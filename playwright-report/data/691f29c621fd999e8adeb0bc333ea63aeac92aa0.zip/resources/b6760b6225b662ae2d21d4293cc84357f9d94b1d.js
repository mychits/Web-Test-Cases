import {
  require_dayjs_min
} from "/node_modules/.vite/deps/chunk-47RKOOME.js?v=819e0a34";
import "/node_modules/.vite/deps/chunk-2TUXWMP5.js?v=819e0a34";
export default require_dayjs_min();
//# sourceMappingURL=dayjs.js.map
