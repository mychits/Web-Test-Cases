import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const EmployeeReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [employeeCustomerData, setEmployeeCustomerData] = useState([]);
  const [loading, setLoading] = useState(false);
  const fetchEmployees = async () => {
    try {
      const res = await api.get("/agent/get-agent");
      setEmployees(res.data);
    } catch (err) {
      console.error("Error fetching employees:", err);
    }
  };
  const fetchEmployeeReport = async (employeeId) => {
    setLoading(true);
    try {
      const res = await api.get(`/agent/getemployeereport?agentId=${employeeId}`);
      setEmployeeCustomerData(res.data);
    } catch (err) {
      console.error("Error fetching employee report:", err);
      setEmployeeCustomerData([]);
    } finally {
      setLoading(false);
    }
  };
  const fetchAllEmployeeReports = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/agent/get-all-employee-report`);
      setEmployeeCustomerData(res.data);
    } catch (err) {
      console.error("Error fetching all employee reports:", err);
      setEmployeeCustomerData([]);
    } finally {
      setLoading(false);
    }
  };
  const handleEmployeeChange = async (value) => {
    setSelectedEmployeeId(value);
    if (value === "ALL") {
      setSelectedEmployeeDetails(null);
      await fetchAllEmployeeReports();
    } else {
      const selectedEmp = employees.find((emp) => emp._id === value);
      setSelectedEmployeeDetails(selectedEmp || null);
      await fetchEmployeeReport(value);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const totalCommission = employeeCustomerData.reduce(
    (acc, curr) => acc + parseFloat(curr.commissionValue?.replace(/,/g, "") || 0),
    0
  );
  const totalBusiness = employeeCustomerData.reduce(
    (acc, curr) => acc + parseFloat(curr.groupValue || 0),
    0
  );
  const totalCustomers = employeeCustomerData.length;
  const processedTableData = employeeCustomerData.map((item, index) => ({
    ...item,
    enrollmentStartDate: item?.enrollmentStartDate?.split("T")[0],
    sl_no: index + 1,
    agentName: item?.employeeName || "-"
  }));
  const baseColumns = [
    { key: "customerName", header: "Customer Name" },
    { key: "customerId", header: "Customer ID" },
    { key: "userPhone", header: "Phone Number" },
    { key: "groupName", header: "Group" },
    { key: "groupValue", header: "Group Value" },
    { key: "enrollmentStartDate", header: "Enrollment Start Date" },
    { key: "ticket", header: "Ticket" },
    { key: "amountPaid", header: "Amount Paid" },
    { key: "toBePaidAmount", header: "To Be Paid" },
    { key: "balance", header: "Balance" },
    { key: "commissionPercent", header: "Commission (%)" },
    { key: "commissionValue", header: "Commission (₹)" },
    { key: "incentives", header: "Incentives" }
  ];
  const slNoColumn = { key: "sl_no", header: "SL. NO" };
  const allColumns = [
    slNoColumn,
    { key: "agentName", header: "Agent Name" },
    ...baseColumns
  ];
  const columns = selectedEmployeeId === "ALL" ? allColumns : [slNoColumn, ...baseColumns];
  return /* @__PURE__ */ jsxDEV("div", { className: " min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
      lineNumber: 122,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center", children: "Reports - Employee" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 124,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center w-full gap-4 bg-violet-50 p-2 w-30 h-40 rounded-3xl border   space-x-2", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-lg text-gray-500 text-center font-semibold mb-2", children: "Employee" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
          lineNumber: 131,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedEmployeeId || void 0,
            onChange: handleEmployeeChange,
            showSearch: true,
            popupMatchSelectWidth: false,
            placeholder: "Search or Select Employee",
            filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
            style: { height: "50px", width: "600px" },
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "ALL", children: "All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                lineNumber: 145,
                columnNumber: 21
              }, this),
              employees.map(
                (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                  emp.name,
                  " - ",
                  emp.phone_number
                ] }, emp._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                  lineNumber: 147,
                  columnNumber: 21
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 134,
            columnNumber: 19
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 130,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 129,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 128,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 127,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ml-6 text-md font-semibold text-violet-700 mb-5", children: [
        /* @__PURE__ */ jsxDEV("label", { children: " Total Business: " }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
          lineNumber: 158,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              className: "rounded-md",
              readOnly: true,
              value: `₹${totalBusiness.toLocaleString("en-IN", {
                minimumFractionDigits: 2
              })}`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 160,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: `text-sm font-mono text-violet-700 pl-1`, children: numberToIndianWords(totalBusiness || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 167,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
          lineNumber: 159,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 157,
        columnNumber: 11
      }, this),
      selectedEmployeeId !== "ALL" && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV("div", { className: "mb-8 bg-gray-50 rounded-md shadow-md p-6 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 177,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: selectedEmployeeDetails.name || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                lineNumber: 178,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 176,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Email" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: selectedEmployeeDetails.email || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                lineNumber: 186,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 184,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Phone Number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 193,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: selectedEmployeeDetails.phone_number || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                lineNumber: 194,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 192,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
          lineNumber: 175,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Adhaar Number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 203,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: selectedEmployeeDetails.adhaar_no || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                lineNumber: 204,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 202,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "PAN Number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 211,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: selectedEmployeeDetails.pan_no || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                lineNumber: 212,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 210,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Pincode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 219,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: selectedEmployeeDetails.pincode || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
                lineNumber: 220,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 218,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
          lineNumber: 201,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Address" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 228,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              value: selectedEmployeeDetails.address || "-",
              readOnly: true,
              className: "border border-gray-300 rounded px-4 py-2 bg-white"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 229,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
          lineNumber: 227,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 174,
        columnNumber: 11
      }, this),
      loading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 240,
        columnNumber: 11
      }, this) : employeeCustomerData.length > 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: processedTableData,
            columns,
            exportedPdfName: `Employee Report`,
            printHeaderKeys: [
              "Name",
              "Phone Number",
              "Total Bussiness"
            ],
            printHeaderValues: [
              selectedEmployeeDetails?.name,
              selectedEmployeeDetails?.phone_number,
              totalBusiness.toLocaleString("en-IN", {
                minimumFractionDigits: 2
              })
            ],
            exportedFileName: `Employee Report-${selectedEmployeeDetails?.name || "all"}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 243,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pr-10 flex justify-end gap-14", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold text-green-700", children: [
              "Total Commission: ₹",
              " ",
              totalCommission.toLocaleString("en-IN", {
                minimumFractionDigits: 2
              })
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 266,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-green-700 mt-1 leading-snug", children: [
              "(",
              numberToIndianWords(totalCommission || 0),
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 272,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 265,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold text-green-700", children: [
              "Total Customers: ",
              totalCustomers
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 279,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-green-700 mt-1 leading-snug", children: [
              "(",
              numberToIndianWords(totalCustomers || 0),
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
              lineNumber: 282,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
            lineNumber: 278,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
          lineNumber: 262,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 242,
        columnNumber: 11
      }, this) : selectedEmployeeId && /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-600", children: "No data found for the selected employee." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
        lineNumber: 292,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
      lineNumber: 123,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
    lineNumber: 121,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx",
    lineNumber: 120,
    columnNumber: 5
  }, this);
};
_s(EmployeeReport, "M4JAOi32egJj1OXxkSQfshmI0Ic=");
_c = EmployeeReport;
export default EmployeeReport;
var _c;
$RefreshReg$(_c, "EmployeeReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUhRLFNBd0hJLFVBeEhKOzJCQXpIUjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLDJCQUEyQjtBQUVwQyxNQUFNQyxpQkFBaUJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSVYsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ1csb0JBQW9CQyxxQkFBcUIsSUFBSVosU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ2EseUJBQXlCQywwQkFBMEIsSUFBSWQsU0FBUyxJQUFJO0FBQzNFLFFBQU0sQ0FBQ2Usc0JBQXNCQyx1QkFBdUIsSUFBSWhCLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNpQixTQUFTQyxVQUFVLElBQUlsQixTQUFTLEtBQUs7QUFHNUMsUUFBTW1CLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU1sQixJQUFJbUIsSUFBSSxrQkFBa0I7QUFDNUNYLG1CQUFhVSxJQUFJRSxJQUFJO0FBQUEsSUFDdkIsU0FBU0MsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDZCQUE2QkYsR0FBRztBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUdBLFFBQU1HLHNCQUFzQixPQUFPQyxlQUFlO0FBQ2hEVCxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTUUsTUFBTSxNQUFNbEIsSUFBSW1CLElBQUksb0NBQW9DTSxVQUFVLEVBQUU7QUFDMUVYLDhCQUF3QkksSUFBSUUsSUFBSTtBQUFBLElBQ2xDLFNBQVNDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSxtQ0FBbUNGLEdBQUc7QUFDcERQLDhCQUF3QixFQUFFO0FBQUEsSUFDNUIsVUFBQztBQUNDRSxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBR0EsUUFBTVUsMEJBQTBCLFlBQVk7QUFDMUNWLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNRSxNQUFNLE1BQU1sQixJQUFJbUIsSUFBSSxnQ0FBZ0M7QUFDMURMLDhCQUF3QkksSUFBSUUsSUFBSTtBQUFBLElBQ2xDLFNBQVNDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSx3Q0FBd0NGLEdBQUc7QUFDekRQLDhCQUF3QixFQUFFO0FBQUEsSUFDNUIsVUFBQztBQUNDRSxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBR0EsUUFBTVcsdUJBQXVCLE9BQU9DLFVBQVU7QUFDNUNsQiwwQkFBc0JrQixLQUFLO0FBQzNCLFFBQUlBLFVBQVUsT0FBTztBQUNuQmhCLGlDQUEyQixJQUFJO0FBQy9CLFlBQU1jLHdCQUF3QjtBQUFBLElBQ2hDLE9BQU87QUFDTCxZQUFNRyxjQUFjdEIsVUFBVXVCLEtBQUssQ0FBQ0MsUUFBUUEsSUFBSUMsUUFBUUosS0FBSztBQUM3RGhCLGlDQUEyQmlCLGVBQWUsSUFBSTtBQUM5QyxZQUFNTCxvQkFBb0JJLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFFQS9CLFlBQVUsTUFBTTtBQUNkb0IsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFHTCxRQUFNZ0Isa0JBQWtCcEIscUJBQXFCcUI7QUFBQUEsSUFDM0MsQ0FBQ0MsS0FBS0MsU0FBU0QsTUFBTUUsV0FBV0QsS0FBS0UsaUJBQWlCQyxRQUFRLE1BQU0sRUFBRSxLQUFLLENBQUM7QUFBQSxJQUM1RTtBQUFBLEVBQ0Y7QUFDQSxRQUFNQyxnQkFBZ0IzQixxQkFBcUJxQjtBQUFBQSxJQUN6QyxDQUFDQyxLQUFLQyxTQUFTRCxNQUFNRSxXQUFXRCxLQUFLSyxjQUFjLENBQUM7QUFBQSxJQUNwRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNQyxpQkFBaUI3QixxQkFBcUI4QjtBQUU1QyxRQUFNQyxxQkFBcUIvQixxQkFBcUJnQyxJQUFJLENBQUNDLE1BQU1DLFdBQVc7QUFBQSxJQUNwRSxHQUFHRDtBQUFBQSxJQUNIRSxxQkFBcUJGLE1BQU1FLHFCQUFxQkMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLElBQzVEQyxPQUFPSCxRQUFRO0FBQUEsSUFDZkksV0FBV0wsTUFBTU0sZ0JBQWdCO0FBQUEsRUFDbkMsRUFBRTtBQUVGLFFBQU1DLGNBQWM7QUFBQSxJQUNsQixFQUFFQyxLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLFFBQVE7QUFBQSxJQUNwQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVELEtBQUssdUJBQXVCQyxRQUFRLHdCQUF3QjtBQUFBLElBQzlELEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxhQUFhO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFRCxLQUFLLHFCQUFxQkMsUUFBUSxpQkFBaUI7QUFBQSxJQUNyRCxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxpQkFBaUI7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLEVBQUM7QUFHN0MsUUFBTUMsYUFBYSxFQUFFRixLQUFLLFNBQVNDLFFBQVEsU0FBUztBQUVwRCxRQUFNRSxhQUFhO0FBQUEsSUFDakJEO0FBQUFBLElBQ0EsRUFBRUYsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxHQUFHRjtBQUFBQSxFQUFXO0FBR2hCLFFBQU1LLFVBQVVqRCx1QkFBdUIsUUFDbkNnRCxhQUNBLENBQUNELFlBQVksR0FBR0gsV0FBVztBQUkvQixTQUNFLHVCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwyQkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxrQ0FBaUMsa0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxNQUdqRSx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsMkdBQ2IsaUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsOERBQTZELHdCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPNUMsc0JBQXNCa0Q7QUFBQUEsWUFDN0IsVUFBVWhDO0FBQUFBLFlBQ1Y7QUFBQSxZQUNBLHVCQUF1QjtBQUFBLFlBQ3ZCLGFBQVk7QUFBQSxZQUNaLGNBQWMsQ0FBQ2lDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxTQUFTLEVBQUVDLFlBQVksRUFBRUMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsWUFFdkUsT0FBTyxFQUFFRSxRQUFRLFFBQVFDLE9BQU8sUUFBUTtBQUFBLFlBRXhDO0FBQUEscUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxPQUFNLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGNBQzdCNUQsVUFBVXNDO0FBQUFBLGdCQUFJLENBQUNkLFFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUlDLEtBQ3JDRDtBQUFBQSxzQkFBSXFDO0FBQUFBLGtCQUFLO0FBQUEsa0JBQUlyQyxJQUFJc0M7QUFBQUEscUJBREF0QyxJQUFJQyxLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUE7QUFBQSxVQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpQkE7QUFBQSxXQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSwrQkFBQyxXQUFNLGlDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUN4Qix1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsT0FBTyxJQUFJUSxjQUFjOEIsZUFBZSxTQUFTO0FBQUEsZ0JBQy9DQyx1QkFBdUI7QUFBQSxjQUN6QixDQUFDLENBQUM7QUFBQTtBQUFBLFlBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS087QUFBQSxVQUVQLHVCQUFDLFNBQUksV0FBVywwQ0FDYm5FLDhCQUFvQm9DLGlCQUFpQixDQUFDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQy9CLHVCQUF1QixTQUFTRSwyQkFDL0IsdUJBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLG9CQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBQ2hEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0Esd0JBQXdCeUQsUUFBUTtBQUFBLGdCQUN2QztBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRytEO0FBQUEsZUFMakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDRCQUEyQixxQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUNqRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU96RCx3QkFBd0I2RCxTQUFTO0FBQUEsZ0JBQ3hDO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHK0Q7QUFBQSxlQUxqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLDRCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLFlBQ3hEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTzdELHdCQUF3QjBELGdCQUFnQjtBQUFBLGdCQUMvQztBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRytEO0FBQUEsZUFMakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDRCQUEyQiw2QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxZQUN6RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8xRCx3QkFBd0I4RCxhQUFhO0FBQUEsZ0JBQzVDO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHK0Q7QUFBQSxlQUxqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLDBCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQ3REO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTzlELHdCQUF3QitELFVBQVU7QUFBQSxnQkFDekM7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUcrRDtBQUFBLGVBTGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw0QkFBMkIsdUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFDbkQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPL0Qsd0JBQXdCZ0UsV0FBVztBQUFBLGdCQUMxQztBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRytEO0FBQUEsZUFMakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw0QkFBMkIsdUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9oRSx3QkFBd0JpRSxXQUFXO0FBQUEsY0FDMUM7QUFBQSxjQUNBLFdBQVU7QUFBQTtBQUFBLFlBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRytEO0FBQUEsYUFMakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0E1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZEQTtBQUFBLE1BSUQ3RCxVQUNDLHVCQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQyxJQUM5QkYscUJBQXFCOEIsU0FBUyxJQUNoQyxtQ0FDRTtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNQztBQUFBQSxZQUNOO0FBQUEsWUFDQSxpQkFBaUI7QUFBQSxZQUNqQixpQkFBaUI7QUFBQSxjQUNmO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUFpQjtBQUFBLFlBRW5CLG1CQUFtQjtBQUFBLGNBQ2pCakMseUJBQXlCeUQ7QUFBQUEsY0FDekJ6RCx5QkFBeUIwRDtBQUFBQSxjQUN6QjdCLGNBQWM4QixlQUFlLFNBQVM7QUFBQSxnQkFDcENDLHVCQUF1QjtBQUFBLGNBQ3pCLENBQUM7QUFBQSxZQUFDO0FBQUEsWUFFSixrQkFBa0IsbUJBQW1CNUQseUJBQXlCeUQsUUFBUSxLQUFLO0FBQUE7QUFBQSxVQWhCN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZ0JvRjtBQUFBLFFBR3BGLHVCQUFDLFNBQUksV0FBVSxzQ0FHYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdDQUF1QztBQUFBO0FBQUEsY0FDaEM7QUFBQSxjQUNuQm5DLGdCQUFnQnFDLGVBQWUsU0FBUztBQUFBLGdCQUN2Q0MsdUJBQXVCO0FBQUEsY0FDekIsQ0FBQztBQUFBLGlCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FBMkM7QUFBQTtBQUFBLGNBQ3REbkUsb0JBQW9CNkIsbUJBQW1CLENBQUM7QUFBQSxjQUFFO0FBQUEsaUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdDQUF1QztBQUFBO0FBQUEsY0FDbENTO0FBQUFBLGlCQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsNENBQTJDO0FBQUE7QUFBQSxjQUN0RHRDLG9CQUFvQnNDLGtCQUFrQixDQUFDO0FBQUEsY0FBRTtBQUFBLGlCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFdBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQ0EsSUFFQWpDLHNCQUNFLHVCQUFDLE9BQUUsV0FBVSw2QkFBNEIsd0RBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBM0tOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4S0E7QUFBQSxPQWhMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUxBLEtBbExGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtTEE7QUFFSjtBQUFFSCxHQXBTSUQsZ0JBQWM7QUFBQXdFLEtBQWR4RTtBQXNTTixlQUFlQTtBQUFlLElBQUF3RTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTZWxlY3QiLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJFbXBsb3llZVJlcG9ydCIsIl9zIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwic2VsZWN0ZWRFbXBsb3llZUlkIiwic2V0U2VsZWN0ZWRFbXBsb3llZUlkIiwic2VsZWN0ZWRFbXBsb3llZURldGFpbHMiLCJzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyIsImVtcGxveWVlQ3VzdG9tZXJEYXRhIiwic2V0RW1wbG95ZWVDdXN0b21lckRhdGEiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZldGNoRW1wbG95ZWVzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoRW1wbG95ZWVSZXBvcnQiLCJlbXBsb3llZUlkIiwiZmV0Y2hBbGxFbXBsb3llZVJlcG9ydHMiLCJoYW5kbGVFbXBsb3llZUNoYW5nZSIsInZhbHVlIiwic2VsZWN0ZWRFbXAiLCJmaW5kIiwiZW1wIiwiX2lkIiwidG90YWxDb21taXNzaW9uIiwicmVkdWNlIiwiYWNjIiwiY3VyciIsInBhcnNlRmxvYXQiLCJjb21taXNzaW9uVmFsdWUiLCJyZXBsYWNlIiwidG90YWxCdXNpbmVzcyIsImdyb3VwVmFsdWUiLCJ0b3RhbEN1c3RvbWVycyIsImxlbmd0aCIsInByb2Nlc3NlZFRhYmxlRGF0YSIsIm1hcCIsIml0ZW0iLCJpbmRleCIsImVucm9sbG1lbnRTdGFydERhdGUiLCJzcGxpdCIsInNsX25vIiwiYWdlbnROYW1lIiwiZW1wbG95ZWVOYW1lIiwiYmFzZUNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJzbE5vQ29sdW1uIiwiYWxsQ29sdW1ucyIsImNvbHVtbnMiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiaGVpZ2h0Iiwid2lkdGgiLCJuYW1lIiwicGhvbmVfbnVtYmVyIiwidG9Mb2NhbGVTdHJpbmciLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJlbWFpbCIsImFkaGFhcl9ubyIsInBhbl9ubyIsInBpbmNvZGUiLCJhZGRyZXNzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRW1wbG95ZWVSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCJcclxuXHJcbmNvbnN0IEVtcGxveWVlUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWVJZCwgc2V0U2VsZWN0ZWRFbXBsb3llZUlkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlRGV0YWlscywgc2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2VtcGxveWVlQ3VzdG9tZXJEYXRhLCBzZXRFbXBsb3llZUN1c3RvbWVyRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1hZ2VudFwiKTtcclxuICAgICAgc2V0RW1wbG95ZWVzKHJlcy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzOlwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlUmVwb3J0ID0gYXN5bmMgKGVtcGxveWVlSWQpID0+IHtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvYWdlbnQvZ2V0ZW1wbG95ZWVyZXBvcnQ/YWdlbnRJZD0ke2VtcGxveWVlSWR9YCk7XHJcbiAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKHJlcy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWUgcmVwb3J0OlwiLCBlcnIpO1xyXG4gICAgICBzZXRFbXBsb3llZUN1c3RvbWVyRGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3QgZmV0Y2hBbGxFbXBsb3llZVJlcG9ydHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL2FnZW50L2dldC1hbGwtZW1wbG95ZWUtcmVwb3J0YCk7XHJcbiAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKHJlcy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWxsIGVtcGxveWVlIHJlcG9ydHM6XCIsIGVycik7XHJcbiAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVFbXBsb3llZUNoYW5nZSA9IGFzeW5jICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRFbXBsb3llZUlkKHZhbHVlKTtcclxuICAgIGlmICh2YWx1ZSA9PT0gXCJBTExcIikge1xyXG4gICAgICBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyhudWxsKTtcclxuICAgICAgYXdhaXQgZmV0Y2hBbGxFbXBsb3llZVJlcG9ydHMoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkRW1wID0gZW1wbG95ZWVzLmZpbmQoKGVtcCkgPT4gZW1wLl9pZCA9PT0gdmFsdWUpO1xyXG4gICAgICBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyhzZWxlY3RlZEVtcCB8fCBudWxsKTtcclxuICAgICAgYXdhaXQgZmV0Y2hFbXBsb3llZVJlcG9ydCh2YWx1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuXHJcbiAgY29uc3QgdG90YWxDb21taXNzaW9uID0gZW1wbG95ZWVDdXN0b21lckRhdGEucmVkdWNlKFxyXG4gICAgKGFjYywgY3VycikgPT4gYWNjICsgcGFyc2VGbG9hdChjdXJyLmNvbW1pc3Npb25WYWx1ZT8ucmVwbGFjZSgvLC9nLCBcIlwiKSB8fCAwKSxcclxuICAgIDBcclxuICApO1xyXG4gIGNvbnN0IHRvdGFsQnVzaW5lc3MgPSBlbXBsb3llZUN1c3RvbWVyRGF0YS5yZWR1Y2UoXHJcbiAgICAoYWNjLCBjdXJyKSA9PiBhY2MgKyBwYXJzZUZsb2F0KGN1cnIuZ3JvdXBWYWx1ZSB8fCAwKSxcclxuICAgIDBcclxuICApO1xyXG4gIGNvbnN0IHRvdGFsQ3VzdG9tZXJzID0gZW1wbG95ZWVDdXN0b21lckRhdGEubGVuZ3RoO1xyXG5cclxuICBjb25zdCBwcm9jZXNzZWRUYWJsZURhdGEgPSBlbXBsb3llZUN1c3RvbWVyRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgLi4uaXRlbSxcclxuICAgIGVucm9sbG1lbnRTdGFydERhdGU6IGl0ZW0/LmVucm9sbG1lbnRTdGFydERhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICBhZ2VudE5hbWU6IGl0ZW0/LmVtcGxveWVlTmFtZSB8fCBcIi1cIixcclxuICB9KSk7XHJcblxyXG4gIGNvbnN0IGJhc2VDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJOYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElEXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBWYWx1ZVwiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsbWVudFN0YXJ0RGF0ZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBTdGFydCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFBhaWRcIiwgaGVhZGVyOiBcIkFtb3VudCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcInRvQmVQYWlkQW1vdW50XCIsIGhlYWRlcjogXCJUbyBCZSBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29tbWlzc2lvblBlcmNlbnRcIiwgaGVhZGVyOiBcIkNvbW1pc3Npb24gKCUpXCIgfSxcclxuICAgIHsga2V5OiBcImNvbW1pc3Npb25WYWx1ZVwiLCBoZWFkZXI6IFwiQ29tbWlzc2lvbiAo4oK5KVwiIH0sXHJcbiAgICB7IGtleTogXCJpbmNlbnRpdmVzXCIsIGhlYWRlcjogXCJJbmNlbnRpdmVzXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBzbE5vQ29sdW1uID0geyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH07XHJcblxyXG4gIGNvbnN0IGFsbENvbHVtbnMgPSBbXHJcbiAgICBzbE5vQ29sdW1uLFxyXG4gICAgeyBrZXk6IFwiYWdlbnROYW1lXCIsIGhlYWRlcjogXCJBZ2VudCBOYW1lXCIgfSxcclxuICAgIC4uLmJhc2VDb2x1bW5zLFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBzZWxlY3RlZEVtcGxveWVlSWQgPT09IFwiQUxMXCJcclxuICAgID8gYWxsQ29sdW1uc1xyXG4gICAgOiBbc2xOb0NvbHVtbiwgLi4uYmFzZUNvbHVtbnNdO1xyXG5cclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIiBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbXQtMzBcIj5cclxuICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyXCI+UmVwb3J0cyAtIEVtcGxveWVlPC9oMT5cclxuXHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB3LWZ1bGwgZ2FwLTQgYmctdmlvbGV0LTUwIHAtMiB3LTMwIGgtNDAgcm91bmRlZC0zeGwgYm9yZGVyICAgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtbGcgdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlciBmb250LXNlbWlib2xkIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVtcGxveWVlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIG9yIFNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjUwcHhcIiwgd2lkdGg6IFwiNjAwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJBTExcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gLSB7ZW1wLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTYgdGV4dC1tZCBmb250LXNlbWlib2xkIHRleHQtdmlvbGV0LTcwMCBtYi01XCI+XHJcbiAgICAgICAgICAgIDxsYWJlbD4gVG90YWwgQnVzaW5lc3M6IDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Digrkke3RvdGFsQnVzaW5lc3MudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgIH0pfWB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tb25vIHRleHQtdmlvbGV0LTcwMCBwbC0xYH0+XHJcbiAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0b3RhbEJ1c2luZXNzIHx8IDApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlSWQgIT09IFwiQUxMXCIgJiYgc2VsZWN0ZWRFbXBsb3llZURldGFpbHMgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTggYmctZ3JheS01MCByb3VuZGVkLW1kIHNoYWRvdy1tZCBwLTYgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5OYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLm5hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+RW1haWw8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHMuZW1haWwgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+UGhvbmUgTnVtYmVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5BZGhhYXIgTnVtYmVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLmFkaGFhcl9ubyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5QQU4gTnVtYmVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLnBhbl9ubyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5QaW5jb2RlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLnBpbmNvZGUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkFkZHJlc3M8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlRGV0YWlscy5hZGRyZXNzIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcblxyXG4gICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICApIDogZW1wbG95ZWVDdXN0b21lckRhdGEubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtwcm9jZXNzZWRUYWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgRW1wbG95ZWUgUmVwb3J0YH1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICBcIk5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgXCJQaG9uZSBOdW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBCdXNzaW5lc3NcIixcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgdG90YWxCdXNpbmVzcy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEVtcGxveWVlIFJlcG9ydC0ke3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiYWxsXCJ9LmNzdmB9XHJcblxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHByLTEwIGZsZXgganVzdGlmeS1lbmQgZ2FwLTE0XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFRvdGFsIENvbW1pc3Npb24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBUb3RhbCBDb21taXNzaW9uOiDigrl7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAge3RvdGFsQ29tbWlzc2lvbi50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyZWVuLTcwMCBtdC0xIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICh7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0b3RhbENvbW1pc3Npb24gfHwgMCl9KVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBUb3RhbCBDdXN0b21lcnMgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBUb3RhbCBDdXN0b21lcnM6IHt0b3RhbEN1c3RvbWVyc31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyZWVuLTcwMCBtdC0xIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICh7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0b3RhbEN1c3RvbWVycyB8fCAwKX0pXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlSWQgJiYgKFxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgIE5vIGRhdGEgZm91bmQgZm9yIHRoZSBzZWxlY3RlZCBlbXBsb3llZS5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVtcGxveWVlUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW1wbG95ZWVSZXBvcnQuanN4In0=