import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayoutSalaryReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import {
  Select,
  Tooltip,
  notification,
  Dropdown,
  Button,
  DatePicker
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import SalarySlipPrint from "/src/components/printFormats/SalarySlipPrint.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import EditSalaryModal from "/src/components/modals/EditSalaryModal.jsx";
const { RangePicker } = DatePicker;
const { Option } = Select;
const PayoutSalaryReport = () => {
  _s();
  const paymentFor = "salary";
  const [api, contextHolder] = notification.useNotification();
  const [filterEmp, setFilterEmp] = useState("");
  const [filterMonth, setFilterMonth] = useState("");
  const [customFromDate, setCustomFromDate] = useState("");
  const [customToDate, setCustomToDate] = useState("");
  const [salaryPayments, setSalaryPayments] = useState([]);
  const [agents, setAgents] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [summaryData, setSummaryData] = useState({
    totalPaid: 0,
    totalSalary: 0,
    latestPayment: "-",
    latestMonth: "-",
    numberOfPayments: 0
  });
  const fetchAgents = async () => {
    try {
      const response = await API.get("/employee");
      setAgents(response.data?.employee || []);
    } catch (error) {
      console.error("Failed to fetch Agents", error);
    }
  };
  const calculateSummary = (payments) => {
    if (!payments.length) {
      setSummaryData({
        totalPaid: 0,
        totalSalary: 0,
        latestPayment: "-",
        latestMonth: "-",
        numberOfPayments: 0
      });
      return;
    }
    const totalPaid = payments.reduce(
      (total, item) => total + Number(item.total_paid_amount || 0),
      0
    );
    const totalSalary = payments.reduce(
      (total, item) => total + Number(item.total_salary || 0),
      0
    );
    const latestRec = [...payments].sort(
      (a, b) => new Date(b.pay_date) - new Date(a.pay_date)
    )[0];
    setSummaryData({
      totalPaid,
      totalSalary,
      latestPayment: latestRec?.total_paid_amount || 0,
      latestMonth: latestRec?.salaryMonth || "-",
      numberOfPayments: payments.length
    });
  };
  const fetchSalaryPayments = async () => {
    setIsLoading(true);
    try {
      const params = {};
      if (filterEmp) params.empId = filterEmp;
      if (filterMonth && filterMonth !== "custom" && !customFromDate && !customToDate)
        params.month = filterMonth;
      if (customFromDate) params.from_date = customFromDate;
      if (customToDate) params.to_date = customToDate;
      const response = await API.get("/salary/get-salary-report", { params });
      const salaryArray = Array.isArray(response.data.data) ? response.data.data : [];
      const filtered = salaryArray.map((payment, index) => {
        const meta = payment.payout_metadata || {};
        return {
          id: index + 1,
          _id: payment._id,
          employee_id: payment.employee_id?._id,
          pay_date: meta?.date_range?.from?.split("T")[0] || payment.pay_date?.split("T")[0] || "-",
          agent_name: payment.employee_id?.name || payment.employee_id?.full_name || "N/A",
          from_date: meta?.date_range?.from?.split("T")[0] || "-",
          to_date: meta?.date_range?.to?.split("T")[0] || "-",
          total_salary: meta?.total_salary || 0,
          total_paid_amount: (meta?.total_paid_amount).toFixed(2) || 0,
          months_included: meta?.months_included?.join(", ") || "-",
          pay_type: meta?.pay_type || "N/A",
          receipt_no: meta?.receipt_no || payment.receipt_no || "-",
          disbursed_by: meta?.disbursed_by || payment.disbursed_by || "Admin",
          salaryMonth: meta?.months_included?.[0] || "-"
        };
      });
      setSalaryPayments(filtered);
      calculateSummary(filtered);
    } catch (error) {
      console.error("Failed to fetch salary payments", error);
      setSalaryPayments([]);
      setSummaryData({
        totalPaid: 0,
        totalSalary: 0,
        latestPayment: "-",
        latestMonth: "-",
        numberOfPayments: 0
      });
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchAgents();
  }, []);
  useEffect(() => {
    fetchSalaryPayments();
  }, [filterEmp, filterMonth, customFromDate, customToDate]);
  const salaryColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Pay Date" },
    { key: "agent_name", header: "Agent" },
    { key: "total_paid_amount", header: "Total Paid Amount (₹)" },
    { key: "total_salary", header: "Total Salary Amount (₹)" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "from_date", header: "From Date" },
    { key: "to_date", header: "To Date" },
    { key: "salaryMonth", header: "Month" },
    { key: "note", header: "Note" },
    { key: "disbursed_by", header: "Disbursed by" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4", children: "Payout Salary Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
        lineNumber: 1013,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm text-gray-700", children: "Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1018,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "Select Employee",
              value: filterEmp || void 0,
              onChange: setFilterEmp,
              className: "w-56",
              allowClear: true,
              children: [
                /* @__PURE__ */ jsxDEV(Option, { value: "", children: "All Employees" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
                  lineNumber: 1026,
                  columnNumber: 17
                }, this),
                agents.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Option, { value: emp._id, children: emp.name || emp.full_name }, emp._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
                    lineNumber: 1028,
                    columnNumber: 17
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1019,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
          lineNumber: 1017,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm text-gray-700", children: "Month" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1036,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "Select Month",
              value: filterMonth || void 0,
              onChange: (value) => {
                setFilterMonth(value);
                if (value !== "custom") {
                  setCustomFromDate("");
                  setCustomToDate("");
                }
              },
              className: "w-40",
              allowClear: true,
              children: [
                /* @__PURE__ */ jsxDEV(Option, { value: "", children: "All Months" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
                  lineNumber: 1050,
                  columnNumber: 17
                }, this),
                [
                  "January",
                  "February",
                  "March",
                  "April",
                  "May",
                  "June",
                  "July",
                  "August",
                  "September",
                  "October",
                  "November",
                  "December"
                ].map(
                  (m) => /* @__PURE__ */ jsxDEV(Option, { value: m, children: m }, m, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
                    lineNumber: 1065,
                    columnNumber: 17
                  }, this)
                ),
                /* @__PURE__ */ jsxDEV(Option, { value: "custom", children: "Custom" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
                  lineNumber: 1069,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1037,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
          lineNumber: 1035,
          columnNumber: 13
        }, this),
        filterMonth === "custom" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm text-gray-700", children: "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1076,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: customFromDate,
                onChange: (e) => setCustomFromDate(e.target.value),
                className: "border rounded px-3 py-2 w-40"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
                lineNumber: 1079,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1075,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm text-gray-700", children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1087,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: customToDate,
                onChange: (e) => setCustomToDate(e.target.value),
                className: "border rounded px-3 py-2 w-40"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
                lineNumber: 1088,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1086,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
          lineNumber: 1074,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => {
              setFilterEmp("");
              setFilterMonth("");
              setCustomFromDate("");
              setCustomToDate("");
              fetchSalaryPayments();
            },
            children: "Clear"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1098,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-5 p-4 rounded-lg  mb-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-sm rounded-lg p-4 w-full sm:w-[180px] text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold block text-violet-700", children: "Total Salary Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1112,
              columnNumber: 17
            }, this),
            "₹",
            summaryData.totalSalary.toFixed(2) || 0
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1111,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-sm rounded-lg p-4 w-full sm:w-[180px] text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold block text-violet-700", children: "Total Paid Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1119,
              columnNumber: 17
            }, this),
            "₹",
            summaryData.totalPaid.toFixed(2) || 0
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1118,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-sm rounded-lg p-4 w-full sm:w-[180px] text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold block text-violet-700", children: "Latest Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1126,
              columnNumber: 17
            }, this),
            "₹",
            summaryData.latestPayment || 0
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1125,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-sm rounded-lg p-4 w-full sm:w-[180px] text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold block text-violet-700", children: "Latest Month" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1133,
              columnNumber: 17
            }, this),
            summaryData.latestMonth || "N/A"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1132,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-sm rounded-lg p-4 w-full sm:w-[180px] text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold block text-violet-700", children: "Number of Payments" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
              lineNumber: 1140,
              columnNumber: 17
            }, this),
            summaryData.numberOfPayments || 0
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
            lineNumber: 1139,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
          lineNumber: 1110,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
        lineNumber: 1016,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-8 bg-white p-6 rounded-lg shadow-md", children: salaryPayments.length > 0 ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: salaryPayments,
          columns: salaryColumns,
          exportedPdfName: "PayOut Salary",
          exportedFileName: "PayOut Salary.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
          lineNumber: 1151,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          data: "Salary Payments",
          failure: salaryPayments.length === 0
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
          lineNumber: 1159,
          columnNumber: 17
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
        lineNumber: 1158,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
        lineNumber: 1149,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
      lineNumber: 1012,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
      lineNumber: 1011,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx",
    lineNumber: 1009,
    columnNumber: 5
  }, this);
};
_s(PayoutSalaryReport, "byrtn+bBa4nQOKqXA0/uye/r57A=", false, function() {
  return [notification.useNotification];
});
_c = PayoutSalaryReport;
export default PayoutSalaryReport;
var _c;
$RefreshReg$(_c, "PayoutSalaryReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayoutSalaryReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBby9CVSxTQTZESSxVQTdESjsyQkFwL0JWO0FBQW9CQSxvQkFBZ0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsWUFBWTtBQUNuQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MscUJBQXFCO0FBQzVCLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxxQkFBcUI7QUFDNUIsTUFBTSxFQUFFQyxZQUFZLElBQUlMO0FBQ3hCLE1BQU0sRUFBRU0sT0FBTyxJQUFJWDtBQW0wQm5CLE1BQU1ZLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQy9CLFFBQU1DLGFBQWE7QUFDbkIsUUFBTSxDQUFDQyxLQUFLQyxhQUFhLElBQUlkLGFBQWFlLGdCQUFnQjtBQUUxRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTNCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM0QixhQUFhQyxjQUFjLElBQUk3QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDOEIsZ0JBQWdCQyxpQkFBaUIsSUFBSS9CLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNnQyxjQUFjQyxlQUFlLElBQUlqQyxTQUFTLEVBQUU7QUFFbkQsUUFBTSxDQUFDa0MsZ0JBQWdCQyxpQkFBaUIsSUFBSW5DLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNvQyxRQUFRQyxTQUFTLElBQUlyQyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDc0MsV0FBV0MsWUFBWSxJQUFJdkMsU0FBUyxLQUFLO0FBRWhELFFBQU0sQ0FBQ3dDLGFBQWFDLGNBQWMsSUFBSXpDLFNBQVM7QUFBQSxJQUM3QzBDLFdBQVc7QUFBQSxJQUNYQyxhQUFhO0FBQUEsSUFDYkMsZUFBZTtBQUFBLElBQ2ZDLGFBQWE7QUFBQSxJQUNiQyxrQkFBa0I7QUFBQSxFQUNwQixDQUFDO0FBRUQsUUFBTUMsY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU05QyxJQUFJK0MsSUFBSSxXQUFXO0FBQzFDWixnQkFBVVcsU0FBU0UsTUFBTUMsWUFBWSxFQUFFO0FBQUEsSUFDekMsU0FBU0MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUVBLFFBQU1FLG1CQUFtQkEsQ0FBQ0MsYUFBYTtBQUNyQyxRQUFJLENBQUNBLFNBQVNDLFFBQVE7QUFDcEJmLHFCQUFlO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLGFBQWE7QUFBQSxRQUNiQyxlQUFlO0FBQUEsUUFDZkMsYUFBYTtBQUFBLFFBQ2JDLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQSxVQUFNSixZQUFZYSxTQUFTRTtBQUFBQSxNQUN6QixDQUFDQyxPQUFPQyxTQUFTRCxRQUFRRSxPQUFPRCxLQUFLRSxxQkFBcUIsQ0FBQztBQUFBLE1BQzNEO0FBQUEsSUFDRjtBQUVBLFVBQU1sQixjQUFjWSxTQUFTRTtBQUFBQSxNQUMzQixDQUFDQyxPQUFPQyxTQUFTRCxRQUFRRSxPQUFPRCxLQUFLRyxnQkFBZ0IsQ0FBQztBQUFBLE1BQ3REO0FBQUEsSUFDRjtBQUVBLFVBQU1DLFlBQVksQ0FBQyxHQUFHUixRQUFRLEVBQUVTO0FBQUFBLE1BQzlCLENBQUNDLEdBQUdDLE1BQU0sSUFBSUMsS0FBS0QsRUFBRUUsUUFBUSxJQUFJLElBQUlELEtBQUtGLEVBQUVHLFFBQVE7QUFBQSxJQUN0RCxFQUFFLENBQUM7QUFFSDNCLG1CQUFlO0FBQUEsTUFDYkM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUMsZUFBZW1CLFdBQVdGLHFCQUFxQjtBQUFBLE1BQy9DaEIsYUFBYWtCLFdBQVdNLGVBQWU7QUFBQSxNQUN2Q3ZCLGtCQUFrQlMsU0FBU0M7QUFBQUEsSUFDN0IsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNYyxzQkFBc0IsWUFBWTtBQUN0Qy9CLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU1nQyxTQUFTLENBQUM7QUFDaEIsVUFBSTdDLFVBQVc2QyxRQUFPQyxRQUFROUM7QUFDOUIsVUFDRUUsZUFDQUEsZ0JBQWdCLFlBQ2hCLENBQUNFLGtCQUNELENBQUNFO0FBRUR1QyxlQUFPRSxRQUFRN0M7QUFDakIsVUFBSUUsZUFBZ0J5QyxRQUFPRyxZQUFZNUM7QUFDdkMsVUFBSUUsYUFBY3VDLFFBQU9JLFVBQVUzQztBQUVuQyxZQUFNZ0IsV0FBVyxNQUFNOUMsSUFBSStDLElBQUksNkJBQTZCLEVBQUVzQixPQUFPLENBQUM7QUFDdEUsWUFBTUssY0FBY0MsTUFBTUMsUUFBUTlCLFNBQVNFLEtBQUtBLElBQUksSUFDaERGLFNBQVNFLEtBQUtBLE9BQ2Q7QUFFSixZQUFNNkIsV0FBV0gsWUFBWUksSUFBSSxDQUFDQyxTQUFTQyxVQUFVO0FBQ25ELGNBQU1DLE9BQU9GLFFBQVFHLG1CQUFtQixDQUFDO0FBQ3pDLGVBQU87QUFBQSxVQUNMQyxJQUFJSCxRQUFRO0FBQUEsVUFDWkksS0FBS0wsUUFBUUs7QUFBQUEsVUFDYkMsYUFBYU4sUUFBUU0sYUFBYUQ7QUFBQUEsVUFDbENsQixVQUNFZSxNQUFNSyxZQUFZQyxNQUFNQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQ3BDVCxRQUFRYixVQUFVc0IsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUM5QjtBQUFBLFVBQ0ZDLFlBQ0VWLFFBQVFNLGFBQWFLLFFBQ3JCWCxRQUFRTSxhQUFhTSxhQUNyQjtBQUFBLFVBQ0ZuQixXQUFXUyxNQUFNSyxZQUFZQyxNQUFNQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxVQUNwRGYsU0FBU1EsTUFBTUssWUFBWU0sSUFBSUosTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsVUFDaEQ1QixjQUFjcUIsTUFBTXJCLGdCQUFnQjtBQUFBLFVBQ3BDRCxvQkFBb0JzQixNQUFNdEIsbUJBQW1Ca0MsUUFBUSxDQUFDLEtBQUs7QUFBQSxVQUMzREMsaUJBQWlCYixNQUFNYSxpQkFBaUJDLEtBQUssSUFBSSxLQUFLO0FBQUEsVUFDdERDLFVBQVVmLE1BQU1lLFlBQVk7QUFBQSxVQUM1QkMsWUFBWWhCLE1BQU1nQixjQUFjbEIsUUFBUWtCLGNBQWM7QUFBQSxVQUN0REMsY0FBY2pCLE1BQU1pQixnQkFBZ0JuQixRQUFRbUIsZ0JBQWdCO0FBQUEsVUFDNUQvQixhQUFhYyxNQUFNYSxrQkFBa0IsQ0FBQyxLQUFLO0FBQUEsUUFDN0M7QUFBQSxNQUNGLENBQUM7QUFFRDdELHdCQUFrQjRDLFFBQVE7QUFDMUJ6Qix1QkFBaUJ5QixRQUFRO0FBQUEsSUFDM0IsU0FBUzNCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERqQix3QkFBa0IsRUFBRTtBQUNwQk0scUJBQWU7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWEMsYUFBYTtBQUFBLFFBQ2JDLGVBQWU7QUFBQSxRQUNmQyxhQUFhO0FBQUEsUUFDYkMsa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDUCxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUE4RCxZQUFVLE1BQU07QUFDZHRELGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTHNELFlBQVUsTUFBTTtBQUNkL0Isd0JBQW9CO0FBQUEsRUFDdEIsR0FBRyxDQUFDNUMsV0FBV0UsYUFBYUUsZ0JBQWdCRSxZQUFZLENBQUM7QUFFekQsUUFBTXNFLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsUUFBUTtBQUFBLElBQ3JDLEVBQUVELEtBQUsscUJBQXFCQyxRQUFRLHdCQUF3QjtBQUFBLElBQzVELEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLDBCQUEwQjtBQUFBLElBQ3pELEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLFFBQVE7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxFQUFDO0FBR2pELFNBQ0UsbUNBQ0doRjtBQUFBQTtBQUFBQSxJQUNELHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrQkFBOEIsb0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUdoRSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLCtCQUE4Qix3QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxVQUN2RDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBWTtBQUFBLGNBQ1osT0FBT0UsYUFBYStFO0FBQUFBLGNBQ3BCLFVBQVU5RTtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUNWLFlBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBTyxPQUFNLElBQUcsNkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUEsZ0JBQzdCUyxPQUFPNEM7QUFBQUEsa0JBQUksQ0FBQzBCLFFBQ1gsdUJBQUMsVUFBcUIsT0FBT0EsSUFBSXBCLEtBQzlCb0IsY0FBSWQsUUFBUWMsSUFBSWIsYUFETmEsSUFBSXBCLEtBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUE7QUFBQSxZQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLCtCQUE4QixxQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBWTtBQUFBLGNBQ1osT0FBTzFELGVBQWU2RTtBQUFBQSxjQUN0QixVQUFVLENBQUNFLFVBQVU7QUFDbkI5RSwrQkFBZThFLEtBQUs7QUFDcEIsb0JBQUlBLFVBQVUsVUFBVTtBQUN0QjVFLG9DQUFrQixFQUFFO0FBQ3BCRSxrQ0FBZ0IsRUFBRTtBQUFBLGdCQUNwQjtBQUFBLGNBQ0Y7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUNWLFlBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBTyxPQUFNLElBQUcsMEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUEsZ0JBQzFCO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsZ0JBQVUsRUFDVitDO0FBQUFBLGtCQUFJLENBQUM0QixNQUNMLHVCQUFDLFVBQWUsT0FBT0EsR0FDcEJBLGVBRFVBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUEsZ0JBQ0QsdUJBQUMsVUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUE7QUFBQTtBQUFBLFlBaEMvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQ0E7QUFBQSxhQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsUUFFQ2hGLGdCQUFnQixZQUNmLG1DQUNFO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwrQkFBOEIseUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9FO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQytFLE1BQU05RSxrQkFBa0I4RSxFQUFFQyxPQUFPSCxLQUFLO0FBQUEsZ0JBQ2pELFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTJDO0FBQUEsZUFSN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwrQkFBOEIsdUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTzNFO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQzZFLE1BQU01RSxnQkFBZ0I0RSxFQUFFQyxPQUFPSCxLQUFLO0FBQUEsZ0JBQy9DLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTJDO0FBQUEsZUFON0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxRQUdGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU07QUFDYmhGLDJCQUFhLEVBQUU7QUFDZkUsNkJBQWUsRUFBRTtBQUNqQkUsZ0NBQWtCLEVBQUU7QUFDcEJFLDhCQUFnQixFQUFFO0FBQ2xCcUMsa0NBQW9CO0FBQUEsWUFDdEI7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsdUNBQXNDLG1DQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBTztBQUFBLFlBQ0w5QixZQUFZRyxZQUFZb0QsUUFBUSxDQUFDLEtBQUs7QUFBQSxlQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsdUNBQXNDLGlDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBTztBQUFBLFlBQ0x2RCxZQUFZRSxVQUFVcUQsUUFBUSxDQUFDLEtBQUs7QUFBQSxlQUp4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsdUNBQXNDLDhCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBTztBQUFBLFlBQ0x2RCxZQUFZSSxpQkFBaUI7QUFBQSxlQUpqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsdUNBQXNDLDRCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQ0osWUFBWUssZUFBZTtBQUFBLGVBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSx1Q0FBc0Msa0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDTCxZQUFZTSxvQkFBb0I7QUFBQSxlQUpuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1DQTtBQUFBLFdBaklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrSUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSwwQ0FDWloseUJBQWVzQixTQUFTLElBQ3ZCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNdEI7QUFBQUEsVUFDTixTQUFTb0U7QUFBQUEsVUFDVCxpQkFBZ0I7QUFBQSxVQUNoQixrQkFBaUI7QUFBQTtBQUFBLFFBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlzQyxJQUd0Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxNQUFLO0FBQUEsVUFDTCxTQUFTcEUsZUFBZXNCLFdBQVc7QUFBQTtBQUFBLFFBSHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUd1QyxLQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUEsS0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsU0ExSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJKQSxLQTVKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkpBO0FBQUEsT0EvSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdLQTtBQUVKO0FBQUVuQyxHQTFUSUQsb0JBQWtCO0FBQUEsVUFFT1YsYUFBYWUsZUFBZTtBQUFBO0FBQUFzRixLQUZyRDNGO0FBNFROLGVBQWVBO0FBQW1CLElBQUEyRjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJTaWRlYmFyIiwiQVBJIiwiTW9kYWwiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiU2VsZWN0IiwiVG9vbHRpcCIsIm5vdGlmaWNhdGlvbiIsIkRyb3Bkb3duIiwiQnV0dG9uIiwiRGF0ZVBpY2tlciIsIlNldHRpbmdTaWRlYmFyIiwiU2FsYXJ5U2xpcFByaW50IiwiSW9NZE1vcmUiLCJFZGl0U2FsYXJ5TW9kYWwiLCJSYW5nZVBpY2tlciIsIk9wdGlvbiIsIlBheW91dFNhbGFyeVJlcG9ydCIsIl9zIiwicGF5bWVudEZvciIsImFwaSIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJmaWx0ZXJFbXAiLCJzZXRGaWx0ZXJFbXAiLCJmaWx0ZXJNb250aCIsInNldEZpbHRlck1vbnRoIiwiY3VzdG9tRnJvbURhdGUiLCJzZXRDdXN0b21Gcm9tRGF0ZSIsImN1c3RvbVRvRGF0ZSIsInNldEN1c3RvbVRvRGF0ZSIsInNhbGFyeVBheW1lbnRzIiwic2V0U2FsYXJ5UGF5bWVudHMiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzdW1tYXJ5RGF0YSIsInNldFN1bW1hcnlEYXRhIiwidG90YWxQYWlkIiwidG90YWxTYWxhcnkiLCJsYXRlc3RQYXltZW50IiwibGF0ZXN0TW9udGgiLCJudW1iZXJPZlBheW1lbnRzIiwiZmV0Y2hBZ2VudHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlbXBsb3llZSIsImVycm9yIiwiY29uc29sZSIsImNhbGN1bGF0ZVN1bW1hcnkiLCJwYXltZW50cyIsImxlbmd0aCIsInJlZHVjZSIsInRvdGFsIiwiaXRlbSIsIk51bWJlciIsInRvdGFsX3BhaWRfYW1vdW50IiwidG90YWxfc2FsYXJ5IiwibGF0ZXN0UmVjIiwic29ydCIsImEiLCJiIiwiRGF0ZSIsInBheV9kYXRlIiwic2FsYXJ5TW9udGgiLCJmZXRjaFNhbGFyeVBheW1lbnRzIiwicGFyYW1zIiwiZW1wSWQiLCJtb250aCIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJzYWxhcnlBcnJheSIsIkFycmF5IiwiaXNBcnJheSIsImZpbHRlcmVkIiwibWFwIiwicGF5bWVudCIsImluZGV4IiwibWV0YSIsInBheW91dF9tZXRhZGF0YSIsImlkIiwiX2lkIiwiZW1wbG95ZWVfaWQiLCJkYXRlX3JhbmdlIiwiZnJvbSIsInNwbGl0IiwiYWdlbnRfbmFtZSIsIm5hbWUiLCJmdWxsX25hbWUiLCJ0byIsInRvRml4ZWQiLCJtb250aHNfaW5jbHVkZWQiLCJqb2luIiwicGF5X3R5cGUiLCJyZWNlaXB0X25vIiwiZGlzYnVyc2VkX2J5IiwidXNlRWZmZWN0Iiwic2FsYXJ5Q29sdW1ucyIsImtleSIsImhlYWRlciIsInVuZGVmaW5lZCIsImVtcCIsInZhbHVlIiwibSIsImUiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYXlvdXRTYWxhcnlSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBBUEkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBUb29sdGlwLFxyXG4gIG5vdGlmaWNhdGlvbixcclxuICBEcm9wZG93bixcclxuICBCdXR0b24sXHJcbiAgRGF0ZVBpY2tlcixcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgU2V0dGluZ1NpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TZXR0aW5nU2lkZWJhclwiO1xyXG5pbXBvcnQgU2FsYXJ5U2xpcFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9TYWxhcnlTbGlwUHJpbnRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEVkaXRTYWxhcnlNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvRWRpdFNhbGFyeU1vZGFsXCI7XHJcbmNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcbmNvbnN0IHsgT3B0aW9uIH0gPSBTZWxlY3Q7XHJcblxyXG4vLyBjb25zdCBQYXlvdXRTYWxhcnlSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgcGF5bWVudEZvciA9IFwic2FsYXJ5XCI7XHJcbi8vICAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcblxyXG4vLyAgIGNvbnN0IFtzaG93U2FsYXJ5TW9kYWwsIHNldFNob3dTYWxhcnlNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW21vZGlmeVBheW1lbnQsIHNldE1vZGlmeVBheW1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFthZG1pbklkLCBzZXRBZG1pbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbZmlsdGVyRW1wLCBzZXRGaWx0ZXJFbXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2ZpbHRlck1vbnRoLCBzZXRGaWx0ZXJNb250aF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbc2FsYXJ5UGF5bWVudHMsIHNldFNhbGFyeVBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3JlUmVuZGVyLCBzZXRSZVJlbmRlcl0gPSB1c2VTdGF0ZSgwKTtcclxuLy8gICBjb25zdCBbaXNFZGl0aW5nLCBzZXRJc0VkaXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtlZGl0aW5nU2FsYXJ5LCBzZXRFZGl0aW5nU2FsYXJ5XSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuLy8gICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4vLyAgICAgbWVzc2FnZTogXCJcIixcclxuLy8gICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4vLyAgICAgbm9SZWxvYWQ6IGZhbHNlLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICAvLyDinIUgRmV0Y2ggZW1wbG95ZWUgbGlzdFxyXG4vLyAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4vLyAgICAgICBzZXRBZ2VudHMocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBBZ2VudHNcIiwgZXJyb3IpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIOKchSBGZXRjaCBzYWxhcnkgcGF5bWVudHMgd2l0aCBtb250aCBmaWx0ZXIgKGZyb20gbW9udGhzX2luY2x1ZGVkKVxyXG4vLyAgIC8vIGNvbnN0IGZldGNoU2FsYXJ5UGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgLy8gICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgLy8gICB0cnkge1xyXG4vLyAgIC8vICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvc2FsYXJ5L2dldC1zYWxhcnktcmVwb3J0XCIpO1xyXG4vLyAgIC8vICAgICBjb25zdCBzYWxhcnlBcnJheSA9IEFycmF5LmlzQXJyYXkocmVzcG9uc2UuZGF0YSlcclxuLy8gICAvLyAgICAgICA/IHJlc3BvbnNlLmRhdGFcclxuLy8gICAvLyAgICAgICA6IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbi8vICAgLy8gICAgIC8vIOKchSBUcmFuc2Zvcm0gZGF0YVxyXG4vLyAgIC8vICAgICBsZXQgZmlsdGVyZWQgPSBzYWxhcnlBcnJheS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiB7XHJcbi8vICAgLy8gICAgICAgY29uc3QgbWV0YSA9IHBheW1lbnQucGF5b3V0X21ldGFkYXRhIHx8IHt9O1xyXG4vLyAgIC8vICAgICAgIGNvbnN0IHNhbGFyeU1vbnRoID0gbWV0YT8ubW9udGhzX2luY2x1ZGVkPy5bMF0gfHwgbnVsbDtcclxuLy8gICAvLyAgICAgICByZXR1cm4ge1xyXG4vLyAgIC8vICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuLy8gICAvLyAgICAgICAgIF9pZDogcGF5bWVudC5faWQsXHJcbi8vICAgLy8gICAgICAgICBwYXlfZGF0ZTpcclxuLy8gICAvLyAgICAgICAgICAgbWV0YT8uZGF0ZV9yYW5nZT8uZnJvbT8uc3BsaXQoXCJUXCIpWzBdIHx8XHJcbi8vICAgLy8gICAgICAgICAgIHBheW1lbnQucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fFxyXG4vLyAgIC8vICAgICAgICAgICBcIi1cIixcclxuLy8gICAvLyAgICAgICAgIGFnZW50X25hbWU6XHJcbi8vICAgLy8gICAgICAgICAgIHBheW1lbnQuZW1wbG95ZWVfaWQ/Lm5hbWUgfHxcclxuLy8gICAvLyAgICAgICAgICAgcGF5bWVudC5lbXBsb3llZV9pZD8uZnVsbF9uYW1lIHx8XHJcbi8vICAgLy8gICAgICAgICAgIFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICBmcm9tX2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LmZyb20/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuLy8gICAvLyAgICAgICAgIHRvX2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LnRvPy5zcGxpdChcIlRcIilbMF0gfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICB0b3RhbF9zYWxhcnk6IG1ldGE/LnRvdGFsX3NhbGFyeSB8fCAwLFxyXG4vLyAgIC8vICAgICAgICAgdG90YWxfcGFpZF9hbW91bnQ6IG1ldGE/LnRvdGFsX3BhaWRfYW1vdW50IHx8IDAsXHJcbi8vICAgLy8gICAgICAgICBtb250aHNfaW5jbHVkZWQ6IG1ldGE/Lm1vbnRoc19pbmNsdWRlZD8uam9pbihcIiwgXCIpIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgcGF5X3R5cGU6IG1ldGE/LnBheV90eXBlIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICByZWNlaXB0X25vOiBtZXRhPy5yZWNlaXB0X25vIHx8IHBheW1lbnQucmVjZWlwdF9ubyB8fCBcIi1cIixcclxuLy8gICAvLyAgICAgICAgIGRpc2J1cnNlZF9ieTogbWV0YT8uZGlzYnVyc2VkX2J5IHx8IHBheW1lbnQuZGlzYnVyc2VkX2J5IHx8IFwiQWRtaW5cIixcclxuLy8gICAvLyAgICAgICAgIHNhbGFyeU1vbnRoLFxyXG4vLyAgIC8vICAgICAgICAgbm90ZTogbWV0YT8ubm90ZSB8fCBcIi1cIixcclxuLy8gICAvLyAgICAgICB9O1xyXG4vLyAgIC8vICAgICB9KTtcclxuXHJcbi8vICAgLy8gICAgIC8vIOKchSBBcHBseSBmaWx0ZXJzXHJcbi8vICAgLy8gICAgIGlmIChmaWx0ZXJFbXApIHtcclxuLy8gICAvLyAgICAgICBmaWx0ZXJlZCA9IGZpbHRlcmVkLmZpbHRlcigocCkgPT4gcC5faWQgJiYgcC5faWQgPT09IGZpbHRlckVtcCk7XHJcbi8vICAgLy8gICAgIH1cclxuLy8gICAvLyAgICAgaWYgKGZpbHRlck1vbnRoKSB7XHJcbi8vICAgLy8gICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIoXHJcbi8vICAgLy8gICAgICAgICAocCkgPT5cclxuLy8gICAvLyAgICAgICAgICAgcC5zYWxhcnlNb250aCAmJlxyXG4vLyAgIC8vICAgICAgICAgICBwLnNhbGFyeU1vbnRoLnRvTG93ZXJDYXNlKCkgPT09IGZpbHRlck1vbnRoLnRvTG93ZXJDYXNlKClcclxuLy8gICAvLyAgICAgICApO1xyXG4vLyAgIC8vICAgICB9XHJcblxyXG4vLyAgIC8vICAgICBzZXRTYWxhcnlQYXltZW50cyhmaWx0ZXJlZCk7XHJcbi8vICAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgIC8vICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHNhbGFyeSBwYXltZW50c1wiLCBlcnJvcik7XHJcbi8vICAgLy8gICAgIHNldFNhbGFyeVBheW1lbnRzKFtdKTtcclxuLy8gICAvLyAgIH0gZmluYWxseSB7XHJcbi8vICAgLy8gICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgLy8gICB9XHJcbi8vICAgLy8gfTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hTYWxhcnlQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgdHJ5IHtcclxuLy8gICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xyXG4vLyAgICAgaWYgKGZpbHRlckVtcCkgcGFyYW1zLmVtcElkID0gZmlsdGVyRW1wO1xyXG4vLyAgICAgaWYgKGZpbHRlck1vbnRoKSBwYXJhbXMubW9udGggPSBmaWx0ZXJNb250aDtcclxuXHJcbi8vICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvc2FsYXJ5L2dldC1zYWxhcnktcmVwb3J0XCIsIHsgcGFyYW1zIH0pO1xyXG4vLyAgICAgY29uc3Qgc2FsYXJ5QXJyYXkgPSBBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEuZGF0YSkgPyByZXNwb25zZS5kYXRhLmRhdGEgOiBbXTtcclxuXHJcbi8vICAgICBjb25zdCBmaWx0ZXJlZCA9IHNhbGFyeUFycmF5Lm1hcCgocGF5bWVudCwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgY29uc3QgbWV0YSA9IHBheW1lbnQucGF5b3V0X21ldGFkYXRhIHx8IHt9O1xyXG4vLyAgICAgICBjb25zdCBzYWxhcnlNb250aCA9IG1ldGE/Lm1vbnRoc19pbmNsdWRlZD8uWzBdIHx8IG51bGw7XHJcbi8vICAgICAgIHJldHVybiB7XHJcbi8vICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBfaWQ6IHBheW1lbnQuX2lkLFxyXG4vLyAgICAgICAgIGVtcGxveWVlX2lkOiBwYXltZW50LmVtcGxveWVlX2lkPy5faWQsXHJcbi8vICAgICAgICAgcGF5X2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LmZyb20/LnNwbGl0KFwiVFwiKVswXSB8fCBwYXltZW50LnBheV9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgXCItXCIsXHJcbi8vICAgICAgICAgYWdlbnRfbmFtZTogcGF5bWVudC5lbXBsb3llZV9pZD8ubmFtZSB8fCBwYXltZW50LmVtcGxveWVlX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICBmcm9tX2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LmZyb20/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuLy8gICAgICAgICB0b19kYXRlOiBtZXRhPy5kYXRlX3JhbmdlPy50bz8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIHRvdGFsX3NhbGFyeTogbWV0YT8udG90YWxfc2FsYXJ5IHx8IDAsXHJcbi8vICAgICAgICAgdG90YWxfcGFpZF9hbW91bnQ6IG1ldGE/LnRvdGFsX3BhaWRfYW1vdW50IHx8IDAsXHJcbi8vICAgICAgICAgbW9udGhzX2luY2x1ZGVkOiBtZXRhPy5tb250aHNfaW5jbHVkZWQ/LmpvaW4oXCIsIFwiKSB8fCBcIi1cIixcclxuLy8gICAgICAgICBwYXlfdHlwZTogbWV0YT8ucGF5X3R5cGUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICByZWNlaXB0X25vOiBtZXRhPy5yZWNlaXB0X25vIHx8IHBheW1lbnQucmVjZWlwdF9ubyB8fCBcIi1cIixcclxuLy8gICAgICAgICBkaXNidXJzZWRfYnk6IG1ldGE/LmRpc2J1cnNlZF9ieSB8fCBwYXltZW50LmRpc2J1cnNlZF9ieSB8fCBcIkFkbWluXCIsXHJcbi8vICAgICAgICAgc2FsYXJ5TW9udGgsXHJcbi8vICAgICAgICAgbm90ZTogbWV0YT8ubm90ZSB8fCBcIi1cIixcclxuLy8gICAgICAgfTtcclxuLy8gICAgIH0pO1xyXG5cclxuLy8gICAgIHNldFNhbGFyeVBheW1lbnRzKGZpbHRlcmVkKTtcclxuLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBzYWxhcnkgcGF5bWVudHNcIiwgZXJyb3IpO1xyXG4vLyAgICAgc2V0U2FsYXJ5UGF5bWVudHMoW10pO1xyXG4vLyAgIH0gZmluYWxseSB7XHJcbi8vICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgIH1cclxuLy8gfTtcclxuXHJcbi8vICAgLy8g4pyFIEluaXRpYWwgc2V0dXBcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuLy8gICAgIGNvbnN0IHVzZXJPYmogPSB1c2VyID8gSlNPTi5wYXJzZSh1c2VyKSA6IHt9O1xyXG4vLyAgICAgc2V0QWRtaW5JZCh1c2VyT2JqLl9pZCk7XHJcbi8vICAgICBzZXRBZG1pbk5hbWUodXNlck9iai5uYW1lIHx8IFwiXCIpO1xyXG4vLyAgICAgaWYgKHVzZXJPYmo/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQpIHtcclxuLy8gICAgICAgc2V0TW9kaWZ5UGF5bWVudChcclxuLy8gICAgICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZC5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9wYXltZW50ID09PSBcInRydWVcIlxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgLy8g4pyFIEF1dG8taGlkZSBhbGVydFxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBpZiAoYWxlcnRDb25maWcudmlzaWJpbGl0eSAmJiBhbGVydENvbmZpZy5ub1JlbG9hZCkge1xyXG4vLyAgICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4vLyAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSk7XHJcbi8vICAgICAgIH0sIDQwMDApO1xyXG4vLyAgICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbYWxlcnRDb25maWcudmlzaWJpbGl0eV0pO1xyXG5cclxuLy8gICAvLyDinIUgRmV0Y2ggb24gbW91bnQgb3IgZmlsdGVyc1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBmZXRjaEFnZW50cygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoU2FsYXJ5UGF5bWVudHMoKTtcclxuLy8gICB9LCBbZmlsdGVyRW1wLCBmaWx0ZXJNb250aCwgcmVSZW5kZXJdKTtcclxuXHJcbi8vICAgLy8g4pyFIFRhYmxlIENvbHVtbnNcclxuLy8gICBjb25zdCBzYWxhcnlDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5IERhdGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYWdlbnRfbmFtZVwiLCBoZWFkZXI6IFwiQWdlbnRcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidG90YWxfcGFpZF9hbW91bnRcIiwgaGVhZGVyOiBcIlRvdGFsIFBhaWQgQW1vdW50ICjigrkpXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInRvdGFsX3NhbGFyeVwiLCBoZWFkZXI6IFwiVG90YWwgU2FsYXJ5IEFtb3VudCAo4oK5KVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwYXlfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBNb2RlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZnJvbV9kYXRlXCIsIGhlYWRlcjogXCJGcm9tIERhdGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidG9fZGF0ZVwiLCBoZWFkZXI6IFwiVG8gRGF0ZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJzYWxhcnlNb250aFwiLCBoZWFkZXI6IFwiTW9udGhcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJkaXNidXJzZWRfYnlcIiwgaGVhZGVyOiBcIkRpc2J1cnNlZCBieVwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDw+XHJcbi8vICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuLy8gICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbi8vICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi00XCI+XHJcbi8vICAgICAgICAgICAgIFBheW91dCBTYWxhcnkgUmVwb3J0XHJcbi8vICAgICAgICAgICA8L2gxPlxyXG5cclxuLy8gICAgICAgICAgIHsvKiBGaWx0ZXJzICovfVxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgIHsvKiBFbXBsb3llZSBGaWx0ZXIgKi99XHJcbi8vICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPkVtcGxveWVlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVyRW1wfVxyXG4vLyAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGaWx0ZXJFbXAoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHctNTZcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgRW1wbG95ZWVzPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoZW1wKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lIHx8IGVtcC5mdWxsX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIE1vbnRoIEZpbHRlciAqL31cclxuLy8gICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+TW9udGg8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJNb250aH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmlsdGVyTW9udGgoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHctNDBcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgTW9udGhzPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICB7W1xyXG4vLyAgICAgICAgICAgICAgICAgICBcIkphbnVhcnlcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJGZWJydWFyeVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIk1hcmNoXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiQXByaWxcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJNYXlcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJKdW5lXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiSnVseVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIkF1Z3VzdFwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIlNlcHRlbWJlclwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIk9jdG9iZXJcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJOb3ZlbWJlclwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIkRlY2VtYmVyXCIsXHJcbi8vICAgICAgICAgICAgICAgICBdLm1hcCgobSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bX0gdmFsdWU9e219PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHttfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBGaWx0ZXIgQnV0dG9uICovfVxyXG4vLyAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgb25DbGljaz17ZmV0Y2hTYWxhcnlQYXltZW50c31cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgaG92ZXI6YmctdmlvbGV0LTcwMCB0cmFuc2l0aW9uXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIEZpbHRlclxyXG4vLyAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIHsvKiBTYWxhcnkgUGF5bWVudHMgVGFibGUgKi99XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcblxyXG4vLyAgICAgICAgICAgICB7c2FsYXJ5UGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuLy8gICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICBkYXRhPXtzYWxhcnlQYXltZW50c31cclxuLy8gICAgICAgICAgICAgICAgIGNvbHVtbnM9e3NhbGFyeUNvbHVtbnN9XHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQYXlPdXQgU2FsYXJ5XCJcclxuLy8gICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJQYXlPdXQgU2FsYXJ5LmNzdlwiXHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4vLyAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuLy8gICAgICAgICAgICAgICAgICAgZGF0YT1cIlNhbGFyeSBQYXltZW50c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e3NhbGFyeVBheW1lbnRzLmxlbmd0aCA9PT0gMH1cclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7LyogRWRpdCBTYWxhcnkgTW9kYWwgKi99XHJcbi8vICAgICAgICAgICA8RWRpdFNhbGFyeU1vZGFsXHJcbi8vICAgICAgICAgICAgIGlzVmlzaWJsZT17aXNFZGl0aW5nfVxyXG4vLyAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcclxuLy8gICAgICAgICAgICAgICBzZXRFZGl0aW5nU2FsYXJ5KG51bGwpO1xyXG4vLyAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICBzYWxhcnk9e2VkaXRpbmdTYWxhcnl9XHJcbi8vICAgICAgICAgICAgIG9uRWRpdFN1Y2Nlc3M9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRJc0VkaXRpbmcoZmFsc2UpO1xyXG4vLyAgICAgICAgICAgICAgIHNldEVkaXRpbmdTYWxhcnkobnVsbCk7XHJcbi8vICAgICAgICAgICAgICAgc2V0UmVSZW5kZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuLy8gICAgICAgICAgICAgICBmZXRjaFNhbGFyeVBheW1lbnRzKCk7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvPlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG4vLyBjb25zdCBQYXlvdXRTYWxhcnlSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgcGF5bWVudEZvciA9IFwic2FsYXJ5XCI7XHJcbi8vICAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcblxyXG4vLyAgIGNvbnN0IFtzaG93U2FsYXJ5TW9kYWwsIHNldFNob3dTYWxhcnlNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW21vZGlmeVBheW1lbnQsIHNldE1vZGlmeVBheW1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFthZG1pbklkLCBzZXRBZG1pbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbZmlsdGVyRW1wLCBzZXRGaWx0ZXJFbXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2ZpbHRlck1vbnRoLCBzZXRGaWx0ZXJNb250aF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbY3VzdG9tRnJvbURhdGUsIHNldEN1c3RvbUZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtjdXN0b21Ub0RhdGUsIHNldEN1c3RvbVRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbi8vICAgY29uc3QgW3NhbGFyeVBheW1lbnRzLCBzZXRTYWxhcnlQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtyZVJlbmRlciwgc2V0UmVSZW5kZXJdID0gdXNlU3RhdGUoMCk7XHJcbi8vICAgY29uc3QgW2lzRWRpdGluZywgc2V0SXNFZGl0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbZWRpdGluZ1NhbGFyeSwgc2V0RWRpdGluZ1NhbGFyeV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbi8vICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuLy8gICAgIG1lc3NhZ2U6IFwiXCIsXHJcbi8vICAgICB0eXBlOiBcImluZm9cIixcclxuLy8gICAgIG5vUmVsb2FkOiBmYWxzZSxcclxuLy8gICB9KTtcclxuXHJcbi8vICAgLy8g4pyFIEZldGNoIGVtcGxveWVlIGxpc3RcclxuLy8gICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9lbXBsb3llZVwiKTtcclxuLy8gICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggQWdlbnRzXCIsIGVycm9yKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyDinIUgRmV0Y2ggc2FsYXJ5IHBheW1lbnRzIHdpdGggbW9udGggKyBjdXN0b20gZGF0ZSBmaWx0ZXJzXHJcbi8vICAgY29uc3QgZmV0Y2hTYWxhcnlQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xyXG4vLyAgICAgICBpZiAoZmlsdGVyRW1wKSBwYXJhbXMuZW1wSWQgPSBmaWx0ZXJFbXA7XHJcbi8vICAgICAgIGlmIChmaWx0ZXJNb250aCAmJiAhY3VzdG9tRnJvbURhdGUgJiYgIWN1c3RvbVRvRGF0ZSkgcGFyYW1zLm1vbnRoID0gZmlsdGVyTW9udGg7XHJcbi8vICAgICAgIGlmIChjdXN0b21Gcm9tRGF0ZSkgcGFyYW1zLmZyb21fZGF0ZSA9IGN1c3RvbUZyb21EYXRlO1xyXG4vLyAgICAgICBpZiAoY3VzdG9tVG9EYXRlKSBwYXJhbXMudG9fZGF0ZSA9IGN1c3RvbVRvRGF0ZTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9zYWxhcnkvZ2V0LXNhbGFyeS1yZXBvcnRcIiwgeyBwYXJhbXMgfSk7XHJcbi8vICAgICAgIGNvbnN0IHNhbGFyeUFycmF5ID0gQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhLmRhdGEpID8gcmVzcG9uc2UuZGF0YS5kYXRhIDogW107XHJcblxyXG4vLyAgICAgICBjb25zdCBmaWx0ZXJlZCA9IHNhbGFyeUFycmF5Lm1hcCgocGF5bWVudCwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICBjb25zdCBtZXRhID0gcGF5bWVudC5wYXlvdXRfbWV0YWRhdGEgfHwge307XHJcbi8vICAgICAgICAgY29uc3Qgc2FsYXJ5TW9udGggPSBtZXRhPy5tb250aHNfaW5jbHVkZWQ/LlswXSB8fCBudWxsO1xyXG4vLyAgICAgICAgIHJldHVybiB7XHJcbi8vICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuLy8gICAgICAgICAgIGVtcGxveWVlX2lkOiBwYXltZW50LmVtcGxveWVlX2lkPy5faWQsXHJcbi8vICAgICAgICAgICBwYXlfZGF0ZTogbWV0YT8uZGF0ZV9yYW5nZT8uZnJvbT8uc3BsaXQoXCJUXCIpWzBdIHx8IHBheW1lbnQucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIGFnZW50X25hbWU6IHBheW1lbnQuZW1wbG95ZWVfaWQ/Lm5hbWUgfHwgcGF5bWVudC5lbXBsb3llZV9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICBmcm9tX2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LmZyb20/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIHRvX2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LnRvPy5zcGxpdChcIlRcIilbMF0gfHwgXCItXCIsXHJcbi8vICAgICAgICAgICB0b3RhbF9zYWxhcnk6IG1ldGE/LnRvdGFsX3NhbGFyeSB8fCAwLFxyXG4vLyAgICAgICAgICAgdG90YWxfcGFpZF9hbW91bnQ6IG1ldGE/LnRvdGFsX3BhaWRfYW1vdW50IHx8IDAsXHJcbi8vICAgICAgICAgICBtb250aHNfaW5jbHVkZWQ6IG1ldGE/Lm1vbnRoc19pbmNsdWRlZD8uam9pbihcIiwgXCIpIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgcGF5X3R5cGU6IG1ldGE/LnBheV90eXBlIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICByZWNlaXB0X25vOiBtZXRhPy5yZWNlaXB0X25vIHx8IHBheW1lbnQucmVjZWlwdF9ubyB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIGRpc2J1cnNlZF9ieTogbWV0YT8uZGlzYnVyc2VkX2J5IHx8IHBheW1lbnQuZGlzYnVyc2VkX2J5IHx8IFwiQWRtaW5cIixcclxuLy8gICAgICAgICAgIHNhbGFyeU1vbnRoLFxyXG4vLyAgICAgICAgICAgbm90ZTogbWV0YT8ubm90ZSB8fCBcIi1cIixcclxuLy8gICAgICAgICB9O1xyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIHNldFNhbGFyeVBheW1lbnRzKGZpbHRlcmVkKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggc2FsYXJ5IHBheW1lbnRzXCIsIGVycm9yKTtcclxuLy8gICAgICAgc2V0U2FsYXJ5UGF5bWVudHMoW10pO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyDinIUgSW5pdGlhbCBzZXR1cFxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4vLyAgICAgY29uc3QgdXNlck9iaiA9IHVzZXIgPyBKU09OLnBhcnNlKHVzZXIpIDoge307XHJcbi8vICAgICBzZXRBZG1pbklkKHVzZXJPYmouX2lkKTtcclxuLy8gICAgIHNldEFkbWluTmFtZSh1c2VyT2JqLm5hbWUgfHwgXCJcIik7XHJcbi8vICAgICBpZiAodXNlck9iaj8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCkge1xyXG4vLyAgICAgICBzZXRNb2RpZnlQYXltZW50KFxyXG4vLyAgICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X3BheW1lbnQgPT09IFwidHJ1ZVwiXHJcbi8vICAgICAgICk7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvLyDinIUgQXV0by1oaWRlIGFsZXJ0XHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmIChhbGVydENvbmZpZy52aXNpYmlsaXR5ICYmIGFsZXJ0Q29uZmlnLm5vUmVsb2FkKSB7XHJcbi8vICAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbi8vICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKTtcclxuLy8gICAgICAgfSwgNDAwMCk7XHJcbi8vICAgICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFthbGVydENvbmZpZy52aXNpYmlsaXR5XSk7XHJcblxyXG4vLyAgIC8vIOKchSBGZXRjaCBvbiBtb3VudCBvciBmaWx0ZXJzXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoQWdlbnRzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgZmV0Y2hTYWxhcnlQYXltZW50cygpO1xyXG4vLyAgIH0sIFtmaWx0ZXJFbXAsIGZpbHRlck1vbnRoLCBjdXN0b21Gcm9tRGF0ZSwgY3VzdG9tVG9EYXRlLCByZVJlbmRlcl0pO1xyXG5cclxuLy8gICAvLyDinIUgVGFibGUgQ29sdW1uc1xyXG4vLyAgIGNvbnN0IHNhbGFyeUNvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBheV9kYXRlXCIsIGhlYWRlcjogXCJQYXkgRGF0ZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhZ2VudF9uYW1lXCIsIGhlYWRlcjogXCJBZ2VudFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0b3RhbF9wYWlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZCBBbW91bnQgKOKCuSlcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidG90YWxfc2FsYXJ5XCIsIGhlYWRlcjogXCJUb3RhbCBTYWxhcnkgQW1vdW50ICjigrkpXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IE1vZGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVjZWlwdF9ub1wiLCBoZWFkZXI6IFwiUmVjZWlwdCBOb1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJmcm9tX2RhdGVcIiwgaGVhZGVyOiBcIkZyb20gRGF0ZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0b19kYXRlXCIsIGhlYWRlcjogXCJUbyBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInNhbGFyeU1vbnRoXCIsIGhlYWRlcjogXCJNb250aFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJub3RlXCIsIGhlYWRlcjogXCJOb3RlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRpc2J1cnNlZF9ieVwiLCBoZWFkZXI6IFwiRGlzYnVyc2VkIGJ5XCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPD5cclxuLy8gICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNFwiPlBheW91dCBTYWxhcnkgUmVwb3J0PC9oMT5cclxuXHJcbi8vICAgICAgICAgICB7LyogRmlsdGVycyAqL31cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGdhcC00IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgey8qIEVtcGxveWVlIEZpbHRlciAqL31cclxuLy8gICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+RW1wbG95ZWU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJFbXB9XHJcbi8vICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZpbHRlckVtcChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBweC0zIHB5LTIgdy01NlwiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBFbXBsb3llZXM8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChlbXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWUgfHwgZW1wLmZ1bGxfbmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogTW9udGggRmlsdGVyICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5Nb250aDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlck1vbnRofVxyXG4vLyAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGaWx0ZXJNb250aChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBweC0zIHB5LTIgdy00MFwiXHJcbi8vICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3VzdG9tRnJvbURhdGUgfHwgY3VzdG9tVG9EYXRlfSAvLyBEaXNhYmxlIG1vbnRoIGZpbHRlciBpZiBjdXN0b20gZGF0ZSBzZWxlY3RlZFxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGwgTW9udGhzPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICB7W1xyXG4vLyAgICAgICAgICAgICAgICAgICBcIkphbnVhcnlcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJGZWJydWFyeVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIk1hcmNoXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiQXByaWxcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJNYXlcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJKdW5lXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiSnVseVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIkF1Z3VzdFwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIlNlcHRlbWJlclwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIk9jdG9iZXJcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJOb3ZlbWJlclwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIkRlY2VtYmVyXCIsXHJcbi8vICAgICAgICAgICAgICAgICBdLm1hcCgobSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17bX0gdmFsdWU9e219PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHttfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjdXN0b21cIj5DdXN0b208L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogQ3VzdG9tIEZyb20gRGF0ZSAqL31cclxuLy8gICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+RnJvbSBEYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21Gcm9tRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHctNDBcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIEN1c3RvbSBUbyBEYXRlICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5UbyBEYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21Ub0RhdGV9XHJcbi8vICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbVRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBweC0zIHB5LTIgdy00MFwiXHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogRmlsdGVyIEJ1dHRvbiAqL31cclxuLy8gICAgICAgICAgICAgey8qIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaFNhbGFyeVBheW1lbnRzfVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBob3ZlcjpiZy12aW9sZXQtNzAwIHRyYW5zaXRpb25cIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgRmlsdGVyXHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPiAqL31cclxuXHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJFbXAoXCJcIik7XHJcbi8vICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJNb250aChcIlwiKTtcclxuLy8gICAgICAgICAgICAgICAgIHNldEN1c3RvbUZyb21EYXRlKFwiXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tVG9EYXRlKFwiXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgZmV0Y2hTYWxhcnlQYXltZW50cygpO1xyXG4vLyAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS00MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBob3ZlcjpiZy1ncmF5LTUwMCB0cmFuc2l0aW9uXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIENsZWFyXHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIFNhbGFyeSBQYXltZW50cyBUYWJsZSAqL31cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBiZy13aGl0ZSBwLTYgcm91bmRlZC1sZyBzaGFkb3ctbWRcIj5cclxuLy8gICAgICAgICAgICAge3NhbGFyeVBheW1lbnRzLmxlbmd0aCA+IDAgPyAoXHJcbi8vICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICAgICAgZGF0YT17c2FsYXJ5UGF5bWVudHN9XHJcbi8vICAgICAgICAgICAgICAgICBjb2x1bW5zPXtzYWxhcnlDb2x1bW5zfVxyXG4vLyAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiUGF5T3V0IFNhbGFyeVwiXHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiUGF5T3V0IFNhbGFyeS5jc3ZcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuLy8gICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbi8vICAgICAgICAgICAgICAgICAgIGRhdGE9XCJTYWxhcnkgUGF5bWVudHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXtzYWxhcnlQYXltZW50cy5sZW5ndGggPT09IDB9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIEVkaXQgU2FsYXJ5IE1vZGFsICovfVxyXG4vLyAgICAgICAgICAgPEVkaXRTYWxhcnlNb2RhbFxyXG4vLyAgICAgICAgICAgICBpc1Zpc2libGU9e2lzRWRpdGluZ31cclxuLy8gICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgIHNldElzRWRpdGluZyhmYWxzZSk7XHJcbi8vICAgICAgICAgICAgICAgc2V0RWRpdGluZ1NhbGFyeShudWxsKTtcclxuLy8gICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgc2FsYXJ5PXtlZGl0aW5nU2FsYXJ5fVxyXG4vLyAgICAgICAgICAgICBvbkVkaXRTdWNjZXNzPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcclxuLy8gICAgICAgICAgICAgICBzZXRFZGl0aW5nU2FsYXJ5KG51bGwpO1xyXG4vLyAgICAgICAgICAgICAgIHNldFJlUmVuZGVyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbi8vICAgICAgICAgICAgICAgZmV0Y2hTYWxhcnlQYXltZW50cygpO1xyXG4vLyAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8Lz5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gY29uc3QgUGF5b3V0U2FsYXJ5UmVwb3J0ID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IHBheW1lbnRGb3IgPSBcInNhbGFyeVwiO1xyXG4vLyAgIGNvbnN0IFthcGksIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG5cclxuLy8gICBjb25zdCBbc2hvd1NhbGFyeU1vZGFsLCBzZXRTaG93U2FsYXJ5TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbYWRtaW5OYW1lLCBzZXRBZG1pbk5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2ZpbHRlckVtcCwgc2V0RmlsdGVyRW1wXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtmaWx0ZXJNb250aCwgc2V0RmlsdGVyTW9udGhdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2N1c3RvbUZyb21EYXRlLCBzZXRDdXN0b21Gcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbY3VzdG9tVG9EYXRlLCBzZXRDdXN0b21Ub0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIGNvbnN0IFtzYWxhcnlQYXltZW50cywgc2V0U2FsYXJ5UGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbcmVSZW5kZXIsIHNldFJlUmVuZGVyXSA9IHVzZVN0YXRlKDApO1xyXG4vLyAgIGNvbnN0IFtpc0VkaXRpbmcsIHNldElzRWRpdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2VkaXRpbmdTYWxhcnksIHNldEVkaXRpbmdTYWxhcnldID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4vLyAgIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbi8vICAgICBtZXNzYWdlOiBcIlwiLFxyXG4vLyAgICAgdHlwZTogXCJpbmZvXCIsXHJcbi8vICAgICBub1JlbG9hZDogZmFsc2UsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4vLyAgICAgICBzZXRBZ2VudHMocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBBZ2VudHNcIiwgZXJyb3IpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoU2FsYXJ5UGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBjb25zdCBwYXJhbXMgPSB7fTtcclxuLy8gICAgICAgaWYgKGZpbHRlckVtcCkgcGFyYW1zLmVtcElkID0gZmlsdGVyRW1wO1xyXG4vLyAgICAgICBpZiAoZmlsdGVyTW9udGggJiYgZmlsdGVyTW9udGggIT09IFwiY3VzdG9tXCIgJiYgIWN1c3RvbUZyb21EYXRlICYmICFjdXN0b21Ub0RhdGUpXHJcbi8vICAgICAgICAgcGFyYW1zLm1vbnRoID0gZmlsdGVyTW9udGg7XHJcbi8vICAgICAgIGlmIChjdXN0b21Gcm9tRGF0ZSkgcGFyYW1zLmZyb21fZGF0ZSA9IGN1c3RvbUZyb21EYXRlO1xyXG4vLyAgICAgICBpZiAoY3VzdG9tVG9EYXRlKSBwYXJhbXMudG9fZGF0ZSA9IGN1c3RvbVRvRGF0ZTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9zYWxhcnkvZ2V0LXNhbGFyeS1yZXBvcnRcIiwgeyBwYXJhbXMgfSk7XHJcbi8vICAgICAgIGNvbnN0IHNhbGFyeUFycmF5ID0gQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhLmRhdGEpXHJcbi8vICAgICAgICAgPyByZXNwb25zZS5kYXRhLmRhdGFcclxuLy8gICAgICAgICA6IFtdO1xyXG5cclxuLy8gICAgICAgY29uc3QgZmlsdGVyZWQgPSBzYWxhcnlBcnJheS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiB7XHJcbi8vICAgICAgICAgY29uc3QgbWV0YSA9IHBheW1lbnQucGF5b3V0X21ldGFkYXRhIHx8IHt9O1xyXG4vLyAgICAgICAgIGNvbnN0IHNhbGFyeU1vbnRoID0gbWV0YT8ubW9udGhzX2luY2x1ZGVkPy5bMF0gfHwgbnVsbDtcclxuLy8gICAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIF9pZDogcGF5bWVudC5faWQsXHJcbi8vICAgICAgICAgICBlbXBsb3llZV9pZDogcGF5bWVudC5lbXBsb3llZV9pZD8uX2lkLFxyXG4vLyAgICAgICAgICAgcGF5X2RhdGU6XHJcbi8vICAgICAgICAgICAgIG1ldGE/LmRhdGVfcmFuZ2U/LmZyb20/LnNwbGl0KFwiVFwiKVswXSB8fFxyXG4vLyAgICAgICAgICAgICBwYXltZW50LnBheV9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHxcclxuLy8gICAgICAgICAgICAgXCItXCIsXHJcbi8vICAgICAgICAgICBhZ2VudF9uYW1lOlxyXG4vLyAgICAgICAgICAgICBwYXltZW50LmVtcGxveWVlX2lkPy5uYW1lIHx8XHJcbi8vICAgICAgICAgICAgIHBheW1lbnQuZW1wbG95ZWVfaWQ/LmZ1bGxfbmFtZSB8fFxyXG4vLyAgICAgICAgICAgICBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgZnJvbV9kYXRlOiBtZXRhPy5kYXRlX3JhbmdlPy5mcm9tPy5zcGxpdChcIlRcIilbMF0gfHwgXCItXCIsXHJcbi8vICAgICAgICAgICB0b19kYXRlOiBtZXRhPy5kYXRlX3JhbmdlPy50bz8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgdG90YWxfc2FsYXJ5OiBtZXRhPy50b3RhbF9zYWxhcnkgfHwgMCxcclxuLy8gICAgICAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiBtZXRhPy50b3RhbF9wYWlkX2Ftb3VudCB8fCAwLFxyXG4vLyAgICAgICAgICAgbW9udGhzX2luY2x1ZGVkOiBtZXRhPy5tb250aHNfaW5jbHVkZWQ/LmpvaW4oXCIsIFwiKSB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIHBheV90eXBlOiBtZXRhPy5wYXlfdHlwZSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgcmVjZWlwdF9ubzogbWV0YT8ucmVjZWlwdF9ubyB8fCBwYXltZW50LnJlY2VpcHRfbm8gfHwgXCItXCIsXHJcbi8vICAgICAgICAgICBkaXNidXJzZWRfYnk6IG1ldGE/LmRpc2J1cnNlZF9ieSB8fCBwYXltZW50LmRpc2J1cnNlZF9ieSB8fCBcIkFkbWluXCIsXHJcbi8vICAgICAgICAgICBzYWxhcnlNb250aCxcclxuLy8gICAgICAgICAgIG5vdGU6IG1ldGE/Lm5vdGUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgfTtcclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBzZXRTYWxhcnlQYXltZW50cyhmaWx0ZXJlZCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHNhbGFyeSBwYXltZW50c1wiLCBlcnJvcik7XHJcbi8vICAgICAgIHNldFNhbGFyeVBheW1lbnRzKFtdKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbi8vICAgICBjb25zdCB1c2VyT2JqID0gdXNlciA/IEpTT04ucGFyc2UodXNlcikgOiB7fTtcclxuLy8gICAgIHNldEFkbWluSWQodXNlck9iai5faWQpO1xyXG4vLyAgICAgc2V0QWRtaW5OYW1lKHVzZXJPYmoubmFtZSB8fCBcIlwiKTtcclxuLy8gICAgIGlmICh1c2VyT2JqPy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50KSB7XHJcbi8vICAgICAgIHNldE1vZGlmeVBheW1lbnQoXHJcbi8vICAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfcGF5bWVudCA9PT0gXCJ0cnVlXCJcclxuLy8gICAgICAgKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBmZXRjaEFnZW50cygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoU2FsYXJ5UGF5bWVudHMoKTtcclxuLy8gICB9LCBbZmlsdGVyRW1wLCBmaWx0ZXJNb250aCwgY3VzdG9tRnJvbURhdGUsIGN1c3RvbVRvRGF0ZSwgcmVSZW5kZXJdKTtcclxuXHJcbi8vICAgY29uc3Qgc2FsYXJ5Q29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGF5X2RhdGVcIiwgaGVhZGVyOiBcIlBheSBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFnZW50X25hbWVcIiwgaGVhZGVyOiBcIkFnZW50XCIgfSxcclxuLy8gICAgIHsga2V5OiBcInRvdGFsX3BhaWRfYW1vdW50XCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkIEFtb3VudCAo4oK5KVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0b3RhbF9zYWxhcnlcIiwgaGVhZGVyOiBcIlRvdGFsIFNhbGFyeSBBbW91bnQgKOKCuSlcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImZyb21fZGF0ZVwiLCBoZWFkZXI6IFwiRnJvbSBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInRvX2RhdGVcIiwgaGVhZGVyOiBcIlRvIERhdGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwic2FsYXJ5TW9udGhcIiwgaGVhZGVyOiBcIk1vbnRoXCIgfSxcclxuLy8gICAgIHsga2V5OiBcIm5vdGVcIiwgaGVhZGVyOiBcIk5vdGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZGlzYnVyc2VkX2J5XCIsIGhlYWRlcjogXCJEaXNidXJzZWQgYnlcIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8PlxyXG4vLyAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi00XCI+UGF5b3V0IFNhbGFyeSBSZXBvcnQ8L2gxPlxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGdhcC00IG1iLTZcIj5cclxuXHJcbi8vICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPkVtcGxveWVlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVyRW1wIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRGaWx0ZXJFbXB9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2XCJcclxuLy8gICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbi8vICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBFbXBsb3llZXM8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChlbXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWUgfHwgZW1wLmZ1bGxfbmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5Nb250aDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTW9udGhcIlxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlck1vbnRoIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyTW9udGgodmFsdWUpO1xyXG4vLyAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUgIT09IFwiY3VzdG9tXCIpIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21Gcm9tRGF0ZShcIlwiKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21Ub0RhdGUoXCJcIik7XHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQwXCJcclxuLy8gICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbi8vICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBNb250aHM8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgIHtbXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiSmFudWFyeVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIkZlYnJ1YXJ5XCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiTWFyY2hcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJBcHJpbFwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIk1heVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIkp1bmVcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXCJKdWx5XCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiQXVndXN0XCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiU2VwdGVtYmVyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiT2N0b2JlclwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIk5vdmVtYmVyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIFwiRGVjZW1iZXJcIixcclxuLy8gICAgICAgICAgICAgICAgIF0ubWFwKChtKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXttfSB2YWx1ZT17bX0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge219XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiY3VzdG9tXCI+Q3VzdG9tPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAge2ZpbHRlck1vbnRoID09PSBcImN1c3RvbVwiICYmIChcclxuLy8gICAgICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIEZyb20gRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbUZyb21EYXRlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHB4LTMgcHktMiB3LTQwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlRvIERhdGU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbVRvRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbVRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHctNDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICA8QnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgc2V0RmlsdGVyRW1wKFwiXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgc2V0RmlsdGVyTW9udGgoXCJcIik7XHJcbi8vICAgICAgICAgICAgICAgICBzZXRDdXN0b21Gcm9tRGF0ZShcIlwiKTtcclxuLy8gICAgICAgICAgICAgICAgIHNldEN1c3RvbVRvRGF0ZShcIlwiKTtcclxuLy8gICAgICAgICAgICAgICAgIGZldGNoU2FsYXJ5UGF5bWVudHMoKTtcclxuLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgQ2xlYXJcclxuLy8gICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbi8vICAgICAgICAgICAgIHtzYWxhcnlQYXltZW50cy5sZW5ndGggPiAwID8gKFxyXG4vLyAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgICAgIGRhdGE9e3NhbGFyeVBheW1lbnRzfVxyXG4vLyAgICAgICAgICAgICAgICAgY29sdW1ucz17c2FsYXJ5Q29sdW1uc31cclxuLy8gICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlBheU91dCBTYWxhcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlBheU91dCBTYWxhcnkuY3N2XCJcclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbi8vICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4vLyAgICAgICAgICAgICAgICAgICBkYXRhPVwiU2FsYXJ5IFBheW1lbnRzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZmFpbHVyZT17c2FsYXJ5UGF5bWVudHMubGVuZ3RoID09PSAwfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIDxFZGl0U2FsYXJ5TW9kYWxcclxuLy8gICAgICAgICAgICAgaXNWaXNpYmxlPXtpc0VkaXRpbmd9XHJcbi8vICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRJc0VkaXRpbmcoZmFsc2UpO1xyXG4vLyAgICAgICAgICAgICAgIHNldEVkaXRpbmdTYWxhcnkobnVsbCk7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgIHNhbGFyeT17ZWRpdGluZ1NhbGFyeX1cclxuLy8gICAgICAgICAgICAgb25FZGl0U3VjY2Vzcz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgIHNldElzRWRpdGluZyhmYWxzZSk7XHJcbi8vICAgICAgICAgICAgICAgc2V0RWRpdGluZ1NhbGFyeShudWxsKTtcclxuLy8gICAgICAgICAgICAgICBzZXRSZVJlbmRlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4vLyAgICAgICAgICAgICAgIGZldGNoU2FsYXJ5UGF5bWVudHMoKTtcclxuLy8gICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC8+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IFBheW91dFNhbGFyeVJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBwYXltZW50Rm9yID0gXCJzYWxhcnlcIjtcclxuICBjb25zdCBbYXBpLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuXHJcbiAgY29uc3QgW2ZpbHRlckVtcCwgc2V0RmlsdGVyRW1wXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJNb250aCwgc2V0RmlsdGVyTW9udGhdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2N1c3RvbUZyb21EYXRlLCBzZXRDdXN0b21Gcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY3VzdG9tVG9EYXRlLCBzZXRDdXN0b21Ub0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFtzYWxhcnlQYXltZW50cywgc2V0U2FsYXJ5UGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW3N1bW1hcnlEYXRhLCBzZXRTdW1tYXJ5RGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0b3RhbFBhaWQ6IDAsXHJcbiAgICB0b3RhbFNhbGFyeTogMCxcclxuICAgIGxhdGVzdFBheW1lbnQ6IFwiLVwiLFxyXG4gICAgbGF0ZXN0TW9udGg6IFwiLVwiLFxyXG4gICAgbnVtYmVyT2ZQYXltZW50czogMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBZ2VudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICAgIHNldEFnZW50cyhyZXNwb25zZS5kYXRhPy5lbXBsb3llZSB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIEFnZW50c1wiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FsY3VsYXRlU3VtbWFyeSA9IChwYXltZW50cykgPT4ge1xyXG4gICAgaWYgKCFwYXltZW50cy5sZW5ndGgpIHtcclxuICAgICAgc2V0U3VtbWFyeURhdGEoe1xyXG4gICAgICAgIHRvdGFsUGFpZDogMCxcclxuICAgICAgICB0b3RhbFNhbGFyeTogMCxcclxuICAgICAgICBsYXRlc3RQYXltZW50OiBcIi1cIixcclxuICAgICAgICBsYXRlc3RNb250aDogXCItXCIsXHJcbiAgICAgICAgbnVtYmVyT2ZQYXltZW50czogMCxcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0b3RhbFBhaWQgPSBwYXltZW50cy5yZWR1Y2UoXHJcbiAgICAgICh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBOdW1iZXIoaXRlbS50b3RhbF9wYWlkX2Ftb3VudCB8fCAwKSxcclxuICAgICAgMFxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbFNhbGFyeSA9IHBheW1lbnRzLnJlZHVjZShcclxuICAgICAgKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIE51bWJlcihpdGVtLnRvdGFsX3NhbGFyeSB8fCAwKSxcclxuICAgICAgMFxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCBsYXRlc3RSZWMgPSBbLi4ucGF5bWVudHNdLnNvcnQoXHJcbiAgICAgIChhLCBiKSA9PiBuZXcgRGF0ZShiLnBheV9kYXRlKSAtIG5ldyBEYXRlKGEucGF5X2RhdGUpXHJcbiAgICApWzBdO1xyXG5cclxuICAgIHNldFN1bW1hcnlEYXRhKHtcclxuICAgICAgdG90YWxQYWlkLFxyXG4gICAgICB0b3RhbFNhbGFyeSxcclxuICAgICAgbGF0ZXN0UGF5bWVudDogbGF0ZXN0UmVjPy50b3RhbF9wYWlkX2Ftb3VudCB8fCAwLFxyXG4gICAgICBsYXRlc3RNb250aDogbGF0ZXN0UmVjPy5zYWxhcnlNb250aCB8fCBcIi1cIixcclxuICAgICAgbnVtYmVyT2ZQYXltZW50czogcGF5bWVudHMubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hTYWxhcnlQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xyXG4gICAgICBpZiAoZmlsdGVyRW1wKSBwYXJhbXMuZW1wSWQgPSBmaWx0ZXJFbXA7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBmaWx0ZXJNb250aCAmJlxyXG4gICAgICAgIGZpbHRlck1vbnRoICE9PSBcImN1c3RvbVwiICYmXHJcbiAgICAgICAgIWN1c3RvbUZyb21EYXRlICYmXHJcbiAgICAgICAgIWN1c3RvbVRvRGF0ZVxyXG4gICAgICApXHJcbiAgICAgICAgcGFyYW1zLm1vbnRoID0gZmlsdGVyTW9udGg7XHJcbiAgICAgIGlmIChjdXN0b21Gcm9tRGF0ZSkgcGFyYW1zLmZyb21fZGF0ZSA9IGN1c3RvbUZyb21EYXRlO1xyXG4gICAgICBpZiAoY3VzdG9tVG9EYXRlKSBwYXJhbXMudG9fZGF0ZSA9IGN1c3RvbVRvRGF0ZTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9zYWxhcnkvZ2V0LXNhbGFyeS1yZXBvcnRcIiwgeyBwYXJhbXMgfSk7XHJcbiAgICAgIGNvbnN0IHNhbGFyeUFycmF5ID0gQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhLmRhdGEpXHJcbiAgICAgICAgPyByZXNwb25zZS5kYXRhLmRhdGFcclxuICAgICAgICA6IFtdO1xyXG5cclxuICAgICAgY29uc3QgZmlsdGVyZWQgPSBzYWxhcnlBcnJheS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgY29uc3QgbWV0YSA9IHBheW1lbnQucGF5b3V0X21ldGFkYXRhIHx8IHt9O1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICAgIGVtcGxveWVlX2lkOiBwYXltZW50LmVtcGxveWVlX2lkPy5faWQsXHJcbiAgICAgICAgICBwYXlfZGF0ZTpcclxuICAgICAgICAgICAgbWV0YT8uZGF0ZV9yYW5nZT8uZnJvbT8uc3BsaXQoXCJUXCIpWzBdIHx8XHJcbiAgICAgICAgICAgIHBheW1lbnQucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fFxyXG4gICAgICAgICAgICBcIi1cIixcclxuICAgICAgICAgIGFnZW50X25hbWU6XHJcbiAgICAgICAgICAgIHBheW1lbnQuZW1wbG95ZWVfaWQ/Lm5hbWUgfHxcclxuICAgICAgICAgICAgcGF5bWVudC5lbXBsb3llZV9pZD8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICAgIFwiTi9BXCIsXHJcbiAgICAgICAgICBmcm9tX2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LmZyb20/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuICAgICAgICAgIHRvX2RhdGU6IG1ldGE/LmRhdGVfcmFuZ2U/LnRvPy5zcGxpdChcIlRcIilbMF0gfHwgXCItXCIsXHJcbiAgICAgICAgICB0b3RhbF9zYWxhcnk6IG1ldGE/LnRvdGFsX3NhbGFyeSB8fCAwLFxyXG4gICAgICAgICAgdG90YWxfcGFpZF9hbW91bnQ6IChtZXRhPy50b3RhbF9wYWlkX2Ftb3VudCkudG9GaXhlZCgyKSB8fCAwLFxyXG4gICAgICAgICAgbW9udGhzX2luY2x1ZGVkOiBtZXRhPy5tb250aHNfaW5jbHVkZWQ/LmpvaW4oXCIsIFwiKSB8fCBcIi1cIixcclxuICAgICAgICAgIHBheV90eXBlOiBtZXRhPy5wYXlfdHlwZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcmVjZWlwdF9ubzogbWV0YT8ucmVjZWlwdF9ubyB8fCBwYXltZW50LnJlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAgICAgICBkaXNidXJzZWRfYnk6IG1ldGE/LmRpc2J1cnNlZF9ieSB8fCBwYXltZW50LmRpc2J1cnNlZF9ieSB8fCBcIkFkbWluXCIsXHJcbiAgICAgICAgICBzYWxhcnlNb250aDogbWV0YT8ubW9udGhzX2luY2x1ZGVkPy5bMF0gfHwgXCItXCIsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRTYWxhcnlQYXltZW50cyhmaWx0ZXJlZCk7XHJcbiAgICAgIGNhbGN1bGF0ZVN1bW1hcnkoZmlsdGVyZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBzYWxhcnkgcGF5bWVudHNcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRTYWxhcnlQYXltZW50cyhbXSk7XHJcbiAgICAgIHNldFN1bW1hcnlEYXRhKHtcclxuICAgICAgICB0b3RhbFBhaWQ6IDAsXHJcbiAgICAgICAgdG90YWxTYWxhcnk6IDAsXHJcbiAgICAgICAgbGF0ZXN0UGF5bWVudDogXCItXCIsXHJcbiAgICAgICAgbGF0ZXN0TW9udGg6IFwiLVwiLFxyXG4gICAgICAgIG51bWJlck9mUGF5bWVudHM6IDAsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFNhbGFyeVBheW1lbnRzKCk7XHJcbiAgfSwgW2ZpbHRlckVtcCwgZmlsdGVyTW9udGgsIGN1c3RvbUZyb21EYXRlLCBjdXN0b21Ub0RhdGVdKTtcclxuXHJcbiAgY29uc3Qgc2FsYXJ5Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X2RhdGVcIiwgaGVhZGVyOiBcIlBheSBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImFnZW50X25hbWVcIiwgaGVhZGVyOiBcIkFnZW50XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX3BhaWRfYW1vdW50XCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkIEFtb3VudCAo4oK5KVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9zYWxhcnlcIiwgaGVhZGVyOiBcIlRvdGFsIFNhbGFyeSBBbW91bnQgKOKCuSlcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcImZyb21fZGF0ZVwiLCBoZWFkZXI6IFwiRnJvbSBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInRvX2RhdGVcIiwgaGVhZGVyOiBcIlRvIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwic2FsYXJ5TW9udGhcIiwgaGVhZGVyOiBcIk1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcIm5vdGVcIiwgaGVhZGVyOiBcIk5vdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGlzYnVyc2VkX2J5XCIsIGhlYWRlcjogXCJEaXNidXJzZWQgYnlcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7Y29udGV4dEhvbGRlcn1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi00XCI+UGF5b3V0IFNhbGFyeSBSZXBvcnQ8L2gxPlxyXG5cclxuICAgICAgICAgIHsvKiBGaWx0ZXJzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5FbXBsb3llZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlckVtcCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0RmlsdGVyRW1wfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01NlwiXHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBFbXBsb3llZXM8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWUgfHwgZW1wLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5Nb250aDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTW9udGhcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlck1vbnRoIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyTW9udGgodmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICBpZiAodmFsdWUgIT09IFwiY3VzdG9tXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21Gcm9tRGF0ZShcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21Ub0RhdGUoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQwXCJcclxuICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiXCI+QWxsIE1vbnRoczwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgXCJKYW51YXJ5XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiRmVicnVhcnlcIixcclxuICAgICAgICAgICAgICAgICAgXCJNYXJjaFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkFwcmlsXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiTWF5XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiSnVuZVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkp1bHlcIixcclxuICAgICAgICAgICAgICAgICAgXCJBdWd1c3RcIixcclxuICAgICAgICAgICAgICAgICAgXCJTZXB0ZW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgXCJPY3RvYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiTm92ZW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgXCJEZWNlbWJlclwiLFxyXG4gICAgICAgICAgICAgICAgXS5tYXAoKG0pID0+IChcclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e219IHZhbHVlPXttfT5cclxuICAgICAgICAgICAgICAgICAgICB7bX1cclxuICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJjdXN0b21cIj5DdXN0b208L09wdGlvbj5cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7ZmlsdGVyTW9udGggPT09IFwiY3VzdG9tXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21Gcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIHctNDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+VG8gRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBweC0zIHB5LTIgdy00MFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRGaWx0ZXJFbXAoXCJcIik7XHJcbiAgICAgICAgICAgICAgICBzZXRGaWx0ZXJNb250aChcIlwiKTtcclxuICAgICAgICAgICAgICAgIHNldEN1c3RvbUZyb21EYXRlKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVG9EYXRlKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgZmV0Y2hTYWxhcnlQYXltZW50cygpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDbGVhclxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTUgcC00IHJvdW5kZWQtbGcgIG1iLTVcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHNoYWRvdy1zbSByb3VuZGVkLWxnIHAtNCB3LWZ1bGwgc206dy1bMTgwcHhdIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgYmxvY2sgdGV4dC12aW9sZXQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvdGFsIFNhbGFyeSBBbW91bnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIOKCuXtzdW1tYXJ5RGF0YS50b3RhbFNhbGFyeS50b0ZpeGVkKDIpIHx8IDB9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgc2hhZG93LXNtIHJvdW5kZWQtbGcgcC00IHctZnVsbCBzbTp3LVsxODBweF0gdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBibG9jayB0ZXh0LXZpb2xldC03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgUGFpZCBBbW91bnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIOKCuXtzdW1tYXJ5RGF0YS50b3RhbFBhaWQudG9GaXhlZCgyKSB8fCAwfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHNoYWRvdy1zbSByb3VuZGVkLWxnIHAtNCB3LWZ1bGwgc206dy1bMTgwcHhdIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgYmxvY2sgdGV4dC12aW9sZXQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIExhdGVzdCBQYXltZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICDigrl7c3VtbWFyeURhdGEubGF0ZXN0UGF5bWVudCB8fCAwfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHNoYWRvdy1zbSByb3VuZGVkLWxnIHAtNCB3LWZ1bGwgc206dy1bMTgwcHhdIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgYmxvY2sgdGV4dC12aW9sZXQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIExhdGVzdCBNb250aFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge3N1bW1hcnlEYXRhLmxhdGVzdE1vbnRoIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgc2hhZG93LXNtIHJvdW5kZWQtbGcgcC00IHctZnVsbCBzbTp3LVsxODBweF0gdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBibG9jayB0ZXh0LXZpb2xldC03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgTnVtYmVyIG9mIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7c3VtbWFyeURhdGEubnVtYmVyT2ZQYXltZW50cyB8fCAwfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGJnLXdoaXRlIHAtNiByb3VuZGVkLWxnIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICB7c2FsYXJ5UGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtzYWxhcnlQYXltZW50c31cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e3NhbGFyeUNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQYXlPdXQgU2FsYXJ5XCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJQYXlPdXQgU2FsYXJ5LmNzdlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgZGF0YT1cIlNhbGFyeSBQYXltZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e3NhbGFyeVBheW1lbnRzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGF5b3V0U2FsYXJ5UmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGF5b3V0U2FsYXJ5UmVwb3J0LmpzeCJ9