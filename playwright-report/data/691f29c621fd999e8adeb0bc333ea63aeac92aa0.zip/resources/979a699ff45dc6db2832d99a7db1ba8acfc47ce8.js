import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/Navbar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { NavLink, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import GlobalSearchBar from "/src/components/search/GlobalSearchBar.jsx";
import { ArrowLeft } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { CgProfile } from "/node_modules/.vite/deps/react-icons_cg.js?v=819e0a34";
import { IoIosNotifications, IoIosLogOut } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { HiX } from "/node_modules/.vite/deps/react-icons_hi.js?v=819e0a34";
import { BiMenu } from "/node_modules/.vite/deps/react-icons_bi.js?v=819e0a34";
import {
  FiUsers,
  FiSmartphone,
  FiCreditCard,
  FiClock
} from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { GiReceiveMoney } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import quickActions from "/src/data/quickActions.jsx";
import CityChits from "/src/assets/images/mychits.png?import";
import API from "/src/instance/TokenInstance.js";
import { FaEye, FaEyeSlash, FaLock, FaStore, FaUserCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
const quickActionAccentClasses = {
  amber: "bg-amber-50 text-amber-700",
  blue: "bg-blue-50 text-blue-700",
  cyan: "bg-cyan-50 text-cyan-700",
  emerald: "bg-emerald-50 text-emerald-700",
  green: "bg-green-50 text-green-700",
  indigo: "bg-indigo-50 text-indigo-700",
  lime: "bg-lime-50 text-lime-700",
  orange: "bg-orange-50 text-orange-700",
  pink: "bg-pink-50 text-pink-700",
  purple: "bg-purple-50 text-purple-700",
  red: "bg-red-50 text-red-700",
  rose: "bg-rose-50 text-rose-700",
  sky: "bg-sky-50 text-sky-700",
  slate: "bg-slate-100 text-slate-700",
  stone: "bg-stone-100 text-stone-700",
  teal: "bg-teal-50 text-teal-700",
  violet: "bg-violet-50 text-violet-700",
  yellow: "bg-yellow-50 text-yellow-700",
  zinc: "bg-zinc-100 text-zinc-700"
};
const quickActionMegaGroups = [
  {
    title: "Main Actions",
    ids: ["unverified", "mobile", "loans", "payment-in", "payment-out", "receipt"]
  },
  {
    title: "Operations",
    ids: ["pigmy", "agent", "visitor", "penalty-whatsapp", "link-unlink"]
  },
  {
    title: "Business",
    ids: ["marketing", "help-support", "accounts", "approvals", "reports"]
  },
  {
    title: "Tools",
    ids: ["quick-search", "hr", "outstanding", "link-guarantor"]
  }
];
const Navbar = ({
  showMobileSidebar = false,
  setShowMobileSidebar = () => {
  }
}) => {
  _s();
  const navigate = useNavigate();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileCard, setShowProfileCard] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [roleTitle, setRoleTitle] = useState("");
  const [branchName, setBranchName] = useState("");
  const [pendingApprovals, setPendingApprovals] = useState();
  const [taskCount, setTaskCount] = useState(0);
  const notificationRef = useRef(null);
  const profileRef = useRef(null);
  const searchBarRef = useRef(null);
  const quickActionRef = useRef(null);
  const [time, setTime] = useState(/* @__PURE__ */ new Date());
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [quickActionSearch, setQuickActionSearch] = useState("");
  const [showPaymentPasswordModal, setShowPaymentPasswordModal] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const quickActionSearchTerm = quickActionSearch.trim().toLowerCase();
  const filteredQuickActions = quickActions.filter((item) => {
    if (!quickActionSearchTerm) return true;
    return [item.label, item.route, ...item.keywords || []].join(" ").toLowerCase().includes(quickActionSearchTerm);
  });
  const groupedQuickActions = quickActionMegaGroups.map((group) => ({
    ...group,
    items: group.ids.map((id) => filteredQuickActions.find((item) => item.id === id)).filter(Boolean)
  })).filter((group) => group.items.length > 0);
  const quickActionsPanelId = "navbar-quick-actions";
  const closeQuickActions = () => {
    setShowQuickActions(false);
    setQuickActionSearch("");
  };
  const focusSearchInput = () => {
    window.setTimeout(() => {
      searchBarRef.current?.querySelector("input")?.focus();
    }, 0);
  };
  const toggleQuickActions = () => {
    setShowQuickActions((current) => {
      const nextState = !current;
      if (nextState) focusSearchInput();
      return nextState;
    });
  };
  const handleSearchChange = (e) => {
    setQuickActionSearch(e.target.value);
    setShowQuickActions(true);
  };
  const handleSearchFocus = () => {
    setShowQuickActions(true);
  };
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("admin");
    localStorage.removeItem("branch");
    navigate("/");
  };
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const usr = localStorage.getItem("user");
        if (usr) {
          const admin = JSON.parse(usr);
          setAdminName(admin?.admin_name || admin?.name || "User");
          const storedBranch = localStorage.getItem("branch");
          if (storedBranch) {
            try {
              const branchData = JSON.parse(storedBranch);
              setBranchName(branchData);
            } catch (error) {
              console.error(error);
            }
          }
          if (admin.admin_access_right_id && typeof admin.admin_access_right_id === "object") {
            setRoleTitle(admin.admin_access_right_id.title);
          } else if (admin._id) {
            try {
              const response = await API.get("/admin/me");
              const fullUserData = response.data?.data || response.data;
              if (fullUserData?.admin_access_right_id?.title) {
                setRoleTitle(fullUserData.admin_access_right_id.title);
              } else {
                setRoleTitle("Admin");
              }
            } catch (apiError) {
              console.error("Failed to fetch role details:", apiError);
              setRoleTitle("Admin");
            }
          } else {
            setRoleTitle("Admin");
          }
        } else {
          setAdminName("User");
          setRoleTitle("Admin");
        }
      } catch (error) {
        console.error("Failed to parse admin:", error);
        setAdminName("User");
        setRoleTitle("Admin");
      }
    };
    fetchUserData();
  }, []);
  useEffect(() => {
    const fetchPendingApprovals = async () => {
      try {
        const response = await API.get("/approvals/count");
        setPendingApprovals(response?.data);
      } catch (error) {
        console.error("Error fetching pending approvals", error);
      }
    };
    fetchPendingApprovals();
  }, []);
  const getPendingCount = (categoryId) => {
    if (!pendingApprovals?.data) return 0;
    switch (categoryId) {
      case 1:
        return pendingApprovals.data.unapproved_users;
      case 2:
        return pendingApprovals.data.unapproved_enrollments;
      case 3:
        return pendingApprovals.data.unapproved_loans;
      default:
        return 0;
    }
  };
  const notificationCount = getPendingCount(1) + getPendingCount(2) + getPendingCount(3);
  useEffect(() => {
    const fetchMyTaskCount = async () => {
      try {
        const userStr = localStorage.getItem("admin");
        if (!userStr) return;
        const user = JSON.parse(userStr);
        const myId = user._id;
        const res = await API.get("/complaints/all");
        const complaints = res.data?.data || [];
        const myPendingTickets = complaints.filter((item) => {
          if (!item.assignedTo) return false;
          let assignedId = null;
          if (typeof item.assignedTo === "object" && item.assignedTo._id) {
            assignedId = item.assignedTo._id;
          } else if (typeof item.assignedTo === "string") {
            assignedId = item.assignedTo;
          }
          const isAssignedToMe = String(assignedId) === String(myId);
          const isPending = item.status !== "Closed";
          return isAssignedToMe && isPending;
        });
        setTaskCount(myPendingTickets.length);
      } catch (error) {
        console.error("Error fetching task count", error);
      }
    };
    fetchMyTaskCount();
  }, []);
  useEffect(() => {
    const timer = setInterval(() => {
      setTime(/* @__PURE__ */ new Date());
    }, 1e3);
    return () => clearInterval(timer);
  }, []);
  const formatTime = (date) => date.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  const userData = localStorage.getItem("user");
  const username = userData ? JSON.parse(userData)?.name || JSON.parse(userData)?.admin_name : "";
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target)) {
        setShowNotifications(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setShowProfileCard(false);
      }
      if (showQuickActions && searchBarRef.current && quickActionRef.current && !searchBarRef.current.contains(event.target) && !quickActionRef.current.contains(event.target)) {
        setShowQuickActions(false);
        setQuickActionSearch("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showQuickActions]);
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key !== "Escape") return;
      setShowQuickActions(false);
      setQuickActionSearch("");
      setShowNotifications(false);
      setShowProfileCard(false);
    };
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);
  useEffect(() => {
    const AUTO_LOGOUT_TIME = 10 * 60 * 60 * 1e3;
    const WARNING_TIME = 10 * 60 * 1e3;
    const WARNING_START_TIME = AUTO_LOGOUT_TIME - WARNING_TIME;
    let inactivityTimer;
    let countdownInterval;
    const performLogout = () => {
      clearTimeout(inactivityTimer);
      clearInterval(countdownInterval);
      handleLogout();
    };
    const startCountdown = () => {
      setShowWarningModal(true);
      setCountdown(Math.floor(WARNING_TIME / 1e3));
      countdownInterval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            performLogout();
            return 0;
          }
          return prev - 1;
        });
      }, 1e3);
    };
    const resetTimers = () => {
      clearTimeout(inactivityTimer);
      clearInterval(countdownInterval);
      inactivityTimer = setTimeout(startCountdown, WARNING_START_TIME);
    };
    const events = ["mousemove", "keydown", "click", "scroll"];
    events.forEach((event) => window.addEventListener(event, resetTimers));
    resetTimers();
    return () => {
      clearTimeout(inactivityTimer);
      clearInterval(countdownInterval);
      events.forEach((event) => window.removeEventListener(event, resetTimers));
    };
  }, []);
  const handlePaymentPasswordSubmit = () => {
    setPasswordError("");
    setPasswordSuccess("");
    const userStr = localStorage.getItem("user");
    if (!userStr) {
      setPasswordError("User not found. Please login again.");
      return;
    }
    const userData2 = JSON.parse(userStr);
    const storedPassword = userData2?.password || "";
    if (!currentPassword.trim()) {
      setPasswordError("Current password is required.");
      return;
    }
    if (currentPassword !== storedPassword) {
      setPasswordError("Current password is incorrect.");
      return;
    }
    if (!newPassword.trim() || newPassword.length < 6) {
      setPasswordError("New password must be at least 6 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError("New password and confirm password do not match.");
      return;
    }
    setPasswordLoading(true);
    try {
      userData2.password = newPassword;
      localStorage.setItem("user", JSON.stringify(userData2));
      setPasswordSuccess("Payment password updated successfully!");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setTimeout(() => {
        setShowPaymentPasswordModal(false);
        setPasswordSuccess("");
      }, 2e3);
    } catch {
      setPasswordError("Failed to update password. Please try again.");
    } finally {
      setPasswordLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("nav", { className: "fixed left-0 top-0 z-50 w-full", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex h-[68px] min-w-0 items-center gap-2 border-b border-slate-200/70 bg-white/80 px-3 text-slate-900 shadow-[0_1px_10px_rgba(15,23,42,0.06)] backdrop-blur-xl sm:gap-3 sm:px-4 lg:px-6", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => navigate("/"),
          className: "flex min-w-[44px] shrink-0 items-center gap-2 rounded-2xl pr-1 text-slate-900 transition hover:bg-slate-100/70 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/30 sm:min-w-[170px] md:min-w-[190px] lg:min-w-[220px]",
          children: [
            /* @__PURE__ */ jsxDEV("img", { src: CityChits, alt: "Logo", className: "h-9 shrink-0 sm:h-10" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 446,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "hidden min-w-0 max-w-[170px] flex-col leading-tight sm:flex lg:max-w-[210px]", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "truncate text-[16px] font-semibold tracking-tight text-slate-950 lg:text-[17px]", children: "My Chits New" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 449,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "hidden truncate text-xs font-medium text-slate-500 xl:block", title: branchName?.branch_name, children: branchName?.branch_name?.toLowerCase()?.endsWith("branch") ? branchName?.branch_name : `${branchName?.branch_name} Branch` }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 450,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 448,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 442,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 flex-1 items-center justify-center gap-1.5 sm:min-w-[220px] sm:gap-2 md:gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            "aria-label": "Go back",
            onClick: () => {
              if (window.history.length > 1) {
                navigate(-1);
                return;
              }
              navigate("/dashboard");
            },
            className: "hidden h-9 w-9 shrink-0 place-items-center rounded-full border border-slate-200/70 bg-white/60 text-slate-600 shadow-sm shadow-slate-900/[0.03] backdrop-blur-xl transition duration-200 hover:bg-white hover:text-slate-950 active:scale-95 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 sm:grid lg:h-10 lg:w-10",
            children: /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "h-[18px] w-[18px]", strokeWidth: 1.9 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 471,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 459,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            ref: searchBarRef,
            className: "flex h-10 w-full min-w-0 max-w-[720px] items-center rounded-full border border-slate-200/80 bg-slate-100/75 px-3 text-slate-900 shadow-inner shadow-white/60 backdrop-blur-xl transition focus-within:border-[#0071e3]/60 focus-within:bg-white/90 focus-within:ring-2 focus-within:ring-[#0071e3]/15 sm:px-3.5",
            children: /* @__PURE__ */ jsxDEV(
              GlobalSearchBar,
              {
                onGlobalSearchChangeHandler: handleSearchChange,
                onFocus: handleSearchFocus,
                onQuickActionToggle: toggleQuickActions,
                quickActionsOpen: showQuickActions,
                quickActionsPanelId,
                value: quickActionSearch,
                visibility: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 477,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 473,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 458,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 shrink-0 items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hidden items-center gap-2 rounded-full border border-slate-200/70 bg-white/55 px-2.5 py-1.5 text-slate-700 backdrop-blur-xl 2xl:flex", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV("svg", { className: "h-3.5 w-3.5 text-slate-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 494,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 493,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "whitespace-nowrap text-xs font-semibold", children: formatTime(time) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 496,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 492,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "h-4 w-px bg-slate-300/80" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 498,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(FaUserCircle, { className: "h-4 w-4 shrink-0 text-slate-500" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 500,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "max-w-[100px] truncate text-xs font-semibold", title: username, children: username || "User" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 501,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 499,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 491,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ml-1 flex items-center gap-0.5 rounded-full border border-slate-200/70 bg-white/55 p-1 backdrop-blur-xl sm:ml-2 sm:gap-1", children: [
          /* @__PURE__ */ jsxDEV(NavLink, { to: "/my-tasks", className: "relative group", children: /* @__PURE__ */ jsxDEV("button", { "aria-label": "Open my tasks", className: "relative flex h-9 w-9 items-center justify-center rounded-full text-slate-600 transition duration-200 hover:bg-slate-100 hover:text-slate-950 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 lg:h-10 lg:w-10", children: [
            /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 512,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 511,
              columnNumber: 15
            }, this),
            taskCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute right-2 top-2 flex h-1.5 w-1.5 rounded-full bg-[#0071e3] ring-2 ring-white", children: /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: taskCount > 9 ? "9+" : taskCount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 516,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 515,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "invisible absolute left-1/2 top-12 -translate-x-1/2 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 opacity-0 shadow-lg shadow-slate-900/10 transition-all group-hover:visible group-hover:opacity-100", children: "My Tasks" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 521,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 510,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 509,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative group", ref: notificationRef, children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "aria-label": "Open notifications",
                onClick: () => setShowNotifications(!showNotifications),
                className: "relative flex h-9 w-9 items-center justify-center rounded-full text-slate-600 transition duration-200 hover:bg-slate-100 hover:text-slate-950 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 lg:h-10 lg:w-10",
                children: [
                  /* @__PURE__ */ jsxDEV(IoIosNotifications, { className: "text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 534,
                    columnNumber: 17
                  }, this),
                  notificationCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute right-2 top-2 flex h-1.5 w-1.5 rounded-full bg-[#0071e3] ring-2 ring-white", children: /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: [
                    notificationCount,
                    " notifications"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 537,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 536,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "invisible absolute left-1/2 top-12 -translate-x-1/2 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 opacity-0 shadow-lg shadow-slate-900/10 transition-all group-hover:visible group-hover:opacity-100", children: "Notifications" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 540,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 529,
                columnNumber: 15
              },
              this
            ),
            showNotifications && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 z-50 mt-3 w-80 max-w-[calc(100vw-24px)] overflow-hidden rounded-2xl border border-slate-200/70 bg-white/85 shadow-xl shadow-slate-900/10 backdrop-blur-2xl backdrop-saturate-150", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-slate-200/70 bg-white/70 px-4 py-3", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold tracking-tight text-slate-950", children: "Pending Actions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 547,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-slate-100/80 px-2 py-0.5 text-[11px] font-semibold text-slate-500", children: notificationCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 548,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 546,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "max-h-80 overflow-y-auto p-2", children: [
                {
                  title: "Payment Link Transactions",
                  href: "/payment-link-transactions",
                  color: "text-green-600",
                  icon: /* @__PURE__ */ jsxDEV(FiCreditCard, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 558,
                    columnNumber: 27
                  }, this)
                },
                {
                  title: "Unverified Customers",
                  href: "/approval-menu/un-approved-customer",
                  color: "text-blue-600",
                  count: getPendingCount(1),
                  icon: /* @__PURE__ */ jsxDEV(FiUsers, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 565,
                    columnNumber: 27
                  }, this)
                },
                {
                  title: "Mobile Enrollments",
                  href: "/approval-menu/mobile-app-enroll",
                  color: "text-amber-600",
                  count: getPendingCount(2),
                  icon: /* @__PURE__ */ jsxDEV(FiSmartphone, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 572,
                    columnNumber: 27
                  }, this)
                },
                {
                  title: "Unapproved Loans",
                  href: "/other-service-menu/loan",
                  color: "text-red-600",
                  count: getPendingCount(3),
                  icon: /* @__PURE__ */ jsxDEV(GiReceiveMoney, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 579,
                    columnNumber: 27
                  }, this)
                }
              ].map(
                (item, index) => /* @__PURE__ */ jsxDEV(
                  NavLink,
                  {
                    to: item.href,
                    onClick: () => setShowNotifications(false),
                    className: "group flex items-center gap-3 rounded-xl border border-transparent px-3 py-2.5 transition duration-200 hover:border-slate-200/70 hover:bg-white/75 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0071e3]/25",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: `flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-current/10 bg-slate-50/80 ${item.color}`, children: item.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 588,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "truncate text-[13px] font-semibold text-slate-800", children: item.title }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 592,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-[11px] text-slate-500", children: item.count > 0 ? `${item.count} items to review` : "No pending items" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 593,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 591,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-[#0071e3]", children: "->" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 597,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 582,
                    columnNumber: 19
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 552,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 545,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 528,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative group", ref: profileRef, children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "aria-label": "Open profile menu",
                onClick: () => setShowProfileCard(!showProfileCard),
                className: "relative flex h-9 w-9 items-center justify-center rounded-full bg-white text-slate-700 ring-1 ring-slate-200/80 transition duration-200 hover:bg-slate-50 hover:text-[#0071e3] focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 lg:h-10 lg:w-10",
                children: [
                  /* @__PURE__ */ jsxDEV(CgProfile, { className: "text-lg lg:text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 612,
                    columnNumber: 15
                  }, this),
                  !showProfileCard && /* @__PURE__ */ jsxDEV("span", { className: "invisible absolute left-1/2 top-12 -translate-x-1/2 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 opacity-0 shadow-lg shadow-slate-900/10 transition-all group-hover:visible group-hover:opacity-100", children: "Profile" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 614,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 607,
                columnNumber: 15
              },
              this
            ),
            showProfileCard && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 z-50 mt-3 w-[340px] max-w-[calc(100vw-24px)] overflow-hidden rounded-2xl border border-slate-200/70 bg-white/85 shadow-xl shadow-slate-900/10 backdrop-blur-2xl backdrop-saturate-150", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden border-b border-slate-200/70 bg-white/70 px-5 pb-5 pt-5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative shrink-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "h-14 w-14 rounded-full border border-slate-200/80 bg-white/80 p-1 shadow-sm shadow-slate-900/[0.04]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-slate-100/90", children: /* @__PURE__ */ jsxDEV(CgProfile, { className: "text-[34px] text-slate-700" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 627,
                      columnNumber: 27
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 626,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 625,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "absolute bottom-0 right-0 flex h-4 w-4 items-center justify-center rounded-full border-2 border-white bg-emerald-500", children: /* @__PURE__ */ jsxDEV("span", { className: "h-1.5 w-1.5 rounded-full bg-white" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 631,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 630,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 624,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "truncate text-base font-semibold text-slate-950", children: adminName || "Admin User" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 635,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-1 truncate text-xs font-medium text-slate-500", children: roleTitle || "Administrator" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 636,
                      columnNumber: 23
                    }, this),
                    branchName?.branch_name && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV(FaStore, { className: "text-[11px] text-slate-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 639,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "truncate text-[11px] font-medium text-slate-600", children: branchName.branch_name.toLowerCase().endsWith("branch") ? branchName.branch_name : `${branchName.branch_name} Branch` }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 640,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 638,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 634,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 623,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative mt-4 flex items-center justify-between rounded-xl border border-slate-200/70 bg-white/70 px-3 py-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-slate-500", children: "Account Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 650,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 text-[11px] font-semibold text-slate-700", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "h-2 w-2 rounded-full bg-emerald-400" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 652,
                      columnNumber: 23
                    }, this),
                    "Active"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 651,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 649,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 622,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setShowProfileCard(false);
                      setShowPaymentPasswordModal(true);
                    },
                    className: "group flex w-full items-center gap-3 rounded-xl border border-transparent px-3 py-2.5 text-left transition duration-200 hover:border-slate-200/70 hover:bg-white/75 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0071e3]/25",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-blue-100/80 bg-blue-50 text-[#0071e3]", children: /* @__PURE__ */ jsxDEV(FaLock, { className: "h-4 w-4" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 669,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 668,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] font-semibold text-slate-700", children: "Change Transaction Password" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 672,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-[11px] text-slate-400", children: "Change payment authorization PIN" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 673,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 671,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-[#0071e3]", children: "->" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 675,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 660,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setShowProfileCard(false),
                    className: "group flex w-full items-center gap-3 rounded-xl border border-transparent px-3 py-2.5 text-left transition duration-200 hover:border-slate-200/70 hover:bg-white/75 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0071e3]/25",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200/70 bg-slate-100/80 text-slate-600", children: /* @__PURE__ */ jsxDEV(FiClock, { className: "h-4 w-4" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 683,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 682,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-slate-700", children: "Login Activity" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 686,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-[11px] text-slate-400", children: "Review recent account activity" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 687,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 685,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-[#0071e3]", children: "->" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                        lineNumber: 689,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                    lineNumber: 677,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 659,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 658,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border-t border-slate-200/70 p-3", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: handleLogout,
                  className: "group flex w-full items-center justify-center gap-2.5 rounded-xl border border-red-100/80 bg-red-50/80 py-2.5 text-red-600 transition duration-200 hover:bg-red-100/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500/20",
                  children: [
                    /* @__PURE__ */ jsxDEV(IoIosLogOut, { className: "text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 700,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold", children: "Logout" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 701,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 695,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 694,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 621,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 606,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 507,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              "aria-label": showMobileSidebar ? "Close mobile menu" : "Open mobile menu",
              onClick: () => setShowMobileSidebar(!showMobileSidebar),
              className: "grid h-10 w-10 place-items-center rounded-full border border-slate-200/70 bg-white/55 text-slate-700 transition hover:bg-slate-100 hover:text-slate-950 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 md:hidden",
              children: showMobileSidebar ? /* @__PURE__ */ jsxDEV(HiX, { size: 24 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 716,
                columnNumber: 36
              }, this) : /* @__PURE__ */ jsxDEV(BiMenu, { size: 24 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 716,
                columnNumber: 56
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 711,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "invisible absolute right-0 top-12 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 opacity-0 shadow-lg shadow-slate-900/10 transition-all group-hover:visible group-hover:opacity-100", children: showMobileSidebar ? "Close Menu" : "Open Menu" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 718,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 710,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 489,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
      lineNumber: 441,
      columnNumber: 7
    }, this),
    showQuickActions && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          "aria-label": "Close Quick Actions",
          className: "fixed inset-x-0 bottom-0 top-[68px] z-30 cursor-default bg-slate-900/10 backdrop-blur-[3px]",
          onClick: closeQuickActions
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 729,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          id: quickActionsPanelId,
          ref: quickActionRef,
          className: "absolute left-0 right-0 top-[68px] z-40 h-auto overflow-visible border-b border-slate-200/70 bg-white/90 text-slate-950 shadow-lg shadow-slate-900/10 backdrop-blur-2xl backdrop-saturate-150 animate-in fade-in slide-in-from-top-2",
          children: /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex h-auto w-full max-w-5xl flex-col px-5 py-5 sm:px-8 lg:py-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-5 flex shrink-0 items-end justify-between gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-slate-500", children: "Quick Actions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 743,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { className: "mt-1 truncate text-2xl font-semibold tracking-tight text-slate-950", children: quickActionSearchTerm ? "Search shortcuts" : "Open a shortcut" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 744,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 742,
                columnNumber: 17
              }, this),
              quickActionSearchTerm && /* @__PURE__ */ jsxDEV("p", { className: "hidden shrink-0 text-xs font-medium text-slate-400 sm:block", children: [
                filteredQuickActions.length,
                " matched"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 749,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 741,
              columnNumber: 15
            }, this),
            filteredQuickActions.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-[180px] flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 text-center", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-slate-700", children: "No quick action found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 757,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-slate-500", children: "Try payment, reports, customer, HR, or search." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 758,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 756,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid max-h-[calc(100dvh-92px)] grid-cols-1 gap-x-12 gap-y-6 overflow-y-auto overscroll-contain pr-1 sm:grid-cols-2 lg:max-h-none lg:grid-cols-[1.25fr_1fr_1fr_1fr] lg:overflow-visible lg:pr-0", children: groupedQuickActions.map(
              (group) => /* @__PURE__ */ jsxDEV("section", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "mb-3 text-xs font-medium text-slate-500", children: group.title }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 764,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: group.items.map((item) => {
                  const Icon = item.icon;
                  const accentClass = quickActionAccentClasses[item.accent] || "bg-slate-100 text-slate-600";
                  return /* @__PURE__ */ jsxDEV(
                    NavLink,
                    {
                      to: item.route,
                      "aria-label": `Open ${item.label}`,
                      onClick: closeQuickActions,
                      className: "group flex min-w-0 items-center gap-2.5 rounded-xl px-2 py-1.5 text-left transition duration-150 hover:bg-slate-100/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0071e3]/30",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: `grid h-6 w-6 shrink-0 place-items-center rounded-lg ${accentClass}`, children: /* @__PURE__ */ jsxDEV(Icon, { className: "h-3.5 w-3.5", strokeWidth: 1.8 }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 779,
                          columnNumber: 33
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 778,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "min-w-0 flex-1 truncate text-sm font-semibold leading-5 tracking-tight text-slate-900 group-hover:text-[#0071e3]", children: item.label }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                          lineNumber: 781,
                          columnNumber: 31
                        }, this)
                      ]
                    },
                    item.id,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                      lineNumber: 771,
                      columnNumber: 23
                    },
                    this
                  );
                }) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                  lineNumber: 765,
                  columnNumber: 23
                }, this)
              ] }, group.title, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 763,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 761,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 740,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 735,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
      lineNumber: 728,
      columnNumber: 7
    }, this),
    showWarningModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4 text-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mb-4 mx-auto", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-8 h-8", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 802,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 801,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 800,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-extrabold text-slate-800 mb-2", children: "Session Expiring" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 805,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 mb-6", children: [
        "You have been inactive for a while. You will be logged out in",
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-amber-600 mx-1 text-xl", children: countdown }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 808,
          columnNumber: 15
        }, this),
        "seconds."
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 806,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 w-full", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, className: "flex-1 py-3 px-4 rounded-xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50", children: "Logout Now" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 812,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowWarningModal(false), className: "flex-1 py-3 px-4 rounded-xl bg-[#0071e3] text-white font-semibold hover:bg-[#0066cc]", children: "Continue Session" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 815,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 811,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
      lineNumber: 799,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
      lineNumber: 798,
      columnNumber: 7
    }, this),
    showPaymentPasswordModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-extrabold text-slate-800 mb-2 flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(FaLock, { className: "text-emerald-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 828,
          columnNumber: 15
        }, this),
        "Change Transaction Password"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 827,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 text-xs mb-6", children: "Enter your current password and set a new one." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 831,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700 mb-1", children: "Current Password" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 834,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: showCurrentPassword ? "text" : "password",
              placeholder: "Enter current password",
              value: currentPassword,
              onChange: (e) => setCurrentPassword(e.target.value),
              className: "w-full px-4 py-2.5 pr-12 rounded-xl border border-slate-200 focus:border-[#0071e3] focus:ring-2 focus:ring-[#0071e3]/20 outline-none"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 839,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowCurrentPassword(!showCurrentPassword),
              className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0071e3]",
              children: showCurrentPassword ? /* @__PURE__ */ jsxDEV(FaEyeSlash, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 852,
                columnNumber: 42
              }, this) : /* @__PURE__ */ jsxDEV(FaEye, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 852,
                columnNumber: 59
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 847,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 838,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 833,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700 mb-1", children: "New Password" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 858,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: showNewPassword ? "text" : "password",
              placeholder: "Enter new password",
              value: newPassword,
              onChange: (e) => setNewPassword(e.target.value),
              className: "w-full px-4 py-2.5 pr-12 rounded-xl border border-slate-200 focus:border-[#0071e3] focus:ring-2 focus:ring-[#0071e3]/20 outline-none"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 863,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowNewPassword(!showNewPassword),
              className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0071e3]",
              children: showNewPassword ? /* @__PURE__ */ jsxDEV(FaEyeSlash, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 876,
                columnNumber: 38
              }, this) : /* @__PURE__ */ jsxDEV(FaEye, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 876,
                columnNumber: 55
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 871,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 862,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 857,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700 mb-1", children: "Confirm New Password" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 882,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: showConfirmPassword ? "text" : "password",
              placeholder: "Re-enter new password",
              value: confirmPassword,
              onChange: (e) => setConfirmPassword(e.target.value),
              className: "w-full px-4 py-2.5 pr-12 rounded-xl border border-slate-200 focus:border-[#0071e3] focus:ring-2 focus:ring-[#0071e3]/20 outline-none"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 887,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowConfirmPassword(!showConfirmPassword),
              className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0071e3]",
              children: showConfirmPassword ? /* @__PURE__ */ jsxDEV(FaEyeSlash, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 900,
                columnNumber: 42
              }, this) : /* @__PURE__ */ jsxDEV(FaEye, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
                lineNumber: 900,
                columnNumber: 59
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
              lineNumber: 895,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
          lineNumber: 886,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 881,
        columnNumber: 13
      }, this),
      passwordError && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-xl border border-red-100", children: passwordError }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 906,
        columnNumber: 11
      }, this),
      passwordSuccess && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-emerald-50 text-[#0071e3] text-sm rounded-xl border border-emerald-100", children: passwordSuccess }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 909,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setShowPaymentPasswordModal(false);
              setCurrentPassword("");
              setNewPassword("");
              setConfirmPassword("");
              setPasswordError("");
              setPasswordSuccess("");
            },
            className: "flex-1 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 913,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handlePaymentPasswordSubmit,
            disabled: passwordLoading,
            className: "flex-1 py-3 rounded-xl bg-[#0071e3] text-white font-semibold hover:bg-[#0066cc] disabled:opacity-60",
            children: passwordLoading ? "Updating..." : "Update Password"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
            lineNumber: 926,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
        lineNumber: 912,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
      lineNumber: 826,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
      lineNumber: 825,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx",
    lineNumber: 439,
    columnNumber: 5
  }, this);
};
_s(Navbar, "RUf3NEMzgWeSE9Zh+J20FaJfXU4=", false, function() {
  return [useNavigate];
});
_c = Navbar;
export default Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Navbar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNmJVLFNBMFJGLFVBMVJFOzJCQTdiVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFVBQVVDLFdBQVdDLGNBQWM7QUFDNUMsU0FBU0MsU0FBU0MsbUJBQW1CO0FBQ3JDLE9BQU9DLHFCQUFxQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFFMUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG9CQUFvQkMsbUJBQW1CO0FBQ2hELFNBQVNDLFdBQVc7QUFDcEIsU0FBU0MsY0FBYztBQUV2QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFTQyxzQkFBc0I7QUFFL0IsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsU0FBUztBQUVoQixTQUFTQyxPQUFPQyxZQUFZQyxRQUFRQyxTQUFTQyxvQkFBb0I7QUFFakUsTUFBTUMsMkJBQTJCO0FBQUEsRUFDL0JDLE9BQU87QUFBQSxFQUNQQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ05DLFNBQVM7QUFBQSxFQUNUQyxPQUFPO0FBQUEsRUFDUEMsUUFBUTtBQUFBLEVBQ1JDLE1BQU07QUFBQSxFQUNOQyxRQUFRO0FBQUEsRUFDUkMsTUFBTTtBQUFBLEVBQ05DLFFBQVE7QUFBQSxFQUNSQyxLQUFLO0FBQUEsRUFDTEMsTUFBTTtBQUFBLEVBQ05DLEtBQUs7QUFBQSxFQUNMQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUFBLEVBQ1BDLE1BQU07QUFBQSxFQUNOQyxRQUFRO0FBQUEsRUFDUkMsUUFBUTtBQUFBLEVBQ1JDLE1BQU07QUFDUjtBQUVBLE1BQU1DLHdCQUF3QjtBQUFBLEVBQzVCO0FBQUEsSUFDRUMsT0FBTztBQUFBLElBQ1BDLEtBQUssQ0FBQyxjQUFjLFVBQVUsU0FBUyxjQUFjLGVBQWUsU0FBUztBQUFBLEVBQy9FO0FBQUEsRUFDQTtBQUFBLElBQ0VELE9BQU87QUFBQSxJQUNQQyxLQUFLLENBQUMsU0FBUyxTQUFTLFdBQVcsb0JBQW9CLGFBQWE7QUFBQSxFQUN0RTtBQUFBLEVBQ0E7QUFBQSxJQUNFRCxPQUFPO0FBQUEsSUFDUEMsS0FBSyxDQUFDLGFBQWEsZ0JBQWdCLFlBQVksYUFBYSxTQUFTO0FBQUEsRUFDdkU7QUFBQSxFQUNBO0FBQUEsSUFDRUQsT0FBTztBQUFBLElBQ1BDLEtBQUssQ0FBQyxnQkFBZ0IsTUFBTSxlQUFlLGdCQUFnQjtBQUFBLEVBQzdEO0FBQUM7QUFHSCxNQUFNQyxTQUFTQSxDQUFDO0FBQUEsRUFDZEMsb0JBQW9CO0FBQUEsRUFDcEJDLHVCQUF1QkEsTUFBTTtBQUFBLEVBQUU7QUFDakMsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTUMsV0FBV2hELFlBQVk7QUFFN0IsUUFBTSxDQUFDaUQsbUJBQW1CQyxvQkFBb0IsSUFBSXRELFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUN1RCxpQkFBaUJDLGtCQUFrQixJQUFJeEQsU0FBUyxLQUFLO0FBRTVELFFBQU0sQ0FBQ3lELFdBQVdDLFlBQVksSUFBSTFELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMyRCxXQUFXQyxZQUFZLElBQUk1RCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDNkQsWUFBWUMsYUFBYSxJQUFJOUQsU0FBUyxFQUFFO0FBRS9DLFFBQU0sQ0FBQytELGtCQUFrQkMsbUJBQW1CLElBQUloRSxTQUFTO0FBQ3pELFFBQU0sQ0FBQ2lFLFdBQVdDLFlBQVksSUFBSWxFLFNBQVMsQ0FBQztBQUU1QyxRQUFNbUUsa0JBQWtCakUsT0FBTyxJQUFJO0FBQ25DLFFBQU1rRSxhQUFhbEUsT0FBTyxJQUFJO0FBQzlCLFFBQU1tRSxlQUFlbkUsT0FBTyxJQUFJO0FBQ2hDLFFBQU1vRSxpQkFBaUJwRSxPQUFPLElBQUk7QUFFbEMsUUFBTSxDQUFDcUUsTUFBTUMsT0FBTyxJQUFJeEUsU0FBUyxvQkFBSXlFLEtBQUssQ0FBQztBQUUzQyxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUkzRSxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDNEUsbUJBQW1CQyxvQkFBb0IsSUFBSTdFLFNBQVMsRUFBRTtBQUU3RCxRQUFNLENBQUM4RSwwQkFBMEJDLDJCQUEyQixJQUFJL0UsU0FBUyxLQUFLO0FBQzlFLFFBQU0sQ0FBQ2dGLGlCQUFpQkMsa0JBQWtCLElBQUlqRixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDa0YsYUFBYUMsY0FBYyxJQUFJbkYsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ29GLGlCQUFpQkMsa0JBQWtCLElBQUlyRixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDc0YsZUFBZUMsZ0JBQWdCLElBQUl2RixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDd0YsaUJBQWlCQyxrQkFBa0IsSUFBSXpGLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUMwRixpQkFBaUJDLGtCQUFrQixJQUFJM0YsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzRGLHFCQUFxQkMsc0JBQXNCLElBQUk3RixTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDOEYsaUJBQWlCQyxrQkFBa0IsSUFBSS9GLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNnRyxxQkFBcUJDLHNCQUFzQixJQUFJakcsU0FBUyxLQUFLO0FBRXBFLFFBQU0sQ0FBQ2tHLGtCQUFrQkMsbUJBQW1CLElBQUluRyxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDb0csV0FBV0MsWUFBWSxJQUFJckcsU0FBUyxFQUFFO0FBRTdDLFFBQU1zRyx3QkFBd0IxQixrQkFBa0IyQixLQUFLLEVBQUVDLFlBQVk7QUFFbkUsUUFBTUMsdUJBQXVCeEYsYUFBYXlGLE9BQU8sQ0FBQ0MsU0FBUztBQUN6RCxRQUFJLENBQUNMLHNCQUF1QixRQUFPO0FBRW5DLFdBQU8sQ0FBQ0ssS0FBS0MsT0FBT0QsS0FBS0UsT0FBTyxHQUFJRixLQUFLRyxZQUFZLEVBQUcsRUFDckRDLEtBQUssR0FBRyxFQUNSUCxZQUFZLEVBQ1pRLFNBQVNWLHFCQUFxQjtBQUFBLEVBQ25DLENBQUM7QUFFRCxRQUFNVyxzQkFBc0JwRSxzQkFDekJxRSxJQUFJLENBQUNDLFdBQVc7QUFBQSxJQUNmLEdBQUdBO0FBQUFBLElBQ0hDLE9BQU9ELE1BQU1wRSxJQUNWbUUsSUFBSSxDQUFDRyxPQUFPWixxQkFBcUJhLEtBQUssQ0FBQ1gsU0FBU0EsS0FBS1UsT0FBT0EsRUFBRSxDQUFDLEVBQy9EWCxPQUFPYSxPQUFPO0FBQUEsRUFDbkIsRUFBRSxFQUNEYixPQUFPLENBQUNTLFVBQVVBLE1BQU1DLE1BQU1JLFNBQVMsQ0FBQztBQUUzQyxRQUFNQyxzQkFBc0I7QUFFNUIsUUFBTUMsb0JBQW9CQSxNQUFNO0FBQzlCL0Msd0JBQW9CLEtBQUs7QUFDekJFLHlCQUFxQixFQUFFO0FBQUEsRUFDekI7QUFFQSxRQUFNOEMsbUJBQW1CQSxNQUFNO0FBQzdCQyxXQUFPQyxXQUFXLE1BQU07QUFDdEJ4RCxtQkFBYXlELFNBQVNDLGNBQWMsT0FBTyxHQUFHQyxNQUFNO0FBQUEsSUFDdEQsR0FBRyxDQUFDO0FBQUEsRUFDTjtBQUVBLFFBQU1DLHFCQUFxQkEsTUFBTTtBQUMvQnRELHdCQUFvQixDQUFDbUQsWUFBWTtBQUMvQixZQUFNSSxZQUFZLENBQUNKO0FBQ25CLFVBQUlJLFVBQVdQLGtCQUFpQjtBQUNoQyxhQUFPTztBQUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUMscUJBQXFCQSxDQUFDQyxNQUFNO0FBQ2hDdkQseUJBQXFCdUQsRUFBRUMsT0FBT0MsS0FBSztBQUNuQzNELHdCQUFvQixJQUFJO0FBQUEsRUFDMUI7QUFFQSxRQUFNNEQsb0JBQW9CQSxNQUFNO0FBQzlCNUQsd0JBQW9CLElBQUk7QUFBQSxFQUMxQjtBQUdBLFFBQU02RCxlQUFlQSxNQUFNO0FBQ3pCQyxpQkFBYUMsV0FBVyxPQUFPO0FBQy9CRCxpQkFBYUMsV0FBVyxPQUFPO0FBQy9CRCxpQkFBYUMsV0FBVyxRQUFRO0FBQ2hDdEYsYUFBUyxHQUFHO0FBQUEsRUFDZDtBQUVBbkQsWUFBVSxNQUFNO0FBQ2QsVUFBTTBJLGdCQUFnQixZQUFZO0FBQ2hDLFVBQUk7QUFDRixjQUFNQyxNQUFNSCxhQUFhSSxRQUFRLE1BQU07QUFDdkMsWUFBSUQsS0FBSztBQUNQLGdCQUFNRSxRQUFRQyxLQUFLQyxNQUFNSixHQUFHO0FBQzVCbEYsdUJBQWFvRixPQUFPRyxjQUFjSCxPQUFPSSxRQUFRLE1BQU07QUFDdkQsZ0JBQU1DLGVBQWVWLGFBQWFJLFFBQVEsUUFBUTtBQUNsRCxjQUFJTSxjQUFjO0FBQ2hCLGdCQUFJO0FBQ0Ysb0JBQU1DLGFBQWFMLEtBQUtDLE1BQU1HLFlBQVk7QUFDMUNyRiw0QkFBY3NGLFVBQVU7QUFBQSxZQUMxQixTQUFTQyxPQUFPO0FBQ2RDLHNCQUFRRCxNQUFNQSxLQUFLO0FBQUEsWUFDckI7QUFBQSxVQUNGO0FBQ0EsY0FDRVAsTUFBTVMseUJBQ04sT0FBT1QsTUFBTVMsMEJBQTBCLFVBQ3ZDO0FBQ0EzRix5QkFBYWtGLE1BQU1TLHNCQUFzQnpHLEtBQUs7QUFBQSxVQUNoRCxXQUFXZ0csTUFBTVUsS0FBSztBQUNwQixnQkFBSTtBQUNGLG9CQUFNQyxXQUFXLE1BQU10SSxJQUFJdUksSUFBSSxXQUFXO0FBQzFDLG9CQUFNQyxlQUFlRixTQUFTRyxNQUFNQSxRQUFRSCxTQUFTRztBQUNyRCxrQkFBSUQsY0FBY0osdUJBQXVCekcsT0FBTztBQUM5Q2MsNkJBQWErRixhQUFhSixzQkFBc0J6RyxLQUFLO0FBQUEsY0FDdkQsT0FBTztBQUNMYyw2QkFBYSxPQUFPO0FBQUEsY0FDdEI7QUFBQSxZQUNGLFNBQVNpRyxVQUFVO0FBQ2pCUCxzQkFBUUQsTUFBTSxpQ0FBaUNRLFFBQVE7QUFDdkRqRywyQkFBYSxPQUFPO0FBQUEsWUFDdEI7QUFBQSxVQUNGLE9BQU87QUFDTEEseUJBQWEsT0FBTztBQUFBLFVBQ3RCO0FBQUEsUUFDRixPQUFPO0FBQ0xGLHVCQUFhLE1BQU07QUFDbkJFLHVCQUFhLE9BQU87QUFBQSxRQUN0QjtBQUFBLE1BQ0YsU0FBU3lGLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQzdDM0YscUJBQWEsTUFBTTtBQUNuQkUscUJBQWEsT0FBTztBQUFBLE1BQ3RCO0FBQUEsSUFDRjtBQUVBK0Usa0JBQWM7QUFBQSxFQUNoQixHQUFHLEVBQUU7QUFFTDFJLFlBQVUsTUFBTTtBQUNkLFVBQU02Six3QkFBd0IsWUFBWTtBQUN4QyxVQUFJO0FBQ0YsY0FBTUwsV0FBVyxNQUFNdEksSUFBSXVJLElBQUksa0JBQWtCO0FBQ2pEMUYsNEJBQW9CeUYsVUFBVUcsSUFBSTtBQUFBLE1BQ3BDLFNBQVNQLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sb0NBQW9DQSxLQUFLO0FBQUEsTUFDekQ7QUFBQSxJQUNGO0FBRUFTLDBCQUFzQjtBQUFBLEVBQ3hCLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGtCQUFrQkEsQ0FBQ0MsZUFBZTtBQUN0QyxRQUFJLENBQUNqRyxrQkFBa0I2RixLQUFNLFFBQU87QUFDcEMsWUFBUUksWUFBVTtBQUFBLE1BQ2hCLEtBQUs7QUFDSCxlQUFPakcsaUJBQWlCNkYsS0FBS0s7QUFBQUEsTUFDL0IsS0FBSztBQUNILGVBQU9sRyxpQkFBaUI2RixLQUFLTTtBQUFBQSxNQUMvQixLQUFLO0FBQ0gsZUFBT25HLGlCQUFpQjZGLEtBQUtPO0FBQUFBLE1BQy9CO0FBQ0UsZUFBTztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBRUEsUUFBTUMsb0JBQ0pMLGdCQUFnQixDQUFDLElBQUlBLGdCQUFnQixDQUFDLElBQUlBLGdCQUFnQixDQUFDO0FBRTdEOUosWUFBVSxNQUFNO0FBQ2QsVUFBTW9LLG1CQUFtQixZQUFZO0FBQ25DLFVBQUk7QUFDRixjQUFNQyxVQUFVN0IsYUFBYUksUUFBUSxPQUFPO0FBQzVDLFlBQUksQ0FBQ3lCLFFBQVM7QUFDZCxjQUFNQyxPQUFPeEIsS0FBS0MsTUFBTXNCLE9BQU87QUFDL0IsY0FBTUUsT0FBT0QsS0FBS2Y7QUFDbEIsY0FBTWlCLE1BQU0sTUFBTXRKLElBQUl1SSxJQUFJLGlCQUFpQjtBQUMzQyxjQUFNZ0IsYUFBYUQsSUFBSWIsTUFBTUEsUUFBUTtBQUNyQyxjQUFNZSxtQkFBbUJELFdBQVdoRSxPQUFPLENBQUNDLFNBQVM7QUFDbkQsY0FBSSxDQUFDQSxLQUFLaUUsV0FBWSxRQUFPO0FBQzdCLGNBQUlDLGFBQWE7QUFDakIsY0FBSSxPQUFPbEUsS0FBS2lFLGVBQWUsWUFBWWpFLEtBQUtpRSxXQUFXcEIsS0FBSztBQUM5RHFCLHlCQUFhbEUsS0FBS2lFLFdBQVdwQjtBQUFBQSxVQUMvQixXQUFXLE9BQU83QyxLQUFLaUUsZUFBZSxVQUFVO0FBQzlDQyx5QkFBYWxFLEtBQUtpRTtBQUFBQSxVQUNwQjtBQUNBLGdCQUFNRSxpQkFBaUJDLE9BQU9GLFVBQVUsTUFBTUUsT0FBT1AsSUFBSTtBQUN6RCxnQkFBTVEsWUFBWXJFLEtBQUtzRSxXQUFXO0FBQ2xDLGlCQUFPSCxrQkFBa0JFO0FBQUFBLFFBQzNCLENBQUM7QUFDRDlHLHFCQUFheUcsaUJBQWlCbkQsTUFBTTtBQUFBLE1BQ3RDLFNBQVM2QixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUVBZ0IscUJBQWlCO0FBQUEsRUFDbkIsR0FBRyxFQUFFO0FBRUxwSyxZQUFVLE1BQU07QUFDZCxVQUFNaUwsUUFBUUMsWUFBWSxNQUFNO0FBQzlCM0csY0FBUSxvQkFBSUMsS0FBSyxDQUFDO0FBQUEsSUFDcEIsR0FBRyxHQUFJO0FBQ1AsV0FBTyxNQUFNMkcsY0FBY0YsS0FBSztBQUFBLEVBQ2xDLEdBQUcsRUFBRTtBQUVMLFFBQU1HLGFBQWFBLENBQUNDLFNBQ2xCQSxLQUFLQyxtQkFBbUIsSUFBSTtBQUFBLElBQzFCQyxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUVILFFBQU1DLFdBQVdqRCxhQUFhSSxRQUFRLE1BQU07QUFDNUMsUUFBTThDLFdBQVdELFdBQ2IzQyxLQUFLQyxNQUFNMEMsUUFBUSxHQUFHeEMsUUFBUUgsS0FBS0MsTUFBTTBDLFFBQVEsR0FBR3pDLGFBQ3BEO0FBRUpoSixZQUFVLE1BQU07QUFDZCxVQUFNMkwscUJBQXFCQSxDQUFDQyxVQUFVO0FBQ3BDLFVBQ0UxSCxnQkFBZ0IyRCxXQUNoQixDQUFDM0QsZ0JBQWdCMkQsUUFBUWdFLFNBQVNELE1BQU14RCxNQUFNLEdBQzlDO0FBQ0EvRSw2QkFBcUIsS0FBSztBQUFBLE1BQzVCO0FBQ0EsVUFDRWMsV0FBVzBELFdBQ1gsQ0FBQzFELFdBQVcwRCxRQUFRZ0UsU0FBU0QsTUFBTXhELE1BQU0sR0FDekM7QUFDQTdFLDJCQUFtQixLQUFLO0FBQUEsTUFDMUI7QUFDQSxVQUNFa0Isb0JBQ0FMLGFBQWF5RCxXQUNieEQsZUFBZXdELFdBQ2YsQ0FBQ3pELGFBQWF5RCxRQUFRZ0UsU0FBU0QsTUFBTXhELE1BQU0sS0FDM0MsQ0FBQy9ELGVBQWV3RCxRQUFRZ0UsU0FBU0QsTUFBTXhELE1BQU0sR0FDN0M7QUFDQTFELDRCQUFvQixLQUFLO0FBQ3pCRSw2QkFBcUIsRUFBRTtBQUFBLE1BQ3pCO0FBQUEsSUFDRjtBQUVBa0gsYUFBU0MsaUJBQWlCLGFBQWFKLGtCQUFrQjtBQUN6RCxXQUFPLE1BQU07QUFDWEcsZUFBU0Usb0JBQW9CLGFBQWFMLGtCQUFrQjtBQUFBLElBQzlEO0FBQUEsRUFDRixHQUFHLENBQUNsSCxnQkFBZ0IsQ0FBQztBQUVyQnpFLFlBQVUsTUFBTTtBQUNkLFVBQU1pTSxlQUFlQSxDQUFDTCxVQUFVO0FBQzlCLFVBQUlBLE1BQU1NLFFBQVEsU0FBVTtBQUU1QnhILDBCQUFvQixLQUFLO0FBQ3pCRSwyQkFBcUIsRUFBRTtBQUN2QnZCLDJCQUFxQixLQUFLO0FBQzFCRSx5QkFBbUIsS0FBSztBQUFBLElBQzFCO0FBRUF1SSxhQUFTQyxpQkFBaUIsV0FBV0UsWUFBWTtBQUNqRCxXQUFPLE1BQU07QUFDWEgsZUFBU0Usb0JBQW9CLFdBQVdDLFlBQVk7QUFBQSxJQUN0RDtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBR0xqTSxZQUFVLE1BQU07QUFDZCxVQUFNbU0sbUJBQW1CLEtBQUssS0FBSyxLQUFLO0FBQ3hDLFVBQU1DLGVBQWUsS0FBSyxLQUFLO0FBQy9CLFVBQU1DLHFCQUFxQkYsbUJBQW1CQztBQUU5QyxRQUFJRTtBQUNKLFFBQUlDO0FBRUosVUFBTUMsZ0JBQWdCQSxNQUFNO0FBQzFCQyxtQkFBYUgsZUFBZTtBQUM1Qm5CLG9CQUFjb0IsaUJBQWlCO0FBQy9CaEUsbUJBQWE7QUFBQSxJQUNmO0FBRUEsVUFBTW1FLGlCQUFpQkEsTUFBTTtBQUMzQnhHLDBCQUFvQixJQUFJO0FBQ3hCRSxtQkFBYXVHLEtBQUtDLE1BQU1SLGVBQWUsR0FBSSxDQUFDO0FBQzVDRywwQkFBb0JyQixZQUFZLE1BQU07QUFDcEM5RSxxQkFBYSxDQUFDeUcsU0FBUztBQUNyQixjQUFJQSxRQUFRLEdBQUc7QUFDYkwsMEJBQWM7QUFDZCxtQkFBTztBQUFBLFVBQ1Q7QUFDQSxpQkFBT0ssT0FBTztBQUFBLFFBQ2hCLENBQUM7QUFBQSxNQUNILEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFFQSxVQUFNQyxjQUFjQSxNQUFNO0FBQ3hCTCxtQkFBYUgsZUFBZTtBQUM1Qm5CLG9CQUFjb0IsaUJBQWlCO0FBQy9CRCx3QkFBa0IxRSxXQUFXOEUsZ0JBQWdCTCxrQkFBa0I7QUFBQSxJQUNqRTtBQUVBLFVBQU1VLFNBQVMsQ0FBQyxhQUFhLFdBQVcsU0FBUyxRQUFRO0FBQ3pEQSxXQUFPQyxRQUFRLENBQUNwQixVQUFVakUsT0FBT29FLGlCQUFpQkgsT0FBT2tCLFdBQVcsQ0FBQztBQUNyRUEsZ0JBQVk7QUFFWixXQUFPLE1BQU07QUFDWEwsbUJBQWFILGVBQWU7QUFDNUJuQixvQkFBY29CLGlCQUFpQjtBQUMvQlEsYUFBT0MsUUFBUSxDQUFDcEIsVUFBVWpFLE9BQU9xRSxvQkFBb0JKLE9BQU9rQixXQUFXLENBQUM7QUFBQSxJQUMxRTtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUcsOEJBQThCQSxNQUFNO0FBQ3hDM0gscUJBQWlCLEVBQUU7QUFDbkJFLHVCQUFtQixFQUFFO0FBRXJCLFVBQU02RSxVQUFVN0IsYUFBYUksUUFBUSxNQUFNO0FBQzNDLFFBQUksQ0FBQ3lCLFNBQVM7QUFDWi9FLHVCQUFpQixxQ0FBcUM7QUFDdEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTW1HLFlBQVczQyxLQUFLQyxNQUFNc0IsT0FBTztBQUNuQyxVQUFNNkMsaUJBQWlCekIsV0FBVTBCLFlBQVk7QUFFN0MsUUFBSSxDQUFDcEksZ0JBQWdCdUIsS0FBSyxHQUFHO0FBQzNCaEIsdUJBQWlCLCtCQUErQjtBQUNoRDtBQUFBLElBQ0Y7QUFDQSxRQUFJUCxvQkFBb0JtSSxnQkFBZ0I7QUFDdEM1SCx1QkFBaUIsZ0NBQWdDO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQ0wsWUFBWXFCLEtBQUssS0FBS3JCLFlBQVlzQyxTQUFTLEdBQUc7QUFDakRqQyx1QkFBaUIsNkNBQTZDO0FBQzlEO0FBQUEsSUFDRjtBQUNBLFFBQUlMLGdCQUFnQkUsaUJBQWlCO0FBQ25DRyx1QkFBaUIsaURBQWlEO0FBQ2xFO0FBQUEsSUFDRjtBQUVBSSx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YrRixnQkFBUzBCLFdBQVdsSTtBQUNwQnVELG1CQUFhNEUsUUFBUSxRQUFRdEUsS0FBS3VFLFVBQVU1QixTQUFRLENBQUM7QUFDckRqRyx5QkFBbUIsd0NBQXdDO0FBQzNEUix5QkFBbUIsRUFBRTtBQUNyQkUscUJBQWUsRUFBRTtBQUNqQkUseUJBQW1CLEVBQUU7QUFDckJ3QyxpQkFBVyxNQUFNO0FBQ2Y5QyxvQ0FBNEIsS0FBSztBQUNqQ1UsMkJBQW1CLEVBQUU7QUFBQSxNQUN2QixHQUFHLEdBQUk7QUFBQSxJQUNULFFBQVE7QUFDTkYsdUJBQWlCLDhDQUE4QztBQUFBLElBQ2pFLFVBQUM7QUFDQ0kseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFHQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxrQ0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwyTEFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU12QyxTQUFTLEdBQUc7QUFBQSxVQUMzQixXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFNBQUksS0FBS2xDLFdBQVcsS0FBSSxRQUFPLFdBQVUsMEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFFaEUsdUJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLG1GQUFrRiw0QkFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEc7QUFBQSxjQUM5Ryx1QkFBQyxVQUFLLFdBQVUsK0RBQThELE9BQU8yQyxZQUFZMEosYUFDOUYxSixzQkFBWTBKLGFBQWEvRyxZQUFZLEdBQUdnSCxTQUFTLFFBQVEsSUFDdEQzSixZQUFZMEosY0FDWixHQUFHMUosWUFBWTBKLFdBQVcsYUFIaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQTtBQUFBO0FBQUEsUUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFjQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLGNBQVc7QUFBQSxZQUNYLFNBQVMsTUFBTTtBQUNiLGtCQUFJM0YsT0FBTzZGLFFBQVFqRyxTQUFTLEdBQUc7QUFDN0JwRSx5QkFBUyxFQUFFO0FBQ1g7QUFBQSxjQUNGO0FBQ0FBLHVCQUFTLFlBQVk7QUFBQSxZQUN2QjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBRVYsaUNBQUMsYUFBVSxXQUFVLHFCQUFvQixhQUFhLE9BQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUE7QUFBQSxVQVo1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEtBQUtpQjtBQUFBQSxZQUNMLFdBQVU7QUFBQSxZQUVWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsNkJBQTZCOEQ7QUFBQUEsZ0JBQzdCLFNBQVNJO0FBQUFBLGdCQUNULHFCQUFxQk47QUFBQUEsZ0JBQ3JCLGtCQUFrQnZEO0FBQUFBLGdCQUNsQjtBQUFBLGdCQUNBLE9BQU9FO0FBQUFBLGdCQUNQLFlBQVk7QUFBQTtBQUFBLGNBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT21CO0FBQUE7QUFBQSxVQVhyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhQTtBQUFBLFdBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxzQ0FFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3SUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4QkFBNkIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNwRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLGlEQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSCxLQURwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsMkNBQTJDeUcscUJBQVc5RyxJQUFJLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUEsZUFKOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLDhCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBLFVBQzFDLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLGdCQUFhLFdBQVUscUNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsVUFBSyxXQUFVLGdEQUErQyxPQUFPb0gsVUFDbkVBLHNCQUFZLFVBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNEhBRWI7QUFBQSxpQ0FBQyxXQUFRLElBQUcsYUFBWSxXQUFVLGtCQUNoQyxpQ0FBQyxZQUFPLGNBQVcsaUJBQWdCLFdBQVUseU5BQzdDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLHlFQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSSxLQUQ1STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQzFILFlBQVksS0FDWCx1QkFBQyxVQUFLLFdBQVUsdUZBQ2QsaUNBQUMsVUFBSyxXQUFVLFdBQ2ZBLHNCQUFZLElBQUksT0FBT0EsYUFEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUVGLHVCQUFDLFVBQUssV0FBVSx1UUFBc1Esd0JBQXRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWJBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUFpQixLQUFLRSxpQkFDbkM7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGNBQVc7QUFBQSxnQkFDWCxTQUFTLE1BQU1iLHFCQUFxQixDQUFDRCxpQkFBaUI7QUFBQSxnQkFDdEQsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsc0JBQW1CLFdBQVUsYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUM7QUFBQSxrQkFDdEMrRyxvQkFBb0IsS0FDbkIsdUJBQUMsVUFBSyxXQUFVLHVGQUNkLGlDQUFDLFVBQUssV0FBVSxXQUFXQTtBQUFBQTtBQUFBQSxvQkFBa0I7QUFBQSx1QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkQsS0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVGLHVCQUFDLFVBQUssV0FBVSx1UUFBc1EsNkJBQXRSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLFlBQ0QvRyxxQkFDQyx1QkFBQyxTQUFJLFdBQVUscU1BQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsdURBQXNELCtCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRjtBQUFBLGdCQUNuRix1QkFBQyxVQUFLLFdBQVUscUZBQ2IrRywrQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNaO0FBQUEsZ0JBQ0M7QUFBQSxrQkFDRXRILE9BQU87QUFBQSxrQkFDUDRLLE1BQU07QUFBQSxrQkFDTkMsT0FBTztBQUFBLGtCQUNQQyxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWE7QUFBQSxnQkFDckI7QUFBQSxnQkFDQTtBQUFBLGtCQUNFOUssT0FBTztBQUFBLGtCQUNQNEssTUFBTTtBQUFBLGtCQUNOQyxPQUFPO0FBQUEsa0JBQ1BFLE9BQU85RCxnQkFBZ0IsQ0FBQztBQUFBLGtCQUN4QjZELE1BQU0sdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFRO0FBQUEsZ0JBQ2hCO0FBQUEsZ0JBQ0E7QUFBQSxrQkFDRTlLLE9BQU87QUFBQSxrQkFDUDRLLE1BQU07QUFBQSxrQkFDTkMsT0FBTztBQUFBLGtCQUNQRSxPQUFPOUQsZ0JBQWdCLENBQUM7QUFBQSxrQkFDeEI2RCxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWE7QUFBQSxnQkFDckI7QUFBQSxnQkFDQTtBQUFBLGtCQUNFOUssT0FBTztBQUFBLGtCQUNQNEssTUFBTTtBQUFBLGtCQUNOQyxPQUFPO0FBQUEsa0JBQ1BFLE9BQU85RCxnQkFBZ0IsQ0FBQztBQUFBLGtCQUN4QjZELE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZTtBQUFBLGdCQUN2QjtBQUFBLGNBQUMsRUFDRDFHO0FBQUFBLGdCQUFJLENBQUNQLE1BQU1tSCxVQUNYO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLElBQUluSCxLQUFLK0c7QUFBQUEsb0JBQ1QsU0FBUyxNQUFNcEsscUJBQXFCLEtBQUs7QUFBQSxvQkFDekMsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsU0FBSSxXQUFXLHdHQUF3R3FELEtBQUtnSCxLQUFLLElBQy9IaEgsZUFBS2lILFFBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLCtDQUFDLE9BQUUsV0FBVSxxREFBcURqSCxlQUFLN0QsU0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkU7QUFBQSx3QkFDN0UsdUJBQUMsT0FBRSxXQUFVLHFDQUNWNkQsZUFBS2tILFFBQVEsSUFBSSxHQUFHbEgsS0FBS2tILEtBQUsscUJBQXFCLHNCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsMkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSw0RkFBMkYsa0JBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdIO0FBQUE7QUFBQTtBQUFBLGtCQWQzR0M7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFnQkE7QUFBQSxjQUNELEtBL0NIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0RBO0FBQUEsaUJBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0RBO0FBQUEsZUF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyRUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxrQkFBaUIsS0FBSzFKLFlBQ25DO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxjQUFXO0FBQUEsZ0JBQ1gsU0FBUyxNQUFNWixtQkFBbUIsQ0FBQ0QsZUFBZTtBQUFBLGdCQUNsRCxXQUFVO0FBQUEsZ0JBRVo7QUFBQSx5Q0FBQyxhQUFVLFdBQVUsd0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlDO0FBQUEsa0JBQ3hDLENBQUNBLG1CQUNBLHVCQUFDLFVBQUssV0FBVSx1UUFBc1EsdUJBQXRSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLFlBRURBLG1CQUNDLHVCQUFDLFNBQUksV0FBVSwwTUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxvRkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSx1R0FDYixpQ0FBQyxTQUFJLFdBQVUsK0ZBQ2IsaUNBQUMsYUFBVSxXQUFVLGdDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSx3SEFDZCxpQ0FBQyxVQUFLLFdBQVUsdUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1ELEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLG1EQUFtREUsdUJBQWEsZ0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsb0JBQzNGLHVCQUFDLE9BQUUsV0FBVSxvREFBb0RFLHVCQUFhLG1CQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4RjtBQUFBLG9CQUM3RkUsWUFBWTBKLGVBQ1gsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsNkNBQUMsV0FBUSxXQUFVLGdDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUErQztBQUFBLHNCQUMvQyx1QkFBQyxVQUFLLFdBQVUsbURBQ2IxSixxQkFBVzBKLFlBQVkvRyxZQUFZLEVBQUVnSCxTQUFTLFFBQVEsSUFDbkQzSixXQUFXMEosY0FDWCxHQUFHMUosV0FBVzBKLFdBQVcsYUFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSx1QkFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeUJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLCtHQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLDBDQUF5Qyw4QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUU7QUFBQSxrQkFDdkUsdUJBQUMsVUFBSyxXQUFVLHNFQUNkO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRDtBQUFBLG9CQUFHO0FBQUEsdUJBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsbUJBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0NBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU07QUFDYi9KLHlDQUFtQixLQUFLO0FBQ3hCdUIsa0RBQTRCLElBQUk7QUFBQSxvQkFDbEM7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsb0hBQ2IsaUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwrQ0FBQyxPQUFFLFdBQVUsNENBQTJDLDJDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRjtBQUFBLHdCQUNuRix1QkFBQyxPQUFFLFdBQVUscUNBQW9DLGdEQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpRjtBQUFBLDJCQUZuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDRGQUEyRixrQkFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0g7QUFBQTtBQUFBO0FBQUEsa0JBZmxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFnQkE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNdkIsbUJBQW1CLEtBQUs7QUFBQSxvQkFDdkMsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsU0FBSSxXQUFVLDBIQUNiLGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsK0NBQUMsT0FBRSxXQUFVLHdDQUF1Qyw4QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBa0U7QUFBQSx3QkFDbEUsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQyw4Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0U7QUFBQSwyQkFGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSw0RkFBMkYsa0JBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdIO0FBQUE7QUFBQTtBQUFBLGtCQVpsSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYUE7QUFBQSxtQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQ0EsS0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQ0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBU2dGO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLG9CQUNoQyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHNCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4QztBQUFBO0FBQUE7QUFBQSxnQkFOaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBbEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUZBO0FBQUEsZUFsR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvR0E7QUFBQSxhQXZNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd01BO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsY0FBWXZGLG9CQUFvQixzQkFBc0I7QUFBQSxjQUN0RCxTQUFTLE1BQU1DLHFCQUFxQixDQUFDRCxpQkFBaUI7QUFBQSxjQUN0RCxXQUFVO0FBQUEsY0FFVEEsOEJBQW9CLHVCQUFDLE9BQUksTUFBTSxNQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWMsSUFBTSx1QkFBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQjtBQUFBO0FBQUEsWUFMNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxxUEFDYkEsOEJBQW9CLGVBQWUsZUFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0F4T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlPQTtBQUFBLFNBelJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwUkE7QUFBQSxJQUlDeUIsb0JBQ0MsbUNBQ0U7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsY0FBVztBQUFBLFVBQ1gsV0FBVTtBQUFBLFVBQ1YsU0FBU2dEO0FBQUFBO0FBQUFBLFFBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSTZCO0FBQUEsTUFFN0I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUlEO0FBQUFBLFVBQ0osS0FBS25EO0FBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBRVYsaUNBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsc0NBQXFDLDZCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRDtBQUFBLGdCQUMvRCx1QkFBQyxRQUFHLFdBQVUsc0VBQ1hnQyxrQ0FBd0IscUJBQXFCLHFCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0NBLHlCQUNDLHVCQUFDLE9BQUUsV0FBVSwrREFDVkc7QUFBQUEscUNBQXFCZTtBQUFBQSxnQkFBTztBQUFBLG1CQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBRUNmLHFCQUFxQmUsV0FBVyxJQUMvQix1QkFBQyxTQUFJLFdBQVUsd0lBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsd0NBQXVDLHFDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RTtBQUFBLGNBQ3pFLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsOERBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlGO0FBQUEsaUJBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa01BQ1pQLDhCQUFvQkM7QUFBQUEsY0FBSSxDQUFDQyxVQUN4Qix1QkFBQyxhQUEwQixXQUFVLFdBQ25DO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDJDQUEyQ0EsZ0JBQU1yRSxTQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRTtBQUFBLGdCQUNwRSx1QkFBQyxTQUFJLFdBQVUsYUFDWnFFLGdCQUFNQyxNQUFNRixJQUFJLENBQUNQLFNBQVM7QUFDekIsd0JBQU1vSCxPQUFPcEgsS0FBS2lIO0FBQ2xCLHdCQUFNSSxjQUFjdk0seUJBQXlCa0YsS0FBS3NILE1BQU0sS0FBSztBQUU3RCx5QkFDRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFQyxJQUFJdEgsS0FBS0U7QUFBQUEsc0JBQ1QsY0FBWSxRQUFRRixLQUFLQyxLQUFLO0FBQUEsc0JBQzlCLFNBQVNjO0FBQUFBLHNCQUNULFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFVBQUssV0FBVyx1REFBdURzRyxXQUFXLElBQ2pGLGlDQUFDLFFBQUssV0FBVSxlQUFjLGFBQWEsT0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBLHVCQUFDLFVBQUssV0FBVSxvSEFDYnJILGVBQUtDLFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBO0FBQUE7QUFBQSxvQkFYS0QsS0FBS1U7QUFBQUEsb0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFhQTtBQUFBLGdCQUVKLENBQUMsS0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzQkE7QUFBQSxtQkF4QllGLE1BQU1yRSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlCQTtBQUFBLFlBQ0QsS0E1Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkE7QUFBQSxlQWxESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9EQTtBQUFBO0FBQUEsUUF6REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BMERBO0FBQUEsU0FqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtFQTtBQUFBLElBR0RvRCxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9HQUNiLGlDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDakUsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSxpREFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrSCxLQURwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSwrQ0FBOEMsZ0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUM1RSx1QkFBQyxPQUFFLFdBQVUsdUJBQXNCO0FBQUE7QUFBQSxRQUVqQyx1QkFBQyxVQUFLLFdBQVUseUNBQXlDRSx1QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQU87QUFBQSxXQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLFlBQU8sU0FBU29DLGNBQWMsV0FBVSxrR0FBaUcsMEJBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU1yQyxvQkFBb0IsS0FBSyxHQUFHLFdBQVUsd0ZBQXVGLGdDQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBSURyQiw0QkFDQyx1QkFBQyxTQUFJLFdBQVUsNEZBQ2IsaUNBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHNFQUNaO0FBQUEsK0JBQUMsVUFBTyxXQUFVLHNCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFBRztBQUFBLFdBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUE4Qiw4REFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RjtBQUFBLE1BRXpGLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLG1EQUFrRCxnQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNYyxzQkFBc0IsU0FBUztBQUFBLGNBQ3JDLGFBQVk7QUFBQSxjQUNaLE9BQU9aO0FBQUFBLGNBQ1AsVUFBVSxDQUFDb0QsTUFBTW5ELG1CQUFtQm1ELEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxjQUNsRCxXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtrSjtBQUFBLFVBR2xKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU16Qyx1QkFBdUIsQ0FBQ0QsbUJBQW1CO0FBQUEsY0FDMUQsV0FBVTtBQUFBLGNBRVRBLGdDQUFzQix1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFXLElBQU0sdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFNO0FBQUE7QUFBQSxZQUxoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFdBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLG1EQUFrRCw0QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNRSxrQkFBa0IsU0FBUztBQUFBLGNBQ2pDLGFBQVk7QUFBQSxjQUNaLE9BQU9aO0FBQUFBLGNBQ1AsVUFBVSxDQUFDa0QsTUFBTWpELGVBQWVpRCxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsY0FDOUMsV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLa0o7QUFBQSxVQUdsSjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNdkMsbUJBQW1CLENBQUNELGVBQWU7QUFBQSxjQUNsRCxXQUFVO0FBQUEsY0FFVEEsNEJBQWtCLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVcsSUFBTSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU07QUFBQTtBQUFBLFlBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsbURBQWtELG9DQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1FLHNCQUFzQixTQUFTO0FBQUEsY0FDckMsYUFBWTtBQUFBLGNBQ1osT0FBT1o7QUFBQUEsY0FDUCxVQUFVLENBQUNnRCxNQUFNL0MsbUJBQW1CK0MsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGNBQ2xELFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS2tKO0FBQUEsVUFHbEo7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXJDLHVCQUF1QixDQUFDRCxtQkFBbUI7QUFBQSxjQUMxRCxXQUFVO0FBQUEsY0FFVEEsZ0NBQXNCLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVcsSUFBTSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU07QUFBQTtBQUFBLFlBTGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BRUNWLGlCQUNDLHVCQUFDLFNBQUksV0FBVSw0RUFBNEVBLDJCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlHO0FBQUEsTUFFMUdFLG1CQUNDLHVCQUFDLFNBQUksV0FBVSxzRkFBc0ZBLDZCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFIO0FBQUEsTUFHdkgsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQ2JULDBDQUE0QixLQUFLO0FBQ2pDRSxpQ0FBbUIsRUFBRTtBQUNyQkUsNkJBQWUsRUFBRTtBQUNqQkUsaUNBQW1CLEVBQUU7QUFDckJFLCtCQUFpQixFQUFFO0FBQ25CRSxpQ0FBbUIsRUFBRTtBQUFBLFlBQ3ZCO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFBMkY7QUFBQTtBQUFBLFVBVHZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU3lIO0FBQUFBLFlBQ1QsVUFBVXhIO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBLDRCQUFrQixnQkFBZ0I7QUFBQTtBQUFBLFVBTHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBM0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0R0EsS0E3R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThHQTtBQUFBLE9BaGZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrZkE7QUFFSjtBQUFFdkMsR0F2MkJJSCxRQUFNO0FBQUEsVUFJTzVDLFdBQVc7QUFBQTtBQUFBOE4sS0FKeEJsTDtBQXkyQk4sZUFBZUE7QUFBTyxJQUFBa0w7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiTmF2TGluayIsInVzZU5hdmlnYXRlIiwiR2xvYmFsU2VhcmNoQmFyIiwiQXJyb3dMZWZ0IiwiQ2dQcm9maWxlIiwiSW9Jb3NOb3RpZmljYXRpb25zIiwiSW9Jb3NMb2dPdXQiLCJIaVgiLCJCaU1lbnUiLCJGaVVzZXJzIiwiRmlTbWFydHBob25lIiwiRmlDcmVkaXRDYXJkIiwiRmlDbG9jayIsIkdpUmVjZWl2ZU1vbmV5IiwicXVpY2tBY3Rpb25zIiwiQ2l0eUNoaXRzIiwiQVBJIiwiRmFFeWUiLCJGYUV5ZVNsYXNoIiwiRmFMb2NrIiwiRmFTdG9yZSIsIkZhVXNlckNpcmNsZSIsInF1aWNrQWN0aW9uQWNjZW50Q2xhc3NlcyIsImFtYmVyIiwiYmx1ZSIsImN5YW4iLCJlbWVyYWxkIiwiZ3JlZW4iLCJpbmRpZ28iLCJsaW1lIiwib3JhbmdlIiwicGluayIsInB1cnBsZSIsInJlZCIsInJvc2UiLCJza3kiLCJzbGF0ZSIsInN0b25lIiwidGVhbCIsInZpb2xldCIsInllbGxvdyIsInppbmMiLCJxdWlja0FjdGlvbk1lZ2FHcm91cHMiLCJ0aXRsZSIsImlkcyIsIk5hdmJhciIsInNob3dNb2JpbGVTaWRlYmFyIiwic2V0U2hvd01vYmlsZVNpZGViYXIiLCJfcyIsIm5hdmlnYXRlIiwic2hvd05vdGlmaWNhdGlvbnMiLCJzZXRTaG93Tm90aWZpY2F0aW9ucyIsInNob3dQcm9maWxlQ2FyZCIsInNldFNob3dQcm9maWxlQ2FyZCIsImFkbWluTmFtZSIsInNldEFkbWluTmFtZSIsInJvbGVUaXRsZSIsInNldFJvbGVUaXRsZSIsImJyYW5jaE5hbWUiLCJzZXRCcmFuY2hOYW1lIiwicGVuZGluZ0FwcHJvdmFscyIsInNldFBlbmRpbmdBcHByb3ZhbHMiLCJ0YXNrQ291bnQiLCJzZXRUYXNrQ291bnQiLCJub3RpZmljYXRpb25SZWYiLCJwcm9maWxlUmVmIiwic2VhcmNoQmFyUmVmIiwicXVpY2tBY3Rpb25SZWYiLCJ0aW1lIiwic2V0VGltZSIsIkRhdGUiLCJzaG93UXVpY2tBY3Rpb25zIiwic2V0U2hvd1F1aWNrQWN0aW9ucyIsInF1aWNrQWN0aW9uU2VhcmNoIiwic2V0UXVpY2tBY3Rpb25TZWFyY2giLCJzaG93UGF5bWVudFBhc3N3b3JkTW9kYWwiLCJzZXRTaG93UGF5bWVudFBhc3N3b3JkTW9kYWwiLCJjdXJyZW50UGFzc3dvcmQiLCJzZXRDdXJyZW50UGFzc3dvcmQiLCJuZXdQYXNzd29yZCIsInNldE5ld1Bhc3N3b3JkIiwiY29uZmlybVBhc3N3b3JkIiwic2V0Q29uZmlybVBhc3N3b3JkIiwicGFzc3dvcmRFcnJvciIsInNldFBhc3N3b3JkRXJyb3IiLCJwYXNzd29yZFN1Y2Nlc3MiLCJzZXRQYXNzd29yZFN1Y2Nlc3MiLCJwYXNzd29yZExvYWRpbmciLCJzZXRQYXNzd29yZExvYWRpbmciLCJzaG93Q3VycmVudFBhc3N3b3JkIiwic2V0U2hvd0N1cnJlbnRQYXNzd29yZCIsInNob3dOZXdQYXNzd29yZCIsInNldFNob3dOZXdQYXNzd29yZCIsInNob3dDb25maXJtUGFzc3dvcmQiLCJzZXRTaG93Q29uZmlybVBhc3N3b3JkIiwic2hvd1dhcm5pbmdNb2RhbCIsInNldFNob3dXYXJuaW5nTW9kYWwiLCJjb3VudGRvd24iLCJzZXRDb3VudGRvd24iLCJxdWlja0FjdGlvblNlYXJjaFRlcm0iLCJ0cmltIiwidG9Mb3dlckNhc2UiLCJmaWx0ZXJlZFF1aWNrQWN0aW9ucyIsImZpbHRlciIsIml0ZW0iLCJsYWJlbCIsInJvdXRlIiwia2V5d29yZHMiLCJqb2luIiwiaW5jbHVkZXMiLCJncm91cGVkUXVpY2tBY3Rpb25zIiwibWFwIiwiZ3JvdXAiLCJpdGVtcyIsImlkIiwiZmluZCIsIkJvb2xlYW4iLCJsZW5ndGgiLCJxdWlja0FjdGlvbnNQYW5lbElkIiwiY2xvc2VRdWlja0FjdGlvbnMiLCJmb2N1c1NlYXJjaElucHV0Iiwid2luZG93Iiwic2V0VGltZW91dCIsImN1cnJlbnQiLCJxdWVyeVNlbGVjdG9yIiwiZm9jdXMiLCJ0b2dnbGVRdWlja0FjdGlvbnMiLCJuZXh0U3RhdGUiLCJoYW5kbGVTZWFyY2hDaGFuZ2UiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJoYW5kbGVTZWFyY2hGb2N1cyIsImhhbmRsZUxvZ291dCIsImxvY2FsU3RvcmFnZSIsInJlbW92ZUl0ZW0iLCJmZXRjaFVzZXJEYXRhIiwidXNyIiwiZ2V0SXRlbSIsImFkbWluIiwiSlNPTiIsInBhcnNlIiwiYWRtaW5fbmFtZSIsIm5hbWUiLCJzdG9yZWRCcmFuY2giLCJicmFuY2hEYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiX2lkIiwicmVzcG9uc2UiLCJnZXQiLCJmdWxsVXNlckRhdGEiLCJkYXRhIiwiYXBpRXJyb3IiLCJmZXRjaFBlbmRpbmdBcHByb3ZhbHMiLCJnZXRQZW5kaW5nQ291bnQiLCJjYXRlZ29yeUlkIiwidW5hcHByb3ZlZF91c2VycyIsInVuYXBwcm92ZWRfZW5yb2xsbWVudHMiLCJ1bmFwcHJvdmVkX2xvYW5zIiwibm90aWZpY2F0aW9uQ291bnQiLCJmZXRjaE15VGFza0NvdW50IiwidXNlclN0ciIsInVzZXIiLCJteUlkIiwicmVzIiwiY29tcGxhaW50cyIsIm15UGVuZGluZ1RpY2tldHMiLCJhc3NpZ25lZFRvIiwiYXNzaWduZWRJZCIsImlzQXNzaWduZWRUb01lIiwiU3RyaW5nIiwiaXNQZW5kaW5nIiwic3RhdHVzIiwidGltZXIiLCJzZXRJbnRlcnZhbCIsImNsZWFySW50ZXJ2YWwiLCJmb3JtYXRUaW1lIiwiZGF0ZSIsInRvTG9jYWxlVGltZVN0cmluZyIsImhvdXIiLCJtaW51dGUiLCJ1c2VyRGF0YSIsInVzZXJuYW1lIiwiaGFuZGxlQ2xpY2tPdXRzaWRlIiwiZXZlbnQiLCJjb250YWlucyIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJoYW5kbGVFc2NhcGUiLCJrZXkiLCJBVVRPX0xPR09VVF9USU1FIiwiV0FSTklOR19USU1FIiwiV0FSTklOR19TVEFSVF9USU1FIiwiaW5hY3Rpdml0eVRpbWVyIiwiY291bnRkb3duSW50ZXJ2YWwiLCJwZXJmb3JtTG9nb3V0IiwiY2xlYXJUaW1lb3V0Iiwic3RhcnRDb3VudGRvd24iLCJNYXRoIiwiZmxvb3IiLCJwcmV2IiwicmVzZXRUaW1lcnMiLCJldmVudHMiLCJmb3JFYWNoIiwiaGFuZGxlUGF5bWVudFBhc3N3b3JkU3VibWl0Iiwic3RvcmVkUGFzc3dvcmQiLCJwYXNzd29yZCIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJicmFuY2hfbmFtZSIsImVuZHNXaXRoIiwiaGlzdG9yeSIsImhyZWYiLCJjb2xvciIsImljb24iLCJjb3VudCIsImluZGV4IiwiSWNvbiIsImFjY2VudENsYXNzIiwiYWNjZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTmF2YmFyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBOYXZMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBHbG9iYWxTZWFyY2hCYXIgZnJvbSBcIi4uL3NlYXJjaC9HbG9iYWxTZWFyY2hCYXJcIjtcclxuaW1wb3J0IHsgQXJyb3dMZWZ0IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuaW1wb3J0IHsgQ2dQcm9maWxlIH0gZnJvbSBcInJlYWN0LWljb25zL2NnXCI7XHJcbmltcG9ydCB7IElvSW9zTm90aWZpY2F0aW9ucywgSW9Jb3NMb2dPdXQgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgSGlYIH0gZnJvbSBcInJlYWN0LWljb25zL2hpXCI7XHJcbmltcG9ydCB7IEJpTWVudSB9IGZyb20gXCJyZWFjdC1pY29ucy9iaVwiO1xyXG5cclxuaW1wb3J0IHtcclxuICBGaVVzZXJzLFxyXG4gIEZpU21hcnRwaG9uZSxcclxuICBGaUNyZWRpdENhcmQsXHJcbiAgRmlDbG9jayxcclxufSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuXHJcbmltcG9ydCB7IEdpUmVjZWl2ZU1vbmV5IH0gZnJvbSBcInJlYWN0LWljb25zL2dpXCI7XHJcblxyXG5pbXBvcnQgcXVpY2tBY3Rpb25zIGZyb20gXCIuLi8uLi9kYXRhL3F1aWNrQWN0aW9uc1wiO1xyXG5pbXBvcnQgQ2l0eUNoaXRzIGZyb20gXCIuLi8uLi9hc3NldHMvaW1hZ2VzL215Y2hpdHMucG5nXCI7XHJcbmltcG9ydCBBUEkgZnJvbSBcIi4uLy4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuXHJcbmltcG9ydCB7IEZhRXllLCBGYUV5ZVNsYXNoLCBGYUxvY2ssIEZhU3RvcmUsIEZhVXNlckNpcmNsZSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5cclxuY29uc3QgcXVpY2tBY3Rpb25BY2NlbnRDbGFzc2VzID0ge1xyXG4gIGFtYmVyOiBcImJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwXCIsXHJcbiAgYmx1ZTogXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDBcIixcclxuICBjeWFuOiBcImJnLWN5YW4tNTAgdGV4dC1jeWFuLTcwMFwiLFxyXG4gIGVtZXJhbGQ6IFwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwXCIsXHJcbiAgZ3JlZW46IFwiYmctZ3JlZW4tNTAgdGV4dC1ncmVlbi03MDBcIixcclxuICBpbmRpZ286IFwiYmctaW5kaWdvLTUwIHRleHQtaW5kaWdvLTcwMFwiLFxyXG4gIGxpbWU6IFwiYmctbGltZS01MCB0ZXh0LWxpbWUtNzAwXCIsXHJcbiAgb3JhbmdlOiBcImJnLW9yYW5nZS01MCB0ZXh0LW9yYW5nZS03MDBcIixcclxuICBwaW5rOiBcImJnLXBpbmstNTAgdGV4dC1waW5rLTcwMFwiLFxyXG4gIHB1cnBsZTogXCJiZy1wdXJwbGUtNTAgdGV4dC1wdXJwbGUtNzAwXCIsXHJcbiAgcmVkOiBcImJnLXJlZC01MCB0ZXh0LXJlZC03MDBcIixcclxuICByb3NlOiBcImJnLXJvc2UtNTAgdGV4dC1yb3NlLTcwMFwiLFxyXG4gIHNreTogXCJiZy1za3ktNTAgdGV4dC1za3ktNzAwXCIsXHJcbiAgc2xhdGU6IFwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwXCIsXHJcbiAgc3RvbmU6IFwiYmctc3RvbmUtMTAwIHRleHQtc3RvbmUtNzAwXCIsXHJcbiAgdGVhbDogXCJiZy10ZWFsLTUwIHRleHQtdGVhbC03MDBcIixcclxuICB2aW9sZXQ6IFwiYmctdmlvbGV0LTUwIHRleHQtdmlvbGV0LTcwMFwiLFxyXG4gIHllbGxvdzogXCJiZy15ZWxsb3ctNTAgdGV4dC15ZWxsb3ctNzAwXCIsXHJcbiAgemluYzogXCJiZy16aW5jLTEwMCB0ZXh0LXppbmMtNzAwXCIsXHJcbn07XHJcblxyXG5jb25zdCBxdWlja0FjdGlvbk1lZ2FHcm91cHMgPSBbXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiTWFpbiBBY3Rpb25zXCIsXHJcbiAgICBpZHM6IFtcInVudmVyaWZpZWRcIiwgXCJtb2JpbGVcIiwgXCJsb2Fuc1wiLCBcInBheW1lbnQtaW5cIiwgXCJwYXltZW50LW91dFwiLCBcInJlY2VpcHRcIl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICB0aXRsZTogXCJPcGVyYXRpb25zXCIsXHJcbiAgICBpZHM6IFtcInBpZ215XCIsIFwiYWdlbnRcIiwgXCJ2aXNpdG9yXCIsIFwicGVuYWx0eS13aGF0c2FwcFwiLCBcImxpbmstdW5saW5rXCJdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiQnVzaW5lc3NcIixcclxuICAgIGlkczogW1wibWFya2V0aW5nXCIsIFwiaGVscC1zdXBwb3J0XCIsIFwiYWNjb3VudHNcIiwgXCJhcHByb3ZhbHNcIiwgXCJyZXBvcnRzXCJdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiVG9vbHNcIixcclxuICAgIGlkczogW1wicXVpY2stc2VhcmNoXCIsIFwiaHJcIiwgXCJvdXRzdGFuZGluZ1wiLCBcImxpbmstZ3VhcmFudG9yXCJdLFxyXG4gIH0sXHJcbl07XHJcblxyXG5jb25zdCBOYXZiYXIgPSAoe1xyXG4gIHNob3dNb2JpbGVTaWRlYmFyID0gZmFsc2UsXHJcbiAgc2V0U2hvd01vYmlsZVNpZGViYXIgPSAoKSA9PiB7IH0sXHJcbn0pID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IFtzaG93Tm90aWZpY2F0aW9ucywgc2V0U2hvd05vdGlmaWNhdGlvbnNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93UHJvZmlsZUNhcmQsIHNldFNob3dQcm9maWxlQ2FyZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcm9sZVRpdGxlLCBzZXRSb2xlVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2JyYW5jaE5hbWUsIHNldEJyYW5jaE5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFtwZW5kaW5nQXBwcm92YWxzLCBzZXRQZW5kaW5nQXBwcm92YWxzXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW3Rhc2tDb3VudCwgc2V0VGFza0NvdW50XSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBjb25zdCBub3RpZmljYXRpb25SZWYgPSB1c2VSZWYobnVsbCk7XHJcbiAgY29uc3QgcHJvZmlsZVJlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBzZWFyY2hCYXJSZWYgPSB1c2VSZWYobnVsbCk7XHJcbiAgY29uc3QgcXVpY2tBY3Rpb25SZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIGNvbnN0IFt0aW1lLCBzZXRUaW1lXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkpO1xyXG5cclxuICBjb25zdCBbc2hvd1F1aWNrQWN0aW9ucywgc2V0U2hvd1F1aWNrQWN0aW9uc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3F1aWNrQWN0aW9uU2VhcmNoLCBzZXRRdWlja0FjdGlvblNlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgW3Nob3dQYXltZW50UGFzc3dvcmRNb2RhbCwgc2V0U2hvd1BheW1lbnRQYXNzd29yZE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFBhc3N3b3JkLCBzZXRDdXJyZW50UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW25ld1Bhc3N3b3JkLCBzZXROZXdQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY29uZmlybVBhc3N3b3JkLCBzZXRDb25maXJtUGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Bhc3N3b3JkRXJyb3IsIHNldFBhc3N3b3JkRXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Bhc3N3b3JkU3VjY2Vzcywgc2V0UGFzc3dvcmRTdWNjZXNzXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXNzd29yZExvYWRpbmcsIHNldFBhc3N3b3JkTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dDdXJyZW50UGFzc3dvcmQsIHNldFNob3dDdXJyZW50UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TmV3UGFzc3dvcmQsIHNldFNob3dOZXdQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dDb25maXJtUGFzc3dvcmQsIHNldFNob3dDb25maXJtUGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbc2hvd1dhcm5pbmdNb2RhbCwgc2V0U2hvd1dhcm5pbmdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2NvdW50ZG93biwgc2V0Q291bnRkb3duXSA9IHVzZVN0YXRlKDEwKTtcclxuXHJcbiAgY29uc3QgcXVpY2tBY3Rpb25TZWFyY2hUZXJtID0gcXVpY2tBY3Rpb25TZWFyY2gudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkUXVpY2tBY3Rpb25zID0gcXVpY2tBY3Rpb25zLmZpbHRlcigoaXRlbSkgPT4ge1xyXG4gICAgaWYgKCFxdWlja0FjdGlvblNlYXJjaFRlcm0pIHJldHVybiB0cnVlO1xyXG5cclxuICAgIHJldHVybiBbaXRlbS5sYWJlbCwgaXRlbS5yb3V0ZSwgLi4uKGl0ZW0ua2V5d29yZHMgfHwgW10pXVxyXG4gICAgICAuam9pbihcIiBcIilcclxuICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgLmluY2x1ZGVzKHF1aWNrQWN0aW9uU2VhcmNoVGVybSk7XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGdyb3VwZWRRdWlja0FjdGlvbnMgPSBxdWlja0FjdGlvbk1lZ2FHcm91cHNcclxuICAgIC5tYXAoKGdyb3VwKSA9PiAoe1xyXG4gICAgICAuLi5ncm91cCxcclxuICAgICAgaXRlbXM6IGdyb3VwLmlkc1xyXG4gICAgICAgIC5tYXAoKGlkKSA9PiBmaWx0ZXJlZFF1aWNrQWN0aW9ucy5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBpZCkpXHJcbiAgICAgICAgLmZpbHRlcihCb29sZWFuKSxcclxuICAgIH0pKVxyXG4gICAgLmZpbHRlcigoZ3JvdXApID0+IGdyb3VwLml0ZW1zLmxlbmd0aCA+IDApO1xyXG5cclxuICBjb25zdCBxdWlja0FjdGlvbnNQYW5lbElkID0gXCJuYXZiYXItcXVpY2stYWN0aW9uc1wiO1xyXG5cclxuICBjb25zdCBjbG9zZVF1aWNrQWN0aW9ucyA9ICgpID0+IHtcclxuICAgIHNldFNob3dRdWlja0FjdGlvbnMoZmFsc2UpO1xyXG4gICAgc2V0UXVpY2tBY3Rpb25TZWFyY2goXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9jdXNTZWFyY2hJbnB1dCA9ICgpID0+IHtcclxuICAgIHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2VhcmNoQmFyUmVmLmN1cnJlbnQ/LnF1ZXJ5U2VsZWN0b3IoXCJpbnB1dFwiKT8uZm9jdXMoKTtcclxuICAgIH0sIDApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVF1aWNrQWN0aW9ucyA9ICgpID0+IHtcclxuICAgIHNldFNob3dRdWlja0FjdGlvbnMoKGN1cnJlbnQpID0+IHtcclxuICAgICAgY29uc3QgbmV4dFN0YXRlID0gIWN1cnJlbnQ7XHJcbiAgICAgIGlmIChuZXh0U3RhdGUpIGZvY3VzU2VhcmNoSW5wdXQoKTtcclxuICAgICAgcmV0dXJuIG5leHRTdGF0ZTtcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlYXJjaENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBzZXRRdWlja0FjdGlvblNlYXJjaChlLnRhcmdldC52YWx1ZSk7XHJcbiAgICBzZXRTaG93UXVpY2tBY3Rpb25zKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlYXJjaEZvY3VzID0gKCkgPT4ge1xyXG4gICAgc2V0U2hvd1F1aWNrQWN0aW9ucyh0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIHRoZSByZXN0IG9mIHRoZSBjb21wb25lbnQgKGxvZ291dCwgZmV0Y2hpbmcgZGF0YSwgZXRjLikgLS0tLS0tLS0tLVxyXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcclxuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwidG9rZW5cIik7XHJcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcImFkbWluXCIpO1xyXG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJicmFuY2hcIik7XHJcbiAgICBuYXZpZ2F0ZShcIi9cIik7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlckRhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdXNyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICAgIGlmICh1c3IpIHtcclxuICAgICAgICAgIGNvbnN0IGFkbWluID0gSlNPTi5wYXJzZSh1c3IpO1xyXG4gICAgICAgICAgc2V0QWRtaW5OYW1lKGFkbWluPy5hZG1pbl9uYW1lIHx8IGFkbWluPy5uYW1lIHx8IFwiVXNlclwiKTtcclxuICAgICAgICAgIGNvbnN0IHN0b3JlZEJyYW5jaCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYnJhbmNoXCIpO1xyXG4gICAgICAgICAgaWYgKHN0b3JlZEJyYW5jaCkge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGJyYW5jaERhdGEgPSBKU09OLnBhcnNlKHN0b3JlZEJyYW5jaCk7XHJcbiAgICAgICAgICAgICAgc2V0QnJhbmNoTmFtZShicmFuY2hEYXRhKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICBhZG1pbi5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQgJiZcclxuICAgICAgICAgICAgdHlwZW9mIGFkbWluLmFkbWluX2FjY2Vzc19yaWdodF9pZCA9PT0gXCJvYmplY3RcIlxyXG4gICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHNldFJvbGVUaXRsZShhZG1pbi5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQudGl0bGUpO1xyXG4gICAgICAgICAgfSBlbHNlIGlmIChhZG1pbi5faWQpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvYWRtaW4vbWVcIik7XHJcbiAgICAgICAgICAgICAgY29uc3QgZnVsbFVzZXJEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgICAgICAgIGlmIChmdWxsVXNlckRhdGE/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8udGl0bGUpIHtcclxuICAgICAgICAgICAgICAgIHNldFJvbGVUaXRsZShmdWxsVXNlckRhdGEuYWRtaW5fYWNjZXNzX3JpZ2h0X2lkLnRpdGxlKTtcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgc2V0Um9sZVRpdGxlKFwiQWRtaW5cIik7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChhcGlFcnJvcikge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcm9sZSBkZXRhaWxzOlwiLCBhcGlFcnJvcik7XHJcbiAgICAgICAgICAgICAgc2V0Um9sZVRpdGxlKFwiQWRtaW5cIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHNldFJvbGVUaXRsZShcIkFkbWluXCIpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRBZG1pbk5hbWUoXCJVc2VyXCIpO1xyXG4gICAgICAgICAgc2V0Um9sZVRpdGxlKFwiQWRtaW5cIik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gcGFyc2UgYWRtaW46XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBZG1pbk5hbWUoXCJVc2VyXCIpO1xyXG4gICAgICAgIHNldFJvbGVUaXRsZShcIkFkbWluXCIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoVXNlckRhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFBlbmRpbmdBcHByb3ZhbHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2FwcHJvdmFscy9jb3VudFwiKTtcclxuICAgICAgICBzZXRQZW5kaW5nQXBwcm92YWxzKHJlc3BvbnNlPy5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGVuZGluZyBhcHByb3ZhbHNcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoUGVuZGluZ0FwcHJvdmFscygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZ2V0UGVuZGluZ0NvdW50ID0gKGNhdGVnb3J5SWQpID0+IHtcclxuICAgIGlmICghcGVuZGluZ0FwcHJvdmFscz8uZGF0YSkgcmV0dXJuIDA7XHJcbiAgICBzd2l0Y2ggKGNhdGVnb3J5SWQpIHtcclxuICAgICAgY2FzZSAxOlxyXG4gICAgICAgIHJldHVybiBwZW5kaW5nQXBwcm92YWxzLmRhdGEudW5hcHByb3ZlZF91c2VycztcclxuICAgICAgY2FzZSAyOlxyXG4gICAgICAgIHJldHVybiBwZW5kaW5nQXBwcm92YWxzLmRhdGEudW5hcHByb3ZlZF9lbnJvbGxtZW50cztcclxuICAgICAgY2FzZSAzOlxyXG4gICAgICAgIHJldHVybiBwZW5kaW5nQXBwcm92YWxzLmRhdGEudW5hcHByb3ZlZF9sb2FucztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBub3RpZmljYXRpb25Db3VudCA9XHJcbiAgICBnZXRQZW5kaW5nQ291bnQoMSkgKyBnZXRQZW5kaW5nQ291bnQoMikgKyBnZXRQZW5kaW5nQ291bnQoMyk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaE15VGFza0NvdW50ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHVzZXJTdHIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImFkbWluXCIpO1xyXG4gICAgICAgIGlmICghdXNlclN0cikgcmV0dXJuO1xyXG4gICAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKHVzZXJTdHIpO1xyXG4gICAgICAgIGNvbnN0IG15SWQgPSB1c2VyLl9pZDtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KFwiL2NvbXBsYWludHMvYWxsXCIpO1xyXG4gICAgICAgIGNvbnN0IGNvbXBsYWludHMgPSByZXMuZGF0YT8uZGF0YSB8fCBbXTtcclxuICAgICAgICBjb25zdCBteVBlbmRpbmdUaWNrZXRzID0gY29tcGxhaW50cy5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGlmICghaXRlbS5hc3NpZ25lZFRvKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICBsZXQgYXNzaWduZWRJZCA9IG51bGw7XHJcbiAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0uYXNzaWduZWRUbyA9PT0gXCJvYmplY3RcIiAmJiBpdGVtLmFzc2lnbmVkVG8uX2lkKSB7XHJcbiAgICAgICAgICAgIGFzc2lnbmVkSWQgPSBpdGVtLmFzc2lnbmVkVG8uX2lkO1xyXG4gICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgaXRlbS5hc3NpZ25lZFRvID09PSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgICAgIGFzc2lnbmVkSWQgPSBpdGVtLmFzc2lnbmVkVG87XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zdCBpc0Fzc2lnbmVkVG9NZSA9IFN0cmluZyhhc3NpZ25lZElkKSA9PT0gU3RyaW5nKG15SWQpO1xyXG4gICAgICAgICAgY29uc3QgaXNQZW5kaW5nID0gaXRlbS5zdGF0dXMgIT09IFwiQ2xvc2VkXCI7XHJcbiAgICAgICAgICByZXR1cm4gaXNBc3NpZ25lZFRvTWUgJiYgaXNQZW5kaW5nO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFRhc2tDb3VudChteVBlbmRpbmdUaWNrZXRzLmxlbmd0aCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRhc2sgY291bnRcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoTXlUYXNrQ291bnQoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgc2V0VGltZShuZXcgRGF0ZSgpKTtcclxuICAgIH0sIDEwMDApO1xyXG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodGltZXIpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZm9ybWF0VGltZSA9IChkYXRlKSA9PlxyXG4gICAgZGF0ZS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHtcclxuICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXHJcbiAgICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXHJcbiAgICB9KTtcclxuXHJcbiAgY29uc3QgdXNlckRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgY29uc3QgdXNlcm5hbWUgPSB1c2VyRGF0YVxyXG4gICAgPyBKU09OLnBhcnNlKHVzZXJEYXRhKT8ubmFtZSB8fCBKU09OLnBhcnNlKHVzZXJEYXRhKT8uYWRtaW5fbmFtZVxyXG4gICAgOiBcIlwiO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaGFuZGxlQ2xpY2tPdXRzaWRlID0gKGV2ZW50KSA9PiB7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBub3RpZmljYXRpb25SZWYuY3VycmVudCAmJlxyXG4gICAgICAgICFub3RpZmljYXRpb25SZWYuY3VycmVudC5jb250YWlucyhldmVudC50YXJnZXQpXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldFNob3dOb3RpZmljYXRpb25zKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoXHJcbiAgICAgICAgcHJvZmlsZVJlZi5jdXJyZW50ICYmXHJcbiAgICAgICAgIXByb2ZpbGVSZWYuY3VycmVudC5jb250YWlucyhldmVudC50YXJnZXQpXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldFNob3dQcm9maWxlQ2FyZChmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKFxyXG4gICAgICAgIHNob3dRdWlja0FjdGlvbnMgJiZcclxuICAgICAgICBzZWFyY2hCYXJSZWYuY3VycmVudCAmJlxyXG4gICAgICAgIHF1aWNrQWN0aW9uUmVmLmN1cnJlbnQgJiZcclxuICAgICAgICAhc2VhcmNoQmFyUmVmLmN1cnJlbnQuY29udGFpbnMoZXZlbnQudGFyZ2V0KSAmJlxyXG4gICAgICAgICFxdWlja0FjdGlvblJlZi5jdXJyZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldClcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0U2hvd1F1aWNrQWN0aW9ucyhmYWxzZSk7XHJcbiAgICAgICAgc2V0UXVpY2tBY3Rpb25TZWFyY2goXCJcIik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gICAgfTtcclxuICB9LCBbc2hvd1F1aWNrQWN0aW9uc10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaGFuZGxlRXNjYXBlID0gKGV2ZW50KSA9PiB7XHJcbiAgICAgIGlmIChldmVudC5rZXkgIT09IFwiRXNjYXBlXCIpIHJldHVybjtcclxuXHJcbiAgICAgIHNldFNob3dRdWlja0FjdGlvbnMoZmFsc2UpO1xyXG4gICAgICBzZXRRdWlja0FjdGlvblNlYXJjaChcIlwiKTtcclxuICAgICAgc2V0U2hvd05vdGlmaWNhdGlvbnMoZmFsc2UpO1xyXG4gICAgICBzZXRTaG93UHJvZmlsZUNhcmQoZmFsc2UpO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVFc2NhcGUpO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlRXNjYXBlKTtcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBBdXRvLWxvZ291dCBsb2dpY1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBBVVRPX0xPR09VVF9USU1FID0gMTAgKiA2MCAqIDYwICogMTAwMDtcclxuICAgIGNvbnN0IFdBUk5JTkdfVElNRSA9IDEwICogNjAgKiAxMDAwO1xyXG4gICAgY29uc3QgV0FSTklOR19TVEFSVF9USU1FID0gQVVUT19MT0dPVVRfVElNRSAtIFdBUk5JTkdfVElNRTtcclxuXHJcbiAgICBsZXQgaW5hY3Rpdml0eVRpbWVyO1xyXG4gICAgbGV0IGNvdW50ZG93bkludGVydmFsO1xyXG5cclxuICAgIGNvbnN0IHBlcmZvcm1Mb2dvdXQgPSAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dChpbmFjdGl2aXR5VGltZXIpO1xyXG4gICAgICBjbGVhckludGVydmFsKGNvdW50ZG93bkludGVydmFsKTtcclxuICAgICAgaGFuZGxlTG9nb3V0KCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHN0YXJ0Q291bnRkb3duID0gKCkgPT4ge1xyXG4gICAgICBzZXRTaG93V2FybmluZ01vZGFsKHRydWUpO1xyXG4gICAgICBzZXRDb3VudGRvd24oTWF0aC5mbG9vcihXQVJOSU5HX1RJTUUgLyAxMDAwKSk7XHJcbiAgICAgIGNvdW50ZG93bkludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgICAgIHNldENvdW50ZG93bigocHJldikgPT4ge1xyXG4gICAgICAgICAgaWYgKHByZXYgPD0gMSkge1xyXG4gICAgICAgICAgICBwZXJmb3JtTG9nb3V0KCk7XHJcbiAgICAgICAgICAgIHJldHVybiAwO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIHByZXYgLSAxO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LCAxMDAwKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzZXRUaW1lcnMgPSAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dChpbmFjdGl2aXR5VGltZXIpO1xyXG4gICAgICBjbGVhckludGVydmFsKGNvdW50ZG93bkludGVydmFsKTtcclxuICAgICAgaW5hY3Rpdml0eVRpbWVyID0gc2V0VGltZW91dChzdGFydENvdW50ZG93biwgV0FSTklOR19TVEFSVF9USU1FKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZXZlbnRzID0gW1wibW91c2Vtb3ZlXCIsIFwia2V5ZG93blwiLCBcImNsaWNrXCIsIFwic2Nyb2xsXCJdO1xyXG4gICAgZXZlbnRzLmZvckVhY2goKGV2ZW50KSA9PiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgcmVzZXRUaW1lcnMpKTtcclxuICAgIHJlc2V0VGltZXJzKCk7XHJcblxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgY2xlYXJUaW1lb3V0KGluYWN0aXZpdHlUaW1lcik7XHJcbiAgICAgIGNsZWFySW50ZXJ2YWwoY291bnRkb3duSW50ZXJ2YWwpO1xyXG4gICAgICBldmVudHMuZm9yRWFjaCgoZXZlbnQpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCByZXNldFRpbWVycykpO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRQYXNzd29yZFN1Ym1pdCA9ICgpID0+IHtcclxuICAgIHNldFBhc3N3b3JkRXJyb3IoXCJcIik7XHJcbiAgICBzZXRQYXNzd29yZFN1Y2Nlc3MoXCJcIik7XHJcblxyXG4gICAgY29uc3QgdXNlclN0ciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGlmICghdXNlclN0cikge1xyXG4gICAgICBzZXRQYXNzd29yZEVycm9yKFwiVXNlciBub3QgZm91bmQuIFBsZWFzZSBsb2dpbiBhZ2Fpbi5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IHVzZXJEYXRhID0gSlNPTi5wYXJzZSh1c2VyU3RyKTtcclxuICAgIGNvbnN0IHN0b3JlZFBhc3N3b3JkID0gdXNlckRhdGE/LnBhc3N3b3JkIHx8IFwiXCI7XHJcblxyXG4gICAgaWYgKCFjdXJyZW50UGFzc3dvcmQudHJpbSgpKSB7XHJcbiAgICAgIHNldFBhc3N3b3JkRXJyb3IoXCJDdXJyZW50IHBhc3N3b3JkIGlzIHJlcXVpcmVkLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKGN1cnJlbnRQYXNzd29yZCAhPT0gc3RvcmVkUGFzc3dvcmQpIHtcclxuICAgICAgc2V0UGFzc3dvcmRFcnJvcihcIkN1cnJlbnQgcGFzc3dvcmQgaXMgaW5jb3JyZWN0LlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKCFuZXdQYXNzd29yZC50cmltKCkgfHwgbmV3UGFzc3dvcmQubGVuZ3RoIDwgNikge1xyXG4gICAgICBzZXRQYXNzd29yZEVycm9yKFwiTmV3IHBhc3N3b3JkIG11c3QgYmUgYXQgbGVhc3QgNiBjaGFyYWN0ZXJzLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKG5ld1Bhc3N3b3JkICE9PSBjb25maXJtUGFzc3dvcmQpIHtcclxuICAgICAgc2V0UGFzc3dvcmRFcnJvcihcIk5ldyBwYXNzd29yZCBhbmQgY29uZmlybSBwYXNzd29yZCBkbyBub3QgbWF0Y2guXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0UGFzc3dvcmRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgdXNlckRhdGEucGFzc3dvcmQgPSBuZXdQYXNzd29yZDtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ1c2VyXCIsIEpTT04uc3RyaW5naWZ5KHVzZXJEYXRhKSk7XHJcbiAgICAgIHNldFBhc3N3b3JkU3VjY2VzcyhcIlBheW1lbnQgcGFzc3dvcmQgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIpO1xyXG4gICAgICBzZXRDdXJyZW50UGFzc3dvcmQoXCJcIik7XHJcbiAgICAgIHNldE5ld1Bhc3N3b3JkKFwiXCIpO1xyXG4gICAgICBzZXRDb25maXJtUGFzc3dvcmQoXCJcIik7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldFNob3dQYXltZW50UGFzc3dvcmRNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgc2V0UGFzc3dvcmRTdWNjZXNzKFwiXCIpO1xyXG4gICAgICB9LCAyMDAwKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBzZXRQYXNzd29yZEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBwYXNzd29yZC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRQYXNzd29yZExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gSlNYIC0tLS0tLS0tLS1cclxuICByZXR1cm4gKFxyXG4gICAgPG5hdiBjbGFzc05hbWU9XCJmaXhlZCBsZWZ0LTAgdG9wLTAgei01MCB3LWZ1bGxcIj5cclxuICAgICAgey8qIE5hdmJhciBoZWFkZXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLVs2OHB4XSBtaW4tdy0wIGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwLzcwIGJnLXdoaXRlLzgwIHB4LTMgdGV4dC1zbGF0ZS05MDAgc2hhZG93LVswXzFweF8xMHB4X3JnYmEoMTUsMjMsNDIsMC4wNildIGJhY2tkcm9wLWJsdXIteGwgc206Z2FwLTMgc206cHgtNCBsZzpweC02XCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoXCIvXCIpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy1bNDRweF0gc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtMnhsIHByLTEgdGV4dC1zbGF0ZS05MDAgdHJhbnNpdGlvbiBob3ZlcjpiZy1zbGF0ZS0xMDAvNzAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8zMCBzbTptaW4tdy1bMTcwcHhdIG1kOm1pbi13LVsxOTBweF0gbGc6bWluLXctWzIyMHB4XVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGltZyBzcmM9e0NpdHlDaGl0c30gYWx0PVwiTG9nb1wiIGNsYXNzTmFtZT1cImgtOSBzaHJpbmstMCBzbTpoLTEwXCIgLz5cclxuICAgICAgICAgIHsvKiA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206YmxvY2sgZm9udC1ib2xkIHRleHQteGxcIj5NeSBDaGl0cyBOZXc8L3NwYW4+ICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbWluLXctMCBtYXgtdy1bMTcwcHhdIGZsZXgtY29sIGxlYWRpbmctdGlnaHQgc206ZmxleCBsZzptYXgtdy1bMjEwcHhdXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQtWzE2cHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05NTAgbGc6dGV4dC1bMTdweF1cIj5NeSBDaGl0cyBOZXc8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiB0cnVuY2F0ZSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIHhsOmJsb2NrXCIgdGl0bGU9e2JyYW5jaE5hbWU/LmJyYW5jaF9uYW1lfT5cclxuICAgICAgICAgICAgICB7YnJhbmNoTmFtZT8uYnJhbmNoX25hbWU/LnRvTG93ZXJDYXNlKCk/LmVuZHNXaXRoKFwiYnJhbmNoXCIpXHJcbiAgICAgICAgICAgICAgICA/IGJyYW5jaE5hbWU/LmJyYW5jaF9uYW1lXHJcbiAgICAgICAgICAgICAgICA6IGAke2JyYW5jaE5hbWU/LmJyYW5jaF9uYW1lfSBCcmFuY2hgfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi13LTAgZmxleC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHNtOm1pbi13LVsyMjBweF0gc206Z2FwLTIgbWQ6Z2FwLTNcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJHbyBiYWNrXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmICh3aW5kb3cuaGlzdG9yeS5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgtMSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIG5hdmlnYXRlKFwiL2Rhc2hib2FyZFwiKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuIGgtOSB3LTkgc2hyaW5rLTAgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS82MCB0ZXh0LXNsYXRlLTYwMCBzaGFkb3ctc20gc2hhZG93LXNsYXRlLTkwMC9bMC4wM10gYmFja2Ryb3AtYmx1ci14bCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBob3ZlcjpiZy13aGl0ZSBob3Zlcjp0ZXh0LXNsYXRlLTk1MCBhY3RpdmU6c2NhbGUtOTUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yNSBzbTpncmlkIGxnOmgtMTAgbGc6dy0xMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwiaC1bMThweF0gdy1bMThweF1cIiBzdHJva2VXaWR0aD17MS45fSAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHJlZj17c2VhcmNoQmFyUmVmfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy1mdWxsIG1pbi13LTAgbWF4LXctWzcyMHB4XSBpdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIGJnLXNsYXRlLTEwMC83NSBweC0zIHRleHQtc2xhdGUtOTAwIHNoYWRvdy1pbm5lciBzaGFkb3ctd2hpdGUvNjAgYmFja2Ryb3AtYmx1ci14bCB0cmFuc2l0aW9uIGZvY3VzLXdpdGhpbjpib3JkZXItWyMwMDcxZTNdLzYwIGZvY3VzLXdpdGhpbjpiZy13aGl0ZS85MCBmb2N1cy13aXRoaW46cmluZy0yIGZvY3VzLXdpdGhpbjpyaW5nLVsjMDA3MWUzXS8xNSBzbTpweC0zLjVcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8R2xvYmFsU2VhcmNoQmFyXHJcbiAgICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtoYW5kbGVTZWFyY2hDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgb25Gb2N1cz17aGFuZGxlU2VhcmNoRm9jdXN9XHJcbiAgICAgICAgICAgICAgb25RdWlja0FjdGlvblRvZ2dsZT17dG9nZ2xlUXVpY2tBY3Rpb25zfVxyXG4gICAgICAgICAgICAgIHF1aWNrQWN0aW9uc09wZW49e3Nob3dRdWlja0FjdGlvbnN9XHJcbiAgICAgICAgICAgICAgcXVpY2tBY3Rpb25zUGFuZWxJZD17cXVpY2tBY3Rpb25zUGFuZWxJZH1cclxuICAgICAgICAgICAgICB2YWx1ZT17cXVpY2tBY3Rpb25TZWFyY2h9XHJcbiAgICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBzaHJpbmstMCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgIHsvKiBUaW1lICYgdXNlciBpbmZvICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS81NSBweC0yLjUgcHktMS41IHRleHQtc2xhdGUtNzAwIGJhY2tkcm9wLWJsdXIteGwgMnhsOmZsZXhcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LXNsYXRlLTUwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTIgOHY0bDMgM202LTNhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCIgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj57Zm9ybWF0VGltZSh0aW1lKX08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTQgdy1weCBiZy1zbGF0ZS0zMDAvODBcIiAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgIDxGYVVzZXJDaXJjbGUgY2xhc3NOYW1lPVwiaC00IHctNCBzaHJpbmstMCB0ZXh0LXNsYXRlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF4LXctWzEwMHB4XSB0cnVuY2F0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIiB0aXRsZT17dXNlcm5hbWV9PlxyXG4gICAgICAgICAgICAgICAge3VzZXJuYW1lIHx8IFwiVXNlclwifVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNzAgYmctd2hpdGUvNTUgcC0xIGJhY2tkcm9wLWJsdXIteGwgc206bWwtMiBzbTpnYXAtMVwiPlxyXG4gICAgICAgICAgICB7LyogTXkgVGFza3MgKi99XHJcbiAgICAgICAgICAgIDxOYXZMaW5rIHRvPVwiL215LXRhc2tzXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIGFyaWEtbGFiZWw9XCJPcGVuIG15IHRhc2tzXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgdGV4dC1zbGF0ZS02MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGhvdmVyOnRleHQtc2xhdGUtOTUwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzAwNzFlM10vMjUgbGc6aC0xMCBsZzp3LTEwXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk05IDVIN2EyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJoMTBhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJoLTJcIiAvPlxyXG4gICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIHt0YXNrQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTIgdG9wLTIgZmxleCBoLTEuNSB3LTEuNSByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdIHJpbmctMiByaW5nLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cclxuICAgICAgICAgICAgICAgICAge3Rhc2tDb3VudCA+IDkgPyBcIjkrXCIgOiB0YXNrQ291bnR9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImludmlzaWJsZSBhYnNvbHV0ZSBsZWZ0LTEvMiB0b3AtMTIgLXRyYW5zbGF0ZS14LTEvMiB3aGl0ZXNwYWNlLW5vd3JhcCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgb3BhY2l0eS0wIHNoYWRvdy1sZyBzaGFkb3ctc2xhdGUtOTAwLzEwIHRyYW5zaXRpb24tYWxsIGdyb3VwLWhvdmVyOnZpc2libGUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDBcIj5cclxuICAgICAgICAgICAgICAgIE15IFRhc2tzXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L05hdkxpbms+XHJcblxyXG4gICAgICAgICAgICB7LyogTm90aWZpY2F0aW9ucyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiIHJlZj17bm90aWZpY2F0aW9uUmVmfT5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiT3BlbiBub3RpZmljYXRpb25zXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dOb3RpZmljYXRpb25zKCFzaG93Tm90aWZpY2F0aW9ucyl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGgtOSB3LTkgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCB0ZXh0LXNsYXRlLTYwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgaG92ZXI6dGV4dC1zbGF0ZS05NTAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yNSBsZzpoLTEwIGxnOnctMTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb0lvc05vdGlmaWNhdGlvbnMgY2xhc3NOYW1lPVwidGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICB7bm90aWZpY2F0aW9uQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMiB0b3AtMiBmbGV4IGgtMS41IHctMS41IHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10gcmluZy0yIHJpbmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+e25vdGlmaWNhdGlvbkNvdW50fSBub3RpZmljYXRpb25zPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW52aXNpYmxlIGFic29sdXRlIGxlZnQtMS8yIHRvcC0xMiAtdHJhbnNsYXRlLXgtMS8yIHdoaXRlc3BhY2Utbm93cmFwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBvcGFjaXR5LTAgc2hhZG93LWxnIHNoYWRvdy1zbGF0ZS05MDAvMTAgdHJhbnNpdGlvbi1hbGwgZ3JvdXAtaG92ZXI6dmlzaWJsZSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBOb3RpZmljYXRpb25zXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIHtzaG93Tm90aWZpY2F0aW9ucyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHotNTAgbXQtMyB3LTgwIG1heC13LVtjYWxjKDEwMHZ3LTI0cHgpXSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNzAgYmctd2hpdGUvODUgc2hhZG93LXhsIHNoYWRvdy1zbGF0ZS05MDAvMTAgYmFja2Ryb3AtYmx1ci0yeGwgYmFja2Ryb3Atc2F0dXJhdGUtMTUwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwLzcwIGJnLXdoaXRlLzcwIHB4LTQgcHktM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTUwXCI+UGVuZGluZyBBY3Rpb25zPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJnLXNsYXRlLTEwMC84MCBweC0yIHB5LTAuNSB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge25vdGlmaWNhdGlvbkNvdW50fVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtODAgb3ZlcmZsb3cteS1hdXRvIHAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlBheW1lbnQgTGluayBUcmFuc2FjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGhyZWY6IFwiL3BheW1lbnQtbGluay10cmFuc2FjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInRleHQtZ3JlZW4tNjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8RmlDcmVkaXRDYXJkIC8+LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVW52ZXJpZmllZCBDdXN0b21lcnNcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGhyZWY6IFwiL2FwcHJvdmFsLW1lbnUvdW4tYXBwcm92ZWQtY3VzdG9tZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInRleHQtYmx1ZS02MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBnZXRQZW5kaW5nQ291bnQoMSksXHJcbiAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8RmlVc2VycyAvPixcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIk1vYmlsZSBFbnJvbGxtZW50c1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZjogXCIvYXBwcm92YWwtbWVudS9tb2JpbGUtYXBwLWVucm9sbFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwidGV4dC1hbWJlci02MDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBnZXRQZW5kaW5nQ291bnQoMiksXHJcbiAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8RmlTbWFydHBob25lIC8+LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVW5hcHByb3ZlZCBMb2Fuc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZjogXCIvb3RoZXItc2VydmljZS1tZW51L2xvYW5cIixcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInRleHQtcmVkLTYwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY291bnQ6IGdldFBlbmRpbmdDb3VudCgzKSxcclxuICAgICAgICAgICAgICAgICAgICAgIGljb246IDxHaVJlY2VpdmVNb25leSAvPixcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgIHRvPXtpdGVtLmhyZWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Tm90aWZpY2F0aW9ucyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcHgtMyBweS0yLjUgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTIwMC83MCBob3ZlcjpiZy13aGl0ZS83NSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLVsjMDA3MWUzXS8yNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGgtOSB3LTkgc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1jdXJyZW50LzEwIGJnLXNsYXRlLTUwLzgwICR7aXRlbS5jb2xvcn1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwXCI+e2l0ZW0udGl0bGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5jb3VudCA+IDAgPyBgJHtpdGVtLmNvdW50fSBpdGVtcyB0byByZXZpZXdgIDogXCJObyBwZW5kaW5nIGl0ZW1zXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCB0cmFuc2l0aW9uIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAuNSBncm91cC1ob3Zlcjp0ZXh0LVsjMDA3MWUzXVwiPi0mZ3Q7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogUHJvZmlsZSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiIHJlZj17cHJvZmlsZVJlZn0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIk9wZW4gcHJvZmlsZSBtZW51XCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQcm9maWxlQ2FyZCghc2hvd1Byb2ZpbGVDYXJkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXdoaXRlIHRleHQtc2xhdGUtNzAwIHJpbmctMSByaW5nLXNsYXRlLTIwMC84MCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBob3ZlcjpiZy1zbGF0ZS01MCBob3Zlcjp0ZXh0LVsjMDA3MWUzXSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzI1IGxnOmgtMTAgbGc6dy0xMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxDZ1Byb2ZpbGUgY2xhc3NOYW1lPVwidGV4dC1sZyBsZzp0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgICB7IXNob3dQcm9maWxlQ2FyZCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbnZpc2libGUgYWJzb2x1dGUgbGVmdC0xLzIgdG9wLTEyIC10cmFuc2xhdGUteC0xLzIgd2hpdGVzcGFjZS1ub3dyYXAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIG9wYWNpdHktMCBzaGFkb3ctbGcgc2hhZG93LXNsYXRlLTkwMC8xMCB0cmFuc2l0aW9uLWFsbCBncm91cC1ob3Zlcjp2aXNpYmxlIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFByb2ZpbGVcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAge3Nob3dQcm9maWxlQ2FyZCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIHotNTAgbXQtMyB3LVszNDBweF0gbWF4LXctW2NhbGMoMTAwdnctMjRweCldIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS84NSBzaGFkb3cteGwgc2hhZG93LXNsYXRlLTkwMC8xMCBiYWNrZHJvcC1ibHVyLTJ4bCBiYWNrZHJvcC1zYXR1cmF0ZS0xNTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAvNzAgYmctd2hpdGUvNzAgcHgtNSBwYi01IHB0LTVcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xNCB3LTE0IHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBiZy13aGl0ZS84MCBwLTEgc2hhZG93LXNtIHNoYWRvdy1zbGF0ZS05MDAvWzAuMDRdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLXNsYXRlLTEwMC85MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDZ1Byb2ZpbGUgY2xhc3NOYW1lPVwidGV4dC1bMzRweF0gdGV4dC1zbGF0ZS03MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgcmlnaHQtMCBmbGV4IGgtNCB3LTQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItd2hpdGUgYmctZW1lcmFsZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsIGJnLXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05NTBcIj57YWRtaW5OYW1lIHx8IFwiQWRtaW4gVXNlclwifTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRydW5jYXRlIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDBcIj57cm9sZVRpdGxlIHx8IFwiQWRtaW5pc3RyYXRvclwifTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIHticmFuY2hOYW1lPy5icmFuY2hfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhU3RvcmUgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YnJhbmNoTmFtZS5icmFuY2hfbmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKFwiYnJhbmNoXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYnJhbmNoTmFtZS5icmFuY2hfbmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGAke2JyYW5jaE5hbWUuYnJhbmNoX25hbWV9IEJyYW5jaGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG10LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNzAgYmctd2hpdGUvNzAgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDBcIj5BY2NvdW50IFN0YXR1czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIEFjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93UHJvZmlsZUNhcmQoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93UGF5bWVudFBhc3N3b3JkTW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBweC0zIHB5LTIuNSB0ZXh0LWxlZnQgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTIwMC83MCBob3ZlcjpiZy13aGl0ZS83NSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLVsjMDA3MWUzXS8yNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtOSB3LTkgc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibHVlLTEwMC84MCBiZy1ibHVlLTUwIHRleHQtWyMwMDcxZTNdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGYUxvY2sgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPkNoYW5nZSBUcmFuc2FjdGlvbiBQYXNzd29yZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+Q2hhbmdlIHBheW1lbnQgYXV0aG9yaXphdGlvbiBQSU48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbiBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wLjUgZ3JvdXAtaG92ZXI6dGV4dC1bIzAwNzFlM11cIj4tJmd0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQcm9maWxlQ2FyZChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IHctZnVsbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHB4LTMgcHktMi41IHRleHQtbGVmdCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBob3Zlcjpib3JkZXItc2xhdGUtMjAwLzcwIGhvdmVyOmJnLXdoaXRlLzc1IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctWyMwMDcxZTNdLzI1XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy1zbGF0ZS0xMDAvODAgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZpQ2xvY2sgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+TG9naW4gQWN0aXZpdHk8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlJldmlldyByZWNlbnQgYWNjb3VudCBhY3Rpdml0eTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCB0cmFuc2l0aW9uIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAuNSBncm91cC1ob3Zlcjp0ZXh0LVsjMDA3MWUzXVwiPi0mZ3Q7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMC83MCBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IHctZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItcmVkLTEwMC84MCBiZy1yZWQtNTAvODAgcHktMi41IHRleHQtcmVkLTYwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBob3ZlcjpiZy1yZWQtMTAwLzgwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmVkLTUwMC8yMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9Jb3NMb2dPdXQgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkXCI+TG9nb3V0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBNb2JpbGUgbWVudSB0b2dnbGUgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtzaG93TW9iaWxlU2lkZWJhciA/IFwiQ2xvc2UgbW9iaWxlIG1lbnVcIiA6IFwiT3BlbiBtb2JpbGUgbWVudVwifVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2JpbGVTaWRlYmFyKCFzaG93TW9iaWxlU2lkZWJhcil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBoLTEwIHctMTAgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS81NSB0ZXh0LXNsYXRlLTcwMCB0cmFuc2l0aW9uIGhvdmVyOmJnLXNsYXRlLTEwMCBob3Zlcjp0ZXh0LXNsYXRlLTk1MCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzI1IG1kOmhpZGRlblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7c2hvd01vYmlsZVNpZGViYXIgPyA8SGlYIHNpemU9ezI0fSAvPiA6IDxCaU1lbnUgc2l6ZT17MjR9IC8+fVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW52aXNpYmxlIGFic29sdXRlIHJpZ2h0LTAgdG9wLTEyIHdoaXRlc3BhY2Utbm93cmFwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBvcGFjaXR5LTAgc2hhZG93LWxnIHNoYWRvdy1zbGF0ZS05MDAvMTAgdHJhbnNpdGlvbi1hbGwgZ3JvdXAtaG92ZXI6dmlzaWJsZSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMFwiPlxyXG4gICAgICAgICAgICAgIHtzaG93TW9iaWxlU2lkZWJhciA/IFwiQ2xvc2UgTWVudVwiIDogXCJPcGVuIE1lbnVcIn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIPCfk6YgUVVJQ0sgQUNUSU9OUyBEUk9QRE9XTiDigJMgc2hvd3Mgb25seSBlbmFibGVkIGFjdGlvbnMgKi99XHJcbiAgICAgIHsvKiBRdWljayBBY3Rpb25zOiBBcHBsZS1zdHlsZSBsYXVuY2hlciAqL31cclxuICAgICAge3Nob3dRdWlja0FjdGlvbnMgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2UgUXVpY2sgQWN0aW9uc1wiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LXgtMCBib3R0b20tMCB0b3AtWzY4cHhdIHotMzAgY3Vyc29yLWRlZmF1bHQgYmctc2xhdGUtOTAwLzEwIGJhY2tkcm9wLWJsdXItWzNweF1cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtjbG9zZVF1aWNrQWN0aW9uc31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGlkPXtxdWlja0FjdGlvbnNQYW5lbElkfVxyXG4gICAgICAgICAgICByZWY9e3F1aWNrQWN0aW9uUmVmfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTAgcmlnaHQtMCB0b3AtWzY4cHhdIHotNDAgaC1hdXRvIG92ZXJmbG93LXZpc2libGUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS85MCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbGcgc2hhZG93LXNsYXRlLTkwMC8xMCBiYWNrZHJvcC1ibHVyLTJ4bCBiYWNrZHJvcC1zYXR1cmF0ZS0xNTAgYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tdG9wLTJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBoLWF1dG8gdy1mdWxsIG1heC13LTV4bCBmbGV4LWNvbCBweC01IHB5LTUgc206cHgtOCBsZzpweS02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IGZsZXggc2hyaW5rLTAgaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDBcIj5RdWljayBBY3Rpb25zPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibXQtMSB0cnVuY2F0ZSB0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3F1aWNrQWN0aW9uU2VhcmNoVGVybSA/IFwiU2VhcmNoIHNob3J0Y3V0c1wiIDogXCJPcGVuIGEgc2hvcnRjdXRcIn1cclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge3F1aWNrQWN0aW9uU2VhcmNoVGVybSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhpZGRlbiBzaHJpbmstMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNDAwIHNtOmJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkUXVpY2tBY3Rpb25zLmxlbmd0aH0gbWF0Y2hlZFxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRRdWlja0FjdGlvbnMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLVsxODBweF0gZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAvNzAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+Tm8gcXVpY2sgYWN0aW9uIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5UcnkgcGF5bWVudCwgcmVwb3J0cywgY3VzdG9tZXIsIEhSLCBvciBzZWFyY2guPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtYXgtaC1bY2FsYygxMDBkdmgtOTJweCldIGdyaWQtY29scy0xIGdhcC14LTEyIGdhcC15LTYgb3ZlcmZsb3cteS1hdXRvIG92ZXJzY3JvbGwtY29udGFpbiBwci0xIHNtOmdyaWQtY29scy0yIGxnOm1heC1oLW5vbmUgbGc6Z3JpZC1jb2xzLVsxLjI1ZnJfMWZyXzFmcl8xZnJdIGxnOm92ZXJmbG93LXZpc2libGUgbGc6cHItMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBlZFF1aWNrQWN0aW9ucy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNlY3Rpb24ga2V5PXtncm91cC50aXRsZX0gY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMyB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwXCI+e2dyb3VwLnRpdGxlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5pdGVtcy5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBJY29uID0gaXRlbS5pY29uO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFjY2VudENsYXNzID0gcXVpY2tBY3Rpb25BY2NlbnRDbGFzc2VzW2l0ZW0uYWNjZW50XSB8fCBcImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMFwiO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17aXRlbS5yb3V0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YE9wZW4gJHtpdGVtLmxhYmVsfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlUXVpY2tBY3Rpb25zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IG1pbi13LTAgaXRlbXMtY2VudGVyIGdhcC0yLjUgcm91bmRlZC14bCBweC0yIHB5LTEuNSB0ZXh0LWxlZnQgdHJhbnNpdGlvbiBkdXJhdGlvbi0xNTAgaG92ZXI6Ymctc2xhdGUtMTAwLzgwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctWyMwMDcxZTNdLzMwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZ3JpZCBoLTYgdy02IHNocmluay0wIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLWxnICR7YWNjZW50Q2xhc3N9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiBzdHJva2VXaWR0aD17MS44fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xIHRydW5jYXRlIHRleHQtc20gZm9udC1zZW1pYm9sZCBsZWFkaW5nLTUgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05MDAgZ3JvdXAtaG92ZXI6dGV4dC1bIzAwNzFlM11cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7c2hvd1dhcm5pbmdNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzYwIGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTggbWF4LXctbWQgdy1mdWxsIG14LTQgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgYmctYW1iZXItMTAwIHRleHQtYW1iZXItNjAwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00IG14LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctOCBoLThcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDh2NGwzIDNtNi0zYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItMlwiPlNlc3Npb24gRXhwaXJpbmc8L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgWW91IGhhdmUgYmVlbiBpbmFjdGl2ZSBmb3IgYSB3aGlsZS4gWW91IHdpbGwgYmUgbG9nZ2VkIG91dCBpblxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWFtYmVyLTYwMCBteC0xIHRleHQteGxcIj57Y291bnRkb3dufTwvc3Bhbj5cclxuICAgICAgICAgICAgICBzZWNvbmRzLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0gY2xhc3NOYW1lPVwiZmxleC0xIHB5LTMgcHgtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRleHQtc2xhdGUtNjAwIGZvbnQtYm9sZCBob3ZlcjpiZy1zbGF0ZS01MFwiPlxyXG4gICAgICAgICAgICAgICAgTG9nb3V0IE5vd1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd1dhcm5pbmdNb2RhbChmYWxzZSl9IGNsYXNzTmFtZT1cImZsZXgtMSBweS0zIHB4LTQgcm91bmRlZC14bCBiZy1bIzAwNzFlM10gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjMDA2NmNjXVwiPlxyXG4gICAgICAgICAgICAgICAgQ29udGludWUgU2Vzc2lvblxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIFBheW1lbnQgcGFzc3dvcmQgbW9kYWwgKi99XHJcbiAgICAgIHtzaG93UGF5bWVudFBhc3N3b3JkTW9kYWwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLXNtIHAtNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIHAtOCBtYXgtdy1tZCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxGYUxvY2sgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgQ2hhbmdlIFRyYW5zYWN0aW9uIFBhc3N3b3JkXHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQteHMgbWItNlwiPkVudGVyIHlvdXIgY3VycmVudCBwYXNzd29yZCBhbmQgc2V0IGEgbmV3IG9uZS48L3A+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEN1cnJlbnQgUGFzc3dvcmRcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT17c2hvd0N1cnJlbnRQYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGN1cnJlbnQgcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1cnJlbnRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSBwci0xMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGZvY3VzOmJvcmRlci1bIzAwNzFlM10gZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzIwIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDdXJyZW50UGFzc3dvcmQoIXNob3dDdXJyZW50UGFzc3dvcmQpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LVsjMDA3MWUzXVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtzaG93Q3VycmVudFBhc3N3b3JkID8gPEZhRXllU2xhc2ggLz4gOiA8RmFFeWUgLz59XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIE5ldyBQYXNzd29yZFxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPXtzaG93TmV3UGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBuZXcgcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yLjUgcHItMTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBmb2N1czpib3JkZXItWyMwMDcxZTNdIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yMCBvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TmV3UGFzc3dvcmQoIXNob3dOZXdQYXNzd29yZCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtWyMwMDcxZTNdXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3Nob3dOZXdQYXNzd29yZCA/IDxGYUV5ZVNsYXNoIC8+IDogPEZhRXllIC8+fVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBDb25maXJtIE5ldyBQYXNzd29yZFxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPXtzaG93Q29uZmlybVBhc3N3b3JkID8gXCJ0ZXh0XCIgOiBcInBhc3N3b3JkXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUmUtZW50ZXIgbmV3IHBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpcm1QYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25maXJtUGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yLjUgcHItMTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBmb2N1czpib3JkZXItWyMwMDcxZTNdIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yMCBvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q29uZmlybVBhc3N3b3JkKCFzaG93Q29uZmlybVBhc3N3b3JkKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1bIzAwNzFlM11cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7c2hvd0NvbmZpcm1QYXNzd29yZCA/IDxGYUV5ZVNsYXNoIC8+IDogPEZhRXllIC8+fVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge3Bhc3N3b3JkRXJyb3IgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTMgYmctcmVkLTUwIHRleHQtcmVkLTYwMCB0ZXh0LXNtIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1yZWQtMTAwXCI+e3Bhc3N3b3JkRXJyb3J9PC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHtwYXNzd29yZFN1Y2Nlc3MgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTMgYmctZW1lcmFsZC01MCB0ZXh0LVsjMDA3MWUzXSB0ZXh0LXNtIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTEwMFwiPntwYXNzd29yZFN1Y2Nlc3N9PC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHNldFNob3dQYXltZW50UGFzc3dvcmRNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldEN1cnJlbnRQYXNzd29yZChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgc2V0TmV3UGFzc3dvcmQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIHNldENvbmZpcm1QYXNzd29yZChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgc2V0UGFzc3dvcmRFcnJvcihcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgc2V0UGFzc3dvcmRTdWNjZXNzKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS02MDAgZm9udC1ib2xkIGhvdmVyOmJnLXNsYXRlLTUwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQYXltZW50UGFzc3dvcmRTdWJtaXR9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFzc3dvcmRMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTMgcm91bmRlZC14bCBiZy1bIzAwNzFlM10gdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIGhvdmVyOmJnLVsjMDA2NmNjXSBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7cGFzc3dvcmRMb2FkaW5nID8gXCJVcGRhdGluZy4uLlwiIDogXCJVcGRhdGUgUGFzc3dvcmRcIn1cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvbmF2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZiYXI7XHJcblxyXG5cclxuXHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyLmpzeCJ9