import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerWelcomeWhatsappMessage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, Input } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const CustomerWelcomeWhatsappMessage = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [selectAll, setSelectAll] = useState(false);
  const [notifier, contextHolder] = notification.useNotification();
  const today = /* @__PURE__ */ new Date();
  const todayString = today.toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedLabel, setSelectedLabel] = useState("All");
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    const today2 = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      setSelectedDate(formatDate(today2));
      setFromDate("");
      setToDate("");
    } else if (value === "Yesterday") {
      const yesterday = new Date(today2);
      yesterday.setDate(yesterday.getDate() - 1);
      setSelectedDate(formatDate(yesterday));
      setFromDate("");
      setToDate("");
    } else if (value === "TwoDaysAgo") {
      const twoDaysAgo = new Date(today2);
      twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
      setSelectedDate(formatDate(twoDaysAgo));
      setFromDate("");
      setToDate("");
    } else if (value === "ThisWeek") {
      const day = today2.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const monday = new Date(today2);
      monday.setDate(today2.getDate() - diffToMonday);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      setFromDate(formatDate(monday));
      setToDate(formatDate(sunday));
      setSelectedDate("");
    } else if (value === "LastWeek") {
      const day = today2.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const thisMonday = new Date(today2);
      thisMonday.setDate(today2.getDate() - diffToMonday);
      const lastMonday = new Date(thisMonday);
      lastMonday.setDate(thisMonday.getDate() - 7);
      const lastSunday = new Date(lastMonday);
      lastSunday.setDate(lastMonday.getDate() + 6);
      setFromDate(formatDate(lastMonday));
      setToDate(formatDate(lastSunday));
      setSelectedDate("");
    } else if (value === "ThisMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth(), 1);
      const end = new Date(today2.getFullYear(), today2.getMonth() + 1, 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "LastMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth() - 1, 1);
      const end = new Date(today2.getFullYear(), today2.getMonth(), 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "ThisYear") {
      const start = new Date(today2.getFullYear(), 0, 1);
      const end = new Date(today2.getFullYear(), 11, 31);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "All") {
      const start = new Date(2e3, 0, 1);
      const end = today2;
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    }
  };
  useEffect(() => {
    handleSelectFilter("All");
  }, []);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const res = await api.get("/enroll/get-enroll");
      const usersList = [];
      const tempActive = {};
      res.data?.forEach((user) => {
        const id = user._id;
        const userName = user?.user_id?.full_name || "Unknown";
        const userPhone = user?.user_id?.phone_number || "";
        const groupName = user?.group_id?.group_name || "N/A";
        const enrollDate = user?.createdAt?.split("T")[0] || "";
        const enrollmentDate = user?.group_id?.createdAt ? user.group_id.createdAt.split("T")[0] : enrollDate;
        usersList.push({
          _id: id,
          userName,
          userPhone,
          groupName,
          enrollmentDate,
          enrollDate
        });
        tempActive[id] = { info: { status: false } };
      });
      setUsersData(usersList);
      setActiveUserData(tempActive);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const filteredUsers = useMemo(() => {
    const normalizeDate = (date) => date ? new Date(date).toLocaleDateString("en-CA") : "";
    return usersData.filter((u) => {
      const matchGroup = groupFilter ? u.groupName === groupFilter : true;
      const enrollDate = normalizeDate(u.enrollDate);
      const matchFrom = fromDate && enrollDate ? enrollDate >= fromDate : true;
      const matchTo = toDate && enrollDate ? enrollDate <= toDate : true;
      const matchExact = selectedDate && enrollDate ? enrollDate === selectedDate : true;
      return matchGroup && matchFrom && matchTo && matchExact;
    }).map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    userPhone: user.userPhone,
                    groupName: user.groupName,
                    userName: user.userName
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 604,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, selectedDate, activeUserData]);
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp...",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/customer-welcome-message", {
        receivers: visibleActiveUsers
      });
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) delete newActiveUserData[user._id];
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Sent Successfully!",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  const visibleSelectedCount = filteredUsers.filter((u) => u.isSelected).length;
  const groupOptions = [
    ...new Set(
      usersData.filter((u) => u.groupName && u.groupName.trim() !== "").map((u) => u.groupName)
    )
  ];
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "userName", header: "Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "enrollDate", header: "Joined On" },
    { key: "groupName", header: "Group Name" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
        lineNumber: 703,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
      lineNumber: 707,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
        lineNumber: 710,
        columnNumber: 12
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Customer Welcome Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
        lineNumber: 711,
        columnNumber: 13
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
        lineNumber: 719,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
        lineNumber: 718,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 727,
                columnNumber: 7
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 728,
                columnNumber: 7
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 726,
              columnNumber: 5
            }, this),
            /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 732,
              columnNumber: 5
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 725,
            columnNumber: 3
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 737,
                columnNumber: 7
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 738,
                columnNumber: 7
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 736,
              columnNumber: 5
            }, this),
            /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 742,
              columnNumber: 5
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 735,
            columnNumber: 3
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
          lineNumber: 724,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-6 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 748,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: 200 },
                allowClear: true,
                placeholder: "--All groups--",
                onChange: (value) => setGroupFilter(value),
                value: groupFilter || void 0,
                children: groupOptions.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 759,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 751,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 747,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "Select Date Filter" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 768,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "border p-2 rounded text-sm",
                value: selectedLabel,
                onChange: (e) => handleSelectFilter(e.target.value),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "Today", children: "Today" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 774,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 775,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "TwoDaysAgo", children: "Two Days Ago" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 776,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "ThisWeek", children: "This Week" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 777,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "LastWeek", children: "Last Week" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 778,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "ThisMonth", children: "This Month" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 779,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "LastMonth", children: "Last Month" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 780,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "ThisYear", children: "This Year" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 781,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                    lineNumber: 782,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 769,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 767,
            columnNumber: 17
          }, this),
          selectedLabel && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 789,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                value: selectedDate,
                onChange: (e) => setSelectedDate(e.target?.value?.split("T")[0]),
                className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 790,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 788,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select All" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
              lineNumber: 803,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                className: "ml-2 w-4 h-4",
                checked: selectAll,
                onChange: (e) => {
                  const checked = e.target.checked;
                  setSelectAll(checked);
                  const updated = { ...activeUserData };
                  filteredUsers.forEach((u) => {
                    updated[u._id] = {
                      info: {
                        status: checked,
                        userPhone: u.userPhone,
                        groupName: u.groupName,
                        userName: u.userName
                      }
                    };
                  });
                  setActiveUserData(updated);
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 806,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 802,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
          lineNumber: 745,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: sendWhatsapp,
            className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
            children: [
              visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                  title: `Message will be sent to ${visibleSelectedCount} customers`,
                  children: visibleSelectedCount
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                  lineNumber: 837,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
                lineNumber: 844,
                columnNumber: 19
              }, this),
              "WhatsApp"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 832,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
          lineNumber: 831,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filteredUsers,
            columns: Auctioncolumns,
            catcher: "_id",
            exportedPdfName: "Customer Welcome Message",
            exportedFileName: "Customer_Welcome_Message.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
            lineNumber: 850,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
        lineNumber: 723,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
        lineNumber: 716,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
      lineNumber: 709,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
    lineNumber: 702,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx",
    lineNumber: 701,
    columnNumber: 5
  }, this);
};
_s(CustomerWelcomeWhatsappMessage, "MZNol/Ft4+DyVCDV/rohVLBJup0=", false, function() {
  return [notification.useNotification];
});
_c = CustomerWelcomeWhatsappMessage;
export default CustomerWelcomeWhatsappMessage;
var _c;
$RefreshReg$(_c, "CustomerWelcomeWhatsappMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerWelcomeWhatsappMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMmxCWTsyQkEzbEJaO0FBQWdCQSxNQUFXQyxjQUFVQyxPQUFPLHNCQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNELE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsUUFBUUMsYUFBYTtBQUM5QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBQzdCLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsU0FBU0MscUJBQXFCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQWtidkIsTUFBTUMsaUNBQWlDQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0MsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlsQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUIsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3FCLGFBQWFDLGNBQWMsSUFBSXRCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUN1QixVQUFVQyxXQUFXLElBQUl4QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDeUIsUUFBUUMsU0FBUyxJQUFJMUIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzJCLGdCQUFnQkMsaUJBQWlCLElBQUk1QixTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUM2QixXQUFXQyxZQUFZLElBQUk5QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDK0IsV0FBV0MsWUFBWSxJQUFJaEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2lDLFVBQVVDLGFBQWEsSUFBSXhCLGFBQWF5QixnQkFBZ0I7QUFDL0QsUUFBTUMsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxjQUFjRixNQUFNRyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDcEQsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUkxQyxTQUFTc0MsV0FBVztBQUM1RCxRQUFNLENBQUNLLGVBQWVDLGdCQUFnQixJQUFJNUMsU0FBUyxLQUFLO0FBR3hELFFBQU02QyxxQkFBcUJBLENBQUNDLFVBQVU7QUFDcENGLHFCQUFpQkUsS0FBSztBQUN0QixVQUFNVixTQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFVBQU1VLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRTVELFFBQUlILFVBQVUsU0FBUztBQUNyQkosc0JBQWdCSyxXQUFXWCxNQUFLLENBQUM7QUFDakNaLGtCQUFZLEVBQUU7QUFDZEUsZ0JBQVUsRUFBRTtBQUFBLElBQ2QsV0FBV29CLFVBQVUsYUFBYTtBQUNoQyxZQUFNSSxZQUFZLElBQUliLEtBQUtELE1BQUs7QUFDaENjLGdCQUFVQyxRQUFRRCxVQUFVRSxRQUFRLElBQUksQ0FBQztBQUN6Q1Ysc0JBQWdCSyxXQUFXRyxTQUFTLENBQUM7QUFDckMxQixrQkFBWSxFQUFFO0FBQ2RFLGdCQUFVLEVBQUU7QUFBQSxJQUNkLFdBQVdvQixVQUFVLGNBQWM7QUFDakMsWUFBTU8sYUFBYSxJQUFJaEIsS0FBS0QsTUFBSztBQUNqQ2lCLGlCQUFXRixRQUFRRSxXQUFXRCxRQUFRLElBQUksQ0FBQztBQUMzQ1Ysc0JBQWdCSyxXQUFXTSxVQUFVLENBQUM7QUFDdEM3QixrQkFBWSxFQUFFO0FBQ2RFLGdCQUFVLEVBQUU7QUFBQSxJQUNkLFdBQVdvQixVQUFVLFlBQVk7QUFDL0IsWUFBTVEsTUFBTWxCLE9BQU1tQixPQUFPO0FBQ3pCLFlBQU1DLGVBQWVGLFFBQVEsSUFBSSxJQUFJQSxNQUFNO0FBQzNDLFlBQU1HLFNBQVMsSUFBSXBCLEtBQUtELE1BQUs7QUFDN0JxQixhQUFPTixRQUFRZixPQUFNZ0IsUUFBUSxJQUFJSSxZQUFZO0FBQzdDLFlBQU1FLFNBQVMsSUFBSXJCLEtBQUtvQixNQUFNO0FBQzlCQyxhQUFPUCxRQUFRTSxPQUFPTCxRQUFRLElBQUksQ0FBQztBQUNuQzVCLGtCQUFZdUIsV0FBV1UsTUFBTSxDQUFDO0FBQzlCL0IsZ0JBQVVxQixXQUFXVyxNQUFNLENBQUM7QUFDNUJoQixzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFdBQVdJLFVBQVUsWUFBWTtBQUMvQixZQUFNUSxNQUFNbEIsT0FBTW1CLE9BQU87QUFDekIsWUFBTUMsZUFBZUYsUUFBUSxJQUFJLElBQUlBLE1BQU07QUFDM0MsWUFBTUssYUFBYSxJQUFJdEIsS0FBS0QsTUFBSztBQUNqQ3VCLGlCQUFXUixRQUFRZixPQUFNZ0IsUUFBUSxJQUFJSSxZQUFZO0FBQ2pELFlBQU1JLGFBQWEsSUFBSXZCLEtBQUtzQixVQUFVO0FBQ3RDQyxpQkFBV1QsUUFBUVEsV0FBV1AsUUFBUSxJQUFJLENBQUM7QUFDM0MsWUFBTVMsYUFBYSxJQUFJeEIsS0FBS3VCLFVBQVU7QUFDdENDLGlCQUFXVixRQUFRUyxXQUFXUixRQUFRLElBQUksQ0FBQztBQUMzQzVCLGtCQUFZdUIsV0FBV2EsVUFBVSxDQUFDO0FBQ2xDbEMsZ0JBQVVxQixXQUFXYyxVQUFVLENBQUM7QUFDaENuQixzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFdBQVdJLFVBQVUsYUFBYTtBQUNoQyxZQUFNZ0IsUUFBUSxJQUFJekIsS0FBS0QsT0FBTTJCLFlBQVksR0FBRzNCLE9BQU00QixTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUk1QixLQUFLRCxPQUFNMkIsWUFBWSxHQUFHM0IsT0FBTTRCLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakV4QyxrQkFBWXVCLFdBQVdlLEtBQUssQ0FBQztBQUM3QnBDLGdCQUFVcUIsV0FBV2tCLEdBQUcsQ0FBQztBQUN6QnZCLHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBV0ksVUFBVSxhQUFhO0FBQ2hDLFlBQU1nQixRQUFRLElBQUl6QixLQUFLRCxPQUFNMkIsWUFBWSxHQUFHM0IsT0FBTTRCLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTUMsTUFBTSxJQUFJNUIsS0FBS0QsT0FBTTJCLFlBQVksR0FBRzNCLE9BQU00QixTQUFTLEdBQUcsQ0FBQztBQUM3RHhDLGtCQUFZdUIsV0FBV2UsS0FBSyxDQUFDO0FBQzdCcEMsZ0JBQVVxQixXQUFXa0IsR0FBRyxDQUFDO0FBQ3pCdkIsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXSSxVQUFVLFlBQVk7QUFDL0IsWUFBTWdCLFFBQVEsSUFBSXpCLEtBQUtELE9BQU0yQixZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSTVCLEtBQUtELE9BQU0yQixZQUFZLEdBQUcsSUFBSSxFQUFFO0FBQ2hEdkMsa0JBQVl1QixXQUFXZSxLQUFLLENBQUM7QUFDN0JwQyxnQkFBVXFCLFdBQVdrQixHQUFHLENBQUM7QUFDekJ2QixzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFdBQVdJLFVBQVUsT0FBTztBQUMxQixZQUFNZ0IsUUFBUSxJQUFJekIsS0FBSyxLQUFNLEdBQUcsQ0FBQztBQUNqQyxZQUFNNEIsTUFBTTdCO0FBQ1paLGtCQUFZdUIsV0FBV2UsS0FBSyxDQUFDO0FBQzdCcEMsZ0JBQVVxQixXQUFXa0IsR0FBRyxDQUFDO0FBQ3pCdkIsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQTNDLFlBQVUsTUFBTTtBQUNkOEMsdUJBQW1CLEtBQUs7QUFBQSxFQUMxQixHQUFHLEVBQUU7QUFHTCxRQUFNcUIsWUFBWSxZQUFZO0FBQzVCLFFBQUk7QUFDRnBDLG1CQUFhLElBQUk7QUFDakIsWUFBTXFDLE1BQU0sTUFBTWpFLElBQUlrRSxJQUFJLG9CQUFvQjtBQUM5QyxZQUFNQyxZQUFZO0FBQ2xCLFlBQU1DLGFBQWEsQ0FBQztBQUVwQkgsVUFBSUksTUFBTUMsUUFBUSxDQUFDQyxTQUFTO0FBQzFCLGNBQU1DLEtBQUtELEtBQUtFO0FBQ2hCLGNBQU1DLFdBQVdILE1BQU1JLFNBQVNDLGFBQWE7QUFDN0MsY0FBTUMsWUFBWU4sTUFBTUksU0FBU0csZ0JBQWdCO0FBQ2pELGNBQU1DLFlBQVlSLE1BQU1TLFVBQVVDLGNBQWM7QUFDaEQsY0FBTUMsYUFBYVgsTUFBTVksV0FBVzdDLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUNyRCxjQUFNOEMsaUJBQWlCYixNQUFNUyxVQUFVRyxZQUNuQ1osS0FBS1MsU0FBU0csVUFBVTdDLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDcEM0QztBQUVKZixrQkFBVWtCLEtBQUs7QUFBQSxVQUNiWixLQUFLRDtBQUFBQSxVQUNMRTtBQUFBQSxVQUNBRztBQUFBQSxVQUNBRTtBQUFBQSxVQUNBSztBQUFBQSxVQUNBRjtBQUFBQSxRQUNGLENBQUM7QUFFRGQsbUJBQVdJLEVBQUUsSUFBSSxFQUFFYyxNQUFNLEVBQUVDLFFBQVEsTUFBTSxFQUFFO0FBQUEsTUFDN0MsQ0FBQztBQUVEckUsbUJBQWFpRCxTQUFTO0FBQ3RCekMsd0JBQWtCMEMsVUFBVTtBQUFBLElBQzlCLFNBQVNvQixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0MsVUFBQztBQUNDNUQsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBL0IsWUFBVSxNQUFNO0FBQ2RtRSxjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFHTCxRQUFNMEIsZ0JBQWdCM0YsUUFBUSxNQUFNO0FBQ2xDLFVBQU00RixnQkFBZ0JBLENBQUM3QyxTQUNyQkEsT0FBTyxJQUFJWCxLQUFLVyxJQUFJLEVBQUVDLG1CQUFtQixPQUFPLElBQUk7QUFFdEQsV0FBTzlCLFVBQ0oyRSxPQUFPLENBQUNDLE1BQU07QUFDYixZQUFNQyxhQUFhM0UsY0FBYzBFLEVBQUVkLGNBQWM1RCxjQUFjO0FBQy9ELFlBQU0rRCxhQUFhUyxjQUFjRSxFQUFFWCxVQUFVO0FBRTdDLFlBQU1hLFlBQ0oxRSxZQUFZNkQsYUFBYUEsY0FBYzdELFdBQVc7QUFDcEQsWUFBTTJFLFVBQVV6RSxVQUFVMkQsYUFBYUEsY0FBYzNELFNBQVM7QUFDOUQsWUFBTTBFLGFBQ0oxRCxnQkFBZ0IyQyxhQUFhQSxlQUFlM0MsZUFBZTtBQUU3RCxhQUFPdUQsY0FBY0MsYUFBYUMsV0FBV0M7QUFBQUEsSUFDL0MsQ0FBQyxFQUNBQyxJQUFJLENBQUMzQixNQUFNNEIsVUFBVTtBQUNwQixZQUFNQyxhQUFhLENBQUMsQ0FBQzNFLGVBQWU4QyxLQUFLRSxHQUFHLEdBQUdhLE1BQU1DO0FBRXJELGFBQU87QUFBQSxRQUNMLEdBQUdoQjtBQUFBQSxRQUNIOEIsT0FBT0YsUUFBUTtBQUFBLFFBQ2ZHLFdBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNGO0FBQUFBLFlBQ1QsVUFBVSxDQUFDRyxNQUFNO0FBQ2Y3RSxnQ0FBa0IsQ0FBQzhFLFVBQVU7QUFBQSxnQkFDM0IsR0FBR0E7QUFBQUEsZ0JBQ0gsQ0FBQ2pDLEtBQUtFLEdBQUcsR0FBRztBQUFBLGtCQUNWYSxNQUFNO0FBQUEsb0JBQ0pDLFFBQVFnQixFQUFFRSxPQUFPQztBQUFBQSxvQkFDakI3QixXQUFXTixLQUFLTTtBQUFBQSxvQkFDaEJFLFdBQVdSLEtBQUtRO0FBQUFBLG9CQUNoQkwsVUFBVUgsS0FBS0c7QUFBQUEsa0JBQ2pCO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGLEVBQUU7QUFBQSxZQUNKO0FBQUE7QUFBQSxVQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWVJO0FBQUEsUUFHTjBCO0FBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNMLEdBQUcsQ0FBQ25GLFdBQVdFLGFBQWFFLFVBQVVFLFFBQVFnQixjQUFjZCxjQUFjLENBQUM7QUFHM0U1QixZQUFVLE1BQU07QUFDZCxVQUFNOEcsYUFDSmpCLGNBQWNrQixTQUFTLEtBQ3ZCbEIsY0FBY21CLE1BQU0sQ0FBQ3RDLFNBQVM5QyxlQUFlOEMsS0FBS0UsR0FBRyxHQUFHYSxNQUFNQyxNQUFNO0FBQ3RFekQsaUJBQWE2RSxVQUFVO0FBQUEsRUFDekIsR0FBRyxDQUFDakIsZUFBZWpFLGNBQWMsQ0FBQztBQUdsQyxRQUFNcUYsZUFBZSxZQUFZO0FBQy9CLFVBQU1DLE1BQU07QUFDWixRQUFJO0FBQ0ZoRixlQUFTaUYsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFFRCxZQUFNQyxxQkFBcUIsQ0FBQztBQUM1QjNCLG9CQUFjcEIsUUFBUSxDQUFDQyxTQUFTO0FBQzlCLFlBQUlBLEtBQUs2QixjQUFjM0UsZUFBZThDLEtBQUtFLEdBQUcsR0FBRztBQUMvQzRDLDZCQUFtQjlDLEtBQUtFLEdBQUcsSUFBSWhELGVBQWU4QyxLQUFLRSxHQUFHO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNekUsSUFBSXNILEtBQUssc0NBQXNDO0FBQUEsUUFDbkRDLFdBQVdGO0FBQUFBLE1BQ2IsQ0FBQztBQUVELFlBQU1HLG9CQUFvQixFQUFFLEdBQUcvRixlQUFlO0FBQzlDaUUsb0JBQWNwQixRQUFRLENBQUNDLFNBQVM7QUFDOUIsWUFBSUEsS0FBSzZCLFdBQVksUUFBT29CLGtCQUFrQmpELEtBQUtFLEdBQUc7QUFBQSxNQUN4RCxDQUFDO0FBQ0QvQyx3QkFBa0I4RixpQkFBaUI7QUFFbkN6RixlQUFTaUYsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNURSxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsU0FBU0ssS0FBSztBQUNaMUYsZUFBU2lGLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYU8sSUFBSVIsV0FBVztBQUFBLFFBQzVCRSxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTU0sdUJBQXVCaEMsY0FBY0UsT0FBTyxDQUFDQyxNQUFNQSxFQUFFTyxVQUFVLEVBQUVRO0FBRXZFLFFBQU1lLGVBQWU7QUFBQSxJQUNuQixHQUFHLElBQUlDO0FBQUFBLE1BQ0wzRyxVQUNHMkUsT0FBTyxDQUFDQyxNQUFNQSxFQUFFZCxhQUFhYyxFQUFFZCxVQUFVOEMsS0FBSyxNQUFNLEVBQUUsRUFDdEQzQixJQUFJLENBQUNMLE1BQU1BLEVBQUVkLFNBQVM7QUFBQSxJQUMzQjtBQUFBLEVBQUM7QUFHSCxRQUFNK0MsaUJBQWlCO0FBQUEsSUFDckIsRUFBRWYsS0FBSyxTQUFTZ0IsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRWhCLEtBQUssYUFBYWdCLFFBQVEsY0FBYztBQUFBLElBQzFDLEVBQUVoQixLQUFLLFlBQVlnQixRQUFRLE9BQU87QUFBQSxJQUNsQyxFQUFFaEIsS0FBSyxhQUFhZ0IsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRWhCLEtBQUssY0FBY2dCLFFBQVEsWUFBWTtBQUFBLElBQ3pDLEVBQUVoQixLQUFLLGFBQWFnQixRQUFRLGFBQWE7QUFBQSxFQUFDO0FBRzVDLFNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ1gsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCLENBQUN4QixNQUFNdkYsY0FBY3VGLEVBQUVFLE9BQU83RCxLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBRU4sdUJBQUMsU0FBSSxXQUFVLGlCQUNkO0FBQUEsNkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDVix1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDWjtBQUFBQSxNQUVELHVCQUFDLFNBQUksV0FBVSxhQUNYTCxzQkFDTix1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxrQkFBZSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUdJLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1EQUM3QjtBQUFBLGlDQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGNBQ3BELHVCQUFDLE9BQUUsV0FBVSxzQ0FDVitELHdCQUFja0IsVUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFdBQVEsV0FBVSw4QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxlQVAvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHlCQUF3QixrQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxjQUN2RCx1QkFBQyxPQUFFLFdBQVUscUNBQ1ZjLGtDQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxpQkFBYyxXQUFVLDZCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLGVBUHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQW5CYztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JoQjtBQUFBLFFBQ2MsdUJBQUMsU0FBSSxXQUFVLDBDQUViO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTyxFQUFFTSxPQUFPLElBQUk7QUFBQSxnQkFDcEI7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osVUFBVSxDQUFDcEYsVUFBVXhCLGVBQWV3QixLQUFLO0FBQUEsZ0JBQ3pDLE9BQU96QixlQUFlOEc7QUFBQUEsZ0JBRXJCTix1QkFBYXpCO0FBQUFBLGtCQUFJLENBQUNnQyxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxlQUFjLGtDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFlBQ2pEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU96RjtBQUFBQSxnQkFDUCxVQUFVLENBQUM4RCxNQUFNNUQsbUJBQW1CNEQsRUFBRUUsT0FBTzdELEtBQUs7QUFBQSxnQkFFbEQ7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDM0IsdUJBQUMsWUFBTyxPQUFNLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1DO0FBQUEsa0JBQ25DLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLGtCQUN2Qyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0M7QUFBQSxrQkFDbEMsdUJBQUMsWUFBTyxPQUFNLFlBQVcseUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUEsa0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxhQUFZLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUNwQyx1QkFBQyxZQUFPLE9BQU0sYUFBWSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQSxrQkFDcEMsdUJBQUMsWUFBTyxPQUFNLFlBQVcseUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUEsa0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxPQUFNLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QjtBQUFBO0FBQUE7QUFBQSxjQWJ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFHQ0gsaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLG9CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVc7QUFBQSxZQUNYO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9GO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2dFLE1BQ1QvRCxnQkFBZ0IrRCxFQUFFRSxRQUFRN0QsT0FBT04sTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsZ0JBRWhELFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTTZGO0FBQUEsZUFSL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBSUYsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixTQUFTVDtBQUFBQSxnQkFDVCxVQUFVLENBQUMwRSxNQUFNO0FBQ2Ysd0JBQU1HLFVBQVVILEVBQUVFLE9BQU9DO0FBQ3pCNUUsK0JBQWE0RSxPQUFPO0FBQ3BCLHdCQUFNeUIsVUFBVSxFQUFFLEdBQUcxRyxlQUFlO0FBQ3BDaUUsZ0NBQWNwQixRQUFRLENBQUN1QixNQUFNO0FBQzNCc0MsNEJBQVF0QyxFQUFFcEIsR0FBRyxJQUFJO0FBQUEsc0JBQ2ZhLE1BQU07QUFBQSx3QkFDSkMsUUFBUW1CO0FBQUFBLHdCQUNSN0IsV0FBV2dCLEVBQUVoQjtBQUFBQSx3QkFDYkUsV0FBV2MsRUFBRWQ7QUFBQUEsd0JBQ2JMLFVBQVVtQixFQUFFbkI7QUFBQUEsc0JBQ2Q7QUFBQSxvQkFDRjtBQUFBLGtCQUNGLENBQUM7QUFDRGhELG9DQUFrQnlHLE9BQU87QUFBQSxnQkFDM0I7QUFBQTtBQUFBLGNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW1CSTtBQUFBLGVBdkJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsYUFsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1GQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTckI7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVFk7QUFBQUEscUNBQXVCLEtBQ3RCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPLDJCQUEyQkEsb0JBQW9CO0FBQUEsa0JBRXJEQTtBQUFBQTtBQUFBQSxnQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUYsdUJBQUMsY0FBVyxXQUFVLFFBQU8sTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQztBQUFBLGNBQUc7QUFBQTtBQUFBO0FBQUEsVUFaM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFHQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTWhDO0FBQUFBLFlBQ04sU0FBU29DO0FBQUFBLFlBQ1QsU0FBUTtBQUFBLFlBQ1IsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxVQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLaUQ7QUFBQSxXQXBJakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNJQSxLQTdJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0lBO0FBQUEsU0F0SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVKQTtBQUFBLE9BOUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnS0EsS0FqS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtLRTtBQUVKO0FBQUVoSCxHQW5hSUQsZ0NBQThCO0FBQUEsVUFTQUwsYUFBYXlCLGVBQWU7QUFBQTtBQUFBbUcsS0FUMUR2SDtBQXFhTixlQUFlQTtBQUErQixJQUFBdUg7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiSW5wdXQiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJGYVdoYXRzYXBwIiwibm90aWZpY2F0aW9uIiwiU2lkZWJhciIsIkZhVXNlcnMiLCJGYUNoZWNrQ2lyY2xlIiwiQnJlYWRjcnVtYiIsIkN1c3RvbWVyV2VsY29tZVdoYXRzYXBwTWVzc2FnZSIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJub3RpZmllciIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJ0b2RheSIsIkRhdGUiLCJ0b2RheVN0cmluZyIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJzZWxlY3RlZExhYmVsIiwic2V0U2VsZWN0ZWRMYWJlbCIsImhhbmRsZVNlbGVjdEZpbHRlciIsInZhbHVlIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInR3b0RheXNBZ28iLCJkYXkiLCJnZXREYXkiLCJkaWZmVG9Nb25kYXkiLCJtb25kYXkiLCJzdW5kYXkiLCJ0aGlzTW9uZGF5IiwibGFzdE1vbmRheSIsImxhc3RTdW5kYXkiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJmZXRjaERhdGEiLCJyZXMiLCJnZXQiLCJ1c2Vyc0xpc3QiLCJ0ZW1wQWN0aXZlIiwiZGF0YSIsImZvckVhY2giLCJ1c2VyIiwiaWQiLCJfaWQiLCJ1c2VyTmFtZSIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJ1c2VyUGhvbmUiLCJwaG9uZV9udW1iZXIiLCJncm91cE5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJlbnJvbGxEYXRlIiwiY3JlYXRlZEF0IiwiZW5yb2xsbWVudERhdGUiLCJwdXNoIiwiaW5mbyIsInN0YXR1cyIsImVycm9yIiwiY29uc29sZSIsImZpbHRlcmVkVXNlcnMiLCJub3JtYWxpemVEYXRlIiwiZmlsdGVyIiwidSIsIm1hdGNoR3JvdXAiLCJtYXRjaEZyb20iLCJtYXRjaFRvIiwibWF0Y2hFeGFjdCIsIm1hcCIsImluZGV4IiwiaXNTZWxlY3RlZCIsInNsX25vIiwiY2hlY2tCb3hzIiwiZSIsInByZXYiLCJ0YXJnZXQiLCJjaGVja2VkIiwiYWxsQ2hlY2tlZCIsImxlbmd0aCIsImV2ZXJ5Iiwic2VuZFdoYXRzYXBwIiwia2V5Iiwib3BlbiIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsImNsYXNzTmFtZSIsImR1cmF0aW9uIiwidmlzaWJsZUFjdGl2ZVVzZXJzIiwicG9zdCIsInJlY2VpdmVycyIsIm5ld0FjdGl2ZVVzZXJEYXRhIiwiZXJyIiwidmlzaWJsZVNlbGVjdGVkQ291bnQiLCJncm91cE9wdGlvbnMiLCJTZXQiLCJ0cmltIiwiQXVjdGlvbmNvbHVtbnMiLCJoZWFkZXIiLCJ3aWR0aCIsInVuZGVmaW5lZCIsImdyb3VwIiwidXBkYXRlZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkN1c3RvbWVyV2VsY29tZVdoYXRzYXBwTWVzc2FnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgSW5wdXQgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHAgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IEZhVXNlcnMsIEZhQ2hlY2tDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuXHJcbi8vIGNvbnN0IEN1c3RvbWVyV2VsY29tZVdoYXRzYXBwTWVzc2FnZSA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuLy8gICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2F1Y3Rpb25EYXRhLCBzZXRBdWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgIGNvbnN0IHRvZGF5U3RyaW5nID0gdG9kYXkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuLy8gICAvL2NvbnN0IGdyb3VwT3B0aW9ucyA9IFsuLi5uZXcgU2V0KHVzZXJzRGF0YS5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKSldO1xyXG4vLyAgIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuLy8gICAgIC4uLm5ldyBTZXQoXHJcbi8vICAgICAgIHVzZXJzRGF0YVxyXG4vLyAgICAgICAgIC5maWx0ZXIoXHJcbi8vICAgICAgICAgICAodSkgPT5cclxuLy8gICAgICAgICAgICAgdS5ncm91cE5hbWUgIT09IHVuZGVmaW5lZCAmJlxyXG4vLyAgICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCJcIiAmJlxyXG4vLyAgICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCIgICBcIlxyXG4vLyAgICAgICAgIClcclxuLy8gICAgICAgICAubWFwKCh1KSA9PiB1Lmdyb3VwTmFtZSlcclxuLy8gICAgICksXHJcbi8vICAgXTtcclxuLy8gICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmaWx0ZXJlZCA9IHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuLy8gICAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuLy8gICAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmVucm9sbG1lbnREYXRlKTtcclxuLy8gICAgICAgY29uc3QgZmlsdGVyRW5yb2xsRGF0ZSA9IHNlbGVjdGVkRGF0ZSA9PT0gdS5lbnJvbGxEYXRlXHJcbi8vICAgICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZVxyXG4vLyAgICAgICAgID8gZW5yb2xsbWVudERhdGUgPj0gbmV3IERhdGUoZnJvbURhdGUpXHJcbi8vICAgICAgICAgOiB0cnVlO1xyXG4vLyAgICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IHRvRGF0ZSA/IGVucm9sbG1lbnREYXRlIDw9IG5ldyBEYXRlKHRvRGF0ZSkgOiB0cnVlO1xyXG4vLyAgICAgICByZXR1cm4gbWF0Y2hHcm91cCAmJiBtYXRjaEZyb21EYXRlICYmIG1hdGNoVG9EYXRlICYmIGZpbHRlckVucm9sbERhdGU7XHJcbi8vICAgICB9KTtcclxuIFxyXG4vLyAgICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4vLyAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgIC4uLnVzZXIsXHJcbi8vICAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBjaGVja0JveHM6IChcclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4vLyAgICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbi8vICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICB9KSk7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICksXHJcbi8vICAgICAgICAgaXNTZWxlY3RlZCxcclxuLy8gICAgICAgfTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH0sIFtcclxuLy8gICAgIHVzZXJzRGF0YSxcclxuLy8gICAgIGdyb3VwRmlsdGVyLFxyXG4vLyAgICAgZnJvbURhdGUsXHJcbi8vICAgICB0b0RhdGUsXHJcbi8vICAgICBzZWFyY2hUZXh0LFxyXG4vLyAgICAgYWN0aXZlVXNlckRhdGEsXHJcbi8vICAgICBzZWFyY2hUZXh0LFxyXG4vLyAgICAgc2VsZWN0ZWREYXRlXHJcbi8vICAgXSk7XHJcblxyXG5cclxuLy8gY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbi8vICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcblxyXG4vLyAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuLy8gICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4vLyAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbi8vICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh0b2RheSkpO1xyXG4vLyAgICAgc2V0RnJvbURhdGUoXCJcIik7XHJcbi8vICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbi8vICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4vLyAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4vLyAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4vLyAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoeWVzdGVyZGF5KSk7XHJcbi8vICAgICBzZXRGcm9tRGF0ZShcIlwiKTtcclxuLy8gICAgIHNldFRvRGF0ZShcIlwiKTtcclxuLy8gICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlR3b0RheXNBZ29cIikge1xyXG4vLyAgICAgY29uc3QgdHdvRGF5c0FnbyA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgIHR3b0RheXNBZ28uc2V0RGF0ZSh0d29EYXlzQWdvLmdldERhdGUoKSAtIDIpO1xyXG4vLyAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUodHdvRGF5c0FnbykpO1xyXG4vLyAgICAgc2V0RnJvbURhdGUoXCJcIik7XHJcbi8vICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbi8vICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzV2Vla1wiKSB7XHJcbi8vICAgICBjb25zdCBkYXkgPSB0b2RheS5nZXREYXkoKTsgLy8gU3VuZGF5PTAsIE1vbmRheT0xLCAuLi5cclxuLy8gICAgIGNvbnN0IGRpZmZUb01vbmRheSA9IGRheSA9PT0gMCA/IDYgOiBkYXkgLSAxOyAvLyBhZGp1c3QgaWYgdG9kYXkgaXMgU3VuZGF5XHJcbi8vICAgICBjb25zdCBtb25kYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbi8vICAgICBtb25kYXkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSBkaWZmVG9Nb25kYXkpO1xyXG4vLyAgICAgY29uc3Qgc3VuZGF5ID0gbmV3IERhdGUobW9uZGF5KTtcclxuLy8gICAgIHN1bmRheS5zZXREYXRlKG1vbmRheS5nZXREYXRlKCkgKyA2KTtcclxuLy8gICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUobW9uZGF5KSk7XHJcbi8vICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShzdW5kYXkpKTtcclxuLy8gICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuLy8gICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RXZWVrXCIpIHtcclxuLy8gICAgIGNvbnN0IGRheSA9IHRvZGF5LmdldERheSgpO1xyXG4vLyAgICAgY29uc3QgZGlmZlRvTW9uZGF5ID0gZGF5ID09PSAwID8gNiA6IGRheSAtIDE7XHJcbi8vICAgICBjb25zdCB0aGlzTW9uZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4vLyAgICAgdGhpc01vbmRheS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIGRpZmZUb01vbmRheSk7XHJcbi8vICAgICBjb25zdCBsYXN0TW9uZGF5ID0gbmV3IERhdGUodGhpc01vbmRheSk7XHJcbi8vICAgICBsYXN0TW9uZGF5LnNldERhdGUodGhpc01vbmRheS5nZXREYXRlKCkgLSA3KTtcclxuLy8gICAgIGNvbnN0IGxhc3RTdW5kYXkgPSBuZXcgRGF0ZShsYXN0TW9uZGF5KTtcclxuLy8gICAgIGxhc3RTdW5kYXkuc2V0RGF0ZShsYXN0TW9uZGF5LmdldERhdGUoKSArIDYpO1xyXG4vLyAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShsYXN0TW9uZGF5KSk7XHJcbi8vICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShsYXN0U3VuZGF5KSk7XHJcbi8vICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbi8vICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4vLyAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuLy8gICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuLy8gICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4vLyAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuLy8gICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4vLyAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbi8vICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuLy8gICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuLy8gICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbi8vICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4vLyAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbi8vICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJBbGxcIikge1xyXG4vLyAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSgyMDAwLCAwLCAxKTtcclxuLy8gICAgIGNvbnN0IGVuZCA9IHRvZGF5O1xyXG4vLyAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbi8vICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4vLyAgICAgLy8gdXNlciBzZWxlY3RzIG1hbnVhbGx5IOKGkiBkb27igJl0IG92ZXJyaWRlXHJcbi8vICAgfVxyXG4vLyB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgaGFuZGxlU2VsZWN0RmlsdGVyKFwiQWxsXCIpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgY29uc3QgdmlzaWJsZVNlbGVjdGVkQ291bnQgPSB1c2VNZW1vKCgpID0+IHtcclxuLy8gICAgIHJldHVybiBmaWx0ZXJlZFVzZXJzLmZpbHRlcigodXNlcikgPT4gdXNlci5pc1NlbGVjdGVkKS5sZW5ndGg7XHJcbi8vICAgfSwgW2ZpbHRlcmVkVXNlcnNdKTtcclxuXHJcbi8vICAgY29uc3Qgc2VuZFdoYXRzYXBwID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgY29uc3Qga2V5ID0gXCJ1cGRhdGFibGVcIjtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4vLyAgICAgICAgIGtleSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIlNlbmRpbmcgTWVzc2FnZXMgVmlhIFdoYXRzYXBwLi5cIixcclxuLy8gICAgICAgICBkZXNjcmlwdGlvbjogXCJQcm9jZXNzaW5nLi4uXCIsXHJcbi8vICAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4vLyAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHZpc2libGVBY3RpdmVVc2VycyA9IHt9O1xyXG4vLyAgICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuLy8gICAgICAgICBpZiAodXNlci5pc1NlbGVjdGVkICYmIGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXSkge1xyXG4vLyAgICAgICAgICAgdmlzaWJsZUFjdGl2ZVVzZXJzW3VzZXIuX2lkXSA9IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgY29uc3QgdGVzdCA9IGF3YWl0IGFwaS5wb3N0KFwiL3doYXRzYXBwL2N1c3RvbWVyLXdlbGNvbWUtbWVzc2FnZVwiLCB7XHJcbi8vICAgICAgICAgcmVjZWl2ZXJzOiB2aXNpYmxlQWN0aXZlVXNlcnMsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICAvL2NvbnNvbGUuaW5mbyh0ZXN0LCBcImhnaGdmZ2hnZmZcIik7XHJcblxyXG4vLyAgICAgICBjb25zdCBuZXdBY3RpdmVVc2VyRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuLy8gICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbi8vICAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkge1xyXG4vLyAgICAgICAgICAgZGVsZXRlIG5ld0FjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBzZXRBY3RpdmVVc2VyRGF0YShuZXdBY3RpdmVVc2VyRGF0YSk7XHJcblxyXG4vLyAgICAgICBub3RpZmllci5vcGVuKHtcclxuLy8gICAgICAgICBrZXksXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBNZXNzYWdlcyBIYXMgQmVlbiBTZW50IFN1Y2Nlc3NmdWxseVwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlN1Y2Nlc3NcIixcclxuLy8gICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbi8vICAgICAgICAgZHVyYXRpb246IDIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4vLyAgICAgICAgIGtleSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBTZW5kIFdoYXRzYXBwXCIsXHJcbi8vICAgICAgICAgZGVzY3JpcHRpb246IGVyci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuLy8gICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4vLyAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICAvLyBBdXRvbWF0aWNhbGx5IHVwZGF0ZSBzZWxlY3RBbGwgYmFzZWQgb24gZmlsdGVyZWRVc2Vyc1xyXG4vLyAgICAgY29uc3QgYWxsQ2hlY2tlZCA9XHJcbi8vICAgICAgIGZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMCAmJlxyXG4vLyAgICAgICBmaWx0ZXJlZFVzZXJzLmV2ZXJ5KCh1c2VyKSA9PiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cyk7XHJcbi8vICAgICBzZXRTZWxlY3RBbGwoYWxsQ2hlY2tlZCk7XHJcbi8vICAgfSwgW2ZpbHRlcmVkVXNlcnMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuLy8gICAgICAgY29uc3QgcmVwb3J0UmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC9nZXQtZW5yb2xsXCIpO1xyXG4vLyAgICAgICBjb25zb2xlLmluZm8ocmVwb3J0UmVzcG9uc2UuZGF0YSwgXCJqaGZzZ2poZGZzZGhnXCIpO1xyXG5cclxuLy8gICAgICAgY29uc3QgdXNlcnNMaXN0ID0gW107XHJcbi8vICAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuLy8gICAgICAgY29uc3QgZGF0YSA9IHJlcG9ydFJlc3BvbnNlLmRhdGE/Lm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICBjb25zdCBpZCA9IHVzZXIuX2lkO1xyXG4vLyAgICAgICAgIC8vICBjb25zdCBncm91cElkID0gbGVhZD8uZ3JvdXBfaWQ7XHJcbi8vICAgICAgICAgY29uc3QgdXNlck5hbWUgPSB1c2VyPy51c2VyX2lkPy5mdWxsX25hbWU7XHJcbi8vICAgICAgICAgY29uc3QgdXNlclBob25lID0gdXNlcj8udXNlcl9pZD8ucGhvbmVfbnVtYmVyO1xyXG4vLyAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IHVzZXI/Lmdyb3VwX2lkPy5ncm91cF9uYW1lO1xyXG4vLyAgICAgICAgIGNvbnN0IGVucm9sbERhdGUgPSB1c2VyPy5jcmVhdGVkQXQuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuLy8gICAgICAgICB0ZW1wQWN0aXZlW2lkXSA9IHtcclxuLy8gICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgfTtcclxuXHJcbi8vICAgICAgICAgY29uc3QgdGVtcFVzciA9IHtcclxuLy8gICAgICAgICAgIF9pZDogaWQsXHJcbi8vICAgICAgICAgICB1c2VyTmFtZSxcclxuLy8gICAgICAgICAgIHVzZXJQaG9uZSxcclxuLy8gICAgICAgICAgIGdyb3VwTmFtZSxcclxuLy8gICAgICAgICAgIC8vIGdyb3VwSWQsXHJcbi8vICAgICAgICAgICBlbnJvbGxtZW50RGF0ZTogdXNlcj8uZ3JvdXBfaWQ/LmNyZWF0ZWRBdC5zcGxpdChcIlRcIilbMF0sXHJcbi8vICAgICAgICAgICBlbnJvbGxEYXRlLFxyXG4vLyAgICAgICAgICAgLy8gbGVhZGVucm9sbERhdGUsXHJcbi8vICAgICAgICAgfTtcclxuLy8gICAgICAgICB1c2Vyc0xpc3QucHVzaCh0ZW1wVXNyKTtcclxuXHJcbi8vICAgICAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIGdyb3VwTmFtZSxcclxuLy8gICAgICAgICAgIHVzZXJOYW1lLFxyXG4vLyAgICAgICAgICAgdXNlclBob25lLFxyXG4vLyAgICAgICAgICAgLy8gIGdyb3VwSWQsXHJcbi8vICAgICAgICAgLy8gIHJlZmVycmVkQnk6IHVzZXI/LmxlYWRfYWdlbnQ/Lm5hbWUsXHJcbi8vICAgICAgICAgICBlbnJvbGxEYXRlLFxyXG4vLyAgICAgICAgIH07XHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgIC8vIGNvbnNvbGUuaW5mbyhkYXRhLCBcImprZ25zZGtnanNibmdcIik7XHJcblxyXG4vLyAgICAgICBzZXRBdWN0aW9uRGF0YShkYXRhKTtcclxuLy8gICAgICAgc2V0VXNlcnNEYXRhKHVzZXJzTGlzdCk7IC8vIOKchSB1cGRhdGUgdXNlcnNEYXRhIGZvciBmaWx0ZXJpbmcgKyBjaGVja2JveGVzXHJcbi8vICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHRlbXBBY3RpdmUpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoRGF0YSgpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgY29uc3QgQXVjdGlvbmNvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNoZWNrQm94c1wiLCBoZWFkZXI6IFwiU2VsZWN0IFVzZXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIk5hbWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZW5yb2xsRGF0ZVwiLCBoZWFkZXI6IFwiSm9pbmVkIG9uXCIgfSxcclxuLy8gICAgIC8vIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbi8vICAgICAvLyAge2tleTogXCJwYXltZW50c1RpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCJ9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInctc2NyZWVuXCI+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0zMFwiPlxyXG4vLyAgICAgICAgIDxOYXZiYXJcclxuLy8gICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuLy8gICAgICAgICAvPlxyXG4vLyAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICBDdXN0b21lciBXZWxjb21lIE1lc3NhZ2VcclxuLy8gICAgICAgICAgICAgPC9oMT5cclxuLy8gICAgICAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktc3RhcnQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMzAwIG1iLTRcIj48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgR3JvdXBcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAyMDAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiLS1BbGwgZ3JvdXBzLS1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0R3JvdXBGaWx0ZXIodmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwRmlsdGVyIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14cyBoLTExIFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGdyb3VwKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXB9IHZhbHVlPXtncm91cH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc3BhY2UteS0yIG1iLTVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5TZWxlY3QgRGF0ZSBGaWx0ZXI8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZCB0ZXh0LXNtXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTZWxlY3RGaWx0ZXIoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUb2RheVwiPlRvZGF5PC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiWWVzdGVyZGF5XCI+WWVzdGVyZGF5PC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVHdvRGF5c0Fnb1wiPlR3byBEYXlzIEFnbzwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRoaXNXZWVrXCI+VGhpcyBXZWVrPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTGFzdFdlZWtcIj5MYXN0IFdlZWs8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzTW9udGhcIj5UaGlzIE1vbnRoPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTGFzdE1vbnRoXCI+TGFzdCBNb250aDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRoaXNZZWFyXCI+VGhpcyBZZWFyPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQWxsXCI+QWxsPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ3VzdG9tXCI+Q3VzdG9tPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAge3NlbGVjdGVkTGFiZWwgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkRhdGU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0Py52YWx1ZT8uc3BsaXQoXCJUXCIpWzBdKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy14c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBBbGxcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgdy00IGgtNCBtYi0zXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdEFsbH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0QWxsKGNoZWNrZWQpOyAvLyBTZXQgZ2xvYmFsIGNoZWNrYm94IHN0YXRlXHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8vIExvb3AgdGhyb3VnaCBhbGwgZmlsdGVyZWQgdXNlcnMgYW5kIGFwcGx5IHRoZSBzZWxlY3Rpb25cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGFbdXNlci5faWRdID0ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGNoZWNrZWQsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci51c2VyUGhvbmUsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBncm91cElkOiB1c2VyLmdyb3VwSWQ/Ll9pZCB8fCB1c2VyLmdyb3VwSWQsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHVwZGF0ZWREYXRhKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIHNpemU9ezIwfSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e0F1Y3Rpb25jb2x1bW5zfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQmlkIFdpbm5lclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuLy8gICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tncm91cEZpbHRlcl19XHJcbi8vICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BCaWQgV2lubmVyLmNzdmB9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuY29uc3QgQ3VzdG9tZXJXZWxjb21lV2hhdHNhcHBNZXNzYWdlID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt1c2Vyc0RhdGEsIHNldFVzZXJzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3VwRmlsdGVyLCBzZXRHcm91cEZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWN0aXZlVXNlckRhdGEsIHNldEFjdGl2ZVVzZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW25vdGlmaWVyLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgdG9kYXlTdHJpbmcgPSB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiQWxsXCIpO1xyXG5cclxuICAvLyAtLS0gREFURSBGSUxURVIgSEFORExFUiAtLS1cclxuICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpO1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKHRvZGF5KSk7XHJcbiAgICAgIHNldEZyb21EYXRlKFwiXCIpO1xyXG4gICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpKTtcclxuICAgICAgc2V0RnJvbURhdGUoXCJcIik7XHJcbiAgICAgIHNldFRvRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVHdvRGF5c0Fnb1wiKSB7XHJcbiAgICAgIGNvbnN0IHR3b0RheXNBZ28gPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHR3b0RheXNBZ28uc2V0RGF0ZSh0d29EYXlzQWdvLmdldERhdGUoKSAtIDIpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh0d29EYXlzQWdvKSk7XHJcbiAgICAgIHNldEZyb21EYXRlKFwiXCIpO1xyXG4gICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNXZWVrXCIpIHtcclxuICAgICAgY29uc3QgZGF5ID0gdG9kYXkuZ2V0RGF5KCk7XHJcbiAgICAgIGNvbnN0IGRpZmZUb01vbmRheSA9IGRheSA9PT0gMCA/IDYgOiBkYXkgLSAxO1xyXG4gICAgICBjb25zdCBtb25kYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIG1vbmRheS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIGRpZmZUb01vbmRheSk7XHJcbiAgICAgIGNvbnN0IHN1bmRheSA9IG5ldyBEYXRlKG1vbmRheSk7XHJcbiAgICAgIHN1bmRheS5zZXREYXRlKG1vbmRheS5nZXREYXRlKCkgKyA2KTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShtb25kYXkpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoc3VuZGF5KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdFdlZWtcIikge1xyXG4gICAgICBjb25zdCBkYXkgPSB0b2RheS5nZXREYXkoKTtcclxuICAgICAgY29uc3QgZGlmZlRvTW9uZGF5ID0gZGF5ID09PSAwID8gNiA6IGRheSAtIDE7XHJcbiAgICAgIGNvbnN0IHRoaXNNb25kYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHRoaXNNb25kYXkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSBkaWZmVG9Nb25kYXkpO1xyXG4gICAgICBjb25zdCBsYXN0TW9uZGF5ID0gbmV3IERhdGUodGhpc01vbmRheSk7XHJcbiAgICAgIGxhc3RNb25kYXkuc2V0RGF0ZSh0aGlzTW9uZGF5LmdldERhdGUoKSAtIDcpO1xyXG4gICAgICBjb25zdCBsYXN0U3VuZGF5ID0gbmV3IERhdGUobGFzdE1vbmRheSk7XHJcbiAgICAgIGxhc3RTdW5kYXkuc2V0RGF0ZShsYXN0TW9uZGF5LmdldERhdGUoKSArIDYpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKGxhc3RNb25kYXkpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUobGFzdFN1bmRheSkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkFsbFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUoMjAwMCwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IHRvZGF5O1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGhhbmRsZVNlbGVjdEZpbHRlcihcIkFsbFwiKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIC0tLSBGRVRDSCBEQVRBIC0tLVxyXG4gIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbnJvbGwvZ2V0LWVucm9sbFwiKTtcclxuICAgICAgY29uc3QgdXNlcnNMaXN0ID0gW107XHJcbiAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuXHJcbiAgICAgIHJlcy5kYXRhPy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaWQgPSB1c2VyLl9pZDtcclxuICAgICAgICBjb25zdCB1c2VyTmFtZSA9IHVzZXI/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIlVua25vd25cIjtcclxuICAgICAgICBjb25zdCB1c2VyUGhvbmUgPSB1c2VyPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJcIjtcclxuICAgICAgICBjb25zdCBncm91cE5hbWUgPSB1c2VyPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbERhdGUgPSB1c2VyPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwiO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gdXNlcj8uZ3JvdXBfaWQ/LmNyZWF0ZWRBdFxyXG4gICAgICAgICAgPyB1c2VyLmdyb3VwX2lkLmNyZWF0ZWRBdC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgIDogZW5yb2xsRGF0ZTtcclxuXHJcbiAgICAgICAgdXNlcnNMaXN0LnB1c2goe1xyXG4gICAgICAgICAgX2lkOiBpZCxcclxuICAgICAgICAgIHVzZXJOYW1lLFxyXG4gICAgICAgICAgdXNlclBob25lLFxyXG4gICAgICAgICAgZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgZW5yb2xsbWVudERhdGUsXHJcbiAgICAgICAgICBlbnJvbGxEYXRlLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0ZW1wQWN0aXZlW2lkXSA9IHsgaW5mbzogeyBzdGF0dXM6IGZhbHNlIH0gfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRVc2Vyc0RhdGEodXNlcnNMaXN0KTtcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEodGVtcEFjdGl2ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyAtLS0gRklMVEVSRUQgVVNFUlMgLS0tXHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3Qgbm9ybWFsaXplRGF0ZSA9IChkYXRlKSA9PlxyXG4gICAgICBkYXRlID8gbmV3IERhdGUoZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIikgOiBcIlwiO1xyXG5cclxuICAgIHJldHVybiB1c2Vyc0RhdGFcclxuICAgICAgLmZpbHRlcigodSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoR3JvdXAgPSBncm91cEZpbHRlciA/IHUuZ3JvdXBOYW1lID09PSBncm91cEZpbHRlciA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgZW5yb2xsRGF0ZSA9IG5vcm1hbGl6ZURhdGUodS5lbnJvbGxEYXRlKTtcclxuXHJcbiAgICAgICAgY29uc3QgbWF0Y2hGcm9tID1cclxuICAgICAgICAgIGZyb21EYXRlICYmIGVucm9sbERhdGUgPyBlbnJvbGxEYXRlID49IGZyb21EYXRlIDogdHJ1ZTtcclxuICAgICAgICBjb25zdCBtYXRjaFRvID0gdG9EYXRlICYmIGVucm9sbERhdGUgPyBlbnJvbGxEYXRlIDw9IHRvRGF0ZSA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hFeGFjdCA9XHJcbiAgICAgICAgICBzZWxlY3RlZERhdGUgJiYgZW5yb2xsRGF0ZSA/IGVucm9sbERhdGUgPT09IHNlbGVjdGVkRGF0ZSA6IHRydWU7XHJcblxyXG4gICAgICAgIHJldHVybiBtYXRjaEdyb3VwICYmIG1hdGNoRnJvbSAmJiBtYXRjaFRvICYmIG1hdGNoRXhhY3Q7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5tYXAoKHVzZXIsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAuLi51c2VyLFxyXG4gICAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIGNoZWNrQm94czogKFxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgW3VzZXIuX2lkXToge1xyXG4gICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci51c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICAgIGlzU2VsZWN0ZWQsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcbiAgfSwgW3VzZXJzRGF0YSwgZ3JvdXBGaWx0ZXIsIGZyb21EYXRlLCB0b0RhdGUsIHNlbGVjdGVkRGF0ZSwgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgLy8gLS0tIFNFTEVDVCBBTEwgQ0hFQ0tCT1ggLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGFsbENoZWNrZWQgPVxyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmxlbmd0aCA+IDAgJiZcclxuICAgICAgZmlsdGVyZWRVc2Vycy5ldmVyeSgodXNlcikgPT4gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXMpO1xyXG4gICAgc2V0U2VsZWN0QWxsKGFsbENoZWNrZWQpO1xyXG4gIH0sIFtmaWx0ZXJlZFVzZXJzLCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICAvLyAtLS0gU0VORCBXSEFUU0FQUCAtLS1cclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyBWaWEgV2hhdHNhcHAuLi5cIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogXCJQcm9jZXNzaW5nLi4uXCIsXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHZpc2libGVBY3RpdmVVc2VycyA9IHt9O1xyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgICBpZiAodXNlci5pc1NlbGVjdGVkICYmIGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXSkge1xyXG4gICAgICAgICAgdmlzaWJsZUFjdGl2ZVVzZXJzW3VzZXIuX2lkXSA9IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvd2hhdHNhcHAvY3VzdG9tZXItd2VsY29tZS1tZXNzYWdlXCIsIHtcclxuICAgICAgICByZWNlaXZlcnM6IHZpc2libGVBY3RpdmVVc2VycyxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBuZXdBY3RpdmVVc2VyRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkgZGVsZXRlIG5ld0FjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKG5ld0FjdGl2ZVVzZXJEYXRhKTtcclxuXHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIE1lc3NhZ2VzIFNlbnQgU3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIFNlbmQgV2hhdHNhcHBcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyLm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZpc2libGVTZWxlY3RlZENvdW50ID0gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHUpID0+IHUuaXNTZWxlY3RlZCkubGVuZ3RoO1xyXG5cclxuICBjb25zdCBncm91cE9wdGlvbnMgPSBbXHJcbiAgICAuLi5uZXcgU2V0KFxyXG4gICAgICB1c2Vyc0RhdGFcclxuICAgICAgICAuZmlsdGVyKCh1KSA9PiB1Lmdyb3VwTmFtZSAmJiB1Lmdyb3VwTmFtZS50cmltKCkgIT09IFwiXCIpXHJcbiAgICAgICAgLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpXHJcbiAgICApLFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdCBVc2VyXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbERhdGVcIiwgaGVhZGVyOiBcIkpvaW5lZCBPblwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIvPlxyXG4gICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG10LTJcIj5cclxuICAgICAgICAgICAgICBDdXN0b21lciBXZWxjb21lIE1lc3NhZ2VcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNiBtdC04IG1iLTZcIj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC0xMDAgcm91bmRlZC14bCBwLTYgc2hhZG93IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgPGRpdj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+VG90YWwgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC12aW9sZXQtNzAwXCI+XHJcbiAgICAgICAge2ZpbHRlcmVkVXNlcnMubGVuZ3RofVxyXG4gICAgICA8L3A+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxGYVVzZXJzIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCB0ZXh0LTR4bFwiIC8+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHJvdW5kZWQteGwgcC02IHNoYWRvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlNlbGVjdGVkIEN1c3RvbWVyczwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50fVxyXG4gICAgICA8L3A+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxGYUNoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtNHhsXCIgLz5cclxuICA8L2Rpdj5cclxuPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTYgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgey8qIEdyb3VwIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwRmlsdGVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBEYXRlIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2VsZWN0IERhdGUgRmlsdGVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcm91bmRlZCB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZVNlbGVjdEZpbHRlcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVG9kYXlcIj5Ub2RheTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJZZXN0ZXJkYXlcIj5ZZXN0ZXJkYXk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVHdvRGF5c0Fnb1wiPlR3byBEYXlzIEFnbzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzV2Vla1wiPlRoaXMgV2Vlazwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMYXN0V2Vla1wiPkxhc3QgV2Vlazwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzTW9udGhcIj5UaGlzIE1vbnRoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RNb250aFwiPkxhc3QgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVGhpc1llYXJcIj5UaGlzIFllYXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQWxsXCI+QWxsPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIERhdGUgUGlja2VyICovfVxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkTGFiZWwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+RGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQ/LnZhbHVlPy5zcGxpdChcIlRcIilbMF0pXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFNlbGVjdCBBbGwgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiB3LTQgaC00XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFt1Ll9pZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1LnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdS5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdS51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh1cGRhdGVkKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBXaGF0c0FwcCBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctZ3JlZW4tNzAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwIGZsZXggaXRlbXMtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2BNZXNzYWdlIHdpbGwgYmUgc2VudCB0byAke3Zpc2libGVTZWxlY3RlZENvdW50fSBjdXN0b21lcnNgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudH1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBUYWJsZSAqL31cclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17QXVjdGlvbmNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkN1c3RvbWVyIFdlbGNvbWUgTWVzc2FnZVwiXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXJfV2VsY29tZV9NZXNzYWdlLmNzdlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgIFxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDdXN0b21lcldlbGNvbWVXaGF0c2FwcE1lc3NhZ2U7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DdXN0b21lcldlbGNvbWVXaGF0c2FwcE1lc3NhZ2UuanN4In0=