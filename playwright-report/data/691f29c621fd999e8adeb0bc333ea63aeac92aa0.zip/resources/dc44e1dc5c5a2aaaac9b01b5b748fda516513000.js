import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/printFormats/PigmyPreclosurePrint.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import imageInput from "/src/assets/images/Agent.png?import";
const PigmyPreclosurePrint = () => {
  _s();
  const { id } = useParams();
  const [pigmy, setPigmy] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!id) return;
    const fetchPigmy = async () => {
      try {
        setLoading(true);
        const response = await api.get(`/v1/admin/pigmes/print/${id}`);
        if (response.data) {
          setPigmy(response.data?.data);
        } else {
          setPigmy(null);
        }
      } catch (error) {
        console.error("Error fetching pigmy details:", error);
        setPigmy(null);
      } finally {
        setLoading(false);
      }
    };
    fetchPigmy();
  }, [id]);
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900 mx-auto" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
        lineNumber: 40,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-600", children: "Loading pigmy details..." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
        lineNumber: 41,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
      lineNumber: 39,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this);
  }
  if (!pigmy) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-red-600 text-lg", children: "Pigmy details not found" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
      lineNumber: 51,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
      lineNumber: 50,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this);
  }
  const totalAmount = pigmy.payable_amount || 0;
  const maturityInterest = pigmy.maturity_interest || 0;
  const duration = pigmy.duration || 0;
  const startDate = new Date(pigmy.start_date);
  const endDate = new Date(startDate);
  endDate.setMonth(endDate.getMonth() + duration);
  const preMaturedInterestRate = (maturityInterest * 0.75).toFixed(2);
  const preMaturedAmount = (totalAmount * (1 + preMaturedInterestRate / 100)).toFixed(2);
  const formatDate = (date) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  };
  const calculateCompletedMonths = (startDate2, endDate2) => {
    if (!startDate2 || !endDate2) return 0;
    const start = new Date(startDate2);
    const end = new Date(endDate2);
    const months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
    return Math.max(months, 0);
  };
  const completedMonths = calculateCompletedMonths(
    pigmy?.start_date,
    pigmy?.closure_date
  );
  const sections = [
    {
      title: "Pigmy Details",
      fields: [
        { label: "Pigmy ID", value: pigmy?.pigme_id },
        { label: "Customer Name", value: pigmy?.customer?.full_name },
        { label: "Phone Number", value: pigmy?.customer?.phone_number },
        { label: "Payment Details", value: pigmy?.maturity_period?.toUpperCase() + " -- ₹" + pigmy?.payable_amount },
        { label: "Start Date", value: formatDate(pigmy?.start_date) },
        { label: "Duration", value: `${duration} Months` },
        { label: "Completed Months", value: `${completedMonths} Months` },
        { label: "Closure Type", value: `${pigmy?.closure_type}` }
      ]
    },
    {
      title: pigmy?.closure_type === "PRE-MATURED" ? "Premature Settlement Calculation" : "Settlement Calculation",
      fields: pigmy?.closure_type === "PRE-MATURED" ? [
        { label: "Total Paid Amount", value: `₹${Number(pigmy?.total_paid).toLocaleString("en-IN")}` },
        { label: "Premature Deduction Interest", value: `${pigmy?.pre_matured_interest}%` },
        { label: "Preclosure Amount", value: `₹${Number(pigmy?.maturity_amount).toLocaleString("en-IN")}` }
      ] : [
        { label: "Total Paid Amount", value: `₹${Number(pigmy?.total_paid).toLocaleString("en-IN")}` },
        { label: "Maturity Interest Rate", value: `${pigmy?.maturity_interest}%` },
        { label: "Settlement Amount", value: `₹${Number(pigmy?.maturity_amount).toLocaleString("en-IN")}` }
      ]
    }
  ];
  const generateAndOpenPDF = (downloadOnly = false) => {
    const doc = new jsPDF("p", "mm", "a4");
    const safeText = (v) => v ? String(v) : "N/A";
    let y = 65;
    doc.addImage(imageInput, "PNG", 90, 8, 30, 30);
    doc.setFillColor(0, 38, 124);
    doc.rect(0, 40, 210, 15, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.text("Pigmy Preclosure Form", 105, 49, { align: "center" });
    const drawField = (label, value, x, y2) => {
      doc.setDrawColor(220, 224, 230);
      doc.rect(x, y2, 80, 8);
      doc.setTextColor(0, 38, 124);
      doc.setFontSize(9);
      doc.text(label + ":", x + 2, y2 + 5);
      doc.setTextColor(33, 33, 33);
      doc.text(safeText(value), x + 40, y2 + 5);
      return y2 + 12;
    };
    sections.forEach((sec) => {
      doc.setFillColor(0, 38, 124);
      doc.rect(15, y, 180, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(11);
      doc.text(sec.title, 20, y + 5);
      y += 15;
      sec.fields.forEach((f, i) => {
        const x = i % 2 === 0 ? 15 : 110;
        y = drawField(f.label, f.value, x, i % 2 ? y - 12 : y);
      });
      y += 5;
    });
    doc.setFontSize(10);
    doc.text("I hereby declare that the above pigmy information is true and correct.", 105, y + 10, { align: "center" });
    const signatures = [
      { label: "Customer Signature", x: 30 },
      { label: "Authorized Signatory", x: 80 },
      { label: "Date", x: 140 }
    ];
    signatures.forEach((sig) => {
      doc.setDrawColor(0, 0, 0);
      doc.rect(sig.x, y + 25, 50, 15);
      doc.setFontSize(9);
      doc.text(sig.label, sig.x + 25, y + 33, { align: "center" });
    });
    doc.setFillColor(0, 38, 124);
    doc.rect(0, 280, 210, 15, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.text("VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED", 105, 288, { align: "center" });
    doc.setTextColor(100, 100, 100);
    doc.setFontSize(7);
    doc.text(`Ref: PRECL-${pigmy?.pigme_id || "N/A"}-${(/* @__PURE__ */ new Date()).getFullYear()}`, 195, 278, { align: "right" });
    if (downloadOnly) {
      doc.save(`Preclosure_${pigmy?.pigme_id || "Form"}.pdf`);
    } else {
      const pdfBlob = doc.output("blob");
      const pdfUrl = URL.createObjectURL(pdfBlob);
      window.open(pdfUrl, "_blank");
    }
  };
  const getStatusColor = (status) => {
    if (!status) return "bg-gray-100 text-gray-800";
    const statusMap = {
      "APPROVED": "bg-green-100 text-green-800",
      "REQUESTED": "bg-yellow-100 text-yellow-800",
      "COMPLETED": "bg-blue-100 text-blue-800",
      "CLOSED": "bg-gray-100 text-gray-800"
    };
    return statusMap[status.toUpperCase()] || "bg-gray-100 text-gray-800";
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("style", { children: `
          @media print {
            body * {
              visibility: hidden;
            }
            #printable-area, #printable-area * {
              visibility: visible;
            }
            #printable-area {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              margin: 0;
              padding: 0;
              background: white !important;
            }
            .no-print {
              display: none !important;
            }
            /* Force background colors and text colors */
            .bg-blue-900, .bg-blue-900 * {
              background-color: #1e3a8a !important;
              color: white !important;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            .bg-amber-500, .bg-amber-500 * {
              background-color: #f59e0b !important;
              color: white !important;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            .bg-blue-50 {
              background-color: #eff6ff !important;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            .bg-yellow-50 {
              background-color: #fffbeb !important;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            .border-blue-900 {
              border-color: #1e3a8a !important;
            }
            .text-blue-900 {
              color: #1e3a8a !important;
            }
            .text-white {
              color: white !important;
            }
            .text-blue-100 {
              color: #dbeafe !important;
            }
            .text-blue-200 {
              color: #bfdbfe !important;
            }
            .text-blue-300 {
              color: #93c5fd !important;
            }
            .text-amber-700 {
              color: #b45309 !important;
            }
            .text-red-600 {
              color: #dc2626 !important;
            }
            /* Ensure borders print */
            .border {
              border: 1px solid #000 !important;
            }
            .border-black {
              border-color: black !important;
            }
          }
        ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
      lineNumber: 211,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-200 p-5 min-h-screen flex flex-col items-center", id: "printable-area", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-lg rounded-lg overflow-hidden w-full max-w-4xl mb-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-900 text-white rounded-t-xl p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: imageInput,
                alt: "Company Logo",
                className: "w-24 h-24 object-contain bg-white rounded-lg p-2"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 297,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 296,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold uppercase tracking-wide", children: "VIJAYA VINAYAK CHITFUNDS PRIVATE LIMITED" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 304,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-100 mt-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "CIN:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                  lineNumber: 308,
                  columnNumber: 19
                }, this),
                " U65999KA2022PTC161858"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 307,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-100 leading-6 mt-1", children: "No. 11/36-25, 2nd Main, Kathriguppe Main Road, Bangalore, Karnataka - 560070" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 310,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 303,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 295,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-t border-blue-700 my-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 316,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold", children: "Pigmy Preclosure Form" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 318,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-200 mt-2", children: [
              "Generated on",
              " ",
              (/* @__PURE__ */ new Date()).toLocaleString("en-IN", {
                dateStyle: "medium",
                timeStyle: "short"
              })
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 319,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 317,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
          lineNumber: 294,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
          sections.map(
            (section, sectionIndex) => /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: `${sectionIndex === 1 ? "bg-amber-500" : "bg-blue-900"} text-white p-2 mb-3 rounded-t`, children: /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold", children: section.title }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 334,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 333,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4", children: section.fields.map(
                (field, fieldIndex) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `border rounded p-3 ${field.label === "Preclosure Amount" || field.label === "Settlement Amount" || field.label === "Preclosure Amount" ? "border-amber-500 bg-amber-50" : "border-gray-300 bg-white"}`,
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: `text-[12px] font-medium ${field.label === "Preclosure Amount" || field.label === "Settlement Amount" ? "text-amber-700" : "text-blue-900"}`, children: [
                        field.label,
                        ":"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                        lineNumber: 345,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: `font-semibold ${field.label === "Preclosure Amount" || field.label === "Settlement Amount" ? "text-2xl text-red-600" : "text-gray-800"}`, children: field.value || "N/A" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                        lineNumber: 351,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  fieldIndex,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                    lineNumber: 338,
                    columnNumber: 17
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 336,
                columnNumber: 17
              }, this)
            ] }, sectionIndex, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 332,
              columnNumber: 13
            }, this)
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "my-6 p-4 bg-yellow-50 border border-yellow-300 rounded text-sm text-gray-700", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-800 mb-2", children: "Terms & Conditions for Pigmy Closure" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 365,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-5 space-y-1", children: [
              /* @__PURE__ */ jsxDEV("li", { children: "Pigmy account closure is subject to verification of all deposited amounts and customer details." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 367,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Interest will be calculated as per the prevailing scheme rules and company policy." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 368,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "In case of premature closure, applicable interest deductions/penalties will be charged." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 369,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Any outstanding dues, loans, or adjustments will be deducted from the closure amount." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 370,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "The final settlement amount will be processed only after approval from authorized officials." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 371,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "Once closed, the pigmy account cannot be reopened under the same account number." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 372,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: "The company reserves the right to modify terms as per financial regulations and internal policy." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 373,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 366,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 364,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-center my-6 p-4 bg-blue-50 rounded border border-blue-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-700", children: "I hereby declare that the above pigmy information is true and correct." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 379,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 378,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4 my-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "border border-black h-16 flex items-center justify-center flex-col", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm", children: "Customer Signature" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 385,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-400 w-32 mt-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 386,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 384,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "border border-black h-16 flex items-center justify-center flex-col", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm", children: "Authorized Signatory" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 389,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-400 w-32 mt-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 390,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 388,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "border border-black h-16 flex items-center justify-center flex-col", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm", children: "Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 393,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-400 w-32 mt-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
                lineNumber: 394,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
              lineNumber: 392,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 383,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
          lineNumber: 330,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-900 text-white text-center p-1 text-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { children: "VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 401,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-blue-300 text-xs mt-1", children: [
            "Ref: PRECL-",
            pigmy?.pigme_id || "N/A",
            "-",
            (/* @__PURE__ */ new Date()).getFullYear()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 402,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-blue-300 text-xs mt-1 italic", children: "*** This is a computer generated document, no signature is required ***" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
            lineNumber: 405,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
          lineNumber: 400,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
        lineNumber: 292,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-4 no-print", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-6 rounded transition-colors duration-200",
          onClick: () => window.print(),
          children: "Print This Page"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
          lineNumber: 425,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
        lineNumber: 412,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
      lineNumber: 290,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx",
    lineNumber: 209,
    columnNumber: 5
  }, this);
};
_s(PigmyPreclosurePrint, "hOXfWLHfX4y4ppD+gpovoPIIu/8=", false, function() {
  return [useParams];
});
_c = PigmyPreclosurePrint;
export default PigmyPreclosurePrint;
var _c;
$RefreshReg$(_c, "PigmyPreclosurePrint");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/PigmyPreclosurePrint.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNVLFNBeUtOLFVBektNOzJCQXZDVjtBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsdUJBQXVCQSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFQyxHQUFHLElBQUlOLFVBQVU7QUFDekIsUUFBTSxDQUFDTyxPQUFPQyxRQUFRLElBQUlULFNBQVMsSUFBSTtBQUN2QyxRQUFNLENBQUNVLFNBQVNDLFVBQVUsSUFBSVgsU0FBUyxJQUFJO0FBRTNDWSxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNMLEdBQUk7QUFFVCxVQUFNTSxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGRixtQkFBVyxJQUFJO0FBRWYsY0FBTUcsV0FBVyxNQUFNWixJQUFJYSxJQUFJLDBCQUEwQlIsRUFBRSxFQUFFO0FBQzdELFlBQUlPLFNBQVNFLE1BQU07QUFDakJQLG1CQUFTSyxTQUFTRSxNQUFNQSxJQUFJO0FBQUEsUUFDOUIsT0FBTztBQUNMUCxtQkFBUyxJQUFJO0FBQUEsUUFDZjtBQUFBLE1BQ0YsU0FBU1EsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcERSLGlCQUFTLElBQUk7QUFBQSxNQUNmLFVBQUM7QUFDQ0UsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUVBRSxlQUFXO0FBQUEsRUFDYixHQUFHLENBQUNOLEVBQUUsQ0FBQztBQUVQLE1BQUlHLFNBQVM7QUFDWCxXQUNFLHVCQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw0RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdGO0FBQUEsTUFDeEYsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQix3Q0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLFNBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLEVBRUo7QUFFQSxNQUFJLENBQUNGLE9BQU87QUFDVixXQUNFLHVCQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxTQUFJLFdBQVUsZUFDYixpQ0FBQyxPQUFFLFdBQVUsd0JBQXVCLHVDQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJELEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLEVBRUo7QUFHQSxRQUFNVyxjQUFjWCxNQUFNWSxrQkFBa0I7QUFDNUMsUUFBTUMsbUJBQW1CYixNQUFNYyxxQkFBcUI7QUFDcEQsUUFBTUMsV0FBV2YsTUFBTWUsWUFBWTtBQUNuQyxRQUFNQyxZQUFZLElBQUlDLEtBQUtqQixNQUFNa0IsVUFBVTtBQUMzQyxRQUFNQyxVQUFVLElBQUlGLEtBQUtELFNBQVM7QUFDbENHLFVBQVFDLFNBQVNELFFBQVFFLFNBQVMsSUFBSU4sUUFBUTtBQUU5QyxRQUFNTywwQkFBMEJULG1CQUFtQixNQUFNVSxRQUFRLENBQUM7QUFDbEUsUUFBTUMsb0JBQW9CYixlQUFlLElBQUtXLHlCQUF5QixNQUFPQyxRQUFRLENBQUM7QUFFdkYsUUFBTUUsYUFBYUEsQ0FBQ0MsU0FBUztBQUMzQixRQUFJLENBQUNBLEtBQU0sUUFBTztBQUNsQixXQUFPLElBQUlULEtBQUtTLElBQUksRUFBRUMsbUJBQW1CLFNBQVM7QUFBQSxNQUNoREMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsSUFDUixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1DLDJCQUEyQkEsQ0FBQ2YsWUFBV0csYUFBWTtBQUN2RCxRQUFJLENBQUNILGNBQWEsQ0FBQ0csU0FBUyxRQUFPO0FBRW5DLFVBQU1hLFFBQVEsSUFBSWYsS0FBS0QsVUFBUztBQUNoQyxVQUFNaUIsTUFBTSxJQUFJaEIsS0FBS0UsUUFBTztBQUU1QixVQUFNZSxVQUNIRCxJQUFJRSxZQUFZLElBQUlILE1BQU1HLFlBQVksS0FBSyxNQUMzQ0YsSUFBSVosU0FBUyxJQUFJVyxNQUFNWCxTQUFTO0FBRW5DLFdBQU9lLEtBQUtDLElBQUlILFFBQVEsQ0FBQztBQUFBLEVBQzNCO0FBR0EsUUFBTUksa0JBQWtCUDtBQUFBQSxJQUN0Qi9CLE9BQU9rQjtBQUFBQSxJQUNQbEIsT0FBT3VDO0FBQUFBLEVBQ1Q7QUFFQSxRQUFNQyxXQUFXO0FBQUEsSUFDZjtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsUUFDTixFQUFFQyxPQUFPLFlBQVlDLE9BQU81QyxPQUFPNkMsU0FBUztBQUFBLFFBQzVDLEVBQUVGLE9BQU8saUJBQWlCQyxPQUFPNUMsT0FBTzhDLFVBQVVDLFVBQVU7QUFBQSxRQUM1RCxFQUFFSixPQUFPLGdCQUFnQkMsT0FBTzVDLE9BQU84QyxVQUFVRSxhQUFhO0FBQUEsUUFDOUQsRUFBRUwsT0FBTyxtQkFBbUJDLE9BQU81QyxPQUFPaUQsaUJBQWlCQyxZQUFZLElBQUksVUFBVWxELE9BQU9ZLGVBQWU7QUFBQSxRQUMzRyxFQUFFK0IsT0FBTyxjQUFjQyxPQUFPbkIsV0FBV3pCLE9BQU9rQixVQUFVLEVBQUU7QUFBQSxRQUM1RCxFQUFFeUIsT0FBTyxZQUFZQyxPQUFPLEdBQUc3QixRQUFRLFVBQVU7QUFBQSxRQUNqRCxFQUFFNEIsT0FBTyxvQkFBb0JDLE9BQU8sR0FBR04sZUFBZSxVQUFVO0FBQUEsUUFDaEUsRUFBRUssT0FBTyxnQkFBZ0JDLE9BQU8sR0FBRzVDLE9BQU9tRCxZQUFZLEdBQUc7QUFBQSxNQUFDO0FBQUEsSUFFOUQ7QUFBQSxJQUNBO0FBQUEsTUFDRVYsT0FBT3pDLE9BQU9tRCxpQkFBaUIsZ0JBQWdCLHFDQUFxQztBQUFBLE1BQ3BGVCxRQUFRMUMsT0FBT21ELGlCQUFpQixnQkFDNUI7QUFBQSxRQUNBLEVBQUVSLE9BQU8scUJBQXFCQyxPQUFPLElBQUlRLE9BQU9wRCxPQUFPcUQsVUFBVSxFQUFFQyxlQUFlLE9BQU8sQ0FBQyxHQUFHO0FBQUEsUUFDN0YsRUFBRVgsT0FBTyxnQ0FBZ0NDLE9BQU8sR0FBRzVDLE9BQU91RCxvQkFBb0IsSUFBSTtBQUFBLFFBQ2xGLEVBQUVaLE9BQU8scUJBQXFCQyxPQUFPLElBQUlRLE9BQU9wRCxPQUFPd0QsZUFBZSxFQUFFRixlQUFlLE9BQU8sQ0FBQyxHQUFHO0FBQUEsTUFBQyxJQUVuRztBQUFBLFFBQ0EsRUFBRVgsT0FBTyxxQkFBcUJDLE9BQU8sSUFBSVEsT0FBT3BELE9BQU9xRCxVQUFVLEVBQUVDLGVBQWUsT0FBTyxDQUFDLEdBQUc7QUFBQSxRQUM3RixFQUFFWCxPQUFPLDBCQUEwQkMsT0FBTyxHQUFHNUMsT0FBT2MsaUJBQWlCLElBQUk7QUFBQSxRQUN6RSxFQUFFNkIsT0FBTyxxQkFBcUJDLE9BQU8sSUFBSVEsT0FBT3BELE9BQU93RCxlQUFlLEVBQUVGLGVBQWUsT0FBTyxDQUFDLEdBQUc7QUFBQSxNQUFDO0FBQUEsSUFFekc7QUFBQSxFQUFDO0FBSUgsUUFBTUcscUJBQXFCQSxDQUFDQyxlQUFlLFVBQVU7QUFDbkQsVUFBTUMsTUFBTSxJQUFJaEUsTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUNyQyxVQUFNaUUsV0FBV0EsQ0FBQ0MsTUFBT0EsSUFBSUMsT0FBT0QsQ0FBQyxJQUFJO0FBQ3pDLFFBQUlFLElBQUk7QUFFUkosUUFBSUssU0FBU3BFLFlBQVksT0FBTyxJQUFJLEdBQUcsSUFBSSxFQUFFO0FBQzdDK0QsUUFBSU0sYUFBYSxHQUFHLElBQUksR0FBRztBQUMzQk4sUUFBSU8sS0FBSyxHQUFHLElBQUksS0FBSyxJQUFJLEdBQUc7QUFDNUJQLFFBQUlRLGFBQWEsS0FBSyxLQUFLLEdBQUc7QUFDOUJSLFFBQUlTLFlBQVksRUFBRTtBQUNsQlQsUUFBSVUsS0FBSyx5QkFBeUIsS0FBSyxJQUFJLEVBQUVDLE9BQU8sU0FBUyxDQUFDO0FBRTlELFVBQU1DLFlBQVlBLENBQUM1QixPQUFPQyxPQUFPNEIsR0FBR1QsT0FBTTtBQUN4Q0osVUFBSWMsYUFBYSxLQUFLLEtBQUssR0FBRztBQUM5QmQsVUFBSU8sS0FBS00sR0FBR1QsSUFBRyxJQUFJLENBQUM7QUFDcEJKLFVBQUlRLGFBQWEsR0FBRyxJQUFJLEdBQUc7QUFDM0JSLFVBQUlTLFlBQVksQ0FBQztBQUNqQlQsVUFBSVUsS0FBSzFCLFFBQVEsS0FBSzZCLElBQUksR0FBR1QsS0FBSSxDQUFDO0FBQ2xDSixVQUFJUSxhQUFhLElBQUksSUFBSSxFQUFFO0FBQzNCUixVQUFJVSxLQUFLVCxTQUFTaEIsS0FBSyxHQUFHNEIsSUFBSSxJQUFJVCxLQUFJLENBQUM7QUFDdkMsYUFBT0EsS0FBSTtBQUFBLElBQ2I7QUFFQXZCLGFBQVNrQyxRQUFRLENBQUNDLFFBQVE7QUFDeEJoQixVQUFJTSxhQUFhLEdBQUcsSUFBSSxHQUFHO0FBQzNCTixVQUFJTyxLQUFLLElBQUlILEdBQUcsS0FBSyxHQUFHLEdBQUc7QUFDM0JKLFVBQUlRLGFBQWEsS0FBSyxLQUFLLEdBQUc7QUFDOUJSLFVBQUlTLFlBQVksRUFBRTtBQUNsQlQsVUFBSVUsS0FBS00sSUFBSWxDLE9BQU8sSUFBSXNCLElBQUksQ0FBQztBQUM3QkEsV0FBSztBQUNMWSxVQUFJakMsT0FBT2dDLFFBQVEsQ0FBQ0UsR0FBR0MsTUFBTTtBQUMzQixjQUFNTCxJQUFJSyxJQUFJLE1BQU0sSUFBSSxLQUFLO0FBQzdCZCxZQUFJUSxVQUFVSyxFQUFFakMsT0FBT2lDLEVBQUVoQyxPQUFPNEIsR0FBR0ssSUFBSSxJQUFJZCxJQUFJLEtBQUtBLENBQUM7QUFBQSxNQUN2RCxDQUFDO0FBQ0RBLFdBQUs7QUFBQSxJQUNQLENBQUM7QUFFREosUUFBSVMsWUFBWSxFQUFFO0FBQ2xCVCxRQUFJVSxLQUFLLDBFQUEwRSxLQUFLTixJQUFJLElBQUksRUFBRU8sT0FBTyxTQUFTLENBQUM7QUFFbkgsVUFBTVEsYUFBYTtBQUFBLE1BQ2pCLEVBQUVuQyxPQUFPLHNCQUFzQjZCLEdBQUcsR0FBRztBQUFBLE1BQ3JDLEVBQUU3QixPQUFPLHdCQUF3QjZCLEdBQUcsR0FBRztBQUFBLE1BQ3ZDLEVBQUU3QixPQUFPLFFBQVE2QixHQUFHLElBQUk7QUFBQSxJQUFDO0FBRTNCTSxlQUFXSixRQUFRLENBQUNLLFFBQVE7QUFDMUJwQixVQUFJYyxhQUFhLEdBQUcsR0FBRyxDQUFDO0FBQ3hCZCxVQUFJTyxLQUFLYSxJQUFJUCxHQUFHVCxJQUFJLElBQUksSUFBSSxFQUFFO0FBQzlCSixVQUFJUyxZQUFZLENBQUM7QUFDakJULFVBQUlVLEtBQUtVLElBQUlwQyxPQUFPb0MsSUFBSVAsSUFBSSxJQUFJVCxJQUFJLElBQUksRUFBRU8sT0FBTyxTQUFTLENBQUM7QUFBQSxJQUM3RCxDQUFDO0FBRURYLFFBQUlNLGFBQWEsR0FBRyxJQUFJLEdBQUc7QUFDM0JOLFFBQUlPLEtBQUssR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHO0FBQzdCUCxRQUFJUSxhQUFhLEtBQUssS0FBSyxHQUFHO0FBQzlCUixRQUFJUyxZQUFZLENBQUM7QUFDakJULFFBQUlVLEtBQUssNkNBQTZDLEtBQUssS0FBSyxFQUFFQyxPQUFPLFNBQVMsQ0FBQztBQUNuRlgsUUFBSVEsYUFBYSxLQUFLLEtBQUssR0FBRztBQUM5QlIsUUFBSVMsWUFBWSxDQUFDO0FBQ2pCVCxRQUFJVSxLQUFLLGNBQWNyRSxPQUFPNkMsWUFBWSxLQUFLLEtBQUksb0JBQUk1QixLQUFLLEdBQUVrQixZQUFZLENBQUMsSUFBSSxLQUFLLEtBQUssRUFBRW1DLE9BQU8sUUFBUSxDQUFDO0FBRTNHLFFBQUlaLGNBQWM7QUFDaEJDLFVBQUlxQixLQUFLLGNBQWNoRixPQUFPNkMsWUFBWSxNQUFNLE1BQU07QUFBQSxJQUN4RCxPQUFPO0FBQ0wsWUFBTW9DLFVBQVV0QixJQUFJdUIsT0FBTyxNQUFNO0FBQ2pDLFlBQU1DLFNBQVNDLElBQUlDLGdCQUFnQkosT0FBTztBQUMxQ0ssYUFBT0MsS0FBS0osUUFBUSxRQUFRO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBRUEsUUFBTUssaUJBQWlCQSxDQUFDQyxXQUFXO0FBQ2pDLFFBQUksQ0FBQ0EsT0FBUSxRQUFPO0FBQ3BCLFVBQU1DLFlBQVk7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixhQUFhO0FBQUEsTUFDYixhQUFhO0FBQUEsTUFDYixVQUFVO0FBQUEsSUFDWjtBQUNBLFdBQU9BLFVBQVVELE9BQU92QyxZQUFZLENBQUMsS0FBSztBQUFBLEVBQzVDO0FBRUEsU0FDRSxtQ0FFRTtBQUFBLDJCQUFDLFdBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMkRBQTBELElBQUcsa0JBRTFFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVFQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsS0FBS3REO0FBQUFBLGdCQUNMLEtBQUk7QUFBQSxnQkFDSixXQUFVO0FBQUE7QUFBQSxjQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUc4RCxLQUpoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSw4Q0FBNkMsd0RBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDWDtBQUFBLHVDQUFDLFVBQUssV0FBVSxpQkFBZ0Isb0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DO0FBQUEsZ0JBQU87QUFBQSxtQkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLHdDQUF1Qyw0RkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLG1DQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFDL0MsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsc0JBQXFCLHFDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLFlBQ3hELHVCQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLGNBQzNCO0FBQUEsZUFDWixvQkFBSXFCLEtBQUssR0FBRXFDLGVBQWUsU0FBUztBQUFBLGdCQUNsQ3FDLFdBQVc7QUFBQSxnQkFDWEMsV0FBVztBQUFBLGNBQ2IsQ0FBQztBQUFBLGlCQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsT0FDWnBEO0FBQUFBLG1CQUFTcUQ7QUFBQUEsWUFBSSxDQUFDQyxTQUFTQyxpQkFDdEIsdUJBQUMsU0FBdUIsV0FBVSxRQUNoQztBQUFBLHFDQUFDLFNBQUksV0FBVyxHQUFHQSxpQkFBaUIsSUFBSSxpQkFBaUIsYUFBYSxrQ0FDcEUsaUNBQUMsUUFBRyxXQUFVLGlCQUFpQkQsa0JBQVFyRCxTQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1pxRCxrQkFBUXBELE9BQU9tRDtBQUFBQSxnQkFBSSxDQUFDRyxPQUFPQyxlQUMxQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFFQyxXQUFXLHNCQUFzQkQsTUFBTXJELFVBQVUsdUJBQXVCcUQsTUFBTXJELFVBQVUsdUJBQXVCcUQsTUFBTXJELFVBQVUsc0JBQzNILGlDQUNBLDBCQUEwQjtBQUFBLG9CQUc5QjtBQUFBLDZDQUFDLFNBQUksV0FBVywyQkFBMkJxRCxNQUFNckQsVUFBVSx1QkFBdUJxRCxNQUFNckQsVUFBVSxzQkFDOUYsbUJBQ0EsZUFBZSxJQUVoQnFEO0FBQUFBLDhCQUFNckQ7QUFBQUEsd0JBQU07QUFBQSwyQkFKZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFXLGlCQUFpQnFELE1BQU1yRCxVQUFVLHVCQUF1QnFELE1BQU1yRCxVQUFVLHNCQUNwRiwwQkFDQSxlQUFlLElBRWhCcUQsZ0JBQU1wRCxTQUFTLFNBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQTtBQUFBO0FBQUEsa0JBakJLcUQ7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFtQkE7QUFBQSxjQUNELEtBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBM0JRRixjQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsVUFDRDtBQUFBLFVBR0QsdUJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9DQUFtQyxvREFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxZQUNyRix1QkFBQyxRQUFHLFdBQVUsNEJBQ1o7QUFBQSxxQ0FBQyxRQUFHLCtHQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1HO0FBQUEsY0FDbkcsdUJBQUMsUUFBRyxrR0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRjtBQUFBLGNBQ3RGLHVCQUFDLFFBQUcsdUdBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkY7QUFBQSxjQUMzRix1QkFBQyxRQUFHLHFHQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlGO0FBQUEsY0FDekYsdUJBQUMsUUFBRyw0R0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRztBQUFBLGNBQ2hHLHVCQUFDLFFBQUcsZ0dBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Y7QUFBQSxjQUNwRix1QkFBQyxRQUFHLGdIQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9HO0FBQUEsaUJBUHRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxrRUFDYixpQ0FBQyxPQUFFLFdBQVUsaUJBQWdCLHNGQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRyxLQURyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUJBQXdCLGtDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGNBQzFELHVCQUFDLFNBQUksV0FBVSx3Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUJBQXdCLG9DQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBLGNBQzVELHVCQUFDLFNBQUksV0FBVSx3Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUJBQXdCLG9CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLGNBQzVDLHVCQUFDLFNBQUksV0FBVSx3Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsYUFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1FQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsaUNBQUMsU0FBSSx5REFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQzlDLHVCQUFDLFNBQUksV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFlBQzlCL0YsT0FBTzZDLFlBQVk7QUFBQSxZQUFNO0FBQUEsYUFBRSxvQkFBSTVCLEtBQUssR0FBRWtCLFlBQVk7QUFBQSxlQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQW9DLHVGQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQXBIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUhBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsc0NBYWI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTW1ELE9BQU9ZLE1BQU07QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBO0FBQUEsU0E3SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThJQTtBQUFBLE9BL05GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnT0E7QUFFSjtBQUFFcEcsR0E1YUlELHNCQUFvQjtBQUFBLFVBQ1RKLFNBQVM7QUFBQTtBQUFBMEcsS0FEcEJ0RztBQThhTixlQUFlQTtBQUFxQixJQUFBc0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUGFyYW1zIiwiYXBpIiwianNQREYiLCJpbWFnZUlucHV0IiwiUGlnbXlQcmVjbG9zdXJlUHJpbnQiLCJfcyIsImlkIiwicGlnbXkiLCJzZXRQaWdteSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwidXNlRWZmZWN0IiwiZmV0Y2hQaWdteSIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsInRvdGFsQW1vdW50IiwicGF5YWJsZV9hbW91bnQiLCJtYXR1cml0eUludGVyZXN0IiwibWF0dXJpdHlfaW50ZXJlc3QiLCJkdXJhdGlvbiIsInN0YXJ0RGF0ZSIsIkRhdGUiLCJzdGFydF9kYXRlIiwiZW5kRGF0ZSIsInNldE1vbnRoIiwiZ2V0TW9udGgiLCJwcmVNYXR1cmVkSW50ZXJlc3RSYXRlIiwidG9GaXhlZCIsInByZU1hdHVyZWRBbW91bnQiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsIm1vbnRoIiwieWVhciIsImNhbGN1bGF0ZUNvbXBsZXRlZE1vbnRocyIsInN0YXJ0IiwiZW5kIiwibW9udGhzIiwiZ2V0RnVsbFllYXIiLCJNYXRoIiwibWF4IiwiY29tcGxldGVkTW9udGhzIiwiY2xvc3VyZV9kYXRlIiwic2VjdGlvbnMiLCJ0aXRsZSIsImZpZWxkcyIsImxhYmVsIiwidmFsdWUiLCJwaWdtZV9pZCIsImN1c3RvbWVyIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwibWF0dXJpdHlfcGVyaW9kIiwidG9VcHBlckNhc2UiLCJjbG9zdXJlX3R5cGUiLCJOdW1iZXIiLCJ0b3RhbF9wYWlkIiwidG9Mb2NhbGVTdHJpbmciLCJwcmVfbWF0dXJlZF9pbnRlcmVzdCIsIm1hdHVyaXR5X2Ftb3VudCIsImdlbmVyYXRlQW5kT3BlblBERiIsImRvd25sb2FkT25seSIsImRvYyIsInNhZmVUZXh0IiwidiIsIlN0cmluZyIsInkiLCJhZGRJbWFnZSIsInNldEZpbGxDb2xvciIsInJlY3QiLCJzZXRUZXh0Q29sb3IiLCJzZXRGb250U2l6ZSIsInRleHQiLCJhbGlnbiIsImRyYXdGaWVsZCIsIngiLCJzZXREcmF3Q29sb3IiLCJmb3JFYWNoIiwic2VjIiwiZiIsImkiLCJzaWduYXR1cmVzIiwic2lnIiwic2F2ZSIsInBkZkJsb2IiLCJvdXRwdXQiLCJwZGZVcmwiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJ3aW5kb3ciLCJvcGVuIiwiZ2V0U3RhdHVzQ29sb3IiLCJzdGF0dXMiLCJzdGF0dXNNYXAiLCJkYXRlU3R5bGUiLCJ0aW1lU3R5bGUiLCJtYXAiLCJzZWN0aW9uIiwic2VjdGlvbkluZGV4IiwiZmllbGQiLCJmaWVsZEluZGV4IiwicHJpbnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQaWdteVByZWNsb3N1cmVQcmludC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi8uLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBqc1BERiBmcm9tIFwianNwZGZcIjtcclxuaW1wb3J0IGltYWdlSW5wdXQgZnJvbSBcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvQWdlbnQucG5nXCI7XHJcblxyXG5jb25zdCBQaWdteVByZWNsb3N1cmVQcmludCA9ICgpID0+IHtcclxuICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCBbcGlnbXksIHNldFBpZ215XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFpZCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGZldGNoUGlnbXkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vcGlnbWVzL3ByaW50LyR7aWR9YCk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEpIHtcclxuICAgICAgICAgIHNldFBpZ215KHJlc3BvbnNlLmRhdGE/LmRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRQaWdteShudWxsKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBpZ215IGRldGFpbHM6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRQaWdteShudWxsKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFBpZ215KCk7XHJcbiAgfSwgW2lkXSk7XHJcblxyXG4gIGlmIChsb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEyIHctMTIgYm9yZGVyLWItMiBib3JkZXItYmx1ZS05MDAgbXgtYXV0b1wiPjwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LWdyYXktNjAwXCI+TG9hZGluZyBwaWdteSBkZXRhaWxzLi4uPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAoIXBpZ215KSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LWxnXCI+UGlnbXkgZGV0YWlscyBub3QgZm91bmQ8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIC8vIENhbGN1bGF0ZSB2YWx1ZXMgKGlmIG5lZWRlZClcclxuICBjb25zdCB0b3RhbEFtb3VudCA9IHBpZ215LnBheWFibGVfYW1vdW50IHx8IDA7XHJcbiAgY29uc3QgbWF0dXJpdHlJbnRlcmVzdCA9IHBpZ215Lm1hdHVyaXR5X2ludGVyZXN0IHx8IDA7XHJcbiAgY29uc3QgZHVyYXRpb24gPSBwaWdteS5kdXJhdGlvbiB8fCAwO1xyXG4gIGNvbnN0IHN0YXJ0RGF0ZSA9IG5ldyBEYXRlKHBpZ215LnN0YXJ0X2RhdGUpO1xyXG4gIGNvbnN0IGVuZERhdGUgPSBuZXcgRGF0ZShzdGFydERhdGUpO1xyXG4gIGVuZERhdGUuc2V0TW9udGgoZW5kRGF0ZS5nZXRNb250aCgpICsgZHVyYXRpb24pO1xyXG5cclxuICBjb25zdCBwcmVNYXR1cmVkSW50ZXJlc3RSYXRlID0gKG1hdHVyaXR5SW50ZXJlc3QgKiAwLjc1KS50b0ZpeGVkKDIpO1xyXG4gIGNvbnN0IHByZU1hdHVyZWRBbW91bnQgPSAodG90YWxBbW91bnQgKiAoMSArIChwcmVNYXR1cmVkSW50ZXJlc3RSYXRlIC8gMTAwKSkpLnRvRml4ZWQoMik7XHJcblxyXG4gIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFkYXRlKSByZXR1cm4gJ04vQSc7XHJcbiAgICByZXR1cm4gbmV3IERhdGUoZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1HQicsIHtcclxuICAgICAgZGF5OiAnMi1kaWdpdCcsXHJcbiAgICAgIG1vbnRoOiAnc2hvcnQnLFxyXG4gICAgICB5ZWFyOiAnbnVtZXJpYydcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNhbGN1bGF0ZUNvbXBsZXRlZE1vbnRocyA9IChzdGFydERhdGUsIGVuZERhdGUpID0+IHtcclxuICAgIGlmICghc3RhcnREYXRlIHx8ICFlbmREYXRlKSByZXR1cm4gMDtcclxuXHJcbiAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShlbmREYXRlKTtcclxuXHJcbiAgICBjb25zdCBtb250aHMgPVxyXG4gICAgICAoZW5kLmdldEZ1bGxZZWFyKCkgLSBzdGFydC5nZXRGdWxsWWVhcigpKSAqIDEyICtcclxuICAgICAgKGVuZC5nZXRNb250aCgpIC0gc3RhcnQuZ2V0TW9udGgoKSk7XHJcblxyXG4gICAgcmV0dXJuIE1hdGgubWF4KG1vbnRocywgMCk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGNvbXBsZXRlZE1vbnRocyA9IGNhbGN1bGF0ZUNvbXBsZXRlZE1vbnRocyhcclxuICAgIHBpZ215Py5zdGFydF9kYXRlLFxyXG4gICAgcGlnbXk/LmNsb3N1cmVfZGF0ZVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHNlY3Rpb25zID0gW1xyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJQaWdteSBEZXRhaWxzXCIsXHJcbiAgICAgIGZpZWxkczogW1xyXG4gICAgICAgIHsgbGFiZWw6IFwiUGlnbXkgSURcIiwgdmFsdWU6IHBpZ215Py5waWdtZV9pZCB9LFxyXG4gICAgICAgIHsgbGFiZWw6IFwiQ3VzdG9tZXIgTmFtZVwiLCB2YWx1ZTogcGlnbXk/LmN1c3RvbWVyPy5mdWxsX25hbWUgfSxcclxuICAgICAgICB7IGxhYmVsOiBcIlBob25lIE51bWJlclwiLCB2YWx1ZTogcGlnbXk/LmN1c3RvbWVyPy5waG9uZV9udW1iZXIgfSxcclxuICAgICAgICB7IGxhYmVsOiBcIlBheW1lbnQgRGV0YWlsc1wiLCB2YWx1ZTogcGlnbXk/Lm1hdHVyaXR5X3BlcmlvZD8udG9VcHBlckNhc2UoKSArIFwiIC0tIOKCuVwiICsgcGlnbXk/LnBheWFibGVfYW1vdW50IH0sXHJcbiAgICAgICAgeyBsYWJlbDogXCJTdGFydCBEYXRlXCIsIHZhbHVlOiBmb3JtYXREYXRlKHBpZ215Py5zdGFydF9kYXRlKSB9LFxyXG4gICAgICAgIHsgbGFiZWw6IFwiRHVyYXRpb25cIiwgdmFsdWU6IGAke2R1cmF0aW9ufSBNb250aHNgIH0sXHJcbiAgICAgICAgeyBsYWJlbDogXCJDb21wbGV0ZWQgTW9udGhzXCIsIHZhbHVlOiBgJHtjb21wbGV0ZWRNb250aHN9IE1vbnRoc2AgfSxcclxuICAgICAgICB7IGxhYmVsOiBcIkNsb3N1cmUgVHlwZVwiLCB2YWx1ZTogYCR7cGlnbXk/LmNsb3N1cmVfdHlwZX1gIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogcGlnbXk/LmNsb3N1cmVfdHlwZSA9PT0gXCJQUkUtTUFUVVJFRFwiID8gXCJQcmVtYXR1cmUgU2V0dGxlbWVudCBDYWxjdWxhdGlvblwiIDogXCJTZXR0bGVtZW50IENhbGN1bGF0aW9uXCIsXHJcbiAgICAgIGZpZWxkczogcGlnbXk/LmNsb3N1cmVfdHlwZSA9PT0gXCJQUkUtTUFUVVJFRFwiXHJcbiAgICAgICAgPyBbXHJcbiAgICAgICAgICB7IGxhYmVsOiBcIlRvdGFsIFBhaWQgQW1vdW50XCIsIHZhbHVlOiBg4oK5JHtOdW1iZXIocGlnbXk/LnRvdGFsX3BhaWQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJQcmVtYXR1cmUgRGVkdWN0aW9uIEludGVyZXN0XCIsIHZhbHVlOiBgJHtwaWdteT8ucHJlX21hdHVyZWRfaW50ZXJlc3R9JWAgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiUHJlY2xvc3VyZSBBbW91bnRcIiwgdmFsdWU6IGDigrkke051bWJlcihwaWdteT8ubWF0dXJpdHlfYW1vdW50KS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAgfSxcclxuICAgICAgICBdXHJcbiAgICAgICAgOiBbXHJcbiAgICAgICAgICB7IGxhYmVsOiBcIlRvdGFsIFBhaWQgQW1vdW50XCIsIHZhbHVlOiBg4oK5JHtOdW1iZXIocGlnbXk/LnRvdGFsX3BhaWQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJNYXR1cml0eSBJbnRlcmVzdCBSYXRlXCIsIHZhbHVlOiBgJHtwaWdteT8ubWF0dXJpdHlfaW50ZXJlc3R9JWAgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiU2V0dGxlbWVudCBBbW91bnRcIiwgdmFsdWU6IGDigrkke051bWJlcihwaWdteT8ubWF0dXJpdHlfYW1vdW50KS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAgfSxcclxuICAgICAgICBdLFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICAvLyBHZW5lcmF0ZSBQREYgZnVuY3Rpb24gKHVuY2hhbmdlZClcclxuICBjb25zdCBnZW5lcmF0ZUFuZE9wZW5QREYgPSAoZG93bmxvYWRPbmx5ID0gZmFsc2UpID0+IHtcclxuICAgIGNvbnN0IGRvYyA9IG5ldyBqc1BERihcInBcIiwgXCJtbVwiLCBcImE0XCIpO1xyXG4gICAgY29uc3Qgc2FmZVRleHQgPSAodikgPT4gKHYgPyBTdHJpbmcodikgOiBcIk4vQVwiKTtcclxuICAgIGxldCB5ID0gNjU7XHJcblxyXG4gICAgZG9jLmFkZEltYWdlKGltYWdlSW5wdXQsIFwiUE5HXCIsIDkwLCA4LCAzMCwgMzApO1xyXG4gICAgZG9jLnNldEZpbGxDb2xvcigwLCAzOCwgMTI0KTtcclxuICAgIGRvYy5yZWN0KDAsIDQwLCAyMTAsIDE1LCBcIkZcIik7XHJcbiAgICBkb2Muc2V0VGV4dENvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE2KTtcclxuICAgIGRvYy50ZXh0KFwiUGlnbXkgUHJlY2xvc3VyZSBGb3JtXCIsIDEwNSwgNDksIHsgYWxpZ246IFwiY2VudGVyXCIgfSk7XHJcblxyXG4gICAgY29uc3QgZHJhd0ZpZWxkID0gKGxhYmVsLCB2YWx1ZSwgeCwgeSkgPT4ge1xyXG4gICAgICBkb2Muc2V0RHJhd0NvbG9yKDIyMCwgMjI0LCAyMzApO1xyXG4gICAgICBkb2MucmVjdCh4LCB5LCA4MCwgOCk7XHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMCwgMzgsIDEyNCk7XHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuICAgICAgZG9jLnRleHQobGFiZWwgKyBcIjpcIiwgeCArIDIsIHkgKyA1KTtcclxuICAgICAgZG9jLnNldFRleHRDb2xvcigzMywgMzMsIDMzKTtcclxuICAgICAgZG9jLnRleHQoc2FmZVRleHQodmFsdWUpLCB4ICsgNDAsIHkgKyA1KTtcclxuICAgICAgcmV0dXJuIHkgKyAxMjtcclxuICAgIH07XHJcblxyXG4gICAgc2VjdGlvbnMuZm9yRWFjaCgoc2VjKSA9PiB7XHJcbiAgICAgIGRvYy5zZXRGaWxsQ29sb3IoMCwgMzgsIDEyNCk7XHJcbiAgICAgIGRvYy5yZWN0KDE1LCB5LCAxODAsIDgsIFwiRlwiKTtcclxuICAgICAgZG9jLnNldFRleHRDb2xvcigyNTUsIDI1NSwgMjU1KTtcclxuICAgICAgZG9jLnNldEZvbnRTaXplKDExKTtcclxuICAgICAgZG9jLnRleHQoc2VjLnRpdGxlLCAyMCwgeSArIDUpO1xyXG4gICAgICB5ICs9IDE1O1xyXG4gICAgICBzZWMuZmllbGRzLmZvckVhY2goKGYsIGkpID0+IHtcclxuICAgICAgICBjb25zdCB4ID0gaSAlIDIgPT09IDAgPyAxNSA6IDExMDtcclxuICAgICAgICB5ID0gZHJhd0ZpZWxkKGYubGFiZWwsIGYudmFsdWUsIHgsIGkgJSAyID8geSAtIDEyIDogeSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICB5ICs9IDU7XHJcbiAgICB9KTtcclxuXHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTApO1xyXG4gICAgZG9jLnRleHQoXCJJIGhlcmVieSBkZWNsYXJlIHRoYXQgdGhlIGFib3ZlIHBpZ215IGluZm9ybWF0aW9uIGlzIHRydWUgYW5kIGNvcnJlY3QuXCIsIDEwNSwgeSArIDEwLCB7IGFsaWduOiBcImNlbnRlclwiIH0pO1xyXG5cclxuICAgIGNvbnN0IHNpZ25hdHVyZXMgPSBbXHJcbiAgICAgIHsgbGFiZWw6IFwiQ3VzdG9tZXIgU2lnbmF0dXJlXCIsIHg6IDMwIH0sXHJcbiAgICAgIHsgbGFiZWw6IFwiQXV0aG9yaXplZCBTaWduYXRvcnlcIiwgeDogODAgfSxcclxuICAgICAgeyBsYWJlbDogXCJEYXRlXCIsIHg6IDE0MCB9LFxyXG4gICAgXTtcclxuICAgIHNpZ25hdHVyZXMuZm9yRWFjaCgoc2lnKSA9PiB7XHJcbiAgICAgIGRvYy5zZXREcmF3Q29sb3IoMCwgMCwgMCk7XHJcbiAgICAgIGRvYy5yZWN0KHNpZy54LCB5ICsgMjUsIDUwLCAxNSk7XHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuICAgICAgZG9jLnRleHQoc2lnLmxhYmVsLCBzaWcueCArIDI1LCB5ICsgMzMsIHsgYWxpZ246IFwiY2VudGVyXCIgfSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBkb2Muc2V0RmlsbENvbG9yKDAsIDM4LCAxMjQpO1xyXG4gICAgZG9jLnJlY3QoMCwgMjgwLCAyMTAsIDE1LCBcIkZcIik7XHJcbiAgICBkb2Muc2V0VGV4dENvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDgpO1xyXG4gICAgZG9jLnRleHQoXCJWSUpBWUEgVklOQVlBSyBDSElUIEZVTkRTIFBSSVZBVEUgTElNSVRFRFwiLCAxMDUsIDI4OCwgeyBhbGlnbjogXCJjZW50ZXJcIiB9KTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoMTAwLCAxMDAsIDEwMCk7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoNyk7XHJcbiAgICBkb2MudGV4dChgUmVmOiBQUkVDTC0ke3BpZ215Py5waWdtZV9pZCB8fCAnTi9BJ30tJHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9YCwgMTk1LCAyNzgsIHsgYWxpZ246IFwicmlnaHRcIiB9KTtcclxuXHJcbiAgICBpZiAoZG93bmxvYWRPbmx5KSB7XHJcbiAgICAgIGRvYy5zYXZlKGBQcmVjbG9zdXJlXyR7cGlnbXk/LnBpZ21lX2lkIHx8ICdGb3JtJ30ucGRmYCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBwZGZCbG9iID0gZG9jLm91dHB1dCgnYmxvYicpO1xyXG4gICAgICBjb25zdCBwZGZVcmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKHBkZkJsb2IpO1xyXG4gICAgICB3aW5kb3cub3BlbihwZGZVcmwsIFwiX2JsYW5rXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFN0YXR1c0NvbG9yID0gKHN0YXR1cykgPT4ge1xyXG4gICAgaWYgKCFzdGF0dXMpIHJldHVybiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCc7XHJcbiAgICBjb25zdCBzdGF0dXNNYXAgPSB7XHJcbiAgICAgICdBUFBST1ZFRCc6ICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAnLFxyXG4gICAgICAnUkVRVUVTVEVEJzogJ2JnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctODAwJyxcclxuICAgICAgJ0NPTVBMRVRFRCc6ICdiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwJyxcclxuICAgICAgJ0NMT1NFRCc6ICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwJyxcclxuICAgIH07XHJcbiAgICByZXR1cm4gc3RhdHVzTWFwW3N0YXR1cy50b1VwcGVyQ2FzZSgpXSB8fCAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCc7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHsvKiBQcmludCBzdHlsZXMgKi99XHJcbiAgICAgIDxzdHlsZT5cclxuICAgICAgICB7YFxyXG4gICAgICAgICAgQG1lZGlhIHByaW50IHtcclxuICAgICAgICAgICAgYm9keSAqIHtcclxuICAgICAgICAgICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgI3ByaW50YWJsZS1hcmVhLCAjcHJpbnRhYmxlLWFyZWEgKiB7XHJcbiAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAjcHJpbnRhYmxlLWFyZWEge1xyXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAgIHRvcDogMDtcclxuICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5uby1wcmludCB7XHJcbiAgICAgICAgICAgICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8qIEZvcmNlIGJhY2tncm91bmQgY29sb3JzIGFuZCB0ZXh0IGNvbG9ycyAqL1xyXG4gICAgICAgICAgICAuYmctYmx1ZS05MDAsIC5iZy1ibHVlLTkwMCAqIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMWUzYThhICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5iZy1hbWJlci01MDAsIC5iZy1hbWJlci01MDAgKiB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2Y1OWUwYiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIC13ZWJraXQtcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIHByaW50LWNvbG9yLWFkanVzdDogZXhhY3QgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuYmctYmx1ZS01MCB7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2VmZjZmZiAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIC13ZWJraXQtcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAgIHByaW50LWNvbG9yLWFkanVzdDogZXhhY3QgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuYmcteWVsbG93LTUwIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmYmViICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5ib3JkZXItYmx1ZS05MDAge1xyXG4gICAgICAgICAgICAgIGJvcmRlci1jb2xvcjogIzFlM2E4YSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC50ZXh0LWJsdWUtOTAwIHtcclxuICAgICAgICAgICAgICBjb2xvcjogIzFlM2E4YSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC50ZXh0LXdoaXRlIHtcclxuICAgICAgICAgICAgICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudGV4dC1ibHVlLTEwMCB7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICNkYmVhZmUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudGV4dC1ibHVlLTIwMCB7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICNiZmRiZmUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudGV4dC1ibHVlLTMwMCB7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICM5M2M1ZmQgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAudGV4dC1hbWJlci03MDAge1xyXG4gICAgICAgICAgICAgIGNvbG9yOiAjYjQ1MzA5ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLnRleHQtcmVkLTYwMCB7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICNkYzI2MjYgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvKiBFbnN1cmUgYm9yZGVycyBwcmludCAqL1xyXG4gICAgICAgICAgICAuYm9yZGVyIHtcclxuICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLmJvcmRlci1ibGFjayB7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgYH1cclxuICAgICAgPC9zdHlsZT5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS0yMDAgcC01IG1pbi1oLXNjcmVlbiBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiIGlkPVwicHJpbnRhYmxlLWFyZWFcIj5cclxuICAgICAgICB7LyogUERGIFByZXZpZXcgQ29udGFpbmVyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgc2hhZG93LWxnIHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIHctZnVsbCBtYXgtdy00eGwgbWItNVwiPlxyXG4gICAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS05MDAgdGV4dC13aGl0ZSByb3VuZGVkLXQteGwgcC02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgc3JjPXtpbWFnZUlucHV0fVxyXG4gICAgICAgICAgICAgICAgICBhbHQ9XCJDb21wYW55IExvZ29cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTI0IGgtMjQgb2JqZWN0LWNvbnRhaW4gYmctd2hpdGUgcm91bmRlZC1sZyBwLTJcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICBWSUpBWUEgVklOQVlBSyBDSElURlVORFMgUFJJVkFURSBMSU1JVEVEXHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsdWUtMTAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkNJTjo8L3NwYW4+IFU2NTk5OUtBMjAyMlBUQzE2MTg1OFxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsdWUtMTAwIGxlYWRpbmctNiBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIE5vLiAxMS8zNi0yNSwgMm5kIE1haW4sIEthdGhyaWd1cHBlIE1haW4gUm9hZCxcclxuICAgICAgICAgICAgICAgICAgQmFuZ2Fsb3JlLCBLYXJuYXRha2EgLSA1NjAwNzBcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWJsdWUtNzAwIG15LTFcIj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj5QaWdteSBQcmVjbG9zdXJlIEZvcm08L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTIwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICBHZW5lcmF0ZWQgb257XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICB7bmV3IERhdGUoKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgZGF0ZVN0eWxlOiBcIm1lZGl1bVwiLFxyXG4gICAgICAgICAgICAgICAgICB0aW1lU3R5bGU6IFwic2hvcnRcIixcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ29udGVudCAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgIHtzZWN0aW9ucy5tYXAoKHNlY3Rpb24sIHNlY3Rpb25JbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtzZWN0aW9uSW5kZXh9IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtzZWN0aW9uSW5kZXggPT09IDEgPyAnYmctYW1iZXItNTAwJyA6ICdiZy1ibHVlLTkwMCd9IHRleHQtd2hpdGUgcC0yIG1iLTMgcm91bmRlZC10YH0+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e3NlY3Rpb24udGl0bGV9PC9oMz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWN0aW9uLmZpZWxkcy5tYXAoKGZpZWxkLCBmaWVsZEluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtmaWVsZEluZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYm9yZGVyIHJvdW5kZWQgcC0zICR7ZmllbGQubGFiZWwgPT09IFwiUHJlY2xvc3VyZSBBbW91bnRcIiB8fCBmaWVsZC5sYWJlbCA9PT0gXCJTZXR0bGVtZW50IEFtb3VudFwiIHx8IGZpZWxkLmxhYmVsID09PSBcIlByZWNsb3N1cmUgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWFtYmVyLTUwMCBiZy1hbWJlci01MCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHRleHQtWzEycHhdIGZvbnQtbWVkaXVtICR7ZmllbGQubGFiZWwgPT09IFwiUHJlY2xvc3VyZSBBbW91bnRcIiB8fCBmaWVsZC5sYWJlbCA9PT0gXCJTZXR0bGVtZW50IEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtYW1iZXItNzAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LWJsdWUtOTAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZC5sYWJlbH06XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZm9udC1zZW1pYm9sZCAke2ZpZWxkLmxhYmVsID09PSBcIlByZWNsb3N1cmUgQW1vdW50XCIgfHwgZmllbGQubGFiZWwgPT09IFwiU2V0dGxlbWVudCBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LTJ4bCB0ZXh0LXJlZC02MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS04MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkLnZhbHVlIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSl9XHJcblxyXG4gICAgICAgICAgICB7LyogVGVybXMgJiBDb25kaXRpb25zICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTYgcC00IGJnLXllbGxvdy01MCBib3JkZXIgYm9yZGVyLXllbGxvdy0zMDAgcm91bmRlZCB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTJcIj5UZXJtcyAmIENvbmRpdGlvbnMgZm9yIFBpZ215IENsb3N1cmU8L2gzPlxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2MgcGwtNSBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgIDxsaT5QaWdteSBhY2NvdW50IGNsb3N1cmUgaXMgc3ViamVjdCB0byB2ZXJpZmljYXRpb24gb2YgYWxsIGRlcG9zaXRlZCBhbW91bnRzIGFuZCBjdXN0b21lciBkZXRhaWxzLjwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+SW50ZXJlc3Qgd2lsbCBiZSBjYWxjdWxhdGVkIGFzIHBlciB0aGUgcHJldmFpbGluZyBzY2hlbWUgcnVsZXMgYW5kIGNvbXBhbnkgcG9saWN5LjwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+SW4gY2FzZSBvZiBwcmVtYXR1cmUgY2xvc3VyZSwgYXBwbGljYWJsZSBpbnRlcmVzdCBkZWR1Y3Rpb25zL3BlbmFsdGllcyB3aWxsIGJlIGNoYXJnZWQuPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5Bbnkgb3V0c3RhbmRpbmcgZHVlcywgbG9hbnMsIG9yIGFkanVzdG1lbnRzIHdpbGwgYmUgZGVkdWN0ZWQgZnJvbSB0aGUgY2xvc3VyZSBhbW91bnQuPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaT5UaGUgZmluYWwgc2V0dGxlbWVudCBhbW91bnQgd2lsbCBiZSBwcm9jZXNzZWQgb25seSBhZnRlciBhcHByb3ZhbCBmcm9tIGF1dGhvcml6ZWQgb2ZmaWNpYWxzLjwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGk+T25jZSBjbG9zZWQsIHRoZSBwaWdteSBhY2NvdW50IGNhbm5vdCBiZSByZW9wZW5lZCB1bmRlciB0aGUgc2FtZSBhY2NvdW50IG51bWJlci48L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpPlRoZSBjb21wYW55IHJlc2VydmVzIHRoZSByaWdodCB0byBtb2RpZnkgdGVybXMgYXMgcGVyIGZpbmFuY2lhbCByZWd1bGF0aW9ucyBhbmQgaW50ZXJuYWwgcG9saWN5LjwvbGk+XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRGVjbGFyYXRpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbXktNiBwLTQgYmctYmx1ZS01MCByb3VuZGVkIGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwXCI+SSBoZXJlYnkgZGVjbGFyZSB0aGF0IHRoZSBhYm92ZSBwaWdteSBpbmZvcm1hdGlvbiBpcyB0cnVlIGFuZCBjb3JyZWN0LjwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogU2lnbmF0dXJlIEJveGVzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTQgbXktMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ibGFjayBoLTE2IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5DdXN0b21lciBTaWduYXR1cmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTQwMCB3LTMyIG10LTNcIj48L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItYmxhY2sgaC0xNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCB0ZXh0LXNtXCI+QXV0aG9yaXplZCBTaWduYXRvcnk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTQwMCB3LTMyIG10LTNcIj48L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItYmxhY2sgaC0xNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCB0ZXh0LXNtXCI+RGF0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktNDAwIHctMzIgbXQtM1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBGb290ZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtOTAwIHRleHQtd2hpdGUgdGV4dC1jZW50ZXIgcC0xIHRleHQtc21cIj5cclxuICAgICAgICAgICAgPGRpdj5WSUpBWUEgVklOQVlBSyBDSElUIEZVTkRTIFBSSVZBVEUgTElNSVRFRDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS0zMDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgUmVmOiBQUkVDTC17cGlnbXk/LnBpZ21lX2lkIHx8ICdOL0EnfS17bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtMzAwIHRleHQteHMgbXQtMSBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAqKiogVGhpcyBpcyBhIGNvbXB1dGVyIGdlbmVyYXRlZCBkb2N1bWVudCwgbm8gc2lnbmF0dXJlIGlzIHJlcXVpcmVkICoqKlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQnV0dG9uIENvbnRhaW5lciAtIGhpZGRlbiBvbiBwcmludCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTQgbm8tcHJpbnRcIj5cclxuICAgICAgICAgIHsvKiA8YnV0dG9uXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtOTAwIGhvdmVyOmJnLWJsdWUtODAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB5LTIgcHgtNiByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdlbmVyYXRlQW5kT3BlblBERihmYWxzZSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFByZXZpZXcgJiBQcmludCBQREZcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB5LTIgcHgtNiByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdlbmVyYXRlQW5kT3BlblBERih0cnVlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgRG93bmxvYWQgUERGXHJcbiAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB5LTIgcHgtNiByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5wcmludCgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBQcmludCBUaGlzIFBhZ2VcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQaWdteVByZWNsb3N1cmVQcmludDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvY29tcG9uZW50cy9wcmludEZvcm1hdHMvUGlnbXlQcmVjbG9zdXJlUHJpbnQuanN4In0=