import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CollectionAreaReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { CalendarDays, CalendarRange, Calendar, IndianRupee } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const StatsCard = ({ title, amount, count, icon: Icon, color }) => {
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 rounded-xl shadow-md border p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: title }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 420,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold mt-2", children: [
        "₹",
        Number(amount).toLocaleString()
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 422,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 mt-2", children: [
        "Customers: ",
        count
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 426,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
      lineNumber: 419,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `${color} p-3 rounded-xl`, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-7 h-7 text-white" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
      lineNumber: 432,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
      lineNumber: 431,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
    lineNumber: 418,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
    lineNumber: 417,
    columnNumber: 5
  }, this);
};
_c = StatsCard;
const CollectionAreaReport = () => {
  _s();
  const [collectionAreaList, setCollectionAreaList] = useState([]);
  const [selectedCollection, setSelectedCollection] = useState(null);
  const [collectionAreaTable, setCollectionAreaTable] = useState([]);
  const [loading, setLoading] = useState(false);
  const [employeeOptions, setEmployeeOptions] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  useEffect(() => {
    const fetchCollectionAreas = async () => {
      setLoading(true);
      try {
        const res = await api.get("/collection-area-request/get-collection-area-data");
        const list = res.data || [];
        setCollectionAreaList(list);
        const employeesSet = /* @__PURE__ */ new Map();
        list.forEach((area) => {
          area.agent_id?.forEach((a) => {
            if (!employeesSet.has(a._id)) {
              employeesSet.set(a._id, {
                label: `${a.name} | ${a.phone_number}`,
                value: a._id
              });
            }
          });
        });
        setEmployeeOptions([...employeesSet.values()]);
      } catch (error) {
        console.error("❌ Error fetching collection areas:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchCollectionAreas();
  }, []);
  useEffect(() => {
    if (!selectedCollection) {
      setCollectionAreaTable([]);
      return;
    }
    const fetchCollectionAreaUsers = async () => {
      setLoading(true);
      try {
        const res = await api.get(`/user/collection-area/${selectedCollection}`);
        let users = res.data.users || [];
        if (selectedEmployee) {
          users = users.filter(
            (user) => user.executive_name && user.executive_phone_number && user.executive_phone_number === employeeOptions.find(
              (emp) => emp.value === selectedEmployee
            )?.label.split("|")[1]?.trim()
          );
        }
        const formattedData = users.map((user, index) => ({
          id: user.customer_id || index,
          SlNo: index + 1,
          customerId: user.customer_id || "-",
          customerName: user.full_name || "-",
          customerPhoneNo: user.phone_number || "-",
          collectionAreaRouteName: user.route_name || "-",
          collectionAreaRoutePincode: user.pincode || "-",
          collectionEmployeeName: user.executive_name || "-",
          collectionEmployeePhoneNo: user.executive_phone_number || "-",
          paymentType: user.payment_type || "-",
          installmentValue: user.installment_value || "-"
        }));
        setCollectionAreaTable(formattedData);
      } catch (error) {
        console.error("❌ Error fetching collection area users:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchCollectionAreaUsers();
  }, [selectedCollection, selectedEmployee]);
  const collectionAreaColumns = [
    { key: "SlNo", header: "Sl No" },
    { key: "customerId", header: "Customer ID" },
    { key: "customerName", header: "Name" },
    { key: "customerPhoneNo", header: "Phone Number" },
    { key: "collectionAreaRouteName", header: "Route Name" },
    { key: "paymentType", header: "Payment Type" },
    { key: "installmentValue", header: "Installment Amount" },
    { key: "collectionAreaRoutePincode", header: "Pincode" },
    { key: "collectionEmployeeName", header: "Collection Executive" },
    { key: "collectionEmployeePhoneNo", header: "Executive Phone No" }
  ];
  const paymentStats = useMemo(() => {
    const stats = {
      daily: { count: 0, amount: 0 },
      weekly: { count: 0, amount: 0 },
      monthly: { count: 0, amount: 0 },
      total: { count: 0, amount: 0 }
    };
    collectionAreaTable.forEach((item) => {
      const type = (item.paymentType || "").toLowerCase();
      const amount = Number(item.installmentValue || 0);
      if (type === "daily") {
        stats.daily.count++;
        stats.daily.amount += amount;
      } else if (type === "weekly") {
        stats.weekly.count++;
        stats.weekly.amount += amount;
      } else if (type === "monthly") {
        stats.monthly.count++;
        stats.monthly.amount += amount;
      }
      stats.total.count++;
      stats.total.amount += amount;
    });
    return stats;
  }, [collectionAreaTable]);
  if (loading) return /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
    lineNumber: 575,
    columnNumber: 23
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-4 w-full", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-900", children: "Collection Area Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 583,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 mt-1", children: "Manage Daily, Weekly and Monthly collections across all routes." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 587,
        columnNumber: 5
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
      lineNumber: 582,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border mb-8 mt-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Collection Area" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
          lineNumber: 598,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            showSearch: true,
            placeholder: "Search Collection Area",
            value: selectedCollection,
            onChange: setSelectedCollection,
            allowClear: true,
            filterOption: (input, option) => option.label.toLowerCase().includes(input.toLowerCase()),
            className: "w-full h-12",
            children: collectionAreaList.map(
              (area) => /* @__PURE__ */ jsxDEV(
                Select.Option,
                {
                  value: area._id,
                  label: `${area.route_name} | ${area.route_pincode}`,
                  children: [
                    area.route_name,
                    " | ",
                    area.route_pincode
                  ]
                },
                area._id,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
                  lineNumber: 614,
                  columnNumber: 15
                },
                this
              )
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
            lineNumber: 602,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 597,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Collection Employee" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
          lineNumber: 627,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            showSearch: true,
            placeholder: "Search Employee",
            value: selectedEmployee,
            onChange: setSelectedEmployee,
            allowClear: true,
            options: employeeOptions,
            className: "w-full h-12"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
            lineNumber: 631,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 626,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
      lineNumber: 594,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
      lineNumber: 593,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-6", children: [
      /* @__PURE__ */ jsxDEV(
        StatsCard,
        {
          title: "Daily Collection",
          amount: paymentStats.daily.amount,
          count: paymentStats.daily.count,
          icon: CalendarDays,
          color: "bg-blue-500"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
          lineNumber: 648,
          columnNumber: 3
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        StatsCard,
        {
          title: "Weekly Collection",
          amount: paymentStats.weekly.amount,
          count: paymentStats.weekly.count,
          icon: CalendarRange,
          color: "bg-green-500"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
          lineNumber: 656,
          columnNumber: 3
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        StatsCard,
        {
          title: "Monthly Collection",
          amount: paymentStats.monthly.amount,
          count: paymentStats.monthly.count,
          icon: Calendar,
          color: "bg-purple-500"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
          lineNumber: 664,
          columnNumber: 3
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        StatsCard,
        {
          title: "Total Collection",
          amount: paymentStats.total.amount,
          count: paymentStats.total.count,
          icon: IndianRupee,
          color: "bg-orange-500"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
          lineNumber: 672,
          columnNumber: 3
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
      lineNumber: 646,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        columns: collectionAreaColumns,
        data: collectionAreaTable,
        exportedPdfName: "Collection Area Report",
        exportedFileName: "Collection Area Report.csv",
        noDataMessage: "Please select a collection area to view data"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
        lineNumber: 683,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx",
    lineNumber: 581,
    columnNumber: 5
  }, this);
};
_s(CollectionAreaReport, "F8rB6UNFE78UzAaT0Na7fbeAPwY=");
_c2 = CollectionAreaReport;
export default CollectionAreaReport;
var _c, _c2;
$RefreshReg$(_c, "StatsCard");
$RefreshReg$(_c2, "CollectionAreaReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CollectionAreaReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbWFVOzJCQW5hVjtBQUFtQkEsb0JBQWtCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEQsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWNDLGVBQWVDLFVBQVVDLG1CQUFtQjtBQXlabkUsTUFBTUMsWUFBWUEsQ0FBQyxFQUFFQyxPQUFPQyxRQUFRQyxPQUFPQyxNQUFNQyxNQUFNQyxNQUFNLE1BQU07QUFDakUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsK0NBQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsV0FBVSx5QkFBeUJMLG1CQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRDO0FBQUEsTUFFNUMsdUJBQUMsUUFBRyxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsUUFDcENNLE9BQU9MLE1BQU0sRUFBRU0sZUFBZTtBQUFBLFdBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsUUFDNUJMO0FBQUFBLFdBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVyxHQUFHRyxLQUFLLG1CQUN0QixpQ0FBQyxRQUFLLFdBQVUsd0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFFRyxLQXRCSVQ7QUF3Qk4sTUFBTVUsdUJBQXVCQSxNQUFNO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxDQUFDQyxvQkFBb0JDLHFCQUFxQixJQUFJQyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDQyxvQkFBb0JDLHFCQUFxQixJQUFJRixTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDRyxxQkFBcUJDLHNCQUFzQixJQUFJSixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDSyxTQUFTQyxVQUFVLElBQUlOLFNBQVMsS0FBSztBQUU1QyxRQUFNLENBQUNPLGlCQUFpQkMsa0JBQWtCLElBQUlSLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNTLGtCQUFrQkMsbUJBQW1CLElBQUlWLFNBQVMsSUFBSTtBQUc3RHZCLFlBQVUsTUFBTTtBQUNkLFVBQU1rQyx1QkFBdUIsWUFBWTtBQUN2Q0wsaUJBQVcsSUFBSTtBQUNmLFVBQUk7QUFDRixjQUFNTSxNQUFNLE1BQU1sQyxJQUFJbUMsSUFBSSxtREFBbUQ7QUFDN0UsY0FBTUMsT0FBT0YsSUFBSUcsUUFBUTtBQUN6QmhCLDhCQUFzQmUsSUFBSTtBQUcxQixjQUFNRSxlQUFlLG9CQUFJQyxJQUFJO0FBQzdCSCxhQUFLSSxRQUFRLENBQUNDLFNBQVM7QUFDckJBLGVBQUtDLFVBQVVGLFFBQVEsQ0FBQ0csTUFBTTtBQUM1QixnQkFBSSxDQUFDTCxhQUFhTSxJQUFJRCxFQUFFRSxHQUFHLEdBQUc7QUFDNUJQLDJCQUFhUSxJQUFJSCxFQUFFRSxLQUFLO0FBQUEsZ0JBQ3RCRSxPQUFPLEdBQUdKLEVBQUVLLElBQUksTUFBTUwsRUFBRU0sWUFBWTtBQUFBLGdCQUNwQ0MsT0FBT1AsRUFBRUU7QUFBQUEsY0FDWCxDQUFDO0FBQUEsWUFDSDtBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0gsQ0FBQztBQUVEZiwyQkFBbUIsQ0FBQyxHQUFHUSxhQUFhYSxPQUFPLENBQUMsQ0FBQztBQUFBLE1BQy9DLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sc0NBQXNDQSxLQUFLO0FBQUEsTUFDM0QsVUFBQztBQUNDeEIsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUNBSyx5QkFBcUI7QUFBQSxFQUN2QixHQUFHLEVBQUU7QUFHTGxDLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3dCLG9CQUFvQjtBQUN2QkcsNkJBQXVCLEVBQUU7QUFDekI7QUFBQSxJQUNGO0FBRUEsVUFBTTRCLDJCQUEyQixZQUFZO0FBQzNDMUIsaUJBQVcsSUFBSTtBQUNmLFVBQUk7QUFDRixjQUFNTSxNQUFNLE1BQU1sQyxJQUFJbUMsSUFBSSx5QkFBeUJaLGtCQUFrQixFQUFFO0FBQ3ZFLFlBQUlnQyxRQUFRckIsSUFBSUcsS0FBS2tCLFNBQVM7QUFHOUIsWUFBSXhCLGtCQUFrQjtBQUNwQndCLGtCQUFRQSxNQUFNQztBQUFBQSxZQUFPLENBQUNDLFNBQ3BCQSxLQUFLQyxrQkFBa0JELEtBQUtFLDBCQUM1QkYsS0FBS0UsMkJBQTJCOUIsZ0JBQWdCK0I7QUFBQUEsY0FDOUMsQ0FBQ0MsUUFBUUEsSUFBSVgsVUFBVW5CO0FBQUFBLFlBQ3pCLEdBQUdnQixNQUFNZSxNQUFNLEdBQUcsRUFBRSxDQUFDLEdBQUdDLEtBQUs7QUFBQSxVQUMvQjtBQUFBLFFBQ0Y7QUFHQSxjQUFNQyxnQkFBZ0JULE1BQU1VLElBQUksQ0FBQ1IsTUFBTVMsV0FBVztBQUFBLFVBQ2hEQyxJQUFJVixLQUFLVyxlQUFlRjtBQUFBQSxVQUN4QkcsTUFBTUgsUUFBUTtBQUFBLFVBQ2RJLFlBQVliLEtBQUtXLGVBQWU7QUFBQSxVQUNoQ0csY0FBY2QsS0FBS2UsYUFBYTtBQUFBLFVBQ2hDQyxpQkFBaUJoQixLQUFLUixnQkFBZ0I7QUFBQSxVQUN0Q3lCLHlCQUF5QmpCLEtBQUtrQixjQUFjO0FBQUEsVUFDNUNDLDRCQUE0Qm5CLEtBQUtvQixXQUFXO0FBQUEsVUFDNUNDLHdCQUF3QnJCLEtBQUtDLGtCQUFrQjtBQUFBLFVBQy9DcUIsMkJBQTJCdEIsS0FBS0UsMEJBQTBCO0FBQUEsVUFDMURxQixhQUFhdkIsS0FBS3dCLGdCQUFnQjtBQUFBLFVBQ2xDQyxrQkFBa0J6QixLQUFLMEIscUJBQXFCO0FBQUEsUUFDOUMsRUFBRTtBQUVGekQsK0JBQXVCc0MsYUFBYTtBQUFBLE1BQ3RDLFNBQVNaLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMkNBQTJDQSxLQUFLO0FBQUEsTUFDaEUsVUFBQztBQUNDeEIsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUVBMEIsNkJBQXlCO0FBQUEsRUFDM0IsR0FBRyxDQUFDL0Isb0JBQW9CUSxnQkFBZ0IsQ0FBQztBQUd6QyxRQUFNcUQsd0JBQXdCO0FBQUEsSUFDNUIsRUFBRUMsS0FBSyxRQUFRQyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFRCxLQUFLLGNBQWNDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLE9BQU87QUFBQSxJQUN0QyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxlQUFlO0FBQUEsSUFDakQsRUFBRUQsS0FBSywyQkFBMkJDLFFBQVEsYUFBYTtBQUFBLElBQ3RELEVBQUVELEtBQUssZUFBZUMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEscUJBQXFCO0FBQUEsSUFDeEQsRUFBRUQsS0FBSyw4QkFBOEJDLFFBQVEsVUFBVTtBQUFBLElBQ3ZELEVBQUVELEtBQUssMEJBQTBCQyxRQUFRLHVCQUF1QjtBQUFBLElBQ2hFLEVBQUVELEtBQUssNkJBQTZCQyxRQUFRLHFCQUFxQjtBQUFBLEVBQUM7QUFLbEUsUUFBTUMsZUFBZUMsUUFBUSxNQUFNO0FBQ3JDLFVBQU1DLFFBQVE7QUFBQSxNQUNaQyxPQUFPLEVBQUUvRSxPQUFPLEdBQUdELFFBQVEsRUFBRTtBQUFBLE1BQzdCaUYsUUFBUSxFQUFFaEYsT0FBTyxHQUFHRCxRQUFRLEVBQUU7QUFBQSxNQUM5QmtGLFNBQVMsRUFBRWpGLE9BQU8sR0FBR0QsUUFBUSxFQUFFO0FBQUEsTUFDL0JtRixPQUFPLEVBQUVsRixPQUFPLEdBQUdELFFBQVEsRUFBRTtBQUFBLElBQy9CO0FBRUFlLHdCQUFvQmUsUUFBUSxDQUFDc0QsU0FBUztBQUNwQyxZQUFNQyxRQUFRRCxLQUFLZCxlQUFlLElBQUlnQixZQUFZO0FBQ2xELFlBQU10RixTQUFTSyxPQUFPK0UsS0FBS1osb0JBQW9CLENBQUM7QUFFaEQsVUFBSWEsU0FBUyxTQUFTO0FBQ3BCTixjQUFNQyxNQUFNL0U7QUFDWjhFLGNBQU1DLE1BQU1oRixVQUFVQTtBQUFBQSxNQUN4QixXQUFXcUYsU0FBUyxVQUFVO0FBQzVCTixjQUFNRSxPQUFPaEY7QUFDYjhFLGNBQU1FLE9BQU9qRixVQUFVQTtBQUFBQSxNQUN6QixXQUFXcUYsU0FBUyxXQUFXO0FBQzdCTixjQUFNRyxRQUFRakY7QUFDZDhFLGNBQU1HLFFBQVFsRixVQUFVQTtBQUFBQSxNQUMxQjtBQUVBK0UsWUFBTUksTUFBTWxGO0FBQ1o4RSxZQUFNSSxNQUFNbkYsVUFBVUE7QUFBQUEsSUFDeEIsQ0FBQztBQUVELFdBQU8rRTtBQUFBQSxFQUNULEdBQUcsQ0FBQ2hFLG1CQUFtQixDQUFDO0FBRXRCLE1BQUlFLFFBQVMsUUFBTyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWU7QUFLbkMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFNBQ0g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsb0NBQW1DLHNDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsK0VBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFKO0FBQUEsSUFHSSx1QkFBQyxTQUFJLFdBQVUsc0RBQ2IsaUNBQUMsU0FBSSxXQUFVLDBCQUdiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sV0FBVSxnREFBK0Msc0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxhQUFZO0FBQUEsWUFDWixPQUFPSjtBQUFBQSxZQUNQLFVBQVVDO0FBQUFBLFlBQ1Y7QUFBQSxZQUNBLGNBQWMsQ0FBQ3lFLE9BQU9DLFdBQ3BCQSxPQUFPbkQsTUFBTWlELFlBQVksRUFBRUcsU0FBU0YsTUFBTUQsWUFBWSxDQUFDO0FBQUEsWUFFekQsV0FBVTtBQUFBLFlBRVQ1RSw2QkFBbUI2QztBQUFBQSxjQUFJLENBQUN4QixTQUN2QjtBQUFBLGdCQUFDLE9BQU87QUFBQSxnQkFBUDtBQUFBLGtCQUVDLE9BQU9BLEtBQUtJO0FBQUFBLGtCQUNaLE9BQU8sR0FBR0osS0FBS2tDLFVBQVUsTUFBTWxDLEtBQUsyRCxhQUFhO0FBQUEsa0JBRWhEM0Q7QUFBQUEseUJBQUtrQztBQUFBQSxvQkFBVztBQUFBLG9CQUFJbEMsS0FBSzJEO0FBQUFBO0FBQUFBO0FBQUFBLGdCQUpyQjNELEtBQUtJO0FBQUFBLGdCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9CQTtBQUFBLFdBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxNQUdBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxXQUFNLFdBQVUsZ0RBQStDLG1DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsYUFBWTtBQUFBLFlBQ1osT0FBT2Q7QUFBQUEsWUFDUCxVQUFVQztBQUFBQSxZQUNWO0FBQUEsWUFDQSxTQUFTSDtBQUFBQSxZQUNULFdBQVU7QUFBQTtBQUFBLFVBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT3lCO0FBQUEsV0FaM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStDQSxLQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsSUFJQSx1QkFBQyxTQUFJLFdBQVUsNkRBRW5CO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFFBQVEwRCxhQUFhRyxNQUFNaEY7QUFBQUEsVUFDM0IsT0FBTzZFLGFBQWFHLE1BQU0vRTtBQUFBQSxVQUMxQixNQUFNUDtBQUFBQSxVQUNOLE9BQU07QUFBQTtBQUFBLFFBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3FCO0FBQUEsTUFHckI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFFBQVFtRixhQUFhSSxPQUFPakY7QUFBQUEsVUFDNUIsT0FBTzZFLGFBQWFJLE9BQU9oRjtBQUFBQSxVQUMzQixNQUFNTjtBQUFBQSxVQUNOLE9BQU07QUFBQTtBQUFBLFFBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3NCO0FBQUEsTUFHdEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFFBQVFrRixhQUFhSyxRQUFRbEY7QUFBQUEsVUFDN0IsT0FBTzZFLGFBQWFLLFFBQVFqRjtBQUFBQSxVQUM1QixNQUFNTDtBQUFBQSxVQUNOLE9BQU07QUFBQTtBQUFBLFFBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3VCO0FBQUEsTUFHdkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFFBQVFpRixhQUFhTSxNQUFNbkY7QUFBQUEsVUFDM0IsT0FBTzZFLGFBQWFNLE1BQU1sRjtBQUFBQSxVQUMxQixNQUFNSjtBQUFBQSxVQUNOLE9BQU07QUFBQTtBQUFBLFFBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3VCO0FBQUEsU0EvQm5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ047QUFBQSxJQUdNO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTNkU7QUFBQUEsUUFDVCxNQUFNM0Q7QUFBQUEsUUFDTixpQkFBZ0I7QUFBQSxRQUNoQixrQkFBaUI7QUFBQSxRQUNqQixlQUFjO0FBQUE7QUFBQSxNQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLOEQ7QUFBQSxPQTNHaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZHQTtBQUVKO0FBQUVOLEdBN1BJRCxzQkFBb0I7QUFBQW1GLE1BQXBCbkY7QUE4UE4sZUFBZUE7QUFBcUIsSUFBQUQsSUFBQW9GO0FBQUFDLGFBQUFyRixJQUFBO0FBQUFxRixhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiYXBpIiwiRGF0YVRhYmxlIiwiU2VsZWN0IiwiQ2lyY3VsYXJMb2FkZXIiLCJDYWxlbmRhckRheXMiLCJDYWxlbmRhclJhbmdlIiwiQ2FsZW5kYXIiLCJJbmRpYW5SdXBlZSIsIlN0YXRzQ2FyZCIsInRpdGxlIiwiYW1vdW50IiwiY291bnQiLCJpY29uIiwiSWNvbiIsImNvbG9yIiwiTnVtYmVyIiwidG9Mb2NhbGVTdHJpbmciLCJfYyIsIkNvbGxlY3Rpb25BcmVhUmVwb3J0IiwiX3MiLCJjb2xsZWN0aW9uQXJlYUxpc3QiLCJzZXRDb2xsZWN0aW9uQXJlYUxpc3QiLCJ1c2VTdGF0ZSIsInNlbGVjdGVkQ29sbGVjdGlvbiIsInNldFNlbGVjdGVkQ29sbGVjdGlvbiIsImNvbGxlY3Rpb25BcmVhVGFibGUiLCJzZXRDb2xsZWN0aW9uQXJlYVRhYmxlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJlbXBsb3llZU9wdGlvbnMiLCJzZXRFbXBsb3llZU9wdGlvbnMiLCJzZWxlY3RlZEVtcGxveWVlIiwic2V0U2VsZWN0ZWRFbXBsb3llZSIsImZldGNoQ29sbGVjdGlvbkFyZWFzIiwicmVzIiwiZ2V0IiwibGlzdCIsImRhdGEiLCJlbXBsb3llZXNTZXQiLCJNYXAiLCJmb3JFYWNoIiwiYXJlYSIsImFnZW50X2lkIiwiYSIsImhhcyIsIl9pZCIsInNldCIsImxhYmVsIiwibmFtZSIsInBob25lX251bWJlciIsInZhbHVlIiwidmFsdWVzIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hDb2xsZWN0aW9uQXJlYVVzZXJzIiwidXNlcnMiLCJmaWx0ZXIiLCJ1c2VyIiwiZXhlY3V0aXZlX25hbWUiLCJleGVjdXRpdmVfcGhvbmVfbnVtYmVyIiwiZmluZCIsImVtcCIsInNwbGl0IiwidHJpbSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJpbmRleCIsImlkIiwiY3VzdG9tZXJfaWQiLCJTbE5vIiwiY3VzdG9tZXJJZCIsImN1c3RvbWVyTmFtZSIsImZ1bGxfbmFtZSIsImN1c3RvbWVyUGhvbmVObyIsImNvbGxlY3Rpb25BcmVhUm91dGVOYW1lIiwicm91dGVfbmFtZSIsImNvbGxlY3Rpb25BcmVhUm91dGVQaW5jb2RlIiwicGluY29kZSIsImNvbGxlY3Rpb25FbXBsb3llZU5hbWUiLCJjb2xsZWN0aW9uRW1wbG95ZWVQaG9uZU5vIiwicGF5bWVudFR5cGUiLCJwYXltZW50X3R5cGUiLCJpbnN0YWxsbWVudFZhbHVlIiwiaW5zdGFsbG1lbnRfdmFsdWUiLCJjb2xsZWN0aW9uQXJlYUNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJwYXltZW50U3RhdHMiLCJ1c2VNZW1vIiwic3RhdHMiLCJkYWlseSIsIndlZWtseSIsIm1vbnRobHkiLCJ0b3RhbCIsIml0ZW0iLCJ0eXBlIiwidG9Mb3dlckNhc2UiLCJpbnB1dCIsIm9wdGlvbiIsImluY2x1ZGVzIiwicm91dGVfcGluY29kZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb2xsZWN0aW9uQXJlYVJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgQ2FsZW5kYXJEYXlzLCBDYWxlbmRhclJhbmdlLCBDYWxlbmRhciwgSW5kaWFuUnVwZWUgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcblxyXG5cclxuLy8gY29uc3QgQ29sbGVjdGlvbkFyZWFSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW2NvbGxlY3Rpb25BcmVhTGlzdCwgc2V0Q29sbGVjdGlvbkFyZWFMaXN0XSA9IHVzZVN0YXRlKFtdKTsgLy8gQWxsIGNvbGxlY3Rpb24gYXJlYXNcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRDb2xsZWN0aW9uLCBzZXRTZWxlY3RlZENvbGxlY3Rpb25dID0gdXNlU3RhdGUobnVsbCk7IC8vIFNlbGVjdGVkIGNvbGxlY3Rpb24gYXJlYVxyXG4vLyAgIGNvbnN0IFtjb2xsZWN0aW9uQXJlYVRhYmxlLCBzZXRDb2xsZWN0aW9uQXJlYVRhYmxlXSA9IHVzZVN0YXRlKFtdKTsgLy8gVGFibGUgZGF0YVxyXG4vLyAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTsgLy8gTG9hZGluZyBzdGF0ZVxyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlcywgc2V0U2VsZWN0ZWRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyBjb25zdCBbZW1wbG95ZWVPcHRpb25zLCBzZXRFbXBsb3llZU9wdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuIFxyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgIGNvbnN0IGZldGNoQ29sbGVjdGlvbkFyZWFzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbi8vICAgICAgICAgXCIvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3QvZ2V0LWNvbGxlY3Rpb24tYXJlYS1kYXRhXCJcclxuLy8gICAgICAgKTtcclxuLy8gICAgICAgY29uc3QgbGlzdCA9IHJlcy5kYXRhIHx8IFtdO1xyXG4vLyAgICAgICBzZXRDb2xsZWN0aW9uQXJlYUxpc3QobGlzdCk7XHJcblxyXG4vLyAgICAgICAvLyDirZAgRXh0cmFjdCB1bmlxdWUgZW1wbG95ZWUgbmFtZXMgJiBwaG9uZSBudW1iZXJzXHJcbi8vICAgICAgIGNvbnN0IGVtcGxveWVlc1NldCA9IG5ldyBNYXAoKTtcclxuXHJcbi8vICAgICAgIGxpc3QuZm9yRWFjaCgoYXJlYSkgPT4ge1xyXG4vLyAgICAgICAgIGFyZWEuYWdlbnRfaWQ/LmZvckVhY2goKGEpID0+IHtcclxuLy8gICAgICAgICAgIGlmICghZW1wbG95ZWVzU2V0LmhhcyhhLl9pZCkpIHtcclxuLy8gICAgICAgICAgICAgZW1wbG95ZWVzU2V0LnNldChhLl9pZCwge1xyXG4vLyAgICAgICAgICAgICAgIGxhYmVsOiBgJHthLm5hbWV9IHwgJHthLnBob25lX251bWJlcn1gLFxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlOiBhLl9pZCxcclxuLy8gICAgICAgICAgICAgfSk7XHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgc2V0RW1wbG95ZWVPcHRpb25zKFsuLi5lbXBsb3llZXNTZXQudmFsdWVzKCldKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCLinYwgRXJyb3IgZmV0Y2hpbmcgY29sbGVjdGlvbiBhcmVhczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuLy8gICBmZXRjaENvbGxlY3Rpb25BcmVhcygpO1xyXG4vLyB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIEZldGNoIHVzZXJzIGZvciBzZWxlY3RlZCBjb2xsZWN0aW9uIGFyZWFcclxuLy8gICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgIC8vICAgaWYgKCFzZWxlY3RlZENvbGxlY3Rpb24pIHtcclxuLy8gICAvLyAgICAgc2V0Q29sbGVjdGlvbkFyZWFUYWJsZShbXSk7IC8vIENsZWFyIHRhYmxlIGlmIG5vIGNvbGxlY3Rpb24gYXJlYSBzZWxlY3RlZFxyXG4vLyAgIC8vICAgICByZXR1cm47XHJcbi8vICAgLy8gICB9XHJcblxyXG4vLyAgIC8vICAgY29uc3QgZmV0Y2hDb2xsZWN0aW9uQXJlYVVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgIC8vICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgIC8vICAgICB0cnkge1xyXG4vLyAgIC8vICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbi8vICAgLy8gICAgICAgICBgL3VzZXIvY29sbGVjdGlvbi1hcmVhLyR7c2VsZWN0ZWRDb2xsZWN0aW9ufWBcclxuLy8gICAvLyAgICAgICApO1xyXG4vLyAgIC8vICAgICAgIGNvbnN0IHVzZXJzID0gcmVzLmRhdGEudXNlcnMgfHwgW107XHJcblxyXG4vLyAgIC8vICAgICAgIC8vIEZpbHRlciB1c2VycyB3aG9zZSBjb2xsZWN0aW9uX2FyZWEuX2lkIG1hdGNoZXMgc2VsZWN0ZWRDb2xsZWN0aW9uXHJcbi8vICAgLy8gICAgICAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZXJzLmZpbHRlcihcclxuLy8gICAvLyAgICAgICAgICh1c2VyKSA9PiB1c2VyLmNvbGxlY3Rpb25fYXJlYT8uX2lkID09PSBzZWxlY3RlZENvbGxlY3Rpb25cclxuLy8gICAvLyAgICAgICApO1xyXG5cclxuLy8gICAvLyAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gZmlsdGVyZWRVc2Vycy5tYXAoKGFyZWEsIGluZGV4KSA9PiAoe1xyXG4vLyAgIC8vICAgICAgICAgaWQ6IGFyZWEuX2lkIHx8IGluZGV4LFxyXG4vLyAgIC8vICAgICAgICAgU2xObzogaW5kZXggKyAxLFxyXG4vLyAgIC8vICAgICAgICAgY3VzdG9tZXJJZDogYXJlYS5jdXN0b21lcl9pZCB8fCBcIi1cIixcclxuLy8gICAvLyAgICAgICAgIGN1c3RvbWVyTmFtZTogYXJlYS5mdWxsX25hbWUgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICBjdXN0b21lclBob25lTm86IGFyZWEucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgY29sbGVjdGlvbkFyZWFSb3V0ZU5hbWU6IGFyZWEuY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgY29sbGVjdGlvbkFyZWFSb3V0ZVBpbmNvZGU6XHJcbi8vICAgLy8gICAgICAgICAgIGFyZWEuY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9waW5jb2RlIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgICAgY29sbGVjdGlvbkVtcGxveWVlTmFtZTpcclxuLy8gICAvLyAgICAgICAgICAgYXJlYS5jb2xsZWN0aW9uX2FyZWE/LmFnZW50X2lkPy5tYXAoKGEpID0+IGEubmFtZSk/LmpvaW4oXCIgfCBcIikgfHxcclxuLy8gICAvLyAgICAgICAgICAgXCItXCIsXHJcbi8vICAgLy8gICAgICAgICBjb2xsZWN0aW9uRW1wbG95ZWVQaG9uZU5vOlxyXG4vLyAgIC8vICAgICAgICAgICBhcmVhLmNvbGxlY3Rpb25fYXJlYT8uYWdlbnRfaWRcclxuLy8gICAvLyAgICAgICAgICAgICA/Lm1hcCgoYSkgPT4gYS5waG9uZV9udW1iZXIpXHJcbi8vICAgLy8gICAgICAgICAgICAgPy5qb2luKFwiIHwgXCIpIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgIH0pKTtcclxuXHJcbi8vICAgLy8gICAgICAgc2V0Q29sbGVjdGlvbkFyZWFUYWJsZShmb3JtYXR0ZWREYXRhKTtcclxuLy8gICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAvLyAgICAgICBjb25zb2xlLmVycm9yKFwi4p2MIEVycm9yIGZldGNoaW5nIGNvbGxlY3Rpb24gYXJlYSB1c2VyczpcIiwgZXJyb3IpO1xyXG4vLyAgIC8vICAgICAgIHNldENvbGxlY3Rpb25BcmVhVGFibGUoW10pO1xyXG4vLyAgIC8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgIC8vICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgIC8vICAgICB9XHJcbi8vICAgLy8gICB9O1xyXG5cclxuLy8gICAvLyAgIGZldGNoQ29sbGVjdGlvbkFyZWFVc2VycygpO1xyXG4vLyAgIC8vIH0sIFtzZWxlY3RlZENvbGxlY3Rpb25dKTtcclxuXHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgaWYgKCFzZWxlY3RlZENvbGxlY3Rpb24pIHtcclxuLy8gICAgIHNldENvbGxlY3Rpb25BcmVhVGFibGUoW10pO1xyXG4vLyAgICAgcmV0dXJuO1xyXG4vLyAgIH1cclxuXHJcbi8vICAgY29uc3QgZmV0Y2hDb2xsZWN0aW9uQXJlYVVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoYC91c2VyL2NvbGxlY3Rpb24tYXJlYS8ke3NlbGVjdGVkQ29sbGVjdGlvbn1gKTtcclxuLy8gICAgICAgbGV0IHVzZXJzID0gcmVzLmRhdGEudXNlcnMgfHwgW107XHJcblxyXG4vLyAgICAgICAvLyBGaWx0ZXIgYnkgY29sbGVjdGlvbiBhcmVhXHJcbi8vICAgICAgIHVzZXJzID0gdXNlcnMuZmlsdGVyKFxyXG4vLyAgICAgICAgICh1c2VyKSA9PiB1c2VyLmNvbGxlY3Rpb25fYXJlYT8uX2lkID09PSBzZWxlY3RlZENvbGxlY3Rpb25cclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIC8vIOKtkCBGaWx0ZXIgYnkgc2VsZWN0ZWQgZW1wbG95ZWVzIChpZiBhbnkgc2VsZWN0ZWQpXHJcbi8vICAgICAgIGlmIChzZWxlY3RlZEVtcGxveWVlcy5sZW5ndGggPiAwKSB7XHJcbi8vICAgICAgICAgdXNlcnMgPSB1c2Vycy5maWx0ZXIoKHVzZXIpID0+XHJcbi8vICAgICAgICAgICB1c2VyLmNvbGxlY3Rpb25fYXJlYT8uYWdlbnRfaWQ/LnNvbWUoKGFnZW50KSA9PlxyXG4vLyAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlcy5pbmNsdWRlcyhhZ2VudC5faWQpXHJcbi8vICAgICAgICAgICApXHJcbi8vICAgICAgICAgKTtcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHVzZXJzLm1hcCgoYXJlYSwgaW5kZXgpID0+ICh7XHJcbi8vICAgICAgICAgaWQ6IGFyZWEuX2lkIHx8IGluZGV4LFxyXG4vLyAgICAgICAgIFNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBjdXN0b21lcklkOiBhcmVhLmN1c3RvbWVyX2lkIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIGN1c3RvbWVyTmFtZTogYXJlYS5mdWxsX25hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgY3VzdG9tZXJQaG9uZU5vOiBhcmVhLnBob25lX251bWJlciB8fCBcIi1cIixcclxuLy8gICAgICAgICBjb2xsZWN0aW9uQXJlYVJvdXRlTmFtZTogYXJlYS5jb2xsZWN0aW9uX2FyZWE/LnJvdXRlX25hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgY29sbGVjdGlvbkFyZWFSb3V0ZVBpbmNvZGU6XHJcbi8vICAgICAgICAgICBhcmVhLmNvbGxlY3Rpb25fYXJlYT8ucm91dGVfcGluY29kZSB8fCBcIi1cIixcclxuLy8gICAgICAgICBjb2xsZWN0aW9uRW1wbG95ZWVOYW1lOlxyXG4vLyAgICAgICAgICAgYXJlYS5jb2xsZWN0aW9uX2FyZWE/LmFnZW50X2lkXHJcbi8vICAgICAgICAgICAgID8ubWFwKChhKSA9PiBhLm5hbWUpXHJcbi8vICAgICAgICAgICAgID8uam9pbihcIiB8IFwiKSB8fCBcIi1cIixcclxuLy8gICAgICAgICBjb2xsZWN0aW9uRW1wbG95ZWVQaG9uZU5vOlxyXG4vLyAgICAgICAgICAgYXJlYS5jb2xsZWN0aW9uX2FyZWE/LmFnZW50X2lkXHJcbi8vICAgICAgICAgICAgID8ubWFwKChhKSA9PiBhLnBob25lX251bWJlcilcclxuLy8gICAgICAgICAgICAgPy5qb2luKFwiIHwgXCIpIHx8IFwiLVwiLFxyXG4vLyAgICAgICB9KSk7XHJcblxyXG4vLyAgICAgICBzZXRDb2xsZWN0aW9uQXJlYVRhYmxlKGZvcm1hdHRlZERhdGEpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIuKdjCBFcnJvciBmZXRjaGluZyBjb2xsZWN0aW9uIGFyZWEgdXNlcnM6XCIsIGVycm9yKTtcclxuLy8gICAgICAgc2V0Q29sbGVjdGlvbkFyZWFUYWJsZShbXSk7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBmZXRjaENvbGxlY3Rpb25BcmVhVXNlcnMoKTtcclxuLy8gfSwgW3NlbGVjdGVkQ29sbGVjdGlvbiwgc2VsZWN0ZWRFbXBsb3llZXNdKTtcclxuXHJcblxyXG4vLyAgIC8vIENvbHVtbnMgZm9yIERhdGFUYWJsZVxyXG4vLyAgIGNvbnN0IGNvbGxlY3Rpb25BcmVhQ29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcIlNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElEXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImN1c3RvbWVyTmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJjdXN0b21lclBob25lTm9cIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbi8vICAgICB7IGtleTogXCJjb2xsZWN0aW9uQXJlYVJvdXRlTmFtZVwiLCBoZWFkZXI6IFwiUm91dGUgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJjb2xsZWN0aW9uQXJlYVJvdXRlUGluY29kZVwiLCBoZWFkZXI6IFwiUGluY29kZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJjb2xsZWN0aW9uRW1wbG95ZWVOYW1lXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIEV4ZWN1dGl2ZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJjb2xsZWN0aW9uRW1wbG95ZWVQaG9uZU5vXCIsIGhlYWRlcjogXCJFeGVjdXRpdmUgUGhvbmUgTm9cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGlmIChsb2FkaW5nKSB7XHJcbi8vICAgICByZXR1cm4gPENpcmN1bGFyTG9hZGVyIC8+OyAvLyBTaG93IGxvYWRlciB3aGlsZSBmZXRjaGluZyBkYXRhXHJcbi8vICAgfVxyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuLy8gICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LTJ4bCBtYi01XCI+Q29sbGVjdGlvbiBBcmVhIFJlcG9ydDwvaDE+XHJcblxyXG4vLyAgICAgICB7LyogQ29sbGVjdGlvbiBBcmVhIERyb3Bkb3duICovfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgdy02NFwiPlxyXG4vLyAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgaHRtbEZvcj1cImdlbmRlclwiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgU2VsZWN0IENvbGxlY3Rpb24gQXJlYVxyXG4vLyAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3IgU2VsZWN0IENvbGxlY3Rpb24gQXJlYVwiXHJcbi8vICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDb2xsZWN0aW9ufVxyXG4vLyAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkQ29sbGVjdGlvbn1cclxuLy8gICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgIG9wdGlvbi5sYWJlbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIHtjb2xsZWN0aW9uQXJlYUxpc3QubWFwKChhcmVhKSA9PiAoXHJcbi8vICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbi8vICAgICAgICAgICAgICAga2V5PXthcmVhLl9pZH1cclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17YXJlYS5faWR9XHJcbi8vICAgICAgICAgICAgICAgbGFiZWw9e2Ake2FyZWEucm91dGVfbmFtZX0gfCAke2FyZWEucm91dGVfcGluY29kZX1gfVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAge2FyZWEucm91dGVfbmFtZX0gfCB7YXJlYS5yb3V0ZV9waW5jb2RlfVxyXG4vLyAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICApKX1cclxuLy8gICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCB3LTgwXCI+XHJcbi8vICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbi8vICAgICBGaWx0ZXIgYnkgQ29sbGVjdGlvbiBFbXBsb3llZVxyXG4vLyAgIDwvbGFiZWw+XHJcblxyXG4vLyAgIDxTZWxlY3RcclxuLy8gICAgIG1vZGU9XCJtdWx0aXBsZVwiXHJcbi8vICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDb2xsZWN0aW9uIEVtcGxveWVlXCJcclxuLy8gICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlc31cclxuLy8gICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZEVtcGxveWVlc31cclxuLy8gICAgIG9wdGlvbnM9e2VtcGxveWVlT3B0aW9uc31cclxuLy8gICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbi8vICAgLz5cclxuLy8gPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogRGF0YVRhYmxlICovfVxyXG4vLyAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgY29sdW1ucz17Y29sbGVjdGlvbkFyZWFDb2x1bW5zfVxyXG4vLyAgICAgICAgIGRhdGE9e2NvbGxlY3Rpb25BcmVhVGFibGV9XHJcbi8vICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ29sbGVjdGlvbiBBcmVhIFJlcG9ydFwiXHJcbi8vICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkNvbGxlY3Rpb25BcmVhUmVwb3J0LmNzdlwiXHJcbi8vICAgICAgICAgbm9EYXRhTWVzc2FnZT1cIlBsZWFzZSBzZWxlY3QgYSBjb2xsZWN0aW9uIGFyZWEgdG8gdmlldyBkYXRhXCJcclxuLy8gICAgICAgLz5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5cclxuLy8gY29uc3QgQ29sbGVjdGlvbkFyZWFSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW2NvbGxlY3Rpb25BcmVhTGlzdCwgc2V0Q29sbGVjdGlvbkFyZWFMaXN0XSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRDb2xsZWN0aW9uLCBzZXRTZWxlY3RlZENvbGxlY3Rpb25dID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW2NvbGxlY3Rpb25BcmVhVGFibGUsIHNldENvbGxlY3Rpb25BcmVhVGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgY29uc3QgW2VtcGxveWVlT3B0aW9ucywgc2V0RW1wbG95ZWVPcHRpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZSwgc2V0U2VsZWN0ZWRFbXBsb3llZV0gPSB1c2VTdGF0ZShudWxsKTsgLy8g4q2QIFNJTkdMRSBTRUxFQ1RcclxuXHJcbi8vICAgLy8gRmV0Y2ggYWxsIENvbGxlY3Rpb24gQXJlYXNcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hDb2xsZWN0aW9uQXJlYXMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9jb2xsZWN0aW9uLWFyZWEtcmVxdWVzdC9nZXQtY29sbGVjdGlvbi1hcmVhLWRhdGFcIik7XHJcbi8vICAgICAgICAgY29uc3QgbGlzdCA9IHJlcy5kYXRhIHx8IFtdO1xyXG4vLyAgICAgICAgIHNldENvbGxlY3Rpb25BcmVhTGlzdChsaXN0KTtcclxuXHJcbi8vICAgICAgICAgLy8gRXh0cmFjdCB1bmlxdWUgZW1wbG95ZWVzXHJcbi8vICAgICAgICAgY29uc3QgZW1wbG95ZWVzU2V0ID0gbmV3IE1hcCgpO1xyXG4vLyAgICAgICAgIGxpc3QuZm9yRWFjaCgoYXJlYSkgPT4ge1xyXG4vLyAgICAgICAgICAgYXJlYS5hZ2VudF9pZD8uZm9yRWFjaCgoYSkgPT4ge1xyXG4vLyAgICAgICAgICAgICBpZiAoIWVtcGxveWVlc1NldC5oYXMoYS5faWQpKSB7XHJcbi8vICAgICAgICAgICAgICAgZW1wbG95ZWVzU2V0LnNldChhLl9pZCwge1xyXG4vLyAgICAgICAgICAgICAgICAgbGFiZWw6IGAke2EubmFtZX0gfCAke2EucGhvbmVfbnVtYmVyfWAsXHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZTogYS5faWQsXHJcbi8vICAgICAgICAgICAgICAgfSk7XHJcbi8vICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgIH0pO1xyXG4vLyAgICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgICBzZXRFbXBsb3llZU9wdGlvbnMoWy4uLmVtcGxveWVlc1NldC52YWx1ZXMoKV0pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCLinYwgRXJyb3IgZmV0Y2hpbmcgY29sbGVjdGlvbiBhcmVhczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hDb2xsZWN0aW9uQXJlYXMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIEZldGNoIFVzZXJzXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmICghc2VsZWN0ZWRDb2xsZWN0aW9uKSB7XHJcbi8vICAgICAgIHNldENvbGxlY3Rpb25BcmVhVGFibGUoW10pO1xyXG4vLyAgICAgICByZXR1cm47XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgY29uc3QgZmV0Y2hDb2xsZWN0aW9uQXJlYVVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoYC91c2VyL2NvbGxlY3Rpb24tYXJlYS8ke3NlbGVjdGVkQ29sbGVjdGlvbn1gKTtcclxuLy8gICAgICAgICBsZXQgdXNlcnMgPSByZXMuZGF0YS51c2VycyB8fCBbXTtcclxuXHJcbi8vICAgICAgICAgLy8gRmlsdGVyIGJ5IENvbGxlY3Rpb24gQXJlYVxyXG4vLyAgICAgICAgIHVzZXJzID0gdXNlcnMuZmlsdGVyKFxyXG4vLyAgICAgICAgICAgKHVzZXIpID0+IHVzZXIuY29sbGVjdGlvbl9hcmVhPy5faWQgPT09IHNlbGVjdGVkQ29sbGVjdGlvblxyXG4vLyAgICAgICAgICk7XHJcblxyXG4vLyAgICAgICAgIC8vIOKtkCBTSU5HTEUgRU1QTE9ZRUUgRklMVEVSXHJcbi8vICAgICAgICAgaWYgKHNlbGVjdGVkRW1wbG95ZWUpIHtcclxuLy8gICAgICAgICAgIHVzZXJzID0gdXNlcnMuZmlsdGVyKCh1c2VyKSA9PlxyXG4vLyAgICAgICAgICAgICB1c2VyLmNvbGxlY3Rpb25fYXJlYT8uYWdlbnRfaWQ/LnNvbWUoXHJcbi8vICAgICAgICAgICAgICAgKGFnZW50KSA9PiBhZ2VudC5faWQgPT09IHNlbGVjdGVkRW1wbG95ZWVcclxuLy8gICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICB9XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB1c2Vycy5tYXAoKGFyZWEsIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgaWQ6IGFyZWEuX2lkIHx8IGluZGV4LFxyXG4vLyAgICAgICAgICAgU2xObzogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgICAgY3VzdG9tZXJJZDogYXJlYS5jdXN0b21lcl9pZCB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIGN1c3RvbWVyTmFtZTogYXJlYS5mdWxsX25hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICBjdXN0b21lclBob25lTm86IGFyZWEucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgY29sbGVjdGlvbkFyZWFSb3V0ZU5hbWU6IGFyZWEuY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgY29sbGVjdGlvbkFyZWFSb3V0ZVBpbmNvZGU6IGFyZWEuY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9waW5jb2RlIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgICAgY29sbGVjdGlvbkVtcGxveWVlTmFtZTpcclxuLy8gICAgICAgICAgICAgYXJlYS5jb2xsZWN0aW9uX2FyZWE/LmFnZW50X2lkPy5tYXAoKGEpID0+IGEubmFtZSk/LmpvaW4oXCIgfCBcIikgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICBjb2xsZWN0aW9uRW1wbG95ZWVQaG9uZU5vOlxyXG4vLyAgICAgICAgICAgICBhcmVhLmNvbGxlY3Rpb25fYXJlYT8uYWdlbnRfaWQ/Lm1hcCgoYSkgPT4gYS5waG9uZV9udW1iZXIpPy5qb2luKFwiIHwgXCIpIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIH0pKTtcclxuXHJcbi8vICAgICAgICAgc2V0Q29sbGVjdGlvbkFyZWFUYWJsZShmb3JtYXR0ZWREYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwi4p2MIEVycm9yIGZldGNoaW5nIGNvbGxlY3Rpb24gYXJlYSB1c2VyczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGZldGNoQ29sbGVjdGlvbkFyZWFVc2VycygpO1xyXG4vLyAgIH0sIFtzZWxlY3RlZENvbGxlY3Rpb24sIHNlbGVjdGVkRW1wbG95ZWVdKTtcclxuXHJcbi8vICAgY29uc3QgY29sbGVjdGlvbkFyZWFDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwiU2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiY3VzdG9tZXJOYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImN1c3RvbWVyUGhvbmVOb1wiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNvbGxlY3Rpb25BcmVhUm91dGVOYW1lXCIsIGhlYWRlcjogXCJSb3V0ZSBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNvbGxlY3Rpb25BcmVhUm91dGVQaW5jb2RlXCIsIGhlYWRlcjogXCJQaW5jb2RlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNvbGxlY3Rpb25FbXBsb3llZU5hbWVcIiwgaGVhZGVyOiBcIkNvbGxlY3Rpb24gRXhlY3V0aXZlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNvbGxlY3Rpb25FbXBsb3llZVBob25lTm9cIiwgaGVhZGVyOiBcIkV4ZWN1dGl2ZSBQaG9uZSBOb1wiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgaWYgKGxvYWRpbmcpIHJldHVybiA8Q2lyY3VsYXJMb2FkZXIgLz47XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCB3LWZ1bGxcIj5cclxuLy8gICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LTJ4bCBtYi01XCI+Q29sbGVjdGlvbiBBcmVhIFJlcG9ydDwvaDE+XHJcblxyXG4vLyAgICAgICB7LyogLS0tIEZJTFRFUiBTRUNUSU9OIChsaWtlIENoaXQgQXNraW5nIFVJKSAtLS0gKi99XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LWxnIGJvcmRlciBtYi02XCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC02XCI+XHJcblxyXG4vLyAgICAgICAgICAgey8qIENvbGxlY3Rpb24gQXJlYSBGaWx0ZXIgKi99XHJcbi8vICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuLy8gICAgICAgICAgICAgICBTZWxlY3QgQ29sbGVjdGlvbiBBcmVhXHJcbi8vICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4vLyAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIENvbGxlY3Rpb24gQXJlYVwiXHJcbi8vICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ29sbGVjdGlvbn1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRDb2xsZWN0aW9ufVxyXG4vLyAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgb3B0aW9uLmxhYmVsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAge2NvbGxlY3Rpb25BcmVhTGlzdC5tYXAoKGFyZWEpID0+IChcclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbi8vICAgICAgICAgICAgICAgICAgIGtleT17YXJlYS5faWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXthcmVhLl9pZH1cclxuLy8gICAgICAgICAgICAgICAgICAgbGFiZWw9e2Ake2FyZWEucm91dGVfbmFtZX0gfCAke2FyZWEucm91dGVfcGluY29kZX1gfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7YXJlYS5yb3V0ZV9uYW1lfSB8IHthcmVhLnJvdXRlX3BpbmNvZGV9XHJcbi8vICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIEVtcGxveWVlIEZpbHRlciAoc2luZ2xlIHNlbGVjdCkgKi99XHJcbi8vICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuLy8gICAgICAgICAgICAgICBDb2xsZWN0aW9uIEVtcGxveWVlXHJcbi8vICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4vLyAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIEVtcGxveWVlXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZX1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRFbXBsb3llZX1cclxuLy8gICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVPcHRpb25zfVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgIHsvKiBEYXRhVGFibGUgKi99XHJcbi8vICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICBjb2x1bW5zPXtjb2xsZWN0aW9uQXJlYUNvbHVtbnN9XHJcbi8vICAgICAgICAgZGF0YT17Y29sbGVjdGlvbkFyZWFUYWJsZX1cclxuLy8gICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDb2xsZWN0aW9uIEFyZWEgUmVwb3J0XCJcclxuLy8gICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ29sbGVjdGlvbiBBcmVhIFJlcG9ydC5jc3ZcIlxyXG4vLyAgICAgICAgIG5vRGF0YU1lc3NhZ2U9XCJQbGVhc2Ugc2VsZWN0IGEgY29sbGVjdGlvbiBhcmVhIHRvIHZpZXcgZGF0YVwiXHJcbi8vICAgICAgIC8+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuY29uc3QgU3RhdHNDYXJkID0gKHsgdGl0bGUsIGFtb3VudCwgY291bnQsIGljb246IEljb24sIGNvbG9yIH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTEwMCByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgcC01XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+e3RpdGxlfTwvcD5cclxuXHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIG10LTJcIj5cclxuICAgICAgICAgICAg4oK5e051bWJlcihhbW91bnQpLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgIEN1c3RvbWVyczoge2NvdW50fVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y29sb3J9IHAtMyByb3VuZGVkLXhsYH0+XHJcbiAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBDb2xsZWN0aW9uQXJlYVJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbY29sbGVjdGlvbkFyZWFMaXN0LCBzZXRDb2xsZWN0aW9uQXJlYUxpc3RdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZENvbGxlY3Rpb24sIHNldFNlbGVjdGVkQ29sbGVjdGlvbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY29sbGVjdGlvbkFyZWFUYWJsZSwgc2V0Q29sbGVjdGlvbkFyZWFUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbZW1wbG95ZWVPcHRpb25zLCBzZXRFbXBsb3llZU9wdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlLCBzZXRTZWxlY3RlZEVtcGxveWVlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICAvLyBGZXRjaCBhbGwgQ29sbGVjdGlvbiBBcmVhc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaENvbGxlY3Rpb25BcmVhcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2NvbGxlY3Rpb24tYXJlYS1yZXF1ZXN0L2dldC1jb2xsZWN0aW9uLWFyZWEtZGF0YVwiKTtcclxuICAgICAgICBjb25zdCBsaXN0ID0gcmVzLmRhdGEgfHwgW107XHJcbiAgICAgICAgc2V0Q29sbGVjdGlvbkFyZWFMaXN0KGxpc3QpO1xyXG5cclxuICAgICAgICAvLyBFeHRyYWN0IHVuaXF1ZSBlbXBsb3llZXNcclxuICAgICAgICBjb25zdCBlbXBsb3llZXNTZXQgPSBuZXcgTWFwKCk7XHJcbiAgICAgICAgbGlzdC5mb3JFYWNoKChhcmVhKSA9PiB7XHJcbiAgICAgICAgICBhcmVhLmFnZW50X2lkPy5mb3JFYWNoKChhKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghZW1wbG95ZWVzU2V0LmhhcyhhLl9pZCkpIHtcclxuICAgICAgICAgICAgICBlbXBsb3llZXNTZXQuc2V0KGEuX2lkLCB7XHJcbiAgICAgICAgICAgICAgICBsYWJlbDogYCR7YS5uYW1lfSB8ICR7YS5waG9uZV9udW1iZXJ9YCxcclxuICAgICAgICAgICAgICAgIHZhbHVlOiBhLl9pZCxcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldEVtcGxveWVlT3B0aW9ucyhbLi4uZW1wbG95ZWVzU2V0LnZhbHVlcygpXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIuKdjCBFcnJvciBmZXRjaGluZyBjb2xsZWN0aW9uIGFyZWFzOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaENvbGxlY3Rpb25BcmVhcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gRmV0Y2ggVXNlcnNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZENvbGxlY3Rpb24pIHtcclxuICAgICAgc2V0Q29sbGVjdGlvbkFyZWFUYWJsZShbXSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBmZXRjaENvbGxlY3Rpb25BcmVhVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3VzZXIvY29sbGVjdGlvbi1hcmVhLyR7c2VsZWN0ZWRDb2xsZWN0aW9ufWApO1xyXG4gICAgICAgIGxldCB1c2VycyA9IHJlcy5kYXRhLnVzZXJzIHx8IFtdO1xyXG5cclxuICAgICAgICAvLyDirZAgU0lOR0xFIEVNUExPWUVFIEZJTFRFUlxyXG4gICAgICAgIGlmIChzZWxlY3RlZEVtcGxveWVlKSB7XHJcbiAgICAgICAgICB1c2VycyA9IHVzZXJzLmZpbHRlcigodXNlcikgPT5cclxuICAgICAgICAgICAgdXNlci5leGVjdXRpdmVfbmFtZSAmJiB1c2VyLmV4ZWN1dGl2ZV9waG9uZV9udW1iZXIgJiZcclxuICAgICAgICAgICAgdXNlci5leGVjdXRpdmVfcGhvbmVfbnVtYmVyID09PSBlbXBsb3llZU9wdGlvbnMuZmluZChcclxuICAgICAgICAgICAgICAoZW1wKSA9PiBlbXAudmFsdWUgPT09IHNlbGVjdGVkRW1wbG95ZWVcclxuICAgICAgICAgICAgKT8ubGFiZWwuc3BsaXQoJ3wnKVsxXT8udHJpbSgpXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gRm9ybWF0IGRhdGEgZm9yIHRhYmxlXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHVzZXJzLm1hcCgodXNlciwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBpZDogdXNlci5jdXN0b21lcl9pZCB8fCBpbmRleCxcclxuICAgICAgICAgIFNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIGN1c3RvbWVySWQ6IHVzZXIuY3VzdG9tZXJfaWQgfHwgXCItXCIsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IHVzZXIuZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJQaG9uZU5vOiB1c2VyLnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgIGNvbGxlY3Rpb25BcmVhUm91dGVOYW1lOiB1c2VyLnJvdXRlX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICBjb2xsZWN0aW9uQXJlYVJvdXRlUGluY29kZTogdXNlci5waW5jb2RlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgY29sbGVjdGlvbkVtcGxveWVlTmFtZTogdXNlci5leGVjdXRpdmVfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICAgIGNvbGxlY3Rpb25FbXBsb3llZVBob25lTm86IHVzZXIuZXhlY3V0aXZlX3Bob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgIHBheW1lbnRUeXBlOiB1c2VyLnBheW1lbnRfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgIGluc3RhbGxtZW50VmFsdWU6IHVzZXIuaW5zdGFsbG1lbnRfdmFsdWUgfHwgXCItXCIsXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRDb2xsZWN0aW9uQXJlYVRhYmxlKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCLinYwgRXJyb3IgZmV0Y2hpbmcgY29sbGVjdGlvbiBhcmVhIHVzZXJzOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hDb2xsZWN0aW9uQXJlYVVzZXJzKCk7XHJcbiAgfSwgW3NlbGVjdGVkQ29sbGVjdGlvbiwgc2VsZWN0ZWRFbXBsb3llZV0pO1xyXG5cclxuICAvLyBVcGRhdGVkIGNvbHVtbnMgd2l0aCBQYXltZW50IFR5cGUgYW5kIEluc3RhbGxtZW50XHJcbiAgY29uc3QgY29sbGVjdGlvbkFyZWFDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiU2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJOYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyUGhvbmVOb1wiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25BcmVhUm91dGVOYW1lXCIsIGhlYWRlcjogXCJSb3V0ZSBOYW1lXCIgfSxcclxuICAgICB7IGtleTogXCJwYXltZW50VHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSwgICAgICAgXHJcbiAgICB7IGtleTogXCJpbnN0YWxsbWVudFZhbHVlXCIsIGhlYWRlcjogXCJJbnN0YWxsbWVudCBBbW91bnRcIiB9LCBcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25BcmVhUm91dGVQaW5jb2RlXCIsIGhlYWRlcjogXCJQaW5jb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25FbXBsb3llZU5hbWVcIiwgaGVhZGVyOiBcIkNvbGxlY3Rpb24gRXhlY3V0aXZlXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25FbXBsb3llZVBob25lTm9cIiwgaGVhZGVyOiBcIkV4ZWN1dGl2ZSBQaG9uZSBOb1wiIH0sXHJcbiAgIFxyXG4gIF07XHJcblxyXG5cclxuICAgIGNvbnN0IHBheW1lbnRTdGF0cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gIGNvbnN0IHN0YXRzID0ge1xyXG4gICAgZGFpbHk6IHsgY291bnQ6IDAsIGFtb3VudDogMCB9LFxyXG4gICAgd2Vla2x5OiB7IGNvdW50OiAwLCBhbW91bnQ6IDAgfSxcclxuICAgIG1vbnRobHk6IHsgY291bnQ6IDAsIGFtb3VudDogMCB9LFxyXG4gICAgdG90YWw6IHsgY291bnQ6IDAsIGFtb3VudDogMCB9LFxyXG4gIH07XHJcblxyXG4gIGNvbGxlY3Rpb25BcmVhVGFibGUuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgY29uc3QgdHlwZSA9IChpdGVtLnBheW1lbnRUeXBlIHx8IFwiXCIpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBjb25zdCBhbW91bnQgPSBOdW1iZXIoaXRlbS5pbnN0YWxsbWVudFZhbHVlIHx8IDApO1xyXG5cclxuICAgIGlmICh0eXBlID09PSBcImRhaWx5XCIpIHtcclxuICAgICAgc3RhdHMuZGFpbHkuY291bnQrKztcclxuICAgICAgc3RhdHMuZGFpbHkuYW1vdW50ICs9IGFtb3VudDtcclxuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJ3ZWVrbHlcIikge1xyXG4gICAgICBzdGF0cy53ZWVrbHkuY291bnQrKztcclxuICAgICAgc3RhdHMud2Vla2x5LmFtb3VudCArPSBhbW91bnQ7XHJcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09IFwibW9udGhseVwiKSB7XHJcbiAgICAgIHN0YXRzLm1vbnRobHkuY291bnQrKztcclxuICAgICAgc3RhdHMubW9udGhseS5hbW91bnQgKz0gYW1vdW50O1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXRzLnRvdGFsLmNvdW50Kys7XHJcbiAgICBzdGF0cy50b3RhbC5hbW91bnQgKz0gYW1vdW50O1xyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gc3RhdHM7XHJcbn0sIFtjb2xsZWN0aW9uQXJlYVRhYmxlXSk7XHJcblxyXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gPENpcmN1bGFyTG9hZGVyIC8+O1xyXG5cclxuXHJcblxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgdy1mdWxsXCI+XHJcbiAgICAgIDxkaXY+XHJcbiAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgQ29sbGVjdGlvbiBBcmVhIFJlcG9ydFxyXG4gICAgPC9oMT5cclxuXHJcbiAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgTWFuYWdlIERhaWx5LCBXZWVrbHkgYW5kIE1vbnRobHkgY29sbGVjdGlvbnMgYWNyb3NzIGFsbCByb3V0ZXMuXHJcbiAgICA8L3A+XHJcbiAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogRmlsdGVyIFNlY3Rpb24gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LWxnIGJvcmRlciBtYi04IG10LTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuXHJcbiAgICAgICAgICB7LyogQ29sbGVjdGlvbiBBcmVhIEZpbHRlciAqL30gIFxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgU2VsZWN0IENvbGxlY3Rpb24gQXJlYVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBDb2xsZWN0aW9uIEFyZWFcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZENvbGxlY3Rpb259XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkQ29sbGVjdGlvbn1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgIG9wdGlvbi5sYWJlbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtjb2xsZWN0aW9uQXJlYUxpc3QubWFwKChhcmVhKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2FyZWEuX2lkfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YXJlYS5faWR9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHthcmVhLnJvdXRlX25hbWV9IHwgJHthcmVhLnJvdXRlX3BpbmNvZGV9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2FyZWEucm91dGVfbmFtZX0gfCB7YXJlYS5yb3V0ZV9waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBFbXBsb3llZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBDb2xsZWN0aW9uIEVtcGxveWVlXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRFbXBsb3llZX1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVPcHRpb25zfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIFxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC01IG1iLTZcIj5cclxuXHJcbiAgPFN0YXRzQ2FyZFxyXG4gICAgdGl0bGU9XCJEYWlseSBDb2xsZWN0aW9uXCJcclxuICAgIGFtb3VudD17cGF5bWVudFN0YXRzLmRhaWx5LmFtb3VudH1cclxuICAgIGNvdW50PXtwYXltZW50U3RhdHMuZGFpbHkuY291bnR9XHJcbiAgICBpY29uPXtDYWxlbmRhckRheXN9XHJcbiAgICBjb2xvcj1cImJnLWJsdWUtNTAwXCJcclxuICAvPlxyXG5cclxuICA8U3RhdHNDYXJkXHJcbiAgICB0aXRsZT1cIldlZWtseSBDb2xsZWN0aW9uXCJcclxuICAgIGFtb3VudD17cGF5bWVudFN0YXRzLndlZWtseS5hbW91bnR9XHJcbiAgICBjb3VudD17cGF5bWVudFN0YXRzLndlZWtseS5jb3VudH1cclxuICAgIGljb249e0NhbGVuZGFyUmFuZ2V9XHJcbiAgICBjb2xvcj1cImJnLWdyZWVuLTUwMFwiXHJcbiAgLz5cclxuXHJcbiAgPFN0YXRzQ2FyZFxyXG4gICAgdGl0bGU9XCJNb250aGx5IENvbGxlY3Rpb25cIlxyXG4gICAgYW1vdW50PXtwYXltZW50U3RhdHMubW9udGhseS5hbW91bnR9XHJcbiAgICBjb3VudD17cGF5bWVudFN0YXRzLm1vbnRobHkuY291bnR9XHJcbiAgICBpY29uPXtDYWxlbmRhcn1cclxuICAgIGNvbG9yPVwiYmctcHVycGxlLTUwMFwiXHJcbiAgLz5cclxuXHJcbiAgPFN0YXRzQ2FyZFxyXG4gICAgdGl0bGU9XCJUb3RhbCBDb2xsZWN0aW9uXCJcclxuICAgIGFtb3VudD17cGF5bWVudFN0YXRzLnRvdGFsLmFtb3VudH1cclxuICAgIGNvdW50PXtwYXltZW50U3RhdHMudG90YWwuY291bnR9XHJcbiAgICBpY29uPXtJbmRpYW5SdXBlZX1cclxuICAgIGNvbG9yPVwiYmctb3JhbmdlLTUwMFwiXHJcbiAgLz5cclxuXHJcbjwvZGl2PlxyXG5cclxuICAgICAgey8qIERhdGFUYWJsZSAqL31cclxuICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgIGNvbHVtbnM9e2NvbGxlY3Rpb25BcmVhQ29sdW1uc31cclxuICAgICAgICBkYXRhPXtjb2xsZWN0aW9uQXJlYVRhYmxlfVxyXG4gICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkNvbGxlY3Rpb24gQXJlYSBSZXBvcnRcIlxyXG4gICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDb2xsZWN0aW9uIEFyZWEgUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgbm9EYXRhTWVzc2FnZT1cIlBsZWFzZSBzZWxlY3QgYSBjb2xsZWN0aW9uIGFyZWEgdG8gdmlldyBkYXRhXCJcclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IENvbGxlY3Rpb25BcmVhUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQ29sbGVjdGlvbkFyZWFSZXBvcnQuanN4In0=