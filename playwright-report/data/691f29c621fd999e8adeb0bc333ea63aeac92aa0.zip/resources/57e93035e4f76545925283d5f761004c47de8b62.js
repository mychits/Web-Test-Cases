import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitCancelPaymentForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select, Spin, Drawer } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaWhatsappSquare, FaHistory } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
const ChitCancelPaymentForm = ({ userId: initialUserId, userData: initialUserData, onClose, onSuccess }) => {
  _s();
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const yesterday = new Date((/* @__PURE__ */ new Date()).setDate((/* @__PURE__ */ new Date()).getDate() - 1)).toISOString().split("T")[0];
  const [users, setUsers] = useState([]);
  const [deletedEnrollments, setDeletedEnrollments] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(initialUserId || "");
  const [userAccountInfo, setUserAccountInfo] = useState(null);
  const [fetchingBalance, setFetchingBalance] = useState(false);
  const [enrollmentLoading, setEnrollmentLoading] = useState(false);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [errors, setErrors] = useState({});
  const [whatsappEnable, setWhatsappEnable] = useState(true);
  const [transactionHistory, setTransactionHistory] = useState([]);
  const [serviceCharge, setServiceCharge] = useState(0);
  const [gstAmount, setGstAmount] = useState(0);
  const [removalReason, setRemovalReason] = useState();
  const [loadingTransaction, setLoadingTransaction] = useState(false);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [borrowers, setBorrowers] = useState([]);
  const [showTxnDrawer, setShowTxnDrawer] = useState(false);
  const [formData, setFormData] = useState({
    user_id: initialUserId || "",
    group_id: "",
    ticket: "",
    pay_date: today,
    total_amount: "",
    deductions: "",
    amount: "",
    pay_type: "Bank Transfer",
    transaction_id: "",
    admin_type: "",
    pay_for: "",
    note: "",
    disbursement_type: "Transfer",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: "",
    pigme_id: "",
    loan_id: ""
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    const perms = user?.admin_access_right_id?.access_permissions || {};
    if (perms.edit_payment === "true") setModifyPayment(true);
    if (perms.edit_limited_payment === "true") {
      setModifyPayment(true);
      setModifyMinMaxPaymentDate(true);
    }
  }, []);
  const mapRemovalReasonToPayFor = (reason) => {
    if (!reason) return "";
    const lower = reason.toLowerCase();
    if (lower.includes("close")) {
      return "Chit Close / Payout";
    }
    if (lower.includes("cancel")) {
      return "Chit Cancellation / Payout";
    }
    return "";
  };
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await api.get("user/verified");
        setUsers(res?.data?.data || []);
      } catch {
        setUsers([]);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    if (initialUserId) {
      setSelectedUserId(initialUserId);
      setFormData((prev) => ({ ...prev, user_id: initialUserId }));
    }
    if (initialUserData) {
      setUserAccountInfo(initialUserData);
      setFormData((prev) => ({
        ...prev,
        total_amount: initialUserData.balance?.toString() || "",
        deductions: "",
        amount: initialUserData.balance?.toString() || ""
      }));
    }
  }, [initialUserId, initialUserData]);
  useEffect(() => {
    if (!selectedUserId) return;
    const fetchTransactionHistory = async () => {
      setLoadingTransaction(true);
      try {
        const res = await api.get("/v1/admin/transaction-history/");
        const transactions = res.data.data || [];
        const userTransactions = transactions.filter(
          (txn) => txn.enroll_id?.user_id?._id === selectedUserId
        );
        setTransactionHistory(userTransactions);
        if (userTransactions.length > 0) {
          const sorted = userTransactions.sort(
            (a, b) => new Date(b.transaction_date) - new Date(a.transaction_date)
          );
          const latest = sorted[0];
          setServiceCharge(latest.service_charge || 0);
          setGstAmount(latest.gst_amount || 0);
          const reason = latest?.enroll_id?.removal_reason;
          setRemovalReason(reason);
          setFormData((prev) => {
            if (!prev.pay_for) {
              const mapped = mapRemovalReasonToPayFor(reason);
              return { ...prev, pay_for: mapped };
            }
            return prev;
          });
        } else {
          setServiceCharge(0);
          setGstAmount(0);
        }
      } catch (error) {
        console.error("Error fetching transaction history:", error);
        setServiceCharge(0);
        setGstAmount(0);
      } finally {
        setLoadingTransaction(false);
      }
    };
    fetchTransactionHistory();
  }, [selectedUserId]);
  useEffect(() => {
    if (!selectedUserId) {
      setBorrowers([]);
      setPigmeCustomers([]);
      return;
    }
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(`/loans/get-borrower-by-user-id/${selectedUserId}`);
        setBorrowers(response.data);
      } catch {
        setBorrowers([]);
      }
    };
    const fetchPigmeDetails = async () => {
      try {
        const response = await api.get(`/pigme/get-pigme-customer-by-user-id/${selectedUserId}`);
        setPigmeCustomers(response.data);
      } catch {
        setPigmeCustomers([]);
      }
    };
    fetchCustomerLoanDetails();
    fetchPigmeDetails();
  }, [selectedUserId]);
  useEffect(() => {
    if (!selectedUserId) return;
    const allOptions = [
      ...pigmeCustomers.map((pigme) => `pigme-${pigme._id}`),
      ...borrowers.map((borrower) => `loan-${borrower._id}`)
    ];
  }, [pigmeCustomers, selectedUserId]);
  useEffect(() => {
    if (!selectedUserId) {
      setUserAccountInfo(null);
      setDeletedEnrollments([]);
      return;
    }
    const fetchAccount = async () => {
      setFetchingBalance(true);
      try {
        if (initialUserData && initialUserData._id === selectedUserId) {
          setUserAccountInfo(initialUserData);
          setFormData((prev) => ({
            ...prev,
            total_amount: initialUserData.balance?.toString() || "",
            deductions: "",
            amount: initialUserData.balance?.toString() || ""
          }));
          setFetchingBalance(false);
          return;
        }
        const res = await api.get(`/v1/admin/user-accounts/${selectedUserId}`);
        if (res.data?.status) {
          const account = res.data.data;
          setUserAccountInfo(account);
          setFormData((prev) => ({
            ...prev,
            total_amount: account.balance?.toString() || "",
            deductions: "",
            amount: account.balance?.toString() || ""
          }));
        } else {
          setUserAccountInfo(null);
        }
      } catch {
        setUserAccountInfo(null);
      } finally {
        setFetchingBalance(false);
      }
    };
    const fetchEnrollments = async () => {
      setEnrollmentLoading(true);
      try {
        const res = await api.get(`/enroll/get-deleted-enrollments`);
        const data = res.data || [];
        const matched = data.filter((item) => item.user_id?._id === selectedUserId);
        setDeletedEnrollments(matched);
        if (matched.length > 0) {
          const first = matched[0];
          setFormData((prev) => ({
            ...prev,
            group_id: first.group_id?._id,
            ticket: first.tickets
          }));
        }
      } catch {
        setDeletedEnrollments([]);
      } finally {
        setEnrollmentLoading(false);
      }
    };
    fetchAccount();
    fetchEnrollments();
  }, [selectedUserId, initialUserData]);
  const handleCustomer = (userId) => {
    setSelectedUserId(userId);
    setFormData((prev) => ({
      ...prev,
      user_id: userId,
      group_id: "",
      ticket: ""
    }));
    setErrors((prev) => ({ ...prev, customer: "", group_ticket: "" }));
    setServiceCharge(0);
    setGstAmount(0);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (["total_amount", "deductions", "amount"].includes(name)) {
      let cleaned = value.replace(/[^0-9.]/g, "");
      if ((cleaned.match(/\./g) || []).length > 1) return;
      setFormData((prev) => {
        const updated = { ...prev, [name]: cleaned };
        if (name === "total_amount" || name === "deductions") {
          const total = parseFloat(name === "total_amount" ? cleaned : updated.total_amount) || 0;
          const deduction = parseFloat(name === "deductions" ? cleaned : updated.deductions) || 0;
          updated.amount = Math.max(total - deduction, 0).toString();
        }
        return updated;
      });
      return;
    }
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({
      ...prev,
      [name]: ""
    }));
  };
  const handlePaymentModeChange = (e) => {
    const mode = e.target.value;
    setFormData((prev) => ({
      ...prev,
      pay_type: mode,
      transaction_id: mode === "cash" ? "" : prev.transaction_id,
      ...mode !== "cheque" && {
        cheque_number: "",
        cheque_date: "",
        cheque_bank_name: "",
        cheque_bank_branch: ""
      }
    }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!formData.user_id) newErrors.customer = "Please select a customer";
    if (!formData.group_id && !formData.pigme_id && !formData.loan_id) {
      newErrors.group_ticket = "Please select a group and ticket";
    }
    if (!formData.pay_date) newErrors.pay_date = "Payment date is required";
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    } else if (userAccountInfo && amount > userAccountInfo.balance) {
      newErrors.amount = `Amount cannot exceed available balance of ₹${userAccountInfo.balance.toLocaleString()}`;
    }
    if (formData.pay_type === "online" || formData.pay_type === "online/upi" || formData.pay_type === "Bank Transfer") {
      if (!formData.transaction_id?.trim())
        newErrors.transaction_id = "Transaction ID is required for online payments";
    } else if (formData.pay_type === "cheque") {
      if (!formData.cheque_number?.trim()) newErrors.cheque_number = "Cheque number is required";
      if (!formData.cheque_date?.trim()) newErrors.cheque_date = "Cheque date is required";
    }
    if (!formData.pay_for) newErrors.pay_for = "Please select reason";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    const admin = JSON.parse(localStorage.getItem("user") || "{}");
    const isPigmy = formData.pay_for === "Pigmy Close / Payout";
    const payload = {
      user_id: formData.user_id,
      ...isPigmy ? { pigme_id: formData.pigme_id } : { group_id: formData.group_id },
      ...isPigmy ? { pay_for: "Pigme" } : "",
      ticket: formData.ticket.toString(),
      pay_date: formData.pay_date,
      total_amount: formData.total_amount || "0",
      deductions: formData.deductions || "0",
      amount: formData.amount,
      pay_type: formData.pay_type,
      reason: formData?.pay_for,
      disbursement_type: formData.pay_for === "Chit Cancellation / Payout" ? "Chit Cancellation" : isPigmy ? "Pigmy Close" : "Chit Close",
      transaction_id: formData.transaction_id || "",
      admin_id: admin._id,
      admin_type: admin._id,
      deleted: false,
      note: formData.note,
      // disbursement_type: "Transfer",
      service_charge: serviceCharge.toString(),
      gst_amount: gstAmount.toString(),
      ...formData.pay_type === "cheque" && {
        cheque_number: formData.cheque_number,
        cheque_date: formData.cheque_date,
        cheque_bank_name: formData.cheque_bank_name,
        cheque_bank_branch: formData.cheque_bank_branch
      }
    };
    setOpenBackdropLoader(true);
    try {
      await api.post("v1/admin/user-accounts/payout", payload);
      if (onSuccess) onSuccess();
      onClose();
    } catch (error) {
      console.error(error);
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Payment Data Processing...." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
      lineNumber: 419,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-6 max-h-[80vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold mb-4 border-b pb-2 flex items-center justify-between", children: /* @__PURE__ */ jsxDEV("span", { children: "Chit Cancellation, Closure & Pigmy Payouts" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
        lineNumber: 423,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
        lineNumber: 422,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "Customer ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 442,
                columnNumber: 26
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 441,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select or search customer",
                showSearch: true,
                size: "large",
                className: "w-full",
                filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                value: formData.user_id || void 0,
                onChange: handleCustomer,
                options: users.map((u) => ({
                  value: u._id,
                  label: `${u.full_name} | ${u.phone_number}`
                }))
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 444,
                columnNumber: 15
              },
              this
            ),
            errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 459,
              columnNumber: 35
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 440,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "Group & Ticket / Pigmy ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 464,
                columnNumber: 40
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 463,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                size: "large",
                className: "w-full",
                value: formData.selectedValue || (formData.ticket ? `${formData.group_id}|${formData.ticket}` : void 0),
                disabled: !formData.user_id || enrollmentLoading,
                loading: enrollmentLoading,
                showSearch: true,
                allowClear: true,
                placeholder: enrollmentLoading ? "Loading..." : "Select Account",
                notFoundContent: enrollmentLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-2", children: /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 481,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 480,
                  columnNumber: 17
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-2 text-gray-500", children: "No Records Found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 484,
                  columnNumber: 17
                }, this),
                onChange: (val) => {
                  if (!val) {
                    setFormData((prev) => ({
                      ...prev,
                      selectedValue: "",
                      group_id: "",
                      ticket: "",
                      pigme_id: "",
                      loan_id: ""
                    }));
                    return;
                  }
                  if (val.startsWith("pigme-")) {
                    setFormData((prev) => ({
                      ...prev,
                      selectedValue: val,
                      pigme_id: val.replace("pigme-", ""),
                      group_id: "",
                      ticket: "",
                      loan_id: ""
                    }));
                  } else if (val.startsWith("loan-")) {
                    setFormData((prev) => ({
                      ...prev,
                      selectedValue: val,
                      loan_id: val.replace("loan-", ""),
                      group_id: "",
                      ticket: "",
                      pigme_id: ""
                    }));
                  } else {
                    const [gid, tkt] = val.split("|");
                    setFormData((prev) => ({
                      ...prev,
                      selectedValue: val,
                      group_id: gid,
                      ticket: tkt,
                      pigme_id: "",
                      loan_id: ""
                    }));
                  }
                  setErrors((prev) => ({ ...prev, group_ticket: "" }));
                },
                filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                options: [
                  // Group & Ticket
                  ...deletedEnrollments.map((item) => ({
                    value: `${item.group_id?._id}|${item.tickets}`,
                    label: `${item.group_id?.group_name} | Ticket ${item.tickets}`
                  })),
                  // Pigmy
                  ...pigmeCustomers.map((pigme) => ({
                    value: `pigme-${pigme._id}`,
                    label: `Pigmy - ${pigme.pigme_id} | ₹${pigme.payable_amount}`
                  })),
                  // Loan
                  ...borrowers.map((borrower) => ({
                    value: `loan-${borrower._id}`,
                    label: `Loan - ${borrower.loan_id} | ₹${borrower.loan_amount}`
                  }))
                ]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 466,
                columnNumber: 15
              },
              this
            ),
            errors.group_ticket && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.group_ticket }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 557,
              columnNumber: 39
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 462,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-indigo-50 border border-indigo-200 rounded-lg p-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "Pay For (Reason) ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 562,
                columnNumber: 34
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 561,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                name: "pay_for",
                value: formData.pay_for,
                onChange: handleChange,
                className: "w-full px-4 py-2 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-indigo-400",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Payment Reason" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 571,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Chit Cancellation / Payout", children: "Chit Cancellation" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 572,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Chit Close / Payout", children: "Chit Close" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 573,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Pigmy Close / Payout", children: "Pigmy Close" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 574,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 565,
                columnNumber: 15
              },
              this
            ),
            errors.pay_for && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_for }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 579,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 560,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 439,
          columnNumber: 11
        }, this),
        userAccountInfo?.balance > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 border border-green-200 rounded-xl p-5 shadow-sm relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 right-4", children: selectedUserId && transactionHistory.length > 0 && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowTxnDrawer(true),
              className: "flex items-center gap-1.5 text-xs font-medium bg-white hover:bg-green-100 text-blue-700 px-3 py-1.5 rounded-lg border border-blue-200 shadow-sm transition",
              children: [
                /* @__PURE__ */ jsxDEV(FaHistory, { className: "text-blue-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 600,
                  columnNumber: 21
                }, this),
                "View History"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 595,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 593,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pr-28", children: [
            " ",
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium uppercase tracking-wide text-gray-500", children: "Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 610,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: userAccountInfo.full_name || userAccountInfo?.userDetails?.full_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 613,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 609,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Available Balance" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 619,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-extrabold text-green-700", children: [
                "₹ ",
                Number(userAccountInfo.balance).toLocaleString()
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 622,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 618,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 608,
            columnNumber: 15
          }, this),
          loadingTransaction && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 border-t border-green-200 pt-4 flex items-center justify-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 681,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Loading transaction details..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 682,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 680,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 591,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-4 border border-gray-200 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-800 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-blue-600 rounded-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 693,
              columnNumber: 15
            }, this),
            " Payment Details"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 692,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                "Payment Date ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 698,
                  columnNumber: 32
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 697,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  name: "pay_date",
                  value: formData.pay_date,
                  onChange: handleChange,
                  disabled: !modifyPayment,
                  min: modifyMinMaxPaymentDate ? yesterday : void 0,
                  max: modifyMinMaxPaymentDate ? today : void 0,
                  className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 700,
                  columnNumber: 17
                },
                this
              ),
              errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 710,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 696,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                "Payment Mode ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 714,
                  columnNumber: 32
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 713,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: formData.pay_type,
                  onChange: handlePaymentModeChange,
                  className: "w-full px-4 py-2 border border-gray-300 rounded-lg",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 721,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Bank Transfer", children: "Bank Transfer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 722,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "online/upi", children: "Online / UPI" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 723,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 724,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Credit Note", children: "Credit Note" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 725,
                      columnNumber: 22
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 716,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 712,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 695,
            columnNumber: 13
          }, this),
          (formData.pay_type === "online" || formData.pay_type === "online/upi" || formData.pay_type === "Bank Transfer") && /* @__PURE__ */ jsxDEV("div", { className: "pt-2 border-t border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "Transaction ID ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 734,
                columnNumber: 34
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 733,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "transaction_id",
                value: formData.transaction_id,
                onChange: handleChange,
                placeholder: "Enter Transaction ID",
                className: "w-1/2 px-4 py-2 border border-gray-300 rounded-lg"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 736,
                columnNumber: 17
              },
              this
            ),
            errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 744,
              columnNumber: 43
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 732,
            columnNumber: 13
          }, this),
          formData.pay_type === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "pt-2 border-t border-gray-200 space-y-4", children: [
            /* @__PURE__ */ jsxDEV("h5", { className: "font-semibold text-gray-800", children: "Cheque Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 751,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                  "Cheque Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 755,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 754,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "cheque_number",
                    value: formData.cheque_number,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 757,
                    columnNumber: 21
                  },
                  this
                ),
                errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 764,
                  columnNumber: 46
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 753,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                  "Cheque Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 768,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 767,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "cheque_date",
                    value: formData.cheque_date,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 770,
                    columnNumber: 21
                  },
                  this
                ),
                errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 777,
                  columnNumber: 44
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 766,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Bank Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 780,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "cheque_bank_name",
                    value: formData.cheque_bank_name,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 781,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 779,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Bank Branch" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 790,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "cheque_bank_branch",
                    value: formData.cheque_bank_branch,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 791,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 789,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 752,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 750,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 691,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 rounded-lg p-4 space-y-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "Amount ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 812,
                columnNumber: 26
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 811,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                name: "amount",
                value: formData.amount,
                onChange: handleChange,
                placeholder: "Net payable",
                className: "w-full px-4 py-2 border border-gray-300 rounded-lg bg-blue-50 font-medium text-blue-800"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 814,
                columnNumber: 17
              },
              this
            ),
            errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 822,
              columnNumber: 35
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 mt-1", children: numberToIndianWords(formData.amount) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 823,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 810,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Note (optional)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 841,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                name: "note",
                value: formData.note,
                onChange: handleChange,
                rows: 2,
                placeholder: "Additional remarks (optional)",
                className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 842,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 840,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 809,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 805,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 border border-gray-200 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { className: "text-green-500 text-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 857,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: "WhatsApp Notification" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 858,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 856,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                checked: whatsappEnable,
                onChange: (e) => setWhatsappEnable(e.target.checked),
                className: "w-5 h-5 text-green-500 rounded"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 861,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Send via WhatsApp" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 867,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 860,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 855,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 pt-4 border-t border-gray-200", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "px-4 py-2 text-sm text-gray-500 hover:bg-gray-100 rounded",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 873,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "px-6 py-2 text-sm bg-blue-600 text-white rounded font-bold hover:bg-blue-700 shadow-lg",
              children: "Confirm Disbursement"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 880,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 872,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
        lineNumber: 437,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
      lineNumber: 421,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between w-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-xl", children: /* @__PURE__ */ jsxDEV(FaHistory, { className: "text-blue-600 text-sm" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 898,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 897,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900", children: "Transaction History" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 902,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: [
                transactionHistory.length,
                " record",
                transactionHistory.length !== 1 ? "s" : "",
                " found"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                lineNumber: 906,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 901,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 896,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-right mr-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 915,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-blue-600", children: transactionHistory?.[0]?.enroll_id?.user_id?.full_name || userAccountInfo?.full_name || "N/A" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 916,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 914,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 894,
          columnNumber: 9
        }, this),
        placement: "right",
        open: showTxnDrawer,
        onClose: () => setShowTxnDrawer(false),
        width: 620,
        closable: false,
        className: "transaction-drawer",
        styles: {
          body: { padding: "0", background: "#f8fafc" },
          header: {
            padding: "20px 24px",
            borderBottom: "1px solid #e2e8f0",
            background: "#ffffff"
          }
        },
        extra: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowTxnDrawer(false),
            className: "p-2 rounded-xl hover:bg-gray-100 transition-colors",
            children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-gray-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 944,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 943,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 939,
            columnNumber: 9
          },
          this
        ),
        children: loadingTransaction ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-64 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 border-3 border-blue-200 border-t-blue-600 rounded-full animate-spin" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 951,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 font-medium", children: "Loading transactions..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 952,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 950,
          columnNumber: 9
        }, this) : transactionHistory.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-64 text-center px-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-8 h-8 text-gray-300", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "1.5", d: "M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 958,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 957,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 956,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-500", children: "No transactions found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 961,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-1", children: "Payment history for this customer will appear here" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
            lineNumber: 962,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 955,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-4 space-y-3", children: transactionHistory.map((txn, idx) => {
          const net = Number(txn.amount);
          const service = Number(txn.service_charge || 0);
          const gst = Number(txn.gst_amount || 0);
          const gross = txn.total_amount || net + service + gst;
          const isCredit = txn.transaction_type?.toLowerCase()?.includes("credit") || txn.transaction_type?.toLowerCase()?.includes("refund") || txn.transaction_type?.toLowerCase()?.includes("receipt");
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: `h-1 w-full ${isCredit ? "bg-gradient-to-r from-emerald-400 to-green-500" : "bg-gradient-to-r from-blue-400 to-indigo-500"}` }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 982,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: `w-8 h-8 rounded-lg flex items-center justify-center ${isCredit ? "bg-emerald-50" : "bg-blue-50"}`, children: isCredit ? /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4 text-emerald-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M7 11l5-5m0 0l5 5m-5-5v12" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 991,
                        columnNumber: 31
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 990,
                        columnNumber: 25
                      }, this) : /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4 text-blue-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 995,
                        columnNumber: 31
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 994,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 988,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-800", children: new Date(txn.transaction_date).toLocaleDateString("en-IN", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric"
                        }) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                          lineNumber: 1e3,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: new Date(txn.transaction_date).toLocaleTimeString("en-IN", {
                          hour: "2-digit",
                          minute: "2-digit"
                        }) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                          lineNumber: 1005,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 999,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 987,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase tracking-wider ${isCredit ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-blue-50 text-blue-700 border border-blue-200"}`, children: txn.transaction_type || "Payment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1013,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 986,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4 p-3 bg-slate-50 rounded-xl", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-slate-600", children: (txn.enroll_id?.user_id?.full_name || userAccountInfo?.full_name || "N/A").charAt(0)?.toUpperCase() }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1024,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1023,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-0.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-500 truncate", children: txn.enroll_id?.group_id?.group_name ? txn.enroll_id.group_id.group_name : "N/A" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1034,
                        columnNumber: 27
                      }, this),
                      txn.enroll_id?.tickets && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-300", children: "·" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                          lineNumber: 1041,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded", children: [
                          "Tkt ",
                          txn.enroll_id.tickets
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                          lineNumber: 1042,
                          columnNumber: 31
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1040,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1033,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1029,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 1022,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-2 mb-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-2.5 text-center", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1", children: "Gross" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1054,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: [
                        "₹",
                        gross.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1055,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1053,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-2.5 text-center", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1", children: "Service" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1060,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: [
                        "₹",
                        service.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1061,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1059,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-2.5 text-center", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1", children: "GST" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1066,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: [
                        "₹",
                        gst.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1067,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1065,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: `rounded-xl p-2.5 text-center ${isCredit ? "bg-emerald-50" : "bg-blue-50"}`, children: [
                      /* @__PURE__ */ jsxDEV("p", { className: `text-[10px] font-semibold uppercase tracking-wider mb-1 ${isCredit ? "text-emerald-500" : "text-blue-500"}`, children: "Net" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1072,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: `text-base font-extrabold ${isCredit ? "text-emerald-700" : "text-blue-700"}`, children: [
                        "₹",
                        net.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1073,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1071,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 1052,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 pt-3 border-t border-gray-100", children: [
                    txn.reason && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5", children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-3 h-3 text-amber-500 flex-shrink-0", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1084,
                        columnNumber: 29
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1083,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-amber-700", children: txn.reason }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1086,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1082,
                      columnNumber: 21
                    }, this),
                    txn.pay_type && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5", children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-3 h-3 text-slate-400 flex-shrink-0", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1092,
                        columnNumber: 29
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1091,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-slate-600", children: txn.pay_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1094,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1090,
                      columnNumber: 21
                    }, this),
                    txn.note && /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-1.5 bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 w-full", children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-3 h-3 text-gray-400 flex-shrink-0 mt-0.5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1100,
                        columnNumber: 29
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1099,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-600 italic leading-relaxed", children: txn.note }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                        lineNumber: 1102,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                      lineNumber: 1098,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                    lineNumber: 1080,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
                  lineNumber: 984,
                  columnNumber: 19
                }, this)
              ]
            },
            txn._id || idx,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
              lineNumber: 977,
              columnNumber: 15
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
          lineNumber: 965,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
        lineNumber: 892,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx",
    lineNumber: 418,
    columnNumber: 5
  }, this);
};
_s(ChitCancelPaymentForm, "FStfPBjP4ra2lBWrVclt4rMwkqM=");
_c = ChitCancelPaymentForm;
export default ChitCancelPaymentForm;
var _c;
$RefreshReg$(_c, "ChitCancelPaymentForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancelPaymentForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa2E2QixTQTZtQkQsVUE3bUJDOzJCQWxhN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsUUFBUUMsTUFBTUMsY0FBYztBQUNyQyxPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLDJCQUEyQjtBQUNwQyxPQUFPQyx3QkFBd0I7QUFDL0IsU0FBU0Msa0JBQWtCQyxpQkFBaUI7QUFFNUMsTUFBTUMsd0JBQXdCQSxDQUFDLEVBQUVDLFFBQVFDLGVBQWVDLFVBQVVDLGlCQUFpQkMsU0FBU0MsVUFBVSxNQUFNO0FBQUFDLEtBQUE7QUFDMUcsUUFBTUMsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTUMsWUFBWSxJQUFJSCxNQUFLLG9CQUFJQSxLQUFLLEdBQUVJLFNBQVEsb0JBQUlKLEtBQUssR0FBRUssUUFBUSxJQUFJLENBQUMsQ0FBQyxFQUNwRUosWUFBWSxFQUNaQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR2YsUUFBTSxDQUFDSSxPQUFPQyxRQUFRLElBQUl6QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMEIsb0JBQW9CQyxxQkFBcUIsSUFBSTNCLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUM0QixnQkFBZ0JDLGlCQUFpQixJQUFJN0IsU0FBU1csaUJBQWlCLEVBQUU7QUFDeEUsUUFBTSxDQUFDbUIsaUJBQWlCQyxrQkFBa0IsSUFBSS9CLFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUNnQyxpQkFBaUJDLGtCQUFrQixJQUFJakMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ2tDLG1CQUFtQkMsb0JBQW9CLElBQUluQyxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDb0Msb0JBQW9CQyxxQkFBcUIsSUFBSXJDLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNzQyxRQUFRQyxTQUFTLElBQUl2QyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN3QyxnQkFBZ0JDLGlCQUFpQixJQUFJekMsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQzBDLG9CQUFvQkMscUJBQXFCLElBQUkzQyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDNEMsZUFBZUMsZ0JBQWdCLElBQUk3QyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDOEMsV0FBV0MsWUFBWSxJQUFJL0MsU0FBUyxDQUFDO0FBQzVDLFFBQU0sQ0FBQ2dELGVBQWVDLGdCQUFnQixJQUFJakQsU0FBUztBQUNuRCxRQUFNLENBQUNrRCxvQkFBb0JDLHFCQUFxQixJQUFJbkQsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQ29ELGdCQUFnQkMsaUJBQWlCLElBQUlyRCxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDc0QsV0FBV0MsWUFBWSxJQUFJdkQsU0FBUyxFQUFFO0FBRzdDLFFBQU0sQ0FBQ3dELGVBQWVDLGdCQUFnQixJQUFJekQsU0FBUyxLQUFLO0FBRXhELFFBQU0sQ0FBQzBELFVBQVVDLFdBQVcsSUFBSTNELFNBQVM7QUFBQSxJQUN2QzRELFNBQVNqRCxpQkFBaUI7QUFBQSxJQUMxQmtELFVBQVU7QUFBQSxJQUNWQyxRQUFRO0FBQUEsSUFDUkMsVUFBVTlDO0FBQUFBLElBQ1YrQyxjQUFjO0FBQUEsSUFDZEMsWUFBWTtBQUFBLElBQ1pDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLElBQ05DLG1CQUFtQjtBQUFBLElBQ25CQyxlQUFlO0FBQUEsSUFDZkMsYUFBYTtBQUFBLElBQ2JDLGtCQUFrQjtBQUFBLElBQ2xCQyxvQkFBb0I7QUFBQSxJQUNwQkMsVUFBVTtBQUFBLElBQ1ZDLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFHRCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJaEYsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ2lGLHlCQUF5QkMsMEJBQTBCLElBQUlsRixTQUFTLEtBQUs7QUFFNUVELFlBQVUsTUFBTTtBQUNkLFVBQU1vRixPQUFPQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLE1BQU0sS0FBSyxJQUFJO0FBQzVELFVBQU1DLFFBQVFMLE1BQU1NLHVCQUF1QkMsc0JBQXNCLENBQUM7QUFDbEUsUUFBSUYsTUFBTUcsaUJBQWlCLE9BQVFYLGtCQUFpQixJQUFJO0FBQ3hELFFBQUlRLE1BQU1JLHlCQUF5QixRQUFRO0FBQ3pDWix1QkFBaUIsSUFBSTtBQUNyQkUsaUNBQTJCLElBQUk7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBR0wsUUFBTVcsMkJBQTJCQSxDQUFDQyxXQUFXO0FBQzNDLFFBQUksQ0FBQ0EsT0FBUSxRQUFPO0FBRXBCLFVBQU1DLFFBQVFELE9BQU9FLFlBQVk7QUFFakMsUUFBSUQsTUFBTUUsU0FBUyxPQUFPLEdBQUc7QUFDM0IsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJRixNQUFNRSxTQUFTLFFBQVEsR0FBRztBQUM1QixhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNUO0FBR0FsRyxZQUFVLE1BQU07QUFDZCxVQUFNbUcsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU0vRixJQUFJZ0csSUFBSSxlQUFlO0FBQ3pDM0UsaUJBQVMwRSxLQUFLRSxNQUFNQSxRQUFRLEVBQUU7QUFBQSxNQUNoQyxRQUFRO0FBQ041RSxpQkFBUyxFQUFFO0FBQUEsTUFDYjtBQUFBLElBQ0Y7QUFDQXlFLGVBQVc7QUFBQSxFQUNiLEdBQUcsRUFBRTtBQUdMbkcsWUFBVSxNQUFNO0FBQ2QsUUFBSVksZUFBZTtBQUNqQmtCLHdCQUFrQmxCLGFBQWE7QUFDL0JnRCxrQkFBWSxDQUFDMkMsVUFBVSxFQUFFLEdBQUdBLE1BQU0xQyxTQUFTakQsY0FBYyxFQUFFO0FBQUEsSUFDN0Q7QUFHQSxRQUFJRSxpQkFBaUI7QUFDbkJrQix5QkFBbUJsQixlQUFlO0FBQ2xDOEMsa0JBQVksQ0FBQzJDLFVBQVU7QUFBQSxRQUNyQixHQUFHQTtBQUFBQSxRQUNIdEMsY0FBY25ELGdCQUFnQjBGLFNBQVNDLFNBQVMsS0FBSztBQUFBLFFBQ3JEdkMsWUFBWTtBQUFBLFFBQ1pDLFFBQVFyRCxnQkFBZ0IwRixTQUFTQyxTQUFTLEtBQUs7QUFBQSxNQUNqRCxFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDN0YsZUFBZUUsZUFBZSxDQUFDO0FBR25DZCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUM2QixlQUFnQjtBQUVyQixVQUFNNkUsMEJBQTBCLFlBQVk7QUFDMUN0RCw0QkFBc0IsSUFBSTtBQUMxQixVQUFJO0FBQ0YsY0FBTWdELE1BQU0sTUFBTS9GLElBQUlnRyxJQUFJLGdDQUFnQztBQUMxRCxjQUFNTSxlQUFlUCxJQUFJRSxLQUFLQSxRQUFRO0FBQ3RDLGNBQU1NLG1CQUFtQkQsYUFBYUU7QUFBQUEsVUFDcEMsQ0FBQ0MsUUFBUUEsSUFBSUMsV0FBV2xELFNBQVNtRCxRQUFRbkY7QUFBQUEsUUFDM0M7QUFFQWUsOEJBQXNCZ0UsZ0JBQWdCO0FBRXRDLFlBQUlBLGlCQUFpQkssU0FBUyxHQUFHO0FBQy9CLGdCQUFNQyxTQUFTTixpQkFBaUJPO0FBQUFBLFlBQzlCLENBQUNDLEdBQUdDLE1BQU0sSUFBSWxHLEtBQUtrRyxFQUFFQyxnQkFBZ0IsSUFBSSxJQUFJbkcsS0FBS2lHLEVBQUVFLGdCQUFnQjtBQUFBLFVBQ3RFO0FBQ0EsZ0JBQU1DLFNBQVNMLE9BQU8sQ0FBQztBQUV2QnBFLDJCQUFpQnlFLE9BQU9DLGtCQUFrQixDQUFDO0FBQzNDeEUsdUJBQWF1RSxPQUFPRSxjQUFjLENBQUM7QUFDbkMsZ0JBQU0xQixTQUFTd0IsUUFBUVIsV0FBV1c7QUFDbEN4RSwyQkFBaUI2QyxNQUFNO0FBR3ZCbkMsc0JBQVksQ0FBQzJDLFNBQVM7QUFDcEIsZ0JBQUksQ0FBQ0EsS0FBS2hDLFNBQVM7QUFDakIsb0JBQU1vRCxTQUFTN0IseUJBQXlCQyxNQUFNO0FBQzlDLHFCQUFPLEVBQUUsR0FBR1EsTUFBTWhDLFNBQVNvRCxPQUFPO0FBQUEsWUFDcEM7QUFDQSxtQkFBT3BCO0FBQUFBLFVBQ1QsQ0FBQztBQUFBLFFBQ0gsT0FBTztBQUNMekQsMkJBQWlCLENBQUM7QUFDbEJFLHVCQUFhLENBQUM7QUFBQSxRQUNoQjtBQUFBLE1BQ0YsU0FBUzRFLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sdUNBQXVDQSxLQUFLO0FBQzFEOUUseUJBQWlCLENBQUM7QUFDbEJFLHFCQUFhLENBQUM7QUFBQSxNQUNoQixVQUFDO0FBQ0NJLDhCQUFzQixLQUFLO0FBQUEsTUFDN0I7QUFBQSxJQUNGO0FBRUFzRCw0QkFBd0I7QUFBQSxFQUMxQixHQUFHLENBQUM3RSxjQUFjLENBQUM7QUFHbkI3QixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUM2QixnQkFBZ0I7QUFDbkIyQixtQkFBYSxFQUFFO0FBQ2ZGLHdCQUFrQixFQUFFO0FBQ3BCO0FBQUEsSUFDRjtBQUNBLFVBQU13RSwyQkFBMkIsWUFBWTtBQUMzQyxVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNMUgsSUFBSWdHLElBQUksa0NBQWtDeEUsY0FBYyxFQUFFO0FBQ2pGMkIscUJBQWF1RSxTQUFTekIsSUFBSTtBQUFBLE1BQzVCLFFBQVE7QUFDTjlDLHFCQUFhLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0Y7QUFDQSxVQUFNd0Usb0JBQW9CLFlBQVk7QUFDcEMsVUFBSTtBQUNGLGNBQU1ELFdBQVcsTUFBTTFILElBQUlnRyxJQUFJLHdDQUF3Q3hFLGNBQWMsRUFBRTtBQUN2RnlCLDBCQUFrQnlFLFNBQVN6QixJQUFJO0FBQUEsTUFDakMsUUFBUTtBQUNOaEQsMEJBQWtCLEVBQUU7QUFBQSxNQUN0QjtBQUFBLElBQ0Y7QUFDQXdFLDZCQUF5QjtBQUN6QkUsc0JBQWtCO0FBQUEsRUFDcEIsR0FBRyxDQUFDbkcsY0FBYyxDQUFDO0FBR25CN0IsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDNkIsZUFBZ0I7QUFDckIsVUFBTW9HLGFBQWE7QUFBQSxNQUNqQixHQUFHNUUsZUFBZTZFLElBQUksQ0FBQUMsVUFBUyxTQUFTQSxNQUFNbkIsR0FBRyxFQUFFO0FBQUEsTUFDbkQsR0FBR3pELFVBQVUyRSxJQUFJLENBQUFFLGFBQVksUUFBUUEsU0FBU3BCLEdBQUcsRUFBRTtBQUFBLElBQUM7QUFBQSxFQUV4RCxHQUFHLENBQUMzRCxnQkFBZ0J4QixjQUFjLENBQUM7QUFHbkM3QixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUM2QixnQkFBZ0I7QUFDbkJHLHlCQUFtQixJQUFJO0FBQ3ZCSiw0QkFBc0IsRUFBRTtBQUN4QjtBQUFBLElBQ0Y7QUFFQSxVQUFNeUcsZUFBZSxZQUFZO0FBQy9CbkcseUJBQW1CLElBQUk7QUFDdkIsVUFBSTtBQUVGLFlBQUlwQixtQkFBbUJBLGdCQUFnQmtHLFFBQVFuRixnQkFBZ0I7QUFDN0RHLDZCQUFtQmxCLGVBQWU7QUFDbEM4QyxzQkFBWSxDQUFDMkMsVUFBVTtBQUFBLFlBQ3JCLEdBQUdBO0FBQUFBLFlBQ0h0QyxjQUFjbkQsZ0JBQWdCMEYsU0FBU0MsU0FBUyxLQUFLO0FBQUEsWUFDckR2QyxZQUFZO0FBQUEsWUFDWkMsUUFBUXJELGdCQUFnQjBGLFNBQVNDLFNBQVMsS0FBSztBQUFBLFVBQ2pELEVBQUU7QUFDRnZFLDZCQUFtQixLQUFLO0FBQ3hCO0FBQUEsUUFDRjtBQUVBLGNBQU1rRSxNQUFNLE1BQU0vRixJQUFJZ0csSUFBSSwyQkFBMkJ4RSxjQUFjLEVBQUU7QUFDckUsWUFBSXVFLElBQUlFLE1BQU1nQyxRQUFRO0FBQ3BCLGdCQUFNQyxVQUFVbkMsSUFBSUUsS0FBS0E7QUFDekJ0RSw2QkFBbUJ1RyxPQUFPO0FBQzFCM0Usc0JBQVksQ0FBQzJDLFVBQVU7QUFBQSxZQUNyQixHQUFHQTtBQUFBQSxZQUNIdEMsY0FBY3NFLFFBQVEvQixTQUFTQyxTQUFTLEtBQUs7QUFBQSxZQUM3Q3ZDLFlBQVk7QUFBQSxZQUNaQyxRQUFRb0UsUUFBUS9CLFNBQVNDLFNBQVMsS0FBSztBQUFBLFVBQ3pDLEVBQUU7QUFBQSxRQUNKLE9BQU87QUFDTHpFLDZCQUFtQixJQUFJO0FBQUEsUUFDekI7QUFBQSxNQUNGLFFBQVE7QUFDTkEsMkJBQW1CLElBQUk7QUFBQSxNQUN6QixVQUFDO0FBQ0NFLDJCQUFtQixLQUFLO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBRUEsVUFBTXNHLG1CQUFtQixZQUFZO0FBQ25DcEcsMkJBQXFCLElBQUk7QUFDekIsVUFBSTtBQUNGLGNBQU1nRSxNQUFNLE1BQU0vRixJQUFJZ0csSUFBSSxpQ0FBaUM7QUFDM0QsY0FBTUMsT0FBT0YsSUFBSUUsUUFBUTtBQUN6QixjQUFNbUMsVUFBVW5DLEtBQUtPLE9BQU8sQ0FBQzZCLFNBQVNBLEtBQUs3RSxTQUFTbUQsUUFBUW5GLGNBQWM7QUFDMUVELDhCQUFzQjZHLE9BQU87QUFDN0IsWUFBSUEsUUFBUXhCLFNBQVMsR0FBRztBQUN0QixnQkFBTTBCLFFBQVFGLFFBQVEsQ0FBQztBQUN2QjdFLHNCQUFZLENBQUMyQyxVQUFVO0FBQUEsWUFDckIsR0FBR0E7QUFBQUEsWUFDSHpDLFVBQVU2RSxNQUFNN0UsVUFBVWtEO0FBQUFBLFlBQzFCakQsUUFBUTRFLE1BQU1DO0FBQUFBLFVBQ2hCLEVBQUU7QUFBQSxRQUNKO0FBQUEsTUFDRixRQUFRO0FBQ05oSCw4QkFBc0IsRUFBRTtBQUFBLE1BQzFCLFVBQUM7QUFDQ1EsNkJBQXFCLEtBQUs7QUFBQSxNQUM1QjtBQUFBLElBQ0Y7QUFFQWlHLGlCQUFhO0FBQ2JHLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsQ0FBQzNHLGdCQUFnQmYsZUFBZSxDQUFDO0FBR3BDLFFBQU0rSCxpQkFBaUJBLENBQUNsSSxXQUFXO0FBQ2pDbUIsc0JBQWtCbkIsTUFBTTtBQUN4QmlELGdCQUFZLENBQUMyQyxVQUFVO0FBQUEsTUFDckIsR0FBR0E7QUFBQUEsTUFDSDFDLFNBQVNsRDtBQUFBQSxNQUNUbUQsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxJQUNWLEVBQUU7QUFDRnZCLGNBQVUsQ0FBQytELFVBQVUsRUFBRSxHQUFHQSxNQUFNdUMsVUFBVSxJQUFJQyxjQUFjLEdBQUcsRUFBRTtBQUVqRWpHLHFCQUFpQixDQUFDO0FBQ2xCRSxpQkFBYSxDQUFDO0FBQUEsRUFDaEI7QUFFQSxRQUFNZ0csZUFBZUEsQ0FBQ0MsTUFBTTtBQUMxQixVQUFNLEVBQUVDLE1BQU1DLE1BQU0sSUFBSUYsRUFBRUc7QUFDMUIsUUFBSSxDQUFDLGdCQUFnQixjQUFjLFFBQVEsRUFBRWxELFNBQVNnRCxJQUFJLEdBQUc7QUFDM0QsVUFBSUcsVUFBVUYsTUFBTUcsUUFBUSxZQUFZLEVBQUU7QUFDMUMsV0FBS0QsUUFBUUUsTUFBTSxLQUFLLEtBQUssSUFBSXRDLFNBQVMsRUFBRztBQUM3Q3JELGtCQUFZLENBQUMyQyxTQUFTO0FBQ3BCLGNBQU1pRCxVQUFVLEVBQUUsR0FBR2pELE1BQU0sQ0FBQzJDLElBQUksR0FBR0csUUFBUTtBQUMzQyxZQUFJSCxTQUFTLGtCQUFrQkEsU0FBUyxjQUFjO0FBQ3BELGdCQUFNTyxRQUFRQyxXQUFXUixTQUFTLGlCQUFpQkcsVUFBVUcsUUFBUXZGLFlBQVksS0FBSztBQUN0RixnQkFBTTBGLFlBQVlELFdBQVdSLFNBQVMsZUFBZUcsVUFBVUcsUUFBUXRGLFVBQVUsS0FBSztBQUN0RnNGLGtCQUFRckYsU0FBU3lGLEtBQUtDLElBQUlKLFFBQVFFLFdBQVcsQ0FBQyxFQUFFbEQsU0FBUztBQUFBLFFBQzNEO0FBQ0EsZUFBTytDO0FBQUFBLE1BQ1QsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUNBNUYsZ0JBQVksQ0FBQzJDLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUMyQyxJQUFJLEdBQUdDLE1BQU0sRUFBRTtBQUNsRDNHLGNBQVUsQ0FBQStELFVBQVM7QUFBQSxNQUNqQixHQUFHQTtBQUFBQSxNQUNILENBQUMyQyxJQUFJLEdBQUc7QUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTVksMEJBQTBCQSxDQUFDYixNQUFNO0FBQ3JDLFVBQU1jLE9BQU9kLEVBQUVHLE9BQU9EO0FBQ3RCdkYsZ0JBQVksQ0FBQzJDLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIbkMsVUFBVTJGO0FBQUFBLE1BQ1YxRixnQkFBZ0IwRixTQUFTLFNBQVMsS0FBS3hELEtBQUtsQztBQUFBQSxNQUM1QyxHQUFJMEYsU0FBUyxZQUFZO0FBQUEsUUFDdkJyRixlQUFlO0FBQUEsUUFDZkMsYUFBYTtBQUFBLFFBQ2JDLGtCQUFrQjtBQUFBLFFBQ2xCQyxvQkFBb0I7QUFBQSxNQUN0QjtBQUFBLElBQ0YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNbUYsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFDbkIsUUFBSSxDQUFDdEcsU0FBU0UsUUFBU29HLFdBQVVuQixXQUFXO0FBQzVDLFFBQUksQ0FBQ25GLFNBQVNHLFlBQVksQ0FBQ0gsU0FBU21CLFlBQVksQ0FBQ25CLFNBQVNvQixTQUFTO0FBQ2pFa0YsZ0JBQVVsQixlQUFlO0FBQUEsSUFDM0I7QUFDQSxRQUFJLENBQUNwRixTQUFTSyxTQUFVaUcsV0FBVWpHLFdBQVc7QUFFN0MsVUFBTUcsU0FBU3VGLFdBQVcvRixTQUFTUSxNQUFNO0FBQ3pDLFFBQUkrRixNQUFNL0YsTUFBTSxLQUFLQSxVQUFVLEdBQUc7QUFDaEM4RixnQkFBVTlGLFNBQVM7QUFBQSxJQUNyQixXQUFXcEMsbUJBQW1Cb0MsU0FBU3BDLGdCQUFnQnlFLFNBQVM7QUFDOUR5RCxnQkFBVTlGLFNBQVMsOENBQThDcEMsZ0JBQWdCeUUsUUFBUTJELGVBQWUsQ0FBQztBQUFBLElBQzNHO0FBRUEsUUFBSXhHLFNBQVNTLGFBQWEsWUFBWVQsU0FBU1MsYUFBYSxnQkFBZ0JULFNBQVNTLGFBQWEsaUJBQWlCO0FBQ2pILFVBQUksQ0FBQ1QsU0FBU1UsZ0JBQWdCK0YsS0FBSztBQUNqQ0gsa0JBQVU1RixpQkFBaUI7QUFBQSxJQUMvQixXQUFXVixTQUFTUyxhQUFhLFVBQVU7QUFDekMsVUFBSSxDQUFDVCxTQUFTZSxlQUFlMEYsS0FBSyxFQUFHSCxXQUFVdkYsZ0JBQWdCO0FBQy9ELFVBQUksQ0FBQ2YsU0FBU2dCLGFBQWF5RixLQUFLLEVBQUdILFdBQVV0RixjQUFjO0FBQUEsSUFDN0Q7QUFFQSxRQUFJLENBQUNoQixTQUFTWSxRQUFTMEYsV0FBVTFGLFVBQVU7QUFFM0MvQixjQUFVeUgsU0FBUztBQUNuQixXQUFPSSxPQUFPQyxLQUFLTCxTQUFTLEVBQUVoRCxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNc0QsZUFBZSxPQUFPdEIsTUFBTTtBQUNoQ0EsTUFBRXVCLGVBQWU7QUFDakIsUUFBSSxDQUFDUixhQUFhLEVBQUc7QUFFckIsVUFBTVMsUUFBUXBGLEtBQUtDLE1BQU1DLGFBQWFDLFFBQVEsTUFBTSxLQUFLLElBQUk7QUFDN0QsVUFBTWtGLFVBQVUvRyxTQUFTWSxZQUFZO0FBQ3JDLFVBQU1vRyxVQUFVO0FBQUEsTUFDZDlHLFNBQVNGLFNBQVNFO0FBQUFBLE1BQ2xCLEdBQUk2RyxVQUNBLEVBQUU1RixVQUFVbkIsU0FBU21CLFNBQVMsSUFDOUIsRUFBRWhCLFVBQVVILFNBQVNHLFNBQVM7QUFBQSxNQUNsQyxHQUFJNEcsVUFDQSxFQUFFbkcsU0FBUyxRQUFRLElBQ25CO0FBQUEsTUFDSlIsUUFBUUosU0FBU0ksT0FBTzBDLFNBQVM7QUFBQSxNQUNqQ3pDLFVBQVVMLFNBQVNLO0FBQUFBLE1BQ25CQyxjQUFjTixTQUFTTSxnQkFBZ0I7QUFBQSxNQUN2Q0MsWUFBWVAsU0FBU08sY0FBYztBQUFBLE1BQ25DQyxRQUFRUixTQUFTUTtBQUFBQSxNQUNqQkMsVUFBVVQsU0FBU1M7QUFBQUEsTUFDbkIyQixRQUFRcEMsVUFBVVk7QUFBQUEsTUFDbEJFLG1CQUNFZCxTQUFTWSxZQUFZLCtCQUNqQixzQkFDQW1HLFVBQ0UsZ0JBQ0E7QUFBQSxNQUNSckcsZ0JBQWdCVixTQUFTVSxrQkFBa0I7QUFBQSxNQUMzQ3VHLFVBQVVILE1BQU16RDtBQUFBQSxNQUNoQjFDLFlBQVltRyxNQUFNekQ7QUFBQUEsTUFDbEI2RCxTQUFTO0FBQUEsTUFDVHJHLE1BQU1iLFNBQVNhO0FBQUFBO0FBQUFBLE1BRWZnRCxnQkFBZ0IzRSxjQUFjNEQsU0FBUztBQUFBLE1BQ3ZDZ0IsWUFBWTFFLFVBQVUwRCxTQUFTO0FBQUEsTUFDL0IsR0FBSTlDLFNBQVNTLGFBQWEsWUFBWTtBQUFBLFFBQ3BDTSxlQUFlZixTQUFTZTtBQUFBQSxRQUN4QkMsYUFBYWhCLFNBQVNnQjtBQUFBQSxRQUN0QkMsa0JBQWtCakIsU0FBU2lCO0FBQUFBLFFBQzNCQyxvQkFBb0JsQixTQUFTa0I7QUFBQUEsTUFDL0I7QUFBQSxJQUNGO0FBRUF2QywwQkFBc0IsSUFBSTtBQUMxQixRQUFJO0FBQ0YsWUFBTWpDLElBQUl5SyxLQUFLLGlDQUFpQ0gsT0FBTztBQUV2RCxVQUFJM0osVUFBV0EsV0FBVTtBQUN6QkQsY0FBUTtBQUFBLElBQ1YsU0FBUzZHLE9BQU87QUFDZEMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBRXJCLFVBQUM7QUFDQ3RGLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDR0Q7QUFBQUEsMEJBQXNCLHVCQUFDLHNCQUFtQixPQUFNLGlDQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsSUFFOUUsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDBFQUNaLGlDQUFDLFVBQUssMERBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRCxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBLHVCQUFDLFVBQUssVUFBVWtJLGNBQWMsV0FBVSxhQUV0QztBQUFBLCtCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxjQUN2RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixjQUFjLENBQUNRLE9BQU9DLFdBQ3BCQSxRQUFRQyxPQUFPaEYsWUFBWSxFQUFFQyxTQUFTNkUsTUFBTTlFLFlBQVksQ0FBQztBQUFBLGdCQUUzRCxPQUFPdEMsU0FBU0UsV0FBV3FIO0FBQUFBLGdCQUMzQixVQUFVckM7QUFBQUEsZ0JBQ1YsU0FBU3BILE1BQU15RyxJQUFJLENBQUNpRCxPQUFPO0FBQUEsa0JBQ3pCaEMsT0FBT2dDLEVBQUVuRTtBQUFBQSxrQkFDVGlFLE9BQU8sR0FBR0UsRUFBRUMsU0FBUyxNQUFNRCxFQUFFRSxZQUFZO0FBQUEsZ0JBQzNDLEVBQUU7QUFBQTtBQUFBLGNBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYU07QUFBQSxZQUVMOUksT0FBT3VHLFlBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnZHLGlCQUFPdUcsWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxlQW5CaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxjQUN6Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUNFbkYsU0FBUzJILGtCQUNSM0gsU0FBU0ksU0FBUyxHQUFHSixTQUFTRyxRQUFRLElBQUlILFNBQVNJLE1BQU0sS0FBS21IO0FBQUFBLGdCQUVqRSxVQUFVLENBQUN2SCxTQUFTRSxXQUFXMUI7QUFBQUEsZ0JBQy9CLFNBQVNBO0FBQUFBLGdCQUNUO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxhQUFhQSxvQkFBb0IsZUFBZTtBQUFBLGdCQUNoRCxpQkFDRUEsb0JBQ0UsdUJBQUMsU0FBSSxXQUFVLDRCQUNiLGlDQUFDLFFBQUssTUFBSyxXQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQWlDLGdDQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0osVUFBVSxDQUFDb0osUUFBUTtBQUNqQixzQkFBSSxDQUFDQSxLQUFLO0FBQ1IzSCxnQ0FBWSxDQUFDMkMsVUFBVTtBQUFBLHNCQUNyQixHQUFHQTtBQUFBQSxzQkFDSCtFLGVBQWU7QUFBQSxzQkFDZnhILFVBQVU7QUFBQSxzQkFDVkMsUUFBUTtBQUFBLHNCQUNSZSxVQUFVO0FBQUEsc0JBQ1ZDLFNBQVM7QUFBQSxvQkFDWCxFQUFFO0FBQ0Y7QUFBQSxrQkFDRjtBQUVBLHNCQUFJd0csSUFBSUMsV0FBVyxRQUFRLEdBQUc7QUFDNUI1SCxnQ0FBWSxDQUFDMkMsVUFBVTtBQUFBLHNCQUNyQixHQUFHQTtBQUFBQSxzQkFDSCtFLGVBQWVDO0FBQUFBLHNCQUNmekcsVUFBVXlHLElBQUlqQyxRQUFRLFVBQVUsRUFBRTtBQUFBLHNCQUNsQ3hGLFVBQVU7QUFBQSxzQkFDVkMsUUFBUTtBQUFBLHNCQUNSZ0IsU0FBUztBQUFBLG9CQUNYLEVBQUU7QUFBQSxrQkFDSixXQUFXd0csSUFBSUMsV0FBVyxPQUFPLEdBQUc7QUFDbEM1SCxnQ0FBWSxDQUFDMkMsVUFBVTtBQUFBLHNCQUNyQixHQUFHQTtBQUFBQSxzQkFDSCtFLGVBQWVDO0FBQUFBLHNCQUNmeEcsU0FBU3dHLElBQUlqQyxRQUFRLFNBQVMsRUFBRTtBQUFBLHNCQUNoQ3hGLFVBQVU7QUFBQSxzQkFDVkMsUUFBUTtBQUFBLHNCQUNSZSxVQUFVO0FBQUEsb0JBQ1osRUFBRTtBQUFBLGtCQUNKLE9BQU87QUFDTCwwQkFBTSxDQUFDMkcsS0FBS0MsR0FBRyxJQUFJSCxJQUFJbEssTUFBTSxHQUFHO0FBQ2hDdUMsZ0NBQVksQ0FBQzJDLFVBQVU7QUFBQSxzQkFDckIsR0FBR0E7QUFBQUEsc0JBQ0grRSxlQUFlQztBQUFBQSxzQkFDZnpILFVBQVUySDtBQUFBQSxzQkFDVjFILFFBQVEySDtBQUFBQSxzQkFDUjVHLFVBQVU7QUFBQSxzQkFDVkMsU0FBUztBQUFBLG9CQUNYLEVBQUU7QUFBQSxrQkFDSjtBQUVBdkMsNEJBQVUsQ0FBQytELFVBQVUsRUFBRSxHQUFHQSxNQUFNd0MsY0FBYyxHQUFHLEVBQUU7QUFBQSxnQkFDckQ7QUFBQSxnQkFDQSxjQUFjLENBQUNnQyxPQUFPQyxXQUNwQkEsUUFBUUMsT0FBT2hGLFlBQVksRUFBRUMsU0FBUzZFLE1BQU05RSxZQUFZLENBQUM7QUFBQSxnQkFFM0QsU0FBUztBQUFBO0FBQUEsa0JBRVAsR0FBR3RFLG1CQUFtQnVHLElBQUksQ0FBQ1EsVUFBVTtBQUFBLG9CQUNuQ1MsT0FBTyxHQUFHVCxLQUFLNUUsVUFBVWtELEdBQUcsSUFBSTBCLEtBQUtFLE9BQU87QUFBQSxvQkFDNUNxQyxPQUFPLEdBQUd2QyxLQUFLNUUsVUFBVTZILFVBQVUsYUFBYWpELEtBQUtFLE9BQU87QUFBQSxrQkFDOUQsRUFBRTtBQUFBO0FBQUEsa0JBR0YsR0FBR3ZGLGVBQWU2RSxJQUFJLENBQUNDLFdBQVc7QUFBQSxvQkFDaENnQixPQUFPLFNBQVNoQixNQUFNbkIsR0FBRztBQUFBLG9CQUN6QmlFLE9BQU8sV0FBVzlDLE1BQU1yRCxRQUFRLE9BQU9xRCxNQUFNeUQsY0FBYztBQUFBLGtCQUM3RCxFQUFFO0FBQUE7QUFBQSxrQkFHRixHQUFHckksVUFBVTJFLElBQUksQ0FBQ0UsY0FBYztBQUFBLG9CQUM5QmUsT0FBTyxRQUFRZixTQUFTcEIsR0FBRztBQUFBLG9CQUMzQmlFLE9BQU8sVUFBVTdDLFNBQVNyRCxPQUFPLE9BQU9xRCxTQUFTeUQsV0FBVztBQUFBLGtCQUM5RCxFQUFFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGNBeEZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXlGSTtBQUFBLFlBRUh0SixPQUFPd0csZ0JBQWdCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ4RyxpQkFBT3dHLGdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLGVBL0Z4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsY0FDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPcEYsU0FBU1k7QUFBQUEsZ0JBQ2hCLFVBQVV5RTtBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sSUFBRyxxQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDdEMsdUJBQUMsWUFBTyxPQUFNLDhCQUE2QixpQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEQ7QUFBQSxrQkFDNUQsdUJBQUMsWUFBTyxPQUFNLHVCQUFzQiwwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQSxrQkFDOUMsdUJBQUMsWUFBTyxPQUFNLHdCQUF1QiwyQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0Q7QUFBQTtBQUFBO0FBQUEsY0FUbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxZQUVDekcsT0FBT2dDLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEMsaUJBQU9nQyxXQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLGFBbEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtSkE7QUFBQSxRQUlDeEMsaUJBQWlCeUUsVUFBVSxLQUMxQix1QkFBQyxTQUFJLFdBQVUseUVBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEJBQ1ozRSw0QkFBa0JjLG1CQUFtQnNFLFNBQVMsS0FDN0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXZELGlCQUFpQixJQUFJO0FBQUEsY0FDcEMsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxhQUFVLFdBQVUsbUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFMekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0EsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFJQSx1QkFBQyxTQUFJLFdBQVUsMkNBQTBDO0FBQUE7QUFBQSxZQUN2RCx1QkFBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLDZEQUE0RCx3QkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUNWM0IsMEJBQWdCcUosYUFBYXJKLGlCQUFpQitKLGFBQWFWLGFBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsaUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSwwQ0FBeUM7QUFBQTtBQUFBLGdCQUNqRFcsT0FBT2hLLGdCQUFnQnlFLE9BQU8sRUFBRTJELGVBQWU7QUFBQSxtQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBcURDaEgsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLDhFQUNiO0FBQUEsbUNBQUMsUUFBSyxNQUFLLFdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0I7QUFBQSxZQUNsQix1QkFBQyxVQUFLLFdBQVUseUJBQXdCLDhDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUE5Rko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdHQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1EQUNaO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQUc7QUFBQSxlQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsZ0JBQ25ELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPUSxTQUFTSztBQUFBQSxrQkFDaEIsVUFBVWdGO0FBQUFBLGtCQUNWLFVBQVUsQ0FBQ2hFO0FBQUFBLGtCQUNYLEtBQUtFLDBCQUEwQjVELFlBQVk0SjtBQUFBQSxrQkFDM0MsS0FBS2hHLDBCQUEwQmhFLFFBQVFnSztBQUFBQSxrQkFDdkMsV0FBVTtBQUFBO0FBQUEsZ0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUWlHO0FBQUEsY0FFaEczSSxPQUFPeUIsWUFBWSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCekIsaUJBQU95QixZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGlCQWRoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsZ0JBQ25ELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0wsU0FBU1M7QUFBQUEsa0JBQ2hCLFVBQVUwRjtBQUFBQSxrQkFDVixXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUI7QUFBQSxvQkFDekIsdUJBQUMsWUFBTyxPQUFNLGlCQUFnQiw2QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQSxvQkFDM0MsdUJBQUMsWUFBTyxPQUFNLGNBQWEsNEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVDO0FBQUEsb0JBQ3ZDLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBLG9CQUMxQix1QkFBQyxZQUFPLE9BQU0sZUFBYywyQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQTtBQUFBO0FBQUEsZ0JBVDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsV0FHRW5HLFNBQVNTLGFBQWEsWUFBWVQsU0FBU1MsYUFBYSxnQkFBZ0JULFNBQVNTLGFBQWEsb0JBQzlGLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGNBQ2pELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9ULFNBQVNVO0FBQUFBLGdCQUNoQixVQUFVMkU7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTStEO0FBQUEsWUFFOUR6RyxPQUFPOEIsa0JBQWtCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI5QixpQkFBTzhCLGtCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLGVBWjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUlEVixTQUFTUyxhQUFhLFlBQ3JCLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwrQkFBOEIsOEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUNsRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9ULFNBQVNlO0FBQUFBLG9CQUNoQixVQUFVc0U7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtnRTtBQUFBLGdCQUUvRHpHLE9BQU9tQyxpQkFBaUIsdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qm5DLGlCQUFPbUMsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsbUJBWDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxrQkFDcEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPZixTQUFTZ0I7QUFBQUEsb0JBQ2hCLFVBQVVxRTtBQUFBQSxvQkFDVixXQUFVO0FBQUE7QUFBQSxrQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS2dFO0FBQUEsZ0JBRS9EekcsT0FBT29DLGVBQWUsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnBDLGlCQUFPb0MsZUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkQ7QUFBQSxtQkFYdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsZ0JBQzNFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2hCLFNBQVNpQjtBQUFBQSxvQkFDaEIsVUFBVW9FO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLZ0U7QUFBQSxtQkFQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZFO0FBQUEsZ0JBQzdFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3JGLFNBQVNrQjtBQUFBQSxvQkFDaEIsVUFBVW1FO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLZ0U7QUFBQSxtQkFQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBLGVBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0RBO0FBQUEsYUE3R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStHQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDREQUliLGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxjQUN6RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPckYsU0FBU1E7QUFBQUEsZ0JBQ2hCLFVBQVU2RTtBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNcUc7QUFBQSxZQUVwR3pHLE9BQU80QixVQUFVLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI1QixpQkFBTzRCLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsWUFDMUUsdUJBQUMsU0FBSSxXQUFVLDhCQUE4QjdELDhCQUFvQnFELFNBQVNRLE1BQU0sS0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Y7QUFBQSxlQWJwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFnQkEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCwrQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxZQUNqRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPUixTQUFTYTtBQUFBQSxnQkFDaEIsVUFBVXdFO0FBQUFBLGdCQUNWLE1BQU07QUFBQSxnQkFDTixhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNZ0U7QUFBQSxlQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBDQSxLQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0NBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxvQkFBaUIsV0FBVSw2QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxVQUFLLFdBQVUsK0JBQThCLHFDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLGVBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSwwQ0FDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVN2RztBQUFBQSxnQkFDVCxVQUFVLENBQUN3RyxNQUFNdkcsa0JBQWtCdUcsRUFBRUcsT0FBTzRDLE9BQU87QUFBQSxnQkFDbkQsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJNEM7QUFBQSxZQUU1Qyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGlDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLGVBUDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNqTDtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUEyRDtBQUFBO0FBQUEsWUFIdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FBd0Y7QUFBQTtBQUFBLFlBRnBHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxXQWpjRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa2NBO0FBQUEsU0FsZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9kQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLDRDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDhCQUNiLGlDQUFDLGFBQVUsV0FBVSwyQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEMsS0FEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxxQ0FBb0MsbUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjRCO0FBQUFBLG1DQUFtQnNFO0FBQUFBLGdCQUFPO0FBQUEsZ0JBQzFCdEUsbUJBQW1Cc0UsV0FBVyxJQUFJLE1BQU07QUFBQSxnQkFBRztBQUFBLG1CQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDZCQUE0Qix3QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUNqRCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1Z0RSwrQkFBcUIsQ0FBQyxHQUFHb0UsV0FBV2xELFNBQVN1SCxhQUM1Q3JKLGlCQUFpQnFKLGFBQ2pCLFNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUVGLFdBQVU7QUFBQSxRQUNWLE1BQU0zSDtBQUFBQSxRQUNOLFNBQVMsTUFBTUMsaUJBQWlCLEtBQUs7QUFBQSxRQUNyQyxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixXQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsVUFDTnVJLE1BQU0sRUFBRUMsU0FBUyxLQUFLQyxZQUFZLFVBQVU7QUFBQSxVQUM1Q0MsUUFBUTtBQUFBLFlBQ05GLFNBQVM7QUFBQSxZQUNURyxjQUFjO0FBQUEsWUFDZEYsWUFBWTtBQUFBLFVBQ2Q7QUFBQSxRQUNGO0FBQUEsUUFDQSxPQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU16SSxpQkFBaUIsS0FBSztBQUFBLFlBQ3JDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFNBQUksV0FBVSx5QkFBd0IsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUMvRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLDBCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRixLQUQ3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQSxVQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFHRFAsK0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtGQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZGO0FBQUEsVUFDN0YsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQyx1Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxhQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsSUFDRVIsbUJBQW1Cc0UsV0FBVyxJQUNoQyx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkVBQ2IsaUNBQUMsU0FBSSxXQUFVLHlCQUF3QixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQy9FLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxPQUFNLEdBQUUsb0lBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVNLEtBRHpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsdUNBQXNDLHFDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLFVBQ3hFLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsa0VBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRGO0FBQUEsYUFQOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNadEUsNkJBQW1CdUYsSUFBSSxDQUFDcEIsS0FBS3dGLFFBQVE7QUFDcEMsZ0JBQU1DLE1BQU1SLE9BQU9qRixJQUFJM0MsTUFBTTtBQUM3QixnQkFBTXFJLFVBQVVULE9BQU9qRixJQUFJVSxrQkFBa0IsQ0FBQztBQUM5QyxnQkFBTWlGLE1BQU1WLE9BQU9qRixJQUFJVyxjQUFjLENBQUM7QUFDdEMsZ0JBQU1pRixRQUFRNUYsSUFBSTdDLGdCQUFpQnNJLE1BQU1DLFVBQVVDO0FBRW5ELGdCQUFNRSxXQUFXN0YsSUFBSThGLGtCQUFrQjNHLFlBQVksR0FBR0MsU0FBUyxRQUFRLEtBQ3JFWSxJQUFJOEYsa0JBQWtCM0csWUFBWSxHQUFHQyxTQUFTLFFBQVEsS0FDdERZLElBQUk4RixrQkFBa0IzRyxZQUFZLEdBQUdDLFNBQVMsU0FBUztBQUV6RCxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBR1Y7QUFBQSx1Q0FBQyxTQUFJLFdBQVcsY0FBY3lHLFdBQVcsbURBQW1ELDhDQUE4QyxNQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2STtBQUFBLGdCQUU3SSx1QkFBQyxTQUFJLFdBQVUsT0FFYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZDQUFDLFNBQUksV0FBVyx1REFBdURBLFdBQVcsa0JBQWtCLFlBQVksSUFDN0dBLHFCQUNDLHVCQUFDLFNBQUksV0FBVSw0QkFBMkIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNsRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLCtCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRyxLQURsRztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQy9FLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsd0pBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlOLEtBRDNOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUEsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FDQztBQUFBLCtDQUFDLE9BQUUsV0FBVSx1Q0FDVixjQUFJeEwsS0FBSzJGLElBQUlRLGdCQUFnQixFQUFFdUYsbUJBQW1CLFNBQVM7QUFBQSwwQkFDMURDLEtBQUs7QUFBQSwwQkFBV0MsT0FBTztBQUFBLDBCQUFTQyxNQUFNO0FBQUEsd0JBQ3hDLENBQUMsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDZCQUNWLGNBQUk3TCxLQUFLMkYsSUFBSVEsZ0JBQWdCLEVBQUUyRixtQkFBbUIsU0FBUztBQUFBLDBCQUMxREMsTUFBTTtBQUFBLDBCQUFXQyxRQUFRO0FBQUEsd0JBQzNCLENBQUMsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsMkJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFXQTtBQUFBLHlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXdCQTtBQUFBLG9CQUVBLHVCQUFDLFVBQUssV0FBVyxrR0FBa0dSLFdBQy9HLDZEQUNBLGlEQUFpRCxJQUVsRDdGLGNBQUk4RixvQkFBb0IsYUFKM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLHVCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlDQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxxSEFDYixpQ0FBQyxVQUFLLFdBQVUsb0NBQ1o5RixlQUFJQyxXQUFXbEQsU0FBU3VILGFBQWFySixpQkFBaUJxSixhQUFhLE9BQ2xFZ0MsT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBSWIsaUNBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHNDQUNidkcsY0FBSUMsV0FBV2pELFVBQVU2SCxhQUN0QjdFLElBQUlDLFVBQVVqRCxTQUFTNkgsYUFDdkIsU0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUlBO0FBQUEsc0JBQ0M3RSxJQUFJQyxXQUFXNkIsV0FDZCxtQ0FDRTtBQUFBLCtDQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUEsd0JBQ2pDLHVCQUFDLFVBQUssV0FBVSxnRkFBK0U7QUFBQTtBQUFBLDBCQUN4RjlCLElBQUlDLFVBQVU2QjtBQUFBQSw2QkFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQSx5QkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWNBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsdUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsNkNBQUMsT0FBRSxXQUFVLHlFQUF3RSxxQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEY7QUFBQSxzQkFDMUYsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQztBQUFBO0FBQUEsd0JBQzNDOEQsTUFBTXZDLGVBQWUsT0FBTztBQUFBLDJCQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLDZDQUFDLE9BQUUsV0FBVSx5RUFBd0UsdUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRGO0FBQUEsc0JBQzVGLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLHdCQUMzQ3FDLFFBQVFyQyxlQUFlLE9BQU87QUFBQSwyQkFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSw2Q0FBQyxPQUFFLFdBQVUseUVBQXdFLG1CQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RjtBQUFBLHNCQUN4Rix1QkFBQyxPQUFFLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSx3QkFDM0NzQyxJQUFJdEMsZUFBZSxPQUFPO0FBQUEsMkJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFXLGdDQUFnQ3dDLFdBQVcsa0JBQWtCLFlBQVksSUFDdkY7QUFBQSw2Q0FBQyxPQUFFLFdBQVcsMkRBQTJEQSxXQUFXLHFCQUFxQixlQUFlLElBQUksbUJBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStIO0FBQUEsc0JBQy9ILHVCQUFDLE9BQUUsV0FBVyw0QkFBNEJBLFdBQVcscUJBQXFCLGVBQWUsSUFBSTtBQUFBO0FBQUEsd0JBQ3pGSixJQUFJcEMsZUFBZSxPQUFPO0FBQUEsMkJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsdUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLG1FQUNackQ7QUFBQUEsd0JBQUlmLFVBQ0gsdUJBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHdDQUF1QyxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQzlGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsK0RBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdJLEtBRGxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUsNENBQTRDZSxjQUFJZixVQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1RTtBQUFBLHlCQUp6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBRURlLElBQUkxQyxZQUNILHVCQUFDLFNBQUksV0FBVSwyRkFDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSx3Q0FBdUMsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUM5RixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLDRGQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2SixLQUQvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDRDQUE0QzBDLGNBQUkxQyxZQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5RTtBQUFBLHlCQUozRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBRUQwQyxJQUFJdEMsUUFDSCx1QkFBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsOENBQTZDLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDcEcsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSw0SEFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkwsS0FEL0w7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLE9BQUUsV0FBVSxvREFBb0RzQyxjQUFJdEMsUUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEU7QUFBQSx5QkFKNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLHVCQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXlCQTtBQUFBLHFCQXpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBIQTtBQUFBO0FBQUE7QUFBQSxZQWhJS3NDLElBQUlFLE9BQU9zRjtBQUFBQSxZQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0lBO0FBQUEsUUFFSixDQUFDLEtBaEpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1S0E7QUFBQTtBQUFBLE1BaFBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtQQTtBQUFBLE9BNXNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNnNCQTtBQUVKO0FBQUVyTCxHQXZtQ0lQLHVCQUFxQjtBQUFBNE0sS0FBckI1TTtBQXltQ04sZUFBZUE7QUFBc0IsSUFBQTRNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNlbGVjdCIsIlNwaW4iLCJEcmF3ZXIiLCJhcGkiLCJudW1iZXJUb0luZGlhbldvcmRzIiwiQmFja2Ryb3BCbHVyTG9hZGVyIiwiRmFXaGF0c2FwcFNxdWFyZSIsIkZhSGlzdG9yeSIsIkNoaXRDYW5jZWxQYXltZW50Rm9ybSIsInVzZXJJZCIsImluaXRpYWxVc2VySWQiLCJ1c2VyRGF0YSIsImluaXRpYWxVc2VyRGF0YSIsIm9uQ2xvc2UiLCJvblN1Y2Nlc3MiLCJfcyIsInRvZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInVzZXJzIiwic2V0VXNlcnMiLCJkZWxldGVkRW5yb2xsbWVudHMiLCJzZXREZWxldGVkRW5yb2xsbWVudHMiLCJzZWxlY3RlZFVzZXJJZCIsInNldFNlbGVjdGVkVXNlcklkIiwidXNlckFjY291bnRJbmZvIiwic2V0VXNlckFjY291bnRJbmZvIiwiZmV0Y2hpbmdCYWxhbmNlIiwic2V0RmV0Y2hpbmdCYWxhbmNlIiwiZW5yb2xsbWVudExvYWRpbmciLCJzZXRFbnJvbGxtZW50TG9hZGluZyIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsImVycm9ycyIsInNldEVycm9ycyIsIndoYXRzYXBwRW5hYmxlIiwic2V0V2hhdHNhcHBFbmFibGUiLCJ0cmFuc2FjdGlvbkhpc3RvcnkiLCJzZXRUcmFuc2FjdGlvbkhpc3RvcnkiLCJzZXJ2aWNlQ2hhcmdlIiwic2V0U2VydmljZUNoYXJnZSIsImdzdEFtb3VudCIsInNldEdzdEFtb3VudCIsInJlbW92YWxSZWFzb24iLCJzZXRSZW1vdmFsUmVhc29uIiwibG9hZGluZ1RyYW5zYWN0aW9uIiwic2V0TG9hZGluZ1RyYW5zYWN0aW9uIiwicGlnbWVDdXN0b21lcnMiLCJzZXRQaWdtZUN1c3RvbWVycyIsImJvcnJvd2VycyIsInNldEJvcnJvd2VycyIsInNob3dUeG5EcmF3ZXIiLCJzZXRTaG93VHhuRHJhd2VyIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXJfaWQiLCJncm91cF9pZCIsInRpY2tldCIsInBheV9kYXRlIiwidG90YWxfYW1vdW50IiwiZGVkdWN0aW9ucyIsImFtb3VudCIsInBheV90eXBlIiwidHJhbnNhY3Rpb25faWQiLCJhZG1pbl90eXBlIiwicGF5X2ZvciIsIm5vdGUiLCJkaXNidXJzZW1lbnRfdHlwZSIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsImNoZXF1ZV9iYW5rX25hbWUiLCJjaGVxdWVfYmFua19icmFuY2giLCJwaWdtZV9pZCIsImxvYW5faWQiLCJtb2RpZnlQYXltZW50Iiwic2V0TW9kaWZ5UGF5bWVudCIsIm1vZGlmeU1pbk1heFBheW1lbnREYXRlIiwic2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJ1c2VyIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBlcm1zIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiZWRpdF9saW1pdGVkX3BheW1lbnQiLCJtYXBSZW1vdmFsUmVhc29uVG9QYXlGb3IiLCJyZWFzb24iLCJsb3dlciIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJmZXRjaFVzZXJzIiwicmVzIiwiZ2V0IiwiZGF0YSIsInByZXYiLCJiYWxhbmNlIiwidG9TdHJpbmciLCJmZXRjaFRyYW5zYWN0aW9uSGlzdG9yeSIsInRyYW5zYWN0aW9ucyIsInVzZXJUcmFuc2FjdGlvbnMiLCJmaWx0ZXIiLCJ0eG4iLCJlbnJvbGxfaWQiLCJfaWQiLCJsZW5ndGgiLCJzb3J0ZWQiLCJzb3J0IiwiYSIsImIiLCJ0cmFuc2FjdGlvbl9kYXRlIiwibGF0ZXN0Iiwic2VydmljZV9jaGFyZ2UiLCJnc3RfYW1vdW50IiwicmVtb3ZhbF9yZWFzb24iLCJtYXBwZWQiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMiLCJyZXNwb25zZSIsImZldGNoUGlnbWVEZXRhaWxzIiwiYWxsT3B0aW9ucyIsIm1hcCIsInBpZ21lIiwiYm9ycm93ZXIiLCJmZXRjaEFjY291bnQiLCJzdGF0dXMiLCJhY2NvdW50IiwiZmV0Y2hFbnJvbGxtZW50cyIsIm1hdGNoZWQiLCJpdGVtIiwiZmlyc3QiLCJ0aWNrZXRzIiwiaGFuZGxlQ3VzdG9tZXIiLCJjdXN0b21lciIsImdyb3VwX3RpY2tldCIsImhhbmRsZUNoYW5nZSIsImUiLCJuYW1lIiwidmFsdWUiLCJ0YXJnZXQiLCJjbGVhbmVkIiwicmVwbGFjZSIsIm1hdGNoIiwidXBkYXRlZCIsInRvdGFsIiwicGFyc2VGbG9hdCIsImRlZHVjdGlvbiIsIk1hdGgiLCJtYXgiLCJoYW5kbGVQYXltZW50TW9kZUNoYW5nZSIsIm1vZGUiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJpc05hTiIsInRvTG9jYWxlU3RyaW5nIiwidHJpbSIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImFkbWluIiwiaXNQaWdteSIsInBheWxvYWQiLCJhZG1pbl9pZCIsImRlbGV0ZWQiLCJwb3N0IiwiaW5wdXQiLCJvcHRpb24iLCJsYWJlbCIsInVuZGVmaW5lZCIsInUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJzZWxlY3RlZFZhbHVlIiwidmFsIiwic3RhcnRzV2l0aCIsImdpZCIsInRrdCIsImdyb3VwX25hbWUiLCJwYXlhYmxlX2Ftb3VudCIsImxvYW5fYW1vdW50IiwidXNlckRldGFpbHMiLCJOdW1iZXIiLCJjaGVja2VkIiwiYm9keSIsInBhZGRpbmciLCJiYWNrZ3JvdW5kIiwiaGVhZGVyIiwiYm9yZGVyQm90dG9tIiwiaWR4IiwibmV0Iiwic2VydmljZSIsImdzdCIsImdyb3NzIiwiaXNDcmVkaXQiLCJ0cmFuc2FjdGlvbl90eXBlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiaG91ciIsIm1pbnV0ZSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2hpdENhbmNlbFBheW1lbnRGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDaGl0Q2FuY2VsUGF5bWVudEZvcm0uanN4XHJcblxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgU3BpbiwgRHJhd2VyIH0gZnJvbSBcImFudGRcIjsgLy8gYWRkIERyYXdlclxyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcbmltcG9ydCBCYWNrZHJvcEJsdXJMb2FkZXIgZnJvbSBcIi4uLy4uL3NyYy9jb21wb25lbnRzL2xvYWRlcnMvQmFja2Ryb3BCbHVyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHBTcXVhcmUsIEZhSGlzdG9yeSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiOyAvLyBhZGQgaWNvblxyXG5cclxuY29uc3QgQ2hpdENhbmNlbFBheW1lbnRGb3JtID0gKHsgdXNlcklkOiBpbml0aWFsVXNlcklkLCB1c2VyRGF0YTogaW5pdGlhbFVzZXJEYXRhLCBvbkNsb3NlLCBvblN1Y2Nlc3MgfSkgPT4ge1xyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZShuZXcgRGF0ZSgpLnNldERhdGUobmV3IERhdGUoKS5nZXREYXRlKCkgLSAxKSlcclxuICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICAvLyAtLS0tIFN0YXRlIC0tLS1cclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZGVsZXRlZEVucm9sbG1lbnRzLCBzZXREZWxldGVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFVzZXJJZCwgc2V0U2VsZWN0ZWRVc2VySWRdID0gdXNlU3RhdGUoaW5pdGlhbFVzZXJJZCB8fCBcIlwiKTtcclxuICBjb25zdCBbdXNlckFjY291bnRJbmZvLCBzZXRVc2VyQWNjb3VudEluZm9dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2ZldGNoaW5nQmFsYW5jZSwgc2V0RmV0Y2hpbmdCYWxhbmNlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZW5yb2xsbWVudExvYWRpbmcsIHNldEVucm9sbG1lbnRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbb3BlbkJhY2tkcm9wTG9hZGVyLCBzZXRPcGVuQmFja2Ryb3BMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3doYXRzYXBwRW5hYmxlLCBzZXRXaGF0c2FwcEVuYWJsZV0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbdHJhbnNhY3Rpb25IaXN0b3J5LCBzZXRUcmFuc2FjdGlvbkhpc3RvcnldID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZXJ2aWNlQ2hhcmdlLCBzZXRTZXJ2aWNlQ2hhcmdlXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtnc3RBbW91bnQsIHNldEdzdEFtb3VudF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbcmVtb3ZhbFJlYXNvbiwgc2V0UmVtb3ZhbFJlYXNvbl0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtsb2FkaW5nVHJhbnNhY3Rpb24sIHNldExvYWRpbmdUcmFuc2FjdGlvbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BpZ21lQ3VzdG9tZXJzLCBzZXRQaWdtZUN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2JvcnJvd2Vycywgc2V0Qm9ycm93ZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgLy8gTmV3IHN0YXRlIGZvciB0cmFuc2FjdGlvbiBkcmF3ZXJcclxuICBjb25zdCBbc2hvd1R4bkRyYXdlciwgc2V0U2hvd1R4bkRyYXdlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcl9pZDogaW5pdGlhbFVzZXJJZCB8fCBcIlwiLFxyXG4gICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICB0aWNrZXQ6IFwiXCIsXHJcbiAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICB0b3RhbF9hbW91bnQ6IFwiXCIsXHJcbiAgICBkZWR1Y3Rpb25zOiBcIlwiLFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiQmFuayBUcmFuc2ZlclwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBhZG1pbl90eXBlOiBcIlwiLFxyXG4gICAgcGF5X2ZvcjogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgICBkaXNidXJzZW1lbnRfdHlwZTogXCJUcmFuc2ZlclwiLFxyXG4gICAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICAgIGNoZXF1ZV9kYXRlOiBcIlwiLFxyXG4gICAgY2hlcXVlX2JhbmtfbmFtZTogXCJcIixcclxuICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgIHBpZ21lX2lkOiBcIlwiLFxyXG4gICAgbG9hbl9pZDogXCJcIixcclxuICB9KTtcclxuXHJcbiAgLy8gLS0tLSBQZXJtaXNzaW9uIGNoZWNrcyAtLS0tXHJcbiAgY29uc3QgW21vZGlmeVBheW1lbnQsIHNldE1vZGlmeVBheW1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttb2RpZnlNaW5NYXhQYXltZW50RGF0ZSwgc2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpIHx8IFwie31cIik7XHJcbiAgICBjb25zdCBwZXJtcyA9IHVzZXI/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zIHx8IHt9O1xyXG4gICAgaWYgKHBlcm1zLmVkaXRfcGF5bWVudCA9PT0gXCJ0cnVlXCIpIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICBpZiAocGVybXMuZWRpdF9saW1pdGVkX3BheW1lbnQgPT09IFwidHJ1ZVwiKSB7XHJcbiAgICAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlKHRydWUpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcblxyXG4gIGNvbnN0IG1hcFJlbW92YWxSZWFzb25Ub1BheUZvciA9IChyZWFzb24pID0+IHtcclxuICAgIGlmICghcmVhc29uKSByZXR1cm4gXCJcIjtcclxuXHJcbiAgICBjb25zdCBsb3dlciA9IHJlYXNvbi50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgIGlmIChsb3dlci5pbmNsdWRlcyhcImNsb3NlXCIpKSB7XHJcbiAgICAgIHJldHVybiBcIkNoaXQgQ2xvc2UgLyBQYXlvdXRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAobG93ZXIuaW5jbHVkZXMoXCJjYW5jZWxcIikpIHtcclxuICAgICAgcmV0dXJuIFwiQ2hpdCBDYW5jZWxsYXRpb24gLyBQYXlvdXRcIjtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gXCJcIjtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tIEZldGNoIHVzZXJzIC0tLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwidXNlci92ZXJpZmllZFwiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXM/LmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIHtcclxuICAgICAgICBzZXRVc2VycyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyAtLS0tIFByZeKAkXNlbGVjdCB1c2VyIC0tLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGluaXRpYWxVc2VySWQpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRVc2VySWQoaW5pdGlhbFVzZXJJZCk7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB1c2VyX2lkOiBpbml0aWFsVXNlcklkIH0pKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBJZiB1c2VyRGF0YSBpcyBwcm92aWRlZCwgdXNlIGl0XHJcbiAgICBpZiAoaW5pdGlhbFVzZXJEYXRhKSB7XHJcbiAgICAgIHNldFVzZXJBY2NvdW50SW5mbyhpbml0aWFsVXNlckRhdGEpO1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRvdGFsX2Ftb3VudDogaW5pdGlhbFVzZXJEYXRhLmJhbGFuY2U/LnRvU3RyaW5nKCkgfHwgXCJcIixcclxuICAgICAgICBkZWR1Y3Rpb25zOiBcIlwiLFxyXG4gICAgICAgIGFtb3VudDogaW5pdGlhbFVzZXJEYXRhLmJhbGFuY2U/LnRvU3RyaW5nKCkgfHwgXCJcIixcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtpbml0aWFsVXNlcklkLCBpbml0aWFsVXNlckRhdGFdKTtcclxuXHJcbiAgLy8gLS0tLSBGZXRjaCB0cmFuc2FjdGlvbiBoaXN0b3J5IChhbHJlYWR5IHByZXNlbnQpIC0tLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZFVzZXJJZCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGZldGNoVHJhbnNhY3Rpb25IaXN0b3J5ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRMb2FkaW5nVHJhbnNhY3Rpb24odHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi90cmFuc2FjdGlvbi1oaXN0b3J5L1wiKTtcclxuICAgICAgICBjb25zdCB0cmFuc2FjdGlvbnMgPSByZXMuZGF0YS5kYXRhIHx8IFtdO1xyXG4gICAgICAgIGNvbnN0IHVzZXJUcmFuc2FjdGlvbnMgPSB0cmFuc2FjdGlvbnMuZmlsdGVyKFxyXG4gICAgICAgICAgKHR4bikgPT4gdHhuLmVucm9sbF9pZD8udXNlcl9pZD8uX2lkID09PSBzZWxlY3RlZFVzZXJJZFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIHNldFRyYW5zYWN0aW9uSGlzdG9yeSh1c2VyVHJhbnNhY3Rpb25zKTtcclxuXHJcbiAgICAgICAgaWYgKHVzZXJUcmFuc2FjdGlvbnMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3Qgc29ydGVkID0gdXNlclRyYW5zYWN0aW9ucy5zb3J0KFxyXG4gICAgICAgICAgICAoYSwgYikgPT4gbmV3IERhdGUoYi50cmFuc2FjdGlvbl9kYXRlKSAtIG5ldyBEYXRlKGEudHJhbnNhY3Rpb25fZGF0ZSlcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBjb25zdCBsYXRlc3QgPSBzb3J0ZWRbMF07XHJcblxyXG4gICAgICAgICAgc2V0U2VydmljZUNoYXJnZShsYXRlc3Quc2VydmljZV9jaGFyZ2UgfHwgMCk7XHJcbiAgICAgICAgICBzZXRHc3RBbW91bnQobGF0ZXN0LmdzdF9hbW91bnQgfHwgMCk7XHJcbiAgICAgICAgICBjb25zdCByZWFzb24gPSBsYXRlc3Q/LmVucm9sbF9pZD8ucmVtb3ZhbF9yZWFzb247XHJcbiAgICAgICAgICBzZXRSZW1vdmFsUmVhc29uKHJlYXNvbik7XHJcblxyXG4gICAgICAgICAgLy8gQXV0b+KAkXNldCBwYXlfZm9yIGlmIG5vdCBhbHJlYWR5IGNob3NlbiBieSB1c2VyXHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXByZXYucGF5X2Zvcikge1xyXG4gICAgICAgICAgICAgIGNvbnN0IG1hcHBlZCA9IG1hcFJlbW92YWxSZWFzb25Ub1BheUZvcihyZWFzb24pO1xyXG4gICAgICAgICAgICAgIHJldHVybiB7IC4uLnByZXYsIHBheV9mb3I6IG1hcHBlZCB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBwcmV2O1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldFNlcnZpY2VDaGFyZ2UoMCk7XHJcbiAgICAgICAgICBzZXRHc3RBbW91bnQoMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0cmFuc2FjdGlvbiBoaXN0b3J5OlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0U2VydmljZUNoYXJnZSgwKTtcclxuICAgICAgICBzZXRHc3RBbW91bnQoMCk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZ1RyYW5zYWN0aW9uKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFRyYW5zYWN0aW9uSGlzdG9yeSgpO1xyXG4gIH0sIFtzZWxlY3RlZFVzZXJJZF0pO1xyXG5cclxuICAvLyAtLS0tIEZldGNoIGxvYW5zICYgcGlnbWUgZm9yIHRoZSBzZWxlY3RlZCB1c2VyIC0tLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZFVzZXJJZCkge1xyXG4gICAgICBzZXRCb3Jyb3dlcnMoW10pO1xyXG4gICAgICBzZXRQaWdtZUN1c3RvbWVycyhbXSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9sb2Fucy9nZXQtYm9ycm93ZXItYnktdXNlci1pZC8ke3NlbGVjdGVkVXNlcklkfWApO1xyXG4gICAgICAgIHNldEJvcnJvd2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgc2V0Qm9ycm93ZXJzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGNvbnN0IGZldGNoUGlnbWVEZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BpZ21lL2dldC1waWdtZS1jdXN0b21lci1ieS11c2VyLWlkLyR7c2VsZWN0ZWRVc2VySWR9YCk7XHJcbiAgICAgICAgc2V0UGlnbWVDdXN0b21lcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscygpO1xyXG4gICAgZmV0Y2hQaWdtZURldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgLy8gLS0tLSBBdXRv4oCRc2VsZWN0IGFsbCBhdmFpbGFibGUgb3B0aW9ucyB3aGVuIHVzZXIgY2hhbmdlcyAtLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRVc2VySWQpIHJldHVybjtcclxuICAgIGNvbnN0IGFsbE9wdGlvbnMgPSBbXHJcbiAgICAgIC4uLnBpZ21lQ3VzdG9tZXJzLm1hcChwaWdtZSA9PiBgcGlnbWUtJHtwaWdtZS5faWR9YCksXHJcbiAgICAgIC4uLmJvcnJvd2Vycy5tYXAoYm9ycm93ZXIgPT4gYGxvYW4tJHtib3Jyb3dlci5faWR9YClcclxuICAgIF07XHJcbiAgfSwgW3BpZ21lQ3VzdG9tZXJzLCBzZWxlY3RlZFVzZXJJZF0pO1xyXG5cclxuICAvLyAtLS0tIEZldGNoIGFjY291bnQgJiBlbnJvbGxtZW50cyAtLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRVc2VySWQpIHtcclxuICAgICAgc2V0VXNlckFjY291bnRJbmZvKG51bGwpO1xyXG4gICAgICBzZXREZWxldGVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZmV0Y2hBY2NvdW50ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRGZXRjaGluZ0JhbGFuY2UodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgLy8gSWYgd2UgYWxyZWFkeSBoYXZlIHVzZXIgZGF0YSwgdXNlIGl0XHJcbiAgICAgICAgaWYgKGluaXRpYWxVc2VyRGF0YSAmJiBpbml0aWFsVXNlckRhdGEuX2lkID09PSBzZWxlY3RlZFVzZXJJZCkge1xyXG4gICAgICAgICAgc2V0VXNlckFjY291bnRJbmZvKGluaXRpYWxVc2VyRGF0YSk7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgdG90YWxfYW1vdW50OiBpbml0aWFsVXNlckRhdGEuYmFsYW5jZT8udG9TdHJpbmcoKSB8fCBcIlwiLFxyXG4gICAgICAgICAgICBkZWR1Y3Rpb25zOiBcIlwiLFxyXG4gICAgICAgICAgICBhbW91bnQ6IGluaXRpYWxVc2VyRGF0YS5iYWxhbmNlPy50b1N0cmluZygpIHx8IFwiXCIsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICBzZXRGZXRjaGluZ0JhbGFuY2UoZmFsc2UpO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL3VzZXItYWNjb3VudHMvJHtzZWxlY3RlZFVzZXJJZH1gKTtcclxuICAgICAgICBpZiAocmVzLmRhdGE/LnN0YXR1cykge1xyXG4gICAgICAgICAgY29uc3QgYWNjb3VudCA9IHJlcy5kYXRhLmRhdGE7XHJcbiAgICAgICAgICBzZXRVc2VyQWNjb3VudEluZm8oYWNjb3VudCk7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgdG90YWxfYW1vdW50OiBhY2NvdW50LmJhbGFuY2U/LnRvU3RyaW5nKCkgfHwgXCJcIixcclxuICAgICAgICAgICAgZGVkdWN0aW9uczogXCJcIixcclxuICAgICAgICAgICAgYW1vdW50OiBhY2NvdW50LmJhbGFuY2U/LnRvU3RyaW5nKCkgfHwgXCJcIixcclxuICAgICAgICAgIH0pKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0VXNlckFjY291bnRJbmZvKG51bGwpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgc2V0VXNlckFjY291bnRJbmZvKG51bGwpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldEZldGNoaW5nQmFsYW5jZShmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZmV0Y2hFbnJvbGxtZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0RW5yb2xsbWVudExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC9nZXQtZGVsZXRlZC1lbnJvbGxtZW50c2ApO1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSByZXMuZGF0YSB8fCBbXTtcclxuICAgICAgICBjb25zdCBtYXRjaGVkID0gZGF0YS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0udXNlcl9pZD8uX2lkID09PSBzZWxlY3RlZFVzZXJJZCk7XHJcbiAgICAgICAgc2V0RGVsZXRlZEVucm9sbG1lbnRzKG1hdGNoZWQpO1xyXG4gICAgICAgIGlmIChtYXRjaGVkLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IGZpcnN0ID0gbWF0Y2hlZFswXTtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBncm91cF9pZDogZmlyc3QuZ3JvdXBfaWQ/Ll9pZCxcclxuICAgICAgICAgICAgdGlja2V0OiBmaXJzdC50aWNrZXRzLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgc2V0RGVsZXRlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRFbnJvbGxtZW50TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hBY2NvdW50KCk7XHJcbiAgICBmZXRjaEVucm9sbG1lbnRzKCk7XHJcbiAgfSwgW3NlbGVjdGVkVXNlcklkLCBpbml0aWFsVXNlckRhdGFdKTtcclxuXHJcbiAgLy8gLS0tLSBIYW5kbGVycyAtLS0tXHJcbiAgY29uc3QgaGFuZGxlQ3VzdG9tZXIgPSAodXNlcklkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFVzZXJJZCh1c2VySWQpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuICAgICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICAgIHRpY2tldDogXCJcIixcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgY3VzdG9tZXI6IFwiXCIsIGdyb3VwX3RpY2tldDogXCJcIiB9KSk7XHJcbiAgICAvLyBSZXNldCBzZXJ2aWNlIGNoYXJnZSBhbmQgR1NUIHdoZW4gY3VzdG9tZXIgY2hhbmdlc1xyXG4gICAgc2V0U2VydmljZUNoYXJnZSgwKTtcclxuICAgIHNldEdzdEFtb3VudCgwKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBpZiAoW1widG90YWxfYW1vdW50XCIsIFwiZGVkdWN0aW9uc1wiLCBcImFtb3VudFwiXS5pbmNsdWRlcyhuYW1lKSkge1xyXG4gICAgICBsZXQgY2xlYW5lZCA9IHZhbHVlLnJlcGxhY2UoL1teMC05Ll0vZywgXCJcIik7XHJcbiAgICAgIGlmICgoY2xlYW5lZC5tYXRjaCgvXFwuL2cpIHx8IFtdKS5sZW5ndGggPiAxKSByZXR1cm47XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiB7XHJcbiAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4ucHJldiwgW25hbWVdOiBjbGVhbmVkIH07XHJcbiAgICAgICAgaWYgKG5hbWUgPT09IFwidG90YWxfYW1vdW50XCIgfHwgbmFtZSA9PT0gXCJkZWR1Y3Rpb25zXCIpIHtcclxuICAgICAgICAgIGNvbnN0IHRvdGFsID0gcGFyc2VGbG9hdChuYW1lID09PSBcInRvdGFsX2Ftb3VudFwiID8gY2xlYW5lZCA6IHVwZGF0ZWQudG90YWxfYW1vdW50KSB8fCAwO1xyXG4gICAgICAgICAgY29uc3QgZGVkdWN0aW9uID0gcGFyc2VGbG9hdChuYW1lID09PSBcImRlZHVjdGlvbnNcIiA/IGNsZWFuZWQgOiB1cGRhdGVkLmRlZHVjdGlvbnMpIHx8IDA7XHJcbiAgICAgICAgICB1cGRhdGVkLmFtb3VudCA9IE1hdGgubWF4KHRvdGFsIC0gZGVkdWN0aW9uLCAwKS50b1N0cmluZygpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZDtcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycyhwcmV2ID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtuYW1lXTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBtb2RlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcGF5X3R5cGU6IG1vZGUsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBtb2RlID09PSBcImNhc2hcIiA/IFwiXCIgOiBwcmV2LnRyYW5zYWN0aW9uX2lkLFxyXG4gICAgICAuLi4obW9kZSAhPT0gXCJjaGVxdWVcIiAmJiB7XHJcbiAgICAgICAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICAgICAgICBjaGVxdWVfZGF0ZTogXCJcIixcclxuICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgICAgfSksXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBpZiAoIWZvcm1EYXRhLnVzZXJfaWQpIG5ld0Vycm9ycy5jdXN0b21lciA9IFwiUGxlYXNlIHNlbGVjdCBhIGN1c3RvbWVyXCI7XHJcbiAgICBpZiAoIWZvcm1EYXRhLmdyb3VwX2lkICYmICFmb3JtRGF0YS5waWdtZV9pZCAmJiAhZm9ybURhdGEubG9hbl9pZCkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfdGlja2V0ID0gXCJQbGVhc2Ugc2VsZWN0IGEgZ3JvdXAgYW5kIHRpY2tldFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXlfZGF0ZSkgbmV3RXJyb3JzLnBheV9kYXRlID0gXCJQYXltZW50IGRhdGUgaXMgcmVxdWlyZWRcIjtcclxuXHJcbiAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KGZvcm1EYXRhLmFtb3VudCk7XHJcbiAgICBpZiAoaXNOYU4oYW1vdW50KSB8fCBhbW91bnQgPD0gMCkge1xyXG4gICAgICBuZXdFcnJvcnMuYW1vdW50ID0gXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBwb3NpdGl2ZSBhbW91bnRcIjtcclxuICAgIH0gZWxzZSBpZiAodXNlckFjY291bnRJbmZvICYmIGFtb3VudCA+IHVzZXJBY2NvdW50SW5mby5iYWxhbmNlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBgQW1vdW50IGNhbm5vdCBleGNlZWQgYXZhaWxhYmxlIGJhbGFuY2Ugb2Yg4oK5JHt1c2VyQWNjb3VudEluZm8uYmFsYW5jZS50b0xvY2FsZVN0cmluZygpfWA7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGZvcm1EYXRhLnBheV90eXBlID09PSBcIm9ubGluZVwiIHx8IGZvcm1EYXRhLnBheV90eXBlID09PSBcIm9ubGluZS91cGlcIiB8fCBmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJCYW5rIFRyYW5zZmVyXCIpIHtcclxuICAgICAgaWYgKCFmb3JtRGF0YS50cmFuc2FjdGlvbl9pZD8udHJpbSgpKVxyXG4gICAgICAgIG5ld0Vycm9ycy50cmFuc2FjdGlvbl9pZCA9IFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWQgZm9yIG9ubGluZSBwYXltZW50c1wiO1xyXG4gICAgfSBlbHNlIGlmIChmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJjaGVxdWVcIikge1xyXG4gICAgICBpZiAoIWZvcm1EYXRhLmNoZXF1ZV9udW1iZXI/LnRyaW0oKSkgbmV3RXJyb3JzLmNoZXF1ZV9udW1iZXIgPSBcIkNoZXF1ZSBudW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgaWYgKCFmb3JtRGF0YS5jaGVxdWVfZGF0ZT8udHJpbSgpKSBuZXdFcnJvcnMuY2hlcXVlX2RhdGUgPSBcIkNoZXF1ZSBkYXRlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXlfZm9yKSBuZXdFcnJvcnMucGF5X2ZvciA9IFwiUGxlYXNlIHNlbGVjdCByZWFzb25cIjtcclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKCF2YWxpZGF0ZUZvcm0oKSkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGFkbWluID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIikgfHwgXCJ7fVwiKTtcclxuICAgIGNvbnN0IGlzUGlnbXkgPSBmb3JtRGF0YS5wYXlfZm9yID09PSBcIlBpZ215IENsb3NlIC8gUGF5b3V0XCI7XHJcbiAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICB1c2VyX2lkOiBmb3JtRGF0YS51c2VyX2lkLFxyXG4gICAgICAuLi4oaXNQaWdteVxyXG4gICAgICAgID8geyBwaWdtZV9pZDogZm9ybURhdGEucGlnbWVfaWQgfVxyXG4gICAgICAgIDogeyBncm91cF9pZDogZm9ybURhdGEuZ3JvdXBfaWQgfSksXHJcbiAgICAgIC4uLihpc1BpZ215XHJcbiAgICAgICAgPyB7IHBheV9mb3I6IFwiUGlnbWVcIiB9XHJcbiAgICAgICAgOiBcIlwiKSxcclxuICAgICAgdGlja2V0OiBmb3JtRGF0YS50aWNrZXQudG9TdHJpbmcoKSxcclxuICAgICAgcGF5X2RhdGU6IGZvcm1EYXRhLnBheV9kYXRlLFxyXG4gICAgICB0b3RhbF9hbW91bnQ6IGZvcm1EYXRhLnRvdGFsX2Ftb3VudCB8fCBcIjBcIixcclxuICAgICAgZGVkdWN0aW9uczogZm9ybURhdGEuZGVkdWN0aW9ucyB8fCBcIjBcIixcclxuICAgICAgYW1vdW50OiBmb3JtRGF0YS5hbW91bnQsXHJcbiAgICAgIHBheV90eXBlOiBmb3JtRGF0YS5wYXlfdHlwZSxcclxuICAgICAgcmVhc29uOiBmb3JtRGF0YT8ucGF5X2ZvcixcclxuICAgICAgZGlzYnVyc2VtZW50X3R5cGU6XHJcbiAgICAgICAgZm9ybURhdGEucGF5X2ZvciA9PT0gXCJDaGl0IENhbmNlbGxhdGlvbiAvIFBheW91dFwiXHJcbiAgICAgICAgICA/IFwiQ2hpdCBDYW5jZWxsYXRpb25cIlxyXG4gICAgICAgICAgOiBpc1BpZ215XHJcbiAgICAgICAgICAgID8gXCJQaWdteSBDbG9zZVwiXHJcbiAgICAgICAgICAgIDogXCJDaGl0IENsb3NlXCIsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBmb3JtRGF0YS50cmFuc2FjdGlvbl9pZCB8fCBcIlwiLFxyXG4gICAgICBhZG1pbl9pZDogYWRtaW4uX2lkLFxyXG4gICAgICBhZG1pbl90eXBlOiBhZG1pbi5faWQsXHJcbiAgICAgIGRlbGV0ZWQ6IGZhbHNlLFxyXG4gICAgICBub3RlOiBmb3JtRGF0YS5ub3RlLFxyXG4gICAgICAvLyBkaXNidXJzZW1lbnRfdHlwZTogXCJUcmFuc2ZlclwiLFxyXG4gICAgICBzZXJ2aWNlX2NoYXJnZTogc2VydmljZUNoYXJnZS50b1N0cmluZygpLFxyXG4gICAgICBnc3RfYW1vdW50OiBnc3RBbW91bnQudG9TdHJpbmcoKSxcclxuICAgICAgLi4uKGZvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiICYmIHtcclxuICAgICAgICBjaGVxdWVfbnVtYmVyOiBmb3JtRGF0YS5jaGVxdWVfbnVtYmVyLFxyXG4gICAgICAgIGNoZXF1ZV9kYXRlOiBmb3JtRGF0YS5jaGVxdWVfZGF0ZSxcclxuICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBmb3JtRGF0YS5jaGVxdWVfYmFua19uYW1lLFxyXG4gICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogZm9ybURhdGEuY2hlcXVlX2JhbmtfYnJhbmNoLFxyXG4gICAgICB9KSxcclxuICAgIH07XHJcblxyXG4gICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXCJ2MS9hZG1pbi91c2VyLWFjY291bnRzL3BheW91dFwiLCBwYXlsb2FkKTtcclxuICAgICAgLy8gcmV0dXJuIGZhbHNlXHJcbiAgICAgIGlmIChvblN1Y2Nlc3MpIG9uU3VjY2VzcygpO1xyXG4gICAgICBvbkNsb3NlKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgLy8gT3B0aW9uYWxseSBzaG93IGFuIGVycm9yIGFsZXJ0XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7b3BlbkJhY2tkcm9wTG9hZGVyICYmIDxCYWNrZHJvcEJsdXJMb2FkZXIgdGl0bGU9XCJQYXltZW50IERhdGEgUHJvY2Vzc2luZy4uLi5cIiAvPn1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IG1heC1oLVs4MHZoXSBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbWItNCBib3JkZXItYiBwYi0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgPHNwYW4+Q2hpdCBDYW5jZWxsYXRpb24sIENsb3N1cmUgJiBQaWdteSBQYXlvdXRzPC9zcGFuPlxyXG4gICAgICAgICAgey8qIEFkZCBWaWV3IEhpc3RvcnkgYnV0dG9uICovfVxyXG4gICAgICAgICAgey8qIHtzZWxlY3RlZFVzZXJJZCAmJiB0cmFuc2FjdGlvbkhpc3RvcnkubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VHhuRHJhd2VyKHRydWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtc20gYmctYmx1ZS01MCBob3ZlcjpiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNzAwIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxGYUhpc3RvcnkgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgVmlldyBIaXN0b3J5XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKX0gKi99XHJcbiAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICB7LyogQ3VzdG9tZXIgJiBHcm91cCAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3Igc2VhcmNoIGN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uPy5sYWJlbD8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnVzZXJfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17dXNlcnMubWFwKCh1KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICB2YWx1ZTogdS5faWQsXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHt1LmZ1bGxfbmFtZX0gfCAke3UucGhvbmVfbnVtYmVyfWAsXHJcbiAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmN1c3RvbWVyfTwvcD59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgR3JvdXAgJiBUaWNrZXQgLyBQaWdteSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnNlbGVjdGVkVmFsdWUgfHxcclxuICAgICAgICAgICAgICAgICAgKGZvcm1EYXRhLnRpY2tldCA/IGAke2Zvcm1EYXRhLmdyb3VwX2lkfXwke2Zvcm1EYXRhLnRpY2tldH1gIDogdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFmb3JtRGF0YS51c2VyX2lkIHx8IGVucm9sbG1lbnRMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17ZW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17ZW5yb2xsbWVudExvYWRpbmcgPyBcIkxvYWRpbmcuLi5cIiA6IFwiU2VsZWN0IEFjY291bnRcIn1cclxuICAgICAgICAgICAgICAgIG5vdEZvdW5kQ29udGVudD17XHJcbiAgICAgICAgICAgICAgICAgIGVucm9sbG1lbnRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U3BpbiBzaXplPVwic21hbGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMiB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBObyBSZWNvcmRzIEZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGlmICghdmFsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGlja2V0OiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGlnbWVfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsb2FuX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgIGlmICh2YWwuc3RhcnRzV2l0aChcInBpZ21lLVwiKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWU6IHZhbCxcclxuICAgICAgICAgICAgICAgICAgICAgIHBpZ21lX2lkOiB2YWwucmVwbGFjZShcInBpZ21lLVwiLCBcIlwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGlja2V0OiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbG9hbl9pZDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodmFsLnN0YXJ0c1dpdGgoXCJsb2FuLVwiKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWU6IHZhbCxcclxuICAgICAgICAgICAgICAgICAgICAgIGxvYW5faWQ6IHZhbC5yZXBsYWNlKFwibG9hbi1cIiwgXCJcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICBncm91cF9pZDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHRpY2tldDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHBpZ21lX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBbZ2lkLCB0a3RdID0gdmFsLnNwbGl0KFwifFwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlOiB2YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgICBncm91cF9pZDogZ2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGlja2V0OiB0a3QsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwaWdtZV9pZDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxvYW5faWQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIGdyb3VwX3RpY2tldDogXCJcIiB9KSk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uPy5sYWJlbD8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1xyXG4gICAgICAgICAgICAgICAgICAvLyBHcm91cCAmIFRpY2tldFxyXG4gICAgICAgICAgICAgICAgICAuLi5kZWxldGVkRW5yb2xsbWVudHMubWFwKChpdGVtKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBgJHtpdGVtLmdyb3VwX2lkPy5faWR9fCR7aXRlbS50aWNrZXRzfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGAke2l0ZW0uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9IHwgVGlja2V0ICR7aXRlbS50aWNrZXRzfWAsXHJcbiAgICAgICAgICAgICAgICAgIH0pKSxcclxuXHJcbiAgICAgICAgICAgICAgICAgIC8vIFBpZ215XHJcbiAgICAgICAgICAgICAgICAgIC4uLnBpZ21lQ3VzdG9tZXJzLm1hcCgocGlnbWUpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGBwaWdtZS0ke3BpZ21lLl9pZH1gLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgUGlnbXkgLSAke3BpZ21lLnBpZ21lX2lkfSB8IOKCuSR7cGlnbWUucGF5YWJsZV9hbW91bnR9YCxcclxuICAgICAgICAgICAgICAgICAgfSkpLFxyXG5cclxuICAgICAgICAgICAgICAgICAgLy8gTG9hblxyXG4gICAgICAgICAgICAgICAgICAuLi5ib3Jyb3dlcnMubWFwKChib3Jyb3dlcikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogYGxvYW4tJHtib3Jyb3dlci5faWR9YCxcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogYExvYW4gLSAke2JvcnJvd2VyLmxvYW5faWR9IHwg4oK5JHtib3Jyb3dlci5sb2FuX2Ftb3VudH1gLFxyXG4gICAgICAgICAgICAgICAgICB9KSksXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF90aWNrZXQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuZ3JvdXBfdGlja2V0fTwvcD59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7LyogUGF5IEZvciBSZWFzb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctaW5kaWdvLTUwIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBQYXkgRm9yIChSZWFzb24pIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgbmFtZT1cInBheV9mb3JcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9mb3J9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgYmctd2hpdGUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTQwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBQYXltZW50IFJlYXNvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNoaXQgQ2FuY2VsbGF0aW9uIC8gUGF5b3V0XCI+Q2hpdCBDYW5jZWxsYXRpb248L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDaGl0IENsb3NlIC8gUGF5b3V0XCI+Q2hpdCBDbG9zZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBpZ215IENsb3NlIC8gUGF5b3V0XCI+UGlnbXkgQ2xvc2U8L29wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgIHtlcnJvcnMucGF5X2ZvciAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2Zvcn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHsvKiA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICB7LyogQmFsYW5jZSBEaXNwbGF5IHdpdGggU2VydmljZSBDaGFyZ2UgYW5kIEdTVCAqL31cclxuICAgICAgICAgIHt1c2VyQWNjb3VudEluZm8/LmJhbGFuY2UgPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCByb3VuZGVkLXhsIHAtNSBzaGFkb3ctc20gcmVsYXRpdmVcIj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00XCI+XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRVc2VySWQgJiYgdHJhbnNhY3Rpb25IaXN0b3J5Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1R4bkRyYXdlcih0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1tZWRpdW0gYmctd2hpdGUgaG92ZXI6YmctZ3JlZW4tMTAwIHRleHQtYmx1ZS03MDAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHNoYWRvdy1zbSB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYUhpc3RvcnkgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgVmlldyBIaXN0b3J5XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7LyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL31cclxuXHJcbiAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwci0yOFwiPiB7LyogQWRkZWQgcHItMjggdG8gYXZvaWQgdGV4dCBvdmVybGFwcGluZyB0aGUgYWJzb2x1dGUgYnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VzZXJBY2NvdW50SW5mby5mdWxsX25hbWUgfHwgdXNlckFjY291bnRJbmZvPy51c2VyRGV0YWlscz8uZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQXZhaWxhYmxlIEJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWV4dHJhYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuSB7TnVtYmVyKHVzZXJBY2NvdW50SW5mby5iYWxhbmNlKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFNlcnZpY2UgQ2hhcmdlcyAqL31cclxuICAgICAgICAgICAgICB7LyogeyhzZXJ2aWNlQ2hhcmdlID4gMCB8fCBnc3RBbW91bnQgPiAwKSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgYm9yZGVyLXQgYm9yZGVyLWdyZWVuLTIwMCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC0zIGJvcmRlciBib3JkZXItYmx1ZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2VydmljZSBDaGFyZ2VcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7TnVtYmVyKHNlcnZpY2VDaGFyZ2UpLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBwLTMgYm9yZGVyIGJvcmRlci1wdXJwbGUtMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEdTVCBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAg4oK5IHtOdW1iZXIoZ3N0QW1vdW50KS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC0zIGJvcmRlciBib3JkZXItcmVkLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBEZWR1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7KE51bWJlcihzZXJ2aWNlQ2hhcmdlKSArIE51bWJlcihnc3RBbW91bnQpKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfSAqL31cclxuXHJcbiAgICAgICAgICAgICAgey8qIFJlbW92YWwgUmVhc29uICovfVxyXG4gICAgICAgICAgICAgIHsvKiB7cmVtb3ZhbFJlYXNvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgYm9yZGVyLXQgYm9yZGVyLWdyZWVuLTIwMCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1ncmF5LTUwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZW1vdmFsIFJlYXNvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIG1kOnRleHQtYmFzZSBmb250LW1lZGl1bSB0ZXh0LXJlZC03MDAgYnJlYWstd29yZHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZW1vdmFsUmVhc29ufVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfSAqL31cclxuXHJcbiAgICAgICAgICAgICAgey8qIExvYWRpbmcgKi99XHJcbiAgICAgICAgICAgICAge2xvYWRpbmdUcmFuc2FjdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgYm9yZGVyLXQgYm9yZGVyLWdyZWVuLTIwMCBwdC00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJzbWFsbFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIExvYWRpbmcgdHJhbnNhY3Rpb24gZGV0YWlscy4uLlxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIFBheW1lbnQgRGV0YWlscyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLWJsdWUtNjAwIHJvdW5kZWQtZnVsbFwiIC8+IFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW1vZGlmeVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgIG1pbj17bW9kaWZ5TWluTWF4UGF5bWVudERhdGUgPyB5ZXN0ZXJkYXkgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG1heD17bW9kaWZ5TWluTWF4UGF5bWVudERhdGUgPyB0b2RheSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMucGF5X2RhdGV9PC9wPn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGF5X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50TW9kZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJhbmsgVHJhbnNmZXJcIj5CYW5rIFRyYW5zZmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmUvdXBpXCI+T25saW5lIC8gVVBJPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5DaGVxdWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNyZWRpdCBOb3RlXCI+Q3JlZGl0IE5vdGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBPbmxpbmUgLyBVUEkgVHJhbnNhY3Rpb24gSUQgKi99XHJcbiAgICAgICAgICAgIHsoZm9ybURhdGEucGF5X3R5cGUgPT09IFwib25saW5lXCIgfHwgZm9ybURhdGEucGF5X3R5cGUgPT09IFwib25saW5lL3VwaVwiIHx8IGZvcm1EYXRhLnBheV90eXBlID09PSBcIkJhbmsgVHJhbnNmZXJcIikgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRyYW5zYWN0aW9uIElEXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy50cmFuc2FjdGlvbl9pZH08L3A+fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIENoZXF1ZSBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICB7Zm9ybURhdGEucGF5X3R5cGUgPT09IFwiY2hlcXVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+Q2hlcXVlIERldGFpbHM8L2g1PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfbnVtYmVyICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmNoZXF1ZV9udW1iZXJ9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfZGF0ZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5jaGVxdWVfZGF0ZX08L3A+fVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPkJhbmsgTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX2JhbmtfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5CYW5rIEJyYW5jaDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ2FuY2VsbGF0aW9uIEJyZWFrZG93biAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHAtNCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgey8qIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTYgYmctcmVkLTUwMCByb3VuZGVkLWZ1bGxcIiAvPiBDYW5jZWxsYXRpb24gQnJlYWtkb3duXHJcbiAgICAgICAgICAgIDwvaDQ+ICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgQW1vdW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOZXQgcGF5YWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGJnLWJsdWUtNTAgZm9udC1tZWRpdW0gdGV4dC1ibHVlLTgwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuYW1vdW50fTwvcD59XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+e251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuYW1vdW50KX08L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7LyogPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBheSBGb3IgKHJlYXNvbikgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfZm9yXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9mb3J9ICAgLy8gPC0tIGNoYW5nZWQgZnJvbSBmb3JtRGF0YS5wYXlfZm9yIHx8IHJlbW92YWxSZWFzb25cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2hpdF9jYW5jZWxsYXRpb25cIj5DaGl0IENhbmNlbGxhdGlvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2hpdF9jbG9zZWRcIj5DaGl0IENsb3NlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2ZvciAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5wYXlfZm9yfTwvcD59XHJcbiAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5Ob3RlIChvcHRpb25hbCk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5vdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkaXRpb25hbCByZW1hcmtzIChvcHRpb25hbClcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBXaGF0c0FwcCBOb3RpZmljYXRpb24gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItZ3JheS0yMDAgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RmFXaGF0c2FwcFNxdWFyZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCB0ZXh0LTJ4bFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+V2hhdHNBcHAgTm90aWZpY2F0aW9uPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17d2hhdHNhcHBFbmFibGV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFdoYXRzYXBwRW5hYmxlKGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyZWVuLTUwMCByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlNlbmQgdmlhIFdoYXRzQXBwPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEFjdGlvbnMgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTEwMCByb3VuZGVkXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMiB0ZXh0LXNtIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcm91bmRlZCBmb250LWJvbGQgaG92ZXI6YmctYmx1ZS03MDAgc2hhZG93LWxnXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENvbmZpcm0gRGlzYnVyc2VtZW50XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9mb3JtPlxyXG5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogVHJhbnNhY3Rpb24gSGlzdG9yeSBEcmF3ZXIgKi99XHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgey8qIExlZnQgU2lkZSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWJsdWUtMTAwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgIDxGYUhpc3RvcnkgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSGlzdG9yeVxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt0cmFuc2FjdGlvbkhpc3RvcnkubGVuZ3RofSByZWNvcmRcclxuICAgICAgICAgICAgICAgICAge3RyYW5zYWN0aW9uSGlzdG9yeS5sZW5ndGggIT09IDEgPyBcInNcIiA6IFwiXCJ9IGZvdW5kXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFJpZ2h0IFNpZGUgLSBDdXN0b21lciBOYW1lICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHQgbXItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj5DdXN0b21lcjwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAge3RyYW5zYWN0aW9uSGlzdG9yeT8uWzBdPy5lbnJvbGxfaWQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICB1c2VyQWNjb3VudEluZm8/LmZ1bGxfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICBcIk4vQVwifVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4gICAgICAgIG9wZW49e3Nob3dUeG5EcmF3ZXJ9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd1R4bkRyYXdlcihmYWxzZSl9XHJcbiAgICAgICAgd2lkdGg9ezYyMH1cclxuICAgICAgICBjbG9zYWJsZT17ZmFsc2V9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwidHJhbnNhY3Rpb24tZHJhd2VyXCJcclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIGJvZHk6IHsgcGFkZGluZzogXCIwXCIsIGJhY2tncm91bmQ6IFwiI2Y4ZmFmY1wiIH0sXHJcbiAgICAgICAgICBoZWFkZXI6IHtcclxuICAgICAgICAgICAgcGFkZGluZzogXCIyMHB4IDI0cHhcIixcclxuICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjZTJlOGYwXCIsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI2ZmZmZmZlwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgZXh0cmE9e1xyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VHhuRHJhd2VyKGZhbHNlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTUwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIiAvPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIH1cclxuICAgICAgPlxyXG4gICAgICAgIHtsb2FkaW5nVHJhbnNhY3Rpb24gPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtNjQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJvcmRlci0zIGJvcmRlci1ibHVlLTIwMCBib3JkZXItdC1ibHVlLTYwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCIgLz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+TG9hZGluZyB0cmFuc2FjdGlvbnMuLi48L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogdHJhbnNhY3Rpb25IaXN0b3J5Lmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC02NCB0ZXh0LWNlbnRlciBweC02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtMnhsIGJnLWdyYXktMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1ncmF5LTMwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMS41XCIgZD1cIk05IDVIN2EyIDIgMCAwMC0yIDJ2MTBhMiAyIDAgMDAyIDJoOGEyIDIgMCAwMDItMlY3YTIgMiAwIDAwLTItMmgtMk05IDVhMiAyIDAgMDAyIDJoMmEyIDIgMCAwMDItMk05IDVhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMlwiIC8+XHJcbiAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMFwiPk5vIHRyYW5zYWN0aW9ucyBmb3VuZDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIG10LTFcIj5QYXltZW50IGhpc3RvcnkgZm9yIHRoaXMgY3VzdG9tZXIgd2lsbCBhcHBlYXIgaGVyZTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAge3RyYW5zYWN0aW9uSGlzdG9yeS5tYXAoKHR4biwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgbmV0ID0gTnVtYmVyKHR4bi5hbW91bnQpO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHNlcnZpY2UgPSBOdW1iZXIodHhuLnNlcnZpY2VfY2hhcmdlIHx8IDApO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdzdCA9IE51bWJlcih0eG4uZ3N0X2Ftb3VudCB8fCAwKTtcclxuICAgICAgICAgICAgICBjb25zdCBncm9zcyA9IHR4bi50b3RhbF9hbW91bnQgfHwgKG5ldCArIHNlcnZpY2UgKyBnc3QpO1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCBpc0NyZWRpdCA9IHR4bi50cmFuc2FjdGlvbl90eXBlPy50b0xvd2VyQ2FzZSgpPy5pbmNsdWRlcyhcImNyZWRpdFwiKSB8fFxyXG4gICAgICAgICAgICAgICAgdHhuLnRyYW5zYWN0aW9uX3R5cGU/LnRvTG93ZXJDYXNlKCk/LmluY2x1ZGVzKFwicmVmdW5kXCIpIHx8XHJcbiAgICAgICAgICAgICAgICB0eG4udHJhbnNhY3Rpb25fdHlwZT8udG9Mb3dlckNhc2UoKT8uaW5jbHVkZXMoXCJyZWNlaXB0XCIpO1xyXG5cclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBrZXk9e3R4bi5faWQgfHwgaWR4fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIG92ZXJmbG93LWhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBUb3AgYWNjZW50IHN0cmlwZSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BoLTEgdy1mdWxsICR7aXNDcmVkaXQgPyAnYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNDAwIHRvLWdyZWVuLTUwMCcgOiAnYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNDAwIHRvLWluZGlnby01MDAnfWB9IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXI6IERhdGUgKyBUeXBlIEJhZGdlICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTggaC04IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgJHtpc0NyZWRpdCA/ICdiZy1lbWVyYWxkLTUwJyA6ICdiZy1ibHVlLTUwJ31gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDcmVkaXQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTYwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk03IDExbDUtNW0wIDBsNSA1bS01LTV2MTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNjAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE3IDlWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2NmEyIDIgMCAwMDIgMmgybTIgNGgxMGEyIDIgMCAwMDItMnYtNmEyIDIgMCAwMC0yLTJIOWEyIDIgMCAwMC0yIDJ2NmEyIDIgMCAwMDIgMnptNy01YTIgMiAwIDExLTQgMCAyIDIgMCAwMTQgMHpcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZSh0eG4udHJhbnNhY3Rpb25fZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1JTicsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF5OiAnMi1kaWdpdCcsIG1vbnRoOiAnc2hvcnQnLCB5ZWFyOiAnbnVtZXJpYydcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUodHhuLnRyYW5zYWN0aW9uX2RhdGUpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTEgcm91bmRlZC1sZyB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyICR7aXNDcmVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0eG4udHJhbnNhY3Rpb25fdHlwZSB8fCBcIlBheW1lbnRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyICYgR3JvdXAgSW5mbyAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTQgcC0zIGJnLXNsYXRlLTUwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS0yMDAgdG8tc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7KHR4bi5lbnJvbGxfaWQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCB1c2VyQWNjb3VudEluZm8/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0eG4uZW5yb2xsX2lkPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgdXNlckFjY291bnRJbmZvPy5mdWxsX25hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNTAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHhuLmVucm9sbF9pZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB0eG4uZW5yb2xsX2lkLmdyb3VwX2lkLmdyb3VwX25hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dHhuLmVucm9sbF9pZD8udGlja2V0cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktMzAwXCI+wrc8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmRpZ28tNjAwIGJnLWluZGlnby01MCBweC0xLjUgcHktMC41IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUa3Qge3R4bi5lbnJvbGxfaWQudGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFtb3VudHMgR3JpZCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+R3Jvc3M8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7Z3Jvc3MudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+U2VydmljZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtzZXJ2aWNlLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLXhsIHAtMi41IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPkdTVDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtnc3QudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIHAtMi41IHRleHQtY2VudGVyICR7aXNDcmVkaXQgPyAnYmctZW1lcmFsZC01MCcgOiAnYmctYmx1ZS01MCd9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEgJHtpc0NyZWRpdCA/ICd0ZXh0LWVtZXJhbGQtNTAwJyA6ICd0ZXh0LWJsdWUtNTAwJ31gfT5OZXQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YHRleHQtYmFzZSBmb250LWV4dHJhYm9sZCAke2lzQ3JlZGl0ID8gJ3RleHQtZW1lcmFsZC03MDAnIDogJ3RleHQtYmx1ZS03MDAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtuZXQudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogUmVhc29uLCBNb2RlICYgTm90ZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiBwdC0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3R4bi5yZWFzb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctYW1iZXItNTAgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNTAwIGZsZXgtc2hyaW5rLTBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEzIDE2aC0xdi00aC0xbTEtNGguMDFNMjEgMTJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtYW1iZXItNzAwXCI+e3R4bi5yZWFzb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dHhuLnBheV90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXNsYXRlLTEwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1zbGF0ZS00MDAgZmxleC1zaHJpbmstMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMyAxMGgxOE03IDE1aDFtNCAwaDFtLTcgNGgxMmEzIDMgMCAwMDMtM1Y4YTMgMyAwIDAwLTMtM0g2YTMgMyAwIDAwLTMgM3Y4YTMgMyAwIDAwMyAzelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPnt0eG4ucGF5X3R5cGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dHhuLm5vdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNSBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWdyYXktNDAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMSA1SDZhMiAyIDAgMDAtMiAydjExYTIgMiAwIDAwMiAyaDExYTIgMiAwIDAwMi0ydi01bS0xLjQxNC05LjQxNGEyIDIgMCAxMTIuODI4IDIuODI4TDExLjgyOCAxNUg5di0yLjgyOGw4LjU4Ni04LjU4NnpcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS02MDAgaXRhbGljIGxlYWRpbmctcmVsYXhlZFwiPnt0eG4ubm90ZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBGb290ZXIgU3VtbWFyeSAqL31cclxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwLTQgYmctd2hpdGUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1sZyBiZy1pbmRpZ28tMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1pbmRpZ28tNjAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNOSA3aDZtMCAxMHYtM20tMyAzaC4wMU05IDE3aC4wMU05IDE0aC4wMU0xMiAxNGguMDFNMTUgMTFoLjAxTTEyIDExaC4wMU05IDExaC4wMU03IDIxaDEwYTIgMiAwIDAwMi0yVjVhMiAyIDAgMDAtMi0ySDdhMiAyIDAgMDAtMiAydjE0YTIgMiAwIDAwMiAyelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+VG90YWwgTmV0IEFtb3VudDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj57dHJhbnNhY3Rpb25IaXN0b3J5Lmxlbmd0aH0gdHJhbnNhY3Rpb25zPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtaW5kaWdvLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7dHJhbnNhY3Rpb25IaXN0b3J5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVkdWNlKChzdW0sIHQpID0+IHN1bSArIE51bWJlcih0LmFtb3VudCB8fCAwKSwgMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9EcmF3ZXI+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hpdENhbmNlbFBheW1lbnRGb3JtOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DaGl0Q2FuY2VsUGF5bWVudEZvcm0uanN4In0=