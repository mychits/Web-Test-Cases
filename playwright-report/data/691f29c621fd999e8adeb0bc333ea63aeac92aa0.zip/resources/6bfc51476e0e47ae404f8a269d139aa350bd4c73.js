import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/VisitorList.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import API from "/src/instance/TokenInstance.js";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tabs, Badge, Input, Button } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Edit, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Modal from "/src/components/modals/Modal.jsx";
const fieldSize = { height: "h-14" };
export default function VisitorList() {
  _s();
  const [openModal, setOpenModal] = useState(false);
  const [openActionId, setOpenActionId] = useState(null);
  const [formData, setFormData] = useState({
    visitorType: "Guest",
    name: "",
    phone: "",
    email: "",
    description: "",
    purpose: "",
    dateTime: "",
    meetPerson: "",
    chitGroup: "",
    customerId: "",
    groupNameDisplay: "",
    ticketNumber: ""
  });
  const [errors, setErrors] = useState({});
  const [visitors, setVisitors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [users, setUsers] = useState([]);
  const [customerEnrollments, setCustomerEnrollments] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loadingGroups, setLoadingGroups] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const getCurrentDateTime = () => {
    const now = /* @__PURE__ */ new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };
  const handleOpenModal = () => {
    setFormData({
      visitorType: "Guest",
      name: "",
      phone: "",
      email: "",
      description: "",
      purpose: "",
      dateTime: getCurrentDateTime(),
      meetPerson: "",
      chitGroup: "",
      customerId: "",
      groupNameDisplay: "",
      ticketNumber: ""
    });
    setErrors({});
    setOpenModal(true);
  };
  const fetchVisitors = async () => {
    try {
      setLoading(true);
      const res = await API.get("/visitors");
      let data = [];
      if (Array.isArray(res.data)) {
        data = res.data;
      } else if (res.data.data && Array.isArray(res.data.data)) {
        data = res.data.data;
      } else if (res.data.visitors && Array.isArray(res.data.visitors)) {
        data = res.data.visitors;
      } else {
        data = Object.values(res.data).find((v) => Array.isArray(v)) || [];
      }
      setVisitors(data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching visitors:", error);
      setLoading(false);
    }
  };
  const fetchAgents = async () => {
    try {
      const response = await API.get("/agent/get");
      let agentList = [];
      if (Array.isArray(response.data)) {
        agentList = response.data;
      } else if (response.data.agent && Array.isArray(response.data.agent)) {
        agentList = response.data.agent;
      } else if (response.data.data && Array.isArray(response.data.data)) {
        agentList = response.data.data;
      } else if (response.data.agents && Array.isArray(response.data.agents)) {
        agentList = response.data.agents;
      }
      setAgents(agentList);
    } catch (error) {
      console.error("Error fetching agents:", error);
    }
  };
  const fetchEmployees = async () => {
    try {
      const response = await API.get("/agent/get-additional-employee-info");
      const employeeData = response.data?.employee || [];
      setEmployees(employeeData);
    } catch (error) {
      console.error("Error fetching employees:", error);
    }
  };
  const fetchUsers = async () => {
    try {
      const response = await API.get("/user/get-user");
      setUsers(response.data || []);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };
  const fetchGroups = async () => {
    try {
      setLoadingGroups(true);
      const response = await API.get("/group/get-group-admin");
      setGroups(response.data || []);
      setLoadingGroups(false);
    } catch (error) {
      console.error("Error fetching groups:", error);
      setLoadingGroups(false);
    }
  };
  const fetchCustomerEnrollments = async (userId) => {
    try {
      const response = await API.post(`/enroll/get-user-tickets-report/${userId}`);
      if (response.data && response.data.length > 0) {
        setCustomerEnrollments(response.data);
        const firstEnrollment = response.data[0];
        const groupData = firstEnrollment?.enrollment?.group;
        if (groupData) {
          setFormData((prev) => ({
            ...prev,
            chitGroup: groupData._id,
            groupNameDisplay: groupData.group_name,
            ticketNumber: firstEnrollment?.enrollment?.tickets
          }));
        }
      } else {
        setCustomerEnrollments([]);
        setFormData((prev) => ({
          ...prev,
          chitGroup: "",
          groupNameDisplay: "No Active Group Found"
        }));
      }
    } catch (error) {
      console.error("Error fetching customer enrollments:", error);
      setCustomerEnrollments([]);
    }
  };
  const handleCustomerSelect = (userId) => {
    const selectedUser = users.find((u) => u._id === userId);
    if (selectedUser) {
      setFormData((prev) => ({
        ...prev,
        customerId: userId,
        name: selectedUser.full_name,
        phone: String(selectedUser.phone_number),
        email: selectedUser.email || ""
      }));
      fetchCustomerEnrollments(userId);
    }
  };
  const handleEdit = (record) => {
    setOpenActionId(null);
    setFormData({
      visitorType: record.visitorType || "Guest",
      name: record.name || "",
      phone: record.phone ? String(record.phone) : "",
      email: record.email || "",
      description: record.description || "",
      purpose: record.purpose || "",
      dateTime: record.dateTime ? record.dateTime.substring(0, 16) : getCurrentDateTime(),
      meetPerson: record.meetPerson || "",
      chitGroup: record.chitGroup || "",
      customerId: record.customerId || "",
      groupNameDisplay: record.groupName || record.groupNameDisplay || "",
      ticketNumber: record.ticketNumber || "",
      _id: record._id
    });
    setOpenModal(true);
    if (record.visitorType === "Customers" && record.customerId) {
      fetchCustomerEnrollments(record.customerId);
    }
  };
  const handleDelete = async (id) => {
    setOpenActionId(null);
    if (window.confirm("Are you sure you want to delete this visitor?")) {
      try {
        await API.delete(`/visitors/${id}`);
        alert("Visitor Deleted Successfully");
        fetchVisitors();
      } catch (error) {
        console.error("Error deleting visitor:", error);
        alert("Failed to delete visitor");
      }
    }
  };
  useEffect(() => {
    fetchVisitors();
    fetchAgents();
    fetchEmployees();
    fetchUsers();
    fetchGroups();
  }, []);
  const handleChange = (name, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };
  const validateForm = () => {
    let newErrors = {};
    if (!formData.name || formData.name.trim() === "") {
      newErrors.name = "Visitor Name is required.";
    }
    if (!formData.phone || formData.phone.trim() === "") {
      newErrors.phone = "Phone Number is required.";
    } else if (!/^[6-9]\d{9}$/.test(formData.phone)) {
      newErrors.phone = "Phone must be exactly 10 digits starting with 6-9.";
    }
    if (!formData.purpose) {
      newErrors.purpose = "Purpose of Visit required.";
    }
    if (!formData.dateTime) {
      newErrors.dateTime = "Date & Time is required.";
    }
    if (!formData.meetPerson) {
      newErrors.meetPerson = "Please select whom to meet.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const cleanPayload = (data) => {
    const cleaned = {};
    Object.entries(data).forEach(([key, value]) => {
      if (value === void 0 || value === null) return;
      if (key === "_id") return;
      if (["email", "description", "chitGroup", "customerId", "groupNameDisplay", "ticketNumber"].includes(key) && value === "") {
        return;
      }
      cleaned[key] = value;
    });
    return cleaned;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setSubmitLoading(true);
    try {
      const isUpdate = !!formData._id;
      const apiUrl = isUpdate ? `/visitors/${formData._id}` : "/visitors";
      const apiMethod = isUpdate ? API.put : API.post;
      const payload = cleanPayload(formData);
      const response = await apiMethod(apiUrl, payload);
      alert(isUpdate ? "Visitor Updated Successfully" : "Visitor Added Successfully");
      setFormData({
        visitorType: "Guest",
        name: "",
        phone: "",
        email: "",
        description: "",
        purpose: "",
        dateTime: "",
        meetPerson: "",
        chitGroup: "",
        customerId: "",
        groupNameDisplay: "",
        ticketNumber: ""
      });
      setOpenModal(false);
      fetchVisitors();
    } catch (error) {
      console.error("Error details:", error.response?.data);
      let errorMessage = "Unknown error";
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.errors) {
        const mongooseErrors = error.response.data.errors;
        errorMessage = Object.values(mongooseErrors).map((err) => err.message).join(", ");
      } else if (error.message) {
        errorMessage = error.message;
      }
      alert(`Failed: ${errorMessage}`);
    } finally {
      setSubmitLoading(false);
    }
  };
  const getMeetPersonName = (personId) => {
    if (!personId) return "N/A";
    const agent = agents.find((a) => a._id === personId);
    if (agent) return agent.name;
    const employee = employees.find((e) => e._id === personId);
    if (employee) return employee.name;
    return "N/A";
  };
  const getGroupName = (groupId) => {
    if (!groupId) return "-";
    const group = groups.find((g) => g._id === groupId);
    return group ? group.group_name : "Unknown Group";
  };
  const formatDateTime = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "Invalid Date";
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12;
    hours = hours ? hours : 12;
    const hoursStr = String(hours).padStart(2, "0");
    return `${day}/${month}/${year} ${hoursStr}:${minutes} ${ampm}`;
  };
  const formattedData = visitors.map((item, index) => {
    const type = (item.visitorType || "Guest").trim();
    return {
      ...item,
      slNo: index + 1,
      visitor_code: item?.visitor_code,
      visitorId: item.visitorId || "N/A",
      visitorType: type.charAt(0).toUpperCase() + type.slice(1),
      agentName: getMeetPersonName(item.meetPerson),
      groupName: getGroupName(item.chitGroup),
      formattedDate: formatDateTime(item.dateTime),
      purpose: item.purpose || "-",
      description: item.description || "-",
      email: item.email || "-",
      _id: item._id,
      action: /* @__PURE__ */ jsxDEV("div", { className: "relative text-center", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: (e) => {
              e.stopPropagation();
              setOpenActionId(openActionId === item._id ? null : item._id);
            },
            className: "p-2 rounded-full hover:bg-gray-200",
            children: "⋮"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
            lineNumber: 408,
            columnNumber: 11
          },
          this
        ),
        openActionId === item._id && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-6 top-10 bg-white border rounded-lg shadow-lg w-40 z-50", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                handleEdit(item);
                setOpenActionId(null);
              },
              className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-blue-600",
              children: [
                /* @__PURE__ */ jsxDEV(Edit, { size: 18 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 427,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Edit" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 428,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 419,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                handleDelete(item._id);
                setOpenActionId(null);
              },
              className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-red-600",
              children: [
                /* @__PURE__ */ jsxDEV(Trash2, { size: 18 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 438,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Delete" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 439,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 430,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 418,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 407,
        columnNumber: 7
      }, this)
    };
  });
  const standardColumns = [
    { key: "slNo", header: "Sl.No" },
    { key: "visitor_code", header: "Visitor Code" },
    { key: "name", header: "Visitor Name" },
    { key: "visitorType", header: "Type" },
    { key: "phone", header: "Phone No" },
    { key: "email", header: "Email" },
    { key: "purpose", header: "Purpose" },
    { key: "description", header: "Description" },
    { key: "formattedDate", header: "Date & Time" },
    { key: "agentName", header: "Whom to Meet" },
    { key: "action", header: "Action" }
  ];
  const customerColumns = [
    { key: "slNo", header: "Sl.No" },
    { key: "visitor_code", header: "Visitor Code" },
    { key: "name", header: "Visitor Name" },
    { key: "visitorType", header: "Type" },
    { key: "phone", header: "Phone No" },
    { key: "email", header: "Email" },
    { key: "groupName", header: "Chit Group" },
    { key: "purpose", header: "Purpose" },
    { key: "description", header: "Description" },
    { key: "formattedDate", header: "Date & Time" },
    { key: "agentName", header: "Whom to Meet" },
    { key: "action", header: "Action" }
  ];
  const counts = {
    All: formattedData.length,
    Guest: formattedData.filter((d) => d.visitorType === "Guest").length,
    Customers: formattedData.filter((d) => d.visitorType === "Customers").length,
    "Sales Leads": formattedData.filter((d) => d.visitorType === "Sales Leads").length,
    Others: formattedData.filter((d) => d.visitorType === "Others").length
  };
  const tabItems = [
    {
      key: "All",
      label: /* @__PURE__ */ jsxDEV("span", { children: [
        "All ",
        /* @__PURE__ */ jsxDEV(Badge, { count: counts.All, style: { backgroundColor: "#722ed1" } }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 488,
          columnNumber: 22
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 488,
        columnNumber: 12
      }, this),
      children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: formattedData,
          columns: customerColumns,
          exportedPdfName: "All Visitors_Report",
          exportedFileName: "All Visitors.csv",
          updateHandler: () => {
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 490,
          columnNumber: 5
        },
        this
      )
    },
    {
      key: "Guest",
      label: /* @__PURE__ */ jsxDEV("span", { children: [
        "Guest ",
        /* @__PURE__ */ jsxDEV(Badge, { count: counts.Guest, style: { backgroundColor: "#52c41a" } }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 501,
          columnNumber: 24
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 501,
        columnNumber: 12
      }, this),
      children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: formattedData.filter((d) => d.visitorType === "Guest"),
          columns: standardColumns,
          exportedPdfName: "Guest Visitors_Report",
          exportedFileName: "Guest Visitors.csv",
          updateHandler: () => {
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 503,
          columnNumber: 5
        },
        this
      )
    },
    {
      key: "Customers",
      label: /* @__PURE__ */ jsxDEV("span", { children: [
        "Customers ",
        /* @__PURE__ */ jsxDEV(Badge, { count: counts.Customers, style: { backgroundColor: "#1890ff" } }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 514,
          columnNumber: 28
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 514,
        columnNumber: 12
      }, this),
      children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: formattedData.filter((d) => d.visitorType === "Customers"),
          columns: customerColumns,
          exportedPdfName: "Customer Visitors Report",
          exportedFileName: "Customer Visitors.csv",
          updateHandler: () => {
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 516,
          columnNumber: 5
        },
        this
      )
    },
    {
      key: "Sales Leads",
      label: /* @__PURE__ */ jsxDEV("span", { children: [
        "Sales Leads ",
        /* @__PURE__ */ jsxDEV(Badge, { count: counts["Sales Leads"], style: { backgroundColor: "#722ed1" } }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 527,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 527,
        columnNumber: 12
      }, this),
      children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: formattedData.filter((d) => d.visitorType === "Sales Leads"),
          columns: standardColumns,
          exportedPdfName: "Sales Leads_Report",
          exportedFileName: "Sales Leads.csv",
          updateHandler: () => {
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 529,
          columnNumber: 5
        },
        this
      )
    },
    {
      key: "Others",
      label: /* @__PURE__ */ jsxDEV("span", { children: [
        "Others ",
        /* @__PURE__ */ jsxDEV(Badge, { count: counts.Others, style: { backgroundColor: "#faad14" } }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 540,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 540,
        columnNumber: 12
      }, this),
      children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: formattedData.filter((d) => d.visitorType === "Others"),
          columns: standardColumns,
          exportedPdfName: "Other Visitors_Report",
          exportedFileName: "Other Visitors.csv",
          updateHandler: () => {
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 542,
          columnNumber: 5
        },
        this
      )
    }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
      lineNumber: 555,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 557,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 mt-8 relative overflow-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold", children: "Visitor Management" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 561,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "Segregated visitor records by type." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 562,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
            lineNumber: 560,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleOpenModal,
              className: " bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Add Details"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 564,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 559,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl shadow-sm border border-gray-200 p-4 min-h-[400px] flex flex-col", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 575,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 574,
          columnNumber: 13
        }, this) : visitors.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: false, failure: true, data: "Visitors" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 579,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 578,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Tabs, { defaultActiveKey: "All", size: "large", items: tabItems }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 582,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 572,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Modal, { isVisible: openModal, onClose: () => setOpenModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: formData._id ? "Edit Visitor" : "Add Visitor" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
            lineNumber: 589,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Visitor Type ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 597,
                  columnNumber: 34
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 596,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: formData.visitorType,
                  onChange: (value) => {
                    handleChange("visitorType", value);
                    handleChange("chitGroup", "");
                    handleChange("customerId", "");
                    handleChange("groupNameDisplay", "");
                  },
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  options: [
                    { value: "Guest", label: "Guest" },
                    { value: "Customers", label: "Customers" },
                    { value: "Sales Leads", label: "Sales Leads" },
                    { value: "Others", label: "Others" }
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 599,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 595,
              columnNumber: 17
            }, this),
            formData.visitorType === "Customers" && /* @__PURE__ */ jsxDEV("div", { className: "animate-fade-in space-y-6", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Search Customer (Type Phone Number) ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 622,
                    columnNumber: 61
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 621,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    showSearch: true,
                    placeholder: "Search by phone number or name...",
                    value: formData.customerId || void 0,
                    onChange: handleCustomerSelect,
                    filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    options: users.map((user) => ({
                      value: user._id,
                      label: `${user.full_name} - ${user.phone_number}`
                    }))
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 624,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 620,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 642,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      value: formData.name,
                      readOnly: true,
                      className: "bg-gray-100 border border-gray-300 h-14 text-gray-600 text-sm rounded-lg w-full p-2.5 cursor-not-allowed"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                      lineNumber: 643,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 641,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 650,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      value: formData.phone,
                      readOnly: true,
                      className: "bg-gray-100 border border-gray-300 h-14 text-gray-600 text-sm rounded-lg w-full p-2.5 cursor-not-allowed"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                      lineNumber: 651,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 649,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 640,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Email" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 660,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: formData.email,
                    readOnly: true,
                    className: "bg-gray-100 border border-gray-300 h-14 text-gray-600 text-sm rounded-lg w-full p-2.5 cursor-not-allowed"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 661,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 659,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Chit Group" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 669,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: formData.groupNameDisplay || "Select a customer to see group",
                    readOnly: true,
                    className: "bg-gray-100 border border-gray-300 h-14 text-gray-600 text-sm rounded-lg w-full p-2.5 cursor-not-allowed"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 670,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 668,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 619,
              columnNumber: 17
            }, this),
            formData.visitorType !== "Customers" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", htmlFor: "name", children: [
                  "Visitor Name ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 684,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 683,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "name",
                    value: formData.name,
                    onChange: (e) => handleChange("name", e.target.value),
                    id: "name",
                    placeholder: "Enter the Full Name",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5 ${errors.name ? "border-red-500" : ""}`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 686,
                    columnNumber: 23
                  },
                  this
                ),
                errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 695,
                  columnNumber: 39
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 682,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", htmlFor: "email", children: "Email" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 700,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "email",
                      name: "email",
                      value: formData.email,
                      onChange: (e) => handleChange("email", e.target.value),
                      id: "email",
                      placeholder: "Enter Email",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5 ${errors.email ? "border-red-500" : ""}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                      lineNumber: 701,
                      columnNumber: 25
                    },
                    this
                  ),
                  errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 710,
                    columnNumber: 42
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 699,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", htmlFor: "phone", children: [
                    "Phone Number ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                      lineNumber: 714,
                      columnNumber: 40
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 713,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "phone",
                      value: formData.phone,
                      maxLength: 10,
                      onChange: (e) => {
                        const value = e.target.value.replace(/\D/g, "");
                        if (value.length <= 10) {
                          handleChange("phone", value);
                        }
                      },
                      id: "phone",
                      placeholder: "Enter 10 digit Phone Number",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5 ${errors.phone ? "border-red-500" : ""}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                      lineNumber: 716,
                      columnNumber: 25
                    },
                    this
                  ),
                  errors.phone && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                    lineNumber: 731,
                    columnNumber: 42
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 712,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 698,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 681,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Purpose of Visit ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 740,
                  columnNumber: 38
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 739,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: formData.purpose,
                  onChange: (value) => handleChange("purpose", value),
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  options: [
                    { value: "Document Sign", label: "Document Sign" },
                    { value: "Chit Information", label: "Chit Information" },
                    { value: "Chit Cancellation", label: "Chit Cancellation" },
                    { value: "Loan Information", label: "Loan Information" },
                    { value: "Pigmy Information", label: "Pigmy Information" },
                    { value: "Auction Bidding", label: "Auction Bidding" },
                    { value: "Interview", label: "Interview" },
                    { value: "Payments", label: "Payment" },
                    { value: "Others", label: "Others" }
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 742,
                  columnNumber: 19
                },
                this
              ),
              errors.purpose && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.purpose }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 758,
                columnNumber: 38
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 738,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", htmlFor: "description", children: "Description" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 763,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input.TextArea,
                {
                  name: "description",
                  placeholder: "Enter Description",
                  value: formData.description,
                  onChange: (e) => handleChange("description", e.target.value),
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                  rows: 3
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 766,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 762,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", htmlFor: "dateTime", children: [
                "Date & Time ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 779,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 778,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "datetime-local",
                  name: "dateTime",
                  value: formData.dateTime,
                  onChange: (e) => handleChange("dateTime", e.target.value),
                  id: "dateTime",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5 ${errors.dateTime ? "border-red-500" : ""}`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 781,
                  columnNumber: 19
                },
                this
              ),
              errors.dateTime && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.dateTime }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 789,
                columnNumber: 39
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 777,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Whom to Meet ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 795,
                  columnNumber: 34
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 794,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  placeholder: "Select an Agent or Employee",
                  optionFilterProp: "children",
                  onChange: (value) => handleChange("meetPerson", value),
                  filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                  value: formData.meetPerson,
                  className: `bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full ${errors.meetPerson ? "border-red-500" : ""}`,
                  options: [
                    ...agents.map((agent) => ({
                      value: agent._id,
                      label: `${agent.name} (Agent) - ${agent.designation_id?.title || "Agent"}`
                    })),
                    ...employees.map((emp) => ({
                      value: emp._id,
                      label: `${emp.name} (Employee) - ${emp.designation_id?.title || "Staff"}`
                    }))
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                  lineNumber: 797,
                  columnNumber: 19
                },
                this
              ),
              errors.meetPerson && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.meetPerson }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 818,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 793,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                disabled: submitLoading,
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n                    focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center disabled:opacity-50 disabled:cursor-not-allowed",
                children: submitLoading ? "Submitting..." : formData._id ? "Update Details" : "Submit Details"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
                lineNumber: 823,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
              lineNumber: 822,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
            lineNumber: 592,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 588,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
          lineNumber: 587,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
        lineNumber: 558,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
      lineNumber: 556,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx",
    lineNumber: 554,
    columnNumber: 5
  }, this);
}
_s(VisitorList, "K7N2J1Mynaccmg3VKObD8wyZ5ZU=");
_c = VisitorList;
var _c;
$RefreshReg$(_c, "VisitorList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/VisitorList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdVpVLFNBaVJRLFVBalJSOzJCQXZaVjtBQUFtQkEsb0JBQWlCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0MsUUFBUUMsTUFBTUMsT0FBT0MsT0FBT0MsY0FBYztBQUNuRCxTQUFTQyxNQUFNQyxjQUFjO0FBQzdCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFdBQVc7QUFFbEIsTUFBTUMsWUFBWSxFQUFFQyxRQUFRLE9BQU87QUFFbkMsd0JBQXdCQyxjQUFjO0FBQUFDLEtBQUE7QUFDcEMsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSUYsU0FBUyxJQUFJO0FBRXJELFFBQU0sQ0FBQ0csVUFBVUMsV0FBVyxJQUFJSixTQUFTO0FBQUEsSUFDdkNLLGFBQWE7QUFBQSxJQUNiQyxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsSUFDWkMsV0FBVztBQUFBLElBQ1hDLFlBQVk7QUFBQSxJQUNaQyxrQkFBa0I7QUFBQSxJQUNsQkMsY0FBYztBQUFBLEVBQ2hCLENBQUM7QUFFRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWxCLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ21CLFVBQVVDLFdBQVcsSUFBSXBCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNxQixTQUFTQyxVQUFVLElBQUl0QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDdUIsUUFBUUMsU0FBUyxJQUFJeEIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMyQixPQUFPQyxRQUFRLElBQUk1QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDNkIscUJBQXFCQyxzQkFBc0IsSUFBSTlCLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUMrQixRQUFRQyxTQUFTLElBQUloQyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDaUMsZUFBZUMsZ0JBQWdCLElBQUlsQyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDbUMsZUFBZUMsZ0JBQWdCLElBQUlwQyxTQUFTLEtBQUs7QUFFeEQsUUFBTXFDLHFCQUFxQkEsTUFBTTtBQUMvQixVQUFNQyxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFVBQU1DLE9BQU9GLElBQUlHLFlBQVk7QUFDN0IsVUFBTUMsUUFBUUMsT0FBT0wsSUFBSU0sU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDeEQsVUFBTUMsTUFBTUgsT0FBT0wsSUFBSVMsUUFBUSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ2pELFVBQU1HLFFBQVFMLE9BQU9MLElBQUlXLFNBQVMsQ0FBQyxFQUFFSixTQUFTLEdBQUcsR0FBRztBQUNwRCxVQUFNSyxVQUFVUCxPQUFPTCxJQUFJYSxXQUFXLENBQUMsRUFBRU4sU0FBUyxHQUFHLEdBQUc7QUFDeEQsV0FBTyxHQUFHTCxJQUFJLElBQUlFLEtBQUssSUFBSUksR0FBRyxJQUFJRSxLQUFLLElBQUlFLE9BQU87QUFBQSxFQUNwRDtBQUVBLFFBQU1FLGtCQUFrQkEsTUFBTTtBQUM1QmhELGdCQUFZO0FBQUEsTUFDVkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTBCLG1CQUFtQjtBQUFBLE1BQzdCekIsWUFBWTtBQUFBLE1BQ1pDLFdBQVc7QUFBQSxNQUNYQyxZQUFZO0FBQUEsTUFDWkMsa0JBQWtCO0FBQUEsTUFDbEJDLGNBQWM7QUFBQSxJQUNoQixDQUFDO0FBQ0RFLGNBQVUsQ0FBQyxDQUFDO0FBQ1puQixpQkFBYSxJQUFJO0FBQUEsRUFDbkI7QUFFQSxRQUFNc0QsZ0JBQWdCLFlBQVk7QUFDaEMsUUFBSTtBQUNGL0IsaUJBQVcsSUFBSTtBQUNmLFlBQU1nQyxNQUFNLE1BQU16RSxJQUFJMEUsSUFBSSxXQUFXO0FBQ3JDLFVBQUlDLE9BQU87QUFDWCxVQUFJQyxNQUFNQyxRQUFRSixJQUFJRSxJQUFJLEdBQUc7QUFDM0JBLGVBQU9GLElBQUlFO0FBQUFBLE1BQ2IsV0FBV0YsSUFBSUUsS0FBS0EsUUFBUUMsTUFBTUMsUUFBUUosSUFBSUUsS0FBS0EsSUFBSSxHQUFHO0FBQ3hEQSxlQUFPRixJQUFJRSxLQUFLQTtBQUFBQSxNQUNsQixXQUFXRixJQUFJRSxLQUFLckMsWUFBWXNDLE1BQU1DLFFBQVFKLElBQUlFLEtBQUtyQyxRQUFRLEdBQUc7QUFDaEVxQyxlQUFPRixJQUFJRSxLQUFLckM7QUFBQUEsTUFDbEIsT0FBTztBQUNMcUMsZUFBT0csT0FBT0MsT0FBT04sSUFBSUUsSUFBSSxFQUFFSyxLQUFLLENBQUFDLE1BQUtMLE1BQU1DLFFBQVFJLENBQUMsQ0FBQyxLQUFLO0FBQUEsTUFDaEU7QUFDQTFDLGtCQUFZb0MsSUFBSTtBQUNoQmxDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQixTQUFTeUMsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRCQUE0QkEsS0FBSztBQUMvQ3pDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkMsY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU1yRixJQUFJMEUsSUFBSSxZQUFZO0FBQzNDLFVBQUlZLFlBQVk7QUFDaEIsVUFBSVYsTUFBTUMsUUFBUVEsU0FBU1YsSUFBSSxHQUFHO0FBQ2hDVyxvQkFBWUQsU0FBU1Y7QUFBQUEsTUFDdkIsV0FBV1UsU0FBU1YsS0FBS1ksU0FBU1gsTUFBTUMsUUFBUVEsU0FBU1YsS0FBS1ksS0FBSyxHQUFHO0FBQ3BFRCxvQkFBWUQsU0FBU1YsS0FBS1k7QUFBQUEsTUFDNUIsV0FBV0YsU0FBU1YsS0FBS0EsUUFBUUMsTUFBTUMsUUFBUVEsU0FBU1YsS0FBS0EsSUFBSSxHQUFHO0FBQ2xFVyxvQkFBWUQsU0FBU1YsS0FBS0E7QUFBQUEsTUFDNUIsV0FBV1UsU0FBU1YsS0FBS2pDLFVBQVVrQyxNQUFNQyxRQUFRUSxTQUFTVixLQUFLakMsTUFBTSxHQUFHO0FBQ3RFNEMsb0JBQVlELFNBQVNWLEtBQUtqQztBQUFBQSxNQUM1QjtBQUNBQyxnQkFBVTJDLFNBQVM7QUFBQSxJQUNyQixTQUFTSixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBRUEsUUFBTU0saUJBQWlCLFlBQVk7QUFDakMsUUFBSTtBQUNGLFlBQU1ILFdBQVcsTUFBTXJGLElBQUkwRSxJQUFJLHFDQUFxQztBQUNwRSxZQUFNZSxlQUFlSixTQUFTVixNQUFNZSxZQUFZO0FBQ2hEN0MsbUJBQWE0QyxZQUFZO0FBQUEsSUFDM0IsU0FBU1AsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUVBLFFBQU1TLGFBQWEsWUFBWTtBQUM3QixRQUFJO0FBQ0YsWUFBTU4sV0FBVyxNQUFNckYsSUFBSTBFLElBQUksZ0JBQWdCO0FBQy9DM0IsZUFBU3NDLFNBQVNWLFFBQVEsRUFBRTtBQUFBLElBQzlCLFNBQVNPLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNVSxjQUFjLFlBQVk7QUFDOUIsUUFBSTtBQUNGdkMsdUJBQWlCLElBQUk7QUFDckIsWUFBTWdDLFdBQVcsTUFBTXJGLElBQUkwRSxJQUFJLHdCQUF3QjtBQUN2RHZCLGdCQUFVa0MsU0FBU1YsUUFBUSxFQUFFO0FBQzdCdEIsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QixTQUFTNkIsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUM3QzdCLHVCQUFpQixLQUFLO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBRUEsUUFBTXdDLDJCQUEyQixPQUFPQyxXQUFXO0FBQ2pELFFBQUk7QUFDRixZQUFNVCxXQUFXLE1BQU1yRixJQUFJK0YsS0FBSyxtQ0FBbUNELE1BQU0sRUFBRTtBQUUzRSxVQUFJVCxTQUFTVixRQUFRVSxTQUFTVixLQUFLcUIsU0FBUyxHQUFHO0FBQzdDL0MsK0JBQXVCb0MsU0FBU1YsSUFBSTtBQUNwQyxjQUFNc0Isa0JBQWtCWixTQUFTVixLQUFLLENBQUM7QUFDdkMsY0FBTXVCLFlBQVlELGlCQUFpQkUsWUFBWUM7QUFFL0MsWUFBSUYsV0FBVztBQUNiM0Usc0JBQVksQ0FBQzhFLFVBQVU7QUFBQSxZQUNyQixHQUFHQTtBQUFBQSxZQUNIckUsV0FBV2tFLFVBQVVJO0FBQUFBLFlBQ3JCcEUsa0JBQWtCZ0UsVUFBVUs7QUFBQUEsWUFDNUJwRSxjQUFjOEQsaUJBQWlCRSxZQUFZSztBQUFBQSxVQUM3QyxFQUFFO0FBQUEsUUFDSjtBQUFBLE1BQ0YsT0FBTztBQUNMdkQsK0JBQXVCLEVBQUU7QUFDekIxQixvQkFBWSxDQUFDOEUsVUFBVTtBQUFBLFVBQ3JCLEdBQUdBO0FBQUFBLFVBQ0hyRSxXQUFXO0FBQUEsVUFDWEUsa0JBQWtCO0FBQUEsUUFDcEIsRUFBRTtBQUFBLE1BQ0o7QUFBQSxJQUNGLFNBQVNnRCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0NBQXdDQSxLQUFLO0FBQzNEakMsNkJBQXVCLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0QsdUJBQXVCQSxDQUFDWCxXQUFXO0FBQ3ZDLFVBQU1ZLGVBQWU1RCxNQUFNa0MsS0FBSyxDQUFDMkIsTUFBTUEsRUFBRUwsUUFBUVIsTUFBTTtBQUN2RCxRQUFJWSxjQUFjO0FBQ2hCbkYsa0JBQVksQ0FBQzhFLFVBQVU7QUFBQSxRQUNyQixHQUFHQTtBQUFBQSxRQUNIcEUsWUFBWTZEO0FBQUFBLFFBQ1pyRSxNQUFNaUYsYUFBYUU7QUFBQUEsUUFDbkJsRixPQUFPb0MsT0FBTzRDLGFBQWFHLFlBQVk7QUFBQSxRQUN2Q2xGLE9BQU8rRSxhQUFhL0UsU0FBUztBQUFBLE1BQy9CLEVBQUU7QUFDRmtFLCtCQUF5QkMsTUFBTTtBQUFBLElBQ2pDO0FBQUEsRUFDRjtBQUVBLFFBQU1nQixhQUFhQSxDQUFDQyxXQUFXO0FBQy9CMUYsb0JBQWdCLElBQUk7QUFFcEJFLGdCQUFZO0FBQUEsTUFDVkMsYUFBYXVGLE9BQU92RixlQUFlO0FBQUEsTUFDbkNDLE1BQU1zRixPQUFPdEYsUUFBUTtBQUFBLE1BQ3JCQyxPQUFPcUYsT0FBT3JGLFFBQVFvQyxPQUFPaUQsT0FBT3JGLEtBQUssSUFBSTtBQUFBLE1BQzdDQyxPQUFPb0YsT0FBT3BGLFNBQVM7QUFBQSxNQUN2QkMsYUFBYW1GLE9BQU9uRixlQUFlO0FBQUEsTUFDbkNDLFNBQVNrRixPQUFPbEYsV0FBVztBQUFBLE1BQzNCQyxVQUFVaUYsT0FBT2pGLFdBQ2JpRixPQUFPakYsU0FBU2tGLFVBQVUsR0FBRyxFQUFFLElBQy9CeEQsbUJBQW1CO0FBQUEsTUFDdkJ6QixZQUFZZ0YsT0FBT2hGLGNBQWM7QUFBQSxNQUNqQ0MsV0FBVytFLE9BQU8vRSxhQUFhO0FBQUEsTUFDL0JDLFlBQVk4RSxPQUFPOUUsY0FBYztBQUFBLE1BQ2pDQyxrQkFBa0I2RSxPQUFPRSxhQUFhRixPQUFPN0Usb0JBQW9CO0FBQUEsTUFDakVDLGNBQWM0RSxPQUFPNUUsZ0JBQWdCO0FBQUEsTUFDckNtRSxLQUFLUyxPQUFPVDtBQUFBQSxJQUNkLENBQUM7QUFFRHBGLGlCQUFhLElBQUk7QUFFakIsUUFBSTZGLE9BQU92RixnQkFBZ0IsZUFBZXVGLE9BQU85RSxZQUFZO0FBQzNENEQsK0JBQXlCa0IsT0FBTzlFLFVBQVU7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFRSxRQUFNaUYsZUFBZSxPQUFPQyxPQUFPO0FBQ2pDOUYsb0JBQWdCLElBQUk7QUFDcEIsUUFBSStGLE9BQU9DLFFBQVEsK0NBQStDLEdBQUc7QUFDbkUsVUFBSTtBQUNGLGNBQU1ySCxJQUFJc0gsT0FBTyxhQUFhSCxFQUFFLEVBQUU7QUFDbENJLGNBQU0sOEJBQThCO0FBQ3BDL0Msc0JBQWM7QUFBQSxNQUNoQixTQUFTVSxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDJCQUEyQkEsS0FBSztBQUM5Q3FDLGNBQU0sMEJBQTBCO0FBQUEsTUFDbEM7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBeEgsWUFBVSxNQUFNO0FBQ2R5RSxrQkFBYztBQUNkWSxnQkFBWTtBQUNaSSxtQkFBZTtBQUNmRyxlQUFXO0FBQ1hDLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTCxRQUFNNEIsZUFBZUEsQ0FBQy9GLE1BQU1nRyxVQUFVO0FBQ3BDbEcsZ0JBQVksQ0FBQ21HLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNqRyxJQUFJLEdBQUdnRztBQUFBQSxJQUNWLEVBQUU7QUFDRixRQUFJckYsT0FBT1gsSUFBSSxHQUFHO0FBQ2hCWSxnQkFBVSxDQUFDZ0UsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQzVFLElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxRQUFNa0csZUFBZUEsTUFBTTtBQUN6QixRQUFJQyxZQUFZLENBQUM7QUFFakIsUUFBSSxDQUFDdEcsU0FBU0csUUFBUUgsU0FBU0csS0FBS29HLEtBQUssTUFBTSxJQUFJO0FBQ2pERCxnQkFBVW5HLE9BQU87QUFBQSxJQUNuQjtBQUVBLFFBQUksQ0FBQ0gsU0FBU0ksU0FBU0osU0FBU0ksTUFBTW1HLEtBQUssTUFBTSxJQUFJO0FBQ25ERCxnQkFBVWxHLFFBQVE7QUFBQSxJQUNwQixXQUFXLENBQUMsZUFBZW9HLEtBQUt4RyxTQUFTSSxLQUFLLEdBQUc7QUFFL0NrRyxnQkFBVWxHLFFBQVE7QUFBQSxJQUNwQjtBQUVBLFFBQUksQ0FBQ0osU0FBU08sU0FBUztBQUNyQitGLGdCQUFVL0YsVUFBVTtBQUFBLElBQ3RCO0FBRUEsUUFBSSxDQUFDUCxTQUFTUSxVQUFVO0FBQ3RCOEYsZ0JBQVU5RixXQUFXO0FBQUEsSUFDdkI7QUFFQSxRQUFJLENBQUNSLFNBQVNTLFlBQVk7QUFDeEI2RixnQkFBVTdGLGFBQWE7QUFBQSxJQUN6QjtBQUVBTSxjQUFVdUYsU0FBUztBQUNuQixXQUFPOUMsT0FBT2lELEtBQUtILFNBQVMsRUFBRTVCLFdBQVc7QUFBQSxFQUMzQztBQUdBLFFBQU1nQyxlQUFlQSxDQUFDckQsU0FBUztBQUM3QixVQUFNc0QsVUFBVSxDQUFDO0FBQ2pCbkQsV0FBT29ELFFBQVF2RCxJQUFJLEVBQUV3RCxRQUFRLENBQUMsQ0FBQ0MsS0FBS1gsS0FBSyxNQUFNO0FBRTdDLFVBQUlBLFVBQVVZLFVBQWFaLFVBQVUsS0FBTTtBQUMzQyxVQUFJVyxRQUFRLE1BQU87QUFHbkIsVUFBSSxDQUFDLFNBQVMsZUFBZSxhQUFhLGNBQWMsb0JBQW9CLGNBQWMsRUFBRUUsU0FBU0YsR0FBRyxLQUFLWCxVQUFVLElBQUk7QUFDekg7QUFBQSxNQUNGO0FBRUFRLGNBQVFHLEdBQUcsSUFBSVg7QUFBQUEsSUFDakIsQ0FBQztBQUNELFdBQU9RO0FBQUFBLEVBQ1Q7QUFFQSxRQUFNTSxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFFakIsUUFBSSxDQUFDZCxhQUFhLEVBQUc7QUFFckJwRSxxQkFBaUIsSUFBSTtBQUVyQixRQUFJO0FBQ0YsWUFBTW1GLFdBQVcsQ0FBQyxDQUFDcEgsU0FBU2dGO0FBQzVCLFlBQU1xQyxTQUFTRCxXQUFXLGFBQWFwSCxTQUFTZ0YsR0FBRyxLQUFLO0FBQ3hELFlBQU1zQyxZQUFZRixXQUFXMUksSUFBSTZJLE1BQU03SSxJQUFJK0Y7QUFHM0MsWUFBTStDLFVBQVVkLGFBQWExRyxRQUFRO0FBRXJDLFlBQU0rRCxXQUFXLE1BQU11RCxVQUFVRCxRQUFRRyxPQUFPO0FBRWhEdkIsWUFBTW1CLFdBQVcsaUNBQWlDLDRCQUE0QjtBQUU5RW5ILGtCQUFZO0FBQUEsUUFDVkMsYUFBYTtBQUFBLFFBQ2JDLE1BQU07QUFBQSxRQUNOQyxPQUFPO0FBQUEsUUFDUEMsT0FBTztBQUFBLFFBQ1BDLGFBQWE7QUFBQSxRQUNiQyxTQUFTO0FBQUEsUUFDVEMsVUFBVTtBQUFBLFFBQ1ZDLFlBQVk7QUFBQSxRQUNaQyxXQUFXO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLGtCQUFrQjtBQUFBLFFBQ2xCQyxjQUFjO0FBQUEsTUFDaEIsQ0FBQztBQUVEakIsbUJBQWEsS0FBSztBQUNsQnNELG9CQUFjO0FBQUEsSUFDaEIsU0FBU1UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGtCQUFrQkEsTUFBTUcsVUFBVVYsSUFBSTtBQUdwRCxVQUFJb0UsZUFBZTtBQUVuQixVQUFJN0QsTUFBTUcsVUFBVVYsTUFBTXFFLFNBQVM7QUFDakNELHVCQUFlN0QsTUFBTUcsU0FBU1YsS0FBS3FFO0FBQUFBLE1BQ3JDLFdBQVc5RCxNQUFNRyxVQUFVVixNQUFNdkMsUUFBUTtBQUV2QyxjQUFNNkcsaUJBQWlCL0QsTUFBTUcsU0FBU1YsS0FBS3ZDO0FBQzNDMkcsdUJBQWVqRSxPQUFPQyxPQUFPa0UsY0FBYyxFQUN4Q0MsSUFBSSxDQUFBQyxRQUFPQSxJQUFJSCxPQUFPLEVBQ3RCSSxLQUFLLElBQUk7QUFBQSxNQUNkLFdBQVdsRSxNQUFNOEQsU0FBUztBQUN4QkQsdUJBQWU3RCxNQUFNOEQ7QUFBQUEsTUFDdkI7QUFFQXpCLFlBQU0sV0FBV3dCLFlBQVksRUFBRTtBQUFBLElBQ2pDLFVBQUM7QUFDQ3hGLHVCQUFpQixLQUFLO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBRUEsUUFBTThGLG9CQUFvQkEsQ0FBQ0MsYUFBYTtBQUN0QyxRQUFJLENBQUNBLFNBQVUsUUFBTztBQUN0QixVQUFNL0QsUUFBUTdDLE9BQU9zQyxLQUFLLENBQUN1RSxNQUFNQSxFQUFFakQsUUFBUWdELFFBQVE7QUFDbkQsUUFBSS9ELE1BQU8sUUFBT0EsTUFBTTlEO0FBQ3hCLFVBQU1pRSxXQUFXOUMsVUFBVW9DLEtBQUssQ0FBQ3dELE1BQU1BLEVBQUVsQyxRQUFRZ0QsUUFBUTtBQUN6RCxRQUFJNUQsU0FBVSxRQUFPQSxTQUFTakU7QUFDOUIsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNK0gsZUFBZUEsQ0FBQ0MsWUFBWTtBQUNoQyxRQUFJLENBQUNBLFFBQVMsUUFBTztBQUNyQixVQUFNckQsUUFBUWxELE9BQU84QixLQUFLLENBQUMwRSxNQUFNQSxFQUFFcEQsUUFBUW1ELE9BQU87QUFDbEQsV0FBT3JELFFBQVFBLE1BQU1HLGFBQWE7QUFBQSxFQUNwQztBQUVBLFFBQU1vRCxpQkFBaUJBLENBQUNDLGVBQWU7QUFDckMsUUFBSSxDQUFDQSxXQUFZLFFBQU87QUFDeEIsVUFBTUMsT0FBTyxJQUFJbkcsS0FBS2tHLFVBQVU7QUFDaEMsUUFBSUUsTUFBTUQsS0FBS0UsUUFBUSxDQUFDLEVBQUcsUUFBTztBQUVsQyxVQUFNOUYsTUFBTUgsT0FBTytGLEtBQUszRixRQUFRLENBQUMsRUFBRUYsU0FBUyxHQUFHLEdBQUc7QUFDbEQsVUFBTUgsUUFBUUMsT0FBTytGLEtBQUs5RixTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUN6RCxVQUFNTCxPQUFPa0csS0FBS2pHLFlBQVk7QUFFOUIsUUFBSU8sUUFBUTBGLEtBQUt6RixTQUFTO0FBQzFCLFVBQU1DLFVBQVVQLE9BQU8rRixLQUFLdkYsV0FBVyxDQUFDLEVBQUVOLFNBQVMsR0FBRyxHQUFHO0FBQ3pELFVBQU1nRyxPQUFPN0YsU0FBUyxLQUFLLE9BQU87QUFDbENBLFlBQVFBLFFBQVE7QUFDaEJBLFlBQVFBLFFBQVFBLFFBQVE7QUFDeEIsVUFBTThGLFdBQVduRyxPQUFPSyxLQUFLLEVBQUVILFNBQVMsR0FBRyxHQUFHO0FBRTlDLFdBQU8sR0FBR0MsR0FBRyxJQUFJSixLQUFLLElBQUlGLElBQUksSUFBSXNHLFFBQVEsSUFBSTVGLE9BQU8sSUFBSTJGLElBQUk7QUFBQSxFQUMvRDtBQUVBLFFBQU1FLGdCQUFnQjVILFNBQVM0RyxJQUFJLENBQUNpQixNQUFNQyxVQUFVO0FBQ2xELFVBQU1DLFFBQVFGLEtBQUszSSxlQUFlLFNBQVNxRyxLQUFLO0FBQ2hELFdBQU87QUFBQSxNQUNMLEdBQUdzQztBQUFBQSxNQUNIRyxNQUFNRixRQUFRO0FBQUEsTUFDZEcsY0FBY0osTUFBTUk7QUFBQUEsTUFDcEJDLFdBQVdMLEtBQUtLLGFBQWE7QUFBQSxNQUM3QmhKLGFBQWE2SSxLQUFLSSxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUFJTCxLQUFLTSxNQUFNLENBQUM7QUFBQSxNQUN4REMsV0FBV3ZCLGtCQUFrQmMsS0FBS3BJLFVBQVU7QUFBQSxNQUM1Q2tGLFdBQVd1QyxhQUFhVyxLQUFLbkksU0FBUztBQUFBLE1BQ3RDNkksZUFBZWxCLGVBQWVRLEtBQUtySSxRQUFRO0FBQUEsTUFDM0NELFNBQVNzSSxLQUFLdEksV0FBVztBQUFBLE1BQ3pCRCxhQUFhdUksS0FBS3ZJLGVBQWU7QUFBQSxNQUNqQ0QsT0FBT3dJLEtBQUt4SSxTQUFTO0FBQUEsTUFDckIyRSxLQUFLNkQsS0FBSzdEO0FBQUFBLE1BQ1Z3RSxRQUNFLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLENBQUN0QyxNQUFNO0FBQ2RBLGdCQUFFdUMsZ0JBQWdCO0FBQ2xCMUosOEJBQWdCRCxpQkFBaUIrSSxLQUFLN0QsTUFBTSxPQUFPNkQsS0FBSzdELEdBQUc7QUFBQSxZQUM3RDtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQW9DO0FBQUE7QUFBQSxVQUxoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBQ0NsRixpQkFBaUIrSSxLQUFLN0QsT0FDckIsdUJBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQ2tDLE1BQU07QUFDZEEsa0JBQUV1QyxnQkFBZ0I7QUFDbEJqRSwyQkFBV3FELElBQUk7QUFDZjlJLGdDQUFnQixJQUFJO0FBQUEsY0FDdEI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUNmLHVCQUFDLFVBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBVTtBQUFBO0FBQUE7QUFBQSxZQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxDQUFDbUgsTUFBTTtBQUNkQSxrQkFBRXVDLGdCQUFnQjtBQUNsQjdELDZCQUFhaUQsS0FBSzdELEdBQUc7QUFDckJqRixnQ0FBZ0IsSUFBSTtBQUFBLGNBQ3RCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQ2pCLHVCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBO0FBQUE7QUFBQSxZQVRkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsYUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQTtBQUFBLFdBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxJQUVKO0FBQUEsRUFDRixDQUFDO0FBRUQsUUFBTTJKLGtCQUFrQjtBQUFBLElBQ3RCLEVBQUU1QyxLQUFLLFFBQVE2QyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFN0MsS0FBSyxnQkFBZ0I2QyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFN0MsS0FBSyxRQUFRNkMsUUFBUSxlQUFlO0FBQUEsSUFDdEMsRUFBRTdDLEtBQUssZUFBZTZDLFFBQVEsT0FBTztBQUFBLElBQ3JDLEVBQUU3QyxLQUFLLFNBQVM2QyxRQUFRLFdBQVc7QUFBQSxJQUNuQyxFQUFFN0MsS0FBSyxTQUFTNkMsUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRTdDLEtBQUssV0FBVzZDLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUU3QyxLQUFLLGVBQWU2QyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFN0MsS0FBSyxpQkFBaUI2QyxRQUFRLGNBQWM7QUFBQSxJQUM5QyxFQUFFN0MsS0FBSyxhQUFhNkMsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRTdDLEtBQUssVUFBVTZDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUMsa0JBQWtCO0FBQUEsSUFDdEIsRUFBRTlDLEtBQUssUUFBUTZDLFFBQVEsUUFBUTtBQUFBLElBQy9CLEVBQUU3QyxLQUFLLGdCQUFnQjZDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUU3QyxLQUFLLFFBQVE2QyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxFQUFFN0MsS0FBSyxlQUFlNkMsUUFBUSxPQUFPO0FBQUEsSUFDckMsRUFBRTdDLEtBQUssU0FBUzZDLFFBQVEsV0FBVztBQUFBLElBQ25DLEVBQUU3QyxLQUFLLFNBQVM2QyxRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFN0MsS0FBSyxhQUFhNkMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRTdDLEtBQUssV0FBVzZDLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUU3QyxLQUFLLGVBQWU2QyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFN0MsS0FBSyxpQkFBaUI2QyxRQUFRLGNBQWM7QUFBQSxJQUM5QyxFQUFFN0MsS0FBSyxhQUFhNkMsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRTdDLEtBQUssVUFBVTZDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUUsU0FBUztBQUFBLElBQ2JDLEtBQUtsQixjQUFjbEU7QUFBQUEsSUFDbkJxRixPQUFPbkIsY0FBY29CLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRS9KLGdCQUFnQixPQUFPLEVBQUV3RTtBQUFBQSxJQUM1RHdGLFdBQVd0QixjQUFjb0IsT0FBTyxDQUFBQyxNQUFLQSxFQUFFL0osZ0JBQWdCLFdBQVcsRUFBRXdFO0FBQUFBLElBQ3BFLGVBQWVrRSxjQUFjb0IsT0FBTyxDQUFBQyxNQUFLQSxFQUFFL0osZ0JBQWdCLGFBQWEsRUFBRXdFO0FBQUFBLElBQzFFeUYsUUFBUXZCLGNBQWNvQixPQUFPLENBQUFDLE1BQUtBLEVBQUUvSixnQkFBZ0IsUUFBUSxFQUFFd0U7QUFBQUEsRUFDaEU7QUFFQSxRQUFNMEYsV0FBVztBQUFBLElBQ2Y7QUFBQSxNQUNFdEQsS0FBSztBQUFBLE1BQ0x1RCxPQUFPLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFFBQUksdUJBQUMsU0FBTSxPQUFPUixPQUFPQyxLQUFLLE9BQU8sRUFBRVEsaUJBQWlCLFVBQVUsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFdBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkU7QUFBQSxNQUNwRkMsVUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTTNCO0FBQUFBLFVBQ04sU0FBU2dCO0FBQUFBLFVBQ1QsaUJBQWdCO0FBQUEsVUFDaEIsa0JBQWlCO0FBQUEsVUFDakIsZUFBZSxNQUFNO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFMekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSzJCO0FBQUEsSUFHL0I7QUFBQSxJQUNBO0FBQUEsTUFDRTlDLEtBQUs7QUFBQSxNQUNMdUQsT0FBTyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxRQUFNLHVCQUFDLFNBQU0sT0FBT1IsT0FBT0UsT0FBTyxPQUFPLEVBQUVPLGlCQUFpQixVQUFVLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxXQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlGO0FBQUEsTUFDeEZDLFVBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU0zQixjQUFjb0IsT0FBTyxDQUFBQyxNQUFLQSxFQUFFL0osZ0JBQWdCLE9BQU87QUFBQSxVQUN6RCxTQUFTd0o7QUFBQUEsVUFDVCxpQkFBZ0I7QUFBQSxVQUNoQixrQkFBaUI7QUFBQSxVQUNqQixlQUFlLE1BQU07QUFBQSxVQUFFO0FBQUE7QUFBQSxRQUx6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLMkI7QUFBQSxJQUcvQjtBQUFBLElBQ0E7QUFBQSxNQUNFNUMsS0FBSztBQUFBLE1BQ0x1RCxPQUFPLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFFBQVUsdUJBQUMsU0FBTSxPQUFPUixPQUFPSyxXQUFXLE9BQU8sRUFBRUksaUJBQWlCLFVBQVUsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRTtBQUFBLFdBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUY7QUFBQSxNQUNoR0MsVUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTTNCLGNBQWNvQixPQUFPLENBQUFDLE1BQUtBLEVBQUUvSixnQkFBZ0IsV0FBVztBQUFBLFVBQzdELFNBQVMwSjtBQUFBQSxVQUNULGlCQUFnQjtBQUFBLFVBQ2hCLGtCQUFpQjtBQUFBLFVBQ2pCLGVBQWUsTUFBTTtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUsyQjtBQUFBLElBRy9CO0FBQUEsSUFDQTtBQUFBLE1BQ0U5QyxLQUFLO0FBQUEsTUFDTHVELE9BQU8sdUJBQUMsVUFBSztBQUFBO0FBQUEsUUFBWSx1QkFBQyxTQUFNLE9BQU9SLE9BQU8sYUFBYSxHQUFHLE9BQU8sRUFBRVMsaUJBQWlCLFVBQVUsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFdBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0c7QUFBQSxNQUN2R0MsVUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTTNCLGNBQWNvQixPQUFPLENBQUFDLE1BQUtBLEVBQUUvSixnQkFBZ0IsYUFBYTtBQUFBLFVBQy9ELFNBQVN3SjtBQUFBQSxVQUNULGlCQUFnQjtBQUFBLFVBQ2hCLGtCQUFpQjtBQUFBLFVBQ2pCLGVBQWUsTUFBTTtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUsyQjtBQUFBLElBRy9CO0FBQUEsSUFDQTtBQUFBLE1BQ0U1QyxLQUFLO0FBQUEsTUFDTHVELE9BQU8sdUJBQUMsVUFBSztBQUFBO0FBQUEsUUFBTyx1QkFBQyxTQUFNLE9BQU9SLE9BQU9NLFFBQVEsT0FBTyxFQUFFRyxpQkFBaUIsVUFBVSxLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsV0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQzFGQyxVQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNM0IsY0FBY29CLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRS9KLGdCQUFnQixRQUFRO0FBQUEsVUFDMUQsU0FBU3dKO0FBQUFBLFVBQ1QsaUJBQWdCO0FBQUEsVUFDaEIsa0JBQWlCO0FBQUEsVUFDakIsZUFBZSxNQUFNO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFMekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSzJCO0FBQUEsSUFHL0I7QUFBQSxFQUFDO0FBR0gsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1IsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxzQkFBcUIsa0NBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQsdUJBQUMsT0FBRSxXQUFVLGlCQUFnQixtREFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxlQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3pHO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQStGO0FBQUE7QUFBQSxZQUYzRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ1ovQixvQkFDQyx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUNFRixTQUFTMEQsV0FBVyxJQUN0Qix1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsa0JBQWUsV0FBVyxPQUFPLFNBQVMsTUFBTSxNQUFLLGNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsUUFBSyxrQkFBaUIsT0FBTSxNQUFLLFNBQVEsT0FBTzBGLFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQsS0FWOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFHQSx1QkFBQyxTQUFNLFdBQVd6SyxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FDWEksbUJBQVNnRixNQUFNLGlCQUFpQixpQkFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWlDLGNBQWMsWUFBVSxNQUc1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDakQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPakgsU0FBU0U7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ2lHLFVBQVU7QUFDbkJELGlDQUFhLGVBQWVDLEtBQUs7QUFDakNELGlDQUFhLGFBQWEsRUFBRTtBQUM1QkEsaUNBQWEsY0FBYyxFQUFFO0FBQzdCQSxpQ0FBYSxvQkFBb0IsRUFBRTtBQUFBLGtCQUNyQztBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFDVixTQUFTO0FBQUEsb0JBQ1AsRUFBRUMsT0FBTyxTQUFTa0UsT0FBTyxRQUFRO0FBQUEsb0JBQ2pDLEVBQUVsRSxPQUFPLGFBQWFrRSxPQUFPLFlBQVk7QUFBQSxvQkFDekMsRUFBRWxFLE9BQU8sZUFBZWtFLE9BQU8sY0FBYztBQUFBLG9CQUM3QyxFQUFFbEUsT0FBTyxVQUFVa0UsT0FBTyxTQUFTO0FBQUEsa0JBQUM7QUFBQTtBQUFBLGdCQWJ4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjSTtBQUFBLGlCQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBR0NySyxTQUFTRSxnQkFBZ0IsZUFDeEIsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUMxQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQztBQUFBLG9CQUNBLGFBQVk7QUFBQSxvQkFDWixPQUFPRixTQUFTVyxjQUFjb0c7QUFBQUEsb0JBQzlCLFVBQVU1QjtBQUFBQSxvQkFDVixjQUFjLENBQUNxRixPQUFPQyxZQUNuQkEsUUFBUUosU0FBUyxJQUFJSyxZQUFZLEVBQUUxRCxTQUFTd0QsTUFBTUUsWUFBWSxDQUFDO0FBQUEsb0JBRWxFLFdBQVU7QUFBQSxvQkFDVixTQUFTbEosTUFBTW9HLElBQUksQ0FBQytDLFVBQVU7QUFBQSxzQkFDNUJ4RSxPQUFPd0UsS0FBSzNGO0FBQUFBLHNCQUNacUYsT0FBTyxHQUFHTSxLQUFLckYsU0FBUyxNQUFNcUYsS0FBS3BGLFlBQVk7QUFBQSxvQkFDakQsRUFBRTtBQUFBO0FBQUEsa0JBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlNO0FBQUEsbUJBaEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsNkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZFO0FBQUEsa0JBQzdFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU92RixTQUFTRztBQUFBQSxzQkFDaEI7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBR3NIO0FBQUEscUJBTHhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRFO0FBQUEsa0JBQzVFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU9ILFNBQVNJO0FBQUFBLHNCQUNoQjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHc0g7QUFBQSxxQkFMeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLG1CQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBRUEsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsZ0JBQ3JFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU9KLFNBQVNLO0FBQUFBLG9CQUNoQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHc0g7QUFBQSxtQkFMeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBRUEsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBFO0FBQUEsZ0JBQzFFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU9MLFNBQVNZLG9CQUFvQjtBQUFBLG9CQUNwQztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHc0g7QUFBQSxtQkFMeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlEQTtBQUFBLFlBSURaLFNBQVNFLGdCQUFnQixlQUN4QixtQ0FDRTtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLFNBQVEsUUFBTztBQUFBO0FBQUEsa0JBQ2hFLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT0YsU0FBU0c7QUFBQUEsb0JBQ2hCLFVBQVUsQ0FBQytHLE1BQU1oQixhQUFhLFFBQVFnQixFQUFFMEQsT0FBT3pFLEtBQUs7QUFBQSxvQkFDcEQsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWixXQUFXLHFDQUFxQzVHLFVBQVVDLE1BQU0sNEZBQTRGc0IsT0FBT1gsT0FBTyxtQkFBbUIsRUFBRTtBQUFBO0FBQUEsa0JBUGpNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPb007QUFBQSxnQkFFbk1XLE9BQU9YLFFBQVEsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QlcsaUJBQU9YLFFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNEO0FBQUEsbUJBYnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyxTQUFRLFNBQVEscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFGO0FBQUEsa0JBQ3JGO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT0gsU0FBU0s7QUFBQUEsc0JBQ2hCLFVBQVUsQ0FBQzZHLE1BQU1oQixhQUFhLFNBQVNnQixFQUFFMEQsT0FBT3pFLEtBQUs7QUFBQSxzQkFDckQsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWixXQUFXLHFDQUFxQzVHLFVBQVVDLE1BQU0sNEZBQTRGc0IsT0FBT1QsUUFBUSxtQkFBbUIsRUFBRTtBQUFBO0FBQUEsb0JBUGxNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPcU07QUFBQSxrQkFFcE1TLE9BQU9ULFNBQVMsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QlMsaUJBQU9ULFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVEO0FBQUEscUJBWDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsU0FBUSxTQUFRO0FBQUE7QUFBQSxvQkFDakUsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPTCxTQUFTSTtBQUFBQSxzQkFDaEIsV0FBVztBQUFBLHNCQUNYLFVBQVUsQ0FBQzhHLE1BQU07QUFDZiw4QkFBTWYsUUFBUWUsRUFBRTBELE9BQU96RSxNQUFNMEUsUUFBUSxPQUFPLEVBQUU7QUFDOUMsNEJBQUkxRSxNQUFNekIsVUFBVSxJQUFJO0FBQ3RCd0IsdUNBQWEsU0FBU0MsS0FBSztBQUFBLHdCQUM3QjtBQUFBLHNCQUNGO0FBQUEsc0JBQ0EsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWixXQUFXLHFDQUFxQzVHLFVBQVVDLE1BQU0sNEZBQTRGc0IsT0FBT1YsUUFBUSxtQkFBbUIsRUFBRTtBQUFBO0FBQUEsb0JBYmxNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFhcU07QUFBQSxrQkFFcE1VLE9BQU9WLFNBQVMsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QlUsaUJBQU9WLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVEO0FBQUEscUJBbkIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW9CQTtBQUFBLG1CQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1DQTtBQUFBLGlCQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFEQTtBQUFBLFlBSUYsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUM3Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9KLFNBQVNPO0FBQUFBLGtCQUNoQixVQUFVLENBQUM0RixVQUFVRCxhQUFhLFdBQVdDLEtBQUs7QUFBQSxrQkFDbEQsV0FBVTtBQUFBLGtCQUNWLFNBQVM7QUFBQSxvQkFDUCxFQUFFQSxPQUFPLGlCQUFpQmtFLE9BQU8sZ0JBQWdCO0FBQUEsb0JBQ2pELEVBQUVsRSxPQUFPLG9CQUFvQmtFLE9BQU8sbUJBQW1CO0FBQUEsb0JBQ3ZELEVBQUVsRSxPQUFPLHFCQUFxQmtFLE9BQU8sb0JBQW9CO0FBQUEsb0JBQ3pELEVBQUVsRSxPQUFPLG9CQUFvQmtFLE9BQU8sbUJBQW1CO0FBQUEsb0JBQ3ZELEVBQUVsRSxPQUFPLHFCQUFxQmtFLE9BQU8sb0JBQW9CO0FBQUEsb0JBQ3pELEVBQUVsRSxPQUFPLG1CQUFtQmtFLE9BQU8sa0JBQWtCO0FBQUEsb0JBQ3JELEVBQUVsRSxPQUFPLGFBQWFrRSxPQUFPLFlBQVk7QUFBQSxvQkFDekMsRUFBRWxFLE9BQU8sWUFBWWtFLE9BQU8sVUFBVTtBQUFBLG9CQUN0QyxFQUFFbEUsT0FBTyxVQUFVa0UsT0FBTyxTQUFTO0FBQUEsa0JBQUM7QUFBQTtBQUFBLGdCQWJ4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjSTtBQUFBLGNBRUh2SixPQUFPUCxXQUFXLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJPLGlCQUFPUCxXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGlCQXBCOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLFNBQVEsZUFBYywyQkFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQyxNQUFNO0FBQUEsZ0JBQU47QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU9QLFNBQVNNO0FBQUFBLGtCQUNoQixVQUFVLENBQUM0RyxNQUFNaEIsYUFBYSxlQUFlZ0IsRUFBRTBELE9BQU96RSxLQUFLO0FBQUEsa0JBQzNELFdBQVU7QUFBQSxrQkFDVixNQUFNO0FBQUE7QUFBQSxnQkFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNVTtBQUFBLGlCQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLFNBQVEsWUFBVztBQUFBO0FBQUEsZ0JBQ3JFLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPbkcsU0FBU1E7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQzBHLE1BQU1oQixhQUFhLFlBQVlnQixFQUFFMEQsT0FBT3pFLEtBQUs7QUFBQSxrQkFDeEQsSUFBRztBQUFBLGtCQUNILFdBQVcscUNBQXFDNUcsVUFBVUMsTUFBTSw0RkFBNEZzQixPQUFPTixXQUFXLG1CQUFtQixFQUFFO0FBQUE7QUFBQSxnQkFOck07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXdNO0FBQUEsY0FFdk1NLE9BQU9OLFlBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qk0saUJBQU9OLFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsaUJBWmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDakQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQztBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWixrQkFBaUI7QUFBQSxrQkFDakIsVUFBVSxDQUFDMkYsVUFBVUQsYUFBYSxjQUFjQyxLQUFLO0FBQUEsa0JBQ3JELGNBQWMsQ0FBQ3FFLE9BQU9DLFlBQ25CQSxRQUFRSixTQUFTLElBQUlLLFlBQVksRUFBRTFELFNBQVN3RCxNQUFNRSxZQUFZLENBQUM7QUFBQSxrQkFFbEUsT0FBTzFLLFNBQVNTO0FBQUFBLGtCQUNoQixXQUFXLGtGQUFrRkssT0FBT0wsYUFBYSxtQkFBbUIsRUFBRTtBQUFBLGtCQUN0SSxTQUFTO0FBQUEsb0JBQ1AsR0FBR1csT0FBT3dHLElBQUksQ0FBQzNELFdBQVc7QUFBQSxzQkFDeEJrQyxPQUFPbEMsTUFBTWU7QUFBQUEsc0JBQ2JxRixPQUFPLEdBQUdwRyxNQUFNOUQsSUFBSSxjQUFjOEQsTUFBTTZHLGdCQUFnQkMsU0FBUyxPQUFPO0FBQUEsb0JBQzFFLEVBQUU7QUFBQSxvQkFDRixHQUFHekosVUFBVXNHLElBQUksQ0FBQ29ELFNBQVM7QUFBQSxzQkFDekI3RSxPQUFPNkUsSUFBSWhHO0FBQUFBLHNCQUNYcUYsT0FBTyxHQUFHVyxJQUFJN0ssSUFBSSxpQkFBaUI2SyxJQUFJRixnQkFBZ0JDLFNBQVMsT0FBTztBQUFBLG9CQUN6RSxFQUFFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLGdCQWxCUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkk7QUFBQSxjQUVIakssT0FBT0wsY0FBYyx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCSyxpQkFBT0wsY0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQ7QUFBQSxpQkF6QnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsVUFBVXVCO0FBQUFBLGdCQUNWLFdBQVU7QUFBQSxnQkFHVEEsMEJBQWdCLGtCQUFtQmhDLFNBQVNnRixNQUFNLG1CQUFtQjtBQUFBO0FBQUEsY0FOeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUEvT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnUEE7QUFBQSxhQXBQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcVBBLEtBdFBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1UEE7QUFBQSxXQXBSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc1JBO0FBQUEsU0F4UkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlSQTtBQUFBLE9BM1JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0UkE7QUFFSjtBQUFDdEYsR0EzekJ1QkQsYUFBVztBQUFBd0wsS0FBWHhMO0FBQVcsSUFBQXdMO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJBUEkiLCJTaWRlYmFyIiwiTmF2YmFyIiwiU2VsZWN0IiwiVGFicyIsIkJhZGdlIiwiSW5wdXQiLCJCdXR0b24iLCJFZGl0IiwiVHJhc2gyIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJNb2RhbCIsImZpZWxkU2l6ZSIsImhlaWdodCIsIlZpc2l0b3JMaXN0IiwiX3MiLCJvcGVuTW9kYWwiLCJzZXRPcGVuTW9kYWwiLCJ1c2VTdGF0ZSIsIm9wZW5BY3Rpb25JZCIsInNldE9wZW5BY3Rpb25JZCIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ2aXNpdG9yVHlwZSIsIm5hbWUiLCJwaG9uZSIsImVtYWlsIiwiZGVzY3JpcHRpb24iLCJwdXJwb3NlIiwiZGF0ZVRpbWUiLCJtZWV0UGVyc29uIiwiY2hpdEdyb3VwIiwiY3VzdG9tZXJJZCIsImdyb3VwTmFtZURpc3BsYXkiLCJ0aWNrZXROdW1iZXIiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJ2aXNpdG9ycyIsInNldFZpc2l0b3JzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJ1c2VycyIsInNldFVzZXJzIiwiY3VzdG9tZXJFbnJvbGxtZW50cyIsInNldEN1c3RvbWVyRW5yb2xsbWVudHMiLCJncm91cHMiLCJzZXRHcm91cHMiLCJsb2FkaW5nR3JvdXBzIiwic2V0TG9hZGluZ0dyb3VwcyIsInN1Ym1pdExvYWRpbmciLCJzZXRTdWJtaXRMb2FkaW5nIiwiZ2V0Q3VycmVudERhdGVUaW1lIiwibm93IiwiRGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsIm1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImRheSIsImdldERhdGUiLCJob3VycyIsImdldEhvdXJzIiwibWludXRlcyIsImdldE1pbnV0ZXMiLCJoYW5kbGVPcGVuTW9kYWwiLCJmZXRjaFZpc2l0b3JzIiwicmVzIiwiZ2V0IiwiZGF0YSIsIkFycmF5IiwiaXNBcnJheSIsIk9iamVjdCIsInZhbHVlcyIsImZpbmQiLCJ2IiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hBZ2VudHMiLCJyZXNwb25zZSIsImFnZW50TGlzdCIsImFnZW50IiwiZmV0Y2hFbXBsb3llZXMiLCJlbXBsb3llZURhdGEiLCJlbXBsb3llZSIsImZldGNoVXNlcnMiLCJmZXRjaEdyb3VwcyIsImZldGNoQ3VzdG9tZXJFbnJvbGxtZW50cyIsInVzZXJJZCIsInBvc3QiLCJsZW5ndGgiLCJmaXJzdEVucm9sbG1lbnQiLCJncm91cERhdGEiLCJlbnJvbGxtZW50IiwiZ3JvdXAiLCJwcmV2IiwiX2lkIiwiZ3JvdXBfbmFtZSIsInRpY2tldHMiLCJoYW5kbGVDdXN0b21lclNlbGVjdCIsInNlbGVjdGVkVXNlciIsInUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJoYW5kbGVFZGl0IiwicmVjb3JkIiwic3Vic3RyaW5nIiwiZ3JvdXBOYW1lIiwiaGFuZGxlRGVsZXRlIiwiaWQiLCJ3aW5kb3ciLCJjb25maXJtIiwiZGVsZXRlIiwiYWxlcnQiLCJoYW5kbGVDaGFuZ2UiLCJ2YWx1ZSIsInByZXZEYXRhIiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwidHJpbSIsInRlc3QiLCJrZXlzIiwiY2xlYW5QYXlsb2FkIiwiY2xlYW5lZCIsImVudHJpZXMiLCJmb3JFYWNoIiwia2V5IiwidW5kZWZpbmVkIiwiaW5jbHVkZXMiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJpc1VwZGF0ZSIsImFwaVVybCIsImFwaU1ldGhvZCIsInB1dCIsInBheWxvYWQiLCJlcnJvck1lc3NhZ2UiLCJtZXNzYWdlIiwibW9uZ29vc2VFcnJvcnMiLCJtYXAiLCJlcnIiLCJqb2luIiwiZ2V0TWVldFBlcnNvbk5hbWUiLCJwZXJzb25JZCIsImEiLCJnZXRHcm91cE5hbWUiLCJncm91cElkIiwiZyIsImZvcm1hdERhdGVUaW1lIiwiZGF0ZVN0cmluZyIsImRhdGUiLCJpc05hTiIsImdldFRpbWUiLCJhbXBtIiwiaG91cnNTdHIiLCJmb3JtYXR0ZWREYXRhIiwiaXRlbSIsImluZGV4IiwidHlwZSIsInNsTm8iLCJ2aXNpdG9yX2NvZGUiLCJ2aXNpdG9ySWQiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInNsaWNlIiwiYWdlbnROYW1lIiwiZm9ybWF0dGVkRGF0ZSIsImFjdGlvbiIsInN0b3BQcm9wYWdhdGlvbiIsInN0YW5kYXJkQ29sdW1ucyIsImhlYWRlciIsImN1c3RvbWVyQ29sdW1ucyIsImNvdW50cyIsIkFsbCIsIkd1ZXN0IiwiZmlsdGVyIiwiZCIsIkN1c3RvbWVycyIsIk90aGVycyIsInRhYkl0ZW1zIiwibGFiZWwiLCJiYWNrZ3JvdW5kQ29sb3IiLCJjaGlsZHJlbiIsImlucHV0Iiwib3B0aW9uIiwidG9Mb3dlckNhc2UiLCJ1c2VyIiwidGFyZ2V0IiwicmVwbGFjZSIsImRlc2lnbmF0aW9uX2lkIiwidGl0bGUiLCJlbXAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJWaXNpdG9yTGlzdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgVGFicywgQmFkZ2UsIElucHV0LCBCdXR0b24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBFZGl0LCBUcmFzaDIgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7IFxyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuXHJcbmNvbnN0IGZpZWxkU2l6ZSA9IHsgaGVpZ2h0OiBcImgtMTRcIiB9O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVmlzaXRvckxpc3QoKSB7XHJcbiAgY29uc3QgW29wZW5Nb2RhbCwgc2V0T3Blbk1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbb3BlbkFjdGlvbklkLCBzZXRPcGVuQWN0aW9uSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaXRvclR5cGU6IFwiR3Vlc3RcIixcclxuICAgIG5hbWU6IFwiXCIsXHJcbiAgICBwaG9uZTogXCJcIixcclxuICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICBwdXJwb3NlOiBcIlwiLFxyXG4gICAgZGF0ZVRpbWU6IFwiXCIsXHJcbiAgICBtZWV0UGVyc29uOiBcIlwiLFxyXG4gICAgY2hpdEdyb3VwOiBcIlwiLFxyXG4gICAgY3VzdG9tZXJJZDogXCJcIixcclxuICAgIGdyb3VwTmFtZURpc3BsYXk6IFwiXCIsXHJcbiAgICB0aWNrZXROdW1iZXI6IFwiXCJcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbdmlzaXRvcnMsIHNldFZpc2l0b3JzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXN0b21lckVucm9sbG1lbnRzLCBzZXRDdXN0b21lckVucm9sbG1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nR3JvdXBzLCBzZXRMb2FkaW5nR3JvdXBzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc3VibWl0TG9hZGluZywgc2V0U3VibWl0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGdldEN1cnJlbnREYXRlVGltZSA9ICgpID0+IHtcclxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCB5ZWFyID0gbm93LmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IFN0cmluZyhub3cuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBkYXkgPSBTdHJpbmcobm93LmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIGNvbnN0IGhvdXJzID0gU3RyaW5nKG5vdy5nZXRIb3VycygpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgbWludXRlcyA9IFN0cmluZyhub3cuZ2V0TWludXRlcygpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fVQke2hvdXJzfToke21pbnV0ZXN9YDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuTW9kYWwgPSAoKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIHZpc2l0b3JUeXBlOiBcIkd1ZXN0XCIsXHJcbiAgICAgIG5hbWU6IFwiXCIsXHJcbiAgICAgIHBob25lOiBcIlwiLFxyXG4gICAgICBlbWFpbDogXCJcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICAgIHB1cnBvc2U6IFwiXCIsXHJcbiAgICAgIGRhdGVUaW1lOiBnZXRDdXJyZW50RGF0ZVRpbWUoKSxcclxuICAgICAgbWVldFBlcnNvbjogXCJcIixcclxuICAgICAgY2hpdEdyb3VwOiBcIlwiLFxyXG4gICAgICBjdXN0b21lcklkOiBcIlwiLFxyXG4gICAgICBncm91cE5hbWVEaXNwbGF5OiBcIlwiLFxyXG4gICAgICB0aWNrZXROdW1iZXI6IFwiXCJcclxuICAgIH0pO1xyXG4gICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIHNldE9wZW5Nb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFZpc2l0b3JzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChcIi92aXNpdG9yc1wiKTtcclxuICAgICAgbGV0IGRhdGEgPSBbXTtcclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzLmRhdGEpKSB7XHJcbiAgICAgICAgZGF0YSA9IHJlcy5kYXRhO1xyXG4gICAgICB9IGVsc2UgaWYgKHJlcy5kYXRhLmRhdGEgJiYgQXJyYXkuaXNBcnJheShyZXMuZGF0YS5kYXRhKSkge1xyXG4gICAgICAgIGRhdGEgPSByZXMuZGF0YS5kYXRhO1xyXG4gICAgICB9IGVsc2UgaWYgKHJlcy5kYXRhLnZpc2l0b3JzICYmIEFycmF5LmlzQXJyYXkocmVzLmRhdGEudmlzaXRvcnMpKSB7XHJcbiAgICAgICAgZGF0YSA9IHJlcy5kYXRhLnZpc2l0b3JzO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGRhdGEgPSBPYmplY3QudmFsdWVzKHJlcy5kYXRhKS5maW5kKHYgPT4gQXJyYXkuaXNBcnJheSh2KSkgfHwgW107XHJcbiAgICAgIH1cclxuICAgICAgc2V0VmlzaXRvcnMoZGF0YSk7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHZpc2l0b3JzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgbGV0IGFnZW50TGlzdCA9IFtdO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhKSkge1xyXG4gICAgICAgIGFnZW50TGlzdCA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0gZWxzZSBpZiAocmVzcG9uc2UuZGF0YS5hZ2VudCAmJiBBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEuYWdlbnQpKSB7XHJcbiAgICAgICAgYWdlbnRMaXN0ID0gcmVzcG9uc2UuZGF0YS5hZ2VudDtcclxuICAgICAgfSBlbHNlIGlmIChyZXNwb25zZS5kYXRhLmRhdGEgJiYgQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhLmRhdGEpKSB7XHJcbiAgICAgICAgYWdlbnRMaXN0ID0gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlLmRhdGEuYWdlbnRzICYmIEFycmF5LmlzQXJyYXkocmVzcG9uc2UuZGF0YS5hZ2VudHMpKSB7XHJcbiAgICAgICAgYWdlbnRMaXN0ID0gcmVzcG9uc2UuZGF0YS5hZ2VudHM7XHJcbiAgICAgIH1cclxuICAgICAgc2V0QWdlbnRzKGFnZW50TGlzdCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWdlbnRzOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvYWdlbnQvZ2V0LWFkZGl0aW9uYWwtZW1wbG95ZWUtaW5mb1wiKTtcclxuICAgICAgY29uc3QgZW1wbG95ZWVEYXRhID0gcmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW107XHJcbiAgICAgIHNldEVtcGxveWVlcyhlbXBsb3llZURhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlczpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcnM6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmdHcm91cHModHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhIHx8IFtdKTtcclxuICAgICAgc2V0TG9hZGluZ0dyb3VwcyhmYWxzZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXBzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldExvYWRpbmdHcm91cHMoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJFbnJvbGxtZW50cyA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLnBvc3QoYC9lbnJvbGwvZ2V0LXVzZXItdGlja2V0cy1yZXBvcnQvJHt1c2VySWR9YCk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBzZXRDdXN0b21lckVucm9sbG1lbnRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIGNvbnN0IGZpcnN0RW5yb2xsbWVudCA9IHJlc3BvbnNlLmRhdGFbMF07XHJcbiAgICAgICAgY29uc3QgZ3JvdXBEYXRhID0gZmlyc3RFbnJvbGxtZW50Py5lbnJvbGxtZW50Py5ncm91cDtcclxuXHJcbiAgICAgICAgaWYgKGdyb3VwRGF0YSkge1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIGNoaXRHcm91cDogZ3JvdXBEYXRhLl9pZCxcclxuICAgICAgICAgICAgZ3JvdXBOYW1lRGlzcGxheTogZ3JvdXBEYXRhLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgIHRpY2tldE51bWJlcjogZmlyc3RFbnJvbGxtZW50Py5lbnJvbGxtZW50Py50aWNrZXRzXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEN1c3RvbWVyRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIGNoaXRHcm91cDogXCJcIixcclxuICAgICAgICAgIGdyb3VwTmFtZURpc3BsYXk6IFwiTm8gQWN0aXZlIEdyb3VwIEZvdW5kXCJcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lciBlbnJvbGxtZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRDdXN0b21lckVucm9sbG1lbnRzKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lclNlbGVjdCA9ICh1c2VySWQpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkVXNlciA9IHVzZXJzLmZpbmQoKHUpID0+IHUuX2lkID09PSB1c2VySWQpO1xyXG4gICAgaWYgKHNlbGVjdGVkVXNlcikge1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIGN1c3RvbWVySWQ6IHVzZXJJZCxcclxuICAgICAgICBuYW1lOiBzZWxlY3RlZFVzZXIuZnVsbF9uYW1lLFxyXG4gICAgICAgIHBob25lOiBTdHJpbmcoc2VsZWN0ZWRVc2VyLnBob25lX251bWJlciksIFxyXG4gICAgICAgIGVtYWlsOiBzZWxlY3RlZFVzZXIuZW1haWwgfHwgXCJcIlxyXG4gICAgICB9KSk7XHJcbiAgICAgIGZldGNoQ3VzdG9tZXJFbnJvbGxtZW50cyh1c2VySWQpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUVkaXQgPSAocmVjb3JkKSA9PiB7XHJcbiAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG5cclxuICBzZXRGb3JtRGF0YSh7XHJcbiAgICB2aXNpdG9yVHlwZTogcmVjb3JkLnZpc2l0b3JUeXBlIHx8IFwiR3Vlc3RcIixcclxuICAgIG5hbWU6IHJlY29yZC5uYW1lIHx8IFwiXCIsXHJcbiAgICBwaG9uZTogcmVjb3JkLnBob25lID8gU3RyaW5nKHJlY29yZC5waG9uZSkgOiBcIlwiLFxyXG4gICAgZW1haWw6IHJlY29yZC5lbWFpbCB8fCBcIlwiLFxyXG4gICAgZGVzY3JpcHRpb246IHJlY29yZC5kZXNjcmlwdGlvbiB8fCBcIlwiLFxyXG4gICAgcHVycG9zZTogcmVjb3JkLnB1cnBvc2UgfHwgXCJcIixcclxuICAgIGRhdGVUaW1lOiByZWNvcmQuZGF0ZVRpbWVcclxuICAgICAgPyByZWNvcmQuZGF0ZVRpbWUuc3Vic3RyaW5nKDAsIDE2KVxyXG4gICAgICA6IGdldEN1cnJlbnREYXRlVGltZSgpLFxyXG4gICAgbWVldFBlcnNvbjogcmVjb3JkLm1lZXRQZXJzb24gfHwgXCJcIixcclxuICAgIGNoaXRHcm91cDogcmVjb3JkLmNoaXRHcm91cCB8fCBcIlwiLFxyXG4gICAgY3VzdG9tZXJJZDogcmVjb3JkLmN1c3RvbWVySWQgfHwgXCJcIixcclxuICAgIGdyb3VwTmFtZURpc3BsYXk6IHJlY29yZC5ncm91cE5hbWUgfHwgcmVjb3JkLmdyb3VwTmFtZURpc3BsYXkgfHwgXCJcIixcclxuICAgIHRpY2tldE51bWJlcjogcmVjb3JkLnRpY2tldE51bWJlciB8fCBcIlwiLFxyXG4gICAgX2lkOiByZWNvcmQuX2lkXHJcbiAgfSk7XHJcblxyXG4gIHNldE9wZW5Nb2RhbCh0cnVlKTtcclxuXHJcbiAgaWYgKHJlY29yZC52aXNpdG9yVHlwZSA9PT0gJ0N1c3RvbWVycycgJiYgcmVjb3JkLmN1c3RvbWVySWQpIHtcclxuICAgIGZldGNoQ3VzdG9tZXJFbnJvbGxtZW50cyhyZWNvcmQuY3VzdG9tZXJJZCk7XHJcbiAgfVxyXG59O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHNldE9wZW5BY3Rpb25JZChudWxsKTtcclxuICAgIGlmICh3aW5kb3cuY29uZmlybShcIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyB2aXNpdG9yP1wiKSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IEFQSS5kZWxldGUoYC92aXNpdG9ycy8ke2lkfWApO1xyXG4gICAgICAgIGFsZXJ0KFwiVmlzaXRvciBEZWxldGVkIFN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICBmZXRjaFZpc2l0b3JzKCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIHZpc2l0b3I6XCIsIGVycm9yKTtcclxuICAgICAgICBhbGVydChcIkZhaWxlZCB0byBkZWxldGUgdmlzaXRvclwiKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFZpc2l0b3JzKCk7XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICAgIGZldGNoVXNlcnMoKTtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAobmFtZSwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBpZiAoZXJyb3JzW25hbWVdKSB7XHJcbiAgICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBsZXQgbmV3RXJyb3JzID0ge307XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5uYW1lIHx8IGZvcm1EYXRhLm5hbWUudHJpbSgpID09PSBcIlwiKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5uYW1lID0gXCJWaXNpdG9yIE5hbWUgaXMgcmVxdWlyZWQuXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5waG9uZSB8fCBmb3JtRGF0YS5waG9uZS50cmltKCkgPT09IFwiXCIpIHtcclxuICAgICAgbmV3RXJyb3JzLnBob25lID0gXCJQaG9uZSBOdW1iZXIgaXMgcmVxdWlyZWQuXCI7XHJcbiAgICB9IGVsc2UgaWYgKCEvXls2LTldXFxkezl9JC8udGVzdChmb3JtRGF0YS5waG9uZSkpIHtcclxuICAgICAgLy8gRklYRUQ6IE5vdyByZXF1aXJlcyBleGFjdGx5IDEwIGRpZ2l0cyBzdGFydGluZyB3aXRoIDYtOVxyXG4gICAgICBuZXdFcnJvcnMucGhvbmUgPSBcIlBob25lIG11c3QgYmUgZXhhY3RseSAxMCBkaWdpdHMgc3RhcnRpbmcgd2l0aCA2LTkuXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wdXJwb3NlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wdXJwb3NlID0gXCJQdXJwb3NlIG9mIFZpc2l0IHJlcXVpcmVkLlwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZm9ybURhdGEuZGF0ZVRpbWUpIHtcclxuICAgICAgbmV3RXJyb3JzLmRhdGVUaW1lID0gXCJEYXRlICYgVGltZSBpcyByZXF1aXJlZC5cIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWZvcm1EYXRhLm1lZXRQZXJzb24pIHtcclxuICAgICAgbmV3RXJyb3JzLm1lZXRQZXJzb24gPSBcIlBsZWFzZSBzZWxlY3Qgd2hvbSB0byBtZWV0LlwiO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIC8vIEZJWEVEOiBDbGVhbiBwYXlsb2FkIGZ1bmN0aW9uIHRvIHJlbW92ZSBlbXB0eS91bmRlZmluZWQgdmFsdWVzXHJcbiAgY29uc3QgY2xlYW5QYXlsb2FkID0gKGRhdGEpID0+IHtcclxuICAgIGNvbnN0IGNsZWFuZWQgPSB7fTtcclxuICAgIE9iamVjdC5lbnRyaWVzKGRhdGEpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xyXG4gICAgICAvLyBTa2lwIGVtcHR5IHN0cmluZ3MgZm9yIG9wdGlvbmFsIGZpZWxkcywgX2lkIGZvciBjcmVhdGUsIGFuZCB1bmRlZmluZWQvbnVsbCB2YWx1ZXNcclxuICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwpIHJldHVybjtcclxuICAgICAgaWYgKGtleSA9PT0gJ19pZCcpIHJldHVybjsgLy8gRG9uJ3Qgc2VuZCBfaWQgaW4gYm9keVxyXG4gICAgICBcclxuICAgICAgLy8gRm9yIG9wdGlvbmFsIHN0cmluZyBmaWVsZHMsIGRvbid0IHNlbmQgZW1wdHkgc3RyaW5nc1xyXG4gICAgICBpZiAoWydlbWFpbCcsICdkZXNjcmlwdGlvbicsICdjaGl0R3JvdXAnLCAnY3VzdG9tZXJJZCcsICdncm91cE5hbWVEaXNwbGF5JywgJ3RpY2tldE51bWJlciddLmluY2x1ZGVzKGtleSkgJiYgdmFsdWUgPT09ICcnKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICBjbGVhbmVkW2tleV0gPSB2YWx1ZTtcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGNsZWFuZWQ7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBpZiAoIXZhbGlkYXRlRm9ybSgpKSByZXR1cm47XHJcblxyXG4gICAgc2V0U3VibWl0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBpc1VwZGF0ZSA9ICEhZm9ybURhdGEuX2lkOyBcclxuICAgICAgY29uc3QgYXBpVXJsID0gaXNVcGRhdGUgPyBgL3Zpc2l0b3JzLyR7Zm9ybURhdGEuX2lkfWAgOiBcIi92aXNpdG9yc1wiO1xyXG4gICAgICBjb25zdCBhcGlNZXRob2QgPSBpc1VwZGF0ZSA/IEFQSS5wdXQgOiBBUEkucG9zdDtcclxuXHJcbiAgICAgIC8vIEZJWEVEOiBDbGVhbiB0aGUgcGF5bG9hZCBiZWZvcmUgc2VuZGluZ1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0gY2xlYW5QYXlsb2FkKGZvcm1EYXRhKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpTWV0aG9kKGFwaVVybCwgcGF5bG9hZCk7XHJcbiAgICAgIFxyXG4gICAgICBhbGVydChpc1VwZGF0ZSA/IFwiVmlzaXRvciBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiIDogXCJWaXNpdG9yIEFkZGVkIFN1Y2Nlc3NmdWxseVwiKTtcclxuXHJcbiAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICB2aXNpdG9yVHlwZTogXCJHdWVzdFwiLFxyXG4gICAgICAgIG5hbWU6IFwiXCIsXHJcbiAgICAgICAgcGhvbmU6IFwiXCIsXHJcbiAgICAgICAgZW1haWw6IFwiXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICAgICAgcHVycG9zZTogXCJcIixcclxuICAgICAgICBkYXRlVGltZTogXCJcIixcclxuICAgICAgICBtZWV0UGVyc29uOiBcIlwiLFxyXG4gICAgICAgIGNoaXRHcm91cDogXCJcIixcclxuICAgICAgICBjdXN0b21lcklkOiBcIlwiLFxyXG4gICAgICAgIGdyb3VwTmFtZURpc3BsYXk6IFwiXCIsXHJcbiAgICAgICAgdGlja2V0TnVtYmVyOiBcIlwiXHJcbiAgICAgIH0pO1xyXG4gICAgICBcclxuICAgICAgc2V0T3Blbk1vZGFsKGZhbHNlKTtcclxuICAgICAgZmV0Y2hWaXNpdG9ycygpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRldGFpbHM6XCIsIGVycm9yLnJlc3BvbnNlPy5kYXRhKTsgLy8gTG9nIGZ1bGwgZXJyb3IgZm9yIGRlYnVnZ2luZ1xyXG4gICAgICBcclxuICAgICAgLy8gRklYRUQ6IEJldHRlciBlcnJvciBtZXNzYWdlIGV4dHJhY3Rpb25cclxuICAgICAgbGV0IGVycm9yTWVzc2FnZSA9IFwiVW5rbm93biBlcnJvclwiO1xyXG4gICAgICBcclxuICAgICAgaWYgKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlKSB7XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlO1xyXG4gICAgICB9IGVsc2UgaWYgKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5lcnJvcnMpIHtcclxuICAgICAgICAvLyBIYW5kbGUgTW9uZ29vc2UgdmFsaWRhdGlvbiBlcnJvcnNcclxuICAgICAgICBjb25zdCBtb25nb29zZUVycm9ycyA9IGVycm9yLnJlc3BvbnNlLmRhdGEuZXJyb3JzO1xyXG4gICAgICAgIGVycm9yTWVzc2FnZSA9IE9iamVjdC52YWx1ZXMobW9uZ29vc2VFcnJvcnMpXHJcbiAgICAgICAgICAubWFwKGVyciA9PiBlcnIubWVzc2FnZSlcclxuICAgICAgICAgIC5qb2luKCcsICcpO1xyXG4gICAgICB9IGVsc2UgaWYgKGVycm9yLm1lc3NhZ2UpIHtcclxuICAgICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICBhbGVydChgRmFpbGVkOiAke2Vycm9yTWVzc2FnZX1gKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFN1Ym1pdExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldE1lZXRQZXJzb25OYW1lID0gKHBlcnNvbklkKSA9PiB7XHJcbiAgICBpZiAoIXBlcnNvbklkKSByZXR1cm4gXCJOL0FcIjtcclxuICAgIGNvbnN0IGFnZW50ID0gYWdlbnRzLmZpbmQoKGEpID0+IGEuX2lkID09PSBwZXJzb25JZCk7XHJcbiAgICBpZiAoYWdlbnQpIHJldHVybiBhZ2VudC5uYW1lO1xyXG4gICAgY29uc3QgZW1wbG95ZWUgPSBlbXBsb3llZXMuZmluZCgoZSkgPT4gZS5faWQgPT09IHBlcnNvbklkKTtcclxuICAgIGlmIChlbXBsb3llZSkgcmV0dXJuIGVtcGxveWVlLm5hbWU7XHJcbiAgICByZXR1cm4gXCJOL0FcIjtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRHcm91cE5hbWUgPSAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgaWYgKCFncm91cElkKSByZXR1cm4gXCItXCI7XHJcbiAgICBjb25zdCBncm91cCA9IGdyb3Vwcy5maW5kKChnKSA9PiBnLl9pZCA9PT0gZ3JvdXBJZCk7XHJcbiAgICByZXR1cm4gZ3JvdXAgPyBncm91cC5ncm91cF9uYW1lIDogXCJVbmtub3duIEdyb3VwXCI7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZVRpbWUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgaWYgKCFkYXRlU3RyaW5nKSByZXR1cm4gXCJOL0FcIjtcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKTtcclxuICAgIGlmIChpc05hTihkYXRlLmdldFRpbWUoKSkpIHJldHVybiBcIkludmFsaWQgRGF0ZVwiO1xyXG5cclxuICAgIGNvbnN0IGRheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG5cclxuICAgIGxldCBob3VycyA9IGRhdGUuZ2V0SG91cnMoKTtcclxuICAgIGNvbnN0IG1pbnV0ZXMgPSBTdHJpbmcoZGF0ZS5nZXRNaW51dGVzKCkpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBhbXBtID0gaG91cnMgPj0gMTIgPyAnUE0nIDogJ0FNJztcclxuICAgIGhvdXJzID0gaG91cnMgJSAxMjtcclxuICAgIGhvdXJzID0gaG91cnMgPyBob3VycyA6IDEyO1xyXG4gICAgY29uc3QgaG91cnNTdHIgPSBTdHJpbmcoaG91cnMpLnBhZFN0YXJ0KDIsICcwJyk7XHJcblxyXG4gICAgcmV0dXJuIGAke2RheX0vJHttb250aH0vJHt5ZWFyfSAke2hvdXJzU3RyfToke21pbnV0ZXN9ICR7YW1wbX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB2aXNpdG9ycy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCB0eXBlID0gKGl0ZW0udmlzaXRvclR5cGUgfHwgXCJHdWVzdFwiKS50cmltKCk7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAuLi5pdGVtLFxyXG4gICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgIHZpc2l0b3JfY29kZTogaXRlbT8udmlzaXRvcl9jb2RlLFxyXG4gICAgICB2aXNpdG9ySWQ6IGl0ZW0udmlzaXRvcklkIHx8IFwiTi9BXCIsXHJcbiAgICAgIHZpc2l0b3JUeXBlOiB0eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdHlwZS5zbGljZSgxKSxcclxuICAgICAgYWdlbnROYW1lOiBnZXRNZWV0UGVyc29uTmFtZShpdGVtLm1lZXRQZXJzb24pLFxyXG4gICAgICBncm91cE5hbWU6IGdldEdyb3VwTmFtZShpdGVtLmNoaXRHcm91cCksXHJcbiAgICAgIGZvcm1hdHRlZERhdGU6IGZvcm1hdERhdGVUaW1lKGl0ZW0uZGF0ZVRpbWUpLFxyXG4gICAgICBwdXJwb3NlOiBpdGVtLnB1cnBvc2UgfHwgXCItXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBpdGVtLmRlc2NyaXB0aW9uIHx8IFwiLVwiLFxyXG4gICAgICBlbWFpbDogaXRlbS5lbWFpbCB8fCBcIi1cIixcclxuICAgICAgX2lkOiBpdGVtLl9pZCxcclxuICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgc2V0T3BlbkFjdGlvbklkKG9wZW5BY3Rpb25JZCA9PT0gaXRlbS5faWQgPyBudWxsIDogaXRlbS5faWQpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMjAwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAg4ouuXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIHtvcGVuQWN0aW9uSWQgPT09IGl0ZW0uX2lkICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC02IHRvcC0xMCBiZy13aGl0ZSBib3JkZXIgcm91bmRlZC1sZyBzaGFkb3ctbGcgdy00MCB6LTUwXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRWRpdChpdGVtKTtcclxuICAgICAgICAgICAgICAgICAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBweC00IHB5LTIgaG92ZXI6YmctZ3JheS0xMDAgdGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEVkaXQgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5FZGl0PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZShpdGVtLl9pZCk7XHJcbiAgICAgICAgICAgICAgICAgIHNldE9wZW5BY3Rpb25JZChudWxsKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkRlbGV0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApLFxyXG4gICAgfTtcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc3RhbmRhcmRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wuTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwidmlzaXRvcl9jb2RlXCIsIGhlYWRlcjogXCJWaXNpdG9yIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiVmlzaXRvciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInZpc2l0b3JUeXBlXCIsIGhlYWRlcjogXCJUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJlbWFpbFwiLCBoZWFkZXI6IFwiRW1haWxcIiB9LFxyXG4gICAgeyBrZXk6IFwicHVycG9zZVwiLCBoZWFkZXI6IFwiUHVycG9zZVwiIH0sXHJcbiAgICB7IGtleTogXCJkZXNjcmlwdGlvblwiLCBoZWFkZXI6IFwiRGVzY3JpcHRpb25cIiB9LCAgXHJcbiAgICB7IGtleTogXCJmb3JtYXR0ZWREYXRlXCIsIGhlYWRlcjogXCJEYXRlICYgVGltZVwiIH0sXHJcbiAgICB7IGtleTogXCJhZ2VudE5hbWVcIiwgaGVhZGVyOiBcIldob20gdG8gTWVldFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgY3VzdG9tZXJDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wuTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwidmlzaXRvcl9jb2RlXCIsIGhlYWRlcjogXCJWaXNpdG9yIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiVmlzaXRvciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInZpc2l0b3JUeXBlXCIsIGhlYWRlcjogXCJUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJlbWFpbFwiLCBoZWFkZXI6IFwiRW1haWxcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJDaGl0IEdyb3VwXCIgfSxcclxuICAgIHsga2V5OiBcInB1cnBvc2VcIiwgaGVhZGVyOiBcIlB1cnBvc2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGVzY3JpcHRpb25cIiwgaGVhZGVyOiBcIkRlc2NyaXB0aW9uXCIgfSxcclxuICAgIHsga2V5OiBcImZvcm1hdHRlZERhdGVcIiwgaGVhZGVyOiBcIkRhdGUgJiBUaW1lXCIgfSxcclxuICAgIHsga2V5OiBcImFnZW50TmFtZVwiLCBoZWFkZXI6IFwiV2hvbSB0byBNZWV0XCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBjb3VudHMgPSB7XHJcbiAgICBBbGw6IGZvcm1hdHRlZERhdGEubGVuZ3RoLFxyXG4gICAgR3Vlc3Q6IGZvcm1hdHRlZERhdGEuZmlsdGVyKGQgPT4gZC52aXNpdG9yVHlwZSA9PT0gJ0d1ZXN0JykubGVuZ3RoLFxyXG4gICAgQ3VzdG9tZXJzOiBmb3JtYXR0ZWREYXRhLmZpbHRlcihkID0+IGQudmlzaXRvclR5cGUgPT09ICdDdXN0b21lcnMnKS5sZW5ndGgsXHJcbiAgICAnU2FsZXMgTGVhZHMnOiBmb3JtYXR0ZWREYXRhLmZpbHRlcihkID0+IGQudmlzaXRvclR5cGUgPT09ICdTYWxlcyBMZWFkcycpLmxlbmd0aCxcclxuICAgIE90aGVyczogZm9ybWF0dGVkRGF0YS5maWx0ZXIoZCA9PiBkLnZpc2l0b3JUeXBlID09PSAnT3RoZXJzJykubGVuZ3RoLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRhYkl0ZW1zID0gW1xyXG4gICAge1xyXG4gICAgICBrZXk6ICdBbGwnLFxyXG4gICAgICBsYWJlbDogPHNwYW4+QWxsIDxCYWRnZSBjb3VudD17Y291bnRzLkFsbH0gc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnIzcyMmVkMScgfX0gLz48L3NwYW4+LFxyXG4gICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgIGRhdGE9e2Zvcm1hdHRlZERhdGF9XHJcbiAgICAgICAgICBjb2x1bW5zPXtjdXN0b21lckNvbHVtbnN9XHJcbiAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJBbGwgVmlzaXRvcnNfUmVwb3J0XCJcclxuICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJBbGwgVmlzaXRvcnMuY3N2XCJcclxuICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9eygpID0+IHsgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6ICdHdWVzdCcsXHJcbiAgICAgIGxhYmVsOiA8c3Bhbj5HdWVzdCA8QmFkZ2UgY291bnQ9e2NvdW50cy5HdWVzdH0gc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnIzUyYzQxYScgfX0gLz48L3NwYW4+LFxyXG4gICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgIGRhdGE9e2Zvcm1hdHRlZERhdGEuZmlsdGVyKGQgPT4gZC52aXNpdG9yVHlwZSA9PT0gJ0d1ZXN0Jyl9XHJcbiAgICAgICAgICBjb2x1bW5zPXtzdGFuZGFyZENvbHVtbnN9XHJcbiAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJHdWVzdCBWaXNpdG9yc19SZXBvcnRcIlxyXG4gICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkd1ZXN0IFZpc2l0b3JzLmNzdlwiXHJcbiAgICAgICAgICB1cGRhdGVIYW5kbGVyPXsoKSA9PiB7IH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiAnQ3VzdG9tZXJzJyxcclxuICAgICAgbGFiZWw6IDxzcGFuPkN1c3RvbWVycyA8QmFkZ2UgY291bnQ9e2NvdW50cy5DdXN0b21lcnN9IHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyMxODkwZmYnIH19IC8+PC9zcGFuPixcclxuICAgICAgY2hpbGRyZW46IChcclxuICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICBkYXRhPXtmb3JtYXR0ZWREYXRhLmZpbHRlcihkID0+IGQudmlzaXRvclR5cGUgPT09ICdDdXN0b21lcnMnKX1cclxuICAgICAgICAgIGNvbHVtbnM9e2N1c3RvbWVyQ29sdW1uc31cclxuICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkN1c3RvbWVyIFZpc2l0b3JzIFJlcG9ydFwiXHJcbiAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXIgVmlzaXRvcnMuY3N2XCJcclxuICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9eygpID0+IHsgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6ICdTYWxlcyBMZWFkcycsXHJcbiAgICAgIGxhYmVsOiA8c3Bhbj5TYWxlcyBMZWFkcyA8QmFkZ2UgY291bnQ9e2NvdW50c1snU2FsZXMgTGVhZHMnXX0gc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnIzcyMmVkMScgfX0gLz48L3NwYW4+LFxyXG4gICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgIGRhdGE9e2Zvcm1hdHRlZERhdGEuZmlsdGVyKGQgPT4gZC52aXNpdG9yVHlwZSA9PT0gJ1NhbGVzIExlYWRzJyl9XHJcbiAgICAgICAgICBjb2x1bW5zPXtzdGFuZGFyZENvbHVtbnN9XHJcbiAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJTYWxlcyBMZWFkc19SZXBvcnRcIlxyXG4gICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlNhbGVzIExlYWRzLmNzdlwiXHJcbiAgICAgICAgICB1cGRhdGVIYW5kbGVyPXsoKSA9PiB7IH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiAnT3RoZXJzJyxcclxuICAgICAgbGFiZWw6IDxzcGFuPk90aGVycyA8QmFkZ2UgY291bnQ9e2NvdW50cy5PdGhlcnN9IHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyNmYWFkMTQnIH19IC8+PC9zcGFuPixcclxuICAgICAgY2hpbGRyZW46IChcclxuICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICBkYXRhPXtmb3JtYXR0ZWREYXRhLmZpbHRlcihkID0+IGQudmlzaXRvclR5cGUgPT09ICdPdGhlcnMnKX1cclxuICAgICAgICAgIGNvbHVtbnM9e3N0YW5kYXJkQ29sdW1uc31cclxuICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIk90aGVyIFZpc2l0b3JzX1JlcG9ydFwiXHJcbiAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiT3RoZXIgVmlzaXRvcnMuY3N2XCJcclxuICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9eygpID0+IHsgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApXHJcbiAgICB9XHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxOYXZiYXIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IG10LTggcmVsYXRpdmUgb3ZlcmZsb3ctYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj5WaXNpdG9yIE1hbmFnZW1lbnQ8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5TZWdyZWdhdGVkIHZpc2l0b3IgcmVjb3JkcyBieSB0eXBlLjwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuTW9kYWx9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIGJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICsgQWRkIERldGFpbHNcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTQgbWluLWgtWzQwMHB4XSBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogdmlzaXRvcnMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXtmYWxzZX0gZmFpbHVyZT17dHJ1ZX0gZGF0YT1cIlZpc2l0b3JzXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8VGFicyBkZWZhdWx0QWN0aXZlS2V5PVwiQWxsXCIgc2l6ZT1cImxhcmdlXCIgaXRlbXM9e3RhYkl0ZW1zfSAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIC0tLSBNT0RBTCBDT01QT05FTlQgLS0tICovfVxyXG4gICAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17b3Blbk1vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuTW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7Zm9ybURhdGEuX2lkID8gXCJFZGl0IFZpc2l0b3JcIiA6IFwiQWRkIFZpc2l0b3JcIn1cclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFZpc2l0b3IgVHlwZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFZpc2l0b3IgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnZpc2l0b3JUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShcInZpc2l0b3JUeXBlXCIsIHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShcImNoaXRHcm91cFwiLCBcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShcImN1c3RvbWVySWRcIiwgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoXCJncm91cE5hbWVEaXNwbGF5XCIsIFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnR3Vlc3QnLCBsYWJlbDogJ0d1ZXN0JyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJ0N1c3RvbWVycycsIGxhYmVsOiAnQ3VzdG9tZXJzJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJ1NhbGVzIExlYWRzJywgbGFiZWw6ICdTYWxlcyBMZWFkcycgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdPdGhlcnMnLCBsYWJlbDogJ090aGVycycgfSxcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIENVU1RPTUVSUyBTRUNUSU9OICovfVxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLnZpc2l0b3JUeXBlID09PSAnQ3VzdG9tZXJzJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1mYWRlLWluIHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2VhcmNoIEN1c3RvbWVyIChUeXBlIFBob25lIE51bWJlcikgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgcGhvbmUgbnVtYmVyIG9yIG5hbWUuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY3VzdG9tZXJJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDdXN0b21lclNlbGVjdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5sYWJlbCA/PyBcIlwiKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17dXNlcnMubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB1c2VyLl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogYCR7dXNlci5mdWxsX25hbWV9IC0gJHt1c2VyLnBob25lX251bWJlcn1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5DdXN0b21lciBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTYwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41IGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+UGhvbmUgTnVtYmVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS02MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNSBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5FbWFpbDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTYwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41IGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+Q2hpdCBHcm91cDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmdyb3VwTmFtZURpc3BsYXkgfHwgXCJTZWxlY3QgYSBjdXN0b21lciB0byBzZWUgZ3JvdXBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS02MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNSBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBHVUVTVCAvIE9USEVSUyBTRUNUSU9OICovfVxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLnZpc2l0b3JUeXBlICE9PSAnQ3VzdG9tZXJzJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiIGh0bWxGb3I9XCJuYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFZpc2l0b3IgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKFwibmFtZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEZ1bGwgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNSAke2Vycm9ycy5uYW1lID8gJ2JvcmRlci1yZWQtNTAwJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5uYW1lICYmIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLm5hbWV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCIgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKFwiZW1haWxcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNSAke2Vycm9ycy5lbWFpbCA/ICdib3JkZXItcmVkLTUwMCcgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtYWlsICYmIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmVtYWlsfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCIgaHRtbEZvcj1cInBob25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsxMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gZS50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKTsgLy8gUmVtb3ZlIG5vbi1kaWdpdHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5sZW5ndGggPD0gMTApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKFwicGhvbmVcIiwgdmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwaG9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciAxMCBkaWdpdCBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNSAke2Vycm9ycy5waG9uZSA/ICdib3JkZXItcmVkLTUwMCcgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lICYmIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnBob25lfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBQdXJwb3NlICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUHVycG9zZSBvZiBWaXNpdCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnB1cnBvc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQ2hhbmdlKFwicHVycG9zZVwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiAnRG9jdW1lbnQgU2lnbicsIGxhYmVsOiAnRG9jdW1lbnQgU2lnbicgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdDaGl0IEluZm9ybWF0aW9uJywgbGFiZWw6ICdDaGl0IEluZm9ybWF0aW9uJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJ0NoaXQgQ2FuY2VsbGF0aW9uJywgbGFiZWw6ICdDaGl0IENhbmNlbGxhdGlvbicgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdMb2FuIEluZm9ybWF0aW9uJywgbGFiZWw6ICdMb2FuIEluZm9ybWF0aW9uJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogJ1BpZ215IEluZm9ybWF0aW9uJywgbGFiZWw6ICdQaWdteSBJbmZvcm1hdGlvbicgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdBdWN0aW9uIEJpZGRpbmcnLCBsYWJlbDogJ0F1Y3Rpb24gQmlkZGluZycgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdJbnRlcnZpZXcnLCBsYWJlbDogJ0ludGVydmlldycgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdQYXltZW50cycsIGxhYmVsOiAnUGF5bWVudCcgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHsgdmFsdWU6ICdPdGhlcnMnLCBsYWJlbDogJ090aGVycycgfSxcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnB1cnBvc2UgJiYgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMucHVycG9zZX08L3A+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIERlc2NyaXB0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCIgaHRtbEZvcj1cImRlc2NyaXB0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRGVzY3JpcHRpb25cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0LlRleHRBcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIERlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoXCJkZXNjcmlwdGlvblwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBEYXRlICYgVGltZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiIGh0bWxGb3I9XCJkYXRlVGltZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERhdGUgJiBUaW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRhdGVUaW1lXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGF0ZVRpbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoXCJkYXRlVGltZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJkYXRlVGltZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41ICR7ZXJyb3JzLmRhdGVUaW1lID8gJ2JvcmRlci1yZWQtNTAwJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGF0ZVRpbWUgJiYgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZGF0ZVRpbWV9PC9wPn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBXaG9tIHRvIE1lZXQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBXaG9tIHRvIE1lZXQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBhbiBBZ2VudCBvciBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVDaGFuZ2UoXCJtZWV0UGVyc29uXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8ubGFiZWwgPz8gXCJcIikudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubWVldFBlcnNvbn1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgJHtlcnJvcnMubWVldFBlcnNvbiA/ICdib3JkZXItcmVkLTUwMCcgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLmFnZW50cy5tYXAoKGFnZW50KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogYWdlbnQuX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogYCR7YWdlbnQubmFtZX0gKEFnZW50KSAtICR7YWdlbnQuZGVzaWduYXRpb25faWQ/LnRpdGxlIHx8ICdBZ2VudCd9YCxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKSxcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLmVtcGxveWVlcy5tYXAoKGVtcCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGVtcC5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHtlbXAubmFtZX0gKEVtcGxveWVlKSAtICR7ZW1wLmRlc2lnbmF0aW9uX2lkPy50aXRsZSB8fCAnU3RhZmYnfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLm1lZXRQZXJzb24gJiYgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMubWVldFBlcnNvbn08L3A+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFN1Ym1pdCBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c3VibWl0TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3N1Ym1pdExvYWRpbmcgPyBcIlN1Ym1pdHRpbmcuLi5cIiA6IChmb3JtRGF0YS5faWQgPyBcIlVwZGF0ZSBEZXRhaWxzXCIgOiBcIlN1Ym1pdCBEZXRhaWxzXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1Zpc2l0b3JMaXN0LmpzeCJ9