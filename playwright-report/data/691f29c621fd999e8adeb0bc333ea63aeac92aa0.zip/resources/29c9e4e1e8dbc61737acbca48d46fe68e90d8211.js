import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/helpers/Breadcrumb.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { ChevronRight, Home } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const routeNameMap = {
  "/approval-menu": "Approval Management",
  "/approval-menu/un-approved-customer": "Unverified Customers",
  "/approval-menu/mobile-app-enroll": "Mobile Enrollments",
  "/approval-menu/un-approved-loans": "Unapproved Loans",
  "/staff-menu": "HR"
};
const toTitleCase = (str) => {
  return str.replace(/\b\w/g, (char) => char.toUpperCase());
};
const Breadcrumb = () => {
  _s();
  const location = useLocation();
  const pathnames = location.pathname.split("/").filter(Boolean);
  const items = [];
  let currentPath = "";
  for (let i = 0; i < pathnames.length; i++) {
    currentPath += `/${pathnames[i]}`;
    const label = routeNameMap[currentPath] || toTitleCase(pathnames[i]);
    items.push({
      path: currentPath,
      label
    });
  }
  return /* @__PURE__ */ jsxDEV("nav", { className: "flex items-center gap-2 text-sm text-gray-500 mb-6 flex-wrap", children: [
    /* @__PURE__ */ jsxDEV(
      Link,
      {
        to: "/dashboard",
        className: "hover:text-violet-600 flex items-center gap-1",
        children: [
          /* @__PURE__ */ jsxDEV(Home, { size: 16 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
            lineNumber: 43,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Home" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
            lineNumber: 44,
            columnNumber: 17
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
        lineNumber: 39,
        columnNumber: 13
      },
      this
    ),
    items.map(
      (item, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(ChevronRight, { size: 14, className: "text-gray-400" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
          lineNumber: 49,
          columnNumber: 21
        }, this),
        idx === items.length - 1 ? /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-900", children: item.label }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
          lineNumber: 52,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: item.path,
            className: "hover:text-violet-600",
            children: item.label
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
            lineNumber: 56,
            columnNumber: 9
          },
          this
        )
      ] }, item.path, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
        lineNumber: 48,
        columnNumber: 7
      }, this)
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
};
_s(Breadcrumb, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
  return [useLocation];
});
_c = Breadcrumb;
export default Breadcrumb;
var _c;
$RefreshReg$(_c, "Breadcrumb");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/helpers/Breadcrumb.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENnQjsyQkExQ2hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLGNBQWNDLFlBQVk7QUFFbkMsTUFBTUMsZUFBZTtBQUFBLEVBQ2pCLGtCQUFrQjtBQUFBLEVBQ2xCLHVDQUF1QztBQUFBLEVBQ3ZDLG9DQUFvQztBQUFBLEVBQ3BDLG9DQUFvQztBQUFBLEVBQ3BDLGVBQWU7QUFDbkI7QUFHQSxNQUFNQyxjQUFjQSxDQUFDQyxRQUFRO0FBQ3pCLFNBQU9BLElBQUlDLFFBQVEsU0FBUyxDQUFDQyxTQUFTQSxLQUFLQyxZQUFZLENBQUM7QUFDNUQ7QUFFQSxNQUFNQyxhQUFhQSxNQUFNO0FBQUFDLEtBQUE7QUFDckIsUUFBTUMsV0FBV1gsWUFBWTtBQUM3QixRQUFNWSxZQUFZRCxTQUFTRSxTQUFTQyxNQUFNLEdBQUcsRUFBRUMsT0FBT0MsT0FBTztBQUU3RCxRQUFNQyxRQUFRO0FBQ2QsTUFBSUMsY0FBYztBQUVsQixXQUFTQyxJQUFJLEdBQUdBLElBQUlQLFVBQVVRLFFBQVFELEtBQUs7QUFDdkNELG1CQUFlLElBQUlOLFVBQVVPLENBQUMsQ0FBQztBQUUvQixVQUFNRSxRQUNGbEIsYUFBYWUsV0FBVyxLQUFLZCxZQUFZUSxVQUFVTyxDQUFDLENBQUM7QUFFekRGLFVBQU1LLEtBQUs7QUFBQSxNQUNQQyxNQUFNTDtBQUFBQSxNQUNORztBQUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFdBQVUsZ0VBQ1g7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csSUFBRztBQUFBLFFBQ0gsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFDZix1QkFBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVU7QUFBQTtBQUFBO0FBQUEsTUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNQTtBQUFBLElBRUNKLE1BQU1PO0FBQUFBLE1BQUksQ0FBQ0MsTUFBTUMsUUFDZCx1QkFBQyxTQUFvQixXQUFVLDJCQUMzQjtBQUFBLCtCQUFDLGdCQUFhLE1BQU0sSUFBSSxXQUFVLG1CQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsUUFFaERBLFFBQVFULE1BQU1HLFNBQVMsSUFDcEIsdUJBQUMsVUFBSyxXQUFVLDZCQUNYSyxlQUFLSixTQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxJQUFJSSxLQUFLRjtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVURSxlQUFLSjtBQUFBQTtBQUFBQSxVQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FiRUksS0FBS0YsTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxJQUNIO0FBQUEsT0ExQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVSO0FBQUViLEdBakRJRCxZQUFVO0FBQUEsVUFDS1QsV0FBVztBQUFBO0FBQUEyQixLQUQxQmxCO0FBbUROLGVBQWVBO0FBQVcsSUFBQWtCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMaW5rIiwidXNlTG9jYXRpb24iLCJDaGV2cm9uUmlnaHQiLCJIb21lIiwicm91dGVOYW1lTWFwIiwidG9UaXRsZUNhc2UiLCJzdHIiLCJyZXBsYWNlIiwiY2hhciIsInRvVXBwZXJDYXNlIiwiQnJlYWRjcnVtYiIsIl9zIiwibG9jYXRpb24iLCJwYXRobmFtZXMiLCJwYXRobmFtZSIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsIml0ZW1zIiwiY3VycmVudFBhdGgiLCJpIiwibGVuZ3RoIiwibGFiZWwiLCJwdXNoIiwicGF0aCIsIm1hcCIsIml0ZW0iLCJpZHgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCcmVhZGNydW1iLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBjb21wb25lbnRzL0JyZWFkY3J1bWIuanN4XHJcbmltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgQ2hldnJvblJpZ2h0LCBIb21lIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuY29uc3Qgcm91dGVOYW1lTWFwID0ge1xyXG4gICAgXCIvYXBwcm92YWwtbWVudVwiOiBcIkFwcHJvdmFsIE1hbmFnZW1lbnRcIixcclxuICAgIFwiL2FwcHJvdmFsLW1lbnUvdW4tYXBwcm92ZWQtY3VzdG9tZXJcIjogXCJVbnZlcmlmaWVkIEN1c3RvbWVyc1wiLFxyXG4gICAgXCIvYXBwcm92YWwtbWVudS9tb2JpbGUtYXBwLWVucm9sbFwiOiBcIk1vYmlsZSBFbnJvbGxtZW50c1wiLFxyXG4gICAgXCIvYXBwcm92YWwtbWVudS91bi1hcHByb3ZlZC1sb2Fuc1wiOiBcIlVuYXBwcm92ZWQgTG9hbnNcIixcclxuICAgIFwiL3N0YWZmLW1lbnVcIjogXCJIUlwiLFxyXG59O1xyXG5cclxuLy8gQ29udmVydCBzbHVnL3BhdGggdG8gVGl0bGUgQ2FzZVxyXG5jb25zdCB0b1RpdGxlQ2FzZSA9IChzdHIpID0+IHtcclxuICAgIHJldHVybiBzdHIucmVwbGFjZSgvXFxiXFx3L2csIChjaGFyKSA9PiBjaGFyLnRvVXBwZXJDYXNlKCkpO1xyXG59O1xyXG5cclxuY29uc3QgQnJlYWRjcnVtYiA9ICgpID0+IHtcclxuICAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICAgIGNvbnN0IHBhdGhuYW1lcyA9IGxvY2F0aW9uLnBhdGhuYW1lLnNwbGl0KFwiL1wiKS5maWx0ZXIoQm9vbGVhbik7XHJcblxyXG4gICAgY29uc3QgaXRlbXMgPSBbXTtcclxuICAgIGxldCBjdXJyZW50UGF0aCA9IFwiXCI7XHJcblxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXRobmFtZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICBjdXJyZW50UGF0aCArPSBgLyR7cGF0aG5hbWVzW2ldfWA7XHJcblxyXG4gICAgICAgIGNvbnN0IGxhYmVsID1cclxuICAgICAgICAgICAgcm91dGVOYW1lTWFwW2N1cnJlbnRQYXRoXSB8fCB0b1RpdGxlQ2FzZShwYXRobmFtZXNbaV0pO1xyXG5cclxuICAgICAgICBpdGVtcy5wdXNoKHtcclxuICAgICAgICAgICAgcGF0aDogY3VycmVudFBhdGgsXHJcbiAgICAgICAgICAgIGxhYmVsLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtZ3JheS01MDAgbWItNiBmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPVwiL2Rhc2hib2FyZFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LXZpb2xldC02MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SG9tZSBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkhvbWU8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0ucGF0aH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2lkeCA9PT0gaXRlbXMubGVuZ3RoIC0gMSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2l0ZW0ucGF0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICA8L25hdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCcmVhZGNydW1iOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9oZWxwZXJzL0JyZWFkY3J1bWIuanN4In0=