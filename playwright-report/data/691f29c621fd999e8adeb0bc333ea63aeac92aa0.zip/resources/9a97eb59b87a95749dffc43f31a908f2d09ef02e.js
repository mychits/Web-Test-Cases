import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TargetIncentiveNewReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select, Radio, Tabs } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { GiPartyPopper } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import {
  FaBullseye,
  FaUserPlus,
  FaHistory,
  FaCoins,
  FaCheckCircle,
  FaTimesCircle,
  FaArrowRight,
  FaChartLine,
  FaTrophy,
  FaRocket,
  FaInfoCircle
} from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { MdOutlinePendingActions } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
const { TabPane } = Tabs;
function TargetIncentiveNewReport() {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(null);
  const [dateSelectionMode, setDateSelectionMode] = useState("month");
  const [agentLoading, setAgentLoading] = useState(false);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [incentiveData, setIncentiveData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [adminId, setAdminId] = useState("");
  const [adminName, setAdminName] = useState("");
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [isFiltering, setIsFiltering] = useState(false);
  const [tempSelectedMonth, setTempSelectedMonth] = useState(null);
  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [note, setNote] = useState("");
  const [lastFetchedInfo, setLastFetchedInfo] = useState(null);
  const [reportLoaded, setReportLoaded] = useState(false);
  const [summary, setSummary] = useState({
    eligibleForSalary: false,
    totalTarget: 0,
    incentive: 0,
    totalCurrentEnrolls: 0,
    totalPreviousEnrolls: 0,
    totalCombinedEnrolls: 0
  });
  const parseAmount = (val) => parseFloat(val?.toString().replace(/[^0-9.-]+/g, "")) || 0;
  useEffect(() => {
    const today2 = /* @__PURE__ */ new Date();
    const currentMonth2 = `${today2.getFullYear()}-${String(
      today2.getMonth() + 1
    ).padStart(2, "0")}`;
    setTempSelectedMonth(currentMonth2);
    setSelectedMonth(currentMonth2);
    const year = today2.getFullYear();
    const month = today2.getMonth() + 1;
    const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastday1 = new Date(year, month, 0).getDate();
    const lastDay = `${year}-${month}-${String(lastday1).padStart(2, "0")}`;
    setTempFromDate(firstDay);
    setTempToDate(lastDay);
    setFromDate(firstDay);
    setToDate(lastDay);
  }, []);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      setAdminId(user._id);
      setAdminName(user.name || "");
    }
  }, []);
  const fetchEmployees = async () => {
    try {
      const res = await api.get("/employee");
      setEmployees(res?.data?.employee);
    } catch (err) {
      console.error("Error fetching employees:", err);
    }
  };
  const fetchSalaryIncentiveReport = async (employeeId, startDate, endDate) => {
    setReportLoaded(false);
    if (!employeeId || !startDate || !endDate) return;
    const abortController = new AbortController();
    try {
      let params = {
        start_date: startDate,
        end_date: endDate
      };
      const res = await api.get(
        `/v1/admin/enrolls/employee/${employeeId}/salary-incentives`,
        {
          params,
          signal: abortController.signal
        }
      );
      if (res.data.success) {
        const { data } = res.data;
        setNote(data.note || "");
        setSummary({
          eligibleForSalary: data.eligibleForSalary || false,
          totalTarget: data.totalTarget || 0,
          incentive: data.incentive || 0,
          totalCurrentEnrolls: data.totalCurrentEnrolls || 0,
          totalPreviousEnrolls: data.totalPreviousEnrolls || 0,
          totalCombinedEnrolls: (data.totalCurrentEnrolls || 0) + (data.totalPreviousEnrolls || 0)
        });
        const processedData = [];
        if (data.incentiveData && data.incentiveData.length > 0) {
          data.incentiveData.forEach((item) => {
            if (item.current_enrolls && item.current_enrolls.length > 0) {
              item.current_enrolls.forEach((enroll) => {
                processedData.push({
                  user_name: enroll.user_id?.full_name || "N/A",
                  phone_number: enroll.user_id?.phone_number || "N/A",
                  group_name: enroll.group_id?.group_name || "N/A",
                  group_value: enroll.group_id?.group_value || 0,
                  group_incentive: enroll.group_id?.incentives || 0,
                  group_ticket: enroll.tickets || "N/A",
                  enrollment_date: enroll.createdAt?.split("T")?.[0] || "N/A",
                  total_paid_amount: enroll.total_paid_amount || 0,
                  business_value: enroll?.diff_group_value ?? 0,
                  upgraded: enroll?.upgraded ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                      lineNumber: 146,
                      columnNumber: 23
                    }, this),
                    "Yes"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 145,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-100 text-red-700 text-xs font-semibold whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "text-red-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                      lineNumber: 151,
                      columnNumber: 23
                    }, this),
                    "No"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 150,
                    columnNumber: 19
                  }, this),
                  monthly_installment: enroll.group_id?.monthly_installment || 0,
                  enroll_code: enroll.enroll_code || "N/A",
                  enroll_type: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 bg-green-500 rounded-full" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                      lineNumber: 161,
                      columnNumber: 23
                    }, this),
                    "Current"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 160,
                    columnNumber: 19
                  }, this),
                  enroll_type_badge: "current"
                });
              });
            }
            if (item.previous_enrolls && item.previous_enrolls.length > 0) {
              item.previous_enrolls.forEach((enroll) => {
                processedData.push({
                  user_name: enroll.user_id?.full_name || "N/A",
                  phone_number: enroll.user_id?.phone_number || "N/A",
                  group_name: enroll.group_id?.group_name || "N/A",
                  group_value: enroll.group_id?.group_value || 0,
                  group_incentive: enroll.group_id?.incentives || 0,
                  group_ticket: enroll.tickets || "N/A",
                  enrollment_date: enroll.createdAt?.split("T")?.[0] || "N/A",
                  total_paid_amount: enroll.total_paid_amount || 0,
                  business_value: enroll?.diff_group_value ?? 0,
                  upgraded: enroll?.upgraded ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                      lineNumber: 184,
                      columnNumber: 23
                    }, this),
                    "Yes"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 183,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-100 text-red-700 text-xs font-semibold whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "text-red-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                      lineNumber: 189,
                      columnNumber: 23
                    }, this),
                    "No"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 188,
                    columnNumber: 19
                  }, this),
                  monthly_installment: enroll.group_id?.monthly_installment || 0,
                  enroll_code: enroll.enroll_code || "N/A",
                  enroll_type: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold whitespace-nowrap", children: [
                    /* @__PURE__ */ jsxDEV(FaHistory, { className: "text-amber-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                      lineNumber: 198,
                      columnNumber: 23
                    }, this),
                    "Carry Forward"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 197,
                    columnNumber: 19
                  }, this),
                  enroll_type_badge: "previous"
                });
              });
            }
          });
        }
        setIncentiveData(processedData);
        setReportLoaded(true);
        setLastFetchedInfo({
          employeeName: selectedEmployeeDetails?.name || "selected employee",
          phoneNumber: selectedEmployeeDetails?.phone_number || "N/A",
          period: dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${selectedMonth}-01`)).toLocaleString("default", {
            month: "long",
            year: "numeric"
          }) : `${new Date(fromDate).toLocaleDateString()} - ${new Date(
            toDate
          ).toLocaleDateString()}`
        });
      }
    } catch (err) {
      if (err.name !== "AbortController") {
        console.error("Error fetching salary incentive report:", err);
        setIncentiveData([]);
        setSummary({
          eligibleForSalary: false,
          totalTarget: 0,
          incentive: 0,
          totalCurrentEnrolls: 0,
          totalPreviousEnrolls: 0,
          totalCombinedEnrolls: 0
        });
        setNote("");
      }
    }
  };
  const handleEmployeeChange = (value) => {
    setSelectedEmployeeId(value);
    setSelectedEmployeeDetails(null);
    setIncentiveData([]);
    setNote("");
    setLastFetchedInfo(null);
    setSummary({
      eligibleForSalary: false,
      totalTarget: 0,
      incentive: 0,
      totalCurrentEnrolls: 0,
      totalPreviousEnrolls: 0,
      totalCombinedEnrolls: 0
    });
  };
  const handleTempMonthChange = (e) => {
    const selectedMonth2 = e.target.value;
    setTempSelectedMonth(selectedMonth2);
    if (selectedMonth2) {
      const [year, month] = selectedMonth2.split("-");
      const firstDay = `${year}-${month}-01`;
      const lastday1 = new Date(year, month, 0).getDate();
      const lastDay = `${year}-${month}-${String(lastday1).padStart(2, "0")}`;
      setTempFromDate(firstDay);
      setTempToDate(lastDay);
    }
  };
  const applyFilter = async () => {
    if (!selectedEmployeeId) {
      alert("Please select an employee.");
      return;
    }
    if (dateSelectionMode === "month" && !tempSelectedMonth) {
      alert("Please select a month.");
      return;
    }
    if (dateSelectionMode === "date-range" && (!tempFromDate || !tempToDate)) {
      alert("Please select both From and To dates.");
      return;
    }
    setIsFiltering(true);
    let startDate, endDate;
    if (dateSelectionMode === "month") {
      setSelectedMonth(tempSelectedMonth);
      const [year, month] = tempSelectedMonth.split("-");
      startDate = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      endDate = `${year}-${month}-${String(lastDay).padStart(2, "0")}`;
      setFromDate(startDate);
      setToDate(endDate);
    } else {
      startDate = tempFromDate;
      endDate = tempToDate;
      setFromDate(startDate);
      setToDate(endDate);
    }
    setLoading(true);
    setAgentLoading(true);
    try {
      const emp = employees.find((e) => e._id === selectedEmployeeId);
      setSelectedEmployeeDetails(emp || null);
      await fetchSalaryIncentiveReport(selectedEmployeeId, startDate, endDate);
    } finally {
      setAgentLoading(false);
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const columns = [
    { key: "user_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "group_ticket", header: "Ticket No" },
    { key: "group_value", header: "Group Value" },
    {
      key: "business_value",
      header: "Business Value",
      render: (value) => value ?? 0
    },
    {
      key: "upgraded",
      header: "Upgraded",
      render: (value) => value ? "Yes" : "No"
    },
    { key: "enroll_type", header: "Enroll Type" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "enroll_code", header: "Enroll Code" },
    { key: "group_incentive", header: "Incentive %" },
    { key: "monthly_installment", header: "First Installment" },
    { key: "total_paid_amount", header: "Total Paid" }
  ];
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  const EligibilityCard = ({ eligible }) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `relative overflow-hidden rounded-2xl p-4 border-2 transition-all duration-500 h-full ${eligible ? "bg-gradient-to-br from-green-50 via-emerald-50 to-green-50 border-green-400 shadow-md shadow-green-200/50" : "bg-gradient-to-br from-gray-50 via-slate-50 to-gray-50 border-gray-300 shadow-md"}`,
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 opacity-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-48 h-48 bg-green-500 rounded-full blur-3xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 358,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-48 h-48 bg-blue-500 rounded-full blur-3xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 359,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 357,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative flex flex-col gap-3 h-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `p-2 rounded-xl ${eligible ? "bg-green-100" : "bg-gray-200"}`,
                children: eligible ? /* @__PURE__ */ jsxDEV(GiPartyPopper, { size: 20, className: "text-green-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 370,
                  columnNumber: 11
                }, this) : /* @__PURE__ */ jsxDEV(MdOutlinePendingActions, { size: 20, className: "text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 372,
                  columnNumber: 11
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 365,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-500 uppercase tracking-wider", children: "Salary Eligibility" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 375,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 364,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: eligible ? /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-extrabold text-green-700", children: "Eligible" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 383,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-extrabold text-orange-600", children: "Not Eligible" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 387,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 381,
              columnNumber: 11
            }, this),
            eligible ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-xl shadow-md shadow-green-200", children: [
              /* @__PURE__ */ jsxDEV(FaRocket, { className: "text-sm" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 395,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-xs uppercase", children: "Approved" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 396,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1.5 h-1.5 bg-white rounded-full animate-ping" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 397,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 394,
              columnNumber: 9
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-gradient-to-r from-orange-500 to-amber-500 text-white px-3 py-1 rounded-xl shadow-md shadow-orange-200", children: [
              /* @__PURE__ */ jsxDEV(MdOutlinePendingActions, { className: "text-sm" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 401,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-xs uppercase", children: "Pending" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 402,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 400,
              columnNumber: 9
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 380,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `mt-1 px-3 py-1.5 rounded-lg border ${eligible ? "bg-white/60 border-green-200" : "bg-orange-50 border-orange-200"}`,
              children: /* @__PURE__ */ jsxDEV(
                "p",
                {
                  className: `text-xs font-medium ${eligible ? "text-green-700" : "text-orange-700"}`,
                  children: eligible ? "Target achieved! Eligible for salary." : "Target not yet achieved. Additional business required."
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 414,
                  columnNumber: 11
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 408,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 362,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
      lineNumber: 350,
      columnNumber: 3
    },
    this
  );
  const SummaryCard = ({
    icon: Icon,
    title,
    value,
    color,
    bgColor,
    borderColor,
    textColor,
    iconBgColor
  }) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `group bg-gradient-to-br ${bgColor} border ${borderColor} rounded-2xl p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-default`,
      children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV(
            "p",
            {
              className: `text-xs font-bold ${textColor} uppercase tracking-wider flex items-center gap-2`,
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { className: `${textColor} text-sm` }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 446,
                  columnNumber: 13
                }, this),
                title
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 443,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: `text-2xl font-extrabold ${textColor} mt-2`, children: [
            "₹",
            value?.toLocaleString("en-IN") || "0"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 449,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "p",
            {
              className: `text-xs ${textColor} mt-2 font-medium opacity-80 truncate`,
              children: numberToIndianWords(value || 0)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 452,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 442,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `${iconBgColor} rounded-2xl p-3 shadow-inner group-hover:scale-110 transition-transform`,
            children: /* @__PURE__ */ jsxDEV(Icon, { className: `${textColor} text-2xl` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 461,
              columnNumber: 11
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 458,
            columnNumber: 9
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
        lineNumber: 441,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
      lineNumber: 438,
      columnNumber: 3
    },
    this
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-screen bg-gray-50", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
      lineNumber: 470,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold text-gray-900", children: "Chit Business Performance & Incentive Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 475,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 text-sm font-bold text-white bg-gradient-to-r from-green-500 to-emerald-600 rounded-full animate-pulse shadow-lg shadow-green-200", children: "NEW" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 478,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 474,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Track employee business targets, achievements, and incentive earnings." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 482,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
        lineNumber: 473,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg border border-gray-100 p-8 mb-8 hover:shadow-xl transition-shadow", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 mb-6 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FaChartLine, { className: "text-blue-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 491,
            columnNumber: 15
          }, this),
          "Report Filters"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 490,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Select Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 499,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedEmployeeId || void 0,
                onChange: handleEmployeeChange,
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Search by name or phone",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                style: { height: "44px" },
                className: "rounded w-full",
                disabled: loading,
                children: employees.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                    emp.name,
                    " - ",
                    emp.phone_number
                  ] }, emp._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 519,
                    columnNumber: 19
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 502,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 498,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Date Selection" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 528,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-3 bg-gray-50 rounded-lg h-11", children: /* @__PURE__ */ jsxDEV(
              Radio.Group,
              {
                value: dateSelectionMode,
                onChange: (e) => setDateSelectionMode(e.target.value),
                disabled: loading,
                children: [
                  /* @__PURE__ */ jsxDEV(Radio, { value: "month", className: "text-sm", children: "Month" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 537,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Radio, { value: "date-range", className: "text-sm", children: "Range" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 540,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 532,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 531,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 527,
            columnNumber: 15
          }, this),
          dateSelectionMode === "month" ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:col-span-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Select Month" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 550,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "month",
                value: tempSelectedMonth || "",
                max: currentMonth,
                onChange: handleTempMonthChange,
                disabled: loading,
                className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 h-11 disabled:bg-gray-100 disabled:cursor-not-allowed"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 553,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 549,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 565,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: tempFromDate || "",
                  max: tempToDate || currentMonth,
                  onChange: (e) => setTempFromDate(e.target.value),
                  disabled: loading,
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 h-11 disabled:bg-gray-100 disabled:cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 568,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 564,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 578,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: tempToDate || "",
                  min: tempFromDate || "",
                  max: currentMonth,
                  onChange: (e) => setTempToDate(e.target.value),
                  disabled: loading,
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 h-11 disabled:bg-gray-100 disabled:cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 581,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 577,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 563,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: " " }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 596,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: applyFilter,
                disabled: loading,
                className: "w-full h-11 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-semibold shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2",
                children: loading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 606,
                    columnNumber: 23
                  }, this),
                  "Loading..."
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 605,
                  columnNumber: 19
                }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  "Continue",
                  /* @__PURE__ */ jsxDEV(FaArrowRight, { className: "text-sm" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                    lineNumber: 612,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 610,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 599,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 595,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 496,
          columnNumber: 13
        }, this),
        reportLoaded && selectedEmployeeDetails?.name && /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 border border-green-200 rounded-xl p-4 mb-6", children: /* @__PURE__ */ jsxDEV("p", { className: "text-green-700 font-medium", children: [
          "Incentive report generated successfully for",
          " ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-green-900", children: selectedEmployeeDetails.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 623,
            columnNumber: 19
          }, this),
          " ",
          "for",
          " ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-green-900", children: dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${selectedMonth}-01`)).toLocaleString("default", {
            month: "long",
            year: "numeric"
          }) : `${new Date(fromDate).toLocaleDateString()} - ${new Date(
            toDate
          ).toLocaleDateString()}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 627,
            columnNumber: 19
          }, this),
          "."
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 621,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 620,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
        lineNumber: 489,
        columnNumber: 11
      }, this),
      agentLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
        lineNumber: 645,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
        lineNumber: 644,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        isFiltering && (dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate) && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg border border-gray-100 p-6 mb-8 hover:shadow-xl transition-shadow", children: [
          selectedEmployeeDetails && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-50 rounded-xl", children: /* @__PURE__ */ jsxDEV(FaTrophy, { className: "text-blue-500 text-xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 659,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 658,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-semibold text-gray-800", children: "Employee Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 661,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 657,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "group", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-500 uppercase tracking-wider", children: "Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 667,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 px-4 py-2.5 bg-gradient-to-r from-gray-50 to-blue-50/30 border border-gray-200 rounded-xl text-gray-900 font-medium group-hover:border-blue-200 transition-colors", children: selectedEmployeeDetails?.name || "-" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 670,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 666,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "group", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-500 uppercase tracking-wider", children: "Email" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 675,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 px-4 py-2.5 bg-gradient-to-r from-gray-50 to-blue-50/30 border border-gray-200 rounded-xl text-gray-900 font-medium group-hover:border-blue-200 transition-colors", children: selectedEmployeeDetails?.email || "-" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 678,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 674,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "group", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-500 uppercase tracking-wider", children: "Phone" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 683,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 px-4 py-2.5 bg-gradient-to-r from-gray-50 to-blue-50/30 border border-gray-200 rounded-xl text-gray-900 font-medium group-hover:border-blue-200 transition-colors", children: selectedEmployeeDetails?.phone_number || "-" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 686,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 682,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 665,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("hr", { className: "my-6 border-gray-200" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 691,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 656,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxDEV(
                SummaryCard,
                {
                  icon: FaBullseye,
                  title: "Target",
                  value: summary.totalTarget,
                  color: "text-blue-700",
                  bgColor: "from-blue-50 to-blue-100/30",
                  borderColor: "border-blue-200",
                  textColor: "text-blue-700",
                  iconBgColor: "bg-blue-100"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 698,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                SummaryCard,
                {
                  icon: FaUserPlus,
                  title: "Current Business",
                  value: summary.totalCurrentEnrolls,
                  color: "text-green-700",
                  bgColor: "from-green-50 to-green-100/30",
                  borderColor: "border-green-200",
                  textColor: "text-green-700",
                  iconBgColor: "bg-green-100"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 709,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(EligibilityCard, { eligible: summary.eligibleForSalary }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 721,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 697,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV(
                SummaryCard,
                {
                  icon: FaHistory,
                  title: "Carry Forward Business",
                  value: summary.totalPreviousEnrolls,
                  color: "text-amber-700",
                  bgColor: "from-amber-50 to-amber-100/30",
                  borderColor: "border-amber-200",
                  textColor: "text-amber-700",
                  iconBgColor: "bg-amber-100"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 726,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                SummaryCard,
                {
                  icon: FaCoins,
                  title: "Total Incentive",
                  value: summary.incentive,
                  color: "text-purple-700",
                  bgColor: "from-purple-50 to-purple-100/30",
                  borderColor: "border-purple-200",
                  textColor: "text-purple-700",
                  iconBgColor: "bg-purple-100"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                  lineNumber: 737,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 725,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 695,
            columnNumber: 21
          }, this),
          note && !loading && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 bg-blue-50 border border-blue-200 rounded-xl p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxDEV(FaInfoCircle, { className: "text-blue-500 mt-0.5 flex-shrink-0" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 754,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-blue-700", children: "Note:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 756,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-700 mt-0.5", children: note }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
                lineNumber: 759,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
              lineNumber: 755,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 753,
            columnNumber: 25
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 752,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 654,
          columnNumber: 13
        }, this),
        loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 772,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 771,
          columnNumber: 13
        }, this) : incentiveData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: incentiveData,
            columns,
            exportedPdfName: `Salary Incentive Report`,
            printHeaderKeys: [
              "Employee Name",
              "Phone Number",
              "Period",
              "Total Target",
              "Current Business",
              "Carry Forward Business",
              "Total Incentive",
              "Eligible for Salary"
            ],
            printHeaderValues: [
              selectedEmployeeDetails?.name || "-",
              selectedEmployeeDetails?.phone_number || "-",
              dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate ? dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${selectedMonth}-01`)).toLocaleString(
                "default",
                {
                  month: "long",
                  year: "numeric"
                }
              ) : `${new Date(fromDate).toLocaleDateString()} - ${new Date(toDate).toLocaleDateString()}` : "-",
              `₹${summary.totalTarget?.toLocaleString("en-IN") || "0"}`,
              `₹${summary.totalCurrentEnrolls?.toLocaleString("en-IN") || "0"}`,
              `₹${summary.totalPreviousEnrolls?.toLocaleString("en-IN") || "0"}`,
              `₹${summary.incentive?.toLocaleString("en-IN") || "0"}`,
              summary.eligibleForSalary ? "Yes" : "No "
            ],
            exportedFileName: `SalaryIncentiveReport-${selectedEmployeeDetails?.name || "employee"}-${dateSelectionMode === "month" ? selectedMonth : `${fromDate}_to_${toDate}`}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 776,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 775,
          columnNumber: 13
        }, this) : isFiltering && (dateSelectionMode === "month" && selectedMonth || dateSelectionMode === "date-range" && fromDate && toDate) && selectedEmployeeDetails?.name && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg border border-gray-100 p-16 text-center hover:shadow-xl transition-shadow", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg font-medium", children: "No incentive data found for the selected period." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 823,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400 text-sm mt-2", children: "Try adjusting your filters or select a different employee." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
            lineNumber: 826,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
          lineNumber: 822,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
        lineNumber: 648,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
      lineNumber: 471,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
    lineNumber: 469,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx",
    lineNumber: 468,
    columnNumber: 5
  }, this);
}
_s(TargetIncentiveNewReport, "6Pabbw7cRQFr5rSW/wu0RTNZErE=");
_c = TargetIncentiveNewReport;
export default TargetIncentiveNewReport;
var _c;
$RefreshReg$(_c, "TargetIncentiveNewReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetIncentiveNewReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUpzQixTQWlhTixVQWphTTsyQkFqSnRCO0FBQWdCQSxNQUFXQyxjQUFRLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEQsU0FBU0MsUUFBUUMsT0FBT0MsWUFBWTtBQUNwQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLDJCQUEyQjtBQUNwQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQywrQkFBK0I7QUFFeEMsTUFBTSxFQUFFQyxRQUFRLElBQUluQjtBQUVwQixTQUFTb0IsMkJBQTJCO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUkxQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDMkIsb0JBQW9CQyxxQkFBcUIsSUFBSTVCLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUM2QixlQUFlQyxnQkFBZ0IsSUFBSTlCLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUMrQixtQkFBbUJDLG9CQUFvQixJQUFJaEMsU0FBUyxPQUFPO0FBQ2xFLFFBQU0sQ0FBQ2lDLGNBQWNDLGVBQWUsSUFBSWxDLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNtQyx5QkFBeUJDLDBCQUEwQixJQUFJcEMsU0FBUyxJQUFJO0FBQzNFLFFBQU0sQ0FBQ3FDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3VDLFNBQVNDLFVBQVUsSUFBSXhDLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUN5QyxTQUFTQyxVQUFVLElBQUkxQyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDMkMsV0FBV0MsWUFBWSxJQUFJNUMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzZDLFVBQVVDLFdBQVcsSUFBSTlDLFNBQVMsSUFBSTtBQUM3QyxRQUFNLENBQUMrQyxRQUFRQyxTQUFTLElBQUloRCxTQUFTLElBQUk7QUFDekMsUUFBTSxDQUFDaUQsYUFBYUMsY0FBYyxJQUFJbEQsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ21ELG1CQUFtQkMsb0JBQW9CLElBQUlwRCxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDcUQsY0FBY0MsZUFBZSxJQUFJdEQsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ3VELFlBQVlDLGFBQWEsSUFBSXhELFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUN5RCxNQUFNQyxPQUFPLElBQUkxRCxTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDMkQsaUJBQWlCQyxrQkFBa0IsSUFBSTVELFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUM2RCxjQUFjQyxlQUFlLElBQUk5RCxTQUFTLEtBQUs7QUFFdEQsUUFBTSxDQUFDK0QsU0FBU0MsVUFBVSxJQUFJaEUsU0FBUztBQUFBLElBQ3JDaUUsbUJBQW1CO0FBQUEsSUFDbkJDLGFBQWE7QUFBQSxJQUNiQyxXQUFXO0FBQUEsSUFDWEMscUJBQXFCO0FBQUEsSUFDckJDLHNCQUFzQjtBQUFBLElBQ3RCQyxzQkFBc0I7QUFBQSxFQUN4QixDQUFDO0FBRUQsUUFBTUMsY0FBY0EsQ0FBQ0MsUUFDbkJDLFdBQVdELEtBQUtFLFNBQVMsRUFBRUMsUUFBUSxjQUFjLEVBQUUsQ0FBQyxLQUFLO0FBRTNENUUsWUFBVSxNQUFNO0FBQ2QsVUFBTTZFLFNBQVEsb0JBQUlDLEtBQUs7QUFDdkIsVUFBTUMsZ0JBQWUsR0FBR0YsT0FBTUcsWUFBWSxDQUFDLElBQUlDO0FBQUFBLE1BQzdDSixPQUFNSyxTQUFTLElBQUk7QUFBQSxJQUNyQixFQUFFQyxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ2xCOUIseUJBQXFCMEIsYUFBWTtBQUNqQ2hELHFCQUFpQmdELGFBQVk7QUFDN0IsVUFBTUssT0FBT1AsT0FBTUcsWUFBWTtBQUMvQixVQUFNSyxRQUFRUixPQUFNSyxTQUFTLElBQUk7QUFDakMsVUFBTUksV0FBVyxHQUFHRixJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUMxRCxVQUFNSSxXQUFXLElBQUlULEtBQUtNLE1BQU1DLE9BQU8sQ0FBQyxFQUFFRyxRQUFRO0FBQ2xELFVBQU1DLFVBQVUsR0FBR0wsSUFBSSxJQUFJQyxLQUFLLElBQUlKLE9BQU9NLFFBQVEsRUFBRUosU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUNyRTVCLG9CQUFnQitCLFFBQVE7QUFDeEI3QixrQkFBY2dDLE9BQU87QUFDckIxQyxnQkFBWXVDLFFBQVE7QUFDcEJyQyxjQUFVd0MsT0FBTztBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMekYsWUFBVSxNQUFNO0FBQ2QsVUFBTTBGLE9BQU9DLEtBQUtDLE1BQU1DLGFBQWFDLFFBQVEsTUFBTSxDQUFDO0FBQ3BELFFBQUlKLE1BQU07QUFDUi9DLGlCQUFXK0MsS0FBS0ssR0FBRztBQUNuQmxELG1CQUFhNkMsS0FBS00sUUFBUSxFQUFFO0FBQUEsSUFDOUI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU03RixJQUFJOEYsSUFBSSxXQUFXO0FBQ3JDeEUsbUJBQWF1RSxLQUFLRSxNQUFNQyxRQUFRO0FBQUEsSUFDbEMsU0FBU0MsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDZCQUE2QkYsR0FBRztBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUVBLFFBQU1HLDZCQUE2QixPQUFPQyxZQUFZQyxXQUFXQyxZQUFZO0FBRTNFN0Msb0JBQWdCLEtBQUs7QUFDckIsUUFBSSxDQUFDMkMsY0FBYyxDQUFDQyxhQUFhLENBQUNDLFFBQVM7QUFDM0MsVUFBTUMsa0JBQWtCLElBQUlDLGdCQUFnQjtBQUM1QyxRQUFJO0FBQ0YsVUFBSUMsU0FBUztBQUFBLFFBQ1hDLFlBQVlMO0FBQUFBLFFBQ1pNLFVBQVVMO0FBQUFBLE1BQ1o7QUFDQSxZQUFNVixNQUFNLE1BQU03RixJQUFJOEY7QUFBQUEsUUFDcEIsOEJBQThCTyxVQUFVO0FBQUEsUUFDeEM7QUFBQSxVQUNFSztBQUFBQSxVQUNBRyxRQUFRTCxnQkFBZ0JLO0FBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUVBLFVBQUloQixJQUFJRSxLQUFLZSxTQUFTO0FBQ3BCLGNBQU0sRUFBRWYsS0FBSyxJQUFJRixJQUFJRTtBQUdyQnpDLGdCQUFReUMsS0FBSzFDLFFBQVEsRUFBRTtBQUV2Qk8sbUJBQVc7QUFBQSxVQUNUQyxtQkFBbUJrQyxLQUFLbEMscUJBQXFCO0FBQUEsVUFDN0NDLGFBQWFpQyxLQUFLakMsZUFBZTtBQUFBLFVBQ2pDQyxXQUFXZ0MsS0FBS2hDLGFBQWE7QUFBQSxVQUM3QkMscUJBQXFCK0IsS0FBSy9CLHVCQUF1QjtBQUFBLFVBQ2pEQyxzQkFBc0I4QixLQUFLOUIsd0JBQXdCO0FBQUEsVUFDbkRDLHVCQUNHNkIsS0FBSy9CLHVCQUF1QixNQUFNK0IsS0FBSzlCLHdCQUF3QjtBQUFBLFFBQ3BFLENBQUM7QUFFRCxjQUFNOEMsZ0JBQWdCO0FBRXRCLFlBQUloQixLQUFLOUQsaUJBQWlCOEQsS0FBSzlELGNBQWMrRSxTQUFTLEdBQUc7QUFDdkRqQixlQUFLOUQsY0FBY2dGLFFBQVEsQ0FBQ0MsU0FBUztBQUNuQyxnQkFBSUEsS0FBS0MsbUJBQW1CRCxLQUFLQyxnQkFBZ0JILFNBQVMsR0FBRztBQUMzREUsbUJBQUtDLGdCQUFnQkYsUUFBUSxDQUFDRyxXQUFXO0FBQ3ZDTCw4QkFBY00sS0FBSztBQUFBLGtCQUNqQkMsV0FBV0YsT0FBT0csU0FBU0MsYUFBYTtBQUFBLGtCQUN4Q0MsY0FBY0wsT0FBT0csU0FBU0UsZ0JBQWdCO0FBQUEsa0JBQzlDQyxZQUFZTixPQUFPTyxVQUFVRCxjQUFjO0FBQUEsa0JBQzNDRSxhQUFhUixPQUFPTyxVQUFVQyxlQUFlO0FBQUEsa0JBQzdDQyxpQkFBaUJULE9BQU9PLFVBQVVHLGNBQWM7QUFBQSxrQkFDaERDLGNBQWNYLE9BQU9ZLFdBQVc7QUFBQSxrQkFDaENDLGlCQUFpQmIsT0FBT2MsV0FBV0MsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLO0FBQUEsa0JBQ3REQyxtQkFBbUJoQixPQUFPZ0IscUJBQXFCO0FBQUEsa0JBQy9DQyxnQkFBZ0JqQixRQUFRa0Isb0JBQW9CO0FBQUEsa0JBQzVDQyxVQUFVbkIsUUFBUW1CLFdBQ2hCLHVCQUFDLFVBQUssV0FBVSwrSEFDZDtBQUFBLDJDQUFDLGlCQUFjLFdBQVUsb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsb0JBQUc7QUFBQSx1QkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQSxJQUVBLHVCQUFDLFVBQUssV0FBVSwySEFDZDtBQUFBLDJDQUFDLGlCQUFjLFdBQVUsa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVDO0FBQUEsb0JBQUc7QUFBQSx1QkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUVGQyxxQkFDRXBCLE9BQU9PLFVBQVVhLHVCQUF1QjtBQUFBLGtCQUMxQ0MsYUFBYXJCLE9BQU9xQixlQUFlO0FBQUEsa0JBRW5DQyxhQUNFLHVCQUFDLFVBQUssV0FBVSwrSEFDZDtBQUFBLDJDQUFDLFVBQUssV0FBVSx1Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Q7QUFBQSxvQkFBTztBQUFBLHVCQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBRUZDLG1CQUFtQjtBQUFBLGdCQUNyQixDQUFDO0FBQUEsY0FDSCxDQUFDO0FBQUEsWUFDSDtBQUVBLGdCQUFJekIsS0FBSzBCLG9CQUFvQjFCLEtBQUswQixpQkFBaUI1QixTQUFTLEdBQUc7QUFDN0RFLG1CQUFLMEIsaUJBQWlCM0IsUUFBUSxDQUFDRyxXQUFXO0FBQ3hDTCw4QkFBY00sS0FBSztBQUFBLGtCQUNqQkMsV0FBV0YsT0FBT0csU0FBU0MsYUFBYTtBQUFBLGtCQUN4Q0MsY0FBY0wsT0FBT0csU0FBU0UsZ0JBQWdCO0FBQUEsa0JBQzlDQyxZQUFZTixPQUFPTyxVQUFVRCxjQUFjO0FBQUEsa0JBQzNDRSxhQUFhUixPQUFPTyxVQUFVQyxlQUFlO0FBQUEsa0JBQzdDQyxpQkFBaUJULE9BQU9PLFVBQVVHLGNBQWM7QUFBQSxrQkFDaERDLGNBQWNYLE9BQU9ZLFdBQVc7QUFBQSxrQkFDaENDLGlCQUFpQmIsT0FBT2MsV0FBV0MsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLO0FBQUEsa0JBQ3REQyxtQkFBbUJoQixPQUFPZ0IscUJBQXFCO0FBQUEsa0JBQy9DQyxnQkFBZ0JqQixRQUFRa0Isb0JBQW9CO0FBQUEsa0JBQzVDQyxVQUFVbkIsUUFBUW1CLFdBQ2hCLHVCQUFDLFVBQUssV0FBVSwrSEFDZDtBQUFBLDJDQUFDLGlCQUFjLFdBQVUsb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsb0JBQUc7QUFBQSx1QkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQSxJQUVBLHVCQUFDLFVBQUssV0FBVSwySEFDZDtBQUFBLDJDQUFDLGlCQUFjLFdBQVUsa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVDO0FBQUEsb0JBQUc7QUFBQSx1QkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUVGQyxxQkFDRXBCLE9BQU9PLFVBQVVhLHVCQUF1QjtBQUFBLGtCQUMxQ0MsYUFBYXJCLE9BQU9xQixlQUFlO0FBQUEsa0JBQ25DQyxhQUNFLHVCQUFDLFVBQUssV0FBVSwrSEFDZDtBQUFBLDJDQUFDLGFBQVUsV0FBVSxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUM7QUFBQSxvQkFBRztBQUFBLHVCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBRUZDLG1CQUFtQjtBQUFBLGdCQUNyQixDQUFDO0FBQUEsY0FDSCxDQUFDO0FBQUEsWUFDSDtBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFFQXpHLHlCQUFpQjZFLGFBQWE7QUFFOUJyRCx3QkFBZ0IsSUFBSTtBQUdwQkYsMkJBQW1CO0FBQUEsVUFDakJxRixjQUFjOUcseUJBQXlCNEQsUUFBUTtBQUFBLFVBQy9DbUQsYUFBYS9HLHlCQUF5QjBGLGdCQUFnQjtBQUFBLFVBQ3REc0IsUUFDRXBILHNCQUFzQixXQUNsQixvQkFBSThDLEtBQUssR0FBR2hELGFBQWEsS0FBSyxHQUFFdUgsZUFBZSxXQUFXO0FBQUEsWUFDMURoRSxPQUFPO0FBQUEsWUFDUEQsTUFBTTtBQUFBLFVBQ1IsQ0FBQyxJQUNDLEdBQUcsSUFBSU4sS0FBS2hDLFFBQVEsRUFBRXdHLG1CQUFtQixDQUFDLE1BQU0sSUFBSXhFO0FBQUFBLFlBQ3BEOUI7QUFBQUEsVUFDRixFQUFFc0csbUJBQW1CLENBQUM7QUFBQSxRQUM1QixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU2hELEtBQUs7QUFDWixVQUFJQSxJQUFJTixTQUFTLG1CQUFtQjtBQUNsQ08sZ0JBQVFDLE1BQU0sMkNBQTJDRixHQUFHO0FBQzVEL0QseUJBQWlCLEVBQUU7QUFDbkIwQixtQkFBVztBQUFBLFVBQ1RDLG1CQUFtQjtBQUFBLFVBQ25CQyxhQUFhO0FBQUEsVUFDYkMsV0FBVztBQUFBLFVBQ1hDLHFCQUFxQjtBQUFBLFVBQ3JCQyxzQkFBc0I7QUFBQSxVQUN0QkMsc0JBQXNCO0FBQUEsUUFDeEIsQ0FBQztBQUNEWixnQkFBUSxFQUFFO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTTRGLHVCQUF1QkEsQ0FBQ0MsVUFBVTtBQUN0QzNILDBCQUFzQjJILEtBQUs7QUFDM0JuSCwrQkFBMkIsSUFBSTtBQUMvQkUscUJBQWlCLEVBQUU7QUFDbkJvQixZQUFRLEVBQUU7QUFDVkUsdUJBQW1CLElBQUk7QUFDdkJJLGVBQVc7QUFBQSxNQUNUQyxtQkFBbUI7QUFBQSxNQUNuQkMsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxNQUNYQyxxQkFBcUI7QUFBQSxNQUNyQkMsc0JBQXNCO0FBQUEsTUFDdEJDLHNCQUFzQjtBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTWtGLHdCQUF3QkEsQ0FBQ0MsTUFBTTtBQUNuQyxVQUFNNUgsaUJBQWdCNEgsRUFBRUMsT0FBT0g7QUFDL0JuRyx5QkFBcUJ2QixjQUFhO0FBQ2xDLFFBQUlBLGdCQUFlO0FBQ2pCLFlBQU0sQ0FBQ3NELE1BQU1DLEtBQUssSUFBSXZELGVBQWMwRyxNQUFNLEdBQUc7QUFDN0MsWUFBTWxELFdBQVcsR0FBR0YsSUFBSSxJQUFJQyxLQUFLO0FBQ2pDLFlBQU1FLFdBQVcsSUFBSVQsS0FBS00sTUFBTUMsT0FBTyxDQUFDLEVBQUVHLFFBQVE7QUFDbEQsWUFBTUMsVUFBVSxHQUFHTCxJQUFJLElBQUlDLEtBQUssSUFBSUosT0FBT00sUUFBUSxFQUFFSixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3JFNUIsc0JBQWdCK0IsUUFBUTtBQUN4QjdCLG9CQUFjZ0MsT0FBTztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU1tRSxjQUFjLFlBQVk7QUFDOUIsUUFBSSxDQUFDaEksb0JBQW9CO0FBQ3ZCaUksWUFBTSw0QkFBNEI7QUFDbEM7QUFBQSxJQUNGO0FBQ0EsUUFBSTdILHNCQUFzQixXQUFXLENBQUNvQixtQkFBbUI7QUFDdkR5RyxZQUFNLHdCQUF3QjtBQUM5QjtBQUFBLElBQ0Y7QUFDQSxRQUFJN0gsc0JBQXNCLGlCQUFpQixDQUFDc0IsZ0JBQWdCLENBQUNFLGFBQWE7QUFDeEVxRyxZQUFNLHVDQUF1QztBQUM3QztBQUFBLElBQ0Y7QUFDQTFHLG1CQUFlLElBQUk7QUFDbkIsUUFBSXdELFdBQVdDO0FBQ2YsUUFBSTVFLHNCQUFzQixTQUFTO0FBQ2pDRCx1QkFBaUJxQixpQkFBaUI7QUFDbEMsWUFBTSxDQUFDZ0MsTUFBTUMsS0FBSyxJQUFJakMsa0JBQWtCb0YsTUFBTSxHQUFHO0FBQ2pEN0Isa0JBQVksR0FBR3ZCLElBQUksSUFBSUMsS0FBSztBQUM1QixZQUFNSSxVQUFVLElBQUlYLEtBQUtNLE1BQU1DLE9BQU8sQ0FBQyxFQUFFRyxRQUFRO0FBQ2pEb0IsZ0JBQVUsR0FBR3hCLElBQUksSUFBSUMsS0FBSyxJQUFJSixPQUFPUSxPQUFPLEVBQUVOLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDOURwQyxrQkFBWTRELFNBQVM7QUFDckIxRCxnQkFBVTJELE9BQU87QUFBQSxJQUNuQixPQUFPO0FBQ0xELGtCQUFZckQ7QUFDWnNELGdCQUFVcEQ7QUFDVlQsa0JBQVk0RCxTQUFTO0FBQ3JCMUQsZ0JBQVUyRCxPQUFPO0FBQUEsSUFDbkI7QUFDQW5FLGVBQVcsSUFBSTtBQUNmTixvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0YsWUFBTTJILE1BQU1wSSxVQUFVcUksS0FBSyxDQUFDTCxNQUFNQSxFQUFFM0QsUUFBUW5FLGtCQUFrQjtBQUM5RFMsaUNBQTJCeUgsT0FBTyxJQUFJO0FBQ3RDLFlBQU1yRCwyQkFBMkI3RSxvQkFBb0IrRSxXQUFXQyxPQUFPO0FBQUEsSUFDekUsVUFBQztBQUNDekUsc0JBQWdCLEtBQUs7QUFDckJNLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQXpDLFlBQVUsTUFBTTtBQUNkaUcsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNK0QsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxhQUFhQyxRQUFRLGdCQUFnQjtBQUFBLElBQzVDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLFlBQVk7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsY0FBYztBQUFBLElBQzVDO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDWCxVQUFVQSxTQUFTO0FBQUEsSUFDOUI7QUFBQSxJQUNBO0FBQUEsTUFDRVMsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDWCxVQUFXQSxRQUFRLFFBQVE7QUFBQSxJQUN0QztBQUFBLElBQ0EsRUFBRVMsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGNBQWM7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLHVCQUF1QkMsUUFBUSxvQkFBb0I7QUFBQSxJQUMxRCxFQUFFRCxLQUFLLHFCQUFxQkMsUUFBUSxhQUFhO0FBQUEsRUFBQztBQUdwRCxRQUFNckYsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxlQUFlLEdBQUdGLE1BQU1HLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxJQUM3Q0osTUFBTUssU0FBUyxJQUFJO0FBQUEsRUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUdsQixRQUFNaUYsa0JBQWtCQSxDQUFDLEVBQUVDLFNBQVMsTUFDbEM7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVcsd0ZBQXdGQSxXQUMvRiw4R0FDQSxrRkFBa0Y7QUFBQSxNQUl0RjtBQUFBLCtCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx5RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLFNBQUksV0FBVSwwRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLGFBRnhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLGtCQUFrQkEsV0FBVyxpQkFBaUIsYUFBYTtBQUFBLGdCQUdyRUEscUJBQ0MsdUJBQUMsaUJBQWMsTUFBTSxJQUFJLFdBQVUsb0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1ELElBRW5ELHVCQUFDLDJCQUF3QixNQUFNLElBQUksV0FBVSxtQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEQ7QUFBQTtBQUFBLGNBUGhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsNERBQTJELGtDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ1pBLHFCQUNDLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0Msd0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUsMENBQXlDLDRCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUNBLFdBQ0MsdUJBQUMsU0FBSSxXQUFVLHVJQUNiO0FBQUEscUNBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsY0FDN0IsdUJBQUMsVUFBSyxXQUFVLCtCQUE4Qix3QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxjQUN0RCx1QkFBQyxTQUFJLFdBQVUsb0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxpQkFIbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx1SUFDYjtBQUFBLHFDQUFDLDJCQUF3QixXQUFVLGFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDNUMsdUJBQUMsVUFBSyxXQUFVLCtCQUE4Qix1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxpQkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFHQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyxzQ0FBc0NBLFdBQzdDLGlDQUNBLGdDQUFnQztBQUFBLGNBR3BDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcsdUJBQXVCQSxXQUFXLG1CQUFtQixpQkFBaUI7QUFBQSxrQkFHaEZBLHFCQUNHLDBDQUNBO0FBQUE7QUFBQSxnQkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBO0FBQUEsWUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQTtBQUFBLGFBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2REE7QUFBQTtBQUFBO0FBQUEsSUF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMEVBO0FBSUYsUUFBTUMsY0FBY0EsQ0FBQztBQUFBLElBQ25CQyxNQUFNQztBQUFBQSxJQUNOQztBQUFBQSxJQUNBakI7QUFBQUEsSUFDQWtCO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDO0FBQUFBLEVBQ0YsTUFDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVywyQkFBMkJILE9BQU8sV0FBV0MsV0FBVztBQUFBLE1BRW5FLGlDQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcscUJBQXFCQyxTQUFTO0FBQUEsY0FFekM7QUFBQSx1Q0FBQyxRQUFLLFdBQVcsR0FBR0EsU0FBUyxjQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QztBQUFBLGdCQUN2Q0o7QUFBQUE7QUFBQUE7QUFBQUEsWUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFXLDJCQUEyQkksU0FBUyxTQUFTO0FBQUE7QUFBQSxZQUN2RHJCLE9BQU9ILGVBQWUsT0FBTyxLQUFLO0FBQUEsZUFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsV0FBV3dCLFNBQVM7QUFBQSxjQUU5Qm5LLDhCQUFvQjhJLFNBQVMsQ0FBQztBQUFBO0FBQUEsWUFIakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVcsR0FBR3NCLFdBQVc7QUFBQSxZQUV6QixpQ0FBQyxRQUFLLFdBQVcsR0FBR0QsU0FBUyxlQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBO0FBQUEsVUFIM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSUE7QUFBQSxXQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUE7QUFBQSxJQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUEwQkE7QUFHRixTQUNFLHVCQUFDLFNBQUksV0FBVSxrQ0FDYixpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFDekIsdUJBQUMsU0FBSSxXQUFVLGlCQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLDREQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsK0lBQThJLG1CQUE5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsc0ZBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsb0dBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0VBQ1o7QUFBQSxpQ0FBQyxlQUFZLFdBQVUsbUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFBRztBQUFBLGFBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCwrQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPakosc0JBQXNCbUo7QUFBQUEsZ0JBQzdCLFVBQVV4QjtBQUFBQSxnQkFDVjtBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixhQUFZO0FBQUEsZ0JBQ1osY0FBYyxDQUFDeUIsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0p2RyxTQUFTLEVBQ1R3RyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPLEVBQUVFLFFBQVEsT0FBTztBQUFBLGdCQUN4QixXQUFVO0FBQUEsZ0JBQ1YsVUFBVTdJO0FBQUFBLGdCQUVUZCxvQkFBVTRKO0FBQUFBLGtCQUFJLENBQUN4QixRQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxJQUFJL0QsS0FDckMrRDtBQUFBQSx3QkFBSTlEO0FBQUFBLG9CQUFLO0FBQUEsb0JBQUk4RCxJQUFJaEM7QUFBQUEsdUJBREFnQyxJQUFJL0QsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFxQkE7QUFBQSxlQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw4QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsY0FBQyxNQUFNO0FBQUEsY0FBTjtBQUFBLGdCQUNDLE9BQU8vRDtBQUFBQSxnQkFDUCxVQUFVLENBQUMwSCxNQUFNekgscUJBQXFCeUgsRUFBRUMsT0FBT0gsS0FBSztBQUFBLGdCQUNwRCxVQUFVaEg7QUFBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxTQUFNLE9BQU0sU0FBUSxXQUFVLFdBQVUscUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFNLE9BQU0sY0FBYSxXQUFVLFdBQVUscUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBR0NSLHNCQUFzQixVQUNyQix1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELDRCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPb0IscUJBQXFCO0FBQUEsZ0JBQzVCLEtBQUsyQjtBQUFBQSxnQkFDTCxVQUFVMEU7QUFBQUEsZ0JBQ1YsVUFBVWpIO0FBQUFBLGdCQUNWLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTTRLO0FBQUEsZUFWOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQSxJQUVBLG1DQUNFO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGtEQUFpRCx5QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9jLGdCQUFnQjtBQUFBLGtCQUN2QixLQUFLRSxjQUFjdUI7QUFBQUEsa0JBQ25CLFVBQVUsQ0FBQzJFLE1BQU1uRyxnQkFBZ0JtRyxFQUFFQyxPQUFPSCxLQUFLO0FBQUEsa0JBQy9DLFVBQVVoSDtBQUFBQSxrQkFDVixXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNNEs7QUFBQSxpQkFWOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGtEQUFpRCx1QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9nQixjQUFjO0FBQUEsa0JBQ3JCLEtBQUtGLGdCQUFnQjtBQUFBLGtCQUNyQixLQUFLeUI7QUFBQUEsa0JBQ0wsVUFBVSxDQUFDMkUsTUFBTWpHLGNBQWNpRyxFQUFFQyxPQUFPSCxLQUFLO0FBQUEsa0JBQzdDLFVBQVVoSDtBQUFBQSxrQkFDVixXQUFVO0FBQUE7QUFBQSxnQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPNEs7QUFBQSxpQkFYOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLGVBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUFJRix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELGlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNvSDtBQUFBQSxnQkFDVCxVQUFVcEg7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUVUQSxvQkFDQyxtQ0FDRTtBQUFBLHlDQUFDLFVBQUssV0FBVSwrRkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEc7QUFBQSxrQkFBTztBQUFBLHFCQURySDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBLElBRUEsbUNBQUU7QUFBQTtBQUFBLGtCQUVBLHVCQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxxQkFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBO0FBQUEsY0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFnQkE7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLGFBeEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5SEE7QUFBQSxRQUVDc0IsZ0JBQWdCMUIseUJBQXlCNEQsUUFDeEMsdUJBQUMsU0FBSSxXQUFVLDJEQUNiLGlDQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFVBQ0k7QUFBQSxVQUM1Qyx1QkFBQyxVQUFLLFdBQVUsNEJBQ2I1RCxrQ0FBd0I0RCxRQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFBUTtBQUFBLFVBQUk7QUFBQSxVQUNSO0FBQUEsVUFDSix1QkFBQyxVQUFLLFdBQVUsNEJBQ2JoRSxnQ0FBc0IsV0FDbkIsb0JBQUk4QyxLQUFLLEdBQUdoRCxhQUFhLEtBQUssR0FBRXVILGVBQWUsV0FBVztBQUFBLFlBQzFEaEUsT0FBTztBQUFBLFlBQ1BELE1BQU07QUFBQSxVQUNSLENBQUMsSUFDQyxHQUFHLElBQUlOLEtBQUtoQyxRQUFRLEVBQUV3RyxtQkFBbUIsQ0FBQyxNQUFNLElBQUl4RTtBQUFBQSxZQUNwRDlCO0FBQUFBLFVBQ0YsRUFBRXNHLG1CQUFtQixDQUFDLE1BUjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUFPO0FBQUEsYUFmVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxXQXRKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0pBO0FBQUEsTUFFQ3BILGVBQ0MsdUJBQUMsU0FBSSxXQUFVLDZCQUNiLGlDQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFFQSxtQ0FFR2dCO0FBQUFBLHdCQUNHbEIsc0JBQXNCLFdBQVdGLGlCQUNoQ0Usc0JBQXNCLGdCQUFnQmMsWUFBWUUsV0FDckRaLDJCQUNFLHVCQUFDLFNBQUksV0FBVSxvR0FDWkE7QUFBQUEscUNBQ0MsbUNBQ0U7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLG9DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0VBQStELG9CQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDBLQUNaQSxtQ0FBeUI0RCxRQUFRLE9BRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnRUFBK0QscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEtBQ1o1RCxtQ0FBeUJtSixTQUFTLE9BRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnRUFBK0QscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEtBQ1puSixtQ0FBeUIwRixnQkFBZ0IsT0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSwwQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLGVBbkN0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9DQTtBQUFBLFVBR0YsdUJBQUMsU0FBSSxXQUFVLGtCQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTW5IO0FBQUFBLGtCQUNOLE9BQU07QUFBQSxrQkFDTixPQUFPcUQsUUFBUUc7QUFBQUEsa0JBQ2YsT0FBTTtBQUFBLGtCQUNOLFNBQVE7QUFBQSxrQkFDUixhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQTtBQUFBLGdCQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVEyQjtBQUFBLGNBRzNCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU12RDtBQUFBQSxrQkFDTixPQUFNO0FBQUEsa0JBQ04sT0FBT29ELFFBQVFLO0FBQUFBLGtCQUNmLE9BQU07QUFBQSxrQkFDTixTQUFRO0FBQUEsa0JBQ1IsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNEI7QUFBQSxjQUk1Qix1QkFBQyxtQkFBZ0IsVUFBVUwsUUFBUUUscUJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFEO0FBQUEsaUJBeEJ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTXJEO0FBQUFBLGtCQUNOLE9BQU07QUFBQSxrQkFDTixPQUFPbUQsUUFBUU07QUFBQUEsa0JBQ2YsT0FBTTtBQUFBLGtCQUNOLFNBQVE7QUFBQSxrQkFDUixhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQTtBQUFBLGdCQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVE0QjtBQUFBLGNBRzVCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU14RDtBQUFBQSxrQkFDTixPQUFNO0FBQUEsa0JBQ04sT0FBT2tELFFBQVFJO0FBQUFBLGtCQUNmLE9BQU07QUFBQSxrQkFDTixTQUFRO0FBQUEsa0JBQ1IsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNkI7QUFBQSxpQkFwQi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsZUFwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxREE7QUFBQSxVQUdDVixRQUFRLENBQUNsQixXQUNSLHVCQUFDLFNBQUksV0FBVSx5REFDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxtQ0FBQyxnQkFBYSxXQUFVLHdDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RDtBQUFBLFlBQzVELHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsdUNBQXNDLHFCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQ1ZrQixrQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQTlHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0hBO0FBQUEsUUFJSGxCLFVBQ0MsdUJBQUMsU0FBSSxXQUFVLDZCQUNiLGlDQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDRUYsY0FBYytFLFNBQVMsSUFDekIsdUJBQUMsU0FBSSxXQUFVLDJHQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNL0U7QUFBQUEsWUFDTjtBQUFBLFlBQ0EsaUJBQWlCO0FBQUEsWUFDakIsaUJBQWlCO0FBQUEsY0FDZjtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUFxQjtBQUFBLFlBRXZCLG1CQUFtQjtBQUFBLGNBQ2pCRix5QkFBeUI0RCxRQUFRO0FBQUEsY0FDakM1RCx5QkFBeUIwRixnQkFBZ0I7QUFBQSxjQUN4QzlGLHNCQUFzQixXQUFXRixpQkFDL0JFLHNCQUFzQixnQkFBZ0JjLFlBQVlFLFNBQ2pEaEIsc0JBQXNCLFdBQ3BCLG9CQUFJOEMsS0FBSyxHQUFHaEQsYUFBYSxLQUFLLEdBQUV1SDtBQUFBQSxnQkFDaEM7QUFBQSxnQkFDQTtBQUFBLGtCQUNFaEUsT0FBTztBQUFBLGtCQUNQRCxNQUFNO0FBQUEsZ0JBQ1I7QUFBQSxjQUNGLElBQ0UsR0FBRyxJQUFJTixLQUFLaEMsUUFBUSxFQUFFd0csbUJBQW1CLENBQUMsTUFBTSxJQUFJeEUsS0FBSzlCLE1BQU0sRUFBRXNHLG1CQUFtQixDQUFDLEtBQ3ZGO0FBQUEsY0FDSixJQUFJdEYsUUFBUUcsYUFBYWtGLGVBQWUsT0FBTyxLQUFLLEdBQUc7QUFBQSxjQUN2RCxJQUFJckYsUUFBUUsscUJBQXFCZ0YsZUFBZSxPQUFPLEtBQUssR0FBRztBQUFBLGNBQy9ELElBQUlyRixRQUFRTSxzQkFBc0IrRSxlQUFlLE9BQU8sS0FBSyxHQUFHO0FBQUEsY0FDaEUsSUFBSXJGLFFBQVFJLFdBQVdpRixlQUFlLE9BQU8sS0FBSyxHQUFHO0FBQUEsY0FDckRyRixRQUFRRSxvQkFBb0IsUUFBUTtBQUFBLFlBQUs7QUFBQSxZQUUzQyxrQkFBa0IseUJBQXlCOUIseUJBQXlCNEQsUUFBUSxVQUFVLElBQUloRSxzQkFBc0IsVUFDNUdGLGdCQUNBLEdBQUdnQixRQUFRLE9BQU9FLE1BQU0sRUFBRTtBQUFBO0FBQUEsVUFyQ2hDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXNDVyxLQXZDYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBLElBRUFFLGdCQUNFbEIsc0JBQXNCLFdBQVdGLGlCQUNoQ0Usc0JBQXNCLGdCQUFnQmMsWUFBWUUsV0FDckRaLHlCQUF5QjRELFFBQ3ZCLHVCQUFDLFNBQUksV0FBVSw0R0FDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsZ0VBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsMEVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBckxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3TEE7QUFBQSxTQXpXSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMldBO0FBQUEsT0E3V0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThXQSxLQS9XRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ1hBO0FBRUo7QUFBQ3ZFLEdBNXlCUUQsMEJBQXdCO0FBQUFnSyxLQUF4QmhLO0FBOHlCVCxlQUFlQTtBQUF5QixJQUFBZ0s7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2VsZWN0IiwiUmFkaW8iLCJUYWJzIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJOYXZiYXIiLCJHaVBhcnR5UG9wcGVyIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkZhQnVsbHNleWUiLCJGYVVzZXJQbHVzIiwiRmFIaXN0b3J5IiwiRmFDb2lucyIsIkZhQ2hlY2tDaXJjbGUiLCJGYVRpbWVzQ2lyY2xlIiwiRmFBcnJvd1JpZ2h0IiwiRmFDaGFydExpbmUiLCJGYVRyb3BoeSIsIkZhUm9ja2V0IiwiRmFJbmZvQ2lyY2xlIiwiTWRPdXRsaW5lUGVuZGluZ0FjdGlvbnMiLCJUYWJQYW5lIiwiVGFyZ2V0SW5jZW50aXZlTmV3UmVwb3J0IiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJzZWxlY3RlZEVtcGxveWVlSWQiLCJzZXRTZWxlY3RlZEVtcGxveWVlSWQiLCJzZWxlY3RlZE1vbnRoIiwic2V0U2VsZWN0ZWRNb250aCIsImRhdGVTZWxlY3Rpb25Nb2RlIiwic2V0RGF0ZVNlbGVjdGlvbk1vZGUiLCJhZ2VudExvYWRpbmciLCJzZXRBZ2VudExvYWRpbmciLCJzZWxlY3RlZEVtcGxveWVlRGV0YWlscyIsInNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzIiwiaW5jZW50aXZlRGF0YSIsInNldEluY2VudGl2ZURhdGEiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImFkbWluSWQiLCJzZXRBZG1pbklkIiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImlzRmlsdGVyaW5nIiwic2V0SXNGaWx0ZXJpbmciLCJ0ZW1wU2VsZWN0ZWRNb250aCIsInNldFRlbXBTZWxlY3RlZE1vbnRoIiwidGVtcEZyb21EYXRlIiwic2V0VGVtcEZyb21EYXRlIiwidGVtcFRvRGF0ZSIsInNldFRlbXBUb0RhdGUiLCJub3RlIiwic2V0Tm90ZSIsImxhc3RGZXRjaGVkSW5mbyIsInNldExhc3RGZXRjaGVkSW5mbyIsInJlcG9ydExvYWRlZCIsInNldFJlcG9ydExvYWRlZCIsInN1bW1hcnkiLCJzZXRTdW1tYXJ5IiwiZWxpZ2libGVGb3JTYWxhcnkiLCJ0b3RhbFRhcmdldCIsImluY2VudGl2ZSIsInRvdGFsQ3VycmVudEVucm9sbHMiLCJ0b3RhbFByZXZpb3VzRW5yb2xscyIsInRvdGFsQ29tYmluZWRFbnJvbGxzIiwicGFyc2VBbW91bnQiLCJ2YWwiLCJwYXJzZUZsb2F0IiwidG9TdHJpbmciLCJyZXBsYWNlIiwidG9kYXkiLCJEYXRlIiwiY3VycmVudE1vbnRoIiwiZ2V0RnVsbFllYXIiLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwieWVhciIsIm1vbnRoIiwiZmlyc3REYXkiLCJsYXN0ZGF5MSIsImdldERhdGUiLCJsYXN0RGF5IiwidXNlciIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJfaWQiLCJuYW1lIiwiZmV0Y2hFbXBsb3llZXMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmZXRjaFNhbGFyeUluY2VudGl2ZVJlcG9ydCIsImVtcGxveWVlSWQiLCJzdGFydERhdGUiLCJlbmREYXRlIiwiYWJvcnRDb250cm9sbGVyIiwiQWJvcnRDb250cm9sbGVyIiwicGFyYW1zIiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwic2lnbmFsIiwic3VjY2VzcyIsInByb2Nlc3NlZERhdGEiLCJsZW5ndGgiLCJmb3JFYWNoIiwiaXRlbSIsImN1cnJlbnRfZW5yb2xscyIsImVucm9sbCIsInB1c2giLCJ1c2VyX25hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfbmFtZSIsImdyb3VwX2lkIiwiZ3JvdXBfdmFsdWUiLCJncm91cF9pbmNlbnRpdmUiLCJpbmNlbnRpdmVzIiwiZ3JvdXBfdGlja2V0IiwidGlja2V0cyIsImVucm9sbG1lbnRfZGF0ZSIsImNyZWF0ZWRBdCIsInNwbGl0IiwidG90YWxfcGFpZF9hbW91bnQiLCJidXNpbmVzc192YWx1ZSIsImRpZmZfZ3JvdXBfdmFsdWUiLCJ1cGdyYWRlZCIsIm1vbnRobHlfaW5zdGFsbG1lbnQiLCJlbnJvbGxfY29kZSIsImVucm9sbF90eXBlIiwiZW5yb2xsX3R5cGVfYmFkZ2UiLCJwcmV2aW91c19lbnJvbGxzIiwiZW1wbG95ZWVOYW1lIiwicGhvbmVOdW1iZXIiLCJwZXJpb2QiLCJ0b0xvY2FsZVN0cmluZyIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImhhbmRsZUVtcGxveWVlQ2hhbmdlIiwidmFsdWUiLCJoYW5kbGVUZW1wTW9udGhDaGFuZ2UiLCJlIiwidGFyZ2V0IiwiYXBwbHlGaWx0ZXIiLCJhbGVydCIsImVtcCIsImZpbmQiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwicmVuZGVyIiwiRWxpZ2liaWxpdHlDYXJkIiwiZWxpZ2libGUiLCJTdW1tYXJ5Q2FyZCIsImljb24iLCJJY29uIiwidGl0bGUiLCJjb2xvciIsImJnQ29sb3IiLCJib3JkZXJDb2xvciIsInRleHRDb2xvciIsImljb25CZ0NvbG9yIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJoZWlnaHQiLCJtYXAiLCJlbWFpbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRhcmdldEluY2VudGl2ZU5ld1JlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBSYWRpbywgVGFicyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IEdpUGFydHlQb3BwZXIgfSBmcm9tIFwicmVhY3QtaWNvbnMvZ2lcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IHtcclxuICBGYUJ1bGxzZXllLFxyXG4gIEZhVXNlclBsdXMsXHJcbiAgRmFIaXN0b3J5LFxyXG4gIEZhQ29pbnMsXHJcbiAgRmFDaGVja0NpcmNsZSxcclxuICBGYVRpbWVzQ2lyY2xlLFxyXG4gIEZhQXJyb3dSaWdodCxcclxuICBGYUNoYXJ0TGluZSxcclxuICBGYVRyb3BoeSxcclxuICBGYVJvY2tldCxcclxuICBGYUluZm9DaXJjbGUsXHJcbn0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IE1kT3V0bGluZVBlbmRpbmdBY3Rpb25zIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcblxyXG5jb25zdCB7IFRhYlBhbmUgfSA9IFRhYnM7XHJcblxyXG5mdW5jdGlvbiBUYXJnZXRJbmNlbnRpdmVOZXdSZXBvcnQoKSB7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZUlkLCBzZXRTZWxlY3RlZEVtcGxveWVlSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkTW9udGgsIHNldFNlbGVjdGVkTW9udGhdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2RhdGVTZWxlY3Rpb25Nb2RlLCBzZXREYXRlU2VsZWN0aW9uTW9kZV0gPSB1c2VTdGF0ZShcIm1vbnRoXCIpO1xyXG4gIGNvbnN0IFthZ2VudExvYWRpbmcsIHNldEFnZW50TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLCBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaW5jZW50aXZlRGF0YSwgc2V0SW5jZW50aXZlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbklkLCBzZXRBZG1pbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNGaWx0ZXJpbmcsIHNldElzRmlsdGVyaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdGVtcFNlbGVjdGVkTW9udGgsIHNldFRlbXBTZWxlY3RlZE1vbnRoXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0ZW1wRnJvbURhdGUsIHNldFRlbXBGcm9tRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdGVtcFRvRGF0ZSwgc2V0VGVtcFRvRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbm90ZSwgc2V0Tm90ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbGFzdEZldGNoZWRJbmZvLCBzZXRMYXN0RmV0Y2hlZEluZm9dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JlcG9ydExvYWRlZCwgc2V0UmVwb3J0TG9hZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW3N1bW1hcnksIHNldFN1bW1hcnldID0gdXNlU3RhdGUoe1xyXG4gICAgZWxpZ2libGVGb3JTYWxhcnk6IGZhbHNlLFxyXG4gICAgdG90YWxUYXJnZXQ6IDAsXHJcbiAgICBpbmNlbnRpdmU6IDAsXHJcbiAgICB0b3RhbEN1cnJlbnRFbnJvbGxzOiAwLFxyXG4gICAgdG90YWxQcmV2aW91c0Vucm9sbHM6IDAsXHJcbiAgICB0b3RhbENvbWJpbmVkRW5yb2xsczogMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcGFyc2VBbW91bnQgPSAodmFsKSA9PlxyXG4gICAgcGFyc2VGbG9hdCh2YWw/LnRvU3RyaW5nKCkucmVwbGFjZSgvW14wLTkuLV0rL2csIFwiXCIpKSB8fCAwO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgY3VycmVudE1vbnRoID0gYCR7dG9kYXkuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcoXHJcbiAgICAgIHRvZGF5LmdldE1vbnRoKCkgKyAxLFxyXG4gICAgKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgIHNldFRlbXBTZWxlY3RlZE1vbnRoKGN1cnJlbnRNb250aCk7XHJcbiAgICBzZXRTZWxlY3RlZE1vbnRoKGN1cnJlbnRNb250aCk7XHJcbiAgICBjb25zdCB5ZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gdG9kYXkuZ2V0TW9udGgoKSArIDE7XHJcbiAgICBjb25zdCBmaXJzdERheSA9IGAke3llYXJ9LSR7U3RyaW5nKG1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LTAxYDtcclxuICAgIGNvbnN0IGxhc3RkYXkxID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuICAgIGNvbnN0IGxhc3REYXkgPSBgJHt5ZWFyfS0ke21vbnRofS0ke1N0cmluZyhsYXN0ZGF5MSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgICBzZXRUZW1wRnJvbURhdGUoZmlyc3REYXkpO1xyXG4gICAgc2V0VGVtcFRvRGF0ZShsYXN0RGF5KTtcclxuICAgIHNldEZyb21EYXRlKGZpcnN0RGF5KTtcclxuICAgIHNldFRvRGF0ZShsYXN0RGF5KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIikpO1xyXG4gICAgaWYgKHVzZXIpIHtcclxuICAgICAgc2V0QWRtaW5JZCh1c2VyLl9pZCk7XHJcbiAgICAgIHNldEFkbWluTmFtZSh1c2VyLm5hbWUgfHwgXCJcIik7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICAgIHNldEVtcGxveWVlcyhyZXM/LmRhdGE/LmVtcGxveWVlKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzOlwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoU2FsYXJ5SW5jZW50aXZlUmVwb3J0ID0gYXN5bmMgKGVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSkgPT4ge1xyXG5cclxuICAgIHNldFJlcG9ydExvYWRlZChmYWxzZSk7XHJcbiAgICBpZiAoIWVtcGxveWVlSWQgfHwgIXN0YXJ0RGF0ZSB8fCAhZW5kRGF0ZSkgcmV0dXJuO1xyXG4gICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBzdGFydF9kYXRlOiBzdGFydERhdGUsXHJcbiAgICAgICAgZW5kX2RhdGU6IGVuZERhdGUsXHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC92MS9hZG1pbi9lbnJvbGxzL2VtcGxveWVlLyR7ZW1wbG95ZWVJZH0vc2FsYXJ5LWluY2VudGl2ZXNgLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBhcmFtcyxcclxuICAgICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgICB9LFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlcy5kYXRhLnN1Y2Nlc3MpIHtcclxuICAgICAgICBjb25zdCB7IGRhdGEgfSA9IHJlcy5kYXRhO1xyXG5cclxuICAgICAgICAvLyBTZXQgbm90ZSBmcm9tIEFQSSByZXNwb25zZVxyXG4gICAgICAgIHNldE5vdGUoZGF0YS5ub3RlIHx8IFwiXCIpO1xyXG5cclxuICAgICAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgICAgIGVsaWdpYmxlRm9yU2FsYXJ5OiBkYXRhLmVsaWdpYmxlRm9yU2FsYXJ5IHx8IGZhbHNlLFxyXG4gICAgICAgICAgdG90YWxUYXJnZXQ6IGRhdGEudG90YWxUYXJnZXQgfHwgMCxcclxuICAgICAgICAgIGluY2VudGl2ZTogZGF0YS5pbmNlbnRpdmUgfHwgMCxcclxuICAgICAgICAgIHRvdGFsQ3VycmVudEVucm9sbHM6IGRhdGEudG90YWxDdXJyZW50RW5yb2xscyB8fCAwLFxyXG4gICAgICAgICAgdG90YWxQcmV2aW91c0Vucm9sbHM6IGRhdGEudG90YWxQcmV2aW91c0Vucm9sbHMgfHwgMCxcclxuICAgICAgICAgIHRvdGFsQ29tYmluZWRFbnJvbGxzOlxyXG4gICAgICAgICAgICAoZGF0YS50b3RhbEN1cnJlbnRFbnJvbGxzIHx8IDApICsgKGRhdGEudG90YWxQcmV2aW91c0Vucm9sbHMgfHwgMCksXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHByb2Nlc3NlZERhdGEgPSBbXTtcclxuXHJcbiAgICAgICAgaWYgKGRhdGEuaW5jZW50aXZlRGF0YSAmJiBkYXRhLmluY2VudGl2ZURhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgZGF0YS5pbmNlbnRpdmVEYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgaWYgKGl0ZW0uY3VycmVudF9lbnJvbGxzICYmIGl0ZW0uY3VycmVudF9lbnJvbGxzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICBpdGVtLmN1cnJlbnRfZW5yb2xscy5mb3JFYWNoKChlbnJvbGwpID0+IHtcclxuICAgICAgICAgICAgICAgIHByb2Nlc3NlZERhdGEucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgIHVzZXJfbmFtZTogZW5yb2xsLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGVucm9sbC51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZW5yb2xsLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwX3ZhbHVlOiBlbnJvbGwuZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwX2luY2VudGl2ZTogZW5yb2xsLmdyb3VwX2lkPy5pbmNlbnRpdmVzIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwX3RpY2tldDogZW5yb2xsLnRpY2tldHMgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgZW5yb2xsbWVudF9kYXRlOiBlbnJvbGwuY3JlYXRlZEF0Py5zcGxpdChcIlRcIik/LlswXSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICB0b3RhbF9wYWlkX2Ftb3VudDogZW5yb2xsLnRvdGFsX3BhaWRfYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgIGJ1c2luZXNzX3ZhbHVlOiBlbnJvbGw/LmRpZmZfZ3JvdXBfdmFsdWUgPz8gMCxcclxuICAgICAgICAgICAgICAgICAgdXBncmFkZWQ6IGVucm9sbD8udXBncmFkZWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAgdGV4dC14cyBmb250LXNlbWlib2xkIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RmFDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBZZXNcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYVRpbWVzQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOb1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgbW9udGhseV9pbnN0YWxsbWVudDpcclxuICAgICAgICAgICAgICAgICAgICBlbnJvbGwuZ3JvdXBfaWQ/Lm1vbnRobHlfaW5zdGFsbG1lbnQgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgZW5yb2xsX2NvZGU6IGVucm9sbC5lbnJvbGxfY29kZSB8fCBcIk4vQVwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgZW5yb2xsX3R5cGU6IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1cnJlbnRcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgIGVucm9sbF90eXBlX2JhZGdlOiBcImN1cnJlbnRcIixcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoaXRlbS5wcmV2aW91c19lbnJvbGxzICYmIGl0ZW0ucHJldmlvdXNfZW5yb2xscy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgaXRlbS5wcmV2aW91c19lbnJvbGxzLmZvckVhY2goKGVucm9sbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcHJvY2Vzc2VkRGF0YS5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgdXNlcl9uYW1lOiBlbnJvbGwudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgIHBob25lX251bWJlcjogZW5yb2xsLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICBncm91cF9uYW1lOiBlbnJvbGwuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBfdmFsdWU6IGVucm9sbC5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBfaW5jZW50aXZlOiBlbnJvbGwuZ3JvdXBfaWQ/LmluY2VudGl2ZXMgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBfdGlja2V0OiBlbnJvbGwudGlja2V0cyB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICBlbnJvbGxtZW50X2RhdGU6IGVucm9sbC5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKT8uWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiBlbnJvbGwudG90YWxfcGFpZF9hbW91bnQgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgYnVzaW5lc3NfdmFsdWU6IGVucm9sbD8uZGlmZl9ncm91cF92YWx1ZSA/PyAwLFxyXG4gICAgICAgICAgICAgICAgICB1cGdyYWRlZDogZW5yb2xsPy51cGdyYWRlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYUNoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIFllc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJnLXJlZC0xMDAgdGV4dC1yZWQtNzAwIHRleHQteHMgZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZhVGltZXNDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICBtb250aGx5X2luc3RhbGxtZW50OlxyXG4gICAgICAgICAgICAgICAgICAgIGVucm9sbC5ncm91cF9pZD8ubW9udGhseV9pbnN0YWxsbWVudCB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICBlbnJvbGxfY29kZTogZW5yb2xsLmVucm9sbF9jb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgIGVucm9sbF90eXBlOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci03MDAgdGV4dC14cyBmb250LXNlbWlib2xkIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RmFIaXN0b3J5IGNsYXNzTmFtZT1cInRleHQtYW1iZXItNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIENhcnJ5IEZvcndhcmRcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgIGVucm9sbF90eXBlX2JhZGdlOiBcInByZXZpb3VzXCIsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzZXRJbmNlbnRpdmVEYXRhKHByb2Nlc3NlZERhdGEpO1xyXG5cclxuICAgICAgICBzZXRSZXBvcnRMb2FkZWQodHJ1ZSk7XHJcblxyXG4gICAgICAgIC8vIFN0b3JlIGxhc3QgZmV0Y2hlZCBpbmZvXHJcbiAgICAgICAgc2V0TGFzdEZldGNoZWRJbmZvKHtcclxuICAgICAgICAgIGVtcGxveWVlTmFtZTogc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCJzZWxlY3RlZCBlbXBsb3llZVwiLFxyXG4gICAgICAgICAgcGhvbmVOdW1iZXI6IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBlcmlvZDpcclxuICAgICAgICAgICAgZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIlxyXG4gICAgICAgICAgICAgID8gbmV3IERhdGUoYCR7c2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcImRlZmF1bHRcIiwge1xyXG4gICAgICAgICAgICAgICAgbW9udGg6IFwibG9uZ1wiLFxyXG4gICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICA6IGAke25ldyBEYXRlKGZyb21EYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKX0gLSAke25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgdG9EYXRlLFxyXG4gICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9YCxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIubmFtZSAhPT0gXCJBYm9ydENvbnRyb2xsZXJcIikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBzYWxhcnkgaW5jZW50aXZlIHJlcG9ydDpcIiwgZXJyKTtcclxuICAgICAgICBzZXRJbmNlbnRpdmVEYXRhKFtdKTtcclxuICAgICAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgICAgIGVsaWdpYmxlRm9yU2FsYXJ5OiBmYWxzZSxcclxuICAgICAgICAgIHRvdGFsVGFyZ2V0OiAwLFxyXG4gICAgICAgICAgaW5jZW50aXZlOiAwLFxyXG4gICAgICAgICAgdG90YWxDdXJyZW50RW5yb2xsczogMCxcclxuICAgICAgICAgIHRvdGFsUHJldmlvdXNFbnJvbGxzOiAwLFxyXG4gICAgICAgICAgdG90YWxDb21iaW5lZEVucm9sbHM6IDAsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0Tm90ZShcIlwiKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUVtcGxveWVlQ2hhbmdlID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEVtcGxveWVlSWQodmFsdWUpO1xyXG4gICAgc2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHMobnVsbCk7XHJcbiAgICBzZXRJbmNlbnRpdmVEYXRhKFtdKTtcclxuICAgIHNldE5vdGUoXCJcIik7XHJcbiAgICBzZXRMYXN0RmV0Y2hlZEluZm8obnVsbCk7XHJcbiAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgZWxpZ2libGVGb3JTYWxhcnk6IGZhbHNlLFxyXG4gICAgICB0b3RhbFRhcmdldDogMCxcclxuICAgICAgaW5jZW50aXZlOiAwLFxyXG4gICAgICB0b3RhbEN1cnJlbnRFbnJvbGxzOiAwLFxyXG4gICAgICB0b3RhbFByZXZpb3VzRW5yb2xsczogMCxcclxuICAgICAgdG90YWxDb21iaW5lZEVucm9sbHM6IDAsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVUZW1wTW9udGhDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRNb250aCA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0VGVtcFNlbGVjdGVkTW9udGgoc2VsZWN0ZWRNb250aCk7XHJcbiAgICBpZiAoc2VsZWN0ZWRNb250aCkge1xyXG4gICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gc2VsZWN0ZWRNb250aC5zcGxpdChcIi1cIik7XHJcbiAgICAgIGNvbnN0IGZpcnN0RGF5ID0gYCR7eWVhcn0tJHttb250aH0tMDFgO1xyXG4gICAgICBjb25zdCBsYXN0ZGF5MSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICAgIGNvbnN0IGxhc3REYXkgPSBgJHt5ZWFyfS0ke21vbnRofS0ke1N0cmluZyhsYXN0ZGF5MSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgICAgIHNldFRlbXBGcm9tRGF0ZShmaXJzdERheSk7XHJcbiAgICAgIHNldFRlbXBUb0RhdGUobGFzdERheSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgYXBwbHlGaWx0ZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkRW1wbG95ZWVJZCkge1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgYW4gZW1wbG95ZWUuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIiAmJiAhdGVtcFNlbGVjdGVkTW9udGgpIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IGEgbW9udGguXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwiZGF0ZS1yYW5nZVwiICYmICghdGVtcEZyb21EYXRlIHx8ICF0ZW1wVG9EYXRlKSkge1xyXG4gICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgYm90aCBGcm9tIGFuZCBUbyBkYXRlcy5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldElzRmlsdGVyaW5nKHRydWUpO1xyXG4gICAgbGV0IHN0YXJ0RGF0ZSwgZW5kRGF0ZTtcclxuICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkTW9udGgodGVtcFNlbGVjdGVkTW9udGgpO1xyXG4gICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gdGVtcFNlbGVjdGVkTW9udGguc3BsaXQoXCItXCIpO1xyXG4gICAgICBzdGFydERhdGUgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbiAgICAgIGNvbnN0IGxhc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMCkuZ2V0RGF0ZSgpO1xyXG4gICAgICBlbmREYXRlID0gYCR7eWVhcn0tJHttb250aH0tJHtTdHJpbmcobGFzdERheSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgICAgIHNldEZyb21EYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgIHNldFRvRGF0ZShlbmREYXRlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHN0YXJ0RGF0ZSA9IHRlbXBGcm9tRGF0ZTtcclxuICAgICAgZW5kRGF0ZSA9IHRlbXBUb0RhdGU7XHJcbiAgICAgIHNldEZyb21EYXRlKHN0YXJ0RGF0ZSk7XHJcbiAgICAgIHNldFRvRGF0ZShlbmREYXRlKTtcclxuICAgIH1cclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRBZ2VudExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBlbXAgPSBlbXBsb3llZXMuZmluZCgoZSkgPT4gZS5faWQgPT09IHNlbGVjdGVkRW1wbG95ZWVJZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKGVtcCB8fCBudWxsKTtcclxuICAgICAgYXdhaXQgZmV0Y2hTYWxhcnlJbmNlbnRpdmVSZXBvcnQoc2VsZWN0ZWRFbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0QWdlbnRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwidXNlcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfdGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfdmFsdWVcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcImJ1c2luZXNzX3ZhbHVlXCIsXHJcbiAgICAgIGhlYWRlcjogXCJCdXNpbmVzcyBWYWx1ZVwiLFxyXG4gICAgICByZW5kZXI6ICh2YWx1ZSkgPT4gdmFsdWUgPz8gMCxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJ1cGdyYWRlZFwiLFxyXG4gICAgICBoZWFkZXI6IFwiVXBncmFkZWRcIixcclxuICAgICAgcmVuZGVyOiAodmFsdWUpID0+ICh2YWx1ZSA/IFwiWWVzXCIgOiBcIk5vXCIpLFxyXG4gICAgfSxcclxuICAgIHsga2V5OiBcImVucm9sbF90eXBlXCIsIGhlYWRlcjogXCJFbnJvbGwgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50X2RhdGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxfY29kZVwiLCBoZWFkZXI6IFwiRW5yb2xsIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfaW5jZW50aXZlXCIsIGhlYWRlcjogXCJJbmNlbnRpdmUgJVwiIH0sXHJcbiAgICB7IGtleTogXCJtb250aGx5X2luc3RhbGxtZW50XCIsIGhlYWRlcjogXCJGaXJzdCBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9wYWlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZFwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKFxyXG4gICAgdG9kYXkuZ2V0TW9udGgoKSArIDEsXHJcbiAgKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuXHJcbiAgLy8gRWxpZ2liaWxpdHkgQ2FyZCBDb21wb25lbnQgLSBFbmhhbmNlZFxyXG4gIGNvbnN0IEVsaWdpYmlsaXR5Q2FyZCA9ICh7IGVsaWdpYmxlIH0pID0+IChcclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIHAtNCBib3JkZXItMiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgaC1mdWxsICR7ZWxpZ2libGVcclxuICAgICAgICA/IFwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmVlbi01MCB2aWEtZW1lcmFsZC01MCB0by1ncmVlbi01MCBib3JkZXItZ3JlZW4tNDAwIHNoYWRvdy1tZCBzaGFkb3ctZ3JlZW4tMjAwLzUwXCJcclxuICAgICAgICA6IFwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmF5LTUwIHZpYS1zbGF0ZS01MCB0by1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCBzaGFkb3ctbWRcIlxyXG4gICAgICAgIH1gfVxyXG4gICAgPlxyXG4gICAgICB7LyogQmFja2dyb3VuZCBEZWNvcmF0aW9uICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgb3BhY2l0eS01XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctNDggaC00OCBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGJsdXItM3hsXCI+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgdy00OCBoLTQ4IGJnLWJsdWUtNTAwIHJvdW5kZWQtZnVsbCBibHVyLTN4bFwiPjwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBmbGV4LWNvbCBnYXAtMyBoLWZ1bGxcIj5cclxuICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQteGwgJHtlbGlnaWJsZSA/IFwiYmctZ3JlZW4tMTAwXCIgOiBcImJnLWdyYXktMjAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2VsaWdpYmxlID8gKFxyXG4gICAgICAgICAgICAgIDxHaVBhcnR5UG9wcGVyIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPE1kT3V0bGluZVBlbmRpbmdBY3Rpb25zIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgU2FsYXJ5IEVsaWdpYmlsaXR5XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIHtlbGlnaWJsZSA/IChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICBFbGlnaWJsZVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgTm90IEVsaWdpYmxlXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2VsaWdpYmxlID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTUwMCB0by1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIHB4LTMgcHktMSByb3VuZGVkLXhsIHNoYWRvdy1tZCBzaGFkb3ctZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgPEZhUm9ja2V0IGNsYXNzTmFtZT1cInRleHQtc21cIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZVwiPkFwcHJvdmVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgYmctd2hpdGUgcm91bmRlZC1mdWxsIGFuaW1hdGUtcGluZ1wiPjwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1ncmFkaWVudC10by1yIGZyb20tb3JhbmdlLTUwMCB0by1hbWJlci01MDAgdGV4dC13aGl0ZSBweC0zIHB5LTEgcm91bmRlZC14bCBzaGFkb3ctbWQgc2hhZG93LW9yYW5nZS0yMDBcIj5cclxuICAgICAgICAgICAgICA8TWRPdXRsaW5lUGVuZGluZ0FjdGlvbnMgY2xhc3NOYW1lPVwidGV4dC1zbVwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlXCI+UGVuZGluZzwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogTWVzc2FnZSAqL31cclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BtdC0xIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgYm9yZGVyICR7ZWxpZ2libGVcclxuICAgICAgICAgICAgPyBcImJnLXdoaXRlLzYwIGJvcmRlci1ncmVlbi0yMDBcIlxyXG4gICAgICAgICAgICA6IFwiYmctb3JhbmdlLTUwIGJvcmRlci1vcmFuZ2UtMjAwXCJcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHBcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC14cyBmb250LW1lZGl1bSAke2VsaWdpYmxlID8gXCJ0ZXh0LWdyZWVuLTcwMFwiIDogXCJ0ZXh0LW9yYW5nZS03MDBcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7ZWxpZ2libGVcclxuICAgICAgICAgICAgICA/IFwiVGFyZ2V0IGFjaGlldmVkISBFbGlnaWJsZSBmb3Igc2FsYXJ5LlwiXHJcbiAgICAgICAgICAgICAgOiBcIlRhcmdldCBub3QgeWV0IGFjaGlldmVkLiBBZGRpdGlvbmFsIGJ1c2luZXNzIHJlcXVpcmVkLlwifVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcblxyXG4gIC8vIEluZGl2aWR1YWwgU3VtbWFyeSBDYXJkIENvbXBvbmVudFxyXG4gIGNvbnN0IFN1bW1hcnlDYXJkID0gKHtcclxuICAgIGljb246IEljb24sXHJcbiAgICB0aXRsZSxcclxuICAgIHZhbHVlLFxyXG4gICAgY29sb3IsXHJcbiAgICBiZ0NvbG9yLFxyXG4gICAgYm9yZGVyQ29sb3IsXHJcbiAgICB0ZXh0Q29sb3IsXHJcbiAgICBpY29uQmdDb2xvcixcclxuICB9KSA9PiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT17YGdyb3VwIGJnLWdyYWRpZW50LXRvLWJyICR7YmdDb2xvcn0gYm9yZGVyICR7Ym9yZGVyQ29sb3J9IHJvdW5kZWQtMnhsIHAtNiBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHRyYW5zZm9ybSBob3ZlcjotdHJhbnNsYXRlLXktMSBjdXJzb3ItZGVmYXVsdGB9XHJcbiAgICA+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgPHBcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC14cyBmb250LWJvbGQgJHt0ZXh0Q29sb3J9IHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMmB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT17YCR7dGV4dENvbG9yfSB0ZXh0LXNtYH0gLz5cclxuICAgICAgICAgICAge3RpdGxlfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPXtgdGV4dC0yeGwgZm9udC1leHRyYWJvbGQgJHt0ZXh0Q29sb3J9IG10LTJgfT5cclxuICAgICAgICAgICAg4oK5e3ZhbHVlPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IFwiMFwifVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHBcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC14cyAke3RleHRDb2xvcn0gbXQtMiBmb250LW1lZGl1bSBvcGFjaXR5LTgwIHRydW5jYXRlYH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModmFsdWUgfHwgMCl9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgJHtpY29uQmdDb2xvcn0gcm91bmRlZC0yeGwgcC0zIHNoYWRvdy1pbm5lciBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT17YCR7dGV4dENvbG9yfSB0ZXh0LTJ4bGB9IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi1oLXNjcmVlbiBiZy1ncmF5LTUwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtOFwiPlxyXG4gICAgICAgICAgey8qIEhlYWRlciBTZWN0aW9uICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIENoaXQgQnVzaW5lc3MgUGVyZm9ybWFuY2UgJiBJbmNlbnRpdmUgUmVwb3J0XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgdGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAwIHRvLWVtZXJhbGQtNjAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlIHNoYWRvdy1sZyBzaGFkb3ctZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICBORVdcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG10LTJcIj5cclxuICAgICAgICAgICAgICBUcmFjayBlbXBsb3llZSBidXNpbmVzcyB0YXJnZXRzLCBhY2hpZXZlbWVudHMsIGFuZCBpbmNlbnRpdmVcclxuICAgICAgICAgICAgICBlYXJuaW5ncy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEZpbHRlciBDYXJkICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTggbWItOCBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RmFDaGFydExpbmUgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgUmVwb3J0IEZpbHRlcnNcclxuICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBBbGwgRmlsdGVyIENvbnRyb2xzIGluIE9uZSBSb3cgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNSBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgey8qIEVtcGxveWVlIFNlbGVjdCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVFbXBsb3llZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBuYW1lIG9yIHBob25lXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjQ0cHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IC0ge2VtcC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRGF0ZSBTZWxlY3Rpb24gTW9kZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIERhdGUgU2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBwLTMgYmctZ3JheS01MCByb3VuZGVkLWxnIGgtMTFcIj5cclxuICAgICAgICAgICAgICAgICAgPFJhZGlvLkdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGVTZWxlY3Rpb25Nb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGF0ZVNlbGVjdGlvbk1vZGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHZhbHVlPVwibW9udGhcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBNb250aFxyXG4gICAgICAgICAgICAgICAgICAgIDwvUmFkaW8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHZhbHVlPVwiZGF0ZS1yYW5nZVwiIGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFJhbmdlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9SYWRpbz5cclxuICAgICAgICAgICAgICAgICAgPC9SYWRpby5Hcm91cD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRGF0ZSBQaWNrZXIgRmllbGRzICovfVxyXG4gICAgICAgICAgICAgIHtkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGxnOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgTW9udGhcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFNlbGVjdGVkTW9udGggfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGVtcE1vbnRoQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGgtMTEgZGlzYWJsZWQ6YmctZ3JheS0xMDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wRnJvbURhdGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIG1heD17dGVtcFRvRGF0ZSB8fCBjdXJyZW50TW9udGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGgtMTEgZGlzYWJsZWQ6YmctZ3JheS0xMDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRvIERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBUb0RhdGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIG1pbj17dGVtcEZyb21EYXRlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGgtMTEgZGlzYWJsZWQ6YmctZ3JheS0xMDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBDb250aW51ZSBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAmbmJzcDtcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FwcGx5RmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTYwMCB0by1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6ZnJvbS1ncmVlbi03MDAgaG92ZXI6dG8tZW1lcmFsZC03MDAgdHJhbnNpdGlvbi1hbGwgZm9udC1zZW1pYm9sZCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayB3LTQgaC00IGJvcmRlci0yIGJvcmRlci13aGl0ZSBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTG9hZGluZy4uLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDb250aW51ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZhQXJyb3dSaWdodCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtyZXBvcnRMb2FkZWQgJiYgc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDAgcm91bmRlZC14bCBwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgSW5jZW50aXZlIHJlcG9ydCBnZW5lcmF0ZWQgc3VjY2Vzc2Z1bGx5IGZvcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JlZW4tOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIGZvcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JlZW4tOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoYCR7c2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcImRlZmF1bHRcIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJsb25nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgIDogYCR7bmV3IERhdGUoZnJvbURhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpfSAtICR7bmV3IERhdGUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX1gfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIC5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHthZ2VudExvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICB7LyogRW1wbG95ZWUgRGV0YWlscyAmIFN1bW1hcnkgKi99XHJcbiAgICAgICAgICAgICAge2lzRmlsdGVyaW5nICYmXHJcbiAgICAgICAgICAgICAgICAoKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgJiYgc2VsZWN0ZWRNb250aCkgfHxcclxuICAgICAgICAgICAgICAgICAgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJiBmcm9tRGF0ZSAmJiB0b0RhdGUpKSAmJlxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNiBtYi04IGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlRGV0YWlscyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ibHVlLTUwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVRyb3BoeSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIHRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRW1wbG95ZWUgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgcHgtNCBweS0yLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyYXktNTAgdG8tYmx1ZS01MC8zMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBncm91cC1ob3Zlcjpib3JkZXItYmx1ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSBweC00IHB5LTIuNSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JheS01MCB0by1ibHVlLTUwLzMwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIGdyb3VwLWhvdmVyOmJvcmRlci1ibHVlLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LmVtYWlsIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaG9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSBweC00IHB5LTIuNSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JheS01MCB0by1ibHVlLTUwLzMwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIGdyb3VwLWhvdmVyOmJvcmRlci1ibHVlLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cIm15LTYgYm9yZGVyLWdyYXktMjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBGaXJzdCBSb3cgLSBUYXJnZXQsIEN1cnJlbnQgRW5yb2xsbWVudHMsIFNhbGFyeSBFbGlnaWJpbGl0eSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3VtbWFyeUNhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uPXtGYUJ1bGxzZXllfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVGFyZ2V0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtbWFyeS50b3RhbFRhcmdldH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInRleHQtYmx1ZS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJnQ29sb3I9XCJmcm9tLWJsdWUtNTAgdG8tYmx1ZS0xMDAvMzBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yPVwiYm9yZGVyLWJsdWUtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0Q29sb3I9XCJ0ZXh0LWJsdWUtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uQmdDb2xvcj1cImJnLWJsdWUtMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdW1tYXJ5Q2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb249e0ZhVXNlclBsdXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDdXJyZW50IEJ1c2luZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtbWFyeS50b3RhbEN1cnJlbnRFbnJvbGxzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwidGV4dC1ncmVlbi03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJnQ29sb3I9XCJmcm9tLWdyZWVuLTUwIHRvLWdyZWVuLTEwMC8zMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I9XCJib3JkZXItZ3JlZW4tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0Q29sb3I9XCJ0ZXh0LWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbkJnQ29sb3I9XCJiZy1ncmVlbi0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNhbGFyeSBFbGlnaWJpbGl0eSBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RWxpZ2liaWxpdHlDYXJkIGVsaWdpYmxlPXtzdW1tYXJ5LmVsaWdpYmxlRm9yU2FsYXJ5fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFNlY29uZCBSb3cgLSBDYXJyeSBGb3J3YXJkIEVucm9sbHMgJiBUb3RhbCBJbmNlbnRpdmUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFN1bW1hcnlDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17RmFIaXN0b3J5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2FycnkgRm9yd2FyZCBCdXNpbmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnkudG90YWxQcmV2aW91c0Vucm9sbHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJ0ZXh0LWFtYmVyLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYmdDb2xvcj1cImZyb20tYW1iZXItNTAgdG8tYW1iZXItMTAwLzMwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJDb2xvcj1cImJvcmRlci1hbWJlci0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRDb2xvcj1cInRleHQtYW1iZXItNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uQmdDb2xvcj1cImJnLWFtYmVyLTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3VtbWFyeUNhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uPXtGYUNvaW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VtbWFyeS5pbmNlbnRpdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJ0ZXh0LXB1cnBsZS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJnQ29sb3I9XCJmcm9tLXB1cnBsZS01MCB0by1wdXJwbGUtMTAwLzMwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJDb2xvcj1cImJvcmRlci1wdXJwbGUtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0Q29sb3I9XCJ0ZXh0LXB1cnBsZS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb25CZ0NvbG9yPVwiYmctcHVycGxlLTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE5vdGUgU2VjdGlvbiAtIE9ubHkgc2hvdyB3aGVuIG5vdCBsb2FkaW5nIGFuZCBkYXRhIGlzIGxvYWRlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICB7bm90ZSAmJiAhbG9hZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHJvdW5kZWQteGwgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUluZm9DaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCBtdC0wLjUgZmxleC1zaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vdGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS03MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIERhdGEgVGFibGUgKi99XHJcbiAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiBpbmNlbnRpdmVEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwIG92ZXJmbG93LWhpZGRlbiBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e2luY2VudGl2ZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BTYWxhcnkgSW5jZW50aXZlIFJlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkVtcGxveWVlIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlBlcmlvZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJUb3RhbCBUYXJnZXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgIFwiQ3VycmVudCBCdXNpbmVzc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJDYXJyeSBGb3J3YXJkIEJ1c2luZXNzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIEluY2VudGl2ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJFbGlnaWJsZSBmb3IgU2FsYXJ5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgJiYgc2VsZWN0ZWRNb250aCkgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJiBmcm9tRGF0ZSAmJiB0b0RhdGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoYCR7c2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZGVmYXVsdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJsb25nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBgJHtuZXcgRGF0ZShmcm9tRGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9IC0gJHtuZXcgRGF0ZSh0b0RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgIGDigrkke3N1bW1hcnkudG90YWxUYXJnZXQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuICAgICAgICAgICAgICAgICAgICAgIGDigrkke3N1bW1hcnkudG90YWxDdXJyZW50RW5yb2xscz8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIn1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYOKCuSR7c3VtbWFyeS50b3RhbFByZXZpb3VzRW5yb2xscz8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIn1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYOKCuSR7c3VtbWFyeS5pbmNlbnRpdmU/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuICAgICAgICAgICAgICAgICAgICAgIHN1bW1hcnkuZWxpZ2libGVGb3JTYWxhcnkgPyBcIlllc1wiIDogXCJObyBcIixcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BTYWxhcnlJbmNlbnRpdmVSZXBvcnQtJHtzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSB8fCBcImVtcGxveWVlXCJ9LSR7ZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBzZWxlY3RlZE1vbnRoXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IGAke2Zyb21EYXRlfV90b18ke3RvRGF0ZX1gXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgaXNGaWx0ZXJpbmcgJiZcclxuICAgICAgICAgICAgICAgICgoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwibW9udGhcIiAmJiBzZWxlY3RlZE1vbnRoKSB8fFxyXG4gICAgICAgICAgICAgICAgICAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwiZGF0ZS1yYW5nZVwiICYmIGZyb21EYXRlICYmIHRvRGF0ZSkpICYmXHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC0xNiB0ZXh0LWNlbnRlciBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtbGcgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vIGluY2VudGl2ZSBkYXRhIGZvdW5kIGZvciB0aGUgc2VsZWN0ZWQgcGVyaW9kLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtc20gbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVHJ5IGFkanVzdGluZyB5b3VyIGZpbHRlcnMgb3Igc2VsZWN0IGEgZGlmZmVyZW50IGVtcGxveWVlLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRhcmdldEluY2VudGl2ZU5ld1JlcG9ydDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1RhcmdldEluY2VudGl2ZU5ld1JlcG9ydC5qc3gifQ==