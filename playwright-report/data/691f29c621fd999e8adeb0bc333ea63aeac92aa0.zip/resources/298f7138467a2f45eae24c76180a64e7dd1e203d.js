import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TotalRevenue.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, DatePicker, Button, Card, Row, Col, Space, Tag, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { SyncOutlined, DownloadOutlined, PrinterOutlined, FilterOutlined, CloseCircleOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const TotalRevenue = () => {
  _s();
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [isFilterVisible, setIsFilterVisible] = useState(true);
  const [groupList, setGroupList] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [paidDate, setPaidDate] = useState(null);
  const [txnDate, setTxnDate] = useState(null);
  const [paymentType, setPaymentType] = useState(null);
  const formatPayDate = (dateString) => {
    return dateString?.split("T")[0];
  };
  const fetchPayments = async (filters = {}) => {
    try {
      setLoading(true);
      const resPayments = await api.get("/payment/get-payment", {});
      let data = resPayments.data || [];
      if (filters.group) {
        data = data.filter((p) => p.group_id?._id === filters.group);
      }
      if (filters.paidDate) {
        data = data.filter((p) => formatPayDate(p.pay_date) === filters.paidDate);
      }
      if (filters.txnDate) {
        data = data.filter((p) => formatPayDate(p.createdAt) === filters.txnDate);
      }
      if (filters.paymentType) {
        data = data.filter((p) => p.pay_type === filters.paymentType);
      }
      const formattedData = data.map((p, index) => ({
        _id: p._id,
        id: index + 1,
        name: p?.user_id?.full_name,
        phone_number: p?.user_id?.phone_number,
        group_name: p?.group_id?.group_name,
        ticket: p.ticket,
        receipt: p.receipt_no,
        old_receipt: p.old_receipt_no,
        amount: p.amount,
        pay_type: p.pay_type,
        date: formatPayDate(p?.pay_date),
        transaction_date: formatPayDate(p?.createdAt),
        collected_by: p?.collected_by?.name || p?.admin_type?.admin_name || "Super Admin"
      }));
      setPayments(formattedData);
    } catch (err) {
      console.error("Error fetching total revenue ", err);
      setPayments([]);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    const fetchInitial = async () => {
      try {
        setLoading(true);
        const [resTotal, resGroups] = await Promise.all(
          [
            api.get("/payment/get-total-payment-amount"),
            api.get("/group/get-group-admin")
          ]
        );
        setTotalRevenue(resTotal.data?.totalAmount || 0);
        setGroupList(resGroups.data || []);
        fetchPayments({});
      } catch (err) {
        console.error("Error fetching initial revenue ", err);
      } finally {
        setLoading(false);
      }
    };
    fetchInitial();
  }, []);
  const handleFilterChange = () => {
    fetchPayments({
      group: selectedGroup,
      paidDate: paidDate ? paidDate.format("YYYY-MM-DD") : null,
      txnDate: txnDate ? txnDate.format("YYYY-MM-DD") : null,
      paymentType
    });
  };
  const handleClearFilters = () => {
    setSelectedGroup(null);
    setPaidDate(null);
    setTxnDate(null);
    setPaymentType(null);
    fetchPayments({});
  };
  const columns = [
    { key: "id", header: "SL. NO", width: 60 },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone" },
    { key: "group_name", header: "Group" },
    { key: "ticket", header: "Ticket #" },
    { key: "old_receipt", header: "Old Receipt" },
    { key: "receipt", header: "Receipt #" },
    { key: "amount", header: "Amount", align: "right" },
    { key: "pay_type", header: "Payment Type" },
    { key: "collected_by", header: "Collected By" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen mt-20 bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
      lineNumber: 131,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-grow", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
        lineNumber: 133,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-grow p-4 md:p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-white shadow-sm rounded-lg p-4 border-b border-gray-200", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: "Total Revenue" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 142,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-3 py-1 bg-violet-50 text-violet-700 rounded-full text-sm font-medium", children: /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-2xl", children: totalRevenue.toLocaleString() }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 145,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 143,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 141,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Refresh Data", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: /* @__PURE__ */ jsxDEV(SyncOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                    lineNumber: 153,
                    columnNumber: 27
                  }, this),
                  onClick: () => fetchPayments({}),
                  size: "large",
                  type: "text",
                  className: "text-gray-600  hover:text-violet-600"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                  lineNumber: 152,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 151,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Tooltip, { title: isFilterVisible ? "Hide Filters" : "Show Filters", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: isFilterVisible ? /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                    lineNumber: 165,
                    columnNumber: 45
                  }, this) : /* @__PURE__ */ jsxDEV(FilterOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                    lineNumber: 165,
                    columnNumber: 71
                  }, this),
                  size: "large",
                  type: "text",
                  onClick: () => setIsFilterVisible(!isFilterVisible),
                  className: `${isFilterVisible ? "text-violet-600" : "text-gray-600"} hover:text-violet-700`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                  lineNumber: 164,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 163,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 150,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
            lineNumber: 139,
            columnNumber: 13
          }, this),
          isFilterVisible && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [8, 8], className: "flex-wrap", children: [
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(
              Select,
              {
                allowClear: true,
                placeholder: "Group",
                className: "w-full",
                value: selectedGroup,
                onChange: setSelectedGroup,
                options: groupList.map((g) => ({
                  label: g.group_name,
                  value: g._id
                })),
                size: "small"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 182,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 181,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(
              DatePicker,
              {
                placeholder: "Paid Date",
                value: paidDate,
                onChange: setPaidDate,
                className: "w-full",
                size: "small"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 197,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 196,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(
              DatePicker,
              {
                placeholder: "Txn Date",
                value: txnDate,
                onChange: setTxnDate,
                className: "w-full",
                size: "small"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 207,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 206,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(
              Select,
              {
                allowClear: true,
                placeholder: "Payment Type",
                className: "w-full",
                value: paymentType,
                onChange: setPaymentType,
                options: [
                  { label: "Cash", value: "cash" },
                  { label: "Online", value: "online" },
                  { label: "Online/UPI", value: "online/upi" },
                  { label: "Cheque", value: "cheque" }
                ],
                size: "small"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                lineNumber: 217,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 216,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(Space, { children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "small",
                  type: "text",
                  onClick: handleClearFilters,
                  className: "text-gray-500 hover:text-red-500",
                  children: "Clear All"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                  lineNumber: 235,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "small",
                  type: "primary",
                  onClick: handleFilterChange,
                  loading,
                  className: "bg-violet-600 hover:bg-violet-700",
                  children: "Apply"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
                  lineNumber: 243,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 234,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
              lineNumber: 233,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
            lineNumber: 180,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
            lineNumber: 179,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this),
        loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Revenue Data" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
          lineNumber: 262,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
          lineNumber: 261,
          columnNumber: 11
        }, this) : payments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: payments,
            columns,
            exportedPdfName: "Total Revenue",
            exportedFileName: "TotalRevenue.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
            lineNumber: 265,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(Card, { className: "text-center py-12 bg-white shadow-sm rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-lg", children: "No payments found. Try adjusting your filters." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
          lineNumber: 273,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
          lineNumber: 272,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
        lineNumber: 135,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
      lineNumber: 132,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx",
    lineNumber: 130,
    columnNumber: 5
  }, this);
};
_s(TotalRevenue, "9c2egxkDDFKu7FEGpNpu7xF6qo8=");
_c = TotalRevenue;
export default TotalRevenue;
var _c;
$RefreshReg$(_c, "TotalRevenue");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TotalRevenue.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0lNOzJCQWxJTjtBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsUUFBUUMsWUFBWUMsUUFBUUMsTUFBTUMsS0FBS0MsS0FBS0MsT0FBT0MsS0FBS0MsZUFBZTtBQUNoRixTQUFTQyxjQUFjQyxrQkFBa0JDLGlCQUFpQkMsZ0JBQWdCQywyQkFBMkI7QUFFckcsTUFBTUMsZUFBZUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3pCLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJdkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3dCLFNBQVNDLFVBQVUsSUFBSXpCLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUMwQixjQUFjQyxlQUFlLElBQUkzQixTQUFTLENBQUM7QUFDbEQsUUFBTSxDQUFDNEIsaUJBQWlCQyxrQkFBa0IsSUFBSTdCLFNBQVMsSUFBSTtBQUczRCxRQUFNLENBQUM4QixXQUFXQyxZQUFZLElBQUkvQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDZ0MsZUFBZUMsZ0JBQWdCLElBQUlqQyxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDa0MsVUFBVUMsV0FBVyxJQUFJbkMsU0FBUyxJQUFJO0FBQzdDLFFBQU0sQ0FBQ29DLFNBQVNDLFVBQVUsSUFBSXJDLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNzQyxhQUFhQyxjQUFjLElBQUl2QyxTQUFTLElBQUk7QUFFbkQsUUFBTXdDLGdCQUFnQkEsQ0FBQ0MsZUFBZTtBQUNwQyxXQUFPQSxZQUFZQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDakM7QUFFQSxRQUFNQyxnQkFBZ0IsT0FBT0MsVUFBVSxDQUFDLE1BQU07QUFDNUMsUUFBSTtBQUNGbkIsaUJBQVcsSUFBSTtBQUVmLFlBQU1vQixjQUFjLE1BQU0xQyxJQUFJMkMsSUFBSSx3QkFBd0IsQ0FFMUQsQ0FBQztBQUVELFVBQUlDLE9BQU9GLFlBQVlFLFFBQVE7QUFFL0IsVUFBSUgsUUFBUUksT0FBTztBQUNqQkQsZUFBT0EsS0FBS0UsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxVQUFVQyxRQUFRUixRQUFRSSxLQUFLO0FBQUEsTUFDN0Q7QUFDQSxVQUFJSixRQUFRVixVQUFVO0FBQ3BCYSxlQUFPQSxLQUFLRSxPQUFPLENBQUNDLE1BQU1WLGNBQWNVLEVBQUVHLFFBQVEsTUFBTVQsUUFBUVYsUUFBUTtBQUFBLE1BQzFFO0FBQ0EsVUFBSVUsUUFBUVIsU0FBUztBQUNuQlcsZUFBT0EsS0FBS0UsT0FBTyxDQUFDQyxNQUFNVixjQUFjVSxFQUFFSSxTQUFTLE1BQU1WLFFBQVFSLE9BQU87QUFBQSxNQUMxRTtBQUNBLFVBQUlRLFFBQVFOLGFBQWE7QUFDdkJTLGVBQU9BLEtBQUtFLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUssYUFBYVgsUUFBUU4sV0FBVztBQUFBLE1BQzlEO0FBRUEsWUFBTWtCLGdCQUFnQlQsS0FBS1UsSUFBSSxDQUFDUCxHQUFHUSxXQUFXO0FBQUEsUUFDNUNOLEtBQUtGLEVBQUVFO0FBQUFBLFFBQ1BPLElBQUlELFFBQVE7QUFBQSxRQUNaRSxNQUFNVixHQUFHVyxTQUFTQztBQUFBQSxRQUNsQkMsY0FBY2IsR0FBR1csU0FBU0U7QUFBQUEsUUFDMUJDLFlBQVlkLEdBQUdDLFVBQVVhO0FBQUFBLFFBQ3pCQyxRQUFRZixFQUFFZTtBQUFBQSxRQUNWQyxTQUFTaEIsRUFBRWlCO0FBQUFBLFFBQ1hDLGFBQWFsQixFQUFFbUI7QUFBQUEsUUFDZkMsUUFBUXBCLEVBQUVvQjtBQUFBQSxRQUNWZixVQUFVTCxFQUFFSztBQUFBQSxRQUNaZ0IsTUFBTS9CLGNBQWNVLEdBQUdHLFFBQVE7QUFBQSxRQUMvQm1CLGtCQUFrQmhDLGNBQWNVLEdBQUdJLFNBQVM7QUFBQSxRQUM1Q21CLGNBQWN2QixHQUFHdUIsY0FBY2IsUUFBUVYsR0FBR3dCLFlBQVlDLGNBQWM7QUFBQSxNQUN0RSxFQUFFO0FBRUZwRCxrQkFBWWlDLGFBQWE7QUFBQSxJQUMzQixTQUFTb0IsS0FBSztBQUNaQyxjQUFRQyxNQUFNLGlDQUFpQ0YsR0FBRztBQUNsRHJELGtCQUFZLEVBQUU7QUFBQSxJQUNoQixVQUFDO0FBQ0NFLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQXNELFlBQVUsTUFBTTtBQUNkLFVBQU1DLGVBQWUsWUFBWTtBQUMvQixVQUFJO0FBQ0Z2RCxtQkFBVyxJQUFJO0FBRWYsY0FBTSxDQUFDd0QsVUFBVUMsU0FBUyxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUM5Q2pGLElBQUkyQyxJQUFJLG1DQUFtQztBQUFBLFlBQzNDM0MsSUFBSTJDLElBQUksd0JBQXdCO0FBQUEsVUFBQztBQUFBLFFBQ2xDO0FBRURuQix3QkFBZ0JzRCxTQUFTbEMsTUFBTXNDLGVBQWUsQ0FBQztBQUMvQ3RELHFCQUFhbUQsVUFBVW5DLFFBQVEsRUFBRTtBQUNqQ0osc0JBQWMsQ0FBQyxDQUFDO0FBQUEsTUFDbEIsU0FBU2lDLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sbUNBQW1DRixHQUFHO0FBQUEsTUFDdEQsVUFBQztBQUNDbkQsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUNBdUQsaUJBQWE7QUFBQSxFQUNmLEdBQUcsRUFBRTtBQUVMLFFBQU1NLHFCQUFxQkEsTUFBTTtBQUMvQjNDLGtCQUFjO0FBQUEsTUFDWkssT0FBT2hCO0FBQUFBLE1BQ1BFLFVBQVVBLFdBQVdBLFNBQVNxRCxPQUFPLFlBQVksSUFBSTtBQUFBLE1BQ3JEbkQsU0FBU0EsVUFBVUEsUUFBUW1ELE9BQU8sWUFBWSxJQUFJO0FBQUEsTUFDbERqRDtBQUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTWtELHFCQUFxQkEsTUFBTTtBQUMvQnZELHFCQUFpQixJQUFJO0FBQ3JCRSxnQkFBWSxJQUFJO0FBQ2hCRSxlQUFXLElBQUk7QUFDZkUsbUJBQWUsSUFBSTtBQUNuQkksa0JBQWMsQ0FBQyxDQUFDO0FBQUEsRUFDbEI7QUFFQSxRQUFNOEMsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxNQUFNQyxRQUFRLFVBQVVDLE9BQU8sR0FBRztBQUFBLElBQ3pDLEVBQUVGLEtBQUssUUFBUUMsUUFBUSxZQUFZO0FBQUEsSUFDbkMsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLFFBQVE7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsUUFBUTtBQUFBLElBQ3JDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxXQUFXO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsWUFBWTtBQUFBLElBQ3RDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxVQUFVRSxPQUFPLFFBQVE7QUFBQSxJQUNsRCxFQUFFSCxLQUFLLFlBQVlDLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxFQUFDO0FBR2pELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFFekIsdUJBQUMsVUFBSyxXQUFVLHdCQUVkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1FQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1FQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLG9DQUFtQyw2QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxjQUM5RCx1QkFBQyxTQUFJLFdBQVUsbUdBRWIsaUNBQUMsVUFBSyxXQUFVLHNCQUFzQmpFLHVCQUFhb0UsZUFBZSxLQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRSxLQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsV0FBUSxPQUFNLGdCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBYTtBQUFBLGtCQUNuQixTQUFTLE1BQU1uRCxjQUFjLENBQUMsQ0FBQztBQUFBLGtCQUMvQixNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtrRCxLQU5wRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FJQSx1QkFBQyxXQUFRLE9BQU9mLGtCQUFrQixpQkFBaUIsZ0JBQ2pEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU1BLGtCQUFrQix1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQixJQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWU7QUFBQSxrQkFDakUsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU1DLG1CQUFtQixDQUFDRCxlQUFlO0FBQUEsa0JBQ2xELFdBQVcsR0FDVEEsa0JBQWtCLG9CQUFvQixlQUFlO0FBQUE7QUFBQSxnQkFOekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTzJCLEtBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkE7QUFBQSxlQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9DQTtBQUFBLFVBR0NBLG1CQUNDLHVCQUFDLFNBQUksV0FBVSxzQ0FDYixpQ0FBQyxPQUFJLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxXQUFVLGFBQzdCO0FBQUEsbUNBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQzlCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWLE9BQU9JO0FBQUFBLGdCQUNQLFVBQVVDO0FBQUFBLGdCQUNWLFNBQVNILFVBQVUyQixJQUFJLENBQUNzQyxPQUFPO0FBQUEsa0JBQzdCQyxPQUFPRCxFQUFFL0I7QUFBQUEsa0JBQ1RpQyxPQUFPRixFQUFFM0M7QUFBQUEsZ0JBQ1gsRUFBRTtBQUFBLGdCQUNGLE1BQUs7QUFBQTtBQUFBLGNBVlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVWMsS0FYaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBRUEsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQzlCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaLE9BQU9sQjtBQUFBQSxnQkFDUCxVQUFVQztBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBO0FBQUEsY0FMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLYyxLQU5oQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksR0FDOUI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osT0FBT0M7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQTtBQUFBLGNBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS2MsS0FOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQzlCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWLE9BQU9DO0FBQUFBLGdCQUNQLFVBQVVDO0FBQUFBLGdCQUNWLFNBQVM7QUFBQSxrQkFDUCxFQUFFeUQsT0FBTyxRQUFRQyxPQUFPLE9BQU87QUFBQSxrQkFDL0IsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLFNBQVM7QUFBQSxrQkFDbkMsRUFBRUQsT0FBTyxjQUFjQyxPQUFPLGFBQWE7QUFBQSxrQkFDM0MsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLFNBQVM7QUFBQSxnQkFBQztBQUFBLGdCQUV0QyxNQUFLO0FBQUE7QUFBQSxjQVpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVljLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUM5QixpQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxTQUFTVDtBQUFBQSxrQkFDVCxXQUFVO0FBQUEsa0JBQWtDO0FBQUE7QUFBQSxnQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsU0FBU0Y7QUFBQUEsa0JBQ1Q7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBQW1DO0FBQUE7QUFBQSxnQkFML0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxlQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBFQSxLQTNFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRFQTtBQUFBLGFBdEhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3SEE7QUFBQSxRQUdDOUQsVUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsa0JBQWUsV0FBVyxNQUFNLE1BQUssa0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0QsS0FEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBQ0VGLFNBQVM0RSxTQUFTLElBQ3BCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNNUU7QUFBQUEsWUFDTjtBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxVQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJcUMsSUFHckMsdUJBQUMsUUFBSyxXQUFVLG1EQUNkLGlDQUFDLFNBQUksV0FBVSx5QkFBd0IsOERBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBN0lKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErSUE7QUFBQSxTQWxKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUpBO0FBQUEsT0FySkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNKQTtBQUVKO0FBQUVELEdBaFJJRCxjQUFZO0FBQUErRSxLQUFaL0U7QUFrUk4sZUFBZUE7QUFBYSxJQUFBK0U7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2lkZWJhciIsIk5hdmJhciIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiRGF0ZVBpY2tlciIsIkJ1dHRvbiIsIkNhcmQiLCJSb3ciLCJDb2wiLCJTcGFjZSIsIlRhZyIsIlRvb2x0aXAiLCJTeW5jT3V0bGluZWQiLCJEb3dubG9hZE91dGxpbmVkIiwiUHJpbnRlck91dGxpbmVkIiwiRmlsdGVyT3V0bGluZWQiLCJDbG9zZUNpcmNsZU91dGxpbmVkIiwiVG90YWxSZXZlbnVlIiwiX3MiLCJwYXltZW50cyIsInNldFBheW1lbnRzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJ0b3RhbFJldmVudWUiLCJzZXRUb3RhbFJldmVudWUiLCJpc0ZpbHRlclZpc2libGUiLCJzZXRJc0ZpbHRlclZpc2libGUiLCJncm91cExpc3QiLCJzZXRHcm91cExpc3QiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInBhaWREYXRlIiwic2V0UGFpZERhdGUiLCJ0eG5EYXRlIiwic2V0VHhuRGF0ZSIsInBheW1lbnRUeXBlIiwic2V0UGF5bWVudFR5cGUiLCJmb3JtYXRQYXlEYXRlIiwiZGF0ZVN0cmluZyIsInNwbGl0IiwiZmV0Y2hQYXltZW50cyIsImZpbHRlcnMiLCJyZXNQYXltZW50cyIsImdldCIsImRhdGEiLCJncm91cCIsImZpbHRlciIsInAiLCJncm91cF9pZCIsIl9pZCIsInBheV9kYXRlIiwiY3JlYXRlZEF0IiwicGF5X3R5cGUiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiaW5kZXgiLCJpZCIsIm5hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfbmFtZSIsInRpY2tldCIsInJlY2VpcHQiLCJyZWNlaXB0X25vIiwib2xkX3JlY2VpcHQiLCJvbGRfcmVjZWlwdF9ubyIsImFtb3VudCIsImRhdGUiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiY29sbGVjdGVkX2J5IiwiYWRtaW5fdHlwZSIsImFkbWluX25hbWUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJ1c2VFZmZlY3QiLCJmZXRjaEluaXRpYWwiLCJyZXNUb3RhbCIsInJlc0dyb3VwcyIsIlByb21pc2UiLCJhbGwiLCJ0b3RhbEFtb3VudCIsImhhbmRsZUZpbHRlckNoYW5nZSIsImZvcm1hdCIsImhhbmRsZUNsZWFyRmlsdGVycyIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJ3aWR0aCIsImFsaWduIiwidG9Mb2NhbGVTdHJpbmciLCJnIiwibGFiZWwiLCJ2YWx1ZSIsImxlbmd0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRvdGFsUmV2ZW51ZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEYXRlUGlja2VyLCBCdXR0b24sIENhcmQsIFJvdywgQ29sLCBTcGFjZSwgVGFnLCBUb29sdGlwIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgU3luY091dGxpbmVkLCBEb3dubG9hZE91dGxpbmVkLCBQcmludGVyT3V0bGluZWQsIEZpbHRlck91dGxpbmVkLCBDbG9zZUNpcmNsZU91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcblxyXG5jb25zdCBUb3RhbFJldmVudWUgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3BheW1lbnRzLCBzZXRQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0b3RhbFJldmVudWUsIHNldFRvdGFsUmV2ZW51ZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbaXNGaWx0ZXJWaXNpYmxlLCBzZXRJc0ZpbHRlclZpc2libGVdID0gdXNlU3RhdGUodHJ1ZSk7IC8vIFRvZ2dsZSBmaWx0ZXJzXHJcblxyXG4gIC8vIEZpbHRlcnNcclxuICBjb25zdCBbZ3JvdXBMaXN0LCBzZXRHcm91cExpc3RdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtwYWlkRGF0ZSwgc2V0UGFpZERhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3R4bkRhdGUsIHNldFR4bkRhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3BheW1lbnRUeXBlLCBzZXRQYXltZW50VHlwZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICByZXR1cm4gZGF0ZVN0cmluZz8uc3BsaXQoXCJUXCIpWzBdO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoUGF5bWVudHMgPSBhc3luYyAoZmlsdGVycyA9IHt9KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgY29uc3QgcmVzUGF5bWVudHMgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnQvZ2V0LXBheW1lbnRcIiwge1xyXG4gICAgICAgXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgbGV0IGRhdGEgPSByZXNQYXltZW50cy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgaWYgKGZpbHRlcnMuZ3JvdXApIHtcclxuICAgICAgICBkYXRhID0gZGF0YS5maWx0ZXIoKHApID0+IHAuZ3JvdXBfaWQ/Ll9pZCA9PT0gZmlsdGVycy5ncm91cCk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGZpbHRlcnMucGFpZERhdGUpIHtcclxuICAgICAgICBkYXRhID0gZGF0YS5maWx0ZXIoKHApID0+IGZvcm1hdFBheURhdGUocC5wYXlfZGF0ZSkgPT09IGZpbHRlcnMucGFpZERhdGUpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChmaWx0ZXJzLnR4bkRhdGUpIHtcclxuICAgICAgICBkYXRhID0gZGF0YS5maWx0ZXIoKHApID0+IGZvcm1hdFBheURhdGUocC5jcmVhdGVkQXQpID09PSBmaWx0ZXJzLnR4bkRhdGUpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChmaWx0ZXJzLnBheW1lbnRUeXBlKSB7XHJcbiAgICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKChwKSA9PiBwLnBheV90eXBlID09PSBmaWx0ZXJzLnBheW1lbnRUeXBlKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IGRhdGEubWFwKChwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICBfaWQ6IHAuX2lkLFxyXG4gICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgbmFtZTogcD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgIHBob25lX251bWJlcjogcD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgIGdyb3VwX25hbWU6IHA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgIHRpY2tldDogcC50aWNrZXQsXHJcbiAgICAgICAgcmVjZWlwdDogcC5yZWNlaXB0X25vLFxyXG4gICAgICAgIG9sZF9yZWNlaXB0OiBwLm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgIGFtb3VudDogcC5hbW91bnQsXHJcbiAgICAgICAgcGF5X3R5cGU6IHAucGF5X3R5cGUsXHJcbiAgICAgICAgZGF0ZTogZm9ybWF0UGF5RGF0ZShwPy5wYXlfZGF0ZSksXHJcbiAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogZm9ybWF0UGF5RGF0ZShwPy5jcmVhdGVkQXQpLFxyXG4gICAgICAgIGNvbGxlY3RlZF9ieTogcD8uY29sbGVjdGVkX2J5Py5uYW1lIHx8IHA/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHwgXCJTdXBlciBBZG1pblwiLFxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICBzZXRQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdG90YWwgcmV2ZW51ZSBcIiwgZXJyKTtcclxuICAgICAgc2V0UGF5bWVudHMoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoSW5pdGlhbCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgICBjb25zdCBbcmVzVG90YWwsIHJlc0dyb3Vwc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL3BheW1lbnQvZ2V0LXRvdGFsLXBheW1lbnQtYW1vdW50XCIpLFxyXG4gICAgICAgICAgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIiksXHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIHNldFRvdGFsUmV2ZW51ZShyZXNUb3RhbC5kYXRhPy50b3RhbEFtb3VudCB8fCAwKTtcclxuICAgICAgICBzZXRHcm91cExpc3QocmVzR3JvdXBzLmRhdGEgfHwgW10pO1xyXG4gICAgICAgIGZldGNoUGF5bWVudHMoe30pO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaW5pdGlhbCByZXZlbnVlIFwiLCBlcnIpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hJbml0aWFsKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWx0ZXJDaGFuZ2UgPSAoKSA9PiB7XHJcbiAgICBmZXRjaFBheW1lbnRzKHtcclxuICAgICAgZ3JvdXA6IHNlbGVjdGVkR3JvdXAsXHJcbiAgICAgIHBhaWREYXRlOiBwYWlkRGF0ZSA/IHBhaWREYXRlLmZvcm1hdChcIllZWVktTU0tRERcIikgOiBudWxsLFxyXG4gICAgICB0eG5EYXRlOiB0eG5EYXRlID8gdHhuRGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogbnVsbCxcclxuICAgICAgcGF5bWVudFR5cGUsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbGVhckZpbHRlcnMgPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwKG51bGwpO1xyXG4gICAgc2V0UGFpZERhdGUobnVsbCk7XHJcbiAgICBzZXRUeG5EYXRlKG51bGwpO1xyXG4gICAgc2V0UGF5bWVudFR5cGUobnVsbCk7XHJcbiAgICBmZXRjaFBheW1lbnRzKHt9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiLCB3aWR0aDogNjAgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cFwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCAjXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0XCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0XCIsIGhlYWRlcjogXCJSZWNlaXB0ICNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiwgYWxpZ246IFwicmlnaHRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0ZWRfYnlcIiwgaGVhZGVyOiBcIkNvbGxlY3RlZCBCeVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gbXQtMjAgYmctZ3JheS01MFwiPlxyXG4gICAgICA8U2lkZWJhciAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC1ncm93XCI+XHJcbiAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG5cclxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC00IG1kOnAtNlwiPlxyXG4gICAgICAgICAgey8qIFN0aWNreSBIZWFkZXIgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBiZy13aGl0ZSBzaGFkb3ctc20gcm91bmRlZC1sZyBwLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIHsvKiBUaXRsZSArIE1ldHJpYyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5Ub3RhbCBSZXZlbnVlPC9oMT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xIGJnLXZpb2xldC01MCB0ZXh0LXZpb2xldC03MDAgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LTJ4bFwiPnt0b3RhbFJldmVudWUudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiUmVmcmVzaCBEYXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBpY29uPXs8U3luY091dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZldGNoUGF5bWVudHMoe30pfVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgIGhvdmVyOnRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcblxyXG4gICAgICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT17aXNGaWx0ZXJWaXNpYmxlID8gXCJIaWRlIEZpbHRlcnNcIiA6IFwiU2hvdyBGaWx0ZXJzXCJ9PlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbj17aXNGaWx0ZXJWaXNpYmxlID8gPENsb3NlQ2lyY2xlT3V0bGluZWQgLz4gOiA8RmlsdGVyT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNGaWx0ZXJWaXNpYmxlKCFpc0ZpbHRlclZpc2libGUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpc0ZpbHRlclZpc2libGUgPyBcInRleHQtdmlvbGV0LTYwMFwiIDogXCJ0ZXh0LWdyYXktNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICB9IGhvdmVyOnRleHQtdmlvbGV0LTcwMGB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIENvbGxhcHNpYmxlIEZpbHRlcnMgKi99XHJcbiAgICAgICAgICAgIHtpc0ZpbHRlclZpc2libGUgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1s4LCA4XX0gY2xhc3NOYW1lPVwiZmxleC13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs2fSBsZz17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRHcm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2dyb3VwTGlzdC5tYXAoKGcpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBnLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBnLl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17Nn0gbGc9ezR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBhaWQgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFpZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0UGFpZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs2fSBsZz17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHhuIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3R4bkRhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0VHhuRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezZ9IGxnPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBheW1lbnQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFBheW1lbnRUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkNhc2hcIiwgdmFsdWU6IFwiY2FzaFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiT25saW5lXCIsIHZhbHVlOiBcIm9ubGluZVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiT25saW5lL1VQSVwiLCB2YWx1ZTogXCJvbmxpbmUvdXBpXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJDaGVxdWVcIiwgdmFsdWU6IFwiY2hlcXVlXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezZ9IGxnPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICA8U3BhY2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtcmVkLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENsZWFyIEFsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRmlsdGVyQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIGhvdmVyOmJnLXZpb2xldC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBcHBseVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TcGFjZT5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4gICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgaC02NFwiPlxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IGRhdGE9XCJSZXZlbnVlIERhdGFcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiBwYXltZW50cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgZGF0YT17cGF5bWVudHN9XHJcbiAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJUb3RhbCBSZXZlbnVlXCJcclxuICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiVG90YWxSZXZlbnVlLmNzdlwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMiBiZy13aGl0ZSBzaGFkb3ctc20gcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICBObyBwYXltZW50cyBmb3VuZC4gVHJ5IGFkanVzdGluZyB5b3VyIGZpbHRlcnMuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9tYWluPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUb3RhbFJldmVudWU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1RvdGFsUmV2ZW51ZS5qc3gifQ==