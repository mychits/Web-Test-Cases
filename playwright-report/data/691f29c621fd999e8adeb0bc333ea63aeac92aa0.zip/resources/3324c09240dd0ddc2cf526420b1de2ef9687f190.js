import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AgentTarget.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Dropdown, Drawer } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore, IoMdAdd, IoMdClose } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Loader from "/src/components/loaders/CircularLoader.jsx";
import { Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FileTextOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const today = /* @__PURE__ */ new Date();
const currentYear = today.getFullYear();
const currentMonth = String(today.getMonth() + 1).padStart(2, "0");
const currentYearMonth = `${currentYear}-${currentMonth}`;
function formatDate(date) {
  const year = date.getFullYear();
  const month = `0${date.getMonth() + 1}`.slice(-2);
  const day = `0${date.getDate()}`.slice(-2);
  return `${year}-${month}-${day}`;
}
const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];
const AgentTarget = () => {
  _s();
  const [selectedId, setSelectedId] = useState("all");
  const [agents, setAgents] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: ""
  });
  const [initialDataLoading, setInitialDataLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isBulkMode, setIsBulkMode] = useState(false);
  const [editTargetId, setEditTargetId] = useState(null);
  const [selectedDate, setSelectedDate] = useState(currentYearMonth);
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [reload, setReload] = useState(0);
  const [targetData, setTargetData] = useState([]);
  const [monthValues, setMonthValues] = useState({
    January: 0,
    February: 0,
    March: 0,
    April: 0,
    May: 0,
    June: 0,
    July: 0,
    August: 0,
    September: 0,
    October: 0,
    November: 0,
    December: 0
  });
  const [fetchedTargetData, setFetchedTargetData] = useState(null);
  const alertShownRef = useRef({
    agents: false,
    targets: false
  });
  const parseDate = (dateString) => {
    const [year, month] = dateString.split("-");
    return {
      year,
      month: String(parseInt(month)).padStart(2, "0"),
      monthName: monthNames[parseInt(month) - 1]
    };
  };
  const formatToYearMonth = (year, month) => {
    return `${year}-${String(month).padStart(2, "0")}`;
  };
  const getMonthDateRange = (dateString) => {
    const { year, month } = parseDate(dateString);
    const startDate = new Date(year, parseInt(month) - 1, 1);
    const endDate = new Date(year, parseInt(month), 0);
    return {
      from_date: formatDate(startDate),
      to_date: formatDate(endDate)
    };
  };
  useEffect(() => {
    const fetchData = async () => {
      setInitialDataLoading(true);
      try {
        const agentRes = await api.get("/agent/get-agent");
        const allAgents = agentRes.data || [];
        setAgents(
          allAgents.filter(
            (a) => a.agent_type === "agent" || a.agent_type === "both"
          )
        );
        alertShownRef.current.agents = false;
      } catch (err) {
        console.error("Error fetching agents:", err);
        if (!alertShownRef.current.agents) {
          setAlertConfig({
            visibility: true,
            message: "Failed to load agents",
            type: "error"
          });
          alertShownRef.current.agents = true;
          setTimeout(() => {
            alertShownRef.current.agents = false;
          }, 3e3);
        }
      } finally {
        setInitialDataLoading(false);
      }
    };
    fetchData();
  }, [reload]);
  useEffect(() => {
    const abortController = new AbortController();
    setDataLoading(true);
    const fetchTargets = async () => {
      try {
        const { from_date, to_date } = getMonthDateRange(selectedDate);
        const res = await api.get("/target/agents", {
          params: {
            from_date,
            to_date
          },
          signal: abortController.signal
        });
        if (res.data.success && res.data.summaries) {
          setTargetData(res.data.summaries);
          alertShownRef.current.targets = false;
        } else {
          setTargetData([]);
        }
      } catch (err) {
        if (err.name !== "AbortError") {
          console.error("Error fetching targets:", err);
          if (!alertShownRef.current.targets) {
            alertShownRef.current.targets = true;
            setTimeout(() => {
              alertShownRef.current.targets = false;
            }, 3e3);
          }
          setTargetData([]);
        }
      } finally {
        if (!abortController.signal.aborted) {
          setDataLoading(false);
        }
      }
    };
    if (!initialDataLoading) {
      fetchTargets();
    }
    return () => {
      abortController.abort();
    };
  }, [selectedDate, initialDataLoading, reload]);
  useEffect(() => {
    if (targetData.length > 0) {
      let filteredData = targetData;
      if (selectedId !== "all") {
        filteredData = targetData.filter(
          (item) => item.agent.id === selectedId
        );
      }
      const anyTargetExists = filteredData.some(
        (item) => item.agent.target.value !== "Not Set"
      );
      const formattedData = filteredData.map((item) => {
        const hasTarget = item.agent.target.value !== "Not Set";
        const dropdownItems = [{ key: "update", label: "Edit Target" }];
        if (!hasTarget) {
          dropdownItems.unshift({ key: "set", label: "Set Target" });
        }
        const actionDropdown = /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: dropdownItems,
              onClick: ({ key }) => {
                if (key === "set") {
                  setIsBulkMode(false);
                  setIsEditMode(false);
                  openSetDrawer(item);
                }
                if (key === "update") {
                  setIsBulkMode(false);
                  setIsEditMode(true);
                  openEditDrawer(item);
                }
              }
            },
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 241,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 223,
            columnNumber: 9
          },
          this
        );
        return {
          name: item.agent.name,
          phone_number: item.agent.phone,
          actual_business: item?.metrics?.actual_business,
          target_difference: item?.metrics?.target_difference,
          target_remaining_digits: item?.metrics?.target_remaining_digits,
          target: item.agent?.target?.value,
          action: actionDropdown,
          _item: item
        };
      });
      setTableData(formattedData);
    } else {
      setTableData([]);
    }
  }, [selectedId, targetData]);
  const fetchTargetDetails = async (item) => {
    try {
      const { year } = parseDate(selectedDate);
      const res = await api.get(`/target/agent/${item.agent.id}`, {
        params: { year }
      });
      let monthData = null;
      if (res.data && res.data.length > 0) {
        const target = res.data[0];
        monthData = target.monthData || null;
      }
      setFetchedTargetData(monthData);
      return monthData;
    } catch (err) {
      console.error("Error fetching target details:", err);
      setFetchedTargetData(null);
      return null;
    }
  };
  const openSetDrawer = async (item) => {
    setSelectedPerson(item);
    setIsEditMode(false);
    setIsBulkMode(false);
    setEditTargetId(item.agent.id);
    const monthData = await fetchTargetDetails(item);
    const monthValues2 = {
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    };
    if (monthData) {
      Object.keys(monthValues2).forEach((month) => {
        monthValues2[month] = monthData[month] || 0;
      });
    }
    setMonthValues(monthValues2);
    setDrawerVisible(true);
  };
  const openEditDrawer = async (item) => {
    setSelectedPerson(item);
    setIsEditMode(true);
    setIsBulkMode(false);
    setEditTargetId(item.agent.id);
    const monthData = await fetchTargetDetails(item);
    const monthValues2 = {
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    };
    if (monthData) {
      Object.keys(monthValues2).forEach((month) => {
        monthValues2[month] = monthData[month] || 0;
      });
    }
    setMonthValues(monthValues2);
    setDrawerVisible(true);
  };
  const openBulkDrawer = () => {
    setIsBulkMode(true);
    setIsEditMode(false);
    setDrawerVisible(true);
    setMonthValues({
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    });
  };
  const handleMonthChange = (month, value) => {
    setMonthValues((prev) => ({
      ...prev,
      [month]: value === "" ? "" : Number(value)
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { year } = parseDate(selectedDate);
      if (isBulkMode) {
        const agentIds = agents.map((a) => a._id);
        await api.patch(`/target/bulk`, {
          agentIds,
          year,
          monthValues
        });
      } else {
        await api.patch(
          `/target/agent/${editTargetId}?year=${year}`,
          monthValues
        );
      }
      setAlertConfig({
        visibility: true,
        message: isBulkMode ? "Bulk targets updated successfully" : isEditMode ? "Target updated successfully" : "Target set successfully",
        type: "success"
      });
      setDrawerVisible(false);
      setReload((prev) => prev + 1);
    } catch (err) {
      console.error("Submit failed", err);
      setAlertConfig({
        visibility: true,
        message: isBulkMode ? "Bulk update failed" : isEditMode ? "Update failed" : "Add failed",
        type: "error"
      });
    }
  };
  const getColumns = () => {
    return [
      { key: "name", header: "Name" },
      { key: "phone_number", header: "Phone Number" },
      { key: "target", header: "Target" },
      { key: "actual_business", header: "Actual Business" },
      { key: "target_difference", header: "Target Difference" },
      { key: "target_remaining_digits", header: "Target Remaining Digits" },
      { key: "action", header: "Action" }
    ];
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
        lineNumber: 444,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
        lineNumber: 445,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => {
            setAlertConfig((prev) => ({ ...prev, visibility: false }));
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 446,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-6", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 456,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Agent Targets Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 458,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: openBulkDrawer,
              className: "flex items-center bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700",
              children: [
                /* @__PURE__ */ jsxDEV(IoMdAdd, { className: "mr-2" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                  lineNumber: 463,
                  columnNumber: 15
                }, this),
                " Bulk Update Targets"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 459,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 457,
          columnNumber: 11
        }, this),
        initialDataLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(Loader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 469,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 468,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "my-6", children: /* @__PURE__ */ jsxDEV(
            Collapse,
            {
              items: [
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-base", children: "Shortcut Keys" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                    lineNumber: 479,
                    columnNumber: 19
                  }, this),
                  children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/reports/target-commission",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-blue-500 hover:text-blue-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            FaRupeeSign,
                            {
                              className: "text-blue-500",
                              size: 20
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                              lineNumber: 489,
                              columnNumber: 29
                            },
                            this
                          ),
                          "Commission Report"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                        lineNumber: 485,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/reports/target-incentive",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-blue-500 hover:text-blue-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            FileTextOutlined,
                            {
                              className: "text-blue-500",
                              size: 30
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                              lineNumber: 500,
                              columnNumber: 29
                            },
                            this
                          ),
                          "Incentive Report"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                        lineNumber: 496,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-blue-500 hover:text-blue-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(FaMoneyBill, { className: "text-blue-500", size: 30 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                            lineNumber: 511,
                            columnNumber: 29
                          }, this),
                          "Salary Payout"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                        lineNumber: 507,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                    lineNumber: 484,
                    columnNumber: 19
                  }, this)
                }
              ],
              defaultActiveKey: ["1"],
              className: "rounded-lg border border-gray-200 bg-white shadow-sm"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 474,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 473,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 flex-wrap mb-6 items-end", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Agent" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 525,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "p-2 border rounded w-full min-w-[200px]",
                  value: selectedId,
                  onChange: (e) => setSelectedId(e.target.value),
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "all", children: "All Agents" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                      lineNumber: 533,
                      columnNumber: 21
                    }, this),
                    agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent._id, children: agent.name || "Unknown Agent" }, agent._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                        lineNumber: 535,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                  lineNumber: 528,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 524,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Target Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 543,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "p-2 border rounded w-full min-w-[150px]",
                  value: selectedDate,
                  onChange: (e) => setSelectedDate(e.target.value),
                  max: formatToYearMonth(currentYear, currentMonth)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                  lineNumber: 546,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 542,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 522,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative min-h-[200px]", children: [
            dataLoading && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-white bg-opacity-70 flex items-center justify-center z-10", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-10 w-10 border-4 border-blue-600 border-t-transparent" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 559,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 558,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: tableData,
                columns: getColumns(),
                exportedPdfName: "Agent-Target-Report",
                exportedFileName: "Agent-Target-Report.csv"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 562,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 556,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 472,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
        lineNumber: 455,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
      lineNumber: 443,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { children: isBulkMode ? "Bulk Update Targets" : isEditMode ? "Edit Target" : "Set Target" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 578,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setDrawerVisible(false),
              className: "text-gray-500 hover:text-gray-700",
              children: /* @__PURE__ */ jsxDEV(IoMdClose, { size: 20 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 589,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 585,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 577,
          columnNumber: 9
        }, this),
        placement: "right",
        closable: false,
        onClose: () => setDrawerVisible(false),
        open: drawerVisible,
        width: 500,
        className: "target-drawer",
        styles: {
          body: {
            padding: 0,
            overflow: "hidden"
          },
          header: {
            borderBottom: "1px solid #f0f0f0",
            padding: "16px 24px"
          }
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
          !isBulkMode && selectedPerson && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Target For" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 614,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: selectedPerson.agent.name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 615,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 613,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Year" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 623,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: parseDate(selectedDate).year }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 624,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 622,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 629,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: parseDate(selectedDate).monthName }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 630,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 628,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 621,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: monthNames.map(
            (month) => /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: month }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 639,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                  lineNumber: 641,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    value: monthValues[month],
                    onChange: (e) => handleMonthChange(month, e.target.value),
                    className: "w-full p-2 border rounded",
                    min: "0",
                    placeholder: `Enter ${month} target`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                    lineNumber: 642,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 640,
                columnNumber: 19
              }, this),
              monthValues[month] > 0 && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 mt-1 italic", children: numberToIndianWords(monthValues[month]) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
                lineNumber: 652,
                columnNumber: 17
              }, this)
            ] }, month, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 638,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
            lineNumber: 636,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700 mt-6",
              children: isBulkMode ? "Update All Targets" : isEditMode ? "Update Target" : "Save Target"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
              lineNumber: 660,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 611,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
          lineNumber: 610,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
        lineNumber: 575,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx",
    lineNumber: 442,
    columnNumber: 5
  }, this);
};
_s(AgentTarget, "InB/WiCopYdehAXa5XES/U6UU4M=");
_c = AgentTarget;
export default AgentTarget;
var _c;
$RefreshReg$(_c, "AgentTarget");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentTarget.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1BZLFNBdU9BLFVBdk9BOzJCQWhQWjtBQUFvQkEsb0JBQWdCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFVBQVVDLFNBQVNDLGlCQUFpQjtBQUM3QyxPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyx3QkFBdUI7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDJCQUEyQjtBQUVwQyxTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsTUFBTUMsY0FBY0YsTUFBTUcsWUFBWTtBQUN0QyxNQUFNQyxlQUFlQyxPQUFPTCxNQUFNTSxTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUNqRSxNQUFNQyxtQkFBbUIsR0FBR04sV0FBVyxJQUFJRSxZQUFZO0FBRXZELFNBQVNLLFdBQVdDLE1BQU07QUFDeEIsUUFBTUMsT0FBT0QsS0FBS1AsWUFBWTtBQUM5QixRQUFNUyxRQUFRLElBQUlGLEtBQUtKLFNBQVMsSUFBSSxDQUFDLEdBQUdPLE1BQU0sRUFBRTtBQUNoRCxRQUFNQyxNQUFNLElBQUlKLEtBQUtLLFFBQVEsQ0FBQyxHQUFHRixNQUFNLEVBQUU7QUFDekMsU0FBTyxHQUFHRixJQUFJLElBQUlDLEtBQUssSUFBSUUsR0FBRztBQUNoQztBQUVBLE1BQU1FLGFBQWE7QUFBQSxFQUNqQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQVU7QUFHWixNQUFNQyxjQUFjQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUl2QyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDd0MsUUFBUUMsU0FBUyxJQUFJekMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzBDLFdBQVdDLFlBQVksSUFBSTNDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM0QyxlQUFlQyxnQkFBZ0IsSUFBSTdDLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUM4QyxhQUFhQyxjQUFjLElBQUkvQyxTQUFTO0FBQUEsSUFDN0NnRCxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLG9CQUFvQkMscUJBQXFCLElBQUlwRCxTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDcUQsYUFBYUMsY0FBYyxJQUFJdEQsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ3VELFlBQVlDLGFBQWEsSUFBSXhELFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUN5RCxZQUFZQyxhQUFhLElBQUkxRCxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDMkQsY0FBY0MsZUFBZSxJQUFJNUQsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzZELGNBQWNDLGVBQWUsSUFBSTlELFNBQVMyQixnQkFBZ0I7QUFDakUsUUFBTSxDQUFDb0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWhFLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNpRSxRQUFRQyxTQUFTLElBQUlsRSxTQUFTLENBQUM7QUFDdEMsUUFBTSxDQUFDbUUsWUFBWUMsYUFBYSxJQUFJcEUsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FFLGFBQWFDLGNBQWMsSUFBSXRFLFNBQVM7QUFBQSxJQUM3Q3VFLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxLQUFLO0FBQUEsSUFDTEMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsSUFDUkMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSXBGLFNBQVMsSUFBSTtBQUUvRCxRQUFNcUYsZ0JBQWdCQyxPQUFPO0FBQUEsSUFDM0I5QyxRQUFRO0FBQUEsSUFDUitDLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNQyxZQUFZQSxDQUFDQyxlQUFlO0FBQ2hDLFVBQU0sQ0FBQzNELE1BQU1DLEtBQUssSUFBSTBELFdBQVdDLE1BQU0sR0FBRztBQUMxQyxXQUFPO0FBQUEsTUFDTDVEO0FBQUFBLE1BQ0FDLE9BQU9QLE9BQU9tRSxTQUFTNUQsS0FBSyxDQUFDLEVBQUVMLFNBQVMsR0FBRyxHQUFHO0FBQUEsTUFDOUNrRSxXQUFXekQsV0FBV3dELFNBQVM1RCxLQUFLLElBQUksQ0FBQztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBLFFBQU04RCxvQkFBb0JBLENBQUMvRCxNQUFNQyxVQUFVO0FBQ3pDLFdBQU8sR0FBR0QsSUFBSSxJQUFJTixPQUFPTyxLQUFLLEVBQUVMLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUNsRDtBQUVBLFFBQU1vRSxvQkFBb0JBLENBQUNMLGVBQWU7QUFDeEMsVUFBTSxFQUFFM0QsTUFBTUMsTUFBTSxJQUFJeUQsVUFBVUMsVUFBVTtBQUM1QyxVQUFNTSxZQUFZLElBQUkzRSxLQUFLVSxNQUFNNkQsU0FBUzVELEtBQUssSUFBSSxHQUFHLENBQUM7QUFDdkQsVUFBTWlFLFVBQVUsSUFBSTVFLEtBQUtVLE1BQU02RCxTQUFTNUQsS0FBSyxHQUFHLENBQUM7QUFFakQsV0FBTztBQUFBLE1BQ0xrRSxXQUFXckUsV0FBV21FLFNBQVM7QUFBQSxNQUMvQkcsU0FBU3RFLFdBQVdvRSxPQUFPO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUFHLFlBQVUsTUFBTTtBQUNkLFVBQU1DLFlBQVksWUFBWTtBQUM1QmhELDRCQUFzQixJQUFJO0FBQzFCLFVBQUk7QUFFRixjQUFNaUQsV0FBVyxNQUFNbEcsSUFBSW1HLElBQUksa0JBQWtCO0FBRWpELGNBQU1DLFlBQVlGLFNBQVNHLFFBQVE7QUFDbkMvRDtBQUFBQSxVQUNFOEQsVUFBVUU7QUFBQUEsWUFDUixDQUFDQyxNQUFNQSxFQUFFQyxlQUFlLFdBQVdELEVBQUVDLGVBQWU7QUFBQSxVQUN0RDtBQUFBLFFBQ0Y7QUFFQXRCLHNCQUFjdUIsUUFBUXBFLFNBQVM7QUFBQSxNQUNqQyxTQUFTcUUsS0FBSztBQUNaQyxnQkFBUUMsTUFBTSwwQkFBMEJGLEdBQUc7QUFFM0MsWUFBSSxDQUFDeEIsY0FBY3VCLFFBQVFwRSxRQUFRO0FBQ2pDTyx5QkFBZTtBQUFBLFlBQ2JDLFlBQVk7QUFBQSxZQUNaQyxTQUFTO0FBQUEsWUFDVEMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUNEbUMsd0JBQWN1QixRQUFRcEUsU0FBUztBQUUvQndFLHFCQUFXLE1BQU07QUFDZjNCLDBCQUFjdUIsUUFBUXBFLFNBQVM7QUFBQSxVQUNqQyxHQUFHLEdBQUk7QUFBQSxRQUNUO0FBQUEsTUFDRixVQUFDO0FBQ0NZLDhCQUFzQixLQUFLO0FBQUEsTUFDN0I7QUFBQSxJQUNGO0FBRUFnRCxjQUFVO0FBQUEsRUFDWixHQUFHLENBQUNuQyxNQUFNLENBQUM7QUFFWGtDLFlBQVUsTUFBTTtBQUNkLFVBQU1jLGtCQUFrQixJQUFJQyxnQkFBZ0I7QUFFNUM1RCxtQkFBZSxJQUFJO0FBRW5CLFVBQU02RCxlQUFlLFlBQVk7QUFDL0IsVUFBSTtBQUNGLGNBQU0sRUFBRWxCLFdBQVdDLFFBQVEsSUFBSUosa0JBQWtCakMsWUFBWTtBQUc3RCxjQUFNdUQsTUFBTSxNQUFNakgsSUFBSW1HLElBQUksa0JBQWtCO0FBQUEsVUFDMUNlLFFBQVE7QUFBQSxZQUNOcEI7QUFBQUEsWUFDQUM7QUFBQUEsVUFDRjtBQUFBLFVBQ0FvQixRQUFRTCxnQkFBZ0JLO0FBQUFBLFFBQzFCLENBQUM7QUFFRCxZQUFJRixJQUFJWixLQUFLZSxXQUFXSCxJQUFJWixLQUFLZ0IsV0FBVztBQUMxQ3BELHdCQUFjZ0QsSUFBSVosS0FBS2dCLFNBQVM7QUFDaENuQyx3QkFBY3VCLFFBQVFyQixVQUFVO0FBQUEsUUFDbEMsT0FBTztBQUNMbkIsd0JBQWMsRUFBRTtBQUFBLFFBQ2xCO0FBQUEsTUFDRixTQUFTeUMsS0FBSztBQUNaLFlBQUlBLElBQUlZLFNBQVMsY0FBYztBQUM3Qlgsa0JBQVFDLE1BQU0sMkJBQTJCRixHQUFHO0FBQzVDLGNBQUksQ0FBQ3hCLGNBQWN1QixRQUFRckIsU0FBUztBQUNsQ0YsMEJBQWN1QixRQUFRckIsVUFBVTtBQUVoQ3lCLHVCQUFXLE1BQU07QUFDZjNCLDRCQUFjdUIsUUFBUXJCLFVBQVU7QUFBQSxZQUNsQyxHQUFHLEdBQUk7QUFBQSxVQUNUO0FBQ0FuQix3QkFBYyxFQUFFO0FBQUEsUUFDbEI7QUFBQSxNQUNGLFVBQUM7QUFDQyxZQUFJLENBQUM2QyxnQkFBZ0JLLE9BQU9JLFNBQVM7QUFDbkNwRSx5QkFBZSxLQUFLO0FBQUEsUUFDdEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQ0gsb0JBQW9CO0FBQ3ZCZ0UsbUJBQWE7QUFBQSxJQUNmO0FBRUEsV0FBTyxNQUFNO0FBQ1hGLHNCQUFnQlUsTUFBTTtBQUFBLElBQ3hCO0FBQUEsRUFDRixHQUFHLENBQUM5RCxjQUFjVixvQkFBb0JjLE1BQU0sQ0FBQztBQUU3Q2tDLFlBQVUsTUFBTTtBQUNkLFFBQUloQyxXQUFXeUQsU0FBUyxHQUFHO0FBQ3pCLFVBQUlDLGVBQWUxRDtBQUVuQixVQUFJN0IsZUFBZSxPQUFPO0FBQ3hCdUYsdUJBQWUxRCxXQUFXc0M7QUFBQUEsVUFDeEIsQ0FBQ3FCLFNBQVNBLEtBQUtDLE1BQU1DLE9BQU8xRjtBQUFBQSxRQUM5QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNMkYsa0JBQWtCSixhQUFhSztBQUFBQSxRQUNuQyxDQUFDSixTQUFTQSxLQUFLQyxNQUFNSSxPQUFPQyxVQUFVO0FBQUEsTUFDeEM7QUFFQSxZQUFNQyxnQkFBZ0JSLGFBQWFTLElBQUksQ0FBQ1IsU0FBUztBQUMvQyxjQUFNUyxZQUFZVCxLQUFLQyxNQUFNSSxPQUFPQyxVQUFVO0FBQzlDLGNBQU1JLGdCQUFnQixDQUFDLEVBQUVDLEtBQUssVUFBVUMsT0FBTyxjQUFjLENBQUM7QUFFOUQsWUFBSSxDQUFDSCxXQUFXO0FBQ2RDLHdCQUFjRyxRQUFRLEVBQUVGLEtBQUssT0FBT0MsT0FBTyxhQUFhLENBQUM7QUFBQSxRQUMzRDtBQUVBLGNBQU1FLGlCQUNKO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLENBQUMsT0FBTztBQUFBLFlBQ2pCLE1BQU07QUFBQSxjQUNKQyxPQUFPTDtBQUFBQSxjQUNQTSxTQUFTQSxDQUFDLEVBQUVMLElBQUksTUFBTTtBQUNwQixvQkFBSUEsUUFBUSxPQUFPO0FBQ2pCL0UsZ0NBQWMsS0FBSztBQUNuQkYsZ0NBQWMsS0FBSztBQUNuQnVGLGdDQUFjakIsSUFBSTtBQUFBLGdCQUNwQjtBQUNBLG9CQUFJVyxRQUFRLFVBQVU7QUFDcEIvRSxnQ0FBYyxLQUFLO0FBQ25CRixnQ0FBYyxJQUFJO0FBQ2xCd0YsaUNBQWVsQixJQUFJO0FBQUEsZ0JBQ3JCO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxZQUVBLGlDQUFDLFlBQVMsV0FBVSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQTtBQUFBLFVBbEJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtQkE7QUFHRixlQUFPO0FBQUEsVUFDTEwsTUFBTUssS0FBS0MsTUFBTU47QUFBQUEsVUFDakJ3QixjQUFjbkIsS0FBS0MsTUFBTW1CO0FBQUFBLFVBQ3pCQyxpQkFBaUJyQixNQUFNc0IsU0FBU0Q7QUFBQUEsVUFDaENFLG1CQUFtQnZCLE1BQU1zQixTQUFTQztBQUFBQSxVQUNsQ0MseUJBQXlCeEIsTUFBTXNCLFNBQVNFO0FBQUFBLFVBQ3hDbkIsUUFBUUwsS0FBS0MsT0FBT0ksUUFBUUM7QUFBQUEsVUFDNUJtQixRQUFRWDtBQUFBQSxVQUNSWSxPQUFPMUI7QUFBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUVEbkYsbUJBQWEwRixhQUFhO0FBQUEsSUFDNUIsT0FBTztBQUNMMUYsbUJBQWEsRUFBRTtBQUFBLElBQ2pCO0FBQUEsRUFDRixHQUFHLENBQUNMLFlBQVk2QixVQUFVLENBQUM7QUFFM0IsUUFBTXNGLHFCQUFxQixPQUFPM0IsU0FBUztBQUN6QyxRQUFJO0FBQ0YsWUFBTSxFQUFFaEcsS0FBSyxJQUFJMEQsVUFBVTNCLFlBQVk7QUFFdkMsWUFBTXVELE1BQU0sTUFBTWpILElBQUltRyxJQUFJLGlCQUFpQndCLEtBQUtDLE1BQU1DLEVBQUUsSUFBSTtBQUFBLFFBQzFEWCxRQUFRLEVBQUV2RixLQUFLO0FBQUEsTUFDakIsQ0FBQztBQUVELFVBQUk0SCxZQUFZO0FBRWhCLFVBQUl0QyxJQUFJWixRQUFRWSxJQUFJWixLQUFLb0IsU0FBUyxHQUFHO0FBQ25DLGNBQU1PLFNBQVNmLElBQUlaLEtBQUssQ0FBQztBQUN6QmtELG9CQUFZdkIsT0FBT3VCLGFBQWE7QUFBQSxNQUNsQztBQUVBdEUsMkJBQXFCc0UsU0FBUztBQUM5QixhQUFPQTtBQUFBQSxJQUNULFNBQVM3QyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sa0NBQWtDRixHQUFHO0FBQ25EekIsMkJBQXFCLElBQUk7QUFDekIsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTTJELGdCQUFnQixPQUFPakIsU0FBUztBQUNwQzlELHNCQUFrQjhELElBQUk7QUFDdEJ0RSxrQkFBYyxLQUFLO0FBQ25CRSxrQkFBYyxLQUFLO0FBQ25CRSxvQkFBZ0JrRSxLQUFLQyxNQUFNQyxFQUFFO0FBRTdCLFVBQU0wQixZQUFZLE1BQU1ELG1CQUFtQjNCLElBQUk7QUFFL0MsVUFBTXpELGVBQWM7QUFBQSxNQUNsQkUsU0FBUztBQUFBLE1BQ1RDLFVBQVU7QUFBQSxNQUNWQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLE1BQ1BDLEtBQUs7QUFBQSxNQUNMQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFFBQVE7QUFBQSxNQUNSQyxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RDLFVBQVU7QUFBQSxNQUNWQyxVQUFVO0FBQUEsSUFDWjtBQUVBLFFBQUl3RSxXQUFXO0FBQ2JDLGFBQU9DLEtBQUt2RixZQUFXLEVBQUV3RixRQUFRLENBQUM5SCxVQUFVO0FBQzFDc0MscUJBQVl0QyxLQUFLLElBQUkySCxVQUFVM0gsS0FBSyxLQUFLO0FBQUEsTUFDM0MsQ0FBQztBQUFBLElBQ0g7QUFFQXVDLG1CQUFlRCxZQUFXO0FBQzFCeEIscUJBQWlCLElBQUk7QUFBQSxFQUN2QjtBQUVBLFFBQU1tRyxpQkFBaUIsT0FBT2xCLFNBQVM7QUFDckM5RCxzQkFBa0I4RCxJQUFJO0FBQ3RCdEUsa0JBQWMsSUFBSTtBQUNsQkUsa0JBQWMsS0FBSztBQUNuQkUsb0JBQWdCa0UsS0FBS0MsTUFBTUMsRUFBRTtBQUU3QixVQUFNMEIsWUFBWSxNQUFNRCxtQkFBbUIzQixJQUFJO0FBRS9DLFVBQU16RCxlQUFjO0FBQUEsTUFDbEJFLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxLQUFLO0FBQUEsTUFDTEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsVUFBVTtBQUFBLElBQ1o7QUFFQSxRQUFJd0UsV0FBVztBQUNiQyxhQUFPQyxLQUFLdkYsWUFBVyxFQUFFd0YsUUFBUSxDQUFDOUgsVUFBVTtBQUMxQ3NDLHFCQUFZdEMsS0FBSyxJQUFJMkgsVUFBVTNILEtBQUssS0FBSztBQUFBLE1BQzNDLENBQUM7QUFBQSxJQUNIO0FBRUF1QyxtQkFBZUQsWUFBVztBQUMxQnhCLHFCQUFpQixJQUFJO0FBQUEsRUFDdkI7QUFFQSxRQUFNaUgsaUJBQWlCQSxNQUFNO0FBQzNCcEcsa0JBQWMsSUFBSTtBQUNsQkYsa0JBQWMsS0FBSztBQUNuQlgscUJBQWlCLElBQUk7QUFFckJ5QixtQkFBZTtBQUFBLE1BQ2JDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxLQUFLO0FBQUEsTUFDTEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsVUFBVTtBQUFBLElBQ1osQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNNkUsb0JBQW9CQSxDQUFDaEksT0FBT3FHLFVBQVU7QUFDMUM5RCxtQkFBZSxDQUFDMEYsVUFBVTtBQUFBLE1BQ3hCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2pJLEtBQUssR0FBR3FHLFVBQVUsS0FBSyxLQUFLNkIsT0FBTzdCLEtBQUs7QUFBQSxJQUMzQyxFQUFFO0FBQUEsRUFDSjtBQUdBLFFBQU04QixlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFFakIsUUFBSTtBQUNGLFlBQU0sRUFBRXRJLEtBQUssSUFBSTBELFVBQVUzQixZQUFZO0FBRXZDLFVBQUlKLFlBQVk7QUFFZCxjQUFNNEcsV0FBVzdILE9BQU84RixJQUFJLENBQUM1QixNQUFNQSxFQUFFNEQsR0FBRztBQUV4QyxjQUFNbkssSUFBSW9LLE1BQU0sZ0JBQWdCO0FBQUEsVUFDOUJGO0FBQUFBLFVBQ0F2STtBQUFBQSxVQUNBdUM7QUFBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0wsY0FBTWxFLElBQUlvSztBQUFBQSxVQUNSLGlCQUFpQjVHLFlBQVksU0FBUzdCLElBQUk7QUFBQSxVQUMxQ3VDO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUF0QixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTUSxhQUNMLHNDQUNBRixhQUNBLGdDQUNBO0FBQUEsUUFDSkwsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNETCx1QkFBaUIsS0FBSztBQUN0QnFCLGdCQUFVLENBQUM4RixTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUM5QixTQUFTbkQsS0FBSztBQUNaQyxjQUFRQyxNQUFNLGlCQUFpQkYsR0FBRztBQUNsQzlELHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNRLGFBQ0wsdUJBQ0FGLGFBQ0Esa0JBQ0E7QUFBQSxRQUNKTCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0gsYUFBYUEsTUFBTTtBQUN2QixXQUFPO0FBQUEsTUFDTCxFQUFFL0IsS0FBSyxRQUFRZ0MsUUFBUSxPQUFPO0FBQUEsTUFDOUIsRUFBRWhDLEtBQUssZ0JBQWdCZ0MsUUFBUSxlQUFlO0FBQUEsTUFDOUMsRUFBRWhDLEtBQUssVUFBVWdDLFFBQVEsU0FBUztBQUFBLE1BQ2xDLEVBQUVoQyxLQUFLLG1CQUFtQmdDLFFBQVEsa0JBQWtCO0FBQUEsTUFDcEQsRUFBRWhDLEtBQUsscUJBQXFCZ0MsUUFBUSxvQkFBb0I7QUFBQSxNQUN4RCxFQUFFaEMsS0FBSywyQkFBMkJnQyxRQUFRLDBCQUEwQjtBQUFBLE1BQ3BFLEVBQUVoQyxLQUFLLFVBQVVnQyxRQUFRLFNBQVM7QUFBQSxJQUFDO0FBQUEsRUFFdkM7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTTNILFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFBTTtBQUNiRiwyQkFBZSxDQUFDaUgsVUFBVSxFQUFFLEdBQUdBLE1BQU1oSCxZQUFZLE1BQU0sRUFBRTtBQUFBLFVBQzNEO0FBQUE7QUFBQSxRQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1JO0FBQUEsTUFHSix1QkFBQyxTQUFJLFdBQVUsaUJBQ1A7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNqQix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLHdDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLFVBQy9EO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTOEc7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFdBQVEsV0FBVSxVQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QjtBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVDM0cscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHlDQUNiLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFPLEtBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTztBQUFBLGdCQUNMO0FBQUEsa0JBQ0VzRixLQUFLO0FBQUEsa0JBQ0xDLE9BQ0UsdUJBQUMsVUFBSyxXQUFVLHlDQUF3Qyw2QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVGZ0MsVUFDRSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxJQUFHO0FBQUEsd0JBQ0gsV0FBVTtBQUFBLHdCQUVWO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLE1BQU07QUFBQTtBQUFBLDRCQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFFVztBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFTQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLElBQUc7QUFBQSx3QkFDSCxXQUFVO0FBQUEsd0JBRVY7QUFBQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFVO0FBQUEsOEJBQ1YsTUFBTTtBQUFBO0FBQUEsNEJBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVNBO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBRztBQUFBLHdCQUNILFdBQVU7QUFBQSx3QkFFVjtBQUFBLGlEQUFDLGVBQVksV0FBVSxpQkFBZ0IsTUFBTSxNQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFnRDtBQUFBLDBCQUFHO0FBQUE7QUFBQTtBQUFBLHNCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTUE7QUFBQSx1QkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE4QkE7QUFBQSxnQkFFSjtBQUFBLGNBQUM7QUFBQSxjQUVILGtCQUFrQixDQUFDLEdBQUc7QUFBQSxjQUN0QixXQUFVO0FBQUE7QUFBQSxZQTdDWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUE2Q2tFLEtBOUNwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdEQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUViO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPcEk7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDNkgsTUFBTTVILGNBQWM0SCxFQUFFaEMsT0FBT0MsS0FBSztBQUFBLGtCQUU3QztBQUFBLDJDQUFDLFlBQU8sT0FBTSxPQUFNLDBCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4QjtBQUFBLG9CQUM3QjVGLE9BQU84RjtBQUFBQSxzQkFBSSxDQUFDUCxVQUNYLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU11QyxLQUNsQ3ZDLGdCQUFNTixRQUFRLG1CQURKTSxNQUFNdUMsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLE9BQU96RztBQUFBQSxrQkFDUCxVQUFVLENBQUNzRyxNQUFNckcsZ0JBQWdCcUcsRUFBRWhDLE9BQU9DLEtBQUs7QUFBQSxrQkFDL0MsS0FBS3ZDLGtCQUFrQnhFLGFBQWFFLFlBQVk7QUFBQTtBQUFBLGdCQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLb0Q7QUFBQSxpQkFUdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1o4QjtBQUFBQSwyQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUZBQ2IsaUNBQUMsU0FBSSxXQUFVLHVGQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1HLEtBRHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTVg7QUFBQUEsZ0JBQ04sU0FBUzhILFdBQVc7QUFBQSxnQkFDcEIsaUJBQWdCO0FBQUEsZ0JBQ2hCLGtCQUFpQjtBQUFBO0FBQUEsY0FKbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTRDO0FBQUEsZUFWOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpR0E7QUFBQSxXQWxISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0hBO0FBQUEsU0FoSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlJQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFDRS9HLHVCQUNHLHdCQUNBRixhQUNBLGdCQUNBLGdCQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1WLGlCQUFpQixLQUFLO0FBQUEsY0FDckMsV0FBVTtBQUFBLGNBRVYsaUNBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9CO0FBQUE7QUFBQSxZQUp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFRixXQUFVO0FBQUEsUUFDVixVQUFVO0FBQUEsUUFDVixTQUFTLE1BQU1BLGlCQUFpQixLQUFLO0FBQUEsUUFDckMsTUFBTUQ7QUFBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxXQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsVUFDTitILE1BQU07QUFBQSxZQUNKQyxTQUFTO0FBQUEsWUFDVEMsVUFBVTtBQUFBLFVBQ1o7QUFBQSxVQUNBSixRQUFRO0FBQUEsWUFDTkssY0FBYztBQUFBLFlBQ2RGLFNBQVM7QUFBQSxVQUNYO0FBQUEsUUFDRjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsVUFBSyxVQUFVVixjQUFjLFdBQVUsYUFDckM7QUFBQSxXQUFDekcsY0FBY00sa0JBQ2QsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwwQkFBeUIsMEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsWUFDcEQsdUJBQUMsU0FBSSxXQUFVLHdDQUNaQSx5QkFBZWdFLE1BQU1OLFFBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUdGLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMEJBQXlCLG9CQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBLGNBQzlDLHVCQUFDLFNBQUksV0FBVSx3Q0FDWmpDLG9CQUFVM0IsWUFBWSxFQUFFL0IsUUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMEJBQXlCLHFCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQy9DLHVCQUFDLFNBQUksV0FBVSx3Q0FDWjBELG9CQUFVM0IsWUFBWSxFQUFFK0IsYUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWnpELHFCQUFXbUc7QUFBQUEsWUFBSSxDQUFDdkcsVUFDZix1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBCQUEwQkEsbUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsY0FDakQsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLFFBQU8saUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCO0FBQUEsZ0JBQ3hCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPc0MsWUFBWXRDLEtBQUs7QUFBQSxvQkFDeEIsVUFBVSxDQUFDb0ksTUFBTUosa0JBQWtCaEksT0FBT29JLEVBQUVoQyxPQUFPQyxLQUFLO0FBQUEsb0JBQ3hELFdBQVU7QUFBQSxvQkFDVixLQUFJO0FBQUEsb0JBQ0osYUFBYSxTQUFTckcsS0FBSztBQUFBO0FBQUEsa0JBTjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNdUM7QUFBQSxtQkFSekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0NzQyxZQUFZdEMsS0FBSyxJQUFJLEtBQ3BCLHVCQUFDLFNBQUksV0FBVSxxQ0FDWmYsOEJBQW9CcUQsWUFBWXRDLEtBQUssQ0FBQyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBaEJNQSxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsVUFDRCxLQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUVUMEIsdUJBQ0csdUJBQ0FGLGFBQ0Esa0JBQ0E7QUFBQTtBQUFBLFlBUk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkRBLEtBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2REE7QUFBQTtBQUFBLE1BaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlHQTtBQUFBLE9BdE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1T0E7QUFFSjtBQUFFbEIsR0FybkJJRCxhQUFXO0FBQUEySSxLQUFYM0k7QUF1bkJOLGVBQWVBO0FBQVksSUFBQTJJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIk5hdmJhciIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJEcm9wZG93biIsIkRyYXdlciIsIklvTWRNb3JlIiwiSW9NZEFkZCIsIklvTWRDbG9zZSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiTG9hZGVyIiwiQ29sbGFwc2UiLCJMaW5rIiwiRmlsZVRleHRPdXRsaW5lZCIsIkZhTW9uZXlCaWxsIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkZhUnVwZWVTaWduIiwiQnJlYWRjcnVtYiIsInRvZGF5IiwiRGF0ZSIsImN1cnJlbnRZZWFyIiwiZ2V0RnVsbFllYXIiLCJjdXJyZW50TW9udGgiLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwiY3VycmVudFllYXJNb250aCIsImZvcm1hdERhdGUiLCJkYXRlIiwieWVhciIsIm1vbnRoIiwic2xpY2UiLCJkYXkiLCJnZXREYXRlIiwibW9udGhOYW1lcyIsIkFnZW50VGFyZ2V0IiwiX3MiLCJzZWxlY3RlZElkIiwic2V0U2VsZWN0ZWRJZCIsImFnZW50cyIsInNldEFnZW50cyIsInRhYmxlRGF0YSIsInNldFRhYmxlRGF0YSIsImRyYXdlclZpc2libGUiLCJzZXREcmF3ZXJWaXNpYmxlIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImluaXRpYWxEYXRhTG9hZGluZyIsInNldEluaXRpYWxEYXRhTG9hZGluZyIsImRhdGFMb2FkaW5nIiwic2V0RGF0YUxvYWRpbmciLCJpc0VkaXRNb2RlIiwic2V0SXNFZGl0TW9kZSIsImlzQnVsa01vZGUiLCJzZXRJc0J1bGtNb2RlIiwiZWRpdFRhcmdldElkIiwic2V0RWRpdFRhcmdldElkIiwic2VsZWN0ZWREYXRlIiwic2V0U2VsZWN0ZWREYXRlIiwic2VsZWN0ZWRQZXJzb24iLCJzZXRTZWxlY3RlZFBlcnNvbiIsInJlbG9hZCIsInNldFJlbG9hZCIsInRhcmdldERhdGEiLCJzZXRUYXJnZXREYXRhIiwibW9udGhWYWx1ZXMiLCJzZXRNb250aFZhbHVlcyIsIkphbnVhcnkiLCJGZWJydWFyeSIsIk1hcmNoIiwiQXByaWwiLCJNYXkiLCJKdW5lIiwiSnVseSIsIkF1Z3VzdCIsIlNlcHRlbWJlciIsIk9jdG9iZXIiLCJOb3ZlbWJlciIsIkRlY2VtYmVyIiwiZmV0Y2hlZFRhcmdldERhdGEiLCJzZXRGZXRjaGVkVGFyZ2V0RGF0YSIsImFsZXJ0U2hvd25SZWYiLCJ1c2VSZWYiLCJ0YXJnZXRzIiwicGFyc2VEYXRlIiwiZGF0ZVN0cmluZyIsInNwbGl0IiwicGFyc2VJbnQiLCJtb250aE5hbWUiLCJmb3JtYXRUb1llYXJNb250aCIsImdldE1vbnRoRGF0ZVJhbmdlIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJ1c2VFZmZlY3QiLCJmZXRjaERhdGEiLCJhZ2VudFJlcyIsImdldCIsImFsbEFnZW50cyIsImRhdGEiLCJmaWx0ZXIiLCJhIiwiYWdlbnRfdHlwZSIsImN1cnJlbnQiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJzZXRUaW1lb3V0IiwiYWJvcnRDb250cm9sbGVyIiwiQWJvcnRDb250cm9sbGVyIiwiZmV0Y2hUYXJnZXRzIiwicmVzIiwicGFyYW1zIiwic2lnbmFsIiwic3VjY2VzcyIsInN1bW1hcmllcyIsIm5hbWUiLCJhYm9ydGVkIiwiYWJvcnQiLCJsZW5ndGgiLCJmaWx0ZXJlZERhdGEiLCJpdGVtIiwiYWdlbnQiLCJpZCIsImFueVRhcmdldEV4aXN0cyIsInNvbWUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJoYXNUYXJnZXQiLCJkcm9wZG93bkl0ZW1zIiwia2V5IiwibGFiZWwiLCJ1bnNoaWZ0IiwiYWN0aW9uRHJvcGRvd24iLCJpdGVtcyIsIm9uQ2xpY2siLCJvcGVuU2V0RHJhd2VyIiwib3BlbkVkaXREcmF3ZXIiLCJwaG9uZV9udW1iZXIiLCJwaG9uZSIsImFjdHVhbF9idXNpbmVzcyIsIm1ldHJpY3MiLCJ0YXJnZXRfZGlmZmVyZW5jZSIsInRhcmdldF9yZW1haW5pbmdfZGlnaXRzIiwiYWN0aW9uIiwiX2l0ZW0iLCJmZXRjaFRhcmdldERldGFpbHMiLCJtb250aERhdGEiLCJPYmplY3QiLCJrZXlzIiwiZm9yRWFjaCIsIm9wZW5CdWxrRHJhd2VyIiwiaGFuZGxlTW9udGhDaGFuZ2UiLCJwcmV2IiwiTnVtYmVyIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwiYWdlbnRJZHMiLCJfaWQiLCJwYXRjaCIsImdldENvbHVtbnMiLCJoZWFkZXIiLCJjaGlsZHJlbiIsImJvZHkiLCJwYWRkaW5nIiwib3ZlcmZsb3ciLCJib3JkZXJCb3R0b20iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBZ2VudFRhcmdldC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBEcm9wZG93biwgRHJhd2VyIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUsIElvTWRBZGQsIElvTWRDbG9zZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBDb2xsYXBzZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaWxlVGV4dE91dGxpbmVkfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHsgRmFNb25leUJpbGwgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuXHJcbmltcG9ydCB7IEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuY29uc3QgY3VycmVudFllYXIgPSB0b2RheS5nZXRGdWxsWWVhcigpO1xyXG5jb25zdCBjdXJyZW50TW9udGggPSBTdHJpbmcodG9kYXkuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuY29uc3QgY3VycmVudFllYXJNb250aCA9IGAke2N1cnJlbnRZZWFyfS0ke2N1cnJlbnRNb250aH1gO1xyXG5cclxuZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlKSB7XHJcbiAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICBjb25zdCBtb250aCA9IGAwJHtkYXRlLmdldE1vbnRoKCkgKyAxfWAuc2xpY2UoLTIpO1xyXG4gIGNvbnN0IGRheSA9IGAwJHtkYXRlLmdldERhdGUoKX1gLnNsaWNlKC0yKTtcclxuICByZXR1cm4gYCR7eWVhcn0tJHttb250aH0tJHtkYXl9YDtcclxufVxyXG5cclxuY29uc3QgbW9udGhOYW1lcyA9IFtcclxuICBcIkphbnVhcnlcIixcclxuICBcIkZlYnJ1YXJ5XCIsXHJcbiAgXCJNYXJjaFwiLFxyXG4gIFwiQXByaWxcIixcclxuICBcIk1heVwiLFxyXG4gIFwiSnVuZVwiLFxyXG4gIFwiSnVseVwiLFxyXG4gIFwiQXVndXN0XCIsXHJcbiAgXCJTZXB0ZW1iZXJcIixcclxuICBcIk9jdG9iZXJcIixcclxuICBcIk5vdmVtYmVyXCIsXHJcbiAgXCJEZWNlbWJlclwiLFxyXG5dO1xyXG5cclxuY29uc3QgQWdlbnRUYXJnZXQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NlbGVjdGVkSWQsIHNldFNlbGVjdGVkSWRdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdGFibGVEYXRhLCBzZXRUYWJsZURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtkcmF3ZXJWaXNpYmxlLCBzZXREcmF3ZXJWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICAgIHR5cGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2luaXRpYWxEYXRhTG9hZGluZywgc2V0SW5pdGlhbERhdGFMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtkYXRhTG9hZGluZywgc2V0RGF0YUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0VkaXRNb2RlLCBzZXRJc0VkaXRNb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNCdWxrTW9kZSwgc2V0SXNCdWxrTW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRUYXJnZXRJZCwgc2V0RWRpdFRhcmdldElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZShjdXJyZW50WWVhck1vbnRoKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQZXJzb24sIHNldFNlbGVjdGVkUGVyc29uXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtyZWxvYWQsIHNldFJlbG9hZF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbdGFyZ2V0RGF0YSwgc2V0VGFyZ2V0RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW21vbnRoVmFsdWVzLCBzZXRNb250aFZhbHVlc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBKYW51YXJ5OiAwLFxyXG4gICAgRmVicnVhcnk6IDAsXHJcbiAgICBNYXJjaDogMCxcclxuICAgIEFwcmlsOiAwLFxyXG4gICAgTWF5OiAwLFxyXG4gICAgSnVuZTogMCxcclxuICAgIEp1bHk6IDAsXHJcbiAgICBBdWd1c3Q6IDAsXHJcbiAgICBTZXB0ZW1iZXI6IDAsXHJcbiAgICBPY3RvYmVyOiAwLFxyXG4gICAgTm92ZW1iZXI6IDAsXHJcbiAgICBEZWNlbWJlcjogMCxcclxuICB9KTtcclxuICBjb25zdCBbZmV0Y2hlZFRhcmdldERhdGEsIHNldEZldGNoZWRUYXJnZXREYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBjb25zdCBhbGVydFNob3duUmVmID0gdXNlUmVmKHtcclxuICAgIGFnZW50czogZmFsc2UsXHJcbiAgICB0YXJnZXRzOiBmYWxzZSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcGFyc2VEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSBkYXRlU3RyaW5nLnNwbGl0KFwiLVwiKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHllYXIsXHJcbiAgICAgIG1vbnRoOiBTdHJpbmcocGFyc2VJbnQobW9udGgpKS5wYWRTdGFydCgyLCBcIjBcIiksXHJcbiAgICAgIG1vbnRoTmFtZTogbW9udGhOYW1lc1twYXJzZUludChtb250aCkgLSAxXSxcclxuICAgIH07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0VG9ZZWFyTW9udGggPSAoeWVhciwgbW9udGgpID0+IHtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0TW9udGhEYXRlUmFuZ2UgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgeyB5ZWFyLCBtb250aCB9ID0gcGFyc2VEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgY29uc3Qgc3RhcnREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpIC0gMSwgMSk7XHJcbiAgICBjb25zdCBlbmREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpLCAwKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBmcm9tX2RhdGU6IGZvcm1hdERhdGUoc3RhcnREYXRlKSxcclxuICAgICAgdG9fZGF0ZTogZm9ybWF0RGF0ZShlbmREYXRlKSxcclxuICAgIH07XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0SW5pdGlhbERhdGFMb2FkaW5nKHRydWUpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIC8vIEZldGNoaW5nIG9ubHkgQWdlbnRzXHJcbiAgICAgICAgY29uc3QgYWdlbnRSZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1hZ2VudFwiKTtcclxuXHJcbiAgICAgICAgY29uc3QgYWxsQWdlbnRzID0gYWdlbnRSZXMuZGF0YSB8fCBbXTtcclxuICAgICAgICBzZXRBZ2VudHMoXHJcbiAgICAgICAgICBhbGxBZ2VudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAoYSkgPT4gYS5hZ2VudF90eXBlID09PSBcImFnZW50XCIgfHwgYS5hZ2VudF90eXBlID09PSBcImJvdGhcIlxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGFsZXJ0U2hvd25SZWYuY3VycmVudC5hZ2VudHMgPSBmYWxzZTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFnZW50czpcIiwgZXJyKTtcclxuXHJcbiAgICAgICAgaWYgKCFhbGVydFNob3duUmVmLmN1cnJlbnQuYWdlbnRzKSB7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgYWdlbnRzXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LmFnZW50cyA9IHRydWU7XHJcblxyXG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGFsZXJ0U2hvd25SZWYuY3VycmVudC5hZ2VudHMgPSBmYWxzZTtcclxuICAgICAgICAgIH0sIDMwMDApO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJbml0aWFsRGF0YUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtyZWxvYWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuXHJcbiAgICBzZXREYXRhTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICBjb25zdCBmZXRjaFRhcmdldHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgeyBmcm9tX2RhdGUsIHRvX2RhdGUgfSA9IGdldE1vbnRoRGF0ZVJhbmdlKHNlbGVjdGVkRGF0ZSk7XHJcblxyXG4gICAgICAgIC8vIEZldGNoaW5nIEFnZW50IFRhcmdldHNcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3RhcmdldC9hZ2VudHNcIiwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgIGZyb21fZGF0ZSxcclxuICAgICAgICAgICAgdG9fZGF0ZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChyZXMuZGF0YS5zdWNjZXNzICYmIHJlcy5kYXRhLnN1bW1hcmllcykge1xyXG4gICAgICAgICAgc2V0VGFyZ2V0RGF0YShyZXMuZGF0YS5zdW1tYXJpZXMpO1xyXG4gICAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LnRhcmdldHMgPSBmYWxzZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0VGFyZ2V0RGF0YShbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBpZiAoZXJyLm5hbWUgIT09IFwiQWJvcnRFcnJvclwiKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFyZ2V0czpcIiwgZXJyKTtcclxuICAgICAgICAgIGlmICghYWxlcnRTaG93blJlZi5jdXJyZW50LnRhcmdldHMpIHtcclxuICAgICAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LnRhcmdldHMgPSB0cnVlO1xyXG5cclxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LnRhcmdldHMgPSBmYWxzZTtcclxuICAgICAgICAgICAgfSwgMzAwMCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBzZXRUYXJnZXREYXRhKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKCFhYm9ydENvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcclxuICAgICAgICAgIHNldERhdGFMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgaWYgKCFpbml0aWFsRGF0YUxvYWRpbmcpIHtcclxuICAgICAgZmV0Y2hUYXJnZXRzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XHJcbiAgICB9O1xyXG4gIH0sIFtzZWxlY3RlZERhdGUsIGluaXRpYWxEYXRhTG9hZGluZywgcmVsb2FkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodGFyZ2V0RGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGxldCBmaWx0ZXJlZERhdGEgPSB0YXJnZXREYXRhO1xyXG5cclxuICAgICAgaWYgKHNlbGVjdGVkSWQgIT09IFwiYWxsXCIpIHtcclxuICAgICAgICBmaWx0ZXJlZERhdGEgPSB0YXJnZXREYXRhLmZpbHRlcihcclxuICAgICAgICAgIChpdGVtKSA9PiBpdGVtLmFnZW50LmlkID09PSBzZWxlY3RlZElkXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgYW55VGFyZ2V0RXhpc3RzID0gZmlsdGVyZWREYXRhLnNvbWUoXHJcbiAgICAgICAgKGl0ZW0pID0+IGl0ZW0uYWdlbnQudGFyZ2V0LnZhbHVlICE9PSBcIk5vdCBTZXRcIlxyXG4gICAgICApO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IGZpbHRlcmVkRGF0YS5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICBjb25zdCBoYXNUYXJnZXQgPSBpdGVtLmFnZW50LnRhcmdldC52YWx1ZSAhPT0gXCJOb3QgU2V0XCI7XHJcbiAgICAgICAgY29uc3QgZHJvcGRvd25JdGVtcyA9IFt7IGtleTogXCJ1cGRhdGVcIiwgbGFiZWw6IFwiRWRpdCBUYXJnZXRcIiB9XTtcclxuXHJcbiAgICAgICAgaWYgKCFoYXNUYXJnZXQpIHtcclxuICAgICAgICAgIGRyb3Bkb3duSXRlbXMudW5zaGlmdCh7IGtleTogXCJzZXRcIiwgbGFiZWw6IFwiU2V0IFRhcmdldFwiIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgYWN0aW9uRHJvcGRvd24gPSAoXHJcbiAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICBpdGVtczogZHJvcGRvd25JdGVtcyxcclxuICAgICAgICAgICAgICBvbkNsaWNrOiAoeyBrZXkgfSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKGtleSA9PT0gXCJzZXRcIikge1xyXG4gICAgICAgICAgICAgICAgICBzZXRJc0J1bGtNb2RlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0SXNFZGl0TW9kZShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgIG9wZW5TZXREcmF3ZXIoaXRlbSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoa2V5ID09PSBcInVwZGF0ZVwiKSB7XHJcbiAgICAgICAgICAgICAgICAgIHNldElzQnVsa01vZGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRJc0VkaXRNb2RlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICBvcGVuRWRpdERyYXdlcihpdGVtKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXJcIiAvPlxyXG4gICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICApO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgbmFtZTogaXRlbS5hZ2VudC5uYW1lLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBpdGVtLmFnZW50LnBob25lLFxyXG4gICAgICAgICAgYWN0dWFsX2J1c2luZXNzOiBpdGVtPy5tZXRyaWNzPy5hY3R1YWxfYnVzaW5lc3MsXHJcbiAgICAgICAgICB0YXJnZXRfZGlmZmVyZW5jZTogaXRlbT8ubWV0cmljcz8udGFyZ2V0X2RpZmZlcmVuY2UsXHJcbiAgICAgICAgICB0YXJnZXRfcmVtYWluaW5nX2RpZ2l0czogaXRlbT8ubWV0cmljcz8udGFyZ2V0X3JlbWFpbmluZ19kaWdpdHMsXHJcbiAgICAgICAgICB0YXJnZXQ6IGl0ZW0uYWdlbnQ/LnRhcmdldD8udmFsdWUsXHJcbiAgICAgICAgICBhY3Rpb246IGFjdGlvbkRyb3Bkb3duLFxyXG4gICAgICAgICAgX2l0ZW06IGl0ZW0sXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRUYWJsZURhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRUYWJsZURhdGEoW10pO1xyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3RlZElkLCB0YXJnZXREYXRhXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoVGFyZ2V0RGV0YWlscyA9IGFzeW5jIChpdGVtKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB7IHllYXIgfSA9IHBhcnNlRGF0ZShzZWxlY3RlZERhdGUpO1xyXG5cclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3RhcmdldC9hZ2VudC8ke2l0ZW0uYWdlbnQuaWR9YCwge1xyXG4gICAgICAgIHBhcmFtczogeyB5ZWFyIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgbGV0IG1vbnRoRGF0YSA9IG51bGw7XHJcblxyXG4gICAgICBpZiAocmVzLmRhdGEgJiYgcmVzLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIGNvbnN0IHRhcmdldCA9IHJlcy5kYXRhWzBdO1xyXG4gICAgICAgIG1vbnRoRGF0YSA9IHRhcmdldC5tb250aERhdGEgfHwgbnVsbDtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0RmV0Y2hlZFRhcmdldERhdGEobW9udGhEYXRhKTtcclxuICAgICAgcmV0dXJuIG1vbnRoRGF0YTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFyZ2V0IGRldGFpbHM6XCIsIGVycik7XHJcbiAgICAgIHNldEZldGNoZWRUYXJnZXREYXRhKG51bGwpO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBvcGVuU2V0RHJhd2VyID0gYXN5bmMgKGl0ZW0pID0+IHtcclxuICAgIHNldFNlbGVjdGVkUGVyc29uKGl0ZW0pO1xyXG4gICAgc2V0SXNFZGl0TW9kZShmYWxzZSk7XHJcbiAgICBzZXRJc0J1bGtNb2RlKGZhbHNlKTtcclxuICAgIHNldEVkaXRUYXJnZXRJZChpdGVtLmFnZW50LmlkKTtcclxuXHJcbiAgICBjb25zdCBtb250aERhdGEgPSBhd2FpdCBmZXRjaFRhcmdldERldGFpbHMoaXRlbSk7XHJcblxyXG4gICAgY29uc3QgbW9udGhWYWx1ZXMgPSB7XHJcbiAgICAgIEphbnVhcnk6IDAsXHJcbiAgICAgIEZlYnJ1YXJ5OiAwLFxyXG4gICAgICBNYXJjaDogMCxcclxuICAgICAgQXByaWw6IDAsXHJcbiAgICAgIE1heTogMCxcclxuICAgICAgSnVuZTogMCxcclxuICAgICAgSnVseTogMCxcclxuICAgICAgQXVndXN0OiAwLFxyXG4gICAgICBTZXB0ZW1iZXI6IDAsXHJcbiAgICAgIE9jdG9iZXI6IDAsXHJcbiAgICAgIE5vdmVtYmVyOiAwLFxyXG4gICAgICBEZWNlbWJlcjogMCxcclxuICAgIH07XHJcblxyXG4gICAgaWYgKG1vbnRoRGF0YSkge1xyXG4gICAgICBPYmplY3Qua2V5cyhtb250aFZhbHVlcykuZm9yRWFjaCgobW9udGgpID0+IHtcclxuICAgICAgICBtb250aFZhbHVlc1ttb250aF0gPSBtb250aERhdGFbbW9udGhdIHx8IDA7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHNldE1vbnRoVmFsdWVzKG1vbnRoVmFsdWVzKTtcclxuICAgIHNldERyYXdlclZpc2libGUodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlbkVkaXREcmF3ZXIgPSBhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRQZXJzb24oaXRlbSk7XHJcbiAgICBzZXRJc0VkaXRNb2RlKHRydWUpO1xyXG4gICAgc2V0SXNCdWxrTW9kZShmYWxzZSk7XHJcbiAgICBzZXRFZGl0VGFyZ2V0SWQoaXRlbS5hZ2VudC5pZCk7XHJcblxyXG4gICAgY29uc3QgbW9udGhEYXRhID0gYXdhaXQgZmV0Y2hUYXJnZXREZXRhaWxzKGl0ZW0pO1xyXG5cclxuICAgIGNvbnN0IG1vbnRoVmFsdWVzID0ge1xyXG4gICAgICBKYW51YXJ5OiAwLFxyXG4gICAgICBGZWJydWFyeTogMCxcclxuICAgICAgTWFyY2g6IDAsXHJcbiAgICAgIEFwcmlsOiAwLFxyXG4gICAgICBNYXk6IDAsXHJcbiAgICAgIEp1bmU6IDAsXHJcbiAgICAgIEp1bHk6IDAsXHJcbiAgICAgIEF1Z3VzdDogMCxcclxuICAgICAgU2VwdGVtYmVyOiAwLFxyXG4gICAgICBPY3RvYmVyOiAwLFxyXG4gICAgICBOb3ZlbWJlcjogMCxcclxuICAgICAgRGVjZW1iZXI6IDAsXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChtb250aERhdGEpIHtcclxuICAgICAgT2JqZWN0LmtleXMobW9udGhWYWx1ZXMpLmZvckVhY2goKG1vbnRoKSA9PiB7XHJcbiAgICAgICAgbW9udGhWYWx1ZXNbbW9udGhdID0gbW9udGhEYXRhW21vbnRoXSB8fCAwO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRNb250aFZhbHVlcyhtb250aFZhbHVlcyk7XHJcbiAgICBzZXREcmF3ZXJWaXNpYmxlKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9wZW5CdWxrRHJhd2VyID0gKCkgPT4ge1xyXG4gICAgc2V0SXNCdWxrTW9kZSh0cnVlKTtcclxuICAgIHNldElzRWRpdE1vZGUoZmFsc2UpO1xyXG4gICAgc2V0RHJhd2VyVmlzaWJsZSh0cnVlKTtcclxuXHJcbiAgICBzZXRNb250aFZhbHVlcyh7XHJcbiAgICAgIEphbnVhcnk6IDAsXHJcbiAgICAgIEZlYnJ1YXJ5OiAwLFxyXG4gICAgICBNYXJjaDogMCxcclxuICAgICAgQXByaWw6IDAsXHJcbiAgICAgIE1heTogMCxcclxuICAgICAgSnVuZTogMCxcclxuICAgICAgSnVseTogMCxcclxuICAgICAgQXVndXN0OiAwLFxyXG4gICAgICBTZXB0ZW1iZXI6IDAsXHJcbiAgICAgIE9jdG9iZXI6IDAsXHJcbiAgICAgIE5vdmVtYmVyOiAwLFxyXG4gICAgICBEZWNlbWJlcjogMCxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU1vbnRoQ2hhbmdlID0gKG1vbnRoLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0TW9udGhWYWx1ZXMoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFttb250aF06IHZhbHVlID09PSBcIlwiID8gXCJcIiA6IE51bWJlcih2YWx1ZSksXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgeyB5ZWFyIH0gPSBwYXJzZURhdGUoc2VsZWN0ZWREYXRlKTtcclxuXHJcbiAgICAgIGlmIChpc0J1bGtNb2RlKSB7XHJcbiAgICAgICAgLy8gQnVsayB1cGRhdGUgZm9yIEFnZW50c1xyXG4gICAgICAgIGNvbnN0IGFnZW50SWRzID0gYWdlbnRzLm1hcCgoYSkgPT4gYS5faWQpO1xyXG5cclxuICAgICAgICBhd2FpdCBhcGkucGF0Y2goYC90YXJnZXQvYnVsa2AsIHtcclxuICAgICAgICAgIGFnZW50SWRzLFxyXG4gICAgICAgICAgeWVhcixcclxuICAgICAgICAgIG1vbnRoVmFsdWVzLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wYXRjaChcclxuICAgICAgICAgIGAvdGFyZ2V0L2FnZW50LyR7ZWRpdFRhcmdldElkfT95ZWFyPSR7eWVhcn1gLFxyXG4gICAgICAgICAgbW9udGhWYWx1ZXNcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBpc0J1bGtNb2RlXHJcbiAgICAgICAgICA/IFwiQnVsayB0YXJnZXRzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCJcclxuICAgICAgICAgIDogaXNFZGl0TW9kZVxyXG4gICAgICAgICAgPyBcIlRhcmdldCB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiXHJcbiAgICAgICAgICA6IFwiVGFyZ2V0IHNldCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldERyYXdlclZpc2libGUoZmFsc2UpO1xyXG4gICAgICBzZXRSZWxvYWQoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiU3VibWl0IGZhaWxlZFwiLCBlcnIpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBpc0J1bGtNb2RlXHJcbiAgICAgICAgICA/IFwiQnVsayB1cGRhdGUgZmFpbGVkXCJcclxuICAgICAgICAgIDogaXNFZGl0TW9kZVxyXG4gICAgICAgICAgPyBcIlVwZGF0ZSBmYWlsZWRcIlxyXG4gICAgICAgICAgOiBcIkFkZCBmYWlsZWRcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldENvbHVtbnMgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gW1xyXG4gICAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuICAgICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgICB7IGtleTogXCJ0YXJnZXRcIiwgaGVhZGVyOiBcIlRhcmdldFwiIH0sXHJcbiAgICAgIHsga2V5OiBcImFjdHVhbF9idXNpbmVzc1wiLCBoZWFkZXI6IFwiQWN0dWFsIEJ1c2luZXNzXCIgfSxcclxuICAgICAgeyBrZXk6IFwidGFyZ2V0X2RpZmZlcmVuY2VcIiwgaGVhZGVyOiBcIlRhcmdldCBEaWZmZXJlbmNlXCIgfSxcclxuICAgICAgeyBrZXk6IFwidGFyZ2V0X3JlbWFpbmluZ19kaWdpdHNcIiwgaGVhZGVyOiBcIlRhcmdldCBSZW1haW5pbmcgRGlnaXRzXCIgfSxcclxuICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgXTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC02XCI+XHJcbiAgICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkFnZW50IFRhcmdldHMgTWFuYWdlbWVudDwvaDE+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXtvcGVuQnVsa0RyYXdlcn1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIGhvdmVyOmJnLWJsdWUtNzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJb01kQWRkIGNsYXNzTmFtZT1cIm1yLTJcIiAvPiBCdWxrIFVwZGF0ZSBUYXJnZXRzXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2luaXRpYWxEYXRhTG9hZGluZyA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTY0XCI+XHJcbiAgICAgICAgICAgICAgPExvYWRlciAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteS02XCI+XHJcbiAgICAgICAgICAgICAgICA8Q29sbGFwc2VcclxuICAgICAgICAgICAgICAgICAgaXRlbXM9e1tcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFNob3J0Y3V0IEtleXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL3RhcmdldC1jb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdGV4dC1iYXNlIGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHB4LTQgcHktMiB0ZXh0LWdyYXktNzAwIGhvdmVyOmJvcmRlci1ibHVlLTUwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezIwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbW1pc3Npb24gUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy90YXJnZXQtaW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdGV4dC1iYXNlIGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHB4LTQgcHktMiB0ZXh0LWdyYXktNzAwIGhvdmVyOmJvcmRlci1ibHVlLTUwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHRPdXRsaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MzB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5jZW50aXZlIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktcGF5bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItYmx1ZS01MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhTW9uZXlCaWxsIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiBzaXplPXszMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhbGFyeSBQYXlvdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IGZsZXgtd3JhcCBtYi02IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBBZ2VudFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJvcmRlciByb3VuZGVkIHctZnVsbCBtaW4tdy1bMjAwcHhdXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRJZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkSWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBBZ2VudHM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZSB8fCBcIlVua25vd24gQWdlbnRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRhcmdldCBNb250aFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBib3JkZXIgcm91bmRlZCB3LWZ1bGwgbWluLXctWzE1MHB4XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgbWF4PXtmb3JtYXRUb1llYXJNb250aChjdXJyZW50WWVhciwgY3VycmVudE1vbnRoKX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1pbi1oLVsyMDBweF1cIj5cclxuICAgICAgICAgICAgICAgIHtkYXRhTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy13aGl0ZSBiZy1vcGFjaXR5LTcwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHotMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC0xMCB3LTEwIGJvcmRlci00IGJvcmRlci1ibHVlLTYwMCBib3JkZXItdC10cmFuc3BhcmVudFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e3RhYmxlRGF0YX1cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17Z2V0Q29sdW1ucygpfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJBZ2VudC1UYXJnZXQtUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkFnZW50LVRhcmdldC1SZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogVGFyZ2V0IERyYXdlciAqL31cclxuICAgICAgPERyYXdlclxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgIHtpc0J1bGtNb2RlXHJcbiAgICAgICAgICAgICAgICA/IFwiQnVsayBVcGRhdGUgVGFyZ2V0c1wiXHJcbiAgICAgICAgICAgICAgICA6IGlzRWRpdE1vZGVcclxuICAgICAgICAgICAgICAgID8gXCJFZGl0IFRhcmdldFwiXHJcbiAgICAgICAgICAgICAgICA6IFwiU2V0IFRhcmdldFwifVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXREcmF3ZXJWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPElvTWRDbG9zZSBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4gICAgICAgIGNsb3NhYmxlPXtmYWxzZX1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXREcmF3ZXJWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICBvcGVuPXtkcmF3ZXJWaXNpYmxlfVxyXG4gICAgICAgIHdpZHRoPXs1MDB9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwidGFyZ2V0LWRyYXdlclwiXHJcbiAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDAsXHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBcImhpZGRlblwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGhlYWRlcjoge1xyXG4gICAgICAgICAgICBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICNmMGYwZjBcIixcclxuICAgICAgICAgICAgcGFkZGluZzogXCIxNnB4IDI0cHhcIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgeyFpc0J1bGtNb2RlICYmIHNlbGVjdGVkUGVyc29uICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtIG1iLTFcIj5UYXJnZXQgRm9yPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBlcnNvbi5hZ2VudC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1tZWRpdW0gbWItMVwiPlllYXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkIGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAge3BhcnNlRGF0ZShzZWxlY3RlZERhdGUpLnllYXJ9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtIG1iLTFcIj5Nb250aDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQgYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICB7cGFyc2VEYXRlKHNlbGVjdGVkRGF0ZSkubW9udGhOYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAge21vbnRoTmFtZXMubWFwKChtb250aCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e21vbnRofT5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtIG1iLTFcIj57bW9udGh9PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1yLTJcIj7igrk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttb250aFZhbHVlc1ttb250aF19XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZU1vbnRoQ2hhbmdlKG1vbnRoLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2BFbnRlciAke21vbnRofSB0YXJnZXRgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7bW9udGhWYWx1ZXNbbW9udGhdID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMSBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKG1vbnRoVmFsdWVzW21vbnRoXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcC0yIHJvdW5kZWQgaG92ZXI6YmctYmx1ZS03MDAgbXQtNlwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7aXNCdWxrTW9kZVxyXG4gICAgICAgICAgICAgICAgPyBcIlVwZGF0ZSBBbGwgVGFyZ2V0c1wiXHJcbiAgICAgICAgICAgICAgICA6IGlzRWRpdE1vZGVcclxuICAgICAgICAgICAgICAgID8gXCJVcGRhdGUgVGFyZ2V0XCJcclxuICAgICAgICAgICAgICAgIDogXCJTYXZlIFRhcmdldFwifVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9EcmF3ZXI+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWdlbnRUYXJnZXQ7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0FnZW50VGFyZ2V0LmpzeCJ9