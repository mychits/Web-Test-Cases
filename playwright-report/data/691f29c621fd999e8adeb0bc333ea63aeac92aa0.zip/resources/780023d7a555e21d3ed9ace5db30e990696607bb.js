import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitCollectionIncentiveReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import {
  Select,
  Radio,
  Card,
  Button,
  Space,
  Statistic,
  Row,
  Col,
  message
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  UserOutlined,
  CalendarOutlined,
  PercentageOutlined,
  FileSearchOutlined,
  TeamOutlined,
  RiseOutlined,
  PrinterOutlined,
  DownloadOutlined,
  SignatureOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FiTarget } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { MdGroups } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import imageInput from "/src/assets/images/Logo.svg?import";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
const ChitCollectionIncentiveReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [dateSelectionMode, setDateSelectionMode] = useState("month");
  const [tempSelectedMonth, setTempSelectedMonth] = useState(null);
  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [incentivePercentage, setIncentivePercentage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [chitData, setChitData] = useState([]);
  const [chitSummary, setChitSummary] = useState({
    total_collection: 0,
    total_incentive: 0,
    total_chits: 0,
    completed_chits: 0,
    pending_chits: 0
  });
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [isFiltering, setIsFiltering] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [signatureData, setSignatureData] = useState(null);
  const [agentSignatureData, setAgentSignatureData] = useState(null);
  useEffect(() => {
    const today2 = /* @__PURE__ */ new Date();
    const currentMonth2 = `${today2.getFullYear()}-${String(
      today2.getMonth() + 1
    ).padStart(2, "0")}`;
    setTempSelectedMonth(currentMonth2);
    const year = today2.getFullYear();
    const month = today2.getMonth() + 1;
    const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    setTempFromDate(firstDay);
    setTempToDate(
      `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`
    );
  }, []);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await api.get("/employee");
        setEmployees(res?.data?.employee || []);
      } catch (err) {
        console.error(err);
      }
    };
    fetchEmployees();
  }, []);
  const handleTempMonthChange = (e) => {
    const value = e.target.value;
    setTempSelectedMonth(value);
    if (value) {
      const [year, month] = value.split("-");
      const firstDay = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      setTempFromDate(firstDay);
      setTempToDate(`${year}-${month}-${String(lastDay).padStart(2, "0")}`);
    }
  };
  const fetchChitCollectionData = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    try {
      const response = await api.get(
        `/v1/admin/payments/chits/collection-agents/${employeeId}/${incentivePercentage}`,
        {
          params: {
            startDate,
            endDate
          }
        }
      );
      if (response.data && response.data.success) {
        const responseData = response.data.data || [];
        let allPayments = [];
        let totalCollection = 0;
        let totalIncentive = 0;
        responseData.forEach((item) => {
          if (item.payments && Array.isArray(item.payments)) {
            allPayments = [...allPayments, ...item.payments];
            totalCollection += item.total_payments || 0;
            totalIncentive += item.incentive_amount || 0;
          }
        });
        setChitData(allPayments);
        setChitSummary({
          total_collection: totalCollection,
          total_incentive: totalIncentive,
          total_chits: allPayments.length,
          completed_chits: allPayments.filter(
            (p) => p.status === "completed" || p.is_completed
          ).length,
          pending_chits: allPayments.filter(
            (p) => p.status !== "completed" && !p.is_completed
          ).length
        });
      } else {
        setChitData([]);
        setChitSummary({
          total_collection: 0,
          total_incentive: 0,
          total_chits: 0,
          completed_chits: 0,
          pending_chits: 0
        });
      }
    } catch (err) {
      console.error("Error fetching chit collection data:", err);
      message.error(err.response?.data?.message || "Failed to fetch data");
      setChitData([]);
      setChitSummary({
        total_collection: 0,
        total_incentive: 0,
        total_chits: 0,
        completed_chits: 0,
        pending_chits: 0
      });
    }
  };
  const handleContinue = async () => {
    if (!selectedEmployeeId) {
      message.warning("Please select an employee.");
      return;
    }
    if (dateSelectionMode === "month" && !tempSelectedMonth) {
      message.warning("Please select a month.");
      return;
    }
    if (dateSelectionMode === "date-range" && (!tempFromDate || !tempToDate)) {
      message.warning("Please select both From and To dates.");
      return;
    }
    setIsFiltering(true);
    setLoading(true);
    let startDate, endDate;
    if (dateSelectionMode === "month") {
      const [year, month] = tempSelectedMonth.split("-");
      startDate = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      endDate = `${year}-${month}-${String(lastDay).padStart(2, "0")}`;
      setFromDate(startDate);
      setToDate(endDate);
    } else {
      startDate = tempFromDate;
      endDate = tempToDate;
      setFromDate(startDate);
      setToDate(endDate);
    }
    try {
      const emp = employees.find((e) => e._id === selectedEmployeeId);
      setSelectedEmployeeDetails(emp || null);
      await fetchChitCollectionData(selectedEmployeeId, startDate, endDate);
      message.success("Data loaded successfully!");
    } catch (error) {
      console.error("Error in handleContinue:", error);
      message.error("Failed to load data");
    } finally {
      setLoading(false);
    }
  };
  const numToWords = (num) => {
    if (isNaN(num) || num === 0) return "Zero";
    const a = [
      "",
      "One",
      "Two",
      "Three",
      "Four",
      "Five",
      "Six",
      "Seven",
      "Eight",
      "Nine",
      "Ten",
      "Eleven",
      "Twelve",
      "Thirteen",
      "Fourteen",
      "Fifteen",
      "Sixteen",
      "Seventeen",
      "Eighteen",
      "Nineteen"
    ];
    const b = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    let numVal = num;
    numVal = Math.round(numVal);
    if ((numVal = numVal.toString()).length > 9) return "Overflow";
    const n = ("000000000" + numVal).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return "";
    let str = "";
    str += n[1] != 0 ? (a[Number(n[1])] || b[n[1][0]] + " " + a[n[1][1]]) + " Crore " : "";
    str += n[2] != 0 ? (a[Number(n[2])] || b[n[2][0]] + " " + a[n[2][1]]) + " Lakh " : "";
    str += n[3] != 0 ? (a[Number(n[3])] || b[n[3][0]] + " " + a[n[3][1]]) + " Thousand " : "";
    str += n[4] != 0 ? (a[Number(n[4])] || b[n[4][0]] + " " + a[n[4][1]]) + " Hundred " : "";
    str += n[5] != 0 ? (str != "" ? "and " : "") + (a[Number(n[5])] || b[n[5][0]] + " " + a[n[5][1]]) + " " : "";
    return str.trim() || "Zero";
  };
  const handleSignatureChange = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === "manager") {
          setSignatureData(reader.result);
        } else {
          setAgentSignatureData(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  const generateIncentiveSlipContent = () => {
    const agent = selectedEmployeeDetails;
    const period = dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString("default", { month: "long", year: "numeric" }) : `${fromDate} to ${toDate}`;
    const amountInWords = numToWords(chitSummary.total_incentive);
    const slipNumber = `INC-CHIT-${Date.now().toString().slice(-6)}`;
    const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
    const logoUrl = imageInput.startsWith("http") ? imageInput : window.location.origin + imageInput;
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Chit Incentive Slip - ${agent?.name || "Agent"}</title>
        <style>
          @page { 
            size: A4; 
            margin: 0;
          }
          
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          body { 
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; 
            background-color: #ffffff;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          .document-container {
            width: 210mm;
            min-height: 297mm;
            margin: 0 auto;
            background: white;
            position: relative;
            page-break-after: avoid;
            page-break-inside: avoid;
          }
          
          .header-section {
            background: linear-gradient(135deg, #00267C 0%, #003d9e 100%);
            padding: 20px 25px;
            color: white;
          }
          
          .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
          }
          
          .logo-area img {
            height: 60px;
            width: auto;
            object-fit: contain;
          }
          
          .company-info {
            text-align: center;
            flex: 1;
          }
          
          .company-name {
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 3px;
          }
          
          .company-tagline {
            font-size: 10px;
            opacity: 0.9;
          }
          
          .document-meta {
            text-align: right;
            font-size: 11px;
            border-left: 1px solid rgba(255,255,255,0.3);
            padding-left: 15px;
          }
          
          .meta-item {
            margin-bottom: 3px;
          }
          
          .meta-label {
            font-weight: 600;
            opacity: 0.8;
          }
          
          .title-section {
            background: #f8f9fa;
            padding: 12px 20px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
          }
          
          .document-title {
            font-size: 20px;
            font-weight: 700;
            color: #00267C;
            text-transform: uppercase;
          }
          
          .content-section {
            padding: 15px 25px;
          }
          
          .info-card {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 15px;
            overflow: hidden;
          }
          
          .card-header {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 10px 15px;
            border-bottom: 2px solid #00267C;
          }
          
          .card-header h3 {
            color: #00267C;
            font-size: 14px;
            font-weight: 700;
            margin: 0;
            text-transform: uppercase;
          }
          
          .card-body {
            padding: 12px 15px;
          }
          
          .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
          }
          
          .info-row {
            display: flex;
            flex-direction: column;
          }
          
          .info-label {
            font-size: 10px;
            font-weight: 600;
            color: #6c757d;
            text-transform: uppercase;
            margin-bottom: 3px;
          }
          
          .info-value {
            font-size: 13px;
            font-weight: 500;
            color: #212529;
          }
          
          .summary-table {
            width: 100%;
            border-collapse: collapse;
          }
          
          .summary-table tr {
            border-bottom: 1px solid #e9ecef;
          }
          
          .summary-table td {
            padding: 8px 5px;
            font-size: 12px;
          }
          
          .summary-table td:first-child {
            font-weight: 500;
            color: #495057;
          }
          
          .summary-table td:last-child {
            text-align: right;
            font-weight: 600;
            color: #212529;
          }
          
          .total-row {
            background: #e8f0fe;
          }
          
          .total-row td {
            font-weight: 700 !important;
            color: #00267C !important;
          }
          
          .highlight-box {
            background: linear-gradient(135deg, #e8f0fe 0%, #d4e2f7 100%);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            margin-top: 12px;
          }
          
          .highlight-label {
            font-size: 11px;
            font-weight: 600;
            color: #00267C;
            text-transform: uppercase;
            margin-bottom: 5px;
          }
          
          .highlight-amount {
            font-size: 28px;
            font-weight: 800;
            color: #00267C;
            margin: 5px 0;
          }
          
          .highlight-words {
            font-size: 10px;
            color: #495057;
            font-style: italic;
            border-top: 1px dashed #00267C40;
            padding-top: 8px;
            margin-top: 5px;
          }
          
          .declaration-box {
            background: #f8f9fa;
            border-left: 3px solid #00267C;
            padding: 10px 15px;
            margin: 12px 0;
            font-size: 10px;
            color: #495057;
            line-height: 1.4;
          }
          
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 15px;
          }
          
          .signature-box {
            text-align: center;
            width: 45%;
          }
          
          .signature-image {
            max-height: 50px;
            margin-bottom: 8px;
            object-fit: contain;
          }
          
          .signature-line {
            border-top: 1px solid #212529;
            padding-top: 6px;
            font-size: 10px;
            font-weight: 600;
            color: #6c757d;
          }
          
          .footer-section {
            background: linear-gradient(135deg, #00267C 0%, #003d9e 100%);
            padding: 10px 20px;
            text-align: center;
            color: white;
            font-size: 8px;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
          }
          
          .footer-company {
            font-weight: 700;
            margin-bottom: 3px;
          }
          
          .footer-address {
            opacity: 0.8;
            margin-bottom: 3px;
          }
          
          .footer-contact {
            opacity: 0.7;
          }
          
          @media print {
            body {
              background: white;
              padding: 0;
              margin: 0;
            }
            .document-container {
              box-shadow: none;
              page-break-after: avoid;
              page-break-inside: avoid;
            }
            .header-section, .footer-section {
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
          }
        </style>
      </head>
      <body>
        <div class="document-container">
          <div class="header-section">
            <div class="header-content">
              <div class="logo-area">
                <img src="${logoUrl}" alt="MyChits Logo" onerror="this.src='data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' fill='%2300267C'/%3E%3Ctext x='50' y='50' text-anchor='middle' dy='.3em' fill='white' font-size='14' font-family='Arial'%3EMC%3C/text%3E%3C/svg%3E'">
              </div>
              <div class="company-info">
                <div class="company-name">MYCHITS</div>
                <div class="company-tagline">Chit Funds • Loans • Investments</div>
              </div>
              <div class="document-meta">
                <div class="meta-item">
                  <span class="meta-label">Date:</span> ${currentDate}
                </div>
               
              </div>
            </div>
          </div>
          
          <div class="title-section">
            <div class="document-title">Chit Collection Incentive Slip</div>
          </div>
          
          <div class="content-section">
            <div class="info-card">
              <div class="card-header">
                <h3>Agent / Employee Details</h3>
              </div>
              <div class="card-body">
                <div class="info-grid">
                  <div class="info-row">
                    <span class="info-label">Agent Name</span>
                    <span class="info-value">${agent?.name || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Employee ID</span>
                    <span class="info-value">${agent?.employeeCode || agent?._id?.slice(-6) || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Phone Number</span>
                    <span class="info-value">${agent?.phone_number || "N/A"}</span>
                  </div>
                  <div class="info-row">
                    <span class="info-label">Reporting Period</span>
                    <span class="info-value">${period}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="info-card">
              <div class="card-header">
                <h3>Collection & Incentive Summary</h3>
              </div>
              <div class="card-body">
                <table class="summary-table">
                  <tbody>
                    </td>
                      <td>Total Collection Amount</td>
                      <td>₹${chitSummary.total_collection?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td>
                    </tr>
                    <tr>
                      <td>Incentive Percentage Rate</td>
                      <td>${incentivePercentage}%</td>
                    </tr>
                    <tr>
                      <td>Total Transactions (Records)</td>
                      <td>${chitData.length}</td>
                    </tr>
                    <tr>
                      <td>Completed Collections</td>
                      <td>${chitSummary.completed_chits}</td>
                    </tr>
                    <tr>
                      <td>Pending Collections</td>
                      <td>${chitSummary.pending_chits}</td>
                    </tr>
                    <tr class="total-row">
                      <td style="font-weight: 700;">Gross Incentive Earned</td>
                      <td style="font-weight: 700; color: #00267C;">₹${chitSummary.total_incentive?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td>
                    </tr>
                  </tbody>
                </table>
                
                <div class="highlight-box">
                  <div class="highlight-label">Net Payable Amount</div>
                  <div class="highlight-amount">₹${chitSummary.total_incentive?.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</div>
                  <div class="highlight-words">
                    Rupees ${amountInWords} Only
                  </div>
                </div>
              </div>
            </div>
            
            <div class="declaration-box">
              <strong>Declaration:</strong> This is a computer-generated incentive slip for chit collections. The details contained herein are true to the best of our knowledge. Any discrepancy should be reported to the accounts department within 48 hours of receipt.
            </div>
            
            <div class="signature-section">
              <div class="signature-box">
                ${agentSignatureData ? `<img src="${agentSignatureData}" class="signature-image" alt="Agent Sign">` : '<div style="height: 50px;"></div>'}
                <div class="signature-line">Agent's Signature</div>
              </div>
              <div class="signature-box">
                ${signatureData ? `<img src="${signatureData}" class="signature-image" alt="Manager Sign">` : '<div style="height: 50px;"></div>'}
                <div class="signature-line">Authorized Signatory</div>
              </div>
            </div>
          </div>
          
          <div class="footer-section">
            <div class="footer-company">VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED</div>
            <div class="footer-address">#11/36-25, 3rd Floor, 2nd Main, Kathriguppe Main Road, Banashankari 3rd Stage, Bengaluru-560085</div>
            <div class="footer-contact">Mob: 9483900777 | Ph: 080-4979 8763 | Email: info.mychits@gmail.com</div>
          </div>
        </div>
      </body>
      </html>
    `;
  };
  const handleGenerateSlip = async () => {
    if (!selectedEmployeeDetails) {
      message.warning("Please load employee data first by clicking Continue.");
      return;
    }
    setIsGeneratingPDF(true);
    try {
      const htmlContent = generateIncentiveSlipContent();
      const agent = selectedEmployeeDetails;
      const period = dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`;
      const fileName = `Chit_Incentive_Slip_${agent?.name || "Agent"}_${period}.pdf`;
      const tempDiv = document.createElement("div");
      tempDiv.style.position = "absolute";
      tempDiv.style.left = "-9999px";
      tempDiv.style.top = "-9999px";
      tempDiv.style.width = "210mm";
      tempDiv.style.backgroundColor = "#ffffff";
      tempDiv.innerHTML = htmlContent;
      document.body.appendChild(tempDiv);
      await new Promise((r) => setTimeout(r, 800));
      const canvas = await html2canvas(tempDiv, {
        scale: 3,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
        windowWidth: 800,
        allowTaint: false,
        foreignObjectRendering: false
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pageWidth = 210;
      const imgWidth = pageWidth;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      pdf.save(fileName);
      document.body.removeChild(tempDiv);
      message.success("Chit Incentive Slip downloaded successfully!");
    } catch (error) {
      console.error("Error generating PDF:", error);
      message.error("Failed to generate incentive slip");
    } finally {
      setIsGeneratingPDF(false);
    }
  };
  const handlePrintSlip = () => {
    if (!selectedEmployeeDetails) {
      message.warning("Please load employee data first by clicking Continue.");
      return;
    }
    const htmlContent = generateIncentiveSlipContent();
    const printWindow = window.open("", "_blank");
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 500);
  };
  const processedTableData = chitData.map((payment, index) => ({
    key: payment._id || index,
    sno: index + 1,
    customer_name: payment.user_id?.full_name || "N/A",
    phone_number: payment.user_id?.phone_number || "N/A",
    chit_group: payment.group_id?.group_name || "N/A",
    ticket_number: payment.ticket || "N/A",
    amount: payment.amount || 0,
    payment_date: payment.pay_date || "N/A",
    transaction_date: payment.createdAt?.split("T")[0] || "N/A",
    payment_mode: payment.pay_type || "N/A",
    receipt_no: payment.receipt_no || "N/A",
    transaction_id: payment.transaction_id || "N/A"
  }));
  const columns = [
    { key: "sno", header: "SL.No" },
    { key: "payment_date", header: "Payment Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "chit_group", header: "Chit Group" },
    { key: "ticket_number", header: "Ticket No" },
    { key: "amount", header: "Amount (₹)" },
    { key: "payment_mode", header: "Payment Mode" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "transaction_id", header: "Transaction ID" }
  ];
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  const selectedEmployee = employees.find(
    (emp) => emp._id === selectedEmployeeId
  );
  const SignatureUpload = ({ type, label, signatureData: signatureData2, onChange }) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-2 p-3 border rounded-lg", children: [
    signatureData2 && /* @__PURE__ */ jsxDEV("img", { src: signatureData2, alt: `${label} Signature`, className: "h-12 object-contain" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 814,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("label", { className: "cursor-pointer", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "file",
          accept: "image/*",
          onChange: (e) => onChange(e, type),
          className: "hidden"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 817,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Button, { size: "small", icon: /* @__PURE__ */ jsxDEV(SignatureOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 823,
        columnNumber: 36
      }, this), children: [
        signatureData2 ? "Change" : "Upload",
        " ",
        label,
        " Signature"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 823,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 816,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
    lineNumber: 812,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent", children: "Chit Collection Incentive Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 835,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2 text-lg", children: "Track and manage chit collection incentives and commissions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 838,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 834,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-full p-3 shadow-md", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-3xl text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 843,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 842,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 833,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 832,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mt-6 mb-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FiTarget, { className: "text-blue-600", size: 18 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 851,
            columnNumber: 13
          }, this),
          "Quick Navigation to Other Reports"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 850,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Explore other incentive reports" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 854,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 849,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/loancollection-incentive",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-purple-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-purple-100 rounded-lg group-hover:bg-purple-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                FiTarget,
                {
                  className: "text-purple-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 865,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 864,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-purple-600 transition-colors", children: "Loan Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 871,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "View loan-based incentives" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 874,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 870,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-purple-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 5l7 7-7 7" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 878,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 877,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 876,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 863,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 859,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/pigmycollection-incentive",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-green-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-green-100 rounded-lg group-hover:bg-green-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                FaRupeeSign,
                {
                  className: "text-green-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 890,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 889,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-green-600 transition-colors", children: "Pigmy Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 896,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "Track pigmy collections" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 899,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 895,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-green-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 5l7 7-7 7" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 903,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 902,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 901,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 888,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 884,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/reports/target-incentive-new",
            className: "group relative overflow-hidden bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-blue-400 hover:shadow-lg transition-all duration-300",
            children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-lg group-hover:bg-blue-500 transition-colors duration-300", children: /* @__PURE__ */ jsxDEV(
                MdGroups,
                {
                  className: "text-blue-600 group-hover:text-white transition-colors duration-300",
                  size: 22
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 916,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 915,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 group-hover:text-blue-600 transition-colors", children: "Chit Business Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 922,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "Track Chit collections" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 925,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 921,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-blue-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 5l7 7-7 7" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 929,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 928,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 927,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 914,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 910,
            columnNumber: 14
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 858,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 857,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 848,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 943,
            columnNumber: 22
          }, this),
          value: chitSummary.total_collection,
          precision: 2,
          prefix: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-green-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 946,
            columnNumber: 23
          }, this),
          valueStyle: { color: "#3f8600", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 942,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 941,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 940,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-4", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 956,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 955,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Incentive" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 960,
            columnNumber: 22
          }, this),
          value: chitSummary.total_incentive,
          precision: 2,
          prefix: /* @__PURE__ */ jsxDEV(RiseOutlined, { className: "text-purple-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 963,
            columnNumber: 23
          }, this),
          valueStyle: { color: "#722ed1", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 959,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 953,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 952,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg hover:shadow-xl transition-shadow", children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600", children: "Total Records" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 973,
            columnNumber: 22
          }, this),
          value: chitSummary.total_chits,
          prefix: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-blue-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 975,
            columnNumber: 23
          }, this),
          valueStyle: { color: "#1890ff", fontSize: "24px" }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 972,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 971,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 970,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 939,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-b border-gray-100", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FileSearchOutlined, { className: "text-blue-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 987,
          columnNumber: 13
        }, this),
        "Report Filters"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 986,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 985,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Date Selection Mode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 995,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Radio.Group,
              {
                value: dateSelectionMode,
                onChange: (e) => setDateSelectionMode(e.target.value),
                buttonStyle: "solid",
                children: [
                  /* @__PURE__ */ jsxDEV(Radio.Button, { value: "month", children: "Monthly" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                    lineNumber: 1003,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Radio.Button, { value: "date-range", children: "Date Range" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                    lineNumber: 1004,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 998,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 994,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Select Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1009,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Search employee by name or phone",
                value: selectedEmployeeId,
                onChange: setSelectedEmployeeId,
                className: "w-full",
                filterOption: (input, option) => (option?.label?.toLowerCase() || "").includes(input.toLowerCase()),
                options: employees.map((emp) => ({
                  value: emp._id,
                  label: `${emp.name} (${emp.phone_number})`
                }))
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1012,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1008,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 993,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: dateSelectionMode === "month" ? "Select Month" : "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1031,
              columnNumber: 15
            }, this),
            dateSelectionMode === "month" ? /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "month",
                value: tempSelectedMonth || "",
                onChange: handleTempMonthChange,
                max: currentMonth,
                className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1035,
                columnNumber: 15
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: tempFromDate || "",
                onChange: (e) => setTempFromDate(e.target.value),
                className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1043,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1030,
            columnNumber: 13
          }, this),
          dateSelectionMode === "date-range" && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1054,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: tempToDate || "",
                onChange: (e) => setTempToDate(e.target.value),
                className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1057,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1053,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Incentive Percentage (%)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1067,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                step: "0.1",
                min: "0",
                value: incentivePercentage,
                onChange: (e) => setIncentivePercentage(parseFloat(e.target.value)),
                className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1070,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1066,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1029,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3", children: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => {
            setSelectedEmployeeId(null);
            setSelectedEmployeeDetails(null);
            setChitData([]);
            setChitSummary({
              total_collection: 0,
              total_incentive: 0,
              total_chits: 0,
              completed_chits: 0,
              pending_chits: 0
            });
            setIsFiltering(false);
          }, children: "Reset" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1082,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              icon: /* @__PURE__ */ jsxDEV(FileSearchOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1099,
                columnNumber: 21
              }, this),
              loading,
              onClick: handleContinue,
              className: "bg-blue-600",
              children: "Continue"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1097,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1081,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 992,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 984,
      columnNumber: 7
    }, this),
    isFiltering && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1115,
              columnNumber: 17
            }, this),
            "Employee Information & Actions"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1114,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Space, { children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                icon: /* @__PURE__ */ jsxDEV(PrinterOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 1120,
                  columnNumber: 23
                }, this),
                onClick: handlePrintSlip,
                children: "Print Slip"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1119,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(DownloadOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                  lineNumber: 1127,
                  columnNumber: 23
                }, this),
                loading: isGeneratingPDF,
                onClick: handleGenerateSlip,
                className: "bg-green-600",
                children: "Download Slip"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
                lineNumber: 1125,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1118,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1113,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Employee Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1139,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold", children: selectedEmployeeDetails?.name || "-" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1140,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1138,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Employee Code" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1143,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold", children: selectedEmployeeDetails?.employeeCode || "-" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1144,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1142,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Phone Number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1147,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold", children: selectedEmployeeDetails?.phone_number || "-" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1148,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1146,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Email" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1151,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold", children: selectedEmployeeDetails?.email || "-" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1152,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1150,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1137,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1136,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 1112,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1161,
            columnNumber: 17
          }, this),
          "Collection Summary"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1160,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1159,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-lg p-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Period" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1168,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-green-700", children: dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString("default", {
              month: "long",
              year: "numeric"
            }) : `${fromDate} to ${toDate}` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1169,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1167,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-lg p-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Collection" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1179,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-blue-700 text-xl", children: [
              "₹",
              chitSummary.total_collection?.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1180,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1178,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 rounded-lg p-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Incentive" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-purple-700 text-xl", children: [
              "₹",
              chitSummary.total_incentive?.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1186,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1184,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 rounded-lg p-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Records" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1191,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-orange-700 text-xl", children: chitData.length }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1192,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1190,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1166,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1165,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 1158,
        columnNumber: 11
      }, this),
      loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 1200,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 1199,
        columnNumber: 9
      }, this) : isFiltering && chitData.length > 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "shadow-lg rounded-xl overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(FileSearchOutlined, { className: "text-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
              lineNumber: 1206,
              columnNumber: 17
            }, this),
            "Payment Details"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1205,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: [
            "Showing ",
            chitData.length,
            " payment records"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1209,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1204,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: processedTableData,
            columns,
            exportedPdfName: `Chit_Collection_Incentive_Report_${selectedEmployeeDetails?.name}_${dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`}`,
            printHeaderKeys: [
              "Employee Name",
              "Employee Code",
              "Phone Number",
              "Period",
              "Incentive Percentage",
              "Total Collection",
              "Total Incentive",
              "Total Records"
            ],
            printHeaderValues: [
              selectedEmployeeDetails?.name || "-",
              selectedEmployeeDetails?.employeeCode || "-",
              selectedEmployeeDetails?.phone_number || "-",
              dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${tempSelectedMonth}-01`)).toLocaleString("default", {
                month: "long",
                year: "numeric"
              }) : `${fromDate} to ${toDate}`,
              `${incentivePercentage}%`,
              `₹${chitSummary.total_collection?.toLocaleString("en-IN") || "0"}`,
              `₹${chitSummary.total_incentive?.toLocaleString("en-IN") || "0"}`,
              chitData.length || "0"
            ],
            exportedFileName: `ChitCollectionReport_${selectedEmployeeDetails?.name || "all"}_${dateSelectionMode === "month" ? tempSelectedMonth : `${fromDate}_to_${toDate}`}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
            lineNumber: 1215,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
          lineNumber: 1214,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
        lineNumber: 1203,
        columnNumber: 9
      }, this) : null
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
      lineNumber: 1111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx",
    lineNumber: 831,
    columnNumber: 5
  }, this);
};
_s(ChitCollectionIncentiveReport, "C7Er6YtwPAFgBNhha2p0ul36X90=");
_c = ChitCollectionIncentiveReport;
export default ChitCollectionIncentiveReport;
var _c;
$RefreshReg$(_c, "ChitCollectionIncentiveReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCollectionIncentiveReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNnlCUSxTQXlTQSxVQXpTQTsyQkE3eUJSO0FBQWdCQSxNQUFXQyxjQUFRLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGlCQUFpQjtBQUV4QixNQUFNQyxnQ0FBZ0NBLE1BQU07QUFBQUMsS0FBQTtBQUMxQyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSWhDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNpQyxvQkFBb0JDLHFCQUFxQixJQUFJbEMsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ21DLG1CQUFtQkMsb0JBQW9CLElBQUlwQyxTQUFTLE9BQU87QUFDbEUsUUFBTSxDQUFDcUMsbUJBQW1CQyxvQkFBb0IsSUFBSXRDLFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUN1QyxjQUFjQyxlQUFlLElBQUl4QyxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDeUMsWUFBWUMsYUFBYSxJQUFJMUMsU0FBUyxJQUFJO0FBQ2pELFFBQU0sQ0FBQzJDLHFCQUFxQkMsc0JBQXNCLElBQUk1QyxTQUFTLENBQUc7QUFDbEUsUUFBTSxDQUFDNkMsU0FBU0MsVUFBVSxJQUFJOUMsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQytDLFVBQVVDLFdBQVcsSUFBSWhELFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpRCxhQUFhQyxjQUFjLElBQUlsRCxTQUFTO0FBQUEsSUFDN0NtRCxrQkFBa0I7QUFBQSxJQUNsQkMsaUJBQWlCO0FBQUEsSUFDakJDLGFBQWE7QUFBQSxJQUNiQyxpQkFBaUI7QUFBQSxJQUNqQkMsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXpELFNBQVMsSUFBSTtBQUM3QyxRQUFNLENBQUMwRCxRQUFRQyxTQUFTLElBQUkzRCxTQUFTLElBQUk7QUFDekMsUUFBTSxDQUFDNEQseUJBQXlCQywwQkFBMEIsSUFBSTdELFNBQVMsSUFBSTtBQUMzRSxRQUFNLENBQUM4RCxhQUFhQyxjQUFjLElBQUkvRCxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDZ0UsaUJBQWlCQyxrQkFBa0IsSUFBSWpFLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNrRSxlQUFlQyxnQkFBZ0IsSUFBSW5FLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUNvRSxvQkFBb0JDLHFCQUFxQixJQUFJckUsU0FBUyxJQUFJO0FBRWpFRCxZQUFVLE1BQU07QUFDZCxVQUFNdUUsU0FBUSxvQkFBSUMsS0FBSztBQUN2QixVQUFNQyxnQkFBZSxHQUFHRixPQUFNRyxZQUFZLENBQUMsSUFBSUM7QUFBQUEsTUFDN0NKLE9BQU1LLFNBQVMsSUFBSTtBQUFBLElBQ3JCLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFFbEJ0Qyx5QkFBcUJrQyxhQUFZO0FBRWpDLFVBQU1LLE9BQU9QLE9BQU1HLFlBQVk7QUFDL0IsVUFBTUssUUFBUVIsT0FBTUssU0FBUyxJQUFJO0FBQ2pDLFVBQU1JLFdBQVcsR0FBR0YsSUFBSSxJQUFJSCxPQUFPSSxLQUFLLEVBQUVGLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDMUQsVUFBTUksVUFBVSxJQUFJVCxLQUFLTSxNQUFNQyxPQUFPLENBQUMsRUFBRUcsUUFBUTtBQUVqRHpDLG9CQUFnQnVDLFFBQVE7QUFDeEJyQztBQUFBQSxNQUNFLEdBQUdtQyxJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQyxJQUFJRixPQUFPTSxPQUFPLEVBQUVKLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFBQSxJQUMvRTtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUw3RSxZQUFVLE1BQU07QUFDZCxVQUFNbUYsaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGLGNBQU1DLE1BQU0sTUFBTWhFLElBQUlpRSxJQUFJLFdBQVc7QUFDckNwRCxxQkFBYW1ELEtBQUtFLE1BQU1DLFlBQVksRUFBRTtBQUFBLE1BQ3hDLFNBQVNDLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU1GLEdBQUc7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFDQUwsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNUSx3QkFBd0JBLENBQUNDLE1BQU07QUFDbkMsVUFBTUMsUUFBUUQsRUFBRUUsT0FBT0Q7QUFDdkJ0RCx5QkFBcUJzRCxLQUFLO0FBQzFCLFFBQUlBLE9BQU87QUFDVCxZQUFNLENBQUNmLE1BQU1DLEtBQUssSUFBSWMsTUFBTUUsTUFBTSxHQUFHO0FBQ3JDLFlBQU1mLFdBQVcsR0FBR0YsSUFBSSxJQUFJQyxLQUFLO0FBQ2pDLFlBQU1FLFVBQVUsSUFBSVQsS0FBS00sTUFBTUMsT0FBTyxDQUFDLEVBQUVHLFFBQVE7QUFDakR6QyxzQkFBZ0J1QyxRQUFRO0FBQ3hCckMsb0JBQWMsR0FBR21DLElBQUksSUFBSUMsS0FBSyxJQUFJSixPQUFPTSxPQUFPLEVBQUVKLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFBRTtBQUFBLElBQ3RFO0FBQUEsRUFDRjtBQUVBLFFBQU1tQiwwQkFBMEIsT0FBT0MsWUFBWUMsV0FBV0MsWUFBWTtBQUN4RSxRQUFJLENBQUNGLGNBQWMsQ0FBQ0MsYUFBYSxDQUFDQyxRQUFTO0FBRTNDLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU1oRixJQUFJaUU7QUFBQUEsUUFDekIsOENBQThDWSxVQUFVLElBQUlyRCxtQkFBbUI7QUFBQSxRQUMvRTtBQUFBLFVBQ0V5RCxRQUFRO0FBQUEsWUFDTkg7QUFBQUEsWUFDQUM7QUFBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsVUFBSUMsU0FBU2QsUUFBUWMsU0FBU2QsS0FBS2dCLFNBQVM7QUFDMUMsY0FBTUMsZUFBZUgsU0FBU2QsS0FBS0EsUUFBUTtBQUUzQyxZQUFJa0IsY0FBYztBQUNsQixZQUFJQyxrQkFBa0I7QUFDdEIsWUFBSUMsaUJBQWlCO0FBR3JCSCxxQkFBYUksUUFBUSxDQUFDQyxTQUFTO0FBQzdCLGNBQUlBLEtBQUtDLFlBQVlDLE1BQU1DLFFBQVFILEtBQUtDLFFBQVEsR0FBRztBQUNqREwsMEJBQWMsQ0FBQyxHQUFHQSxhQUFhLEdBQUdJLEtBQUtDLFFBQVE7QUFDL0NKLCtCQUFtQkcsS0FBS0ksa0JBQWtCO0FBQzFDTiw4QkFBa0JFLEtBQUtLLG9CQUFvQjtBQUFBLFVBQzdDO0FBQUEsUUFDRixDQUFDO0FBRURoRSxvQkFBWXVELFdBQVc7QUFDdkJyRCx1QkFBZTtBQUFBLFVBQ2JDLGtCQUFrQnFEO0FBQUFBLFVBQ2xCcEQsaUJBQWlCcUQ7QUFBQUEsVUFDakJwRCxhQUFha0QsWUFBWVU7QUFBQUEsVUFDekIzRCxpQkFBaUJpRCxZQUFZVztBQUFBQSxZQUMzQixDQUFDQyxNQUFNQSxFQUFFQyxXQUFXLGVBQWVELEVBQUVFO0FBQUFBLFVBQ3ZDLEVBQUVKO0FBQUFBLFVBQ0YxRCxlQUFlZ0QsWUFBWVc7QUFBQUEsWUFDekIsQ0FBQ0MsTUFBTUEsRUFBRUMsV0FBVyxlQUFlLENBQUNELEVBQUVFO0FBQUFBLFVBQ3hDLEVBQUVKO0FBQUFBLFFBQ0osQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMakUsb0JBQVksRUFBRTtBQUNkRSx1QkFBZTtBQUFBLFVBQ2JDLGtCQUFrQjtBQUFBLFVBQ2xCQyxpQkFBaUI7QUFBQSxVQUNqQkMsYUFBYTtBQUFBLFVBQ2JDLGlCQUFpQjtBQUFBLFVBQ2pCQyxlQUFlO0FBQUEsUUFDakIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNnQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sd0NBQXdDRixHQUFHO0FBQ3pEOUUsY0FBUWdGLE1BQU1GLElBQUlZLFVBQVVkLE1BQU01RSxXQUFXLHNCQUFzQjtBQUNuRXVDLGtCQUFZLEVBQUU7QUFDZEUscUJBQWU7QUFBQSxRQUNiQyxrQkFBa0I7QUFBQSxRQUNsQkMsaUJBQWlCO0FBQUEsUUFDakJDLGFBQWE7QUFBQSxRQUNiQyxpQkFBaUI7QUFBQSxRQUNqQkMsZUFBZTtBQUFBLE1BQ2pCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0rRCxpQkFBaUIsWUFBWTtBQUNqQyxRQUFJLENBQUNyRixvQkFBb0I7QUFDdkJ4QixjQUFROEcsUUFBUSw0QkFBNEI7QUFDNUM7QUFBQSxJQUNGO0FBRUEsUUFBSXBGLHNCQUFzQixXQUFXLENBQUNFLG1CQUFtQjtBQUN2RDVCLGNBQVE4RyxRQUFRLHdCQUF3QjtBQUN4QztBQUFBLElBQ0Y7QUFFQSxRQUFJcEYsc0JBQXNCLGlCQUFpQixDQUFDSSxnQkFBZ0IsQ0FBQ0UsYUFBYTtBQUN4RWhDLGNBQVE4RyxRQUFRLHVDQUF1QztBQUN2RDtBQUFBLElBQ0Y7QUFFQXhELG1CQUFlLElBQUk7QUFDbkJqQixlQUFXLElBQUk7QUFFZixRQUFJbUQsV0FBV0M7QUFFZixRQUFJL0Qsc0JBQXNCLFNBQVM7QUFDakMsWUFBTSxDQUFDMEMsTUFBTUMsS0FBSyxJQUFJekMsa0JBQWtCeUQsTUFBTSxHQUFHO0FBQ2pERyxrQkFBWSxHQUFHcEIsSUFBSSxJQUFJQyxLQUFLO0FBQzVCLFlBQU1FLFVBQVUsSUFBSVQsS0FBS00sTUFBTUMsT0FBTyxDQUFDLEVBQUVHLFFBQVE7QUFDakRpQixnQkFBVSxHQUFHckIsSUFBSSxJQUFJQyxLQUFLLElBQUlKLE9BQU9NLE9BQU8sRUFBRUosU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUM5RG5CLGtCQUFZd0MsU0FBUztBQUNyQnRDLGdCQUFVdUMsT0FBTztBQUFBLElBQ25CLE9BQU87QUFDTEQsa0JBQVkxRDtBQUNaMkQsZ0JBQVV6RDtBQUNWZ0Isa0JBQVl3QyxTQUFTO0FBQ3JCdEMsZ0JBQVV1QyxPQUFPO0FBQUEsSUFDbkI7QUFFQSxRQUFJO0FBQ0YsWUFBTXNCLE1BQU16RixVQUFVMEYsS0FBSyxDQUFDOUIsTUFBTUEsRUFBRStCLFFBQVF6RixrQkFBa0I7QUFDOUQ0QixpQ0FBMkIyRCxPQUFPLElBQUk7QUFDdEMsWUFBTXpCLHdCQUF3QjlELG9CQUFvQmdFLFdBQVdDLE9BQU87QUFDcEV6RixjQUFRNEYsUUFBUSwyQkFBMkI7QUFBQSxJQUM3QyxTQUFTWixPQUFPO0FBQ2RELGNBQVFDLE1BQU0sNEJBQTRCQSxLQUFLO0FBQy9DaEYsY0FBUWdGLE1BQU0scUJBQXFCO0FBQUEsSUFDckMsVUFBQztBQUNDM0MsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUdBLFFBQU02RSxhQUFhQSxDQUFDQyxRQUFRO0FBQzFCLFFBQUlDLE1BQU1ELEdBQUcsS0FBS0EsUUFBUSxFQUFHLFFBQU87QUFFcEMsVUFBTUUsSUFBSTtBQUFBLE1BQ1I7QUFBQSxNQUFJO0FBQUEsTUFBTztBQUFBLE1BQU87QUFBQSxNQUFTO0FBQUEsTUFBUTtBQUFBLE1BQVE7QUFBQSxNQUFPO0FBQUEsTUFBUztBQUFBLE1BQVM7QUFBQSxNQUNwRTtBQUFBLE1BQU87QUFBQSxNQUFVO0FBQUEsTUFBVTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBVztBQUFBLE1BQzlEO0FBQUEsTUFBYTtBQUFBLE1BQVk7QUFBQSxJQUFVO0FBRXJDLFVBQU1DLElBQUksQ0FBQyxJQUFJLElBQUksVUFBVSxVQUFVLFNBQVMsU0FBUyxTQUFTLFdBQVcsVUFBVSxRQUFRO0FBRS9GLFFBQUlDLFNBQVNKO0FBQ2JJLGFBQVNDLEtBQUtDLE1BQU1GLE1BQU07QUFDMUIsU0FBS0EsU0FBU0EsT0FBT0csU0FBUyxHQUFHbEIsU0FBUyxFQUFHLFFBQU87QUFFcEQsVUFBTW1CLEtBQUssY0FBY0osUUFBUUssT0FBTyxFQUFFLEVBQUVDLE1BQU0sdUNBQXVDO0FBQ3pGLFFBQUksQ0FBQ0YsRUFBRyxRQUFPO0FBRWYsUUFBSUcsTUFBTTtBQUNWQSxXQUFPSCxFQUFFLENBQUMsS0FBSyxLQUFLTixFQUFFVSxPQUFPSixFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUtMLEVBQUVLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU1OLEVBQUVNLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFlBQVk7QUFDcEZHLFdBQU9ILEVBQUUsQ0FBQyxLQUFLLEtBQUtOLEVBQUVVLE9BQU9KLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBS0wsRUFBRUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTU4sRUFBRU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssV0FBVztBQUNuRkcsV0FBT0gsRUFBRSxDQUFDLEtBQUssS0FBS04sRUFBRVUsT0FBT0osRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLTCxFQUFFSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNTixFQUFFTSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxlQUFlO0FBQ3ZGRyxXQUFPSCxFQUFFLENBQUMsS0FBSyxLQUFLTixFQUFFVSxPQUFPSixFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUtMLEVBQUVLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU1OLEVBQUVNLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLGNBQWM7QUFDdEZHLFdBQU9ILEVBQUUsQ0FBQyxLQUFLLEtBQUtHLE9BQU8sS0FBSyxTQUFTLE9BQU9ULEVBQUVVLE9BQU9KLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBS0wsRUFBRUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTU4sRUFBRU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssTUFBTTtBQUUxRyxXQUFPRyxJQUFJRSxLQUFLLEtBQUs7QUFBQSxFQUN2QjtBQUdBLFFBQU1DLHdCQUF3QkEsQ0FBQy9DLEdBQUdnRCxTQUFTO0FBQ3pDLFVBQU1DLE9BQU9qRCxFQUFFRSxPQUFPZ0QsTUFBTSxDQUFDO0FBQzdCLFFBQUlELE1BQU07QUFDUixZQUFNRSxTQUFTLElBQUlDLFdBQVc7QUFDOUJELGFBQU9FLFlBQVksTUFBTTtBQUN2QixZQUFJTCxTQUFTLFdBQVc7QUFDdEJ4RSwyQkFBaUIyRSxPQUFPRyxNQUFNO0FBQUEsUUFDaEMsT0FBTztBQUNMNUUsZ0NBQXNCeUUsT0FBT0csTUFBTTtBQUFBLFFBQ3JDO0FBQUEsTUFDRjtBQUNBSCxhQUFPSSxjQUFjTixJQUFJO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsUUFBTU8sK0JBQStCQSxNQUFNO0FBQ3pDLFVBQU1DLFFBQVF4RjtBQUNkLFVBQU15RixTQUFTbEgsc0JBQXNCLFdBQ2pDLG9CQUFJb0MsS0FBSyxHQUFHbEMsaUJBQWlCLEtBQUssR0FBRWlILGVBQWUsV0FBVyxFQUFFeEUsT0FBTyxRQUFRRCxNQUFNLFVBQVUsQ0FBQyxJQUNoRyxHQUFHckIsUUFBUSxPQUFPRSxNQUFNO0FBRTVCLFVBQU02RixnQkFBZ0I1QixXQUFXMUUsWUFBWUcsZUFBZTtBQUM1RCxVQUFNb0csYUFBYSxZQUFZakYsS0FBS2tGLElBQUksRUFBRXRCLFNBQVMsRUFBRXVCLE1BQU0sRUFBRSxDQUFDO0FBQzlELFVBQU1DLGVBQWMsb0JBQUlwRixLQUFLLEdBQUVxRixtQkFBbUIsU0FBUyxFQUFFQyxLQUFLLFdBQVcvRSxPQUFPLFFBQVFELE1BQU0sVUFBVSxDQUFDO0FBRTdHLFVBQU1pRixVQUFVcEksV0FBV3FJLFdBQVcsTUFBTSxJQUFJckksYUFBYXNJLE9BQU9DLFNBQVNDLFNBQVN4STtBQUV0RixXQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FLNEIwSCxPQUFPZSxRQUFRLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQWlUakNMLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBEQVF1QkgsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBb0J0QlAsT0FBT2UsUUFBUSxLQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBSXBCZixPQUFPZ0IsZ0JBQWdCaEIsT0FBTzFCLEtBQUtnQyxNQUFNLEVBQUUsS0FBSyxLQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBSXJETixPQUFPaUIsZ0JBQWdCLEtBQUs7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQ0FJNUJoQixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWV4QnBHLFlBQVlFLGtCQUFrQm1HLGVBQWUsU0FBUyxFQUFFZ0IsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBSXBGM0gsbUJBQW1CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBSW5CSSxTQUFTa0UsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUlmaEUsWUFBWUssZUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUkzQkwsWUFBWU0sYUFBYTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVFQUlrQk4sWUFBWUcsaUJBQWlCa0csZUFBZSxTQUFTLEVBQUVnQix1QkFBdUIsRUFBRSxDQUFDLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtREFPdEdySCxZQUFZRyxpQkFBaUJrRyxlQUFlLFNBQVMsRUFBRWdCLHVCQUF1QixFQUFFLENBQUMsQ0FBQztBQUFBO0FBQUEsNkJBRXhHZixhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVl4Qm5GLHFCQUFxQixhQUFhQSxrQkFBa0IsZ0RBQWdELG1DQUFtQztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUl2SUYsZ0JBQWdCLGFBQWFBLGFBQWEsa0RBQWtELG1DQUFtQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWUvSTtBQUVBLFFBQU1xRyxxQkFBcUIsWUFBWTtBQUNyQyxRQUFJLENBQUMzRyx5QkFBeUI7QUFDNUJuRCxjQUFROEcsUUFBUSx1REFBdUQ7QUFDdkU7QUFBQSxJQUNGO0FBRUF0RCx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YsWUFBTXVHLGNBQWNyQiw2QkFBNkI7QUFDakQsWUFBTUMsUUFBUXhGO0FBQ2QsWUFBTXlGLFNBQVNsSCxzQkFBc0IsVUFBVUUsb0JBQW9CLEdBQUdtQixRQUFRLE9BQU9FLE1BQU07QUFDM0YsWUFBTStHLFdBQVcsdUJBQXVCckIsT0FBT2UsUUFBUSxPQUFPLElBQUlkLE1BQU07QUFFeEUsWUFBTXFCLFVBQVVDLFNBQVNDLGNBQWMsS0FBSztBQUM1Q0YsY0FBUUcsTUFBTUMsV0FBVztBQUN6QkosY0FBUUcsTUFBTUUsT0FBTztBQUNyQkwsY0FBUUcsTUFBTUcsTUFBTTtBQUNwQk4sY0FBUUcsTUFBTUksUUFBUTtBQUN0QlAsY0FBUUcsTUFBTUssa0JBQWtCO0FBQ2hDUixjQUFRUyxZQUFZWDtBQUNwQkcsZUFBU1MsS0FBS0MsWUFBWVgsT0FBTztBQUVqQyxZQUFNLElBQUlZLFFBQVEsQ0FBQUMsTUFBS0MsV0FBV0QsR0FBRyxHQUFHLENBQUM7QUFFekMsWUFBTUUsU0FBUyxNQUFNN0osWUFBWThJLFNBQVM7QUFBQSxRQUN4Q2dCLE9BQU87QUFBQSxRQUNQQyxTQUFTO0FBQUEsUUFDVFQsaUJBQWlCO0FBQUEsUUFDakJVLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLHdCQUF3QjtBQUFBLE1BQzFCLENBQUM7QUFFRCxZQUFNQyxVQUFVUCxPQUFPUSxVQUFVLFdBQVc7QUFDNUMsWUFBTUMsTUFBTSxJQUFJdkssTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUNyQyxZQUFNd0ssWUFBWTtBQUNsQixZQUFNQyxXQUFXRDtBQUNqQixZQUFNRSxZQUFhWixPQUFPYSxTQUFTRixXQUFZWCxPQUFPUjtBQUV0RGlCLFVBQUlLLFNBQVNQLFNBQVMsT0FBTyxHQUFHLEdBQUdJLFVBQVVDLFNBQVM7QUFDdERILFVBQUlNLEtBQUsvQixRQUFRO0FBRWpCRSxlQUFTUyxLQUFLcUIsWUFBWS9CLE9BQU87QUFDakNqSyxjQUFRNEYsUUFBUSw4Q0FBOEM7QUFBQSxJQUNoRSxTQUFTWixPQUFPO0FBQ2RELGNBQVFDLE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDaEYsY0FBUWdGLE1BQU0sbUNBQW1DO0FBQUEsSUFDbkQsVUFBQztBQUNDeEIseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNeUksa0JBQWtCQSxNQUFNO0FBQzVCLFFBQUksQ0FBQzlJLHlCQUF5QjtBQUM1Qm5ELGNBQVE4RyxRQUFRLHVEQUF1RDtBQUN2RTtBQUFBLElBQ0Y7QUFFQSxVQUFNaUQsY0FBY3JCLDZCQUE2QjtBQUNqRCxVQUFNd0QsY0FBYzNDLE9BQU80QyxLQUFLLElBQUksUUFBUTtBQUM1Q0QsZ0JBQVloQyxTQUFTa0MsTUFBTXJDLFdBQVc7QUFDdENtQyxnQkFBWWhDLFNBQVNtQyxNQUFNO0FBQzNCSCxnQkFBWUksTUFBTTtBQUNsQnZCLGVBQVcsTUFBTTtBQUNmbUIsa0JBQVlLLE1BQU07QUFDbEJMLGtCQUFZRyxNQUFNO0FBQUEsSUFDcEIsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUdBLFFBQU1HLHFCQUFxQmxLLFNBQVNtSyxJQUFJLENBQUNDLFNBQVNDLFdBQVc7QUFBQSxJQUMzREMsS0FBS0YsUUFBUXpGLE9BQU8wRjtBQUFBQSxJQUNwQkUsS0FBS0YsUUFBUTtBQUFBLElBQ2JHLGVBQWVKLFFBQVFLLFNBQVNDLGFBQWE7QUFBQSxJQUM3Q3BELGNBQWM4QyxRQUFRSyxTQUFTbkQsZ0JBQWdCO0FBQUEsSUFDL0NxRCxZQUFZUCxRQUFRUSxVQUFVQyxjQUFjO0FBQUEsSUFDNUNDLGVBQWVWLFFBQVFXLFVBQVU7QUFBQSxJQUNqQ0MsUUFBUVosUUFBUVksVUFBVTtBQUFBLElBQzFCQyxjQUFjYixRQUFRYyxZQUFZO0FBQUEsSUFDbENDLGtCQUFrQmYsUUFBUWdCLFdBQVdySSxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxJQUN0RHNJLGNBQWNqQixRQUFRa0IsWUFBWTtBQUFBLElBQ2xDQyxZQUFZbkIsUUFBUW1CLGNBQWM7QUFBQSxJQUNsQ0MsZ0JBQWdCcEIsUUFBUW9CLGtCQUFrQjtBQUFBLEVBQzVDLEVBQUU7QUFHRixRQUFNQyxVQUFVO0FBQUEsSUFDZCxFQUFFbkIsS0FBSyxPQUFPb0IsUUFBUSxRQUFRO0FBQUEsSUFDOUIsRUFBRXBCLEtBQUssZ0JBQWdCb0IsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXBCLEtBQUssb0JBQW9Cb0IsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFcEIsS0FBSyxpQkFBaUJvQixRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVwQixLQUFLLGdCQUFnQm9CLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVwQixLQUFLLGNBQWNvQixRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFcEIsS0FBSyxpQkFBaUJvQixRQUFRLFlBQVk7QUFBQSxJQUM1QyxFQUFFcEIsS0FBSyxVQUFVb0IsUUFBUSxhQUFhO0FBQUEsSUFDdEMsRUFBRXBCLEtBQUssZ0JBQWdCb0IsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXBCLEtBQUssY0FBY29CLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVwQixLQUFLLGtCQUFrQm9CLFFBQVEsaUJBQWlCO0FBQUEsRUFBQztBQUdyRCxRQUFNbkssUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxlQUFlLEdBQUdGLE1BQU1HLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxJQUM3Q0osTUFBTUssU0FBUyxJQUFJO0FBQUEsRUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUVsQixRQUFNOEosbUJBQW1CM00sVUFBVTBGO0FBQUFBLElBQ2pDLENBQUNELFFBQVFBLElBQUlFLFFBQVF6RjtBQUFBQSxFQUN2QjtBQUdBLFFBQU0wTSxrQkFBa0JBLENBQUMsRUFBRWhHLE1BQU1pRyxPQUFPMUssK0JBQWUySyxTQUFTLE1BQzlELHVCQUFDLFNBQUksV0FBVSwwREFDWjNLO0FBQUFBLHNCQUNDLHVCQUFDLFNBQUksS0FBS0EsZ0JBQWUsS0FBSyxHQUFHMEssS0FBSyxjQUFjLFdBQVUseUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUY7QUFBQSxJQUVyRix1QkFBQyxXQUFNLFdBQVUsa0JBQ2Y7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsUUFBTztBQUFBLFVBQ1AsVUFBVSxDQUFDakosTUFBTWtKLFNBQVNsSixHQUFHZ0QsSUFBSTtBQUFBLFVBQ2pDLFdBQVU7QUFBQTtBQUFBLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSW9CO0FBQUEsTUFFcEIsdUJBQUMsVUFBTyxNQUFLLFNBQVEsTUFBTSx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCLEdBQzFDekU7QUFBQUEseUJBQWdCLFdBQVc7QUFBQSxRQUFTO0FBQUEsUUFBRTBLO0FBQUFBLFFBQU07QUFBQSxXQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBR0YsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUVBQ1Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlHQUFnRyxnREFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDJFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiLGlDQUFDLGVBQVksV0FBVSw2QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRCxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBRUYsdUJBQUMsUUFBSyxXQUFVLGtDQUNaO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlFQUNqQjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxpRUFDWjtBQUFBLGlDQUFDLFlBQVMsV0FBVSxpQkFBZ0IsTUFBTSxNQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQUc7QUFBQSxhQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsK0NBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUU7QUFBQSxXQUx2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUo7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUZBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE1BQU07QUFBQTtBQUFBLGdCQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUVXLEtBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNkVBQTRFLHFDQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLGdDQUErQiwwQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxtQkFKeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFBMEIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLGtCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRixLQURyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBO0FBQUEsVUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBdUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsV0FBVTtBQUFBLFlBRVYsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixNQUFNO0FBQUE7QUFBQSxnQkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FFVyxLQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDRFQUEyRSxzQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsdUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1FO0FBQUEsbUJBSnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQXlCLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDaEYsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSxrQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUYsS0FEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQTtBQUFBLFVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXVCQTtBQUFBLFFBR0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNBLElBQUc7QUFBQSxZQUNILFdBQVU7QUFBQSxZQUVWLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsTUFBTTtBQUFBO0FBQUEsZ0JBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRVcsS0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwyRUFBMEUsOENBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQStCLHNDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRTtBQUFBLG1CQUpwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2IsaUNBQUMsU0FBSSxXQUFVLHlCQUF3QixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQy9FLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBYSxHQUFHLEdBQUUsa0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GLEtBRHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUE7QUFBQSxVQXRCRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF1QkQ7QUFBQSxXQTNFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEVBLEtBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4RUE7QUFBQSxTQXZGQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0ZGO0FBQUEsSUFHQSx1QkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FBRyxXQUFVLFFBQy9CO0FBQUEsNkJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkIsaUNBQUMsUUFBSyxXQUFVLCtDQUNkO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsZ0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFDdkQsT0FBTzNMLFlBQVlFO0FBQUFBLFVBQ25CLFdBQVc7QUFBQSxVQUNYLFFBQVEsdUJBQUMsZUFBWSxXQUFVLG9CQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQy9DLFlBQVksRUFBRTJMLE9BQU8sV0FBV0MsVUFBVSxPQUFPO0FBQUE7QUFBQSxRQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLcUQsS0FOdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFFQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QixpQ0FBQyxRQUFLLFdBQVUsK0NBQ2JsTSxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsK0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFDdEQsT0FBT0ksWUFBWUc7QUFBQUEsVUFDbkIsV0FBVztBQUFBLFVBQ1gsUUFBUSx1QkFBQyxnQkFBYSxXQUFVLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLFVBQ2pELFlBQVksRUFBRTBMLE9BQU8sV0FBV0MsVUFBVSxPQUFPO0FBQUE7QUFBQSxRQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLcUQsS0FYekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BRUEsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDdkIsaUNBQUMsUUFBSyxXQUFVLCtDQUNkO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDcEQsT0FBTzlMLFlBQVlJO0FBQUFBLFVBQ25CLFFBQVEsdUJBQUMsZ0JBQWEsV0FBVSxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxVQUMvQyxZQUFZLEVBQUV5TCxPQUFPLFdBQVdDLFVBQVUsT0FBTztBQUFBO0FBQUEsUUFKbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXFELEtBTHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQ0E7QUFBQSxJQUVBLHVCQUFDLFFBQUssV0FBVSw2QkFDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSxzQ0FDYixpQ0FBQyxRQUFHLFdBQVUsaUVBQ1o7QUFBQSwrQkFBQyxzQkFBbUIsV0FBVSxtQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QztBQUFBLFFBQUc7QUFBQSxXQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsbUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQyxNQUFNO0FBQUEsY0FBTjtBQUFBLGdCQUNDLE9BQU81TTtBQUFBQSxnQkFDUCxVQUFVLENBQUN3RCxNQUFNdkQscUJBQXFCdUQsRUFBRUUsT0FBT0QsS0FBSztBQUFBLGdCQUNwRCxhQUFZO0FBQUEsZ0JBRVo7QUFBQSx5Q0FBQyxNQUFNLFFBQU4sRUFBYSxPQUFNLFNBQVEsdUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1DO0FBQUEsa0JBQ25DLHVCQUFDLE1BQU0sUUFBTixFQUFhLE9BQU0sY0FBYSwwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkM7QUFBQTtBQUFBO0FBQUEsY0FON0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLE9BQU8zRDtBQUFBQSxnQkFDUCxVQUFVQztBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBQ1YsY0FBYyxDQUFDOE0sT0FBT0MsWUFDbkJBLFFBQVFMLE9BQU9NLFlBQVksS0FBSyxJQUFJQyxTQUFTSCxNQUFNRSxZQUFZLENBQUM7QUFBQSxnQkFFbkUsU0FBU25OLFVBQVVtTCxJQUFJLENBQUExRixTQUFRO0FBQUEsa0JBQzdCNUIsT0FBTzRCLElBQUlFO0FBQUFBLGtCQUNYa0gsT0FBTyxHQUFHcEgsSUFBSTJDLElBQUksS0FBSzNDLElBQUk2QyxZQUFZO0FBQUEsZ0JBQ3pDLEVBQUU7QUFBQTtBQUFBLGNBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWU07QUFBQSxlQWhCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLGFBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQ2RsSSxnQ0FBc0IsVUFBVSxpQkFBaUIsZUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0NBLHNCQUFzQixVQUNyQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPRSxxQkFBcUI7QUFBQSxnQkFDNUIsVUFBVXFEO0FBQUFBLGdCQUNWLEtBQUtsQjtBQUFBQSxnQkFDTCxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtzSCxJQUd0SDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPakMsZ0JBQWdCO0FBQUEsZ0JBQ3ZCLFVBQVUsQ0FBQ29ELE1BQU1uRCxnQkFBZ0JtRCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBQy9DLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXNIO0FBQUEsZUFqQjFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQ3pELHNCQUFzQixnQkFDckIsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9NLGNBQWM7QUFBQSxnQkFDckIsVUFBVSxDQUFDa0QsTUFBTWpELGNBQWNpRCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBQzdDLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXNIO0FBQUEsZUFSeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBR0YsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0Msd0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxLQUFJO0FBQUEsZ0JBQ0osT0FBT2pEO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2dELE1BQU0vQyx1QkFBdUJ3TSxXQUFXekosRUFBRUUsT0FBT0QsS0FBSyxDQUFDO0FBQUEsZ0JBQ2xFLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXNIO0FBQUEsZUFWeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrREE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFVBQU8sU0FBUyxNQUFNO0FBQ3JCMUQsa0NBQXNCLElBQUk7QUFDMUIyQix1Q0FBMkIsSUFBSTtBQUMvQmIsd0JBQVksRUFBRTtBQUNkRSwyQkFBZTtBQUFBLGNBQ2JDLGtCQUFrQjtBQUFBLGNBQ2xCQyxpQkFBaUI7QUFBQSxjQUNqQkMsYUFBYTtBQUFBLGNBQ2JDLGlCQUFpQjtBQUFBLGNBQ2pCQyxlQUFlO0FBQUEsWUFDakIsQ0FBQztBQUNEUSwyQkFBZSxLQUFLO0FBQUEsVUFDdEIsR0FBRyxxQkFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBTSx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQ3pCO0FBQUEsY0FDQSxTQUFTdUQ7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBYTtBQUFBO0FBQUEsWUFMekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsV0FsSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1IQTtBQUFBLFNBM0hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0SEE7QUFBQSxJQUVDeEQsZUFBZUYsMkJBQ2QsbUNBQ0U7QUFBQSw2QkFBQyxRQUFLLFdBQVUsNkJBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUdBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsaUVBQ1o7QUFBQSxtQ0FBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQUc7QUFBQSxlQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQ3RCLFNBQVM4STtBQUFBQSxnQkFBZ0I7QUFBQTtBQUFBLGNBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQ3ZCLFNBQVMxSTtBQUFBQSxnQkFDVCxTQUFTdUc7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUFjO0FBQUE7QUFBQSxjQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxPQUFFLFdBQVUsaUJBQWlCM0csbUNBQXlCdUcsUUFBUSxPQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLGVBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQ2xELHVCQUFDLE9BQUUsV0FBVSxpQkFBaUJ2RyxtQ0FBeUJ3RyxnQkFBZ0IsT0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxlQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw0QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUNqRCx1QkFBQyxPQUFFLFdBQVUsaUJBQWlCeEcsbUNBQXlCeUcsZ0JBQWdCLE9BQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsZUFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLE9BQUUsV0FBVSx5QkFBd0IscUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFDMUMsdUJBQUMsT0FBRSxXQUFVLGlCQUFpQnpHLG1DQUF5QnlMLFNBQVMsT0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxlQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsV0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRDQTtBQUFBLE1BRUEsdUJBQUMsUUFBSyxXQUFVLDZCQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1HQUNiLGlDQUFDLFFBQUcsV0FBVSxpRUFDWjtBQUFBLGlDQUFDLGVBQVksV0FBVSxtQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUFHO0FBQUEsYUFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUseUJBQXdCLHNCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQzNDLHVCQUFDLE9BQUUsV0FBVSw0QkFDVmxOLGdDQUFzQixXQUNuQixvQkFBSW9DLEtBQUssR0FBR2xDLGlCQUFpQixLQUFLLEdBQUVpSCxlQUFlLFdBQVc7QUFBQSxjQUM1RHhFLE9BQU87QUFBQSxjQUNQRCxNQUFNO0FBQUEsWUFDUixDQUFDLElBQ0QsR0FBR3JCLFFBQVEsT0FBT0UsTUFBTSxNQU45QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUseUJBQXdCLGdDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLFlBQ3JELHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLGNBQzNDVCxZQUFZRSxrQkFBa0JtRyxlQUFlLE9BQU87QUFBQSxpQkFEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUNwRCx1QkFBQyxPQUFFLFdBQVUscUNBQW9DO0FBQUE7QUFBQSxjQUM3Q3JHLFlBQVlHLGlCQUFpQmtHLGVBQWUsT0FBTztBQUFBLGlCQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQ2xELHVCQUFDLE9BQUUsV0FBVSxxQ0FBcUN2RyxtQkFBU2tFLFVBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsZUFGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThCQTtBQUFBLFdBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxNQUVPcEUsVUFDUCx1QkFBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUNFaUIsZUFBZWYsU0FBU2tFLFNBQVMsSUFDbkMsdUJBQUMsUUFBSyxXQUFVLHdDQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGlFQUNaO0FBQUEsbUNBQUMsc0JBQW1CLFdBQVUsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsWUFBRztBQUFBLGVBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFlBQy9CbEUsU0FBU2tFO0FBQUFBLFlBQU87QUFBQSxlQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNZ0c7QUFBQUEsWUFDTjtBQUFBLFlBQ0EsaUJBQWlCLG9DQUFvQ3JKLHlCQUF5QnVHLElBQUksSUFBSWhJLHNCQUFzQixVQUN4R0Usb0JBQ1IsR0FBR21CLFFBQVEsT0FBT0UsTUFBTSxFQUFFO0FBQUEsWUFDOUIsaUJBQWlCO0FBQUEsY0FDZjtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUFlO0FBQUEsWUFFakIsbUJBQW1CO0FBQUEsY0FDakJFLHlCQUF5QnVHLFFBQVE7QUFBQSxjQUNqQ3ZHLHlCQUF5QndHLGdCQUFnQjtBQUFBLGNBQ3pDeEcseUJBQXlCeUcsZ0JBQWdCO0FBQUEsY0FDekNsSSxzQkFBc0IsV0FDbEIsb0JBQUlvQyxLQUFLLEdBQUdsQyxpQkFBaUIsS0FBSyxHQUFFaUgsZUFBZSxXQUFXO0FBQUEsZ0JBQzVEeEUsT0FBTztBQUFBLGdCQUNQRCxNQUFNO0FBQUEsY0FDUixDQUFDLElBQ0QsR0FBR3JCLFFBQVEsT0FBT0UsTUFBTTtBQUFBLGNBQzVCLEdBQUdmLG1CQUFtQjtBQUFBLGNBQ3RCLElBQUlNLFlBQVlFLGtCQUFrQm1HLGVBQWUsT0FBTyxLQUFLLEdBQUc7QUFBQSxjQUNoRSxJQUFJckcsWUFBWUcsaUJBQWlCa0csZUFBZSxPQUFPLEtBQUssR0FBRztBQUFBLGNBQy9EdkcsU0FBU2tFLFVBQVU7QUFBQSxZQUFHO0FBQUEsWUFFeEIsa0JBQWtCLHdCQUF3QnJELHlCQUF5QnVHLFFBQVEsS0FBSyxJQUM5RWhJLHNCQUFzQixVQUNsQkUsb0JBQ0EsR0FBR21CLFFBQVEsT0FBT0UsTUFBTSxFQUFFO0FBQUE7QUFBQSxVQWxDMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUNPLEtBcENUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQ0Y7QUFBQSxXQWpEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0RGLElBQ0U7QUFBQSxTQS9JRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUpEO0FBQUEsT0EzYUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtiQTtBQUlBO0FBQUU1QixHQWx0Q0FELCtCQUE2QjtBQUFBeU4sS0FBN0J6TjtBQXV0Q04sZUFBZUE7QUFBOEIsSUFBQXlOO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNlbGVjdCIsIlJhZGlvIiwiQ2FyZCIsIkJ1dHRvbiIsIlNwYWNlIiwiU3RhdGlzdGljIiwiUm93IiwiQ29sIiwibWVzc2FnZSIsIlVzZXJPdXRsaW5lZCIsIkNhbGVuZGFyT3V0bGluZWQiLCJQZXJjZW50YWdlT3V0bGluZWQiLCJGaWxlU2VhcmNoT3V0bGluZWQiLCJUZWFtT3V0bGluZWQiLCJSaXNlT3V0bGluZWQiLCJQcmludGVyT3V0bGluZWQiLCJEb3dubG9hZE91dGxpbmVkIiwiU2lnbmF0dXJlT3V0bGluZWQiLCJhcGkiLCJGYVJ1cGVlU2lnbiIsIkxpbmsiLCJGaVRhcmdldCIsIk1kR3JvdXBzIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJpbWFnZUlucHV0IiwianNQREYiLCJodG1sMmNhbnZhcyIsIkNoaXRDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0IiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJzZWxlY3RlZEVtcGxveWVlSWQiLCJzZXRTZWxlY3RlZEVtcGxveWVlSWQiLCJkYXRlU2VsZWN0aW9uTW9kZSIsInNldERhdGVTZWxlY3Rpb25Nb2RlIiwidGVtcFNlbGVjdGVkTW9udGgiLCJzZXRUZW1wU2VsZWN0ZWRNb250aCIsInRlbXBGcm9tRGF0ZSIsInNldFRlbXBGcm9tRGF0ZSIsInRlbXBUb0RhdGUiLCJzZXRUZW1wVG9EYXRlIiwiaW5jZW50aXZlUGVyY2VudGFnZSIsInNldEluY2VudGl2ZVBlcmNlbnRhZ2UiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImNoaXREYXRhIiwic2V0Q2hpdERhdGEiLCJjaGl0U3VtbWFyeSIsInNldENoaXRTdW1tYXJ5IiwidG90YWxfY29sbGVjdGlvbiIsInRvdGFsX2luY2VudGl2ZSIsInRvdGFsX2NoaXRzIiwiY29tcGxldGVkX2NoaXRzIiwicGVuZGluZ19jaGl0cyIsImZyb21EYXRlIiwic2V0RnJvbURhdGUiLCJ0b0RhdGUiLCJzZXRUb0RhdGUiLCJzZWxlY3RlZEVtcGxveWVlRGV0YWlscyIsInNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzIiwiaXNGaWx0ZXJpbmciLCJzZXRJc0ZpbHRlcmluZyIsImlzR2VuZXJhdGluZ1BERiIsInNldElzR2VuZXJhdGluZ1BERiIsInNpZ25hdHVyZURhdGEiLCJzZXRTaWduYXR1cmVEYXRhIiwiYWdlbnRTaWduYXR1cmVEYXRhIiwic2V0QWdlbnRTaWduYXR1cmVEYXRhIiwidG9kYXkiLCJEYXRlIiwiY3VycmVudE1vbnRoIiwiZ2V0RnVsbFllYXIiLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwieWVhciIsIm1vbnRoIiwiZmlyc3REYXkiLCJsYXN0RGF5IiwiZ2V0RGF0ZSIsImZldGNoRW1wbG95ZWVzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImVtcGxveWVlIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiaGFuZGxlVGVtcE1vbnRoQ2hhbmdlIiwiZSIsInZhbHVlIiwidGFyZ2V0Iiwic3BsaXQiLCJmZXRjaENoaXRDb2xsZWN0aW9uRGF0YSIsImVtcGxveWVlSWQiLCJzdGFydERhdGUiLCJlbmREYXRlIiwicmVzcG9uc2UiLCJwYXJhbXMiLCJzdWNjZXNzIiwicmVzcG9uc2VEYXRhIiwiYWxsUGF5bWVudHMiLCJ0b3RhbENvbGxlY3Rpb24iLCJ0b3RhbEluY2VudGl2ZSIsImZvckVhY2giLCJpdGVtIiwicGF5bWVudHMiLCJBcnJheSIsImlzQXJyYXkiLCJ0b3RhbF9wYXltZW50cyIsImluY2VudGl2ZV9hbW91bnQiLCJsZW5ndGgiLCJmaWx0ZXIiLCJwIiwic3RhdHVzIiwiaXNfY29tcGxldGVkIiwiaGFuZGxlQ29udGludWUiLCJ3YXJuaW5nIiwiZW1wIiwiZmluZCIsIl9pZCIsIm51bVRvV29yZHMiLCJudW0iLCJpc05hTiIsImEiLCJiIiwibnVtVmFsIiwiTWF0aCIsInJvdW5kIiwidG9TdHJpbmciLCJuIiwic3Vic3RyIiwibWF0Y2giLCJzdHIiLCJOdW1iZXIiLCJ0cmltIiwiaGFuZGxlU2lnbmF0dXJlQ2hhbmdlIiwidHlwZSIsImZpbGUiLCJmaWxlcyIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWRlbmQiLCJyZXN1bHQiLCJyZWFkQXNEYXRhVVJMIiwiZ2VuZXJhdGVJbmNlbnRpdmVTbGlwQ29udGVudCIsImFnZW50IiwicGVyaW9kIiwidG9Mb2NhbGVTdHJpbmciLCJhbW91bnRJbldvcmRzIiwic2xpcE51bWJlciIsIm5vdyIsInNsaWNlIiwiY3VycmVudERhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJsb2dvVXJsIiwic3RhcnRzV2l0aCIsIndpbmRvdyIsImxvY2F0aW9uIiwib3JpZ2luIiwibmFtZSIsImVtcGxveWVlQ29kZSIsInBob25lX251bWJlciIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsImhhbmRsZUdlbmVyYXRlU2xpcCIsImh0bWxDb250ZW50IiwiZmlsZU5hbWUiLCJ0ZW1wRGl2IiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50Iiwic3R5bGUiLCJwb3NpdGlvbiIsImxlZnQiLCJ0b3AiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsImlubmVySFRNTCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsIlByb21pc2UiLCJyIiwic2V0VGltZW91dCIsImNhbnZhcyIsInNjYWxlIiwidXNlQ09SUyIsImxvZ2dpbmciLCJ3aW5kb3dXaWR0aCIsImFsbG93VGFpbnQiLCJmb3JlaWduT2JqZWN0UmVuZGVyaW5nIiwiaW1nRGF0YSIsInRvRGF0YVVSTCIsInBkZiIsInBhZ2VXaWR0aCIsImltZ1dpZHRoIiwiaW1nSGVpZ2h0IiwiaGVpZ2h0IiwiYWRkSW1hZ2UiLCJzYXZlIiwicmVtb3ZlQ2hpbGQiLCJoYW5kbGVQcmludFNsaXAiLCJwcmludFdpbmRvdyIsIm9wZW4iLCJ3cml0ZSIsImNsb3NlIiwiZm9jdXMiLCJwcmludCIsInByb2Nlc3NlZFRhYmxlRGF0YSIsIm1hcCIsInBheW1lbnQiLCJpbmRleCIsImtleSIsInNubyIsImN1c3RvbWVyX25hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwiY2hpdF9ncm91cCIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsInRpY2tldF9udW1iZXIiLCJ0aWNrZXQiLCJhbW91bnQiLCJwYXltZW50X2RhdGUiLCJwYXlfZGF0ZSIsInRyYW5zYWN0aW9uX2RhdGUiLCJjcmVhdGVkQXQiLCJwYXltZW50X21vZGUiLCJwYXlfdHlwZSIsInJlY2VpcHRfbm8iLCJ0cmFuc2FjdGlvbl9pZCIsImNvbHVtbnMiLCJoZWFkZXIiLCJzZWxlY3RlZEVtcGxveWVlIiwiU2lnbmF0dXJlVXBsb2FkIiwibGFiZWwiLCJvbkNoYW5nZSIsImNvbG9yIiwiZm9udFNpemUiLCJpbnB1dCIsIm9wdGlvbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJwYXJzZUZsb2F0IiwiZW1haWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDaGl0Q29sbGVjdGlvbkluY2VudGl2ZVJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBTZWxlY3QsXHJcbiAgUmFkaW8sXHJcbiAgQ2FyZCxcclxuICBCdXR0b24sXHJcbiAgU3BhY2UsXHJcbiAgU3RhdGlzdGljLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbiAgbWVzc2FnZSxcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQge1xyXG4gIFVzZXJPdXRsaW5lZCxcclxuICBDYWxlbmRhck91dGxpbmVkLFxyXG4gIFBlcmNlbnRhZ2VPdXRsaW5lZCxcclxuICBGaWxlU2VhcmNoT3V0bGluZWQsXHJcbiAgVGVhbU91dGxpbmVkLFxyXG4gIFJpc2VPdXRsaW5lZCxcclxuICBQcmludGVyT3V0bGluZWQsXHJcbiAgRG93bmxvYWRPdXRsaW5lZCxcclxuICBTaWduYXR1cmVPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBGYVJ1cGVlU2lnbiB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgRmlUYXJnZXQgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgTWRHcm91cHMgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgaW1hZ2VJbnB1dCBmcm9tIFwiLi4vYXNzZXRzL2ltYWdlcy9Mb2dvLnN2Z1wiO1xyXG5pbXBvcnQganNQREYgZnJvbSBcImpzcGRmXCI7XHJcbmltcG9ydCBodG1sMmNhbnZhcyBmcm9tIFwiaHRtbDJjYW52YXNcIjtcclxuXHJcbmNvbnN0IENoaXRDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWVJZCwgc2V0U2VsZWN0ZWRFbXBsb3llZUlkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtkYXRlU2VsZWN0aW9uTW9kZSwgc2V0RGF0ZVNlbGVjdGlvbk1vZGVdID0gdXNlU3RhdGUoXCJtb250aFwiKTtcclxuICBjb25zdCBbdGVtcFNlbGVjdGVkTW9udGgsIHNldFRlbXBTZWxlY3RlZE1vbnRoXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0ZW1wRnJvbURhdGUsIHNldFRlbXBGcm9tRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdGVtcFRvRGF0ZSwgc2V0VGVtcFRvRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaW5jZW50aXZlUGVyY2VudGFnZSwgc2V0SW5jZW50aXZlUGVyY2VudGFnZV0gPSB1c2VTdGF0ZSgxLjApO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY2hpdERhdGEsIHNldENoaXREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY2hpdFN1bW1hcnksIHNldENoaXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsX2NvbGxlY3Rpb246IDAsXHJcbiAgICB0b3RhbF9pbmNlbnRpdmU6IDAsXHJcbiAgICB0b3RhbF9jaGl0czogMCxcclxuICAgIGNvbXBsZXRlZF9jaGl0czogMCxcclxuICAgIHBlbmRpbmdfY2hpdHM6IDAsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLCBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNGaWx0ZXJpbmcsIHNldElzRmlsdGVyaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNHZW5lcmF0aW5nUERGLCBzZXRJc0dlbmVyYXRpbmdQREZdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaWduYXR1cmVEYXRhLCBzZXRTaWduYXR1cmVEYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFthZ2VudFNpZ25hdHVyZURhdGEsIHNldEFnZW50U2lnbmF0dXJlRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKFxyXG4gICAgICB0b2RheS5nZXRNb250aCgpICsgMSxcclxuICAgICkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcblxyXG4gICAgc2V0VGVtcFNlbGVjdGVkTW9udGgoY3VycmVudE1vbnRoKTtcclxuXHJcbiAgICBjb25zdCB5ZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gdG9kYXkuZ2V0TW9udGgoKSArIDE7XHJcbiAgICBjb25zdCBmaXJzdERheSA9IGAke3llYXJ9LSR7U3RyaW5nKG1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LTAxYDtcclxuICAgIGNvbnN0IGxhc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMCkuZ2V0RGF0ZSgpO1xyXG5cclxuICAgIHNldFRlbXBGcm9tRGF0ZShmaXJzdERheSk7XHJcbiAgICBzZXRUZW1wVG9EYXRlKFxyXG4gICAgICBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YCxcclxuICAgICk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuICAgICAgICBzZXRFbXBsb3llZXMocmVzPy5kYXRhPy5lbXBsb3llZSB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVUZW1wTW9udGhDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgdmFsdWUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFRlbXBTZWxlY3RlZE1vbnRoKHZhbHVlKTtcclxuICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gdmFsdWUuc3BsaXQoXCItXCIpO1xyXG4gICAgICBjb25zdCBmaXJzdERheSA9IGAke3llYXJ9LSR7bW9udGh9LTAxYDtcclxuICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICAgIHNldFRlbXBGcm9tRGF0ZShmaXJzdERheSk7XHJcbiAgICAgIHNldFRlbXBUb0RhdGUoYCR7eWVhcn0tJHttb250aH0tJHtTdHJpbmcobGFzdERheSkucGFkU3RhcnQoMiwgXCIwXCIpfWApO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQ2hpdENvbGxlY3Rpb25EYXRhID0gYXN5bmMgKGVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFlbXBsb3llZUlkIHx8ICFzdGFydERhdGUgfHwgIWVuZERhdGUpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC92MS9hZG1pbi9wYXltZW50cy9jaGl0cy9jb2xsZWN0aW9uLWFnZW50cy8ke2VtcGxveWVlSWR9LyR7aW5jZW50aXZlUGVyY2VudGFnZX1gLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBzdGFydERhdGU6IHN0YXJ0RGF0ZSxcclxuICAgICAgICAgICAgZW5kRGF0ZTogZW5kRGF0ZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgbGV0IGFsbFBheW1lbnRzID0gW107XHJcbiAgICAgICAgbGV0IHRvdGFsQ29sbGVjdGlvbiA9IDA7XHJcbiAgICAgICAgbGV0IHRvdGFsSW5jZW50aXZlID0gMDtcclxuXHJcbiAgICAgICAgLy8gUHJvY2VzcyB0aGUgcmVzcG9uc2UgZGF0YSAtIGl0J3MgYW4gYXJyYXkgb2Ygb2JqZWN0cyB3aXRoIHBheW1lbnRzIGFycmF5XHJcbiAgICAgICAgcmVzcG9uc2VEYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGlmIChpdGVtLnBheW1lbnRzICYmIEFycmF5LmlzQXJyYXkoaXRlbS5wYXltZW50cykpIHtcclxuICAgICAgICAgICAgYWxsUGF5bWVudHMgPSBbLi4uYWxsUGF5bWVudHMsIC4uLml0ZW0ucGF5bWVudHNdO1xyXG4gICAgICAgICAgICB0b3RhbENvbGxlY3Rpb24gKz0gaXRlbS50b3RhbF9wYXltZW50cyB8fCAwO1xyXG4gICAgICAgICAgICB0b3RhbEluY2VudGl2ZSArPSBpdGVtLmluY2VudGl2ZV9hbW91bnQgfHwgMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0Q2hpdERhdGEoYWxsUGF5bWVudHMpO1xyXG4gICAgICAgIHNldENoaXRTdW1tYXJ5KHtcclxuICAgICAgICAgIHRvdGFsX2NvbGxlY3Rpb246IHRvdGFsQ29sbGVjdGlvbixcclxuICAgICAgICAgIHRvdGFsX2luY2VudGl2ZTogdG90YWxJbmNlbnRpdmUsXHJcbiAgICAgICAgICB0b3RhbF9jaGl0czogYWxsUGF5bWVudHMubGVuZ3RoLFxyXG4gICAgICAgICAgY29tcGxldGVkX2NoaXRzOiBhbGxQYXltZW50cy5maWx0ZXIoXHJcbiAgICAgICAgICAgIChwKSA9PiBwLnN0YXR1cyA9PT0gXCJjb21wbGV0ZWRcIiB8fCBwLmlzX2NvbXBsZXRlZCxcclxuICAgICAgICAgICkubGVuZ3RoLFxyXG4gICAgICAgICAgcGVuZGluZ19jaGl0czogYWxsUGF5bWVudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAocCkgPT4gcC5zdGF0dXMgIT09IFwiY29tcGxldGVkXCIgJiYgIXAuaXNfY29tcGxldGVkLFxyXG4gICAgICAgICAgKS5sZW5ndGgsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0Q2hpdERhdGEoW10pO1xyXG4gICAgICAgIHNldENoaXRTdW1tYXJ5KHtcclxuICAgICAgICAgIHRvdGFsX2NvbGxlY3Rpb246IDAsXHJcbiAgICAgICAgICB0b3RhbF9pbmNlbnRpdmU6IDAsXHJcbiAgICAgICAgICB0b3RhbF9jaGl0czogMCxcclxuICAgICAgICAgIGNvbXBsZXRlZF9jaGl0czogMCxcclxuICAgICAgICAgIHBlbmRpbmdfY2hpdHM6IDAsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY2hpdCBjb2xsZWN0aW9uIGRhdGE6XCIsIGVycik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoZXJyLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGZldGNoIGRhdGFcIik7XHJcbiAgICAgIHNldENoaXREYXRhKFtdKTtcclxuICAgICAgc2V0Q2hpdFN1bW1hcnkoe1xyXG4gICAgICAgIHRvdGFsX2NvbGxlY3Rpb246IDAsXHJcbiAgICAgICAgdG90YWxfaW5jZW50aXZlOiAwLFxyXG4gICAgICAgIHRvdGFsX2NoaXRzOiAwLFxyXG4gICAgICAgIGNvbXBsZXRlZF9jaGl0czogMCxcclxuICAgICAgICBwZW5kaW5nX2NoaXRzOiAwLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb250aW51ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRFbXBsb3llZUlkKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBzZWxlY3QgYW4gZW1wbG95ZWUuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgJiYgIXRlbXBTZWxlY3RlZE1vbnRoKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBzZWxlY3QgYSBtb250aC5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwiZGF0ZS1yYW5nZVwiICYmICghdGVtcEZyb21EYXRlIHx8ICF0ZW1wVG9EYXRlKSkge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGJvdGggRnJvbSBhbmQgVG8gZGF0ZXMuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNGaWx0ZXJpbmcodHJ1ZSk7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIGxldCBzdGFydERhdGUsIGVuZERhdGU7XHJcblxyXG4gICAgaWYgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgY29uc3QgW3llYXIsIG1vbnRoXSA9IHRlbXBTZWxlY3RlZE1vbnRoLnNwbGl0KFwiLVwiKTtcclxuICAgICAgc3RhcnREYXRlID0gYCR7eWVhcn0tJHttb250aH0tMDFgO1xyXG4gICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuICAgICAgZW5kRGF0ZSA9IGAke3llYXJ9LSR7bW9udGh9LSR7U3RyaW5nKGxhc3REYXkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4gICAgICBzZXRGcm9tRGF0ZShzdGFydERhdGUpO1xyXG4gICAgICBzZXRUb0RhdGUoZW5kRGF0ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzdGFydERhdGUgPSB0ZW1wRnJvbURhdGU7XHJcbiAgICAgIGVuZERhdGUgPSB0ZW1wVG9EYXRlO1xyXG4gICAgICBzZXRGcm9tRGF0ZShzdGFydERhdGUpO1xyXG4gICAgICBzZXRUb0RhdGUoZW5kRGF0ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZW1wID0gZW1wbG95ZWVzLmZpbmQoKGUpID0+IGUuX2lkID09PSBzZWxlY3RlZEVtcGxveWVlSWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyhlbXAgfHwgbnVsbCk7XHJcbiAgICAgIGF3YWl0IGZldGNoQ2hpdENvbGxlY3Rpb25EYXRhKHNlbGVjdGVkRW1wbG95ZWVJZCwgc3RhcnREYXRlLCBlbmREYXRlKTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiRGF0YSBsb2FkZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBoYW5kbGVDb250aW51ZTpcIiwgZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgZGF0YVwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIENvbnZlcnQgbnVtYmVyIHRvIHdvcmRzXHJcbiAgY29uc3QgbnVtVG9Xb3JkcyA9IChudW0pID0+IHtcclxuICAgIGlmIChpc05hTihudW0pIHx8IG51bSA9PT0gMCkgcmV0dXJuIFwiWmVyb1wiO1xyXG4gICAgXHJcbiAgICBjb25zdCBhID0gW1xyXG4gICAgICBcIlwiLCBcIk9uZVwiLCBcIlR3b1wiLCBcIlRocmVlXCIsIFwiRm91clwiLCBcIkZpdmVcIiwgXCJTaXhcIiwgXCJTZXZlblwiLCBcIkVpZ2h0XCIsIFwiTmluZVwiLCBcclxuICAgICAgXCJUZW5cIiwgXCJFbGV2ZW5cIiwgXCJUd2VsdmVcIiwgXCJUaGlydGVlblwiLCBcIkZvdXJ0ZWVuXCIsIFwiRmlmdGVlblwiLCBcIlNpeHRlZW5cIiwgXHJcbiAgICAgIFwiU2V2ZW50ZWVuXCIsIFwiRWlnaHRlZW5cIiwgXCJOaW5ldGVlblwiXHJcbiAgICBdO1xyXG4gICAgY29uc3QgYiA9IFtcIlwiLCBcIlwiLCBcIlR3ZW50eVwiLCBcIlRoaXJ0eVwiLCBcIkZvcnR5XCIsIFwiRmlmdHlcIiwgXCJTaXh0eVwiLCBcIlNldmVudHlcIiwgXCJFaWdodHlcIiwgXCJOaW5ldHlcIl07XHJcbiAgICBcclxuICAgIGxldCBudW1WYWwgPSBudW07XHJcbiAgICBudW1WYWwgPSBNYXRoLnJvdW5kKG51bVZhbCk7XHJcbiAgICBpZiAoKG51bVZhbCA9IG51bVZhbC50b1N0cmluZygpKS5sZW5ndGggPiA5KSByZXR1cm4gXCJPdmVyZmxvd1wiO1xyXG4gICAgXHJcbiAgICBjb25zdCBuID0gKFwiMDAwMDAwMDAwXCIgKyBudW1WYWwpLnN1YnN0cigtOSkubWF0Y2goL14oXFxkezJ9KShcXGR7Mn0pKFxcZHsyfSkoXFxkezF9KShcXGR7Mn0pJC8pO1xyXG4gICAgaWYgKCFuKSByZXR1cm4gXCJcIjtcclxuICAgIFxyXG4gICAgbGV0IHN0ciA9IFwiXCI7XHJcbiAgICBzdHIgKz0gblsxXSAhPSAwID8gKGFbTnVtYmVyKG5bMV0pXSB8fCBiW25bMV1bMF1dICsgXCIgXCIgKyBhW25bMV1bMV1dKSArIFwiIENyb3JlIFwiIDogXCJcIjtcclxuICAgIHN0ciArPSBuWzJdICE9IDAgPyAoYVtOdW1iZXIoblsyXSldIHx8IGJbblsyXVswXV0gKyBcIiBcIiArIGFbblsyXVsxXV0pICsgXCIgTGFraCBcIiA6IFwiXCI7XHJcbiAgICBzdHIgKz0gblszXSAhPSAwID8gKGFbTnVtYmVyKG5bM10pXSB8fCBiW25bM11bMF1dICsgXCIgXCIgKyBhW25bM11bMV1dKSArIFwiIFRob3VzYW5kIFwiIDogXCJcIjtcclxuICAgIHN0ciArPSBuWzRdICE9IDAgPyAoYVtOdW1iZXIobls0XSldIHx8IGJbbls0XVswXV0gKyBcIiBcIiArIGFbbls0XVsxXV0pICsgXCIgSHVuZHJlZCBcIiA6IFwiXCI7XHJcbiAgICBzdHIgKz0gbls1XSAhPSAwID8gKHN0ciAhPSBcIlwiID8gXCJhbmQgXCIgOiBcIlwiKSArIChhW051bWJlcihuWzVdKV0gfHwgYltuWzVdWzBdXSArIFwiIFwiICsgYVtuWzVdWzFdXSkgKyBcIiBcIiA6IFwiXCI7XHJcbiAgICBcclxuICAgIHJldHVybiBzdHIudHJpbSgpIHx8IFwiWmVyb1wiO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBTaWduYXR1cmUgQ2hhbmdlXHJcbiAgY29uc3QgaGFuZGxlU2lnbmF0dXJlQ2hhbmdlID0gKGUsIHR5cGUpID0+IHtcclxuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcclxuICAgIGlmIChmaWxlKSB7XHJcbiAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKHR5cGUgPT09ICdtYW5hZ2VyJykge1xyXG4gICAgICAgICAgc2V0U2lnbmF0dXJlRGF0YShyZWFkZXIucmVzdWx0KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0QWdlbnRTaWduYXR1cmVEYXRhKHJlYWRlci5yZXN1bHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2VuZXJhdGVJbmNlbnRpdmVTbGlwQ29udGVudCA9ICgpID0+IHtcclxuICAgIGNvbnN0IGFnZW50ID0gc2VsZWN0ZWRFbXBsb3llZURldGFpbHM7XHJcbiAgICBjb25zdCBwZXJpb2QgPSBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgID8gbmV3IERhdGUoYCR7dGVtcFNlbGVjdGVkTW9udGh9LTAxYCkudG9Mb2NhbGVTdHJpbmcoXCJkZWZhdWx0XCIsIHsgbW9udGg6IFwibG9uZ1wiLCB5ZWFyOiBcIm51bWVyaWNcIiB9KVxyXG4gICAgICA6IGAke2Zyb21EYXRlfSB0byAke3RvRGF0ZX1gO1xyXG4gICAgXHJcbiAgICBjb25zdCBhbW91bnRJbldvcmRzID0gbnVtVG9Xb3JkcyhjaGl0U3VtbWFyeS50b3RhbF9pbmNlbnRpdmUpO1xyXG4gICAgY29uc3Qgc2xpcE51bWJlciA9IGBJTkMtQ0hJVC0ke0RhdGUubm93KCkudG9TdHJpbmcoKS5zbGljZSgtNil9YDtcclxuICAgIGNvbnN0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUlOJywgeyBkYXk6ICdudW1lcmljJywgbW9udGg6ICdsb25nJywgeWVhcjogJ251bWVyaWMnIH0pO1xyXG5cclxuICAgIGNvbnN0IGxvZ29VcmwgPSBpbWFnZUlucHV0LnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IGltYWdlSW5wdXQgOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luICsgaW1hZ2VJbnB1dDtcclxuXHJcbiAgICByZXR1cm4gYFxyXG4gICAgICA8IURPQ1RZUEUgaHRtbD5cclxuICAgICAgPGh0bWw+XHJcbiAgICAgIDxoZWFkPlxyXG4gICAgICAgIDxtZXRhIGNoYXJzZXQ9XCJVVEYtOFwiPlxyXG4gICAgICAgIDx0aXRsZT5DaGl0IEluY2VudGl2ZSBTbGlwIC0gJHthZ2VudD8ubmFtZSB8fCBcIkFnZW50XCJ9PC90aXRsZT5cclxuICAgICAgICA8c3R5bGU+XHJcbiAgICAgICAgICBAcGFnZSB7IFxyXG4gICAgICAgICAgICBzaXplOiBBNDsgXHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgKiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgYm9keSB7IFxyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ0hlbHZldGljYSBOZXVlJywgSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZjsgXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xyXG4gICAgICAgICAgICBwcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZG9jdW1lbnQtY29udGFpbmVyIHtcclxuICAgICAgICAgICAgd2lkdGg6IDIxMG1tO1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiAyOTdtbTtcclxuICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgIHBhZ2UtYnJlYWstYWZ0ZXI6IGF2b2lkO1xyXG4gICAgICAgICAgICBwYWdlLWJyZWFrLWluc2lkZTogYXZvaWQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5oZWFkZXItc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICMwMDI2N0MgMCUsICMwMDNkOWUgMTAwJSk7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDIwcHggMjVweDtcclxuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaGVhZGVyLWNvbnRlbnQge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgICAgICAgICAgZ2FwOiAxNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAubG9nby1hcmVhIGltZyB7XHJcbiAgICAgICAgICAgIGhlaWdodDogNjBweDtcclxuICAgICAgICAgICAgd2lkdGg6IGF1dG87XHJcbiAgICAgICAgICAgIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jb21wYW55LWluZm8ge1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGZsZXg6IDE7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jb21wYW55LW5hbWUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDNweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmNvbXBhbnktdGFnbGluZSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC45O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZG9jdW1lbnQtbWV0YSB7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1sZWZ0OiAxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjMpO1xyXG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5tZXRhLWl0ZW0ge1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5tZXRhLWxhYmVsIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC44O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAudGl0bGUtc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmOGY5ZmE7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEycHggMjBweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U5ZWNlZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmRvY3VtZW50LXRpdGxlIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QztcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmNvbnRlbnQtc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDE1cHggMjVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tY2FyZCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZTllY2VmO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jYXJkLWhlYWRlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmOGY5ZmEgMCUsICNlOWVjZWYgMTAwJSk7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICMwMDI2N0M7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5jYXJkLWhlYWRlciBoMyB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMDAyNjdDO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmNhcmQtYm9keSB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEycHggMTVweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tZ3JpZCB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICAgICAgICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDIsIDFmcik7XHJcbiAgICAgICAgICAgIGdhcDogMTJweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tcm93IHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmluZm8tbGFiZWwge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNmM3NTdkO1xyXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5pbmZvLXZhbHVlIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzIxMjUyOTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUge1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUgdHIge1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U5ZWNlZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLnN1bW1hcnktdGFibGUgdGQge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiA4cHggNXB4O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zdW1tYXJ5LXRhYmxlIHRkOmZpcnN0LWNoaWxkIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgY29sb3I6ICM0OTUwNTc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zdW1tYXJ5LXRhYmxlIHRkOmxhc3QtY2hpbGQge1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgY29sb3I6ICMyMTI1Mjk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC50b3RhbC1yb3cge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZThmMGZlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAudG90YWwtcm93IHRkIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaGlnaGxpZ2h0LWJveCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNlOGYwZmUgMCUsICNkNGUyZjcgMTAwJSk7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICAgICAgcGFkZGluZzogMTVweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaGlnaGxpZ2h0LWxhYmVsIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzAwMjY3QztcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuaGlnaGxpZ2h0LWFtb3VudCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICAgICAgICAgICAgY29sb3I6ICMwMDI2N0M7XHJcbiAgICAgICAgICAgIG1hcmdpbjogNXB4IDA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5oaWdobGlnaHQtd29yZHMge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjNDk1MDU3O1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3A6IDFweCBkYXNoZWQgIzAwMjY3QzQwO1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogOHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5kZWNsYXJhdGlvbi1ib3gge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjhmOWZhO1xyXG4gICAgICAgICAgICBib3JkZXItbGVmdDogM3B4IHNvbGlkICMwMDI2N0M7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAxMnB4IDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgY29sb3I6ICM0OTUwNTc7XHJcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zaWduYXR1cmUtc2VjdGlvbiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDE1cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC5zaWduYXR1cmUtYm94IHtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICB3aWR0aDogNDUlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuc2lnbmF0dXJlLWltYWdlIHtcclxuICAgICAgICAgICAgbWF4LWhlaWdodDogNTBweDtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogOHB4O1xyXG4gICAgICAgICAgICBvYmplY3QtZml0OiBjb250YWluO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuc2lnbmF0dXJlLWxpbmUge1xyXG4gICAgICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzIxMjUyOTtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDZweDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBjb2xvcjogIzZjNzU3ZDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmZvb3Rlci1zZWN0aW9uIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzAwMjY3QyAwJSwgIzAwM2Q5ZSAxMDAlKTtcclxuICAgICAgICAgICAgcGFkZGluZzogMTBweCAyMHB4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgZm9udC1zaXplOiA4cHg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICByaWdodDogMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmZvb3Rlci1jb21wYW55IHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogM3B4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuZm9vdGVyLWFkZHJlc3Mge1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwLjg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDNweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLmZvb3Rlci1jb250YWN0IHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMC43O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBAbWVkaWEgcHJpbnQge1xyXG4gICAgICAgICAgICBib2R5IHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuZG9jdW1lbnQtY29udGFpbmVyIHtcclxuICAgICAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICAgIHBhZ2UtYnJlYWstYWZ0ZXI6IGF2b2lkO1xyXG4gICAgICAgICAgICAgIHBhZ2UtYnJlYWstaW5zaWRlOiBhdm9pZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuaGVhZGVyLXNlY3Rpb24sIC5mb290ZXItc2VjdGlvbiB7XHJcbiAgICAgICAgICAgICAgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0O1xyXG4gICAgICAgICAgICAgIHByaW50LWNvbG9yLWFkanVzdDogZXhhY3Q7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICA8L3N0eWxlPlxyXG4gICAgICA8L2hlYWQ+XHJcbiAgICAgIDxib2R5PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJkb2N1bWVudC1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJoZWFkZXItc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyLWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibG9nby1hcmVhXCI+XHJcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIiR7bG9nb1VybH1cIiBhbHQ9XCJNeUNoaXRzIExvZ29cIiBvbmVycm9yPVwidGhpcy5zcmM9J2RhdGE6aW1hZ2Uvc3ZnK3htbCwlM0NzdmcgeG1sbnM9XFwnaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcXCcgd2lkdGg9XFwnMTAwXFwnIGhlaWdodD1cXCcxMDBcXCcgdmlld0JveD1cXCcwIDAgMTAwIDEwMFxcJyUzRSUzQ3JlY3Qgd2lkdGg9XFwnMTAwXFwnIGhlaWdodD1cXCcxMDBcXCcgZmlsbD1cXCclMjMwMDI2N0NcXCcvJTNFJTNDdGV4dCB4PVxcJzUwXFwnIHk9XFwnNTBcXCcgdGV4dC1hbmNob3I9XFwnbWlkZGxlXFwnIGR5PVxcJy4zZW1cXCcgZmlsbD1cXCd3aGl0ZVxcJyBmb250LXNpemU9XFwnMTRcXCcgZm9udC1mYW1pbHk9XFwnQXJpYWxcXCclM0VNQyUzQy90ZXh0JTNFJTNDL3N2ZyUzRSdcIj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29tcGFueS1pbmZvXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29tcGFueS1uYW1lXCI+TVlDSElUUzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbXBhbnktdGFnbGluZVwiPkNoaXQgRnVuZHMg4oCiIExvYW5zIOKAoiBJbnZlc3RtZW50czwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkb2N1bWVudC1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWV0YS1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibWV0YS1sYWJlbFwiPkRhdGU6PC9zcGFuPiAke2N1cnJlbnREYXRlfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidGl0bGUtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZG9jdW1lbnQtdGl0bGVcIj5DaGl0IENvbGxlY3Rpb24gSW5jZW50aXZlIFNsaXA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29udGVudC1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWNhcmRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxoMz5BZ2VudCAvIEVtcGxveWVlIERldGFpbHM8L2gzPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWdyaWRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLWxhYmVsXCI+QWdlbnQgTmFtZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tdmFsdWVcIj4ke2FnZW50Py5uYW1lIHx8IFwiTi9BXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImluZm8tcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLWxhYmVsXCI+RW1wbG95ZWUgSUQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJpbmZvLXZhbHVlXCI+JHthZ2VudD8uZW1wbG95ZWVDb2RlIHx8IGFnZW50Py5faWQ/LnNsaWNlKC02KSB8fCBcIk4vQVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby1sYWJlbFwiPlBob25lIE51bWJlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tdmFsdWVcIj4ke2FnZW50Py5waG9uZV9udW1iZXIgfHwgXCJOL0FcIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImluZm8tbGFiZWxcIj5SZXBvcnRpbmcgUGVyaW9kPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5mby12YWx1ZVwiPiR7cGVyaW9kfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1jYXJkXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8aDM+Q29sbGVjdGlvbiAmIEluY2VudGl2ZSBTdW1tYXJ5PC9oMz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3M9XCJzdW1tYXJ5LXRhYmxlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPlRvdGFsIENvbGxlY3Rpb24gQW1vdW50PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD7igrkke2NoaXRTdW1tYXJ5LnRvdGFsX2NvbGxlY3Rpb24/LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+SW5jZW50aXZlIFBlcmNlbnRhZ2UgUmF0ZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtpbmNlbnRpdmVQZXJjZW50YWdlfSU8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPlRvdGFsIFRyYW5zYWN0aW9ucyAoUmVjb3Jkcyk8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7Y2hpdERhdGEubGVuZ3RofTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+Q29tcGxldGVkIENvbGxlY3Rpb25zPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD4ke2NoaXRTdW1tYXJ5LmNvbXBsZXRlZF9jaGl0c308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPlBlbmRpbmcgQ29sbGVjdGlvbnM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7Y2hpdFN1bW1hcnkucGVuZGluZ19jaGl0c308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzPVwidG90YWwtcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgc3R5bGU9XCJmb250LXdlaWdodDogNzAwO1wiPkdyb3NzIEluY2VudGl2ZSBFYXJuZWQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPVwiZm9udC13ZWlnaHQ6IDcwMDsgY29sb3I6ICMwMDI2N0M7XCI+4oK5JHtjaGl0U3VtbWFyeS50b3RhbF9pbmNlbnRpdmU/LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWdobGlnaHQtYm94XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWdobGlnaHQtbGFiZWxcIj5OZXQgUGF5YWJsZSBBbW91bnQ8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpZ2hsaWdodC1hbW91bnRcIj7igrkke2NoaXRTdW1tYXJ5LnRvdGFsX2luY2VudGl2ZT8udG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJywgeyBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIgfSl9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWdobGlnaHQtd29yZHNcIj5cclxuICAgICAgICAgICAgICAgICAgICBSdXBlZXMgJHthbW91bnRJbldvcmRzfSBPbmx5XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRlY2xhcmF0aW9uLWJveFwiPlxyXG4gICAgICAgICAgICAgIDxzdHJvbmc+RGVjbGFyYXRpb246PC9zdHJvbmc+IFRoaXMgaXMgYSBjb21wdXRlci1nZW5lcmF0ZWQgaW5jZW50aXZlIHNsaXAgZm9yIGNoaXQgY29sbGVjdGlvbnMuIFRoZSBkZXRhaWxzIGNvbnRhaW5lZCBoZXJlaW4gYXJlIHRydWUgdG8gdGhlIGJlc3Qgb2Ygb3VyIGtub3dsZWRnZS4gQW55IGRpc2NyZXBhbmN5IHNob3VsZCBiZSByZXBvcnRlZCB0byB0aGUgYWNjb3VudHMgZGVwYXJ0bWVudCB3aXRoaW4gNDggaG91cnMgb2YgcmVjZWlwdC5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2lnbmF0dXJlLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2lnbmF0dXJlLWJveFwiPlxyXG4gICAgICAgICAgICAgICAgJHthZ2VudFNpZ25hdHVyZURhdGEgPyBgPGltZyBzcmM9XCIke2FnZW50U2lnbmF0dXJlRGF0YX1cIiBjbGFzcz1cInNpZ25hdHVyZS1pbWFnZVwiIGFsdD1cIkFnZW50IFNpZ25cIj5gIDogJzxkaXYgc3R5bGU9XCJoZWlnaHQ6IDUwcHg7XCI+PC9kaXY+J31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaWduYXR1cmUtbGluZVwiPkFnZW50J3MgU2lnbmF0dXJlPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25hdHVyZS1ib3hcIj5cclxuICAgICAgICAgICAgICAgICR7c2lnbmF0dXJlRGF0YSA/IGA8aW1nIHNyYz1cIiR7c2lnbmF0dXJlRGF0YX1cIiBjbGFzcz1cInNpZ25hdHVyZS1pbWFnZVwiIGFsdD1cIk1hbmFnZXIgU2lnblwiPmAgOiAnPGRpdiBzdHlsZT1cImhlaWdodDogNTBweDtcIj48L2Rpdj4nfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25hdHVyZS1saW5lXCI+QXV0aG9yaXplZCBTaWduYXRvcnk8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3Rlci1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb290ZXItY29tcGFueVwiPlZJSkFZQSBWSU5BWUFLIENISVQgRlVORFMgUFJJVkFURSBMSU1JVEVEPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb290ZXItYWRkcmVzc1wiPiMxMS8zNi0yNSwgM3JkIEZsb29yLCAybmQgTWFpbiwgS2F0aHJpZ3VwcGUgTWFpbiBSb2FkLCBCYW5hc2hhbmthcmkgM3JkIFN0YWdlLCBCZW5nYWx1cnUtNTYwMDg1PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb290ZXItY29udGFjdFwiPk1vYjogOTQ4MzkwMDc3NyB8IFBoOiAwODAtNDk3OSA4NzYzIHwgRW1haWw6IGluZm8ubXljaGl0c0BnbWFpbC5jb208L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2JvZHk+XHJcbiAgICAgIDwvaHRtbD5cclxuICAgIGA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR2VuZXJhdGVTbGlwID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEVtcGxveWVlRGV0YWlscykge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2UgbG9hZCBlbXBsb3llZSBkYXRhIGZpcnN0IGJ5IGNsaWNraW5nIENvbnRpbnVlLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzR2VuZXJhdGluZ1BERih0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGh0bWxDb250ZW50ID0gZ2VuZXJhdGVJbmNlbnRpdmVTbGlwQ29udGVudCgpO1xyXG4gICAgICBjb25zdCBhZ2VudCA9IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzO1xyXG4gICAgICBjb25zdCBwZXJpb2QgPSBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiID8gdGVtcFNlbGVjdGVkTW9udGggOiBgJHtmcm9tRGF0ZX1fdG9fJHt0b0RhdGV9YDtcclxuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgQ2hpdF9JbmNlbnRpdmVfU2xpcF8ke2FnZW50Py5uYW1lIHx8IFwiQWdlbnRcIn1fJHtwZXJpb2R9LnBkZmA7XHJcblxyXG4gICAgICBjb25zdCB0ZW1wRGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgdGVtcERpdi5zdHlsZS5wb3NpdGlvbiA9IFwiYWJzb2x1dGVcIjtcclxuICAgICAgdGVtcERpdi5zdHlsZS5sZWZ0ID0gXCItOTk5OXB4XCI7XHJcbiAgICAgIHRlbXBEaXYuc3R5bGUudG9wID0gXCItOTk5OXB4XCI7XHJcbiAgICAgIHRlbXBEaXYuc3R5bGUud2lkdGggPSBcIjIxMG1tXCI7XHJcbiAgICAgIHRlbXBEaXYuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gXCIjZmZmZmZmXCI7XHJcbiAgICAgIHRlbXBEaXYuaW5uZXJIVE1MID0gaHRtbENvbnRlbnQ7XHJcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGVtcERpdik7XHJcblxyXG4gICAgICBhd2FpdCBuZXcgUHJvbWlzZShyID0+IHNldFRpbWVvdXQociwgODAwKSk7XHJcblxyXG4gICAgICBjb25zdCBjYW52YXMgPSBhd2FpdCBodG1sMmNhbnZhcyh0ZW1wRGl2LCB7XHJcbiAgICAgICAgc2NhbGU6IDMsXHJcbiAgICAgICAgdXNlQ09SUzogdHJ1ZSxcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZmZmZlwiLFxyXG4gICAgICAgIGxvZ2dpbmc6IGZhbHNlLFxyXG4gICAgICAgIHdpbmRvd1dpZHRoOiA4MDAsXHJcbiAgICAgICAgYWxsb3dUYWludDogZmFsc2UsXHJcbiAgICAgICAgZm9yZWlnbk9iamVjdFJlbmRlcmluZzogZmFsc2UsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgaW1nRGF0YSA9IGNhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS9wbmdcIik7XHJcbiAgICAgIGNvbnN0IHBkZiA9IG5ldyBqc1BERihcInBcIiwgXCJtbVwiLCBcImE0XCIpO1xyXG4gICAgICBjb25zdCBwYWdlV2lkdGggPSAyMTA7XHJcbiAgICAgIGNvbnN0IGltZ1dpZHRoID0gcGFnZVdpZHRoO1xyXG4gICAgICBjb25zdCBpbWdIZWlnaHQgPSAoY2FudmFzLmhlaWdodCAqIGltZ1dpZHRoKSAvIGNhbnZhcy53aWR0aDtcclxuICAgICAgXHJcbiAgICAgIHBkZi5hZGRJbWFnZShpbWdEYXRhLCBcIlBOR1wiLCAwLCAwLCBpbWdXaWR0aCwgaW1nSGVpZ2h0KTtcclxuICAgICAgcGRmLnNhdmUoZmlsZU5hbWUpO1xyXG5cclxuICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZCh0ZW1wRGl2KTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQ2hpdCBJbmNlbnRpdmUgU2xpcCBkb3dubG9hZGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZ2VuZXJhdGluZyBQREY6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBnZW5lcmF0ZSBpbmNlbnRpdmUgc2xpcFwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzR2VuZXJhdGluZ1BERihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUHJpbnRTbGlwID0gKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEVtcGxveWVlRGV0YWlscykge1xyXG4gICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2UgbG9hZCBlbXBsb3llZSBkYXRhIGZpcnN0IGJ5IGNsaWNraW5nIENvbnRpbnVlLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGh0bWxDb250ZW50ID0gZ2VuZXJhdGVJbmNlbnRpdmVTbGlwQ29udGVudCgpO1xyXG4gICAgY29uc3QgcHJpbnRXaW5kb3cgPSB3aW5kb3cub3BlbihcIlwiLCBcIl9ibGFua1wiKTtcclxuICAgIHByaW50V2luZG93LmRvY3VtZW50LndyaXRlKGh0bWxDb250ZW50KTtcclxuICAgIHByaW50V2luZG93LmRvY3VtZW50LmNsb3NlKCk7XHJcbiAgICBwcmludFdpbmRvdy5mb2N1cygpO1xyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHByaW50V2luZG93LnByaW50KCk7XHJcbiAgICAgIHByaW50V2luZG93LmNsb3NlKCk7XHJcbiAgICB9LCA1MDApO1xyXG4gIH07XHJcblxyXG4gIC8vIFByb2Nlc3MgdGFibGUgZGF0YSBmcm9tIHBheW1lbnRzIGFycmF5IGJhc2VkIG9uIGFjdHVhbCBBUEkgcmVzcG9uc2VcclxuICBjb25zdCBwcm9jZXNzZWRUYWJsZURhdGEgPSBjaGl0RGF0YS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiAoe1xyXG4gICAga2V5OiBwYXltZW50Ll9pZCB8fCBpbmRleCxcclxuICAgIHNubzogaW5kZXggKyAxLFxyXG4gICAgY3VzdG9tZXJfbmFtZTogcGF5bWVudC51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgIHBob25lX251bWJlcjogcGF5bWVudC51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgIGNoaXRfZ3JvdXA6IHBheW1lbnQuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgIHRpY2tldF9udW1iZXI6IHBheW1lbnQudGlja2V0IHx8IFwiTi9BXCIsXHJcbiAgICBhbW91bnQ6IHBheW1lbnQuYW1vdW50IHx8IDAsXHJcbiAgICBwYXltZW50X2RhdGU6IHBheW1lbnQucGF5X2RhdGUgfHwgXCJOL0FcIixcclxuICAgIHRyYW5zYWN0aW9uX2RhdGU6IHBheW1lbnQuY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0gfHwgXCJOL0FcIixcclxuICAgIHBheW1lbnRfbW9kZTogcGF5bWVudC5wYXlfdHlwZSB8fCBcIk4vQVwiLFxyXG4gICAgcmVjZWlwdF9ubzogcGF5bWVudC5yZWNlaXB0X25vIHx8IFwiTi9BXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogcGF5bWVudC50cmFuc2FjdGlvbl9pZCB8fCBcIk4vQVwiLFxyXG4gIH0pKTtcclxuXHJcbiAgLy8gVGFibGUgY29sdW1ucyBmb3IgY2hpdCBjb2xsZWN0aW9uc1xyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbm9cIiwgaGVhZGVyOiBcIlNMLk5vXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJjaGl0X2dyb3VwXCIsIGhlYWRlcjogXCJDaGl0IEdyb3VwXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldF9udW1iZXJcIiwgaGVhZGVyOiBcIlRpY2tldCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudCAo4oK5KVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X21vZGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uX2lkXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBJRFwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKFxyXG4gICAgdG9kYXkuZ2V0TW9udGgoKSArIDEsXHJcbiAgKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRFbXBsb3llZSA9IGVtcGxveWVlcy5maW5kKFxyXG4gICAgKGVtcCkgPT4gZW1wLl9pZCA9PT0gc2VsZWN0ZWRFbXBsb3llZUlkLFxyXG4gICk7XHJcblxyXG4gIC8vIFNpZ25hdHVyZSB1cGxvYWQgY29tcG9uZW50XHJcbiAgY29uc3QgU2lnbmF0dXJlVXBsb2FkID0gKHsgdHlwZSwgbGFiZWwsIHNpZ25hdHVyZURhdGEsIG9uQ2hhbmdlIH0pID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTIgcC0zIGJvcmRlciByb3VuZGVkLWxnXCI+XHJcbiAgICAgIHtzaWduYXR1cmVEYXRhICYmIChcclxuICAgICAgICA8aW1nIHNyYz17c2lnbmF0dXJlRGF0YX0gYWx0PXtgJHtsYWJlbH0gU2lnbmF0dXJlYH0gY2xhc3NOYW1lPVwiaC0xMiBvYmplY3QtY29udGFpblwiIC8+XHJcbiAgICAgICl9XHJcbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKGUsIHR5cGUpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgaWNvbj17PFNpZ25hdHVyZU91dGxpbmVkIC8+fT5cclxuICAgICAgICAgIHtzaWduYXR1cmVEYXRhID8gXCJDaGFuZ2VcIiA6IFwiVXBsb2FkXCJ9IHtsYWJlbH0gU2lnbmF0dXJlXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgIDwvbGFiZWw+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby0xMDAgcC02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudFwiPlxyXG4gICAgICAgICAgICAgICAgICBDaGl0IENvbGxlY3Rpb24gSW5jZW50aXZlIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbXQtMiB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRyYWNrIGFuZCBtYW5hZ2UgY2hpdCBjb2xsZWN0aW9uIGluY2VudGl2ZXMgYW5kIGNvbW1pc3Npb25zXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWZ1bGwgcC0zIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInRleHQtM3hsIHRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIHJvdW5kZWQteGwgbXQtNiBtYi01XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCBib3JkZXItYlwiPlxyXG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEZpVGFyZ2V0IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgUXVpY2sgTmF2aWdhdGlvbiB0byBPdGhlciBSZXBvcnRzXHJcbiAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5FeHBsb3JlIG90aGVyIGluY2VudGl2ZSByZXBvcnRzPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9sb2FuY29sbGVjdGlvbi1pbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBiZy13aGl0ZSBib3JkZXItMiBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBwLTQgaG92ZXI6Ym9yZGVyLXB1cnBsZS00MDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1wdXJwbGUtMTAwIHJvdW5kZWQtbGcgZ3JvdXAtaG92ZXI6YmctcHVycGxlLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPEZpVGFyZ2V0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNjAwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPXsyMn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LXB1cnBsZS02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICBMb2FuIEluY2VudGl2ZSBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPlZpZXcgbG9hbi1iYXNlZCBpbmNlbnRpdmVzPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHlcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcHVycGxlLTYwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDVsNyA3LTcgN1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9waWdteWNvbGxlY3Rpb24taW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gYmctd2hpdGUgYm9yZGVyLTIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgcC00IGhvdmVyOmJvcmRlci1ncmVlbi00MDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmVlbi0xMDAgcm91bmRlZC1sZyBncm91cC1ob3ZlcjpiZy1ncmVlbi01MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIGdyb3VwLWhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPXsyMn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWdyZWVuLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBpZ215IEluY2VudGl2ZSBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPlRyYWNrIHBpZ215IGNvbGxlY3Rpb25zPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHlcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JlZW4tNjAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTkgNWw3IDctNyA3XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuXHJcbiAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvdGFyZ2V0LWluY2VudGl2ZS1uZXdcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBiZy13aGl0ZSBib3JkZXItMiBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBwLTQgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctYmx1ZS0xMDAgcm91bmRlZC1sZyBncm91cC1ob3ZlcjpiZy1ibHVlLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPE1kR3JvdXBzXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT17MjJ9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIENoaXQgQnVzaW5lc3MgSW5jZW50aXZlIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMC41XCI+VHJhY2sgQ2hpdCBjb2xsZWN0aW9uczwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNjAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTkgNWw3IDctNyA3XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvQ2FyZD5cclxuXHJcblxyXG4gICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBsZz17Nn0+XHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbGcgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICB0aXRsZT17PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlRvdGFsIENvbGxlY3Rpb248L3NwYW4+fVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjaGl0U3VtbWFyeS50b3RhbF9jb2xsZWN0aW9ufVxyXG4gICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICBwcmVmaXg9ezxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzNmODYwMFwiLCBmb250U2l6ZTogXCIyNHB4XCIgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbGc9ezZ9PlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktNFwiPlxyXG4gICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5Ub3RhbCBJbmNlbnRpdmU8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NoaXRTdW1tYXJ5LnRvdGFsX2luY2VudGl2ZX1cclxuICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgIHByZWZpeD17PFJpc2VPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS01MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzcyMmVkMVwiLCBmb250U2l6ZTogXCIyNHB4XCIgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBsZz17Nn0+XHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbGcgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICB0aXRsZT17PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlRvdGFsIFJlY29yZHM8L3NwYW4+fVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjaGl0U3VtbWFyeS50b3RhbF9jaGl0c31cclxuICAgICAgICAgICAgICBwcmVmaXg9ezxUZWFtT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzE4OTBmZlwiLCBmb250U2l6ZTogXCIyNHB4XCIgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8L0NvbD5cclxuXHJcbiAgICAgICBcclxuICAgICAgPC9Sb3c+XHJcblxyXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbGcgcm91bmRlZC14bCBtYi02XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8RmlsZVNlYXJjaE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICBSZXBvcnQgRmlsdGVyc1xyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBEYXRlIFNlbGVjdGlvbiBNb2RlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8UmFkaW8uR3JvdXBcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlU2VsZWN0aW9uTW9kZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGF0ZVNlbGVjdGlvbk1vZGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgYnV0dG9uU3R5bGU9XCJzb2xpZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFJhZGlvLkJ1dHRvbiB2YWx1ZT1cIm1vbnRoXCI+TW9udGhseTwvUmFkaW8uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPFJhZGlvLkJ1dHRvbiB2YWx1ZT1cImRhdGUtcmFuZ2VcIj5EYXRlIFJhbmdlPC9SYWRpby5CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9SYWRpby5Hcm91cD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgU2VsZWN0IEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBlbXBsb3llZSBieSBuYW1lIG9yIHBob25lXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlSWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRFbXBsb3llZUlkfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgIChvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpIHx8IFwiXCIpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtlbXBsb3llZXMubWFwKGVtcCA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICB2YWx1ZTogZW1wLl9pZCxcclxuICAgICAgICAgICAgICAgICAgbGFiZWw6IGAke2VtcC5uYW1lfSAoJHtlbXAucGhvbmVfbnVtYmVyfSlgXHJcbiAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAge2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgPyBcIlNlbGVjdCBNb250aFwiIDogXCJGcm9tIERhdGVcIn1cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIHtkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiID8gKFxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wU2VsZWN0ZWRNb250aCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGVtcE1vbnRoQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXB1cnBsZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBGcm9tRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wdXJwbGUtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7ZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwiZGF0ZS1yYW5nZVwiICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvIERhdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFRvRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIEluY2VudGl2ZSBQZXJjZW50YWdlICglKVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjFcIlxyXG4gICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17aW5jZW50aXZlUGVyY2VudGFnZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW5jZW50aXZlUGVyY2VudGFnZShwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRFbXBsb3llZUlkKG51bGwpO1xyXG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKG51bGwpO1xyXG4gICAgICAgICAgICAgIHNldENoaXREYXRhKFtdKTtcclxuICAgICAgICAgICAgICBzZXRDaGl0U3VtbWFyeSh7XHJcbiAgICAgICAgICAgICAgICB0b3RhbF9jb2xsZWN0aW9uOiAwLFxyXG4gICAgICAgICAgICAgICAgdG90YWxfaW5jZW50aXZlOiAwLFxyXG4gICAgICAgICAgICAgICAgdG90YWxfY2hpdHM6IDAsXHJcbiAgICAgICAgICAgICAgICBjb21wbGV0ZWRfY2hpdHM6IDAsXHJcbiAgICAgICAgICAgICAgICBwZW5kaW5nX2NoaXRzOiAwLFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIHNldElzRmlsdGVyaW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgfX0+XHJcbiAgICAgICAgICAgICAgUmVzZXRcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgaWNvbj17PEZpbGVTZWFyY2hPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNvbnRpbnVlfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENvbnRpbnVlXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgIHtpc0ZpbHRlcmluZyAmJiBzZWxlY3RlZEVtcGxveWVlRGV0YWlscyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1sZyByb3VuZGVkLXhsIG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIGJvcmRlci1iIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgRW1wbG95ZWUgSW5mb3JtYXRpb24gJiBBY3Rpb25zXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8U3BhY2U+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIGljb249ezxQcmludGVyT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVByaW50U2xpcH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUHJpbnQgU2xpcFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PERvd25sb2FkT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2lzR2VuZXJhdGluZ1BERn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR2VuZXJhdGVTbGlwfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEb3dubG9hZCBTbGlwXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPkVtcGxveWVlIE5hbWU8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCItXCJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5FbXBsb3llZSBDb2RlPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5lbXBsb3llZUNvZGUgfHwgXCItXCJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5QaG9uZSBOdW1iZXI8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LnBob25lX251bWJlciB8fCBcIi1cIn08L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPkVtYWlsPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5lbWFpbCB8fCBcIi1cIn08L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcblxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LWxnIHJvdW5kZWQteGwgbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgYm9yZGVyLWIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIENvbGxlY3Rpb24gU3VtbWFyeVxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5QZXJpb2Q8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGAke3RlbXBTZWxlY3RlZE1vbnRofS0wMWApLnRvTG9jYWxlU3RyaW5nKFwiZGVmYXVsdFwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGg6IFwibG9uZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX0gdG8gJHt0b0RhdGV9YH1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+VG90YWwgQ29sbGVjdGlvbjwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS03MDAgdGV4dC14bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuXtjaGl0U3VtbWFyeS50b3RhbF9jb2xsZWN0aW9uPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTUwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlRvdGFsIEluY2VudGl2ZTwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMCB0ZXh0LXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg4oK5e2NoaXRTdW1tYXJ5LnRvdGFsX2luY2VudGl2ZT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLW9yYW5nZS01MCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Ub3RhbCBSZWNvcmRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1vcmFuZ2UtNzAwIHRleHQteGxcIj57Y2hpdERhdGEubGVuZ3RofTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IGlzRmlsdGVyaW5nICYmIGNoaXREYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbGcgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIGJvcmRlci1iXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxGaWxlU2VhcmNoT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBQYXltZW50IERldGFpbHNcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICBTaG93aW5nIHtjaGl0RGF0YS5sZW5ndGh9IHBheW1lbnQgcmVjb3Jkc1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGRhdGE9e3Byb2Nlc3NlZFRhYmxlRGF0YX1cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BDaGl0X0NvbGxlY3Rpb25fSW5jZW50aXZlX1JlcG9ydF8ke3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lfV8ke2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgPyB0ZW1wU2VsZWN0ZWRNb250aFxyXG4gICAgICAgICAgOiBgJHtmcm9tRGF0ZX1fdG9fJHt0b0RhdGV9YH1gfVxyXG4gICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgXCJFbXBsb3llZSBOYW1lXCIsXHJcbiAgICAgICAgICBcIkVtcGxveWVlIENvZGVcIixcclxuICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICBcIlBlcmlvZFwiLFxyXG4gICAgICAgICAgXCJJbmNlbnRpdmUgUGVyY2VudGFnZVwiLFxyXG4gICAgICAgICAgXCJUb3RhbCBDb2xsZWN0aW9uXCIsXHJcbiAgICAgICAgICBcIlRvdGFsIEluY2VudGl2ZVwiLFxyXG4gICAgICAgICAgXCJUb3RhbCBSZWNvcmRzXCIsXHJcbiAgICAgICAgXX1cclxuICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8uZW1wbG95ZWVDb2RlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgIGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHt0ZW1wU2VsZWN0ZWRNb250aH0tMDFgKS50b0xvY2FsZVN0cmluZyhcImRlZmF1bHRcIiwge1xyXG4gICAgICAgICAgICAgICAgbW9udGg6IFwibG9uZ1wiLFxyXG4gICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX0gdG8gJHt0b0RhdGV9YCxcclxuICAgICAgICAgIGAke2luY2VudGl2ZVBlcmNlbnRhZ2V9JWAsXHJcbiAgICAgICAgICBg4oK5JHtjaGl0U3VtbWFyeS50b3RhbF9jb2xsZWN0aW9uPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IFwiMFwifWAsXHJcbiAgICAgICAgICBg4oK5JHtjaGl0U3VtbWFyeS50b3RhbF9pbmNlbnRpdmU/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuICAgICAgICAgIGNoaXREYXRhLmxlbmd0aCB8fCBcIjBcIixcclxuICAgICAgICBdfVxyXG4gICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDaGl0Q29sbGVjdGlvblJlcG9ydF8ke3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiYWxsXCJ9XyR7XHJcbiAgICAgICAgICBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgID8gdGVtcFNlbGVjdGVkTW9udGhcclxuICAgICAgICAgICAgOiBgJHtmcm9tRGF0ZX1fdG9fJHt0b0RhdGV9YFxyXG4gICAgICAgICAgICAgIH0uY3N2YH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgKSA6IG51bGx9XHJcblxyXG5cclxuICAgICAgXHJcbiAgICAgICA8Lz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgIFxyXG5cclxuICAgIFxyXG4gICAgXHJcbiAgICA8L2Rpdj5cclxuICAgIFxyXG4gICAgXHJcbiAgICAgICk7XHJcbiAgICB9O1xyXG4gICAgXHJcblxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENoaXRDb2xsZWN0aW9uSW5jZW50aXZlUmVwb3J0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DaGl0Q29sbGVjdGlvbkluY2VudGl2ZVJlcG9ydC5qc3gifQ==