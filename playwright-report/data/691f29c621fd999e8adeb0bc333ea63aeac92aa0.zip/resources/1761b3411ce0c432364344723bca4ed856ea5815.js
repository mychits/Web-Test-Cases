import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PromotionWhatsappMessageMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { MdEmail } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { RiMoneyRupeeCircleLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const PromotionWhatsappMessageMenu = () => {
  const promotionwhatsappCategories = [
    {
      id: 2,
      title: "Promotion Message",
      description: "Manage Promotion Whatsapp Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
        lineNumber: 19,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/promo-whatsapp-marketing/what-promo",
      //   target:"_self",
      stats: "Active Promotion Whatsapp Message"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
      lineNumber: 35,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
        lineNumber: 37,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
          lineNumber: 39,
          columnNumber: 16
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-gray-900", children: "Promotion Whatsapp Message Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
            lineNumber: 41,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Manage and organize your Promotion Whatsapp Message" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
            lineNumber: 44,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
          lineNumber: 40,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6", children: promotionwhatsappCategories.map(
          (category) => /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `relative h-full overflow-hidden rounded-xl bg-white border ${category.borderColor} shadow-md hover:shadow-lg transition-all duration-300`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                    lineNumber: 55,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `inline-flex items-center justify-center w-14 h-14 ${category.lightColor} rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300`,
                      children: /* @__PURE__ */ jsxDEV("div", { children: category.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                        lineNumber: 63,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                      lineNumber: 60,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: category.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                      lineNumber: 67,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: category.description }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                      lineNumber: 70,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                    lineNumber: 66,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                      lineNumber: 76,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `p-1.5 rounded-lg bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300`,
                        children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                          lineNumber: 82,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                        lineNumber: 79,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                    lineNumber: 75,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                  lineNumber: 59,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
                    lineNumber: 87,
                    columnNumber: 21
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
              lineNumber: 52,
              columnNumber: 19
            },
            this
          ) }, category.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
            lineNumber: 51,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
          lineNumber: 49,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-violet-50 to-indigo-50 rounded-2xl border border-violet-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-violet-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
            lineNumber: 97,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
            lineNumber: 96,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
              lineNumber: 100,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Manage Promotion whatsapp and more with Marketing Management—everything in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
              lineNumber: 101,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
            lineNumber: 99,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
          lineNumber: 95,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
          lineNumber: 94,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
        lineNumber: 38,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
      lineNumber: 36,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
    lineNumber: 34,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx",
    lineNumber: 33,
    columnNumber: 5
  }, this);
};
_c = PromotionWhatsappMessageMenu;
export default PromotionWhatsappMessageMenu;
var _c;
$RefreshReg$(_c, "PromotionWhatsappMessageMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PromotionWhatsappMessageMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JZO0FBbEJaLDJCQUFxQjtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkMsT0FBT0EsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLE9BQU9DLFdBQVdDLGNBQWFDLFdBQVk7QUFDcEQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsOEJBQThCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQUl2QixNQUFNQywrQkFBK0JBLE1BQU07QUFDekMsUUFBTUMsOEJBQThCO0FBQUEsSUFFakM7QUFBQSxNQUNDQyxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDckNDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQTtBQUFBLE1BRU5DLE9BQU87QUFBQSxJQUNUO0FBQUEsRUFBQztBQU1ILFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxTQUFJLFdBQVUsT0FDVjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ2QsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLHFEQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLG1FQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDWlQsc0NBQTRCVTtBQUFBQSxVQUFJLENBQUNDLGFBQ2hDLHVCQUFDLFFBQXVCLElBQUlBLFNBQVNILE1BQU0sV0FBVSxTQUNuRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyw4REFBOERHLFNBQVNKLFdBQVc7QUFBQSxjQUU3RjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsc0RBQXNESSxTQUFTTixLQUFLO0FBQUE7QUFBQSxrQkFEakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNvTDtBQUFBLGdCQUdwTCx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLHFEQUFxRE0sU0FBU0wsVUFBVTtBQUFBLHNCQUVuRixpQ0FBQyxTQUFLSyxtQkFBU1AsUUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQjtBQUFBO0FBQUEsb0JBSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLG9GQUNYTyxtQkFBU1QsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWUyxtQkFBU1IsZUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxpSEFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSx5R0FDYlEsbUJBQVNGLFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVcsc0NBQXNDRSxTQUFTTixLQUFLO0FBQUEsd0JBRS9ELGlDQUFDLGdCQUFhLFdBQVUsd0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTRDO0FBQUE7QUFBQSxzQkFIOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlBO0FBQUEsdUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLHFCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBCQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsd0RBQXdETSxTQUFTTixLQUFLO0FBQUE7QUFBQSxrQkFEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUN3SjtBQUFBO0FBQUE7QUFBQSxZQXBDMUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBc0NBLEtBdkNTTSxTQUFTVixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdDQTtBQUFBLFFBQ0QsS0EzQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRDQTtBQUFBLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLGdHQUNqQixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxPQUFJLFdBQVUsa0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSw2Q0FBNEMsMEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsT0FBRSxXQUFVLGtCQUFpQixxR0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUg7QUFBQSxlQUZySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUo7QUFBQSxXQWxFQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUVBO0FBQUEsU0FyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNFQTtBQUFBLE9BeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RUEsS0ExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJFQTtBQUVKO0FBQUVXLEtBbEdJYjtBQW9HTixlQUFlQTtBQUE2QixJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTmF2YmFyIiwiU2lkZWJhciIsIlVzZXJzIiwiQnJpZWZjYXNlIiwiQ2hldnJvblJpZ2h0IiwiWmFwIiwiTWRFbWFpbCIsIkZhV2hhdHNhcHAiLCJSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIiwiQnJlYWRjcnVtYiIsIlByb21vdGlvbldoYXRzYXBwTWVzc2FnZU1lbnUiLCJwcm9tb3Rpb253aGF0c2FwcENhdGVnb3JpZXMiLCJpZCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJpY29uIiwiY29sb3IiLCJsaWdodENvbG9yIiwiYm9yZGVyQ29sb3IiLCJocmVmIiwic3RhdHMiLCJtYXAiLCJjYXRlZ29yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByb21vdGlvbldoYXRzYXBwTWVzc2FnZU1lbnUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBVc2VycywgQnJpZWZjYXNlLCBDaGV2cm9uUmlnaHQsWmFwICB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgTWRFbWFpbCB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvcmlcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuXHJcblxyXG5jb25zdCBQcm9tb3Rpb25XaGF0c2FwcE1lc3NhZ2VNZW51ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHByb21vdGlvbndoYXRzYXBwQ2F0ZWdvcmllcyA9IFtcclxuICBcclxuICAgICB7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICB0aXRsZTogXCJQcm9tb3Rpb24gTWVzc2FnZVwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgUHJvbW90aW9uIFdoYXRzYXBwIE1lc3NhZ2VcIixcclxuICAgICAgaWNvbjogPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvcHJvbW8td2hhdHNhcHAtbWFya2V0aW5nL3doYXQtcHJvbW9cIixcclxuICAgIC8vICAgdGFyZ2V0OlwiX3NlbGZcIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIFByb21vdGlvbiBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG5cclxuICAgXHJcbiAgICAgXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIHctZnVsbCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLThcIj5cclxuICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgIFByb21vdGlvbiBXaGF0c2FwcCBNZXNzYWdlIE1hbmFnZW1lbnRcclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgTWFuYWdlIGFuZCBvcmdhbml6ZSB5b3VyIFByb21vdGlvbiBXaGF0c2FwcCBNZXNzYWdlXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgIHtwcm9tb3Rpb253aGF0c2FwcENhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPExpbmsga2V5PXtjYXRlZ29yeS5pZH0gdG89e2NhdGVnb3J5LmhyZWZ9IGNsYXNzTmFtZT1cImdyb3VwXCIgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJnLXdoaXRlIGJvcmRlciAke2NhdGVnb3J5LmJvcmRlckNvbG9yfSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctMzIgaC0zMiBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMCByb3VuZGVkLWZ1bGwgLW1yLTE2IC1tdC0xNiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYmx1ci14bGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTQgaC0xNCAke2NhdGVnb3J5LmxpZ2h0Q29sb3J9IHJvdW5kZWQtbGcgbWItNSBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj57Y2F0ZWdvcnkuaWNvbn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0yIGdyb3VwLWhvdmVyOnRleHQtZ3JheS05NTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGdyb3VwLWhvdmVyOmJvcmRlci1ncmF5LTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5zdGF0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNmb3JtIHRyYW5zbGF0ZS14LTEgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgcmlnaHQtMCBoLTAuNSBiZy1ncmFkaWVudC10by1yICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xNiBwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8taW5kaWdvLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItdmlvbGV0LTEwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXZpb2xldC02MDAgbXQtMVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMlwiPlF1aWNrIFRpcHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDBcIj5NYW5hZ2UgUHJvbW90aW9uIHdoYXRzYXBwIGFuZCBtb3JlIHdpdGggTWFya2V0aW5nIE1hbmFnZW1lbnTigJRldmVyeXRoaW5nIGluIG9uZSBwbGFjZS48L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvbW90aW9uV2hhdHNhcHBNZXNzYWdlTWVudTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1Byb21vdGlvbldoYXRzYXBwTWVzc2FnZU1lbnUuanN4In0=