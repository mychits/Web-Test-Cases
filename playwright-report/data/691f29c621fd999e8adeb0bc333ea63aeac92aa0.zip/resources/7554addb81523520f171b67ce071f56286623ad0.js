import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AgentCommission.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Drawer, Modal, Empty, Alert } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FiCalendar, FiCreditCard, FiHash } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
const AgentCommission = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [tablePayments, setTablePayments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [editId, setEditId] = useState(null);
  const today = /* @__PURE__ */ new Date();
  const currentMonth = today.toISOString().slice(0, 7);
  const initialForm = {
    employee_id: "",
    commission_month: currentMonth,
    pay_date: today,
    month: (/* @__PURE__ */ new Date()).toLocaleString("default", { month: "long" }),
    pay_type: "cash",
    transaction_id: "",
    amount: 0
  };
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info",
    noReload: true
  });
  useEffect(() => {
    if (alertConfig.visibility) {
      const timer = setTimeout(() => {
        setAlertConfig((prev) => ({ ...prev, visibility: false }));
      }, 3e3);
      return () => clearTimeout(timer);
    }
  }, [alertConfig.visibility]);
  useEffect(() => {
    fetchEmployees();
    fetchCommissionHistory();
  }, []);
  const fetchEmployees = async () => {
    const res = await api.get("/agent/get");
    setEmployees(res.data?.agent);
  };
  const fetchCommissionHistory = async () => {
    try {
      setIsLoading(true);
      const response = await api.get("/commission-payment/get-commission");
      const formatted = response.data.map((item, index) => ({
        ...item,
        id: index + 1,
        date: item.pay_date?.split("T")[0],
        commission_month: item.commission_month,
        employeeName: item.employee_id?.name || "N/A",
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                { key: "1", label: "Edit", onClick: () => handleEdit(item) },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                    lineNumber: 388,
                    columnNumber: 22
                  }, this),
                  onClick: () => showDeleteConfirm(item._id)
                }
              ]
            },
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 395,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
            lineNumber: 382,
            columnNumber: 9
          },
          this
        )
      }));
      setTablePayments(formatted);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  const showDeleteConfirm = (id) => {
    Modal.confirm({
      title: "Are you sure you want to delete this record?",
      content: "This action cannot be undone.",
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handleEdit = (item) => {
    const employeeId = typeof item.employee_id === "object" ? item.employee_id._id : item.employee_id;
    setEditId(item._id);
    setFormData({
      employee_id: employeeId,
      pay_date: item.pay_date?.split("T")[0],
      commission_month: item.commission_month,
      month: item.month || (/* @__PURE__ */ new Date()).toLocaleString("default", { month: "long" }),
      pay_type: item.pay_type,
      transaction_id: item.transaction_id || "",
      amount: item.amount
    });
    setShowModal(true);
  };
  const handleDelete = async (id) => {
    try {
      setOpenBackdropLoader(true);
      await api.delete(`/commission-payment/delete-commission/${id}`);
      setAlertConfig({
        visibility: true,
        message: "Data Deleted Successfully!",
        type: "success",
        noReload: true
      });
      fetchCommissionHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      setOpenBackdropLoader(true);
      if (editId) {
        await api.put(
          `/commission-payment/update-commission/${editId}`,
          formData
        );
      } else {
        await api.post("/commission-payment/add-commission", formData);
      }
      setAlertConfig({
        visibility: true,
        message: editId ? "Data Updated Successfully!" : "Data Added Successfully!",
        type: "success",
        noReload: true
      });
      closeDrawer();
      fetchCommissionHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Error saving data",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const validateForm = () => {
    const errs = {};
    if (!formData.employee_id) errs.employee = "Required";
    if (!formData.amount || formData.amount <= 0)
      errs.amount = "Enter valid amount";
    if (!formData.month) errs.month = "Required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
  const closeDrawer = () => {
    setShowModal(false);
    setEditId(null);
    setFormData(initialForm);
    setErrors({});
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "employeeName", header: "Agent" },
    { key: "commission_month", header: "Month" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Mode" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Processing..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
      lineNumber: 528,
      columnNumber: 30
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
          lineNumber: 530,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
        lineNumber: 534,
        columnNumber: 9
      }, this),
      alertConfig.visibility && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-5 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-md px-4", children: /* @__PURE__ */ jsxDEV(
        Alert,
        {
          message: alertConfig.message,
          type: alertConfig.type,
          showIcon: true,
          closable: true,
          onClose: () => setAlertConfig({ ...alertConfig, visibility: false })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
          lineNumber: 537,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
        lineNumber: 536,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Agent Commission" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
            lineNumber: 551,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setEditId(null);
                setFormData(initialForm);
                setShowModal(true);
              },
              className: "bg-blue-950 text-white px-4 py-2 rounded",
              children: "+ Add Commission"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 552,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
          lineNumber: 550,
          columnNumber: 11
        }, this),
        tablePayments.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Commission Payment Data Found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
          lineNumber: 565,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: tablePayments.filter(
              (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
            ),
            columns
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
            lineNumber: 567,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
        lineNumber: 549,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Drawer,
        {
          title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 582,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 581,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: editId ? "Edit Commission Payment" : "New Commission Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 584,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
            lineNumber: 580,
            columnNumber: 11
          }, this),
          open: showModal,
          onClose: closeDrawer,
          width: 480,
          children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6 p-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                "Agent ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 597,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 596,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  size: "large",
                  className: "w-full",
                  placeholder: "Search and select Agent",
                  value: formData.employee_id || void 0,
                  optionFilterProp: "label",
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  onChange: (val) => setFormData({ ...formData, employee_id: val }),
                  children: employees.map(
                    (emp) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: emp._id,
                        label: `${emp.name} ${emp.employeeCode}`,
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-medium text-blue-700", children: emp.name.charAt(0).toUpperCase() }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                            lineNumber: 620,
                            columnNumber: 23
                          }, this),
                          emp.name,
                          " | ",
                          emp.employeeCode
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                          lineNumber: 619,
                          columnNumber: 21
                        }, this)
                      },
                      emp._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                        lineNumber: 614,
                        columnNumber: 17
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 599,
                  columnNumber: 15
                },
                this
              ),
              errors.employee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 631,
                  columnNumber: 19
                }, this),
                errors.employee
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 630,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 595,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 640,
                  columnNumber: 17
                }, this),
                "Commission Month"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 639,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  value: formData.commission_month,
                  onChange: (e) => setFormData({
                    ...formData,
                    commission_month: e.target.value
                    // YYYY-MM ✅
                  })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 644,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 643,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 638,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 660,
                  columnNumber: 17
                }, this),
                "Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 661,
                  columnNumber: 24
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 659,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 664,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    step: "0.01",
                    className: "w-full border border-gray-300 rounded-lg pl-8 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                    placeholder: "0.00",
                    value: formData.amount,
                    onChange: (e) => setFormData({ ...formData, amount: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                    lineNumber: 667,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 663,
                columnNumber: 15
              }, this),
              formData.amount && /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 border border-blue-200 rounded-lg px-3 py-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-xs font-medium uppercase tracking-wide", children: numberToIndianWords(formData.amount) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 680,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 679,
                columnNumber: 15
              }, this),
              errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 687,
                  columnNumber: 19
                }, this),
                errors.amount
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 686,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 658,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 695,
                  columnNumber: 17
                }, this),
                "Payment Date"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 694,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  value: formData.pay_date,
                  onChange: (e) => setFormData({ ...formData, pay_date: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 699,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 698,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 693,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 713,
                  columnNumber: 17
                }, this),
                "Payment Mode"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 712,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  className: "w-full",
                  value: formData.pay_type,
                  onChange: (val) => setFormData({ ...formData, pay_type: val }),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cash" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                      lineNumber: 723,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                      lineNumber: 722,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Online/UPI" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                      lineNumber: 726,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                      lineNumber: 725,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cheque" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                      lineNumber: 729,
                      columnNumber: 19
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                      lineNumber: 728,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 716,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 711,
              columnNumber: 13
            }, this),
            formData.pay_type !== "cash" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 animate-fadeIn", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                /* @__PURE__ */ jsxDEV(FiHash, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 738,
                  columnNumber: 19
                }, this),
                formData.pay_type === "cheque" ? "Cheque Number" : "Transaction ID"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 737,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                  placeholder: formData.pay_type === "cheque" ? "Enter cheque number" : "Enter transaction/UPI ID",
                  value: formData.transaction_id,
                  onChange: (e) => setFormData({ ...formData, transaction_id: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                  lineNumber: 743,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 736,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2",
                children: editId ? "Update Commission Payment" : "Save Commission Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
                lineNumber: 761,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
              lineNumber: 760,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
            lineNumber: 593,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
          lineNumber: 578,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
      lineNumber: 529,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx",
    lineNumber: 527,
    columnNumber: 5
  }, this);
};
_s(AgentCommission, "looicvpxDTbLb4dl+zT5a8dmxuU=");
_c = AgentCommission;
export default AgentCommission;
var _c;
$RefreshReg$(_c, "AgentCommission");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AgentCommission.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbVl5QixTQTJJckIsVUEzSXFCOzJCQW5ZekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFvVEEsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVDLFFBQVFDLE9BQU9DLE9BQU9DLGFBQWE7QUFDOUQsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsWUFBWUMsY0FBY0MsY0FBYztBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsTUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFDNUIsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUl0QixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDdUIsZUFBZUMsZ0JBQWdCLElBQUl4QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDeUIsV0FBV0MsWUFBWSxJQUFJMUIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzJCLFdBQVdDLFlBQVksSUFBSTVCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM2QixZQUFZQyxhQUFhLElBQUk5QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK0Isb0JBQW9CQyxxQkFBcUIsSUFBSWhDLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNpQyxRQUFRQyxTQUFTLElBQUlsQyxTQUFTLElBQUk7QUFFekMsUUFBTW1DLFFBQVEsb0JBQUlDLEtBQUs7QUFFekIsUUFBTUMsZUFBZUYsTUFBTUcsWUFBWSxFQUFFQyxNQUFNLEdBQUcsQ0FBQztBQUdqRCxRQUFNQyxjQUFjO0FBQUEsSUFDbEJDLGFBQWE7QUFBQSxJQUNiQyxrQkFBa0JMO0FBQUFBLElBQ2xCTSxVQUFVUjtBQUFBQSxJQUNWUyxRQUFPLG9CQUFJUixLQUFLLEdBQUVTLGVBQWUsV0FBVyxFQUFFRCxPQUFPLE9BQU8sQ0FBQztBQUFBLElBQzdERSxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxFQUNWO0FBRUEsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlsRCxTQUFTd0MsV0FBVztBQUNwRCxRQUFNLENBQUNXLFFBQVFDLFNBQVMsSUFBSXBELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3FELGFBQWFDLGNBQWMsSUFBSXRELFNBQVM7QUFBQSxJQUM3Q3VELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLElBQ05DLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRDNELFlBQVUsTUFBTTtBQUNkLFFBQUlzRCxZQUFZRSxZQUFZO0FBQzFCLFlBQU1JLFFBQVFDLFdBQVcsTUFBTTtBQUM3Qk4sdUJBQWUsQ0FBQ08sVUFBVSxFQUFFLEdBQUdBLE1BQU1OLFlBQVksTUFBTSxFQUFFO0FBQUEsTUFDM0QsR0FBRyxHQUFJO0FBQ1AsYUFBTyxNQUFNTyxhQUFhSCxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsQ0FBQ04sWUFBWUUsVUFBVSxDQUFDO0FBQzNCeEQsWUFBVSxNQUFNO0FBQ2RnRSxtQkFBZTtBQUNmQywyQkFBdUI7QUFBQSxFQUN6QixHQUFHLEVBQUU7QUFFTCxRQUFNRCxpQkFBaUIsWUFBWTtBQUNqQyxVQUFNRSxNQUFNLE1BQU0vRCxJQUFJZ0UsSUFBSSxZQUFZO0FBQ3JDNUMsaUJBQWEyQyxJQUFJRSxNQUFNQyxLQUFLO0FBQUEsRUFDL0I7QUFFQSxRQUFNSix5QkFBeUIsWUFBWTtBQUN6QyxRQUFJO0FBQ0ZwQyxtQkFBYSxJQUFJO0FBQ2pCLFlBQU15QyxXQUFXLE1BQU1uRSxJQUFJZ0UsSUFBSSxvQ0FBb0M7QUFDbkUsWUFBTUksWUFBWUQsU0FBU0YsS0FBS0ksSUFBSSxDQUFDQyxNQUFNQyxXQUFXO0FBQUEsUUFDcEQsR0FBR0Q7QUFBQUEsUUFDSEUsSUFBSUQsUUFBUTtBQUFBLFFBQ1pFLE1BQU1ILEtBQUs3QixVQUFVaUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2pDbEMsa0JBQWtCOEIsS0FBSzlCO0FBQUFBLFFBQ3ZCbUMsY0FBY0wsS0FBSy9CLGFBQWFxQyxRQUFRO0FBQUEsUUFDeENDLFFBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU07QUFBQSxjQUNKQyxPQUFPO0FBQUEsZ0JBQ0wsRUFBRUMsS0FBSyxLQUFLQyxPQUFPLFFBQVFDLFNBQVNBLE1BQU1DLFdBQVdaLElBQUksRUFBRTtBQUFBLGdCQUMzRDtBQUFBLGtCQUNFUyxLQUFLO0FBQUEsa0JBQ0xDLE9BQU8sdUJBQUMsVUFBSyxXQUFVLGdCQUFlLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQztBQUFBLGtCQUM1Q0MsU0FBU0EsTUFBTUUsa0JBQWtCYixLQUFLYyxHQUFHO0FBQUEsZ0JBQzNDO0FBQUEsY0FBQztBQUFBLFlBRUw7QUFBQSxZQUNBLFNBQVMsQ0FBQyxPQUFPO0FBQUEsWUFFakIsaUNBQUMsWUFBUyxXQUFVLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBO0FBQUEsVUFiOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBY0E7QUFBQSxNQUVKLEVBQUU7QUFDRjlELHVCQUFpQjhDLFNBQVM7QUFBQSxJQUM1QixTQUFTaUIsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkIsVUFBQztBQUNDM0QsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU15RCxvQkFBb0JBLENBQUNYLE9BQU87QUFDaENqRSxVQUFNaUYsUUFBUTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFDWkMsT0FBTztBQUNMQyxxQkFBYXZCLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNVSxhQUFhQSxDQUFDWixTQUFTO0FBQzNCLFVBQU0wQixhQUNKLE9BQU8xQixLQUFLL0IsZ0JBQWdCLFdBQ3hCK0IsS0FBSy9CLFlBQVk2QyxNQUNqQmQsS0FBSy9CO0FBRVhQLGNBQVVzQyxLQUFLYyxHQUFHO0FBQ2xCcEMsZ0JBQVk7QUFBQSxNQUNWVCxhQUFheUQ7QUFBQUEsTUFDYnZELFVBQVU2QixLQUFLN0IsVUFBVWlDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNyQ2xDLGtCQUFrQjhCLEtBQUs5QjtBQUFBQSxNQUN2QkUsT0FDRTRCLEtBQUs1QixVQUFTLG9CQUFJUixLQUFLLEdBQUVTLGVBQWUsV0FBVyxFQUFFRCxPQUFPLE9BQU8sQ0FBQztBQUFBLE1BQ3RFRSxVQUFVMEIsS0FBSzFCO0FBQUFBLE1BQ2ZDLGdCQUFnQnlCLEtBQUt6QixrQkFBa0I7QUFBQSxNQUN2Q0MsUUFBUXdCLEtBQUt4QjtBQUFBQSxJQUNmLENBQUM7QUFDRHRCLGlCQUFhLElBQUk7QUFBQSxFQUNuQjtBQUVBLFFBQU11RSxlQUFlLE9BQU92QixPQUFPO0FBQ2pDLFFBQUk7QUFDRjFDLDRCQUFzQixJQUFJO0FBQzFCLFlBQU05QixJQUFJaUcsT0FBTyx5Q0FBeUN6QixFQUFFLEVBQUU7QUFDOURwQixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLFFBQ05DLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFDRE0sNkJBQXVCO0FBQUEsSUFDekIsU0FBU3lCLE9BQU87QUFDZG5DLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDMUIsNEJBQXNCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0UsZUFBZSxPQUFPQyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ0MsYUFBYSxFQUFHO0FBRXJCLFFBQUk7QUFDRnZFLDRCQUFzQixJQUFJO0FBQzFCLFVBQUlDLFFBQVE7QUFDVixjQUFNL0IsSUFBSXNHO0FBQUFBLFVBQ1IseUNBQXlDdkUsTUFBTTtBQUFBLFVBQy9DZ0I7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU0vQyxJQUFJdUcsS0FBSyxzQ0FBc0N4RCxRQUFRO0FBQUEsTUFDL0Q7QUFDQUsscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBU3ZCLFNBQ0wsK0JBQ0E7QUFBQSxRQUNKd0IsTUFBTTtBQUFBLFFBQ05DLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFDRGdELGtCQUFZO0FBQ1oxQyw2QkFBdUI7QUFBQSxJQUN6QixTQUFTeUIsT0FBTztBQUNkbkMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxRQUNOQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0MxQiw0QkFBc0IsS0FBSztBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUVBLFFBQU11RSxlQUFlQSxNQUFNO0FBQ3pCLFVBQU1JLE9BQU8sQ0FBQztBQUNkLFFBQUksQ0FBQzFELFNBQVNSLFlBQWFrRSxNQUFLQyxXQUFXO0FBQzNDLFFBQUksQ0FBQzNELFNBQVNELFVBQVVDLFNBQVNELFVBQVU7QUFDekMyRCxXQUFLM0QsU0FBUztBQUNoQixRQUFJLENBQUNDLFNBQVNMLE1BQU8rRCxNQUFLL0QsUUFBUTtBQUNsQ1EsY0FBVXVELElBQUk7QUFDZCxXQUFPRSxPQUFPQyxLQUFLSCxJQUFJLEVBQUVJLFdBQVc7QUFBQSxFQUN0QztBQUVBLFFBQU1MLGNBQWNBLE1BQU07QUFDeEJoRixpQkFBYSxLQUFLO0FBQ2xCUSxjQUFVLElBQUk7QUFDZGdCLGdCQUFZVixXQUFXO0FBQ3ZCWSxjQUFVLENBQUMsQ0FBQztBQUFBLEVBQ2Q7QUFFQSxRQUFNNEQsVUFBVTtBQUFBLElBQ2QsRUFBRS9CLEtBQUssTUFBTWdDLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVoQyxLQUFLLFFBQVFnQyxRQUFRLFlBQVk7QUFBQSxJQUNuQyxFQUFFaEMsS0FBSyxnQkFBZ0JnQyxRQUFRLFFBQVE7QUFBQSxJQUN2QyxFQUFFaEMsS0FBSyxvQkFBb0JnQyxRQUFRLFFBQVE7QUFBQSxJQUMzQyxFQUFFaEMsS0FBSyxVQUFVZ0MsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRWhDLEtBQUssWUFBWWdDLFFBQVEsT0FBTztBQUFBLElBQ2xDLEVBQUVoQyxLQUFLLFVBQVVnQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFNBQ0UsbUNBQ0dsRjtBQUFBQSwwQkFBc0IsdUJBQUMsc0JBQW1CLE9BQU8sbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkM7QUFBQSxJQUNsRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyw2QkFBNkIsQ0FBQ3NFLE1BQU12RSxjQUFjdUUsRUFBRWEsT0FBT0MsS0FBSztBQUFBLFVBQ2hFLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNQOUQsWUFBWUUsY0FDWCx1QkFBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLE1BQU1ILFlBQVlJO0FBQUFBLFVBQ2xCO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBUyxNQUNQSCxlQUFlLEVBQUUsR0FBR0QsYUFBYUUsWUFBWSxNQUFNLENBQUM7QUFBQTtBQUFBLFFBTnhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9HLEtBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLGdDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLFVBQ3ZEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYnJCLDBCQUFVLElBQUk7QUFDZGdCLDRCQUFZVixXQUFXO0FBQ3ZCZCw2QkFBYSxJQUFJO0FBQUEsY0FDbkI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUEwQztBQUFBO0FBQUEsWUFOdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUNILGNBQWN3RixVQUFVLElBQ3ZCLHVCQUFDLFNBQU0sYUFBWSxzQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRCxJQUVyRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTXhGLGNBQWM2RjtBQUFBQSxjQUFPLENBQUM1QyxTQUMxQkEsS0FBS0ssY0FDRHdDLFlBQVksRUFDYkMsU0FBU3pGLFdBQVd3RixZQUFZLENBQUM7QUFBQSxZQUN0QztBQUFBLFlBQ0E7QUFBQTtBQUFBLFVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTW1CO0FBQUEsV0F4QnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxlQUFZLFdBQVUsbUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFDYnBGLG1CQUFTLDRCQUE0Qiw0QkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUYsTUFBTVI7QUFBQUEsVUFDTixTQUFTaUY7QUFBQUEsVUFDVCxPQUFPO0FBQUEsVUFFUCxpQ0FBQyxVQUFLLFVBQVVOLGNBQWMsV0FBVSxpQkFFdEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFBNEQ7QUFBQTtBQUFBLGdCQUNyRSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FBT25ELFNBQVNSLGVBQWU4RTtBQUFBQSxrQkFDL0Isa0JBQWlCO0FBQUEsa0JBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLFFBQVF2QyxPQUFPbUMsWUFBWSxFQUFFQyxTQUFTRSxNQUFNSCxZQUFZLENBQUM7QUFBQSxrQkFFM0QsVUFBVSxDQUFDSyxRQUNUeEUsWUFBWSxFQUFFLEdBQUdELFVBQVVSLGFBQWFpRixJQUFJLENBQUM7QUFBQSxrQkFHOUNyRyxvQkFBVWtEO0FBQUFBLG9CQUFJLENBQUNvRCxRQUNkO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBT0EsSUFBSXJDO0FBQUFBLHdCQUNYLE9BQU8sR0FBR3FDLElBQUk3QyxJQUFJLElBQUk2QyxJQUFJQyxZQUFZO0FBQUEsd0JBRXRDLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlEQUFDLFNBQUksV0FBVSx1R0FDWkQsY0FBSTdDLEtBQUsrQyxPQUFPLENBQUMsRUFBRUMsWUFBWSxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0NILElBQUk3QztBQUFBQSwwQkFBSztBQUFBLDBCQUFJNkMsSUFBSUM7QUFBQUEsNkJBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBS0E7QUFBQTtBQUFBLHNCQVRLRCxJQUFJckM7QUFBQUEsc0JBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkEzQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBNEJBO0FBQUEsY0FFQ25DLE9BQU95RCxZQUNOLHVCQUFDLE9BQUUsV0FBVSxxREFDWDtBQUFBLHVDQUFDLFVBQUssV0FBVSxxQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0Q7QUFBQSxnQkFDakR6RCxPQUFPeUQ7QUFBQUEsbUJBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdDQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkRBQ2Y7QUFBQSx1Q0FBQyxjQUFXLFdBQVUsMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixPQUFPM0QsU0FBU1A7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQzJELE1BQ1RuRCxZQUFZO0FBQUEsb0JBQ1YsR0FBR0Q7QUFBQUEsb0JBQ0hQLGtCQUFrQjJELEVBQUVhLE9BQU9DO0FBQUFBO0FBQUFBLGtCQUM3QixDQUFDO0FBQUE7QUFBQSxnQkFSTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTRyxLQVZMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDZEQUNmO0FBQUEsdUNBQUMsZUFBWSxXQUFVLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QztBQUFBLGdCQUFHO0FBQUEsZ0JBQzFDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsc0VBQXFFLGlCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLE9BQU9sRSxTQUFTRDtBQUFBQSxvQkFDaEIsVUFBVSxDQUFDcUQsTUFDVG5ELFlBQVksRUFBRSxHQUFHRCxVQUFVRCxRQUFRcUQsRUFBRWEsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxrQkFQdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFHO0FBQUEsbUJBWkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGNBQ0NsRSxTQUFTRCxVQUNSLHVCQUFDLFNBQUksV0FBVSwwREFDYixpQ0FBQyxPQUFFLFdBQVUsNkRBQ1ZsQyw4QkFBb0JtQyxTQUFTRCxNQUFNLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FFREcsT0FBT0gsVUFDTix1QkFBQyxPQUFFLFdBQVUsZ0RBQ1g7QUFBQSx1Q0FBQyxVQUFLLFdBQVUscUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtEO0FBQUEsZ0JBQ2pERyxPQUFPSDtBQUFBQSxtQkFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHVDQUFDLGNBQVcsV0FBVSwyQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFBRztBQUFBLG1CQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLE9BQU9DLFNBQVNOO0FBQUFBLGtCQUNoQixVQUFVLENBQUMwRCxNQUNUbkQsWUFBWSxFQUFFLEdBQUdELFVBQVVOLFVBQVUwRCxFQUFFYSxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGdCQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNRyxLQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHVDQUFDLGdCQUFhLFdBQVUsMkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixPQUFPbEUsU0FBU0g7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQzRFLFFBQVF4RSxZQUFZLEVBQUUsR0FBR0QsVUFBVUgsVUFBVTRFLElBQUksQ0FBQztBQUFBLGtCQUU3RDtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQixvQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUQsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQixzQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUE7QUFBQSxnQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FlQTtBQUFBLGlCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBR0N6RSxTQUFTSCxhQUFhLFVBQ3JCLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw2REFDZjtBQUFBLHVDQUFDLFVBQU8sV0FBVSwyQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDeENHLFNBQVNILGFBQWEsV0FDbkIsa0JBQ0E7QUFBQSxtQkFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLGFBQ0VHLFNBQVNILGFBQWEsV0FDbEIsd0JBQ0E7QUFBQSxrQkFFTixPQUFPRyxTQUFTRjtBQUFBQSxrQkFDaEIsVUFBVSxDQUFDc0QsTUFDVG5ELFlBQVksRUFBRSxHQUFHRCxVQUFVRixnQkFBZ0JzRCxFQUFFYSxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGdCQVYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXRztBQUFBLGlCQWxCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFFVGxGLG1CQUFTLDhCQUE4QjtBQUFBO0FBQUEsY0FKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUE5S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErS0E7QUFBQTtBQUFBLFFBOUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQStMQTtBQUFBLFNBaFBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpUEE7QUFBQSxPQW5QRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb1BBO0FBRUo7QUFBRWIsR0FwY0lELGlCQUFlO0FBQUE0RyxLQUFmNUc7QUFzY04sZUFBZUE7QUFBZ0IsSUFBQTRHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIk5hdmJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiRHJhd2VyIiwiTW9kYWwiLCJFbXB0eSIsIkFsZXJ0IiwiSW9NZE1vcmUiLCJCYWNrZHJvcEJsdXJMb2FkZXIiLCJudW1iZXJUb0luZGlhbldvcmRzIiwiRmlDYWxlbmRhciIsIkZpQ3JlZGl0Q2FyZCIsIkZpSGFzaCIsIkZhUnVwZWVTaWduIiwiQWdlbnRDb21taXNzaW9uIiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJ0YWJsZVBheW1lbnRzIiwic2V0VGFibGVQYXltZW50cyIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwib3BlbkJhY2tkcm9wTG9hZGVyIiwic2V0T3BlbkJhY2tkcm9wTG9hZGVyIiwiZWRpdElkIiwic2V0RWRpdElkIiwidG9kYXkiLCJEYXRlIiwiY3VycmVudE1vbnRoIiwidG9JU09TdHJpbmciLCJzbGljZSIsImluaXRpYWxGb3JtIiwiZW1wbG95ZWVfaWQiLCJjb21taXNzaW9uX21vbnRoIiwicGF5X2RhdGUiLCJtb250aCIsInRvTG9jYWxlU3RyaW5nIiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsImFtb3VudCIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwibm9SZWxvYWQiLCJ0aW1lciIsInNldFRpbWVvdXQiLCJwcmV2IiwiY2xlYXJUaW1lb3V0IiwiZmV0Y2hFbXBsb3llZXMiLCJmZXRjaENvbW1pc3Npb25IaXN0b3J5IiwicmVzIiwiZ2V0IiwiZGF0YSIsImFnZW50IiwicmVzcG9uc2UiLCJmb3JtYXR0ZWQiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJpZCIsImRhdGUiLCJzcGxpdCIsImVtcGxveWVlTmFtZSIsIm5hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwib25DbGljayIsImhhbmRsZUVkaXQiLCJzaG93RGVsZXRlQ29uZmlybSIsIl9pZCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbnRlbnQiLCJva1RleHQiLCJva1R5cGUiLCJjYW5jZWxUZXh0Iiwib25PayIsImhhbmRsZURlbGV0ZSIsImVtcGxveWVlSWQiLCJkZWxldGUiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ2YWxpZGF0ZUZvcm0iLCJwdXQiLCJwb3N0IiwiY2xvc2VEcmF3ZXIiLCJlcnJzIiwiZW1wbG95ZWUiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiY29sdW1ucyIsImhlYWRlciIsInRhcmdldCIsInZhbHVlIiwiZmlsdGVyIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVuZGVmaW5lZCIsImlucHV0Iiwib3B0aW9uIiwidmFsIiwiZW1wIiwiZW1wbG95ZWVDb2RlIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBZ2VudENvbW1pc3Npb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbi8vIGltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuLy8gaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbi8vIGltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuLy8gaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG4vLyBpbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbi8vIGltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbi8vIGltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuLy8gaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuLy8gaW1wb3J0IHtcclxuLy8gICBEcmF3ZXIsXHJcbi8vICAgRm9ybSxcclxuLy8gICBJbnB1dCxcclxuLy8gICBCdXR0b24sXHJcbi8vICAgU2VsZWN0LFxyXG4vLyAgIElucHV0TnVtYmVyLFxyXG4vLyAgIFRhZyxcclxuLy8gICBFbXB0eSxcclxuLy8gfSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuLy8gY29uc3QgQWxsRW1wbG95ZWVJbmNlbnRpdmVzID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IFt0YWJsZURhdGEsIHNldFRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbcmVsb2FkLCBzZXRSZWxvYWRdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4vLyAgIGNvbnN0IFtkcmF3ZXJPcGVuLCBzZXREcmF3ZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRSb3csIHNldFNlbGVjdGVkUm93XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtmb3JtXSA9IEZvcm0udXNlRm9ybSgpO1xyXG5cclxuLy8gICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4vLyAgICAgbWVzc2FnZTogXCJcIixcclxuLy8gICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4vLyAgICAgc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSk7XHJcbi8vICAgfTtcclxuLy8gICBjb25zdCBmZXRjaEFsbEluY2VudGl2ZXMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWUvaW5jZW50aXZlcy9wZW5kaW5nXCIpO1xyXG5cclxuLy8gICAgICAgY29uc3QgYXBpRGF0YSA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW107XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlQXJyYXkgPSBhcGlEYXRhLm1hcCgoZGF0YSwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICBjb25zdCB0YXJnZXQgPSBkYXRhPy5tb250aGx5X2J1c2luZXNzX2luZm8/LnRhcmdldCB8fCAwO1xyXG4vLyAgICAgICAgIGNvbnN0IGFjdHVhbCA9IGRhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mbz8udG90YWxfYnVzaW5lc3NfY2xvc2VkIHx8IDA7XHJcbi8vICAgICAgICAgY29uc3QgaW5jZW50aXZlRWFybmVkID0gZGF0YT8uY2FsY3VsYXRlZF9pbmNlbnRpdmUgfHwgMDtcclxuLy8gICAgICAgICBjb25zdCBpbmNlbnRpdmVQYWlkID0gZGF0YT8uaW5jZW50aXZlX3BhaWRfYW1vdW50IHx8IDA7XHJcbi8vICAgICAgICAgY29uc3QgaW5jZW50aXZlUmVtYWluaW5nID0gaW5jZW50aXZlRWFybmVkIC0gaW5jZW50aXZlUGFpZDtcclxuLy8gICAgICAgICBjb25zdCB0YXJnZXRTdGF0dXMgPSBhY3R1YWwgPj0gdGFyZ2V0ID8gXCJBY2hpZXZlZFwiIDogXCJOb3QgQWNoaWV2ZWRcIjtcclxuXHJcbi8vICAgICAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgICAgIF9pZDogZGF0YT8uX2lkLFxyXG4vLyAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIGVtcGxveWVlX25hbWU6IGRhdGE/LmVtcGxveWVlX2lkPy5uYW1lIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICBlbXBsb3llZV9jb2RlOiBkYXRhPy5lbXBsb3llZV9pZD8uZW1wbG95ZWVDb2RlIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICBzYWxhcnlfbW9udGg6IGRhdGE/LnNhbGFyeV9tb250aCB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgc2FsYXJ5X3llYXI6IGRhdGE/LnNhbGFyeV95ZWFyIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICB0YXJnZXRfYW1vdW50OiB0YXJnZXQsXHJcbi8vICAgICAgICAgICBhY3R1YWxfY2xvc2VkOiBhY3R1YWwsXHJcbi8vICAgICAgICAgICB0YXJnZXRfc3RhdHVzOiAoXHJcbi8vICAgICAgICAgICAgIDxUYWcgY29sb3I9e3RhcmdldFN0YXR1cyA9PT0gXCJBY2hpZXZlZFwiID8gXCJncmVlblwiIDogXCJ2b2xjYW5vXCJ9PlxyXG4vLyAgICAgICAgICAgICAgIHt0YXJnZXRTdGF0dXN9XHJcbi8vICAgICAgICAgICAgIDwvVGFnPlxyXG4vLyAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgIHRhcmdldF9zdGF0dXNfcmF3OiB0YXJnZXRTdGF0dXMsXHJcbi8vICAgICAgICAgICBpbmNlbnRpdmVfZWFybmVkOiBpbmNlbnRpdmVFYXJuZWQsXHJcbi8vICAgICAgICAgICBpbmNlbnRpdmVfcGFpZDogaW5jZW50aXZlUGFpZCxcclxuLy8gICAgICAgICAgIGluY2VudGl2ZV9yZW1haW5pbmc6IGluY2VudGl2ZVJlbWFpbmluZyxcclxuLy8gICAgICAgICAgIGluY2VudGl2ZV9zdGF0dXM6IChcclxuLy8gICAgICAgICAgICAgPFRhZyBjb2xvcj17ZGF0YT8uaW5jZW50aXZlX3N0YXR1cyA9PT0gXCJQYWlkXCIgPyBcImdyZWVuXCIgOiBcIm9yYW5nZVwifT5cclxuLy8gICAgICAgICAgICAgICB7ZGF0YT8uaW5jZW50aXZlX3N0YXR1cyB8fCBcIlBlbmRpbmdcIn1cclxuLy8gICAgICAgICAgICAgPC9UYWc+XHJcbi8vICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgaW5jZW50aXZlX3N0YXR1c19yYXc6ZGF0YT8uaW5jZW50aXZlX3N0YXR1cyB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgYWN0aW9uOiAoXHJcbi8vICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbi8vICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICBvcGVuRHJhd2VyKHtcclxuLy8gICAgICAgICAgICAgICAgICAgc2FsYXJ5X2lkOiBkYXRhLl9pZCxcclxuLy8gICAgICAgICAgICAgICAgICAgZW1wbG95ZWVfbmFtZTogZGF0YT8uZW1wbG95ZWVfaWQ/Lm5hbWUsXHJcbi8vICAgICAgICAgICAgICAgICAgIGVtcGxveWVlX2NvZGU6IGRhdGE/LmVtcGxveWVlX2lkPy5lbXBsb3llZUNvZGUsXHJcbi8vICAgICAgICAgICAgICAgICAgIG1vbnRoOiBkYXRhPy5zYWxhcnlfbW9udGgsXHJcbi8vICAgICAgICAgICAgICAgICAgIHllYXI6IGRhdGE/LnNhbGFyeV95ZWFyLFxyXG4vLyAgICAgICAgICAgICAgICAgICByZW1haW5pbmc6IGluY2VudGl2ZVJlbWFpbmluZyxcclxuLy8gICAgICAgICAgICAgICAgIH0pO1xyXG4vLyAgICAgICAgICAgICAgIH19PlxyXG4vLyAgICAgICAgICAgICAgIFBheSBJbmNlbnRpdmVcclxuLy8gICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICApLFxyXG4vLyAgICAgICAgIH07XHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgc2V0VGFibGVEYXRhKHJlc3BvbnNlQXJyYXkpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbi8vICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuLy8gICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4vLyAgICAgICAgIG1lc3NhZ2U6IFwiTm8gSW5jZW50aXZlIERhdGEgRm91bmRcIixcclxuLy8gICAgICAgICB0eXBlOiBcImluZm9cIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIHNldFRhYmxlRGF0YShbXSk7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoQWxsSW5jZW50aXZlcygpO1xyXG4vLyAgIH0sIFtyZWxvYWRdKTtcclxuXHJcbi8vICAgY29uc3Qgb3BlbkRyYXdlciA9IChkYXRhKSA9PiB7XHJcbi8vICAgICBzZXRTZWxlY3RlZFJvdyhkYXRhKTtcclxuLy8gICAgIGZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4vLyAgICAgICBpbmNlbnRpdmVfcGFpZF9hbW91bnQ6IGRhdGEucmVtYWluaW5nLFxyXG4vLyAgICAgICBpbmNlbnRpdmVfcGF5bWVudF9tZXRob2Q6IFwiXCIsXHJcbi8vICAgICB9KTtcclxuLy8gICAgIHNldERyYXdlck9wZW4odHJ1ZSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgY2xvc2VEcmF3ZXIgPSAoKSA9PiB7XHJcbi8vICAgICBzZXREcmF3ZXJPcGVuKGZhbHNlKTtcclxuLy8gICAgIHNldFNlbGVjdGVkUm93KG51bGwpO1xyXG4vLyAgICAgZm9ybS5yZXNldEZpZWxkcygpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVBheUluY2VudGl2ZSA9IGFzeW5jICh2YWx1ZXMpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbi8vICAgICAgICAgYC9lbXBsb3llZS9zYWxhcmllcy8ke3NlbGVjdGVkUm93LnNhbGFyeV9pZH0vcGF5LWluY2VudGl2ZWAsXHJcbi8vICAgICAgICAgdmFsdWVzXHJcbi8vICAgICAgICk7XHJcblxyXG4vLyAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIkluY2VudGl2ZSBwYWlkIHN1Y2Nlc3NmdWxseVwiLFxyXG4vLyAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGNsb3NlRHJhd2VyKCk7XHJcbi8vICAgICAgIGZldGNoQWxsSW5jZW50aXZlcygpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuLy8gICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4vLyAgICAgICAgIG1lc3NhZ2U6IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBwYXkgaW5jZW50aXZlXCIsXHJcbi8vICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBjb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJlbXBsb3llZV9uYW1lXCIsIGhlYWRlcjogXCJFbXBsb3llZSBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInNhbGFyeV9tb250aFwiLCBoZWFkZXI6IFwiTW9udGhcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwic2FsYXJ5X3llYXJcIiwgaGVhZGVyOiBcIlllYXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidGFyZ2V0X2Ftb3VudFwiLCBoZWFkZXI6IFwiVGFyZ2V0ICjigrkpXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFjdHVhbF9jbG9zZWRcIiwgaGVhZGVyOiBcIkJ1c2luZXNzIENsb3NlZCAo4oK5KVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0YXJnZXRfc3RhdHVzXCIsIGhlYWRlcjogXCJUYXJnZXQgU3RhdHVzXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImluY2VudGl2ZV9lYXJuZWRcIiwgaGVhZGVyOiBcIkluY2VudGl2ZSBFYXJuZWQgKOKCuSlcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiaW5jZW50aXZlX3BhaWRcIiwgaGVhZGVyOiBcIlBhaWQgKOKCuSlcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiaW5jZW50aXZlX3JlbWFpbmluZ1wiLCBoZWFkZXI6IFwiUmVtYWluaW5nICjigrkpXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImluY2VudGl2ZV9zdGF0dXNcIiwgaGVhZGVyOiBcIkluY2VudGl2ZSBTdGF0dXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IGVtcGxveWVlQ29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZW1wbG95ZWVfbmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJzYWxhcnlfbW9udGhcIiwgaGVhZGVyOiBcIk1vbnRoXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInNhbGFyeV95ZWFyXCIsIGhlYWRlcjogXCJZZWFyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInRhcmdldF9hbW91bnRcIiwgaGVhZGVyOiBcIlRhcmdldCAo4oK5KVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhY3R1YWxfY2xvc2VkXCIsIGhlYWRlcjogXCJCdXNpbmVzcyBDbG9zZWQgKOKCuSlcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidGFyZ2V0X3N0YXR1c19yYXdcIiwgaGVhZGVyOiBcIlRhcmdldCBTdGF0dXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiaW5jZW50aXZlX2Vhcm5lZFwiLCBoZWFkZXI6IFwiSW5jZW50aXZlIEVhcm5lZCAo4oK5KVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJpbmNlbnRpdmVfcGFpZFwiLCBoZWFkZXI6IFwiUGFpZCAo4oK5KVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJpbmNlbnRpdmVfcmVtYWluaW5nXCIsIGhlYWRlcjogXCJSZW1haW5pbmcgKOKCuSlcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiaW5jZW50aXZlX3N0YXR1c19yYXdcIiwgaGVhZGVyOiBcIkluY2VudGl2ZSBTdGF0dXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8PlxyXG4vLyAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuLy8gICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuLy8gICAgICAgLz5cclxuXHJcbi8vICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4vLyAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbi8vICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4vLyAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbi8vICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuLy8gICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgIC8+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICA8U2lkZWJhciAvPlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbi8vICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XHJcbi8vICAgICAgICAgICAgICAgQWxsIEVtcGxveWVlcyDigJMgSW5jZW50aXZlIFJlcG9ydFxyXG4vLyAgICAgICAgICAgICA8L2gxPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuLy8gICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuLy8gICAgICAgICAgICkgOiB0YWJsZURhdGEubGVuZ3RoIDw9IDAgPyAoXHJcbi8vICAgICAgICAgICAgIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIEVtcGxveWVlIEluY2VudGl2ZSBEYXRhIEZvdW5kXCIvPlxyXG4vLyAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4vLyAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbih0YWJsZURhdGEsIHNlYXJjaFRleHQpfVxyXG4vLyAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbi8vICAgICAgICAgICAgICAgZXhwb3J0Q29scz17ZW1wbG95ZWVDb2x1bW5zfVxyXG4vLyAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkFsbCBFbXBsb3llZSBJbmNlbnRpdmVzXCJcclxuLy8gICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQWxsX0VtcGxveWVlX0luY2VudGl2ZXMuY3N2XCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgPERyYXdlclxyXG4vLyAgICAgICAgIHRpdGxlPVwiUGF5IEluY2VudGl2ZVwiXHJcbi8vICAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4vLyAgICAgICAgIHdpZHRoPXtcIjMwJVwifVxyXG4vLyAgICAgICAgIG9wZW49e2RyYXdlck9wZW59XHJcbi8vICAgICAgICAgb25DbG9zZT17Y2xvc2VEcmF3ZXJ9PlxyXG4vLyAgICAgICAgIHtzZWxlY3RlZFJvdyAmJiAoXHJcbi8vICAgICAgICAgICA8Rm9ybSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIGZvcm09e2Zvcm19IG9uRmluaXNoPXtoYW5kbGVQYXlJbmNlbnRpdmV9PlxyXG4vLyAgICAgICAgICAgICA8Rm9ybS5JdGVtIGxhYmVsPVwiRW1wbG95ZWVcIj5cclxuLy8gICAgICAgICAgICAgICA8SW5wdXRcclxuLy8gICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7c2VsZWN0ZWRSb3cuZW1wbG95ZWVfbmFtZX0gKCR7c2VsZWN0ZWRSb3cuZW1wbG95ZWVfY29kZX0pYH1cclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbi8vICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbGFiZWw9XCJNb250aFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtzZWxlY3RlZFJvdy5tb250aH0sICR7c2VsZWN0ZWRSb3cueWVhcn1gfVxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuLy8gICAgICAgICAgICAgPEZvcm0uSXRlbSBsYWJlbD1cIlJlbWFpbmluZyBJbmNlbnRpdmVcIj5cclxuLy8gICAgICAgICAgICAgICA8SW5wdXRcclxuLy8gICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSAke3NlbGVjdGVkUm93LnJlbWFpbmluZy50b0xvY2FsZVN0cmluZygpfWB9XHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4vLyAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgbGFiZWw9XCJQYXkgQW1vdW50XCJcclxuLy8gICAgICAgICAgICAgICBuYW1lPVwiaW5jZW50aXZlX3BhaWRfYW1vdW50XCJcclxuLy8gICAgICAgICAgICAgICBydWxlcz17W1xyXG4vLyAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgYW1vdW50IHRvIHBheVwiIH0sXHJcbi8vICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvcjogKF8sIHZhbHVlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlID4gc2VsZWN0ZWRSb3cucmVtYWluaW5nXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA/IFByb21pc2UucmVqZWN0KFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBFcnJvcihcIkFtb3VudCBleGNlZWRzIHJlbWFpbmluZyBpbmNlbnRpdmVcIilcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBQcm9taXNlLnJlc29sdmUoKSxcclxuLy8gICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgXX0+XHJcbi8vICAgICAgICAgICAgICAgPElucHV0TnVtYmVyXHJcbi8vICAgICAgICAgICAgICAgICBtaW49ezF9XHJcbi8vICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuLy8gICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICBg4oK5ICR7dmFsdWV9YC5yZXBsYWNlKC9cXEIoPz0oXFxkezN9KSsoPyFcXGQpKS9nLCBcIixcIilcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIHBhcnNlcj17KHZhbHVlKSA9PiB2YWx1ZS5yZXBsYWNlKC9cXOKCuVxccz98KCwqKS9nLCBcIlwiKX1cclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbi8vICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuLy8gICAgICAgICAgICAgICBsYWJlbD1cIlBheW1lbnQgTWV0aG9kXCJcclxuLy8gICAgICAgICAgICAgICBuYW1lPVwiaW5jZW50aXZlX3BheW1lbnRfbWV0aG9kXCJcclxuLy8gICAgICAgICAgICAgICBydWxlcz17W1xyXG4vLyAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IHBheW1lbnQgbWV0aG9kXCIgfSxcclxuLy8gICAgICAgICAgICAgICBdfT5cclxuLy8gICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IHBheW1lbnQgbWV0aG9kXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkNhc2hcIj5DYXNoPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJPbmxpbmUvVVBJXCI+VVBJPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJPbmxpbmUvTkVGVFwiPk5FRlQ8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIk9ubGluZS9JTVBTXCI+SU1QUzwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiT25saW5lL1JUR1NcIj5SVEdTPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJDaGVxdWVcIj5DaGVxdWU8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuLy8gICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIGh0bWxUeXBlPVwic3VibWl0XCIgYmxvY2s+XHJcbi8vICAgICAgICAgICAgICAgUGF5IEluY2VudGl2ZVxyXG4vLyAgICAgICAgICAgICA8L0J1dHRvbj5cclxuLy8gICAgICAgICAgIDwvRm9ybT5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L0RyYXdlcj5cclxuLy8gICAgIDwvPlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG4vLyBleHBvcnQgZGVmYXVsdCBBbGxFbXBsb3llZUluY2VudGl2ZXM7XHJcbi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biwgRHJhd2VyLCBNb2RhbCwgRW1wdHksIEFsZXJ0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEJhY2tkcm9wQmx1ckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0JhY2tkcm9wQmx1ckxvYWRlclwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5pbXBvcnQgeyBGaUNhbGVuZGFyLCBGaUNyZWRpdENhcmQsIEZpSGFzaCB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5pbXBvcnQgeyBGYVJ1cGVlU2lnbiB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5jb25zdCBBZ2VudENvbW1pc3Npb24gPSAoKSA9PiB7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdGFibGVQYXltZW50cywgc2V0VGFibGVQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtvcGVuQmFja2Ryb3BMb2FkZXIsIHNldE9wZW5CYWNrZHJvcExvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRJZCwgc2V0RWRpdElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcblxyXG5jb25zdCBjdXJyZW50TW9udGggPSB0b2RheS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDcpO1xyXG4gIFxyXG5cclxuICBjb25zdCBpbml0aWFsRm9ybSA9IHtcclxuICAgIGVtcGxveWVlX2lkOiBcIlwiLFxyXG4gICAgY29tbWlzc2lvbl9tb250aDogY3VycmVudE1vbnRoLFxyXG4gICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgbW9udGg6IG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoXCJkZWZhdWx0XCIsIHsgbW9udGg6IFwibG9uZ1wiIH0pLFxyXG4gICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBhbW91bnQ6IDAsXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZShpbml0aWFsRm9ybSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgfSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChhbGVydENvbmZpZy52aXNpYmlsaXR5KSB7XHJcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKTtcclxuICAgICAgfSwgMzAwMCk7XHJcbiAgICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4gICAgfVxyXG4gIH0sIFthbGVydENvbmZpZy52aXNpYmlsaXR5XSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgICBmZXRjaENvbW1pc3Npb25IaXN0b3J5KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0XCIpO1xyXG4gICAgIHNldEVtcGxveWVlcyhyZXMuZGF0YT8uYWdlbnQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQ29tbWlzc2lvbkhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9jb21taXNzaW9uLXBheW1lbnQvZ2V0LWNvbW1pc3Npb25cIik7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlc3BvbnNlLmRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAuLi5pdGVtLFxyXG4gICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgZGF0ZTogaXRlbS5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgIGNvbW1pc3Npb25fbW9udGg6IGl0ZW0uY29tbWlzc2lvbl9tb250aCxcclxuICAgICAgICBlbXBsb3llZU5hbWU6IGl0ZW0uZW1wbG95ZWVfaWQ/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgIHsga2V5OiBcIjFcIiwgbGFiZWw6IFwiRWRpdFwiLCBvbkNsaWNrOiAoKSA9PiBoYW5kbGVFZGl0KGl0ZW0pIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj5EZWxldGU8L3NwYW4+LFxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBzaG93RGVsZXRlQ29uZmlybShpdGVtLl9pZCksXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICksXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2hvd0RlbGV0ZUNvbmZpcm0gPSAoaWQpID0+IHtcclxuICAgIE1vZGFsLmNvbmZpcm0oe1xyXG4gICAgICB0aXRsZTogXCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgcmVjb3JkP1wiLFxyXG4gICAgICBjb250ZW50OiBcIlRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuXCIsXHJcbiAgICAgIG9rVGV4dDogXCJZZXMsIERlbGV0ZVwiLFxyXG4gICAgICBva1R5cGU6IFwiZGFuZ2VyXCIsXHJcbiAgICAgIGNhbmNlbFRleHQ6IFwiTm9cIixcclxuICAgICAgb25PaygpIHtcclxuICAgICAgICBoYW5kbGVEZWxldGUoaWQpO1xyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRWRpdCA9IChpdGVtKSA9PiB7XHJcbiAgICBjb25zdCBlbXBsb3llZUlkID1cclxuICAgICAgdHlwZW9mIGl0ZW0uZW1wbG95ZWVfaWQgPT09IFwib2JqZWN0XCJcclxuICAgICAgICA/IGl0ZW0uZW1wbG95ZWVfaWQuX2lkXHJcbiAgICAgICAgOiBpdGVtLmVtcGxveWVlX2lkO1xyXG5cclxuICAgIHNldEVkaXRJZChpdGVtLl9pZCk7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxyXG4gICAgICBwYXlfZGF0ZTogaXRlbS5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICBjb21taXNzaW9uX21vbnRoOiBpdGVtLmNvbW1pc3Npb25fbW9udGgsXHJcbiAgICAgIG1vbnRoOlxyXG4gICAgICAgIGl0ZW0ubW9udGggfHwgbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZyhcImRlZmF1bHRcIiwgeyBtb250aDogXCJsb25nXCIgfSksXHJcbiAgICAgIHBheV90eXBlOiBpdGVtLnBheV90eXBlLFxyXG4gICAgICB0cmFuc2FjdGlvbl9pZDogaXRlbS50cmFuc2FjdGlvbl9pZCB8fCBcIlwiLFxyXG4gICAgICBhbW91bnQ6IGl0ZW0uYW1vdW50LFxyXG4gICAgfSk7XHJcbiAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9jb21taXNzaW9uLXBheW1lbnQvZGVsZXRlLWNvbW1pc3Npb24vJHtpZH1gKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJEYXRhIERlbGV0ZWQgU3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgZmV0Y2hDb21taXNzaW9uSGlzdG9yeSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJEZWxldGUgZmFpbGVkXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIGlmIChlZGl0SWQpIHtcclxuICAgICAgICBhd2FpdCBhcGkucHV0KFxyXG4gICAgICAgICAgYC9jb21taXNzaW9uLXBheW1lbnQvdXBkYXRlLWNvbW1pc3Npb24vJHtlZGl0SWR9YCxcclxuICAgICAgICAgIGZvcm1EYXRhLFxyXG4gICAgICAgICk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvY29tbWlzc2lvbi1wYXltZW50L2FkZC1jb21taXNzaW9uXCIsIGZvcm1EYXRhKTtcclxuICAgICAgfVxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlZGl0SWRcclxuICAgICAgICAgID8gXCJEYXRhIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5IVwiXHJcbiAgICAgICAgICA6IFwiRGF0YSBBZGRlZCBTdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBjbG9zZURyYXdlcigpO1xyXG4gICAgICBmZXRjaENvbW1pc3Npb25IaXN0b3J5KCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yIHNhdmluZyBkYXRhXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXJycyA9IHt9O1xyXG4gICAgaWYgKCFmb3JtRGF0YS5lbXBsb3llZV9pZCkgZXJycy5lbXBsb3llZSA9IFwiUmVxdWlyZWRcIjtcclxuICAgIGlmICghZm9ybURhdGEuYW1vdW50IHx8IGZvcm1EYXRhLmFtb3VudCA8PSAwKVxyXG4gICAgICBlcnJzLmFtb3VudCA9IFwiRW50ZXIgdmFsaWQgYW1vdW50XCI7XHJcbiAgICBpZiAoIWZvcm1EYXRhLm1vbnRoKSBlcnJzLm1vbnRoID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgc2V0RXJyb3JzKGVycnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKGVycnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBjbG9zZURyYXdlciA9ICgpID0+IHtcclxuICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZU5hbWVcIiwgaGVhZGVyOiBcIkFnZW50XCIgfSxcclxuICAgIHsga2V5OiBcImNvbW1pc3Npb25fbW9udGhcIiwgaGVhZGVyOiBcIk1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJNb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge29wZW5CYWNrZHJvcExvYWRlciAmJiA8QmFja2Ryb3BCbHVyTG9hZGVyIHRpdGxlPXtcIlByb2Nlc3NpbmcuLi5cIn0gLz59XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAge2FsZXJ0Q29uZmlnLnZpc2liaWxpdHkgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtNSBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHotWzEwMDBdIHctZnVsbCBtYXgtdy1tZCBweC00XCI+XHJcbiAgICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX0gLy8gc3VjY2VzcywgaW5mbywgd2FybmluZywgZXJyb3JcclxuICAgICAgICAgICAgICBzaG93SWNvblxyXG4gICAgICAgICAgICAgIGNsb3NhYmxlXHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHsgLi4uYWxlcnRDb25maWcsIHZpc2liaWxpdHk6IGZhbHNlIH0pXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+QWdlbnQgQ29tbWlzc2lvbjwvaDE+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICsgQWRkIENvbW1pc3Npb25cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7dGFibGVQYXltZW50cy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gQ29tbWlzc2lvbiBQYXltZW50IERhdGEgRm91bmRcIiAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgIGRhdGE9e3RhYmxlUGF5bWVudHMuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgaXRlbS5lbXBsb3llZU5hbWVcclxuICAgICAgICAgICAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCkpLFxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxEcmF3ZXJcclxuICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1ibHVlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICB7ZWRpdElkID8gXCJFZGl0IENvbW1pc3Npb24gUGF5bWVudFwiIDogXCJOZXcgQ29tbWlzc2lvbiBQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG9wZW49e3Nob3dNb2RhbH1cclxuICAgICAgICAgIG9uQ2xvc2U9e2Nsb3NlRHJhd2VyfVxyXG4gICAgICAgICAgd2lkdGg9ezQ4MH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTYgcC0xXCI+XHJcbiAgICAgICAgICAgIHsvKiBFbXBsb3llZSBTZWxlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgQWdlbnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYW5kIHNlbGVjdCBBZ2VudFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1wbG95ZWVfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImxhYmVsXCJcclxuICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbj8ubGFiZWw/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBlbXBsb3llZV9pZDogdmFsIH0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17ZW1wLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD17YCR7ZW1wLm5hbWV9ICR7ZW1wLmVtcGxveWVlQ29kZX1gfSAvLyDwn5SRIHNlYXJjaGFibGUgdGV4dFxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTYgaC02IGJnLWJsdWUtMTAwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtYmx1ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IHwge2VtcC5lbXBsb3llZUNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLmVtcGxveWVlICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xIGgtMSBiZy1yZWQtNTAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbXBsb3llZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBQYXltZW50IERhdGUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgPEZpQ2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIENvbW1pc3Npb24gTW9udGhcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvbW1pc3Npb25fbW9udGh9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25fbW9udGg6IGUudGFyZ2V0LnZhbHVlLCAvLyBZWVlZLU1NIOKchVxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC00IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcGwtOCBwci00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBhbW91bnQ6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2Zvcm1EYXRhLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCByb3VuZGVkLWxnIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5hbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTEgYmctcmVkLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8RmlDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcGF5X2RhdGU6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFBheW1lbnQgTW9kZSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8RmlDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHBheV90eXBlOiB2YWwgfSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjYXNoXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5DYXNoPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+T25saW5lL1VQSTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPkNoZXF1ZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUcmFuc2FjdGlvbi9DaGVxdWUgSUQgKi99XHJcbiAgICAgICAgICAgIHtmb3JtRGF0YS5wYXlfdHlwZSAhPT0gXCJjYXNoXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIGFuaW1hdGUtZmFkZUluXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGaUhhc2ggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcIkNoZXF1ZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJUcmFuc2FjdGlvbiBJRFwifVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEucGF5X3R5cGUgPT09IFwiY2hlcXVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJFbnRlciBjaGVxdWUgbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJFbnRlciB0cmFuc2FjdGlvbi9VUEkgSURcIlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHRyYW5zYWN0aW9uX2lkOiBlLnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFN1Ym1pdCBCdXR0b24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tYmx1ZS03MDAgdGV4dC13aGl0ZSBweS0zIHJvdW5kZWQtbGcgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1ibHVlLTgwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZm9udC1zZW1pYm9sZCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zZm9ybSBob3ZlcjotdHJhbnNsYXRlLXktMC41IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZWRpdElkID8gXCJVcGRhdGUgQ29tbWlzc2lvbiBQYXltZW50XCIgOiBcIlNhdmUgQ29tbWlzc2lvbiBQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBZ2VudENvbW1pc3Npb247XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9BZ2VudENvbW1pc3Npb24uanN4In0=