import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecentAuction.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"]; const useMemo = __vite__cjsImport4_react["useMemo"];
import { useNavigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import api from "/src/instance/TokenInstance.js";
import {
  Dropdown,
  Popconfirm,
  message,
  Button,
  Modal,
  DatePicker,
  Space,
  Progress,
  Tooltip,
  Select
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import {
  IoFlash,
  IoDocumentText,
  IoCheckmarkCircle,
  IoEye,
  IoDocument,
  IoDownload,
  IoClose,
  IoSearch
} from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import filterOption from "/src/helpers/filterOption.js";
import ModalComponent from "/src/components/modals/Modal.jsx";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { IoFlag } from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import __vite__cjsImport18_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport18_dayjs.__esModule ? __vite__cjsImport18_dayjs.default : __vite__cjsImport18_dayjs;
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import SimplePasswordModal from "/src/components/modals/SimplePasswordModal.jsx";
import handleKycVerificationPrint from "/src/components/printFormats/kycVerificationPrint.jsx";
const { RangePicker } = DatePicker;
const REQUIRED_DOCUMENTS = [
  { key: "user_profile_photo", label: "Photo" },
  { key: "user_adharcard_front_photo", label: "Aadhar Card (Front)" },
  { key: "user_adharcard_back_photo", label: "Aadhar Card (Back)" },
  { key: "user_pancard_photo", label: "PAN Card" },
  { key: "user_cheque_leaf", label: "Cheque Leaf" },
  { key: "bank_statement_month", label: "Bank Statement" },
  { key: "bank_passbook_photo", label: "Passbook Photo" },
  { key: "business_document_proof", label: "Business Proof" },
  { key: "user_salary_slip", label: "Salary Slip" },
  { key: "user_nominee_adharcard_front_photo", label: "Nominee Aadhar (Front)" },
  { key: "user_nominee_adharcard_back_photo", label: "Nominee Aadhar (Back)" },
  { key: "user_nominee_pancard_photo", label: "Nominee PAN Card" }
];
function RecentAuction() {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const [loadingRecent, setLoadingRecent] = useState(false);
  const [TableAuctions, setTableAuctions] = useState([]);
  const [allRecentAuctions, setAllRecentAuctions] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [activeTab, setActiveTab] = useState("recent_auctions");
  const [isLoading, setIsLoading] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);
  const [previewTitle, setPreviewTitle] = useState("");
  const [showPayoutPassword, setShowPayoutPassword] = useState(false);
  const [pendingPayoutId, setPendingPayoutId] = useState(null);
  const [filteredDocCollection, setFilteredDocCollection] = useState([]);
  const [filteredDocVerification, setFilteredDocVerification] = useState([]);
  const [filteredCompleted, setFilteredCompleted] = useState([]);
  const [showKycPreview, setShowKycPreview] = useState(false);
  const [kycUserData, setKycUserData] = useState(null);
  const [dateRange, setDateRange] = useState([null, null]);
  const [filteredAuctions, setFilteredAuctions] = useState([]);
  const [documentCollectionData, setDocumentCollectionData] = useState([]);
  const [documentVerificationData, setDocumentVerificationData] = useState([]);
  const [completedData, setCompletedData] = useState([]);
  const [updateFormData, setUpdateFormData] = useState({
    auction_date: "",
    next_date: ""
  });
  const [activeUserData, setActiveUserData] = useState({});
  const [selectAll, setSelectAll] = useState(false);
  const [openActionMenuId, setOpenActionMenuId] = useState(null);
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [currentDocuments, setCurrentDocuments] = useState([]);
  const [currentAuctionForDocs, setCurrentAuctionForDocs] = useState(null);
  const [documentUploadedKeys, setDocumentUploadedKeys] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedGroupName, setSelectedGroupName] = useState("");
  const [filteredGroupAuctions, setFilteredGroupAuctions] = useState([]);
  const [isGroupLoading, setIsGroupLoading] = useState(false);
  useEffect(() => {
    fetchGroups();
    fetchRecentAuctions();
    fetchProcessData();
  }, []);
  const fetchGroups = async () => {
    try {
      const { data } = await api.get("/group/get-group-admin");
      setGroups(data);
    } catch (err) {
      console.error("Error fetching groups:", err);
    }
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroupId(groupId);
    if (!groupId) {
      setFilteredGroupAuctions([]);
      setFilteredAuctions(allRecentAuctions);
      setSelectedGroupName("");
      return;
    }
    setIsGroupLoading(true);
    setTableAuctions([]);
    setFilteredGroupAuctions([]);
    try {
      const { data } = await api.get(`/auction/unprized/group/${groupId}`);
      const selectedGroup = groups.find((g) => g._id === groupId);
      setSelectedGroupName(selectedGroup?.group_name || "");
      if (data && data.length > 0) {
        const formattedAuctions = [
          {
            id: 1,
            auction_date: new Date(
              new Date(data[0].auction_date).getTime() - 10 * 864e5
            ).toLocaleDateString("en-US", {
              day: "numeric",
              month: "short",
              year: "numeric"
            }).replace(",", ""),
            name: "Commencement",
            phone_number: "Commencement",
            ticket: "Commencement",
            bid_amount: 0,
            amount: 0,
            auction_type: "Commencement Auction",
            status: "Commencement",
            workflow_status: "Commencement",
            group_name: selectedGroup?.group_name || "N/A",
            group_value: data[0]?.group_id?.group_value || "N/A",
            auction_code: "Commencement",
            isCommencement: true,
            action: null
          },
          ...data.map((g, idx) => ({
            _id: g._id,
            id: idx + 2,
            auction_date: new Date(g.auction_date).toLocaleDateString("en-US", {
              day: "numeric",
              month: "short",
              year: "numeric"
            }),
            name: g.user_id?.full_name || "N/A",
            phone_number: g.user_id?.phone_number || "N/A",
            ticket: g.ticket || "N/A",
            bid_amount: Number(g.divident) + Number(g.commission) || 0,
            amount: g.win_amount || 0,
            auction_type: g.auction_type?.charAt(0).toUpperCase() + g.auction_type?.slice(1) + " Auction" || "Normal Auction",
            status: !g?.isPrized ? "Un Prized" : "Prized",
            workflow_status: g.status || "Pending",
            group_name: g.group_id?.group_name || selectedGroup?.group_name || "N/A",
            group_value: g.group_id?.group_value || "N/A",
            auction_code: g.auction_code || "N/A",
            user_id: g.user_id?._id,
            group_id: g.group_id?._id,
            isCommencement: false,
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                trigger: ["click"],
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-blue-600",
                          onClick: () => {
                            if (g.user_id?._id && g.group_id?._id) {
                              updateAuctionStatus(g._id, "Document Collection");
                            } else {
                              message.warning("Cannot move to document collection - missing user or group");
                            }
                          },
                          children: "Document Collection"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                          lineNumber: 2274,
                          columnNumber: 19
                        },
                        this
                      )
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-orange-600",
                          onClick: () => handleUpdateModalOpen(g._id),
                          children: "Edit Auction"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                          lineNumber: 2291,
                          columnNumber: 19
                        },
                        this
                      )
                    },
                    {
                      key: "3",
                      label: /* @__PURE__ */ jsxDEV(
                        Popconfirm,
                        {
                          title: "Delete Auction",
                          description: "Are you sure you want to delete this auction?",
                          onConfirm: () => handleDeleteAuction(g._id),
                          okText: "Yes",
                          cancelText: "No",
                          children: /* @__PURE__ */ jsxDEV("div", { className: "text-red-600", children: "Delete" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                            lineNumber: 2309,
                            columnNumber: 29
                          }, this)
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                          lineNumber: 2302,
                          columnNumber: 19
                        },
                        this
                      )
                    }
                  ]
                },
                placement: "bottomLeft",
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold text-xl cursor-pointer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 2317,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 2267,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 2266,
              columnNumber: 11
            }, this)
          }))
        ];
        setFilteredGroupAuctions(formattedAuctions);
        setFilteredAuctions(formattedAuctions);
        setTableAuctions(formattedAuctions);
      } else {
        setFilteredGroupAuctions([]);
        setFilteredAuctions([]);
        setTableAuctions([]);
        message.info("No unprized auctions found for this group");
      }
    } catch (error) {
      console.error("Error fetching group auctions:", error);
      message.error(error.response?.data?.message || "Failed to fetch auctions for this group");
      setFilteredGroupAuctions([]);
      setFilteredAuctions([]);
      setTableAuctions([]);
    } finally {
      setIsGroupLoading(false);
    }
  };
  const handleKycPreview = async (userId) => {
    try {
      setIsLoading(true);
      const response = await api.get(`/user/get-user-by-id/${userId}`);
      setKycUserData(response.data);
      setShowKycPreview(true);
    } catch (error) {
      console.error("Error fetching user KYC data:", error);
      message.error("Failed to fetch KYC details");
    } finally {
      setIsLoading(false);
    }
  };
  const fetchRecentAuctions = async () => {
    setLoadingRecent(true);
    try {
      const response = await api.get("/v1/admin/auctions/recent");
      const auctionsData = response.data?.data || response.data;
      if (auctionsData && Array.isArray(auctionsData) && auctionsData.length > 0) {
        const pendingAuctions = auctionsData.filter(
          (auction) => auction.status === "Pending" || !auction.status
        );
        const formattedData = pendingAuctions.map((auction, index) => ({
          _id: auction._id,
          id: index + 1,
          auction_code: auction?.auction_code,
          auction_date: auction?.auction_date?.split("T")[0] || auction?.auction_date,
          group_name: auction.group_id?.group_name || "N/A",
          group_value: auction.group_id?.group_value || "N/A",
          group_id: auction.group_id?._id || auction.group_id,
          name: auction.user_id?.full_name || "N/A",
          phone_number: auction.user_id?.phone_number || "N/A",
          ticket: auction?.ticket,
          bid_amount: (parseInt(auction.divident) || 0) + (parseInt(auction.commission) || 0),
          amount: auction?.win_amount,
          auction_type: auction?.auction_type?.charAt(0).toUpperCase() + auction?.auction_type?.slice(1) + " Auction",
          status: !auction?.isPrized ? "Un Prized" : auction?.isPrized === "true" ? "Prized" : "Un Prized",
          user_id: auction.user_id?._id,
          workflow_status: auction.status || "Pending",
          isCommencement: false
        }));
        setAllRecentAuctions(formattedData);
        if (!selectedGroupId) {
          setFilteredAuctions(formattedData);
        }
        setTableAuctions(formattedData);
        const tempActive = {};
        formattedData.forEach((item) => {
          tempActive[item._id] = {
            info: {
              status: false,
              auction_code: item.auction_code,
              name: item.name
            }
          };
        });
        setActiveUserData(tempActive);
      } else {
        setAllRecentAuctions([]);
        if (!selectedGroupId) {
          setFilteredAuctions([]);
        }
        setTableAuctions([]);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      message.error(error.response?.data?.message || "Failed to fetch recent auctions");
    } finally {
      setLoadingRecent(false);
    }
  };
  const updateAuctionStatus = async (auctionId, newStatus) => {
    try {
      const id = typeof auctionId === "object" ? auctionId?._id : auctionId;
      if (!id) {
        console.error("Invalid auctionId:", auctionId);
        return;
      }
      await api.put(`v1/admin/auctions/status/${id}`, {
        status: newStatus
      });
      message.success(`Status updated to ${newStatus}`);
      if (selectedGroupId) {
        await handleGroupChange(selectedGroupId);
      } else {
        fetchRecentAuctions();
      }
      fetchProcessData();
      setActiveUserData({});
      setSelectAll(false);
      setOpenActionMenuId(null);
    } catch (error) {
      message.error(error.response?.data?.message || "Failed to update status");
    }
  };
  const handleBulkStatusUpdate = (newStatus) => {
    const selectedItems = filteredAuctions.filter(
      (item) => activeUserData[item._id]?.info?.status && !item.isCommencement
    );
    if (selectedItems.length === 0) {
      message.warning("Please select auctions to update");
      return;
    }
    Modal.confirm({
      title: `Bulk Update Confirmation`,
      content: `You are about to update status to "${newStatus}" for ${selectedItems.length} auction(s). Are you sure?`,
      okText: "Yes, Update",
      cancelText: "No",
      onOk: async () => {
        try {
          await Promise.all(
            selectedItems.map((item) => updateAuctionStatus(item._id, newStatus))
          );
          message.success(`${selectedItems.length} auctions moved to ${newStatus}`);
        } catch (error) {
          message.error("Failed to update some auctions");
        }
      }
    });
  };
  const handleBulkDelete = () => {
    const selectedItems = filteredAuctions.filter(
      (item) => activeUserData[item._id]?.info?.status && !item.isCommencement
    );
    if (selectedItems.length === 0) {
      message.warning("Please select auctions to delete");
      return;
    }
    Modal.confirm({
      title: `Delete Confirmation`,
      content: `Are you sure you want to delete ${selectedItems.length} auction(s)? This action cannot be undone.`,
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk: async () => {
        try {
          await Promise.all(
            selectedItems.map((item) => handleDeleteAuction(item._id))
          );
          message.success(`${selectedItems.length} auctions deleted successfully`);
        } catch (error) {
          message.error("Failed to delete some auctions");
        }
      }
    });
  };
  const getStatusTag = (status, percentage = null) => {
    const baseClass = "inline-flex items-center justify-center px-3 py-1 text-xs font-medium rounded-full whitespace-nowrap min-w-[120px]";
    switch (status) {
      case "Pending":
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-gray-100 text-gray-600`, children: "Pending" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 2528,
          columnNumber: 16
        }, this);
      case "Document Collection":
        return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-yellow-100 text-yellow-700`, children: "DOC Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 2533,
            columnNumber: 13
          }, this),
          percentage !== null && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Progress,
            {
              type: "circle",
              percent: percentage,
              width: 40,
              strokeColor: percentage === 100 ? "#52c41a" : percentage >= 70 ? "#faad14" : "#ff4d4f",
              format: (percent) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold", children: [
                percent,
                "%"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 2541,
                columnNumber: 38
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 2536,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 2535,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 2532,
          columnNumber: 11
        }, this);
      case "Document Verification":
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-blue-100 text-blue-700`, children: "DOC Verification" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 2549,
          columnNumber: 16
        }, this);
      case "Completed":
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-green-100 text-green-700`, children: "Completed" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 2552,
          columnNumber: 16
        }, this);
      case "Commencement":
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-purple-100 text-purple-700`, children: "Commencement" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 2555,
          columnNumber: 16
        }, this);
      default:
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-gray-100 text-gray-500`, children: status }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 2558,
          columnNumber: 16
        }, this);
    }
  };
  const handlePreview = (imageUrl, title) => {
    setPreviewImage(imageUrl);
    setPreviewTitle(title);
  };
  const handleCancelPreview = () => {
    setPreviewImage(null);
    setPreviewTitle("");
  };
  const handlePayout = (auctionId) => {
    setPendingPayoutId(auctionId);
    setShowPayoutPassword(true);
  };
  const handlePayoutModalClose = () => {
    setShowPayoutPassword(false);
    setPendingPayoutId(null);
  };
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get("openModal") === "true") {
      const userId = params.get("userId");
      if (userId) {
        handleUpdateModalOpen(userId);
      } else {
        setShowModal(true);
      }
      window.history.replaceState({}, document.title, "/customer-menu/user");
    }
  }, [location]);
  const fetchProcessData = async () => {
    setIsLoading(true);
    try {
      const response = await api.get("/v1/admin/auctions/all-paginated?limit=1000");
      const auctions = response.data?.data || [];
      const docCollectionPromises = auctions.filter((auction) => auction.status === "Document Collection").map(async (auction, idx) => {
        let documentPercentage = 0;
        let documents = [];
        const userId = auction.user_id?._id || auction.user_id;
        if (userId) {
          try {
            const userDocsRes = await api.get(`/v1/admin/user-documents/${userId}`);
            if (userDocsRes.data && userDocsRes.data.data) {
              let userDoc = userDocsRes.data.data;
              if (Array.isArray(userDoc) && userDoc.length > 0) {
                userDoc = userDoc[0];
              }
              documents = transformUserDocumentsToArray(userDoc);
              documentPercentage = calculateDocumentPercentage(documents);
            }
          } catch (err) {
            console.error("Error fetching user documents:", err);
          }
        }
        return {
          key: auction._id,
          id: idx + 1,
          auction_code: auction.auction_code || "N/A",
          auction_date: auction.auction_date?.split("T")[0] || auction.auction_date,
          name: auction.user_id?.full_name || "N/A",
          phone_number: auction.user_id?.phone_number || "N/A",
          group_name: auction.group_id?.group_name || "N/A",
          status: getStatusTag("Document Collection", documentPercentage),
          time: auction.updatedAt?.split("T")[0] || "N/A",
          auction_id: auction._id,
          auction_data: auction,
          document: /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "link",
              icon: /* @__PURE__ */ jsxDEV(IoEye, { className: "text-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 2643,
                columnNumber: 19
              }, this),
              onClick: () => handleViewDocuments(auction, documents),
              className: "text-blue-600",
              children: "View"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 2641,
              columnNumber: 11
            },
            this
          ),
          action: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "a",
                      {
                        onClick: () => {
                          window.open(
                            `/legals-menu/user-document?userId=${auction.user_id?._id}&auctionId=${auction._id}`,
                            "_blank"
                          );
                        },
                        className: "text-red-600",
                        children: "Upload Documents"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                        lineNumber: 2657,
                        columnNumber: 17
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-purple-600",
                        onClick: () => updateAuctionStatus(auction._id, "Document Verification"),
                        children: "Verification"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                        lineNumber: 2673,
                        columnNumber: 17
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => updateAuctionStatus(auction._id, "Completed"),
                        children: "Mark Completed"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                        lineNumber: 2684,
                        columnNumber: 17
                      },
                      this
                    )
                  },
                  {
                    key: "4",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-blue-600",
                        onClick: () => {
                          const userId2 = auction.user_id?._id || auction.user_id;
                          if (userId2) {
                            window.open(
                              `/customer-menu/user?openModal=true&userId=${userId2}`,
                              "_blank"
                            );
                          } else {
                            message.error("User ID not found");
                          }
                        },
                        children: "Customer KYC Upload"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                        lineNumber: 2695,
                        columnNumber: 17
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              trigger: ["click"],
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 2718,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 2651,
              columnNumber: 11
            },
            this
          )
        };
      });
      const docCollection = await Promise.all(docCollectionPromises);
      setDocumentCollectionData(docCollection);
      setFilteredDocCollection(docCollection);
      const docVerificationPromises = auctions.filter((auction) => auction.status === "Document Verification").map(async (auction, idx) => {
        let documents = [];
        const userId = auction.user_id?._id || auction.user_id;
        if (userId) {
          try {
            const userDocsRes = await api.get(`/v1/admin/user-documents/${userId}`);
            if (userDocsRes.data && userDocsRes.data.data) {
              let userDoc = userDocsRes.data.data;
              if (Array.isArray(userDoc) && userDoc.length > 0) {
                userDoc = userDoc[0];
              }
              documents = transformUserDocumentsToArray(userDoc);
            }
          } catch (err) {
            console.error("Error fetching user documents:", err);
          }
        }
        return {
          key: auction._id,
          id: idx + 1,
          auction_code: auction.auction_code || "N/A",
          auction_date: auction.auction_date?.split("T")[0] || auction.auction_date,
          name: auction.user_id?.full_name || "N/A",
          phone_number: auction.user_id?.phone_number || "N/A",
          group_name: auction.group_id?.group_name || "N/A",
          status: getStatusTag("Document Verification"),
          time: auction.updatedAt?.split("T")[0] || "N/A",
          auction_id: auction._id,
          auction_data: auction,
          document: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "link",
                icon: /* @__PURE__ */ jsxDEV(IoEye, { className: "text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 2766,
                  columnNumber: 21
                }, this),
                onClick: () => handleViewDocuments(auction, documents),
                className: "text-blue-600",
                children: "View"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 2764,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "link",
                icon: /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 2774,
                  columnNumber: 21
                }, this),
                onClick: () => {
                  const userId2 = auction.user_id?._id || auction.user_id;
                  if (userId2) {
                    handleKycPreview(userId2);
                  } else {
                    message.error("User ID not found");
                  }
                },
                className: "text-green-600",
                children: "KYC Details"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 2772,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 2763,
            columnNumber: 11
          }, this),
          action: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => updateAuctionStatus(auction._id, "Completed"),
                        children: "Verification Completed"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                        lineNumber: 2796,
                        columnNumber: 17
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              trigger: ["click"],
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 2809,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 2790,
              columnNumber: 11
            },
            this
          )
        };
      });
      const docVerification = await Promise.all(docVerificationPromises);
      setDocumentVerificationData(docVerification);
      setFilteredDocVerification(docVerification);
      const completed = auctions.filter((auction) => auction.status === "Completed").map((auction, idx) => ({
        key: auction._id,
        id: idx + 1,
        auction_code: auction.auction_code || "N/A",
        auction_date: auction.auction_date?.split("T")[0] || auction.auction_date,
        name: auction.user_id?.full_name || "N/A",
        phone_number: auction.user_id?.phone_number || "N/A",
        group_name: auction.group_id?.group_name || "N/A",
        status: getStatusTag("Completed"),
        time: auction.updatedAt?.split("T")[0] || "N/A",
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV("div", { className: "text-blue-600", onClick: () => handlePayout(auction._id), children: "Forward to Accounts for Chit Payout" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 2839,
                    columnNumber: 15
                  }, this)
                }
              ]
            },
            placement: "bottomLeft",
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 2849,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 2833,
            columnNumber: 9
          },
          this
        )
      }));
      setCompletedData(completed);
      setFilteredCompleted(completed);
    } catch (error) {
      console.error("Error fetching process data:", error);
      message.error("Failed to fetch process data");
    } finally {
      setIsLoading(false);
    }
  };
  const handleDateFilter = (dates) => {
    if (!dates || !dates[0] || !dates[1]) {
      setDateRange([null, null]);
      if (selectedGroupId) {
        setFilteredAuctions(filteredGroupAuctions);
      } else {
        setFilteredAuctions(allRecentAuctions);
      }
      setFilteredDocCollection(documentCollectionData);
      setFilteredDocVerification(documentVerificationData);
      setFilteredCompleted(completedData);
      return;
    }
    setDateRange(dates);
    const [start, end] = dates;
    let dataToFilter = selectedGroupId ? filteredGroupAuctions : allRecentAuctions;
    const filteredRecent = filterDataByDate(dataToFilter, dates);
    const filteredCollection = filterDataByDate(documentCollectionData, dates);
    const filteredVerification = filterDataByDate(documentVerificationData, dates);
    const filteredCompletedData = filterDataByDate(completedData, dates);
    setFilteredAuctions(filteredRecent);
    setFilteredDocCollection(filteredCollection);
    setFilteredDocVerification(filteredVerification);
    setFilteredCompleted(filteredCompletedData);
  };
  const filterDataByDate = (data, dates) => {
    if (!dates || !dates[0] || !dates[1]) return data;
    const [start, end] = dates;
    return data.filter((item) => {
      let itemDate = item.auction_date || item.time;
      if (!itemDate) return true;
      if (typeof itemDate === "string" && itemDate.includes("T")) {
        itemDate = itemDate.split("T")[0];
      }
      const auctionDate = dayjs(itemDate);
      return auctionDate.isAfter(start.subtract(1, "day")) && auctionDate.isBefore(end.add(1, "day"));
    });
  };
  const handleViewDocuments = async (auctionData, existingDocuments = null) => {
    try {
      let documents = existingDocuments;
      if (!documents) {
        const userId = auctionData?.user_id?._id || auctionData?.user_id;
        if (!userId) {
          console.error("No user_id found for this auction");
          message.error("Customer information not found");
          return;
        }
        const response = await api.get(`/v1/admin/user-documents/${userId}`);
        if (response.data && response.data.data) {
          let userDoc = response.data.data;
          if (Array.isArray(userDoc) && userDoc.length > 0) {
            userDoc = userDoc[0];
          }
          documents = transformUserDocumentsToArray(userDoc);
        } else {
          documents = [];
        }
      }
      setCurrentDocuments(documents);
      setCurrentAuctionForDocs(auctionData);
      setShowDocumentModal(true);
    } catch (error) {
      console.error("Error fetching documents:", error);
      message.error("Failed to fetch documents");
    }
  };
  const transformUserDocumentsToArray = (userDoc) => {
    if (!userDoc) return [];
    const documents = [];
    const docMappings = [
      { key: "user_profile_photo", label: "Photo", isImage: true },
      { key: "user_adharcard_front_photo", label: "Aadhar Card (Front)", isImage: true },
      { key: "user_adharcard_back_photo", label: "Aadhar Card (Back)", isImage: true },
      { key: "user_pancard_photo", label: "PAN Card", isImage: true },
      { key: "user_cheque_leaf", label: "Cheque Leaf", isImage: true },
      { key: "bank_statement_month", label: "Bank Statement", isImage: false },
      { key: "bank_passbook_photo", label: "Passbook Photo", isImage: true },
      { key: "business_document_proof", label: "Business Proof", isImage: false },
      { key: "user_salary_slip", label: "Salary Slip", isImage: false },
      { key: "user_nominee_adharcard_front_photo", label: "Nominee Aadhar (Front)", isImage: true },
      { key: "user_nominee_adharcard_back_photo", label: "Nominee Aadhar (Back)", isImage: true },
      { key: "user_nominee_pancard_photo", label: "Nominee PAN Card", isImage: true }
    ];
    docMappings.forEach((mapping) => {
      if (userDoc[mapping.key]) {
        documents.push({
          document_type: mapping.label,
          file_url: userDoc[mapping.key],
          description: `${mapping.label} document`,
          isImage: mapping.isImage
        });
      }
    });
    if (userDoc.user_document_code) {
      documents.push({
        document_type: "Document Reference",
        file_url: null,
        description: `Document Code: ${userDoc.user_document_code}`,
        isImage: false
      });
    }
    return documents;
  };
  const calculateDocumentPercentage = (documents) => {
    if (!documents || documents.length === 0) return 0;
    const uploadedDocs = documents.filter(
      (doc) => doc.file_url && doc.document_type !== "Document Reference"
    );
    const totalRequiredDocs = REQUIRED_DOCUMENTS.length;
    const percentage = uploadedDocs.length / totalRequiredDocs * 100;
    return Math.round(percentage);
  };
  const handleDocumentAction = async (action) => {
    if (!currentAuctionForDocs) return;
    try {
      let newStatus = "";
      switch (action) {
        case "verify":
          newStatus = "Document Verification";
          break;
        case "complete":
          newStatus = "Completed";
          break;
        case "pending":
          newStatus = "Document Collection";
          message.info("Document marked as pending");
          break;
        default:
          break;
      }
      if (newStatus) {
        await updateAuctionStatus(currentAuctionForDocs._id, newStatus);
      }
      setShowDocumentModal(false);
      setCurrentDocuments([]);
      setCurrentAuctionForDocs(null);
      fetchProcessData();
    } catch (error) {
      console.error("Error updating document status:", error);
      message.error("Failed to update document status");
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handlePayoutSuccess = () => {
    navigate("/payment-menu/payment-in-out-menu/pay-out-menu/chit");
    message.success("Access granted. Redirecting to payout...");
    setPendingPayoutId(null);
  };
  const handleDeleteAuction = async (auctionId) => {
    try {
      await api.delete(`/auction/delete-auction/${auctionId}`);
      message.success("Auction deleted successfully");
      if (selectedGroupId) {
        await handleGroupChange(selectedGroupId);
      } else {
        fetchRecentAuctions();
      }
      fetchProcessData();
    } catch (error) {
      message.error("Failed to delete auction");
    }
  };
  const handleUpdateModalOpen = async (auctionId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${auctionId}`);
      setUpdateFormData({
        auction_date: response.data?.auction_date,
        next_date: response.data?.next_date
      });
      setCurrentUpdateGroup(response.data);
      setShowModalUpdate(true);
      setOpenActionMenuId(null);
    } catch (error) {
      console.error("Error fetching auction:", error);
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/auction/${currentUpdateGroup?._id}`, updateFormData);
      setShowModalUpdate(false);
      message.success("Auction date Updated Successfully");
      if (selectedGroupId) {
        await handleGroupChange(selectedGroupId);
      } else {
        fetchRecentAuctions();
      }
    } catch (error) {
      message.error(error.response?.data?.message || "An unexpected error occurred");
    }
  };
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const getDisplayData = () => {
    return filteredAuctions.filter((item) => !item.isCommencement);
  };
  const displayData = getDisplayData();
  const totalGroupValue = displayData.reduce(
    (sum, item) => sum + (parseFloat(item.group_value) || 0),
    0
  );
  const totalBidAmount = displayData.reduce(
    (sum, item) => sum + (parseFloat(item.bid_amount) || 0),
    0
  );
  const totalWinAmount = displayData.reduce(
    (sum, item) => sum + (parseFloat(item.amount) || 0),
    0
  );
  const selectedCount = useMemo(() => {
    return displayData.filter((item) => activeUserData[item._id]?.info?.status).length;
  }, [displayData, activeUserData]);
  useEffect(() => {
    const allChecked = displayData.length > 0 && displayData.every((item) => activeUserData[item._id]?.info?.status);
    setSelectAll(allChecked);
  }, [displayData, activeUserData]);
  const handleCheckboxChange = (item) => {
    if (item.isCommencement) return;
    setActiveUserData((prev) => ({
      ...prev,
      [item._id]: {
        info: {
          status: !prev[item._id]?.info?.status,
          auction_code: item.auction_code,
          name: item.name
        }
      }
    }));
  };
  const handleSelectAllChange = (e) => {
    const checked = e.target.checked;
    setSelectAll(checked);
    const updated = { ...activeUserData };
    displayData.forEach((item) => {
      if (!item.isCommencement) {
        updated[item._id] = {
          info: {
            status: checked,
            auction_code: item.auction_code,
            name: item.name
          }
        };
      }
    });
    setActiveUserData(updated);
  };
  const formattedAuctionData = useMemo(() => {
    const formatted = filteredAuctions.map((item) => {
      const workflowStatus = item.workflow_status || "Pending";
      const checkbox = item.isCommencement ? /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3181,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "checkbox",
          checked: activeUserData[item._id]?.info?.status || false,
          onChange: () => handleCheckboxChange(item),
          className: "w-4 h-4 cursor-pointer accent-blue-600"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3183,
          columnNumber: 7
        },
        this
      );
      return {
        ...item,
        checkbox,
        workflow_status: getStatusTag(workflowStatus),
        action: item.isCommencement ? null : item.action
      };
    });
    return formatted;
  }, [filteredAuctions, activeUserData]);
  const recentColumns = [
    { key: "checkbox", header: "Select" },
    { key: "id", header: "SL. NO" },
    { key: "auction_code", header: "Auction Code" },
    { key: "auction_date", header: "Auction Date" },
    { key: "group_name", header: "Group Name" },
    { key: "group_value", header: "Group Value" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "ticket", header: "Ticket" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "amount", header: "Win Amount" },
    { key: "auction_type", header: "Auction Type" },
    { key: "workflow_status", header: "Workflow Status" },
    { key: "action", header: "Action" }
  ];
  const docCollectionColumns = [
    { key: "id", header: "SL. NO" },
    { key: "auction_code", header: "Auction Code" },
    { key: "auction_date", header: "Auction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "status", header: "Status" },
    { key: "time", header: "Updated Date" },
    { key: "document", header: "Document" },
    { key: "action", header: "Action" }
  ];
  const docVerificationColumns = [
    { key: "id", header: "SL. NO" },
    { key: "auction_code", header: "Auction Code" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "status", header: "Status" },
    { key: "time", header: "Updated Date" },
    { key: "document", header: "Document" },
    { key: "action", header: "Action" }
  ];
  const completedColumns = [
    { key: "id", header: "SL. NO" },
    { key: "auction_code", header: "Auction Code" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "status", header: "Status" },
    { key: "time", header: "Completed Date" },
    { key: "action", header: "Action" }
  ];
  const tabs = [
    {
      id: "recent_auctions",
      label: "Auction Winners",
      count: filteredAuctions.filter((item) => !item.isCommencement).length,
      icon: /* @__PURE__ */ jsxDEV(IoFlash, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3260,
        columnNumber: 11
      }, this)
    },
    {
      id: "document_collection",
      label: "Document Collection",
      count: filteredDocCollection.length,
      icon: /* @__PURE__ */ jsxDEV(IoDocumentText, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3266,
        columnNumber: 11
      }, this)
    },
    {
      id: "document_verification",
      label: "Document Verification",
      count: filteredDocVerification.length,
      icon: /* @__PURE__ */ jsxDEV(IoCheckmarkCircle, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3272,
        columnNumber: 11
      }, this)
    },
    {
      id: "completed",
      label: "Completed",
      count: filteredCompleted.length,
      icon: /* @__PURE__ */ jsxDEV(IoFlag, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3278,
        columnNumber: 11
      }, this)
    }
  ];
  const renderTabContent = () => {
    if (isLoading) {
      return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-10", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3286,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3285,
        columnNumber: 9
      }, this);
    }
    switch (activeTab) {
      case "recent_auctions":
        return /* @__PURE__ */ jsxDEV(Fragment, { children: [
          selectedCount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg shadow p-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-600 text-white rounded-full h-10 w-10 flex items-center justify-center font-bold text-lg shadow-md", children: selectedCount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3299,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-lg", children: "Item(s) Selected" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3302,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3298,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3 justify-center", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  className: "bg-blue-600 hover:bg-blue-700",
                  onClick: () => handleBulkStatusUpdate("Document Collection"),
                  children: "Document Collection"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3305,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  className: "bg-orange-500 text-white hover:bg-orange-600",
                  onClick: () => {
                    const selected = displayData.filter(
                      (item) => activeUserData[item._id]?.info?.status && !item.isCommencement
                    );
                    if (selected.length === 1) {
                      handleUpdateModalOpen(selected[0]._id);
                    } else if (selected.length > 1) {
                      message.warning("Please select only one auction to edit");
                    } else {
                      message.warning("Please select an auction to edit");
                    }
                  },
                  children: "Edit Auction"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3312,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Button, { danger: true, onClick: handleBulkDelete, children: "Delete" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3329,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3304,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3297,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3296,
            columnNumber: 13
          }, this),
          displayData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-gray-50 rounded-lg flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                className: "w-4 h-4 cursor-pointer accent-blue-600",
                checked: selectAll,
                onChange: handleSelectAllChange
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3339,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: [
              selectAll ? "Deselect All" : "Select All",
              " (",
              displayData.length,
              " items)"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3345,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3338,
            columnNumber: 13
          }, this),
          loadingRecent || isGroupLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-10", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3353,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3352,
            columnNumber: 13
          }, this) : filteredAuctions?.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filterOption(formattedAuctionData, searchText),
              columns: recentColumns,
              exportedFileName: selectedGroupId ? `Group_${selectedGroupName}_Auctions.csv` : "Recent_Auctions.csv"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3356,
              columnNumber: 13
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: selectedGroupId ? "No auctions found for this group." : "No recent auctions available." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3362,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3294,
          columnNumber: 11
        }, this);
      case "document_collection":
        return filteredDocCollection?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredDocCollection, searchText),
            columns: docCollectionColumns,
            exportedFileName: "Document_Collection.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3371,
            columnNumber: 9
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No records in Document Collection." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3377,
          columnNumber: 9
        }, this);
      case "document_verification":
        return filteredDocVerification?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredDocVerification, searchText),
            columns: docVerificationColumns,
            exportedFileName: "Document_Verification.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3382,
            columnNumber: 9
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No records in Document Verification." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3388,
          columnNumber: 9
        }, this);
      case "completed":
        return filteredCompleted?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredCompleted, searchText),
            columns: completedColumns,
            exportedFileName: "Completed.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3393,
            columnNumber: 9
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No completed records." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3399,
          columnNumber: 9
        }, this);
      default:
        return null;
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: previewImage !== null,
        title: previewTitle,
        footer: null,
        onCancel: handleCancelPreview,
        width: "auto",
        style: { maxWidth: "90vw" },
        children: /* @__PURE__ */ jsxDEV("img", { alt: previewTitle, style: { width: "100%" }, src: previewImage }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3417,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3409,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      ModalComponent,
      {
        isVisible: showKycPreview,
        onClose: () => {
          setShowKycPreview(false);
          setKycUserData(null);
        },
        width: "900px",
        title: "Customer KYC Verification",
        children: [
          isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3431,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3430,
            columnNumber: 9
          }, this) : kycUserData ? /* @__PURE__ */ jsxDEV("div", { className: "max-h-[70vh] overflow-y-auto p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border rounded-lg p-6 shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-center border-b pb-4 mb-4", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-blue-800", children: "CUSTOMER KYC VERIFICATION FORM" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3437,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Know Your Customer - Verification Document" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3438,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mt-2 text-sm", children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Customer ID:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3441,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData?.customer_id || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3440,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Date:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3444,
                    columnNumber: 21
                  }, this),
                  " ",
                  (/* @__PURE__ */ new Date()).toLocaleDateString()
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3443,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3439,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3436,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-bold bg-blue-800 text-white px-3 py-1 rounded", children: "Customer Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3451,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 mt-2 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Name:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3454,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.full_name || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3453,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "DOB:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3457,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.dateofbirth?.split("T")[0] || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3456,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Gender:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3460,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.gender || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3459,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Phone:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3463,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.phone_number || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3462,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Email:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3466,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.email || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3465,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Marital Status:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3469,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.marital_status || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3468,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Nationality:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3472,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.nationality || "Indian"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3471,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Address:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3475,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.address || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3474,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Village:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3478,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.village || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3477,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Taluk:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3481,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.taluk || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3480,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "District:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3484,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.district || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3483,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "State:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3487,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.state || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3486,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Pincode:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3490,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.pincode || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3489,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Father:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3493,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.father_name || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3492,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Aadhaar No:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3496,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.adhaar_no || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3495,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "PAN No:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3499,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.pan_no || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3498,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3452,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3450,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-bold bg-blue-800 text-white px-3 py-1 rounded", children: "Nominee Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3506,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 mt-2 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Name:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3509,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.nominee_name || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3508,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "DOB:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3512,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.nominee_dateofbirth?.split("T")[0] || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3511,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Relationship:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3515,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.nominee_relationship || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3514,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Phone:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3518,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.nominee_phone_number || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3517,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3507,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3505,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-bold bg-yellow-600 text-white px-3 py-1 rounded", children: "Guarantor Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3525,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 mt-2 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Name:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3528,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.guarantor_name || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3527,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "DOB:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3531,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.guarantor_dateofbirth?.split("T")[0] || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3530,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Relationship:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3534,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.guarantor_relationship || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3533,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Phone:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3537,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.guarantor_phone || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3536,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Address:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3540,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.guarantor_address || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3539,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Aadhaar No:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3543,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.guarantor_adhaar || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3542,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "PAN No:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3546,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.guarantor_pan || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3545,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3526,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3524,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-bold bg-blue-800 text-white px-3 py-1 rounded", children: "Bank Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3553,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 mt-2 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Bank Name:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3556,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.bank_name || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3555,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Branch Name:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3559,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.bank_branch_name || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3558,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Account No:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3562,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.bank_account_number || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3561,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "IFSC Code:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3565,
                    columnNumber: 21
                  }, this),
                  " ",
                  kycUserData.bank_IFSC_code || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3564,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3554,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3552,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-4 border-t", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium", children: "Signature of Subscriber" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3574,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-400 w-48 mt-2 h-8" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3575,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3573,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium", children: "Signature of Guarantor" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3578,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-400 w-48 mt-2 h-8" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3579,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3577,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3572,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "This is a system generated KYC document. Verification required." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3583,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3582,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3571,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3435,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3434,
            columnNumber: 9
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No data available" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3589,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 border-t pt-4 mt-4", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                onClick: () => {
                  setShowKycPreview(false);
                  setKycUserData(null);
                },
                className: "bg-gray-500 hover:bg-gray-600 text-white",
                children: "Close"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3593,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3604,
                  columnNumber: 19
                }, this),
                onClick: () => {
                  if (kycUserData) {
                    handleKycVerificationPrint(kycUserData._id);
                  }
                },
                className: "bg-blue-600",
                children: "Download KYC"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3602,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3592,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3420,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { onGlobalSearchChangeHandler, visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3618,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3619,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3622,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-gray-900", children: "Auction Workflow Management" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3625,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Track and manage post-auction processes" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3626,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3624,
            columnNumber: 13
          }, this),
          activeTab === "recent_auctions" && displayData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 bg-gradient-to-r from-orange-50 to-orange-100 border border-orange-200 rounded-xl shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-orange-600", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-5 h-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3633,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3632,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-orange-600 font-medium", children: "Group Value" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3636,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-gray-900", children: [
                "₹",
                totalGroupValue.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3637,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3635,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-10 border-l border-orange-300" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3641,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-blue-600 font-medium", children: "Bid Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3643,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-blue-700", children: [
                "₹",
                totalBidAmount.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3644,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3642,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-10 border-l border-orange-300" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3648,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-green-600 font-medium", children: "Total Win Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3650,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-green-700", children: [
                "₹",
                totalWinAmount.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3651,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3649,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3631,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3630,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3623,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 p-4 bg-white border border-gray-200 rounded-lg shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(IoSearch, { className: "text-gray-400 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3665,
              columnNumber: 7
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700 whitespace-nowrap", children: "Filter by Group:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3666,
              columnNumber: 7
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3664,
            columnNumber: 5
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedGroupId || void 0,
              onChange: handleGroupChange,
              showSearch: true,
              className: "w-64",
              placeholder: "Search or select a group...",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              suffixIcon: /* @__PURE__ */ jsxDEV(IoSearch, { className: "text-gray-400" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3677,
                columnNumber: 29
              }, this),
              notFoundContent: "No groups found",
              allowClear: true,
              loading: isGroupLoading,
              children: groups.map(
                (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g._id, children: g.group_name }, g._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3683,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3668,
              columnNumber: 5
            },
            this
          ),
          selectedGroupId && /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "small",
              onClick: () => {
                setSelectedGroupId("");
                setSelectedGroupName("");
                setFilteredGroupAuctions([]);
                setFilteredAuctions(allRecentAuctions);
                setTableAuctions(allRecentAuctions);
              },
              className: "text-red-500 hover:text-red-700",
              children: "Clear"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3689,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:block w-px h-8 bg-gray-300" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3705,
            columnNumber: 5
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700 whitespace-nowrap", children: "Date Filter:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3709,
              columnNumber: 7
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                onChange: handleDateFilter,
                format: "YYYY-MM-DD",
                placeholder: ["Start", "End"],
                className: "w-56",
                size: "small"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3710,
                columnNumber: 7
              },
              this
            ),
            dateRange?.[0] && dateRange?.[1] && /* @__PURE__ */ jsxDEV(
              Button,
              {
                onClick: () => {
                  setDateRange([null, null]);
                  if (selectedGroupId) {
                    setFilteredAuctions(filteredGroupAuctions);
                  } else {
                    setFilteredAuctions(allRecentAuctions);
                  }
                  setFilteredDocCollection(documentCollectionData);
                  setFilteredDocVerification(documentVerificationData);
                  setFilteredCompleted(completedData);
                },
                size: "small",
                className: "text-blue-600 px-2",
                children: "Clear"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3718,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3708,
            columnNumber: 5
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3662,
          columnNumber: 3
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3661,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("nav", { className: "flex space-x-8", "aria-label": "Tabs", children: tabs.map(
          (tab) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setActiveTab(tab.id);
                setOpenActionMenuId(null);
              },
              className: `group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm ${activeTab === tab.id ? "border-orange-500 text-orange-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2 text-lg", children: tab.icon }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3765,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: tab.label }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3766,
                  columnNumber: 21
                }, this),
                tab.count > 0 && /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: `ml-3 py-0.5 px-2 rounded-full text-xs font-medium ${activeTab === tab.id ? "bg-orange-100 text-orange-600" : "bg-gray-100 text-gray-600"}`,
                    children: tab.count
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3768,
                    columnNumber: 19
                  },
                  this
                )
              ]
            },
            tab.id,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3753,
              columnNumber: 17
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3751,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3750,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3749,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: renderTabContent() }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3782,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
        lineNumber: 3621,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        ModalComponent,
        {
          isVisible: showModalUpdate,
          onClose: () => setShowModalUpdate(false),
          width: "800px",
          children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Edit Auction" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3792,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Auction Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3796,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "auction_date",
                      value: updateFormData?.auction_date?.split("T")[0] || "",
                      onChange: handleInputChange,
                      className: "w-full p-2.5 border rounded-lg"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                      lineNumber: 3797,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3795,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Next Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3806,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "next_date",
                      value: updateFormData?.next_date?.split("T")[0] || "",
                      onChange: handleInputChange,
                      className: "w-full p-2.5 border rounded-lg"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                      lineNumber: 3807,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3805,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3794,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "text-white bg-blue-700 hover:bg-blue-800 font-medium rounded-lg text-sm px-5 py-2.5",
                  children: "Update"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3817,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3816,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3793,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
            lineNumber: 3791,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3786,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        SimplePasswordModal,
        {
          isOpen: showPayoutPassword,
          onClose: handlePayoutModalClose,
          onSuccess: handlePayoutSuccess,
          title: "Payout Authorization",
          description: "Enter your admin password to proceed with the payout"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3828,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        ModalComponent,
        {
          isVisible: showDocumentModal,
          onClose: () => {
            setShowDocumentModal(false);
            setCurrentDocuments([]);
            setCurrentAuctionForDocs(null);
          },
          width: "900px",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "max-h-[70vh] overflow-y-auto space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-xl p-4 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3850,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: currentAuctionForDocs?.user_id?.full_name || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3851,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3849,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3856,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: currentAuctionForDocs?.user_id?.phone_number || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3857,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3855,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: "Customer ID" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3862,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 break-all", children: currentAuctionForDocs?.user_id?.customer_id || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3863,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3861,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3848,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3847,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 rounded-xl p-4 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700", children: "Document Upload Progress" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3872,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `text-sm font-semibold ${calculateDocumentPercentage(currentDocuments) === 100 ? "text-green-600" : calculateDocumentPercentage(currentDocuments) >= 70 ? "text-yellow-600" : "text-red-600"}`,
                      children: [
                        calculateDocumentPercentage(currentDocuments),
                        "%"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                      lineNumber: 3873,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3871,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(Progress, { percent: calculateDocumentPercentage(currentDocuments), size: "small" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3885,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mt-3 text-xs text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Uploaded:",
                    " ",
                    currentDocuments.filter(
                      (doc) => doc.file_url && doc.document_type !== "Document Reference"
                    ).length,
                    " ",
                    "/ ",
                    REQUIRED_DOCUMENTS.length
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3887,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Remaining:",
                    " ",
                    REQUIRED_DOCUMENTS.length - currentDocuments.filter(
                      (doc) => doc.file_url && doc.document_type !== "Document Reference"
                    ).length
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3896,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3886,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3870,
                columnNumber: 13
              }, this),
              currentDocuments.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: currentDocuments.map(
                (doc, index) => /* @__PURE__ */ jsxDEV("div", { className: "border rounded-xl p-4 hover:shadow-md transition bg-white", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-2", children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 text-sm", children: doc.document_type }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                      lineNumber: 3911,
                      columnNumber: 23
                    }, this),
                    doc.file_url && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                      /* @__PURE__ */ jsxDEV(
                        IoEye,
                        {
                          onClick: () => handlePreview(doc.file_url, doc.document_type),
                          className: "text-blue-600 cursor-pointer text-lg hover:scale-110"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                          lineNumber: 3914,
                          columnNumber: 27
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("a", { href: doc.file_url, target: "_blank", rel: "noopener noreferrer", children: /* @__PURE__ */ jsxDEV(IoDownload, { className: "text-green-600 text-lg hover:scale-110" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                        lineNumber: 3919,
                        columnNumber: 29
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                        lineNumber: 3918,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                      lineNumber: 3913,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3910,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2 h-32 flex items-center justify-center", children: doc.isImage && doc.file_url ? /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: doc.file_url,
                      alt: doc.document_type,
                      className: "h-full object-contain cursor-pointer",
                      onClick: () => handlePreview(doc.file_url, doc.document_type)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                      lineNumber: 3926,
                      columnNumber: 19
                    },
                    this
                  ) : doc.file_url ? /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-gray-400 text-4xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3933,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: "No file uploaded" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3935,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                    lineNumber: 3924,
                    columnNumber: 21
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3909,
                  columnNumber: 15
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3907,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10", children: [
                /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-gray-400 text-5xl mx-auto mb-3" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3943,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No documents uploaded for this auction." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3944,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                lineNumber: 3942,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3846,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 border-t pt-4 mt-4", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => handleDocumentAction("pending"),
                  className: "bg-yellow-500 hover:bg-yellow-600 text-white",
                  children: "Docs Pending"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3950,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => handleDocumentAction("verify"),
                  type: "primary",
                  className: "bg-blue-600",
                  disabled: calculateDocumentPercentage(currentDocuments) < 100,
                  children: [
                    "Move to Verification",
                    calculateDocumentPercentage(currentDocuments) < 100 && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs opacity-75", children: [
                      "(",
                      calculateDocumentPercentage(currentDocuments),
                      "% complete)"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                      lineNumber: 3964,
                      columnNumber: 15
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3956,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => handleDocumentAction("complete"),
                  className: "bg-green-600 text-white hover:bg-green-700",
                  children: "Completed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
                  lineNumber: 3969,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3949,
              columnNumber: 11
            }, this),
            calculateDocumentPercentage(currentDocuments) < 100 && currentDocuments.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 text-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-yellow-600", children: [
              "⚠️ Please upload all required documents (",
              REQUIRED_DOCUMENTS.length - currentDocuments.filter(
                (doc) => doc.file_url && doc.document_type !== "Document Reference"
              ).length,
              " ",
              "remaining) before verification"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3978,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
              lineNumber: 3977,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
          lineNumber: 3837,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
      lineNumber: 3617,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx",
    lineNumber: 3408,
    columnNumber: 5
  }, this);
}
_s(RecentAuction, "2R3A9XCK+IJOoCP2tVOOuySjEi0=", false, function() {
  return [useNavigate, useLocation];
});
_c = RecentAuction;
export default RecentAuction;
var _c;
$RefreshReg$(_c, "RecentAuction");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RecentAuction.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaXVFMEIsU0E0L0JoQixVQTUvQmdCOzJCQWp1RTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBeWdFQSxPQUFPQSxXQUFXO0FBQ2xCLFNBQVNDLFdBQVdDLFVBQVVDLGVBQWU7QUFDN0MsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxTQUFTO0FBQ2hCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGdCQUFnQjtBQUN6QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLHlCQUF5QjtBQUNoQyxPQUFPQyxnQ0FBZ0M7QUFFdkMsTUFBTSxFQUFFQyxZQUFZLElBQUl0QjtBQUd4QixNQUFNdUIscUJBQXFCO0FBQUEsRUFDekIsRUFBRUMsS0FBSyxzQkFBc0JDLE9BQU8sUUFBUTtBQUFBLEVBQzVDLEVBQUVELEtBQUssOEJBQThCQyxPQUFPLHNCQUFzQjtBQUFBLEVBQ2xFLEVBQUVELEtBQUssNkJBQTZCQyxPQUFPLHFCQUFxQjtBQUFBLEVBQ2hFLEVBQUVELEtBQUssc0JBQXNCQyxPQUFPLFdBQVc7QUFBQSxFQUMvQyxFQUFFRCxLQUFLLG9CQUFvQkMsT0FBTyxjQUFjO0FBQUEsRUFDaEQsRUFBRUQsS0FBSyx3QkFBd0JDLE9BQU8saUJBQWlCO0FBQUEsRUFDdkQsRUFBRUQsS0FBSyx1QkFBdUJDLE9BQU8saUJBQWlCO0FBQUEsRUFDdEQsRUFBRUQsS0FBSywyQkFBMkJDLE9BQU8saUJBQWlCO0FBQUEsRUFDMUQsRUFBRUQsS0FBSyxvQkFBb0JDLE9BQU8sY0FBYztBQUFBLEVBQ2hELEVBQUVELEtBQUssc0NBQXNDQyxPQUFPLHlCQUF5QjtBQUFBLEVBQzdFLEVBQUVELEtBQUsscUNBQXFDQyxPQUFPLHdCQUF3QjtBQUFBLEVBQzNFLEVBQUVELEtBQUssOEJBQThCQyxPQUFPLG1CQUFtQjtBQUFDO0FBR2xFLFNBQVNDLGdCQUFnQjtBQUFBQyxLQUFBO0FBQ3ZCLFFBQU1DLFdBQVd4QyxZQUFZO0FBQzdCLFFBQU15QyxXQUFXeEMsWUFBWTtBQUM3QixRQUFNLENBQUN5QyxlQUFlQyxnQkFBZ0IsSUFBSTdDLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUM4QyxlQUFlQyxnQkFBZ0IsSUFBSS9DLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNnRCxtQkFBbUJDLG9CQUFvQixJQUFJakQsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ2tELFlBQVlDLGFBQWEsSUFBSW5ELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNvRCxpQkFBaUJDLGtCQUFrQixJQUFJckQsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3NELG9CQUFvQkMscUJBQXFCLElBQUl2RCxTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDd0QsV0FBV0MsWUFBWSxJQUFJekQsU0FBUyxpQkFBaUI7QUFDNUQsUUFBTSxDQUFDMEQsV0FBV0MsWUFBWSxJQUFJM0QsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzRELGNBQWNDLGVBQWUsSUFBSTdELFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUM4RCxjQUFjQyxlQUFlLElBQUkvRCxTQUFTLEVBQUU7QUFFbkQsUUFBTSxDQUFDZ0Usb0JBQW9CQyxxQkFBcUIsSUFBSWpFLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNrRSxpQkFBaUJDLGtCQUFrQixJQUFJbkUsU0FBUyxJQUFJO0FBRTNELFFBQU0sQ0FBQ29FLHVCQUF1QkMsd0JBQXdCLElBQUlyRSxTQUFTLEVBQUU7QUFDckUsUUFBTSxDQUFDc0UseUJBQXlCQywwQkFBMEIsSUFBSXZFLFNBQVMsRUFBRTtBQUN6RSxRQUFNLENBQUN3RSxtQkFBbUJDLG9CQUFvQixJQUFJekUsU0FBUyxFQUFFO0FBRTdELFFBQU0sQ0FBQzBFLGdCQUFnQkMsaUJBQWlCLElBQUkzRSxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDNEUsYUFBYUMsY0FBYyxJQUFJN0UsU0FBUyxJQUFJO0FBR25ELFFBQU0sQ0FBQzhFLFdBQVdDLFlBQVksSUFBSS9FLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQztBQUN2RCxRQUFNLENBQUNnRixrQkFBa0JDLG1CQUFtQixJQUFJakYsU0FBUyxFQUFFO0FBRzNELFFBQU0sQ0FBQ2tGLHdCQUF3QkMseUJBQXlCLElBQUluRixTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDb0YsMEJBQTBCQywyQkFBMkIsSUFBSXJGLFNBQVMsRUFBRTtBQUMzRSxRQUFNLENBQUNzRixlQUFlQyxnQkFBZ0IsSUFBSXZGLFNBQVMsRUFBRTtBQUVyRCxRQUFNLENBQUN3RixnQkFBZ0JDLGlCQUFpQixJQUFJekYsU0FBUztBQUFBLElBQ25EMEYsY0FBYztBQUFBLElBQ2RDLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFHRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUk3RixTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUM4RixXQUFXQyxZQUFZLElBQUkvRixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDZ0csa0JBQWtCQyxtQkFBbUIsSUFBSWpHLFNBQVMsSUFBSTtBQUc3RCxRQUFNLENBQUNrRyxtQkFBbUJDLG9CQUFvQixJQUFJbkcsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ29HLGtCQUFrQkMsbUJBQW1CLElBQUlyRyxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDc0csdUJBQXVCQyx3QkFBd0IsSUFBSXZHLFNBQVMsSUFBSTtBQUN2RSxRQUFNLENBQUN3RyxzQkFBc0JDLHVCQUF1QixJQUFJekcsU0FBUyxFQUFFO0FBR25FLFFBQU0sQ0FBQzBHLFFBQVFDLFNBQVMsSUFBSTNHLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUM0RyxpQkFBaUJDLGtCQUFrQixJQUFJN0csU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzhHLG1CQUFtQkMsb0JBQW9CLElBQUkvRyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDZ0gsdUJBQXVCQyx3QkFBd0IsSUFBSWpILFNBQVMsRUFBRTtBQUNyRSxRQUFNLENBQUNrSCxnQkFBZ0JDLGlCQUFpQixJQUFJbkgsU0FBUyxLQUFLO0FBRTFERCxZQUFVLE1BQU07QUFDZHFILGdCQUFZO0FBQ1pDLHdCQUFvQjtBQUNwQkMscUJBQWlCO0FBQUEsRUFDbkIsR0FBRyxFQUFFO0FBR0wsUUFBTUYsY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNLEVBQUVHLEtBQUssSUFBSSxNQUFNL0csSUFBSWdILElBQUksd0JBQXdCO0FBQ3ZEYixnQkFBVVksSUFBSTtBQUFBLElBQ2hCLFNBQVNFLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSwwQkFBMEJGLEdBQUc7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFHQSxRQUFNRyxvQkFBb0IsT0FBT0MsWUFBWTtBQUMzQ2hCLHVCQUFtQmdCLE9BQU87QUFFMUIsUUFBSSxDQUFDQSxTQUFTO0FBRVpaLCtCQUF5QixFQUFFO0FBQzNCaEMsMEJBQW9CakMsaUJBQWlCO0FBQ3JDK0QsMkJBQXFCLEVBQUU7QUFDdkI7QUFBQSxJQUNGO0FBRUFJLHNCQUFrQixJQUFJO0FBQ3RCcEUscUJBQWlCLEVBQUU7QUFDbkJrRSw2QkFBeUIsRUFBRTtBQUUzQixRQUFJO0FBRUYsWUFBTSxFQUFFTSxLQUFLLElBQUksTUFBTS9HLElBQUlnSCxJQUFJLDJCQUEyQkssT0FBTyxFQUFFO0FBR25FLFlBQU1DLGdCQUFnQnBCLE9BQU9xQixLQUFLLENBQUFDLE1BQUtBLEVBQUVDLFFBQVFKLE9BQU87QUFDeERkLDJCQUFxQmUsZUFBZUksY0FBYyxFQUFFO0FBRXBELFVBQUlYLFFBQVFBLEtBQUtZLFNBQVMsR0FBRztBQUUzQixjQUFNQyxvQkFBb0I7QUFBQSxVQUN4QjtBQUFBLFlBQ0VDLElBQUk7QUFBQSxZQUNKM0MsY0FBYyxJQUFJNEM7QUFBQUEsY0FDaEIsSUFBSUEsS0FBS2YsS0FBSyxDQUFDLEVBQUU3QixZQUFZLEVBQUU2QyxRQUFRLElBQUksS0FBSztBQUFBLFlBQ2xELEVBQ0dDLG1CQUFtQixTQUFTO0FBQUEsY0FDM0JDLEtBQUs7QUFBQSxjQUNMQyxPQUFPO0FBQUEsY0FDUEMsTUFBTTtBQUFBLFlBQ1IsQ0FBQyxFQUNBQyxRQUFRLEtBQUssRUFBRTtBQUFBLFlBQ2xCQyxNQUFNO0FBQUEsWUFDTkMsY0FBYztBQUFBLFlBQ2RDLFFBQVE7QUFBQSxZQUNSQyxZQUFZO0FBQUEsWUFDWkMsUUFBUTtBQUFBLFlBQ1JDLGNBQWM7QUFBQSxZQUNkQyxRQUFRO0FBQUEsWUFDUkMsaUJBQWlCO0FBQUEsWUFDakJsQixZQUFZSixlQUFlSSxjQUFjO0FBQUEsWUFDekNtQixhQUFhOUIsS0FBSyxDQUFDLEdBQUcrQixVQUFVRCxlQUFlO0FBQUEsWUFDL0NFLGNBQWM7QUFBQSxZQUNkQyxnQkFBZ0I7QUFBQSxZQUNoQkMsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxVQUNBLEdBQUdsQyxLQUFLbUMsSUFBSSxDQUFDMUIsR0FBRzJCLFNBQVM7QUFBQSxZQUN2QjFCLEtBQUtELEVBQUVDO0FBQUFBLFlBQ1BJLElBQUlzQixNQUFNO0FBQUEsWUFDVmpFLGNBQWMsSUFBSTRDLEtBQUtOLEVBQUV0QyxZQUFZLEVBQUU4QyxtQkFBbUIsU0FBUztBQUFBLGNBQ2pFQyxLQUFLO0FBQUEsY0FDTEMsT0FBTztBQUFBLGNBQ1BDLE1BQU07QUFBQSxZQUNSLENBQUM7QUFBQSxZQUNERSxNQUFNYixFQUFFNEIsU0FBU0MsYUFBYTtBQUFBLFlBQzlCZixjQUFjZCxFQUFFNEIsU0FBU2QsZ0JBQWdCO0FBQUEsWUFDekNDLFFBQVFmLEVBQUVlLFVBQVU7QUFBQSxZQUNwQkMsWUFBWWMsT0FBTzlCLEVBQUUrQixRQUFRLElBQUlELE9BQU85QixFQUFFZ0MsVUFBVSxLQUFLO0FBQUEsWUFDekRmLFFBQVFqQixFQUFFaUMsY0FBYztBQUFBLFlBQ3hCZixjQUNFbEIsRUFBRWtCLGNBQWNnQixPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUN0Q25DLEVBQUVrQixjQUFja0IsTUFBTSxDQUFDLElBQ3ZCLGNBQWM7QUFBQSxZQUNoQmpCLFFBQVEsQ0FBQ25CLEdBQUdxQyxXQUFXLGNBQWM7QUFBQSxZQUNyQ2pCLGlCQUFpQnBCLEVBQUVtQixVQUFVO0FBQUEsWUFDN0JqQixZQUFZRixFQUFFc0IsVUFBVXBCLGNBQWNKLGVBQWVJLGNBQWM7QUFBQSxZQUNuRW1CLGFBQWFyQixFQUFFc0IsVUFBVUQsZUFBZTtBQUFBLFlBQ3hDRSxjQUFjdkIsRUFBRXVCLGdCQUFnQjtBQUFBLFlBQ2hDSyxTQUFTNUIsRUFBRTRCLFNBQVMzQjtBQUFBQSxZQUNwQnFCLFVBQVV0QixFQUFFc0IsVUFBVXJCO0FBQUFBLFlBQ3RCdUIsZ0JBQWdCO0FBQUEsWUFDaEJDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxDQUFDLE9BQU87QUFBQSxnQkFDakIsTUFBTTtBQUFBLGtCQUNKYSxPQUFPO0FBQUEsb0JBQ0w7QUFBQSxzQkFDRWhJLEtBQUs7QUFBQSxzQkFDTEMsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUFNO0FBQ2IsZ0NBQUl5RixFQUFFNEIsU0FBUzNCLE9BQU9ELEVBQUVzQixVQUFVckIsS0FBSztBQUNyQ3NDLGtEQUFvQnZDLEVBQUVDLEtBQUsscUJBQXFCO0FBQUEsNEJBQ2xELE9BQU87QUFDTHRILHNDQUFRNkosUUFBUSw0REFBNEQ7QUFBQSw0QkFDOUU7QUFBQSwwQkFDRjtBQUFBLDBCQUFFO0FBQUE7QUFBQSx3QkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBV0E7QUFBQSxvQkFFSjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VsSSxLQUFLO0FBQUEsc0JBQ0xDLE9BQ0U7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVMsTUFBTWtJLHNCQUFzQnpDLEVBQUVDLEdBQUc7QUFBQSwwQkFBRTtBQUFBO0FBQUEsd0JBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRTNGLEtBQUs7QUFBQSxzQkFDTEMsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxPQUFNO0FBQUEsMEJBQ04sYUFBWTtBQUFBLDBCQUNaLFdBQVcsTUFBTW1JLG9CQUFvQjFDLEVBQUVDLEdBQUc7QUFBQSwwQkFDMUMsUUFBTztBQUFBLDBCQUNQLFlBQVc7QUFBQSwwQkFFWCxpQ0FBQyxTQUFJLFdBQVUsZ0JBQWUsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW9DO0FBQUE7QUFBQSx3QkFQdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVFBO0FBQUEsb0JBRUo7QUFBQSxrQkFBQztBQUFBLGdCQUVMO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLFlBQVMsV0FBVSxzQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQTtBQUFBLGNBbER4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtREEsS0FwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxREE7QUFBQSxVQUVKLEVBQUU7QUFBQSxRQUFDO0FBR0xoQixpQ0FBeUJtQixpQkFBaUI7QUFDMUNuRCw0QkFBb0JtRCxpQkFBaUI7QUFDckNyRix5QkFBaUJxRixpQkFBaUI7QUFBQSxNQUNwQyxPQUFPO0FBQ0xuQixpQ0FBeUIsRUFBRTtBQUMzQmhDLDRCQUFvQixFQUFFO0FBQ3RCbEMseUJBQWlCLEVBQUU7QUFDbkJwQyxnQkFBUWdLLEtBQUssMkNBQTJDO0FBQUEsTUFDMUQ7QUFBQSxJQUNGLFNBQVNoRCxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JEaEgsY0FBUWdILE1BQU1BLE1BQU1pRCxVQUFVckQsTUFBTTVHLFdBQVcseUNBQXlDO0FBQ3hGc0csK0JBQXlCLEVBQUU7QUFDM0JoQywwQkFBb0IsRUFBRTtBQUN0QmxDLHVCQUFpQixFQUFFO0FBQUEsSUFDckIsVUFBQztBQUNDb0Usd0JBQWtCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEQsbUJBQW1CLE9BQU9DLFdBQVc7QUFDekMsUUFBSTtBQUNGbkgsbUJBQWEsSUFBSTtBQUNqQixZQUFNaUgsV0FBVyxNQUFNcEssSUFBSWdILElBQUksd0JBQXdCc0QsTUFBTSxFQUFFO0FBQy9EakcscUJBQWUrRixTQUFTckQsSUFBSTtBQUM1QjVDLHdCQUFrQixJQUFJO0FBQUEsSUFDeEIsU0FBU2dELE9BQU87QUFDZEQsY0FBUUMsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcERoSCxjQUFRZ0gsTUFBTSw2QkFBNkI7QUFBQSxJQUM3QyxVQUFDO0FBQ0NoRSxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0EsUUFBTTBELHNCQUFzQixZQUFZO0FBQ3RDeEUscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNGLFlBQU0rSCxXQUFXLE1BQU1wSyxJQUFJZ0gsSUFBSSwyQkFBMkI7QUFDMUQsWUFBTXVELGVBQWVILFNBQVNyRCxNQUFNQSxRQUFRcUQsU0FBU3JEO0FBRXJELFVBQUl3RCxnQkFBZ0JDLE1BQU1DLFFBQVFGLFlBQVksS0FBS0EsYUFBYTVDLFNBQVMsR0FBRztBQUUxRSxjQUFNK0Msa0JBQWtCSCxhQUFhSTtBQUFBQSxVQUNuQyxDQUFDQyxZQUFZQSxRQUFRakMsV0FBVyxhQUFhLENBQUNpQyxRQUFRakM7QUFBQUEsUUFDeEQ7QUFFQSxjQUFNa0MsZ0JBQWdCSCxnQkFBZ0J4QixJQUFJLENBQUMwQixTQUFTRSxXQUFXO0FBQUEsVUFDN0RyRCxLQUFLbUQsUUFBUW5EO0FBQUFBLFVBQ2JJLElBQUlpRCxRQUFRO0FBQUEsVUFDWi9CLGNBQWM2QixTQUFTN0I7QUFBQUEsVUFDdkI3RCxjQUFjMEYsU0FBUzFGLGNBQWM2RixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUtILFNBQVMxRjtBQUFBQSxVQUMvRHdDLFlBQVlrRCxRQUFROUIsVUFBVXBCLGNBQWM7QUFBQSxVQUM1Q21CLGFBQWErQixRQUFROUIsVUFBVUQsZUFBZTtBQUFBLFVBQzlDQyxVQUFVOEIsUUFBUTlCLFVBQVVyQixPQUFPbUQsUUFBUTlCO0FBQUFBLFVBQzNDVCxNQUFNdUMsUUFBUXhCLFNBQVNDLGFBQWE7QUFBQSxVQUNwQ2YsY0FBY3NDLFFBQVF4QixTQUFTZCxnQkFBZ0I7QUFBQSxVQUMvQ0MsUUFBUXFDLFNBQVNyQztBQUFBQSxVQUNqQkMsYUFBYXdDLFNBQVNKLFFBQVFyQixRQUFRLEtBQUssTUFBTXlCLFNBQVNKLFFBQVFwQixVQUFVLEtBQUs7QUFBQSxVQUNqRmYsUUFBUW1DLFNBQVNuQjtBQUFBQSxVQUNqQmYsY0FDRWtDLFNBQVNsQyxjQUFjZ0IsT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFDN0NpQixTQUFTbEMsY0FBY2tCLE1BQU0sQ0FBQyxJQUM5QjtBQUFBLFVBQ0ZqQixRQUFRLENBQUNpQyxTQUFTZixXQUFXLGNBQWNlLFNBQVNmLGFBQWEsU0FBUyxXQUFXO0FBQUEsVUFDckZULFNBQVN3QixRQUFReEIsU0FBUzNCO0FBQUFBLFVBQzFCbUIsaUJBQWlCZ0MsUUFBUWpDLFVBQVU7QUFBQSxVQUNuQ0ssZ0JBQWdCO0FBQUEsUUFDbEIsRUFBRTtBQUVGdkcsNkJBQXFCb0ksYUFBYTtBQUVsQyxZQUFJLENBQUN6RSxpQkFBaUI7QUFDcEIzQiw4QkFBb0JvRyxhQUFhO0FBQUEsUUFDbkM7QUFDQXRJLHlCQUFpQnNJLGFBQWE7QUFHOUIsY0FBTUksYUFBYSxDQUFDO0FBQ3BCSixzQkFBY0ssUUFBUSxDQUFDQyxTQUFTO0FBQzlCRixxQkFBV0UsS0FBSzFELEdBQUcsSUFBSTtBQUFBLFlBQ3JCMEMsTUFBTTtBQUFBLGNBQ0p4QixRQUFRO0FBQUEsY0FDUkksY0FBY29DLEtBQUtwQztBQUFBQSxjQUNuQlYsTUFBTThDLEtBQUs5QztBQUFBQSxZQUNiO0FBQUEsVUFDRjtBQUFBLFFBQ0YsQ0FBQztBQUNEaEQsMEJBQWtCNEYsVUFBVTtBQUFBLE1BQzlCLE9BQU87QUFDTHhJLDZCQUFxQixFQUFFO0FBQ3ZCLFlBQUksQ0FBQzJELGlCQUFpQjtBQUNwQjNCLDhCQUFvQixFQUFFO0FBQUEsUUFDeEI7QUFDQWxDLHlCQUFpQixFQUFFO0FBQUEsTUFDckI7QUFBQSxJQUNGLFNBQVM0RSxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDaEgsY0FBUWdILE1BQU1BLE1BQU1pRCxVQUFVckQsTUFBTTVHLFdBQVcsaUNBQWlDO0FBQUEsSUFDbEYsVUFBQztBQUNDa0MsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNMEgsc0JBQXNCLE9BQU9xQixXQUFXQyxjQUFjO0FBQzFELFFBQUk7QUFDRixZQUFNeEQsS0FBSyxPQUFPdUQsY0FBYyxXQUFXQSxXQUFXM0QsTUFBTTJEO0FBRTVELFVBQUksQ0FBQ3ZELElBQUk7QUFDUFgsZ0JBQVFDLE1BQU0sc0JBQXNCaUUsU0FBUztBQUM3QztBQUFBLE1BQ0Y7QUFFQSxZQUFNcEwsSUFBSXNMLElBQUksNEJBQTRCekQsRUFBRSxJQUFJO0FBQUEsUUFDOUNjLFFBQVEwQztBQUFBQSxNQUNWLENBQUM7QUFFRGxMLGNBQVFvTCxRQUFRLHFCQUFxQkYsU0FBUyxFQUFFO0FBR2hELFVBQUlqRixpQkFBaUI7QUFFbkIsY0FBTWdCLGtCQUFrQmhCLGVBQWU7QUFBQSxNQUN6QyxPQUFPO0FBRUxTLDRCQUFvQjtBQUFBLE1BQ3RCO0FBQ0FDLHVCQUFpQjtBQUdqQnpCLHdCQUFrQixDQUFDLENBQUM7QUFDcEJFLG1CQUFhLEtBQUs7QUFDbEJFLDBCQUFvQixJQUFJO0FBQUEsSUFDMUIsU0FBUzBCLE9BQU87QUFDZGhILGNBQVFnSCxNQUFNQSxNQUFNaUQsVUFBVXJELE1BQU01RyxXQUFXLHlCQUF5QjtBQUFBLElBQzFFO0FBQUEsRUFDRjtBQUdBLFFBQU1xTCx5QkFBeUJBLENBQUNILGNBQWM7QUFDNUMsVUFBTUksZ0JBQWdCakgsaUJBQWlCbUc7QUFBQUEsTUFDckMsQ0FBQ1EsU0FBUy9GLGVBQWUrRixLQUFLMUQsR0FBRyxHQUFHMEMsTUFBTXhCLFVBQVUsQ0FBQ3dDLEtBQUtuQztBQUFBQSxJQUM1RDtBQUVBLFFBQUl5QyxjQUFjOUQsV0FBVyxHQUFHO0FBQzlCeEgsY0FBUTZKLFFBQVEsa0NBQWtDO0FBQ2xEO0FBQUEsSUFDRjtBQUVBM0osVUFBTXFMLFFBQVE7QUFBQSxNQUNaQyxPQUFPO0FBQUEsTUFDUEMsU0FBUyxzQ0FBc0NQLFNBQVMsU0FBU0ksY0FBYzlELE1BQU07QUFBQSxNQUNyRmtFLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFDWkMsTUFBTSxZQUFZO0FBQ2hCLFlBQUk7QUFDRixnQkFBTUMsUUFBUUM7QUFBQUEsWUFDWlIsY0FBY3ZDLElBQUksQ0FBQ2lDLFNBQVNwQixvQkFBb0JvQixLQUFLMUQsS0FBSzRELFNBQVMsQ0FBQztBQUFBLFVBQ3RFO0FBQ0FsTCxrQkFBUW9MLFFBQVEsR0FBR0UsY0FBYzlELE1BQU0sc0JBQXNCMEQsU0FBUyxFQUFFO0FBQUEsUUFDMUUsU0FBU2xFLE9BQU87QUFDZGhILGtCQUFRZ0gsTUFBTSxnQ0FBZ0M7QUFBQSxRQUNoRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTStFLG1CQUFtQkEsTUFBTTtBQUM3QixVQUFNVCxnQkFBZ0JqSCxpQkFBaUJtRztBQUFBQSxNQUNyQyxDQUFDUSxTQUFTL0YsZUFBZStGLEtBQUsxRCxHQUFHLEdBQUcwQyxNQUFNeEIsVUFBVSxDQUFDd0MsS0FBS25DO0FBQUFBLElBQzVEO0FBRUEsUUFBSXlDLGNBQWM5RCxXQUFXLEdBQUc7QUFDOUJ4SCxjQUFRNkosUUFBUSxrQ0FBa0M7QUFDbEQ7QUFBQSxJQUNGO0FBRUEzSixVQUFNcUwsUUFBUTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQQyxTQUFTLG1DQUFtQ0gsY0FBYzlELE1BQU07QUFBQSxNQUNoRWtFLFFBQVE7QUFBQSxNQUNSTSxRQUFRO0FBQUEsTUFDUkwsWUFBWTtBQUFBLE1BQ1pDLE1BQU0sWUFBWTtBQUNoQixZQUFJO0FBQ0YsZ0JBQU1DLFFBQVFDO0FBQUFBLFlBQ1pSLGNBQWN2QyxJQUFJLENBQUNpQyxTQUFTakIsb0JBQW9CaUIsS0FBSzFELEdBQUcsQ0FBQztBQUFBLFVBQzNEO0FBQ0F0SCxrQkFBUW9MLFFBQVEsR0FBR0UsY0FBYzlELE1BQU0sZ0NBQWdDO0FBQUEsUUFDekUsU0FBU1IsT0FBTztBQUNkaEgsa0JBQVFnSCxNQUFNLGdDQUFnQztBQUFBLFFBQ2hEO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNaUYsZUFBZUEsQ0FBQ3pELFFBQVEwRCxhQUFhLFNBQVM7QUFDbEQsVUFBTUMsWUFDSjtBQUVGLFlBQVEzRCxRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0gsZUFBTyx1QkFBQyxVQUFLLFdBQVcsR0FBRzJELFNBQVMsOEJBQThCLHVCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsTUFFM0UsS0FBSztBQUNILGVBQ0UsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFXLEdBQUdBLFNBQVMsa0NBQWtDLDhCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzVFRCxlQUFlLFFBQ2QsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTQTtBQUFBQSxjQUNULE9BQU87QUFBQSxjQUNQLGFBQWFBLGVBQWUsTUFBTSxZQUFZQSxjQUFjLEtBQUssWUFBWTtBQUFBLGNBQzdFLFFBQVEsQ0FBQ0UsWUFBWSx1QkFBQyxVQUFLLFdBQVUscUJBQXFCQTtBQUFBQTtBQUFBQSxnQkFBUTtBQUFBLG1CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBO0FBQUEsWUFMckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSzZFLEtBTi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLE1BR0osS0FBSztBQUNILGVBQU8sdUJBQUMsVUFBSyxXQUFXLEdBQUdELFNBQVMsOEJBQThCLGdDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsTUFFcEYsS0FBSztBQUNILGVBQU8sdUJBQUMsVUFBSyxXQUFXLEdBQUdBLFNBQVMsZ0NBQWdDLHlCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsTUFFL0UsS0FBSztBQUNILGVBQU8sdUJBQUMsVUFBSyxXQUFXLEdBQUdBLFNBQVMsa0NBQWtDLDRCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsTUFFcEY7QUFDRSxlQUFPLHVCQUFDLFVBQUssV0FBVyxHQUFHQSxTQUFTLDhCQUErQjNELG9CQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsSUFDOUU7QUFBQSxFQUNGO0FBR0EsUUFBTTZELGdCQUFnQkEsQ0FBQ0MsVUFBVWQsVUFBVTtBQUN6Q3RJLG9CQUFnQm9KLFFBQVE7QUFDeEJsSixvQkFBZ0JvSSxLQUFLO0FBQUEsRUFDdkI7QUFFQSxRQUFNZSxzQkFBc0JBLE1BQU07QUFDaENySixvQkFBZ0IsSUFBSTtBQUNwQkUsb0JBQWdCLEVBQUU7QUFBQSxFQUNwQjtBQUVBLFFBQU1vSixlQUFlQSxDQUFDdkIsY0FBYztBQUNsQ3pILHVCQUFtQnlILFNBQVM7QUFDNUIzSCwwQkFBc0IsSUFBSTtBQUFBLEVBQzVCO0FBR0EsUUFBTW1KLHlCQUF5QkEsTUFBTTtBQUNuQ25KLDBCQUFzQixLQUFLO0FBQzNCRSx1QkFBbUIsSUFBSTtBQUFBLEVBQ3pCO0FBRUFwRSxZQUFVLE1BQU07QUFDZCxVQUFNc04sU0FBUyxJQUFJQyxnQkFBZ0IzSyxTQUFTNEssTUFBTTtBQUNsRCxRQUFJRixPQUFPN0YsSUFBSSxXQUFXLE1BQU0sUUFBUTtBQUN0QyxZQUFNc0QsU0FBU3VDLE9BQU83RixJQUFJLFFBQVE7QUFDbEMsVUFBSXNELFFBQVE7QUFDVkwsOEJBQXNCSyxNQUFNO0FBQUEsTUFDOUIsT0FBTztBQUNMMEMscUJBQWEsSUFBSTtBQUFBLE1BQ25CO0FBQ0FDLGFBQU9DLFFBQVFDLGFBQWEsQ0FBQyxHQUFHQyxTQUFTekIsT0FBTyxxQkFBcUI7QUFBQSxJQUN2RTtBQUFBLEVBQ0YsR0FBRyxDQUFDeEosUUFBUSxDQUFDO0FBR2IsUUFBTTJFLG1CQUFtQixZQUFZO0FBQ25DM0QsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTWlILFdBQVcsTUFBTXBLLElBQUlnSCxJQUFJLDZDQUE2QztBQUM1RSxZQUFNcUcsV0FBV2pELFNBQVNyRCxNQUFNQSxRQUFRO0FBR3hDLFlBQU11Ryx3QkFBd0JELFNBQzNCMUMsT0FBTyxDQUFDQyxZQUFZQSxRQUFRakMsV0FBVyxxQkFBcUIsRUFDNURPLElBQUksT0FBTzBCLFNBQVN6QixRQUFRO0FBQzNCLFlBQUlvRSxxQkFBcUI7QUFDekIsWUFBSUMsWUFBWTtBQUVoQixjQUFNbEQsU0FBU00sUUFBUXhCLFNBQVMzQixPQUFPbUQsUUFBUXhCO0FBQy9DLFlBQUlrQixRQUFRO0FBQ1YsY0FBSTtBQUNGLGtCQUFNbUQsY0FBYyxNQUFNek4sSUFBSWdILElBQUksNEJBQTRCc0QsTUFBTSxFQUFFO0FBQ3RFLGdCQUFJbUQsWUFBWTFHLFFBQVEwRyxZQUFZMUcsS0FBS0EsTUFBTTtBQUM3QyxrQkFBSTJHLFVBQVVELFlBQVkxRyxLQUFLQTtBQUMvQixrQkFBSXlELE1BQU1DLFFBQVFpRCxPQUFPLEtBQUtBLFFBQVEvRixTQUFTLEdBQUc7QUFDaEQrRiwwQkFBVUEsUUFBUSxDQUFDO0FBQUEsY0FDckI7QUFDQUYsMEJBQVlHLDhCQUE4QkQsT0FBTztBQUNqREgsbUNBQXFCSyw0QkFBNEJKLFNBQVM7QUFBQSxZQUM1RDtBQUFBLFVBQ0YsU0FBU3ZHLEtBQUs7QUFDWkMsb0JBQVFDLE1BQU0sa0NBQWtDRixHQUFHO0FBQUEsVUFDckQ7QUFBQSxRQUNGO0FBRUEsZUFBTztBQUFBLFVBQ0xuRixLQUFLOEksUUFBUW5EO0FBQUFBLFVBQ2JJLElBQUlzQixNQUFNO0FBQUEsVUFDVkosY0FBYzZCLFFBQVE3QixnQkFBZ0I7QUFBQSxVQUN0QzdELGNBQWMwRixRQUFRMUYsY0FBYzZGLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBS0gsUUFBUTFGO0FBQUFBLFVBQzdEbUQsTUFBTXVDLFFBQVF4QixTQUFTQyxhQUFhO0FBQUEsVUFDcENmLGNBQWNzQyxRQUFReEIsU0FBU2QsZ0JBQWdCO0FBQUEsVUFDL0NaLFlBQVlrRCxRQUFROUIsVUFBVXBCLGNBQWM7QUFBQSxVQUM1Q2lCLFFBQVF5RCxhQUFhLHVCQUF1Qm1CLGtCQUFrQjtBQUFBLFVBQzlETSxNQUFNakQsUUFBUWtELFdBQVcvQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxVQUMxQ2dELFlBQVluRCxRQUFRbkQ7QUFBQUEsVUFDcEJ1RyxjQUFjcEQ7QUFBQUEsVUFDZHdDLFVBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQU0sdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsY0FDaEMsU0FBUyxNQUFNYSxvQkFBb0JyRCxTQUFTNEMsU0FBUztBQUFBLGNBQ3JELFdBQVU7QUFBQSxjQUFlO0FBQUE7QUFBQSxZQUozQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBRUZ2RSxRQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNO0FBQUEsZ0JBQ0phLE9BQU87QUFBQSxrQkFDTDtBQUFBLG9CQUNFaEksS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFNBQVMsTUFBTTtBQUNia0wsaUNBQU9pQjtBQUFBQSw0QkFDTCxxQ0FBcUN0RCxRQUFReEIsU0FBUzNCLEdBQUcsY0FBY21ELFFBQVFuRCxHQUFHO0FBQUEsNEJBQ2xGO0FBQUEsMEJBQ0Y7QUFBQSx3QkFDRjtBQUFBLHdCQUNBLFdBQVU7QUFBQSx3QkFBYztBQUFBO0FBQUEsc0JBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFVQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRTNGLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNZ0ksb0JBQW9CYSxRQUFRbkQsS0FBSyx1QkFBdUI7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRTNGLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNZ0ksb0JBQW9CYSxRQUFRbkQsS0FBSyxXQUFXO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGtCQUNBO0FBQUEsb0JBQ0UzRixLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTTtBQUNiLGdDQUFNdUksVUFBU00sUUFBUXhCLFNBQVMzQixPQUFPbUQsUUFBUXhCO0FBQy9DLDhCQUFJa0IsU0FBUTtBQUNWMkMsbUNBQU9pQjtBQUFBQSw4QkFDTCw2Q0FBNkM1RCxPQUFNO0FBQUEsOEJBQ25EO0FBQUEsNEJBQ0Y7QUFBQSwwQkFDRixPQUFPO0FBQ0xuSyxvQ0FBUWdILE1BQU0sbUJBQW1CO0FBQUEsMEJBQ25DO0FBQUEsd0JBQ0Y7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWVBO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRUw7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUNWLFNBQVMsQ0FBQyxPQUFPO0FBQUEsY0FFakIsaUNBQUMsWUFBUyxXQUFVLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBO0FBQUEsWUFuRTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9FQTtBQUFBLFFBRUo7QUFBQSxNQUNGLENBQUM7QUFFSCxZQUFNZ0gsZ0JBQWdCLE1BQU1uQyxRQUFRQyxJQUFJcUIscUJBQXFCO0FBQzdEM0ksZ0NBQTBCd0osYUFBYTtBQUN2Q3RLLCtCQUF5QnNLLGFBQWE7QUFHdEMsWUFBTUMsMEJBQTBCZixTQUM3QjFDLE9BQU8sQ0FBQ0MsWUFBWUEsUUFBUWpDLFdBQVcsdUJBQXVCLEVBQzlETyxJQUFJLE9BQU8wQixTQUFTekIsUUFBUTtBQUMzQixZQUFJcUUsWUFBWTtBQUVoQixjQUFNbEQsU0FBU00sUUFBUXhCLFNBQVMzQixPQUFPbUQsUUFBUXhCO0FBQy9DLFlBQUlrQixRQUFRO0FBQ1YsY0FBSTtBQUNGLGtCQUFNbUQsY0FBYyxNQUFNek4sSUFBSWdILElBQUksNEJBQTRCc0QsTUFBTSxFQUFFO0FBQ3RFLGdCQUFJbUQsWUFBWTFHLFFBQVEwRyxZQUFZMUcsS0FBS0EsTUFBTTtBQUM3QyxrQkFBSTJHLFVBQVVELFlBQVkxRyxLQUFLQTtBQUMvQixrQkFBSXlELE1BQU1DLFFBQVFpRCxPQUFPLEtBQUtBLFFBQVEvRixTQUFTLEdBQUc7QUFDaEQrRiwwQkFBVUEsUUFBUSxDQUFDO0FBQUEsY0FDckI7QUFDQUYsMEJBQVlHLDhCQUE4QkQsT0FBTztBQUFBLFlBQ25EO0FBQUEsVUFDRixTQUFTekcsS0FBSztBQUNaQyxvQkFBUUMsTUFBTSxrQ0FBa0NGLEdBQUc7QUFBQSxVQUNyRDtBQUFBLFFBQ0Y7QUFFQSxlQUFPO0FBQUEsVUFDTG5GLEtBQUs4SSxRQUFRbkQ7QUFBQUEsVUFDYkksSUFBSXNCLE1BQU07QUFBQSxVQUNWSixjQUFjNkIsUUFBUTdCLGdCQUFnQjtBQUFBLFVBQ3RDN0QsY0FBYzBGLFFBQVExRixjQUFjNkYsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLSCxRQUFRMUY7QUFBQUEsVUFDN0RtRCxNQUFNdUMsUUFBUXhCLFNBQVNDLGFBQWE7QUFBQSxVQUNwQ2YsY0FBY3NDLFFBQVF4QixTQUFTZCxnQkFBZ0I7QUFBQSxVQUMvQ1osWUFBWWtELFFBQVE5QixVQUFVcEIsY0FBYztBQUFBLFVBQzVDaUIsUUFBUXlELGFBQWEsdUJBQXVCO0FBQUEsVUFDNUN5QixNQUFNakQsUUFBUWtELFdBQVcvQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxVQUMxQ2dELFlBQVluRCxRQUFRbkQ7QUFBQUEsVUFDcEJ1RyxjQUFjcEQ7QUFBQUEsVUFDZHdDLFVBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFNLHVCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQjtBQUFBLGdCQUNoQyxTQUFTLE1BQU1hLG9CQUFvQnJELFNBQVM0QyxTQUFTO0FBQUEsZ0JBQ3JELFdBQVU7QUFBQSxnQkFBZTtBQUFBO0FBQUEsY0FKM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQU0sdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUEsZ0JBQ3JDLFNBQVMsTUFBTTtBQUNiLHdCQUFNbEQsVUFBU00sUUFBUXhCLFNBQVMzQixPQUFPbUQsUUFBUXhCO0FBQy9DLHNCQUFJa0IsU0FBUTtBQUNWRCxxQ0FBaUJDLE9BQU07QUFBQSxrQkFDekIsT0FBTztBQUNMbkssNEJBQVFnSCxNQUFNLG1CQUFtQjtBQUFBLGtCQUNuQztBQUFBLGdCQUNGO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUFnQjtBQUFBO0FBQUEsY0FYNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLFVBRUY4QixRQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNO0FBQUEsZ0JBQ0phLE9BQU87QUFBQSxrQkFDTDtBQUFBLG9CQUNFaEksS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1nSSxvQkFBb0JhLFFBQVFuRCxLQUFLLFdBQVc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsZ0JBQUM7QUFBQSxjQUVMO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FDVixTQUFTLENBQUMsT0FBTztBQUFBLGNBRWpCLGlDQUFDLFlBQVMsV0FBVSw0QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQTtBQUFBLFlBbkI5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQkE7QUFBQSxRQUVKO0FBQUEsTUFDRixDQUFDO0FBRUgsWUFBTTRHLGtCQUFrQixNQUFNckMsUUFBUUMsSUFBSW1DLHVCQUF1QjtBQUNqRXZKLGtDQUE0QndKLGVBQWU7QUFDM0N0SyxpQ0FBMkJzSyxlQUFlO0FBRzFDLFlBQU1DLFlBQVlqQixTQUNmMUMsT0FBTyxDQUFDQyxZQUFZQSxRQUFRakMsV0FBVyxXQUFXLEVBQ2xETyxJQUFJLENBQUMwQixTQUFTekIsU0FBUztBQUFBLFFBQ3RCckgsS0FBSzhJLFFBQVFuRDtBQUFBQSxRQUNiSSxJQUFJc0IsTUFBTTtBQUFBLFFBQ1ZKLGNBQWM2QixRQUFRN0IsZ0JBQWdCO0FBQUEsUUFDdEM3RCxjQUFjMEYsUUFBUTFGLGNBQWM2RixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUtILFFBQVExRjtBQUFBQSxRQUM3RG1ELE1BQU11QyxRQUFReEIsU0FBU0MsYUFBYTtBQUFBLFFBQ3BDZixjQUFjc0MsUUFBUXhCLFNBQVNkLGdCQUFnQjtBQUFBLFFBQy9DWixZQUFZa0QsUUFBUTlCLFVBQVVwQixjQUFjO0FBQUEsUUFDNUNpQixRQUFReUQsYUFBYSxXQUFXO0FBQUEsUUFDaEN5QixNQUFNakQsUUFBUWtELFdBQVcvQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxRQUMxQzlCLFFBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU07QUFBQSxjQUNKYSxPQUFPO0FBQUEsZ0JBQ0w7QUFBQSxrQkFDRWhJLEtBQUs7QUFBQSxrQkFDTEMsT0FDRSx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLFNBQVMsTUFBTTRLLGFBQWEvQixRQUFRbkQsR0FBRyxHQUFHLG1EQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBRUo7QUFBQSxjQUFDO0FBQUEsWUFFTDtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQ1YsU0FBUyxDQUFDLE9BQU87QUFBQSxZQUVqQixpQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUE7QUFBQSxVQWhCOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBaUJBO0FBQUEsTUFFSixFQUFFO0FBRUoxQyx1QkFBaUJ1SixTQUFTO0FBQzFCckssMkJBQXFCcUssU0FBUztBQUFBLElBQ2hDLFNBQVNuSCxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EaEgsY0FBUWdILE1BQU0sOEJBQThCO0FBQUEsSUFDOUMsVUFBQztBQUNDaEUsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1vTCxtQkFBbUJBLENBQUNDLFVBQVU7QUFDbEMsUUFBSSxDQUFDQSxTQUFTLENBQUNBLE1BQU0sQ0FBQyxLQUFLLENBQUNBLE1BQU0sQ0FBQyxHQUFHO0FBQ3BDakssbUJBQWEsQ0FBQyxNQUFNLElBQUksQ0FBQztBQUN6QixVQUFJNkIsaUJBQWlCO0FBRW5CM0IsNEJBQW9CK0IscUJBQXFCO0FBQUEsTUFDM0MsT0FBTztBQUNML0IsNEJBQW9CakMsaUJBQWlCO0FBQUEsTUFDdkM7QUFDQXFCLCtCQUF5QmEsc0JBQXNCO0FBQy9DWCxpQ0FBMkJhLHdCQUF3QjtBQUNuRFgsMkJBQXFCYSxhQUFhO0FBQ2xDO0FBQUEsSUFDRjtBQUVBUCxpQkFBYWlLLEtBQUs7QUFDbEIsVUFBTSxDQUFDQyxPQUFPQyxHQUFHLElBQUlGO0FBRXJCLFFBQUlHLGVBQWV2SSxrQkFBa0JJLHdCQUF3QmhFO0FBQzdELFVBQU1vTSxpQkFBaUJDLGlCQUFpQkYsY0FBY0gsS0FBSztBQUMzRCxVQUFNTSxxQkFBcUJELGlCQUFpQm5LLHdCQUF3QjhKLEtBQUs7QUFDekUsVUFBTU8sdUJBQXVCRixpQkFBaUJqSywwQkFBMEI0SixLQUFLO0FBQzdFLFVBQU1RLHdCQUF3QkgsaUJBQWlCL0osZUFBZTBKLEtBQUs7QUFFbkUvSix3QkFBb0JtSyxjQUFjO0FBQ2xDL0ssNkJBQXlCaUwsa0JBQWtCO0FBQzNDL0ssK0JBQTJCZ0wsb0JBQW9CO0FBQy9DOUsseUJBQXFCK0sscUJBQXFCO0FBQUEsRUFDNUM7QUFFQSxRQUFNSCxtQkFBbUJBLENBQUM5SCxNQUFNeUgsVUFBVTtBQUN4QyxRQUFJLENBQUNBLFNBQVMsQ0FBQ0EsTUFBTSxDQUFDLEtBQUssQ0FBQ0EsTUFBTSxDQUFDLEVBQUcsUUFBT3pIO0FBRTdDLFVBQU0sQ0FBQzBILE9BQU9DLEdBQUcsSUFBSUY7QUFFckIsV0FBT3pILEtBQUs0RCxPQUFPLENBQUNRLFNBQVM7QUFDM0IsVUFBSThELFdBQVc5RCxLQUFLakcsZ0JBQWdCaUcsS0FBSzBDO0FBQ3pDLFVBQUksQ0FBQ29CLFNBQVUsUUFBTztBQUV0QixVQUFJLE9BQU9BLGFBQWEsWUFBWUEsU0FBU0MsU0FBUyxHQUFHLEdBQUc7QUFDMURELG1CQUFXQSxTQUFTbEUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xDO0FBRUEsWUFBTW9FLGNBQWMzTixNQUFNeU4sUUFBUTtBQUNsQyxhQUFPRSxZQUFZQyxRQUFRWCxNQUFNWSxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUtGLFlBQVlHLFNBQVNaLElBQUlhLElBQUksR0FBRyxLQUFLLENBQUM7QUFBQSxJQUNoRyxDQUFDO0FBQUEsRUFDSDtBQUdBLFFBQU10QixzQkFBc0IsT0FBT3VCLGFBQWFDLG9CQUFvQixTQUFTO0FBQzNFLFFBQUk7QUFDRixVQUFJakMsWUFBWWlDO0FBRWhCLFVBQUksQ0FBQ2pDLFdBQVc7QUFDZCxjQUFNbEQsU0FBU2tGLGFBQWFwRyxTQUFTM0IsT0FBTytILGFBQWFwRztBQUV6RCxZQUFJLENBQUNrQixRQUFRO0FBQ1hwRCxrQkFBUUMsTUFBTSxtQ0FBbUM7QUFDakRoSCxrQkFBUWdILE1BQU0sZ0NBQWdDO0FBQzlDO0FBQUEsUUFDRjtBQUVBLGNBQU1pRCxXQUFXLE1BQU1wSyxJQUFJZ0gsSUFBSSw0QkFBNEJzRCxNQUFNLEVBQUU7QUFFbkUsWUFBSUYsU0FBU3JELFFBQVFxRCxTQUFTckQsS0FBS0EsTUFBTTtBQUN2QyxjQUFJMkcsVUFBVXRELFNBQVNyRCxLQUFLQTtBQUM1QixjQUFJeUQsTUFBTUMsUUFBUWlELE9BQU8sS0FBS0EsUUFBUS9GLFNBQVMsR0FBRztBQUNoRCtGLHNCQUFVQSxRQUFRLENBQUM7QUFBQSxVQUNyQjtBQUNBRixzQkFBWUcsOEJBQThCRCxPQUFPO0FBQUEsUUFDbkQsT0FBTztBQUNMRixzQkFBWTtBQUFBLFFBQ2Q7QUFBQSxNQUNGO0FBRUEzSCwwQkFBb0IySCxTQUFTO0FBQzdCekgsK0JBQXlCeUosV0FBVztBQUNwQzdKLDJCQUFxQixJQUFJO0FBQUEsSUFDM0IsU0FBU3dCLE9BQU87QUFDZEQsY0FBUUMsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaERoSCxjQUFRZ0gsTUFBTSwyQkFBMkI7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFFQSxRQUFNd0csZ0NBQWdDQSxDQUFDRCxZQUFZO0FBQ2pELFFBQUksQ0FBQ0EsUUFBUyxRQUFPO0FBRXJCLFVBQU1GLFlBQVk7QUFFbEIsVUFBTWtDLGNBQWM7QUFBQSxNQUNsQixFQUFFNU4sS0FBSyxzQkFBc0JDLE9BQU8sU0FBUzROLFNBQVMsS0FBSztBQUFBLE1BQzNELEVBQUU3TixLQUFLLDhCQUE4QkMsT0FBTyx1QkFBdUI0TixTQUFTLEtBQUs7QUFBQSxNQUNqRixFQUFFN04sS0FBSyw2QkFBNkJDLE9BQU8sc0JBQXNCNE4sU0FBUyxLQUFLO0FBQUEsTUFDL0UsRUFBRTdOLEtBQUssc0JBQXNCQyxPQUFPLFlBQVk0TixTQUFTLEtBQUs7QUFBQSxNQUM5RCxFQUFFN04sS0FBSyxvQkFBb0JDLE9BQU8sZUFBZTROLFNBQVMsS0FBSztBQUFBLE1BQy9ELEVBQUU3TixLQUFLLHdCQUF3QkMsT0FBTyxrQkFBa0I0TixTQUFTLE1BQU07QUFBQSxNQUN2RSxFQUFFN04sS0FBSyx1QkFBdUJDLE9BQU8sa0JBQWtCNE4sU0FBUyxLQUFLO0FBQUEsTUFDckUsRUFBRTdOLEtBQUssMkJBQTJCQyxPQUFPLGtCQUFrQjROLFNBQVMsTUFBTTtBQUFBLE1BQzFFLEVBQUU3TixLQUFLLG9CQUFvQkMsT0FBTyxlQUFlNE4sU0FBUyxNQUFNO0FBQUEsTUFDaEUsRUFBRTdOLEtBQUssc0NBQXNDQyxPQUFPLDBCQUEwQjROLFNBQVMsS0FBSztBQUFBLE1BQzVGLEVBQUU3TixLQUFLLHFDQUFxQ0MsT0FBTyx5QkFBeUI0TixTQUFTLEtBQUs7QUFBQSxNQUMxRixFQUFFN04sS0FBSyw4QkFBOEJDLE9BQU8sb0JBQW9CNE4sU0FBUyxLQUFLO0FBQUEsSUFBQztBQUdqRkQsZ0JBQVl4RSxRQUFRLENBQUMwRSxZQUFZO0FBQy9CLFVBQUlsQyxRQUFRa0MsUUFBUTlOLEdBQUcsR0FBRztBQUN4QjBMLGtCQUFVcUMsS0FBSztBQUFBLFVBQ2JDLGVBQWVGLFFBQVE3TjtBQUFBQSxVQUN2QmdPLFVBQVVyQyxRQUFRa0MsUUFBUTlOLEdBQUc7QUFBQSxVQUM3QmtPLGFBQWEsR0FBR0osUUFBUTdOLEtBQUs7QUFBQSxVQUM3QjROLFNBQVNDLFFBQVFEO0FBQUFBLFFBQ25CLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBRUQsUUFBSWpDLFFBQVF1QyxvQkFBb0I7QUFDOUJ6QyxnQkFBVXFDLEtBQUs7QUFBQSxRQUNiQyxlQUFlO0FBQUEsUUFDZkMsVUFBVTtBQUFBLFFBQ1ZDLGFBQWEsa0JBQWtCdEMsUUFBUXVDLGtCQUFrQjtBQUFBLFFBQ3pETixTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU9uQztBQUFBQSxFQUNUO0FBRUEsUUFBTUksOEJBQThCQSxDQUFDSixjQUFjO0FBQ2pELFFBQUksQ0FBQ0EsYUFBYUEsVUFBVTdGLFdBQVcsRUFBRyxRQUFPO0FBRWpELFVBQU11SSxlQUFlMUMsVUFBVTdDO0FBQUFBLE1BQzdCLENBQUN3RixRQUFRQSxJQUFJSixZQUFZSSxJQUFJTCxrQkFBa0I7QUFBQSxJQUNqRDtBQUNBLFVBQU1NLG9CQUFvQnZPLG1CQUFtQjhGO0FBQzdDLFVBQU0wRSxhQUFjNkQsYUFBYXZJLFNBQVN5SSxvQkFBcUI7QUFDL0QsV0FBT0MsS0FBS0MsTUFBTWpFLFVBQVU7QUFBQSxFQUM5QjtBQUdBLFFBQU1rRSx1QkFBdUIsT0FBT3RILFdBQVc7QUFDN0MsUUFBSSxDQUFDbkQsc0JBQXVCO0FBRTVCLFFBQUk7QUFDRixVQUFJdUYsWUFBWTtBQUNoQixjQUFRcEMsUUFBTTtBQUFBLFFBQ1osS0FBSztBQUNIb0Msc0JBQVk7QUFDWjtBQUFBLFFBQ0YsS0FBSztBQUNIQSxzQkFBWTtBQUNaO0FBQUEsUUFDRixLQUFLO0FBQ0hBLHNCQUFZO0FBQ1psTCxrQkFBUWdLLEtBQUssNEJBQTRCO0FBQ3pDO0FBQUEsUUFDRjtBQUNFO0FBQUEsTUFDSjtBQUVBLFVBQUlrQixXQUFXO0FBQ2IsY0FBTXRCLG9CQUFvQmpFLHNCQUFzQjJCLEtBQUs0RCxTQUFTO0FBQUEsTUFDaEU7QUFFQTFGLDJCQUFxQixLQUFLO0FBQzFCRSwwQkFBb0IsRUFBRTtBQUN0QkUsK0JBQXlCLElBQUk7QUFDN0JlLHVCQUFpQjtBQUFBLElBQ25CLFNBQVNLLE9BQU87QUFDZEQsY0FBUUMsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERoSCxjQUFRZ0gsTUFBTSxrQ0FBa0M7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUosb0JBQW9CQSxDQUFDQyxNQUFNO0FBQy9CLFVBQU0sRUFBRXBJLE1BQU1xSSxNQUFNLElBQUlELEVBQUVFO0FBQzFCMUwsc0JBQWtCLENBQUMyTCxjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDdkksSUFBSSxHQUFHcUk7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1HLHNCQUFzQkEsTUFBTTtBQUNoQzNPLGFBQVMscURBQXFEO0FBQzlEL0IsWUFBUW9MLFFBQVEsMENBQTBDO0FBQzFENUgsdUJBQW1CLElBQUk7QUFBQSxFQUN6QjtBQUdBLFFBQU11RyxzQkFBc0IsT0FBT2tCLGNBQWM7QUFDL0MsUUFBSTtBQUNGLFlBQU1wTCxJQUFJOFEsT0FBTywyQkFBMkIxRixTQUFTLEVBQUU7QUFDdkRqTCxjQUFRb0wsUUFBUSw4QkFBOEI7QUFFOUMsVUFBSW5GLGlCQUFpQjtBQUVuQixjQUFNZ0Isa0JBQWtCaEIsZUFBZTtBQUFBLE1BQ3pDLE9BQU87QUFFTFMsNEJBQW9CO0FBQUEsTUFDdEI7QUFDQUMsdUJBQWlCO0FBQUEsSUFDbkIsU0FBU0ssT0FBTztBQUNkaEgsY0FBUWdILE1BQU0sMEJBQTBCO0FBQUEsSUFDMUM7QUFBQSxFQUNGO0FBRUEsUUFBTThDLHdCQUF3QixPQUFPbUIsY0FBYztBQUNqRCxRQUFJO0FBQ0YsWUFBTWhCLFdBQVcsTUFBTXBLLElBQUlnSCxJQUFJLDhCQUE4Qm9FLFNBQVMsRUFBRTtBQUN4RW5HLHdCQUFrQjtBQUFBLFFBQ2hCQyxjQUFja0YsU0FBU3JELE1BQU03QjtBQUFBQSxRQUM3QkMsV0FBV2lGLFNBQVNyRCxNQUFNNUI7QUFBQUEsTUFDNUIsQ0FBQztBQUNEcEMsNEJBQXNCcUgsU0FBU3JELElBQUk7QUFDbkNsRSx5QkFBbUIsSUFBSTtBQUN2QjRDLDBCQUFvQixJQUFJO0FBQUEsSUFDMUIsU0FBUzBCLE9BQU87QUFDZEQsY0FBUUMsTUFBTSwyQkFBMkJBLEtBQUs7QUFBQSxJQUNoRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEosZUFBZSxPQUFPTixNQUFNO0FBQ2hDQSxNQUFFTyxlQUFlO0FBQ2pCLFFBQUk7QUFDRixZQUFNaFIsSUFBSXNMLElBQUksWUFBWXhJLG9CQUFvQjJFLEdBQUcsSUFBSXpDLGNBQWM7QUFDbkVuQyx5QkFBbUIsS0FBSztBQUN4QjFDLGNBQVFvTCxRQUFRLG1DQUFtQztBQUVuRCxVQUFJbkYsaUJBQWlCO0FBRW5CLGNBQU1nQixrQkFBa0JoQixlQUFlO0FBQUEsTUFDekMsT0FBTztBQUVMUyw0QkFBb0I7QUFBQSxNQUN0QjtBQUFBLElBQ0YsU0FBU00sT0FBTztBQUNkaEgsY0FBUWdILE1BQU1BLE1BQU1pRCxVQUFVckQsTUFBTTVHLFdBQVcsOEJBQThCO0FBQUEsSUFDL0U7QUFBQSxFQUNGO0FBRUEsUUFBTThRLDhCQUE4QkEsQ0FBQ1IsTUFBTTtBQUN6QzlOLGtCQUFjOE4sRUFBRUUsT0FBT0QsS0FBSztBQUFBLEVBQzlCO0FBR0EsUUFBTVEsaUJBQWlCQSxNQUFNO0FBQzNCLFdBQU8xTSxpQkFBaUJtRyxPQUFPLENBQUFRLFNBQVEsQ0FBQ0EsS0FBS25DLGNBQWM7QUFBQSxFQUM3RDtBQUVBLFFBQU1tSSxjQUFjRCxlQUFlO0FBQ25DLFFBQU1FLGtCQUFrQkQsWUFBWUU7QUFBQUEsSUFDbEMsQ0FBQ0MsS0FBS25HLFNBQVNtRyxPQUFPQyxXQUFXcEcsS0FBS3RDLFdBQVcsS0FBSztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUNBLFFBQU0ySSxpQkFBaUJMLFlBQVlFO0FBQUFBLElBQ2pDLENBQUNDLEtBQUtuRyxTQUFTbUcsT0FBT0MsV0FBV3BHLEtBQUszQyxVQUFVLEtBQUs7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNaUosaUJBQWlCTixZQUFZRTtBQUFBQSxJQUNqQyxDQUFDQyxLQUFLbkcsU0FBU21HLE9BQU9DLFdBQVdwRyxLQUFLMUMsTUFBTSxLQUFLO0FBQUEsSUFDakQ7QUFBQSxFQUNGO0FBR0EsUUFBTWlKLGdCQUFnQmpTLFFBQVEsTUFBTTtBQUNsQyxXQUFPMFIsWUFBWXhHLE9BQU8sQ0FBQ1EsU0FBUy9GLGVBQWUrRixLQUFLMUQsR0FBRyxHQUFHMEMsTUFBTXhCLE1BQU0sRUFBRWhCO0FBQUFBLEVBQzlFLEdBQUcsQ0FBQ3dKLGFBQWEvTCxjQUFjLENBQUM7QUFHaEM3RixZQUFVLE1BQU07QUFDZCxVQUFNb1MsYUFDSlIsWUFBWXhKLFNBQVMsS0FDckJ3SixZQUFZUyxNQUFNLENBQUN6RyxTQUFTL0YsZUFBZStGLEtBQUsxRCxHQUFHLEdBQUcwQyxNQUFNeEIsTUFBTTtBQUNwRXBELGlCQUFhb00sVUFBVTtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ1IsYUFBYS9MLGNBQWMsQ0FBQztBQUdoQyxRQUFNeU0sdUJBQXVCQSxDQUFDMUcsU0FBUztBQUNyQyxRQUFJQSxLQUFLbkMsZUFBZ0I7QUFDekIzRCxzQkFBa0IsQ0FBQ3lNLFVBQVU7QUFBQSxNQUMzQixHQUFHQTtBQUFBQSxNQUNILENBQUMzRyxLQUFLMUQsR0FBRyxHQUFHO0FBQUEsUUFDVjBDLE1BQU07QUFBQSxVQUNKeEIsUUFBUSxDQUFDbUosS0FBSzNHLEtBQUsxRCxHQUFHLEdBQUcwQyxNQUFNeEI7QUFBQUEsVUFDL0JJLGNBQWNvQyxLQUFLcEM7QUFBQUEsVUFDbkJWLE1BQU04QyxLQUFLOUM7QUFBQUEsUUFDYjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTTBKLHdCQUF3QkEsQ0FBQ3RCLE1BQU07QUFDbkMsVUFBTXVCLFVBQVV2QixFQUFFRSxPQUFPcUI7QUFDekJ6TSxpQkFBYXlNLE9BQU87QUFDcEIsVUFBTUMsVUFBVSxFQUFFLEdBQUc3TSxlQUFlO0FBQ3BDK0wsZ0JBQVlqRyxRQUFRLENBQUNDLFNBQVM7QUFDNUIsVUFBSSxDQUFDQSxLQUFLbkMsZ0JBQWdCO0FBQ3hCaUosZ0JBQVE5RyxLQUFLMUQsR0FBRyxJQUFJO0FBQUEsVUFDbEIwQyxNQUFNO0FBQUEsWUFDSnhCLFFBQVFxSjtBQUFBQSxZQUNSakosY0FBY29DLEtBQUtwQztBQUFBQSxZQUNuQlYsTUFBTThDLEtBQUs5QztBQUFBQSxVQUNiO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFDRGhELHNCQUFrQjRNLE9BQU87QUFBQSxFQUMzQjtBQUdBLFFBQU1DLHVCQUF1QnpTLFFBQVEsTUFBTTtBQUN6QyxVQUFNMFMsWUFBWTNOLGlCQUFpQjBFLElBQUksQ0FBQ2lDLFNBQVM7QUFDL0MsWUFBTWlILGlCQUFpQmpILEtBQUt2QyxtQkFBbUI7QUFHL0MsWUFBTXlKLFdBQVdsSCxLQUFLbkMsaUJBQ3BCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUMsSUFFakM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVM1RCxlQUFlK0YsS0FBSzFELEdBQUcsR0FBRzBDLE1BQU14QixVQUFVO0FBQUEsVUFDbkQsVUFBVSxNQUFNa0oscUJBQXFCMUcsSUFBSTtBQUFBLFVBQ3pDLFdBQVU7QUFBQTtBQUFBLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSW9EO0FBSXRELGFBQU87QUFBQSxRQUNMLEdBQUdBO0FBQUFBLFFBQ0hrSDtBQUFBQSxRQUNBekosaUJBQWlCd0QsYUFBYWdHLGNBQWM7QUFBQSxRQUM1Q25KLFFBQVFrQyxLQUFLbkMsaUJBQWlCLE9BQU9tQyxLQUFLbEM7QUFBQUEsTUFDNUM7QUFBQSxJQUNGLENBQUM7QUFFRCxXQUFPa0o7QUFBQUEsRUFDVCxHQUFHLENBQUMzTixrQkFBa0JZLGNBQWMsQ0FBQztBQUVyQyxRQUFNa04sZ0JBQWdCO0FBQUEsSUFDcEIsRUFBRXhRLEtBQUssWUFBWXlRLFFBQVEsU0FBUztBQUFBLElBQ3BDLEVBQUV6USxLQUFLLE1BQU15USxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFelEsS0FBSyxnQkFBZ0J5USxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFelEsS0FBSyxnQkFBZ0J5USxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFelEsS0FBSyxjQUFjeVEsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRXpRLEtBQUssZUFBZXlRLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUV6USxLQUFLLFFBQVF5USxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUV6USxLQUFLLGdCQUFnQnlRLFFBQVEsd0JBQXdCO0FBQUEsSUFDdkQsRUFBRXpRLEtBQUssVUFBVXlRLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUV6USxLQUFLLGNBQWN5USxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFelEsS0FBSyxVQUFVeVEsUUFBUSxhQUFhO0FBQUEsSUFDdEMsRUFBRXpRLEtBQUssZ0JBQWdCeVEsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXpRLEtBQUssbUJBQW1CeVEsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFelEsS0FBSyxVQUFVeVEsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyx1QkFBdUI7QUFBQSxJQUMzQixFQUFFMVEsS0FBSyxNQUFNeVEsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRXpRLEtBQUssZ0JBQWdCeVEsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXpRLEtBQUssZ0JBQWdCeVEsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXpRLEtBQUssUUFBUXlRLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRXpRLEtBQUssZ0JBQWdCeVEsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRXpRLEtBQUssY0FBY3lRLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUV6USxLQUFLLFVBQVV5USxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFelEsS0FBSyxRQUFReVEsUUFBUSxlQUFlO0FBQUEsSUFDdEMsRUFBRXpRLEtBQUssWUFBWXlRLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUV6USxLQUFLLFVBQVV5USxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1FLHlCQUF5QjtBQUFBLElBQzdCLEVBQUUzUSxLQUFLLE1BQU15USxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFelEsS0FBSyxnQkFBZ0J5USxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFelEsS0FBSyxRQUFReVEsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFelEsS0FBSyxnQkFBZ0J5USxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFelEsS0FBSyxjQUFjeVEsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRXpRLEtBQUssVUFBVXlRLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUV6USxLQUFLLFFBQVF5USxRQUFRLGVBQWU7QUFBQSxJQUN0QyxFQUFFelEsS0FBSyxZQUFZeVEsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRXpRLEtBQUssVUFBVXlRLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUcsbUJBQW1CO0FBQUEsSUFDdkIsRUFBRTVRLEtBQUssTUFBTXlRLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUV6USxLQUFLLGdCQUFnQnlRLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUV6USxLQUFLLFFBQVF5USxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUV6USxLQUFLLGdCQUFnQnlRLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUV6USxLQUFLLGNBQWN5USxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFelEsS0FBSyxVQUFVeVEsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRXpRLEtBQUssUUFBUXlRLFFBQVEsaUJBQWlCO0FBQUEsSUFDeEMsRUFBRXpRLEtBQUssVUFBVXlRLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUksT0FBTztBQUFBLElBQ1g7QUFBQSxNQUNFOUssSUFBSTtBQUFBLE1BQ0o5RixPQUFPO0FBQUEsTUFDUDZRLE9BQU9wTyxpQkFBaUJtRyxPQUFPLENBQUFRLFNBQVEsQ0FBQ0EsS0FBS25DLGNBQWMsRUFBRXJCO0FBQUFBLE1BQzdEa0wsTUFBTSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLE1BQ0VoTCxJQUFJO0FBQUEsTUFDSjlGLE9BQU87QUFBQSxNQUNQNlEsT0FBT2hQLHNCQUFzQitEO0FBQUFBLE1BQzdCa0wsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxJQUN2QjtBQUFBLElBQ0E7QUFBQSxNQUNFaEwsSUFBSTtBQUFBLE1BQ0o5RixPQUFPO0FBQUEsTUFDUDZRLE9BQU85Tyx3QkFBd0I2RDtBQUFBQSxNQUMvQmtMLE1BQU0sdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQjtBQUFBLElBQzFCO0FBQUEsSUFDQTtBQUFBLE1BQ0VoTCxJQUFJO0FBQUEsTUFDSjlGLE9BQU87QUFBQSxNQUNQNlEsT0FBTzVPLGtCQUFrQjJEO0FBQUFBLE1BQ3pCa0wsTUFBTSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLElBQ2Y7QUFBQSxFQUFDO0FBR0gsUUFBTUMsbUJBQW1CQSxNQUFNO0FBQzdCLFFBQUk1UCxXQUFXO0FBQ2IsYUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLElBRUo7QUFFQSxZQUFRRixXQUFTO0FBQUEsTUFDZixLQUFLO0FBQ0gsZUFDRSxtQ0FDRzBPO0FBQUFBLDBCQUFnQixLQUNmLHVCQUFDLFNBQUksV0FBVSxnR0FDYixpQ0FBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsOEdBQ1pBLDJCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0MsZ0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsaUJBSnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNbEcsdUJBQXVCLHFCQUFxQjtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFIL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU07QUFDYiwwQkFBTXVILFdBQVc1QixZQUFZeEc7QUFBQUEsc0JBQzNCLENBQUNRLFNBQVMvRixlQUFlK0YsS0FBSzFELEdBQUcsR0FBRzBDLE1BQU14QixVQUFVLENBQUN3QyxLQUFLbkM7QUFBQUEsb0JBQzVEO0FBQ0Esd0JBQUkrSixTQUFTcEwsV0FBVyxHQUFHO0FBQ3pCc0MsNENBQXNCOEksU0FBUyxDQUFDLEVBQUV0TCxHQUFHO0FBQUEsb0JBQ3ZDLFdBQVdzTCxTQUFTcEwsU0FBUyxHQUFHO0FBQzlCeEgsOEJBQVE2SixRQUFRLHdDQUF3QztBQUFBLG9CQUMxRCxPQUFPO0FBQ0w3Siw4QkFBUTZKLFFBQVEsa0NBQWtDO0FBQUEsb0JBQ3BEO0FBQUEsa0JBQ0Y7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZ0JBO0FBQUEsY0FDQSx1QkFBQyxVQUFPLFFBQU0sTUFBQyxTQUFTa0Msa0JBQWtCLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsZUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQ0EsS0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQ0E7QUFBQSxVQUdEaUYsWUFBWXhKLFNBQVMsS0FDcEIsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFNBQVNyQztBQUFBQSxnQkFDVCxVQUFVeU07QUFBQUE7QUFBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJa0M7QUFBQSxZQUVsQyx1QkFBQyxVQUFLLFdBQVUseUJBQ2J6TTtBQUFBQSwwQkFBWSxpQkFBaUI7QUFBQSxjQUFhO0FBQUEsY0FBRzZMLFlBQVl4SjtBQUFBQSxjQUFPO0FBQUEsaUJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUdEdkYsaUJBQWlCc0UsaUJBQ2hCLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFDRWxDLGtCQUFrQm1ELFNBQVMsSUFDN0I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU12RyxhQUFhOFEsc0JBQXNCeFAsVUFBVTtBQUFBLGNBQ25ELFNBQVM0UDtBQUFBQSxjQUNULGtCQUFrQmxNLGtCQUFrQixTQUFTRSxpQkFBaUIsa0JBQWtCO0FBQUE7QUFBQSxZQUhsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHd0csSUFHeEcsdUJBQUMsU0FBSSxXQUFVLG1DQUNaRiw0QkFBa0Isc0NBQXNDLG1DQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF0RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdFQTtBQUFBLE1BR0osS0FBSztBQUNILGVBQU94Qyx1QkFBdUIrRCxTQUFTLElBQ3JDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNdkcsYUFBYXdDLHVCQUF1QmxCLFVBQVU7QUFBQSxZQUNwRCxTQUFTOFA7QUFBQUEsWUFDVCxrQkFBaUI7QUFBQTtBQUFBLFVBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc0QyxJQUc1Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLGtEQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsTUFHdkYsS0FBSztBQUNILGVBQU8xTyx5QkFBeUI2RCxTQUFTLElBQ3ZDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNdkcsYUFBYTBDLHlCQUF5QnBCLFVBQVU7QUFBQSxZQUN0RCxTQUFTK1A7QUFBQUEsWUFDVCxrQkFBaUI7QUFBQTtBQUFBLFVBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc4QyxJQUc5Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLG9EQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsTUFHekYsS0FBSztBQUNILGVBQU96TyxtQkFBbUIyRCxTQUFTLElBQ2pDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNdkcsYUFBYTRDLG1CQUFtQnRCLFVBQVU7QUFBQSxZQUNoRCxTQUFTZ1E7QUFBQUEsWUFDVCxrQkFBaUI7QUFBQTtBQUFBLFVBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdrQyxJQUdsQyx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLHFDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsTUFHMUU7QUFDRSxlQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXRQLGlCQUFpQjtBQUFBLFFBQ3ZCLE9BQU9FO0FBQUFBLFFBQ1AsUUFBUTtBQUFBLFFBQ1IsVUFBVW9KO0FBQUFBLFFBQ1YsT0FBTTtBQUFBLFFBQ04sT0FBTyxFQUFFc0csVUFBVSxPQUFPO0FBQUEsUUFFMUIsaUNBQUMsU0FBSSxLQUFLMVAsY0FBYyxPQUFPLEVBQUUyUCxPQUFPLE9BQU8sR0FBRyxLQUFLN1AsZ0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQTtBQUFBLE1BUnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV2M7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNEJBQWtCLEtBQUs7QUFDdkJFLHlCQUFlLElBQUk7QUFBQSxRQUNyQjtBQUFBLFFBQ0EsT0FBTTtBQUFBLFFBQ04sT0FBTTtBQUFBLFFBRUxuQjtBQUFBQSxzQkFDQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0VrQixjQUNGLHVCQUFDLFNBQUksV0FBVSxvQ0FDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsbUNBQWtDLDhDQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RTtBQUFBLGNBQzlFLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsMERBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsY0FDcEYsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsVUFDQztBQUFBLHlDQUFDLFlBQU8sNEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0I7QUFBQSxrQkFBUztBQUFBLGtCQUFFQSxhQUFhOE8sZUFBZTtBQUFBLHFCQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFDQztBQUFBLHlDQUFDLFlBQU8scUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBYTtBQUFBLGtCQUFTO0FBQUEsbUJBQUUsb0JBQUlwTCxLQUFLLEdBQUVFLG1CQUFtQjtBQUFBLHFCQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLHNEQUFxRCxnQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUY7QUFBQSxjQUNuRix1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyxxQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFhO0FBQUEsa0JBQVM7QUFBQSxrQkFBRTVELFlBQVlpRixhQUFhO0FBQUEscUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyxvQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFZO0FBQUEsa0JBQVM7QUFBQSxrQkFBRWpGLFlBQVkrTyxhQUFhcEksTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEscUJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyx1QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUEsa0JBQVM7QUFBQSxrQkFBRTNHLFlBQVlnUCxVQUFVO0FBQUEscUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFjO0FBQUEsa0JBQVM7QUFBQSxrQkFBRWhQLFlBQVlrRSxnQkFBZ0I7QUFBQSxxQkFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFjO0FBQUEsa0JBQVM7QUFBQSxrQkFBRWxFLFlBQVlpUCxTQUFTO0FBQUEscUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTywrQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QjtBQUFBLGtCQUFTO0FBQUEsa0JBQUVqUCxZQUFZa1Asa0JBQWtCO0FBQUEscUJBRGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyw0QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQjtBQUFBLGtCQUFTO0FBQUEsa0JBQUVsUCxZQUFZbVAsZUFBZTtBQUFBLHFCQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxZQUFPLHdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdCO0FBQUEsa0JBQVM7QUFBQSxrQkFBRW5QLFlBQVlvUCxXQUFXO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyx3QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQjtBQUFBLGtCQUFTO0FBQUEsa0JBQUVwUCxZQUFZcVAsV0FBVztBQUFBLHFCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFlBQU8sc0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBYztBQUFBLGtCQUFTO0FBQUEsa0JBQUVyUCxZQUFZc1AsU0FBUztBQUFBLHFCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFlBQU8seUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUI7QUFBQSxrQkFBUztBQUFBLGtCQUFFdFAsWUFBWXVQLFlBQVk7QUFBQSxxQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLHNCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWM7QUFBQSxrQkFBUztBQUFBLGtCQUFFdlAsWUFBWXdQLFNBQVM7QUFBQSxxQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLHdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdCO0FBQUEsa0JBQVM7QUFBQSxrQkFBRXhQLFlBQVl5UCxXQUFXO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyx1QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUEsa0JBQVM7QUFBQSxrQkFBRXpQLFlBQVkwUCxlQUFlO0FBQUEscUJBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQjtBQUFBLGtCQUFTO0FBQUEsa0JBQUUxUCxZQUFZMlAsYUFBYTtBQUFBLHFCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFlBQU8sdUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZTtBQUFBLGtCQUFTO0FBQUEsa0JBQUUzUCxZQUFZNFAsVUFBVTtBQUFBLHFCQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaURBO0FBQUEsaUJBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0RBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSxzREFBcUQsK0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsY0FDbEYsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFlBQU8scUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBYTtBQUFBLGtCQUFTO0FBQUEsa0JBQUU1UCxZQUFZNlAsZ0JBQWdCO0FBQUEscUJBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyxvQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFZO0FBQUEsa0JBQVM7QUFBQSxrQkFBRTdQLFlBQVk4UCxxQkFBcUJuSixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxxQkFEM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLDZCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFCO0FBQUEsa0JBQVM7QUFBQSxrQkFBRTNHLFlBQVkrUCx3QkFBd0I7QUFBQSxxQkFEdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLHNCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWM7QUFBQSxrQkFBUztBQUFBLGtCQUFFL1AsWUFBWWdRLHdCQUF3QjtBQUFBLHFCQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGlCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSx3REFBdUQsaUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNGO0FBQUEsY0FDdEYsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFlBQU8scUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBYTtBQUFBLGtCQUFTO0FBQUEsa0JBQUVoUSxZQUFZaVEsa0JBQWtCO0FBQUEscUJBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsWUFBTyxvQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFZO0FBQUEsa0JBQVM7QUFBQSxrQkFBRWpRLFlBQVlrUSx1QkFBdUJ2SixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxxQkFEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLDZCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFCO0FBQUEsa0JBQVM7QUFBQSxrQkFBRTNHLFlBQVltUSwwQkFBMEI7QUFBQSxxQkFEeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLHNCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWM7QUFBQSxrQkFBUztBQUFBLGtCQUFFblEsWUFBWW9RLG1CQUFtQjtBQUFBLHFCQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxZQUFPLHdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdCO0FBQUEsa0JBQVM7QUFBQSxrQkFBRXBRLFlBQVlxUSxxQkFBcUI7QUFBQSxxQkFEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1CO0FBQUEsa0JBQVM7QUFBQSxrQkFBRXJRLFlBQVlzUSxvQkFBb0I7QUFBQSxxQkFEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWU7QUFBQSxrQkFBUztBQUFBLGtCQUFFdFEsWUFBWXVRLGlCQUFpQjtBQUFBLHFCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSxzREFBcUQsNEJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStFO0FBQUEsY0FDL0UsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFlBQU8sMEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0I7QUFBQSxrQkFBUztBQUFBLGtCQUFFdlEsWUFBWXdRLGFBQWE7QUFBQSxxQkFEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLDRCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9CO0FBQUEsa0JBQVM7QUFBQSxrQkFBRXhRLFlBQVl5USxvQkFBb0I7QUFBQSxxQkFEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1CO0FBQUEsa0JBQVM7QUFBQSxrQkFBRXpRLFlBQVkwUSx1QkFBdUI7QUFBQSxxQkFEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxZQUFPLDBCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtCO0FBQUEsa0JBQVM7QUFBQSxrQkFBRTFRLFlBQVkyUSxrQkFBa0I7QUFBQSxxQkFEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLE9BQUUsV0FBVSx1QkFBc0IsdUNBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBEO0FBQUEsa0JBQzFELHVCQUFDLFNBQUksV0FBVSw0Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLHFCQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLE9BQUUsV0FBVSx1QkFBc0Isc0NBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlEO0FBQUEsa0JBQ3pELHVCQUFDLFNBQUksV0FBVSw0Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLHFCQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsK0VBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9HLEtBRHRHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsZUF0SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1SkEsS0F4SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5SkEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLGlDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRTtBQUFBLFVBR3BFLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2I1USxvQ0FBa0IsS0FBSztBQUN2QkUsaUNBQWUsSUFBSTtBQUFBLGdCQUNyQjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBMEM7QUFBQTtBQUFBLGNBTHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQjtBQUFBLGdCQUNyQyxTQUFTLE1BQU07QUFDYixzQkFBSUQsYUFBYTtBQUNmekMsK0NBQTJCeUMsWUFBWXFELEdBQUc7QUFBQSxrQkFDNUM7QUFBQSxnQkFDRjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBYTtBQUFBO0FBQUEsY0FSekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBO0FBQUE7QUFBQSxNQWxNRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtTUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsVUFBTyw2QkFBMEQsWUFBWSxRQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1GO0FBQUEsTUFDbkYsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUVSLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMkNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEYsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix1REFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxlQUZuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQ3pFLGNBQWMscUJBQXFCbU8sWUFBWXhKLFNBQVMsS0FDdkQsdUJBQUMsU0FBSSxXQUFVLHlHQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFVBQUssV0FBVSx1Q0FBc0MsMkJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FDakUsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQztBQUFBO0FBQUEsZ0JBQzNDeUosZ0JBQWdCNEQsZUFBZSxPQUFPO0FBQUEsbUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUNqRCx1QkFBQyxTQUNDO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywwQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxjQUM5RCx1QkFBQyxPQUFFLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxnQkFDM0N4RCxlQUFld0QsZUFBZSxPQUFPO0FBQUEsbUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUNqRCx1QkFBQyxTQUNDO0FBQUEscUNBQUMsVUFBSyxXQUFVLHNDQUFxQyxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUNyRSx1QkFBQyxPQUFFLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxnQkFDNUN2RCxlQUFldUQsZUFBZSxPQUFPO0FBQUEsbUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFHVix1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsOEZBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsWUFDM0MsdUJBQUMsVUFBSyxXQUFVLHVEQUFzRCxnQ0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Y7QUFBQSxlQUZ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTzVPLG1CQUFtQjZPO0FBQUFBLGNBQzFCLFVBQVU3TjtBQUFBQSxjQUNWO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixjQUFjLENBQUM4TixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsU0FBUyxFQUFFQyxZQUFZLEVBQUVwRyxTQUFTZ0csTUFBTUksWUFBWSxDQUFDO0FBQUEsY0FFdkUsWUFBWSx1QkFBQyxZQUFTLFdBQVUsbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsY0FDL0MsaUJBQWdCO0FBQUEsY0FDaEI7QUFBQSxjQUNBLFNBQVM1TztBQUFBQSxjQUVSUixpQkFBT2dEO0FBQUFBLGdCQUFJLENBQUMxQixNQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxFQUFFQyxLQUNqQ0QsWUFBRUUsY0FEZUYsRUFBRUMsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQTtBQUFBLFVBQ0NyQixtQkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQ2JDLG1DQUFtQixFQUFFO0FBQ3JCRSxxQ0FBcUIsRUFBRTtBQUN2QkUseUNBQXlCLEVBQUU7QUFDM0JoQyxvQ0FBb0JqQyxpQkFBaUI7QUFDckNELGlDQUFpQkMsaUJBQWlCO0FBQUEsY0FDcEM7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUFpQztBQUFBO0FBQUEsWUFUN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUE7QUFBQSxVQUlGLHVCQUFDLFNBQUksV0FBVSwwQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBR3RELHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSx1REFBc0QsNEJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtGO0FBQUEsWUFDbEY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxVQUFVK0w7QUFBQUEsZ0JBQ1YsUUFBTztBQUFBLGdCQUNQLGFBQWEsQ0FBQyxTQUFTLEtBQUs7QUFBQSxnQkFDNUIsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQTtBQUFBLGNBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS2M7QUFBQSxZQUViakssWUFBWSxDQUFDLEtBQUtBLFlBQVksQ0FBQyxLQUM5QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiQywrQkFBYSxDQUFDLE1BQU0sSUFBSSxDQUFDO0FBQ3pCLHNCQUFJNkIsaUJBQWlCO0FBQ25CM0Isd0NBQW9CK0IscUJBQXFCO0FBQUEsa0JBQzNDLE9BQU87QUFDTC9CLHdDQUFvQmpDLGlCQUFpQjtBQUFBLGtCQUN2QztBQUNBcUIsMkNBQXlCYSxzQkFBc0I7QUFDL0NYLDZDQUEyQmEsd0JBQXdCO0FBQ25EWCx1Q0FBcUJhLGFBQWE7QUFBQSxnQkFDcEM7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUFvQjtBQUFBO0FBQUEsY0FiaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZ0JBO0FBQUEsZUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxhQTFFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0ZBLEtBckZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzRkE7QUFBQSxRQUVVLHVCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxTQUFJLFdBQVUsa0JBQWlCLGNBQVcsUUFDeEM2TixlQUFLeko7QUFBQUEsVUFBSSxDQUFDcU0sUUFDVDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNO0FBQ2J0Uyw2QkFBYXNTLElBQUkxTixFQUFFO0FBQ25CcEMsb0NBQW9CLElBQUk7QUFBQSxjQUMxQjtBQUFBLGNBQ0EsV0FBVywyRUFDVHpDLGNBQWN1UyxJQUFJMU4sS0FDZCxzQ0FDQSw0RUFBNEU7QUFBQSxjQUdsRjtBQUFBLHVDQUFDLFVBQUssV0FBVSxnQkFBZ0IwTixjQUFJMUMsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDekMsdUJBQUMsVUFBTTBDLGNBQUl4VCxTQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQ2hCd1QsSUFBSTNDLFFBQVEsS0FDWDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFEQUNUNVAsY0FBY3VTLElBQUkxTixLQUFLLGtDQUFrQywyQkFBMkI7QUFBQSxvQkFHckYwTixjQUFJM0M7QUFBQUE7QUFBQUEsa0JBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBcEJHMkMsSUFBSTFOO0FBQUFBLFlBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXVCQTtBQUFBLFFBQ0QsS0ExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBLEtBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxRQUFRaUwsMkJBQWlCLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxXQWpLNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtLQTtBQUFBLE1BR0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVdsUTtBQUFBQSxVQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxVQUN2QyxPQUFNO0FBQUEsVUFFTixpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQ2pFLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVrTyxjQUNwQztBQUFBLHFDQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEU7QUFBQSxrQkFDNUU7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPL0wsZ0JBQWdCRSxjQUFjNkYsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsc0JBQ3RELFVBQVV5RjtBQUFBQSxzQkFDVixXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSzRDO0FBQUEscUJBUDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MseUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlFO0FBQUEsa0JBQ3pFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT3hMLGdCQUFnQkcsV0FBVzRGLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLHNCQUNuRCxVQUFVeUY7QUFBQUEsc0JBQ1YsV0FBVTtBQUFBO0FBQUEsb0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUs0QztBQUFBLHFCQVA5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFBcUY7QUFBQTtBQUFBLGdCQUZqRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxlQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQTtBQUFBO0FBQUEsUUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bd0NBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsUUFBUWhOO0FBQUFBLFVBQ1IsU0FBU29KO0FBQUFBLFVBQ1QsV0FBV2lFO0FBQUFBLFVBQ1gsT0FBTTtBQUFBLFVBQ04sYUFBWTtBQUFBO0FBQUEsUUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLb0U7QUFBQSxNQUlwRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBV25MO0FBQUFBLFVBQ1gsU0FBUyxNQUFNO0FBQ2JDLGlDQUFxQixLQUFLO0FBQzFCRSxnQ0FBb0IsRUFBRTtBQUN0QkUscUNBQXlCLElBQUk7QUFBQSxVQUMvQjtBQUFBLFVBQ0EsT0FBTTtBQUFBLFVBRU47QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsOEZBQ2IsaUNBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHlCQUF3Qiw2QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUQ7QUFBQSxrQkFDckQsdUJBQUMsVUFBSyxXQUFVLCtCQUNiRCxpQ0FBdUJzRCxTQUFTQyxhQUFhLFNBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHlCQUF3Qiw0QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0Q7QUFBQSxrQkFDcEQsdUJBQUMsVUFBSyxXQUFVLCtCQUNidkQsaUNBQXVCc0QsU0FBU2QsZ0JBQWdCLFNBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHlCQUF3QiwyQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUQ7QUFBQSxrQkFDbkQsdUJBQUMsVUFBSyxXQUFVLHlDQUNieEMsaUNBQXVCc0QsU0FBUzhKLGVBQWUsU0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSxxQ0FBb0Msd0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRFO0FBQUEsa0JBQzVFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcseUJBQ1R0Riw0QkFBNEJoSSxnQkFBZ0IsTUFBTSxNQUM5QyxtQkFDQWdJLDRCQUE0QmhJLGdCQUFnQixLQUFLLEtBQy9DLG9CQUNBLGNBQWM7QUFBQSxzQkFHckJnSTtBQUFBQSxvREFBNEJoSSxnQkFBZ0I7QUFBQSx3QkFBRTtBQUFBO0FBQUE7QUFBQSxvQkFUakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUNBLHVCQUFDLFlBQVMsU0FBU2dJLDRCQUE0QmhJLGdCQUFnQixHQUFHLE1BQUssV0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEU7QUFBQSxnQkFDOUUsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEseUNBQUMsVUFBSztBQUFBO0FBQUEsb0JBQ007QUFBQSxvQkFFUkEsaUJBQWlCK0U7QUFBQUEsc0JBQ2YsQ0FBQ3dGLFFBQVFBLElBQUlKLFlBQVlJLElBQUlMLGtCQUFrQjtBQUFBLG9CQUNqRCxFQUFFbkk7QUFBQUEsb0JBQ0Y7QUFBQSxvQkFBSTtBQUFBLG9CQUNIOUYsbUJBQW1COEY7QUFBQUEsdUJBUHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLO0FBQUE7QUFBQSxvQkFDTztBQUFBLG9CQUNWOUYsbUJBQW1COEYsU0FDbEIvQixpQkFBaUIrRTtBQUFBQSxzQkFDZixDQUFDd0YsUUFBUUEsSUFBSUosWUFBWUksSUFBSUwsa0JBQWtCO0FBQUEsb0JBQ2pELEVBQUVuSTtBQUFBQSx1QkFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsbUJBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0NBO0FBQUEsY0FFQy9CLGlCQUFpQitCLFNBQVMsSUFDekIsdUJBQUMsU0FBSSxXQUFVLHlDQUNaL0IsMkJBQWlCc0Q7QUFBQUEsZ0JBQUksQ0FBQ2lILEtBQUtyRixVQUMxQix1QkFBQyxTQUFnQixXQUFVLDZEQUN6QjtBQUFBLHlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDJDQUFDLFFBQUcsV0FBVSx1Q0FBdUNxRixjQUFJTCxpQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUU7QUFBQSxvQkFDdEVLLElBQUlKLFlBQ0gsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxTQUFTLE1BQU12RCxjQUFjMkQsSUFBSUosVUFBVUksSUFBSUwsYUFBYTtBQUFBLDBCQUM1RCxXQUFVO0FBQUE7QUFBQSx3QkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRWtFO0FBQUEsc0JBRWxFLHVCQUFDLE9BQUUsTUFBTUssSUFBSUosVUFBVSxRQUFPLFVBQVMsS0FBSSx1QkFDekMsaUNBQUMsY0FBVyxXQUFVLDRDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4RCxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLHVCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ1pJLGNBQUlSLFdBQVdRLElBQUlKLFdBQ2xCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLEtBQUtJLElBQUlKO0FBQUFBLHNCQUNULEtBQUtJLElBQUlMO0FBQUFBLHNCQUNULFdBQVU7QUFBQSxzQkFDVixTQUFTLE1BQU10RCxjQUFjMkQsSUFBSUosVUFBVUksSUFBSUwsYUFBYTtBQUFBO0FBQUEsb0JBSjlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJZ0UsSUFFOURLLElBQUlKLFdBQ04sdUJBQUMsY0FBVyxXQUFVLDRCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QyxJQUU5Qyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGdDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RCxLQVg1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBNUJRakYsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTZCQTtBQUFBLGNBQ0QsS0FoQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQ0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSx1Q0FBQyxjQUFXLFdBQVUseUNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJEO0FBQUEsZ0JBQzNELHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0IsdURBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9FO0FBQUEsbUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFuR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxR0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTXlGLHFCQUFxQixTQUFTO0FBQUEsa0JBQzdDLFdBQVU7QUFBQSxrQkFBOEM7QUFBQTtBQUFBLGdCQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNQSxxQkFBcUIsUUFBUTtBQUFBLGtCQUM1QyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFVBQVUzQyw0QkFBNEJoSSxnQkFBZ0IsSUFBSTtBQUFBLGtCQUFJO0FBQUE7QUFBQSxvQkFHN0RnSSw0QkFBNEJoSSxnQkFBZ0IsSUFBSSxPQUMvQyx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxzQkFDdENnSSw0QkFBNEJoSSxnQkFBZ0I7QUFBQSxzQkFBRTtBQUFBLHlCQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQTtBQUFBLGdCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU0ySyxxQkFBcUIsVUFBVTtBQUFBLGtCQUM5QyxXQUFVO0FBQUEsa0JBQTRDO0FBQUE7QUFBQSxnQkFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUNDM0MsNEJBQTRCaEksZ0JBQWdCLElBQUksT0FBT0EsaUJBQWlCK0IsU0FBUyxLQUNoRix1QkFBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsVUFBSyxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsY0FFdkM5RixtQkFBbUI4RixTQUNsQi9CLGlCQUFpQitFO0FBQUFBLGdCQUNmLENBQUN3RixRQUFRQSxJQUFJSixZQUFZSSxJQUFJTCxrQkFBa0I7QUFBQSxjQUNqRCxFQUFFbkk7QUFBQUEsY0FBUTtBQUFBLGNBQUk7QUFBQSxpQkFMbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQTtBQUFBO0FBQUEsUUFySko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BdUpBO0FBQUEsU0FuWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9YQTtBQUFBLE9BcmtCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc2tCQTtBQUVKO0FBQUMxRixHQXAxRFFELGVBQWE7QUFBQSxVQUNIdEMsYUFDQUMsV0FBVztBQUFBO0FBQUE2VixLQUZyQnhUO0FBczFEVCxlQUFlQTtBQUFjLElBQUF3VDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJ1c2VOYXZpZ2F0ZSIsInVzZUxvY2F0aW9uIiwiTmF2YmFyIiwiU2lkZWJhciIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiYXBpIiwiRHJvcGRvd24iLCJQb3Bjb25maXJtIiwibWVzc2FnZSIsIkJ1dHRvbiIsIk1vZGFsIiwiRGF0ZVBpY2tlciIsIlNwYWNlIiwiUHJvZ3Jlc3MiLCJUb29sdGlwIiwiU2VsZWN0IiwiSW9NZE1vcmUiLCJJb0ZsYXNoIiwiSW9Eb2N1bWVudFRleHQiLCJJb0NoZWNrbWFya0NpcmNsZSIsIklvRXllIiwiSW9Eb2N1bWVudCIsIklvRG93bmxvYWQiLCJJb0Nsb3NlIiwiSW9TZWFyY2giLCJmaWx0ZXJPcHRpb24iLCJNb2RhbENvbXBvbmVudCIsIkZhUnVwZWVTaWduIiwiSW9GbGFnIiwiZGF5anMiLCJCcmVhZGNydW1iIiwiU2ltcGxlUGFzc3dvcmRNb2RhbCIsImhhbmRsZUt5Y1ZlcmlmaWNhdGlvblByaW50IiwiUmFuZ2VQaWNrZXIiLCJSRVFVSVJFRF9ET0NVTUVOVFMiLCJrZXkiLCJsYWJlbCIsIlJlY2VudEF1Y3Rpb24iLCJfcyIsIm5hdmlnYXRlIiwibG9jYXRpb24iLCJsb2FkaW5nUmVjZW50Iiwic2V0TG9hZGluZ1JlY2VudCIsIlRhYmxlQXVjdGlvbnMiLCJzZXRUYWJsZUF1Y3Rpb25zIiwiYWxsUmVjZW50QXVjdGlvbnMiLCJzZXRBbGxSZWNlbnRBdWN0aW9ucyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicHJldmlld0ltYWdlIiwic2V0UHJldmlld0ltYWdlIiwicHJldmlld1RpdGxlIiwic2V0UHJldmlld1RpdGxlIiwic2hvd1BheW91dFBhc3N3b3JkIiwic2V0U2hvd1BheW91dFBhc3N3b3JkIiwicGVuZGluZ1BheW91dElkIiwic2V0UGVuZGluZ1BheW91dElkIiwiZmlsdGVyZWREb2NDb2xsZWN0aW9uIiwic2V0RmlsdGVyZWREb2NDb2xsZWN0aW9uIiwiZmlsdGVyZWREb2NWZXJpZmljYXRpb24iLCJzZXRGaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbiIsImZpbHRlcmVkQ29tcGxldGVkIiwic2V0RmlsdGVyZWRDb21wbGV0ZWQiLCJzaG93S3ljUHJldmlldyIsInNldFNob3dLeWNQcmV2aWV3Iiwia3ljVXNlckRhdGEiLCJzZXRLeWNVc2VyRGF0YSIsImRhdGVSYW5nZSIsInNldERhdGVSYW5nZSIsImZpbHRlcmVkQXVjdGlvbnMiLCJzZXRGaWx0ZXJlZEF1Y3Rpb25zIiwiZG9jdW1lbnRDb2xsZWN0aW9uRGF0YSIsInNldERvY3VtZW50Q29sbGVjdGlvbkRhdGEiLCJkb2N1bWVudFZlcmlmaWNhdGlvbkRhdGEiLCJzZXREb2N1bWVudFZlcmlmaWNhdGlvbkRhdGEiLCJjb21wbGV0ZWREYXRhIiwic2V0Q29tcGxldGVkRGF0YSIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJhdWN0aW9uX2RhdGUiLCJuZXh0X2RhdGUiLCJhY3RpdmVVc2VyRGF0YSIsInNldEFjdGl2ZVVzZXJEYXRhIiwic2VsZWN0QWxsIiwic2V0U2VsZWN0QWxsIiwib3BlbkFjdGlvbk1lbnVJZCIsInNldE9wZW5BY3Rpb25NZW51SWQiLCJzaG93RG9jdW1lbnRNb2RhbCIsInNldFNob3dEb2N1bWVudE1vZGFsIiwiY3VycmVudERvY3VtZW50cyIsInNldEN1cnJlbnREb2N1bWVudHMiLCJjdXJyZW50QXVjdGlvbkZvckRvY3MiLCJzZXRDdXJyZW50QXVjdGlvbkZvckRvY3MiLCJkb2N1bWVudFVwbG9hZGVkS2V5cyIsInNldERvY3VtZW50VXBsb2FkZWRLZXlzIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwic2VsZWN0ZWRHcm91cElkIiwic2V0U2VsZWN0ZWRHcm91cElkIiwic2VsZWN0ZWRHcm91cE5hbWUiLCJzZXRTZWxlY3RlZEdyb3VwTmFtZSIsImZpbHRlcmVkR3JvdXBBdWN0aW9ucyIsInNldEZpbHRlcmVkR3JvdXBBdWN0aW9ucyIsImlzR3JvdXBMb2FkaW5nIiwic2V0SXNHcm91cExvYWRpbmciLCJmZXRjaEdyb3VwcyIsImZldGNoUmVjZW50QXVjdGlvbnMiLCJmZXRjaFByb2Nlc3NEYXRhIiwiZGF0YSIsImdldCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZUdyb3VwQ2hhbmdlIiwiZ3JvdXBJZCIsInNlbGVjdGVkR3JvdXAiLCJmaW5kIiwiZyIsIl9pZCIsImdyb3VwX25hbWUiLCJsZW5ndGgiLCJmb3JtYXR0ZWRBdWN0aW9ucyIsImlkIiwiRGF0ZSIsImdldFRpbWUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJyZXBsYWNlIiwibmFtZSIsInBob25lX251bWJlciIsInRpY2tldCIsImJpZF9hbW91bnQiLCJhbW91bnQiLCJhdWN0aW9uX3R5cGUiLCJzdGF0dXMiLCJ3b3JrZmxvd19zdGF0dXMiLCJncm91cF92YWx1ZSIsImdyb3VwX2lkIiwiYXVjdGlvbl9jb2RlIiwiaXNDb21tZW5jZW1lbnQiLCJhY3Rpb24iLCJtYXAiLCJpZHgiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwiTnVtYmVyIiwiZGl2aWRlbnQiLCJjb21taXNzaW9uIiwid2luX2Ftb3VudCIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJpc1ByaXplZCIsIml0ZW1zIiwidXBkYXRlQXVjdGlvblN0YXR1cyIsIndhcm5pbmciLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVBdWN0aW9uIiwiaW5mbyIsInJlc3BvbnNlIiwiaGFuZGxlS3ljUHJldmlldyIsInVzZXJJZCIsImF1Y3Rpb25zRGF0YSIsIkFycmF5IiwiaXNBcnJheSIsInBlbmRpbmdBdWN0aW9ucyIsImZpbHRlciIsImF1Y3Rpb24iLCJmb3JtYXR0ZWREYXRhIiwiaW5kZXgiLCJzcGxpdCIsInBhcnNlSW50IiwidGVtcEFjdGl2ZSIsImZvckVhY2giLCJpdGVtIiwiYXVjdGlvbklkIiwibmV3U3RhdHVzIiwicHV0Iiwic3VjY2VzcyIsImhhbmRsZUJ1bGtTdGF0dXNVcGRhdGUiLCJzZWxlY3RlZEl0ZW1zIiwiY29uZmlybSIsInRpdGxlIiwiY29udGVudCIsIm9rVGV4dCIsImNhbmNlbFRleHQiLCJvbk9rIiwiUHJvbWlzZSIsImFsbCIsImhhbmRsZUJ1bGtEZWxldGUiLCJva1R5cGUiLCJnZXRTdGF0dXNUYWciLCJwZXJjZW50YWdlIiwiYmFzZUNsYXNzIiwicGVyY2VudCIsImhhbmRsZVByZXZpZXciLCJpbWFnZVVybCIsImhhbmRsZUNhbmNlbFByZXZpZXciLCJoYW5kbGVQYXlvdXQiLCJoYW5kbGVQYXlvdXRNb2RhbENsb3NlIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwic2VhcmNoIiwic2V0U2hvd01vZGFsIiwid2luZG93IiwiaGlzdG9yeSIsInJlcGxhY2VTdGF0ZSIsImRvY3VtZW50IiwiYXVjdGlvbnMiLCJkb2NDb2xsZWN0aW9uUHJvbWlzZXMiLCJkb2N1bWVudFBlcmNlbnRhZ2UiLCJkb2N1bWVudHMiLCJ1c2VyRG9jc1JlcyIsInVzZXJEb2MiLCJ0cmFuc2Zvcm1Vc2VyRG9jdW1lbnRzVG9BcnJheSIsImNhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZSIsInRpbWUiLCJ1cGRhdGVkQXQiLCJhdWN0aW9uX2lkIiwiYXVjdGlvbl9kYXRhIiwiaGFuZGxlVmlld0RvY3VtZW50cyIsIm9wZW4iLCJkb2NDb2xsZWN0aW9uIiwiZG9jVmVyaWZpY2F0aW9uUHJvbWlzZXMiLCJkb2NWZXJpZmljYXRpb24iLCJjb21wbGV0ZWQiLCJoYW5kbGVEYXRlRmlsdGVyIiwiZGF0ZXMiLCJzdGFydCIsImVuZCIsImRhdGFUb0ZpbHRlciIsImZpbHRlcmVkUmVjZW50IiwiZmlsdGVyRGF0YUJ5RGF0ZSIsImZpbHRlcmVkQ29sbGVjdGlvbiIsImZpbHRlcmVkVmVyaWZpY2F0aW9uIiwiZmlsdGVyZWRDb21wbGV0ZWREYXRhIiwiaXRlbURhdGUiLCJpbmNsdWRlcyIsImF1Y3Rpb25EYXRlIiwiaXNBZnRlciIsInN1YnRyYWN0IiwiaXNCZWZvcmUiLCJhZGQiLCJhdWN0aW9uRGF0YSIsImV4aXN0aW5nRG9jdW1lbnRzIiwiZG9jTWFwcGluZ3MiLCJpc0ltYWdlIiwibWFwcGluZyIsInB1c2giLCJkb2N1bWVudF90eXBlIiwiZmlsZV91cmwiLCJkZXNjcmlwdGlvbiIsInVzZXJfZG9jdW1lbnRfY29kZSIsInVwbG9hZGVkRG9jcyIsImRvYyIsInRvdGFsUmVxdWlyZWREb2NzIiwiTWF0aCIsInJvdW5kIiwiaGFuZGxlRG9jdW1lbnRBY3Rpb24iLCJoYW5kbGVJbnB1dENoYW5nZSIsImUiLCJ2YWx1ZSIsInRhcmdldCIsInByZXZEYXRhIiwiaGFuZGxlUGF5b3V0U3VjY2VzcyIsImRlbGV0ZSIsImhhbmRsZVVwZGF0ZSIsInByZXZlbnREZWZhdWx0Iiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZ2V0RGlzcGxheURhdGEiLCJkaXNwbGF5RGF0YSIsInRvdGFsR3JvdXBWYWx1ZSIsInJlZHVjZSIsInN1bSIsInBhcnNlRmxvYXQiLCJ0b3RhbEJpZEFtb3VudCIsInRvdGFsV2luQW1vdW50Iiwic2VsZWN0ZWRDb3VudCIsImFsbENoZWNrZWQiLCJldmVyeSIsImhhbmRsZUNoZWNrYm94Q2hhbmdlIiwicHJldiIsImhhbmRsZVNlbGVjdEFsbENoYW5nZSIsImNoZWNrZWQiLCJ1cGRhdGVkIiwiZm9ybWF0dGVkQXVjdGlvbkRhdGEiLCJmb3JtYXR0ZWQiLCJ3b3JrZmxvd1N0YXR1cyIsImNoZWNrYm94IiwicmVjZW50Q29sdW1ucyIsImhlYWRlciIsImRvY0NvbGxlY3Rpb25Db2x1bW5zIiwiZG9jVmVyaWZpY2F0aW9uQ29sdW1ucyIsImNvbXBsZXRlZENvbHVtbnMiLCJ0YWJzIiwiY291bnQiLCJpY29uIiwicmVuZGVyVGFiQ29udGVudCIsInNlbGVjdGVkIiwibWF4V2lkdGgiLCJ3aWR0aCIsImN1c3RvbWVyX2lkIiwiZGF0ZW9mYmlydGgiLCJnZW5kZXIiLCJlbWFpbCIsIm1hcml0YWxfc3RhdHVzIiwibmF0aW9uYWxpdHkiLCJhZGRyZXNzIiwidmlsbGFnZSIsInRhbHVrIiwiZGlzdHJpY3QiLCJzdGF0ZSIsInBpbmNvZGUiLCJmYXRoZXJfbmFtZSIsImFkaGFhcl9ubyIsInBhbl9ubyIsIm5vbWluZWVfbmFtZSIsIm5vbWluZWVfZGF0ZW9mYmlydGgiLCJub21pbmVlX3JlbGF0aW9uc2hpcCIsIm5vbWluZWVfcGhvbmVfbnVtYmVyIiwiZ3VhcmFudG9yX25hbWUiLCJndWFyYW50b3JfZGF0ZW9mYmlydGgiLCJndWFyYW50b3JfcmVsYXRpb25zaGlwIiwiZ3VhcmFudG9yX3Bob25lIiwiZ3VhcmFudG9yX2FkZHJlc3MiLCJndWFyYW50b3JfYWRoYWFyIiwiZ3VhcmFudG9yX3BhbiIsImJhbmtfbmFtZSIsImJhbmtfYnJhbmNoX25hbWUiLCJiYW5rX2FjY291bnRfbnVtYmVyIiwiYmFua19JRlNDX2NvZGUiLCJ0b0xvY2FsZVN0cmluZyIsInVuZGVmaW5lZCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwidGFiIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVjZW50QXVjdGlvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG4vLyBpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbi8vIGltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbi8vIGltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuLy8gaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbi8vIGltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuLy8gaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuLy8gaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG4vLyBpbXBvcnQge1xyXG4vLyAgIERyb3Bkb3duLFxyXG4vLyAgIFBvcGNvbmZpcm0sXHJcbi8vICAgbWVzc2FnZSxcclxuLy8gICBCdXR0b24sXHJcbi8vICAgTW9kYWwsXHJcbi8vICAgRGF0ZVBpY2tlcixcclxuLy8gICBTcGFjZSxcclxuLy8gICBQcm9ncmVzcyxcclxuLy8gICBUb29sdGlwLFxyXG4vLyB9IGZyb20gXCJhbnRkXCI7XHJcbi8vIGltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbi8vIGltcG9ydCB7XHJcbi8vICAgSW9GbGFzaCxcclxuLy8gICBJb0RvY3VtZW50VGV4dCxcclxuLy8gICBJb0NoZWNrbWFya0NpcmNsZSxcclxuLy8gICBJb0V5ZSxcclxuLy8gICBJb0RvY3VtZW50LFxyXG4vLyAgIElvRG93bmxvYWQsXHJcbi8vICAgSW9DbG9zZSxcclxuLy8gfSBmcm9tIFwicmVhY3QtaWNvbnMvaW81XCI7XHJcbi8vIGltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbi8vIGltcG9ydCBNb2RhbENvbXBvbmVudCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuLy8gaW1wb3J0IHsgRmFSdXBlZVNpZ24gfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuLy8gaW1wb3J0IHsgSW9GbGFnIH0gZnJvbSBcInJlYWN0LWljb25zL2lvNVwiO1xyXG4vLyBpbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcbi8vIGltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuLy8gaW1wb3J0IFNpbXBsZVBhc3N3b3JkTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL1NpbXBsZVBhc3N3b3JkTW9kYWxcIjtcclxuLy8gaW1wb3J0IGhhbmRsZUt5Y1ZlcmlmaWNhdGlvblByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9reWNWZXJpZmljYXRpb25QcmludFwiO1xyXG5cclxuXHJcbi8vIGNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcblxyXG4vLyAvLyBEb2N1bWVudCB0eXBlIG1hcHBpbmcgZm9yIHJlcXVpcmVkIGRvY3VtZW50c1xyXG4vLyBjb25zdCBSRVFVSVJFRF9ET0NVTUVOVFMgPSBbXHJcbi8vICAgeyBrZXk6IFwidXNlcl9wcm9maWxlX3Bob3RvXCIsIGxhYmVsOiBcIlBob3RvXCIgfSxcclxuLy8gICB7IGtleTogXCJ1c2VyX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLCBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoRnJvbnQpXCIgfSxcclxuLy8gICB7IGtleTogXCJ1c2VyX2FkaGFyY2FyZF9iYWNrX3Bob3RvXCIsIGxhYmVsOiBcIkFhZGhhciBDYXJkIChCYWNrKVwiIH0sXHJcbi8vICAgeyBrZXk6IFwidXNlcl9wYW5jYXJkX3Bob3RvXCIsIGxhYmVsOiBcIlBBTiBDYXJkXCIgfSxcclxuLy8gICB7IGtleTogXCJ1c2VyX2NoZXF1ZV9sZWFmXCIsIGxhYmVsOiBcIkNoZXF1ZSBMZWFmXCIgfSxcclxuLy8gICB7IGtleTogXCJiYW5rX3N0YXRlbWVudF9tb250aFwiLCBsYWJlbDogXCJCYW5rIFN0YXRlbWVudFwiIH0sXHJcbi8vICAgeyBrZXk6IFwiYmFua19wYXNzYm9va19waG90b1wiLCBsYWJlbDogXCJQYXNzYm9vayBQaG90b1wiIH0sXHJcbi8vICAgeyBrZXk6IFwiYnVzaW5lc3NfZG9jdW1lbnRfcHJvb2ZcIiwgbGFiZWw6IFwiQnVzaW5lc3MgUHJvb2ZcIiB9LFxyXG4vLyAgIHsga2V5OiBcInVzZXJfc2FsYXJ5X3NsaXBcIiwgbGFiZWw6IFwiU2FsYXJ5IFNsaXBcIiB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGtleTogXCJ1c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvXCIsXHJcbi8vICAgICBsYWJlbDogXCJOb21pbmVlIEFhZGhhciAoRnJvbnQpXCIsXHJcbi8vICAgfSxcclxuLy8gICB7IGtleTogXCJ1c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG9cIiwgbGFiZWw6IFwiTm9taW5lZSBBYWRoYXIgKEJhY2spXCIgfSxcclxuLy8gICB7IGtleTogXCJ1c2VyX25vbWluZWVfcGFuY2FyZF9waG90b1wiLCBsYWJlbDogXCJOb21pbmVlIFBBTiBDYXJkXCIgfSxcclxuLy8gXTtcclxuXHJcbi8vIGZ1bmN0aW9uIFJlY2VudEF1Y3Rpb24oKSB7XHJcbi8vICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4vLyAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuLy8gICBjb25zdCBbbG9hZGluZ1JlY2VudCwgc2V0TG9hZGluZ1JlY2VudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW1RhYmxlQXVjdGlvbnMsIHNldFRhYmxlQXVjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFthbGxSZWNlbnRBdWN0aW9ucywgc2V0QWxsUmVjZW50QXVjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2N1cnJlbnRVcGRhdGVHcm91cCwgc2V0Q3VycmVudFVwZGF0ZUdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcInJlY2VudF9hdWN0aW9uc1wiKTtcclxuLy8gICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtwcmV2aWV3SW1hZ2UsIHNldFByZXZpZXdJbWFnZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbcHJldmlld1RpdGxlLCBzZXRQcmV2aWV3VGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIGNvbnN0IFtzaG93UGF5b3V0UGFzc3dvcmQsIHNldFNob3dQYXlvdXRQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3BlbmRpbmdQYXlvdXRJZCwgc2V0UGVuZGluZ1BheW91dElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuLy8gICBjb25zdCBbZmlsdGVyZWREb2NDb2xsZWN0aW9uLCBzZXRGaWx0ZXJlZERvY0NvbGxlY3Rpb25dID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtmaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbiwgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb25dID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtmaWx0ZXJlZENvbXBsZXRlZCwgc2V0RmlsdGVyZWRDb21wbGV0ZWRdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuLy8gY29uc3QgW3Nob3dLeWNQcmV2aWV3LCBzZXRTaG93S3ljUHJldmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vIGNvbnN0IFtreWNVc2VyRGF0YSwgc2V0S3ljVXNlckRhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4vLyAgIC8vIERhdGUgZmlsdGVyIHN0YXRlc1xyXG4vLyAgIGNvbnN0IFtkYXRlUmFuZ2UsIHNldERhdGVSYW5nZV0gPSB1c2VTdGF0ZShbbnVsbCwgbnVsbF0pO1xyXG4vLyAgIGNvbnN0IFtmaWx0ZXJlZEF1Y3Rpb25zLCBzZXRGaWx0ZXJlZEF1Y3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbi8vICAgLy8gVGFiIGRhdGFcclxuLy8gICBjb25zdCBbZG9jdW1lbnRDb2xsZWN0aW9uRGF0YSwgc2V0RG9jdW1lbnRDb2xsZWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2RvY3VtZW50VmVyaWZpY2F0aW9uRGF0YSwgc2V0RG9jdW1lbnRWZXJpZmljYXRpb25EYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbY29tcGxldGVkRGF0YSwgc2V0Q29tcGxldGVkRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4vLyAgIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgYXVjdGlvbl9kYXRlOiBcIlwiLFxyXG4vLyAgICAgbmV4dF9kYXRlOiBcIlwiLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICAvLyBTZWxlY3Rpb24gc3RhdGVzXHJcbi8vICAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbi8vICAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbb3BlbkFjdGlvbk1lbnVJZCwgc2V0T3BlbkFjdGlvbk1lbnVJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbi8vICAgLy8gRG9jdW1lbnQgbW9kYWwgc3RhdGVzXHJcbi8vICAgY29uc3QgW3Nob3dEb2N1bWVudE1vZGFsLCBzZXRTaG93RG9jdW1lbnRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2N1cnJlbnREb2N1bWVudHMsIHNldEN1cnJlbnREb2N1bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtjdXJyZW50QXVjdGlvbkZvckRvY3MsIHNldEN1cnJlbnRBdWN0aW9uRm9yRG9jc10gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbZG9jdW1lbnRVcGxvYWRlZEtleXMsIHNldERvY3VtZW50VXBsb2FkZWRLZXlzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoUmVjZW50QXVjdGlvbnMoKTtcclxuLy8gICAgIGZldGNoUHJvY2Vzc0RhdGEoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIENoZWNrIFVSTCBwYXJhbXMgZm9yIGRvY3VtZW50IHVwbG9hZCBuYXZpZ2F0aW9uXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKTtcclxuLy8gICAgIGNvbnN0IHVwbG9hZEF1Y3Rpb25JZCA9IHBhcmFtcy5nZXQoXCJ1cGxvYWRcIik7XHJcbi8vICAgICBpZiAodXBsb2FkQXVjdGlvbklkKSB7XHJcbi8vICAgICAgIGNvbnN0IGF1Y3Rpb24gPSBhbGxSZWNlbnRBdWN0aW9ucy5maW5kKChhKSA9PiBhLl9pZCA9PT0gdXBsb2FkQXVjdGlvbklkKTtcclxuLy8gICAgICAgaWYgKGF1Y3Rpb24pIHtcclxuLy8gICAgICAgICB3aW5kb3cub3BlbihcclxuLy8gICAgICAgICAgIGAvbGVnYWxzLW1lbnUvdXNlci1kb2N1bWVudD91c2VySWQ9JHthdWN0aW9uLnVzZXJfaWQgfHwgYXVjdGlvbi51c2VySWR9JmF1Y3Rpb25JZD0ke3VwbG9hZEF1Y3Rpb25JZH1gLFxyXG4vLyAgICAgICAgICAgXCJfYmxhbmtcIixcclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW2xvY2F0aW9uLnNlYXJjaCwgYWxsUmVjZW50QXVjdGlvbnNdKTtcclxuXHJcbi8vIGNvbnN0IGhhbmRsZUt5Y1ByZXZpZXcgPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbi8vICAgdHJ5IHtcclxuLy8gICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuLy8gICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3VzZXIvZ2V0LXVzZXItYnktaWQvJHt1c2VySWR9YCk7XHJcbi8vICAgICBzZXRLeWNVc2VyRGF0YShyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgIHNldFNob3dLeWNQcmV2aWV3KHRydWUpO1xyXG4vLyAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBLWUMgZGF0YTpcIiwgZXJyb3IpO1xyXG4vLyAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBLWUMgZGV0YWlsc1wiKTtcclxuLy8gICB9IGZpbmFsbHkge1xyXG4vLyAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICB9XHJcbi8vIH07XHJcblxyXG4vLyAgIC8vIEZldGNoIHJlY2VudCBhdWN0aW9ucyAoQXVjdGlvbiBXaW5uZXJzIHRhYikgLSBPbmx5IHNob3cgUGVuZGluZ1xyXG4vLyAgIGNvbnN0IGZldGNoUmVjZW50QXVjdGlvbnMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBzZXRMb2FkaW5nUmVjZW50KHRydWUpO1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL2F1Y3Rpb25zL3JlY2VudFwiKTtcclxuLy8gICAgICAgY29uc3QgYXVjdGlvbnNEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhO1xyXG5cclxuLy8gICAgICAgaWYgKFxyXG4vLyAgICAgICAgIGF1Y3Rpb25zRGF0YSAmJlxyXG4vLyAgICAgICAgIEFycmF5LmlzQXJyYXkoYXVjdGlvbnNEYXRhKSAmJlxyXG4vLyAgICAgICAgIGF1Y3Rpb25zRGF0YS5sZW5ndGggPiAwXHJcbi8vICAgICAgICkge1xyXG4vLyAgICAgICAgIC8vIEZpbHRlciB0byBvbmx5IHNob3cgUGVuZGluZyBzdGF0dXNcclxuLy8gICAgICAgICBjb25zdCBwZW5kaW5nQXVjdGlvbnMgPSBhdWN0aW9uc0RhdGEuZmlsdGVyKFxyXG4vLyAgICAgICAgICAgKGF1Y3Rpb24pID0+IGF1Y3Rpb24uc3RhdHVzID09PSBcIlBlbmRpbmdcIiB8fCAhYXVjdGlvbi5zdGF0dXMsXHJcbi8vICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHBlbmRpbmdBdWN0aW9ucy5tYXAoKGF1Y3Rpb24sIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgX2lkOiBhdWN0aW9uLl9pZCxcclxuLy8gICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbi8vICAgICAgICAgICBhdWN0aW9uX2NvZGU6IGF1Y3Rpb24/LmF1Y3Rpb25fY29kZSxcclxuLy8gICAgICAgICAgIGF1Y3Rpb25fZGF0ZTpcclxuLy8gICAgICAgICAgICAgYXVjdGlvbj8uYXVjdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgYXVjdGlvbj8uYXVjdGlvbl9kYXRlLFxyXG4vLyAgICAgICAgICAgZ3JvdXBfbmFtZTogYXVjdGlvbi5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgZ3JvdXBfdmFsdWU6IGF1Y3Rpb24uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICBuYW1lOiBhdWN0aW9uLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgdGlja2V0OiBhdWN0aW9uPy50aWNrZXQsXHJcbi8vICAgICAgICAgICBiaWRfYW1vdW50OlxyXG4vLyAgICAgICAgICAgICAocGFyc2VJbnQoYXVjdGlvbi5kaXZpZGVudCkgfHwgMCkgK1xyXG4vLyAgICAgICAgICAgICAocGFyc2VJbnQoYXVjdGlvbi5jb21taXNzaW9uKSB8fCAwKSxcclxuLy8gICAgICAgICAgIGFtb3VudDogYXVjdGlvbj8ud2luX2Ftb3VudCxcclxuLy8gICAgICAgICAgIGF1Y3Rpb25fdHlwZTpcclxuLy8gICAgICAgICAgICAgYXVjdGlvbj8uYXVjdGlvbl90eXBlPy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArXHJcbi8vICAgICAgICAgICAgIGF1Y3Rpb24/LmF1Y3Rpb25fdHlwZT8uc2xpY2UoMSkgK1xyXG4vLyAgICAgICAgICAgICBcIiBBdWN0aW9uXCIsXHJcbi8vICAgICAgICAgICBzdGF0dXM6ICFhdWN0aW9uPy5pc1ByaXplZFxyXG4vLyAgICAgICAgICAgICA/IFwiVW4gUHJpemVkXCJcclxuLy8gICAgICAgICAgICAgOiBhdWN0aW9uPy5pc1ByaXplZCA9PT0gXCJ0cnVlXCJcclxuLy8gICAgICAgICAgICAgICA/IFwiUHJpemVkXCJcclxuLy8gICAgICAgICAgICAgICA6IFwiVW4gUHJpemVkXCIsXHJcbi8vICAgICAgICAgICB1c2VyX2lkOiBhdWN0aW9uLnVzZXJfaWQ/Ll9pZCxcclxuLy8gICAgICAgICAgIHdvcmtmbG93X3N0YXR1czogYXVjdGlvbi5zdGF0dXMgfHwgXCJQZW5kaW5nXCIsXHJcbi8vICAgICAgICAgfSkpO1xyXG5cclxuLy8gICAgICAgICBzZXRBbGxSZWNlbnRBdWN0aW9ucyhmb3JtYXR0ZWREYXRhKTtcclxuLy8gICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb25zKGZvcm1hdHRlZERhdGEpO1xyXG4vLyAgICAgICAgIHNldFRhYmxlQXVjdGlvbnMoZm9ybWF0dGVkRGF0YSk7XHJcblxyXG4vLyAgICAgICAgIC8vIEluaXRpYWxpemUgc2VsZWN0aW9uIHN0YXRlXHJcbi8vICAgICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG4vLyAgICAgICAgIGZvcm1hdHRlZERhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4vLyAgICAgICAgICAgdGVtcEFjdGl2ZVtpdGVtLl9pZF0gPSB7XHJcbi8vICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4vLyAgICAgICAgICAgICAgIGF1Y3Rpb25fY29kZTogaXRlbS5hdWN0aW9uX2NvZGUsXHJcbi8vICAgICAgICAgICAgICAgbmFtZTogaXRlbS5uYW1lLFxyXG4vLyAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgfTtcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh0ZW1wQWN0aXZlKTtcclxuLy8gICAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgICBzZXRBbGxSZWNlbnRBdWN0aW9ucyhbXSk7XHJcbi8vICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9ucyhbXSk7XHJcbi8vICAgICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIG1lc3NhZ2UuZXJyb3IoXHJcbi8vICAgICAgICAgZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gZmV0Y2ggcmVjZW50IGF1Y3Rpb25zXCIsXHJcbi8vICAgICAgICk7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nUmVjZW50KGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBVcGRhdGUgYXVjdGlvbiBzdGF0dXMgaW4gQXVjdGlvbiBtb2RlbCBkaXJlY3RseVxyXG4vLyAgIGNvbnN0IHVwZGF0ZUF1Y3Rpb25TdGF0dXMgPSBhc3luYyAoYXVjdGlvbklkLCBuZXdTdGF0dXMpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IGlkID0gdHlwZW9mIGF1Y3Rpb25JZCA9PT0gXCJvYmplY3RcIiA/IGF1Y3Rpb25JZD8uX2lkIDogYXVjdGlvbklkO1xyXG5cclxuLy8gICAgICAgaWYgKCFpZCkge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbnZhbGlkIGF1Y3Rpb25JZDpcIiwgYXVjdGlvbklkKTtcclxuLy8gICAgICAgICByZXR1cm47XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIC8vIFVwZGF0ZSBzdGF0dXMgZGlyZWN0bHkgaW4gQXVjdGlvbiBtb2RlbFxyXG4vLyAgICAgICBhd2FpdCBhcGkucHV0KGB2MS9hZG1pbi9hdWN0aW9ucy9zdGF0dXMvJHtpZH1gLCB7XHJcbi8vICAgICAgICAgc3RhdHVzOiBuZXdTdGF0dXMsXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgbWVzc2FnZS5zdWNjZXNzKGBTdGF0dXMgdXBkYXRlZCB0byAke25ld1N0YXR1c31gKTtcclxuXHJcbi8vICAgICAgIC8vIFJlZnJlc2ggYWxsIGRhdGFcclxuLy8gICAgICAgZmV0Y2hSZWNlbnRBdWN0aW9ucygpO1xyXG4vLyAgICAgICBmZXRjaFByb2Nlc3NEYXRhKCk7XHJcblxyXG4vLyAgICAgICAvLyBDbGVhciBzZWxlY3Rpb25zXHJcbi8vICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHt9KTtcclxuLy8gICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuLy8gICAgICAgc2V0T3BlbkFjdGlvbk1lbnVJZChudWxsKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIG1lc3NhZ2UuZXJyb3IoZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gdXBkYXRlIHN0YXR1c1wiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBCdWxrIHVwZGF0ZSBzdGF0dXNcclxuLy8gICBjb25zdCBoYW5kbGVCdWxrU3RhdHVzVXBkYXRlID0gKG5ld1N0YXR1cykgPT4ge1xyXG4vLyAgICAgY29uc3Qgc2VsZWN0ZWRJdGVtcyA9IGZpbHRlcmVkQXVjdGlvbnMuZmlsdGVyKFxyXG4vLyAgICAgICAoaXRlbSkgPT4gYWN0aXZlVXNlckRhdGFbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXMsXHJcbi8vICAgICApO1xyXG5cclxuLy8gICAgIGlmIChzZWxlY3RlZEl0ZW1zLmxlbmd0aCA9PT0gMCkge1xyXG4vLyAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGF1Y3Rpb25zIHRvIHVwZGF0ZVwiKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIE1vZGFsLmNvbmZpcm0oe1xyXG4vLyAgICAgICB0aXRsZTogYEJ1bGsgVXBkYXRlIENvbmZpcm1hdGlvbmAsXHJcbi8vICAgICAgIGNvbnRlbnQ6IGBZb3UgYXJlIGFib3V0IHRvIHVwZGF0ZSBzdGF0dXMgdG8gXCIke25ld1N0YXR1c31cIiBmb3IgJHtzZWxlY3RlZEl0ZW1zLmxlbmd0aH0gYXVjdGlvbihzKS4gQXJlIHlvdSBzdXJlP2AsXHJcbi8vICAgICAgIG9rVGV4dDogXCJZZXMsIFVwZGF0ZVwiLFxyXG4vLyAgICAgICBjYW5jZWxUZXh0OiBcIk5vXCIsXHJcbi8vICAgICAgIG9uT2s6IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgICB0cnkge1xyXG4vLyAgICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoXHJcbi8vICAgICAgICAgICAgIHNlbGVjdGVkSXRlbXMubWFwKChpdGVtKSA9PlxyXG4vLyAgICAgICAgICAgICAgIHVwZGF0ZUF1Y3Rpb25TdGF0dXMoaXRlbS5faWQsIG5ld1N0YXR1cyksXHJcbi8vICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgbWVzc2FnZS5zdWNjZXNzKFxyXG4vLyAgICAgICAgICAgICBgJHtzZWxlY3RlZEl0ZW1zLmxlbmd0aH0gYXVjdGlvbnMgbW92ZWQgdG8gJHtuZXdTdGF0dXN9YCxcclxuLy8gICAgICAgICAgICk7XHJcbi8vICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHNvbWUgYXVjdGlvbnNcIik7XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gQnVsayBkZWxldGVcclxuLy8gICBjb25zdCBoYW5kbGVCdWxrRGVsZXRlID0gKCkgPT4ge1xyXG4vLyAgICAgY29uc3Qgc2VsZWN0ZWRJdGVtcyA9IGZpbHRlcmVkQXVjdGlvbnMuZmlsdGVyKFxyXG4vLyAgICAgICAoaXRlbSkgPT4gYWN0aXZlVXNlckRhdGFbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXMsXHJcbi8vICAgICApO1xyXG5cclxuLy8gICAgIGlmIChzZWxlY3RlZEl0ZW1zLmxlbmd0aCA9PT0gMCkge1xyXG4vLyAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGF1Y3Rpb25zIHRvIGRlbGV0ZVwiKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIE1vZGFsLmNvbmZpcm0oe1xyXG4vLyAgICAgICB0aXRsZTogYERlbGV0ZSBDb25maXJtYXRpb25gLFxyXG4vLyAgICAgICBjb250ZW50OiBgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSBhdWN0aW9uKHMpPyBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLmAsXHJcbi8vICAgICAgIG9rVGV4dDogXCJZZXMsIERlbGV0ZVwiLFxyXG4vLyAgICAgICBva1R5cGU6IFwiZGFuZ2VyXCIsXHJcbi8vICAgICAgIGNhbmNlbFRleHQ6IFwiTm9cIixcclxuLy8gICAgICAgb25PazogYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChcclxuLy8gICAgICAgICAgICAgc2VsZWN0ZWRJdGVtcy5tYXAoKGl0ZW0pID0+IGhhbmRsZURlbGV0ZUF1Y3Rpb24oaXRlbS5faWQpKSxcclxuLy8gICAgICAgICAgICk7XHJcbi8vICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXHJcbi8vICAgICAgICAgICAgIGAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSBhdWN0aW9ucyBkZWxldGVkIHN1Y2Nlc3NmdWxseWAsXHJcbi8vICAgICAgICAgICApO1xyXG4vLyAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGRlbGV0ZSBzb21lIGF1Y3Rpb25zXCIpO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSxcclxuLy8gICAgIH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGdldFN0YXR1c1RhZyA9IChzdGF0dXMsIHBlcmNlbnRhZ2UgPSBudWxsKSA9PiB7XHJcbi8vICAgICBjb25zdCBiYXNlQ2xhc3MgPVxyXG4vLyAgICAgICBcImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweC0zIHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSByb3VuZGVkLWZ1bGwgd2hpdGVzcGFjZS1ub3dyYXAgbWluLXctWzEyMHB4XVwiO1xyXG5cclxuLy8gICAgIHN3aXRjaCAoc3RhdHVzKSB7XHJcbi8vICAgICAgIGNhc2UgXCJQZW5kaW5nXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7YmFzZUNsYXNzfSBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwYH0+XHJcbi8vICAgICAgICAgICAgIFBlbmRpbmdcclxuLy8gICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICApO1xyXG5cclxuLy8gICAgICAgY2FzZSBcIkRvY3VtZW50IENvbGxlY3Rpb25cIjpcclxuLy8gICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake2Jhc2VDbGFzc30gYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy03MDBgfT5cclxuLy8gICAgICAgICAgICAgICBET0MgQ29sbGVjdGlvblxyXG4vLyAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIHtwZXJjZW50YWdlICE9PSBudWxsICYmIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8UHJvZ3Jlc3NcclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cImNpcmNsZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBlcmNlbnQ9e3BlcmNlbnRhZ2V9XHJcbi8vICAgICAgICAgICAgICAgICAgIHdpZHRoPXs0MH1cclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlQ29sb3I9e1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBlcmNlbnRhZ2UgPT09IDEwMFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPyBcIiM1MmM0MWFcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBwZXJjZW50YWdlID49IDcwXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgID8gXCIjZmFhZDE0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgOiBcIiNmZjRkNGZcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIGZvcm1hdD17KHBlcmNlbnQpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZFwiPntwZXJjZW50fSU8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgIGNhc2UgXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIjpcclxuLy8gICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHtiYXNlQ2xhc3N9IGJnLWJsdWUtMTAwIHRleHQtYmx1ZS03MDBgfT5cclxuLy8gICAgICAgICAgICAgRE9DIFZlcmlmaWNhdGlvblxyXG4vLyAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICk7XHJcblxyXG4vLyAgICAgICBjYXNlIFwiQ29tcGxldGVkXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7YmFzZUNsYXNzfSBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDBgfT5cclxuLy8gICAgICAgICAgICAgQ29tcGxldGVkXHJcbi8vICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgIGRlZmF1bHQ6XHJcbi8vICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7YmFzZUNsYXNzfSBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNTAwYH0+XHJcbi8vICAgICAgICAgICAgIHtzdGF0dXN9XHJcbi8vICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBIYW5kbGUgcHJldmlldyBpbWFnZVxyXG4vLyAgIGNvbnN0IGhhbmRsZVByZXZpZXcgPSAoaW1hZ2VVcmwsIHRpdGxlKSA9PiB7XHJcbi8vICAgICBzZXRQcmV2aWV3SW1hZ2UoaW1hZ2VVcmwpO1xyXG4vLyAgICAgc2V0UHJldmlld1RpdGxlKHRpdGxlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVDYW5jZWxQcmV2aWV3ID0gKCkgPT4ge1xyXG4vLyAgICAgc2V0UHJldmlld0ltYWdlKG51bGwpO1xyXG4vLyAgICAgc2V0UHJldmlld1RpdGxlKFwiXCIpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVBheW91dCA9IChhdWN0aW9uSWQpID0+IHtcclxuLy8gICAgIHNldFBlbmRpbmdQYXlvdXRJZChhdWN0aW9uSWQpO1xyXG4vLyAgICAgc2V0U2hvd1BheW91dFBhc3N3b3JkKHRydWUpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIEhhbmRsZSBtb2RhbCBjbG9zZVxyXG4vLyAgIGNvbnN0IGhhbmRsZVBheW91dE1vZGFsQ2xvc2UgPSAoKSA9PiB7XHJcbi8vICAgICBzZXRTaG93UGF5b3V0UGFzc3dvcmQoZmFsc2UpO1xyXG4vLyAgICAgc2V0UGVuZGluZ1BheW91dElkKG51bGwpO1xyXG4vLyAgIH07XHJcblxyXG4vLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKTtcclxuLy8gICBpZiAocGFyYW1zLmdldChcIm9wZW5Nb2RhbFwiKSA9PT0gXCJ0cnVlXCIpIHtcclxuLy8gICAgIGNvbnN0IHVzZXJJZCA9IHBhcmFtcy5nZXQoXCJ1c2VySWRcIik7XHJcbi8vICAgICBpZiAodXNlcklkKSB7XHJcbi8vICAgICAgIC8vIE9wZW4gdGhlIGVkaXQgbW9kYWwgZm9yIHRoZSBzcGVjaWZpYyB1c2VyXHJcbi8vICAgICAgIGhhbmRsZVVwZGF0ZU1vZGFsT3Blbih1c2VySWQpO1xyXG4vLyAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgLy8gUmVtb3ZlIHRoZSBxdWVyeSBwYXJhbWV0ZXIgZnJvbSB0aGUgVVJMIHRvIHByZXZlbnQgcmXigJFvcGVuaW5nIG9uIHJlZnJlc2hcclxuLy8gICAgIHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSh7fSwgZG9jdW1lbnQudGl0bGUsIFwiL2N1c3RvbWVyLW1lbnUvdXNlclwiKTtcclxuLy8gICB9XHJcbi8vIH0sIFtsb2NhdGlvbl0pO1xyXG5cclxuLy8gICAvLyBGZXRjaCBhbGwgcHJvY2VzcyBkYXRhIGZyb20gQXVjdGlvbiBtb2RlbCB1c2luZyBzdGF0dXMgZmllbGRcclxuLy8gICBjb25zdCBmZXRjaFByb2Nlc3NEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuLy8gICB0cnkge1xyXG4vLyAgICAgLy8gRmV0Y2ggYWxsIGF1Y3Rpb25zIHdpdGggdGhlaXIgc3RhdHVzXHJcbi8vICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vYXVjdGlvbnMvYWxsLXBhZ2luYXRlZD9saW1pdD0xMDAwXCIpO1xyXG4vLyAgICAgY29uc3QgYXVjdGlvbnMgPSByZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuLy8gICAgIC8vIEZvciBEb2N1bWVudCBDb2xsZWN0aW9uIHRhYiAtIG5lZWQgdG8gZmV0Y2ggZG9jdW1lbnQgcGVyY2VudGFnZSBmb3IgZWFjaCBhdWN0aW9uXHJcbi8vICAgICBjb25zdCBkb2NDb2xsZWN0aW9uUHJvbWlzZXMgPSBhdWN0aW9uc1xyXG4vLyAgICAgICAuZmlsdGVyKGF1Y3Rpb24gPT4gYXVjdGlvbi5zdGF0dXMgPT09IFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiKVxyXG4vLyAgICAgICAubWFwKGFzeW5jIChhdWN0aW9uLCBpZHgpID0+IHtcclxuLy8gICAgICAgICBsZXQgZG9jdW1lbnRQZXJjZW50YWdlID0gMDtcclxuLy8gICAgICAgICBsZXQgZG9jdW1lbnRzID0gW107XHJcbiAgICAgICAgXHJcbi8vICAgICAgICAgLy8gRmV0Y2ggdXNlciBkb2N1bWVudHMgdG8gY2FsY3VsYXRlIHBlcmNlbnRhZ2VcclxuLy8gICAgICAgICBjb25zdCB1c2VySWQgPSBhdWN0aW9uLnVzZXJfaWQ/Ll9pZCB8fCBhdWN0aW9uLnVzZXJfaWQ7XHJcbi8vICAgICAgICAgaWYgKHVzZXJJZCkge1xyXG4vLyAgICAgICAgICAgdHJ5IHtcclxuLy8gICAgICAgICAgICAgY29uc3QgdXNlckRvY3NSZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vdXNlci1kb2N1bWVudHMvJHt1c2VySWR9YCk7XHJcbi8vICAgICAgICAgICAgIGlmICh1c2VyRG9jc1Jlcy5kYXRhICYmIHVzZXJEb2NzUmVzLmRhdGEuZGF0YSkge1xyXG4vLyAgICAgICAgICAgICAgIGxldCB1c2VyRG9jID0gdXNlckRvY3NSZXMuZGF0YS5kYXRhO1xyXG4vLyAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHVzZXJEb2MpICYmIHVzZXJEb2MubGVuZ3RoID4gMCkge1xyXG4vLyAgICAgICAgICAgICAgICAgdXNlckRvYyA9IHVzZXJEb2NbMF07XHJcbi8vICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgIGRvY3VtZW50cyA9IHRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5KHVzZXJEb2MpO1xyXG4vLyAgICAgICAgICAgICAgIGRvY3VtZW50UGVyY2VudGFnZSA9IGNhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZShkb2N1bWVudHMpO1xyXG4vLyAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgZG9jdW1lbnRzOlwiLCBlcnIpO1xyXG4vLyAgICAgICAgICAgfVxyXG4vLyAgICAgICAgIH1cclxuICAgICAgICBcclxuLy8gICAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgICAga2V5OiBhdWN0aW9uLl9pZCxcclxuLy8gICAgICAgICAgIGlkOiBpZHggKyAxLFxyXG4vLyAgICAgICAgICAgYXVjdGlvbl9jb2RlOiBhdWN0aW9uLmF1Y3Rpb25fY29kZSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgYXVjdGlvbl9kYXRlOiBhdWN0aW9uLmF1Y3Rpb25fZGF0ZT8uc3BsaXQoXCJUXCIpWzBdIHx8IGF1Y3Rpb24uYXVjdGlvbl9kYXRlLFxyXG4vLyAgICAgICAgICAgbmFtZTogYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICAgIHBob25lX251bWJlcjogYXVjdGlvbi51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICAgIGdyb3VwX25hbWU6IGF1Y3Rpb24uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiLCBkb2N1bWVudFBlcmNlbnRhZ2UpLFxyXG4vLyAgICAgICAgICAgdGltZTogYXVjdGlvbi51cGRhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgYXVjdGlvbl9pZDogYXVjdGlvbi5faWQsXHJcbi8vICAgICAgICAgICBhdWN0aW9uX2RhdGE6IGF1Y3Rpb24sXHJcbi8vICAgICAgICAgICBkb2N1bWVudDogKFxyXG4vLyAgICAgICAgICAgICA8QnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cImxpbmtcIlxyXG4vLyAgICAgICAgICAgICAgIGljb249ezxJb0V5ZSBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz59XHJcbi8vICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmlld0RvY3VtZW50cyhhdWN0aW9uLCBkb2N1bWVudHMpfVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgVmlld1xyXG4vLyAgICAgICAgICAgICA8L0J1dHRvbj5cclxuLy8gICAgICAgICAgICksXHJcbi8vICAgICAgICAgICBhY3Rpb246IChcclxuLy8gICAgICAgICAgICAgPERyb3Bkb3duXHJcbi8vICAgICAgICAgICAgICAgbWVudT17e1xyXG4vLyAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuLy8gICAgICAgICAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGtleTogXCI0XCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSBhdWN0aW9uLnVzZXJfaWQ/Ll9pZCB8fCBhdWN0aW9uLnVzZXJfaWQ7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVzZXJJZCkge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93Lm9wZW4oXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvY3VzdG9tZXItbWVudS91c2VyP29wZW5Nb2RhbD10cnVlJnVzZXJJZD0ke3VzZXJJZH1gLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIl9ibGFua1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIlVzZXIgSUQgbm90IGZvdW5kXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgS1lDIFVwbG9hZFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cub3BlbihcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvbGVnYWxzLW1lbnUvdXNlci1kb2N1bWVudD91c2VySWQ9JHthdWN0aW9uLnVzZXJfaWQ/Ll9pZH0mYXVjdGlvbklkPSR7YXVjdGlvbi5faWR9YCxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiX2JsYW5rXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgVXBsb2FkIERvY3VtZW50c1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUF1Y3Rpb25TdGF0dXMoYXVjdGlvbi5faWQsIFwiRG9jdW1lbnQgVmVyaWZpY2F0aW9uXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBWZXJpZmljYXRpb25cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlQXVjdGlvblN0YXR1cyhhdWN0aW9uLl9pZCwgXCJDb21wbGV0ZWRcIil9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIE1hcmsgQ29tcGxldGVkXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBcclxuLy8gICAgICAgICAgICAgICAgIF0sXHJcbi8vICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuLy8gICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuLy8gICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuLy8gICAgICAgICAgICksXHJcbi8vICAgICAgICAgfTtcclxuLy8gICAgICAgfSk7XHJcbiAgICBcclxuLy8gICAgIC8vIFdhaXQgZm9yIGFsbCBkb2N1bWVudCBwZXJjZW50YWdlIGNhbGN1bGF0aW9ucyB0byBjb21wbGV0ZVxyXG4vLyAgICAgY29uc3QgZG9jQ29sbGVjdGlvbiA9IGF3YWl0IFByb21pc2UuYWxsKGRvY0NvbGxlY3Rpb25Qcm9taXNlcyk7XHJcbiAgICBcclxuLy8gICAgIHNldERvY3VtZW50Q29sbGVjdGlvbkRhdGEoZG9jQ29sbGVjdGlvbik7XHJcbi8vICAgICBzZXRGaWx0ZXJlZERvY0NvbGxlY3Rpb24oZG9jQ29sbGVjdGlvbik7XHJcblxyXG4vLyAgICAgLy8gRG9jdW1lbnQgVmVyaWZpY2F0aW9uIHRhYiAtIEZldGNoIGRvY3VtZW50cyBmb3IgZWFjaCBhdWN0aW9uXHJcbi8vICAgICBjb25zdCBkb2NWZXJpZmljYXRpb25Qcm9taXNlcyA9IGF1Y3Rpb25zXHJcbi8vICAgICAgIC5maWx0ZXIoYXVjdGlvbiA9PiBhdWN0aW9uLnN0YXR1cyA9PT0gXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIilcclxuLy8gICAgICAgLm1hcChhc3luYyAoYXVjdGlvbiwgaWR4KSA9PiB7XHJcbi8vICAgICAgICAgbGV0IGRvY3VtZW50cyA9IFtdO1xyXG4gICAgICAgIFxyXG4vLyAgICAgICAgIC8vIEZldGNoIHVzZXIgZG9jdW1lbnRzXHJcbi8vICAgICAgICAgY29uc3QgdXNlcklkID0gYXVjdGlvbi51c2VyX2lkPy5faWQgfHwgYXVjdGlvbi51c2VyX2lkO1xyXG4vLyAgICAgICAgIGlmICh1c2VySWQpIHtcclxuLy8gICAgICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgICAgIGNvbnN0IHVzZXJEb2NzUmVzID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL3VzZXItZG9jdW1lbnRzLyR7dXNlcklkfWApO1xyXG4vLyAgICAgICAgICAgICBpZiAodXNlckRvY3NSZXMuZGF0YSAmJiB1c2VyRG9jc1Jlcy5kYXRhLmRhdGEpIHtcclxuLy8gICAgICAgICAgICAgICBsZXQgdXNlckRvYyA9IHVzZXJEb2NzUmVzLmRhdGEuZGF0YTtcclxuLy8gICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh1c2VyRG9jKSAmJiB1c2VyRG9jLmxlbmd0aCA+IDApIHtcclxuLy8gICAgICAgICAgICAgICAgIHVzZXJEb2MgPSB1c2VyRG9jWzBdO1xyXG4vLyAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICBkb2N1bWVudHMgPSB0cmFuc2Zvcm1Vc2VyRG9jdW1lbnRzVG9BcnJheSh1c2VyRG9jKTtcclxuLy8gICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRvY3VtZW50czpcIiwgZXJyKTtcclxuLy8gICAgICAgICAgIH1cclxuLy8gICAgICAgICB9XHJcbiAgICAgICAgXHJcbi8vICAgICAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgICAgIGtleTogYXVjdGlvbi5faWQsXHJcbi8vICAgICAgICAgICBpZDogaWR4ICsgMSxcclxuLy8gICAgICAgICAgIGF1Y3Rpb25fY29kZTogYXVjdGlvbi5hdWN0aW9uX2NvZGUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICAgIGF1Y3Rpb25fZGF0ZTogYXVjdGlvbi5hdWN0aW9uX2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBhdWN0aW9uLmF1Y3Rpb25fZGF0ZSxcclxuLy8gICAgICAgICAgIG5hbWU6IGF1Y3Rpb24udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICBwaG9uZV9udW1iZXI6IGF1Y3Rpb24udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICBncm91cF9uYW1lOiBhdWN0aW9uLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICBzdGF0dXM6IGdldFN0YXR1c1RhZyhcIkRvY3VtZW50IFZlcmlmaWNhdGlvblwiKSxcclxuLy8gICAgICAgICAgIHRpbWU6IGF1Y3Rpb24udXBkYXRlZEF0Py5zcGxpdChcIlRcIilbMF0gfHwgXCJOL0FcIixcclxuLy8gICAgICAgICAgIGF1Y3Rpb25faWQ6IGF1Y3Rpb24uX2lkLFxyXG4vLyAgICAgICAgICAgYXVjdGlvbl9kYXRhOiBhdWN0aW9uLFxyXG4vLyAgICAgICAgICBkb2N1bWVudDogKFxyXG4vLyAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4vLyAgICAgPEJ1dHRvblxyXG4vLyAgICAgICB0eXBlPVwibGlua1wiXHJcbi8vICAgICAgIGljb249ezxJb0V5ZSBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz59XHJcbi8vICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdEb2N1bWVudHMoYXVjdGlvbiwgZG9jdW1lbnRzKX1cclxuLy8gICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbi8vICAgICA+XHJcbi8vICAgICAgIFZpZXdcclxuLy8gICAgIDwvQnV0dG9uPlxyXG4vLyAgICAgPEJ1dHRvblxyXG4vLyAgICAgICB0eXBlPVwibGlua1wiXHJcbi8vICAgICAgIGljb249ezxJb0RvY3VtZW50IGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPn1cclxuLy8gICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgIGNvbnN0IHVzZXJJZCA9IGF1Y3Rpb24udXNlcl9pZD8uX2lkIHx8IGF1Y3Rpb24udXNlcl9pZDtcclxuLy8gICAgICAgICBpZiAodXNlcklkKSB7XHJcbi8vICAgICAgICAgICAgaGFuZGxlS3ljUHJldmlldyh1c2VySWQpO1xyXG4vLyAgICAgICAgIH0gZWxzZSB7XHJcbi8vICAgICAgICAgICBtZXNzYWdlLmVycm9yKFwiVXNlciBJRCBub3QgZm91bmRcIik7XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICB9fVxyXG4vLyAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbi8vICAgICA+XHJcbi8vICAgICAgIEtZQyBEZXRhaWxzXHJcbi8vICAgICA8L0J1dHRvbj5cclxuLy8gICA8L2Rpdj5cclxuLy8gKSxcclxuLy8gICAgICAgICAgIGFjdGlvbjogKFxyXG4vLyAgICAgICAgICAgICA8RHJvcGRvd25cclxuLy8gICAgICAgICAgICAgICBtZW51PXt7XHJcbi8vICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4vLyAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUF1Y3Rpb25TdGF0dXMoYXVjdGlvbi5faWQsIFwiQ29tcGxldGVkXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBWZXJpZmljYXRpb24gQ29tcGxldGVkXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgXSxcclxuLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4vLyAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQteGxcIiAvPlxyXG4vLyAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4vLyAgICAgICAgICAgKSxcclxuLy8gICAgICAgICB9O1xyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICBjb25zdCBkb2NWZXJpZmljYXRpb24gPSBhd2FpdCBQcm9taXNlLmFsbChkb2NWZXJpZmljYXRpb25Qcm9taXNlcyk7XHJcbi8vICAgICBzZXREb2N1bWVudFZlcmlmaWNhdGlvbkRhdGEoZG9jVmVyaWZpY2F0aW9uKTtcclxuLy8gICAgIHNldEZpbHRlcmVkRG9jVmVyaWZpY2F0aW9uKGRvY1ZlcmlmaWNhdGlvbik7XHJcblxyXG4vLyAgICAgLy8gQ29tcGxldGVkIHRhYiAtIE5PIGRvY3VtZW50IHZpZXcgYnV0dG9uXHJcbi8vICAgICBjb25zdCBjb21wbGV0ZWQgPSBhdWN0aW9uc1xyXG4vLyAgICAgICAuZmlsdGVyKGF1Y3Rpb24gPT4gYXVjdGlvbi5zdGF0dXMgPT09IFwiQ29tcGxldGVkXCIpXHJcbi8vICAgICAgIC5tYXAoKGF1Y3Rpb24sIGlkeCkgPT4gKHtcclxuLy8gICAgICAgICBrZXk6IGF1Y3Rpb24uX2lkLFxyXG4vLyAgICAgICAgIGlkOiBpZHggKyAxLFxyXG4vLyAgICAgICAgIGF1Y3Rpb25fY29kZTogYXVjdGlvbi5hdWN0aW9uX2NvZGUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICBhdWN0aW9uX2RhdGU6IGF1Y3Rpb24uYXVjdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgYXVjdGlvbi5hdWN0aW9uX2RhdGUsXHJcbi8vICAgICAgICAgbmFtZTogYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuLy8gICAgICAgICBwaG9uZV9udW1iZXI6IGF1Y3Rpb24udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgZ3JvdXBfbmFtZTogYXVjdGlvbi5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiQ29tcGxldGVkXCIpLFxyXG4vLyAgICAgICAgIHRpbWU6IGF1Y3Rpb24udXBkYXRlZEF0Py5zcGxpdChcIlRcIilbMF0gfHwgXCJOL0FcIixcclxuLy8gICAgICAgICBhY3Rpb246IChcclxuLy8gICAgICAgICAgIDxEcm9wZG93blxyXG4vLyAgICAgICAgICAgICBtZW51PXt7XHJcbi8vICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuLy8gICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuLy8gICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBheW91dChhdWN0aW9uLl9pZCl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgUGF5b3V0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgIF0sXHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4vLyAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQteGxcIiAvPlxyXG4vLyAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuLy8gICAgICAgICApLFxyXG4vLyAgICAgICB9KSk7XHJcblxyXG4vLyAgICAgc2V0Q29tcGxldGVkRGF0YShjb21wbGV0ZWQpO1xyXG4vLyAgICAgc2V0RmlsdGVyZWRDb21wbGV0ZWQoY29tcGxldGVkKTtcclxuICAgIFxyXG4vLyAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcHJvY2VzcyBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHByb2Nlc3MgZGF0YVwiKTtcclxuLy8gICB9IGZpbmFsbHkge1xyXG4vLyAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICB9XHJcbi8vIH07XHJcblxyXG4vLyAgIC8vIEZldGNoIGFsbCBwcm9jZXNzIGRhdGEgZnJvbSBBdWN0aW9uIG1vZGVsIHVzaW5nIHN0YXR1cyBmaWVsZFxyXG4vLyAgIC8vIGNvbnN0IGZldGNoUHJvY2Vzc0RhdGEgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgLy8gICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgLy8gICB0cnkge1xyXG4vLyAgIC8vICAgICAvLyBGZXRjaCBhbGwgYXVjdGlvbnMgd2l0aCB0aGVpciBzdGF0dXNcclxuLy8gICAvLyAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4vLyAgIC8vICAgICAgIFwiL3YxL2FkbWluL2F1Y3Rpb25zL2FsbC1wYWdpbmF0ZWQ/bGltaXQ9MTAwMFwiLFxyXG4vLyAgIC8vICAgICApO1xyXG4vLyAgIC8vICAgICBjb25zdCBhdWN0aW9ucyA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4vLyAgIC8vICAgICAvLyBGb3IgRG9jdW1lbnQgQ29sbGVjdGlvbiB0YWIgLSBuZWVkIHRvIGZldGNoIGRvY3VtZW50IHBlcmNlbnRhZ2UgZm9yIGVhY2ggYXVjdGlvblxyXG4vLyAgIC8vICAgICBjb25zdCBkb2NDb2xsZWN0aW9uUHJvbWlzZXMgPSBhdWN0aW9uc1xyXG4vLyAgIC8vICAgICAgIC5maWx0ZXIoKGF1Y3Rpb24pID0+IGF1Y3Rpb24uc3RhdHVzID09PSBcIkRvY3VtZW50IENvbGxlY3Rpb25cIilcclxuLy8gICAvLyAgICAgICAubWFwKGFzeW5jIChhdWN0aW9uLCBpZHgpID0+IHtcclxuLy8gICAvLyAgICAgICAgIGxldCBkb2N1bWVudFBlcmNlbnRhZ2UgPSAwO1xyXG4vLyAgIC8vICAgICAgICAgbGV0IGRvY3VtZW50cyA9IFtdO1xyXG5cclxuLy8gICAvLyAgICAgICAgIC8vIEZldGNoIHVzZXIgZG9jdW1lbnRzIHRvIGNhbGN1bGF0ZSBwZXJjZW50YWdlXHJcbi8vICAgLy8gICAgICAgICBjb25zdCB1c2VySWQgPSBhdWN0aW9uLnVzZXJfaWQ/Ll9pZCB8fCBhdWN0aW9uLnVzZXJfaWQ7XHJcbi8vICAgLy8gICAgICAgICBpZiAodXNlcklkKSB7XHJcbi8vICAgLy8gICAgICAgICAgIHRyeSB7XHJcbi8vICAgLy8gICAgICAgICAgICAgY29uc3QgdXNlckRvY3NSZXMgPSBhd2FpdCBhcGkuZ2V0KFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgYC92MS9hZG1pbi91c2VyLWRvY3VtZW50cy8ke3VzZXJJZH1gLFxyXG4vLyAgIC8vICAgICAgICAgICAgICk7XHJcbi8vICAgLy8gICAgICAgICAgICAgaWYgKHVzZXJEb2NzUmVzLmRhdGEgJiYgdXNlckRvY3NSZXMuZGF0YS5kYXRhKSB7XHJcbi8vICAgLy8gICAgICAgICAgICAgICBsZXQgdXNlckRvYyA9IHVzZXJEb2NzUmVzLmRhdGEuZGF0YTtcclxuLy8gICAvLyAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHVzZXJEb2MpICYmIHVzZXJEb2MubGVuZ3RoID4gMCkge1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICB1c2VyRG9jID0gdXNlckRvY1swXTtcclxuLy8gICAvLyAgICAgICAgICAgICAgIH1cclxuLy8gICAvLyAgICAgICAgICAgICAgIGRvY3VtZW50cyA9IHRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5KHVzZXJEb2MpO1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgZG9jdW1lbnRQZXJjZW50YWdlID0gY2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGRvY3VtZW50cyk7XHJcbi8vICAgLy8gICAgICAgICAgICAgfVxyXG4vLyAgIC8vICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAvLyAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkb2N1bWVudHM6XCIsIGVycik7XHJcbi8vICAgLy8gICAgICAgICAgIH1cclxuLy8gICAvLyAgICAgICAgIH1cclxuXHJcbi8vICAgLy8gICAgICAgICByZXR1cm4ge1xyXG4vLyAgIC8vICAgICAgICAgICBrZXk6IGF1Y3Rpb24uX2lkLFxyXG4vLyAgIC8vICAgICAgICAgICBpZDogaWR4ICsgMSxcclxuLy8gICAvLyAgICAgICAgICAgYXVjdGlvbl9jb2RlOiBhdWN0aW9uLmF1Y3Rpb25fY29kZSB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgICBhdWN0aW9uX2RhdGU6XHJcbi8vICAgLy8gICAgICAgICAgICAgYXVjdGlvbi5hdWN0aW9uX2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBhdWN0aW9uLmF1Y3Rpb25fZGF0ZSxcclxuLy8gICAvLyAgICAgICAgICAgbmFtZTogYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuLy8gICAvLyAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgICBncm91cF9uYW1lOiBhdWN0aW9uLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiLCBkb2N1bWVudFBlcmNlbnRhZ2UpLFxyXG4vLyAgIC8vICAgICAgICAgICB0aW1lOiBhdWN0aW9uLnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICAgIGF1Y3Rpb25faWQ6IGF1Y3Rpb24uX2lkLFxyXG4vLyAgIC8vICAgICAgICAgICBhdWN0aW9uX2RhdGE6IGF1Y3Rpb24sXHJcbi8vICAgLy8gICAgICAgICAgIGRvY3VtZW50OiAoXHJcbi8vICAgLy8gICAgICAgICAgICAgPEJ1dHRvblxyXG4vLyAgIC8vICAgICAgICAgICAgICAgdHlwZT1cImxpbmtcIlxyXG4vLyAgIC8vICAgICAgICAgICAgICAgaWNvbj17PElvRXllIGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPn1cclxuLy8gICAvLyAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdEb2N1bWVudHMoYXVjdGlvbiwgZG9jdW1lbnRzKX1cclxuLy8gICAvLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4vLyAgIC8vICAgICAgICAgICAgID5cclxuLy8gICAvLyAgICAgICAgICAgICAgIFZpZXdcclxuLy8gICAvLyAgICAgICAgICAgICA8L0J1dHRvbj5cclxuLy8gICAvLyAgICAgICAgICAgKSxcclxuLy8gICAvLyAgICAgICAgICAgYWN0aW9uOiAoXHJcbi8vICAgLy8gICAgICAgICAgICAgPERyb3Bkb3duXHJcbi8vICAgLy8gICAgICAgICAgICAgICBtZW51PXt7XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAge1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93Lm9wZW4oXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvbGVnYWxzLW1lbnUvdXNlci1kb2N1bWVudD91c2VySWQ9JHthdWN0aW9uLnVzZXJfaWQ/Ll9pZH0mYXVjdGlvbklkPSR7YXVjdGlvbi5faWR9YCxcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJfYmxhbmtcIixcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgVXBsb2FkIERvY3VtZW50c1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAge1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDBcIlxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVBdWN0aW9uU3RhdHVzKFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdWN0aW9uLl9pZCxcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIixcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICBWZXJpZmljYXRpb25cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAge1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUF1Y3Rpb25TdGF0dXMoYXVjdGlvbi5faWQsIFwiQ29tcGxldGVkXCIpXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgTWFyayBDb21wbGV0ZWRcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgIF0sXHJcbi8vICAgLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgIC8vICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbi8vICAgLy8gICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuLy8gICAvLyAgICAgICAgICAgICA+XHJcbi8vICAgLy8gICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgdGV4dC14bFwiIC8+XHJcbi8vICAgLy8gICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuLy8gICAvLyAgICAgICAgICAgKSxcclxuLy8gICAvLyAgICAgICAgIH07XHJcbi8vICAgLy8gICAgICAgfSk7XHJcblxyXG4vLyAgIC8vICAgICAvLyBXYWl0IGZvciBhbGwgZG9jdW1lbnQgcGVyY2VudGFnZSBjYWxjdWxhdGlvbnMgdG8gY29tcGxldGVcclxuLy8gICAvLyAgICAgY29uc3QgZG9jQ29sbGVjdGlvbiA9IGF3YWl0IFByb21pc2UuYWxsKGRvY0NvbGxlY3Rpb25Qcm9taXNlcyk7XHJcblxyXG4vLyAgIC8vICAgICBzZXREb2N1bWVudENvbGxlY3Rpb25EYXRhKGRvY0NvbGxlY3Rpb24pO1xyXG4vLyAgIC8vICAgICBzZXRGaWx0ZXJlZERvY0NvbGxlY3Rpb24oZG9jQ29sbGVjdGlvbik7XHJcblxyXG4vLyAgIC8vICAgICAvLyBEb2N1bWVudCBWZXJpZmljYXRpb24gdGFiIChubyBwZXJjZW50YWdlIG5lZWRlZClcclxuLy8gICAvLyAgICAgY29uc3QgZG9jVmVyaWZpY2F0aW9uID0gYXVjdGlvbnNcclxuLy8gICAvLyAgICAgICAuZmlsdGVyKChhdWN0aW9uKSA9PiBhdWN0aW9uLnN0YXR1cyA9PT0gXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIilcclxuLy8gICAvLyAgICAgICAubWFwKChhdWN0aW9uLCBpZHgpID0+ICh7XHJcbi8vICAgLy8gICAgICAgICBrZXk6IGF1Y3Rpb24uX2lkLFxyXG4vLyAgIC8vICAgICAgICAgaWQ6IGlkeCArIDEsXHJcbi8vICAgLy8gICAgICAgICBhdWN0aW9uX2NvZGU6IGF1Y3Rpb24uYXVjdGlvbl9jb2RlIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICBhdWN0aW9uX2RhdGU6XHJcbi8vICAgLy8gICAgICAgICAgIGF1Y3Rpb24uYXVjdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgYXVjdGlvbi5hdWN0aW9uX2RhdGUsXHJcbi8vICAgLy8gICAgICAgICBuYW1lOiBhdWN0aW9uLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgcGhvbmVfbnVtYmVyOiBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgZ3JvdXBfbmFtZTogYXVjdGlvbi5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgc3RhdHVzOiBnZXRTdGF0dXNUYWcoXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIiksXHJcbi8vICAgLy8gICAgICAgICB0aW1lOiBhdWN0aW9uLnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICBhdWN0aW9uX2lkOiBhdWN0aW9uLl9pZCxcclxuLy8gICAvLyAgICAgICAgIGRvY3VtZW50OiAoXHJcbi8vICAgLy8gICAgICAgICAgIDxCdXR0b25cclxuLy8gICAvLyAgICAgICAgICAgICB0eXBlPVwibGlua1wiXHJcbi8vICAgLy8gICAgICAgICAgICAgaWNvbj17PElvRXllIGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPn1cclxuLy8gICAvLyAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVWaWV3RG9jdW1lbnRzKGF1Y3Rpb24sIGRvY3VtZW50cyl9XHJcbi8vICAgLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbi8vICAgLy8gICAgICAgICAgID5cclxuLy8gICAvLyAgICAgICAgICAgICBWaWV3XHJcbi8vICAgLy8gICAgICAgICAgIDwvQnV0dG9uPlxyXG4vLyAgIC8vICAgICAgICAgKSxcclxuLy8gICAvLyAgICAgICAgIGFjdGlvbjogKFxyXG4vLyAgIC8vICAgICAgICAgICA8RHJvcGRvd25cclxuLy8gICAvLyAgICAgICAgICAgICBtZW51PXt7XHJcbi8vICAgLy8gICAgICAgICAgICAgICBpdGVtczogW1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICB7XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlQXVjdGlvblN0YXR1cyhhdWN0aW9uLl9pZCwgXCJDb21wbGV0ZWRcIilcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgICBWZXJpZmljYXRpb24gQ29tcGxldGVkXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAvLyB7XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgIC8vICAga2V5OiBcIjJcIixcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgLy8gICBsYWJlbDogKFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAvLyAgICAgPGRpdlxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAvLyAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgLy8gICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUGF5b3V0KGF1Y3Rpb24uX2lkKX1cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgLy8gICAgID5cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgLy8gICAgICAgUGF5b3V0XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgIC8vICAgICA8L2Rpdj5cclxuLy8gICAvLyAgICAgICAgICAgICAgICAgLy8gICApLFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAvLyB9LFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgXSxcclxuLy8gICAvLyAgICAgICAgICAgICB9fVxyXG4vLyAgIC8vICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4vLyAgIC8vICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4vLyAgIC8vICAgICAgICAgICA+XHJcbi8vICAgLy8gICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQteGxcIiAvPlxyXG4vLyAgIC8vICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4vLyAgIC8vICAgICAgICAgKSxcclxuLy8gICAvLyAgICAgICB9KSk7XHJcblxyXG4vLyAgIC8vICAgICBzZXREb2N1bWVudFZlcmlmaWNhdGlvbkRhdGEoZG9jVmVyaWZpY2F0aW9uKTtcclxuLy8gICAvLyAgICAgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb24oZG9jVmVyaWZpY2F0aW9uKTtcclxuXHJcbi8vICAgLy8gICAgIC8vIENvbXBsZXRlZCB0YWJcclxuLy8gICAvLyAgICAgY29uc3QgY29tcGxldGVkID0gYXVjdGlvbnNcclxuLy8gICAvLyAgICAgICAuZmlsdGVyKChhdWN0aW9uKSA9PiBhdWN0aW9uLnN0YXR1cyA9PT0gXCJDb21wbGV0ZWRcIilcclxuLy8gICAvLyAgICAgICAubWFwKChhdWN0aW9uLCBpZHgpID0+ICh7XHJcbi8vICAgLy8gICAgICAgICBrZXk6IGF1Y3Rpb24uX2lkLFxyXG4vLyAgIC8vICAgICAgICAgaWQ6IGlkeCArIDEsXHJcbi8vICAgLy8gICAgICAgICBhdWN0aW9uX2NvZGU6IGF1Y3Rpb24uYXVjdGlvbl9jb2RlIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICBhdWN0aW9uX2RhdGU6XHJcbi8vICAgLy8gICAgICAgICAgIGF1Y3Rpb24uYXVjdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgYXVjdGlvbi5hdWN0aW9uX2RhdGUsXHJcbi8vICAgLy8gICAgICAgICBuYW1lOiBhdWN0aW9uLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgcGhvbmVfbnVtYmVyOiBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgZ3JvdXBfbmFtZTogYXVjdGlvbi5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgIC8vICAgICAgICAgc3RhdHVzOiBnZXRTdGF0dXNUYWcoXCJDb21wbGV0ZWRcIiksXHJcbi8vICAgLy8gICAgICAgICB0aW1lOiBhdWN0aW9uLnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgICBhY3Rpb246IChcclxuLy8gICAvLyAgICAgICAgICAgPERyb3Bkb3duXHJcbi8vICAgLy8gICAgICAgICAgICAgbWVudT17e1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuLy8gICAvLyAgICAgICAgICAgICAgICAge1xyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBheW91dChhdWN0aW9uLl9pZCl9XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgICAgIFBheW91dFxyXG4vLyAgIC8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgLy8gICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAvLyAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAvLyAgICAgICAgICAgICAgIF0sXHJcbi8vICAgLy8gICAgICAgICAgICAgfX1cclxuLy8gICAvLyAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuLy8gICAvLyAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuLy8gICAvLyAgICAgICAgICAgPlxyXG4vLyAgIC8vICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuLy8gICAvLyAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuLy8gICAvLyAgICAgICAgICksXHJcbi8vICAgLy8gICAgICAgfSkpO1xyXG5cclxuLy8gICAvLyAgICAgc2V0Q29tcGxldGVkRGF0YShjb21wbGV0ZWQpO1xyXG4vLyAgIC8vICAgICBzZXRGaWx0ZXJlZENvbXBsZXRlZChjb21wbGV0ZWQpO1xyXG4vLyAgIC8vICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAvLyAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHByb2Nlc3MgZGF0YTpcIiwgZXJyb3IpO1xyXG4vLyAgIC8vICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHByb2Nlc3MgZGF0YVwiKTtcclxuLy8gICAvLyAgIH0gZmluYWxseSB7XHJcbi8vICAgLy8gICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgLy8gICB9XHJcbi8vICAgLy8gfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlRGF0ZUZpbHRlciA9IChkYXRlcykgPT4ge1xyXG4vLyAgICAgaWYgKCFkYXRlcyB8fCAhZGF0ZXNbMF0gfHwgIWRhdGVzWzFdKSB7XHJcbi8vICAgICAgIHNldERhdGVSYW5nZShbbnVsbCwgbnVsbF0pO1xyXG4vLyAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb25zKGFsbFJlY2VudEF1Y3Rpb25zKTtcclxuLy8gICAgICAgc2V0RmlsdGVyZWREb2NDb2xsZWN0aW9uKGRvY3VtZW50Q29sbGVjdGlvbkRhdGEpO1xyXG4vLyAgICAgICBzZXRGaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbihkb2N1bWVudFZlcmlmaWNhdGlvbkRhdGEpO1xyXG4vLyAgICAgICBzZXRGaWx0ZXJlZENvbXBsZXRlZChjb21wbGV0ZWREYXRhKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIHNldERhdGVSYW5nZShkYXRlcyk7XHJcbi8vICAgICBjb25zdCBbc3RhcnQsIGVuZF0gPSBkYXRlcztcclxuXHJcbi8vICAgICBjb25zdCBmaWx0ZXJlZFJlY2VudCA9IGZpbHRlckRhdGFCeURhdGUoYWxsUmVjZW50QXVjdGlvbnMsIGRhdGVzKTtcclxuLy8gICAgIGNvbnN0IGZpbHRlcmVkQ29sbGVjdGlvbiA9IGZpbHRlckRhdGFCeURhdGUoZG9jdW1lbnRDb2xsZWN0aW9uRGF0YSwgZGF0ZXMpO1xyXG4vLyAgICAgY29uc3QgZmlsdGVyZWRWZXJpZmljYXRpb24gPSBmaWx0ZXJEYXRhQnlEYXRlKFxyXG4vLyAgICAgICBkb2N1bWVudFZlcmlmaWNhdGlvbkRhdGEsXHJcbi8vICAgICAgIGRhdGVzLFxyXG4vLyAgICAgKTtcclxuLy8gICAgIGNvbnN0IGZpbHRlcmVkQ29tcGxldGVkRGF0YSA9IGZpbHRlckRhdGFCeURhdGUoY29tcGxldGVkRGF0YSwgZGF0ZXMpO1xyXG5cclxuLy8gICAgIHNldEZpbHRlcmVkQXVjdGlvbnMoZmlsdGVyZWRSZWNlbnQpO1xyXG4vLyAgICAgc2V0RmlsdGVyZWREb2NDb2xsZWN0aW9uKGZpbHRlcmVkQ29sbGVjdGlvbik7XHJcbi8vICAgICBzZXRGaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbihmaWx0ZXJlZFZlcmlmaWNhdGlvbik7XHJcbi8vICAgICBzZXRGaWx0ZXJlZENvbXBsZXRlZChmaWx0ZXJlZENvbXBsZXRlZERhdGEpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZpbHRlckRhdGFCeURhdGUgPSAoZGF0YSwgZGF0ZXMpID0+IHtcclxuLy8gICAgIGlmICghZGF0ZXMgfHwgIWRhdGVzWzBdIHx8ICFkYXRlc1sxXSkgcmV0dXJuIGRhdGE7XHJcblxyXG4vLyAgICAgY29uc3QgW3N0YXJ0LCBlbmRdID0gZGF0ZXM7XHJcblxyXG4vLyAgICAgcmV0dXJuIGRhdGEuZmlsdGVyKChpdGVtKSA9PiB7XHJcbi8vICAgICAgIGxldCBpdGVtRGF0ZSA9IGl0ZW0uYXVjdGlvbl9kYXRlIHx8IGl0ZW0udGltZTtcclxuLy8gICAgICAgaWYgKCFpdGVtRGF0ZSkgcmV0dXJuIHRydWU7XHJcblxyXG4vLyAgICAgICBpZiAodHlwZW9mIGl0ZW1EYXRlID09PSBcInN0cmluZ1wiICYmIGl0ZW1EYXRlLmluY2x1ZGVzKFwiVFwiKSkge1xyXG4vLyAgICAgICAgIGl0ZW1EYXRlID0gaXRlbURhdGUuc3BsaXQoXCJUXCIpWzBdO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBjb25zdCBhdWN0aW9uRGF0ZSA9IGRheWpzKGl0ZW1EYXRlKTtcclxuLy8gICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICBhdWN0aW9uRGF0ZS5pc0FmdGVyKHN0YXJ0LnN1YnRyYWN0KDEsIFwiZGF5XCIpKSAmJlxyXG4vLyAgICAgICAgIGF1Y3Rpb25EYXRlLmlzQmVmb3JlKGVuZC5hZGQoMSwgXCJkYXlcIikpXHJcbi8vICAgICAgICk7XHJcbi8vICAgICB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBIYW5kbGUgdmlldyBkb2N1bWVudHNcclxuLy8gICBjb25zdCBoYW5kbGVWaWV3RG9jdW1lbnRzID0gYXN5bmMgKGF1Y3Rpb25EYXRhLCBleGlzdGluZ0RvY3VtZW50cyA9IG51bGwpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGxldCBkb2N1bWVudHMgPSBleGlzdGluZ0RvY3VtZW50cztcclxuXHJcbi8vICAgICAgIGlmICghZG9jdW1lbnRzKSB7XHJcbi8vICAgICAgICAgY29uc3QgdXNlcklkID0gYXVjdGlvbkRhdGE/LnVzZXJfaWQ/Ll9pZCB8fCBhdWN0aW9uRGF0YT8udXNlcl9pZDtcclxuXHJcbi8vICAgICAgICAgaWYgKCF1c2VySWQpIHtcclxuLy8gICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyB1c2VyX2lkIGZvdW5kIGZvciB0aGlzIGF1Y3Rpb25cIik7XHJcbi8vICAgICAgICAgICBtZXNzYWdlLmVycm9yKFwiQ3VzdG9tZXIgaW5mb3JtYXRpb24gbm90IGZvdW5kXCIpO1xyXG4vLyAgICAgICAgICAgcmV0dXJuO1xyXG4vLyAgICAgICAgIH1cclxuXHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vdXNlci1kb2N1bWVudHMvJHt1c2VySWR9YCk7XHJcblxyXG4vLyAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuZGF0YSkge1xyXG4vLyAgICAgICAgICAgbGV0IHVzZXJEb2MgPSByZXNwb25zZS5kYXRhLmRhdGE7XHJcbi8vICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh1c2VyRG9jKSAmJiB1c2VyRG9jLmxlbmd0aCA+IDApIHtcclxuLy8gICAgICAgICAgICAgdXNlckRvYyA9IHVzZXJEb2NbMF07XHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICBkb2N1bWVudHMgPSB0cmFuc2Zvcm1Vc2VyRG9jdW1lbnRzVG9BcnJheSh1c2VyRG9jKTtcclxuLy8gICAgICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICAgICAgZG9jdW1lbnRzID0gW107XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBzZXRDdXJyZW50RG9jdW1lbnRzKGRvY3VtZW50cyk7XHJcbi8vICAgICAgIHNldEN1cnJlbnRBdWN0aW9uRm9yRG9jcyhhdWN0aW9uRGF0YSk7XHJcbi8vICAgICAgIHNldFNob3dEb2N1bWVudE1vZGFsKHRydWUpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRvY3VtZW50czpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGRvY3VtZW50c1wiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCB0cmFuc2Zvcm1Vc2VyRG9jdW1lbnRzVG9BcnJheSA9ICh1c2VyRG9jKSA9PiB7XHJcbi8vICAgICBpZiAoIXVzZXJEb2MpIHJldHVybiBbXTtcclxuXHJcbi8vICAgICBjb25zdCBkb2N1bWVudHMgPSBbXTtcclxuXHJcbi8vICAgICBjb25zdCBkb2NNYXBwaW5ncyA9IFtcclxuLy8gICAgICAgeyBrZXk6IFwidXNlcl9wcm9maWxlX3Bob3RvXCIsIGxhYmVsOiBcIlBob3RvXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCJ1c2VyX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLFxyXG4vLyAgICAgICAgIGxhYmVsOiBcIkFhZGhhciBDYXJkIChGcm9udClcIixcclxuLy8gICAgICAgICBpc0ltYWdlOiB0cnVlLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICB7XHJcbi8vICAgICAgICAga2V5OiBcInVzZXJfYWRoYXJjYXJkX2JhY2tfcGhvdG9cIixcclxuLy8gICAgICAgICBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoQmFjaylcIixcclxuLy8gICAgICAgICBpc0ltYWdlOiB0cnVlLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICB7IGtleTogXCJ1c2VyX3BhbmNhcmRfcGhvdG9cIiwgbGFiZWw6IFwiUEFOIENhcmRcIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4vLyAgICAgICB7IGtleTogXCJ1c2VyX2NoZXF1ZV9sZWFmXCIsIGxhYmVsOiBcIkNoZXF1ZSBMZWFmXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuLy8gICAgICAgeyBrZXk6IFwiYmFua19zdGF0ZW1lbnRfbW9udGhcIiwgbGFiZWw6IFwiQmFuayBTdGF0ZW1lbnRcIiwgaXNJbWFnZTogZmFsc2UgfSxcclxuLy8gICAgICAgeyBrZXk6IFwiYmFua19wYXNzYm9va19waG90b1wiLCBsYWJlbDogXCJQYXNzYm9vayBQaG90b1wiLCBpc0ltYWdlOiB0cnVlIH0sXHJcbi8vICAgICAgIHtcclxuLy8gICAgICAgICBrZXk6IFwiYnVzaW5lc3NfZG9jdW1lbnRfcHJvb2ZcIixcclxuLy8gICAgICAgICBsYWJlbDogXCJCdXNpbmVzcyBQcm9vZlwiLFxyXG4vLyAgICAgICAgIGlzSW1hZ2U6IGZhbHNlLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICB7IGtleTogXCJ1c2VyX3NhbGFyeV9zbGlwXCIsIGxhYmVsOiBcIlNhbGFyeSBTbGlwXCIsIGlzSW1hZ2U6IGZhbHNlIH0sXHJcbi8vICAgICAgIHtcclxuLy8gICAgICAgICBrZXk6IFwidXNlcl9ub21pbmVlX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLFxyXG4vLyAgICAgICAgIGxhYmVsOiBcIk5vbWluZWUgQWFkaGFyIChGcm9udClcIixcclxuLy8gICAgICAgICBpc0ltYWdlOiB0cnVlLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICB7XHJcbi8vICAgICAgICAga2V5OiBcInVzZXJfbm9taW5lZV9hZGhhcmNhcmRfYmFja19waG90b1wiLFxyXG4vLyAgICAgICAgIGxhYmVsOiBcIk5vbWluZWUgQWFkaGFyIChCYWNrKVwiLFxyXG4vLyAgICAgICAgIGlzSW1hZ2U6IHRydWUsXHJcbi8vICAgICAgIH0sXHJcbi8vICAgICAgIHtcclxuLy8gICAgICAgICBrZXk6IFwidXNlcl9ub21pbmVlX3BhbmNhcmRfcGhvdG9cIixcclxuLy8gICAgICAgICBsYWJlbDogXCJOb21pbmVlIFBBTiBDYXJkXCIsXHJcbi8vICAgICAgICAgaXNJbWFnZTogdHJ1ZSxcclxuLy8gICAgICAgfSxcclxuLy8gICAgIF07XHJcblxyXG4vLyAgICAgZG9jTWFwcGluZ3MuZm9yRWFjaCgobWFwcGluZykgPT4ge1xyXG4vLyAgICAgICBpZiAodXNlckRvY1ttYXBwaW5nLmtleV0pIHtcclxuLy8gICAgICAgICBkb2N1bWVudHMucHVzaCh7XHJcbi8vICAgICAgICAgICBkb2N1bWVudF90eXBlOiBtYXBwaW5nLmxhYmVsLFxyXG4vLyAgICAgICAgICAgZmlsZV91cmw6IHVzZXJEb2NbbWFwcGluZy5rZXldLFxyXG4vLyAgICAgICAgICAgZGVzY3JpcHRpb246IGAke21hcHBpbmcubGFiZWx9IGRvY3VtZW50YCxcclxuLy8gICAgICAgICAgIGlzSW1hZ2U6IG1hcHBpbmcuaXNJbWFnZSxcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSk7XHJcblxyXG4vLyAgICAgaWYgKHVzZXJEb2MudXNlcl9kb2N1bWVudF9jb2RlKSB7XHJcbi8vICAgICAgIGRvY3VtZW50cy5wdXNoKHtcclxuLy8gICAgICAgICBkb2N1bWVudF90eXBlOiBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4vLyAgICAgICAgIGZpbGVfdXJsOiBudWxsLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBgRG9jdW1lbnQgQ29kZTogJHt1c2VyRG9jLnVzZXJfZG9jdW1lbnRfY29kZX1gLFxyXG4vLyAgICAgICAgIGlzSW1hZ2U6IGZhbHNlLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICByZXR1cm4gZG9jdW1lbnRzO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGNhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZSA9IChkb2N1bWVudHMpID0+IHtcclxuLy8gICAgIGlmICghZG9jdW1lbnRzIHx8IGRvY3VtZW50cy5sZW5ndGggPT09IDApIHJldHVybiAwO1xyXG5cclxuLy8gICAgIGNvbnN0IHVwbG9hZGVkRG9jcyA9IGRvY3VtZW50cy5maWx0ZXIoXHJcbi8vICAgICAgIChkb2MpID0+IGRvYy5maWxlX3VybCAmJiBkb2MuZG9jdW1lbnRfdHlwZSAhPT0gXCJEb2N1bWVudCBSZWZlcmVuY2VcIixcclxuLy8gICAgICk7XHJcbi8vICAgICBjb25zdCB0b3RhbFJlcXVpcmVkRG9jcyA9IFJFUVVJUkVEX0RPQ1VNRU5UUy5sZW5ndGg7XHJcbi8vICAgICBjb25zdCBwZXJjZW50YWdlID0gKHVwbG9hZGVkRG9jcy5sZW5ndGggLyB0b3RhbFJlcXVpcmVkRG9jcykgKiAxMDA7XHJcbi8vICAgICByZXR1cm4gTWF0aC5yb3VuZChwZXJjZW50YWdlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBIYW5kbGUgZG9jdW1lbnQgYWN0aW9ucyBmcm9tIG1vZGFsXHJcbi8vICAgY29uc3QgaGFuZGxlRG9jdW1lbnRBY3Rpb24gPSBhc3luYyAoYWN0aW9uKSA9PiB7XHJcbi8vICAgICBpZiAoIWN1cnJlbnRBdWN0aW9uRm9yRG9jcykgcmV0dXJuO1xyXG5cclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGxldCBuZXdTdGF0dXMgPSBcIlwiO1xyXG4vLyAgICAgICBzd2l0Y2ggKGFjdGlvbikge1xyXG4vLyAgICAgICAgIGNhc2UgXCJ2ZXJpZnlcIjpcclxuLy8gICAgICAgICAgIG5ld1N0YXR1cyA9IFwiRG9jdW1lbnQgVmVyaWZpY2F0aW9uXCI7XHJcbi8vICAgICAgICAgICBicmVhaztcclxuLy8gICAgICAgICBjYXNlIFwiY29tcGxldGVcIjpcclxuLy8gICAgICAgICAgIG5ld1N0YXR1cyA9IFwiQ29tcGxldGVkXCI7XHJcbi8vICAgICAgICAgICBicmVhaztcclxuLy8gICAgICAgICBjYXNlIFwicGVuZGluZ1wiOlxyXG4vLyAgICAgICAgICAgbmV3U3RhdHVzID0gXCJEb2N1bWVudCBDb2xsZWN0aW9uXCI7XHJcbi8vICAgICAgICAgICBtZXNzYWdlLmluZm8oXCJEb2N1bWVudCBtYXJrZWQgYXMgcGVuZGluZ1wiKTtcclxuLy8gICAgICAgICAgIGJyZWFrO1xyXG4vLyAgICAgICAgIGRlZmF1bHQ6XHJcbi8vICAgICAgICAgICBicmVhaztcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgaWYgKG5ld1N0YXR1cykge1xyXG4vLyAgICAgICAgIGF3YWl0IHVwZGF0ZUF1Y3Rpb25TdGF0dXMoY3VycmVudEF1Y3Rpb25Gb3JEb2NzLl9pZCwgbmV3U3RhdHVzKTtcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgc2V0U2hvd0RvY3VtZW50TW9kYWwoZmFsc2UpO1xyXG4vLyAgICAgICBzZXRDdXJyZW50RG9jdW1lbnRzKFtdKTtcclxuLy8gICAgICAgc2V0Q3VycmVudEF1Y3Rpb25Gb3JEb2NzKG51bGwpO1xyXG4vLyAgICAgICBmZXRjaFByb2Nlc3NEYXRhKCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZG9jdW1lbnQgc3RhdHVzOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIGRvY3VtZW50IHN0YXR1c1wiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChlKSA9PiB7XHJcbi8vICAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuLy8gICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuLy8gICAgICAgLi4ucHJldkRhdGEsXHJcbi8vICAgICAgIFtuYW1lXTogdmFsdWUsXHJcbi8vICAgICB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gUGF5b3V0IEhhbmRsZXJcclxuLy8gICAvLyBjb25zdCBoYW5kbGVQYXlvdXQgPSAoYXVjdGlvbklkKSA9PiB7XHJcbi8vICAgLy8gICBuYXZpZ2F0ZShcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvY2hpdFwiKTtcclxuLy8gICAvLyB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVQYXlvdXRTdWNjZXNzID0gKCkgPT4ge1xyXG4vLyAgICAgbmF2aWdhdGUoXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2NoaXRcIik7XHJcblxyXG4vLyAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQWNjZXNzIGdyYW50ZWQuIFJlZGlyZWN0aW5nIHRvIHBheW91dC4uLlwiKTtcclxuXHJcbi8vICAgICAvLyBDbGVhciB0aGUgcGVuZGluZyBJRFxyXG4vLyAgICAgc2V0UGVuZGluZ1BheW91dElkKG51bGwpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIERlbGV0ZSBhdWN0aW9uXHJcbi8vICAgY29uc3QgaGFuZGxlRGVsZXRlQXVjdGlvbiA9IGFzeW5jIChhdWN0aW9uSWQpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9hdWN0aW9uL2RlbGV0ZS1hdWN0aW9uLyR7YXVjdGlvbklkfWApO1xyXG4vLyAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJBdWN0aW9uIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4vLyAgICAgICBmZXRjaFJlY2VudEF1Y3Rpb25zKCk7XHJcbi8vICAgICAgIGZldGNoUHJvY2Vzc0RhdGEoKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZGVsZXRlIGF1Y3Rpb25cIik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGF1Y3Rpb25JZCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2F1Y3Rpb25JZH1gKTtcclxuLy8gICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4vLyAgICAgICAgIGF1Y3Rpb25fZGF0ZTogcmVzcG9uc2UuZGF0YT8uYXVjdGlvbl9kYXRlLFxyXG4vLyAgICAgICAgIG5leHRfZGF0ZTogcmVzcG9uc2UuZGF0YT8ubmV4dF9kYXRlLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgc2V0Q3VycmVudFVwZGF0ZUdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4vLyAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbi8vICAgICAgIHNldE9wZW5BY3Rpb25NZW51SWQobnVsbCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXVjdGlvbjpcIiwgZXJyb3IpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbi8vICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBhd2FpdCBhcGkucHV0KGAvYXVjdGlvbi8ke2N1cnJlbnRVcGRhdGVHcm91cD8uX2lkfWAsIHVwZGF0ZUZvcm1EYXRhKTtcclxuLy8gICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuLy8gICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQXVjdGlvbiBkYXRlIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIpO1xyXG4vLyAgICAgICBmZXRjaFJlY2VudEF1Y3Rpb25zKCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBtZXNzYWdlLmVycm9yKFxyXG4vLyAgICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZFwiLFxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbi8vICAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBDYWxjdWxhdGUgc3RhdGlzdGljc1xyXG4vLyAgIGNvbnN0IHRvdGFsR3JvdXBWYWx1ZSA9IGZpbHRlcmVkQXVjdGlvbnMucmVkdWNlKFxyXG4vLyAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgKHBhcnNlRmxvYXQoaXRlbS5ncm91cF92YWx1ZSkgfHwgMCksXHJcbi8vICAgICAwLFxyXG4vLyAgICk7XHJcbi8vICAgY29uc3QgdG90YWxCaWRBbW91bnQgPSBmaWx0ZXJlZEF1Y3Rpb25zLnJlZHVjZShcclxuLy8gICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChwYXJzZUZsb2F0KGl0ZW0uYmlkX2Ftb3VudCkgfHwgMCksXHJcbi8vICAgICAwLFxyXG4vLyAgICk7XHJcbi8vICAgY29uc3QgdG90YWxXaW5BbW91bnQgPSBmaWx0ZXJlZEF1Y3Rpb25zLnJlZHVjZShcclxuLy8gICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChwYXJzZUZsb2F0KGl0ZW0uYW1vdW50KSB8fCAwKSxcclxuLy8gICAgIDAsXHJcbi8vICAgKTtcclxuXHJcbi8vICAgLy8gR2V0IHNlbGVjdGVkIGNvdW50XHJcbi8vICAgY29uc3Qgc2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4vLyAgICAgcmV0dXJuIGZpbHRlcmVkQXVjdGlvbnMuZmlsdGVyKFxyXG4vLyAgICAgICAoaXRlbSkgPT4gYWN0aXZlVXNlckRhdGFbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXMsXHJcbi8vICAgICApLmxlbmd0aDtcclxuLy8gICB9LCBbZmlsdGVyZWRBdWN0aW9ucywgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbi8vICAgLy8gSGFuZGxlIHNlbGVjdCBhbGxcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgYWxsQ2hlY2tlZCA9XHJcbi8vICAgICAgIGZpbHRlcmVkQXVjdGlvbnMubGVuZ3RoID4gMCAmJlxyXG4vLyAgICAgICBmaWx0ZXJlZEF1Y3Rpb25zLmV2ZXJ5KChpdGVtKSA9PiBhY3RpdmVVc2VyRGF0YVtpdGVtLl9pZF0/LmluZm8/LnN0YXR1cyk7XHJcbi8vICAgICBzZXRTZWxlY3RBbGwoYWxsQ2hlY2tlZCk7XHJcbi8vICAgfSwgW2ZpbHRlcmVkQXVjdGlvbnMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4vLyAgIC8vIEhhbmRsZSBpbmRpdmlkdWFsIGNoZWNrYm94IGNoYW5nZVxyXG4vLyAgIGNvbnN0IGhhbmRsZUNoZWNrYm94Q2hhbmdlID0gKGl0ZW0pID0+IHtcclxuLy8gICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICBbaXRlbS5faWRdOiB7XHJcbi8vICAgICAgICAgaW5mbzoge1xyXG4vLyAgICAgICAgICAgc3RhdHVzOiAhcHJldltpdGVtLl9pZF0/LmluZm8/LnN0YXR1cyxcclxuLy8gICAgICAgICAgIGF1Y3Rpb25fY29kZTogaXRlbS5hdWN0aW9uX2NvZGUsXHJcbi8vICAgICAgICAgICBuYW1lOiBpdGVtLm5hbWUsXHJcbi8vICAgICAgICAgfSxcclxuLy8gICAgICAgfSxcclxuLy8gICAgIH0pKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBIYW5kbGUgc2VsZWN0IGFsbCBjaGVja2JveFxyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEFsbENoYW5nZSA9IChlKSA9PiB7XHJcbi8vICAgICBjb25zdCBjaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuLy8gICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTtcclxuLy8gICAgIGNvbnN0IHVwZGF0ZWQgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbi8vICAgICBmaWx0ZXJlZEF1Y3Rpb25zLmZvckVhY2goKGl0ZW0pID0+IHtcclxuLy8gICAgICAgdXBkYXRlZFtpdGVtLl9pZF0gPSB7XHJcbi8vICAgICAgICAgaW5mbzoge1xyXG4vLyAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4vLyAgICAgICAgICAgYXVjdGlvbl9jb2RlOiBpdGVtLmF1Y3Rpb25fY29kZSxcclxuLy8gICAgICAgICAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuLy8gICAgICAgICB9LFxyXG4vLyAgICAgICB9O1xyXG4vLyAgICAgfSk7XHJcbi8vICAgICBzZXRBY3RpdmVVc2VyRGF0YSh1cGRhdGVkKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBGb3JtYXQgZGF0YSBmb3IgQXVjdGlvbiBXaW5uZXIgdGFiXHJcbi8vICAgY29uc3QgZm9ybWF0dGVkQXVjdGlvbkRhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZpbHRlcmVkQXVjdGlvbnMubWFwKChpdGVtKSA9PiB7XHJcbi8vICAgICAgIGNvbnN0IHdvcmtmbG93U3RhdHVzID0gaXRlbS53b3JrZmxvd19zdGF0dXMgfHwgXCJQZW5kaW5nXCI7XHJcblxyXG4vLyAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgIC4uLml0ZW0sXHJcbi8vICAgICAgICAgY2hlY2tib3g6IChcclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4vLyAgICAgICAgICAgICBjaGVja2VkPXthY3RpdmVVc2VyRGF0YVtpdGVtLl9pZF0/LmluZm8/LnN0YXR1cyB8fCBmYWxzZX1cclxuLy8gICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZUNoZWNrYm94Q2hhbmdlKGl0ZW0pfVxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGN1cnNvci1wb2ludGVyIGFjY2VudC1ibHVlLTYwMFwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICksXHJcbi8vICAgICAgICAgd29ya2Zsb3dfc3RhdHVzOiBnZXRTdGF0dXNUYWcod29ya2Zsb3dTdGF0dXMpLFxyXG4vLyAgICAgICAgIGFjdGlvbjogKFxyXG4vLyAgICAgICAgICAgPERyb3Bkb3duXHJcbi8vICAgICAgICAgICAgIG1lbnU9e3tcclxuLy8gICAgICAgICAgICAgICBpdGVtczogW1xyXG4vLyAgICAgICAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlQXVjdGlvblN0YXR1cyhpdGVtLl9pZCwgXCJEb2N1bWVudCBDb2xsZWN0aW9uXCIpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgRG9jdW1lbnQgQ29sbGVjdGlvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuLy8gICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS02MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGl0ZW0uX2lkKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBFZGl0IEF1Y3Rpb25cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIEF1Y3Rpb25cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgYXVjdGlvbj9cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtPXsoKSA9PiBoYW5kbGVEZWxldGVBdWN0aW9uKGl0ZW0uX2lkKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCI+RGVsZXRlPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4vLyAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICBdLFxyXG4vLyAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuLy8gICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuLy8gICAgICAgICAgIDwvRHJvcGRvd24+XHJcbi8vICAgICAgICAgKSxcclxuLy8gICAgICAgfTtcclxuLy8gICAgIH0pO1xyXG5cclxuLy8gICAgIHJldHVybiBmb3JtYXR0ZWQ7XHJcbi8vICAgfSwgW2ZpbHRlcmVkQXVjdGlvbnMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4vLyAgIGNvbnN0IHJlY2VudENvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJjaGVja2JveFwiLCBoZWFkZXI6IFwiU2VsZWN0XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYXVjdGlvbl9jb2RlXCIsIGhlYWRlcjogXCJBdWN0aW9uIENvZGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYXVjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJBdWN0aW9uIERhdGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJncm91cF92YWx1ZVwiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJiaWRfYW1vdW50XCIsIGhlYWRlcjogXCJCaWQgQW1vdW50XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiV2luIEFtb3VudFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhdWN0aW9uX3R5cGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ3b3JrZmxvd19zdGF0dXNcIiwgaGVhZGVyOiBcIldvcmtmbG93IFN0YXR1c1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgZG9jQ29sbGVjdGlvbkNvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImF1Y3Rpb25fY29kZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBDb2RlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImF1Y3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0aW1lXCIsIGhlYWRlcjogXCJVcGRhdGVkIERhdGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZG9jdW1lbnRcIiwgaGVhZGVyOiBcIkRvY3VtZW50XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICBjb25zdCBkb2NWZXJpZmljYXRpb25Db2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJhdWN0aW9uX2NvZGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gQ29kZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwidGltZVwiLCBoZWFkZXI6IFwiVXBkYXRlZCBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImRvY3VtZW50XCIsIGhlYWRlcjogXCJEb2N1bWVudFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgY29tcGxldGVkQ29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYXVjdGlvbl9jb2RlXCIsIGhlYWRlcjogXCJBdWN0aW9uIENvZGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbi8vICAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInRpbWVcIiwgaGVhZGVyOiBcIkNvbXBsZXRlZCBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICBjb25zdCB0YWJzID0gW1xyXG4vLyAgICAge1xyXG4vLyAgICAgICBpZDogXCJyZWNlbnRfYXVjdGlvbnNcIixcclxuLy8gICAgICAgbGFiZWw6IFwiQXVjdGlvbiBXaW5uZXJzXCIsXHJcbi8vICAgICAgIGNvdW50OiBmaWx0ZXJlZEF1Y3Rpb25zLmxlbmd0aCxcclxuLy8gICAgICAgaWNvbjogPElvRmxhc2ggLz4sXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBpZDogXCJkb2N1bWVudF9jb2xsZWN0aW9uXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIkRvY3VtZW50IENvbGxlY3Rpb25cIixcclxuLy8gICAgICAgY291bnQ6IGZpbHRlcmVkRG9jQ29sbGVjdGlvbi5sZW5ndGgsXHJcbi8vICAgICAgIGljb246IDxJb0RvY3VtZW50VGV4dCAvPixcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGlkOiBcImRvY3VtZW50X3ZlcmlmaWNhdGlvblwiLFxyXG4vLyAgICAgICBsYWJlbDogXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIixcclxuLy8gICAgICAgY291bnQ6IGZpbHRlcmVkRG9jVmVyaWZpY2F0aW9uLmxlbmd0aCxcclxuLy8gICAgICAgaWNvbjogPElvQ2hlY2ttYXJrQ2lyY2xlIC8+LFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAgaWQ6IFwiY29tcGxldGVkXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIkNvbXBsZXRlZFwiLFxyXG4vLyAgICAgICBjb3VudDogZmlsdGVyZWRDb21wbGV0ZWQubGVuZ3RoLFxyXG4vLyAgICAgICBpY29uOiA8SW9GbGFnIC8+LFxyXG4vLyAgICAgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICBjb25zdCByZW5kZXJUYWJDb250ZW50ID0gKCkgPT4ge1xyXG4vLyAgICAgaWYgKGlzTG9hZGluZykge1xyXG4vLyAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHktMTBcIj5cclxuLy8gICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIHN3aXRjaCAoYWN0aXZlVGFiKSB7XHJcbi8vICAgICAgIGNhc2UgXCJyZWNlbnRfYXVjdGlvbnNcIjpcclxuLy8gICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAge3NlbGVjdGVkQ291bnQgPiAwICYmIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCBoLTEwIHctMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQtbGcgc2hhZG93LW1kXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDb3VudH1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1sZ1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgSXRlbShzKSBTZWxlY3RlZFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTMganVzdGlmeS1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVCdWxrU3RhdHVzVXBkYXRlKFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIERvY3VtZW50IENvbGxlY3Rpb25cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtNTAwIHRleHQtd2hpdGUgaG92ZXI6Ymctb3JhbmdlLTYwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkID0gZmlsdGVyZWRBdWN0aW9ucy5maWx0ZXIoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0uX2lkXT8uaW5mbz8uc3RhdHVzLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWQubGVuZ3RoID09PSAxKSB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKHNlbGVjdGVkWzBdLl9pZCk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoc2VsZWN0ZWQubGVuZ3RoID4gMSkge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2Uud2FybmluZyhcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUGxlYXNlIHNlbGVjdCBvbmx5IG9uZSBhdWN0aW9uIHRvIGVkaXRcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBzZWxlY3QgYW4gYXVjdGlvbiB0byBlZGl0XCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIEVkaXQgQXVjdGlvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gZGFuZ2VyIG9uQ2xpY2s9e2hhbmRsZUJ1bGtEZWxldGV9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICB7ZmlsdGVyZWRBdWN0aW9ucz8ubGVuZ3RoID4gMCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtMyBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGN1cnNvci1wb2ludGVyIGFjY2VudC1ibHVlLTYwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdEFsbH1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEFsbENoYW5nZX1cclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge3NlbGVjdEFsbCA/IFwiRGVzZWxlY3QgQWxsXCIgOiBcIlNlbGVjdCBBbGxcIn0gKFxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRBdWN0aW9ucy5sZW5ndGh9IGl0ZW1zKVxyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAge2xvYWRpbmdSZWNlbnQgPyAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBweS0xMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICkgOiBmaWx0ZXJlZEF1Y3Rpb25zPy5sZW5ndGggPiAwID8gKFxyXG4vLyAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihmb3JtYXR0ZWRBdWN0aW9uRGF0YSwgc2VhcmNoVGV4dCl9XHJcbi8vICAgICAgICAgICAgICAgICBjb2x1bW5zPXtyZWNlbnRDb2x1bW5zfVxyXG4vLyAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlJlY2VudF9BdWN0aW9ucy5jc3ZcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICBObyByZWNlbnQgYXVjdGlvbnMgYXZhaWxhYmxlLlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgIGNhc2UgXCJkb2N1bWVudF9jb2xsZWN0aW9uXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIGZpbHRlcmVkRG9jQ29sbGVjdGlvbj8ubGVuZ3RoID4gMCA/IChcclxuLy8gICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkRG9jQ29sbGVjdGlvbiwgc2VhcmNoVGV4dCl9XHJcbi8vICAgICAgICAgICAgIGNvbHVtbnM9e2RvY0NvbGxlY3Rpb25Db2x1bW5zfVxyXG4vLyAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiRG9jdW1lbnRfQ29sbGVjdGlvbi5jc3ZcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+XHJcbi8vICAgICAgICAgICAgIE5vIHJlY29yZHMgaW4gRG9jdW1lbnQgQ29sbGVjdGlvbi5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICk7XHJcblxyXG4vLyAgICAgICBjYXNlIFwiZG9jdW1lbnRfdmVyaWZpY2F0aW9uXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIGZpbHRlcmVkRG9jVmVyaWZpY2F0aW9uPy5sZW5ndGggPiAwID8gKFxyXG4vLyAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24oZmlsdGVyZWREb2NWZXJpZmljYXRpb24sIHNlYXJjaFRleHQpfVxyXG4vLyAgICAgICAgICAgICBjb2x1bW5zPXtkb2NWZXJpZmljYXRpb25Db2x1bW5zfVxyXG4vLyAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiRG9jdW1lbnRfVmVyaWZpY2F0aW9uLmNzdlwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEwIHRleHQtZ3JheS01MDBcIj5cclxuLy8gICAgICAgICAgICAgTm8gcmVjb3JkcyBpbiBEb2N1bWVudCBWZXJpZmljYXRpb24uXHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICApO1xyXG5cclxuLy8gICAgICAgY2FzZSBcImNvbXBsZXRlZFwiOlxyXG4vLyAgICAgICAgIHJldHVybiBmaWx0ZXJlZENvbXBsZXRlZD8ubGVuZ3RoID4gMCA/IChcclxuLy8gICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkQ29tcGxldGVkLCBzZWFyY2hUZXh0KX1cclxuLy8gICAgICAgICAgICAgY29sdW1ucz17Y29tcGxldGVkQ29sdW1uc31cclxuLy8gICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkNvbXBsZXRlZC5jc3ZcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+XHJcbi8vICAgICAgICAgICAgIE5vIGNvbXBsZXRlZCByZWNvcmRzLlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgKTtcclxuXHJcbi8vICAgICAgIGRlZmF1bHQ6XHJcbi8vICAgICAgICAgcmV0dXJuIG51bGw7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXY+XHJcbi8vICAgICAgIDxNb2RhbFxyXG4vLyAgICAgICAgIG9wZW49e3ByZXZpZXdJbWFnZSAhPT0gbnVsbH1cclxuLy8gICAgICAgICB0aXRsZT17cHJldmlld1RpdGxlfVxyXG4vLyAgICAgICAgIGZvb3Rlcj17bnVsbH1cclxuLy8gICAgICAgICBvbkNhbmNlbD17aGFuZGxlQ2FuY2VsUHJldmlld31cclxuLy8gICAgICAgICB3aWR0aD1cImF1dG9cIlxyXG4vLyAgICAgICAgIHN0eWxlPXt7IG1heFdpZHRoOiBcIjkwdndcIiB9fVxyXG4vLyAgICAgICA+XHJcbi8vICAgICAgICAgPGltZyBhbHQ9e3ByZXZpZXdUaXRsZX0gc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19IHNyYz17cHJldmlld0ltYWdlfSAvPlxyXG4vLyAgICAgICA8L01vZGFsPlxyXG5cclxuXHJcbi8vICAgICA8TW9kYWxDb21wb25lbnRcclxuLy8gICBpc1Zpc2libGU9e3Nob3dLeWNQcmV2aWV3fVxyXG4vLyAgIG9uQ2xvc2U9eygpID0+IHtcclxuLy8gICAgIHNldFNob3dLeWNQcmV2aWV3KGZhbHNlKTtcclxuLy8gICAgIHNldEt5Y1VzZXJEYXRhKG51bGwpO1xyXG4vLyAgIH19XHJcbi8vICAgd2lkdGg9XCI5MDBweFwiXHJcbi8vICAgdGl0bGU9XCJDdXN0b21lciBLWUMgVmVyaWZpY2F0aW9uXCJcclxuLy8gPlxyXG4vLyAgIHtpc0xvYWRpbmcgPyAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTIwXCI+XHJcbi8vICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKSA6IGt5Y1VzZXJEYXRhID8gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC1bNzB2aF0gb3ZlcmZsb3cteS1hdXRvIHAtNFwiPlxyXG4vLyAgICAgICB7LyogUHJldmlldyBjb250ZW50ICovfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciByb3VuZGVkLWxnIHAtNiBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGJvcmRlci1iIHBiLTQgbWItNFwiPlxyXG4vLyAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtYmx1ZS04MDBcIj5DVVNUT01FUiBLWUMgVkVSSUZJQ0FUSU9OIEZPUk08L2gyPlxyXG4vLyAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5Lbm93IFlvdXIgQ3VzdG9tZXIgLSBWZXJpZmljYXRpb24gRG9jdW1lbnQ8L3A+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIG10LTIgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICA8c3Bhbj48c3Ryb25nPkN1c3RvbWVyIElEOjwvc3Ryb25nPiB7a3ljVXNlckRhdGE/LmN1c3RvbWVyX2lkIHx8IFwiTi9BXCJ9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8c3Bhbj48c3Ryb25nPkRhdGU6PC9zdHJvbmc+IHtuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygpfTwvc3Bhbj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICB7LyogQ3VzdG9tZXIgRGV0YWlscyAqL31cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuLy8gICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgYmctYmx1ZS04MDAgdGV4dC13aGl0ZSBweC0zIHB5LTEgcm91bmRlZFwiPkN1c3RvbWVyIERldGFpbHM8L2gzPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yIG10LTIgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+TmFtZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmZ1bGxfbmFtZSB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+RE9COjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZGF0ZW9mYmlydGg/LnNwbGl0KFwiVFwiKVswXSB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+R2VuZGVyOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZ2VuZGVyIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5QaG9uZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLnBob25lX251bWJlciB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTJcIj48c3Ryb25nPkVtYWlsOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZW1haWwgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPk1hcml0YWwgU3RhdHVzOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEubWFyaXRhbF9zdGF0dXMgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPk5hdGlvbmFsaXR5Ojwvc3Ryb25nPiB7a3ljVXNlckRhdGEubmF0aW9uYWxpdHkgfHwgXCJJbmRpYW5cIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yXCI+PHN0cm9uZz5BZGRyZXNzOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuYWRkcmVzcyB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+VmlsbGFnZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLnZpbGxhZ2UgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPlRhbHVrOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEudGFsdWsgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPkRpc3RyaWN0Ojwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZGlzdHJpY3QgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPlN0YXRlOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuc3RhdGUgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPlBpbmNvZGU6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5waW5jb2RlIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5GYXRoZXI6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5mYXRoZXJfbmFtZSB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+QWFkaGFhciBObzo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmFkaGFhcl9ubyB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+UEFOIE5vOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEucGFuX25vIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qIE5vbWluZWUgRGV0YWlscyAqL31cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuLy8gICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgYmctYmx1ZS04MDAgdGV4dC13aGl0ZSBweC0zIHB5LTEgcm91bmRlZFwiPk5vbWluZWUgRGV0YWlsczwvaDM+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgbXQtMiB0ZXh0LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5OYW1lOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEubm9taW5lZV9uYW1lIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5ET0I6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5ub21pbmVlX2RhdGVvZmJpcnRoPy5zcGxpdChcIlRcIilbMF0gfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPlJlbGF0aW9uc2hpcDo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLm5vbWluZWVfcmVsYXRpb25zaGlwIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5QaG9uZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLm5vbWluZWVfcGhvbmVfbnVtYmVyIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qIEd1YXJhbnRvciBEZXRhaWxzICovfVxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4vLyAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBiZy15ZWxsb3ctNjAwIHRleHQtd2hpdGUgcHgtMyBweS0xIHJvdW5kZWRcIj5HdWFyYW50b3IgRGV0YWlsczwvaDM+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgbXQtMiB0ZXh0LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5OYW1lOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZ3VhcmFudG9yX25hbWUgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPkRPQjo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmd1YXJhbnRvcl9kYXRlb2ZiaXJ0aD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5SZWxhdGlvbnNoaXA6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5ndWFyYW50b3JfcmVsYXRpb25zaGlwIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5QaG9uZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmd1YXJhbnRvcl9waG9uZSB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTJcIj48c3Ryb25nPkFkZHJlc3M6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5ndWFyYW50b3JfYWRkcmVzcyB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+QWFkaGFhciBObzo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmd1YXJhbnRvcl9hZGhhYXIgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPlBBTiBObzo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmd1YXJhbnRvcl9wYW4gfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICB7LyogQmFuayBEZXRhaWxzICovfVxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4vLyAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBiZy1ibHVlLTgwMCB0ZXh0LXdoaXRlIHB4LTMgcHktMSByb3VuZGVkXCI+QmFuayBEZXRhaWxzPC9oMz5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiBtdC0yIHRleHQtc21cIj5cclxuLy8gICAgICAgICAgICAgPGRpdj48c3Ryb25nPkJhbmsgTmFtZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmJhbmtfbmFtZSB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+QnJhbmNoIE5hbWU6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5iYW5rX2JyYW5jaF9uYW1lIHx8IFwiTi9BXCJ9PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+PHN0cm9uZz5BY2NvdW50IE5vOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuYmFua19hY2NvdW50X251bWJlciB8fCBcIk4vQVwifTwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PjxzdHJvbmc+SUZTQyBDb2RlOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuYmFua19JRlNDX2NvZGUgfHwgXCJOL0FcIn08L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICB7LyogU2lnbmF0dXJlIFNlY3Rpb24gKi99XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTQgYm9yZGVyLXRcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5TaWduYXR1cmUgb2YgU3Vic2NyaWJlcjwvcD5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTQwMCB3LTQ4IG10LTIgaC04XCI+PC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5TaWduYXR1cmUgb2YgR3VhcmFudG9yPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktNDAwIHctNDggbXQtMiBoLThcIj48L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5UaGlzIGlzIGEgc3lzdGVtIGdlbmVyYXRlZCBLWUMgZG9jdW1lbnQuIFZlcmlmaWNhdGlvbiByZXF1aXJlZC48L3A+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApIDogKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+Tm8gZGF0YSBhdmFpbGFibGU8L2Rpdj5cclxuLy8gICApfVxyXG5cclxuLy8gICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgYm9yZGVyLXQgcHQtNCBtdC00XCI+XHJcbi8vICAgICA8QnV0dG9uXHJcbi8vICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuLy8gICAgICAgICBzZXRTaG93S3ljUHJldmlldyhmYWxzZSk7XHJcbi8vICAgICAgICAgc2V0S3ljVXNlckRhdGEobnVsbCk7XHJcbi8vICAgICAgIH19XHJcbi8vICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAwIGhvdmVyOmJnLWdyYXktNjAwIHRleHQtd2hpdGVcIlxyXG4vLyAgICAgPlxyXG4vLyAgICAgICBDbG9zZVxyXG4vLyAgICAgPC9CdXR0b24+XHJcbi8vICAgICA8QnV0dG9uXHJcbi8vICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuLy8gICAgICAgaWNvbj17PElvRG9jdW1lbnQgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+fVxyXG4vLyAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgaWYgKGt5Y1VzZXJEYXRhKSB7XHJcbi8vICAgICAgICAgICBoYW5kbGVLeWNWZXJpZmljYXRpb25QcmludChreWNVc2VyRGF0YS5faWQpO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfX1cclxuLy8gICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS02MDBcIlxyXG4vLyAgICAgPlxyXG4vLyAgICAgICBEb3dubG9hZCBLWUNcclxuLy8gICAgIDwvQnV0dG9uPlxyXG4vLyAgIDwvZGl2PlxyXG4vLyA8L01vZGFsQ29tcG9uZW50PlxyXG5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgICAgPE5hdmJhclxyXG4vLyAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbi8vICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4vLyAgICAgICAgIC8+XHJcbi8vICAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgIEF1Y3Rpb24gV29ya2Zsb3cgTWFuYWdlbWVudFxyXG4vLyAgICAgICAgICAgICAgIDwvaDE+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgIFRyYWNrIGFuZCBtYW5hZ2UgcG9zdC1hdWN0aW9uIHByb2Nlc3Nlc1xyXG4vLyAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcInJlY2VudF9hdWN0aW9uc1wiICYmIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tb3JhbmdlLTUwIHRvLW9yYW5nZS0xMDAgYm9yZGVyIGJvcmRlci1vcmFuZ2UtMjAwIHJvdW5kZWQteGwgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtb3JhbmdlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgVmFsdWVcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAg4oK5e3RvdGFsR3JvdXBWYWx1ZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xMCBib3JkZXItbCBib3JkZXItb3JhbmdlLTMwMFwiPjwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgQmlkIEFtb3VudFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICDigrl7dG90YWxCaWRBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTAgYm9yZGVyLWwgYm9yZGVyLW9yYW5nZS0zMDBcIj48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JlZW4tNjAwIGZvbnQtbWVkaXVtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBXaW4gQW1vdW50XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICDigrl7dG90YWxXaW5BbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgaW5saW5lLWJsb2NrIHAtMyBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbWQgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuLy8gICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgIERhdGUgRmlsdGVyOlxyXG4vLyAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICA8UmFuZ2VQaWNrZXJcclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVEYXRlRmlsdGVyfVxyXG4vLyAgICAgICAgICAgICAgICAgZm9ybWF0PVwiWVlZWS1NTS1ERFwiXHJcbi8vICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17W1wiU3RhcnQgRGF0ZVwiLCBcIkVuZCBEYXRlXCJdfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01NlwiXHJcbi8vICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAge2RhdGVSYW5nZT8uWzBdICYmIGRhdGVSYW5nZT8uWzFdICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNldERhdGVSYW5nZShbbnVsbCwgbnVsbF0pO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbnMoYWxsUmVjZW50QXVjdGlvbnMpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNldEZpbHRlcmVkRG9jQ29sbGVjdGlvbihkb2N1bWVudENvbGxlY3Rpb25EYXRhKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbihkb2N1bWVudFZlcmlmaWNhdGlvbkRhdGEpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNldEZpbHRlcmVkQ29tcGxldGVkKGNvbXBsZXRlZERhdGEpO1xyXG4vLyAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHB4LTJcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBDbGVhciBGaWx0ZXJcclxuLy8gICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtOFwiIGFyaWEtbGFiZWw9XCJUYWJzXCI+XHJcbi8vICAgICAgICAgICAgICAgICB7dGFicy5tYXAoKHRhYikgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAga2V5PXt0YWIuaWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVGFiKHRhYi5pZCk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzZXRPcGVuQWN0aW9uTWVudUlkKG51bGwpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB5LTQgcHgtMSBib3JkZXItYi0yIGZvbnQtbWVkaXVtIHRleHQtc20gJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gdGFiLmlkXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItb3JhbmdlLTUwMCB0ZXh0LW9yYW5nZS02MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItZ3JheS0zMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXItMiB0ZXh0LWxnXCI+e3RhYi5pY29ufTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dGFiLmxhYmVsfTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7dGFiLmNvdW50ID4gMCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtbC0zIHB5LTAuNSBweC0yIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSB0YWIuaWRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTYwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTYwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7dGFiLmNvdW50fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgPC9uYXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+e3JlbmRlclRhYkNvbnRlbnQoKX08L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qIEVkaXQgTW9kYWwgKi99XHJcbi8vICAgICAgICAgPE1vZGFsQ29tcG9uZW50XHJcbi8vICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuLy8gICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbi8vICAgICAgICAgICB3aWR0aD1cIjgwMHB4XCJcclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4vLyAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgRWRpdCBBdWN0aW9uXHJcbi8vICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImF1Y3Rpb25fZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5hdWN0aW9uX2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yLjUgYm9yZGVyIHJvdW5kZWQtbGdcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIE5leHQgRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5leHRfZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5uZXh0X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yLjUgYm9yZGVyIHJvdW5kZWQtbGdcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjVcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBVcGRhdGVcclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Zvcm0+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L01vZGFsQ29tcG9uZW50PlxyXG5cclxuLy8gICAgICAgICA8U2ltcGxlUGFzc3dvcmRNb2RhbFxyXG4vLyAgICAgICAgICAgaXNPcGVuPXtzaG93UGF5b3V0UGFzc3dvcmR9XHJcbi8vICAgICAgICAgICBvbkNsb3NlPXtoYW5kbGVQYXlvdXRNb2RhbENsb3NlfVxyXG4vLyAgICAgICAgICAgb25TdWNjZXNzPXtoYW5kbGVQYXlvdXRTdWNjZXNzfVxyXG4vLyAgICAgICAgICAgdGl0bGU9XCJQYXlvdXQgQXV0aG9yaXphdGlvblwiXHJcbi8vICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkVudGVyIHlvdXIgYWRtaW4gcGFzc3dvcmQgdG8gcHJvY2VlZCB3aXRoIHRoZSBwYXlvdXRcIlxyXG4vLyAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgIHsvKiBEb2N1bWVudCBWaWV3IE1vZGFsICovfVxyXG4vLyAgICAgICAgIDxNb2RhbENvbXBvbmVudFxyXG4vLyAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93RG9jdW1lbnRNb2RhbH1cclxuLy8gICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgc2V0U2hvd0RvY3VtZW50TW9kYWwoZmFsc2UpO1xyXG4vLyAgICAgICAgICAgICBzZXRDdXJyZW50RG9jdW1lbnRzKFtdKTtcclxuLy8gICAgICAgICAgICAgc2V0Q3VycmVudEF1Y3Rpb25Gb3JEb2NzKG51bGwpO1xyXG4vLyAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgIHdpZHRoPVwiOTAwcHhcIlxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtWzcwdmhdIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTRcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC14c1wiPkN1c3RvbWVyIE5hbWU8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QXVjdGlvbkZvckRvY3M/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwifVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHNcIj5QaG9uZSBOdW1iZXI8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QXVjdGlvbkZvckRvY3M/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwifVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHNcIj5DdXN0b21lciBJRDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGJyZWFrLWFsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QXVjdGlvbkZvckRvY3M/LnVzZXJfaWQ/LmN1c3RvbWVyX2lkIHx8IFwiTi9BXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgRG9jdW1lbnQgVXBsb2FkIFByb2dyZXNzXHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhblxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgJHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPT09IDEwMCA/IFwidGV4dC1ncmVlbi02MDBcIiA6IGNhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZShjdXJyZW50RG9jdW1lbnRzKSA+PSA3MCA/IFwidGV4dC15ZWxsb3ctNjAwXCIgOiBcInRleHQtcmVkLTYwMFwifWB9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cyl9JVxyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxQcm9ncmVzc1xyXG4vLyAgICAgICAgICAgICAgICAgcGVyY2VudD17Y2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGN1cnJlbnREb2N1bWVudHMpfVxyXG4vLyAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gbXQtMyB0ZXh0LXhzIHRleHQtZ3JheS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICBVcGxvYWRlZDp7XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBjdXJyZW50RG9jdW1lbnRzLmZpbHRlcihcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIChkb2MpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGRvYy5maWxlX3VybCAmJlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBkb2MuZG9jdW1lbnRfdHlwZSAhPT0gXCJEb2N1bWVudCBSZWZlcmVuY2VcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICApLmxlbmd0aFxyXG4vLyAgICAgICAgICAgICAgICAgICB9e1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAvIHtSRVFVSVJFRF9ET0NVTUVOVFMubGVuZ3RofVxyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIFJlbWFpbmluZzp7XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgIHtSRVFVSVJFRF9ET0NVTUVOVFMubGVuZ3RoIC1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjdXJyZW50RG9jdW1lbnRzLmZpbHRlcihcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIChkb2MpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGRvYy5maWxlX3VybCAmJlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBkb2MuZG9jdW1lbnRfdHlwZSAhPT0gXCJEb2N1bWVudCBSZWZlcmVuY2VcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICApLmxlbmd0aH1cclxuLy8gICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7Y3VycmVudERvY3VtZW50cy5sZW5ndGggPiAwID8gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAge2N1cnJlbnREb2N1bWVudHMubWFwKChkb2MsIGluZGV4KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkLXhsIHAtNCBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbiBiZy13aGl0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1zbVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7ZG9jLmRvY3VtZW50X3R5cGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2RvYy5maWxlX3VybCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb0V5ZVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlUHJldmlldyhkb2MuZmlsZV91cmwsIGRvYy5kb2N1bWVudF90eXBlKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBjdXJzb3ItcG9pbnRlciB0ZXh0LWxnIGhvdmVyOnNjYWxlLTExMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17ZG9jLmZpbGVfdXJsfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb0Rvd25sb2FkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtbGcgaG92ZXI6c2NhbGUtMTEwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTIgaC0zMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2RvYy5pc0ltYWdlICYmIGRvYy5maWxlX3VybCA/IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17ZG9jLmZpbGVfdXJsfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17ZG9jLmRvY3VtZW50X3R5cGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIG9iamVjdC1jb250YWluIGN1cnNvci1wb2ludGVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlUHJldmlldyhkb2MuZmlsZV91cmwsIGRvYy5kb2N1bWVudF90eXBlKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICkgOiBkb2MuZmlsZV91cmwgPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxJb0RvY3VtZW50IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC00eGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gZmlsZSB1cGxvYWRlZFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxJb0RvY3VtZW50IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC01eGwgbXgtYXV0byBtYi0zXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgTm8gZG9jdW1lbnRzIHVwbG9hZGVkIGZvciB0aGlzIGF1Y3Rpb24uXHJcbi8vICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgYm9yZGVyLXQgcHQtNCBtdC00XCI+XHJcbi8vICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb2N1bWVudEFjdGlvbihcInBlbmRpbmdcIil9XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmcteWVsbG93LTUwMCBob3ZlcjpiZy15ZWxsb3ctNjAwIHRleHQtd2hpdGVcIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgRG9jcyBQZW5kaW5nXHJcbi8vICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4vLyAgICAgICAgICAgICA8QnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRG9jdW1lbnRBY3Rpb24oXCJ2ZXJpZnlcIil9XHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNjAwXCJcclxuLy8gICAgICAgICAgICAgICBkaXNhYmxlZD17Y2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGN1cnJlbnREb2N1bWVudHMpIDwgMTAwfVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgTW92ZSB0byBWZXJpZmljYXRpb25cclxuLy8gICAgICAgICAgICAgICB7Y2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGN1cnJlbnREb2N1bWVudHMpIDwgMTAwICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC14cyBvcGFjaXR5LTc1XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICh7Y2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGN1cnJlbnREb2N1bWVudHMpfSUgY29tcGxldGUpXHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb2N1bWVudEFjdGlvbihcImNvbXBsZXRlXCIpfVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLWdyZWVuLTcwMFwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICBDb21wbGV0ZWRcclxuLy8gICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPCAxMDAgJiZcclxuLy8gICAgICAgICAgICAgY3VycmVudERvY3VtZW50cy5sZW5ndGggPiAwICYmIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgdGV4dC1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC15ZWxsb3ctNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIOKaoO+4jyBQbGVhc2UgdXBsb2FkIGFsbCByZXF1aXJlZCBkb2N1bWVudHMgKFxyXG4vLyAgICAgICAgICAgICAgICAgICB7UkVRVUlSRURfRE9DVU1FTlRTLmxlbmd0aCAtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgY3VycmVudERvY3VtZW50cy5maWx0ZXIoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAoZG9jKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBkb2MuZmlsZV91cmwgJiZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZG9jLmRvY3VtZW50X3R5cGUgIT09IFwiRG9jdW1lbnQgUmVmZXJlbmNlXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGh9e1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICByZW1haW5pbmcpIGJlZm9yZSB2ZXJpZmljYXRpb25cclxuLy8gICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICA8L01vZGFsQ29tcG9uZW50PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH1cclxuXHJcbi8vIGV4cG9ydCBkZWZhdWx0IFJlY2VudEF1Y3Rpb247XHJcblxyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQge1xyXG4gIERyb3Bkb3duLFxyXG4gIFBvcGNvbmZpcm0sXHJcbiAgbWVzc2FnZSxcclxuICBCdXR0b24sXHJcbiAgTW9kYWwsXHJcbiAgRGF0ZVBpY2tlcixcclxuICBTcGFjZSxcclxuICBQcm9ncmVzcyxcclxuICBUb29sdGlwLFxyXG4gIFNlbGVjdCxcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQge1xyXG4gIElvRmxhc2gsXHJcbiAgSW9Eb2N1bWVudFRleHQsXHJcbiAgSW9DaGVja21hcmtDaXJjbGUsXHJcbiAgSW9FeWUsXHJcbiAgSW9Eb2N1bWVudCxcclxuICBJb0Rvd25sb2FkLFxyXG4gIElvQ2xvc2UsXHJcbiAgSW9TZWFyY2gsXHJcbn0gZnJvbSBcInJlYWN0LWljb25zL2lvNVwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgTW9kYWxDb21wb25lbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCB7IEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IElvRmxhZyB9IGZyb20gXCJyZWFjdC1pY29ucy9pbzVcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcbmltcG9ydCBTaW1wbGVQYXNzd29yZE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9TaW1wbGVQYXNzd29yZE1vZGFsXCI7XHJcbmltcG9ydCBoYW5kbGVLeWNWZXJpZmljYXRpb25QcmludCBmcm9tIFwiLi4vY29tcG9uZW50cy9wcmludEZvcm1hdHMva3ljVmVyaWZpY2F0aW9uUHJpbnRcIjtcclxuXHJcbmNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcblxyXG4vLyBEb2N1bWVudCB0eXBlIG1hcHBpbmcgZm9yIHJlcXVpcmVkIGRvY3VtZW50c1xyXG5jb25zdCBSRVFVSVJFRF9ET0NVTUVOVFMgPSBbXHJcbiAgeyBrZXk6IFwidXNlcl9wcm9maWxlX3Bob3RvXCIsIGxhYmVsOiBcIlBob3RvXCIgfSxcclxuICB7IGtleTogXCJ1c2VyX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLCBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoRnJvbnQpXCIgfSxcclxuICB7IGtleTogXCJ1c2VyX2FkaGFyY2FyZF9iYWNrX3Bob3RvXCIsIGxhYmVsOiBcIkFhZGhhciBDYXJkIChCYWNrKVwiIH0sXHJcbiAgeyBrZXk6IFwidXNlcl9wYW5jYXJkX3Bob3RvXCIsIGxhYmVsOiBcIlBBTiBDYXJkXCIgfSxcclxuICB7IGtleTogXCJ1c2VyX2NoZXF1ZV9sZWFmXCIsIGxhYmVsOiBcIkNoZXF1ZSBMZWFmXCIgfSxcclxuICB7IGtleTogXCJiYW5rX3N0YXRlbWVudF9tb250aFwiLCBsYWJlbDogXCJCYW5rIFN0YXRlbWVudFwiIH0sXHJcbiAgeyBrZXk6IFwiYmFua19wYXNzYm9va19waG90b1wiLCBsYWJlbDogXCJQYXNzYm9vayBQaG90b1wiIH0sXHJcbiAgeyBrZXk6IFwiYnVzaW5lc3NfZG9jdW1lbnRfcHJvb2ZcIiwgbGFiZWw6IFwiQnVzaW5lc3MgUHJvb2ZcIiB9LFxyXG4gIHsga2V5OiBcInVzZXJfc2FsYXJ5X3NsaXBcIiwgbGFiZWw6IFwiU2FsYXJ5IFNsaXBcIiB9LFxyXG4gIHsga2V5OiBcInVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG9cIiwgbGFiZWw6IFwiTm9taW5lZSBBYWRoYXIgKEZyb250KVwiIH0sXHJcbiAgeyBrZXk6IFwidXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvXCIsIGxhYmVsOiBcIk5vbWluZWUgQWFkaGFyIChCYWNrKVwiIH0sXHJcbiAgeyBrZXk6IFwidXNlcl9ub21pbmVlX3BhbmNhcmRfcGhvdG9cIiwgbGFiZWw6IFwiTm9taW5lZSBQQU4gQ2FyZFwiIH0sXHJcbl07XHJcblxyXG5mdW5jdGlvbiBSZWNlbnRBdWN0aW9uKCkge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgW2xvYWRpbmdSZWNlbnQsIHNldExvYWRpbmdSZWNlbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtUYWJsZUF1Y3Rpb25zLCBzZXRUYWJsZUF1Y3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWxsUmVjZW50QXVjdGlvbnMsIHNldEFsbFJlY2VudEF1Y3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlR3JvdXAsIHNldEN1cnJlbnRVcGRhdGVHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoXCJyZWNlbnRfYXVjdGlvbnNcIik7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcHJldmlld0ltYWdlLCBzZXRQcmV2aWV3SW1hZ2VdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3ByZXZpZXdUaXRsZSwgc2V0UHJldmlld1RpdGxlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBbc2hvd1BheW91dFBhc3N3b3JkLCBzZXRTaG93UGF5b3V0UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwZW5kaW5nUGF5b3V0SWQsIHNldFBlbmRpbmdQYXlvdXRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgY29uc3QgW2ZpbHRlcmVkRG9jQ29sbGVjdGlvbiwgc2V0RmlsdGVyZWREb2NDb2xsZWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWREb2NWZXJpZmljYXRpb24sIHNldEZpbHRlcmVkRG9jVmVyaWZpY2F0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRDb21wbGV0ZWQsIHNldEZpbHRlcmVkQ29tcGxldGVkXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3QgW3Nob3dLeWNQcmV2aWV3LCBzZXRTaG93S3ljUHJldmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2t5Y1VzZXJEYXRhLCBzZXRLeWNVc2VyRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgLy8gRGF0ZSBmaWx0ZXIgc3RhdGVzXHJcbiAgY29uc3QgW2RhdGVSYW5nZSwgc2V0RGF0ZVJhbmdlXSA9IHVzZVN0YXRlKFtudWxsLCBudWxsXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbnMsIHNldEZpbHRlcmVkQXVjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICAvLyBUYWIgZGF0YVxyXG4gIGNvbnN0IFtkb2N1bWVudENvbGxlY3Rpb25EYXRhLCBzZXREb2N1bWVudENvbGxlY3Rpb25EYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZG9jdW1lbnRWZXJpZmljYXRpb25EYXRhLCBzZXREb2N1bWVudFZlcmlmaWNhdGlvbkRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjb21wbGV0ZWREYXRhLCBzZXRDb21wbGV0ZWREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBhdWN0aW9uX2RhdGU6IFwiXCIsXHJcbiAgICBuZXh0X2RhdGU6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIC8vIFNlbGVjdGlvbiBzdGF0ZXNcclxuICBjb25zdCBbYWN0aXZlVXNlckRhdGEsIHNldEFjdGl2ZVVzZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtvcGVuQWN0aW9uTWVudUlkLCBzZXRPcGVuQWN0aW9uTWVudUlkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICAvLyBEb2N1bWVudCBtb2RhbCBzdGF0ZXNcclxuICBjb25zdCBbc2hvd0RvY3VtZW50TW9kYWwsIHNldFNob3dEb2N1bWVudE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudERvY3VtZW50cywgc2V0Q3VycmVudERvY3VtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2N1cnJlbnRBdWN0aW9uRm9yRG9jcywgc2V0Q3VycmVudEF1Y3Rpb25Gb3JEb2NzXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtkb2N1bWVudFVwbG9hZGVkS2V5cywgc2V0RG9jdW1lbnRVcGxvYWRlZEtleXNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICAvLyBHcm91cCBmaWx0ZXIgc3RhdGVzIC0gU2ltaWxhciB0byBHZW5lcmFsUGF5bWVudE91dFxyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwTmFtZSwgc2V0U2VsZWN0ZWRHcm91cE5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2ZpbHRlcmVkR3JvdXBBdWN0aW9ucywgc2V0RmlsdGVyZWRHcm91cEF1Y3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNHcm91cExvYWRpbmcsIHNldElzR3JvdXBMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgICBmZXRjaFJlY2VudEF1Y3Rpb25zKCk7XHJcbiAgICBmZXRjaFByb2Nlc3NEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBGZXRjaCBncm91cHMgLSBTaW1pbGFyIHRvIEdlbmVyYWxQYXltZW50T3V0XHJcbiAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICBzZXRHcm91cHMoZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwczpcIiwgZXJyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgZ3JvdXAgc2VsZWN0aW9uIC0gU2ltaWxhciB0byBHZW5lcmFsUGF5bWVudE91dCBoYW5kbGVHcm91cEF1Y3Rpb25cclxuICBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBcclxuICAgIGlmICghZ3JvdXBJZCkge1xyXG4gICAgICAvLyBJZiBubyBncm91cCBzZWxlY3RlZCwgc2hvdyBhbGwgYXVjdGlvbnNcclxuICAgICAgc2V0RmlsdGVyZWRHcm91cEF1Y3Rpb25zKFtdKTtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9ucyhhbGxSZWNlbnRBdWN0aW9ucyk7XHJcbiAgICAgIHNldFNlbGVjdGVkR3JvdXBOYW1lKFwiXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNHcm91cExvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRUYWJsZUF1Y3Rpb25zKFtdKTtcclxuICAgIHNldEZpbHRlcmVkR3JvdXBBdWN0aW9ucyhbXSk7XHJcbiAgICBcclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIEZldGNoIGF1Y3Rpb25zIGZvciB0aGUgc2VsZWN0ZWQgZ3JvdXAgLSBTaW1pbGFyIHRvIEdlbmVyYWxQYXltZW50T3V0XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChgL2F1Y3Rpb24vdW5wcml6ZWQvZ3JvdXAvJHtncm91cElkfWApO1xyXG4gICAgICBcclxuICAgICAgLy8gRmluZCB0aGUgc2VsZWN0ZWQgZ3JvdXAgbmFtZVxyXG4gICAgICBjb25zdCBzZWxlY3RlZEdyb3VwID0gZ3JvdXBzLmZpbmQoZyA9PiBnLl9pZCA9PT0gZ3JvdXBJZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkR3JvdXBOYW1lKHNlbGVjdGVkR3JvdXA/Lmdyb3VwX25hbWUgfHwgXCJcIik7XHJcblxyXG4gICAgICBpZiAoZGF0YSAmJiBkYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAvLyBGb3JtYXQgdGhlIGRhdGEgc2ltaWxhciB0byBHZW5lcmFsUGF5bWVudE91dFxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZEF1Y3Rpb25zID0gW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogMSxcclxuICAgICAgICAgICAgYXVjdGlvbl9kYXRlOiBuZXcgRGF0ZShcclxuICAgICAgICAgICAgICBuZXcgRGF0ZShkYXRhWzBdLmF1Y3Rpb25fZGF0ZSkuZ2V0VGltZSgpIC0gMTAgKiA4NjQwMDAwMFxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIHtcclxuICAgICAgICAgICAgICAgIGRheTogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxyXG4gICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAucmVwbGFjZShcIixcIiwgXCJcIiksXHJcbiAgICAgICAgICAgIG5hbWU6IFwiQ29tbWVuY2VtZW50XCIsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogXCJDb21tZW5jZW1lbnRcIixcclxuICAgICAgICAgICAgdGlja2V0OiBcIkNvbW1lbmNlbWVudFwiLFxyXG4gICAgICAgICAgICBiaWRfYW1vdW50OiAwLFxyXG4gICAgICAgICAgICBhbW91bnQ6IDAsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fdHlwZTogXCJDb21tZW5jZW1lbnQgQXVjdGlvblwiLFxyXG4gICAgICAgICAgICBzdGF0dXM6IFwiQ29tbWVuY2VtZW50XCIsXHJcbiAgICAgICAgICAgIHdvcmtmbG93X3N0YXR1czogXCJDb21tZW5jZW1lbnRcIixcclxuICAgICAgICAgICAgZ3JvdXBfbmFtZTogc2VsZWN0ZWRHcm91cD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBncm91cF92YWx1ZTogZGF0YVswXT8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fY29kZTogXCJDb21tZW5jZW1lbnRcIixcclxuICAgICAgICAgICAgaXNDb21tZW5jZW1lbnQ6IHRydWUsXHJcbiAgICAgICAgICAgIGFjdGlvbjogbnVsbCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICAuLi5kYXRhLm1hcCgoZywgaWR4KSA9PiAoe1xyXG4gICAgICAgICAgICBfaWQ6IGcuX2lkLFxyXG4gICAgICAgICAgICBpZDogaWR4ICsgMixcclxuICAgICAgICAgICAgYXVjdGlvbl9kYXRlOiBuZXcgRGF0ZShnLmF1Y3Rpb25fZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tVVNcIiwge1xyXG4gICAgICAgICAgICAgIGRheTogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgbW9udGg6IFwic2hvcnRcIixcclxuICAgICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIG5hbWU6IGcudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogZy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgdGlja2V0OiBnLnRpY2tldCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBiaWRfYW1vdW50OiBOdW1iZXIoZy5kaXZpZGVudCkgKyBOdW1iZXIoZy5jb21taXNzaW9uKSB8fCAwLFxyXG4gICAgICAgICAgICBhbW91bnQ6IGcud2luX2Ftb3VudCB8fCAwLFxyXG4gICAgICAgICAgICBhdWN0aW9uX3R5cGU6XHJcbiAgICAgICAgICAgICAgZy5hdWN0aW9uX3R5cGU/LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICtcclxuICAgICAgICAgICAgICBnLmF1Y3Rpb25fdHlwZT8uc2xpY2UoMSkgK1xyXG4gICAgICAgICAgICAgIFwiIEF1Y3Rpb25cIiB8fCBcIk5vcm1hbCBBdWN0aW9uXCIsXHJcbiAgICAgICAgICAgIHN0YXR1czogIWc/LmlzUHJpemVkID8gXCJVbiBQcml6ZWRcIiA6IFwiUHJpemVkXCIsXHJcbiAgICAgICAgICAgIHdvcmtmbG93X3N0YXR1czogZy5zdGF0dXMgfHwgXCJQZW5kaW5nXCIsXHJcbiAgICAgICAgICAgIGdyb3VwX25hbWU6IGcuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgc2VsZWN0ZWRHcm91cD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBncm91cF92YWx1ZTogZy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgYXVjdGlvbl9jb2RlOiBnLmF1Y3Rpb25fY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICB1c2VyX2lkOiBnLnVzZXJfaWQ/Ll9pZCxcclxuICAgICAgICAgICAgZ3JvdXBfaWQ6IGcuZ3JvdXBfaWQ/Ll9pZCxcclxuICAgICAgICAgICAgaXNDb21tZW5jZW1lbnQ6IGZhbHNlLFxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChnLnVzZXJfaWQ/Ll9pZCAmJiBnLmdyb3VwX2lkPy5faWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVBdWN0aW9uU3RhdHVzKGcuX2lkLCBcIkRvY3VtZW50IENvbGxlY3Rpb25cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiQ2Fubm90IG1vdmUgdG8gZG9jdW1lbnQgY29sbGVjdGlvbiAtIG1pc3NpbmcgdXNlciBvciBncm91cFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEb2N1bWVudCBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXQgQXVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgQXVjdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyBhdWN0aW9uP1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNvbmZpcm09eygpID0+IGhhbmRsZURlbGV0ZUF1Y3Rpb24oZy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIj5EZWxldGU8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkIHRleHQteGwgY3Vyc29yLXBvaW50ZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH0pKSxcclxuICAgICAgICBdO1xyXG5cclxuICAgICAgICBzZXRGaWx0ZXJlZEdyb3VwQXVjdGlvbnMoZm9ybWF0dGVkQXVjdGlvbnMpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbnMoZm9ybWF0dGVkQXVjdGlvbnMpO1xyXG4gICAgICAgIHNldFRhYmxlQXVjdGlvbnMoZm9ybWF0dGVkQXVjdGlvbnMpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEZpbHRlcmVkR3JvdXBBdWN0aW9ucyhbXSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9ucyhbXSk7XHJcbiAgICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICAgICAgbWVzc2FnZS5pbmZvKFwiTm8gdW5wcml6ZWQgYXVjdGlvbnMgZm91bmQgZm9yIHRoaXMgZ3JvdXBcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBhdWN0aW9uczpcIiwgZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGZldGNoIGF1Y3Rpb25zIGZvciB0aGlzIGdyb3VwXCIpO1xyXG4gICAgICBzZXRGaWx0ZXJlZEdyb3VwQXVjdGlvbnMoW10pO1xyXG4gICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb25zKFtdKTtcclxuICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0dyb3VwTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlS3ljUHJldmlldyA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdXNlci9nZXQtdXNlci1ieS1pZC8ke3VzZXJJZH1gKTtcclxuICAgICAgc2V0S3ljVXNlckRhdGEocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dLeWNQcmV2aWV3KHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgS1lDIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBLWUMgZGV0YWlsc1wiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggcmVjZW50IGF1Y3Rpb25zIChBdWN0aW9uIFdpbm5lcnMgdGFiKSAtIE9ubHkgc2hvdyBQZW5kaW5nXHJcbiAgY29uc3QgZmV0Y2hSZWNlbnRBdWN0aW9ucyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldExvYWRpbmdSZWNlbnQodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vYXVjdGlvbnMvcmVjZW50XCIpO1xyXG4gICAgICBjb25zdCBhdWN0aW9uc0RhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhIHx8IHJlc3BvbnNlLmRhdGE7XHJcblxyXG4gICAgICBpZiAoYXVjdGlvbnNEYXRhICYmIEFycmF5LmlzQXJyYXkoYXVjdGlvbnNEYXRhKSAmJiBhdWN0aW9uc0RhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIC8vIEZpbHRlciB0byBvbmx5IHNob3cgUGVuZGluZyBzdGF0dXNcclxuICAgICAgICBjb25zdCBwZW5kaW5nQXVjdGlvbnMgPSBhdWN0aW9uc0RhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgKGF1Y3Rpb24pID0+IGF1Y3Rpb24uc3RhdHVzID09PSBcIlBlbmRpbmdcIiB8fCAhYXVjdGlvbi5zdGF0dXMsXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHBlbmRpbmdBdWN0aW9ucy5tYXAoKGF1Y3Rpb24sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBhdWN0aW9uLl9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBhdWN0aW9uX2NvZGU6IGF1Y3Rpb24/LmF1Y3Rpb25fY29kZSxcclxuICAgICAgICAgIGF1Y3Rpb25fZGF0ZTogYXVjdGlvbj8uYXVjdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgYXVjdGlvbj8uYXVjdGlvbl9kYXRlLFxyXG4gICAgICAgICAgZ3JvdXBfbmFtZTogYXVjdGlvbi5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgZ3JvdXBfdmFsdWU6IGF1Y3Rpb24uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBncm91cF9pZDogYXVjdGlvbi5ncm91cF9pZD8uX2lkIHx8IGF1Y3Rpb24uZ3JvdXBfaWQsXHJcbiAgICAgICAgICBuYW1lOiBhdWN0aW9uLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgdGlja2V0OiBhdWN0aW9uPy50aWNrZXQsXHJcbiAgICAgICAgICBiaWRfYW1vdW50OiAocGFyc2VJbnQoYXVjdGlvbi5kaXZpZGVudCkgfHwgMCkgKyAocGFyc2VJbnQoYXVjdGlvbi5jb21taXNzaW9uKSB8fCAwKSxcclxuICAgICAgICAgIGFtb3VudDogYXVjdGlvbj8ud2luX2Ftb3VudCxcclxuICAgICAgICAgIGF1Y3Rpb25fdHlwZTpcclxuICAgICAgICAgICAgYXVjdGlvbj8uYXVjdGlvbl90eXBlPy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArXHJcbiAgICAgICAgICAgIGF1Y3Rpb24/LmF1Y3Rpb25fdHlwZT8uc2xpY2UoMSkgK1xyXG4gICAgICAgICAgICBcIiBBdWN0aW9uXCIsXHJcbiAgICAgICAgICBzdGF0dXM6ICFhdWN0aW9uPy5pc1ByaXplZCA/IFwiVW4gUHJpemVkXCIgOiBhdWN0aW9uPy5pc1ByaXplZCA9PT0gXCJ0cnVlXCIgPyBcIlByaXplZFwiIDogXCJVbiBQcml6ZWRcIixcclxuICAgICAgICAgIHVzZXJfaWQ6IGF1Y3Rpb24udXNlcl9pZD8uX2lkLFxyXG4gICAgICAgICAgd29ya2Zsb3dfc3RhdHVzOiBhdWN0aW9uLnN0YXR1cyB8fCBcIlBlbmRpbmdcIixcclxuICAgICAgICAgIGlzQ29tbWVuY2VtZW50OiBmYWxzZSxcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHNldEFsbFJlY2VudEF1Y3Rpb25zKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIC8vIE9ubHkgc2V0IGZpbHRlcmVkIGF1Y3Rpb25zIGlmIG5vIGdyb3VwIGlzIHNlbGVjdGVkXHJcbiAgICAgICAgaWYgKCFzZWxlY3RlZEdyb3VwSWQpIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbnMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldFRhYmxlQXVjdGlvbnMoZm9ybWF0dGVkRGF0YSk7XHJcblxyXG4gICAgICAgIC8vIEluaXRpYWxpemUgc2VsZWN0aW9uIHN0YXRlXHJcbiAgICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG4gICAgICAgIGZvcm1hdHRlZERhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgdGVtcEFjdGl2ZVtpdGVtLl9pZF0gPSB7XHJcbiAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIGF1Y3Rpb25fY29kZTogaXRlbS5hdWN0aW9uX2NvZGUsXHJcbiAgICAgICAgICAgICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh0ZW1wQWN0aXZlKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGxSZWNlbnRBdWN0aW9ucyhbXSk7XHJcbiAgICAgICAgaWYgKCFzZWxlY3RlZEdyb3VwSWQpIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbnMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZXRUYWJsZUF1Y3Rpb25zKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBmZXRjaCByZWNlbnQgYXVjdGlvbnNcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nUmVjZW50KGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBVcGRhdGUgYXVjdGlvbiBzdGF0dXMgaW4gQXVjdGlvbiBtb2RlbCBkaXJlY3RseVxyXG4gIGNvbnN0IHVwZGF0ZUF1Y3Rpb25TdGF0dXMgPSBhc3luYyAoYXVjdGlvbklkLCBuZXdTdGF0dXMpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGlkID0gdHlwZW9mIGF1Y3Rpb25JZCA9PT0gXCJvYmplY3RcIiA/IGF1Y3Rpb25JZD8uX2lkIDogYXVjdGlvbklkO1xyXG5cclxuICAgICAgaWYgKCFpZCkge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJJbnZhbGlkIGF1Y3Rpb25JZDpcIiwgYXVjdGlvbklkKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoYHYxL2FkbWluL2F1Y3Rpb25zL3N0YXR1cy8ke2lkfWAsIHtcclxuICAgICAgICBzdGF0dXM6IG5ld1N0YXR1cyxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoYFN0YXR1cyB1cGRhdGVkIHRvICR7bmV3U3RhdHVzfWApO1xyXG5cclxuICAgICAgLy8gUmVmcmVzaCBkYXRhIGJhc2VkIG9uIGN1cnJlbnQgdmlld1xyXG4gICAgICBpZiAoc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgICAgLy8gSWYgZ3JvdXAgaXMgc2VsZWN0ZWQsIHJlZnJlc2ggZ3JvdXAgZGF0YVxyXG4gICAgICAgIGF3YWl0IGhhbmRsZUdyb3VwQ2hhbmdlKHNlbGVjdGVkR3JvdXBJZCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gT3RoZXJ3aXNlIHJlZnJlc2ggYWxsIGRhdGFcclxuICAgICAgICBmZXRjaFJlY2VudEF1Y3Rpb25zKCk7XHJcbiAgICAgIH1cclxuICAgICAgZmV0Y2hQcm9jZXNzRGF0YSgpO1xyXG5cclxuICAgICAgLy8gQ2xlYXIgc2VsZWN0aW9uc1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YSh7fSk7XHJcbiAgICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgICAgIHNldE9wZW5BY3Rpb25NZW51SWQobnVsbCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHVwZGF0ZSBzdGF0dXNcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gQnVsayB1cGRhdGUgc3RhdHVzXHJcbiAgY29uc3QgaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZSA9IChuZXdTdGF0dXMpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkSXRlbXMgPSBmaWx0ZXJlZEF1Y3Rpb25zLmZpbHRlcihcclxuICAgICAgKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0uX2lkXT8uaW5mbz8uc3RhdHVzICYmICFpdGVtLmlzQ29tbWVuY2VtZW50LFxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoc2VsZWN0ZWRJdGVtcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCBhdWN0aW9ucyB0byB1cGRhdGVcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBNb2RhbC5jb25maXJtKHtcclxuICAgICAgdGl0bGU6IGBCdWxrIFVwZGF0ZSBDb25maXJtYXRpb25gLFxyXG4gICAgICBjb250ZW50OiBgWW91IGFyZSBhYm91dCB0byB1cGRhdGUgc3RhdHVzIHRvIFwiJHtuZXdTdGF0dXN9XCIgZm9yICR7c2VsZWN0ZWRJdGVtcy5sZW5ndGh9IGF1Y3Rpb24ocykuIEFyZSB5b3Ugc3VyZT9gLFxyXG4gICAgICBva1RleHQ6IFwiWWVzLCBVcGRhdGVcIixcclxuICAgICAgY2FuY2VsVGV4dDogXCJOb1wiLFxyXG4gICAgICBvbk9rOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFxyXG4gICAgICAgICAgICBzZWxlY3RlZEl0ZW1zLm1hcCgoaXRlbSkgPT4gdXBkYXRlQXVjdGlvblN0YXR1cyhpdGVtLl9pZCwgbmV3U3RhdHVzKSksXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgbWVzc2FnZS5zdWNjZXNzKGAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSBhdWN0aW9ucyBtb3ZlZCB0byAke25ld1N0YXR1c31gKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgc29tZSBhdWN0aW9uc1wiKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICAvLyBCdWxrIGRlbGV0ZVxyXG4gIGNvbnN0IGhhbmRsZUJ1bGtEZWxldGUgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZEl0ZW1zID0gZmlsdGVyZWRBdWN0aW9ucy5maWx0ZXIoXHJcbiAgICAgIChpdGVtKSA9PiBhY3RpdmVVc2VyRGF0YVtpdGVtLl9pZF0/LmluZm8/LnN0YXR1cyAmJiAhaXRlbS5pc0NvbW1lbmNlbWVudCxcclxuICAgICk7XHJcblxyXG4gICAgaWYgKHNlbGVjdGVkSXRlbXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBzZWxlY3QgYXVjdGlvbnMgdG8gZGVsZXRlXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgTW9kYWwuY29uZmlybSh7XHJcbiAgICAgIHRpdGxlOiBgRGVsZXRlIENvbmZpcm1hdGlvbmAsXHJcbiAgICAgIGNvbnRlbnQ6IGBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlICR7c2VsZWN0ZWRJdGVtcy5sZW5ndGh9IGF1Y3Rpb24ocyk/IFRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuYCxcclxuICAgICAgb2tUZXh0OiBcIlllcywgRGVsZXRlXCIsXHJcbiAgICAgIG9rVHlwZTogXCJkYW5nZXJcIixcclxuICAgICAgY2FuY2VsVGV4dDogXCJOb1wiLFxyXG4gICAgICBvbk9rOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFxyXG4gICAgICAgICAgICBzZWxlY3RlZEl0ZW1zLm1hcCgoaXRlbSkgPT4gaGFuZGxlRGVsZXRlQXVjdGlvbihpdGVtLl9pZCkpLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhgJHtzZWxlY3RlZEl0ZW1zLmxlbmd0aH0gYXVjdGlvbnMgZGVsZXRlZCBzdWNjZXNzZnVsbHlgKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBkZWxldGUgc29tZSBhdWN0aW9uc1wiKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRTdGF0dXNUYWcgPSAoc3RhdHVzLCBwZXJjZW50YWdlID0gbnVsbCkgPT4ge1xyXG4gICAgY29uc3QgYmFzZUNsYXNzID1cclxuICAgICAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZC1mdWxsIHdoaXRlc3BhY2Utbm93cmFwIG1pbi13LVsxMjBweF1cIjtcclxuXHJcbiAgICBzd2l0Y2ggKHN0YXR1cykge1xyXG4gICAgICBjYXNlIFwiUGVuZGluZ1wiOlxyXG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2Ake2Jhc2VDbGFzc30gYmctZ3JheS0xMDAgdGV4dC1ncmF5LTYwMGB9PlBlbmRpbmc8L3NwYW4+O1xyXG5cclxuICAgICAgY2FzZSBcIkRvY3VtZW50IENvbGxlY3Rpb25cIjpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake2Jhc2VDbGFzc30gYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy03MDBgfT5ET0MgQ29sbGVjdGlvbjwvc3Bhbj5cclxuICAgICAgICAgICAge3BlcmNlbnRhZ2UgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxQcm9ncmVzc1xyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgICAgcGVyY2VudD17cGVyY2VudGFnZX1cclxuICAgICAgICAgICAgICAgICAgd2lkdGg9ezQwfVxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VDb2xvcj17cGVyY2VudGFnZSA9PT0gMTAwID8gXCIjNTJjNDFhXCIgOiBwZXJjZW50YWdlID49IDcwID8gXCIjZmFhZDE0XCIgOiBcIiNmZjRkNGZcIn1cclxuICAgICAgICAgICAgICAgICAgZm9ybWF0PXsocGVyY2VudCkgPT4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGRcIj57cGVyY2VudH0lPC9zcGFuPn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApO1xyXG5cclxuICAgICAgY2FzZSBcIkRvY3VtZW50IFZlcmlmaWNhdGlvblwiOlxyXG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2Ake2Jhc2VDbGFzc30gYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMGB9PkRPQyBWZXJpZmljYXRpb248L3NwYW4+O1xyXG5cclxuICAgICAgY2FzZSBcIkNvbXBsZXRlZFwiOlxyXG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2Ake2Jhc2VDbGFzc30gYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwYH0+Q29tcGxldGVkPC9zcGFuPjtcclxuXHJcbiAgICAgIGNhc2UgXCJDb21tZW5jZW1lbnRcIjpcclxuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPXtgJHtiYXNlQ2xhc3N9IGJnLXB1cnBsZS0xMDAgdGV4dC1wdXJwbGUtNzAwYH0+Q29tbWVuY2VtZW50PC9zcGFuPjtcclxuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT17YCR7YmFzZUNsYXNzfSBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNTAwYH0+e3N0YXR1c308L3NwYW4+O1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBwcmV2aWV3IGltYWdlXHJcbiAgY29uc3QgaGFuZGxlUHJldmlldyA9IChpbWFnZVVybCwgdGl0bGUpID0+IHtcclxuICAgIHNldFByZXZpZXdJbWFnZShpbWFnZVVybCk7XHJcbiAgICBzZXRQcmV2aWV3VGl0bGUodGl0bGUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNhbmNlbFByZXZpZXcgPSAoKSA9PiB7XHJcbiAgICBzZXRQcmV2aWV3SW1hZ2UobnVsbCk7XHJcbiAgICBzZXRQcmV2aWV3VGl0bGUoXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGF5b3V0ID0gKGF1Y3Rpb25JZCkgPT4ge1xyXG4gICAgc2V0UGVuZGluZ1BheW91dElkKGF1Y3Rpb25JZCk7XHJcbiAgICBzZXRTaG93UGF5b3V0UGFzc3dvcmQodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIG1vZGFsIGNsb3NlXHJcbiAgY29uc3QgaGFuZGxlUGF5b3V0TW9kYWxDbG9zZSA9ICgpID0+IHtcclxuICAgIHNldFNob3dQYXlvdXRQYXNzd29yZChmYWxzZSk7XHJcbiAgICBzZXRQZW5kaW5nUGF5b3V0SWQobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKTtcclxuICAgIGlmIChwYXJhbXMuZ2V0KFwib3Blbk1vZGFsXCIpID09PSBcInRydWVcIikge1xyXG4gICAgICBjb25zdCB1c2VySWQgPSBwYXJhbXMuZ2V0KFwidXNlcklkXCIpO1xyXG4gICAgICBpZiAodXNlcklkKSB7XHJcbiAgICAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKHVzZXJJZCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICB9XHJcbiAgICAgIHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSh7fSwgZG9jdW1lbnQudGl0bGUsIFwiL2N1c3RvbWVyLW1lbnUvdXNlclwiKTtcclxuICAgIH1cclxuICB9LCBbbG9jYXRpb25dKTtcclxuXHJcbiAgLy8gRmV0Y2ggYWxsIHByb2Nlc3MgZGF0YSBmcm9tIEF1Y3Rpb24gbW9kZWwgdXNpbmcgc3RhdHVzIGZpZWxkXHJcbiAgY29uc3QgZmV0Y2hQcm9jZXNzRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9hdWN0aW9ucy9hbGwtcGFnaW5hdGVkP2xpbWl0PTEwMDBcIik7XHJcbiAgICAgIGNvbnN0IGF1Y3Rpb25zID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgIC8vIEZvciBEb2N1bWVudCBDb2xsZWN0aW9uIHRhYlxyXG4gICAgICBjb25zdCBkb2NDb2xsZWN0aW9uUHJvbWlzZXMgPSBhdWN0aW9uc1xyXG4gICAgICAgIC5maWx0ZXIoKGF1Y3Rpb24pID0+IGF1Y3Rpb24uc3RhdHVzID09PSBcIkRvY3VtZW50IENvbGxlY3Rpb25cIilcclxuICAgICAgICAubWFwKGFzeW5jIChhdWN0aW9uLCBpZHgpID0+IHtcclxuICAgICAgICAgIGxldCBkb2N1bWVudFBlcmNlbnRhZ2UgPSAwO1xyXG4gICAgICAgICAgbGV0IGRvY3VtZW50cyA9IFtdO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHVzZXJJZCA9IGF1Y3Rpb24udXNlcl9pZD8uX2lkIHx8IGF1Y3Rpb24udXNlcl9pZDtcclxuICAgICAgICAgIGlmICh1c2VySWQpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBjb25zdCB1c2VyRG9jc1JlcyA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi91c2VyLWRvY3VtZW50cy8ke3VzZXJJZH1gKTtcclxuICAgICAgICAgICAgICBpZiAodXNlckRvY3NSZXMuZGF0YSAmJiB1c2VyRG9jc1Jlcy5kYXRhLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgIGxldCB1c2VyRG9jID0gdXNlckRvY3NSZXMuZGF0YS5kYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodXNlckRvYykgJiYgdXNlckRvYy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgIHVzZXJEb2MgPSB1c2VyRG9jWzBdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnRzID0gdHJhbnNmb3JtVXNlckRvY3VtZW50c1RvQXJyYXkodXNlckRvYyk7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudFBlcmNlbnRhZ2UgPSBjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoZG9jdW1lbnRzKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRvY3VtZW50czpcIiwgZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGtleTogYXVjdGlvbi5faWQsXHJcbiAgICAgICAgICAgIGlkOiBpZHggKyAxLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2NvZGU6IGF1Y3Rpb24uYXVjdGlvbl9jb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fZGF0ZTogYXVjdGlvbi5hdWN0aW9uX2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBhdWN0aW9uLmF1Y3Rpb25fZGF0ZSxcclxuICAgICAgICAgICAgbmFtZTogYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBncm91cF9uYW1lOiBhdWN0aW9uLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiLCBkb2N1bWVudFBlcmNlbnRhZ2UpLFxyXG4gICAgICAgICAgICB0aW1lOiBhdWN0aW9uLnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25faWQ6IGF1Y3Rpb24uX2lkLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGE6IGF1Y3Rpb24sXHJcbiAgICAgICAgICAgIGRvY3VtZW50OiAoXHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImxpbmtcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PElvRXllIGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdEb2N1bWVudHMoYXVjdGlvbiwgZG9jdW1lbnRzKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFZpZXdcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93Lm9wZW4oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvbGVnYWxzLW1lbnUvdXNlci1kb2N1bWVudD91c2VySWQ9JHthdWN0aW9uLnVzZXJfaWQ/Ll9pZH0mYXVjdGlvbklkPSR7YXVjdGlvbi5faWR9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJfYmxhbmtcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVXBsb2FkIERvY3VtZW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUF1Y3Rpb25TdGF0dXMoYXVjdGlvbi5faWQsIFwiRG9jdW1lbnQgVmVyaWZpY2F0aW9uXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmVyaWZpY2F0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUF1Y3Rpb25TdGF0dXMoYXVjdGlvbi5faWQsIFwiQ29tcGxldGVkXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTWFyayBDb21wbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjRcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSBhdWN0aW9uLnVzZXJfaWQ/Ll9pZCB8fCBhdWN0aW9uLnVzZXJfaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXNlcklkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvY3VzdG9tZXItbWVudS91c2VyP29wZW5Nb2RhbD10cnVlJnVzZXJJZD0ke3VzZXJJZH1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiX2JsYW5rXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmVycm9yKFwiVXNlciBJRCBub3QgZm91bmRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIEtZQyBVcGxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBkb2NDb2xsZWN0aW9uID0gYXdhaXQgUHJvbWlzZS5hbGwoZG9jQ29sbGVjdGlvblByb21pc2VzKTtcclxuICAgICAgc2V0RG9jdW1lbnRDb2xsZWN0aW9uRGF0YShkb2NDb2xsZWN0aW9uKTtcclxuICAgICAgc2V0RmlsdGVyZWREb2NDb2xsZWN0aW9uKGRvY0NvbGxlY3Rpb24pO1xyXG5cclxuICAgICAgLy8gRG9jdW1lbnQgVmVyaWZpY2F0aW9uIHRhYlxyXG4gICAgICBjb25zdCBkb2NWZXJpZmljYXRpb25Qcm9taXNlcyA9IGF1Y3Rpb25zXHJcbiAgICAgICAgLmZpbHRlcigoYXVjdGlvbikgPT4gYXVjdGlvbi5zdGF0dXMgPT09IFwiRG9jdW1lbnQgVmVyaWZpY2F0aW9uXCIpXHJcbiAgICAgICAgLm1hcChhc3luYyAoYXVjdGlvbiwgaWR4KSA9PiB7XHJcbiAgICAgICAgICBsZXQgZG9jdW1lbnRzID0gW107XHJcblxyXG4gICAgICAgICAgY29uc3QgdXNlcklkID0gYXVjdGlvbi51c2VyX2lkPy5faWQgfHwgYXVjdGlvbi51c2VyX2lkO1xyXG4gICAgICAgICAgaWYgKHVzZXJJZCkge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHVzZXJEb2NzUmVzID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL3VzZXItZG9jdW1lbnRzLyR7dXNlcklkfWApO1xyXG4gICAgICAgICAgICAgIGlmICh1c2VyRG9jc1Jlcy5kYXRhICYmIHVzZXJEb2NzUmVzLmRhdGEuZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHVzZXJEb2MgPSB1c2VyRG9jc1Jlcy5kYXRhLmRhdGE7XHJcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh1c2VyRG9jKSAmJiB1c2VyRG9jLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgdXNlckRvYyA9IHVzZXJEb2NbMF07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudHMgPSB0cmFuc2Zvcm1Vc2VyRG9jdW1lbnRzVG9BcnJheSh1c2VyRG9jKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRvY3VtZW50czpcIiwgZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGtleTogYXVjdGlvbi5faWQsXHJcbiAgICAgICAgICAgIGlkOiBpZHggKyAxLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2NvZGU6IGF1Y3Rpb24uYXVjdGlvbl9jb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fZGF0ZTogYXVjdGlvbi5hdWN0aW9uX2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBhdWN0aW9uLmF1Y3Rpb25fZGF0ZSxcclxuICAgICAgICAgICAgbmFtZTogYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBncm91cF9uYW1lOiBhdWN0aW9uLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiRG9jdW1lbnQgVmVyaWZpY2F0aW9uXCIpLFxyXG4gICAgICAgICAgICB0aW1lOiBhdWN0aW9uLnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25faWQ6IGF1Y3Rpb24uX2lkLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGE6IGF1Y3Rpb24sXHJcbiAgICAgICAgICAgIGRvY3VtZW50OiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJsaW5rXCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PElvRXllIGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmlld0RvY3VtZW50cyhhdWN0aW9uLCBkb2N1bWVudHMpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVmlld1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJsaW5rXCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PElvRG9jdW1lbnQgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+fVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gYXVjdGlvbi51c2VyX2lkPy5faWQgfHwgYXVjdGlvbi51c2VyX2lkO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh1c2VySWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUt5Y1ByZXZpZXcodXNlcklkKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIlVzZXIgSUQgbm90IGZvdW5kXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBLWUMgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUF1Y3Rpb25TdGF0dXMoYXVjdGlvbi5faWQsIFwiQ29tcGxldGVkXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmVyaWZpY2F0aW9uIENvbXBsZXRlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IGRvY1ZlcmlmaWNhdGlvbiA9IGF3YWl0IFByb21pc2UuYWxsKGRvY1ZlcmlmaWNhdGlvblByb21pc2VzKTtcclxuICAgICAgc2V0RG9jdW1lbnRWZXJpZmljYXRpb25EYXRhKGRvY1ZlcmlmaWNhdGlvbik7XHJcbiAgICAgIHNldEZpbHRlcmVkRG9jVmVyaWZpY2F0aW9uKGRvY1ZlcmlmaWNhdGlvbik7XHJcblxyXG4gICAgICAvLyBDb21wbGV0ZWQgdGFiXHJcbiAgICAgIGNvbnN0IGNvbXBsZXRlZCA9IGF1Y3Rpb25zXHJcbiAgICAgICAgLmZpbHRlcigoYXVjdGlvbikgPT4gYXVjdGlvbi5zdGF0dXMgPT09IFwiQ29tcGxldGVkXCIpXHJcbiAgICAgICAgLm1hcCgoYXVjdGlvbiwgaWR4KSA9PiAoe1xyXG4gICAgICAgICAga2V5OiBhdWN0aW9uLl9pZCxcclxuICAgICAgICAgIGlkOiBpZHggKyAxLFxyXG4gICAgICAgICAgYXVjdGlvbl9jb2RlOiBhdWN0aW9uLmF1Y3Rpb25fY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgYXVjdGlvbl9kYXRlOiBhdWN0aW9uLmF1Y3Rpb25fZGF0ZT8uc3BsaXQoXCJUXCIpWzBdIHx8IGF1Y3Rpb24uYXVjdGlvbl9kYXRlLFxyXG4gICAgICAgICAgbmFtZTogYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogYXVjdGlvbi51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGdyb3VwX25hbWU6IGF1Y3Rpb24uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiQ29tcGxldGVkXCIpLFxyXG4gICAgICAgICAgdGltZTogYXVjdGlvbi51cGRhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQYXlvdXQoYXVjdGlvbi5faWQpfT5cclxuICAgICAgICAgICAgICAgICAgICAgIEZvcndhcmQgdG8gQWNjb3VudHMgZm9yIENoaXQgUGF5b3V0XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICBzZXRDb21wbGV0ZWREYXRhKGNvbXBsZXRlZCk7XHJcbiAgICAgIHNldEZpbHRlcmVkQ29tcGxldGVkKGNvbXBsZXRlZCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcHJvY2VzcyBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcHJvY2VzcyBkYXRhXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEYXRlRmlsdGVyID0gKGRhdGVzKSA9PiB7XHJcbiAgICBpZiAoIWRhdGVzIHx8ICFkYXRlc1swXSB8fCAhZGF0ZXNbMV0pIHtcclxuICAgICAgc2V0RGF0ZVJhbmdlKFtudWxsLCBudWxsXSk7XHJcbiAgICAgIGlmIChzZWxlY3RlZEdyb3VwSWQpIHtcclxuICAgICAgICAvLyBJZiBncm91cCBpcyBzZWxlY3RlZCwgZmlsdGVyIGdyb3VwIGF1Y3Rpb25zXHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9ucyhmaWx0ZXJlZEdyb3VwQXVjdGlvbnMpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbnMoYWxsUmVjZW50QXVjdGlvbnMpO1xyXG4gICAgICB9XHJcbiAgICAgIHNldEZpbHRlcmVkRG9jQ29sbGVjdGlvbihkb2N1bWVudENvbGxlY3Rpb25EYXRhKTtcclxuICAgICAgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb24oZG9jdW1lbnRWZXJpZmljYXRpb25EYXRhKTtcclxuICAgICAgc2V0RmlsdGVyZWRDb21wbGV0ZWQoY29tcGxldGVkRGF0YSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXREYXRlUmFuZ2UoZGF0ZXMpO1xyXG4gICAgY29uc3QgW3N0YXJ0LCBlbmRdID0gZGF0ZXM7XHJcblxyXG4gICAgbGV0IGRhdGFUb0ZpbHRlciA9IHNlbGVjdGVkR3JvdXBJZCA/IGZpbHRlcmVkR3JvdXBBdWN0aW9ucyA6IGFsbFJlY2VudEF1Y3Rpb25zO1xyXG4gICAgY29uc3QgZmlsdGVyZWRSZWNlbnQgPSBmaWx0ZXJEYXRhQnlEYXRlKGRhdGFUb0ZpbHRlciwgZGF0ZXMpO1xyXG4gICAgY29uc3QgZmlsdGVyZWRDb2xsZWN0aW9uID0gZmlsdGVyRGF0YUJ5RGF0ZShkb2N1bWVudENvbGxlY3Rpb25EYXRhLCBkYXRlcyk7XHJcbiAgICBjb25zdCBmaWx0ZXJlZFZlcmlmaWNhdGlvbiA9IGZpbHRlckRhdGFCeURhdGUoZG9jdW1lbnRWZXJpZmljYXRpb25EYXRhLCBkYXRlcyk7XHJcbiAgICBjb25zdCBmaWx0ZXJlZENvbXBsZXRlZERhdGEgPSBmaWx0ZXJEYXRhQnlEYXRlKGNvbXBsZXRlZERhdGEsIGRhdGVzKTtcclxuXHJcbiAgICBzZXRGaWx0ZXJlZEF1Y3Rpb25zKGZpbHRlcmVkUmVjZW50KTtcclxuICAgIHNldEZpbHRlcmVkRG9jQ29sbGVjdGlvbihmaWx0ZXJlZENvbGxlY3Rpb24pO1xyXG4gICAgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb24oZmlsdGVyZWRWZXJpZmljYXRpb24pO1xyXG4gICAgc2V0RmlsdGVyZWRDb21wbGV0ZWQoZmlsdGVyZWRDb21wbGV0ZWREYXRhKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmaWx0ZXJEYXRhQnlEYXRlID0gKGRhdGEsIGRhdGVzKSA9PiB7XHJcbiAgICBpZiAoIWRhdGVzIHx8ICFkYXRlc1swXSB8fCAhZGF0ZXNbMV0pIHJldHVybiBkYXRhO1xyXG5cclxuICAgIGNvbnN0IFtzdGFydCwgZW5kXSA9IGRhdGVzO1xyXG5cclxuICAgIHJldHVybiBkYXRhLmZpbHRlcigoaXRlbSkgPT4ge1xyXG4gICAgICBsZXQgaXRlbURhdGUgPSBpdGVtLmF1Y3Rpb25fZGF0ZSB8fCBpdGVtLnRpbWU7XHJcbiAgICAgIGlmICghaXRlbURhdGUpIHJldHVybiB0cnVlO1xyXG5cclxuICAgICAgaWYgKHR5cGVvZiBpdGVtRGF0ZSA9PT0gXCJzdHJpbmdcIiAmJiBpdGVtRGF0ZS5pbmNsdWRlcyhcIlRcIikpIHtcclxuICAgICAgICBpdGVtRGF0ZSA9IGl0ZW1EYXRlLnNwbGl0KFwiVFwiKVswXTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgYXVjdGlvbkRhdGUgPSBkYXlqcyhpdGVtRGF0ZSk7XHJcbiAgICAgIHJldHVybiBhdWN0aW9uRGF0ZS5pc0FmdGVyKHN0YXJ0LnN1YnRyYWN0KDEsIFwiZGF5XCIpKSAmJiBhdWN0aW9uRGF0ZS5pc0JlZm9yZShlbmQuYWRkKDEsIFwiZGF5XCIpKTtcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSB2aWV3IGRvY3VtZW50c1xyXG4gIGNvbnN0IGhhbmRsZVZpZXdEb2N1bWVudHMgPSBhc3luYyAoYXVjdGlvbkRhdGEsIGV4aXN0aW5nRG9jdW1lbnRzID0gbnVsbCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IGRvY3VtZW50cyA9IGV4aXN0aW5nRG9jdW1lbnRzO1xyXG5cclxuICAgICAgaWYgKCFkb2N1bWVudHMpIHtcclxuICAgICAgICBjb25zdCB1c2VySWQgPSBhdWN0aW9uRGF0YT8udXNlcl9pZD8uX2lkIHx8IGF1Y3Rpb25EYXRhPy51c2VyX2lkO1xyXG5cclxuICAgICAgICBpZiAoIXVzZXJJZCkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIk5vIHVzZXJfaWQgZm91bmQgZm9yIHRoaXMgYXVjdGlvblwiKTtcclxuICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJDdXN0b21lciBpbmZvcm1hdGlvbiBub3QgZm91bmRcIik7XHJcbiAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi91c2VyLWRvY3VtZW50cy8ke3VzZXJJZH1gKTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5kYXRhKSB7XHJcbiAgICAgICAgICBsZXQgdXNlckRvYyA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHVzZXJEb2MpICYmIHVzZXJEb2MubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICB1c2VyRG9jID0gdXNlckRvY1swXTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGRvY3VtZW50cyA9IHRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5KHVzZXJEb2MpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBkb2N1bWVudHMgPSBbXTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldEN1cnJlbnREb2N1bWVudHMoZG9jdW1lbnRzKTtcclxuICAgICAgc2V0Q3VycmVudEF1Y3Rpb25Gb3JEb2NzKGF1Y3Rpb25EYXRhKTtcclxuICAgICAgc2V0U2hvd0RvY3VtZW50TW9kYWwodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZG9jdW1lbnRzOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggZG9jdW1lbnRzXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5ID0gKHVzZXJEb2MpID0+IHtcclxuICAgIGlmICghdXNlckRvYykgcmV0dXJuIFtdO1xyXG5cclxuICAgIGNvbnN0IGRvY3VtZW50cyA9IFtdO1xyXG5cclxuICAgIGNvbnN0IGRvY01hcHBpbmdzID0gW1xyXG4gICAgICB7IGtleTogXCJ1c2VyX3Byb2ZpbGVfcGhvdG9cIiwgbGFiZWw6IFwiUGhvdG9cIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgICB7IGtleTogXCJ1c2VyX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLCBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoRnJvbnQpXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuICAgICAgeyBrZXk6IFwidXNlcl9hZGhhcmNhcmRfYmFja19waG90b1wiLCBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoQmFjaylcIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgICB7IGtleTogXCJ1c2VyX3BhbmNhcmRfcGhvdG9cIiwgbGFiZWw6IFwiUEFOIENhcmRcIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgICB7IGtleTogXCJ1c2VyX2NoZXF1ZV9sZWFmXCIsIGxhYmVsOiBcIkNoZXF1ZSBMZWFmXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuICAgICAgeyBrZXk6IFwiYmFua19zdGF0ZW1lbnRfbW9udGhcIiwgbGFiZWw6IFwiQmFuayBTdGF0ZW1lbnRcIiwgaXNJbWFnZTogZmFsc2UgfSxcclxuICAgICAgeyBrZXk6IFwiYmFua19wYXNzYm9va19waG90b1wiLCBsYWJlbDogXCJQYXNzYm9vayBQaG90b1wiLCBpc0ltYWdlOiB0cnVlIH0sXHJcbiAgICAgIHsga2V5OiBcImJ1c2luZXNzX2RvY3VtZW50X3Byb29mXCIsIGxhYmVsOiBcIkJ1c2luZXNzIFByb29mXCIsIGlzSW1hZ2U6IGZhbHNlIH0sXHJcbiAgICAgIHsga2V5OiBcInVzZXJfc2FsYXJ5X3NsaXBcIiwgbGFiZWw6IFwiU2FsYXJ5IFNsaXBcIiwgaXNJbWFnZTogZmFsc2UgfSxcclxuICAgICAgeyBrZXk6IFwidXNlcl9ub21pbmVlX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLCBsYWJlbDogXCJOb21pbmVlIEFhZGhhciAoRnJvbnQpXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuICAgICAgeyBrZXk6IFwidXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvXCIsIGxhYmVsOiBcIk5vbWluZWUgQWFkaGFyIChCYWNrKVwiLCBpc0ltYWdlOiB0cnVlIH0sXHJcbiAgICAgIHsga2V5OiBcInVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvXCIsIGxhYmVsOiBcIk5vbWluZWUgUEFOIENhcmRcIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBkb2NNYXBwaW5ncy5mb3JFYWNoKChtYXBwaW5nKSA9PiB7XHJcbiAgICAgIGlmICh1c2VyRG9jW21hcHBpbmcua2V5XSkge1xyXG4gICAgICAgIGRvY3VtZW50cy5wdXNoKHtcclxuICAgICAgICAgIGRvY3VtZW50X3R5cGU6IG1hcHBpbmcubGFiZWwsXHJcbiAgICAgICAgICBmaWxlX3VybDogdXNlckRvY1ttYXBwaW5nLmtleV0sXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogYCR7bWFwcGluZy5sYWJlbH0gZG9jdW1lbnRgLFxyXG4gICAgICAgICAgaXNJbWFnZTogbWFwcGluZy5pc0ltYWdlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAodXNlckRvYy51c2VyX2RvY3VtZW50X2NvZGUpIHtcclxuICAgICAgZG9jdW1lbnRzLnB1c2goe1xyXG4gICAgICAgIGRvY3VtZW50X3R5cGU6IFwiRG9jdW1lbnQgUmVmZXJlbmNlXCIsXHJcbiAgICAgICAgZmlsZV91cmw6IG51bGwsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGBEb2N1bWVudCBDb2RlOiAke3VzZXJEb2MudXNlcl9kb2N1bWVudF9jb2RlfWAsXHJcbiAgICAgICAgaXNJbWFnZTogZmFsc2UsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBkb2N1bWVudHM7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlID0gKGRvY3VtZW50cykgPT4ge1xyXG4gICAgaWYgKCFkb2N1bWVudHMgfHwgZG9jdW1lbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDA7XHJcblxyXG4gICAgY29uc3QgdXBsb2FkZWREb2NzID0gZG9jdW1lbnRzLmZpbHRlcihcclxuICAgICAgKGRvYykgPT4gZG9jLmZpbGVfdXJsICYmIGRvYy5kb2N1bWVudF90eXBlICE9PSBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4gICAgKTtcclxuICAgIGNvbnN0IHRvdGFsUmVxdWlyZWREb2NzID0gUkVRVUlSRURfRE9DVU1FTlRTLmxlbmd0aDtcclxuICAgIGNvbnN0IHBlcmNlbnRhZ2UgPSAodXBsb2FkZWREb2NzLmxlbmd0aCAvIHRvdGFsUmVxdWlyZWREb2NzKSAqIDEwMDtcclxuICAgIHJldHVybiBNYXRoLnJvdW5kKHBlcmNlbnRhZ2UpO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBkb2N1bWVudCBhY3Rpb25zIGZyb20gbW9kYWxcclxuICBjb25zdCBoYW5kbGVEb2N1bWVudEFjdGlvbiA9IGFzeW5jIChhY3Rpb24pID0+IHtcclxuICAgIGlmICghY3VycmVudEF1Y3Rpb25Gb3JEb2NzKSByZXR1cm47XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IG5ld1N0YXR1cyA9IFwiXCI7XHJcbiAgICAgIHN3aXRjaCAoYWN0aW9uKSB7XHJcbiAgICAgICAgY2FzZSBcInZlcmlmeVwiOlxyXG4gICAgICAgICAgbmV3U3RhdHVzID0gXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJjb21wbGV0ZVwiOlxyXG4gICAgICAgICAgbmV3U3RhdHVzID0gXCJDb21wbGV0ZWRcIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJwZW5kaW5nXCI6XHJcbiAgICAgICAgICBuZXdTdGF0dXMgPSBcIkRvY3VtZW50IENvbGxlY3Rpb25cIjtcclxuICAgICAgICAgIG1lc3NhZ2UuaW5mbyhcIkRvY3VtZW50IG1hcmtlZCBhcyBwZW5kaW5nXCIpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAobmV3U3RhdHVzKSB7XHJcbiAgICAgICAgYXdhaXQgdXBkYXRlQXVjdGlvblN0YXR1cyhjdXJyZW50QXVjdGlvbkZvckRvY3MuX2lkLCBuZXdTdGF0dXMpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRTaG93RG9jdW1lbnRNb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldEN1cnJlbnREb2N1bWVudHMoW10pO1xyXG4gICAgICBzZXRDdXJyZW50QXVjdGlvbkZvckRvY3MobnVsbCk7XHJcbiAgICAgIGZldGNoUHJvY2Vzc0RhdGEoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBkb2N1bWVudCBzdGF0dXM6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgZG9jdW1lbnQgc3RhdHVzXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXlvdXRTdWNjZXNzID0gKCkgPT4ge1xyXG4gICAgbmF2aWdhdGUoXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2NoaXRcIik7XHJcbiAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJBY2Nlc3MgZ3JhbnRlZC4gUmVkaXJlY3RpbmcgdG8gcGF5b3V0Li4uXCIpO1xyXG4gICAgc2V0UGVuZGluZ1BheW91dElkKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIC8vIERlbGV0ZSBhdWN0aW9uXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQXVjdGlvbiA9IGFzeW5jIChhdWN0aW9uSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9hdWN0aW9uL2RlbGV0ZS1hdWN0aW9uLyR7YXVjdGlvbklkfWApO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJBdWN0aW9uIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICBcclxuICAgICAgaWYgKHNlbGVjdGVkR3JvdXBJZCkge1xyXG4gICAgICAgIC8vIElmIGdyb3VwIGlzIHNlbGVjdGVkLCByZWZyZXNoIGdyb3VwIGRhdGFcclxuICAgICAgICBhd2FpdCBoYW5kbGVHcm91cENoYW5nZShzZWxlY3RlZEdyb3VwSWQpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIE90aGVyd2lzZSByZWZyZXNoIGFsbCBkYXRhXHJcbiAgICAgICAgZmV0Y2hSZWNlbnRBdWN0aW9ucygpO1xyXG4gICAgICB9XHJcbiAgICAgIGZldGNoUHJvY2Vzc0RhdGEoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZGVsZXRlIGF1Y3Rpb25cIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGF1Y3Rpb25JZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2F1Y3Rpb25JZH1gKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIGF1Y3Rpb25fZGF0ZTogcmVzcG9uc2UuZGF0YT8uYXVjdGlvbl9kYXRlLFxyXG4gICAgICAgIG5leHRfZGF0ZTogcmVzcG9uc2UuZGF0YT8ubmV4dF9kYXRlLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZUdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICAgIHNldE9wZW5BY3Rpb25NZW51SWQobnVsbCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXVjdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucHV0KGAvYXVjdGlvbi8ke2N1cnJlbnRVcGRhdGVHcm91cD8uX2lkfWAsIHVwZGF0ZUZvcm1EYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQXVjdGlvbiBkYXRlIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICBcclxuICAgICAgaWYgKHNlbGVjdGVkR3JvdXBJZCkge1xyXG4gICAgICAgIC8vIElmIGdyb3VwIGlzIHNlbGVjdGVkLCByZWZyZXNoIGdyb3VwIGRhdGFcclxuICAgICAgICBhd2FpdCBoYW5kbGVHcm91cENoYW5nZShzZWxlY3RlZEdyb3VwSWQpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIE90aGVyd2lzZSByZWZyZXNoIGFsbCBkYXRhXHJcbiAgICAgICAgZmV0Y2hSZWNlbnRBdWN0aW9ucygpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZFwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gQ2FsY3VsYXRlIHN0YXRpc3RpY3MgLSBPbmx5IGZvciBub24tY29tbWVuY2VtZW50IGl0ZW1zXHJcbiAgY29uc3QgZ2V0RGlzcGxheURhdGEgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyZWRBdWN0aW9ucy5maWx0ZXIoaXRlbSA9PiAhaXRlbS5pc0NvbW1lbmNlbWVudCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZGlzcGxheURhdGEgPSBnZXREaXNwbGF5RGF0YSgpO1xyXG4gIGNvbnN0IHRvdGFsR3JvdXBWYWx1ZSA9IGRpc3BsYXlEYXRhLnJlZHVjZShcclxuICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChwYXJzZUZsb2F0KGl0ZW0uZ3JvdXBfdmFsdWUpIHx8IDApLFxyXG4gICAgMCxcclxuICApO1xyXG4gIGNvbnN0IHRvdGFsQmlkQW1vdW50ID0gZGlzcGxheURhdGEucmVkdWNlKFxyXG4gICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgKHBhcnNlRmxvYXQoaXRlbS5iaWRfYW1vdW50KSB8fCAwKSxcclxuICAgIDAsXHJcbiAgKTtcclxuICBjb25zdCB0b3RhbFdpbkFtb3VudCA9IGRpc3BsYXlEYXRhLnJlZHVjZShcclxuICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChwYXJzZUZsb2F0KGl0ZW0uYW1vdW50KSB8fCAwKSxcclxuICAgIDAsXHJcbiAgKTtcclxuXHJcbiAgLy8gR2V0IHNlbGVjdGVkIGNvdW50IC0gT25seSBmb3Igbm9uLWNvbW1lbmNlbWVudCBpdGVtc1xyXG4gIGNvbnN0IHNlbGVjdGVkQ291bnQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBkaXNwbGF5RGF0YS5maWx0ZXIoKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0uX2lkXT8uaW5mbz8uc3RhdHVzKS5sZW5ndGg7XHJcbiAgfSwgW2Rpc3BsYXlEYXRhLCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICAvLyBIYW5kbGUgc2VsZWN0IGFsbCAtIE9ubHkgZm9yIG5vbi1jb21tZW5jZW1lbnQgaXRlbXNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgYWxsQ2hlY2tlZCA9XHJcbiAgICAgIGRpc3BsYXlEYXRhLmxlbmd0aCA+IDAgJiZcclxuICAgICAgZGlzcGxheURhdGEuZXZlcnkoKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0uX2lkXT8uaW5mbz8uc3RhdHVzKTtcclxuICAgIHNldFNlbGVjdEFsbChhbGxDaGVja2VkKTtcclxuICB9LCBbZGlzcGxheURhdGEsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIC8vIEhhbmRsZSBpbmRpdmlkdWFsIGNoZWNrYm94IGNoYW5nZVxyXG4gIGNvbnN0IGhhbmRsZUNoZWNrYm94Q2hhbmdlID0gKGl0ZW0pID0+IHtcclxuICAgIGlmIChpdGVtLmlzQ29tbWVuY2VtZW50KSByZXR1cm47IC8vIERvbid0IGFsbG93IHNlbGVjdGlvbiBvZiBjb21tZW5jZW1lbnQgcm93XHJcbiAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgW2l0ZW0uX2lkXToge1xyXG4gICAgICAgIGluZm86IHtcclxuICAgICAgICAgIHN0YXR1czogIXByZXZbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXMsXHJcbiAgICAgICAgICBhdWN0aW9uX2NvZGU6IGl0ZW0uYXVjdGlvbl9jb2RlLFxyXG4gICAgICAgICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIHNlbGVjdCBhbGwgY2hlY2tib3hcclxuICBjb25zdCBoYW5kbGVTZWxlY3RBbGxDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICBzZXRTZWxlY3RBbGwoY2hlY2tlZCk7XHJcbiAgICBjb25zdCB1cGRhdGVkID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgZGlzcGxheURhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICBpZiAoIWl0ZW0uaXNDb21tZW5jZW1lbnQpIHtcclxuICAgICAgICB1cGRhdGVkW2l0ZW0uX2lkXSA9IHtcclxuICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2NvZGU6IGl0ZW0uYXVjdGlvbl9jb2RlLFxyXG4gICAgICAgICAgICBuYW1lOiBpdGVtLm5hbWUsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgc2V0QWN0aXZlVXNlckRhdGEodXBkYXRlZCk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRm9ybWF0IGRhdGEgZm9yIEF1Y3Rpb24gV2lubmVyIHRhYlxyXG4gIGNvbnN0IGZvcm1hdHRlZEF1Y3Rpb25EYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmb3JtYXR0ZWQgPSBmaWx0ZXJlZEF1Y3Rpb25zLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICBjb25zdCB3b3JrZmxvd1N0YXR1cyA9IGl0ZW0ud29ya2Zsb3dfc3RhdHVzIHx8IFwiUGVuZGluZ1wiO1xyXG5cclxuICAgICAgLy8gSWYgaXQncyBjb21tZW5jZW1lbnQsIGRvbid0IHNob3cgY2hlY2tib3hcclxuICAgICAgY29uc3QgY2hlY2tib3ggPSBpdGVtLmlzQ29tbWVuY2VtZW50ID8gKFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj4tPC9zcGFuPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgIGNoZWNrZWQ9e2FjdGl2ZVVzZXJEYXRhW2l0ZW0uX2lkXT8uaW5mbz8uc3RhdHVzIHx8IGZhbHNlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZUNoZWNrYm94Q2hhbmdlKGl0ZW0pfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBjdXJzb3ItcG9pbnRlciBhY2NlbnQtYmx1ZS02MDBcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICk7XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgY2hlY2tib3g6IGNoZWNrYm94LFxyXG4gICAgICAgIHdvcmtmbG93X3N0YXR1czogZ2V0U3RhdHVzVGFnKHdvcmtmbG93U3RhdHVzKSxcclxuICAgICAgICBhY3Rpb246IGl0ZW0uaXNDb21tZW5jZW1lbnQgPyBudWxsIDogaXRlbS5hY3Rpb24sXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gZm9ybWF0dGVkO1xyXG4gIH0sIFtmaWx0ZXJlZEF1Y3Rpb25zLCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICBjb25zdCByZWNlbnRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiY2hlY2tib3hcIiwgaGVhZGVyOiBcIlNlbGVjdFwiIH0sXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fY29kZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBDb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfdmFsdWVcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQmlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIldpbiBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl90eXBlXCIsIGhlYWRlcjogXCJBdWN0aW9uIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwid29ya2Zsb3dfc3RhdHVzXCIsIGhlYWRlcjogXCJXb3JrZmxvdyBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGRvY0NvbGxlY3Rpb25Db2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX2NvZGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwidGltZVwiLCBoZWFkZXI6IFwiVXBkYXRlZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImRvY3VtZW50XCIsIGhlYWRlcjogXCJEb2N1bWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZG9jVmVyaWZpY2F0aW9uQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl9jb2RlXCIsIGhlYWRlcjogXCJBdWN0aW9uIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcInRpbWVcIiwgaGVhZGVyOiBcIlVwZGF0ZWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJkb2N1bWVudFwiLCBoZWFkZXI6IFwiRG9jdW1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGNvbXBsZXRlZENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fY29kZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBDb2RlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJ0aW1lXCIsIGhlYWRlcjogXCJDb21wbGV0ZWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdGFicyA9IFtcclxuICAgIHtcclxuICAgICAgaWQ6IFwicmVjZW50X2F1Y3Rpb25zXCIsXHJcbiAgICAgIGxhYmVsOiBcIkF1Y3Rpb24gV2lubmVyc1wiLFxyXG4gICAgICBjb3VudDogZmlsdGVyZWRBdWN0aW9ucy5maWx0ZXIoaXRlbSA9PiAhaXRlbS5pc0NvbW1lbmNlbWVudCkubGVuZ3RoLFxyXG4gICAgICBpY29uOiA8SW9GbGFzaCAvPixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcImRvY3VtZW50X2NvbGxlY3Rpb25cIixcclxuICAgICAgbGFiZWw6IFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiLFxyXG4gICAgICBjb3VudDogZmlsdGVyZWREb2NDb2xsZWN0aW9uLmxlbmd0aCxcclxuICAgICAgaWNvbjogPElvRG9jdW1lbnRUZXh0IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IFwiZG9jdW1lbnRfdmVyaWZpY2F0aW9uXCIsXHJcbiAgICAgIGxhYmVsOiBcIkRvY3VtZW50IFZlcmlmaWNhdGlvblwiLFxyXG4gICAgICBjb3VudDogZmlsdGVyZWREb2NWZXJpZmljYXRpb24ubGVuZ3RoLFxyXG4gICAgICBpY29uOiA8SW9DaGVja21hcmtDaXJjbGUgLz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogXCJjb21wbGV0ZWRcIixcclxuICAgICAgbGFiZWw6IFwiQ29tcGxldGVkXCIsXHJcbiAgICAgIGNvdW50OiBmaWx0ZXJlZENvbXBsZXRlZC5sZW5ndGgsXHJcbiAgICAgIGljb246IDxJb0ZsYWcgLz4sXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHJlbmRlclRhYkNvbnRlbnQgPSAoKSA9PiB7XHJcbiAgICBpZiAoaXNMb2FkaW5nKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBweS0xMFwiPlxyXG4gICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgc3dpdGNoIChhY3RpdmVUYWIpIHtcclxuICAgICAgY2FzZSBcInJlY2VudF9hdWN0aW9uc1wiOlxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICB7c2VsZWN0ZWRDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcm91bmRlZC1sZyBzaGFkb3cgcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIGgtMTAgdy0xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgdGV4dC1sZyBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWxnXCI+SXRlbShzKSBTZWxlY3RlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTMganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdWxrU3RhdHVzVXBkYXRlKFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEb2N1bWVudCBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLW9yYW5nZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGRpc3BsYXlEYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAoaXRlbSkgPT4gYWN0aXZlVXNlckRhdGFbaXRlbS5faWRdPy5pbmZvPy5zdGF0dXMgJiYgIWl0ZW0uaXNDb21tZW5jZW1lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZC5sZW5ndGggPT09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oc2VsZWN0ZWRbMF0uX2lkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZC5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCBvbmx5IG9uZSBhdWN0aW9uIHRvIGVkaXRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCBhbiBhdWN0aW9uIHRvIGVkaXRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRWRpdCBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBkYW5nZXIgb25DbGljaz17aGFuZGxlQnVsa0RlbGV0ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtkaXNwbGF5RGF0YS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC0zIGJnLWdyYXktNTAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgY3Vyc29yLXBvaW50ZXIgYWNjZW50LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0QWxsQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0QWxsID8gXCJEZXNlbGVjdCBBbGxcIiA6IFwiU2VsZWN0IEFsbFwifSAoe2Rpc3BsYXlEYXRhLmxlbmd0aH0gaXRlbXMpXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7bG9hZGluZ1JlY2VudCB8fCBpc0dyb3VwTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTEwXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IGZpbHRlcmVkQXVjdGlvbnM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZvcm1hdHRlZEF1Y3Rpb25EYXRhLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e3JlY2VudENvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtzZWxlY3RlZEdyb3VwSWQgPyBgR3JvdXBfJHtzZWxlY3RlZEdyb3VwTmFtZX1fQXVjdGlvbnMuY3N2YCA6IFwiUmVjZW50X0F1Y3Rpb25zLmNzdlwifVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRHcm91cElkID8gXCJObyBhdWN0aW9ucyBmb3VuZCBmb3IgdGhpcyBncm91cC5cIiA6IFwiTm8gcmVjZW50IGF1Y3Rpb25zIGF2YWlsYWJsZS5cIn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICBjYXNlIFwiZG9jdW1lbnRfY29sbGVjdGlvblwiOlxyXG4gICAgICAgIHJldHVybiBmaWx0ZXJlZERvY0NvbGxlY3Rpb24/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihmaWx0ZXJlZERvY0NvbGxlY3Rpb24sIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtkb2NDb2xsZWN0aW9uQ29sdW1uc31cclxuICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkRvY3VtZW50X0NvbGxlY3Rpb24uY3N2XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTAgdGV4dC1ncmF5LTUwMFwiPk5vIHJlY29yZHMgaW4gRG9jdW1lbnQgQ29sbGVjdGlvbi48L2Rpdj5cclxuICAgICAgICApO1xyXG5cclxuICAgICAgY2FzZSBcImRvY3VtZW50X3ZlcmlmaWNhdGlvblwiOlxyXG4gICAgICAgIHJldHVybiBmaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbj8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkRG9jVmVyaWZpY2F0aW9uLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgY29sdW1ucz17ZG9jVmVyaWZpY2F0aW9uQ29sdW1uc31cclxuICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkRvY3VtZW50X1ZlcmlmaWNhdGlvbi5jc3ZcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+Tm8gcmVjb3JkcyBpbiBEb2N1bWVudCBWZXJpZmljYXRpb24uPC9kaXY+XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgIGNhc2UgXCJjb21wbGV0ZWRcIjpcclxuICAgICAgICByZXR1cm4gZmlsdGVyZWRDb21wbGV0ZWQ/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihmaWx0ZXJlZENvbXBsZXRlZCwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgIGNvbHVtbnM9e2NvbXBsZXRlZENvbHVtbnN9XHJcbiAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDb21wbGV0ZWQuY3N2XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTAgdGV4dC1ncmF5LTUwMFwiPk5vIGNvbXBsZXRlZCByZWNvcmRzLjwvZGl2PlxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICBvcGVuPXtwcmV2aWV3SW1hZ2UgIT09IG51bGx9XHJcbiAgICAgICAgdGl0bGU9e3ByZXZpZXdUaXRsZX1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgb25DYW5jZWw9e2hhbmRsZUNhbmNlbFByZXZpZXd9XHJcbiAgICAgICAgd2lkdGg9XCJhdXRvXCJcclxuICAgICAgICBzdHlsZT17eyBtYXhXaWR0aDogXCI5MHZ3XCIgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxpbWcgYWx0PXtwcmV2aWV3VGl0bGV9IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fSBzcmM9e3ByZXZpZXdJbWFnZX0gLz5cclxuICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgIDxNb2RhbENvbXBvbmVudFxyXG4gICAgICAgIGlzVmlzaWJsZT17c2hvd0t5Y1ByZXZpZXd9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0U2hvd0t5Y1ByZXZpZXcoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0S3ljVXNlckRhdGEobnVsbCk7XHJcbiAgICAgICAgfX1cclxuICAgICAgICB3aWR0aD1cIjkwMHB4XCJcclxuICAgICAgICB0aXRsZT1cIkN1c3RvbWVyIEtZQyBWZXJpZmljYXRpb25cIlxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHktMjBcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDoga3ljVXNlckRhdGEgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLVs3MHZoXSBvdmVyZmxvdy15LWF1dG8gcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIHJvdW5kZWQtbGcgcC02IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgYm9yZGVyLWIgcGItNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ibHVlLTgwMFwiPkNVU1RPTUVSIEtZQyBWRVJJRklDQVRJT04gRk9STTwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPktub3cgWW91ciBDdXN0b21lciAtIFZlcmlmaWNhdGlvbiBEb2N1bWVudDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gbXQtMiB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Q3VzdG9tZXIgSUQ6PC9zdHJvbmc+IHtreWNVc2VyRGF0YT8uY3VzdG9tZXJfaWQgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkRhdGU6PC9zdHJvbmc+IHtuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIGJnLWJsdWUtODAwIHRleHQtd2hpdGUgcHgtMyBweS0xIHJvdW5kZWRcIj5DdXN0b21lciBEZXRhaWxzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiBtdC0yIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPk5hbWU6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5mdWxsX25hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5ET0I6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5kYXRlb2ZiaXJ0aD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+R2VuZGVyOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZ2VuZGVyIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+UGhvbmU6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5waG9uZV9udW1iZXIgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+RW1haWw6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5lbWFpbCB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPk1hcml0YWwgU3RhdHVzOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEubWFyaXRhbF9zdGF0dXMgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5OYXRpb25hbGl0eTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLm5hdGlvbmFsaXR5IHx8IFwiSW5kaWFuXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkFkZHJlc3M6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5hZGRyZXNzIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VmlsbGFnZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLnZpbGxhZ2UgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5UYWx1azo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLnRhbHVrIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+RGlzdHJpY3Q6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5kaXN0cmljdCB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlN0YXRlOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuc3RhdGUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5QaW5jb2RlOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEucGluY29kZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkZhdGhlcjo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmZhdGhlcl9uYW1lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+QWFkaGFhciBObzo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmFkaGFhcl9ubyB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlBBTiBObzo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLnBhbl9ubyB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogTm9taW5lZSBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBiZy1ibHVlLTgwMCB0ZXh0LXdoaXRlIHB4LTMgcHktMSByb3VuZGVkXCI+Tm9taW5lZSBEZXRhaWxzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiBtdC0yIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPk5hbWU6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5ub21pbmVlX25hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5ET0I6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5ub21pbmVlX2RhdGVvZmJpcnRoPy5zcGxpdChcIlRcIilbMF0gfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5SZWxhdGlvbnNoaXA6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5ub21pbmVlX3JlbGF0aW9uc2hpcCB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlBob25lOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEubm9taW5lZV9waG9uZV9udW1iZXIgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEd1YXJhbnRvciBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBiZy15ZWxsb3ctNjAwIHRleHQtd2hpdGUgcHgtMyBweS0xIHJvdW5kZWRcIj5HdWFyYW50b3IgRGV0YWlsczwvaDM+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgbXQtMiB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5OYW1lOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZ3VhcmFudG9yX25hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5ET0I6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5ndWFyYW50b3JfZGF0ZW9mYmlydGg/LnNwbGl0KFwiVFwiKVswXSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlJlbGF0aW9uc2hpcDo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmd1YXJhbnRvcl9yZWxhdGlvbnNoaXAgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5QaG9uZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmd1YXJhbnRvcl9waG9uZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5BZGRyZXNzOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZ3VhcmFudG9yX2FkZHJlc3MgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5BYWRoYWFyIE5vOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuZ3VhcmFudG9yX2FkaGFhciB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlBBTiBObzo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmd1YXJhbnRvcl9wYW4gfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEJhbmsgRGV0YWlscyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgYmctYmx1ZS04MDAgdGV4dC13aGl0ZSBweC0zIHB5LTEgcm91bmRlZFwiPkJhbmsgRGV0YWlsczwvaDM+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgbXQtMiB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5CYW5rIE5hbWU6PC9zdHJvbmc+IHtreWNVc2VyRGF0YS5iYW5rX25hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5CcmFuY2ggTmFtZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmJhbmtfYnJhbmNoX25hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5BY2NvdW50IE5vOjwvc3Ryb25nPiB7a3ljVXNlckRhdGEuYmFua19hY2NvdW50X251bWJlciB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPklGU0MgQ29kZTo8L3N0cm9uZz4ge2t5Y1VzZXJEYXRhLmJhbmtfSUZTQ19jb2RlIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTaWduYXR1cmUgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlNpZ25hdHVyZSBvZiBTdWJzY3JpYmVyPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktNDAwIHctNDggbXQtMiBoLThcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlNpZ25hdHVyZSBvZiBHdWFyYW50b3I8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS00MDAgdy00OCBtdC0yIGgtOFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlRoaXMgaXMgYSBzeXN0ZW0gZ2VuZXJhdGVkIEtZQyBkb2N1bWVudC4gVmVyaWZpY2F0aW9uIHJlcXVpcmVkLjwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEwIHRleHQtZ3JheS01MDBcIj5ObyBkYXRhIGF2YWlsYWJsZTwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBib3JkZXItdCBwdC00IG10LTRcIj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFNob3dLeWNQcmV2aWV3KGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRLeWNVc2VyRGF0YShudWxsKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MDAgaG92ZXI6YmctZ3JheS02MDAgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBpY29uPXs8SW9Eb2N1bWVudCBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz59XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICBpZiAoa3ljVXNlckRhdGEpIHtcclxuICAgICAgICAgICAgICAgIGhhbmRsZUt5Y1ZlcmlmaWNhdGlvblByaW50KGt5Y1VzZXJEYXRhLl9pZCk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIERvd25sb2FkIEtZQ1xyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvTW9kYWxDb21wb25lbnQ+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICA8TmF2YmFyIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfSB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+QXVjdGlvbiBXb3JrZmxvdyBNYW5hZ2VtZW50PC9oMT5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlRyYWNrIGFuZCBtYW5hZ2UgcG9zdC1hdWN0aW9uIHByb2Nlc3NlczwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcInJlY2VudF9hdWN0aW9uc1wiICYmIGRpc3BsYXlEYXRhLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1vcmFuZ2UtNTAgdG8tb3JhbmdlLTEwMCBib3JkZXIgYm9yZGVyLW9yYW5nZS0yMDAgcm91bmRlZC14bCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RmFSdXBlZVNpZ24gY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1vcmFuZ2UtNjAwIGZvbnQtbWVkaXVtXCI+R3JvdXAgVmFsdWU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5e3RvdGFsR3JvdXBWYWx1ZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xMCBib3JkZXItbCBib3JkZXItb3JhbmdlLTMwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bVwiPkJpZCBBbW91bnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5e3RvdGFsQmlkQW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTEwIGJvcmRlci1sIGJvcmRlci1vcmFuZ2UtMzAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyZWVuLTYwMCBmb250LW1lZGl1bVwiPlRvdGFsIFdpbiBBbW91bnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuXt0b3RhbFdpbkFtb3VudC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICB7LyogR3JvdXAgRmlsdGVyIGFuZCBEYXRlIEZpbHRlciAtIFNhbWUgUm93ICovfVxyXG48ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNCBwLTQgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgey8qIEdyb3VwIEZpbHRlciAqL31cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgPElvU2VhcmNoIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPkZpbHRlciBieSBHcm91cDo8L3NwYW4+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxTZWxlY3RcclxuICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cENoYW5nZX1cclxuICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICBjbGFzc05hbWU9XCJ3LTY0XCJcclxuICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3Igc2VsZWN0IGEgZ3JvdXAuLi5cIlxyXG4gICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgfVxyXG4gICAgICBzdWZmaXhJY29uPXs8SW9TZWFyY2ggY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4gICAgICBub3RGb3VuZENvbnRlbnQ9XCJObyBncm91cHMgZm91bmRcIlxyXG4gICAgICBhbGxvd0NsZWFyXHJcbiAgICAgIGxvYWRpbmc9e2lzR3JvdXBMb2FkaW5nfVxyXG4gICAgPlxyXG4gICAgICB7Z3JvdXBzLm1hcCgoZykgPT4gKFxyXG4gICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Zy5faWR9IHZhbHVlPXtnLl9pZH0+XHJcbiAgICAgICAgICB7Zy5ncm91cF9uYW1lfVxyXG4gICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgKSl9XHJcbiAgICA8L1NlbGVjdD5cclxuICAgIHtzZWxlY3RlZEdyb3VwSWQgJiYgKFxyXG4gICAgICA8QnV0dG9uXHJcbiAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwTmFtZShcIlwiKTtcclxuICAgICAgICAgIHNldEZpbHRlcmVkR3JvdXBBdWN0aW9ucyhbXSk7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb25zKGFsbFJlY2VudEF1Y3Rpb25zKTtcclxuICAgICAgICAgIHNldFRhYmxlQXVjdGlvbnMoYWxsUmVjZW50QXVjdGlvbnMpO1xyXG4gICAgICAgIH19XHJcbiAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMFwiXHJcbiAgICAgID5cclxuICAgICAgICBDbGVhclxyXG4gICAgICA8L0J1dHRvbj5cclxuICAgICl9XHJcblxyXG4gICAgey8qIERpdmlkZXIgKi99XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpibG9jayB3LXB4IGgtOCBiZy1ncmF5LTMwMFwiPjwvZGl2PlxyXG5cclxuICAgIHsvKiBEYXRlIEZpbHRlciAqL31cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIHdoaXRlc3BhY2Utbm93cmFwXCI+RGF0ZSBGaWx0ZXI6PC9zcGFuPlxyXG4gICAgICA8UmFuZ2VQaWNrZXJcclxuICAgICAgICBvbkNoYW5nZT17aGFuZGxlRGF0ZUZpbHRlcn1cclxuICAgICAgICBmb3JtYXQ9XCJZWVlZLU1NLUREXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj17W1wiU3RhcnRcIiwgXCJFbmRcIl19XHJcbiAgICAgICAgY2xhc3NOYW1lPVwidy01NlwiXHJcbiAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgLz5cclxuICAgICAge2RhdGVSYW5nZT8uWzBdICYmIGRhdGVSYW5nZT8uWzFdICYmIChcclxuICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldERhdGVSYW5nZShbbnVsbCwgbnVsbF0pO1xyXG4gICAgICAgICAgICBpZiAoc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9ucyhmaWx0ZXJlZEdyb3VwQXVjdGlvbnMpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbnMoYWxsUmVjZW50QXVjdGlvbnMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHNldEZpbHRlcmVkRG9jQ29sbGVjdGlvbihkb2N1bWVudENvbGxlY3Rpb25EYXRhKTtcclxuICAgICAgICAgICAgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb24oZG9jdW1lbnRWZXJpZmljYXRpb25EYXRhKTtcclxuICAgICAgICAgICAgc2V0RmlsdGVyZWRDb21wbGV0ZWQoY29tcGxldGVkRGF0YSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgcHgtMlwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgQ2xlYXJcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIHsvKiBDb3VudCAtIFJpZ2h0IGFsaWduZWQgKi99XHJcbiAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJtbC1hdXRvIHRleHQtc20gdGV4dC1ncmF5LTUwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICB7c2VsZWN0ZWRHcm91cElkID8gKFxyXG4gICAgICAgIDxzcGFuPlNob3dpbmcgPHN0cm9uZz57ZGlzcGxheURhdGEubGVuZ3RofTwvc3Ryb25nPiBhdWN0aW9uKHMpIGZvciA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIj57c2VsZWN0ZWRHcm91cE5hbWV9PC9zdHJvbmc+PC9zcGFuPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxzcGFuPlNob3dpbmcgPHN0cm9uZz57ZGlzcGxheURhdGEubGVuZ3RofTwvc3Ryb25nPiBhdWN0aW9uKHMpPC9zcGFuPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+ICovfVxyXG4gIDwvZGl2PlxyXG48L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC04XCIgYXJpYS1sYWJlbD1cIlRhYnNcIj5cclxuICAgICAgICAgICAgICAgIHt0YWJzLm1hcCgodGFiKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUYWIodGFiLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5BY3Rpb25NZW51SWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bncm91cCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHktNCBweC0xIGJvcmRlci1iLTIgZm9udC1tZWRpdW0gdGV4dC1zbSAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSB0YWIuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1vcmFuZ2UtNTAwIHRleHQtb3JhbmdlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGhvdmVyOmJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yIHRleHQtbGdcIj57dGFiLmljb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnt0YWIubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0YWIuY291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1sLTMgcHktMC41IHB4LTIgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IHRhYi5pZCA/IFwiYmctb3JhbmdlLTEwMCB0ZXh0LW9yYW5nZS02MDBcIiA6IFwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dGFiLmNvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+e3JlbmRlclRhYkNvbnRlbnQoKX08L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEVkaXQgTW9kYWwgKi99XHJcbiAgICAgICAgPE1vZGFsQ29tcG9uZW50XHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgICB3aWR0aD1cIjgwMHB4XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+RWRpdCBBdWN0aW9uPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+QXVjdGlvbiBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYXVjdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMi41IGJvcmRlciByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5OZXh0IERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5leHRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5uZXh0X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yLjUgYm9yZGVyIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsQ29tcG9uZW50PlxyXG5cclxuICAgICAgICA8U2ltcGxlUGFzc3dvcmRNb2RhbFxyXG4gICAgICAgICAgaXNPcGVuPXtzaG93UGF5b3V0UGFzc3dvcmR9XHJcbiAgICAgICAgICBvbkNsb3NlPXtoYW5kbGVQYXlvdXRNb2RhbENsb3NlfVxyXG4gICAgICAgICAgb25TdWNjZXNzPXtoYW5kbGVQYXlvdXRTdWNjZXNzfVxyXG4gICAgICAgICAgdGl0bGU9XCJQYXlvdXQgQXV0aG9yaXphdGlvblwiXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIkVudGVyIHlvdXIgYWRtaW4gcGFzc3dvcmQgdG8gcHJvY2VlZCB3aXRoIHRoZSBwYXlvdXRcIlxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIHsvKiBEb2N1bWVudCBWaWV3IE1vZGFsICovfVxyXG4gICAgICAgIDxNb2RhbENvbXBvbmVudFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93RG9jdW1lbnRNb2RhbH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd0RvY3VtZW50TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50RG9jdW1lbnRzKFtdKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEF1Y3Rpb25Gb3JEb2NzKG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIHdpZHRoPVwiOTAwcHhcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtWzcwdmhdIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC14c1wiPkN1c3RvbWVyIE5hbWU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QXVjdGlvbkZvckRvY3M/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHNcIj5QaG9uZSBOdW1iZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QXVjdGlvbkZvckRvY3M/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHNcIj5DdXN0b21lciBJRDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGJyZWFrLWFsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QXVjdGlvbkZvckRvY3M/LnVzZXJfaWQ/LmN1c3RvbWVyX2lkIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5Eb2N1bWVudCBVcGxvYWQgUHJvZ3Jlc3M8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgJHtcclxuICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPT09IDEwMFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogY2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGN1cnJlbnREb2N1bWVudHMpID49IDcwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LXllbGxvdy02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cyl9JVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxQcm9ncmVzcyBwZXJjZW50PXtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cyl9IHNpemU9XCJzbWFsbFwiIC8+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBtdC0zIHRleHQteHMgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgIFVwbG9hZGVkOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnREb2N1bWVudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgKGRvYykgPT4gZG9jLmZpbGVfdXJsICYmIGRvYy5kb2N1bWVudF90eXBlICE9PSBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgIH17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIC8ge1JFUVVJUkVEX0RPQ1VNRU5UUy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgUmVtYWluaW5nOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge1JFUVVJUkVEX0RPQ1VNRU5UUy5sZW5ndGggLVxyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnREb2N1bWVudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgKGRvYykgPT4gZG9jLmZpbGVfdXJsICYmIGRvYy5kb2N1bWVudF90eXBlICE9PSBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICkubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtjdXJyZW50RG9jdW1lbnRzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICB7Y3VycmVudERvY3VtZW50cy5tYXAoKGRvYywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZC14bCBwLTQgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24gYmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1zbVwiPntkb2MuZG9jdW1lbnRfdHlwZX08L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2RvYy5maWxlX3VybCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJb0V5ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJldmlldyhkb2MuZmlsZV91cmwsIGRvYy5kb2N1bWVudF90eXBlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXIgdGV4dC1sZyBob3ZlcjpzY2FsZS0xMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj17ZG9jLmZpbGVfdXJsfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9Eb3dubG9hZCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LWxnIGhvdmVyOnNjYWxlLTExMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yIGgtMzIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtkb2MuaXNJbWFnZSAmJiBkb2MuZmlsZV91cmwgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2RvYy5maWxlX3VybH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2RvYy5kb2N1bWVudF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCBvYmplY3QtY29udGFpbiBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJldmlldyhkb2MuZmlsZV91cmwsIGRvYy5kb2N1bWVudF90eXBlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICkgOiBkb2MuZmlsZV91cmwgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb0RvY3VtZW50IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC00eGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+Tm8gZmlsZSB1cGxvYWRlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMFwiPlxyXG4gICAgICAgICAgICAgICAgPElvRG9jdW1lbnQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LTV4bCBteC1hdXRvIG1iLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPk5vIGRvY3VtZW50cyB1cGxvYWRlZCBmb3IgdGhpcyBhdWN0aW9uLjwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBib3JkZXItdCBwdC00IG10LTRcIj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURvY3VtZW50QWN0aW9uKFwicGVuZGluZ1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy15ZWxsb3ctNTAwIGhvdmVyOmJnLXllbGxvdy02MDAgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBEb2NzIFBlbmRpbmdcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb2N1bWVudEFjdGlvbihcInZlcmlmeVwiKX1cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPCAxMDB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBNb3ZlIHRvIFZlcmlmaWNhdGlvblxyXG4gICAgICAgICAgICAgIHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPCAxMDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXhzIG9wYWNpdHktNzVcIj5cclxuICAgICAgICAgICAgICAgICAgKHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cyl9JSBjb21wbGV0ZSlcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURvY3VtZW50QWN0aW9uKFwiY29tcGxldGVcIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgaG92ZXI6YmctZ3JlZW4tNzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENvbXBsZXRlZFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge2NhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZShjdXJyZW50RG9jdW1lbnRzKSA8IDEwMCAmJiBjdXJyZW50RG9jdW1lbnRzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQteWVsbG93LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAg4pqg77iPIFBsZWFzZSB1cGxvYWQgYWxsIHJlcXVpcmVkIGRvY3VtZW50cyAoXHJcbiAgICAgICAgICAgICAgICB7UkVRVUlSRURfRE9DVU1FTlRTLmxlbmd0aCAtXHJcbiAgICAgICAgICAgICAgICAgIGN1cnJlbnREb2N1bWVudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgIChkb2MpID0+IGRvYy5maWxlX3VybCAmJiBkb2MuZG9jdW1lbnRfdHlwZSAhPT0gXCJEb2N1bWVudCBSZWZlcmVuY2VcIixcclxuICAgICAgICAgICAgICAgICAgKS5sZW5ndGh9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgcmVtYWluaW5nKSBiZWZvcmUgdmVyaWZpY2F0aW9uXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9Nb2RhbENvbXBvbmVudD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZWNlbnRBdWN0aW9uO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUmVjZW50QXVjdGlvbi5qc3gifQ==