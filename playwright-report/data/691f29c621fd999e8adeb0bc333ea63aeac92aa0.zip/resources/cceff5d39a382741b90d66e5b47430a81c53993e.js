import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HRSalaryManagement.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import {
  DatePicker,
  Drawer,
  Dropdown,
  Modal,
  Input,
  Form,
  Select,
  Button,
  message,
  Popconfirm,
  Empty
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport7_react["useEffect"]; const useState = __vite__cjsImport7_react["useState"]; const useMemo = __vite__cjsImport7_react["useMemo"];
import {
  TrendingUp,
  Target,
  CheckCircle,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  User
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import API from "/src/instance/TokenInstance.js";
import __vite__cjsImport10_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport10_dayjs.__esModule ? __vite__cjsImport10_dayjs.default : __vite__cjsImport10_dayjs;
import {
  Select as AntSelect,
  Segmented,
  Button as AntButton,
  Flex,
  Spin
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { PlusOutlined, DeleteOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import __vite__cjsImport17_dayjs_plugin_utc from "/node_modules/.vite/deps/dayjs_plugin_utc.js?v=819e0a34"; const utc = __vite__cjsImport17_dayjs_plugin_utc.__esModule ? __vite__cjsImport17_dayjs_plugin_utc.default : __vite__cjsImport17_dayjs_plugin_utc;
import { LoadingOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { MdOutlineMan } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { RiMoneyRupeeCircleFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
dayjs.extend(utc);
const HRSalaryManagement = () => {
  _s();
  const navigate = useNavigate();
  const [isOpenAddModal, setIsOpenAddModal] = useState(false);
  const [isOpenUpdateModal, setIsOpenUpdateModal] = useState(false);
  const [updateLoading, setUpdateLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [calculateLoading, setCalculateLoading] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [employeeDetails, setEmployeeDetails] = useState({});
  const [allSalaryPayments, setAllSalarypayments] = useState([]);
  const [employeeDetailsLoading, setEmployeeDetailsLoading] = useState(false);
  const [currentSalaryId, setCurrentSalaryId] = useState(null);
  const [calculatedSalary, setCalculatedSalary] = useState(null);
  const [showComponents, setShowComponents] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [form] = Form.useForm();
  const [dataTableLoading, setDataTableLoading] = useState(false);
  const [updateForm] = Form.useForm();
  const [alreadyPaidModalOpen, setAlreadyPaidModalOpen] = useState(false);
  const [existingSalaryRecord, setExistingSalaryRecord] = useState(null);
  const [isEditFormDirty, setIsEditFormDirty] = useState(false);
  const [paymentMode, setPaymentMode] = useState("cash");
  const [additionalSalaryDetails, setAdditionalSalaryDetails] = useState([]);
  const [additionalSalaryloading, setAdditionalSalaryloading] = useState(false);
  const [updateFormData, setUpdateFormData] = useState({
    employee_id: "",
    month: "",
    year: "",
    earnings: {
      basic: 0,
      hra: 0,
      travel_allowance: 0,
      medical_allowance: 0,
      basket_of_benifits: 0,
      performance_bonus: 0,
      other_allowances: 0,
      conveyance: 0
    },
    deductions: {
      income_tax: 0,
      esi: 0,
      epf: 0,
      professional_tax: 0
    },
    additional_payments: [],
    additional_deductions: [],
    advance_payments: [],
    calculated_incentive: 0,
    payment_method: "",
    transaction_id: "",
    monthly_business_info: {
      target: 0,
      // previous_remaining_target: 0,
      total_target: 0,
      total_business_closed: 0,
      current_remaining_target: 0
    },
    status: ""
  });
  const [payAsSalaryModalOpen, setPayAsSalaryModalOpen] = useState(false);
  const [payAsIncentiveModalOpen, setPayAsIncentiveModalOpen] = useState(false);
  const thisYear = dayjs().format("YYYY");
  const earningsObject = {
    basic: 0,
    hra: 0,
    travel_allowance: 0,
    medical_allowance: 0,
    basket_of_benifits: 0,
    performance_bonus: 0,
    other_allowances: 0,
    conveyance: 0
  };
  const deductionsObject = {
    income_tax: 0,
    esi: 0,
    epf: 0,
    professional_tax: 0
  };
  const columns = [
    { key: "siNo", header: "SL. NO" },
    { key: "employeeName", header: "Employee Name" },
    { key: "employeeCode", header: "Employee Id" },
    { key: "salaryYear", header: "Year" },
    { key: "salaryMonth", header: "Salary Month" },
    { key: "netPayable", header: "Net Payable" },
    { key: "paidAmount", header: "Paid Amount" },
    { key: "status", header: "Payment Status" },
    { key: "action", header: "Action" }
  ];
  const excelColumns = [
    { key: "siNo", header: "SL. NO" },
    { key: "employeeName", header: "Employee Name" },
    { key: "employeeCode", header: "Employee Id" },
    { key: "salaryYear", header: "Year" },
    { key: "salaryMonth", header: "Month" },
    { key: "totalDays", header: "Total Days" },
    { key: "presentDays", header: "Present Days" },
    { key: "absentDays", header: "Absent Days" },
    { key: "paidLeaves", header: "Paid Leaves" },
    { key: "basic", header: "Basic" },
    { key: "hra", header: "HRA" },
    { key: "travelAllowance", header: "Travel Allowanace" },
    { key: "medicalAllowance", header: "Medical Allowance" },
    { key: "basketOfBenifits", header: "Basket Of Benifits" },
    { key: "performanceBonus", header: "Performance Bonus" },
    { key: "otherAllowances", header: "Other Allowances" },
    { key: "conveyance", header: "Conveyance" },
    { key: "incomeTax", header: "Income Tax" },
    { key: "esi", header: "Esi" },
    { key: "epf", header: "Epf" },
    { key: "professionalTax", header: "Professional Tax" },
    { key: "status", header: "Payment Status" },
    { key: "netPayable", header: "Net Payable" },
    { key: "paidAmount", header: "Paid Amount" }
  ];
  const months = [
    { label: "January", value: "January", disabled: false },
    { label: "February", value: "February", disabled: false },
    { label: "March", value: "March", disabled: false },
    { label: "April", value: "April", disabled: false },
    { label: "May", value: "May", disabled: false },
    { label: "June", value: "June", disabled: false },
    { label: "July", value: "July", disabled: false },
    { label: "August", value: "August", disabled: false },
    {
      label: "September",
      value: "September",
      disabled: false
    },
    { label: "October", value: "October", disabled: false },
    { label: "November", value: "November", disabled: false },
    { label: "December", value: "December", disabled: false }
  ];
  const previousMonth = months[dayjs().subtract(2, "month").format("MM")]?.label;
  const [formData, setFormData] = useState({
    employee_id: "",
    month: previousMonth,
    year: thisYear,
    earnings: {
      basic: 0,
      hra: 0,
      travel_allowance: 0,
      medical_allowance: 0,
      basket_of_benifits: 0,
      performance_bonus: 0,
      other_allowances: 0,
      conveyance: 0
    },
    deductions: {
      income_tax: 0,
      esi: 0,
      epf: 0,
      professional_tax: 0
    },
    additional_payments: [],
    additional_deductions: [],
    advance_payments: [],
    calculated_incentive: 0,
    total_salary_payable: 0,
    paid_amount: 0,
    payment_method: "",
    transaction_id: "",
    monthly_business_info: {
      target: 0,
      // previous_remaining_target: 0,
      total_target: 0,
      total_business_closed: 0,
      current_remaining_target: 0
    },
    total_salary: 0,
    pigmy_perc: 0,
    loan_perc: 0,
    pigmy_collection_incentive: 0,
    loan_collection_incentive: 0,
    advance_repayment: {
      pay_date: "",
      amount: 0,
      transaction_id: "",
      remarks: "",
      cheque_number: "",
      cheque_date: "",
      cheque_bank_name: "",
      cheque_bank_branch: ""
    }
  });
  const [showCollectionContinue, setShowCollectionContinue] = useState(false);
  const [collectionLoading, setCollectionLoading] = useState(false);
  const [isBusinessLoading, setIsBusinessLoading] = useState(false);
  const handlePayAsSalary = () => {
    setPayAsSalaryModalOpen(true);
  };
  const handlePayAsIncentive = () => {
    setPayAsIncentiveModalOpen(true);
  };
  const confirmPayAsSalary = () => {
    const totalTarget = Number(
      formData.monthly_business_info.total_target || 0
    );
    const totalBusinessClosed = Number(
      formData.monthly_business_info.total_business_closed || 0
    );
    const currentRemainingTarget = Number(
      formData.monthly_business_info.current_remaining_target || 0
    );
    const rawIncentive = (totalTarget - totalBusinessClosed) / 100;
    let incentiveAmount = 0;
    if (rawIncentive > 0) {
      incentiveAmount = totalBusinessClosed / 100;
    } else if (rawIncentive < 0) {
      incentiveAmount = Math.abs(rawIncentive);
    }
    const updatedRemainingTarget = currentRemainingTarget < 0 ? 0 : currentRemainingTarget;
    setFormData((prev) => ({
      ...prev,
      additional_payments: [
        ...prev.additional_payments,
        {
          name: "Salary Payable",
          value: incentiveAmount
        }
      ],
      monthly_business_info: {
        ...prev.monthly_business_info,
        current_remaining_target: updatedRemainingTarget
      },
      calculated_incentive: 0
      // Reset calculated incentive
    }));
    message.success("Salary payable amount added successfully");
    setPayAsSalaryModalOpen(false);
  };
  const confirmPayAsIncentive = () => {
    const totalTarget = Number(
      formData.monthly_business_info.total_target || 0
    );
    const totalBusinessClosed = Number(
      formData.monthly_business_info.total_business_closed || 0
    );
    const rawIncentive = (totalTarget - totalBusinessClosed) / 100;
    let incentiveAmount = 0;
    if (rawIncentive > 0) {
      incentiveAmount = totalBusinessClosed / 100;
    } else if (rawIncentive < 0) {
      incentiveAmount = Math.abs(rawIncentive);
    }
    setFormData((prev) => ({
      ...prev,
      calculated_incentive: incentiveAmount,
      monthly_business_info: {
        ...prev.monthly_business_info,
        current_remaining_target: 0
      }
    }));
    message.success("Incentive payable amount added successfully");
    setPayAsIncentiveModalOpen(false);
  };
  async function fetchEmployees() {
    try {
      const responseData = await API.get("/employee");
      const filteredEmployee = responseData?.data?.employee?.map((emp) => ({
        value: emp?._id,
        label: `${emp?.name} | ${emp?.phone_number}` || "Unknown Employee"
      }));
      setEmployees(filteredEmployee || []);
    } catch (error) {
      setEmployees([]);
    }
  }
  async function fetchAdditionalSalaryPayments(employeeId) {
    try {
      setAdditionalSalaryloading(true);
      const responseData = await API.get(`/salary-payment/additional/employees?employee_id=${employeeId}&year=${formData?.year}&month=${formData?.month}`);
      setAdditionalSalaryDetails(responseData?.data?.data || []);
    } catch (error) {
      setAdditionalSalaryDetails([]);
    } finally {
      setAdditionalSalaryloading(false);
    }
  }
  useEffect(() => {
    fetchEmployees();
  }, []);
  async function getSalaryById(id) {
    try {
      const response = await API.get(`/salary-payment/${id}`);
      return response?.data?.data;
    } catch (error) {
      console.error("Error fetching salary by ID:", error);
      return null;
    }
  }
  const fetchEmployeeTarget = async (employeeId, start_date, end_date) => {
    try {
      const response = await API.get(`/target/employees/${employeeId}`, {
        params: { start_date, end_date }
      });
      return response.data?.total_target || 0;
    } catch (err) {
      console.error("Failed to fetch target:", err);
      return 0;
    }
  };
  const fetchPreviousRemainingTarget = async (employeeId) => {
    try {
      const response = await API.get(
        `/salary-payment/employees/${employeeId}?month=${formData.month}&year=${formData.year}`
      );
      return response.data?.data.remainingTarget || 0;
    } catch (err) {
      console.error("Failed to fetch Remaining Target:", err);
      return 0;
    }
  };
  const fetchEmployeeBusinessClosed = async (employeeId, start_date, end_date) => {
    try {
      const response = await API.get(
        `/enroll/employee/${employeeId}/incentive`,
        { params: { start_date, end_date } }
      );
      return response.data?.incentiveSummary?.total_group_value || 0;
    } catch (err) {
      console.error("Failed to fetch incentive:", err);
      return 0;
    }
  };
  const getValidMonths = (joiningDateStr, selectedYear) => {
    if (!joiningDateStr || !selectedYear) {
      return months.map((m) => ({ ...m, disabled: true }));
    }
    const joining = dayjs(joiningDateStr);
    const today = dayjs();
    const joinYear = joining.year();
    const currentYear = today.year();
    const selectedYearNum = Number(selectedYear);
    return months.map((month, index) => {
      const isBeforeJoining = selectedYearNum === joinYear && index < joining.month();
      const isAfterToday = selectedYearNum === currentYear && index > today.month();
      const disabled = selectedYearNum < joinYear || selectedYearNum > currentYear || isBeforeJoining || isAfterToday;
      return { ...month, disabled };
    });
  };
  useEffect(() => {
    if (formData.employee_id && formData.year && employeeDetails?.joining_date) {
      const validMonths = getValidMonths(
        employeeDetails.joining_date,
        formData.year
      );
      const currentMonthValid = validMonths.some(
        (m) => m.value === formData.month && !m.disabled
      );
      if (!currentMonthValid) {
        const firstValid = validMonths.find((m) => !m.disabled);
        if (firstValid) {
          setFormData((prev) => ({
            ...prev,
            month: firstValid.value
          }));
        }
      }
    }
  }, [formData.year, formData.employee_id, employeeDetails?.joining_date]);
  const handleEdit = async (id) => {
    try {
      setUpdateLoading(true);
      setIsOpenUpdateModal(true);
      setIsEditFormDirty(false);
      const salaryData = await getSalaryById(id);
      if (salaryData) {
        setCurrentSalaryId(id);
        const yearAsDayjs = dayjs(salaryData.salary_year, "YYYY");
        const formData2 = {
          employee_id: salaryData?.employee_id?._id,
          month: salaryData?.salary_month,
          year: yearAsDayjs,
          earnings: salaryData?.earnings,
          deductions: salaryData?.deductions,
          additional_payments: salaryData?.additional_payments || [],
          additional_deductions: salaryData?.additional_deductions || [],
          advance_payments: salaryData?.advance_payments || [],
          calculated_incentive: salaryData?.calculated_incentive || 0,
          total_salary_payable: salaryData?.total_salary_payable || 0,
          paid_amount: salaryData?.paid_amount || 0,
          payment_method: salaryData?.payment_method,
          transaction_id: salaryData?.transaction_id || "",
          pay_date: salaryData?.pay_date ? moment(salaryData?.pay_date) : moment(),
          attendance_details: salaryData?.attendance_details || {},
          monthly_business_info: salaryData?.monthly_business_info || {
            target: 0,
            // previous_remaining_target: 0,
            total_target: 0,
            total_business_closed: 0,
            current_remaining_target: 0
          },
          status: salaryData?.status
        };
        setUpdateFormData(formData2);
        updateForm.setFieldsValue(formData2);
      }
    } catch (error) {
      message.error("Failed to fetch salary details");
    } finally {
      setUpdateLoading(false);
    }
  };
  const handleDeleteConfirm = async (id) => {
    try {
      setDeleteLoading(true);
      await API.delete(`/salary-payment/${id}`);
      message.success("Salary Management deleted successfully");
      setDeleteModalOpen(false);
      getAllSalary();
    } catch (error) {
      message.error("Failed to delete Salary Management");
    } finally {
      setDeleteLoading(false);
    }
  };
  const handleFetchCollectionIncentive = async () => {
    try {
      setCollectionLoading(true);
      const monthIndex = moment().month(formData.month).month();
      const start_date = moment().year(formData.year).month(monthIndex).startOf("month").format("YYYY-MM-DD");
      const end_date = moment().year(formData.year).month(monthIndex).endOf("month").format("YYYY-MM-DD");
      const response = await API.get(
        `/payment/pigmy-loan/collection/${formData.employee_id}/pigmy-perc/${formData.pigmy_perc}/loan-perc/${formData.loan_perc}`,
        { params: { from_date: start_date, to_date: end_date } }
      );
      const { total_loan_collections_perc, total_pigmy_collections_perc } = response.data.data;
      setFormData((prev) => ({
        ...prev,
        loan_collection_incentive: total_loan_collections_perc || 0,
        pigmy_collection_incentive: total_pigmy_collections_perc || 0
      }));
      setShowCollectionContinue(false);
      message.success("Collection data fetched successfully");
    } catch (error) {
      message.error("Failed to fetch collection data");
    } finally {
      setCollectionLoading(false);
    }
  };
  const handlePrint = (salaryPaymentId) => {
    navigate("/salary-slip-print/" + salaryPaymentId);
  };
  const dropDownItems = (salaryPayment) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-blue-600",
            onClick: () => handlePrint(salaryPayment?._id),
            children: "Print"
          },
          salaryPayment?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 577,
            columnNumber: 7
          },
          this
        )
      },
      {
        key: "2",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600",
            onClick: () => handleEdit(salaryPayment._id),
            children: "View"
          },
          salaryPayment?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 588,
            columnNumber: 7
          },
          this
        )
      },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-red-600",
            onClick: () => {
              setDeleteId(salaryPayment?._id);
              setDeleteModalOpen(true);
            },
            children: "Delete"
          },
          salaryPayment?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 599,
            columnNumber: 7
          },
          this
        )
      }
    ];
    return dropDownItemList;
  };
  async function fetchSalaryDetails() {
    try {
      setEmployeeDetailsLoading(true);
      const responseData = await API.get(`/employee/${formData.employee_id}`);
      const emp = responseData?.data?.data;
      const updatedEarnings = {
        ...earningsObject,
        ...emp?.earnings,
        salary: emp?.salary || 0
      };
      const updatedDeductions = {
        ...deductionsObject,
        ...emp?.deductions
      };
      setEmployeeDetails(emp);
      setFormData((prev) => ({
        ...prev,
        earnings: updatedEarnings,
        deductions: updatedDeductions,
        total_salary: emp?.salary || 0
      }));
    } catch (error) {
      setEmployeeDetails({});
    } finally {
      setEmployeeDetailsLoading(false);
    }
  }
  useEffect(() => {
    if (formData.employee_id && formData.month && formData.year) {
      loadTargetAndIncentive();
      fetchSalaryDetails();
    }
  }, [formData.employee_id, formData.month, formData.year]);
  const loadTargetAndIncentive = async () => {
    try {
      setIsBusinessLoading(true);
      const monthIndex = moment().month(formData.month).month();
      const year = formData.year;
      const start_date = moment().year(year).month(monthIndex).startOf("month").format("YYYY-MM-DD");
      const end_date = moment().year(year).month(monthIndex).endOf("month").format("YYYY-MM-DD");
      const targetValue = await fetchEmployeeTarget(
        formData.employee_id,
        start_date,
        end_date
      );
      const businessClosedValue = await fetchEmployeeBusinessClosed(
        formData.employee_id,
        start_date,
        end_date
      );
      const employeePreviousRemainingTarget = await fetchPreviousRemainingTarget(formData.employee_id);
      await fetchAdditionalSalaryPayments(formData.employee_id);
      const totalTarget = (targetValue || 0) + (employeePreviousRemainingTarget || 0);
      const remainingTarget = (totalTarget || 0) - (businessClosedValue || 0);
      setFormData((prev) => ({
        ...prev,
        monthly_business_info: {
          target: targetValue ?? 0,
          // previous_remaining_target: employeePreviousRemainingTarget ?? 0,
          total_target: totalTarget ?? 0,
          total_business_closed: businessClosedValue ?? 0,
          current_remaining_target: remainingTarget ?? 0
        }
      }));
    } catch (err) {
      console.error("Failed to auto-load target & incentive", err);
    } finally {
      setIsBusinessLoading(false);
    }
  };
  useEffect(() => {
    if (formData.employee_id) {
      fetchSalaryDetails();
    }
  }, [formData?.employee_id]);
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === "amount") {
      let cleaned = value.replace(/[^0-9.]/g, "");
      const dotCount = (cleaned.match(/\./g) || []).length;
      if (dotCount > 1) return;
      setFormData((prev) => ({
        ...prev,
        advance_repayment: {
          ...prev.advance_repayment,
          [name]: cleaned
        }
      }));
      return;
    }
    setFormData((prev) => ({
      ...prev,
      advance_repayment: {
        ...prev.advance_repayment,
        [name]: value
      }
    }));
  };
  const handleChange = (name, value) => {
    setFormData((prev) => {
      let updatedFormData = { ...prev, [name]: value };
      if (name === "month") {
        updatedFormData = {
          ...updatedFormData,
          calculated_incentive: 0
        };
      }
      if (["employee_id", "month", "year", "target"].includes(name)) {
        setCalculatedSalary(null);
        setShowComponents(false);
        updatedFormData = {
          ...updatedFormData,
          paid_amount: 0,
          transaction_id: "",
          payment_method: "",
          // Reset advance_repayment fields
          advance_repayment: {
            pay_date: "",
            amount: 0,
            transaction_id: "",
            remarks: "",
            cheque_number: "",
            cheque_date: "",
            cheque_bank_name: "",
            cheque_bank_branch: ""
          }
        };
      }
      return updatedFormData;
    });
    setAdditionalSalaryDetails([]);
  };
  const handleDeductionsChange = (name, value) => {
    setFormData((prev) => ({
      ...prev,
      earnings: { ...prev.earnings },
      deductions: { ...prev.deductions, [name]: value },
      paid_amount: 0,
      transaction_id: "",
      payment_method: ""
    }));
    setCalculatedSalary(null);
    setShowComponents(false);
  };
  const handleEarningsChange = (name, value) => {
    setFormData((prev) => ({
      ...prev,
      earnings: { ...prev.earnings, [name]: value },
      deductions: { ...prev.deductions },
      paid_amount: 0,
      transaction_id: "",
      payment_method: ""
    }));
    setCalculatedSalary(null);
    setShowComponents(false);
  };
  const handleAdvancePaymentChange = (index, field, value) => {
    const updatedPayments = [...formData.advance_payments];
    updatedPayments[index] = { ...updatedPayments[index], [field]: value };
    setFormData((prev) => ({ ...prev, advance_payments: updatedPayments }));
  };
  const addAdvancePayment = () => {
    setFormData((prev) => ({
      ...prev,
      advance_payments: [...prev.advance_payments, { name: "", value: 0 }]
    }));
  };
  const removeAdvancePayment = (index) => {
    const updatedPayments = formData.advance_payments.filter(
      (_, i) => i !== index
    );
    setFormData((prev) => ({ ...prev, advance_payments: updatedPayments }));
  };
  const handleAdditionalPaymentChange = (index, field, value) => {
    const updatedPayments = [...formData.additional_payments];
    updatedPayments[index] = { ...updatedPayments[index], [field]: value };
    setFormData((prev) => ({ ...prev, additional_payments: updatedPayments }));
  };
  const addAdditionalPayment = () => {
    setFormData((prev) => ({
      ...prev,
      additional_payments: [
        ...prev.additional_payments,
        { name: "", value: 0 }
      ]
    }));
  };
  const removeAdditionalPayment = (index) => {
    const updatedPayments = formData.additional_payments.filter(
      (_, i) => i !== index
    );
    setFormData((prev) => ({ ...prev, additional_payments: updatedPayments }));
  };
  const handleAdditionalDeductionChange = (index, field, value) => {
    const updatedDeductions = [...formData.additional_deductions];
    updatedDeductions[index] = { ...updatedDeductions[index], [field]: value };
    setFormData((prev) => ({
      ...prev,
      additional_deductions: updatedDeductions
    }));
  };
  const addAdditionalDeduction = () => {
    setFormData((prev) => ({
      ...prev,
      additional_deductions: [
        ...prev.additional_deductions,
        { name: "", value: 0 }
      ]
    }));
  };
  const removeAdditionalDeduction = (index) => {
    const updatedDeductions = formData.additional_deductions.filter(
      (_, i) => i !== index
    );
    setFormData((prev) => ({
      ...prev,
      additional_deductions: updatedDeductions
    }));
  };
  const updateTotalEarnings = useMemo(() => {
    const earnings = updateFormData?.earnings || {};
    return Object.values(earnings).reduce((sum, v) => sum + Number(v || 0), 0);
  }, [updateFormData]);
  const updateTotalDeductions = useMemo(() => {
    const deductions = updateFormData?.deductions || {};
    const base = Object.values(deductions).reduce(
      (sum, v) => sum + Number(v || 0),
      0
    );
    return base;
  }, [updateFormData]);
  async function handleCalculateSalary() {
    try {
      setCalculateLoading(true);
      setFormData((prev) => ({
        ...prev,
        additional_payments: [],
        additional_deductions: [],
        advance_payments: []
      }));
      const monthIndex = moment().month(formData.month).month();
      const start_date = moment().year(formData.year).month(monthIndex).startOf("month").format("YYYY-MM-DD");
      const end_date = moment().year(formData.year).month(monthIndex).endOf("month").format("YYYY-MM-DD");
      const [salaryRes, collectionRes] = await Promise.all(
        [
          API.get("/salary-payment/calculate", {
            params: {
              employee_id: formData.employee_id,
              month: formData.month,
              year: formData.year,
              earnings: formData.earnings,
              deductions: formData.deductions
            }
          }),
          API.get(
            `/payment/pigmy-loan/collection/${formData.employee_id}/pigmy-perc/${formData.pigmy_perc}/loan-perc/${formData.loan_perc}`,
            { params: { from_date: start_date, to_date: end_date } }
          )
        ]
      );
      const calculated = salaryRes.data.data;
      const { total_loan_collections_perc, total_pigmy_collections_perc } = collectionRes.data.data;
      setCalculatedSalary(calculated);
      setFormData((prev) => ({
        ...prev,
        total_salary_payable: calculated.calculated_salary,
        loan_collection_incentive: total_loan_collections_perc || 0,
        pigmy_collection_incentive: total_pigmy_collections_perc || 0
      }));
      setShowComponents(true);
      message.success("Salary and Collections calculated successfully");
    } catch (error) {
      console.error("Error in calculation:", error);
      if (error.response?.status === 406 && error.response?.data?.existing_salary) {
        setExistingSalaryRecord(error.response.data.existing_salary);
        setAlreadyPaidModalOpen(true);
        setCalculatedSalary(null);
        setShowComponents(false);
        return;
      }
      message.error(error.response?.data?.message || "Failed to calculate details");
    } finally {
      setCalculateLoading(false);
    }
  }
  async function handleAddSalary() {
    try {
      const baseSalary = calculatedSalary ? calculatedSalary.calculated_salary : Object.values(formData.earnings).reduce(
        (sum, v) => sum + Number(v || 0),
        0
      ) - Object.values(formData.deductions).reduce(
        (sum, v) => sum + Number(v || 0),
        0
      );
      const advanceTotal = formData.advance_payments.reduce(
        (sum, a) => sum + Number(a.value || 0),
        0
      );
      const additionalPaymentsTotal = formData.additional_payments.reduce(
        (sum, payment) => sum + Number(payment.value || 0),
        0
      );
      const additionalDeductionsTotal = formData.additional_deductions.reduce(
        (sum, deduction) => sum + Number(deduction.value || 0),
        0
      );
      let totalSalaryPayable = 0;
      let finalCalculatedIncentive = formData.calculated_incentive || 0;
      const totalTarget = Number(
        formData.monthly_business_info.total_target || 0
      );
      const totalBusinessClosed = Number(
        formData.monthly_business_info.total_business_closed || 0
      );
      const rawIncentive = (totalTarget - totalBusinessClosed) / 100;
      if (rawIncentive > 0) {
        totalSalaryPayable = 0;
        totalSalaryPayable += advanceTotal;
        totalSalaryPayable += additionalPaymentsTotal - additionalDeductionsTotal;
        totalSalaryPayable -= totalDeductions;
      } else if (rawIncentive < 0) {
        totalSalaryPayable = baseSalary;
        totalSalaryPayable += advanceTotal;
        totalSalaryPayable += additionalPaymentsTotal - additionalDeductionsTotal;
      } else {
        totalSalaryPayable = baseSalary;
        totalSalaryPayable += advanceTotal;
        totalSalaryPayable += additionalPaymentsTotal - additionalDeductionsTotal;
      }
      const paidAmount = Number(formData.paid_amount || 0);
      const remainingBalance = totalSalaryPayable - paidAmount;
      const attendanceDetails = calculatedSalary ? {
        total_days: calculatedSalary.total_days,
        present_days: calculatedSalary.present_days,
        paid_days: calculatedSalary.paid_days,
        lop_days: calculatedSalary.lop_days,
        lop: calculatedSalary.lop,
        per_day_salary: calculatedSalary.per_day_salary,
        calculated_salary: calculatedSalary.calculated_salary,
        absent_days: calculatedSalary.absent_days || 0,
        leave_days: calculatedSalary.leave_days || 0,
        half_days: calculatedSalary.half_days || 0,
        salary_from_date: calculatedSalary.salary_from_date,
        salary_to_date: calculatedSalary.salary_to_date
      } : {};
      const monthlyTargetIncentive = {
        target: Number(formData.monthly_business_info.target || 0),
        total_business_closed: Number(
          formData.monthly_business_info.total_business_closed || 0
        ),
        // previous_remaining_target:
        //   formData.monthly_business_info.previous_remaining_target,
        total_target: formData.monthly_business_info.total_target,
        current_remaining_target: formData.monthly_business_info.current_remaining_target
      };
      const salaryData = {
        employee_id: formData?.employee_id,
        additional_salaries: additionalSalaryDetails?.additional_salaries || [],
        advance_repayment: formData.advance_repayment,
        salary_from_date: calculatedSalary ? calculatedSalary?.salary_from_date : /* @__PURE__ */ new Date(),
        salary_to_date: calculatedSalary ? calculatedSalary.salary_to_date : /* @__PURE__ */ new Date(),
        salary_month: formData.month,
        salary_year: formData.year,
        earnings: formData.earnings,
        deductions: formData.deductions,
        additional_payments: formData.additional_payments,
        additional_deductions: formData.additional_deductions,
        advance_payments: formData.advance_payments,
        calculated_incentive: finalCalculatedIncentive,
        paid_days: calculatedSalary ? calculatedSalary.paid_days : 30,
        lop: calculatedSalary ? calculatedSalary.lop : 0,
        lop_days: calculatedSalary ? calculatedSalary.lop_days : 0,
        net_payable: totalSalaryPayable,
        paid_amount: paidAmount,
        remaining_balance: remainingBalance,
        total_salary_payable: totalSalaryPayable,
        payment_method: formData.payment_method,
        status: "Pending",
        attendance_details: attendanceDetails,
        monthly_business_info: monthlyTargetIncentive,
        loan_collection: {
          loan_perc: formData?.loan_perc,
          loan_collection_incentive: formData?.loan_collection_incentive
        },
        pigmy_collection: {
          pigmy_perc: formData?.pigmy_perc,
          pigmy_collection_incentive: formData?.pigmy_collection_incentive
        }
      };
      await API.post("/salary-payment/", salaryData);
      message.success("Salary added successfully");
      setIsOpenAddModal(false);
      setCalculatedSalary(null);
      setShowComponents(false);
      getAllSalary();
    } catch (error) {
      console.error("Error adding salary:", error);
      message.error(error?.response?.data?.message ?? "Failed to add Salary");
    }
  }
  async function getAllSalary() {
    try {
      setDataTableLoading(true);
      const response = await API.get("/salary-payment/all");
      const responseData = response?.data?.data || [];
      const filteredData = responseData.map((data, index) => ({
        siNo: index + 1,
        _id: data?._id,
        employeeName: data?.employee_id?.name,
        employeeCode: data?.employee_id?.employeeCode,
        salaryMonth: data?.salary_month,
        salaryYear: data?.salary_year,
        netPayable: data?.total_salary_payable,
        paidAmount: data?.paid_amount,
        presentDays: (data?.attendance_details?.present_days || 0) + (data?.attendance_details?.half_days || 0),
        absentDays: data?.attendance_details?.absent_days ?? 0,
        paidLeaves: data?.attendance_details?.leave_days ?? 0,
        totalDays: data?.attendance_details?.total_days ?? 0,
        basic: data?.earnings?.basic,
        hra: data?.earnings?.hra,
        travelAllowance: data?.earnings?.travel_allowance,
        medicalAllowance: data?.earnings?.medical_allowance,
        basketOfBenifits: data?.earnings?.basket_of_benifits,
        performanceBonus: data?.earnings?.performance_bonus,
        otherAllowances: data?.earnings?.other_allowances,
        conveyance: data?.earnings?.conveyance,
        incomeTax: data?.deductions?.income_tax,
        esi: data?.deductions?.esi,
        epf: data?.deductions?.epf,
        professionalTax: data?.deductions?.professional_tax,
        salaryAdvance: data?.deductions?.salary_advance,
        status: data?.status,
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: dropDownItems(data)
            },
            placement: "bottomLeft",
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1133,
              columnNumber: 15
            }, this)
          },
          data?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1126,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 1125,
          columnNumber: 9
        }, this)
      }));
      setAllSalarypayments([...filteredData]);
    } catch (error) {
      setAllSalarypayments([]);
    } finally {
      setDataTableLoading(false);
    }
  }
  useEffect(() => {
    getAllSalary();
  }, []);
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" || selectedMode === "online/upi" ? prevData.transaction_id : ""
    }));
  };
  const totalEarningsExcludingSalary = useMemo(() => {
    const earnings = formData.earnings || {};
    return Object.keys(earnings).filter((key) => key !== "salary").reduce((sum, key) => sum + (Number(earnings[key]) || 0), 0);
  }, [formData.earnings]);
  const totalDeductions = useMemo(() => {
    const baseDeductions = formData.deductions || {};
    const baseTotal = Object.values(baseDeductions).reduce(
      (sum, val) => sum + (Number(val) || 0),
      0
    );
    return baseTotal;
  }, [formData.deductions]);
  const calculatedIncentive = useMemo(
    () => {
      const totalTarget = Number(
        formData.monthly_business_info.total_target || 0
      );
      const totalBusinessClosed = Number(
        formData.monthly_business_info.total_business_closed || 0
      );
      const rawIncentive = (totalTarget - totalBusinessClosed) / 100;
      if (rawIncentive > 0) {
        return totalBusinessClosed / 100;
      } else if (rawIncentive < 0) {
        return Math.abs(rawIncentive);
      } else {
        return 0;
      }
    },
    [
      formData.monthly_business_info.total_target,
      formData.monthly_business_info.total_business_closed
    ]
  );
  const NAV_LINKS = [
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1206,
        columnNumber: 11
      }, this),
      label: "Salary payment"
    },
    {
      to: "/staff-menu/employee-menu/employee-statement",
      icon: /* @__PURE__ */ jsxDEV(User, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1211,
        columnNumber: 11
      }, this),
      label: "Salary Ledger"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-in-menu/advance-payment-in",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1216,
        columnNumber: 11
      }, this),
      label: "Advance repayment"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-incentive",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1221,
        columnNumber: 11
      }, this),
      label: "Salary incentive"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/additional-salary",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1226,
        columnNumber: 11
      }, this),
      label: "Additional salary"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1234,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1235,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 1237,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Salary Management" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 1238,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end items-center w-full", children: /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setIsOpenAddModal(true),
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Add Salary"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1242,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1241,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1240,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-widest text-gray-400 mb-3", children: "Quick navigator" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1251,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: NAV_LINKS.map(
              (link) => /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: link.to,
                  className: "flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:border-blue-400 hover:text-blue-600 hover:bg-blue-50 transition-all",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-blue-500", children: link.icon }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1261,
                      columnNumber: 21
                    }, this),
                    link.label
                  ]
                },
                link.to,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1256,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1254,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1250,
            columnNumber: 13
          }, this),
          dataTableLoading ? /* @__PURE__ */ jsxDEV(
            Spin,
            {
              indicator: /* @__PURE__ */ jsxDEV(LoadingOutlined, { style: { fontSize: 48 }, spin: true }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1270,
                columnNumber: 26
              }, this),
              className: "w-full"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1269,
              columnNumber: 13
            },
            this
          ) : (allSalaryPayments || []).length > 0 ? /* @__PURE__ */ jsxDEV(DataTable, { columns, data: allSalaryPayments, exportCols: excelColumns, exportedFileName: "Salary Payments.csv", exportedPdfName: "Salary Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1274,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(Empty, { description: "No Salary Data Found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1276,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 1239,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1236,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
      lineNumber: 1233,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: "Add New Salary",
        width: "65%",
        className: "payment-drawer",
        open: isOpenAddModal,
        onClose: () => {
          setIsOpenAddModal(false);
          setCalculatedSalary(null);
          setShowComponents(false);
        },
        closable: true,
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => setIsOpenAddModal(false),
              className: "bg-red-600 hover:bg-red-700 text-white",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1294,
              columnNumber: 13
            },
            this
          ),
          calculatedSalary && /* @__PURE__ */ jsxDEV(Button, { type: "primary", onClick: handleAddSalary, children: "Save Salary" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1300,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 1293,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "form-group w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
              "Select Employee ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-600", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1309,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1308,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                optionFilterProp: "label",
                filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                filterSort: (optionA, optionB) => (optionA?.label ?? "").toLowerCase().localeCompare((optionB?.label ?? "").toLowerCase()),
                style: { width: "100%" },
                placeholder: "Search to Select Employee",
                options: employees,
                onChange: (value) => handleChange("employee_id", value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1311,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1307,
            columnNumber: 11
          }, this),
          !employeeDetailsLoading ? formData.employee_id && Object.values(employeeDetails).length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
                  "Select Year ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-600", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1337,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1336,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  DatePicker,
                  {
                    value: formData.year ? dayjs(formData.year, "YYYY") : null,
                    onChange: (date, dateString) => handleChange("year", dateString),
                    picker: "year",
                    style: { width: "100%" },
                    disabledDate: (current) => {
                      if (!employeeDetails?.joining_date) return false;
                      const joinYear = dayjs(
                        employeeDetails.joining_date
                      ).year();
                      const currentYear = dayjs().year();
                      const year = current ? current.year() : null;
                      return year < joinYear || year > currentYear;
                    }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1339,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1335,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
                  "Select Month ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-600", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1361,
                    columnNumber: 36
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1360,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Segmented,
                  {
                    className: "[&_.ant-segmented-item-selected]:!bg-green-600 [&_.ant-segmented-item-selected]:!text-white",
                    value: formData.month,
                    options: getValidMonths(
                      employeeDetails?.joining_date,
                      formData.year
                    ),
                    onChange: (value) => handleChange("month", value),
                    style: { width: "%" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1363,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1359,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1334,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-4 rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Employee Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1376,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1381,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      placeholder: "Name",
                      value: employeeDetails?.name,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1384,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1380,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Email" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1393,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      placeholder: "Email",
                      value: employeeDetails?.email,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1396,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1392,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1405,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      placeholder: "Phone Number",
                      value: employeeDetails?.phone_number,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1408,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1404,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Joining Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1417,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      placeholder: "Joining Date",
                      value: employeeDetails?.joining_date?.split("T")[0],
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1420,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1416,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Employee ID" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1429,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      placeholder: "Employee Id",
                      value: employeeDetails?.employeeCode,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1432,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1428,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1379,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-4 border-t border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold mb-4", children: "Earnings" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1444,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Gross Salary" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1447,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.salary || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1450,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1446,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Basic Salary" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1458,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.basic || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1461,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(formData?.earnings?.basic || 0) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1467,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1457,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "House Rent Allowance (HRA)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1472,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.hra || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1475,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(formData?.earnings?.hra || 0) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1481,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1471,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Travel Allowance" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1486,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.travel_allowance || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1489,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.earnings?.travel_allowance || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1495,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1485,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Medical Allowance" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1502,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.medical_allowance || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1505,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.earnings?.medical_allowance || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1511,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1501,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Basket of Benefits" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1518,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.basket_of_benifits || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1521,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.earnings?.basket_of_benifits || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1527,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1517,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Performance Bonus" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1534,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.performance_bonus || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1537,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.earnings?.performance_bonus || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1543,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1533,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Other Allowances" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1550,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.other_allowances || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1553,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.earnings?.other_allowances || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1559,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1549,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Conveyance" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1566,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.earnings?.conveyance || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1569,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.earnings?.conveyance || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1575,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1565,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1445,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1443,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-4 border-t border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold  mb-4", children: "Deductions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1586,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Income Tax" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1589,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.deductions?.income_tax || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1592,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.deductions?.income_tax || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1598,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1588,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "ESI (Employee State Insurance)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1605,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.deductions?.esi || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1608,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(formData?.deductions?.esi || 0) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1614,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1604,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "EPF (Employee Provident Fund)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1619,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.deductions?.epf || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1622,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(formData?.deductions?.epf || 0) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1628,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1618,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Professional Tax" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1633,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: formData?.deductions?.professional_tax || 0,
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1636,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                      formData?.deductions?.professional_tax || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1642,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1632,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group mt-2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Total Deductions" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1649,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                        value: totalDeductions.toFixed(2),
                        disabled: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1652,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(totalDeductions.toFixed(2)) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1658,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1648,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1587,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1585,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1375,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-gradient-to-br from-white to-slate-50 rounded-2xl border border-slate-200 p-8 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(BarChart3, { className: "w-6 h-6 text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1670,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1669,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-xl text-gray-900", children: "Monthly Target & Incentive" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1672,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1668,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1667,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 md:grid-cols-4 lg:grid-cols-4 gap-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-2", children: [
                    /* @__PURE__ */ jsxDEV(Target, { className: "w-4 h-4 text-blue-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1682,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("label", { className: "font-semibold text-gray-700 text-sm", children: "Current Month Target" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1683,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1681,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      value: formData?.monthly_business_info?.target || 0,
                      disabled: true,
                      className: "w-full px-4 py-3 border border-slate-200 rounded-lg text-gray-900 font-semibold bg-slate-50 focus:bg-white focus:border-blue-300 focus:outline-none transition-colors disabled:cursor-not-allowed"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1687,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "mt-2 font-medium font-mono text-blue-600 text-sm", children: numberToIndianWords(
                    formData?.monthly_business_info?.target ?? 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1694,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1680,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-2", children: [
                    /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1751,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("label", { className: "font-semibold text-gray-700 text-[12px]", children: "Total Business Closed (Current Month)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1752,
                      columnNumber: 25
                    }, this),
                    isBusinessLoading && /* @__PURE__ */ jsxDEV(Spin, { size: "small", className: "ml-2" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1755,
                      columnNumber: 47
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1750,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      value: isBusinessLoading ? "loading ..." : formData?.monthly_business_info?.total_business_closed ?? 0,
                      readOnly: true,
                      className: "w-full px-4 py-3 border border-slate-200 rounded-lg text-gray-900 font-semibold bg-emerald-50 cursor-not-allowed"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1757,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "mt-2 font-medium font-mono text-emerald-600 text-sm", children: numberToIndianWords(
                    formData?.monthly_business_info?.total_business_closed || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1767,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1749,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-blue-500 uppercase mb-2 tracking-wider", children: "Pigmy Incentive (Edit)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1776,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      disabled: true,
                      value: formData.pigmy_collection_incentive,
                      onChange: (e) => setFormData((prev) => ({ ...prev, pigmy_collection_incentive: Number(e.target.value) })),
                      prefix: "₹",
                      className: "font-bold border-blue-300 bg-white hover:border-blue-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1777,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1775,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-blue-500 uppercase mb-2 tracking-wider", children: "Loan Incentive (Edit)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1789,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      disabled: true,
                      value: formData.loan_collection_incentive,
                      onChange: (e) => setFormData((prev) => ({ ...prev, loan_collection_incentive: Number(e.target.value) })),
                      prefix: "₹",
                      className: "font-bold border-blue-300 bg-white hover:border-blue-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1790,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1788,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1678,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex justify-start", children: (() => {
                const totalTarget = Number(
                  formData.monthly_business_info.total_target || 0
                );
                const totalBusinessClosed = Number(
                  formData.monthly_business_info.total_business_closed || 0
                );
                const variance = totalBusinessClosed - totalTarget;
                const statusConfig = {
                  exceeded: {
                    icon: /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1818,
                      columnNumber: 23
                    }, this),
                    container: "bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm shadow-emerald-100/50",
                    label: `Business Exceeded by ₹${variance.toLocaleString(
                      "en-IN"
                    )}`
                  },
                  achieved: {
                    icon: /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-green-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1828,
                      columnNumber: 23
                    }, this),
                    container: "bg-green-50 text-green-700 border-green-200 shadow-sm shadow-blue-100/50",
                    label: "Target Achieved"
                  },
                  shortfall: {
                    icon: /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-4 h-4 text-red-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1836,
                      columnNumber: 23
                    }, this),
                    container: "bg-red-50 text-red-700 border-red-200 shadow-sm shadow-red-100/50",
                    label: `Business Shortfall: ₹${Math.abs(
                      variance
                    ).toLocaleString("en-IN")}`
                  }
                };
                let currentStatus = statusConfig.shortfall;
                if (variance > 0) currentStatus = statusConfig.exceeded;
                else if (variance === 0)
                  currentStatus = statusConfig.achieved;
                return /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `
        inline-flex items-center gap-2.5 px-4 py-1.5 
        rounded-xl border font-bold text-xs tracking-tight
        transition-all duration-300 ease-in-out
        ${currentStatus.container}
      `,
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center", children: currentStatus.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1859,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "uppercase", children: currentStatus.label }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1862,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1852,
                    columnNumber: 21
                  },
                  this
                );
              })() }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1803,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1665,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-slate-50 rounded-2xl border border-slate-200 p-8 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-yellow-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(CreditCard, { className: "w-6 h-6 text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1874,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1873,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-xl text-gray-900", children: "Advance Repayment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1876,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1872,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1871,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "group_install",
                      children: "Payment Date"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1884,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "pay_date",
                      value: formData?.advance_repayment?.pay_date,
                      id: "pay_date",
                      onChange: handleInputChange,
                      placeholder: "",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1890,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1883,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "group_value",
                        children: [
                          "Amount ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 1907,
                            columnNumber: 34
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1903,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        name: "amount",
                        value: formData?.advance_repayment?.amount,
                        id: "amount",
                        onChange: handleInputChange,
                        placeholder: "Enter Amount",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 1909,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1902,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-blue-900" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 1920,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1901,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "pay_mode",
                      children: "Payment Mode"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1925,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      name: "pay_mode",
                      id: "pay_mode",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5",
                      onChange: handlePaymentModeChange,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 1937,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 1938,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "online/upi", children: "Online/UPI" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 1939,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 1940,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1931,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1924,
                  columnNumber: 21
                }, this),
                (paymentMode === "online" || paymentMode === "online/upi") && /* @__PURE__ */ jsxDEV("div", { className: "", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "transaction_id",
                      children: [
                        "Transaction ID",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 1951,
                          columnNumber: 29
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1946,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "transaction_id",
                      id: "transaction_id",
                      value: formData?.advance_repayment?.transaction_id,
                      onChange: handleInputChange,
                      placeholder: "Enter Transaction ID",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1953,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1945,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1882,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: paymentMode === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 md:grid-cols-4 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "cheque_number",
                      children: [
                        "Cheque Number",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 1974,
                          columnNumber: 29
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1969,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_number",
                      id: "cheque_number",
                      value: formData?.advance_repayment?.cheque_number,
                      onChange: handleInputChange,
                      placeholder: "Enter Cheque Number",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1976,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1968,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "cheque_date",
                      children: [
                        "Cheque Date",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 1994,
                          columnNumber: 29
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1989,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "cheque_date",
                      id: "cheque_date",
                      value: formData?.advance_repayment?.cheque_date?.split("T")[0],
                      onChange: handleInputChange,
                      placeholder: "Enter Cheque Date",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 1996,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 1988,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "cheque_bank_name",
                      children: "Bank Name"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2008,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_bank_name",
                      id: "cheque_bank_name",
                      value: formData?.advance_repayment?.cheque_bank_name,
                      onChange: handleInputChange,
                      placeholder: "Enter Bank Name",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2014,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2007,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "cheque_bank_branch",
                      children: "Bank Branch"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2026,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_bank_branch",
                      id: "cheque_bank_branch",
                      value: formData?.advance_repayment?.cheque_bank_branch,
                      onChange: handleInputChange,
                      placeholder: "Enter Bank Branch",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2032,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2025,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1967,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 1965,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2 mt-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900 ",
                    htmlFor: "remarks",
                    children: "Remarks"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2048,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    name: "remarks",
                    id: "remarks",
                    value: formData?.advance_repayment?.remarks,
                    onChange: handleInputChange,
                    placeholder: "Remarks if any...",
                    rows: 2,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2054,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2047,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 1870,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-slate-50 rounded-2xl border border-slate-200 p-8 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-green-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-6 h-6 text-white" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2068,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2067,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-xl text-gray-900", children: "Collection Incentive" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2070,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2066,
                  columnNumber: 21
                }, this),
                showCollectionContinue && /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    onClick: handleFetchCollectionIncentive,
                    loading: collectionLoading,
                    style: {
                      backgroundColor: "#16a34a",
                      borderColor: "#16a34a"
                    },
                    className: "px-8 shadow-md",
                    children: "Continue"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2077,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2065,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-slate-50 rounded-2xl border border-slate-200 p-8 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2094,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "font-semibold text-gray-700 text-sm mb-2 text-blue-600", children: "Pigmy Collection Percentage (%)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2100,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        placeholder: "Enter %",
                        value: formData.pigmy_perc,
                        onChange: (e) => setFormData((prev) => ({ ...prev, pigmy_perc: e.target.value })),
                        className: "h-11 font-bold text-lg",
                        suffix: "%"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2103,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2099,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "font-semibold text-gray-700 text-sm mb-2 text-blue-600", children: "Loan Collection Percentage (%)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2114,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        placeholder: "Enter %",
                        value: formData.loan_perc,
                        onChange: (e) => setFormData((prev) => ({ ...prev, loan_perc: e.target.value })),
                        className: "h-11 font-bold text-lg",
                        suffix: "%"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2117,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2113,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2098,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-xs text-gray-400 italic", children: '* Values will be fetched when you press the main "Continue" button below.' }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2128,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2093,
                columnNumber: 19
              }, this),
              additionalSalaryloading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 border-4 border-gray-200 border-t-green-500 rounded-full animate-spin" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2134,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2132,
                columnNumber: 15
              }, this) : additionalSalaryDetails?.additional_salaries?.length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow p-6 mt-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-gray-900", children: [
                  "Additional Salary: ",
                  additionalSalaryDetails?.salary_month,
                  " ",
                  additionalSalaryDetails?.salary_year
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2141,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2140,
                  columnNumber: 27
                }, this),
                additionalSalaryDetails?.attendance_summary && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-4 mb-6 border border-gray-200", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-md font-semibold text-gray-800 mb-3", children: "Attendance Summary" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2147,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded shadow-sm text-center", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500", children: "Total Days" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2152,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-gray-800", children: additionalSalaryDetails?.attendance_summary?.total_days }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2153,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2151,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded shadow-sm text-center", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500", children: "Present Days" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2158,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-green-600", children: additionalSalaryDetails?.attendance_summary?.present_days }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2159,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2157,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded shadow-sm text-center", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500", children: "Leave Days" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2164,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-red-500", children: additionalSalaryDetails?.attendance_summary?.leave_days }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2165,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2163,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded shadow-sm text-center", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500", children: "Half Days" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2170,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-yellow-500", children: additionalSalaryDetails?.attendance_summary?.half_days }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2171,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2169,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded shadow-sm text-center", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500", children: "Paid Days" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2176,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-blue-600", children: additionalSalaryDetails?.attendance_summary?.paid_days }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2177,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2175,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2150,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2146,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border border-gray-200 rounded-lg", children: [
                  /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-sm font-medium text-gray-700 border-b", children: "Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2192,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-sm font-medium text-gray-700 border-b", children: "Payable Amount" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2195,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-sm font-medium text-gray-700 border-b", children: "Payment Amount" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2198,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2191,
                    columnNumber: 33
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2190,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { children: additionalSalaryDetails?.additional_salaries?.map(
                    (item, index) => /* @__PURE__ */ jsxDEV(
                      "tr",
                      {
                        className: index % 2 === 0 ? "bg-white" : "bg-gray-50",
                        children: [
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-800 font-medium", children: item.name }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2209,
                            columnNumber: 37
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-700", children: [
                            "₹",
                            item.original_value.toLocaleString("en-IN")
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2212,
                            columnNumber: 37
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-green-600 font-semibold", children: [
                            "₹",
                            item.payment_value.toLocaleString("en-IN")
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2215,
                            columnNumber: 37
                          }, this)
                        ]
                      },
                      index,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2205,
                        columnNumber: 25
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2203,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-gray-100 font-bold text-gray-900", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2", children: "Total" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2223,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2", children: [
                      "₹",
                      additionalSalaryDetails?.total_original_additional_salary?.toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2224,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-green-600", children: [
                      "₹",
                      additionalSalaryDetails?.total_payment_amount?.toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2227,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2222,
                    columnNumber: 33
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2221,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2189,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2188,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2139,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2138,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2064,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                onClick: handleCalculateSalary,
                size: "large",
                className: "px-8",
                loading: calculateLoading,
                disabled: !formData.employee_id || !formData.month || !formData.year,
                style: {
                  backgroundColor: "#16a34a"
                },
                children: "Continue"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2239,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2238,
              columnNumber: 17
            }, this),
            calculatedSalary && /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 p-4 rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-blue-800 mb-4", children: "Attendance Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2257,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Total Days" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2262,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      value: calculatedSalary.total_days,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2265,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                    calculatedSalary.total_days || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2272,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2261,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Present Days" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2279,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      value: calculatedSalary.present_days,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2282,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                    calculatedSalary.present_days || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2289,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2278,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Paid Days" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2296,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      value: calculatedSalary.paid_days,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2299,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(calculatedSalary.paid_days || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2306,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2295,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "LOP Days" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2311,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      value: calculatedSalary.lop_days,
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2314,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(calculatedSalary.lop_days || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2321,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2310,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "LOP" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2327,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      value: (calculatedSalary.lop || 0).toFixed(2),
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2330,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(calculatedSalary.lop_days || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2337,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2326,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Per Day Salary" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2342,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      value: calculatedSalary.per_day_salary.toFixed(2),
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2345,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                    calculatedSalary.per_day_salary.toFixed(2) || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2352,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2341,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Calculated Salary" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2359,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700",
                      value: calculatedSalary.calculated_salary.toFixed(2),
                      disabled: true
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2362,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(
                    calculatedSalary.calculated_salary.toFixed(2) || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2369,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2358,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2260,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-gradient-to-br from-white to-slate-50 rounded-2xl border border-slate-200 p-8 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(BarChart3, { className: "w-6 h-6 text-white" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2380,
                      columnNumber: 29
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2379,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-xl text-gray-900", children: "Monthly Target & Incentive" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2382,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2378,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: calculatedIncentive > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        type: "primary",
                        onClick: handlePayAsSalary,
                        className: "bg-blue-600 hover:bg-blue-700",
                        children: "Pay as Salary"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2389,
                        columnNumber: 31
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        type: "primary",
                        onClick: handlePayAsIncentive,
                        className: "bg-purple-600 hover:bg-purple-700",
                        children: "Pay as Incentive"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2395,
                        columnNumber: 31
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2388,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2386,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2377,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-2", children: [
                      /* @__PURE__ */ jsxDEV(Target, { className: "w-4 h-4 text-blue-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2410,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("label", { className: "font-semibold text-gray-700 text-sm", children: "Current Month Target" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2411,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2409,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        onWheel: (e) => e.target.blur(),
                        value: formData?.monthly_business_info?.target || 0,
                        disabled: true,
                        className: "w-full px-4 py-3 border border-slate-200 rounded-lg text-gray-900 font-semibold bg-slate-50 focus:bg-white focus:border-blue-300 focus:outline-none transition-colors disabled:cursor-not-allowed"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2415,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "mt-2 font-medium font-mono text-blue-600 text-sm", children: numberToIndianWords(
                      formData?.monthly_business_info?.target ?? 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2422,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2408,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-2", children: [
                      /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2479,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("label", { className: "font-semibold text-gray-700 text-[13px]", children: "Total Business Closed (Current Month)" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2480,
                        columnNumber: 29
                      }, this),
                      isBusinessLoading && /* @__PURE__ */ jsxDEV(Spin, { size: "small", className: "ml-2" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2483,
                        columnNumber: 51
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2478,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        value: isBusinessLoading ? "loading ..." : formData?.monthly_business_info?.total_business_closed ?? 0,
                        readOnly: true,
                        className: "w-full px-4 py-3 border border-slate-200 rounded-lg text-gray-900 font-semibold bg-emerald-50 cursor-not-allowed"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2485,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "mt-2 font-medium font-mono text-emerald-600 text-sm", children: numberToIndianWords(
                      formData?.monthly_business_info?.total_business_closed || 0
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2495,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2477,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2406,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex justify-start", children: (() => {
                  const totalTarget = Number(
                    formData.monthly_business_info.total_target || 0
                  );
                  const totalBusinessClosed = Number(
                    formData.monthly_business_info.total_business_closed || 0
                  );
                  const variance = totalBusinessClosed - totalTarget;
                  const statusConfig = {
                    exceeded: {
                      icon: /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2520,
                        columnNumber: 25
                      }, this),
                      container: "bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm shadow-emerald-100/50",
                      label: `Target Exceeded by ₹${variance.toLocaleString(
                        "en-IN"
                      )}`
                    },
                    achieved: {
                      icon: /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-green-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2530,
                        columnNumber: 25
                      }, this),
                      container: "bg-green-50 text-green-700 border-green-200 shadow-sm shadow-blue-100/50",
                      label: "Target Achieved"
                    },
                    shortfall: {
                      icon: /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-4 h-4 text-red-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2538,
                        columnNumber: 25
                      }, this),
                      container: "bg-red-50 text-red-700 border-red-200 shadow-sm shadow-red-100/50",
                      label: `Target Shortfall: ₹${Math.abs(
                        variance
                      ).toLocaleString("en-IN")}`
                    }
                  };
                  let currentStatus = statusConfig.shortfall;
                  if (variance > 0)
                    currentStatus = statusConfig.exceeded;
                  else if (variance === 0)
                    currentStatus = statusConfig.achieved;
                  return /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `
        inline-flex items-center gap-2.5 px-4 py-1.5 
        rounded-xl border font-bold text-xs tracking-tight
        transition-all duration-300 ease-in-out
        ${currentStatus.container}
      `,
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center", children: currentStatus.icon }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 2562,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "uppercase", children: currentStatus.label }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 2565,
                          columnNumber: 31
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2555,
                      columnNumber: 23
                    },
                    this
                  );
                })() }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2505,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2376,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2256,
              columnNumber: 13
            }, this),
            showComponents && /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 p-4 rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-purple-800", children: "Additional Payments" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2580,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    icon: /* @__PURE__ */ jsxDEV(PlusOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2585,
                      columnNumber: 25
                    }, this),
                    onClick: addAdditionalPayment,
                    children: "Add Payment"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2583,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2579,
                columnNumber: 21
              }, this),
              formData.additional_payments.map(
                (payment, index) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Payment Name" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 2595,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            placeholder: "Enter payment name",
                            value: payment.name,
                            onChange: (e) => handleAdditionalPaymentChange(
                              index,
                              "name",
                              e.target.value
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2598,
                            columnNumber: 27
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2594,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "form-group flex items-end gap-2", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex-grow", children: [
                          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2612,
                            columnNumber: 29
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            Input,
                            {
                              type: "number",
                              placeholder: "Enter amount",
                              value: payment.value,
                              onChange: (e) => handleAdditionalPaymentChange(
                                index,
                                "value",
                                e.target.value
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                              lineNumber: 2615,
                              columnNumber: 29
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-blue-600", children: numberToIndianWords(payment.value || 0) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2627,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 2611,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "primary",
                            danger: true,
                            icon: /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                              lineNumber: 2634,
                              columnNumber: 27
                            }, this),
                            onClick: () => removeAdditionalPayment(index)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2631,
                            columnNumber: 27
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2610,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2591,
                    columnNumber: 15
                  },
                  this
                )
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2578,
              columnNumber: 13
            }, this),
            showComponents && /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 p-4 rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-orange-800", children: "Additional Deductions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2645,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    danger: true,
                    icon: /* @__PURE__ */ jsxDEV(PlusOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2651,
                      columnNumber: 25
                    }, this),
                    onClick: addAdditionalDeduction,
                    children: "Add Deduction"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2648,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2644,
                columnNumber: 21
              }, this),
              formData.additional_deductions.map(
                (deduction, index) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Deduction Name" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 2661,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            placeholder: "Enter deduction name",
                            value: deduction.name,
                            onChange: (e) => handleAdditionalDeductionChange(
                              index,
                              "name",
                              e.target.value
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2664,
                            columnNumber: 27
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2660,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "form-group flex items-end gap-2", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex-grow", children: [
                          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2678,
                            columnNumber: 29
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            Input,
                            {
                              type: "number",
                              placeholder: "Enter amount",
                              onWheel: (e) => e.target.blur(),
                              value: deduction.value,
                              onChange: (e) => handleAdditionalDeductionChange(
                                index,
                                "value",
                                e.target.value
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                              lineNumber: 2681,
                              columnNumber: 29
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-green-600", children: numberToIndianWords(
                            Number(deduction.value || 0).toFixed(2)
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2694,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 2677,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "primary",
                            danger: true,
                            icon: /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                              lineNumber: 2703,
                              columnNumber: 27
                            }, this),
                            onClick: () => removeAdditionalDeduction(index)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                            lineNumber: 2700,
                            columnNumber: 27
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2676,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2657,
                    columnNumber: 15
                  },
                  this
                )
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2643,
              columnNumber: 13
            }, this),
            calculatedSalary && showComponents && /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 p-6 rounded-xl mt-4 border border-blue-100 shadow-inner", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-blue-800 mb-6 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2714,
                  columnNumber: 23
                }, this),
                " Final Transaction Adjustments"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2713,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-500 uppercase mb-2 tracking-wider", children: "Target Incentive" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2720,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      value: formData.calculated_incentive,
                      disabled: true,
                      prefix: "₹",
                      className: "font-bold !text-blue-600 !bg-white"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2721,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2719,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-blue-500 uppercase mb-2 tracking-wider", children: "Pigmy Incentive (Edit)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2731,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      disabled: true,
                      value: formData.pigmy_collection_incentive,
                      onChange: (e) => setFormData((prev) => ({ ...prev, pigmy_collection_incentive: Number(e.target.value) })),
                      prefix: "₹",
                      className: "font-bold border-blue-300 bg-white hover:border-blue-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2732,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2730,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-blue-500 uppercase mb-2 tracking-wider", children: "Loan Incentive (Edit)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2744,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      disabled: true,
                      value: formData.loan_collection_incentive,
                      onChange: (e) => setFormData((prev) => ({ ...prev, loan_collection_incentive: Number(e.target.value) })),
                      prefix: "₹",
                      className: "font-bold border-blue-300 bg-white hover:border-blue-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2745,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2743,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-700 uppercase mb-2 tracking-wider", children: "Final Net Payable" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2757,
                    columnNumber: 25
                  }, this),
                  (() => {
                    const basePay = Number(formData.total_salary_payable || 0);
                    const totalAdditionalPayments = formData.additional_payments.reduce(
                      (acc, payment) => acc + Number(payment.value || 0),
                      0
                    );
                    const totalAdditionalDeductions = formData.additional_deductions.reduce(
                      (acc, deduction) => acc + Number(deduction.value || 0),
                      0
                    );
                    const total = basePay + totalAdditionalPayments - totalAdditionalDeductions;
                    return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          value: total.toFixed(2),
                          disabled: true,
                          prefix: "₹",
                          className: "font-black !text-gray-900 !bg-gray-200 border-none text-lg h-10"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                          lineNumber: 2780,
                          columnNumber: 31
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-500 mt-1 font-mono uppercase", children: numberToIndianWords(total.toFixed(2)) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 2786,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 2779,
                      columnNumber: 23
                    }, this);
                  })()
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2756,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2716,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2712,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 1333,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-12", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2801,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-600", children: "Loading employee details..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2802,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2800,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2799,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 1306,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 1281,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Confirm Pay as Salary",
        open: payAsSalaryModalOpen,
        onCancel: () => setPayAsSalaryModalOpen(false),
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setPayAsSalaryModalOpen(false), children: "Cancel" }, "cancel", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2817,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { type: "primary", onClick: confirmPayAsSalary, children: "Confirm" }, "confirm", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2820,
            columnNumber: 9
          }, this)
        ],
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-medium mb-4", children: "Are you sure you want to add the incentive amount as salary?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2824,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 p-4 rounded-lg", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Incentive Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2829,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-700 text-lg", children: [
                "₹",
                Number(calculatedIncentive).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2830,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2828,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "This amount will be added to the salary payable" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2835,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2834,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2827,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 2812,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Confirm Pay as Incentive",
        open: payAsIncentiveModalOpen,
        onCancel: () => setPayAsIncentiveModalOpen(false),
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => setPayAsIncentiveModalOpen(false),
              children: "Cancel"
            },
            "cancel",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2848,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Button, { type: "primary", onClick: confirmPayAsIncentive, children: "Confirm" }, "confirm", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2853,
            columnNumber: 9
          }, this)
        ],
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-medium mb-4", children: "Are you sure you want to add the incentive amount as incentive payable?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2857,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 p-4 rounded-lg", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Incentive Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2863,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-purple-700 text-lg", children: [
                "₹",
                Number(calculatedIncentive).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2864,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2862,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "This amount will be added to the incentive payable" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2869,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2868,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2861,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 2843,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: "View Salary Details",
        width: "55%",
        className: "payment-drawer",
        open: isOpenUpdateModal,
        onClose: () => setIsOpenUpdateModal(false),
        closable: true,
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => setIsOpenUpdateModal(false),
            className: "!rounded-xl !px-5 !py-2 !font-semibold !text-gray-700 !bg-gray-100 hover:!bg-gray-200 !border-none !shadow-sm transition-all duration-200",
            children: "Close"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2885,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 2884,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200/80 p-3 shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2899,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                value: employees.find((e) => e.value === updateFormData.employee_id)?.label || "—",
                readOnly: true,
                className: "!bg-gray-50 !border-gray-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-gray-300 transition-colors"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2902,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2898,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200/80 p-3 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2915,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  value: updateFormData.month || "—",
                  readOnly: true,
                  className: "!bg-gray-50 !border-gray-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-gray-300 transition-colors"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2918,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2914,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200/80 p-3 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Year" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2925,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  value: dayjs.isDayjs(updateFormData.year) ? updateFormData.year.format("YYYY") : updateFormData.year || "—",
                  readOnly: true,
                  className: "!bg-gray-50 !border-gray-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-gray-300 transition-colors"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2928,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2924,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2913,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-emerald-50/70 rounded-xl border border-emerald-200/60 p-3 shadow-sm hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-emerald-800 text-sm font-bold border-b border-emerald-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "💰" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2943,
                columnNumber: 15
              }, this),
              " Earnings"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2942,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: Object.entries(updateFormData.earnings || {}).map(
              ([key, value]) => /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2948,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: Number(value || 0).toLocaleString("en-IN", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }),
                    readOnly: true,
                    className: "!bg-white !border-emerald-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-emerald-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2953,
                    columnNumber: 19
                  },
                  this
                )
              ] }, key, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2947,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2945,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2941,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-rose-50/70 rounded-xl border border-rose-200/60 p-3 shadow-sm hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-rose-800 text-sm font-bold border-b border-rose-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "🔻" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2969,
                columnNumber: 15
              }, this),
              " Deductions"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2968,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: Object.entries(updateFormData.deductions || {}).map(
              ([key, value]) => /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2974,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: Number(value || 0).toLocaleString("en-IN", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }),
                    readOnly: true,
                    className: "!bg-white !border-rose-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-rose-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 2979,
                    columnNumber: 19
                  },
                  this
                )
              ] }, key, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2973,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2971,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-2 border-t border-rose-200/50", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Total Deductions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 2991,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  value: updateTotalDeductions.toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  }),
                  readOnly: true,
                  className: "!bg-white !border-rose-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-semibold !shadow-sm !cursor-default !w-full hover:!border-rose-300 transition-colors"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 2994,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 2990,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 2967,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-sky-50/70 rounded-xl border border-sky-200/60 p-3 shadow-sm hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-sky-800 text-sm font-bold border-b border-sky-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "📊" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3008,
                columnNumber: 15
              }, this),
              " Monthly Business Info"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3007,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Target" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3012,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: Number(
                      updateFormData.monthly_business_info?.target || 0
                    ).toLocaleString("en-IN", { minimumFractionDigits: 2 }),
                    readOnly: true,
                    className: "!bg-white !border-sky-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-sky-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3015,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3011,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Total Business Closed" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3024,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: Number(
                      updateFormData.monthly_business_info?.total_business_closed || 0
                    ).toLocaleString("en-IN", { minimumFractionDigits: 2 }),
                    readOnly: true,
                    className: "!bg-white !border-sky-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-sky-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3027,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3023,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3010,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3006,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-sky-50/70 rounded-xl border border-sky-200/60 p-3 shadow-sm hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-sky-800 text-sm font-bold border-b border-sky-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "🎯" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3041,
                columnNumber: 15
              }, this),
              " Calculated Incentive"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3040,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                value: Number(
                  updateFormData.calculated_incentive || 0
                ).toLocaleString("en-IN", { minimumFractionDigits: 2 }),
                readOnly: true,
                className: "!bg-white !border-sky-200 !rounded-lg !px-3 !py-2 !text-gray-800 !font-bold !text-lg !shadow-sm !cursor-default !w-full hover:!border-sky-300 transition-colors"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3043,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3039,
            columnNumber: 11
          }, this),
          updateFormData.advance_payments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-indigo-50/70 rounded-xl border border-indigo-200/60 p-3 shadow-sm hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-indigo-800 text-sm font-bold border-b border-indigo-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "💳" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3056,
                columnNumber: 17
              }, this),
              " Advance Payments"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3055,
              columnNumber: 15
            }, this),
            updateFormData.advance_payments.map(
              (pay, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-2 mb-2 last:mb-0", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: pay.name || "Advance",
                    readOnly: true,
                    className: "!bg-white !border-indigo-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default flex-1 hover:!border-indigo-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3060,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: `₹${Number(pay.value).toLocaleString("en-IN")}`,
                    readOnly: true,
                    className: "!bg-white !border-indigo-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-semibold !shadow-sm !cursor-default w-full sm:w-36 text-right hover:!border-indigo-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3065,
                    columnNumber: 19
                  },
                  this
                )
              ] }, i, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3059,
                columnNumber: 13
              }, this)
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3054,
            columnNumber: 11
          }, this),
          updateFormData.additional_payments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50/70 rounded-xl border border-purple-200/60 p-3 shadow-sm hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-purple-800 text-sm font-bold border-b border-purple-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "✨" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3079,
                columnNumber: 17
              }, this),
              " Additional Payments"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3078,
              columnNumber: 15
            }, this),
            updateFormData.additional_payments.map(
              (pay, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-2 mb-2 last:mb-0", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: pay.name || "Payment",
                    readOnly: true,
                    className: "!bg-white !border-purple-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default flex-1 hover:!border-purple-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3083,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: `₹${Number(pay.value).toLocaleString("en-IN")}`,
                    readOnly: true,
                    className: "!bg-white !border-purple-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-semibold !shadow-sm !cursor-default w-full sm:w-36 text-right hover:!border-purple-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3088,
                    columnNumber: 19
                  },
                  this
                )
              ] }, i, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3082,
                columnNumber: 13
              }, this)
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3077,
            columnNumber: 11
          }, this),
          updateFormData.additional_deductions?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50/70 rounded-xl border border-orange-200/60 p-3 shadow-sm hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-orange-800 text-sm font-bold border-b border-orange-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "⚠️" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3102,
                columnNumber: 17
              }, this),
              " Additional Deductions"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3101,
              columnNumber: 15
            }, this),
            updateFormData.additional_deductions.map(
              (ded, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-2 mb-2 last:mb-0", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: ded.name || "Deduction",
                    readOnly: true,
                    className: "!bg-white !border-orange-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default flex-1 hover:!border-orange-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3106,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: `₹${Number(ded.value).toLocaleString("en-IN")}`,
                    readOnly: true,
                    className: "!bg-white !border-orange-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-semibold !shadow-sm !cursor-default w-full sm:w-36 text-right hover:!border-orange-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3111,
                    columnNumber: 19
                  },
                  this
                )
              ] }, i, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3105,
                columnNumber: 13
              }, this)
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3100,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-100/80 rounded-xl border border-slate-200/70 p-4 shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-slate-700 text-sm font-bold border-b border-slate-200/50 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "🏷️" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3124,
                columnNumber: 15
              }, this),
              " Total Salary Payable"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3123,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                value: Number(
                  updateFormData.total_salary_payable || 0
                ).toLocaleString("en-IN", { minimumFractionDigits: 2 }),
                readOnly: true,
                className: "!bg-white !border-slate-200 !rounded-lg !px-3 !py-2.5 !text-gray-900 !font-bold !text-xl !shadow-sm !cursor-default !w-full text-center hover:!border-slate-300 transition-colors"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3126,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3122,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200/80 p-3 shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 text-gray-700 text-sm font-bold border-b border-gray-200/60 pb-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "💳" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3138,
                columnNumber: 15
              }, this),
              " Payment Details"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3137,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Paid Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3142,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: Number(updateFormData.paid_amount || 0).toLocaleString(
                      "en-IN",
                      { minimumFractionDigits: 2 }
                    ),
                    readOnly: true,
                    className: "!bg-gray-50 !border-gray-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-gray-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3145,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3141,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Payment Method" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3155,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: updateFormData?.payment_method || "N/A",
                    readOnly: true,
                    className: "!bg-gray-50 !border-gray-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-gray-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3158,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3154,
                columnNumber: 15
              }, this),
              updateFormData.transaction_id && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Transaction ID" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3166,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: updateFormData.transaction_id,
                    readOnly: true,
                    className: "!bg-gray-50 !border-gray-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-mono !text-sm !shadow-sm !cursor-default !w-full hover:!border-gray-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3169,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3165,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-0.5", children: "Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3177,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: updateFormData.status,
                    readOnly: true,
                    className: "!bg-gray-50 !border-gray-200 !rounded-lg !px-3 !py-1.5 !text-gray-800 !font-medium !shadow-sm !cursor-default !w-full hover:!border-gray-300 transition-colors"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3180,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3176,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3140,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3136,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 2895,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 2876,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Delete Salary",
        open: deleteModalOpen,
        onCancel: () => setDeleteModalOpen(false),
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDeleteModalOpen(false), children: "Cancel" }, "cancel", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3196,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              danger: true,
              loading: deleteLoading,
              onClick: () => handleDeleteConfirm(deleteId),
              children: "Delete"
            },
            "delete",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3199,
              columnNumber: 9
            },
            this
          )
        ],
        children: /* @__PURE__ */ jsxDEV("p", { children: "Are you sure you want to delete this salary ? This action cannot be undone." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 3208,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 3191,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxDEV("span", { className: "text-amber-800 text-lg font-semibold flex items-center", children: "Salary Already Processed" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 3217,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 3216,
          columnNumber: 9
        }, this),
        open: alreadyPaidModalOpen,
        onCancel: () => setAlreadyPaidModalOpen(false),
        width: 920,
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setAlreadyPaidModalOpen(false), children: "Close" }, "close", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3226,
            columnNumber: 9
          }, this),
          existingSalaryRecord?.status === "Pending" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              style: {
                backgroundColor: "#D4AF37",
                borderColor: "#B8860B",
                color: "#000"
              },
              onClick: () => {
                handleEdit(existingSalaryRecord._id);
                setAlreadyPaidModalOpen(false);
              },
              children: "Edit Record"
            },
            "edit",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3230,
              columnNumber: 9
            },
            this
          )
        ],
        style: {
          padding: "24px",
          maxHeight: "70vh",
          overflowY: "auto",
          backgroundColor: "#fafafa"
        },
        children: existingSalaryRecord ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
          /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-white to-slate-50 p-6 rounded-xl shadow-md border border-slate-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-blue-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3257,
                columnNumber: 17
              }, this),
              "Salary Period"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3256,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg border border-slate-100 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-slate-500 uppercase tracking-wide mb-1", children: "Month" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3262,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-900 font-semibold text-base", children: [
                  existingSalaryRecord.salary_month,
                  " ",
                  existingSalaryRecord.salary_year
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3265,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3261,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg border border-slate-100 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-slate-500 uppercase tracking-wide mb-1", children: "From" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3271,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-900 font-semibold text-base", children: dayjs.utc(existingSalaryRecord.salary_from_date).format("DD MMM YYYY") }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3274,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3270,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg border border-slate-100 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-slate-500 uppercase tracking-wide mb-1", children: "To" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3281,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-900 font-semibold text-base", children: dayjs.utc(existingSalaryRecord.salary_to_date).format("DD MMM YYYY") }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3284,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3280,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3260,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3255,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "flex flex-col gap-4 bg-gradient-to-br from-purple-50 to-purple-50 p-6 rounded-xl shadow-md border border-purple-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-2 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-purple-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3296,
                columnNumber: 17
              }, this),
              "Attendance Details"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3295,
              columnNumber: 15
            }, this),
            Object.entries(
              existingSalaryRecord.attendance_details || {}
            ).map(([key, val]) => {
              const isCurrency = key.includes("salary") || key.includes("calculated");
              const isDate = key.includes("date");
              let displayValue;
              if (isDate) {
                displayValue = val ? dayjs(val).format("YYYY-MM-DD") : "N/A";
              } else if (isCurrency) {
                displayValue = `₹${Number(val).toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })}`;
              } else {
                displayValue = val;
              }
              return /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "flex justify-between items-center bg-white p-4 rounded-lg border border-purple-100 hover:border-purple-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "capitalize text-slate-700 font-medium", children: key.replace(/_/g, " ") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3324,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `font-bold ${isCurrency ? "text-purple-700" : "text-slate-600"}`,
                        children: displayValue
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                        lineNumber: 3327,
                        columnNumber: 21
                      },
                      this
                    )
                  ]
                },
                key,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3321,
                  columnNumber: 17
                },
                this
              );
            })
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3294,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl shadow-md border border-green-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-green-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3339,
                columnNumber: 17
              }, this),
              "Earnings"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3338,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: Object.entries(existingSalaryRecord.earnings || {}).map(
              ([key, val]) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between items-center bg-white p-4 rounded-lg border border-green-100 hover:border-green-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "capitalize text-slate-700 font-medium", children: key.replace(/_/g, " ") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3348,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-green-700", children: [
                      "₹",
                      Number(val).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3351,
                      columnNumber: 23
                    }, this)
                  ]
                },
                key,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3345,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3342,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3337,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-red-50 to-rose-50 p-6 rounded-xl shadow-md border border-red-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-red-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3367,
                columnNumber: 17
              }, this),
              "Deductions"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3366,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: Object.entries(existingSalaryRecord.deductions || {}).map(
              ([key, val]) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between items-center bg-white p-4 rounded-lg border border-red-100 hover:border-red-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "capitalize text-slate-700 font-medium", children: key.replace(/_/g, " ") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3376,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-red-700", children: [
                      "₹",
                      Number(val).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3379,
                      columnNumber: 23
                    }, this)
                  ]
                },
                key,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3373,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3370,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3365,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-blue-50 to-blue-50 p-6 rounded-xl shadow-md border border-blue-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-blue-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3393,
                columnNumber: 17
              }, this),
              "Target Details"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3392,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: Object.entries(
              existingSalaryRecord.monthly_business_info || {}
            ).map(
              ([key, val]) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between items-center bg-white p-4 rounded-lg border border-blue-100 hover:border-blue-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "capitalize text-slate-700 font-medium", children: key.replace(/_/g, " ") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3403,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-700", children: [
                      "₹",
                      Number(val).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3406,
                      columnNumber: 21
                    }, this)
                  ]
                },
                key,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3400,
                  columnNumber: 15
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3396,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3391,
            columnNumber: 13
          }, this),
          existingSalaryRecord.advance_payments?.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl shadow-md border border-blue-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-blue-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3421,
                columnNumber: 19
              }, this),
              "Advance Payments"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3420,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: existingSalaryRecord.advance_payments.map(
              (pay, i) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between items-center bg-white p-4 rounded-lg border border-blue-100 hover:border-blue-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: pay.name || "Advance Payment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3429,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-700", children: [
                      "₹",
                      Number(pay.value).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3432,
                      columnNumber: 23
                    }, this)
                  ]
                },
                i,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3426,
                  columnNumber: 15
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3424,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3419,
            columnNumber: 11
          }, this),
          existingSalaryRecord.additional_payments?.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl shadow-md border border-blue-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-blue-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3448,
                columnNumber: 19
              }, this),
              "Additional Payments"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3447,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: existingSalaryRecord.additional_payments.map(
              (pay, i) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between items-center bg-white p-4 rounded-lg border border-blue-100 hover:border-blue-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: pay.name || "Payment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3456,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-700", children: [
                      "₹",
                      Number(pay.value).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3459,
                      columnNumber: 23
                    }, this)
                  ]
                },
                i,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3453,
                  columnNumber: 15
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3451,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3446,
            columnNumber: 11
          }, this),
          existingSalaryRecord.additional_deductions?.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-orange-50 to-amber-50 p-6 rounded-xl shadow-md border border-orange-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-orange-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3475,
                columnNumber: 19
              }, this),
              "Additional Deductions"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3474,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: existingSalaryRecord.additional_deductions.map(
              (ded, i) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between items-center bg-white p-4 rounded-lg border border-orange-100 hover:border-orange-200 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: ded.name || "Deduction" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3483,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-orange-700", children: [
                      "₹",
                      Number(ded.value).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                      lineNumber: 3486,
                      columnNumber: 23
                    }, this)
                  ]
                },
                i,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3480,
                  columnNumber: 15
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3478,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3473,
            columnNumber: 11
          }, this),
          existingSalaryRecord.calculated_incentive !== 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl shadow-md border border-amber-200 hover:shadow-lg transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-amber-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3502,
                columnNumber: 19
              }, this),
              "Incentive Adjustment"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3501,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg border border-amber-100 hover:border-amber-200 transition-colors", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Calculated Incentive:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3506,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `font-bold ml-2 ${existingSalaryRecord.calculated_incentive > 0 ? "text-green-700" : "text-red-700"}`,
                  children: [
                    "₹",
                    Math.abs(
                      existingSalaryRecord.calculated_incentive
                    ).toLocaleString("en-IN", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }),
                    existingSalaryRecord.calculated_incentive > 0 ? " (Bonus)" : " (Deduction)"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3509,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3505,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3500,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-6 rounded-xl shadow-lg border-2 border-indigo-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-900 mb-4 flex items-center text-lg", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-indigo-600 rounded-full mr-3" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3531,
                columnNumber: 17
              }, this),
              "Payment Summary"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3530,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 bg-white p-5 rounded-lg border border-slate-200", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Calculated Salary" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3536,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-900 font-semibold text-lg", children: [
                  "₹",
                  Number(
                    existingSalaryRecord?.attendance_details?.calculated_salary
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3539,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3535,
                columnNumber: 17
              }, this),
              existingSalaryRecord.advance_payments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Advance Payments:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3552,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-700 font-semibold text-lg", children: [
                  "₹",
                  Number(
                    existingSalaryRecord.advance_payments.reduce(
                      (sum, p) => sum + Number(p.value),
                      0
                    )
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3555,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3551,
                columnNumber: 15
              }, this),
              existingSalaryRecord.additional_payments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Additional Payments:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3571,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-700 font-semibold text-lg", children: [
                  "₹",
                  Number(
                    existingSalaryRecord.additional_payments.reduce(
                      (sum, p) => sum + Number(p.value),
                      0
                    )
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3574,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3570,
                columnNumber: 15
              }, this),
              existingSalaryRecord.additional_deductions?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Additional Deductions:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3590,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-700 font-semibold text-lg", children: [
                  "₹",
                  Number(
                    existingSalaryRecord.additional_deductions.reduce(
                      (sum, d) => sum + Number(d.value),
                      0
                    )
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3593,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3589,
                columnNumber: 15
              }, this),
              existingSalaryRecord.calculated_incentive !== 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Incentive Adjustment:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3609,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: `font-semibold text-lg ${existingSalaryRecord.calculated_incentive > 0 ? "text-green-700" : "text-red-700"}`,
                    children: [
                      "₹",
                      Math.abs(
                        existingSalaryRecord.calculated_incentive
                      ).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      }),
                      existingSalaryRecord.calculated_incentive > 0 ? "" : " (Deduction)"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3612,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3608,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-3 border-t-2 border-slate-300 mt-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-900 font-bold text-lg", children: "Net Payable:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3631,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-indigo-700 font-bold text-2xl", children: [
                  "₹",
                  Number(existingSalaryRecord.net_payable).toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3634,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3630,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Paid Amount:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3646,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-900 font-semibold text-lg", children: [
                  "₹",
                  Number(existingSalaryRecord.paid_amount).toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3649,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3645,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Remaining Balance:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3661,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: `font-bold text-lg ${Number(existingSalaryRecord.remaining_balance) > 0 ? "text-red-600" : "text-green-600"}`,
                    children: [
                      "₹",
                      Number(
                        existingSalaryRecord.remaining_balance
                      ).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3664,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3660,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2 mt-3 pt-3 border-t border-slate-200", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Status:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3679,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: `px-4 py-1 rounded-full font-semibold text-sm ${existingSalaryRecord.status === "Paid" ? "bg-green-100 text-green-800 border border-green-300" : "bg-amber-100 text-amber-800 border border-amber-300"}`,
                    children: existingSalaryRecord.status
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                    lineNumber: 3680,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3678,
                columnNumber: 17
              }, this),
              existingSalaryRecord.transaction_id && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Transaction ID:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3690,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-900 font-mono text-sm bg-slate-100 px-3 py-1 rounded", children: existingSalaryRecord.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3693,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3689,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 font-medium", children: "Payment Method:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3699,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-900 font-medium", children: existingSalaryRecord.payment_method || "N/A" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                  lineNumber: 3702,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
                lineNumber: 3698,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
              lineNumber: 3534,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
            lineNumber: 3529,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 3253,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-32 text-gray-500", children: "Loading salary details..." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
          lineNumber: 3710,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
        lineNumber: 3214,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx",
    lineNumber: 1232,
    columnNumber: 5
  }, this);
};
_s(HRSalaryManagement, "BC46/94Iq/KFMsJHAByovv0nxiA=", false, function() {
  return [useNavigate, Form.useForm, Form.useForm];
});
_c = HRSalaryManagement;
export default HRSalaryManagement;
var _c;
$RefreshReg$(_c, "HRSalaryManagement");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HRSalaryManagement.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ2tCVSxTQXloRFksVUF6aERaOzJCQWhrQlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxXQUFXQyxVQUFVQyxlQUFlO0FBQzdDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQjtBQUFBLEVBQ0VwQixVQUFVcUI7QUFBQUEsRUFDVkM7QUFBQUEsRUFDQXJCLFVBQVVzQjtBQUFBQSxFQUNWQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyxjQUFjQyxzQkFBc0I7QUFDN0MsU0FBU0MsMkJBQTJCO0FBQ3BDLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLDhCQUE4QjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFDdkJqQixNQUFNa0IsT0FBT0wsR0FBRztBQUVoQixNQUFNTSxxQkFBcUJBLE1BQU07QUFBQUMsS0FBQTtBQUMvQixRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU0sQ0FBQ2MsZ0JBQWdCQyxpQkFBaUIsSUFBSWxDLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUNtQyxtQkFBbUJDLG9CQUFvQixJQUFJcEMsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ3FDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3VDLGVBQWVDLGdCQUFnQixJQUFJeEMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3lDLGtCQUFrQkMsbUJBQW1CLElBQUkxQyxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDMkMsV0FBV0MsWUFBWSxJQUFJNUMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzZDLGlCQUFpQkMsa0JBQWtCLElBQUk5QyxTQUFTLENBQUMsQ0FBQztBQUN6RCxRQUFNLENBQUMrQyxtQkFBbUJDLG9CQUFvQixJQUFJaEQsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ2lELHdCQUF3QkMseUJBQXlCLElBQUlsRCxTQUFTLEtBQUs7QUFDMUUsUUFBTSxDQUFDbUQsaUJBQWlCQyxrQkFBa0IsSUFBSXBELFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUNxRCxrQkFBa0JDLG1CQUFtQixJQUFJdEQsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQ3VELGdCQUFnQkMsaUJBQWlCLElBQUl4RCxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDeUQsaUJBQWlCQyxrQkFBa0IsSUFBSTFELFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMyRCxVQUFVQyxXQUFXLElBQUk1RCxTQUFTLElBQUk7QUFDN0MsUUFBTSxDQUFDNkQsSUFBSSxJQUFJdkUsS0FBS3dFLFFBQVE7QUFDNUIsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJaEUsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ2lFLFVBQVUsSUFBSTNFLEtBQUt3RSxRQUFRO0FBQ2xDLFFBQU0sQ0FBQ0ksc0JBQXNCQyx1QkFBdUIsSUFBSW5FLFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUNvRSxzQkFBc0JDLHVCQUF1QixJQUFJckUsU0FBUyxJQUFJO0FBQ3JFLFFBQU0sQ0FBQ3NFLGlCQUFpQkMsa0JBQWtCLElBQUl2RSxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDd0UsYUFBYUMsY0FBYyxJQUFJekUsU0FBUyxNQUFNO0FBQ3JELFFBQU0sQ0FBQzBFLHlCQUF5QkMsMEJBQTBCLElBQUkzRSxTQUFTLEVBQUU7QUFDekUsUUFBTSxDQUFDNEUseUJBQXlCQywwQkFBMEIsSUFBSTdFLFNBQVMsS0FBSztBQUM1RSxRQUFNLENBQUM4RSxnQkFBZ0JDLGlCQUFpQixJQUFJL0UsU0FBUztBQUFBLElBQ25EZ0YsYUFBYTtBQUFBLElBQ2JDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsVUFBVTtBQUFBLE1BQ1JDLE9BQU87QUFBQSxNQUNQQyxLQUFLO0FBQUEsTUFDTEMsa0JBQWtCO0FBQUEsTUFDbEJDLG1CQUFtQjtBQUFBLE1BQ25CQyxvQkFBb0I7QUFBQSxNQUNwQkMsbUJBQW1CO0FBQUEsTUFDbkJDLGtCQUFrQjtBQUFBLE1BQ2xCQyxZQUFZO0FBQUEsSUFDZDtBQUFBLElBQ0FDLFlBQVk7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsS0FBSztBQUFBLE1BQ0xDLEtBQUs7QUFBQSxNQUNMQyxrQkFBa0I7QUFBQSxJQUNwQjtBQUFBLElBQ0FDLHFCQUFxQjtBQUFBLElBQ3JCQyx1QkFBdUI7QUFBQSxJQUN2QkMsa0JBQWtCO0FBQUEsSUFDbEJDLHNCQUFzQjtBQUFBLElBQ3RCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLHVCQUF1QjtBQUFBLE1BQ3JCQyxRQUFRO0FBQUE7QUFBQSxNQUVSQyxjQUFjO0FBQUEsTUFDZEMsdUJBQXVCO0FBQUEsTUFDdkJDLDBCQUEwQjtBQUFBLElBQzVCO0FBQUEsSUFDQUMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUdELFFBQU0sQ0FBQ0Msc0JBQXNCQyx1QkFBdUIsSUFBSTlHLFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUMrRyx5QkFBeUJDLDBCQUEwQixJQUFJaEgsU0FBUyxLQUFLO0FBRTVFLFFBQU1pSCxXQUFXdEcsTUFBTSxFQUFFdUcsT0FBTyxNQUFNO0FBRXRDLFFBQU1DLGlCQUFpQjtBQUFBLElBQ3JCL0IsT0FBTztBQUFBLElBQ1BDLEtBQUs7QUFBQSxJQUNMQyxrQkFBa0I7QUFBQSxJQUNsQkMsbUJBQW1CO0FBQUEsSUFDbkJDLG9CQUFvQjtBQUFBLElBQ3BCQyxtQkFBbUI7QUFBQSxJQUNuQkMsa0JBQWtCO0FBQUEsSUFDbEJDLFlBQVk7QUFBQSxFQUNkO0FBRUEsUUFBTXlCLG1CQUFtQjtBQUFBLElBQ3ZCdkIsWUFBWTtBQUFBLElBQ1pDLEtBQUs7QUFBQSxJQUNMQyxLQUFLO0FBQUEsSUFDTEMsa0JBQWtCO0FBQUEsRUFDcEI7QUFFQSxRQUFNcUIsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxRQUFRQyxRQUFRLFNBQVM7QUFBQSxJQUNoQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxjQUFjO0FBQUEsSUFDN0MsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLE9BQU87QUFBQSxJQUNwQyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsaUJBQWlCO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBSXJDLFFBQU1DLGVBQWU7QUFBQSxJQUNuQixFQUFFRixLQUFLLFFBQVFDLFFBQVEsU0FBUztBQUFBLElBQ2hDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGdCQUFnQjtBQUFBLElBQy9DLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGNBQWM7QUFBQSxJQUM3QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsT0FBTztBQUFBLElBQ3BDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxRQUFRO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLFNBQVNDLFFBQVEsUUFBUTtBQUFBLElBQ2hDLEVBQUVELEtBQUssT0FBT0MsUUFBUSxNQUFNO0FBQUEsSUFDNUIsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsb0JBQW9CO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsb0JBQW9CO0FBQUEsSUFDdkQsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEscUJBQXFCO0FBQUEsSUFDeEQsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsb0JBQW9CO0FBQUEsSUFDdkQsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsbUJBQW1CO0FBQUEsSUFDckQsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUVELEtBQUssT0FBT0MsUUFBUSxNQUFNO0FBQUEsSUFDNUIsRUFBRUQsS0FBSyxPQUFPQyxRQUFRLE1BQU07QUFBQSxJQUM1QixFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxtQkFBbUI7QUFBQSxJQUNyRCxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsaUJBQWlCO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsY0FBYztBQUFBLEVBQUM7QUFJOUMsUUFBTUUsU0FBUztBQUFBLElBQ2IsRUFBRUMsT0FBTyxXQUFXQyxPQUFPLFdBQVdDLFVBQVUsTUFBTTtBQUFBLElBQ3RELEVBQUVGLE9BQU8sWUFBWUMsT0FBTyxZQUFZQyxVQUFVLE1BQU07QUFBQSxJQUN4RCxFQUFFRixPQUFPLFNBQVNDLE9BQU8sU0FBU0MsVUFBVSxNQUFNO0FBQUEsSUFDbEQsRUFBRUYsT0FBTyxTQUFTQyxPQUFPLFNBQVNDLFVBQVUsTUFBTTtBQUFBLElBQ2xELEVBQUVGLE9BQU8sT0FBT0MsT0FBTyxPQUFPQyxVQUFVLE1BQU07QUFBQSxJQUM5QyxFQUFFRixPQUFPLFFBQVFDLE9BQU8sUUFBUUMsVUFBVSxNQUFNO0FBQUEsSUFDaEQsRUFBRUYsT0FBTyxRQUFRQyxPQUFPLFFBQVFDLFVBQVUsTUFBTTtBQUFBLElBQ2hELEVBQUVGLE9BQU8sVUFBVUMsT0FBTyxVQUFVQyxVQUFVLE1BQU07QUFBQSxJQUNwRDtBQUFBLE1BQ0VGLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBLEVBQUVGLE9BQU8sV0FBV0MsT0FBTyxXQUFXQyxVQUFVLE1BQU07QUFBQSxJQUN0RCxFQUFFRixPQUFPLFlBQVlDLE9BQU8sWUFBWUMsVUFBVSxNQUFNO0FBQUEsSUFDeEQsRUFBRUYsT0FBTyxZQUFZQyxPQUFPLFlBQVlDLFVBQVUsTUFBTTtBQUFBLEVBQUM7QUFHM0QsUUFBTUMsZ0JBQWdCSixPQUFPOUcsTUFBTSxFQUFFbUgsU0FBUyxHQUFHLE9BQU8sRUFBRVosT0FBTyxJQUFJLENBQUMsR0FBR1E7QUFFekUsUUFBTSxDQUFDSyxVQUFVQyxXQUFXLElBQUloSSxTQUFTO0FBQUEsSUFDdkNnRixhQUFhO0FBQUEsSUFDYkMsT0FBTzRDO0FBQUFBLElBQ1AzQyxNQUFNK0I7QUFBQUEsSUFDTjlCLFVBQVU7QUFBQSxNQUNSQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLGtCQUFrQjtBQUFBLE1BQ2xCQyxtQkFBbUI7QUFBQSxNQUNuQkMsb0JBQW9CO0FBQUEsTUFDcEJDLG1CQUFtQjtBQUFBLE1BQ25CQyxrQkFBa0I7QUFBQSxNQUNsQkMsWUFBWTtBQUFBLElBQ2Q7QUFBQSxJQUNBQyxZQUFZO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLEtBQUs7QUFBQSxNQUNMQyxLQUFLO0FBQUEsTUFDTEMsa0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxJQUNBQyxxQkFBcUI7QUFBQSxJQUNyQkMsdUJBQXVCO0FBQUEsSUFDdkJDLGtCQUFrQjtBQUFBLElBQ2xCQyxzQkFBc0I7QUFBQSxJQUN0QjZCLHNCQUFzQjtBQUFBLElBQ3RCQyxhQUFhO0FBQUEsSUFDYjdCLGdCQUFnQjtBQUFBLElBQ2hCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsdUJBQXVCO0FBQUEsTUFDckJDLFFBQVE7QUFBQTtBQUFBLE1BRVJDLGNBQWM7QUFBQSxNQUNkQyx1QkFBdUI7QUFBQSxNQUN2QkMsMEJBQTBCO0FBQUEsSUFDNUI7QUFBQSxJQUNBd0IsY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxJQUNaQyxXQUFXO0FBQUEsSUFDWEMsNEJBQTRCO0FBQUEsSUFDNUJDLDJCQUEyQjtBQUFBLElBQzNCQyxtQkFBbUI7QUFBQSxNQUNqQkMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNScEMsZ0JBQWdCO0FBQUEsTUFDaEJxQyxTQUFTO0FBQUEsTUFDVEMsZUFBZTtBQUFBLE1BQ2ZDLGFBQWE7QUFBQSxNQUNiQyxrQkFBa0I7QUFBQSxNQUNsQkMsb0JBQW9CO0FBQUEsSUFDdEI7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLENBQUNDLHdCQUF3QkMseUJBQXlCLElBQUlqSixTQUFTLEtBQUs7QUFDMUUsUUFBTSxDQUFDa0osbUJBQW1CQyxvQkFBb0IsSUFBSW5KLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUNvSixtQkFBbUJDLG9CQUFvQixJQUFJckosU0FBUyxLQUFLO0FBRWhFLFFBQU1zSixvQkFBb0JBLE1BQU07QUFDOUJ4Qyw0QkFBd0IsSUFBSTtBQUFBLEVBQzlCO0FBR0EsUUFBTXlDLHVCQUF1QkEsTUFBTTtBQUNqQ3ZDLCtCQUEyQixJQUFJO0FBQUEsRUFDakM7QUFHQSxRQUFNd0MscUJBQXFCQSxNQUFNO0FBQy9CLFVBQU1DLGNBQWNDO0FBQUFBLE1BQ2xCM0IsU0FBU3hCLHNCQUFzQkUsZ0JBQWdCO0FBQUEsSUFDakQ7QUFDQSxVQUFNa0Qsc0JBQXNCRDtBQUFBQSxNQUMxQjNCLFNBQVN4QixzQkFBc0JHLHlCQUF5QjtBQUFBLElBQzFEO0FBQ0EsVUFBTWtELHlCQUF5QkY7QUFBQUEsTUFDN0IzQixTQUFTeEIsc0JBQXNCSSw0QkFBNEI7QUFBQSxJQUM3RDtBQUdBLFVBQU1rRCxnQkFBZ0JKLGNBQWNFLHVCQUF1QjtBQUUzRCxRQUFJRyxrQkFBa0I7QUFDdEIsUUFBSUQsZUFBZSxHQUFHO0FBRXBCQyx3QkFBa0JILHNCQUFzQjtBQUFBLElBQzFDLFdBQVdFLGVBQWUsR0FBRztBQUUzQkMsd0JBQWtCQyxLQUFLQyxJQUFJSCxZQUFZO0FBQUEsSUFDekM7QUFJQSxVQUFNSSx5QkFDSkwseUJBQXlCLElBQUksSUFBSUE7QUFFbkM1QixnQkFBWSxDQUFDa0MsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0hqRSxxQkFBcUI7QUFBQSxRQUNuQixHQUFHaUUsS0FBS2pFO0FBQUFBLFFBQ1I7QUFBQSxVQUNFa0UsTUFBTTtBQUFBLFVBQ054QyxPQUFPbUM7QUFBQUEsUUFDVDtBQUFBLE1BQUM7QUFBQSxNQUVIdkQsdUJBQXVCO0FBQUEsUUFDckIsR0FBRzJELEtBQUszRDtBQUFBQSxRQUNSSSwwQkFBMEJzRDtBQUFBQSxNQUM1QjtBQUFBLE1BQ0E3RCxzQkFBc0I7QUFBQTtBQUFBLElBQ3hCLEVBQUU7QUFFRjNHLFlBQVEySyxRQUFRLDBDQUEwQztBQUMxRHRELDRCQUF3QixLQUFLO0FBQUEsRUFDL0I7QUFHQSxRQUFNdUQsd0JBQXdCQSxNQUFNO0FBQ2xDLFVBQU1aLGNBQWNDO0FBQUFBLE1BQ2xCM0IsU0FBU3hCLHNCQUFzQkUsZ0JBQWdCO0FBQUEsSUFDakQ7QUFDQSxVQUFNa0Qsc0JBQXNCRDtBQUFBQSxNQUMxQjNCLFNBQVN4QixzQkFBc0JHLHlCQUF5QjtBQUFBLElBQzFEO0FBR0EsVUFBTW1ELGdCQUFnQkosY0FBY0UsdUJBQXVCO0FBQzNELFFBQUlHLGtCQUFrQjtBQUV0QixRQUFJRCxlQUFlLEdBQUc7QUFFcEJDLHdCQUFrQkgsc0JBQXNCO0FBQUEsSUFDMUMsV0FBV0UsZUFBZSxHQUFHO0FBRTNCQyx3QkFBa0JDLEtBQUtDLElBQUlILFlBQVk7QUFBQSxJQUN6QztBQUVBN0IsZ0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIOUQsc0JBQXNCMEQ7QUFBQUEsTUFDdEJ2RCx1QkFBdUI7QUFBQSxRQUNyQixHQUFHMkQsS0FBSzNEO0FBQUFBLFFBQ1JJLDBCQUEwQjtBQUFBLE1BQzVCO0FBQUEsSUFDRixFQUFFO0FBRUZsSCxZQUFRMkssUUFBUSw2Q0FBNkM7QUFDN0RwRCwrQkFBMkIsS0FBSztBQUFBLEVBQ2xDO0FBRUEsaUJBQWVzRCxpQkFBaUI7QUFDOUIsUUFBSTtBQUNGLFlBQU1DLGVBQWUsTUFBTTdKLElBQUk4SixJQUFJLFdBQVc7QUFDOUMsWUFBTUMsbUJBQW1CRixjQUFjRyxNQUFNQyxVQUFVQyxJQUFJLENBQUNDLFNBQVM7QUFBQSxRQUNuRWxELE9BQU9rRCxLQUFLQztBQUFBQSxRQUNacEQsT0FBTyxHQUFHbUQsS0FBS1YsSUFBSSxNQUFNVSxLQUFLRSxZQUFZLE1BQU07QUFBQSxNQUNsRCxFQUFFO0FBQ0ZuSSxtQkFBYTZILG9CQUFvQixFQUFFO0FBQUEsSUFDckMsU0FBU08sT0FBTztBQUNkcEksbUJBQWEsRUFBRTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLGlCQUFlcUksOEJBQThCQyxZQUFZO0FBQ3ZELFFBQUk7QUFDRnJHLGlDQUEyQixJQUFJO0FBQy9CLFlBQU0wRixlQUFlLE1BQU03SixJQUFJOEosSUFBSSxvREFBb0RVLFVBQVUsU0FBU25ELFVBQVU3QyxJQUFJLFVBQVU2QyxVQUFVOUMsS0FBSyxFQUFFO0FBQ25KTixpQ0FBMkI0RixjQUFjRyxNQUFNQSxRQUFRLEVBQUU7QUFBQSxJQUMzRCxTQUFTTSxPQUFPO0FBQ2RyRyxpQ0FBMkIsRUFBRTtBQUFBLElBQy9CLFVBQUM7QUFDQ0UsaUNBQTJCLEtBQUs7QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFFQTlFLFlBQVUsTUFBTTtBQUNkdUssbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFHTCxpQkFBZWEsY0FBY0MsSUFBSTtBQUMvQixRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNM0ssSUFBSThKLElBQUksbUJBQW1CWSxFQUFFLEVBQUU7QUFDdEQsYUFBT0MsVUFBVVgsTUFBTUE7QUFBQUEsSUFDekIsU0FBU00sT0FBTztBQUNkTSxjQUFRTixNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRCxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNTyxzQkFBc0IsT0FBT0wsWUFBWU0sWUFBWUMsYUFBYTtBQUN0RSxRQUFJO0FBQ0YsWUFBTUosV0FBVyxNQUFNM0ssSUFBSThKLElBQUkscUJBQXFCVSxVQUFVLElBQUk7QUFBQSxRQUNoRVEsUUFBUSxFQUFFRixZQUFZQyxTQUFTO0FBQUEsTUFDakMsQ0FBQztBQUNELGFBQU9KLFNBQVNYLE1BQU1qRSxnQkFBZ0I7QUFBQSxJQUN4QyxTQUFTa0YsS0FBSztBQUNaTCxjQUFRTixNQUFNLDJCQUEyQlcsR0FBRztBQUM1QyxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQywrQkFBK0IsT0FBT1YsZUFBZTtBQUN6RCxRQUFJO0FBQ0YsWUFBTUcsV0FBVyxNQUFNM0ssSUFBSThKO0FBQUFBLFFBQ3pCLDZCQUE2QlUsVUFBVSxVQUFVbkQsU0FBUzlDLEtBQUssU0FBUzhDLFNBQVM3QyxJQUFJO0FBQUEsTUFDdkY7QUFDQSxhQUFPbUcsU0FBU1gsTUFBTUEsS0FBS21CLG1CQUFtQjtBQUFBLElBQ2hELFNBQVNGLEtBQUs7QUFDWkwsY0FBUU4sTUFBTSxxQ0FBcUNXLEdBQUc7QUFDdEQsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTUcsOEJBQThCLE9BQ2xDWixZQUNBTSxZQUNBQyxhQUNHO0FBQ0gsUUFBSTtBQUNGLFlBQU1KLFdBQVcsTUFBTTNLLElBQUk4SjtBQUFBQSxRQUN6QixvQkFBb0JVLFVBQVU7QUFBQSxRQUM5QixFQUFFUSxRQUFRLEVBQUVGLFlBQVlDLFNBQVMsRUFBRTtBQUFBLE1BQ3JDO0FBQ0EsYUFBT0osU0FBU1gsTUFBTXFCLGtCQUFrQkMscUJBQXFCO0FBQUEsSUFDL0QsU0FBU0wsS0FBSztBQUNaTCxjQUFRTixNQUFNLDhCQUE4QlcsR0FBRztBQUMvQyxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNTSxpQkFBaUJBLENBQUNDLGdCQUFnQkMsaUJBQWlCO0FBQ3ZELFFBQUksQ0FBQ0Qsa0JBQWtCLENBQUNDLGNBQWM7QUFDcEMsYUFBTzFFLE9BQU9tRCxJQUFJLENBQUN3QixPQUFPLEVBQUUsR0FBR0EsR0FBR3hFLFVBQVUsS0FBSyxFQUFFO0FBQUEsSUFDckQ7QUFDQSxVQUFNeUUsVUFBVTFMLE1BQU11TCxjQUFjO0FBQ3BDLFVBQU1JLFFBQVEzTCxNQUFNO0FBQ3BCLFVBQU00TCxXQUFXRixRQUFRbkgsS0FBSztBQUM5QixVQUFNc0gsY0FBY0YsTUFBTXBILEtBQUs7QUFDL0IsVUFBTXVILGtCQUFrQi9DLE9BQU95QyxZQUFZO0FBQzNDLFdBQU8xRSxPQUFPbUQsSUFBSSxDQUFDM0YsT0FBT3lILFVBQVU7QUFDbEMsWUFBTUMsa0JBQ0pGLG9CQUFvQkYsWUFBWUcsUUFBUUwsUUFBUXBILE1BQU07QUFDeEQsWUFBTTJILGVBQ0pILG9CQUFvQkQsZUFBZUUsUUFBUUosTUFBTXJILE1BQU07QUFDekQsWUFBTTJDLFdBQ0o2RSxrQkFBa0JGLFlBQ2xCRSxrQkFBa0JELGVBQ2xCRyxtQkFDQUM7QUFDRixhQUFPLEVBQUUsR0FBRzNILE9BQU8yQyxTQUFTO0FBQUEsSUFDOUIsQ0FBQztBQUFBLEVBQ0g7QUFFQTdILFlBQVUsTUFBTTtBQUNkLFFBQ0VnSSxTQUFTL0MsZUFDVCtDLFNBQVM3QyxRQUNUckMsaUJBQWlCZ0ssY0FDakI7QUFDQSxZQUFNQyxjQUFjYjtBQUFBQSxRQUNsQnBKLGdCQUFnQmdLO0FBQUFBLFFBQ2hCOUUsU0FBUzdDO0FBQUFBLE1BQ1g7QUFDQSxZQUFNNkgsb0JBQW9CRCxZQUFZRTtBQUFBQSxRQUNwQyxDQUFDWixNQUFNQSxFQUFFekUsVUFBVUksU0FBUzlDLFNBQVMsQ0FBQ21ILEVBQUV4RTtBQUFBQSxNQUMxQztBQUNBLFVBQUksQ0FBQ21GLG1CQUFtQjtBQUN0QixjQUFNRSxhQUFhSCxZQUFZSSxLQUFLLENBQUNkLE1BQU0sQ0FBQ0EsRUFBRXhFLFFBQVE7QUFDdEQsWUFBSXFGLFlBQVk7QUFDZGpGLHNCQUFZLENBQUNrQyxVQUFVO0FBQUEsWUFDckIsR0FBR0E7QUFBQUEsWUFDSGpGLE9BQU9nSSxXQUFXdEY7QUFBQUEsVUFDcEIsRUFBRTtBQUFBLFFBQ0o7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDSSxTQUFTN0MsTUFBTTZDLFNBQVMvQyxhQUFhbkMsaUJBQWlCZ0ssWUFBWSxDQUFDO0FBRXZFLFFBQU1NLGFBQWEsT0FBTy9CLE9BQU87QUFDL0IsUUFBSTtBQUNGOUksdUJBQWlCLElBQUk7QUFDckJGLDJCQUFxQixJQUFJO0FBQ3pCbUMseUJBQW1CLEtBQUs7QUFDeEIsWUFBTTZJLGFBQWEsTUFBTWpDLGNBQWNDLEVBQUU7QUFDekMsVUFBSWdDLFlBQVk7QUFDZGhLLDJCQUFtQmdJLEVBQUU7QUFDckIsY0FBTWlDLGNBQWMxTSxNQUFNeU0sV0FBV0UsYUFBYSxNQUFNO0FBQ3hELGNBQU12RixZQUFXO0FBQUEsVUFDZi9DLGFBQWFvSSxZQUFZcEksYUFBYThGO0FBQUFBLFVBQ3RDN0YsT0FBT21JLFlBQVlHO0FBQUFBLFVBQ25CckksTUFBTW1JO0FBQUFBLFVBQ05sSSxVQUFVaUksWUFBWWpJO0FBQUFBLFVBQ3RCUyxZQUFZd0gsWUFBWXhIO0FBQUFBLFVBQ3hCSyxxQkFBcUJtSCxZQUFZbkgsdUJBQXVCO0FBQUEsVUFDeERDLHVCQUF1QmtILFlBQVlsSCx5QkFBeUI7QUFBQSxVQUM1REMsa0JBQWtCaUgsWUFBWWpILG9CQUFvQjtBQUFBLFVBQ2xEQyxzQkFBc0JnSCxZQUFZaEgsd0JBQXdCO0FBQUEsVUFDMUQ2QixzQkFBc0JtRixZQUFZbkYsd0JBQXdCO0FBQUEsVUFDMURDLGFBQWFrRixZQUFZbEYsZUFBZTtBQUFBLFVBQ3hDN0IsZ0JBQWdCK0csWUFBWS9HO0FBQUFBLFVBQzVCQyxnQkFBZ0I4RyxZQUFZOUcsa0JBQWtCO0FBQUEsVUFDOUNtQyxVQUFVMkUsWUFBWTNFLFdBQ2xCbEgsT0FBTzZMLFlBQVkzRSxRQUFRLElBQzNCbEgsT0FBTztBQUFBLFVBQ1hpTSxvQkFBb0JKLFlBQVlJLHNCQUFzQixDQUFDO0FBQUEsVUFDdkRqSCx1QkFBdUI2RyxZQUFZN0cseUJBQXlCO0FBQUEsWUFDMURDLFFBQVE7QUFBQTtBQUFBLFlBRVJDLGNBQWM7QUFBQSxZQUNkQyx1QkFBdUI7QUFBQSxZQUN2QkMsMEJBQTBCO0FBQUEsVUFDNUI7QUFBQSxVQUNBQyxRQUFRd0csWUFBWXhHO0FBQUFBLFFBQ3RCO0FBQ0E3QiwwQkFBa0JnRCxTQUFRO0FBQzFCOUQsbUJBQVd3SixlQUFlMUYsU0FBUTtBQUFBLE1BQ3BDO0FBQUEsSUFDRixTQUFTaUQsT0FBTztBQUNkdkwsY0FBUXVMLE1BQU0sZ0NBQWdDO0FBQUEsSUFDaEQsVUFBQztBQUNDMUksdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0wsc0JBQXNCLE9BQU90QyxPQUFPO0FBQ3hDLFFBQUk7QUFDRjVJLHVCQUFpQixJQUFJO0FBQ3JCLFlBQU05QixJQUFJaU4sT0FBTyxtQkFBbUJ2QyxFQUFFLEVBQUU7QUFDeEMzTCxjQUFRMkssUUFBUSx3Q0FBd0M7QUFDeEQxRyx5QkFBbUIsS0FBSztBQUN4QmtLLG1CQUFhO0FBQUEsSUFDZixTQUFTNUMsT0FBTztBQUNkdkwsY0FBUXVMLE1BQU0sb0NBQW9DO0FBQUEsSUFDcEQsVUFBQztBQUNDeEksdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNcUwsaUNBQWlDLFlBQVk7QUFDakQsUUFBSTtBQUNGMUUsMkJBQXFCLElBQUk7QUFDekIsWUFBTTJFLGFBQWF2TSxPQUFPLEVBQUUwRCxNQUFNOEMsU0FBUzlDLEtBQUssRUFBRUEsTUFBTTtBQUN4RCxZQUFNdUcsYUFBYWpLLE9BQU8sRUFDdkIyRCxLQUFLNkMsU0FBUzdDLElBQUksRUFDbEJELE1BQU02SSxVQUFVLEVBQ2hCQyxRQUFRLE9BQU8sRUFDZjdHLE9BQU8sWUFBWTtBQUN0QixZQUFNdUUsV0FBV2xLLE9BQU8sRUFDckIyRCxLQUFLNkMsU0FBUzdDLElBQUksRUFDbEJELE1BQU02SSxVQUFVLEVBQ2hCRSxNQUFNLE9BQU8sRUFDYjlHLE9BQU8sWUFBWTtBQUV0QixZQUFNbUUsV0FBVyxNQUFNM0ssSUFBSThKO0FBQUFBLFFBQ3pCLGtDQUFrQ3pDLFNBQVMvQyxXQUFXLGVBQWUrQyxTQUFTSyxVQUFVLGNBQWNMLFNBQVNNLFNBQVM7QUFBQSxRQUN4SCxFQUFFcUQsUUFBUSxFQUFFdUMsV0FBV3pDLFlBQVkwQyxTQUFTekMsU0FBUyxFQUFFO0FBQUEsTUFDekQ7QUFFQSxZQUFNLEVBQUUwQyw2QkFBNkJDLDZCQUE2QixJQUNoRS9DLFNBQVNYLEtBQUtBO0FBRWhCMUMsa0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxRQUNyQixHQUFHQTtBQUFBQSxRQUNIM0IsMkJBQTJCNEYsK0JBQStCO0FBQUEsUUFDMUQ3Riw0QkFBNEI4RixnQ0FBZ0M7QUFBQSxNQUM5RCxFQUFFO0FBRUZuRixnQ0FBMEIsS0FBSztBQUMvQnhKLGNBQVEySyxRQUFRLHNDQUFzQztBQUFBLElBQ3hELFNBQVNZLE9BQU87QUFDZHZMLGNBQVF1TCxNQUFNLGlDQUFpQztBQUFBLElBQ2pELFVBQUM7QUFDQzdCLDJCQUFxQixLQUFLO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBQ0EsUUFBTWtGLGNBQWNBLENBQUNDLG9CQUFvQjtBQUN2Q3RNLGFBQVMsd0JBQXdCc00sZUFBZTtBQUFBLEVBQ2xEO0FBRUEsUUFBTUMsZ0JBQWdCQSxDQUFDQyxrQkFBa0I7QUFDdkMsVUFBTUMsbUJBQW1CO0FBQUEsTUFDdkI7QUFBQSxRQUNFbkgsS0FBSztBQUFBLFFBQ0xJLE9BQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTTJHLFlBQVlHLGVBQWUxRCxHQUFHO0FBQUEsWUFBRztBQUFBO0FBQUEsVUFGM0MwRCxlQUFlMUQ7QUFBQUEsVUFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsTUFFSjtBQUFBLE1BQ0E7QUFBQSxRQUNFeEQsS0FBSztBQUFBLFFBQ0xJLE9BQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTXlGLFdBQVdxQixjQUFjMUQsR0FBRztBQUFBLFlBQUc7QUFBQTtBQUFBLFVBRnpDMEQsZUFBZTFEO0FBQUFBLFVBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLE1BRUo7QUFBQSxNQUNBO0FBQUEsUUFDRXhELEtBQUs7QUFBQSxRQUNMSSxPQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU07QUFDYjlELDBCQUFZNEssZUFBZTFELEdBQUc7QUFDOUJwSCxpQ0FBbUIsSUFBSTtBQUFBLFlBQ3pCO0FBQUEsWUFBRztBQUFBO0FBQUEsVUFMRThLLGVBQWUxRDtBQUFBQSxVQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxNQUVKO0FBQUEsSUFBQztBQUVILFdBQU8yRDtBQUFBQSxFQUNUO0FBRUEsaUJBQWVDLHFCQUFxQjtBQUNsQyxRQUFJO0FBQ0Z4TCxnQ0FBMEIsSUFBSTtBQUM5QixZQUFNcUgsZUFBZSxNQUFNN0osSUFBSThKLElBQUksYUFBYXpDLFNBQVMvQyxXQUFXLEVBQUU7QUFDdEUsWUFBTTZGLE1BQU1OLGNBQWNHLE1BQU1BO0FBQ2hDLFlBQU1pRSxrQkFBa0I7QUFBQSxRQUN0QixHQUFHeEg7QUFBQUEsUUFDSCxHQUFHMEQsS0FBSzFGO0FBQUFBLFFBQ1J5SixRQUFRL0QsS0FBSytELFVBQVU7QUFBQSxNQUN6QjtBQUNBLFlBQU1DLG9CQUFvQjtBQUFBLFFBQ3hCLEdBQUd6SDtBQUFBQSxRQUNILEdBQUd5RCxLQUFLakY7QUFBQUEsTUFDVjtBQUNBOUMseUJBQW1CK0gsR0FBRztBQUN0QjdDLGtCQUFZLENBQUNrQyxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSC9FLFVBQVV3SjtBQUFBQSxRQUNWL0ksWUFBWWlKO0FBQUFBLFFBQ1oxRyxjQUFjMEMsS0FBSytELFVBQVU7QUFBQSxNQUMvQixFQUFFO0FBQUEsSUFDSixTQUFTNUQsT0FBTztBQUNkbEkseUJBQW1CLENBQUMsQ0FBQztBQUFBLElBQ3ZCLFVBQUM7QUFDQ0ksZ0NBQTBCLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFFQW5ELFlBQVUsTUFBTTtBQUNkLFFBQUlnSSxTQUFTL0MsZUFBZStDLFNBQVM5QyxTQUFTOEMsU0FBUzdDLE1BQU07QUFDM0Q0Siw2QkFBdUI7QUFDdkJKLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUMzRyxTQUFTL0MsYUFBYStDLFNBQVM5QyxPQUFPOEMsU0FBUzdDLElBQUksQ0FBQztBQUV4RCxRQUFNNEoseUJBQXlCLFlBQVk7QUFDekMsUUFBSTtBQUNGekYsMkJBQXFCLElBQUk7QUFDekIsWUFBTXlFLGFBQWF2TSxPQUFPLEVBQUUwRCxNQUFNOEMsU0FBUzlDLEtBQUssRUFBRUEsTUFBTTtBQUN4RCxZQUFNQyxPQUFPNkMsU0FBUzdDO0FBQ3RCLFlBQU1zRyxhQUFhakssT0FBTyxFQUN2QjJELEtBQUtBLElBQUksRUFDVEQsTUFBTTZJLFVBQVUsRUFDaEJDLFFBQVEsT0FBTyxFQUNmN0csT0FBTyxZQUFZO0FBQ3RCLFlBQU11RSxXQUFXbEssT0FBTyxFQUNyQjJELEtBQUtBLElBQUksRUFDVEQsTUFBTTZJLFVBQVUsRUFDaEJFLE1BQU0sT0FBTyxFQUNiOUcsT0FBTyxZQUFZO0FBQ3RCLFlBQU02SCxjQUFjLE1BQU14RDtBQUFBQSxRQUN4QnhELFNBQVMvQztBQUFBQSxRQUNUd0c7QUFBQUEsUUFDQUM7QUFBQUEsTUFDRjtBQUNBLFlBQU11RCxzQkFBc0IsTUFBTWxEO0FBQUFBLFFBQ2hDL0QsU0FBUy9DO0FBQUFBLFFBQ1R3RztBQUFBQSxRQUNBQztBQUFBQSxNQUNGO0FBQ0EsWUFBTXdELGtDQUNKLE1BQU1yRCw2QkFBNkI3RCxTQUFTL0MsV0FBVztBQUN6RCxZQUFNaUcsOEJBQThCbEQsU0FBUy9DLFdBQVc7QUFDeEQsWUFBTXlFLGVBQ0hzRixlQUFlLE1BQU1FLG1DQUFtQztBQUMzRCxZQUFNcEQsbUJBQW1CcEMsZUFBZSxNQUFNdUYsdUJBQXVCO0FBQ3JFaEgsa0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxRQUNyQixHQUFHQTtBQUFBQSxRQUNIM0QsdUJBQXVCO0FBQUEsVUFDckJDLFFBQVF1SSxlQUFlO0FBQUE7QUFBQSxVQUV2QnRJLGNBQWNnRCxlQUFlO0FBQUEsVUFDN0IvQyx1QkFBdUJzSSx1QkFBdUI7QUFBQSxVQUM5Q3JJLDBCQUEwQmtGLG1CQUFtQjtBQUFBLFFBQy9DO0FBQUEsTUFDRixFQUFFO0FBQUEsSUFDSixTQUFTRixLQUFLO0FBQ1pMLGNBQVFOLE1BQU0sMENBQTBDVyxHQUFHO0FBQUEsSUFDN0QsVUFBQztBQUVDdEMsMkJBQXFCLEtBQUs7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFFQXRKLFlBQVUsTUFBTTtBQUNkLFFBQUlnSSxTQUFTL0MsYUFBYTtBQUN4QjBKLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUMzRyxVQUFVL0MsV0FBVyxDQUFDO0FBRTFCLFFBQU1rSyxvQkFBb0JBLENBQUNDLE1BQU07QUFDL0IsVUFBTSxFQUFFaEYsTUFBTXhDLE1BQU0sSUFBSXdILEVBQUUzSTtBQUUxQixRQUFJMkQsU0FBUyxVQUFVO0FBRXJCLFVBQUlpRixVQUFVekgsTUFBTTBILFFBQVEsWUFBWSxFQUFFO0FBQzFDLFlBQU1DLFlBQVlGLFFBQVFHLE1BQU0sS0FBSyxLQUFLLElBQUlDO0FBQzlDLFVBQUlGLFdBQVcsRUFBRztBQUVsQnRILGtCQUFZLENBQUNrQyxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSDFCLG1CQUFtQjtBQUFBLFVBQ2pCLEdBQUcwQixLQUFLMUI7QUFBQUEsVUFDUixDQUFDMkIsSUFBSSxHQUFHaUY7QUFBQUEsUUFDVjtBQUFBLE1BQ0YsRUFBRTtBQUVGO0FBQUEsSUFDRjtBQUdBcEgsZ0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIMUIsbUJBQW1CO0FBQUEsUUFDakIsR0FBRzBCLEtBQUsxQjtBQUFBQSxRQUNSLENBQUMyQixJQUFJLEdBQUd4QztBQUFBQSxNQUNWO0FBQUEsSUFDRixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU04SCxlQUFlQSxDQUFDdEYsTUFBTXhDLFVBQVU7QUFDcENLLGdCQUFZLENBQUNrQyxTQUFTO0FBQ3BCLFVBQUl3RixrQkFBa0IsRUFBRSxHQUFHeEYsTUFBTSxDQUFDQyxJQUFJLEdBQUd4QyxNQUFNO0FBRy9DLFVBQUl3QyxTQUFTLFNBQVM7QUFDcEJ1RiwwQkFBa0I7QUFBQSxVQUNoQixHQUFHQTtBQUFBQSxVQUNIdEosc0JBQXNCO0FBQUEsUUFDeEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxDQUFDLGVBQWUsU0FBUyxRQUFRLFFBQVEsRUFBRXVKLFNBQVN4RixJQUFJLEdBQUc7QUFDN0Q3Ryw0QkFBb0IsSUFBSTtBQUN4QkUsMEJBQWtCLEtBQUs7QUFDdkJrTSwwQkFBa0I7QUFBQSxVQUNoQixHQUFHQTtBQUFBQSxVQUNIeEgsYUFBYTtBQUFBLFVBQ2I1QixnQkFBZ0I7QUFBQSxVQUNoQkQsZ0JBQWdCO0FBQUE7QUFBQSxVQUVoQm1DLG1CQUFtQjtBQUFBLFlBQ2pCQyxVQUFVO0FBQUEsWUFDVkMsUUFBUTtBQUFBLFlBQ1JwQyxnQkFBZ0I7QUFBQSxZQUNoQnFDLFNBQVM7QUFBQSxZQUNUQyxlQUFlO0FBQUEsWUFDZkMsYUFBYTtBQUFBLFlBQ2JDLGtCQUFrQjtBQUFBLFlBQ2xCQyxvQkFBb0I7QUFBQSxVQUN0QjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsYUFBTzJHO0FBQUFBLElBQ1QsQ0FBQztBQUNEL0ssK0JBQTJCLEVBQUU7QUFBQSxFQUMvQjtBQUVBLFFBQU1pTCx5QkFBeUJBLENBQUN6RixNQUFNeEMsVUFBVTtBQUM5Q0ssZ0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIL0UsVUFBVSxFQUFFLEdBQUcrRSxLQUFLL0UsU0FBUztBQUFBLE1BQzdCUyxZQUFZLEVBQUUsR0FBR3NFLEtBQUt0RSxZQUFZLENBQUN1RSxJQUFJLEdBQUd4QyxNQUFNO0FBQUEsTUFDaERPLGFBQWE7QUFBQSxNQUNiNUIsZ0JBQWdCO0FBQUEsTUFDaEJELGdCQUFnQjtBQUFBLElBQ2xCLEVBQUU7QUFDRi9DLHdCQUFvQixJQUFJO0FBQ3hCRSxzQkFBa0IsS0FBSztBQUFBLEVBQ3pCO0FBRUEsUUFBTXFNLHVCQUF1QkEsQ0FBQzFGLE1BQU14QyxVQUFVO0FBQzVDSyxnQkFBWSxDQUFDa0MsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0gvRSxVQUFVLEVBQUUsR0FBRytFLEtBQUsvRSxVQUFVLENBQUNnRixJQUFJLEdBQUd4QyxNQUFNO0FBQUEsTUFDNUMvQixZQUFZLEVBQUUsR0FBR3NFLEtBQUt0RSxXQUFXO0FBQUEsTUFDakNzQyxhQUFhO0FBQUEsTUFDYjVCLGdCQUFnQjtBQUFBLE1BQ2hCRCxnQkFBZ0I7QUFBQSxJQUNsQixFQUFFO0FBQ0YvQyx3QkFBb0IsSUFBSTtBQUN4QkUsc0JBQWtCLEtBQUs7QUFBQSxFQUN6QjtBQUVBLFFBQU1zTSw2QkFBNkJBLENBQUNwRCxPQUFPcUQsT0FBT3BJLFVBQVU7QUFDMUQsVUFBTXFJLGtCQUFrQixDQUFDLEdBQUdqSSxTQUFTNUIsZ0JBQWdCO0FBQ3JENkosb0JBQWdCdEQsS0FBSyxJQUFJLEVBQUUsR0FBR3NELGdCQUFnQnRELEtBQUssR0FBRyxDQUFDcUQsS0FBSyxHQUFHcEksTUFBTTtBQUNyRUssZ0JBQVksQ0FBQ2tDLFVBQVUsRUFBRSxHQUFHQSxNQUFNL0Qsa0JBQWtCNkosZ0JBQWdCLEVBQUU7QUFBQSxFQUN4RTtBQUVBLFFBQU1DLG9CQUFvQkEsTUFBTTtBQUM5QmpJLGdCQUFZLENBQUNrQyxVQUFVO0FBQUEsTUFDckIsR0FBR0E7QUFBQUEsTUFDSC9ELGtCQUFrQixDQUFDLEdBQUcrRCxLQUFLL0Qsa0JBQWtCLEVBQUVnRSxNQUFNLElBQUl4QyxPQUFPLEVBQUUsQ0FBQztBQUFBLElBQ3JFLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTXVJLHVCQUF1QkEsQ0FBQ3hELFVBQVU7QUFDdEMsVUFBTXNELGtCQUFrQmpJLFNBQVM1QixpQkFBaUJnSztBQUFBQSxNQUNoRCxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNM0Q7QUFBQUEsSUFDbEI7QUFDQTFFLGdCQUFZLENBQUNrQyxVQUFVLEVBQUUsR0FBR0EsTUFBTS9ELGtCQUFrQjZKLGdCQUFnQixFQUFFO0FBQUEsRUFDeEU7QUFFQSxRQUFNTSxnQ0FBZ0NBLENBQUM1RCxPQUFPcUQsT0FBT3BJLFVBQVU7QUFDN0QsVUFBTXFJLGtCQUFrQixDQUFDLEdBQUdqSSxTQUFTOUIsbUJBQW1CO0FBQ3hEK0osb0JBQWdCdEQsS0FBSyxJQUFJLEVBQUUsR0FBR3NELGdCQUFnQnRELEtBQUssR0FBRyxDQUFDcUQsS0FBSyxHQUFHcEksTUFBTTtBQUNyRUssZ0JBQVksQ0FBQ2tDLFVBQVUsRUFBRSxHQUFHQSxNQUFNakUscUJBQXFCK0osZ0JBQWdCLEVBQUU7QUFBQSxFQUMzRTtBQUVBLFFBQU1PLHVCQUF1QkEsTUFBTTtBQUNqQ3ZJLGdCQUFZLENBQUNrQyxVQUFVO0FBQUEsTUFDckIsR0FBR0E7QUFBQUEsTUFDSGpFLHFCQUFxQjtBQUFBLFFBQ25CLEdBQUdpRSxLQUFLakU7QUFBQUEsUUFDUixFQUFFa0UsTUFBTSxJQUFJeEMsT0FBTyxFQUFFO0FBQUEsTUFBQztBQUFBLElBRTFCLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTTZJLDBCQUEwQkEsQ0FBQzlELFVBQVU7QUFDekMsVUFBTXNELGtCQUFrQmpJLFNBQVM5QixvQkFBb0JrSztBQUFBQSxNQUNuRCxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNM0Q7QUFBQUEsSUFDbEI7QUFDQTFFLGdCQUFZLENBQUNrQyxVQUFVLEVBQUUsR0FBR0EsTUFBTWpFLHFCQUFxQitKLGdCQUFnQixFQUFFO0FBQUEsRUFDM0U7QUFFQSxRQUFNUyxrQ0FBa0NBLENBQUMvRCxPQUFPcUQsT0FBT3BJLFVBQVU7QUFDL0QsVUFBTWtILG9CQUFvQixDQUFDLEdBQUc5RyxTQUFTN0IscUJBQXFCO0FBQzVEMkksc0JBQWtCbkMsS0FBSyxJQUFJLEVBQUUsR0FBR21DLGtCQUFrQm5DLEtBQUssR0FBRyxDQUFDcUQsS0FBSyxHQUFHcEksTUFBTTtBQUN6RUssZ0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIaEUsdUJBQXVCMkk7QUFBQUEsSUFDekIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNNkIseUJBQXlCQSxNQUFNO0FBQ25DMUksZ0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIaEUsdUJBQXVCO0FBQUEsUUFDckIsR0FBR2dFLEtBQUtoRTtBQUFBQSxRQUNSLEVBQUVpRSxNQUFNLElBQUl4QyxPQUFPLEVBQUU7QUFBQSxNQUFDO0FBQUEsSUFFMUIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNZ0osNEJBQTRCQSxDQUFDakUsVUFBVTtBQUMzQyxVQUFNbUMsb0JBQW9COUcsU0FBUzdCLHNCQUFzQmlLO0FBQUFBLE1BQ3ZELENBQUNDLEdBQUdDLE1BQU1BLE1BQU0zRDtBQUFBQSxJQUNsQjtBQUNBMUUsZ0JBQVksQ0FBQ2tDLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIaEUsdUJBQXVCMkk7QUFBQUEsSUFDekIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNK0Isc0JBQXNCM1EsUUFBUSxNQUFNO0FBQ3hDLFVBQU1rRixXQUFXTCxnQkFBZ0JLLFlBQVksQ0FBQztBQUM5QyxXQUFPMEwsT0FBT0MsT0FBTzNMLFFBQVEsRUFBRTRMLE9BQU8sQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTXRILE9BQU91SCxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQUEsRUFDM0UsR0FBRyxDQUFDbk0sY0FBYyxDQUFDO0FBRW5CLFFBQU1vTSx3QkFBd0JqUixRQUFRLE1BQU07QUFDMUMsVUFBTTJGLGFBQWFkLGdCQUFnQmMsY0FBYyxDQUFDO0FBQ2xELFVBQU11TCxPQUFPTixPQUFPQyxPQUFPbEwsVUFBVSxFQUFFbUw7QUFBQUEsTUFDckMsQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTXRILE9BQU91SCxLQUFLLENBQUM7QUFBQSxNQUMvQjtBQUFBLElBQ0Y7QUFDQSxXQUFPRTtBQUFBQSxFQUNULEdBQUcsQ0FBQ3JNLGNBQWMsQ0FBQztBQUVuQixpQkFBZXNNLHdCQUF3QjtBQUNyQyxRQUFJO0FBQ0YxTywwQkFBb0IsSUFBSTtBQUd4QnNGLGtCQUFZLENBQUNrQyxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSGpFLHFCQUFxQjtBQUFBLFFBQ3JCQyx1QkFBdUI7QUFBQSxRQUN2QkMsa0JBQWtCO0FBQUEsTUFDcEIsRUFBRTtBQUdGLFlBQU0ySCxhQUFhdk0sT0FBTyxFQUFFMEQsTUFBTThDLFNBQVM5QyxLQUFLLEVBQUVBLE1BQU07QUFDeEQsWUFBTXVHLGFBQWFqSyxPQUFPLEVBQUUyRCxLQUFLNkMsU0FBUzdDLElBQUksRUFBRUQsTUFBTTZJLFVBQVUsRUFBRUMsUUFBUSxPQUFPLEVBQUU3RyxPQUFPLFlBQVk7QUFDdEcsWUFBTXVFLFdBQVdsSyxPQUFPLEVBQUUyRCxLQUFLNkMsU0FBUzdDLElBQUksRUFBRUQsTUFBTTZJLFVBQVUsRUFBRUUsTUFBTSxPQUFPLEVBQUU5RyxPQUFPLFlBQVk7QUFHbEcsWUFBTSxDQUFDbUssV0FBV0MsYUFBYSxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNuRDlRLElBQUk4SixJQUFJLDZCQUE2QjtBQUFBLFlBQ25Da0IsUUFBUTtBQUFBLGNBQ04xRyxhQUFhK0MsU0FBUy9DO0FBQUFBLGNBQ3RCQyxPQUFPOEMsU0FBUzlDO0FBQUFBLGNBQ2hCQyxNQUFNNkMsU0FBUzdDO0FBQUFBLGNBQ2ZDLFVBQVU0QyxTQUFTNUM7QUFBQUEsY0FDbkJTLFlBQVltQyxTQUFTbkM7QUFBQUEsWUFDdkI7QUFBQSxVQUNGLENBQUM7QUFBQSxVQUNEbEYsSUFBSThKO0FBQUFBLFlBQ0Ysa0NBQWtDekMsU0FBUy9DLFdBQVcsZUFBZStDLFNBQVNLLFVBQVUsY0FBY0wsU0FBU00sU0FBUztBQUFBLFlBQ3hILEVBQUVxRCxRQUFRLEVBQUV1QyxXQUFXekMsWUFBWTBDLFNBQVN6QyxTQUFTLEVBQUU7QUFBQSxVQUN6RDtBQUFBLFFBQUM7QUFBQSxNQUNGO0FBRUQsWUFBTWdHLGFBQWFKLFVBQVUzRyxLQUFLQTtBQUNsQyxZQUFNLEVBQUV5RCw2QkFBNkJDLDZCQUE2QixJQUFJa0QsY0FBYzVHLEtBQUtBO0FBR3pGcEgsMEJBQW9CbU8sVUFBVTtBQUM5QnpKLGtCQUFZLENBQUNrQyxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSGpDLHNCQUFzQndKLFdBQVdDO0FBQUFBLFFBQ2pDbkosMkJBQTJCNEYsK0JBQStCO0FBQUEsUUFDMUQ3Riw0QkFBNEI4RixnQ0FBZ0M7QUFBQSxNQUM5RCxFQUFFO0FBRUY1Syx3QkFBa0IsSUFBSTtBQUN0Qi9ELGNBQVEySyxRQUFRLGdEQUFnRDtBQUFBLElBQ2xFLFNBQVNZLE9BQU87QUFDZE0sY0FBUU4sTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUMsVUFBSUEsTUFBTUssVUFBVXpFLFdBQVcsT0FBT29FLE1BQU1LLFVBQVVYLE1BQU1pSCxpQkFBaUI7QUFDM0V0TixnQ0FBd0IyRyxNQUFNSyxTQUFTWCxLQUFLaUgsZUFBZTtBQUMzRHhOLGdDQUF3QixJQUFJO0FBQzVCYiw0QkFBb0IsSUFBSTtBQUN4QkUsMEJBQWtCLEtBQUs7QUFDdkI7QUFBQSxNQUNGO0FBQ0EvRCxjQUFRdUwsTUFBTUEsTUFBTUssVUFBVVgsTUFBTWpMLFdBQVcsNkJBQTZCO0FBQUEsSUFDOUUsVUFBQztBQUNDaUQsMEJBQW9CLEtBQUs7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxpQkFBZWtQLGtCQUFrQjtBQUMvQixRQUFJO0FBQ0YsWUFBTUMsYUFBYXhPLG1CQUNmQSxpQkFBaUJxTyxvQkFDakJiLE9BQU9DLE9BQU8vSSxTQUFTNUMsUUFBUSxFQUFFNEw7QUFBQUEsUUFDakMsQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTXRILE9BQU91SCxLQUFLLENBQUM7QUFBQSxRQUMvQjtBQUFBLE1BQ0YsSUFDQUosT0FBT0MsT0FBTy9JLFNBQVNuQyxVQUFVLEVBQUVtTDtBQUFBQSxRQUNqQyxDQUFDQyxLQUFLQyxNQUFNRCxNQUFNdEgsT0FBT3VILEtBQUssQ0FBQztBQUFBLFFBQy9CO0FBQUEsTUFDRjtBQUVGLFlBQU1hLGVBQWUvSixTQUFTNUIsaUJBQWlCNEs7QUFBQUEsUUFDN0MsQ0FBQ0MsS0FBS2UsTUFBTWYsTUFBTXRILE9BQU9xSSxFQUFFcEssU0FBUyxDQUFDO0FBQUEsUUFDckM7QUFBQSxNQUNGO0FBQ0EsWUFBTXFLLDBCQUEwQmpLLFNBQVM5QixvQkFBb0I4SztBQUFBQSxRQUMzRCxDQUFDQyxLQUFLaUIsWUFBWWpCLE1BQU10SCxPQUFPdUksUUFBUXRLLFNBQVMsQ0FBQztBQUFBLFFBQ2pEO0FBQUEsTUFDRjtBQUNBLFlBQU11Syw0QkFBNEJuSyxTQUFTN0Isc0JBQXNCNks7QUFBQUEsUUFDL0QsQ0FBQ0MsS0FBS21CLGNBQWNuQixNQUFNdEgsT0FBT3lJLFVBQVV4SyxTQUFTLENBQUM7QUFBQSxRQUNyRDtBQUFBLE1BQ0Y7QUFHQSxVQUFJeUsscUJBQXFCO0FBQ3pCLFVBQUlDLDJCQUEyQnRLLFNBQVMzQix3QkFBd0I7QUFFaEUsWUFBTXFELGNBQWNDO0FBQUFBLFFBQ2xCM0IsU0FBU3hCLHNCQUFzQkUsZ0JBQWdCO0FBQUEsTUFDakQ7QUFDQSxZQUFNa0Qsc0JBQXNCRDtBQUFBQSxRQUMxQjNCLFNBQVN4QixzQkFBc0JHLHlCQUF5QjtBQUFBLE1BQzFEO0FBR0EsWUFBTW1ELGdCQUFnQkosY0FBY0UsdUJBQXVCO0FBRTNELFVBQUlFLGVBQWUsR0FBRztBQUNwQnVJLDZCQUFxQjtBQUNyQkEsOEJBQXNCTjtBQUN0Qk0sOEJBQ0VKLDBCQUEwQkU7QUFDNUJFLDhCQUFzQkU7QUFBQUEsTUFDeEIsV0FBV3pJLGVBQWUsR0FBRztBQUMzQnVJLDZCQUFxQlA7QUFDckJPLDhCQUFzQk47QUFDdEJNLDhCQUNFSiwwQkFBMEJFO0FBQUFBLE1BQzlCLE9BQU87QUFDTEUsNkJBQXFCUDtBQUNyQk8sOEJBQXNCTjtBQUN0Qk0sOEJBQ0VKLDBCQUEwQkU7QUFBQUEsTUFDOUI7QUFLQSxZQUFNSyxhQUFhN0ksT0FBTzNCLFNBQVNHLGVBQWUsQ0FBQztBQUNuRCxZQUFNc0ssbUJBQW1CSixxQkFBcUJHO0FBRTlDLFlBQU1FLG9CQUFvQnBQLG1CQUN0QjtBQUFBLFFBQ0FxUCxZQUFZclAsaUJBQWlCcVA7QUFBQUEsUUFDN0JDLGNBQWN0UCxpQkFBaUJzUDtBQUFBQSxRQUMvQkMsV0FBV3ZQLGlCQUFpQnVQO0FBQUFBLFFBQzVCQyxVQUFVeFAsaUJBQWlCd1A7QUFBQUEsUUFDM0JDLEtBQUt6UCxpQkFBaUJ5UDtBQUFBQSxRQUN0QkMsZ0JBQWdCMVAsaUJBQWlCMFA7QUFBQUEsUUFDakNyQixtQkFBbUJyTyxpQkFBaUJxTztBQUFBQSxRQUNwQ3NCLGFBQWEzUCxpQkFBaUIyUCxlQUFlO0FBQUEsUUFDN0NDLFlBQVk1UCxpQkFBaUI0UCxjQUFjO0FBQUEsUUFDM0NDLFdBQVc3UCxpQkFBaUI2UCxhQUFhO0FBQUEsUUFDekNDLGtCQUFrQjlQLGlCQUFpQjhQO0FBQUFBLFFBQ25DQyxnQkFBZ0IvUCxpQkFBaUIrUDtBQUFBQSxNQUNuQyxJQUNFLENBQUM7QUFFTCxZQUFNQyx5QkFBeUI7QUFBQSxRQUM3QjdNLFFBQVFrRCxPQUFPM0IsU0FBU3hCLHNCQUFzQkMsVUFBVSxDQUFDO0FBQUEsUUFDekRFLHVCQUF1QmdEO0FBQUFBLFVBQ3JCM0IsU0FBU3hCLHNCQUFzQkcseUJBQXlCO0FBQUEsUUFDMUQ7QUFBQTtBQUFBO0FBQUEsUUFHQUQsY0FBY3NCLFNBQVN4QixzQkFBc0JFO0FBQUFBLFFBQzdDRSwwQkFDRW9CLFNBQVN4QixzQkFBc0JJO0FBQUFBLE1BQ25DO0FBRUEsWUFBTXlHLGFBQWE7QUFBQSxRQUNqQnBJLGFBQWErQyxVQUFVL0M7QUFBQUEsUUFDdkJzTyxxQkFBcUI1Tyx5QkFBeUI0Tyx1QkFBdUI7QUFBQSxRQUNyRTlLLG1CQUFtQlQsU0FBU1M7QUFBQUEsUUFDNUIySyxrQkFBa0I5UCxtQkFDZEEsa0JBQWtCOFAsbUJBQ2xCLG9CQUFJSSxLQUFLO0FBQUEsUUFDYkgsZ0JBQWdCL1AsbUJBQ1pBLGlCQUFpQitQLGlCQUNqQixvQkFBSUcsS0FBSztBQUFBLFFBQ2JoRyxjQUFjeEYsU0FBUzlDO0FBQUFBLFFBQ3ZCcUksYUFBYXZGLFNBQVM3QztBQUFBQSxRQUN0QkMsVUFBVTRDLFNBQVM1QztBQUFBQSxRQUNuQlMsWUFBWW1DLFNBQVNuQztBQUFBQSxRQUNyQksscUJBQXFCOEIsU0FBUzlCO0FBQUFBLFFBQzlCQyx1QkFBdUI2QixTQUFTN0I7QUFBQUEsUUFDaENDLGtCQUFrQjRCLFNBQVM1QjtBQUFBQSxRQUMzQkMsc0JBQXNCaU07QUFBQUEsUUFDdEJPLFdBQVd2UCxtQkFBbUJBLGlCQUFpQnVQLFlBQVk7QUFBQSxRQUMzREUsS0FBS3pQLG1CQUFtQkEsaUJBQWlCeVAsTUFBTTtBQUFBLFFBQy9DRCxVQUFVeFAsbUJBQW1CQSxpQkFBaUJ3UCxXQUFXO0FBQUEsUUFDekRXLGFBQWFwQjtBQUFBQSxRQUNibEssYUFBYXFLO0FBQUFBLFFBQ2JrQixtQkFBbUJqQjtBQUFBQSxRQUNuQnZLLHNCQUFzQm1LO0FBQUFBLFFBQ3RCL0wsZ0JBQWdCMEIsU0FBUzFCO0FBQUFBLFFBQ3pCTyxRQUFRO0FBQUEsUUFDUjRHLG9CQUFvQmlGO0FBQUFBLFFBQ3BCbE0sdUJBQXVCOE07QUFBQUEsUUFDdkJLLGlCQUFpQjtBQUFBLFVBQ2ZyTCxXQUFXTixVQUFVTTtBQUFBQSxVQUNyQkUsMkJBQTJCUixVQUFVUTtBQUFBQSxRQUN2QztBQUFBLFFBQ0FvTCxrQkFBa0I7QUFBQSxVQUNoQnZMLFlBQVlMLFVBQVVLO0FBQUFBLFVBQ3RCRSw0QkFBNEJQLFVBQVVPO0FBQUFBLFFBQ3hDO0FBQUEsTUFDRjtBQUVBLFlBQU01SCxJQUFJa1QsS0FBSyxvQkFBb0J4RyxVQUFVO0FBQzdDM04sY0FBUTJLLFFBQVEsMkJBQTJCO0FBQzNDbEksd0JBQWtCLEtBQUs7QUFDdkJvQiwwQkFBb0IsSUFBSTtBQUN4QkUsd0JBQWtCLEtBQUs7QUFDdkJvSyxtQkFBYTtBQUFBLElBQ2YsU0FBUzVDLE9BQU87QUFDZE0sY0FBUU4sTUFBTSx3QkFBd0JBLEtBQUs7QUFDM0N2TCxjQUFRdUwsTUFBTUEsT0FBT0ssVUFBVVgsTUFBTWpMLFdBQVcsc0JBQXNCO0FBQUEsSUFDeEU7QUFBQSxFQUNGO0FBRUEsaUJBQWVtTyxlQUFlO0FBQzVCLFFBQUk7QUFDRjVKLDBCQUFvQixJQUFJO0FBQ3hCLFlBQU1xSCxXQUFXLE1BQU0zSyxJQUFJOEosSUFBSSxxQkFBcUI7QUFDcEQsWUFBTUQsZUFBZWMsVUFBVVgsTUFBTUEsUUFBUTtBQUM3QyxZQUFNbUosZUFBZXRKLGFBQWFLLElBQUksQ0FBQ0YsTUFBTWdDLFdBQVc7QUFBQSxRQUN0RG9ILE1BQU1wSCxRQUFRO0FBQUEsUUFDZDVCLEtBQUtKLE1BQU1JO0FBQUFBLFFBQ1hpSixjQUFjckosTUFBTTFGLGFBQWFtRjtBQUFBQSxRQUNqQzZKLGNBQWN0SixNQUFNMUYsYUFBYWdQO0FBQUFBLFFBQ2pDQyxhQUFhdkosTUFBTTZDO0FBQUFBLFFBQ25CMkcsWUFBWXhKLE1BQU00QztBQUFBQSxRQUNsQjZHLFlBQVl6SixNQUFNekM7QUFBQUEsUUFDbEJzSyxZQUFZN0gsTUFBTXhDO0FBQUFBLFFBQ2xCa00sY0FBYzFKLE1BQU04QyxvQkFBb0JtRixnQkFBZ0IsTUFBTWpJLE1BQU04QyxvQkFBb0IwRixhQUFhO0FBQUEsUUFDckdtQixZQUFhM0osTUFBTThDLG9CQUFvQndGLGVBQWdCO0FBQUEsUUFDdkRzQixZQUFhNUosTUFBTThDLG9CQUFvQnlGLGNBQWU7QUFBQSxRQUN0RHNCLFdBQVk3SixNQUFNOEMsb0JBQW9Ca0YsY0FBZTtBQUFBLFFBQ3JEdE4sT0FBT3NGLE1BQU12RixVQUFVQztBQUFBQSxRQUN2QkMsS0FBS3FGLE1BQU12RixVQUFVRTtBQUFBQSxRQUNyQm1QLGlCQUFpQjlKLE1BQU12RixVQUFVRztBQUFBQSxRQUNqQ21QLGtCQUFrQi9KLE1BQU12RixVQUFVSTtBQUFBQSxRQUNsQ21QLGtCQUFrQmhLLE1BQU12RixVQUFVSztBQUFBQSxRQUNsQ21QLGtCQUFrQmpLLE1BQU12RixVQUFVTTtBQUFBQSxRQUNsQ21QLGlCQUFpQmxLLE1BQU12RixVQUFVTztBQUFBQSxRQUNqQ0MsWUFBWStFLE1BQU12RixVQUFVUTtBQUFBQSxRQUM1QmtQLFdBQVduSyxNQUFNOUUsWUFBWUM7QUFBQUEsUUFDN0JDLEtBQUs0RSxNQUFNOUUsWUFBWUU7QUFBQUEsUUFDdkJDLEtBQUsyRSxNQUFNOUUsWUFBWUc7QUFBQUEsUUFDdkIrTyxpQkFBaUJwSyxNQUFNOUUsWUFBWUk7QUFBQUEsUUFDbkMrTyxlQUFlckssTUFBTTlFLFlBQVlvUDtBQUFBQSxRQUNqQ3BPLFFBQVE4RCxNQUFNOUQ7QUFBQUEsUUFDZHFPLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLENBQUMsT0FBTztBQUFBLFlBQ2pCLE1BQU07QUFBQSxjQUNKQyxPQUFPM0csY0FBYzdELElBQUk7QUFBQSxZQUMzQjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQ1YsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUE7QUFBQSxVQU4xQkEsTUFBTUk7QUFBQUEsVUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxNQUVKLEVBQUU7QUFDRjlILDJCQUFxQixDQUFDLEdBQUc2USxZQUFZLENBQUM7QUFBQSxJQUN4QyxTQUFTN0ksT0FBTztBQUNkaEksMkJBQXFCLEVBQUU7QUFBQSxJQUN6QixVQUFDO0FBQ0NnQiwwQkFBb0IsS0FBSztBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBakUsWUFBVSxNQUFNO0FBQ2Q2TixpQkFBYTtBQUFBLEVBQ2YsR0FBRyxFQUFFO0FBRUwsUUFBTXVILDBCQUEwQkEsQ0FBQ2hHLE1BQU07QUFDckMsVUFBTWlHLGVBQWVqRyxFQUFFM0ksT0FBT21CO0FBQzlCbEQsbUJBQWUyUSxZQUFZO0FBQzNCcE4sZ0JBQVksQ0FBQ3FOLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNIQyxVQUFVRjtBQUFBQSxNQUVWOU8sZ0JBQ0U4TyxpQkFBaUIsWUFBWUEsaUJBQWlCLGVBQzFDQyxTQUFTL08saUJBQ1Q7QUFBQSxJQUNSLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTWlQLCtCQUErQnRWLFFBQVEsTUFBTTtBQUNqRCxVQUFNa0YsV0FBVzRDLFNBQVM1QyxZQUFZLENBQUM7QUFDdkMsV0FBTzBMLE9BQU8yRSxLQUFLclEsUUFBUSxFQUN4QmdMLE9BQU8sQ0FBQzdJLFFBQVFBLFFBQVEsUUFBUSxFQUNoQ3lKLE9BQU8sQ0FBQ0MsS0FBSzFKLFFBQVEwSixPQUFPdEgsT0FBT3ZFLFNBQVNtQyxHQUFHLENBQUMsS0FBSyxJQUFJLENBQUM7QUFBQSxFQUMvRCxHQUFHLENBQUNTLFNBQVM1QyxRQUFRLENBQUM7QUFFdEIsUUFBTW1OLGtCQUFrQnJTLFFBQVEsTUFBTTtBQUNwQyxVQUFNd1YsaUJBQWlCMU4sU0FBU25DLGNBQWMsQ0FBQztBQUMvQyxVQUFNOFAsWUFBWTdFLE9BQU9DLE9BQU8yRSxjQUFjLEVBQUUxRTtBQUFBQSxNQUM5QyxDQUFDQyxLQUFLMkUsUUFBUTNFLE9BQU90SCxPQUFPaU0sR0FBRyxLQUFLO0FBQUEsTUFDcEM7QUFBQSxJQUNGO0FBQ0EsV0FBT0Q7QUFBQUEsRUFDVCxHQUFHLENBQUMzTixTQUFTbkMsVUFBVSxDQUFDO0FBRXhCLFFBQU1nUSxzQkFBc0IzVjtBQUFBQSxJQUFRLE1BQU07QUFDeEMsWUFBTXdKLGNBQWNDO0FBQUFBLFFBQ2xCM0IsU0FBU3hCLHNCQUFzQkUsZ0JBQWdCO0FBQUEsTUFDakQ7QUFDQSxZQUFNa0Qsc0JBQXNCRDtBQUFBQSxRQUMxQjNCLFNBQVN4QixzQkFBc0JHLHlCQUF5QjtBQUFBLE1BQzFEO0FBRUEsWUFBTW1ELGdCQUFnQkosY0FBY0UsdUJBQXVCO0FBRTNELFVBQUlFLGVBQWUsR0FBRztBQUNwQixlQUFPRixzQkFBc0I7QUFBQSxNQUMvQixXQUFXRSxlQUFlLEdBQUc7QUFDM0IsZUFBT0UsS0FBS0MsSUFBSUgsWUFBWTtBQUFBLE1BQzlCLE9BQU87QUFDTCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxJQUFHO0FBQUEsTUFDRDlCLFNBQVN4QixzQkFBc0JFO0FBQUFBLE1BQy9Cc0IsU0FBU3hCLHNCQUFzQkc7QUFBQUEsSUFBcUI7QUFBQSxFQUNyRDtBQUdELFFBQU1tUCxZQUFZO0FBQUEsSUFDaEI7QUFBQSxNQUNFQyxJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDdkNyTyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFb08sSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDckJyTyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFb08sSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsMEJBQXVCLE1BQU0sTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ3ZDck8sT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRW9PLElBQUk7QUFBQSxNQUNKQyxNQUFNLHVCQUFDLDBCQUF1QixNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUN2Q3JPLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VvTyxJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDdkNyTyxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFHSCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsUUFBRyxXQUFVLDBCQUF5QixpQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQ3hELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdDQUNiLGlDQUFDLFNBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXhGLGtCQUFrQixJQUFJO0FBQUEsY0FDckMsV0FBVTtBQUFBLGNBQW9HO0FBQUE7QUFBQSxZQUZoSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxhQUFRLFdBQVUsUUFDakI7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsc0VBQXFFLCtCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1oyVCxvQkFBVWpMO0FBQUFBLGNBQUksQ0FBQ29MLFNBQ2Q7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsSUFBSUEsS0FBS0Y7QUFBQUEsa0JBQ1QsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsVUFBSyxXQUFVLGlCQUFpQkUsZUFBS0QsUUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQSxvQkFDMUNDLEtBQUt0TztBQUFBQTtBQUFBQTtBQUFBQSxnQkFMRHNPLEtBQUtGO0FBQUFBLGdCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLFlBQ0QsS0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBRUMvUixtQkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyx1QkFBQyxtQkFBZ0IsT0FBTyxFQUFFa1MsVUFBVSxHQUFHLEdBQUcsTUFBSSxRQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBLGNBQ3pELFdBQVU7QUFBQTtBQUFBLFlBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRW9CLEtBRWpCbFQscUJBQXFCLElBQUl5TSxTQUFTLElBQ3JDLHVCQUFDLGFBQVUsU0FBa0IsTUFBTXpNLG1CQUFtQixZQUFZeUUsY0FBYyxrQkFBaUIsdUJBQXNCLGlCQUFnQixxQkFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0osSUFFeEosdUJBQUMsU0FBTSxhQUFZLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLGFBckM3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUNBO0FBQUEsV0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJDQTtBQUFBLFNBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQ0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxXQUFVO0FBQUEsUUFDVixNQUFNdkY7QUFBQUEsUUFDTixTQUFTLE1BQU07QUFDYkMsNEJBQWtCLEtBQUs7QUFDdkJvQiw4QkFBb0IsSUFBSTtBQUN4QkUsNEJBQWtCLEtBQUs7QUFBQSxRQUN6QjtBQUFBLFFBQ0EsVUFBVTtBQUFBLFFBQ1YsUUFDRSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNdEIsa0JBQWtCLEtBQUs7QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FBeUM7QUFBQTtBQUFBLFlBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlBO0FBQUEsVUFDQ21CLG9CQUNDLHVCQUFDLFVBQU8sTUFBSyxXQUFVLFNBQVN1TyxpQkFBaUIsMkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUYsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxjQUM5Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxrQkFBaUI7QUFBQSxnQkFDakIsY0FBYyxDQUFDc0UsT0FBT0MsWUFDbkJBLFFBQVF6TyxTQUFTLElBQ2YwTyxZQUFZLEVBQ1p6RyxTQUFTdUcsTUFBTUUsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLFlBQVksQ0FBQ0MsU0FBU0MsYUFDbkJELFNBQVMzTyxTQUFTLElBQ2hCME8sWUFBWSxFQUNaRyxlQUFlRCxTQUFTNU8sU0FBUyxJQUFJME8sWUFBWSxDQUFDO0FBQUEsZ0JBRXZELE9BQU8sRUFBRUksT0FBTyxPQUFPO0FBQUEsZ0JBQ3ZCLGFBQVk7QUFBQSxnQkFDWixTQUFTN1Q7QUFBQUEsZ0JBQ1QsVUFBVSxDQUFDZ0YsVUFBVThILGFBQWEsZUFBZTlILEtBQUs7QUFBQTtBQUFBLGNBaEJ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFnQjBEO0FBQUEsZUFwQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFDQyxDQUFDMUUseUJBQ0E4RSxTQUFTL0MsZUFDVDZMLE9BQU9DLE9BQU9qTyxlQUFlLEVBQUUyTSxTQUFTLEtBQ3RDLG1DQUNFO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxrQkFDbEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FDRXpILFNBQVM3QyxPQUFPdkUsTUFBTW9ILFNBQVM3QyxNQUFNLE1BQU0sSUFBSTtBQUFBLG9CQUVqRCxVQUFVLENBQUN1UixNQUFNQyxlQUNmakgsYUFBYSxRQUFRaUgsVUFBVTtBQUFBLG9CQUVqQyxRQUFPO0FBQUEsb0JBQ1AsT0FBTyxFQUFFRixPQUFPLE9BQU87QUFBQSxvQkFDdkIsY0FBYyxDQUFDRyxZQUFZO0FBQ3pCLDBCQUFJLENBQUM5VCxpQkFBaUJnSyxhQUFjLFFBQU87QUFDM0MsNEJBQU1OLFdBQVc1TDtBQUFBQSx3QkFDZmtDLGdCQUFnQmdLO0FBQUFBLHNCQUNsQixFQUFFM0gsS0FBSztBQUNQLDRCQUFNc0gsY0FBYzdMLE1BQU0sRUFBRXVFLEtBQUs7QUFDakMsNEJBQU1BLE9BQU95UixVQUFVQSxRQUFRelIsS0FBSyxJQUFJO0FBQ3hDLDZCQUFPQSxPQUFPcUgsWUFBWXJILE9BQU9zSDtBQUFBQSxvQkFDbkM7QUFBQTtBQUFBLGtCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaUJJO0FBQUEsbUJBckJOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUNqRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBT3pFLFNBQVM5QztBQUFBQSxvQkFDaEIsU0FBU2dIO0FBQUFBLHNCQUNQcEosaUJBQWlCZ0s7QUFBQUEsc0JBQ2pCOUUsU0FBUzdDO0FBQUFBLG9CQUNYO0FBQUEsb0JBQ0EsVUFBVSxDQUFDeUMsVUFBVThILGFBQWEsU0FBUzlILEtBQUs7QUFBQSxvQkFDaEQsT0FBTyxFQUFFNk8sT0FBTyxJQUFJO0FBQUE7QUFBQSxrQkFSdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVF3QjtBQUFBLG1CQVoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNENBQTJDLGdDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0Msb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPM1QsaUJBQWlCc0g7QUFBQUEsc0JBQ3hCLFVBQVE7QUFBQTtBQUFBLG9CQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLVTtBQUFBLHFCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPdEgsaUJBQWlCK1Q7QUFBQUEsc0JBQ3hCLFVBQVE7QUFBQTtBQUFBLG9CQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLVTtBQUFBLHFCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPL1QsaUJBQWlCa0k7QUFBQUEsc0JBQ3hCLFVBQVE7QUFBQTtBQUFBLG9CQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLVTtBQUFBLHFCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPbEksaUJBQWlCZ0ssY0FBY2dLLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxzQkFDbEQsVUFBUTtBQUFBO0FBQUEsb0JBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtVO0FBQUEscUJBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQywyQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLE9BQU9oVSxpQkFBaUJtUjtBQUFBQSxzQkFDeEIsVUFBUTtBQUFBO0FBQUEsb0JBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtVO0FBQUEscUJBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLG1CQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTZEQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDhCQUE2Qix3QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUQ7QUFBQSxnQkFDbkQsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPak0sVUFBVTVDLFVBQVV5SixVQUFVO0FBQUEsd0JBQ3JDLFVBQVE7QUFBQTtBQUFBLHNCQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJVTtBQUFBLHVCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLE9BQU83RyxVQUFVNUMsVUFBVUMsU0FBUztBQUFBLHdCQUNwQyxVQUFRO0FBQUE7QUFBQSxzQkFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSVU7QUFBQSxvQkFFVix1QkFBQyxVQUFLLFdBQVUsNENBQ2I5RCw4QkFBb0J5RyxVQUFVNUMsVUFBVUMsU0FBUyxDQUFDLEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPMkMsVUFBVTVDLFVBQVVFLE9BQU87QUFBQSx3QkFDbEMsVUFBUTtBQUFBO0FBQUEsc0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlVO0FBQUEsb0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNiL0QsOEJBQW9CeUcsVUFBVTVDLFVBQVVFLE9BQU8sQ0FBQyxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxnQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQ1YsT0FBTzBDLFVBQVU1QyxVQUFVRyxvQkFBb0I7QUFBQSx3QkFDL0MsVUFBUTtBQUFBO0FBQUEsc0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlVO0FBQUEsb0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNiaEU7QUFBQUEsc0JBQ0N5RyxVQUFVNUMsVUFBVUcsb0JBQW9CO0FBQUEsb0JBQzFDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsaUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLE9BQU95QyxVQUFVNUMsVUFBVUkscUJBQXFCO0FBQUEsd0JBQ2hELFVBQVE7QUFBQTtBQUFBLHNCQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJVTtBQUFBLG9CQUVWLHVCQUFDLFVBQUssV0FBVSw0Q0FDYmpFO0FBQUFBLHNCQUNDeUcsVUFBVTVDLFVBQVVJLHFCQUFxQjtBQUFBLG9CQUMzQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLGtDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPd0MsVUFBVTVDLFVBQVVLLHNCQUFzQjtBQUFBLHdCQUNqRCxVQUFRO0FBQUE7QUFBQSxzQkFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSVU7QUFBQSxvQkFFVix1QkFBQyxVQUFLLFdBQVUsNENBQ2JsRTtBQUFBQSxzQkFDQ3lHLFVBQVU1QyxVQUFVSyxzQkFBc0I7QUFBQSxvQkFDNUMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFlQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxpQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQ1YsT0FBT3VDLFVBQVU1QyxVQUFVTSxxQkFBcUI7QUFBQSx3QkFDaEQsVUFBUTtBQUFBO0FBQUEsc0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlVO0FBQUEsb0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNibkU7QUFBQUEsc0JBQ0N5RyxVQUFVNUMsVUFBVU0scUJBQXFCO0FBQUEsb0JBQzNDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsZ0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLE9BQU9zQyxVQUFVNUMsVUFBVU8sb0JBQW9CO0FBQUEsd0JBQy9DLFVBQVE7QUFBQTtBQUFBLHNCQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJVTtBQUFBLG9CQUVWLHVCQUFDLFVBQUssV0FBVSw0Q0FDYnBFO0FBQUFBLHNCQUNDeUcsVUFBVTVDLFVBQVVPLG9CQUFvQjtBQUFBLG9CQUMxQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPcUMsVUFBVTVDLFVBQVVRLGNBQWM7QUFBQSx3QkFDekMsVUFBUTtBQUFBO0FBQUEsc0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlVO0FBQUEsb0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNickU7QUFBQUEsc0JBQ0N5RyxVQUFVNUMsVUFBVVEsY0FBYztBQUFBLG9CQUNwQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWVBO0FBQUEscUJBdklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0lBO0FBQUEsbUJBMUlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMklBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0JBQThCLDBCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLGdCQUN0RCx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLE9BQU9vQyxVQUFVbkMsWUFBWUMsY0FBYztBQUFBLHdCQUMzQyxVQUFRO0FBQUE7QUFBQSxzQkFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSVU7QUFBQSxvQkFFVix1QkFBQyxVQUFLLFdBQVUsNENBQ2J2RTtBQUFBQSxzQkFDQ3lHLFVBQVVuQyxZQUFZQyxjQUFjO0FBQUEsb0JBQ3RDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsOENBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLE9BQU9rQyxVQUFVbkMsWUFBWUUsT0FBTztBQUFBLHdCQUNwQyxVQUFRO0FBQUE7QUFBQSxzQkFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSVU7QUFBQSxvQkFFVix1QkFBQyxVQUFLLFdBQVUsNENBQ2J4RSw4QkFBb0J5RyxVQUFVbkMsWUFBWUUsT0FBTyxDQUFDLEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPaUMsVUFBVW5DLFlBQVlHLE9BQU87QUFBQSx3QkFDcEMsVUFBUTtBQUFBO0FBQUEsc0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlVO0FBQUEsb0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNiekUsOEJBQW9CeUcsVUFBVW5DLFlBQVlHLE9BQU8sQ0FBQyxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxnQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQ1YsT0FBT2dDLFVBQVVuQyxZQUFZSSxvQkFBb0I7QUFBQSx3QkFDakQsVUFBUTtBQUFBO0FBQUEsc0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlVO0FBQUEsb0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNiMUU7QUFBQUEsc0JBQ0N5RyxVQUFVbkMsWUFBWUksb0JBQW9CO0FBQUEsb0JBQzVDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLGdDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPc00sZ0JBQWdCd0UsUUFBUSxDQUFDO0FBQUEsd0JBQ2hDLFVBQVE7QUFBQTtBQUFBLHNCQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJVTtBQUFBLG9CQUVWLHVCQUFDLFVBQUssV0FBVSw0Q0FDYnhWLDhCQUFvQmdSLGdCQUFnQndFLFFBQVEsQ0FBQyxDQUFDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkVBO0FBQUEsbUJBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBOEVBO0FBQUEsaUJBaFNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaVNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsbUdBRWI7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDhEQUNiLGlDQUFDLGFBQVUsV0FBVSx3QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsMENBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUViO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsMkNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QztBQUFBLG9CQUN6Qyx1QkFBQyxXQUFNLFdBQVUsdUNBQXNDLG9DQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUMzSCxNQUFNQSxFQUFFM0ksT0FBT3VRLEtBQUs7QUFBQSxzQkFDOUIsT0FBT2hQLFVBQVV4Qix1QkFBdUJDLFVBQVU7QUFBQSxzQkFDbEQ7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSytNO0FBQUEsa0JBRS9NLHVCQUFDLFVBQUssV0FBVSxvREFDYmxGO0FBQUFBLG9CQUNDeUcsVUFBVXhCLHVCQUF1QkMsVUFBVTtBQUFBLGtCQUM3QyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxnQkFrREEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsMkNBQUMsZUFBWSxXQUFVLDhCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRDtBQUFBLG9CQUNqRCx1QkFBQyxXQUFNLFdBQVUsMkNBQTBDLHFEQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0M0QyxxQkFBcUIsdUJBQUMsUUFBSyxNQUFLLFNBQVEsV0FBVSxVQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQztBQUFBLHVCQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE9BQU9BLG9CQUFvQixnQkFDekJyQixVQUFVeEIsdUJBQ05HLHlCQUF5QjtBQUFBLHNCQUUvQjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPOEg7QUFBQSxrQkFHOUgsdUJBQUMsVUFBSyxXQUFVLHVEQUNicEY7QUFBQUEsb0JBQ0N5RyxVQUFVeEIsdUJBQ05HLHlCQUF5QjtBQUFBLGtCQUMvQixLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3QkE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSx1RUFBc0Usc0NBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZHO0FBQUEsa0JBQzdHO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTDtBQUFBLHNCQUNBLE9BQU9xQixTQUFTTztBQUFBQSxzQkFDaEIsVUFBVSxDQUFDNkcsTUFBTW5ILFlBQVksQ0FBQWtDLFVBQVMsRUFBRSxHQUFHQSxNQUFNNUIsNEJBQTRCb0IsT0FBT3lGLEVBQUUzSSxPQUFPbUIsS0FBSyxFQUFFLEVBQUU7QUFBQSxzQkFDdEcsUUFBTztBQUFBLHNCQUNQLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNc0U7QUFBQSxxQkFSeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLHVFQUFzRSxxQ0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEc7QUFBQSxrQkFDNUc7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMO0FBQUEsc0JBQ0EsT0FBT0ksU0FBU1E7QUFBQUEsc0JBQ2hCLFVBQVUsQ0FBQzRHLE1BQU1uSCxZQUFZLENBQUFrQyxVQUFTLEVBQUUsR0FBR0EsTUFBTTNCLDJCQUEyQm1CLE9BQU95RixFQUFFM0ksT0FBT21CLEtBQUssRUFBRSxFQUFFO0FBQUEsc0JBQ3JHLFFBQU87QUFBQSxzQkFDUCxXQUFVO0FBQUE7QUFBQSxvQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTXNFO0FBQUEscUJBUnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxtQkF4SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwSEE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSwyQkFDWCxpQkFBTTtBQUNOLHNCQUFNOEIsY0FBY0M7QUFBQUEsa0JBQ2xCM0IsU0FBU3hCLHNCQUFzQkUsZ0JBQWdCO0FBQUEsZ0JBQ2pEO0FBQ0Esc0JBQU1rRCxzQkFBc0JEO0FBQUFBLGtCQUMxQjNCLFNBQVN4QixzQkFBc0JHLHlCQUMvQjtBQUFBLGdCQUNGO0FBQ0Esc0JBQU1zUSxXQUFXck4sc0JBQXNCRjtBQUd2QyxzQkFBTXdOLGVBQWU7QUFBQSxrQkFDbkJDLFVBQVU7QUFBQSxvQkFDUm5CLE1BQ0UsdUJBQUMsY0FBVyxXQUFVLDhCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLG9CQUVsRG9CLFdBQ0U7QUFBQSxvQkFDRnpQLE9BQU8seUJBQXlCc1AsU0FBU0k7QUFBQUEsc0JBQ3ZDO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLGtCQUNIO0FBQUEsa0JBQ0FDLFVBQVU7QUFBQSxvQkFDUnRCLE1BQ0UsdUJBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0Q7QUFBQSxvQkFFbERvQixXQUNFO0FBQUEsb0JBQ0Z6UCxPQUFPO0FBQUEsa0JBQ1Q7QUFBQSxrQkFDQTRQLFdBQVc7QUFBQSxvQkFDVHZCLE1BQ0UsdUJBQUMsZUFBWSxXQUFVLDBCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QztBQUFBLG9CQUUvQ29CLFdBQ0U7QUFBQSxvQkFDRnpQLE9BQU8sd0JBQXdCcUMsS0FBS0M7QUFBQUEsc0JBQ2xDZ047QUFBQUEsb0JBQ0YsRUFBRUksZUFBZSxPQUFPLENBQUM7QUFBQSxrQkFDM0I7QUFBQSxnQkFDRjtBQUVBLG9CQUFJRyxnQkFBZ0JOLGFBQWFLO0FBQ2pDLG9CQUFJTixXQUFXLEVBQUdPLGlCQUFnQk4sYUFBYUM7QUFBQUEseUJBQ3RDRixhQUFhO0FBQ3BCTyxrQ0FBZ0JOLGFBQWFJO0FBRS9CLHVCQUNFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUkzQkUsY0FBY0osU0FBUztBQUFBO0FBQUEsb0JBRVA7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsb0NBQ1pJLHdCQUFjeEIsUUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSxhQUNid0Isd0JBQWM3UCxTQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQTtBQUFBLGtCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBLGNBRUosR0FBRyxLQWhFTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlFQTtBQUFBLGlCQTNNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRNQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxnQ0FDYixpQ0FBQyxjQUFXLFdBQVUsd0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLGlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFlO0FBQUE7QUFBQSxvQkFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPSyxVQUFVUyxtQkFBbUJDO0FBQUFBLHNCQUNwQyxJQUFHO0FBQUEsc0JBQ0gsVUFBVXlHO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT3VJO0FBQUEscUJBZHpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQ0M7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFhO0FBQUE7QUFBQSwwQkFFZCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9uSCxVQUFVUyxtQkFBbUJFO0FBQUFBLHdCQUNwQyxJQUFHO0FBQUEsd0JBQ0gsVUFBVXdHO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRdUk7QUFBQSx1QkFmekk7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFDQTtBQUFBLHFCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFCQTtBQUFBLGdCQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFVO0FBQUE7QUFBQSxvQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxXQUFVO0FBQUEsc0JBQ1YsVUFBVWlHO0FBQUFBLHNCQUVWO0FBQUEsK0NBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXlCO0FBQUEsd0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2QjtBQUFBLHdCQUM3Qix1QkFBQyxZQUFPLE9BQU0sY0FBYSwwQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBcUM7QUFBQSx3QkFDckMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUE7QUFBQTtBQUFBLG9CQVQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxxQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxpQkFDRTNRLGdCQUFnQixZQUNoQkEsZ0JBQWdCLGlCQUNkLHVCQUFDLFNBQUksV0FBVSxJQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBZ0I7QUFBQTtBQUFBLHdCQUVUO0FBQUEsd0JBQ2YsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBO0FBQUE7QUFBQSxvQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsT0FBT3VELFVBQVVTLG1CQUFtQmxDO0FBQUFBLHNCQUNwQyxVQUFVNEk7QUFBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLFdBQVU7QUFBQTtBQUFBLG9CQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPdUk7QUFBQSxxQkFmekk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxtQkFoRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrRkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNaMUssMEJBQWdCLFlBQ2YsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQWU7QUFBQTtBQUFBLHdCQUVUO0FBQUEsd0JBQ2QsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnQztBQUFBO0FBQUE7QUFBQSxvQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsT0FBT3VELFVBQVVTLG1CQUFtQkk7QUFBQUEsc0JBQ3BDLFVBQVVzRztBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU91STtBQUFBLHFCQWZ6STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLGdCQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFhO0FBQUE7QUFBQSx3QkFFVDtBQUFBLHdCQUNaLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0M7QUFBQTtBQUFBO0FBQUEsb0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILE9BQU9uSCxVQUFVUyxtQkFBbUJLLGFBQWFnTyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsc0JBQzdELFVBQVUzSDtBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU91STtBQUFBLHFCQWZ6STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLGdCQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFrQjtBQUFBO0FBQUEsb0JBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILE9BQU9uSCxVQUFVUyxtQkFBbUJNO0FBQUFBLHNCQUNwQyxVQUFVb0c7QUFBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLFdBQVU7QUFBQTtBQUFBLG9CQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPdUk7QUFBQSxxQkFkekk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQkE7QUFBQSxnQkFFQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBb0I7QUFBQTtBQUFBLG9CQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxPQUFPbkgsVUFBVVMsbUJBQW1CTztBQUFBQSxzQkFDcEMsVUFBVW1HO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT3VJO0FBQUEscUJBZHpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsbUJBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkVBLEtBN0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0ZBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVM7QUFBQTtBQUFBLGtCQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFBUyxNQUFLO0FBQUEsb0JBQVUsSUFBRztBQUFBLG9CQUFVLE9BQU9uSCxVQUFVUyxtQkFBbUJHO0FBQUFBLG9CQUFTLFVBQVV1RztBQUFBQSxvQkFDM0YsYUFBWTtBQUFBLG9CQUNaLE1BQU07QUFBQSxvQkFDTixXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBL0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaU1BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsK0JBQ2IsaUNBQUMsY0FBVyxXQUFVLHdCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHVDQUFzQyxvQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFHQ2xHLDBCQUNDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTNkU7QUFBQUEsb0JBQ1QsU0FBUzNFO0FBQUFBLG9CQUNULE9BQU87QUFBQSxzQkFDTHNPLGlCQUFpQjtBQUFBLHNCQUNqQkMsYUFBYTtBQUFBLG9CQUNmO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUFpQjtBQUFBO0FBQUEsa0JBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFVQTtBQUFBLG1CQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdCQTtBQUFBLGNBSUEsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsMERBQXlELCtDQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLGFBQVk7QUFBQSx3QkFDWixPQUFPMVAsU0FBU0s7QUFBQUEsd0JBQ2hCLFVBQVUsQ0FBQytHLE1BQU1uSCxZQUFZLENBQUFrQyxVQUFTLEVBQUUsR0FBR0EsTUFBTTlCLFlBQVkrRyxFQUFFM0ksT0FBT21CLE1BQU0sRUFBRTtBQUFBLHdCQUM5RSxXQUFVO0FBQUEsd0JBQ1YsUUFBTztBQUFBO0FBQUEsc0JBTlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1ZO0FBQUEsdUJBVmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSwwREFBeUQsOENBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsYUFBWTtBQUFBLHdCQUNaLE9BQU9JLFNBQVNNO0FBQUFBLHdCQUNoQixVQUFVLENBQUM4RyxNQUFNbkgsWUFBWSxDQUFBa0MsVUFBUyxFQUFFLEdBQUdBLE1BQU03QixXQUFXOEcsRUFBRTNJLE9BQU9tQixNQUFNLEVBQUU7QUFBQSx3QkFDN0UsV0FBVTtBQUFBLHdCQUNWLFFBQU87QUFBQTtBQUFBLHNCQU5UO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNWTtBQUFBLHVCQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxxQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0QkE7QUFBQSxnQkFFQSx1QkFBQyxPQUFFLFdBQVUscUNBQW9DLHlGQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwSDtBQUFBLG1CQW5DNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQ0E7QUFBQSxjQUVDL0MsMEJBQ0MsdUJBQUMsU0FBSSxXQUFVLHdDQUViLGlDQUFDLFNBQUksV0FBVSxxRkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRyxLQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBLElBRUFGLHlCQUF5QjRPLHFCQUFxQjlELFNBQVMsS0FDckQsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFFBQUcsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLGtCQUMxQjlLLHlCQUF5QjZJO0FBQUFBLGtCQUFhO0FBQUEsa0JBQUU3SSx5QkFBeUI0STtBQUFBQSxxQkFEdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFDQzVJLHlCQUF5QmdULHNCQUN4Qix1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsNENBQTJDLGtDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHlCQUF3QiwwQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUQ7QUFBQSxzQkFDakQsdUJBQUMsU0FBSSxXQUFVLG1DQUNaaFQsbUNBQXlCZ1Qsb0JBQW9CaEYsY0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUseUJBQXdCLDRCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtRDtBQUFBLHNCQUNuRCx1QkFBQyxTQUFJLFdBQVUsb0NBQ1poTyxtQ0FBeUJnVCxvQkFBb0IvRSxnQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUseUJBQXdCLDBCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRDtBQUFBLHNCQUNqRCx1QkFBQyxTQUFJLFdBQVUsa0NBQ1pqTyxtQ0FBeUJnVCxvQkFBb0J6RSxjQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSx5QkFBd0IseUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdEO0FBQUEsc0JBQ2hELHVCQUFDLFNBQUksV0FBVSxxQ0FDWnZPLG1DQUF5QmdULG9CQUFvQnhFLGFBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHlCQUF3Qix5QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0Q7QUFBQSxzQkFDaEQsdUJBQUMsU0FBSSxXQUFVLG1DQUNaeE8sbUNBQXlCZ1Qsb0JBQW9COUUsYUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSx1QkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkErQkE7QUFBQSxxQkFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQ0E7QUFBQSxnQkFNRix1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLHNEQUNmO0FBQUEseUNBQUMsV0FBTSxXQUFVLGNBQ2YsaUNBQUMsUUFDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSx3REFBdUQsb0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsd0RBQXVELDhCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHdEQUF1RCw4QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEsa0JBQ0EsdUJBQUMsV0FDRWxPLG1DQUF5QjRPLHFCQUFxQjFJO0FBQUFBLG9CQUFJLENBQUMrTSxNQUFNakwsVUFDeEQ7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBRUMsV0FBV0EsUUFBUSxNQUFNLElBQUksYUFBYTtBQUFBLHdCQUUxQztBQUFBLGlEQUFDLFFBQUcsV0FBVSwrQ0FDWGlMLGVBQUt4TixRQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSw0QkFDNUN3TixLQUFLQyxlQUFlUixlQUFlLE9BQU87QUFBQSwrQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSxrREFBaUQ7QUFBQTtBQUFBLDRCQUMzRE8sS0FBS0UsY0FBY1QsZUFBZSxPQUFPO0FBQUEsK0JBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQTtBQUFBO0FBQUEsc0JBWEsxSztBQUFBQSxzQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWFBO0FBQUEsa0JBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxrQkFDQSx1QkFBQyxXQUFNLFdBQVUsdUNBQ2YsaUNBQUMsUUFDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSxhQUFZLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBLG9CQUMvQix1QkFBQyxRQUFHLFdBQVUsYUFBWTtBQUFBO0FBQUEsc0JBQ3RCaEkseUJBQXlCb1Qsa0NBQWtDVixlQUFlLE9BQU87QUFBQSx5QkFEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSw0QkFBMkI7QUFBQTtBQUFBLHNCQUNyQzFTLHlCQUF5QnFULHNCQUFzQlgsZUFBZSxPQUFPO0FBQUEseUJBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFVQTtBQUFBLHFCQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJDQSxLQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTZDQTtBQUFBLG1CQTlGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStGQSxLQWhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlHQTtBQUFBLGlCQTNLTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNoRztBQUFBQSxnQkFDVCxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFNBQVMzTztBQUFBQSxnQkFDVCxVQUNFLENBQUNzRixTQUFTL0MsZUFBZSxDQUFDK0MsU0FBUzlDLFNBQVMsQ0FBQzhDLFNBQVM3QztBQUFBQSxnQkFFeEQsT0FBTztBQUFBLGtCQUNMc1MsaUJBQWlCO0FBQUEsZ0JBQ25CO0FBQUEsZ0JBQUc7QUFBQTtBQUFBLGNBWEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFFQ25VLG9CQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSw0Q0FBMkMsa0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUM4TCxNQUFNQSxFQUFFM0ksT0FBT3VRLEtBQUs7QUFBQSxzQkFDOUIsV0FBVTtBQUFBLHNCQUNWLE9BQU8xVCxpQkFBaUJxUDtBQUFBQSxzQkFDeEIsVUFBUTtBQUFBO0FBQUEsb0JBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtVO0FBQUEsa0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNicFI7QUFBQUEsb0JBQ0MrQixpQkFBaUJxUCxjQUFjO0FBQUEsa0JBQ2pDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLHFCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsQ0FBQ3ZELE1BQU1BLEVBQUUzSSxPQUFPdVEsS0FBSztBQUFBLHNCQUM5QixXQUFVO0FBQUEsc0JBQ1YsT0FBTzFULGlCQUFpQnNQO0FBQUFBLHNCQUN4QixVQUFRO0FBQUE7QUFBQSxvQkFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS1U7QUFBQSxrQkFFVix1QkFBQyxVQUFLLFdBQVUsNENBQ2JyUjtBQUFBQSxvQkFDQytCLGlCQUFpQnNQLGdCQUFnQjtBQUFBLGtCQUNuQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdCQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyx5QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUN4RCxNQUFNQSxFQUFFM0ksT0FBT3VRLEtBQUs7QUFBQSxzQkFDOUIsV0FBVTtBQUFBLHNCQUNWLE9BQU8xVCxpQkFBaUJ1UDtBQUFBQSxzQkFDeEIsVUFBUTtBQUFBO0FBQUEsb0JBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtVO0FBQUEsa0JBRVYsdUJBQUMsVUFBSyxXQUFVLDRDQUNidFIsOEJBQW9CK0IsaUJBQWlCdVAsYUFBYSxDQUFDLEtBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsQ0FBQ3pELE1BQU1BLEVBQUUzSSxPQUFPdVEsS0FBSztBQUFBLHNCQUM5QixXQUFVO0FBQUEsc0JBQ1YsT0FBTzFULGlCQUFpQndQO0FBQUFBLHNCQUN4QixVQUFRO0FBQUE7QUFBQSxvQkFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS1U7QUFBQSxrQkFFVix1QkFBQyxVQUFLLFdBQVUsNENBQ2J2Uiw4QkFBb0IrQixpQkFBaUJ3UCxZQUFZLENBQUMsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBY0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsbUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxDQUFDMUQsTUFBTUEsRUFBRTNJLE9BQU91USxLQUFLO0FBQUEsc0JBQzlCLFdBQVU7QUFBQSxzQkFDVixRQUFRMVQsaUJBQWlCeVAsT0FBTyxHQUFHZ0UsUUFBUSxDQUFDO0FBQUEsc0JBQzVDLFVBQVE7QUFBQTtBQUFBLG9CQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLVTtBQUFBLGtCQUVWLHVCQUFDLFVBQUssV0FBVSw0Q0FDYnhWLDhCQUFvQitCLGlCQUFpQndQLFlBQVksQ0FBQyxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUMxRCxNQUFNQSxFQUFFM0ksT0FBT3VRLEtBQUs7QUFBQSxzQkFDOUIsV0FBVTtBQUFBLHNCQUNWLE9BQU8xVCxpQkFBaUIwUCxlQUFlK0QsUUFBUSxDQUFDO0FBQUEsc0JBQ2hELFVBQVE7QUFBQTtBQUFBLG9CQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLVTtBQUFBLGtCQUVWLHVCQUFDLFVBQUssV0FBVSw0Q0FDYnhWO0FBQUFBLG9CQUNDK0IsaUJBQWlCMFAsZUFBZStELFFBQVEsQ0FBQyxLQUFLO0FBQUEsa0JBQ2hELEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLHFCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsQ0FBQzNILE1BQU1BLEVBQUUzSSxPQUFPdVEsS0FBSztBQUFBLHNCQUM5QixXQUFVO0FBQUEsc0JBQ1YsT0FBTzFULGlCQUFpQnFPLGtCQUFrQm9GLFFBQVEsQ0FBQztBQUFBLHNCQUNuRCxVQUFRO0FBQUE7QUFBQSxvQkFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS1U7QUFBQSxrQkFFVix1QkFBQyxVQUFLLFdBQVUsNENBQ2J4VjtBQUFBQSxvQkFDQytCLGlCQUFpQnFPLGtCQUFrQm9GLFFBQVEsQ0FBQyxLQUFLO0FBQUEsa0JBQ25ELEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLHFCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsbUJBbEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUhBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsbUdBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsOERBQ2IsaUNBQUMsYUFBVSxXQUFVLHdCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHVDQUFzQywwQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDWmxCLGdDQUFzQixLQUNyQixtQ0FDRTtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTdE07QUFBQUEsd0JBQ1QsV0FBVTtBQUFBLHdCQUFnQztBQUFBO0FBQUEsc0JBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTQztBQUFBQSx3QkFDVCxXQUFVO0FBQUEsd0JBQW9DO0FBQUE7QUFBQSxzQkFIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsdUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQSxLQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkJBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUViO0FBQUEseUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkNBQUMsVUFBTyxXQUFVLDJCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxXQUFNLFdBQVUsdUNBQXNDLG9DQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTLENBQUM0RixNQUFNQSxFQUFFM0ksT0FBT3VRLEtBQUs7QUFBQSx3QkFDOUIsT0FBT2hQLFVBQVV4Qix1QkFBdUJDLFVBQVU7QUFBQSx3QkFDbEQ7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSytNO0FBQUEsb0JBRS9NLHVCQUFDLFVBQUssV0FBVSxvREFDYmxGO0FBQUFBLHNCQUNDeUcsVUFBVXhCLHVCQUF1QkMsVUFBVTtBQUFBLG9CQUM3QyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxrQkFrREEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkNBQUMsZUFBWSxXQUFVLDhCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRDtBQUFBLHNCQUNqRCx1QkFBQyxXQUFNLFdBQVUsMkNBQTBDLHFEQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0M0QyxxQkFBcUIsdUJBQUMsUUFBSyxNQUFLLFNBQVEsV0FBVSxVQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtQztBQUFBLHlCQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE9BQU9BLG9CQUFvQixnQkFDekJyQixVQUFVeEIsdUJBQ05HLHlCQUF5QjtBQUFBLHdCQUUvQjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPOEg7QUFBQSxvQkFHOUgsdUJBQUMsVUFBSyxXQUFVLHVEQUNicEY7QUFBQUEsc0JBQ0N5RyxVQUFVeEIsdUJBQ05HLHlCQUF5QjtBQUFBLG9CQUMvQixLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSx1QkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF3QkE7QUFBQSxxQkEvRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnR0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1gsaUJBQU07QUFDTix3QkFBTStDLGNBQWNDO0FBQUFBLG9CQUNsQjNCLFNBQVN4QixzQkFBc0JFLGdCQUFnQjtBQUFBLGtCQUNqRDtBQUNBLHdCQUFNa0Qsc0JBQXNCRDtBQUFBQSxvQkFDMUIzQixTQUFTeEIsc0JBQ05HLHlCQUF5QjtBQUFBLGtCQUM5QjtBQUNBLHdCQUFNc1EsV0FBV3JOLHNCQUFzQkY7QUFHdkMsd0JBQU13TixlQUFlO0FBQUEsb0JBQ25CQyxVQUFVO0FBQUEsc0JBQ1JuQixNQUNFLHVCQUFDLGNBQVcsV0FBVSw4QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0Q7QUFBQSxzQkFFbERvQixXQUNFO0FBQUEsc0JBQ0Z6UCxPQUFPLHVCQUF1QnNQLFNBQVNJO0FBQUFBLHdCQUNyQztBQUFBLHNCQUNGLENBQUM7QUFBQSxvQkFDSDtBQUFBLG9CQUNBQyxVQUFVO0FBQUEsc0JBQ1J0QixNQUNFLHVCQUFDLGdCQUFhLFdBQVUsNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdEO0FBQUEsc0JBRWxEb0IsV0FDRTtBQUFBLHNCQUNGelAsT0FBTztBQUFBLG9CQUNUO0FBQUEsb0JBQ0E0UCxXQUFXO0FBQUEsc0JBQ1R2QixNQUNFLHVCQUFDLGVBQVksV0FBVSwwQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkM7QUFBQSxzQkFFL0NvQixXQUNFO0FBQUEsc0JBQ0Z6UCxPQUFPLHNCQUFzQnFDLEtBQUtDO0FBQUFBLHdCQUNoQ2dOO0FBQUFBLHNCQUNGLEVBQUVJLGVBQWUsT0FBTyxDQUFDO0FBQUEsb0JBQzNCO0FBQUEsa0JBQ0Y7QUFFQSxzQkFBSUcsZ0JBQWdCTixhQUFhSztBQUNqQyxzQkFBSU4sV0FBVztBQUNiTyxvQ0FBZ0JOLGFBQWFDO0FBQUFBLDJCQUN0QkYsYUFBYTtBQUNwQk8sb0NBQWdCTixhQUFhSTtBQUUvQix5QkFDRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJL0JFLGNBQWNKLFNBQVM7QUFBQTtBQUFBLHNCQUVIO0FBQUEsK0NBQUMsU0FBSSxXQUFVLG9DQUNaSSx3QkFBY3hCLFFBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFDQSx1QkFBQyxVQUFLLFdBQVUsYUFDYndCLHdCQUFjN1AsU0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBO0FBQUE7QUFBQSxvQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBYUE7QUFBQSxnQkFFSixHQUFHLEtBakVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0VBO0FBQUEsbUJBbk1GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb01BO0FBQUEsaUJBNVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNlRBO0FBQUEsWUFJRG5FLGtCQUNDLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx5Q0FBd0MsbUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFhO0FBQUEsb0JBQ25CLFNBQVNnTjtBQUFBQSxvQkFBc0I7QUFBQTtBQUFBLGtCQUhqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQ3hJLFNBQVM5QixvQkFBb0IyRTtBQUFBQSxnQkFBSSxDQUFDcUgsU0FBU3ZGLFVBQzFDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLFdBQVU7QUFBQSxvQkFDVjtBQUFBLDZDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0NBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLGFBQVk7QUFBQSw0QkFDWixPQUFPdUYsUUFBUTlIO0FBQUFBLDRCQUNmLFVBQVUsQ0FBQ2dGLE1BQ1RtQjtBQUFBQSw4QkFDRTVEO0FBQUFBLDhCQUNBO0FBQUEsOEJBQ0F5QyxFQUFFM0ksT0FBT21CO0FBQUFBLDRCQUNYO0FBQUE7QUFBQSwwQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBU0c7QUFBQSwyQkFiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsK0NBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpREFBQyxXQUFNLFdBQVUsZ0RBQStDLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0E7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMLGFBQVk7QUFBQSw4QkFDWixPQUFPc0ssUUFBUXRLO0FBQUFBLDhCQUNmLFVBQVUsQ0FBQ3dILE1BQ1RtQjtBQUFBQSxnQ0FDRTVEO0FBQUFBLGdDQUNBO0FBQUEsZ0NBQ0F5QyxFQUFFM0ksT0FBT21CO0FBQUFBLDhCQUNYO0FBQUE7QUFBQSw0QkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBVUc7QUFBQSwwQkFFSCx1QkFBQyxVQUFLLFdBQVUsNENBQ2JyRyw4QkFBb0IyUSxRQUFRdEssU0FBUyxDQUFDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFtQkE7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0w7QUFBQSw0QkFDQSxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWU7QUFBQSw0QkFDckIsU0FBUyxNQUFNNkksd0JBQXdCOUQsS0FBSztBQUFBO0FBQUEsMEJBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFJZ0Q7QUFBQSwyQkF6QmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBMkJBO0FBQUE7QUFBQTtBQUFBLGtCQTdDS0E7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkErQ0E7QUFBQSxjQUNEO0FBQUEsaUJBN0RIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOERBO0FBQUEsWUFFRG5KLGtCQUNDLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx5Q0FBd0MscUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0w7QUFBQSxvQkFDQSxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWE7QUFBQSxvQkFDbkIsU0FBU21OO0FBQUFBLG9CQUF3QjtBQUFBO0FBQUEsa0JBSm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUNDM0ksU0FBUzdCLHNCQUFzQjBFO0FBQUFBLGdCQUFJLENBQUN1SCxXQUFXekYsVUFDOUM7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUMsV0FBVTtBQUFBLG9CQUNWO0FBQUEsNkNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsYUFBWTtBQUFBLDRCQUNaLE9BQU95RixVQUFVaEk7QUFBQUEsNEJBQ2pCLFVBQVUsQ0FBQ2dGLE1BQ1RzQjtBQUFBQSw4QkFDRS9EO0FBQUFBLDhCQUNBO0FBQUEsOEJBQ0F5QyxFQUFFM0ksT0FBT21CO0FBQUFBLDRCQUNYO0FBQUE7QUFBQSwwQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBU0c7QUFBQSwyQkFiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsK0NBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpREFBQyxXQUFNLFdBQVUsZ0RBQStDLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0E7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMLGFBQVk7QUFBQSw4QkFDWixTQUFTLENBQUN3SCxNQUFNQSxFQUFFM0ksT0FBT3VRLEtBQUs7QUFBQSw4QkFDOUIsT0FBTzVFLFVBQVV4SztBQUFBQSw4QkFDakIsVUFBVSxDQUFDd0gsTUFDVHNCO0FBQUFBLGdDQUNFL0Q7QUFBQUEsZ0NBQ0E7QUFBQSxnQ0FDQXlDLEVBQUUzSSxPQUFPbUI7QUFBQUEsOEJBQ1g7QUFBQTtBQUFBLDRCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFXRztBQUFBLDBCQUVILHVCQUFDLFVBQUssV0FBVSw2Q0FDYnJHO0FBQUFBLDRCQUNDb0ksT0FBT3lJLFVBQVV4SyxTQUFTLENBQUMsRUFBRW1QLFFBQVEsQ0FBQztBQUFBLDBCQUN4QyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBSUE7QUFBQSw2QkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFzQkE7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0w7QUFBQSw0QkFDQSxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWU7QUFBQSw0QkFDckIsU0FBUyxNQUFNbkcsMEJBQTBCakUsS0FBSztBQUFBO0FBQUEsMEJBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFJa0Q7QUFBQSwyQkE1QnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBOEJBO0FBQUE7QUFBQTtBQUFBLGtCQWhES0E7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFrREE7QUFBQSxjQUNEO0FBQUEsaUJBakVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0VBO0FBQUEsWUFFRHJKLG9CQUFvQkUsa0JBQ25CLHVCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSxvRUFDWjtBQUFBLHVDQUFDLDRCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVCO0FBQUEsZ0JBQUc7QUFBQSxtQkFENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUdiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsdUVBQXNFLGdDQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RztBQUFBLGtCQUN2RztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFPd0UsU0FBUzNCO0FBQUFBLHNCQUNoQjtBQUFBLHNCQUNBLFFBQU87QUFBQSxzQkFDUCxXQUFVO0FBQUE7QUFBQSxvQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSWdEO0FBQUEscUJBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSx1RUFBc0Usc0NBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZHO0FBQUEsa0JBQzdHO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTDtBQUFBLHNCQUNBLE9BQU8yQixTQUFTTztBQUFBQSxzQkFDaEIsVUFBVSxDQUFDNkcsTUFBTW5ILFlBQVksQ0FBQWtDLFVBQVMsRUFBRSxHQUFHQSxNQUFNNUIsNEJBQTRCb0IsT0FBT3lGLEVBQUUzSSxPQUFPbUIsS0FBSyxFQUFFLEVBQUU7QUFBQSxzQkFDdEcsUUFBTztBQUFBLHNCQUNQLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNc0U7QUFBQSxxQkFSeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLHVFQUFzRSxxQ0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEc7QUFBQSxrQkFDNUc7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMO0FBQUEsc0JBQ0EsT0FBT0ksU0FBU1E7QUFBQUEsc0JBQ2hCLFVBQVUsQ0FBQzRHLE1BQU1uSCxZQUFZLENBQUFrQyxVQUFTLEVBQUUsR0FBR0EsTUFBTTNCLDJCQUEyQm1CLE9BQU95RixFQUFFM0ksT0FBT21CLEtBQUssRUFBRSxFQUFFO0FBQUEsc0JBQ3JHLFFBQU87QUFBQSxzQkFDUCxXQUFVO0FBQUE7QUFBQSxvQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTXNFO0FBQUEscUJBUnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSx1RUFBc0UsaUNBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdHO0FBQUEsbUJBQ3RHLE1BQU07QUFDTiwwQkFBTXFRLFVBQVV0TyxPQUFPM0IsU0FBU0Usd0JBQXdCLENBQUM7QUFPekQsMEJBQU1nUSwwQkFBMEJsUSxTQUFTOUIsb0JBQW9COEs7QUFBQUEsc0JBQzNELENBQUNtSCxLQUFLakcsWUFBWWlHLE1BQU14TyxPQUFPdUksUUFBUXRLLFNBQVMsQ0FBQztBQUFBLHNCQUNqRDtBQUFBLG9CQUNGO0FBQ0EsMEJBQU13USw0QkFBNEJwUSxTQUFTN0Isc0JBQXNCNks7QUFBQUEsc0JBQy9ELENBQUNtSCxLQUFLL0YsY0FBYytGLE1BQU14TyxPQUFPeUksVUFBVXhLLFNBQVMsQ0FBQztBQUFBLHNCQUNyRDtBQUFBLG9CQUNGO0FBSUEsMEJBQU15USxRQUFRSixVQUFVQywwQkFBMEJFO0FBQ2xELDJCQUNFLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE9BQU9DLE1BQU10QixRQUFRLENBQUM7QUFBQSwwQkFDdEI7QUFBQSwwQkFDQSxRQUFPO0FBQUEsMEJBQ1AsV0FBVTtBQUFBO0FBQUEsd0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUk2RTtBQUFBLHNCQUU3RSx1QkFBQyxVQUFLLFdBQVUsc0RBQ2J4Viw4QkFBb0I4VyxNQUFNdEIsUUFBUSxDQUFDLENBQUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVUE7QUFBQSxrQkFFSixHQUFHO0FBQUEscUJBbkNMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0NBO0FBQUEsbUJBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkVBO0FBQUEsaUJBakZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0ZBO0FBQUEsZUFyN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdTdDQSxJQUdGLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RjtBQUFBLFlBQ3hGLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsMkNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUE1OUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4OUNBO0FBQUE7QUFBQSxNQXYvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBdy9DQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE1BQU1qUTtBQUFBQSxRQUNOLFVBQVUsTUFBTUMsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QyxRQUFRO0FBQUEsVUFDTix1QkFBQyxVQUFvQixTQUFTLE1BQU1BLHdCQUF3QixLQUFLLEdBQUcsc0JBQXhELFVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBcUIsTUFBSyxXQUFVLFNBQVMwQyxvQkFBb0IsdUJBQXRELFdBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFFBQVM7QUFBQSxRQUVYO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDRCQUEyQiw0RUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLDZCQUE0QixpQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxjQUM3RCx1QkFBQyxVQUFLLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxnQkFDOUNFLE9BQU9rTSxtQkFBbUIsRUFBRXdCLGVBQWUsT0FBTztBQUFBLG1CQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLFVBQUssV0FBVSw2QkFBNEIsK0RBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUE7QUFBQTtBQUFBLE1BM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRCQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE1BQU1yUTtBQUFBQSxRQUNOLFVBQVUsTUFBTUMsMkJBQTJCLEtBQUs7QUFBQSxRQUNoRCxRQUFRO0FBQUEsVUFDTjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNQSwyQkFBMkIsS0FBSztBQUFBLGNBQUc7QUFBQTtBQUFBLFlBRDlDO0FBQUEsWUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSUE7QUFBQSxVQUNBLHVCQUFDLFVBQXFCLE1BQUssV0FBVSxTQUFTcUQsdUJBQXVCLHVCQUF6RCxXQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUFTO0FBQUEsUUFFWDtBQUFBLGlDQUFDLE9BQUUsV0FBVSw0QkFBMkIsdUZBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSw2QkFBNEIsaUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsY0FDN0QsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQztBQUFBO0FBQUEsZ0JBQ2hEWCxPQUFPa00sbUJBQW1CLEVBQUV3QixlQUFlLE9BQU87QUFBQSxtQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYixpQ0FBQyxVQUFLLFdBQVUsNkJBQTRCLGtFQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBO0FBQUE7QUFBQSxNQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUErQkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixPQUFNO0FBQUEsUUFDTixXQUFVO0FBQUEsUUFDVixNQUFNalY7QUFBQUEsUUFDTixTQUFTLE1BQU1DLHFCQUFxQixLQUFLO0FBQUEsUUFDekMsVUFBVTtBQUFBLFFBQ1YsUUFDRSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUEscUJBQXFCLEtBQUs7QUFBQSxZQUN6QyxXQUFVO0FBQUEsWUFBMkk7QUFBQTtBQUFBLFVBRnZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFJRixpQ0FBQyxTQUFJLFdBQVUsYUFHYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxpRkFBZ0Ysd0JBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FDRU8sVUFBVXVLLEtBQUssQ0FBQ2lDLE1BQU1BLEVBQUV4SCxVQUFVN0MsZUFBZUUsV0FBVyxHQUN4RDBDLFNBQVM7QUFBQSxnQkFFZjtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTTRLO0FBQUEsZUFWOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGlGQUFnRixxQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTzVDLGVBQWVHLFNBQVM7QUFBQSxrQkFDL0I7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHNEs7QUFBQSxpQkFQOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGlGQUFnRixvQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FDRXRFLE1BQU0wWCxRQUFRdlQsZUFBZUksSUFBSSxJQUM3QkosZUFBZUksS0FBS2dDLE9BQU8sTUFBTSxJQUNqQ3BDLGVBQWVJLFFBQVE7QUFBQSxrQkFFN0I7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPNEs7QUFBQSxpQkFYOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsNEdBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdUdBQ1o7QUFBQSxxQ0FBQyxVQUFLLGtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVE7QUFBQSxjQUFPO0FBQUEsaUJBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWjJMLGlCQUFPeUgsUUFBUXhULGVBQWVLLFlBQVksQ0FBQyxDQUFDLEVBQUV5RjtBQUFBQSxjQUFJLENBQUMsQ0FBQ3RELEtBQUtLLEtBQUssTUFDN0QsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxpRkFDZEwsY0FDRStILFFBQVEsTUFBTSxHQUFHLEVBQ2pCQSxRQUFRLFNBQVMsQ0FBQ2tKLE1BQU1BLEVBQUVDLFlBQVksQ0FBQyxLQUg1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTzlPLE9BQU8vQixTQUFTLENBQUMsRUFBRXlQLGVBQWUsU0FBUztBQUFBLHNCQUNoRHFCLHVCQUF1QjtBQUFBLHNCQUN2QkMsdUJBQXVCO0FBQUEsb0JBQ3pCLENBQUM7QUFBQSxvQkFDRDtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNZ0w7QUFBQSxtQkFaeEtwUixLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxZQUNELEtBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsZUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxpR0FDWjtBQUFBLHFDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUTtBQUFBLGNBQU87QUFBQSxpQkFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNadUosaUJBQU95SCxRQUFReFQsZUFBZWMsY0FBYyxDQUFDLENBQUMsRUFBRWdGO0FBQUFBLGNBQUksQ0FBQyxDQUFDdEQsS0FBS0ssS0FBSyxNQUMvRCx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGlGQUNkTCxjQUNFK0gsUUFBUSxNQUFNLEdBQUcsRUFDakJBLFFBQVEsU0FBUyxDQUFDa0osTUFBTUEsRUFBRUMsWUFBWSxDQUFDLEtBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPOU8sT0FBTy9CLFNBQVMsQ0FBQyxFQUFFeVAsZUFBZSxTQUFTO0FBQUEsc0JBQ2hEcUIsdUJBQXVCO0FBQUEsc0JBQ3ZCQyx1QkFBdUI7QUFBQSxvQkFDekIsQ0FBQztBQUFBLG9CQUNEO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU0wSztBQUFBLG1CQVpsS3BSLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLFlBQ0QsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxpRkFBZ0YsZ0NBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU80SixzQkFBc0JrRyxlQUFlLFNBQVM7QUFBQSxvQkFDbkRxQix1QkFBdUI7QUFBQSxvQkFDdkJDLHVCQUF1QjtBQUFBLGtCQUN6QixDQUFDO0FBQUEsa0JBQ0Q7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNNEs7QUFBQSxpQkFWOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0NBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsb0dBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsK0ZBQ1o7QUFBQSxxQ0FBQyxVQUFLLGtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVE7QUFBQSxjQUFPO0FBQUEsaUJBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsaUZBQWdGLHNCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBT2hQO0FBQUFBLHNCQUNMNUUsZUFBZXlCLHVCQUF1QkMsVUFBVTtBQUFBLG9CQUNsRCxFQUFFNFEsZUFBZSxTQUFTLEVBQUVxQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsb0JBQ3REO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUt3SztBQUFBLG1CQVQxSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGlGQUFnRixxQ0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU8vTztBQUFBQSxzQkFDTDVFLGVBQWV5Qix1QkFBdUJHLHlCQUF5QjtBQUFBLG9CQUNqRSxFQUFFMFEsZUFBZSxTQUFTLEVBQUVxQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsb0JBQ3REO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUt3SztBQUFBLG1CQVQxSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsZUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxvR0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwrRkFDWjtBQUFBLHFDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUTtBQUFBLGNBQU87QUFBQSxpQkFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPL087QUFBQUEsa0JBQ0w1RSxlQUFlc0Isd0JBQXdCO0FBQUEsZ0JBQ3pDLEVBQUVnUixlQUFlLFNBQVMsRUFBRXFCLHVCQUF1QixFQUFFLENBQUM7QUFBQSxnQkFDdEQ7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUs2SztBQUFBLGVBVC9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUdDM1QsZUFBZXFCLGtCQUFrQnFKLFNBQVMsS0FDekMsdUJBQUMsU0FBSSxXQUFVLDBHQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHFHQUNaO0FBQUEscUNBQUMsVUFBSyxrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFRO0FBQUEsY0FBTztBQUFBLGlCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQzFLLGVBQWVxQixpQkFBaUJ5RTtBQUFBQSxjQUFJLENBQUMrTixLQUFLdEksTUFDekMsdUJBQUMsU0FBWSxXQUFVLGtEQUNyQjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU9zSSxJQUFJeE8sUUFBUTtBQUFBLG9CQUNuQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHNks7QUFBQSxnQkFFN0s7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTyxJQUFJVCxPQUFPaVAsSUFBSWhSLEtBQUssRUFBRXlQLGVBQWUsT0FBTyxDQUFDO0FBQUEsb0JBQ3BEO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdrTTtBQUFBLG1CQVQxTC9HLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLFlBQ0Q7QUFBQSxlQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBSUR2TCxlQUFlbUIscUJBQXFCdUosU0FBUyxLQUM1Qyx1QkFBQyxTQUFJLFdBQVUsMEdBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUscUdBQ1o7QUFBQSxxQ0FBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU87QUFBQSxjQUFPO0FBQUEsaUJBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDMUssZUFBZW1CLG9CQUFvQjJFO0FBQUFBLGNBQUksQ0FBQytOLEtBQUt0SSxNQUM1Qyx1QkFBQyxTQUFZLFdBQVUsa0RBQ3JCO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBT3NJLElBQUl4TyxRQUFRO0FBQUEsb0JBQ25CO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUc2SztBQUFBLGdCQUU3SztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPLElBQUlULE9BQU9pUCxJQUFJaFIsS0FBSyxFQUFFeVAsZUFBZSxPQUFPLENBQUM7QUFBQSxvQkFDcEQ7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR2tNO0FBQUEsbUJBVDFML0csR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsWUFDRDtBQUFBLGVBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsVUFJRHZMLGVBQWVvQix1QkFBdUJzSixTQUFTLEtBQzlDLHVCQUFDLFNBQUksV0FBVSwwR0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxxR0FDWjtBQUFBLHFDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUTtBQUFBLGNBQU87QUFBQSxpQkFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0MxSyxlQUFlb0Isc0JBQXNCMEU7QUFBQUEsY0FBSSxDQUFDZ08sS0FBS3ZJLE1BQzlDLHVCQUFDLFNBQVksV0FBVSxrREFDckI7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPdUksSUFBSXpPLFFBQVE7QUFBQSxvQkFDbkI7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzZLO0FBQUEsZ0JBRTdLO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU8sSUFBSVQsT0FBT2tQLElBQUlqUixLQUFLLEVBQUV5UCxlQUFlLE9BQU8sQ0FBQztBQUFBLG9CQUNwRDtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHa007QUFBQSxtQkFUMUwvRyxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxZQUNEO0FBQUEsZUFqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUlGLHVCQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxtR0FDWjtBQUFBLHFDQUFDLFVBQUssbUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUztBQUFBLGNBQU87QUFBQSxpQkFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPM0c7QUFBQUEsa0JBQ0w1RSxlQUFlbUQsd0JBQXdCO0FBQUEsZ0JBQ3pDLEVBQUVtUCxlQUFlLFNBQVMsRUFBRXFCLHVCQUF1QixFQUFFLENBQUM7QUFBQSxnQkFDdEQ7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUsrTDtBQUFBLGVBVGpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxpR0FDWjtBQUFBLHFDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUTtBQUFBLGNBQU87QUFBQSxpQkFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxpRkFBZ0YsMkJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPL08sT0FBTzVFLGVBQWVvRCxlQUFlLENBQUMsRUFBRWtQO0FBQUFBLHNCQUM3QztBQUFBLHNCQUNBLEVBQUVxQix1QkFBdUIsRUFBRTtBQUFBLG9CQUM3QjtBQUFBLG9CQUNBO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU00SztBQUFBLG1CQVY5SztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGlGQUFnRiw4QkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU8zVCxnQkFBZ0J1QixrQkFBa0I7QUFBQSxvQkFDekM7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzRLO0FBQUEsbUJBUDlLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNDdkIsZUFBZXdCLGtCQUNkLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsaUZBQWdGLDhCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBT3hCLGVBQWV3QjtBQUFBQSxvQkFDdEI7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR21MO0FBQUEsbUJBUHJMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUVGLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsaUZBQWdGLHNCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBT3hCLGVBQWU4QjtBQUFBQSxvQkFDdEI7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzRLO0FBQUEsbUJBUDlLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4Q0E7QUFBQSxlQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1EQTtBQUFBLGFBcFNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxU0E7QUFBQTtBQUFBLE1BeFRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXlUQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE1BQU1uRDtBQUFBQSxRQUNOLFVBQVUsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUN4QyxRQUFRO0FBQUEsVUFDTix1QkFBQyxVQUFvQixTQUFTLE1BQU1BLG1CQUFtQixLQUFLLEdBQUcsc0JBQW5ELFVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxTQUFTbkI7QUFBQUEsY0FDVCxTQUFTLE1BQU1tTCxvQkFBb0IvSixRQUFRO0FBQUEsY0FBRztBQUFBO0FBQUEsWUFKMUM7QUFBQSxZQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFFBQVM7QUFBQSxRQUVYLGlDQUFDLE9BQUUsMkZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUE7QUFBQSxNQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFxQkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYixpQ0FBQyxVQUFLLFdBQVUsMERBQXlELHdDQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUVGLE1BQU1PO0FBQUFBLFFBQ04sVUFBVSxNQUFNQyx3QkFBd0IsS0FBSztBQUFBLFFBQzdDLE9BQU87QUFBQSxRQUNQLFFBQVE7QUFBQSxVQUNOLHVCQUFDLFVBQW1CLFNBQVMsTUFBTUEsd0JBQXdCLEtBQUssR0FBRyxxQkFBdkQsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQUMsc0JBQXNCd0MsV0FBVyxhQUMvQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsT0FBTztBQUFBLGdCQUNMNFEsaUJBQWlCO0FBQUEsZ0JBQ2pCQyxhQUFhO0FBQUEsZ0JBQ2JvQixPQUFPO0FBQUEsY0FDVDtBQUFBLGNBQ0EsU0FBUyxNQUFNO0FBQ2IxTCwyQkFBVy9JLHFCQUFxQjBHLEdBQUc7QUFDbkMzRyx3Q0FBd0IsS0FBSztBQUFBLGNBQy9CO0FBQUEsY0FBRztBQUFBO0FBQUEsWUFWQztBQUFBLFlBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsUUFDRDtBQUFBLFFBRUgsT0FBTztBQUFBLFVBQ0wyVSxTQUFTO0FBQUEsVUFDVEMsV0FBVztBQUFBLFVBQ1hDLFdBQVc7QUFBQSxVQUNYeEIsaUJBQWlCO0FBQUEsUUFDbkI7QUFBQSxRQUNDcFQsaUNBQ0MsdUJBQUMsU0FBSSxXQUFVLGFBRWI7QUFBQSxpQ0FBQyxhQUFRLFdBQVUsK0hBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDJEQUNaO0FBQUEscUNBQUMsVUFBSyxXQUFVLDJDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQU87QUFBQSxpQkFEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLG1FQUFrRSxxQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSwwQ0FDVkE7QUFBQUEsdUNBQXFCbUo7QUFBQUEsa0JBQWM7QUFBQSxrQkFDbkNuSixxQkFBcUJrSjtBQUFBQSxxQkFGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSxtRUFBa0Usb0JBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsMENBQ1YzTSxnQkFDRWEsSUFBSTRDLHFCQUFxQitPLGdCQUFnQixFQUN6Q2pNLE9BQU8sYUFBYSxLQUh6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLG1FQUFrRSxrQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSwwQ0FDVnZHLGdCQUNFYSxJQUFJNEMscUJBQXFCZ1AsY0FBYyxFQUN2Q2xNLE9BQU8sYUFBYSxLQUh6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBLGVBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0NBO0FBQUEsVUFHQSx1QkFBQyxhQUFRLFdBQVUseUpBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDJEQUNaO0FBQUEscUNBQUMsVUFBSyxXQUFVLDZDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGNBQU87QUFBQSxpQkFEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUMySixPQUFPeUg7QUFBQUEsY0FDTmxVLHFCQUFxQm9KLHNCQUFzQixDQUFDO0FBQUEsWUFDOUMsRUFBRTVDLElBQUksQ0FBQyxDQUFDdEQsS0FBS3FPLEdBQUcsTUFBTTtBQUNwQixvQkFBTXNELGFBQ0ozUixJQUFJcUksU0FBUyxRQUFRLEtBQUtySSxJQUFJcUksU0FBUyxZQUFZO0FBQ3JELG9CQUFNdUosU0FBUzVSLElBQUlxSSxTQUFTLE1BQU07QUFFbEMsa0JBQUl3SjtBQUNKLGtCQUFJRCxRQUFRO0FBRVZDLCtCQUFleEQsTUFBTWhWLE1BQU1nVixHQUFHLEVBQUV6TyxPQUFPLFlBQVksSUFBSTtBQUFBLGNBQ3pELFdBQVcrUixZQUFZO0FBQ3JCRSwrQkFBZSxJQUFJelAsT0FBT2lNLEdBQUcsRUFBRXlCLGVBQWUsU0FBUztBQUFBLGtCQUNyRHFCLHVCQUF1QjtBQUFBLGtCQUN2QkMsdUJBQXVCO0FBQUEsZ0JBQ3pCLENBQUMsQ0FBQztBQUFBLGNBQ0osT0FBTztBQUNMUywrQkFBZXhEO0FBQUFBLGNBQ2pCO0FBRUEscUJBQ0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVTtBQUFBLGtCQUNWO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlDQUNick8sY0FBSStILFFBQVEsTUFBTSxHQUFHLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLGFBQWE0SixhQUFhLG9CQUFvQixnQkFBZ0I7QUFBQSx3QkFFeEVFO0FBQUFBO0FBQUFBLHNCQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJQTtBQUFBO0FBQUE7QUFBQSxnQkFUSzdSO0FBQUFBLGdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXQTtBQUFBLFlBRUosQ0FBQztBQUFBLGVBeENIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUNBO0FBQUEsVUFFQSx1QkFBQyxhQUFRLFdBQVUsb0lBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDJEQUNaO0FBQUEscUNBQUMsVUFBSyxXQUFVLDRDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBQU87QUFBQSxpQkFEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1h1SixpQkFBT3lILFFBQVFsVSxxQkFBcUJlLFlBQVksQ0FBQyxDQUFDLEVBQUV5RjtBQUFBQSxjQUNuRCxDQUFDLENBQUN0RCxLQUFLcU8sR0FBRyxNQUNSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFDVjtBQUFBLDJDQUFDLFVBQUssV0FBVSx5Q0FDYnJPLGNBQUkrSCxRQUFRLE1BQU0sR0FBRyxLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDRCQUEyQjtBQUFBO0FBQUEsc0JBRXhDM0YsT0FBT2lNLEdBQUcsRUFBRXlCLGVBQWUsU0FBUztBQUFBLHdCQUNuQ3FCLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUM7QUFBQSx5QkFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUE7QUFBQTtBQUFBLGdCQVhLcFI7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsWUFFSixLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFHQSx1QkFBQyxhQUFRLFdBQVUsNkhBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDJEQUNaO0FBQUEscUNBQUMsVUFBSyxXQUFVLDBDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RDtBQUFBLGNBQU87QUFBQSxpQkFEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1h1SixpQkFBT3lILFFBQVFsVSxxQkFBcUJ3QixjQUFjLENBQUMsQ0FBQyxFQUFFZ0Y7QUFBQUEsY0FDckQsQ0FBQyxDQUFDdEQsS0FBS3FPLEdBQUcsTUFDUjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFVO0FBQUEsa0JBQ1Y7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUNBQ2JyTyxjQUFJK0gsUUFBUSxNQUFNLEdBQUcsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSwwQkFBeUI7QUFBQTtBQUFBLHNCQUV0QzNGLE9BQU9pTSxHQUFHLEVBQUV5QixlQUFlLFNBQVM7QUFBQSx3QkFDbkNxQix1QkFBdUI7QUFBQSx3QkFDdkJDLHVCQUF1QjtBQUFBLHNCQUN6QixDQUFDO0FBQUEseUJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBO0FBQUE7QUFBQSxnQkFYS3BSO0FBQUFBLGdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLFlBRUosS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLFVBQ0EsdUJBQUMsYUFBUSxXQUFVLCtIQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwyREFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSwyQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Q7QUFBQSxjQUFPO0FBQUEsaUJBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNYdUosaUJBQU95SDtBQUFBQSxjQUNObFUscUJBQXFCbUMseUJBQXlCLENBQUM7QUFBQSxZQUNqRCxFQUFFcUU7QUFBQUEsY0FBSSxDQUFDLENBQUN0RCxLQUFLcU8sR0FBRyxNQUNkO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFDVjtBQUFBLDJDQUFDLFVBQUssV0FBVSx5Q0FDYnJPLGNBQUkrSCxRQUFRLE1BQU0sR0FBRyxLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsc0JBRXZDM0YsT0FBT2lNLEdBQUcsRUFBRXlCLGVBQWUsU0FBUztBQUFBLHdCQUNuQ3FCLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUM7QUFBQSx5QkFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUE7QUFBQTtBQUFBLGdCQVhLcFI7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsWUFDRCxLQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFFQ2xELHFCQUFxQitCLGtCQUFrQnFKLFNBQVMsS0FDL0MsdUJBQUMsYUFBUSxXQUFVLCtIQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwyREFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSwyQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Q7QUFBQSxjQUFPO0FBQUEsaUJBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNYcEwsK0JBQXFCK0IsaUJBQWlCeUU7QUFBQUEsY0FBSSxDQUFDK04sS0FBS3RJLE1BQy9DO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFDVjtBQUFBLDJDQUFDLFVBQUssV0FBVSw4QkFDYnNJLGNBQUl4TyxRQUFRLHFCQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxzQkFFdkNULE9BQU9pUCxJQUFJaFIsS0FBSyxFQUFFeVAsZUFBZSxTQUFTO0FBQUEsd0JBQ3pDcUIsdUJBQXVCO0FBQUEsd0JBQ3ZCQyx1QkFBdUI7QUFBQSxzQkFDekIsQ0FBQztBQUFBLHlCQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQTtBQUFBO0FBQUEsZ0JBWEtySTtBQUFBQSxnQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxZQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsZUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxVQUdEak0scUJBQXFCNkIscUJBQXFCdUosU0FBUyxLQUNsRCx1QkFBQyxhQUFRLFdBQVUsK0hBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDJEQUNaO0FBQUEscUNBQUMsVUFBSyxXQUFVLDJDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQU87QUFBQSxpQkFEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1hwTCwrQkFBcUI2QixvQkFBb0IyRTtBQUFBQSxjQUFJLENBQUMrTixLQUFLdEksTUFDbEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVTtBQUFBLGtCQUNWO0FBQUEsMkNBQUMsVUFBSyxXQUFVLDhCQUNic0ksY0FBSXhPLFFBQVEsYUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsc0JBRXZDVCxPQUFPaVAsSUFBSWhSLEtBQUssRUFBRXlQLGVBQWUsU0FBUztBQUFBLHdCQUN6Q3FCLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUM7QUFBQSx5QkFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUE7QUFBQTtBQUFBLGdCQVhLckk7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsWUFDRCxLQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsVUFHRGpNLHFCQUFxQjhCLHVCQUF1QnNKLFNBQVMsS0FDcEQsdUJBQUMsYUFBUSxXQUFVLG9JQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwyREFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSw2Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxjQUFPO0FBQUEsaUJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNYcEwsK0JBQXFCOEIsc0JBQXNCMEU7QUFBQUEsY0FBSSxDQUFDZ08sS0FBS3ZJLE1BQ3BEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFDVjtBQUFBLDJDQUFDLFVBQUssV0FBVSw4QkFDYnVJLGNBQUl6TyxRQUFRLGVBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSw2QkFBNEI7QUFBQTtBQUFBLHNCQUV6Q1QsT0FBT2tQLElBQUlqUixLQUFLLEVBQUV5UCxlQUFlLFNBQVM7QUFBQSx3QkFDekNxQix1QkFBdUI7QUFBQSx3QkFDdkJDLHVCQUF1QjtBQUFBLHNCQUN6QixDQUFDO0FBQUEseUJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBO0FBQUE7QUFBQSxnQkFYS3JJO0FBQUFBLGdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLFlBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLFVBR0RqTSxxQkFBcUJnQyx5QkFBeUIsS0FDN0MsdUJBQUMsYUFBUSxXQUFVLG1JQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwyREFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSw0Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxjQUFPO0FBQUEsaUJBRGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw0RkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSw4QkFBNkIscUNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcsa0JBQWtCaEMscUJBQXFCZ0MsdUJBQXVCLElBQ3JFLG1CQUNBLGNBQWM7QUFBQSxrQkFDWjtBQUFBO0FBQUEsb0JBRUwyRCxLQUFLQztBQUFBQSxzQkFDSjVGLHFCQUFxQmdDO0FBQUFBLG9CQUN2QixFQUFFZ1IsZUFBZSxTQUFTO0FBQUEsc0JBQ3hCcUIsdUJBQXVCO0FBQUEsc0JBQ3ZCQyx1QkFBdUI7QUFBQSxvQkFDekIsQ0FBQztBQUFBLG9CQUNBdFUscUJBQXFCZ0MsdUJBQXVCLElBQ3pDLGFBQ0E7QUFBQTtBQUFBO0FBQUEsZ0JBZE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUE7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxlQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0YsdUJBQUMsYUFBUSxXQUFVLGlIQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwyREFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSw2Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxjQUFPO0FBQUEsaUJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4QkFBNkIsaUNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsd0NBQXVDO0FBQUE7QUFBQSxrQkFFcERzRDtBQUFBQSxvQkFDQ3RGLHNCQUFzQm9KLG9CQUNsQmtFO0FBQUFBLGtCQUNOLEVBQUUwRixlQUFlLFNBQVM7QUFBQSxvQkFDeEJxQix1QkFBdUI7QUFBQSxvQkFDdkJDLHVCQUF1QjtBQUFBLGtCQUN6QixDQUFDO0FBQUEscUJBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNDdFUscUJBQXFCK0Isa0JBQWtCcUosU0FBUyxLQUMvQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsOEJBQTZCLGlDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHdDQUF1QztBQUFBO0FBQUEsa0JBRXBEOUY7QUFBQUEsb0JBQ0N0RixxQkFBcUIrQixpQkFBaUI0SztBQUFBQSxzQkFDcEMsQ0FBQ0MsS0FBS29JLE1BQU1wSSxNQUFNdEgsT0FBTzBQLEVBQUV6UixLQUFLO0FBQUEsc0JBQ2hDO0FBQUEsb0JBQ0Y7QUFBQSxrQkFDRixFQUFFeVAsZUFBZSxTQUFTO0FBQUEsb0JBQ3hCcUIsdUJBQXVCO0FBQUEsb0JBQ3ZCQyx1QkFBdUI7QUFBQSxrQkFDekIsQ0FBQztBQUFBLHFCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxtQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGNBRUR0VSxxQkFBcUI2QixxQkFBcUJ1SixTQUFTLEtBQ2xELHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4QkFBNkIsb0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsd0NBQXVDO0FBQUE7QUFBQSxrQkFFcEQ5RjtBQUFBQSxvQkFDQ3RGLHFCQUFxQjZCLG9CQUFvQjhLO0FBQUFBLHNCQUN2QyxDQUFDQyxLQUFLb0ksTUFBTXBJLE1BQU10SCxPQUFPMFAsRUFBRXpSLEtBQUs7QUFBQSxzQkFDaEM7QUFBQSxvQkFDRjtBQUFBLGtCQUNGLEVBQUV5UCxlQUFlLFNBQVM7QUFBQSxvQkFDeEJxQix1QkFBdUI7QUFBQSxvQkFDdkJDLHVCQUF1QjtBQUFBLGtCQUN6QixDQUFDO0FBQUEscUJBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLG1CQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FFRHRVLHFCQUFxQjhCLHVCQUF1QnNKLFNBQVMsS0FDcEQsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDhCQUE2QixzQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGtCQUVsRDlGO0FBQUFBLG9CQUNDdEYscUJBQXFCOEIsc0JBQXNCNks7QUFBQUEsc0JBQ3pDLENBQUNDLEtBQUtxSSxNQUFNckksTUFBTXRILE9BQU8yUCxFQUFFMVIsS0FBSztBQUFBLHNCQUNoQztBQUFBLG9CQUNGO0FBQUEsa0JBQ0YsRUFBRXlQLGVBQWUsU0FBUztBQUFBLG9CQUN4QnFCLHVCQUF1QjtBQUFBLG9CQUN2QkMsdUJBQXVCO0FBQUEsa0JBQ3pCLENBQUM7QUFBQSxxQkFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsbUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUVEdFUscUJBQXFCZ0MseUJBQXlCLEtBQzdDLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4QkFBNkIscUNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHlCQUF5QmhDLHFCQUFxQmdDLHVCQUF1QixJQUM1RSxtQkFDQSxjQUFjO0FBQUEsb0JBQ1o7QUFBQTtBQUFBLHNCQUVMMkQsS0FBS0M7QUFBQUEsd0JBQ0o1RixxQkFBcUJnQztBQUFBQSxzQkFDdkIsRUFBRWdSLGVBQWUsU0FBUztBQUFBLHdCQUN4QnFCLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUM7QUFBQSxzQkFDQXRVLHFCQUFxQmdDLHVCQUF1QixJQUN6QyxLQUNBO0FBQUE7QUFBQTtBQUFBLGtCQWROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFlQTtBQUFBLG1CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGNBRUYsdUJBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLG9DQUFtQyw0QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGtCQUVsRHNELE9BQU90RixxQkFBcUJvUCxXQUFXLEVBQUU0RDtBQUFBQSxvQkFDeEM7QUFBQSxvQkFDQTtBQUFBLHNCQUNFcUIsdUJBQXVCO0FBQUEsc0JBQ3ZCQyx1QkFBdUI7QUFBQSxvQkFDekI7QUFBQSxrQkFDRjtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsOEJBQTZCLDRCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHdDQUF1QztBQUFBO0FBQUEsa0JBRXBEaFAsT0FBT3RGLHFCQUFxQjhELFdBQVcsRUFBRWtQO0FBQUFBLG9CQUN4QztBQUFBLG9CQUNBO0FBQUEsc0JBQ0VxQix1QkFBdUI7QUFBQSxzQkFDdkJDLHVCQUF1QjtBQUFBLG9CQUN6QjtBQUFBLGtCQUNGO0FBQUEscUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4QkFBNkIsa0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFCQUFxQmhQLE9BQU90RixxQkFBcUJxUCxpQkFBaUIsSUFBSSxJQUM3RSxpQkFDQSxnQkFBZ0I7QUFBQSxvQkFDZDtBQUFBO0FBQUEsc0JBRUwvSjtBQUFBQSx3QkFDQ3RGLHFCQUFxQnFQO0FBQUFBLHNCQUN2QixFQUFFMkQsZUFBZSxTQUFTO0FBQUEsd0JBQ3hCcUIsdUJBQXVCO0FBQUEsd0JBQ3ZCQyx1QkFBdUI7QUFBQSxzQkFDekIsQ0FBQztBQUFBO0FBQUE7QUFBQSxrQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWUE7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSw4RUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4QkFBNkIsdUJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9EO0FBQUEsZ0JBQ3BEO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsZ0RBQWdEdFUscUJBQXFCd0MsV0FBVyxTQUN2Rix3REFDQSxxREFBcUQ7QUFBQSxvQkFFeER4QywrQkFBcUJ3QztBQUFBQTtBQUFBQSxrQkFMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0N4QyxxQkFBcUJrQyxrQkFDcEIsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDhCQUE2QiwrQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxtRUFDYmxDLCtCQUFxQmtDLGtCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBRUYsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDhCQUE2QiwrQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSw4QkFDYmxDLCtCQUFxQmlDLGtCQUFrQixTQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQTNLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRLQTtBQUFBLGVBakxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0xBO0FBQUEsYUF0Y0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVjQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx1REFBc0QseUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFsZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBb2ZBO0FBQUEsT0FsN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtN0VBO0FBRUo7QUFBRXRFLEdBcGxISUQsb0JBQWtCO0FBQUEsVUFDTFgsYUFlRjdCLEtBQUt3RSxTQUVDeEUsS0FBS3dFLE9BQU87QUFBQTtBQUFBd1YsS0FsQjdCeFg7QUFzbEhOLGVBQWVBO0FBQW1CLElBQUF3WDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRGF0ZVBpY2tlciIsIkRyYXdlciIsIkRyb3Bkb3duIiwiTW9kYWwiLCJJbnB1dCIsIkZvcm0iLCJTZWxlY3QiLCJCdXR0b24iLCJtZXNzYWdlIiwiUG9wY29uZmlybSIsIkVtcHR5IiwiTmF2YmFyIiwiU2lkZWJhciIsIkRhdGFUYWJsZSIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsIlRyZW5kaW5nVXAiLCJUYXJnZXQiLCJDaGVja0NpcmNsZSIsIkJhckNoYXJ0MyIsIkNoZWNrQ2lyY2xlMiIsIkFsZXJ0Q2lyY2xlIiwiQ3JlZGl0Q2FyZCIsIlVzZXIiLCJBUEkiLCJkYXlqcyIsIkFudFNlbGVjdCIsIlNlZ21lbnRlZCIsIkFudEJ1dHRvbiIsIkZsZXgiLCJTcGluIiwiSW9NZE1vcmUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJQbHVzT3V0bGluZWQiLCJEZWxldGVPdXRsaW5lZCIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJtb21lbnQiLCJ1dGMiLCJMb2FkaW5nT3V0bGluZWQiLCJNZE91dGxpbmVNYW4iLCJSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIiwiQnJlYWRjcnVtYiIsImV4dGVuZCIsIkhSU2FsYXJ5TWFuYWdlbWVudCIsIl9zIiwibmF2aWdhdGUiLCJpc09wZW5BZGRNb2RhbCIsInNldElzT3BlbkFkZE1vZGFsIiwiaXNPcGVuVXBkYXRlTW9kYWwiLCJzZXRJc09wZW5VcGRhdGVNb2RhbCIsInVwZGF0ZUxvYWRpbmciLCJzZXRVcGRhdGVMb2FkaW5nIiwiZGVsZXRlTG9hZGluZyIsInNldERlbGV0ZUxvYWRpbmciLCJjYWxjdWxhdGVMb2FkaW5nIiwic2V0Q2FsY3VsYXRlTG9hZGluZyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsImVtcGxveWVlRGV0YWlscyIsInNldEVtcGxveWVlRGV0YWlscyIsImFsbFNhbGFyeVBheW1lbnRzIiwic2V0QWxsU2FsYXJ5cGF5bWVudHMiLCJlbXBsb3llZURldGFpbHNMb2FkaW5nIiwic2V0RW1wbG95ZWVEZXRhaWxzTG9hZGluZyIsImN1cnJlbnRTYWxhcnlJZCIsInNldEN1cnJlbnRTYWxhcnlJZCIsImNhbGN1bGF0ZWRTYWxhcnkiLCJzZXRDYWxjdWxhdGVkU2FsYXJ5Iiwic2hvd0NvbXBvbmVudHMiLCJzZXRTaG93Q29tcG9uZW50cyIsImRlbGV0ZU1vZGFsT3BlbiIsInNldERlbGV0ZU1vZGFsT3BlbiIsImRlbGV0ZUlkIiwic2V0RGVsZXRlSWQiLCJmb3JtIiwidXNlRm9ybSIsImRhdGFUYWJsZUxvYWRpbmciLCJzZXREYXRhVGFibGVMb2FkaW5nIiwidXBkYXRlRm9ybSIsImFscmVhZHlQYWlkTW9kYWxPcGVuIiwic2V0QWxyZWFkeVBhaWRNb2RhbE9wZW4iLCJleGlzdGluZ1NhbGFyeVJlY29yZCIsInNldEV4aXN0aW5nU2FsYXJ5UmVjb3JkIiwiaXNFZGl0Rm9ybURpcnR5Iiwic2V0SXNFZGl0Rm9ybURpcnR5IiwicGF5bWVudE1vZGUiLCJzZXRQYXltZW50TW9kZSIsImFkZGl0aW9uYWxTYWxhcnlEZXRhaWxzIiwic2V0QWRkaXRpb25hbFNhbGFyeURldGFpbHMiLCJhZGRpdGlvbmFsU2FsYXJ5bG9hZGluZyIsInNldEFkZGl0aW9uYWxTYWxhcnlsb2FkaW5nIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsImVtcGxveWVlX2lkIiwibW9udGgiLCJ5ZWFyIiwiZWFybmluZ3MiLCJiYXNpYyIsImhyYSIsInRyYXZlbF9hbGxvd2FuY2UiLCJtZWRpY2FsX2FsbG93YW5jZSIsImJhc2tldF9vZl9iZW5pZml0cyIsInBlcmZvcm1hbmNlX2JvbnVzIiwib3RoZXJfYWxsb3dhbmNlcyIsImNvbnZleWFuY2UiLCJkZWR1Y3Rpb25zIiwiaW5jb21lX3RheCIsImVzaSIsImVwZiIsInByb2Zlc3Npb25hbF90YXgiLCJhZGRpdGlvbmFsX3BheW1lbnRzIiwiYWRkaXRpb25hbF9kZWR1Y3Rpb25zIiwiYWR2YW5jZV9wYXltZW50cyIsImNhbGN1bGF0ZWRfaW5jZW50aXZlIiwicGF5bWVudF9tZXRob2QiLCJ0cmFuc2FjdGlvbl9pZCIsIm1vbnRobHlfYnVzaW5lc3NfaW5mbyIsInRhcmdldCIsInRvdGFsX3RhcmdldCIsInRvdGFsX2J1c2luZXNzX2Nsb3NlZCIsImN1cnJlbnRfcmVtYWluaW5nX3RhcmdldCIsInN0YXR1cyIsInBheUFzU2FsYXJ5TW9kYWxPcGVuIiwic2V0UGF5QXNTYWxhcnlNb2RhbE9wZW4iLCJwYXlBc0luY2VudGl2ZU1vZGFsT3BlbiIsInNldFBheUFzSW5jZW50aXZlTW9kYWxPcGVuIiwidGhpc1llYXIiLCJmb3JtYXQiLCJlYXJuaW5nc09iamVjdCIsImRlZHVjdGlvbnNPYmplY3QiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwiZXhjZWxDb2x1bW5zIiwibW9udGhzIiwibGFiZWwiLCJ2YWx1ZSIsImRpc2FibGVkIiwicHJldmlvdXNNb250aCIsInN1YnRyYWN0IiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInRvdGFsX3NhbGFyeV9wYXlhYmxlIiwicGFpZF9hbW91bnQiLCJ0b3RhbF9zYWxhcnkiLCJwaWdteV9wZXJjIiwibG9hbl9wZXJjIiwicGlnbXlfY29sbGVjdGlvbl9pbmNlbnRpdmUiLCJsb2FuX2NvbGxlY3Rpb25faW5jZW50aXZlIiwiYWR2YW5jZV9yZXBheW1lbnQiLCJwYXlfZGF0ZSIsImFtb3VudCIsInJlbWFya3MiLCJjaGVxdWVfbnVtYmVyIiwiY2hlcXVlX2RhdGUiLCJjaGVxdWVfYmFua19uYW1lIiwiY2hlcXVlX2JhbmtfYnJhbmNoIiwic2hvd0NvbGxlY3Rpb25Db250aW51ZSIsInNldFNob3dDb2xsZWN0aW9uQ29udGludWUiLCJjb2xsZWN0aW9uTG9hZGluZyIsInNldENvbGxlY3Rpb25Mb2FkaW5nIiwiaXNCdXNpbmVzc0xvYWRpbmciLCJzZXRJc0J1c2luZXNzTG9hZGluZyIsImhhbmRsZVBheUFzU2FsYXJ5IiwiaGFuZGxlUGF5QXNJbmNlbnRpdmUiLCJjb25maXJtUGF5QXNTYWxhcnkiLCJ0b3RhbFRhcmdldCIsIk51bWJlciIsInRvdGFsQnVzaW5lc3NDbG9zZWQiLCJjdXJyZW50UmVtYWluaW5nVGFyZ2V0IiwicmF3SW5jZW50aXZlIiwiaW5jZW50aXZlQW1vdW50IiwiTWF0aCIsImFicyIsInVwZGF0ZWRSZW1haW5pbmdUYXJnZXQiLCJwcmV2IiwibmFtZSIsInN1Y2Nlc3MiLCJjb25maXJtUGF5QXNJbmNlbnRpdmUiLCJmZXRjaEVtcGxveWVlcyIsInJlc3BvbnNlRGF0YSIsImdldCIsImZpbHRlcmVkRW1wbG95ZWUiLCJkYXRhIiwiZW1wbG95ZWUiLCJtYXAiLCJlbXAiLCJfaWQiLCJwaG9uZV9udW1iZXIiLCJlcnJvciIsImZldGNoQWRkaXRpb25hbFNhbGFyeVBheW1lbnRzIiwiZW1wbG95ZWVJZCIsImdldFNhbGFyeUJ5SWQiLCJpZCIsInJlc3BvbnNlIiwiY29uc29sZSIsImZldGNoRW1wbG95ZWVUYXJnZXQiLCJzdGFydF9kYXRlIiwiZW5kX2RhdGUiLCJwYXJhbXMiLCJlcnIiLCJmZXRjaFByZXZpb3VzUmVtYWluaW5nVGFyZ2V0IiwicmVtYWluaW5nVGFyZ2V0IiwiZmV0Y2hFbXBsb3llZUJ1c2luZXNzQ2xvc2VkIiwiaW5jZW50aXZlU3VtbWFyeSIsInRvdGFsX2dyb3VwX3ZhbHVlIiwiZ2V0VmFsaWRNb250aHMiLCJqb2luaW5nRGF0ZVN0ciIsInNlbGVjdGVkWWVhciIsIm0iLCJqb2luaW5nIiwidG9kYXkiLCJqb2luWWVhciIsImN1cnJlbnRZZWFyIiwic2VsZWN0ZWRZZWFyTnVtIiwiaW5kZXgiLCJpc0JlZm9yZUpvaW5pbmciLCJpc0FmdGVyVG9kYXkiLCJqb2luaW5nX2RhdGUiLCJ2YWxpZE1vbnRocyIsImN1cnJlbnRNb250aFZhbGlkIiwic29tZSIsImZpcnN0VmFsaWQiLCJmaW5kIiwiaGFuZGxlRWRpdCIsInNhbGFyeURhdGEiLCJ5ZWFyQXNEYXlqcyIsInNhbGFyeV95ZWFyIiwic2FsYXJ5X21vbnRoIiwiYXR0ZW5kYW5jZV9kZXRhaWxzIiwic2V0RmllbGRzVmFsdWUiLCJoYW5kbGVEZWxldGVDb25maXJtIiwiZGVsZXRlIiwiZ2V0QWxsU2FsYXJ5IiwiaGFuZGxlRmV0Y2hDb2xsZWN0aW9uSW5jZW50aXZlIiwibW9udGhJbmRleCIsInN0YXJ0T2YiLCJlbmRPZiIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJ0b3RhbF9sb2FuX2NvbGxlY3Rpb25zX3BlcmMiLCJ0b3RhbF9waWdteV9jb2xsZWN0aW9uc19wZXJjIiwiaGFuZGxlUHJpbnQiLCJzYWxhcnlQYXltZW50SWQiLCJkcm9wRG93bkl0ZW1zIiwic2FsYXJ5UGF5bWVudCIsImRyb3BEb3duSXRlbUxpc3QiLCJmZXRjaFNhbGFyeURldGFpbHMiLCJ1cGRhdGVkRWFybmluZ3MiLCJzYWxhcnkiLCJ1cGRhdGVkRGVkdWN0aW9ucyIsImxvYWRUYXJnZXRBbmRJbmNlbnRpdmUiLCJ0YXJnZXRWYWx1ZSIsImJ1c2luZXNzQ2xvc2VkVmFsdWUiLCJlbXBsb3llZVByZXZpb3VzUmVtYWluaW5nVGFyZ2V0IiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJlIiwiY2xlYW5lZCIsInJlcGxhY2UiLCJkb3RDb3VudCIsIm1hdGNoIiwibGVuZ3RoIiwiaGFuZGxlQ2hhbmdlIiwidXBkYXRlZEZvcm1EYXRhIiwiaW5jbHVkZXMiLCJoYW5kbGVEZWR1Y3Rpb25zQ2hhbmdlIiwiaGFuZGxlRWFybmluZ3NDaGFuZ2UiLCJoYW5kbGVBZHZhbmNlUGF5bWVudENoYW5nZSIsImZpZWxkIiwidXBkYXRlZFBheW1lbnRzIiwiYWRkQWR2YW5jZVBheW1lbnQiLCJyZW1vdmVBZHZhbmNlUGF5bWVudCIsImZpbHRlciIsIl8iLCJpIiwiaGFuZGxlQWRkaXRpb25hbFBheW1lbnRDaGFuZ2UiLCJhZGRBZGRpdGlvbmFsUGF5bWVudCIsInJlbW92ZUFkZGl0aW9uYWxQYXltZW50IiwiaGFuZGxlQWRkaXRpb25hbERlZHVjdGlvbkNoYW5nZSIsImFkZEFkZGl0aW9uYWxEZWR1Y3Rpb24iLCJyZW1vdmVBZGRpdGlvbmFsRGVkdWN0aW9uIiwidXBkYXRlVG90YWxFYXJuaW5ncyIsIk9iamVjdCIsInZhbHVlcyIsInJlZHVjZSIsInN1bSIsInYiLCJ1cGRhdGVUb3RhbERlZHVjdGlvbnMiLCJiYXNlIiwiaGFuZGxlQ2FsY3VsYXRlU2FsYXJ5Iiwic2FsYXJ5UmVzIiwiY29sbGVjdGlvblJlcyIsIlByb21pc2UiLCJhbGwiLCJjYWxjdWxhdGVkIiwiY2FsY3VsYXRlZF9zYWxhcnkiLCJleGlzdGluZ19zYWxhcnkiLCJoYW5kbGVBZGRTYWxhcnkiLCJiYXNlU2FsYXJ5IiwiYWR2YW5jZVRvdGFsIiwiYSIsImFkZGl0aW9uYWxQYXltZW50c1RvdGFsIiwicGF5bWVudCIsImFkZGl0aW9uYWxEZWR1Y3Rpb25zVG90YWwiLCJkZWR1Y3Rpb24iLCJ0b3RhbFNhbGFyeVBheWFibGUiLCJmaW5hbENhbGN1bGF0ZWRJbmNlbnRpdmUiLCJ0b3RhbERlZHVjdGlvbnMiLCJwYWlkQW1vdW50IiwicmVtYWluaW5nQmFsYW5jZSIsImF0dGVuZGFuY2VEZXRhaWxzIiwidG90YWxfZGF5cyIsInByZXNlbnRfZGF5cyIsInBhaWRfZGF5cyIsImxvcF9kYXlzIiwibG9wIiwicGVyX2RheV9zYWxhcnkiLCJhYnNlbnRfZGF5cyIsImxlYXZlX2RheXMiLCJoYWxmX2RheXMiLCJzYWxhcnlfZnJvbV9kYXRlIiwic2FsYXJ5X3RvX2RhdGUiLCJtb250aGx5VGFyZ2V0SW5jZW50aXZlIiwiYWRkaXRpb25hbF9zYWxhcmllcyIsIkRhdGUiLCJuZXRfcGF5YWJsZSIsInJlbWFpbmluZ19iYWxhbmNlIiwibG9hbl9jb2xsZWN0aW9uIiwicGlnbXlfY29sbGVjdGlvbiIsInBvc3QiLCJmaWx0ZXJlZERhdGEiLCJzaU5vIiwiZW1wbG95ZWVOYW1lIiwiZW1wbG95ZWVDb2RlIiwic2FsYXJ5TW9udGgiLCJzYWxhcnlZZWFyIiwibmV0UGF5YWJsZSIsInByZXNlbnREYXlzIiwiYWJzZW50RGF5cyIsInBhaWRMZWF2ZXMiLCJ0b3RhbERheXMiLCJ0cmF2ZWxBbGxvd2FuY2UiLCJtZWRpY2FsQWxsb3dhbmNlIiwiYmFza2V0T2ZCZW5pZml0cyIsInBlcmZvcm1hbmNlQm9udXMiLCJvdGhlckFsbG93YW5jZXMiLCJpbmNvbWVUYXgiLCJwcm9mZXNzaW9uYWxUYXgiLCJzYWxhcnlBZHZhbmNlIiwic2FsYXJ5X2FkdmFuY2UiLCJhY3Rpb24iLCJpdGVtcyIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwic2VsZWN0ZWRNb2RlIiwicHJldkRhdGEiLCJwYXlfdHlwZSIsInRvdGFsRWFybmluZ3NFeGNsdWRpbmdTYWxhcnkiLCJrZXlzIiwiYmFzZURlZHVjdGlvbnMiLCJiYXNlVG90YWwiLCJ2YWwiLCJjYWxjdWxhdGVkSW5jZW50aXZlIiwiTkFWX0xJTktTIiwidG8iLCJpY29uIiwibGluayIsImZvbnRTaXplIiwiaW5wdXQiLCJvcHRpb24iLCJ0b0xvd2VyQ2FzZSIsIm9wdGlvbkEiLCJvcHRpb25CIiwibG9jYWxlQ29tcGFyZSIsIndpZHRoIiwiZGF0ZSIsImRhdGVTdHJpbmciLCJjdXJyZW50IiwiZW1haWwiLCJzcGxpdCIsInRvRml4ZWQiLCJibHVyIiwidmFyaWFuY2UiLCJzdGF0dXNDb25maWciLCJleGNlZWRlZCIsImNvbnRhaW5lciIsInRvTG9jYWxlU3RyaW5nIiwiYWNoaWV2ZWQiLCJzaG9ydGZhbGwiLCJjdXJyZW50U3RhdHVzIiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyQ29sb3IiLCJhdHRlbmRhbmNlX3N1bW1hcnkiLCJpdGVtIiwib3JpZ2luYWxfdmFsdWUiLCJwYXltZW50X3ZhbHVlIiwidG90YWxfb3JpZ2luYWxfYWRkaXRpb25hbF9zYWxhcnkiLCJ0b3RhbF9wYXltZW50X2Ftb3VudCIsImJhc2VQYXkiLCJ0b3RhbEFkZGl0aW9uYWxQYXltZW50cyIsImFjYyIsInRvdGFsQWRkaXRpb25hbERlZHVjdGlvbnMiLCJ0b3RhbCIsImlzRGF5anMiLCJlbnRyaWVzIiwibCIsInRvVXBwZXJDYXNlIiwibWluaW11bUZyYWN0aW9uRGlnaXRzIiwibWF4aW11bUZyYWN0aW9uRGlnaXRzIiwicGF5IiwiZGVkIiwiY29sb3IiLCJwYWRkaW5nIiwibWF4SGVpZ2h0Iiwib3ZlcmZsb3dZIiwiaXNDdXJyZW5jeSIsImlzRGF0ZSIsImRpc3BsYXlWYWx1ZSIsInAiLCJkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSFJTYWxhcnlNYW5hZ2VtZW50LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIERhdGVQaWNrZXIsXHJcbiAgRHJhd2VyLFxyXG4gIERyb3Bkb3duLFxyXG4gIE1vZGFsLFxyXG4gIElucHV0LFxyXG4gIEZvcm0sXHJcbiAgU2VsZWN0LFxyXG4gIEJ1dHRvbixcclxuICBtZXNzYWdlLFxyXG4gIFBvcGNvbmZpcm0sXHJcbiAgRW1wdHksXHJcbn0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgVHJlbmRpbmdVcCxcclxuICBUYXJnZXQsXHJcbiAgQ2hlY2tDaXJjbGUsXHJcbiAgQmFyQ2hhcnQzLFxyXG4gIENoZWNrQ2lyY2xlMixcclxuICBBbGVydENpcmNsZSxcclxuICBDcmVkaXRDYXJkLFxyXG4gIFVzZXIsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IHtcclxuICBTZWxlY3QgYXMgQW50U2VsZWN0LFxyXG4gIFNlZ21lbnRlZCxcclxuICBCdXR0b24gYXMgQW50QnV0dG9uLFxyXG4gIEZsZXgsXHJcbiAgU3BpbixcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IFBsdXNPdXRsaW5lZCwgRGVsZXRlT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IG1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCB1dGMgZnJvbSBcImRheWpzL3BsdWdpbi91dGNcIjtcclxuaW1wb3J0IHsgTG9hZGluZ091dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCB7IE1kT3V0bGluZU1hbiB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuZGF5anMuZXh0ZW5kKHV0Yyk7XHJcblxyXG5jb25zdCBIUlNhbGFyeU1hbmFnZW1lbnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtpc09wZW5BZGRNb2RhbCwgc2V0SXNPcGVuQWRkTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc09wZW5VcGRhdGVNb2RhbCwgc2V0SXNPcGVuVXBkYXRlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt1cGRhdGVMb2FkaW5nLCBzZXRVcGRhdGVMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZGVsZXRlTG9hZGluZywgc2V0RGVsZXRlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2NhbGN1bGF0ZUxvYWRpbmcsIHNldENhbGN1bGF0ZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlRGV0YWlscywgc2V0RW1wbG95ZWVEZXRhaWxzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbYWxsU2FsYXJ5UGF5bWVudHMsIHNldEFsbFNhbGFyeXBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVEZXRhaWxzTG9hZGluZywgc2V0RW1wbG95ZWVEZXRhaWxzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRTYWxhcnlJZCwgc2V0Q3VycmVudFNhbGFyeUlkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtjYWxjdWxhdGVkU2FsYXJ5LCBzZXRDYWxjdWxhdGVkU2FsYXJ5XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93Q29tcG9uZW50cywgc2V0U2hvd0NvbXBvbmVudHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtkZWxldGVNb2RhbE9wZW4sIHNldERlbGV0ZU1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2RlbGV0ZUlkLCBzZXREZWxldGVJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZm9ybV0gPSBGb3JtLnVzZUZvcm0oKTtcclxuICBjb25zdCBbZGF0YVRhYmxlTG9hZGluZywgc2V0RGF0YVRhYmxlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW2FscmVhZHlQYWlkTW9kYWxPcGVuLCBzZXRBbHJlYWR5UGFpZE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2V4aXN0aW5nU2FsYXJ5UmVjb3JkLCBzZXRFeGlzdGluZ1NhbGFyeVJlY29yZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNFZGl0Rm9ybURpcnR5LCBzZXRJc0VkaXRGb3JtRGlydHldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwYXltZW50TW9kZSwgc2V0UGF5bWVudE1vZGVdID0gdXNlU3RhdGUoXCJjYXNoXCIpO1xyXG4gIGNvbnN0IFthZGRpdGlvbmFsU2FsYXJ5RGV0YWlscywgc2V0QWRkaXRpb25hbFNhbGFyeURldGFpbHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZGRpdGlvbmFsU2FsYXJ5bG9hZGluZywgc2V0QWRkaXRpb25hbFNhbGFyeWxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZW1wbG95ZWVfaWQ6IFwiXCIsXHJcbiAgICBtb250aDogXCJcIixcclxuICAgIHllYXI6IFwiXCIsXHJcbiAgICBlYXJuaW5nczoge1xyXG4gICAgICBiYXNpYzogMCxcclxuICAgICAgaHJhOiAwLFxyXG4gICAgICB0cmF2ZWxfYWxsb3dhbmNlOiAwLFxyXG4gICAgICBtZWRpY2FsX2FsbG93YW5jZTogMCxcclxuICAgICAgYmFza2V0X29mX2JlbmlmaXRzOiAwLFxyXG4gICAgICBwZXJmb3JtYW5jZV9ib251czogMCxcclxuICAgICAgb3RoZXJfYWxsb3dhbmNlczogMCxcclxuICAgICAgY29udmV5YW5jZTogMCxcclxuICAgIH0sXHJcbiAgICBkZWR1Y3Rpb25zOiB7XHJcbiAgICAgIGluY29tZV90YXg6IDAsXHJcbiAgICAgIGVzaTogMCxcclxuICAgICAgZXBmOiAwLFxyXG4gICAgICBwcm9mZXNzaW9uYWxfdGF4OiAwLFxyXG4gICAgfSxcclxuICAgIGFkZGl0aW9uYWxfcGF5bWVudHM6IFtdLFxyXG4gICAgYWRkaXRpb25hbF9kZWR1Y3Rpb25zOiBbXSxcclxuICAgIGFkdmFuY2VfcGF5bWVudHM6IFtdLFxyXG4gICAgY2FsY3VsYXRlZF9pbmNlbnRpdmU6IDAsXHJcbiAgICBwYXltZW50X21ldGhvZDogXCJcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgbW9udGhseV9idXNpbmVzc19pbmZvOiB7XHJcbiAgICAgIHRhcmdldDogMCxcclxuICAgICAgLy8gcHJldmlvdXNfcmVtYWluaW5nX3RhcmdldDogMCxcclxuICAgICAgdG90YWxfdGFyZ2V0OiAwLFxyXG4gICAgICB0b3RhbF9idXNpbmVzc19jbG9zZWQ6IDAsXHJcbiAgICAgIGN1cnJlbnRfcmVtYWluaW5nX3RhcmdldDogMCxcclxuICAgIH0sXHJcbiAgICBzdGF0dXM6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIC8vIE5ldyBzdGF0ZSBmb3IgY29uZmlybWF0aW9uIG1vZGFsc1xyXG4gIGNvbnN0IFtwYXlBc1NhbGFyeU1vZGFsT3Blbiwgc2V0UGF5QXNTYWxhcnlNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwYXlBc0luY2VudGl2ZU1vZGFsT3Blbiwgc2V0UGF5QXNJbmNlbnRpdmVNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCB0aGlzWWVhciA9IGRheWpzKCkuZm9ybWF0KFwiWVlZWVwiKTtcclxuXHJcbiAgY29uc3QgZWFybmluZ3NPYmplY3QgPSB7XHJcbiAgICBiYXNpYzogMCxcclxuICAgIGhyYTogMCxcclxuICAgIHRyYXZlbF9hbGxvd2FuY2U6IDAsXHJcbiAgICBtZWRpY2FsX2FsbG93YW5jZTogMCxcclxuICAgIGJhc2tldF9vZl9iZW5pZml0czogMCxcclxuICAgIHBlcmZvcm1hbmNlX2JvbnVzOiAwLFxyXG4gICAgb3RoZXJfYWxsb3dhbmNlczogMCxcclxuICAgIGNvbnZleWFuY2U6IDAsXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZGVkdWN0aW9uc09iamVjdCA9IHtcclxuICAgIGluY29tZV90YXg6IDAsXHJcbiAgICBlc2k6IDAsXHJcbiAgICBlcGY6IDAsXHJcbiAgICBwcm9mZXNzaW9uYWxfdGF4OiAwLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzaU5vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1wbG95ZWVOYW1lXCIsIGhlYWRlcjogXCJFbXBsb3llZSBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlQ29kZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwic2FsYXJ5WWVhclwiLCBoZWFkZXI6IFwiWWVhclwiIH0sXHJcbiAgICB7IGtleTogXCJzYWxhcnlNb250aFwiLCBoZWFkZXI6IFwiU2FsYXJ5IE1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcIm5ldFBheWFibGVcIiwgaGVhZGVyOiBcIk5ldCBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcInBhaWRBbW91bnRcIiwgaGVhZGVyOiBcIlBhaWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiUGF5bWVudCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG5cclxuICBjb25zdCBleGNlbENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzaU5vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1wbG95ZWVOYW1lXCIsIGhlYWRlcjogXCJFbXBsb3llZSBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlQ29kZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwic2FsYXJ5WWVhclwiLCBoZWFkZXI6IFwiWWVhclwiIH0sXHJcbiAgICB7IGtleTogXCJzYWxhcnlNb250aFwiLCBoZWFkZXI6IFwiTW9udGhcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxEYXlzXCIsIGhlYWRlcjogXCJUb3RhbCBEYXlzXCIgfSxcclxuICAgIHsga2V5OiBcInByZXNlbnREYXlzXCIsIGhlYWRlcjogXCJQcmVzZW50IERheXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWJzZW50RGF5c1wiLCBoZWFkZXI6IFwiQWJzZW50IERheXNcIiB9LFxyXG4gICAgeyBrZXk6IFwicGFpZExlYXZlc1wiLCBoZWFkZXI6IFwiUGFpZCBMZWF2ZXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFzaWNcIiwgaGVhZGVyOiBcIkJhc2ljXCIgfSxcclxuICAgIHsga2V5OiBcImhyYVwiLCBoZWFkZXI6IFwiSFJBXCIgfSxcclxuICAgIHsga2V5OiBcInRyYXZlbEFsbG93YW5jZVwiLCBoZWFkZXI6IFwiVHJhdmVsIEFsbG93YW5hY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwibWVkaWNhbEFsbG93YW5jZVwiLCBoZWFkZXI6IFwiTWVkaWNhbCBBbGxvd2FuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFza2V0T2ZCZW5pZml0c1wiLCBoZWFkZXI6IFwiQmFza2V0IE9mIEJlbmlmaXRzXCIgfSxcclxuICAgIHsga2V5OiBcInBlcmZvcm1hbmNlQm9udXNcIiwgaGVhZGVyOiBcIlBlcmZvcm1hbmNlIEJvbnVzXCIgfSxcclxuICAgIHsga2V5OiBcIm90aGVyQWxsb3dhbmNlc1wiLCBoZWFkZXI6IFwiT3RoZXIgQWxsb3dhbmNlc1wiIH0sXHJcbiAgICB7IGtleTogXCJjb252ZXlhbmNlXCIsIGhlYWRlcjogXCJDb252ZXlhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImluY29tZVRheFwiLCBoZWFkZXI6IFwiSW5jb21lIFRheFwiIH0sXHJcbiAgICB7IGtleTogXCJlc2lcIiwgaGVhZGVyOiBcIkVzaVwiIH0sXHJcbiAgICB7IGtleTogXCJlcGZcIiwgaGVhZGVyOiBcIkVwZlwiIH0sXHJcbiAgICB7IGtleTogXCJwcm9mZXNzaW9uYWxUYXhcIiwgaGVhZGVyOiBcIlByb2Zlc3Npb25hbCBUYXhcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJQYXltZW50IFN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJuZXRQYXlhYmxlXCIsIGhlYWRlcjogXCJOZXQgUGF5YWJsZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYWlkQW1vdW50XCIsIGhlYWRlcjogXCJQYWlkIEFtb3VudFwiIH0sXHJcbiAgXTtcclxuXHJcblxyXG4gIGNvbnN0IG1vbnRocyA9IFtcclxuICAgIHsgbGFiZWw6IFwiSmFudWFyeVwiLCB2YWx1ZTogXCJKYW51YXJ5XCIsIGRpc2FibGVkOiBmYWxzZSB9LFxyXG4gICAgeyBsYWJlbDogXCJGZWJydWFyeVwiLCB2YWx1ZTogXCJGZWJydWFyeVwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICAgIHsgbGFiZWw6IFwiTWFyY2hcIiwgdmFsdWU6IFwiTWFyY2hcIiwgZGlzYWJsZWQ6IGZhbHNlIH0sXHJcbiAgICB7IGxhYmVsOiBcIkFwcmlsXCIsIHZhbHVlOiBcIkFwcmlsXCIsIGRpc2FibGVkOiBmYWxzZSB9LFxyXG4gICAgeyBsYWJlbDogXCJNYXlcIiwgdmFsdWU6IFwiTWF5XCIsIGRpc2FibGVkOiBmYWxzZSB9LFxyXG4gICAgeyBsYWJlbDogXCJKdW5lXCIsIHZhbHVlOiBcIkp1bmVcIiwgZGlzYWJsZWQ6IGZhbHNlIH0sXHJcbiAgICB7IGxhYmVsOiBcIkp1bHlcIiwgdmFsdWU6IFwiSnVseVwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICAgIHsgbGFiZWw6IFwiQXVndXN0XCIsIHZhbHVlOiBcIkF1Z3VzdFwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IFwiU2VwdGVtYmVyXCIsXHJcbiAgICAgIHZhbHVlOiBcIlNlcHRlbWJlclwiLFxyXG4gICAgICBkaXNhYmxlZDogZmFsc2UsXHJcbiAgICB9LFxyXG4gICAgeyBsYWJlbDogXCJPY3RvYmVyXCIsIHZhbHVlOiBcIk9jdG9iZXJcIiwgZGlzYWJsZWQ6IGZhbHNlIH0sXHJcbiAgICB7IGxhYmVsOiBcIk5vdmVtYmVyXCIsIHZhbHVlOiBcIk5vdmVtYmVyXCIsIGRpc2FibGVkOiBmYWxzZSB9LFxyXG4gICAgeyBsYWJlbDogXCJEZWNlbWJlclwiLCB2YWx1ZTogXCJEZWNlbWJlclwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBwcmV2aW91c01vbnRoID0gbW9udGhzW2RheWpzKCkuc3VidHJhY3QoMiwgXCJtb250aFwiKS5mb3JtYXQoXCJNTVwiKV0/LmxhYmVsO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGVtcGxveWVlX2lkOiBcIlwiLFxyXG4gICAgbW9udGg6IHByZXZpb3VzTW9udGgsXHJcbiAgICB5ZWFyOiB0aGlzWWVhcixcclxuICAgIGVhcm5pbmdzOiB7XHJcbiAgICAgIGJhc2ljOiAwLFxyXG4gICAgICBocmE6IDAsXHJcbiAgICAgIHRyYXZlbF9hbGxvd2FuY2U6IDAsXHJcbiAgICAgIG1lZGljYWxfYWxsb3dhbmNlOiAwLFxyXG4gICAgICBiYXNrZXRfb2ZfYmVuaWZpdHM6IDAsXHJcbiAgICAgIHBlcmZvcm1hbmNlX2JvbnVzOiAwLFxyXG4gICAgICBvdGhlcl9hbGxvd2FuY2VzOiAwLFxyXG4gICAgICBjb252ZXlhbmNlOiAwLFxyXG4gICAgfSxcclxuICAgIGRlZHVjdGlvbnM6IHtcclxuICAgICAgaW5jb21lX3RheDogMCxcclxuICAgICAgZXNpOiAwLFxyXG4gICAgICBlcGY6IDAsXHJcbiAgICAgIHByb2Zlc3Npb25hbF90YXg6IDAsXHJcbiAgICB9LFxyXG4gICAgYWRkaXRpb25hbF9wYXltZW50czogW10sXHJcbiAgICBhZGRpdGlvbmFsX2RlZHVjdGlvbnM6IFtdLFxyXG4gICAgYWR2YW5jZV9wYXltZW50czogW10sXHJcbiAgICBjYWxjdWxhdGVkX2luY2VudGl2ZTogMCxcclxuICAgIHRvdGFsX3NhbGFyeV9wYXlhYmxlOiAwLFxyXG4gICAgcGFpZF9hbW91bnQ6IDAsXHJcbiAgICBwYXltZW50X21ldGhvZDogXCJcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgbW9udGhseV9idXNpbmVzc19pbmZvOiB7XHJcbiAgICAgIHRhcmdldDogMCxcclxuICAgICAgLy8gcHJldmlvdXNfcmVtYWluaW5nX3RhcmdldDogMCxcclxuICAgICAgdG90YWxfdGFyZ2V0OiAwLFxyXG4gICAgICB0b3RhbF9idXNpbmVzc19jbG9zZWQ6IDAsXHJcbiAgICAgIGN1cnJlbnRfcmVtYWluaW5nX3RhcmdldDogMCxcclxuICAgIH0sXHJcbiAgICB0b3RhbF9zYWxhcnk6IDAsXHJcbiAgICBwaWdteV9wZXJjOiAwLFxyXG4gICAgbG9hbl9wZXJjOiAwLFxyXG4gICAgcGlnbXlfY29sbGVjdGlvbl9pbmNlbnRpdmU6IDAsXHJcbiAgICBsb2FuX2NvbGxlY3Rpb25faW5jZW50aXZlOiAwLFxyXG4gICAgYWR2YW5jZV9yZXBheW1lbnQ6IHtcclxuICAgICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgICAgIGFtb3VudDogMCxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgIHJlbWFya3M6IFwiXCIsXHJcbiAgICAgIGNoZXF1ZV9udW1iZXI6IFwiXCIsXHJcbiAgICAgIGNoZXF1ZV9kYXRlOiBcIlwiLFxyXG4gICAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgICBjaGVxdWVfYmFua19icmFuY2g6IFwiXCJcclxuICAgIH1cclxuICB9KTtcclxuICBjb25zdCBbc2hvd0NvbGxlY3Rpb25Db250aW51ZSwgc2V0U2hvd0NvbGxlY3Rpb25Db250aW51ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2NvbGxlY3Rpb25Mb2FkaW5nLCBzZXRDb2xsZWN0aW9uTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQnVzaW5lc3NMb2FkaW5nLCBzZXRJc0J1c2luZXNzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgLy8gSGFuZGxlciBmb3IgUGF5IGFzIFNhbGFyeSBidXR0b25cclxuICBjb25zdCBoYW5kbGVQYXlBc1NhbGFyeSA9ICgpID0+IHtcclxuICAgIHNldFBheUFzU2FsYXJ5TW9kYWxPcGVuKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZXIgZm9yIFBheSBhcyBJbmNlbnRpdmUgYnV0dG9uXHJcbiAgY29uc3QgaGFuZGxlUGF5QXNJbmNlbnRpdmUgPSAoKSA9PiB7XHJcbiAgICBzZXRQYXlBc0luY2VudGl2ZU1vZGFsT3Blbih0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyBDb25maXJtIFBheSBhcyBTYWxhcnlcclxuICBjb25zdCBjb25maXJtUGF5QXNTYWxhcnkgPSAoKSA9PiB7XHJcbiAgICBjb25zdCB0b3RhbFRhcmdldCA9IE51bWJlcihcclxuICAgICAgZm9ybURhdGEubW9udGhseV9idXNpbmVzc19pbmZvLnRvdGFsX3RhcmdldCB8fCAwXHJcbiAgICApO1xyXG4gICAgY29uc3QgdG90YWxCdXNpbmVzc0Nsb3NlZCA9IE51bWJlcihcclxuICAgICAgZm9ybURhdGEubW9udGhseV9idXNpbmVzc19pbmZvLnRvdGFsX2J1c2luZXNzX2Nsb3NlZCB8fCAwXHJcbiAgICApO1xyXG4gICAgY29uc3QgY3VycmVudFJlbWFpbmluZ1RhcmdldCA9IE51bWJlcihcclxuICAgICAgZm9ybURhdGEubW9udGhseV9idXNpbmVzc19pbmZvLmN1cnJlbnRfcmVtYWluaW5nX3RhcmdldCB8fCAwXHJcbiAgICApO1xyXG5cclxuICAgIC8vIENhbGN1bGF0ZSByYXcgaW5jZW50aXZlIGFzIHBlciByZXF1aXJlbWVudHNcclxuICAgIGNvbnN0IHJhd0luY2VudGl2ZSA9ICh0b3RhbFRhcmdldCAtIHRvdGFsQnVzaW5lc3NDbG9zZWQpIC8gMTAwO1xyXG5cclxuICAgIGxldCBpbmNlbnRpdmVBbW91bnQgPSAwO1xyXG4gICAgaWYgKHJhd0luY2VudGl2ZSA+IDApIHtcclxuICAgICAgLy8gSWYgcmF3SW5jZW50aXZlID4gMCwgY2FsY3VsYXRlZEluY2VudGl2ZSA9IHRvdGFsQnVzaW5lc3NDbG9zZWQgLyAxMDBcclxuICAgICAgaW5jZW50aXZlQW1vdW50ID0gdG90YWxCdXNpbmVzc0Nsb3NlZCAvIDEwMDtcclxuICAgIH0gZWxzZSBpZiAocmF3SW5jZW50aXZlIDwgMCkge1xyXG4gICAgICAvLyBJZiByYXdJbmNlbnRpdmUgPCAwLCBjYWxjdWxhdGVkSW5jZW50aXZlID0gYWJzKHJhd0luY2VudGl2ZSlcclxuICAgICAgaW5jZW50aXZlQW1vdW50ID0gTWF0aC5hYnMocmF3SW5jZW50aXZlKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBIYW5kbGUgY3VycmVudF9yZW1haW5pbmdfdGFyZ2V0IGJhc2VkIG9uIHJlcXVpcmVtZW50XHJcbiAgICAvLyBJZiBjdXJyZW50UmVtYWluaW5nVGFyZ2V0IDwgMCwgc2V0IHRvIDA7IGVsc2UsIGtlZXAgYXMgaXNcclxuICAgIGNvbnN0IHVwZGF0ZWRSZW1haW5pbmdUYXJnZXQgPVxyXG4gICAgICBjdXJyZW50UmVtYWluaW5nVGFyZ2V0IDwgMCA/IDAgOiBjdXJyZW50UmVtYWluaW5nVGFyZ2V0O1xyXG5cclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBhZGRpdGlvbmFsX3BheW1lbnRzOiBbXHJcbiAgICAgICAgLi4ucHJldi5hZGRpdGlvbmFsX3BheW1lbnRzLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6IFwiU2FsYXJ5IFBheWFibGVcIixcclxuICAgICAgICAgIHZhbHVlOiBpbmNlbnRpdmVBbW91bnQsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSxcclxuICAgICAgbW9udGhseV9idXNpbmVzc19pbmZvOiB7XHJcbiAgICAgICAgLi4ucHJldi5tb250aGx5X2J1c2luZXNzX2luZm8sXHJcbiAgICAgICAgY3VycmVudF9yZW1haW5pbmdfdGFyZ2V0OiB1cGRhdGVkUmVtYWluaW5nVGFyZ2V0LFxyXG4gICAgICB9LFxyXG4gICAgICBjYWxjdWxhdGVkX2luY2VudGl2ZTogMCwgLy8gUmVzZXQgY2FsY3VsYXRlZCBpbmNlbnRpdmVcclxuICAgIH0pKTtcclxuXHJcbiAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJTYWxhcnkgcGF5YWJsZSBhbW91bnQgYWRkZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgc2V0UGF5QXNTYWxhcnlNb2RhbE9wZW4oZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIC8vIENvbmZpcm0gUGF5IGFzIEluY2VudGl2ZVxyXG4gIGNvbnN0IGNvbmZpcm1QYXlBc0luY2VudGl2ZSA9ICgpID0+IHtcclxuICAgIGNvbnN0IHRvdGFsVGFyZ2V0ID0gTnVtYmVyKFxyXG4gICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfdGFyZ2V0IHx8IDBcclxuICAgICk7XHJcbiAgICBjb25zdCB0b3RhbEJ1c2luZXNzQ2xvc2VkID0gTnVtYmVyKFxyXG4gICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfYnVzaW5lc3NfY2xvc2VkIHx8IDBcclxuICAgICk7XHJcblxyXG4gICAgLy8gQ2FsY3VsYXRlIHJhdyBpbmNlbnRpdmVcclxuICAgIGNvbnN0IHJhd0luY2VudGl2ZSA9ICh0b3RhbFRhcmdldCAtIHRvdGFsQnVzaW5lc3NDbG9zZWQpIC8gMTAwO1xyXG4gICAgbGV0IGluY2VudGl2ZUFtb3VudCA9IDA7XHJcblxyXG4gICAgaWYgKHJhd0luY2VudGl2ZSA+IDApIHtcclxuICAgICAgLy8gSWYgcmF3SW5jZW50aXZlID4gMCwgY2FsY3VsYXRlZEluY2VudGl2ZSA9IHRvdGFsQnVzaW5lc3NDbG9zZWQgLyAxMDBcclxuICAgICAgaW5jZW50aXZlQW1vdW50ID0gdG90YWxCdXNpbmVzc0Nsb3NlZCAvIDEwMDtcclxuICAgIH0gZWxzZSBpZiAocmF3SW5jZW50aXZlIDwgMCkge1xyXG4gICAgICAvLyBJZiByYXdJbmNlbnRpdmUgPCAwLCBjYWxjdWxhdGVkSW5jZW50aXZlID0gYWJzKHJhd0luY2VudGl2ZSlcclxuICAgICAgaW5jZW50aXZlQW1vdW50ID0gTWF0aC5hYnMocmF3SW5jZW50aXZlKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgY2FsY3VsYXRlZF9pbmNlbnRpdmU6IGluY2VudGl2ZUFtb3VudCxcclxuICAgICAgbW9udGhseV9idXNpbmVzc19pbmZvOiB7XHJcbiAgICAgICAgLi4ucHJldi5tb250aGx5X2J1c2luZXNzX2luZm8sXHJcbiAgICAgICAgY3VycmVudF9yZW1haW5pbmdfdGFyZ2V0OiAwLFxyXG4gICAgICB9LFxyXG4gICAgfSkpO1xyXG5cclxuICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIkluY2VudGl2ZSBwYXlhYmxlIGFtb3VudCBhZGRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICBzZXRQYXlBc0luY2VudGl2ZU1vZGFsT3BlbihmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hFbXBsb3llZXMoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZURhdGEgPSBhd2FpdCBBUEkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICBjb25zdCBmaWx0ZXJlZEVtcGxveWVlID0gcmVzcG9uc2VEYXRhPy5kYXRhPy5lbXBsb3llZT8ubWFwKChlbXApID0+ICh7XHJcbiAgICAgICAgdmFsdWU6IGVtcD8uX2lkLFxyXG4gICAgICAgIGxhYmVsOiBgJHtlbXA/Lm5hbWV9IHwgJHtlbXA/LnBob25lX251bWJlcn1gIHx8IFwiVW5rbm93biBFbXBsb3llZVwiLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldEVtcGxveWVlcyhmaWx0ZXJlZEVtcGxveWVlIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEVtcGxveWVlcyhbXSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBmZXRjaEFkZGl0aW9uYWxTYWxhcnlQYXltZW50cyhlbXBsb3llZUlkKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRBZGRpdGlvbmFsU2FsYXJ5bG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gYXdhaXQgQVBJLmdldChgL3NhbGFyeS1wYXltZW50L2FkZGl0aW9uYWwvZW1wbG95ZWVzP2VtcGxveWVlX2lkPSR7ZW1wbG95ZWVJZH0meWVhcj0ke2Zvcm1EYXRhPy55ZWFyfSZtb250aD0ke2Zvcm1EYXRhPy5tb250aH1gKTtcclxuICAgICAgc2V0QWRkaXRpb25hbFNhbGFyeURldGFpbHMocmVzcG9uc2VEYXRhPy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFkZGl0aW9uYWxTYWxhcnlEZXRhaWxzKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldEFkZGl0aW9uYWxTYWxhcnlsb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFNhbGFyeUJ5SWQoaWQpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChgL3NhbGFyeS1wYXltZW50LyR7aWR9YCk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZT8uZGF0YT8uZGF0YTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBzYWxhcnkgYnkgSUQ6XCIsIGVycm9yKTtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlVGFyZ2V0ID0gYXN5bmMgKGVtcGxveWVlSWQsIHN0YXJ0X2RhdGUsIGVuZF9kYXRlKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoYC90YXJnZXQvZW1wbG95ZWVzLyR7ZW1wbG95ZWVJZH1gLCB7XHJcbiAgICAgICAgcGFyYW1zOiB7IHN0YXJ0X2RhdGUsIGVuZF9kYXRlIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8udG90YWxfdGFyZ2V0IHx8IDA7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YXJnZXQ6XCIsIGVycik7XHJcbiAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoUHJldmlvdXNSZW1haW5pbmdUYXJnZXQgPSBhc3luYyAoZW1wbG95ZWVJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFxyXG4gICAgICAgIGAvc2FsYXJ5LXBheW1lbnQvZW1wbG95ZWVzLyR7ZW1wbG95ZWVJZH0/bW9udGg9JHtmb3JtRGF0YS5tb250aH0meWVhcj0ke2Zvcm1EYXRhLnllYXJ9YFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8uZGF0YS5yZW1haW5pbmdUYXJnZXQgfHwgMDtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIFJlbWFpbmluZyBUYXJnZXQ6XCIsIGVycik7XHJcbiAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoRW1wbG95ZWVCdXNpbmVzc0Nsb3NlZCA9IGFzeW5jIChcclxuICAgIGVtcGxveWVlSWQsXHJcbiAgICBzdGFydF9kYXRlLFxyXG4gICAgZW5kX2RhdGVcclxuICApID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcclxuICAgICAgICBgL2Vucm9sbC9lbXBsb3llZS8ke2VtcGxveWVlSWR9L2luY2VudGl2ZWAsXHJcbiAgICAgICAgeyBwYXJhbXM6IHsgc3RhcnRfZGF0ZSwgZW5kX2RhdGUgfSB9XHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5pbmNlbnRpdmVTdW1tYXJ5Py50b3RhbF9ncm91cF92YWx1ZSB8fCAwO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggaW5jZW50aXZlOlwiLCBlcnIpO1xyXG4gICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRWYWxpZE1vbnRocyA9IChqb2luaW5nRGF0ZVN0ciwgc2VsZWN0ZWRZZWFyKSA9PiB7XHJcbiAgICBpZiAoIWpvaW5pbmdEYXRlU3RyIHx8ICFzZWxlY3RlZFllYXIpIHtcclxuICAgICAgcmV0dXJuIG1vbnRocy5tYXAoKG0pID0+ICh7IC4uLm0sIGRpc2FibGVkOiB0cnVlIH0pKTtcclxuICAgIH1cclxuICAgIGNvbnN0IGpvaW5pbmcgPSBkYXlqcyhqb2luaW5nRGF0ZVN0cik7XHJcbiAgICBjb25zdCB0b2RheSA9IGRheWpzKCk7XHJcbiAgICBjb25zdCBqb2luWWVhciA9IGpvaW5pbmcueWVhcigpO1xyXG4gICAgY29uc3QgY3VycmVudFllYXIgPSB0b2RheS55ZWFyKCk7XHJcbiAgICBjb25zdCBzZWxlY3RlZFllYXJOdW0gPSBOdW1iZXIoc2VsZWN0ZWRZZWFyKTtcclxuICAgIHJldHVybiBtb250aHMubWFwKChtb250aCwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc3QgaXNCZWZvcmVKb2luaW5nID1cclxuICAgICAgICBzZWxlY3RlZFllYXJOdW0gPT09IGpvaW5ZZWFyICYmIGluZGV4IDwgam9pbmluZy5tb250aCgpO1xyXG4gICAgICBjb25zdCBpc0FmdGVyVG9kYXkgPVxyXG4gICAgICAgIHNlbGVjdGVkWWVhck51bSA9PT0gY3VycmVudFllYXIgJiYgaW5kZXggPiB0b2RheS5tb250aCgpO1xyXG4gICAgICBjb25zdCBkaXNhYmxlZCA9XHJcbiAgICAgICAgc2VsZWN0ZWRZZWFyTnVtIDwgam9pblllYXIgfHxcclxuICAgICAgICBzZWxlY3RlZFllYXJOdW0gPiBjdXJyZW50WWVhciB8fFxyXG4gICAgICAgIGlzQmVmb3JlSm9pbmluZyB8fFxyXG4gICAgICAgIGlzQWZ0ZXJUb2RheTtcclxuICAgICAgcmV0dXJuIHsgLi4ubW9udGgsIGRpc2FibGVkIH07XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBmb3JtRGF0YS5lbXBsb3llZV9pZCAmJlxyXG4gICAgICBmb3JtRGF0YS55ZWFyICYmXHJcbiAgICAgIGVtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlXHJcbiAgICApIHtcclxuICAgICAgY29uc3QgdmFsaWRNb250aHMgPSBnZXRWYWxpZE1vbnRocyhcclxuICAgICAgICBlbXBsb3llZURldGFpbHMuam9pbmluZ19kYXRlLFxyXG4gICAgICAgIGZvcm1EYXRhLnllYXJcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgY3VycmVudE1vbnRoVmFsaWQgPSB2YWxpZE1vbnRocy5zb21lKFxyXG4gICAgICAgIChtKSA9PiBtLnZhbHVlID09PSBmb3JtRGF0YS5tb250aCAmJiAhbS5kaXNhYmxlZFxyXG4gICAgICApO1xyXG4gICAgICBpZiAoIWN1cnJlbnRNb250aFZhbGlkKSB7XHJcbiAgICAgICAgY29uc3QgZmlyc3RWYWxpZCA9IHZhbGlkTW9udGhzLmZpbmQoKG0pID0+ICFtLmRpc2FibGVkKTtcclxuICAgICAgICBpZiAoZmlyc3RWYWxpZCkge1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIG1vbnRoOiBmaXJzdFZhbGlkLnZhbHVlLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0sIFtmb3JtRGF0YS55ZWFyLCBmb3JtRGF0YS5lbXBsb3llZV9pZCwgZW1wbG95ZWVEZXRhaWxzPy5qb2luaW5nX2RhdGVdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRWRpdCA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0VXBkYXRlTG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0SXNPcGVuVXBkYXRlTW9kYWwodHJ1ZSk7XHJcbiAgICAgIHNldElzRWRpdEZvcm1EaXJ0eShmYWxzZSk7XHJcbiAgICAgIGNvbnN0IHNhbGFyeURhdGEgPSBhd2FpdCBnZXRTYWxhcnlCeUlkKGlkKTtcclxuICAgICAgaWYgKHNhbGFyeURhdGEpIHtcclxuICAgICAgICBzZXRDdXJyZW50U2FsYXJ5SWQoaWQpO1xyXG4gICAgICAgIGNvbnN0IHllYXJBc0RheWpzID0gZGF5anMoc2FsYXJ5RGF0YS5zYWxhcnlfeWVhciwgXCJZWVlZXCIpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0ge1xyXG4gICAgICAgICAgZW1wbG95ZWVfaWQ6IHNhbGFyeURhdGE/LmVtcGxveWVlX2lkPy5faWQsXHJcbiAgICAgICAgICBtb250aDogc2FsYXJ5RGF0YT8uc2FsYXJ5X21vbnRoLFxyXG4gICAgICAgICAgeWVhcjogeWVhckFzRGF5anMsXHJcbiAgICAgICAgICBlYXJuaW5nczogc2FsYXJ5RGF0YT8uZWFybmluZ3MsXHJcbiAgICAgICAgICBkZWR1Y3Rpb25zOiBzYWxhcnlEYXRhPy5kZWR1Y3Rpb25zLFxyXG4gICAgICAgICAgYWRkaXRpb25hbF9wYXltZW50czogc2FsYXJ5RGF0YT8uYWRkaXRpb25hbF9wYXltZW50cyB8fCBbXSxcclxuICAgICAgICAgIGFkZGl0aW9uYWxfZGVkdWN0aW9uczogc2FsYXJ5RGF0YT8uYWRkaXRpb25hbF9kZWR1Y3Rpb25zIHx8IFtdLFxyXG4gICAgICAgICAgYWR2YW5jZV9wYXltZW50czogc2FsYXJ5RGF0YT8uYWR2YW5jZV9wYXltZW50cyB8fCBbXSxcclxuICAgICAgICAgIGNhbGN1bGF0ZWRfaW5jZW50aXZlOiBzYWxhcnlEYXRhPy5jYWxjdWxhdGVkX2luY2VudGl2ZSB8fCAwLFxyXG4gICAgICAgICAgdG90YWxfc2FsYXJ5X3BheWFibGU6IHNhbGFyeURhdGE/LnRvdGFsX3NhbGFyeV9wYXlhYmxlIHx8IDAsXHJcbiAgICAgICAgICBwYWlkX2Ftb3VudDogc2FsYXJ5RGF0YT8ucGFpZF9hbW91bnQgfHwgMCxcclxuICAgICAgICAgIHBheW1lbnRfbWV0aG9kOiBzYWxhcnlEYXRhPy5wYXltZW50X21ldGhvZCxcclxuICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBzYWxhcnlEYXRhPy50cmFuc2FjdGlvbl9pZCB8fCBcIlwiLFxyXG4gICAgICAgICAgcGF5X2RhdGU6IHNhbGFyeURhdGE/LnBheV9kYXRlXHJcbiAgICAgICAgICAgID8gbW9tZW50KHNhbGFyeURhdGE/LnBheV9kYXRlKVxyXG4gICAgICAgICAgICA6IG1vbWVudCgpLFxyXG4gICAgICAgICAgYXR0ZW5kYW5jZV9kZXRhaWxzOiBzYWxhcnlEYXRhPy5hdHRlbmRhbmNlX2RldGFpbHMgfHwge30sXHJcbiAgICAgICAgICBtb250aGx5X2J1c2luZXNzX2luZm86IHNhbGFyeURhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mbyB8fCB7XHJcbiAgICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgICAgLy8gcHJldmlvdXNfcmVtYWluaW5nX3RhcmdldDogMCxcclxuICAgICAgICAgICAgdG90YWxfdGFyZ2V0OiAwLFxyXG4gICAgICAgICAgICB0b3RhbF9idXNpbmVzc19jbG9zZWQ6IDAsXHJcbiAgICAgICAgICAgIGN1cnJlbnRfcmVtYWluaW5nX3RhcmdldDogMCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBzdGF0dXM6IHNhbGFyeURhdGE/LnN0YXR1cyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKGZvcm1EYXRhKTtcclxuICAgICAgICB1cGRhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKGZvcm1EYXRhKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBzYWxhcnkgZGV0YWlsc1wiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFVwZGF0ZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUNvbmZpcm0gPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldERlbGV0ZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGF3YWl0IEFQSS5kZWxldGUoYC9zYWxhcnktcGF5bWVudC8ke2lkfWApO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJTYWxhcnkgTWFuYWdlbWVudCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgc2V0RGVsZXRlTW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgZ2V0QWxsU2FsYXJ5KCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGRlbGV0ZSBTYWxhcnkgTWFuYWdlbWVudFwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldERlbGV0ZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlRmV0Y2hDb2xsZWN0aW9uSW5jZW50aXZlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0Q29sbGVjdGlvbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IG1vbnRoSW5kZXggPSBtb21lbnQoKS5tb250aChmb3JtRGF0YS5tb250aCkubW9udGgoKTtcclxuICAgICAgY29uc3Qgc3RhcnRfZGF0ZSA9IG1vbWVudCgpXHJcbiAgICAgICAgLnllYXIoZm9ybURhdGEueWVhcilcclxuICAgICAgICAubW9udGgobW9udGhJbmRleClcclxuICAgICAgICAuc3RhcnRPZihcIm1vbnRoXCIpXHJcbiAgICAgICAgLmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcbiAgICAgIGNvbnN0IGVuZF9kYXRlID0gbW9tZW50KClcclxuICAgICAgICAueWVhcihmb3JtRGF0YS55ZWFyKVxyXG4gICAgICAgIC5tb250aChtb250aEluZGV4KVxyXG4gICAgICAgIC5lbmRPZihcIm1vbnRoXCIpXHJcbiAgICAgICAgLmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXHJcbiAgICAgICAgYC9wYXltZW50L3BpZ215LWxvYW4vY29sbGVjdGlvbi8ke2Zvcm1EYXRhLmVtcGxveWVlX2lkfS9waWdteS1wZXJjLyR7Zm9ybURhdGEucGlnbXlfcGVyY30vbG9hbi1wZXJjLyR7Zm9ybURhdGEubG9hbl9wZXJjfWAsXHJcbiAgICAgICAgeyBwYXJhbXM6IHsgZnJvbV9kYXRlOiBzdGFydF9kYXRlLCB0b19kYXRlOiBlbmRfZGF0ZSB9IH1cclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHsgdG90YWxfbG9hbl9jb2xsZWN0aW9uc19wZXJjLCB0b3RhbF9waWdteV9jb2xsZWN0aW9uc19wZXJjIH0gPVxyXG4gICAgICAgIHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuXHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgbG9hbl9jb2xsZWN0aW9uX2luY2VudGl2ZTogdG90YWxfbG9hbl9jb2xsZWN0aW9uc19wZXJjIHx8IDAsXHJcbiAgICAgICAgcGlnbXlfY29sbGVjdGlvbl9pbmNlbnRpdmU6IHRvdGFsX3BpZ215X2NvbGxlY3Rpb25zX3BlcmMgfHwgMCxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0U2hvd0NvbGxlY3Rpb25Db250aW51ZShmYWxzZSk7IC8vIEhpZGUgYnV0dG9uIGFmdGVyIGZldGNoaW5nXHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIkNvbGxlY3Rpb24gZGF0YSBmZXRjaGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggY29sbGVjdGlvbiBkYXRhXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0Q29sbGVjdGlvbkxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlUHJpbnQgPSAoc2FsYXJ5UGF5bWVudElkKSA9PiB7XHJcbiAgICBuYXZpZ2F0ZShcIi9zYWxhcnktc2xpcC1wcmludC9cIiArIHNhbGFyeVBheW1lbnRJZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZHJvcERvd25JdGVtcyA9IChzYWxhcnlQYXltZW50KSA9PiB7XHJcbiAgICBjb25zdCBkcm9wRG93bkl0ZW1MaXN0ID0gW1xyXG4gICAgICB7XHJcbiAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBrZXk9e3NhbGFyeVBheW1lbnQ/Ll9pZH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVByaW50KHNhbGFyeVBheW1lbnQ/Ll9pZCl9PlxyXG4gICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAga2V5PXtzYWxhcnlQYXltZW50Py5faWR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRWRpdChzYWxhcnlQYXltZW50Ll9pZCl9PlxyXG4gICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBrZXk9e3NhbGFyeVBheW1lbnQ/Ll9pZH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldERlbGV0ZUlkKHNhbGFyeVBheW1lbnQ/Ll9pZCk7XHJcbiAgICAgICAgICAgICAgc2V0RGVsZXRlTW9kYWxPcGVuKHRydWUpO1xyXG4gICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuICAgIHJldHVybiBkcm9wRG93bkl0ZW1MaXN0O1xyXG4gIH07XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGZldGNoU2FsYXJ5RGV0YWlscygpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldEVtcGxveWVlRGV0YWlsc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IEFQSS5nZXQoYC9lbXBsb3llZS8ke2Zvcm1EYXRhLmVtcGxveWVlX2lkfWApO1xyXG4gICAgICBjb25zdCBlbXAgPSByZXNwb25zZURhdGE/LmRhdGE/LmRhdGE7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWRFYXJuaW5ncyA9IHtcclxuICAgICAgICAuLi5lYXJuaW5nc09iamVjdCxcclxuICAgICAgICAuLi5lbXA/LmVhcm5pbmdzLFxyXG4gICAgICAgIHNhbGFyeTogZW1wPy5zYWxhcnkgfHwgMCxcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgdXBkYXRlZERlZHVjdGlvbnMgPSB7XHJcbiAgICAgICAgLi4uZGVkdWN0aW9uc09iamVjdCxcclxuICAgICAgICAuLi5lbXA/LmRlZHVjdGlvbnMsXHJcbiAgICAgIH07XHJcbiAgICAgIHNldEVtcGxveWVlRGV0YWlscyhlbXApO1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIGVhcm5pbmdzOiB1cGRhdGVkRWFybmluZ3MsXHJcbiAgICAgICAgZGVkdWN0aW9uczogdXBkYXRlZERlZHVjdGlvbnMsXHJcbiAgICAgICAgdG90YWxfc2FsYXJ5OiBlbXA/LnNhbGFyeSB8fCAwLFxyXG4gICAgICB9KSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRFbXBsb3llZURldGFpbHMoe30pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RW1wbG95ZWVEZXRhaWxzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGZvcm1EYXRhLmVtcGxveWVlX2lkICYmIGZvcm1EYXRhLm1vbnRoICYmIGZvcm1EYXRhLnllYXIpIHtcclxuICAgICAgbG9hZFRhcmdldEFuZEluY2VudGl2ZSgpO1xyXG4gICAgICBmZXRjaFNhbGFyeURldGFpbHMoKTtcclxuICAgIH1cclxuICB9LCBbZm9ybURhdGEuZW1wbG95ZWVfaWQsIGZvcm1EYXRhLm1vbnRoLCBmb3JtRGF0YS55ZWFyXSk7XHJcblxyXG4gIGNvbnN0IGxvYWRUYXJnZXRBbmRJbmNlbnRpdmUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0J1c2luZXNzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgbW9udGhJbmRleCA9IG1vbWVudCgpLm1vbnRoKGZvcm1EYXRhLm1vbnRoKS5tb250aCgpO1xyXG4gICAgICBjb25zdCB5ZWFyID0gZm9ybURhdGEueWVhcjtcclxuICAgICAgY29uc3Qgc3RhcnRfZGF0ZSA9IG1vbWVudCgpXHJcbiAgICAgICAgLnllYXIoeWVhcilcclxuICAgICAgICAubW9udGgobW9udGhJbmRleClcclxuICAgICAgICAuc3RhcnRPZihcIm1vbnRoXCIpXHJcbiAgICAgICAgLmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcbiAgICAgIGNvbnN0IGVuZF9kYXRlID0gbW9tZW50KClcclxuICAgICAgICAueWVhcih5ZWFyKVxyXG4gICAgICAgIC5tb250aChtb250aEluZGV4KVxyXG4gICAgICAgIC5lbmRPZihcIm1vbnRoXCIpXHJcbiAgICAgICAgLmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcbiAgICAgIGNvbnN0IHRhcmdldFZhbHVlID0gYXdhaXQgZmV0Y2hFbXBsb3llZVRhcmdldChcclxuICAgICAgICBmb3JtRGF0YS5lbXBsb3llZV9pZCxcclxuICAgICAgICBzdGFydF9kYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGJ1c2luZXNzQ2xvc2VkVmFsdWUgPSBhd2FpdCBmZXRjaEVtcGxveWVlQnVzaW5lc3NDbG9zZWQoXHJcbiAgICAgICAgZm9ybURhdGEuZW1wbG95ZWVfaWQsXHJcbiAgICAgICAgc3RhcnRfZGF0ZSxcclxuICAgICAgICBlbmRfZGF0ZVxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBlbXBsb3llZVByZXZpb3VzUmVtYWluaW5nVGFyZ2V0ID1cclxuICAgICAgICBhd2FpdCBmZXRjaFByZXZpb3VzUmVtYWluaW5nVGFyZ2V0KGZvcm1EYXRhLmVtcGxveWVlX2lkKTtcclxuICAgICAgYXdhaXQgZmV0Y2hBZGRpdGlvbmFsU2FsYXJ5UGF5bWVudHMoZm9ybURhdGEuZW1wbG95ZWVfaWQpO1xyXG4gICAgICBjb25zdCB0b3RhbFRhcmdldCA9XHJcbiAgICAgICAgKHRhcmdldFZhbHVlIHx8IDApICsgKGVtcGxveWVlUHJldmlvdXNSZW1haW5pbmdUYXJnZXQgfHwgMCk7XHJcbiAgICAgIGNvbnN0IHJlbWFpbmluZ1RhcmdldCA9ICh0b3RhbFRhcmdldCB8fCAwKSAtIChidXNpbmVzc0Nsb3NlZFZhbHVlIHx8IDApO1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIG1vbnRobHlfYnVzaW5lc3NfaW5mbzoge1xyXG4gICAgICAgICAgdGFyZ2V0OiB0YXJnZXRWYWx1ZSA/PyAwLFxyXG4gICAgICAgICAgLy8gcHJldmlvdXNfcmVtYWluaW5nX3RhcmdldDogZW1wbG95ZWVQcmV2aW91c1JlbWFpbmluZ1RhcmdldCA/PyAwLFxyXG4gICAgICAgICAgdG90YWxfdGFyZ2V0OiB0b3RhbFRhcmdldCA/PyAwLFxyXG4gICAgICAgICAgdG90YWxfYnVzaW5lc3NfY2xvc2VkOiBidXNpbmVzc0Nsb3NlZFZhbHVlID8/IDAsXHJcbiAgICAgICAgICBjdXJyZW50X3JlbWFpbmluZ190YXJnZXQ6IHJlbWFpbmluZ1RhcmdldCA/PyAwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGF1dG8tbG9hZCB0YXJnZXQgJiBpbmNlbnRpdmVcIiwgZXJyKTtcclxuICAgIH1cclxuICAgIGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0J1c2luZXNzTG9hZGluZyhmYWxzZSk7IC8vIOKchSBTdG9wIGxvYWRlciAoYWx3YXlzIHJ1bnMpXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmb3JtRGF0YS5lbXBsb3llZV9pZCkge1xyXG4gICAgICBmZXRjaFNhbGFyeURldGFpbHMoKTtcclxuICAgIH1cclxuICB9LCBbZm9ybURhdGE/LmVtcGxveWVlX2lkXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG5cclxuICAgIGlmIChuYW1lID09PSBcImFtb3VudFwiKSB7XHJcbiAgICAgIC8vIEFsbG93IG9ubHkgZGlnaXRzICYgb25lIGRvdFxyXG4gICAgICBsZXQgY2xlYW5lZCA9IHZhbHVlLnJlcGxhY2UoL1teMC05Ll0vZywgXCJcIik7XHJcbiAgICAgIGNvbnN0IGRvdENvdW50ID0gKGNsZWFuZWQubWF0Y2goL1xcLi9nKSB8fCBbXSkubGVuZ3RoO1xyXG4gICAgICBpZiAoZG90Q291bnQgPiAxKSByZXR1cm47XHJcblxyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIGFkdmFuY2VfcmVwYXltZW50OiB7XHJcbiAgICAgICAgICAuLi5wcmV2LmFkdmFuY2VfcmVwYXltZW50LFxyXG4gICAgICAgICAgW25hbWVdOiBjbGVhbmVkLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBGb3Igb3RoZXIgZmllbGRzIGluc2lkZSBhZHZhbmNlX3JlcGF5bWVudFxyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIGFkdmFuY2VfcmVwYXltZW50OiB7XHJcbiAgICAgICAgLi4ucHJldi5hZHZhbmNlX3JlcGF5bWVudCxcclxuICAgICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgICB9LFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChuYW1lLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+IHtcclxuICAgICAgbGV0IHVwZGF0ZWRGb3JtRGF0YSA9IHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9O1xyXG5cclxuICAgICAgLy8gUmVzZXQgY2FsY3VsYXRlZF9pbmNlbnRpdmUgd2hlbiBtb250aCBjaGFuZ2VzXHJcbiAgICAgIGlmIChuYW1lID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgICB1cGRhdGVkRm9ybURhdGEgPSB7XHJcbiAgICAgICAgICAuLi51cGRhdGVkRm9ybURhdGEsXHJcbiAgICAgICAgICBjYWxjdWxhdGVkX2luY2VudGl2ZTogMCxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoW1wiZW1wbG95ZWVfaWRcIiwgXCJtb250aFwiLCBcInllYXJcIiwgXCJ0YXJnZXRcIl0uaW5jbHVkZXMobmFtZSkpIHtcclxuICAgICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KG51bGwpO1xyXG4gICAgICAgIHNldFNob3dDb21wb25lbnRzKGZhbHNlKTtcclxuICAgICAgICB1cGRhdGVkRm9ybURhdGEgPSB7XHJcbiAgICAgICAgICAuLi51cGRhdGVkRm9ybURhdGEsXHJcbiAgICAgICAgICBwYWlkX2Ftb3VudDogMCxcclxuICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICAgICAgcGF5bWVudF9tZXRob2Q6IFwiXCIsXHJcbiAgICAgICAgICAvLyBSZXNldCBhZHZhbmNlX3JlcGF5bWVudCBmaWVsZHNcclxuICAgICAgICAgIGFkdmFuY2VfcmVwYXltZW50OiB7XHJcbiAgICAgICAgICAgIHBheV9kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICBhbW91bnQ6IDAsXHJcbiAgICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICByZW1hcmtzOiBcIlwiLFxyXG4gICAgICAgICAgICBjaGVxdWVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgICAgICBjaGVxdWVfZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgY2hlcXVlX2JhbmtfbmFtZTogXCJcIixcclxuICAgICAgICAgICAgY2hlcXVlX2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gdXBkYXRlZEZvcm1EYXRhO1xyXG4gICAgfSk7XHJcbiAgICBzZXRBZGRpdGlvbmFsU2FsYXJ5RGV0YWlscyhbXSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVkdWN0aW9uc0NoYW5nZSA9IChuYW1lLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIGVhcm5pbmdzOiB7IC4uLnByZXYuZWFybmluZ3MgfSxcclxuICAgICAgZGVkdWN0aW9uczogeyAuLi5wcmV2LmRlZHVjdGlvbnMsIFtuYW1lXTogdmFsdWUgfSxcclxuICAgICAgcGFpZF9hbW91bnQ6IDAsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICBwYXltZW50X21ldGhvZDogXCJcIixcclxuICAgIH0pKTtcclxuICAgIHNldENhbGN1bGF0ZWRTYWxhcnkobnVsbCk7XHJcbiAgICBzZXRTaG93Q29tcG9uZW50cyhmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRWFybmluZ3NDaGFuZ2UgPSAobmFtZSwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBlYXJuaW5nczogeyAuLi5wcmV2LmVhcm5pbmdzLCBbbmFtZV06IHZhbHVlIH0sXHJcbiAgICAgIGRlZHVjdGlvbnM6IHsgLi4ucHJldi5kZWR1Y3Rpb25zIH0sXHJcbiAgICAgIHBhaWRfYW1vdW50OiAwLFxyXG4gICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgcGF5bWVudF9tZXRob2Q6IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KG51bGwpO1xyXG4gICAgc2V0U2hvd0NvbXBvbmVudHMoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkdmFuY2VQYXltZW50Q2hhbmdlID0gKGluZGV4LCBmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIGNvbnN0IHVwZGF0ZWRQYXltZW50cyA9IFsuLi5mb3JtRGF0YS5hZHZhbmNlX3BheW1lbnRzXTtcclxuICAgIHVwZGF0ZWRQYXltZW50c1tpbmRleF0gPSB7IC4uLnVwZGF0ZWRQYXltZW50c1tpbmRleF0sIFtmaWVsZF06IHZhbHVlIH07XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgYWR2YW5jZV9wYXltZW50czogdXBkYXRlZFBheW1lbnRzIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBhZGRBZHZhbmNlUGF5bWVudCA9ICgpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBhZHZhbmNlX3BheW1lbnRzOiBbLi4ucHJldi5hZHZhbmNlX3BheW1lbnRzLCB7IG5hbWU6IFwiXCIsIHZhbHVlOiAwIH1dLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZUFkdmFuY2VQYXltZW50ID0gKGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCB1cGRhdGVkUGF5bWVudHMgPSBmb3JtRGF0YS5hZHZhbmNlX3BheW1lbnRzLmZpbHRlcihcclxuICAgICAgKF8sIGkpID0+IGkgIT09IGluZGV4XHJcbiAgICApO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIGFkdmFuY2VfcGF5bWVudHM6IHVwZGF0ZWRQYXltZW50cyB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWRkaXRpb25hbFBheW1lbnRDaGFuZ2UgPSAoaW5kZXgsIGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgY29uc3QgdXBkYXRlZFBheW1lbnRzID0gWy4uLmZvcm1EYXRhLmFkZGl0aW9uYWxfcGF5bWVudHNdO1xyXG4gICAgdXBkYXRlZFBheW1lbnRzW2luZGV4XSA9IHsgLi4udXBkYXRlZFBheW1lbnRzW2luZGV4XSwgW2ZpZWxkXTogdmFsdWUgfTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhZGRpdGlvbmFsX3BheW1lbnRzOiB1cGRhdGVkUGF5bWVudHMgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFkZEFkZGl0aW9uYWxQYXltZW50ID0gKCkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIGFkZGl0aW9uYWxfcGF5bWVudHM6IFtcclxuICAgICAgICAuLi5wcmV2LmFkZGl0aW9uYWxfcGF5bWVudHMsXHJcbiAgICAgICAgeyBuYW1lOiBcIlwiLCB2YWx1ZTogMCB9LFxyXG4gICAgICBdLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZUFkZGl0aW9uYWxQYXltZW50ID0gKGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCB1cGRhdGVkUGF5bWVudHMgPSBmb3JtRGF0YS5hZGRpdGlvbmFsX3BheW1lbnRzLmZpbHRlcihcclxuICAgICAgKF8sIGkpID0+IGkgIT09IGluZGV4XHJcbiAgICApO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIGFkZGl0aW9uYWxfcGF5bWVudHM6IHVwZGF0ZWRQYXltZW50cyB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWRkaXRpb25hbERlZHVjdGlvbkNoYW5nZSA9IChpbmRleCwgZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBjb25zdCB1cGRhdGVkRGVkdWN0aW9ucyA9IFsuLi5mb3JtRGF0YS5hZGRpdGlvbmFsX2RlZHVjdGlvbnNdO1xyXG4gICAgdXBkYXRlZERlZHVjdGlvbnNbaW5kZXhdID0geyAuLi51cGRhdGVkRGVkdWN0aW9uc1tpbmRleF0sIFtmaWVsZF06IHZhbHVlIH07XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgYWRkaXRpb25hbF9kZWR1Y3Rpb25zOiB1cGRhdGVkRGVkdWN0aW9ucyxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBhZGRBZGRpdGlvbmFsRGVkdWN0aW9uID0gKCkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIGFkZGl0aW9uYWxfZGVkdWN0aW9uczogW1xyXG4gICAgICAgIC4uLnByZXYuYWRkaXRpb25hbF9kZWR1Y3Rpb25zLFxyXG4gICAgICAgIHsgbmFtZTogXCJcIiwgdmFsdWU6IDAgfSxcclxuICAgICAgXSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCByZW1vdmVBZGRpdGlvbmFsRGVkdWN0aW9uID0gKGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCB1cGRhdGVkRGVkdWN0aW9ucyA9IGZvcm1EYXRhLmFkZGl0aW9uYWxfZGVkdWN0aW9ucy5maWx0ZXIoXHJcbiAgICAgIChfLCBpKSA9PiBpICE9PSBpbmRleFxyXG4gICAgKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBhZGRpdGlvbmFsX2RlZHVjdGlvbnM6IHVwZGF0ZWREZWR1Y3Rpb25zLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHVwZGF0ZVRvdGFsRWFybmluZ3MgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGVhcm5pbmdzID0gdXBkYXRlRm9ybURhdGE/LmVhcm5pbmdzIHx8IHt9O1xyXG4gICAgcmV0dXJuIE9iamVjdC52YWx1ZXMoZWFybmluZ3MpLnJlZHVjZSgoc3VtLCB2KSA9PiBzdW0gKyBOdW1iZXIodiB8fCAwKSwgMCk7XHJcbiAgfSwgW3VwZGF0ZUZvcm1EYXRhXSk7XHJcblxyXG4gIGNvbnN0IHVwZGF0ZVRvdGFsRGVkdWN0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZGVkdWN0aW9ucyA9IHVwZGF0ZUZvcm1EYXRhPy5kZWR1Y3Rpb25zIHx8IHt9O1xyXG4gICAgY29uc3QgYmFzZSA9IE9iamVjdC52YWx1ZXMoZGVkdWN0aW9ucykucmVkdWNlKFxyXG4gICAgICAoc3VtLCB2KSA9PiBzdW0gKyBOdW1iZXIodiB8fCAwKSxcclxuICAgICAgMFxyXG4gICAgKTtcclxuICAgIHJldHVybiBiYXNlO1xyXG4gIH0sIFt1cGRhdGVGb3JtRGF0YV0pO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVDYWxjdWxhdGVTYWxhcnkoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRDYWxjdWxhdGVMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgLy8gUmVzZXQgc3BlY2lmaWMgZHluYW1pYyBmaWVsZHNcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBhZGRpdGlvbmFsX3BheW1lbnRzOiBbXSxcclxuICAgICAgICBhZGRpdGlvbmFsX2RlZHVjdGlvbnM6IFtdLFxyXG4gICAgICAgIGFkdmFuY2VfcGF5bWVudHM6IFtdLFxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICAvLyAxLiBQcmVwYXJlIERhdGVzIGZvciBDb2xsZWN0aW9uIEFQSVxyXG4gICAgICBjb25zdCBtb250aEluZGV4ID0gbW9tZW50KCkubW9udGgoZm9ybURhdGEubW9udGgpLm1vbnRoKCk7XHJcbiAgICAgIGNvbnN0IHN0YXJ0X2RhdGUgPSBtb21lbnQoKS55ZWFyKGZvcm1EYXRhLnllYXIpLm1vbnRoKG1vbnRoSW5kZXgpLnN0YXJ0T2YoXCJtb250aFwiKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG4gICAgICBjb25zdCBlbmRfZGF0ZSA9IG1vbWVudCgpLnllYXIoZm9ybURhdGEueWVhcikubW9udGgobW9udGhJbmRleCkuZW5kT2YoXCJtb250aFwiKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG5cclxuICAgICAgLy8gMi4gUnVuIGJvdGggQVBJIGNhbGxzIGluIHBhcmFsbGVsIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2VcclxuICAgICAgY29uc3QgW3NhbGFyeVJlcywgY29sbGVjdGlvblJlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgQVBJLmdldChcIi9zYWxhcnktcGF5bWVudC9jYWxjdWxhdGVcIiwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgIGVtcGxveWVlX2lkOiBmb3JtRGF0YS5lbXBsb3llZV9pZCxcclxuICAgICAgICAgICAgbW9udGg6IGZvcm1EYXRhLm1vbnRoLFxyXG4gICAgICAgICAgICB5ZWFyOiBmb3JtRGF0YS55ZWFyLFxyXG4gICAgICAgICAgICBlYXJuaW5nczogZm9ybURhdGEuZWFybmluZ3MsXHJcbiAgICAgICAgICAgIGRlZHVjdGlvbnM6IGZvcm1EYXRhLmRlZHVjdGlvbnMsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIEFQSS5nZXQoXHJcbiAgICAgICAgICBgL3BheW1lbnQvcGlnbXktbG9hbi9jb2xsZWN0aW9uLyR7Zm9ybURhdGEuZW1wbG95ZWVfaWR9L3BpZ215LXBlcmMvJHtmb3JtRGF0YS5waWdteV9wZXJjfS9sb2FuLXBlcmMvJHtmb3JtRGF0YS5sb2FuX3BlcmN9YCxcclxuICAgICAgICAgIHsgcGFyYW1zOiB7IGZyb21fZGF0ZTogc3RhcnRfZGF0ZSwgdG9fZGF0ZTogZW5kX2RhdGUgfSB9XHJcbiAgICAgICAgKVxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIGNvbnN0IGNhbGN1bGF0ZWQgPSBzYWxhcnlSZXMuZGF0YS5kYXRhO1xyXG4gICAgICBjb25zdCB7IHRvdGFsX2xvYW5fY29sbGVjdGlvbnNfcGVyYywgdG90YWxfcGlnbXlfY29sbGVjdGlvbnNfcGVyYyB9ID0gY29sbGVjdGlvblJlcy5kYXRhLmRhdGE7XHJcblxyXG4gICAgICAvLyAzLiBVcGRhdGUgc3RhdGUgd2l0aCBhbGwgcmVzdWx0c1xyXG4gICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KGNhbGN1bGF0ZWQpO1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRvdGFsX3NhbGFyeV9wYXlhYmxlOiBjYWxjdWxhdGVkLmNhbGN1bGF0ZWRfc2FsYXJ5LFxyXG4gICAgICAgIGxvYW5fY29sbGVjdGlvbl9pbmNlbnRpdmU6IHRvdGFsX2xvYW5fY29sbGVjdGlvbnNfcGVyYyB8fCAwLFxyXG4gICAgICAgIHBpZ215X2NvbGxlY3Rpb25faW5jZW50aXZlOiB0b3RhbF9waWdteV9jb2xsZWN0aW9uc19wZXJjIHx8IDAsXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAgIHNldFNob3dDb21wb25lbnRzKHRydWUpO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJTYWxhcnkgYW5kIENvbGxlY3Rpb25zIGNhbGN1bGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIGNhbGN1bGF0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChlcnJvci5yZXNwb25zZT8uc3RhdHVzID09PSA0MDYgJiYgZXJyb3IucmVzcG9uc2U/LmRhdGE/LmV4aXN0aW5nX3NhbGFyeSkge1xyXG4gICAgICAgIHNldEV4aXN0aW5nU2FsYXJ5UmVjb3JkKGVycm9yLnJlc3BvbnNlLmRhdGEuZXhpc3Rpbmdfc2FsYXJ5KTtcclxuICAgICAgICBzZXRBbHJlYWR5UGFpZE1vZGFsT3Blbih0cnVlKTtcclxuICAgICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KG51bGwpO1xyXG4gICAgICAgIHNldFNob3dDb21wb25lbnRzKGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgICAgbWVzc2FnZS5lcnJvcihlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBjYWxjdWxhdGUgZGV0YWlsc1wiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldENhbGN1bGF0ZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlQWRkU2FsYXJ5KCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgYmFzZVNhbGFyeSA9IGNhbGN1bGF0ZWRTYWxhcnlcclxuICAgICAgICA/IGNhbGN1bGF0ZWRTYWxhcnkuY2FsY3VsYXRlZF9zYWxhcnlcclxuICAgICAgICA6IE9iamVjdC52YWx1ZXMoZm9ybURhdGEuZWFybmluZ3MpLnJlZHVjZShcclxuICAgICAgICAgIChzdW0sIHYpID0+IHN1bSArIE51bWJlcih2IHx8IDApLFxyXG4gICAgICAgICAgMFxyXG4gICAgICAgICkgLVxyXG4gICAgICAgIE9iamVjdC52YWx1ZXMoZm9ybURhdGEuZGVkdWN0aW9ucykucmVkdWNlKFxyXG4gICAgICAgICAgKHN1bSwgdikgPT4gc3VtICsgTnVtYmVyKHYgfHwgMCksXHJcbiAgICAgICAgICAwXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IGFkdmFuY2VUb3RhbCA9IGZvcm1EYXRhLmFkdmFuY2VfcGF5bWVudHMucmVkdWNlKFxyXG4gICAgICAgIChzdW0sIGEpID0+IHN1bSArIE51bWJlcihhLnZhbHVlIHx8IDApLFxyXG4gICAgICAgIDBcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgYWRkaXRpb25hbFBheW1lbnRzVG90YWwgPSBmb3JtRGF0YS5hZGRpdGlvbmFsX3BheW1lbnRzLnJlZHVjZShcclxuICAgICAgICAoc3VtLCBwYXltZW50KSA9PiBzdW0gKyBOdW1iZXIocGF5bWVudC52YWx1ZSB8fCAwKSxcclxuICAgICAgICAwXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGFkZGl0aW9uYWxEZWR1Y3Rpb25zVG90YWwgPSBmb3JtRGF0YS5hZGRpdGlvbmFsX2RlZHVjdGlvbnMucmVkdWNlKFxyXG4gICAgICAgIChzdW0sIGRlZHVjdGlvbikgPT4gc3VtICsgTnVtYmVyKGRlZHVjdGlvbi52YWx1ZSB8fCAwKSxcclxuICAgICAgICAwXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBBcHBseSBidXNpbmVzcyBjb25kaXRpb24gLSBOZXcgbG9naWMgYWNjb3JkaW5nIHRvIHJlcXVpcmVtZW50c1xyXG4gICAgICBsZXQgdG90YWxTYWxhcnlQYXlhYmxlID0gMDtcclxuICAgICAgbGV0IGZpbmFsQ2FsY3VsYXRlZEluY2VudGl2ZSA9IGZvcm1EYXRhLmNhbGN1bGF0ZWRfaW5jZW50aXZlIHx8IDA7XHJcblxyXG4gICAgICBjb25zdCB0b3RhbFRhcmdldCA9IE51bWJlcihcclxuICAgICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfdGFyZ2V0IHx8IDBcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgdG90YWxCdXNpbmVzc0Nsb3NlZCA9IE51bWJlcihcclxuICAgICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfYnVzaW5lc3NfY2xvc2VkIHx8IDBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIC8vIENhbGN1bGF0ZSByYXcgaW5jZW50aXZlXHJcbiAgICAgIGNvbnN0IHJhd0luY2VudGl2ZSA9ICh0b3RhbFRhcmdldCAtIHRvdGFsQnVzaW5lc3NDbG9zZWQpIC8gMTAwO1xyXG5cclxuICAgICAgaWYgKHJhd0luY2VudGl2ZSA+IDApIHtcclxuICAgICAgICB0b3RhbFNhbGFyeVBheWFibGUgPSAwO1xyXG4gICAgICAgIHRvdGFsU2FsYXJ5UGF5YWJsZSArPSBhZHZhbmNlVG90YWw7XHJcbiAgICAgICAgdG90YWxTYWxhcnlQYXlhYmxlICs9XHJcbiAgICAgICAgICBhZGRpdGlvbmFsUGF5bWVudHNUb3RhbCAtIGFkZGl0aW9uYWxEZWR1Y3Rpb25zVG90YWw7XHJcbiAgICAgICAgdG90YWxTYWxhcnlQYXlhYmxlIC09IHRvdGFsRGVkdWN0aW9ucztcclxuICAgICAgfSBlbHNlIGlmIChyYXdJbmNlbnRpdmUgPCAwKSB7XHJcbiAgICAgICAgdG90YWxTYWxhcnlQYXlhYmxlID0gYmFzZVNhbGFyeTtcclxuICAgICAgICB0b3RhbFNhbGFyeVBheWFibGUgKz0gYWR2YW5jZVRvdGFsO1xyXG4gICAgICAgIHRvdGFsU2FsYXJ5UGF5YWJsZSArPVxyXG4gICAgICAgICAgYWRkaXRpb25hbFBheW1lbnRzVG90YWwgLSBhZGRpdGlvbmFsRGVkdWN0aW9uc1RvdGFsO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRvdGFsU2FsYXJ5UGF5YWJsZSA9IGJhc2VTYWxhcnk7XHJcbiAgICAgICAgdG90YWxTYWxhcnlQYXlhYmxlICs9IGFkdmFuY2VUb3RhbDtcclxuICAgICAgICB0b3RhbFNhbGFyeVBheWFibGUgKz1cclxuICAgICAgICAgIGFkZGl0aW9uYWxQYXltZW50c1RvdGFsIC0gYWRkaXRpb25hbERlZHVjdGlvbnNUb3RhbDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gQWRkIGNhbGN1bGF0ZWQgaW5jZW50aXZlIGlmIGl0J3MgYmVlbiBzZXQgKFBheSBhcyBJbmNlbnRpdmUgd2FzIGNvbmZpcm1lZClcclxuICAgICAgLy8gdG90YWxTYWxhcnlQYXlhYmxlICs9IGZpbmFsQ2FsY3VsYXRlZEluY2VudGl2ZTtcclxuXHJcbiAgICAgIGNvbnN0IHBhaWRBbW91bnQgPSBOdW1iZXIoZm9ybURhdGEucGFpZF9hbW91bnQgfHwgMCk7XHJcbiAgICAgIGNvbnN0IHJlbWFpbmluZ0JhbGFuY2UgPSB0b3RhbFNhbGFyeVBheWFibGUgLSBwYWlkQW1vdW50O1xyXG5cclxuICAgICAgY29uc3QgYXR0ZW5kYW5jZURldGFpbHMgPSBjYWxjdWxhdGVkU2FsYXJ5XHJcbiAgICAgICAgPyB7XHJcbiAgICAgICAgICB0b3RhbF9kYXlzOiBjYWxjdWxhdGVkU2FsYXJ5LnRvdGFsX2RheXMsXHJcbiAgICAgICAgICBwcmVzZW50X2RheXM6IGNhbGN1bGF0ZWRTYWxhcnkucHJlc2VudF9kYXlzLFxyXG4gICAgICAgICAgcGFpZF9kYXlzOiBjYWxjdWxhdGVkU2FsYXJ5LnBhaWRfZGF5cyxcclxuICAgICAgICAgIGxvcF9kYXlzOiBjYWxjdWxhdGVkU2FsYXJ5LmxvcF9kYXlzLFxyXG4gICAgICAgICAgbG9wOiBjYWxjdWxhdGVkU2FsYXJ5LmxvcCxcclxuICAgICAgICAgIHBlcl9kYXlfc2FsYXJ5OiBjYWxjdWxhdGVkU2FsYXJ5LnBlcl9kYXlfc2FsYXJ5LFxyXG4gICAgICAgICAgY2FsY3VsYXRlZF9zYWxhcnk6IGNhbGN1bGF0ZWRTYWxhcnkuY2FsY3VsYXRlZF9zYWxhcnksXHJcbiAgICAgICAgICBhYnNlbnRfZGF5czogY2FsY3VsYXRlZFNhbGFyeS5hYnNlbnRfZGF5cyB8fCAwLFxyXG4gICAgICAgICAgbGVhdmVfZGF5czogY2FsY3VsYXRlZFNhbGFyeS5sZWF2ZV9kYXlzIHx8IDAsXHJcbiAgICAgICAgICBoYWxmX2RheXM6IGNhbGN1bGF0ZWRTYWxhcnkuaGFsZl9kYXlzIHx8IDAsXHJcbiAgICAgICAgICBzYWxhcnlfZnJvbV9kYXRlOiBjYWxjdWxhdGVkU2FsYXJ5LnNhbGFyeV9mcm9tX2RhdGUsXHJcbiAgICAgICAgICBzYWxhcnlfdG9fZGF0ZTogY2FsY3VsYXRlZFNhbGFyeS5zYWxhcnlfdG9fZGF0ZSxcclxuICAgICAgICB9XHJcbiAgICAgICAgOiB7fTtcclxuXHJcbiAgICAgIGNvbnN0IG1vbnRobHlUYXJnZXRJbmNlbnRpdmUgPSB7XHJcbiAgICAgICAgdGFyZ2V0OiBOdW1iZXIoZm9ybURhdGEubW9udGhseV9idXNpbmVzc19pbmZvLnRhcmdldCB8fCAwKSxcclxuICAgICAgICB0b3RhbF9idXNpbmVzc19jbG9zZWQ6IE51bWJlcihcclxuICAgICAgICAgIGZvcm1EYXRhLm1vbnRobHlfYnVzaW5lc3NfaW5mby50b3RhbF9idXNpbmVzc19jbG9zZWQgfHwgMFxyXG4gICAgICAgICksXHJcbiAgICAgICAgLy8gcHJldmlvdXNfcmVtYWluaW5nX3RhcmdldDpcclxuICAgICAgICAvLyAgIGZvcm1EYXRhLm1vbnRobHlfYnVzaW5lc3NfaW5mby5wcmV2aW91c19yZW1haW5pbmdfdGFyZ2V0LFxyXG4gICAgICAgIHRvdGFsX3RhcmdldDogZm9ybURhdGEubW9udGhseV9idXNpbmVzc19pbmZvLnRvdGFsX3RhcmdldCxcclxuICAgICAgICBjdXJyZW50X3JlbWFpbmluZ190YXJnZXQ6XHJcbiAgICAgICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8uY3VycmVudF9yZW1haW5pbmdfdGFyZ2V0LFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3Qgc2FsYXJ5RGF0YSA9IHtcclxuICAgICAgICBlbXBsb3llZV9pZDogZm9ybURhdGE/LmVtcGxveWVlX2lkLFxyXG4gICAgICAgIGFkZGl0aW9uYWxfc2FsYXJpZXM6IGFkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy5hZGRpdGlvbmFsX3NhbGFyaWVzIHx8IFtdLFxyXG4gICAgICAgIGFkdmFuY2VfcmVwYXltZW50OiBmb3JtRGF0YS5hZHZhbmNlX3JlcGF5bWVudCxcclxuICAgICAgICBzYWxhcnlfZnJvbV9kYXRlOiBjYWxjdWxhdGVkU2FsYXJ5XHJcbiAgICAgICAgICA/IGNhbGN1bGF0ZWRTYWxhcnk/LnNhbGFyeV9mcm9tX2RhdGVcclxuICAgICAgICAgIDogbmV3IERhdGUoKSxcclxuICAgICAgICBzYWxhcnlfdG9fZGF0ZTogY2FsY3VsYXRlZFNhbGFyeVxyXG4gICAgICAgICAgPyBjYWxjdWxhdGVkU2FsYXJ5LnNhbGFyeV90b19kYXRlXHJcbiAgICAgICAgICA6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgc2FsYXJ5X21vbnRoOiBmb3JtRGF0YS5tb250aCxcclxuICAgICAgICBzYWxhcnlfeWVhcjogZm9ybURhdGEueWVhcixcclxuICAgICAgICBlYXJuaW5nczogZm9ybURhdGEuZWFybmluZ3MsXHJcbiAgICAgICAgZGVkdWN0aW9uczogZm9ybURhdGEuZGVkdWN0aW9ucyxcclxuICAgICAgICBhZGRpdGlvbmFsX3BheW1lbnRzOiBmb3JtRGF0YS5hZGRpdGlvbmFsX3BheW1lbnRzLFxyXG4gICAgICAgIGFkZGl0aW9uYWxfZGVkdWN0aW9uczogZm9ybURhdGEuYWRkaXRpb25hbF9kZWR1Y3Rpb25zLFxyXG4gICAgICAgIGFkdmFuY2VfcGF5bWVudHM6IGZvcm1EYXRhLmFkdmFuY2VfcGF5bWVudHMsXHJcbiAgICAgICAgY2FsY3VsYXRlZF9pbmNlbnRpdmU6IGZpbmFsQ2FsY3VsYXRlZEluY2VudGl2ZSxcclxuICAgICAgICBwYWlkX2RheXM6IGNhbGN1bGF0ZWRTYWxhcnkgPyBjYWxjdWxhdGVkU2FsYXJ5LnBhaWRfZGF5cyA6IDMwLFxyXG4gICAgICAgIGxvcDogY2FsY3VsYXRlZFNhbGFyeSA/IGNhbGN1bGF0ZWRTYWxhcnkubG9wIDogMCxcclxuICAgICAgICBsb3BfZGF5czogY2FsY3VsYXRlZFNhbGFyeSA/IGNhbGN1bGF0ZWRTYWxhcnkubG9wX2RheXMgOiAwLFxyXG4gICAgICAgIG5ldF9wYXlhYmxlOiB0b3RhbFNhbGFyeVBheWFibGUsXHJcbiAgICAgICAgcGFpZF9hbW91bnQ6IHBhaWRBbW91bnQsXHJcbiAgICAgICAgcmVtYWluaW5nX2JhbGFuY2U6IHJlbWFpbmluZ0JhbGFuY2UsXHJcbiAgICAgICAgdG90YWxfc2FsYXJ5X3BheWFibGU6IHRvdGFsU2FsYXJ5UGF5YWJsZSxcclxuICAgICAgICBwYXltZW50X21ldGhvZDogZm9ybURhdGEucGF5bWVudF9tZXRob2QsXHJcbiAgICAgICAgc3RhdHVzOiBcIlBlbmRpbmdcIixcclxuICAgICAgICBhdHRlbmRhbmNlX2RldGFpbHM6IGF0dGVuZGFuY2VEZXRhaWxzLFxyXG4gICAgICAgIG1vbnRobHlfYnVzaW5lc3NfaW5mbzogbW9udGhseVRhcmdldEluY2VudGl2ZSxcclxuICAgICAgICBsb2FuX2NvbGxlY3Rpb246IHtcclxuICAgICAgICAgIGxvYW5fcGVyYzogZm9ybURhdGE/LmxvYW5fcGVyYyxcclxuICAgICAgICAgIGxvYW5fY29sbGVjdGlvbl9pbmNlbnRpdmU6IGZvcm1EYXRhPy5sb2FuX2NvbGxlY3Rpb25faW5jZW50aXZlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcGlnbXlfY29sbGVjdGlvbjoge1xyXG4gICAgICAgICAgcGlnbXlfcGVyYzogZm9ybURhdGE/LnBpZ215X3BlcmMsXHJcbiAgICAgICAgICBwaWdteV9jb2xsZWN0aW9uX2luY2VudGl2ZTogZm9ybURhdGE/LnBpZ215X2NvbGxlY3Rpb25faW5jZW50aXZlLFxyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIGF3YWl0IEFQSS5wb3N0KFwiL3NhbGFyeS1wYXltZW50L1wiLCBzYWxhcnlEYXRhKTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiU2FsYXJ5IGFkZGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgc2V0SXNPcGVuQWRkTW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KG51bGwpO1xyXG4gICAgICBzZXRTaG93Q29tcG9uZW50cyhmYWxzZSk7XHJcbiAgICAgIGdldEFsbFNhbGFyeSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFkZGluZyBzYWxhcnk6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgPz8gXCJGYWlsZWQgdG8gYWRkIFNhbGFyeVwiKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEFsbFNhbGFyeSgpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldERhdGFUYWJsZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9zYWxhcnktcGF5bWVudC9hbGxcIik7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlPy5kYXRhPy5kYXRhIHx8IFtdO1xyXG4gICAgICBjb25zdCBmaWx0ZXJlZERhdGEgPSByZXNwb25zZURhdGEubWFwKChkYXRhLCBpbmRleCkgPT4gKHtcclxuICAgICAgICBzaU5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgX2lkOiBkYXRhPy5faWQsXHJcbiAgICAgICAgZW1wbG95ZWVOYW1lOiBkYXRhPy5lbXBsb3llZV9pZD8ubmFtZSxcclxuICAgICAgICBlbXBsb3llZUNvZGU6IGRhdGE/LmVtcGxveWVlX2lkPy5lbXBsb3llZUNvZGUsXHJcbiAgICAgICAgc2FsYXJ5TW9udGg6IGRhdGE/LnNhbGFyeV9tb250aCxcclxuICAgICAgICBzYWxhcnlZZWFyOiBkYXRhPy5zYWxhcnlfeWVhcixcclxuICAgICAgICBuZXRQYXlhYmxlOiBkYXRhPy50b3RhbF9zYWxhcnlfcGF5YWJsZSxcclxuICAgICAgICBwYWlkQW1vdW50OiBkYXRhPy5wYWlkX2Ftb3VudCxcclxuICAgICAgICBwcmVzZW50RGF5czogKGRhdGE/LmF0dGVuZGFuY2VfZGV0YWlscz8ucHJlc2VudF9kYXlzIHx8IDApICsgKGRhdGE/LmF0dGVuZGFuY2VfZGV0YWlscz8uaGFsZl9kYXlzIHx8IDApLFxyXG4gICAgICAgIGFic2VudERheXM6IChkYXRhPy5hdHRlbmRhbmNlX2RldGFpbHM/LmFic2VudF9kYXlzKSA/PyAwLFxyXG4gICAgICAgIHBhaWRMZWF2ZXM6IChkYXRhPy5hdHRlbmRhbmNlX2RldGFpbHM/LmxlYXZlX2RheXMpID8/IDAsXHJcbiAgICAgICAgdG90YWxEYXlzOiAoZGF0YT8uYXR0ZW5kYW5jZV9kZXRhaWxzPy50b3RhbF9kYXlzKSA/PyAwLFxyXG4gICAgICAgIGJhc2ljOiBkYXRhPy5lYXJuaW5ncz8uYmFzaWMsXHJcbiAgICAgICAgaHJhOiBkYXRhPy5lYXJuaW5ncz8uaHJhLFxyXG4gICAgICAgIHRyYXZlbEFsbG93YW5jZTogZGF0YT8uZWFybmluZ3M/LnRyYXZlbF9hbGxvd2FuY2UsXHJcbiAgICAgICAgbWVkaWNhbEFsbG93YW5jZTogZGF0YT8uZWFybmluZ3M/Lm1lZGljYWxfYWxsb3dhbmNlLFxyXG4gICAgICAgIGJhc2tldE9mQmVuaWZpdHM6IGRhdGE/LmVhcm5pbmdzPy5iYXNrZXRfb2ZfYmVuaWZpdHMsXHJcbiAgICAgICAgcGVyZm9ybWFuY2VCb251czogZGF0YT8uZWFybmluZ3M/LnBlcmZvcm1hbmNlX2JvbnVzLFxyXG4gICAgICAgIG90aGVyQWxsb3dhbmNlczogZGF0YT8uZWFybmluZ3M/Lm90aGVyX2FsbG93YW5jZXMsXHJcbiAgICAgICAgY29udmV5YW5jZTogZGF0YT8uZWFybmluZ3M/LmNvbnZleWFuY2UsXHJcbiAgICAgICAgaW5jb21lVGF4OiBkYXRhPy5kZWR1Y3Rpb25zPy5pbmNvbWVfdGF4LFxyXG4gICAgICAgIGVzaTogZGF0YT8uZGVkdWN0aW9ucz8uZXNpLFxyXG4gICAgICAgIGVwZjogZGF0YT8uZGVkdWN0aW9ucz8uZXBmLFxyXG4gICAgICAgIHByb2Zlc3Npb25hbFRheDogZGF0YT8uZGVkdWN0aW9ucz8ucHJvZmVzc2lvbmFsX3RheCxcclxuICAgICAgICBzYWxhcnlBZHZhbmNlOiBkYXRhPy5kZWR1Y3Rpb25zPy5zYWxhcnlfYWR2YW5jZSxcclxuICAgICAgICBzdGF0dXM6IGRhdGE/LnN0YXR1cyxcclxuICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICBrZXk9e2RhdGE/Ll9pZH1cclxuICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICBpdGVtczogZHJvcERvd25JdGVtcyhkYXRhKSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIj5cclxuICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0QWxsU2FsYXJ5cGF5bWVudHMoWy4uLmZpbHRlcmVkRGF0YV0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0QWxsU2FsYXJ5cGF5bWVudHMoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RGF0YVRhYmxlTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZ2V0QWxsU2FsYXJ5KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vZGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFBheW1lbnRNb2RlKHNlbGVjdGVkTW9kZSk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBwYXlfdHlwZTogc2VsZWN0ZWRNb2RlLFxyXG5cclxuICAgICAgdHJhbnNhY3Rpb25faWQ6XHJcbiAgICAgICAgc2VsZWN0ZWRNb2RlID09PSBcIm9ubGluZVwiIHx8IHNlbGVjdGVkTW9kZSA9PT0gXCJvbmxpbmUvdXBpXCJcclxuICAgICAgICAgID8gcHJldkRhdGEudHJhbnNhY3Rpb25faWRcclxuICAgICAgICAgIDogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB0b3RhbEVhcm5pbmdzRXhjbHVkaW5nU2FsYXJ5ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBlYXJuaW5ncyA9IGZvcm1EYXRhLmVhcm5pbmdzIHx8IHt9O1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKGVhcm5pbmdzKVxyXG4gICAgICAuZmlsdGVyKChrZXkpID0+IGtleSAhPT0gXCJzYWxhcnlcIilcclxuICAgICAgLnJlZHVjZSgoc3VtLCBrZXkpID0+IHN1bSArIChOdW1iZXIoZWFybmluZ3Nba2V5XSkgfHwgMCksIDApO1xyXG4gIH0sIFtmb3JtRGF0YS5lYXJuaW5nc10pO1xyXG5cclxuICBjb25zdCB0b3RhbERlZHVjdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGJhc2VEZWR1Y3Rpb25zID0gZm9ybURhdGEuZGVkdWN0aW9ucyB8fCB7fTtcclxuICAgIGNvbnN0IGJhc2VUb3RhbCA9IE9iamVjdC52YWx1ZXMoYmFzZURlZHVjdGlvbnMpLnJlZHVjZShcclxuICAgICAgKHN1bSwgdmFsKSA9PiBzdW0gKyAoTnVtYmVyKHZhbCkgfHwgMCksXHJcbiAgICAgIDBcclxuICAgICk7XHJcbiAgICByZXR1cm4gYmFzZVRvdGFsO1xyXG4gIH0sIFtmb3JtRGF0YS5kZWR1Y3Rpb25zXSk7XHJcblxyXG4gIGNvbnN0IGNhbGN1bGF0ZWRJbmNlbnRpdmUgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHRvdGFsVGFyZ2V0ID0gTnVtYmVyKFxyXG4gICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfdGFyZ2V0IHx8IDBcclxuICAgICk7XHJcbiAgICBjb25zdCB0b3RhbEJ1c2luZXNzQ2xvc2VkID0gTnVtYmVyKFxyXG4gICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfYnVzaW5lc3NfY2xvc2VkIHx8IDBcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgcmF3SW5jZW50aXZlID0gKHRvdGFsVGFyZ2V0IC0gdG90YWxCdXNpbmVzc0Nsb3NlZCkgLyAxMDA7XHJcblxyXG4gICAgaWYgKHJhd0luY2VudGl2ZSA+IDApIHtcclxuICAgICAgcmV0dXJuIHRvdGFsQnVzaW5lc3NDbG9zZWQgLyAxMDA7XHJcbiAgICB9IGVsc2UgaWYgKHJhd0luY2VudGl2ZSA8IDApIHtcclxuICAgICAgcmV0dXJuIE1hdGguYWJzKHJhd0luY2VudGl2ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuICB9LCBbXHJcbiAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfdGFyZ2V0LFxyXG4gICAgZm9ybURhdGEubW9udGhseV9idXNpbmVzc19pbmZvLnRvdGFsX2J1c2luZXNzX2Nsb3NlZCxcclxuICBdKTtcclxuXHJcbiAgLy8gUXVpY2sgbmF2aWdhdG9yIGxpbmsgZGF0YVxyXG4gIGNvbnN0IE5BVl9MSU5LUyA9IFtcclxuICAgIHtcclxuICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktcGF5bWVudFwiLFxyXG4gICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlRmlsbCBzaXplPXsxNn0gLz4sXHJcbiAgICAgIGxhYmVsOiBcIlNhbGFyeSBwYXltZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0bzogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51L2VtcGxveWVlLXN0YXRlbWVudFwiLFxyXG4gICAgICBpY29uOiA8VXNlciBzaXplPXsxNn0gLz4sXHJcbiAgICAgIGxhYmVsOiBcIlNhbGFyeSBMZWRnZXJcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRvOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9hZHZhbmNlLXBheW1lbnQtaW5cIixcclxuICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgc2l6ZT17MTZ9IC8+LFxyXG4gICAgICBsYWJlbDogXCJBZHZhbmNlIHJlcGF5bWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktaW5jZW50aXZlXCIsXHJcbiAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiU2FsYXJ5IGluY2VudGl2ZVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9hZGRpdGlvbmFsLXNhbGFyeVwiLFxyXG4gICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlRmlsbCBzaXplPXsxNn0gLz4sXHJcbiAgICAgIGxhYmVsOiBcIkFkZGl0aW9uYWwgc2FsYXJ5XCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlNhbGFyeSBNYW5hZ2VtZW50PC9oMT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNPcGVuQWRkTW9kYWwodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctYmx1ZS05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctYmx1ZS04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgKyBBZGQgU2FsYXJ5XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiDilIDilIAgUXVpY2sgTmF2aWdhdG9yIOKUgOKUgCAqL31cclxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtZ3JheS00MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgUXVpY2sgbmF2aWdhdG9yXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIHtOQVZfTElOS1MubWFwKChsaW5rKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rLnRvfVxyXG4gICAgICAgICAgICAgICAgICAgIHRvPXtsaW5rLnRvfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJvcmRlci1ibHVlLTQwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMFwiPntsaW5rLmljb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIHtsaW5rLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgICAge2RhdGFUYWJsZUxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPFNwaW5cclxuICAgICAgICAgICAgICAgIGluZGljYXRvcj17PExvYWRpbmdPdXRsaW5lZCBzdHlsZT17eyBmb250U2l6ZTogNDggfX0gc3BpbiAvPn1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChhbGxTYWxhcnlQYXltZW50cyB8fCBbXSkubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlIGNvbHVtbnM9e2NvbHVtbnN9IGRhdGE9e2FsbFNhbGFyeVBheW1lbnRzfSBleHBvcnRDb2xzPXtleGNlbENvbHVtbnN9IGV4cG9ydGVkRmlsZU5hbWU9XCJTYWxhcnkgUGF5bWVudHMuY3N2XCIgZXhwb3J0ZWRQZGZOYW1lPVwiU2FsYXJ5IFBheW1lbnRzXCIgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8RW1wdHkgZGVzY3JpcHRpb249XCJObyBTYWxhcnkgRGF0YSBGb3VuZFwiIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT1cIkFkZCBOZXcgU2FsYXJ5XCJcclxuICAgICAgICB3aWR0aD17XCI2NSVcIn1cclxuICAgICAgICBjbGFzc05hbWU9XCJwYXltZW50LWRyYXdlclwiXHJcbiAgICAgICAgb3Blbj17aXNPcGVuQWRkTW9kYWx9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0SXNPcGVuQWRkTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0Q2FsY3VsYXRlZFNhbGFyeShudWxsKTtcclxuICAgICAgICAgIHNldFNob3dDb21wb25lbnRzKGZhbHNlKTtcclxuICAgICAgICB9fVxyXG4gICAgICAgIGNsb3NhYmxlPXt0cnVlfVxyXG4gICAgICAgIGZvb3Rlcj17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzT3BlbkFkZE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1yZWQtNjAwIGhvdmVyOmJnLXJlZC03MDAgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAge2NhbGN1bGF0ZWRTYWxhcnkgJiYgKFxyXG4gICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInByaW1hcnlcIiBvbkNsaWNrPXtoYW5kbGVBZGRTYWxhcnl9PlxyXG4gICAgICAgICAgICAgICAgU2F2ZSBTYWxhcnlcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cCB3LTEvMlwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICBTZWxlY3QgRW1wbG95ZWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAob3B0aW9uPy5sYWJlbCA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgZmlsdGVyU29ydD17KG9wdGlvbkEsIG9wdGlvbkIpID0+XHJcbiAgICAgICAgICAgICAgICAob3B0aW9uQT8ubGFiZWwgPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgLmxvY2FsZUNvbXBhcmUoKG9wdGlvbkI/LmxhYmVsID8/IFwiXCIpLnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHRvIFNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVzfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUNoYW5nZShcImVtcGxveWVlX2lkXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgeyFlbXBsb3llZURldGFpbHNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICBmb3JtRGF0YS5lbXBsb3llZV9pZCAmJlxyXG4gICAgICAgICAgICBPYmplY3QudmFsdWVzKGVtcGxveWVlRGV0YWlscykubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBZZWFyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS55ZWFyID8gZGF5anMoZm9ybURhdGEueWVhciwgXCJZWVlZXCIpIDogbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhkYXRlLCBkYXRlU3RyaW5nKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoXCJ5ZWFyXCIsIGRhdGVTdHJpbmcpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwaWNrZXI9XCJ5ZWFyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWREYXRlPXsoY3VycmVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWVtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGpvaW5ZZWFyID0gZGF5anMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW1wbG95ZWVEZXRhaWxzLmpvaW5pbmdfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLnllYXIoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VycmVudFllYXIgPSBkYXlqcygpLnllYXIoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IGN1cnJlbnQgPyBjdXJyZW50LnllYXIoKSA6IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB5ZWFyIDwgam9pblllYXIgfHwgeWVhciA+IGN1cnJlbnRZZWFyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgTW9udGggPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWdtZW50ZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIlsmXy5hbnQtc2VnbWVudGVkLWl0ZW0tc2VsZWN0ZWRdOiFiZy1ncmVlbi02MDAgWyZfLmFudC1zZWdtZW50ZWQtaXRlbS1zZWxlY3RlZF06IXRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm1vbnRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17Z2V0VmFsaWRNb250aHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS55ZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQ2hhbmdlKFwibW9udGhcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBwLTQgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtcGxveWVlIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWVEZXRhaWxzPy5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlRGV0YWlscz8uZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbXBsb3llZURldGFpbHM/LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgSm9pbmluZyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSm9pbmluZyBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlPy5zcGxpdChcIlRcIilbMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEVtcGxveWVlIElEXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW1wbG95ZWUgSWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWVEZXRhaWxzPy5lbXBsb3llZUNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiA9PT0gRWFybmluZ3MgU3Vic2VjdGlvbiAoSW5zaWRlIEVtcGxveWVlIERldGFpbHMpID09PSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBtYi00XCI+RWFybmluZ3M8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3NzIFNhbGFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmVhcm5pbmdzPy5zYWxhcnkgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFzaWMgU2FsYXJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZWFybmluZ3M/LmJhc2ljIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5lYXJuaW5ncz8uYmFzaWMgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEhvdXNlIFJlbnQgQWxsb3dhbmNlIChIUkEpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZWFybmluZ3M/LmhyYSB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YT8uZWFybmluZ3M/LmhyYSB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVHJhdmVsIEFsbG93YW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmVhcm5pbmdzPy50cmF2ZWxfYWxsb3dhbmNlIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/LmVhcm5pbmdzPy50cmF2ZWxfYWxsb3dhbmNlIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBNZWRpY2FsIEFsbG93YW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5lYXJuaW5ncz8ubWVkaWNhbF9hbGxvd2FuY2UgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8uZWFybmluZ3M/Lm1lZGljYWxfYWxsb3dhbmNlIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBCYXNrZXQgb2YgQmVuZWZpdHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5lYXJuaW5ncz8uYmFza2V0X29mX2JlbmlmaXRzIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/LmVhcm5pbmdzPy5iYXNrZXRfb2ZfYmVuaWZpdHMgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBlcmZvcm1hbmNlIEJvbnVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZWFybmluZ3M/LnBlcmZvcm1hbmNlX2JvbnVzIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/LmVhcm5pbmdzPy5wZXJmb3JtYW5jZV9ib251cyB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgT3RoZXIgQWxsb3dhbmNlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmVhcm5pbmdzPy5vdGhlcl9hbGxvd2FuY2VzIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/LmVhcm5pbmdzPy5vdGhlcl9hbGxvd2FuY2VzIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDb252ZXlhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZWFybmluZ3M/LmNvbnZleWFuY2UgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8uZWFybmluZ3M/LmNvbnZleWFuY2UgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiA9PT0gRGVkdWN0aW9ucyBTdWJzZWN0aW9uIChJbnNpZGUgRW1wbG95ZWUgRGV0YWlscykgPT09ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkICBtYi00XCI+RGVkdWN0aW9uczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgSW5jb21lIFRheFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmRlZHVjdGlvbnM/LmluY29tZV90YXggfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8uZGVkdWN0aW9ucz8uaW5jb21lX3RheCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRVNJIChFbXBsb3llZSBTdGF0ZSBJbnN1cmFuY2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZGVkdWN0aW9ucz8uZXNpIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5kZWR1Y3Rpb25zPy5lc2kgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVQRiAoRW1wbG95ZWUgUHJvdmlkZW50IEZ1bmQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZGVkdWN0aW9ucz8uZXBmIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5kZWR1Y3Rpb25zPy5lcGYgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFByb2Zlc3Npb25hbCBUYXhcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5kZWR1Y3Rpb25zPy5wcm9mZXNzaW9uYWxfdGF4IHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/LmRlZHVjdGlvbnM/LnByb2Zlc3Npb25hbF90YXggfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgRGVkdWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWxEZWR1Y3Rpb25zLnRvRml4ZWQoMil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHRvdGFsRGVkdWN0aW9ucy50b0ZpeGVkKDIpKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS13aGl0ZSB0by1zbGF0ZS01MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTggc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0MyBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXhsIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTW9udGhseSBUYXJnZXQgJiBJbmNlbnRpdmVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7LyogTWV0cmljcyBHcmlkICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgbWQ6Z3JpZC1jb2xzLTQgbGc6Z3JpZC1jb2xzLTQgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogTW9udGhseSBUYXJnZXQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRhcmdldCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDdXJyZW50IE1vbnRoIFRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiBlLnRhcmdldC5ibHVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubW9udGhseV9idXNpbmVzc19pbmZvPy50YXJnZXQgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHRleHQtZ3JheS05MDAgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS01MCBmb2N1czpiZy13aGl0ZSBmb2N1czpib3JkZXItYmx1ZS0zMDAgZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhPy5tb250aGx5X2J1c2luZXNzX2luZm8/LnRhcmdldCA/PyAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFJlbWFpbmluZyBUYXJnZXQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQcmV2aW91cyBSZW1haW5pbmcgVGFyZ2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhPy5tb250aGx5X2J1c2luZXNzX2luZm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ucHJldmlvdXNfcmVtYWluaW5nX3RhcmdldCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHRleHQtZ3JheS05MDAgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS01MCBmb2N1czpiZy13aGl0ZSBmb2N1czpib3JkZXItYW1iZXItMzAwIGZvY3VzOm91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtYW1iZXItNjAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPy5wcmV2aW91c19yZW1haW5pbmdfdGFyZ2V0ID8/IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIFRhcmdldCAqL31cclxuICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRhcmdldCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiBlLnRhcmdldC5ibHVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8ubW9udGhseV9idXNpbmVzc19pbmZvPy50b3RhbF90YXJnZXQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktOTAwIGZvbnQtc2VtaWJvbGQgYmctc2xhdGUtNTAgZm9jdXM6Ymctd2hpdGUgZm9jdXM6Ym9yZGVyLXB1cnBsZS0zMDAgZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1wdXJwbGUtNjAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mbz8udG90YWxfdGFyZ2V0ID8/IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIEJ1c2luZXNzIENsb3NlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCB0ZXh0LVsxMnB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEJ1c2luZXNzIENsb3NlZCAoQ3VycmVudCBNb250aClcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzQnVzaW5lc3NMb2FkaW5nICYmIDxTcGluIHNpemU9XCJzbWFsbFwiIGNsYXNzTmFtZT1cIm1sLTJcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2lzQnVzaW5lc3NMb2FkaW5nID8gXCJsb2FkaW5nIC4uLlwiIDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8ubW9udGhseV9idXNpbmVzc19pbmZvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnRvdGFsX2J1c2luZXNzX2Nsb3NlZCA/PyAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHRleHQtZ3JheS05MDAgZm9udC1zZW1pYm9sZCBiZy1lbWVyYWxkLTUwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtZW1lcmFsZC02MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8ubW9udGhseV9idXNpbmVzc19pbmZvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnRvdGFsX2J1c2luZXNzX2Nsb3NlZCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFBpZ215IENvbGxlY3Rpb24gSW5jZW50aXZlIChFZGl0YWJsZSkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ibHVlLTUwMCB1cHBlcmNhc2UgbWItMiB0cmFja2luZy13aWRlclwiPlBpZ215IEluY2VudGl2ZSAoRWRpdCk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGlnbXlfY29sbGVjdGlvbl9pbmNlbnRpdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBwaWdteV9jb2xsZWN0aW9uX2luY2VudGl2ZTogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBib3JkZXItYmx1ZS0zMDAgYmctd2hpdGUgaG92ZXI6Ym9yZGVyLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBMb2FuIENvbGxlY3Rpb24gSW5jZW50aXZlIChFZGl0YWJsZSkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ibHVlLTUwMCB1cHBlcmNhc2UgbWItMiB0cmFja2luZy13aWRlclwiPkxvYW4gSW5jZW50aXZlIChFZGl0KTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5sb2FuX2NvbGxlY3Rpb25faW5jZW50aXZlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgbG9hbl9jb2xsZWN0aW9uX2luY2VudGl2ZTogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBib3JkZXItYmx1ZS0zMDAgYmctd2hpdGUgaG92ZXI6Ym9yZGVyLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiA9PT0gVGFyZ2V0IEFjaGlldmVtZW50IEJhZGdlID09PSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXgganVzdGlmeS1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxUYXJnZXQgPSBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLm1vbnRobHlfYnVzaW5lc3NfaW5mby50b3RhbF90YXJnZXQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvdGFsQnVzaW5lc3NDbG9zZWQgPSBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLm1vbnRobHlfYnVzaW5lc3NfaW5mby50b3RhbF9idXNpbmVzc19jbG9zZWQgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhcmlhbmNlID0gdG90YWxCdXNpbmVzc0Nsb3NlZCAtIHRvdGFsVGFyZ2V0O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIC8vIENvbmZpZ3VyYXRpb24gZm9yIGRpZmZlcmVudCBzdGF0dXMgc3RhdGVzXHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGF0dXNDb25maWcgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4Y2VlZGVkOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5lcjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlci1lbWVyYWxkLTIwMCBzaGFkb3ctc20gc2hhZG93LWVtZXJhbGQtMTAwLzUwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGBCdXNpbmVzcyBFeGNlZWRlZCBieSDigrkke3ZhcmlhbmNlLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2hpZXZlZDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluZXI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImJnLWdyZWVuLTUwIHRleHQtZ3JlZW4tNzAwIGJvcmRlci1ncmVlbi0yMDAgc2hhZG93LXNtIHNoYWRvdy1ibHVlLTEwMC81MFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIlRhcmdldCBBY2hpZXZlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG9ydGZhbGw6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJlZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGFpbmVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJiZy1yZWQtNTAgdGV4dC1yZWQtNzAwIGJvcmRlci1yZWQtMjAwIHNoYWRvdy1zbSBzaGFkb3ctcmVkLTEwMC81MFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgQnVzaW5lc3MgU2hvcnRmYWxsOiDigrkke01hdGguYWJzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRTdGF0dXMgPSBzdGF0dXNDb25maWcuc2hvcnRmYWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHZhcmlhbmNlID4gMCkgY3VycmVudFN0YXR1cyA9IHN0YXR1c0NvbmZpZy5leGNlZWRlZDtcclxuICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHZhcmlhbmNlID09PSAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U3RhdHVzID0gc3RhdHVzQ29uZmlnLmFjaGlldmVkO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BcclxuICAgICAgICBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC00IHB5LTEuNSBcclxuICAgICAgICByb3VuZGVkLXhsIGJvcmRlciBmb250LWJvbGQgdGV4dC14cyB0cmFja2luZy10aWdodFxyXG4gICAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dFxyXG4gICAgICAgICR7Y3VycmVudFN0YXR1cy5jb250YWluZXJ9XHJcbiAgICAgIGB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50U3RhdHVzLmljb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFN0YXR1cy5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICB9KSgpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJnLXNsYXRlLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHAtOCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXllbGxvdy02MDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZCBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXhsIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWR2YW5jZSBSZXBheW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hZHZhbmNlX3JlcGF5bWVudD8ucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGF5X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hZHZhbmNlX3JlcGF5bWVudD8uYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRNb2RlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPk9ubGluZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lL3VwaVwiPk9ubGluZS9VUEk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPkNoZXF1ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgeyhwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGF5bWVudE1vZGUgPT09IFwib25saW5lL3VwaVwiKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEe1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hZHZhbmNlX3JlcGF5bWVudD8udHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRyYW5zYWN0aW9uIElEXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjaGVxdWVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaGVxdWUgTnVtYmVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uYWR2YW5jZV9yZXBheW1lbnQ/LmNoZXF1ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIENoZXF1ZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2hlcXVlX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEYXRle1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY2hlcXVlX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hZHZhbmNlX3JlcGF5bWVudD8uY2hlcXVlX2RhdGU/LnNwbGl0KFwiVFwiKVswXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQ2hlcXVlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNoZXF1ZV9iYW5rX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNoZXF1ZV9iYW5rX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hZHZhbmNlX3JlcGF5bWVudD8uY2hlcXVlX2JhbmtfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQmFuayBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgQnJhbmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hZHZhbmNlX3JlcGF5bWVudD8uY2hlcXVlX2JhbmtfYnJhbmNofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCYW5rIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzIgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJyZW1hcmtzXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZW1hcmtzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWEgbmFtZT1cInJlbWFya3NcIiBpZD1cInJlbWFya3NcIiB2YWx1ZT17Zm9ybURhdGE/LmFkdmFuY2VfcmVwYXltZW50Py5yZW1hcmtzfSBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJlbWFya3MgaWYgYW55Li4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGV4dGFyZWE+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBiZy1zbGF0ZS01MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTggc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmVlbi02MDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXhsIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBJbmNlbnRpdmVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDb250aW51ZSBCdXR0b24gLSBTaG93cyBvbmx5IHdoZW4gdmFsdWVzIGFyZSB1cGRhdGVkICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93Q29sbGVjdGlvbkNvbnRpbnVlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVGZXRjaENvbGxlY3Rpb25JbmNlbnRpdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2NvbGxlY3Rpb25Mb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjMTZhMzRhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I6IFwiIzE2YTM0YVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC04IHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDb250aW51ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBiZy1zbGF0ZS01MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTggc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi02XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtc20gbWItMiB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGlnbXkgQ29sbGVjdGlvbiBQZXJjZW50YWdlICglKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyICVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waWdteV9wZXJjfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBwaWdteV9wZXJjOiBlLnRhcmdldC52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMSBmb250LWJvbGQgdGV4dC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3VmZml4PVwiJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCB0ZXh0LXNtIG1iLTIgdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIExvYW4gQ29sbGVjdGlvbiBQZXJjZW50YWdlICglKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyICVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5sb2FuX3BlcmN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGxvYW5fcGVyYzogZS50YXJnZXQudmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgZm9udC1ib2xkIHRleHQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN1ZmZpeD1cIiVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC14cyB0ZXh0LWdyYXktNDAwIGl0YWxpY1wiPiogVmFsdWVzIHdpbGwgYmUgZmV0Y2hlZCB3aGVuIHlvdSBwcmVzcyB0aGUgbWFpbiBcIkNvbnRpbnVlXCIgYnV0dG9uIGJlbG93LjwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA9PT0gQWRkaXRpb25hbCBTYWxhcnkgU3Vic2VjdGlvbiAoSW5zaWRlIEVtcGxveWVlIERldGFpbHMpID09PSAqL31cclxuICAgICAgICAgICAgICAgICAge2FkZGl0aW9uYWxTYWxhcnlsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogU2ltcGxlIHNwaW5uZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBib3JkZXItNCBib3JkZXItZ3JheS0yMDAgYm9yZGVyLXQtZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW5cIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6XHJcbiAgICAgICAgICAgICAgICAgICAgYWRkaXRpb25hbFNhbGFyeURldGFpbHM/LmFkZGl0aW9uYWxfc2FsYXJpZXM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdyBwLTYgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgU2FsYXJ5OiB7YWRkaXRpb25hbFNhbGFyeURldGFpbHM/LnNhbGFyeV9tb250aH0ge2FkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy5zYWxhcnlfeWVhcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2FkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy5hdHRlbmRhbmNlX3N1bW1hcnkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC00IG1iLTYgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1tZCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEF0dGVuZGFuY2UgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTYgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtMyByb3VuZGVkIHNoYWRvdy1zbSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBEYXlzPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy5hdHRlbmRhbmNlX3N1bW1hcnk/LnRvdGFsX2RheXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtMyByb3VuZGVkIHNoYWRvdy1zbSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5QcmVzZW50IERheXM8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy5hdHRlbmRhbmNlX3N1bW1hcnk/LnByZXNlbnRfZGF5c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC0zIHJvdW5kZWQgc2hhZG93LXNtIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPkxlYXZlIERheXM8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthZGRpdGlvbmFsU2FsYXJ5RGV0YWlscz8uYXR0ZW5kYW5jZV9zdW1tYXJ5Py5sZWF2ZV9kYXlzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTMgcm91bmRlZCBzaGFkb3ctc20gdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+SGFsZiBEYXlzPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQteWVsbG93LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWRkaXRpb25hbFNhbGFyeURldGFpbHM/LmF0dGVuZGFuY2Vfc3VtbWFyeT8uaGFsZl9kYXlzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTMgcm91bmRlZCBzaGFkb3ctc20gdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+UGFpZCBEYXlzPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy5hdHRlbmRhbmNlX3N1bW1hcnk/LnBhaWRfZGF5c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBZGRpdGlvbmFsIFNhbGFyaWVzIFRhYmxlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5YWJsZSBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy5hZGRpdGlvbmFsX3NhbGFyaWVzPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbmRleCAlIDIgPT09IDAgPyBcImJnLXdoaXRlXCIgOiBcImJnLWdyYXktNTBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS04MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtpdGVtLm9yaWdpbmFsX3ZhbHVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyZWVuLTYwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0ucGF5bWVudF92YWx1ZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRmb290IGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMlwiPlRvdGFsPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2FkZGl0aW9uYWxTYWxhcnlEZXRhaWxzPy50b3RhbF9vcmlnaW5hbF9hZGRpdGlvbmFsX3NhbGFyeT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXthZGRpdGlvbmFsU2FsYXJ5RGV0YWlscz8udG90YWxfcGF5bWVudF9hbW91bnQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGZvb3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2FsY3VsYXRlU2FsYXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtOFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17Y2FsY3VsYXRlTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAhZm9ybURhdGEuZW1wbG95ZWVfaWQgfHwgIWZvcm1EYXRhLm1vbnRoIHx8ICFmb3JtRGF0YS55ZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzE2YTM0YVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIENvbnRpbnVlXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge2NhbGN1bGF0ZWRTYWxhcnkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgcC00IHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS04MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQXR0ZW5kYW5jZSBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBEYXlzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiBlLnRhcmdldC5ibHVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbGN1bGF0ZWRTYWxhcnkudG90YWxfZGF5c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGVkU2FsYXJ5LnRvdGFsX2RheXMgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFByZXNlbnQgRGF5c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjYWxjdWxhdGVkU2FsYXJ5LnByZXNlbnRfZGF5c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGVkU2FsYXJ5LnByZXNlbnRfZGF5cyB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGFpZCBEYXlzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiBlLnRhcmdldC5ibHVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbGN1bGF0ZWRTYWxhcnkucGFpZF9kYXlzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhjYWxjdWxhdGVkU2FsYXJ5LnBhaWRfZGF5cyB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTE9QIERheXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FsY3VsYXRlZFNhbGFyeS5sb3BfZGF5c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoY2FsY3VsYXRlZFNhbGFyeS5sb3BfZGF5cyB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIExPUFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXsoY2FsY3VsYXRlZFNhbGFyeS5sb3AgfHwgMCkudG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoY2FsY3VsYXRlZFNhbGFyeS5sb3BfZGF5cyB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGVyIERheSBTYWxhcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FsY3VsYXRlZFNhbGFyeS5wZXJfZGF5X3NhbGFyeS50b0ZpeGVkKDIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGN1bGF0ZWRTYWxhcnkucGVyX2RheV9zYWxhcnkudG9GaXhlZCgyKSB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FsY3VsYXRlZCBTYWxhcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FsY3VsYXRlZFNhbGFyeS5jYWxjdWxhdGVkX3NhbGFyeS50b0ZpeGVkKDIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGN1bGF0ZWRTYWxhcnkuY2FsY3VsYXRlZF9zYWxhcnkudG9GaXhlZCgyKSB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUgdG8tc2xhdGUtNTAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC04IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFyQ2hhcnQzIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC14bCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNb250aGx5IFRhcmdldCAmIEluY2VudGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2FsY3VsYXRlZEluY2VudGl2ZSA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQYXlBc1NhbGFyeX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheSBhcyBTYWxhcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUGF5QXNJbmNlbnRpdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5IGFzIEluY2VudGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogTWV0cmljcyBHcmlkICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNb250aGx5IFRhcmdldCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFyZ2V0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VycmVudCBNb250aCBUYXJnZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiBlLnRhcmdldC5ibHVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mbz8udGFyZ2V0IHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHRleHQtZ3JheS05MDAgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS01MCBmb2N1czpiZy13aGl0ZSBmb2N1czpib3JkZXItYmx1ZS0zMDAgZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWJsdWUtNjAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8ubW9udGhseV9idXNpbmVzc19pbmZvPy50YXJnZXQgPz8gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogUmVtYWluaW5nIFRhcmdldCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJldmlvdXMgUmVtYWluaW5nIFRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ucHJldmlvdXNfcmVtYWluaW5nX3RhcmdldCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHRleHQtZ3JheS05MDAgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS01MCBmb2N1czpiZy13aGl0ZSBmb2N1czpib3JkZXItYW1iZXItMzAwIGZvY3VzOm91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1hbWJlci02MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhPy5tb250aGx5X2J1c2luZXNzX2luZm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnByZXZpb3VzX3JlbWFpbmluZ190YXJnZXQgPz8gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIFRhcmdldCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhcmdldCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgVGFyZ2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YT8ubW9udGhseV9idXNpbmVzc19pbmZvPy50b3RhbF90YXJnZXQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktOTAwIGZvbnQtc2VtaWJvbGQgYmctc2xhdGUtNTAgZm9jdXM6Ymctd2hpdGUgZm9jdXM6Ym9yZGVyLXB1cnBsZS0zMDAgZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LXB1cnBsZS02MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhPy5tb250aGx5X2J1c2luZXNzX2luZm8/LnRvdGFsX3RhcmdldCA/PyAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogVG90YWwgQnVzaW5lc3MgQ2xvc2VkICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCB0ZXh0LVsxM3B4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBCdXNpbmVzcyBDbG9zZWQgKEN1cnJlbnQgTW9udGgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQnVzaW5lc3NMb2FkaW5nICYmIDxTcGluIHNpemU9XCJzbWFsbFwiIGNsYXNzTmFtZT1cIm1sLTJcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpc0J1c2luZXNzTG9hZGluZyA/IFwibG9hZGluZyAuLi5cIiA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhPy5tb250aGx5X2J1c2luZXNzX2luZm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnRvdGFsX2J1c2luZXNzX2Nsb3NlZCA/PyAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHRleHQtZ3JheS05MDAgZm9udC1zZW1pYm9sZCBiZy1lbWVyYWxkLTUwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1lbWVyYWxkLTYwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8udG90YWxfYnVzaW5lc3NfY2xvc2VkIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiA9PT0gVGFyZ2V0IEFjaGlldmVtZW50IEJhZGdlID09PSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGp1c3RpZnktc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeygoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxUYXJnZXQgPSBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8udG90YWxfdGFyZ2V0IHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvdGFsQnVzaW5lc3NDbG9zZWQgPSBOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvdGFsX2J1c2luZXNzX2Nsb3NlZCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YXJpYW5jZSA9IHRvdGFsQnVzaW5lc3NDbG9zZWQgLSB0b3RhbFRhcmdldDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQ29uZmlndXJhdGlvbiBmb3IgZGlmZmVyZW50IHN0YXR1cyBzdGF0ZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGF0dXNDb25maWcgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGNlZWRlZDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGFpbmVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlci1lbWVyYWxkLTIwMCBzaGFkb3ctc20gc2hhZG93LWVtZXJhbGQtMTAwLzUwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgVGFyZ2V0IEV4Y2VlZGVkIGJ5IOKCuSR7dmFyaWFuY2UudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2hpZXZlZDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGFpbmVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYmctZ3JlZW4tNTAgdGV4dC1ncmVlbi03MDAgYm9yZGVyLWdyZWVuLTIwMCBzaGFkb3ctc20gc2hhZG93LWJsdWUtMTAwLzUwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIlRhcmdldCBBY2hpZXZlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3J0ZmFsbDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGFpbmVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYmctcmVkLTUwIHRleHQtcmVkLTcwMCBib3JkZXItcmVkLTIwMCBzaGFkb3ctc20gc2hhZG93LXJlZC0xMDAvNTBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGBUYXJnZXQgU2hvcnRmYWxsOiDigrkke01hdGguYWJzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudFN0YXR1cyA9IHN0YXR1c0NvbmZpZy5zaG9ydGZhbGw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhcmlhbmNlID4gMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRTdGF0dXMgPSBzdGF0dXNDb25maWcuZXhjZWVkZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAodmFyaWFuY2UgPT09IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U3RhdHVzID0gc3RhdHVzQ29uZmlnLmFjaGlldmVkO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BcclxuICAgICAgICBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBweC00IHB5LTEuNSBcclxuICAgICAgICByb3VuZGVkLXhsIGJvcmRlciBmb250LWJvbGQgdGV4dC14cyB0cmFja2luZy10aWdodFxyXG4gICAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dFxyXG4gICAgICAgICR7Y3VycmVudFN0YXR1cy5jb250YWluZXJ9XHJcbiAgICAgIGB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRTdGF0dXMuaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50U3RhdHVzLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHsvKiBJbmNlbnRpdmUgQWRqdXN0bWVudCBEaXNwbGF5ICovfVxyXG5cclxuICAgICAgICAgICAgICAgIHtzaG93Q29tcG9uZW50cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTUwIHAtNCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkaXRpb25hbCBQYXltZW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8UGx1c091dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthZGRBZGRpdGlvbmFsUGF5bWVudH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkZCBQYXltZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWRkaXRpb25hbF9wYXltZW50cy5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHBheW1lbnQgbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBZGRpdGlvbmFsUGF5bWVudENoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIm5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cCBmbGV4IGl0ZW1zLWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50LnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQWRkaXRpb25hbFBheW1lbnRDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhwYXltZW50LnZhbHVlIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PERlbGV0ZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlQWRkaXRpb25hbFBheW1lbnQoaW5kZXgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtzaG93Q29tcG9uZW50cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIHAtNCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LW9yYW5nZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkaXRpb25hbCBEZWR1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8UGx1c091dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthZGRBZGRpdGlvbmFsRGVkdWN0aW9ufT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkIERlZHVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFkZGl0aW9uYWxfZGVkdWN0aW9ucy5tYXAoKGRlZHVjdGlvbiwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVkdWN0aW9uIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBkZWR1Y3Rpb24gbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGVkdWN0aW9uLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFkZGl0aW9uYWxEZWR1Y3Rpb25DaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJuYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAgZmxleCBpdGVtcy1lbmQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGVkdWN0aW9uLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQWRkaXRpb25hbERlZHVjdGlvbkNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZGVkdWN0aW9uLnZhbHVlIHx8IDApLnRvRml4ZWQoMilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxEZWxldGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZUFkZGl0aW9uYWxEZWR1Y3Rpb24oaW5kZXgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVkU2FsYXJ5ICYmIHNob3dDb21wb25lbnRzICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIHAtNiByb3VuZGVkLXhsIG10LTQgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCBzaGFkb3ctaW5uZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS04MDAgbWItNiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgLz4gRmluYWwgVHJhbnNhY3Rpb24gQWRqdXN0bWVudHNcclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNlwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBUYXJnZXQgSW5jZW50aXZlIChSZWFkIE9ubHkpICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0yIHRyYWNraW5nLXdpZGVyXCI+VGFyZ2V0IEluY2VudGl2ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jYWxjdWxhdGVkX2luY2VudGl2ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ib2xkICF0ZXh0LWJsdWUtNjAwICFiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogUGlnbXkgQ29sbGVjdGlvbiBJbmNlbnRpdmUgKEVkaXRhYmxlKSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ibHVlLTUwMCB1cHBlcmNhc2UgbWItMiB0cmFja2luZy13aWRlclwiPlBpZ215IEluY2VudGl2ZSAoRWRpdCk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waWdteV9jb2xsZWN0aW9uX2luY2VudGl2ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgcGlnbXlfY29sbGVjdGlvbl9pbmNlbnRpdmU6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIGJvcmRlci1ibHVlLTMwMCBiZy13aGl0ZSBob3Zlcjpib3JkZXItYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIExvYW4gQ29sbGVjdGlvbiBJbmNlbnRpdmUgKEVkaXRhYmxlKSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ibHVlLTUwMCB1cHBlcmNhc2UgbWItMiB0cmFja2luZy13aWRlclwiPkxvYW4gSW5jZW50aXZlIChFZGl0KTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmxvYW5fY29sbGVjdGlvbl9pbmNlbnRpdmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGxvYW5fY29sbGVjdGlvbl9pbmNlbnRpdmU6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIGJvcmRlci1ibHVlLTMwMCBiZy13aGl0ZSBob3Zlcjpib3JkZXItYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEZpbmFsIE5ldCBQYXlhYmxlIChUb3RhbCBTdW0pICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIHVwcGVyY2FzZSBtYi0yIHRyYWNraW5nLXdpZGVyXCI+RmluYWwgTmV0IFBheWFibGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBiYXNlUGF5ID0gTnVtYmVyKGZvcm1EYXRhLnRvdGFsX3NhbGFyeV9wYXlhYmxlIHx8IDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnN0IHRvdGFsID0gYmFzZVBheSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gICBOdW1iZXIoZm9ybURhdGEuY2FsY3VsYXRlZF9pbmNlbnRpdmUgfHwgMCkgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE51bWJlcihmb3JtRGF0YS5waWdteV9jb2xsZWN0aW9uX2luY2VudGl2ZSB8fCAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTnVtYmVyKGZvcm1EYXRhLmxvYW5fY29sbGVjdGlvbl9pbmNlbnRpdmUgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU3VtIG9mIGFsbCBhZGRpdGlvbmFsIHBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxBZGRpdGlvbmFsUGF5bWVudHMgPSBmb3JtRGF0YS5hZGRpdGlvbmFsX3BheW1lbnRzLnJlZHVjZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChhY2MsIHBheW1lbnQpID0+IGFjYyArIE51bWJlcihwYXltZW50LnZhbHVlIHx8IDApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxBZGRpdGlvbmFsRGVkdWN0aW9ucyA9IGZvcm1EYXRhLmFkZGl0aW9uYWxfZGVkdWN0aW9ucy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoYWNjLCBkZWR1Y3Rpb24pID0+IGFjYyArIE51bWJlcihkZWR1Y3Rpb24udmFsdWUgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5ldCBwYXlhYmxlIGFmdGVyIHJlZHVjaW5nIGFkZGl0aW9uYWwgcGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0b3RhbCA9IGJhc2VQYXkgKyB0b3RhbEFkZGl0aW9uYWxQYXltZW50cyAtIHRvdGFsQWRkaXRpb25hbERlZHVjdGlvbnM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWwudG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ibGFjayAhdGV4dC1ncmF5LTkwMCAhYmctZ3JheS0yMDAgYm9yZGVyLW5vbmUgdGV4dC1sZyBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1ncmF5LTUwMCBtdC0xIGZvbnQtbW9ubyB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0b3RhbC50b0ZpeGVkKDIpKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSkoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC0xMiB3LTEyIGJvcmRlci1iLTIgYm9yZGVyLWJsdWUtNTAwIG14LWF1dG9cIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBMb2FkaW5nIGVtcGxveWVlIGRldGFpbHMuLi5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0RyYXdlcj5cclxuXHJcbiAgICAgIHsvKiBQYXkgYXMgU2FsYXJ5IENvbmZpcm1hdGlvbiBNb2RhbCAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgdGl0bGU9XCJDb25maXJtIFBheSBhcyBTYWxhcnlcIlxyXG4gICAgICAgIG9wZW49e3BheUFzU2FsYXJ5TW9kYWxPcGVufVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRQYXlBc1NhbGFyeU1vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICA8QnV0dG9uIGtleT1cImNhbmNlbFwiIG9uQ2xpY2s9eygpID0+IHNldFBheUFzU2FsYXJ5TW9kYWxPcGVuKGZhbHNlKX0+XHJcbiAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgICAgPEJ1dHRvbiBrZXk9XCJjb25maXJtXCIgdHlwZT1cInByaW1hcnlcIiBvbkNsaWNrPXtjb25maXJtUGF5QXNTYWxhcnl9PlxyXG4gICAgICAgICAgICBDb25maXJtXHJcbiAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgXX0+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBtYi00XCI+XHJcbiAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gYWRkIHRoZSBpbmNlbnRpdmUgYW1vdW50IGFzIHNhbGFyeT9cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIHAtNCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5JbmNlbnRpdmUgQW1vdW50Ojwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS03MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgIOKCuXtOdW1iZXIoY2FsY3VsYXRlZEluY2VudGl2ZSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgVGhpcyBhbW91bnQgd2lsbCBiZSBhZGRlZCB0byB0aGUgc2FsYXJ5IHBheWFibGVcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICB7LyogUGF5IGFzIEluY2VudGl2ZSBDb25maXJtYXRpb24gTW9kYWwgKi99XHJcbiAgICAgIDxNb2RhbFxyXG4gICAgICAgIHRpdGxlPVwiQ29uZmlybSBQYXkgYXMgSW5jZW50aXZlXCJcclxuICAgICAgICBvcGVuPXtwYXlBc0luY2VudGl2ZU1vZGFsT3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0UGF5QXNJbmNlbnRpdmVNb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgIGZvb3Rlcj17W1xyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9XCJjYW5jZWxcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYXlBc0luY2VudGl2ZU1vZGFsT3BlbihmYWxzZSl9PlxyXG4gICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgIDwvQnV0dG9uPixcclxuICAgICAgICAgIDxCdXR0b24ga2V5PVwiY29uZmlybVwiIHR5cGU9XCJwcmltYXJ5XCIgb25DbGljaz17Y29uZmlybVBheUFzSW5jZW50aXZlfT5cclxuICAgICAgICAgICAgQ29uZmlybVxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgIF19PlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gbWItNFwiPlxyXG4gICAgICAgICAgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGFkZCB0aGUgaW5jZW50aXZlIGFtb3VudCBhcyBpbmNlbnRpdmVcclxuICAgICAgICAgIHBheWFibGU/XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTUwIHAtNCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5JbmNlbnRpdmUgQW1vdW50Ojwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAg4oK5e051bWJlcihjYWxjdWxhdGVkSW5jZW50aXZlKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICBUaGlzIGFtb3VudCB3aWxsIGJlIGFkZGVkIHRvIHRoZSBpbmNlbnRpdmUgcGF5YWJsZVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT1cIlZpZXcgU2FsYXJ5IERldGFpbHNcIlxyXG4gICAgICAgIHdpZHRoPVwiNTUlXCJcclxuICAgICAgICBjbGFzc05hbWU9XCJwYXltZW50LWRyYXdlclwiXHJcbiAgICAgICAgb3Blbj17aXNPcGVuVXBkYXRlTW9kYWx9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNPcGVuVXBkYXRlTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgIGNsb3NhYmxlPXt0cnVlfVxyXG4gICAgICAgIGZvb3Rlcj17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzT3BlblVwZGF0ZU1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCIhcm91bmRlZC14bCAhcHgtNSAhcHktMiAhZm9udC1zZW1pYm9sZCAhdGV4dC1ncmF5LTcwMCAhYmctZ3JheS0xMDAgaG92ZXI6IWJnLWdyYXktMjAwICFib3JkZXItbm9uZSAhc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgPlxyXG4gICAgICAgIHsvKiBPdXRlciBzcGFjaW5nIHJlZHVjZWQgZnJvbSBzcGFjZS15LTYgdG8gc3BhY2UteS0zICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcblxyXG4gICAgICAgICAgey8qIC0tLS0tIEVtcGxveWVlIEluZm8gLS0tLS0gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMC84MCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIG1iLTAuNVwiPlxyXG4gICAgICAgICAgICAgIEVtcGxveWVlXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgIGVtcGxveWVlcy5maW5kKChlKSA9PiBlLnZhbHVlID09PSB1cGRhdGVGb3JtRGF0YS5lbXBsb3llZV9pZClcclxuICAgICAgICAgICAgICAgICAgPy5sYWJlbCB8fCBcIuKAlFwiXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLWdyYXktNTAgIWJvcmRlci1ncmF5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LW1lZGl1bSAhc2hhZG93LXNtICFjdXJzb3ItZGVmYXVsdCAhdy1mdWxsIGhvdmVyOiFib3JkZXItZ3JheS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIC0tLS0tIE1vbnRoICYgWWVhciAoZ3JpZCBnYXAgcmVkdWNlZCkgLS0tLS0gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAvODAgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIG1iLTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgTW9udGhcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm1vbnRoIHx8IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLWdyYXktNTAgIWJvcmRlci1ncmF5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LW1lZGl1bSAhc2hhZG93LXNtICFjdXJzb3ItZGVmYXVsdCAhdy1mdWxsIGhvdmVyOiFib3JkZXItZ3JheS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMC84MCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICBZZWFyXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgZGF5anMuaXNEYXlqcyh1cGRhdGVGb3JtRGF0YS55ZWFyKVxyXG4gICAgICAgICAgICAgICAgICAgID8gdXBkYXRlRm9ybURhdGEueWVhci5mb3JtYXQoXCJZWVlZXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVGb3JtRGF0YS55ZWFyIHx8IFwi4oCUXCJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIhYmctZ3JheS01MCAhYm9yZGVyLWdyYXktMjAwICFyb3VuZGVkLWxnICFweC0zICFweS0xLjUgIXRleHQtZ3JheS04MDAgIWZvbnQtbWVkaXVtICFzaGFkb3ctc20gIWN1cnNvci1kZWZhdWx0ICF3LWZ1bGwgaG92ZXI6IWJvcmRlci1ncmF5LTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogLS0tLS0gRWFybmluZ3MgKGNhcmQgcGFkZGluZyByZWR1Y2VkIHRvIHAtMywgaGVhZGluZyBtYXJnaW4gcmVkdWNlZCkgLS0tLS0gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAvNzAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwLzYwIHAtMyBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWVtZXJhbGQtODAwIHRleHQtc20gZm9udC1ib2xkIGJvcmRlci1iIGJvcmRlci1lbWVyYWxkLTIwMC81MCBwYi0yIG1iLTNcIj5cclxuICAgICAgICAgICAgICA8c3Bhbj7wn5KwPC9zcGFuPiBFYXJuaW5nc1xyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXModXBkYXRlRm9ybURhdGEuZWFybmluZ3MgfHwge30pLm1hcCgoW2tleSwgdmFsdWVdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17a2V5fT5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2tleVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL18vZywgXCIgXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxiXFx3L2csIChsKSA9PiBsLnRvVXBwZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyKHZhbHVlIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLXdoaXRlICFib3JkZXItZW1lcmFsZC0yMDAgIXJvdW5kZWQtbGcgIXB4LTMgIXB5LTEuNSAhdGV4dC1ncmF5LTgwMCAhZm9udC1tZWRpdW0gIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgIXctZnVsbCBob3ZlcjohYm9yZGVyLWVtZXJhbGQtMzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiAtLS0tLSBEZWR1Y3Rpb25zICh0aWdodGVyKSAtLS0tLSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcm9zZS01MC83MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItcm9zZS0yMDAvNjAgcC0zIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtcm9zZS04MDAgdGV4dC1zbSBmb250LWJvbGQgYm9yZGVyLWIgYm9yZGVyLXJvc2UtMjAwLzUwIHBiLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPvCflLs8L3NwYW4+IERlZHVjdGlvbnNcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHVwZGF0ZUZvcm1EYXRhLmRlZHVjdGlvbnMgfHwge30pLm1hcCgoW2tleSwgdmFsdWVdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17a2V5fT5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2tleVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL18vZywgXCIgXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxiXFx3L2csIChsKSA9PiBsLnRvVXBwZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyKHZhbHVlIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLXdoaXRlICFib3JkZXItcm9zZS0yMDAgIXJvdW5kZWQtbGcgIXB4LTMgIXB5LTEuNSAhdGV4dC1ncmF5LTgwMCAhZm9udC1tZWRpdW0gIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgIXctZnVsbCBob3ZlcjohYm9yZGVyLXJvc2UtMzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXJvc2UtMjAwLzUwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICBUb3RhbCBEZWR1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVUb3RhbERlZHVjdGlvbnMudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLXdoaXRlICFib3JkZXItcm9zZS0yMDAgIXJvdW5kZWQtbGcgIXB4LTMgIXB5LTEuNSAhdGV4dC1ncmF5LTgwMCAhZm9udC1zZW1pYm9sZCAhc2hhZG93LXNtICFjdXJzb3ItZGVmYXVsdCAhdy1mdWxsIGhvdmVyOiFib3JkZXItcm9zZS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIC0tLS0tIE1vbnRobHkgQnVzaW5lc3MgSW5mbyAodGlnaHRlcikgLS0tLS0gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNreS01MC83MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2t5LTIwMC82MCBwLTMgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1za3ktODAwIHRleHQtc20gZm9udC1ib2xkIGJvcmRlci1iIGJvcmRlci1za3ktMjAwLzUwIHBiLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPvCfk4o8L3NwYW4+IE1vbnRobHkgQnVzaW5lc3MgSW5mb1xyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgIFRhcmdldFxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLm1vbnRobHlfYnVzaW5lc3NfaW5mbz8udGFyZ2V0IHx8IDBcclxuICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxyXG4gICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIhYmctd2hpdGUgIWJvcmRlci1za3ktMjAwICFyb3VuZGVkLWxnICFweC0zICFweS0xLjUgIXRleHQtZ3JheS04MDAgIWZvbnQtbWVkaXVtICFzaGFkb3ctc20gIWN1cnNvci1kZWZhdWx0ICF3LWZ1bGwgaG92ZXI6IWJvcmRlci1za3ktMzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIG1iLTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbCBCdXNpbmVzcyBDbG9zZWRcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5tb250aGx5X2J1c2luZXNzX2luZm8/LnRvdGFsX2J1c2luZXNzX2Nsb3NlZCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiB9KX1cclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLXdoaXRlICFib3JkZXItc2t5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LW1lZGl1bSAhc2hhZG93LXNtICFjdXJzb3ItZGVmYXVsdCAhdy1mdWxsIGhvdmVyOiFib3JkZXItc2t5LTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiAtLS0tLSBDYWxjdWxhdGVkIEluY2VudGl2ZSAodGlnaHRlcikgLS0tLS0gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNreS01MC83MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2t5LTIwMC82MCBwLTMgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1za3ktODAwIHRleHQtc20gZm9udC1ib2xkIGJvcmRlci1iIGJvcmRlci1za3ktMjAwLzUwIHBiLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPvCfjq88L3NwYW4+IENhbGN1bGF0ZWQgSW5jZW50aXZlXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgIHZhbHVlPXtOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jYWxjdWxhdGVkX2luY2VudGl2ZSB8fCAwXHJcbiAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxyXG4gICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLXdoaXRlICFib3JkZXItc2t5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMiAhdGV4dC1ncmF5LTgwMCAhZm9udC1ib2xkICF0ZXh0LWxnICFzaGFkb3ctc20gIWN1cnNvci1kZWZhdWx0ICF3LWZ1bGwgaG92ZXI6IWJvcmRlci1za3ktMzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiAtLS0tLSBBZHZhbmNlIFBheW1lbnRzICh0aWdodGVyKSAtLS0tLSAqL31cclxuICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hZHZhbmNlX3BheW1lbnRzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1pbmRpZ28tNTAvNzAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAvNjAgcC0zIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1pbmRpZ28tODAwIHRleHQtc20gZm9udC1ib2xkIGJvcmRlci1iIGJvcmRlci1pbmRpZ28tMjAwLzUwIHBiLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+8J+Sszwvc3Bhbj4gQWR2YW5jZSBQYXltZW50c1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFkdmFuY2VfcGF5bWVudHMubWFwKChwYXksIGkpID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC0yIG1iLTIgbGFzdDptYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXkubmFtZSB8fCBcIkFkdmFuY2VcIn1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiFiZy13aGl0ZSAhYm9yZGVyLWluZGlnby0yMDAgIXJvdW5kZWQtbGcgIXB4LTMgIXB5LTEuNSAhdGV4dC1ncmF5LTgwMCAhZm9udC1tZWRpdW0gIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgZmxleC0xIGhvdmVyOiFib3JkZXItaW5kaWdvLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHtOdW1iZXIocGF5LnZhbHVlKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIhYmctd2hpdGUgIWJvcmRlci1pbmRpZ28tMjAwICFyb3VuZGVkLWxnICFweC0zICFweS0xLjUgIXRleHQtZ3JheS04MDAgIWZvbnQtc2VtaWJvbGQgIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgdy1mdWxsIHNtOnctMzYgdGV4dC1yaWdodCBob3ZlcjohYm9yZGVyLWluZGlnby0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogLS0tLS0gQWRkaXRpb25hbCBQYXltZW50cyAodGlnaHRlcikgLS0tLS0gKi99XHJcbiAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWRkaXRpb25hbF9wYXltZW50cz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTUwLzcwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwLzYwIHAtMyBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtcHVycGxlLTgwMCB0ZXh0LXNtIGZvbnQtYm9sZCBib3JkZXItYiBib3JkZXItcHVycGxlLTIwMC81MCBwYi0yIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPuKcqDwvc3Bhbj4gQWRkaXRpb25hbCBQYXltZW50c1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFkZGl0aW9uYWxfcGF5bWVudHMubWFwKChwYXksIGkpID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC0yIG1iLTIgbGFzdDptYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXkubmFtZSB8fCBcIlBheW1lbnRcIn1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiFiZy13aGl0ZSAhYm9yZGVyLXB1cnBsZS0yMDAgIXJvdW5kZWQtbGcgIXB4LTMgIXB5LTEuNSAhdGV4dC1ncmF5LTgwMCAhZm9udC1tZWRpdW0gIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgZmxleC0xIGhvdmVyOiFib3JkZXItcHVycGxlLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHtOdW1iZXIocGF5LnZhbHVlKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIhYmctd2hpdGUgIWJvcmRlci1wdXJwbGUtMjAwICFyb3VuZGVkLWxnICFweC0zICFweS0xLjUgIXRleHQtZ3JheS04MDAgIWZvbnQtc2VtaWJvbGQgIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgdy1mdWxsIHNtOnctMzYgdGV4dC1yaWdodCBob3ZlcjohYm9yZGVyLXB1cnBsZS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogLS0tLS0gQWRkaXRpb25hbCBEZWR1Y3Rpb25zICh0aWdodGVyKSAtLS0tLSAqL31cclxuICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hZGRpdGlvbmFsX2RlZHVjdGlvbnM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLW9yYW5nZS01MC83MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItb3JhbmdlLTIwMC82MCBwLTMgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LW9yYW5nZS04MDAgdGV4dC1zbSBmb250LWJvbGQgYm9yZGVyLWIgYm9yZGVyLW9yYW5nZS0yMDAvNTAgcGItMiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj7imqDvuI88L3NwYW4+IEFkZGl0aW9uYWwgRGVkdWN0aW9uc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFkZGl0aW9uYWxfZGVkdWN0aW9ucy5tYXAoKGRlZCwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgZ2FwLTIgbWItMiBsYXN0Om1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RlZC5uYW1lIHx8IFwiRGVkdWN0aW9uXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIhYmctd2hpdGUgIWJvcmRlci1vcmFuZ2UtMjAwICFyb3VuZGVkLWxnICFweC0zICFweS0xLjUgIXRleHQtZ3JheS04MDAgIWZvbnQtbWVkaXVtICFzaGFkb3ctc20gIWN1cnNvci1kZWZhdWx0IGZsZXgtMSBob3ZlcjohYm9yZGVyLW9yYW5nZS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7TnVtYmVyKGRlZC52YWx1ZSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLXdoaXRlICFib3JkZXItb3JhbmdlLTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LXNlbWlib2xkICFzaGFkb3ctc20gIWN1cnNvci1kZWZhdWx0IHctZnVsbCBzbTp3LTM2IHRleHQtcmlnaHQgaG92ZXI6IWJvcmRlci1vcmFuZ2UtMzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIC0tLS0tIFRvdGFsIFNhbGFyeSBQYXlhYmxlICh0aWdodGVyKSAtLS0tLSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtMTAwLzgwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNzAgcC00IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbGF0ZS03MDAgdGV4dC1zbSBmb250LWJvbGQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMC81MCBwYi0yIG1iLTNcIj5cclxuICAgICAgICAgICAgICA8c3Bhbj7wn4+377iPPC9zcGFuPiBUb3RhbCBTYWxhcnkgUGF5YWJsZVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEudG90YWxfc2FsYXJ5X3BheWFibGUgfHwgMFxyXG4gICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiB9KX1cclxuICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiFiZy13aGl0ZSAhYm9yZGVyLXNsYXRlLTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMi41ICF0ZXh0LWdyYXktOTAwICFmb250LWJvbGQgIXRleHQteGwgIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgIXctZnVsbCB0ZXh0LWNlbnRlciBob3ZlcjohYm9yZGVyLXNsYXRlLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogLS0tLS0gUGF5bWVudCBEZXRhaWxzICh0aWdodGVyKSAtLS0tLSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzgwIHAtMyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZ3JheS03MDAgdGV4dC1zbSBmb250LWJvbGQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwLzYwIHBiLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPvCfkrM8L3NwYW4+IFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgIFBhaWQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtOdW1iZXIodXBkYXRlRm9ybURhdGEucGFpZF9hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHsgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyIH1cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLWdyYXktNTAgIWJvcmRlci1ncmF5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LW1lZGl1bSAhc2hhZG93LXNtICFjdXJzb3ItZGVmYXVsdCAhdy1mdWxsIGhvdmVyOiFib3JkZXItZ3JheS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgIFBheW1lbnQgTWV0aG9kXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucGF5bWVudF9tZXRob2QgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLWdyYXktNTAgIWJvcmRlci1ncmF5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LW1lZGl1bSAhc2hhZG93LXNtICFjdXJzb3ItZGVmYXVsdCAhdy1mdWxsIGhvdmVyOiFib3JkZXItZ3JheS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEudHJhbnNhY3Rpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSURcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLWdyYXktNTAgIWJvcmRlci1ncmF5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LW1vbm8gIXRleHQtc20gIXNoYWRvdy1zbSAhY3Vyc29yLWRlZmF1bHQgIXctZnVsbCBob3ZlcjohYm9yZGVyLWdyYXktMzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIG1iLTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICBTdGF0dXNcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIWJnLWdyYXktNTAgIWJvcmRlci1ncmF5LTIwMCAhcm91bmRlZC1sZyAhcHgtMyAhcHktMS41ICF0ZXh0LWdyYXktODAwICFmb250LW1lZGl1bSAhc2hhZG93LXNtICFjdXJzb3ItZGVmYXVsdCAhdy1mdWxsIGhvdmVyOiFib3JkZXItZ3JheS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9EcmF3ZXI+XHJcblxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICB0aXRsZT1cIkRlbGV0ZSBTYWxhcnlcIlxyXG4gICAgICAgIG9wZW49e2RlbGV0ZU1vZGFsT3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0RGVsZXRlTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICBmb290ZXI9e1tcclxuICAgICAgICAgIDxCdXR0b24ga2V5PVwiY2FuY2VsXCIgb25DbGljaz17KCkgPT4gc2V0RGVsZXRlTW9kYWxPcGVuKGZhbHNlKX0+XHJcbiAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9XCJkZWxldGVcIlxyXG4gICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICBsb2FkaW5nPXtkZWxldGVMb2FkaW5nfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVDb25maXJtKGRlbGV0ZUlkKX0+XHJcbiAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgIF19PlxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIHNhbGFyeSA/IFRoaXMgYWN0aW9uIGNhbm5vdCBiZVxyXG4gICAgICAgICAgdW5kb25lLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgIDxNb2RhbFxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci04MDAgdGV4dC1sZyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgU2FsYXJ5IEFscmVhZHkgUHJvY2Vzc2VkXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXthbHJlYWR5UGFpZE1vZGFsT3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0QWxyZWFkeVBhaWRNb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgIHdpZHRoPXs5MjB9XHJcbiAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICA8QnV0dG9uIGtleT1cImNsb3NlXCIgb25DbGljaz17KCkgPT4gc2V0QWxyZWFkeVBhaWRNb2RhbE9wZW4oZmFsc2UpfT5cclxuICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgIDwvQnV0dG9uPixcclxuICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkPy5zdGF0dXMgPT09IFwiUGVuZGluZ1wiICYmIChcclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIGtleT1cImVkaXRcIlxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcIiNENEFGMzdcIixcclxuICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcIiNCODg2MEJcIixcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMwMDBcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIGhhbmRsZUVkaXQoZXhpc3RpbmdTYWxhcnlSZWNvcmQuX2lkKTtcclxuICAgICAgICAgICAgICAgIHNldEFscmVhZHlQYWlkTW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICBFZGl0IFJlY29yZFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgXX1cclxuICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgcGFkZGluZzogXCIyNHB4XCIsXHJcbiAgICAgICAgICBtYXhIZWlnaHQ6IFwiNzB2aFwiLFxyXG4gICAgICAgICAgb3ZlcmZsb3dZOiBcImF1dG9cIixcclxuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmFmYWZhXCIsXHJcbiAgICAgICAgfX0+XHJcbiAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cclxuICAgICAgICAgICAgey8qIFNhbGFyeSBQZXJpb2QgKi99XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUgdG8tc2xhdGUtNTAgcC02IHJvdW5kZWQteGwgc2hhZG93LW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLWJsdWUtNjAwIHJvdW5kZWQtZnVsbCBtci0zXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgU2FsYXJ5IFBlcmlvZFxyXG4gICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBNb250aFxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGZvbnQtc2VtaWJvbGQgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLnNhbGFyeV9tb250aH17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLnNhbGFyeV95ZWFyfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEZyb21cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LXNlbWlib2xkIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtkYXlqc1xyXG4gICAgICAgICAgICAgICAgICAgICAgLnV0YyhleGlzdGluZ1NhbGFyeVJlY29yZC5zYWxhcnlfZnJvbV9kYXRlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmZvcm1hdChcIkREIE1NTSBZWVlZXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgZm9udC1zZW1pYm9sZCB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZGF5anNcclxuICAgICAgICAgICAgICAgICAgICAgIC51dGMoZXhpc3RpbmdTYWxhcnlSZWNvcmQuc2FsYXJ5X3RvX2RhdGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuZm9ybWF0KFwiREQgTU1NIFlZWVlcIil9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgIHsvKiBBdHRlbmRhbmNlIFN1bW1hcnkgKi99XHJcbiAgICAgICAgICAgIHsvKiBBZGRlZCAnZmxleCBmbGV4LWNvbCcgc28gdGhhdCAnZ2FwLTQnIGFjdHVhbGx5IHdvcmtzICovfVxyXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS01MCBwLTYgcm91bmRlZC14bCBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLXB1cnBsZS02MDAgcm91bmRlZC1mdWxsIG1yLTNcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICBBdHRlbmRhbmNlIERldGFpbHNcclxuICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoXHJcbiAgICAgICAgICAgICAgICBleGlzdGluZ1NhbGFyeVJlY29yZC5hdHRlbmRhbmNlX2RldGFpbHMgfHwge31cclxuICAgICAgICAgICAgICApLm1hcCgoW2tleSwgdmFsXSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgaXNDdXJyZW5jeSA9XHJcbiAgICAgICAgICAgICAgICAgIGtleS5pbmNsdWRlcyhcInNhbGFyeVwiKSB8fCBrZXkuaW5jbHVkZXMoXCJjYWxjdWxhdGVkXCIpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgaXNEYXRlID0ga2V5LmluY2x1ZGVzKFwiZGF0ZVwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgZGlzcGxheVZhbHVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKGlzRGF0ZSkge1xyXG4gICAgICAgICAgICAgICAgICAvLyBJbXByb3ZlZCBkYXlqcyBzYWZldHkgY2hlY2tcclxuICAgICAgICAgICAgICAgICAgZGlzcGxheVZhbHVlID0gdmFsID8gZGF5anModmFsKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogXCJOL0FcIjtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoaXNDdXJyZW5jeSkge1xyXG4gICAgICAgICAgICAgICAgICBkaXNwbGF5VmFsdWUgPSBg4oK5JHtOdW1iZXIodmFsKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICB9KX1gO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgZGlzcGxheVZhbHVlID0gdmFsO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgLy8gQ2hhbmdlZCB0byBkaXYgZm9yIHNlbWFudGljIGNvcnJlY3RuZXNzIHNpbmNlIHdlIGFyZW4ndCB1c2luZyBhIDx1bD4gd3JhcHBlclxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17a2V5fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXB1cnBsZS0xMDAgaG92ZXI6Ym9yZGVyLXB1cnBsZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXBpdGFsaXplIHRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7a2V5LnJlcGxhY2UoL18vZywgXCIgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9udC1ib2xkICR7aXNDdXJyZW5jeSA/IFwidGV4dC1wdXJwbGUtNzAwXCIgOiBcInRleHQtc2xhdGUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Rpc3BsYXlWYWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICB7LyogRWFybmluZ3MgKi99XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNTAgdG8tZW1lcmFsZC01MCBwLTYgcm91bmRlZC14bCBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi00IGZsZXggaXRlbXMtY2VudGVyIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTYgYmctZ3JlZW4tNjAwIHJvdW5kZWQtZnVsbCBtci0zXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgRWFybmluZ3NcclxuICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhleGlzdGluZ1NhbGFyeVJlY29yZC5lYXJuaW5ncyB8fCB7fSkubWFwKFxyXG4gICAgICAgICAgICAgICAgICAoW2tleSwgdmFsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtrZXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmVlbi0xMDAgaG92ZXI6Ym9yZGVyLWdyZWVuLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FwaXRhbGl6ZSB0ZXh0LXNsYXRlLTcwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7a2V5LnJlcGxhY2UoL18vZywgXCIgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKHZhbCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgICAgICB7LyogRGVkdWN0aW9ucyAqL31cclxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1yZWQtNTAgdG8tcm9zZS01MCBwLTYgcm91bmRlZC14bCBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLXJlZC02MDAgcm91bmRlZC1mdWxsIG1yLTNcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICBEZWR1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoZXhpc3RpbmdTYWxhcnlSZWNvcmQuZGVkdWN0aW9ucyB8fCB7fSkubWFwKFxyXG4gICAgICAgICAgICAgICAgICAoW2tleSwgdmFsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtrZXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1yZWQtMTAwIGhvdmVyOmJvcmRlci1yZWQtMjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXBpdGFsaXplIHRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtrZXkucmVwbGFjZSgvXy9nLCBcIiBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1yZWQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKHZhbCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1ibHVlLTUwIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLWJsdWUtNjAwIHJvdW5kZWQtZnVsbCBtci0zXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgVGFyZ2V0IERldGFpbHNcclxuICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhcclxuICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQubW9udGhseV9idXNpbmVzc19pbmZvIHx8IHt9XHJcbiAgICAgICAgICAgICAgICApLm1hcCgoW2tleSwgdmFsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2tleX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCBob3Zlcjpib3JkZXItYmx1ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXBpdGFsaXplIHRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7a2V5LnJlcGxhY2UoL18vZywgXCIgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKHZhbCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICB7LyogQWR2YW5jZSBQYXltZW50cyAqL31cclxuICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmFkdmFuY2VfcGF5bWVudHM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1jeWFuLTUwIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi00IGZsZXggaXRlbXMtY2VudGVyIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xIGgtNiBiZy1ibHVlLTYwMCByb3VuZGVkLWZ1bGwgbXItM1wiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgQWR2YW5jZSBQYXltZW50c1xyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmFkdmFuY2VfcGF5bWVudHMubWFwKChwYXksIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMTAwIGhvdmVyOmJvcmRlci1ibHVlLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BheS5uYW1lIHx8IFwiQWR2YW5jZSBQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAge051bWJlcihwYXkudmFsdWUpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHsvKiBBZGRpdGlvbmFsIFBheW1lbnRzICovfVxyXG4gICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWRkaXRpb25hbF9wYXltZW50cz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHRvLWN5YW4tNTAgcC02IHJvdW5kZWQteGwgc2hhZG93LW1kIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLWJsdWUtNjAwIHJvdW5kZWQtZnVsbCBtci0zXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWRkaXRpb25hbF9wYXltZW50cy5tYXAoKHBheSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGJnLXdoaXRlIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYmx1ZS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF5Lm5hbWUgfHwgXCJQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAge051bWJlcihwYXkudmFsdWUpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHsvKiBBZGRpdGlvbmFsIERlZHVjdGlvbnMgKi99XHJcbiAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5hZGRpdGlvbmFsX2RlZHVjdGlvbnM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tb3JhbmdlLTUwIHRvLWFtYmVyLTUwIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLW9yYW5nZS0yMDAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLW9yYW5nZS02MDAgcm91bmRlZC1mdWxsIG1yLTNcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgRGVkdWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmFkZGl0aW9uYWxfZGVkdWN0aW9ucy5tYXAoKGRlZCwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGJnLXdoaXRlIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItb3JhbmdlLTEwMCBob3Zlcjpib3JkZXItb3JhbmdlLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2RlZC5uYW1lIHx8IFwiRGVkdWN0aW9uXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1vcmFuZ2UtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKGRlZC52YWx1ZSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgey8qIEluY2VudGl2ZSBBZGp1c3RtZW50ICovfVxyXG4gICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuY2FsY3VsYXRlZF9pbmNlbnRpdmUgIT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNTAgdG8tb3JhbmdlLTUwIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTYgYmctYW1iZXItNjAwIHJvdW5kZWQtZnVsbCBtci0zXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgQWRqdXN0bWVudFxyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1hbWJlci0xMDAgaG92ZXI6Ym9yZGVyLWFtYmVyLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENhbGN1bGF0ZWQgSW5jZW50aXZlOlxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9udC1ib2xkIG1sLTIgJHtleGlzdGluZ1NhbGFyeVJlY29yZC5jYWxjdWxhdGVkX2luY2VudGl2ZSA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICB7TWF0aC5hYnMoXHJcbiAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1NhbGFyeVJlY29yZC5jYWxjdWxhdGVkX2luY2VudGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmNhbGN1bGF0ZWRfaW5jZW50aXZlID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIiAoQm9udXMpXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCIgKERlZHVjdGlvbilcIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7LyogUGF5bWVudCBTdW1tYXJ5ICovfVxyXG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWluZGlnby01MCB2aWEtcHVycGxlLTUwIHRvLXBpbmstNTAgcC02IHJvdW5kZWQteGwgc2hhZG93LWxnIGJvcmRlci0yIGJvcmRlci1pbmRpZ28tMjAwXCI+XHJcbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi00IGZsZXggaXRlbXMtY2VudGVyIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTYgYmctaW5kaWdvLTYwMCByb3VuZGVkLWZ1bGwgbXItM1wiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgU3VtbWFyeVxyXG4gICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgYmctd2hpdGUgcC01IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICBDYWxjdWxhdGVkIFNhbGFyeVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGZvbnQtc2VtaWJvbGQgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgIHtOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1NhbGFyeVJlY29yZD8uYXR0ZW5kYW5jZV9kZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8uY2FsY3VsYXRlZF9zYWxhcnlcclxuICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5hZHZhbmNlX3BheW1lbnRzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZHZhbmNlIFBheW1lbnRzOlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTcwMCBmb250LXNlbWlib2xkIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAge051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWR2YW5jZV9wYXltZW50cy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgcCkgPT4gc3VtICsgTnVtYmVyKHAudmFsdWUpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5hZGRpdGlvbmFsX3BheW1lbnRzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIFBheW1lbnRzOlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTcwMCBmb250LXNlbWlib2xkIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAge051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWRkaXRpb25hbF9wYXltZW50cy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgcCkgPT4gc3VtICsgTnVtYmVyKHAudmFsdWUpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5hZGRpdGlvbmFsX2RlZHVjdGlvbnM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgRGVkdWN0aW9uczpcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNzAwIGZvbnQtc2VtaWJvbGQgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1NhbGFyeVJlY29yZC5hZGRpdGlvbmFsX2RlZHVjdGlvbnMucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChzdW0sIGQpID0+IHN1bSArIE51bWJlcihkLnZhbHVlKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuY2FsY3VsYXRlZF9pbmNlbnRpdmUgIT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEluY2VudGl2ZSBBZGp1c3RtZW50OlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9udC1zZW1pYm9sZCB0ZXh0LWxnICR7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuY2FsY3VsYXRlZF9pbmNlbnRpdmUgPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXJlZC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgIHtNYXRoLmFicyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQuY2FsY3VsYXRlZF9pbmNlbnRpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuY2FsY3VsYXRlZF9pbmNlbnRpdmUgPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiIChEZWR1Y3Rpb24pXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0zIGJvcmRlci10LTIgYm9yZGVyLXNsYXRlLTMwMCBtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGZvbnQtYm9sZCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTmV0IFBheWFibGU6XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNzAwIGZvbnQtYm9sZCB0ZXh0LTJ4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgIHtOdW1iZXIoZXhpc3RpbmdTYWxhcnlSZWNvcmQubmV0X3BheWFibGUpLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICBQYWlkIEFtb3VudDpcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LXNlbWlib2xkIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKGV4aXN0aW5nU2FsYXJ5UmVjb3JkLnBhaWRfYW1vdW50KS50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIixcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVtYWluaW5nIEJhbGFuY2U6XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb250LWJvbGQgdGV4dC1sZyAke051bWJlcihleGlzdGluZ1NhbGFyeVJlY29yZC5yZW1haW5pbmdfYmFsYW5jZSkgPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAge051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLnJlbWFpbmluZ19iYWxhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0yIG10LTMgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGZvbnQtbWVkaXVtXCI+U3RhdHVzOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTEgcm91bmRlZC1mdWxsIGZvbnQtc2VtaWJvbGQgdGV4dC1zbSAke2V4aXN0aW5nU2FsYXJ5UmVjb3JkLnN0YXR1cyA9PT0gXCJQYWlkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDAgYm9yZGVyIGJvcmRlci1ncmVlbi0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWFtYmVyLTEwMCB0ZXh0LWFtYmVyLTgwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQudHJhbnNhY3Rpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEOlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LW1vbm8gdGV4dC1zbSBiZy1zbGF0ZS0xMDAgcHgtMyBweS0xIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1ldGhvZDpcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5wYXltZW50X21ldGhvZCB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC0zMiB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgIExvYWRpbmcgc2FsYXJ5IGRldGFpbHMuLi5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvTW9kYWw+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSFJTYWxhcnlNYW5hZ2VtZW50O1xyXG5cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0hSU2FsYXJ5TWFuYWdlbWVudC5qc3gifQ==