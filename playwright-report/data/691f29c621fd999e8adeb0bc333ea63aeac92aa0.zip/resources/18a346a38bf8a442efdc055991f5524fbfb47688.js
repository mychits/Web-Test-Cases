import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PaymentLinkMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { MdAddLink } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { PiLinkSimpleBreakFill } from "/node_modules/.vite/deps/react-icons_pi.js?v=819e0a34";
import { FaWpforms } from "/node_modules/.vite/deps/react-icons_fa6.js?v=819e0a34";
import { Banknote, Briefcase, TicketCheck, MoreHorizontal, ChevronRight, Zap, Sparkles, ArrowUpRight } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const PaymentLinkMenu = () => {
  const paymentInLinkMenuCategories = [
    {
      id: 1,
      title: "Chit Payment Link",
      description: "Manage customer chit payment link transaction information.",
      subtitle: "Individual Mode",
      icon: MdAddLink,
      gradient: "from-violet-500 via-purple-500 to-pink-500",
      bgGradient: "from-violet-50 via-purple-50 to-pink-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu/chit-payment",
      stats: "Chit Payment Link Information",
      secondaryIcon: ArrowUpRight,
      iconColor: "text-violet-600",
      bgColor: "bg-violet-100"
    },
    {
      id: 2,
      title: "Bulk Chit Payment Link",
      description: "Manage customer Bulk chit payment link transaction information.",
      subtitle: "Bulk Mode",
      icon: PiLinkSimpleBreakFill,
      gradient: "from-violet-500 via-indigo-500 to-purple-500",
      bgGradient: "from-violet-50 via-indigo-50 to-purple-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu/chit-bulk-payment",
      stats: "Bulk Chit Payment Link Information",
      secondaryIcon: ArrowUpRight,
      iconColor: "text-violet-600",
      bgColor: "bg-violet-100"
    },
    {
      id: 3,
      title: "Chit Registration Payment Link",
      subtitle: "Individual Mode",
      description: "Manage customer chit Registration payment link transaction information.",
      icon: FaWpforms,
      gradient: "from-emerald-500 via-teal-500 to-cyan-500",
      bgGradient: "from-emerald-50 via-teal-50 to-cyan-50",
      href: "/payment-menu/payment-in-out-menu/pay-in-menu/payment-link-menu/registration-chit-payment",
      stats: "Chit Registration Payment Link Information",
      secondaryIcon: ArrowUpRight,
      iconColor: "text-emerald-600",
      bgColor: "bg-emerald-100"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full relative overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
          lineNumber: 71,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-8 relative", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
            lineNumber: 73,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-12", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-600 to-purple-600 rounded-2xl blur-lg opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 78,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-2xl", children: /* @__PURE__ */ jsxDEV(Banknote, { className: "w-8 h-8 text-white" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 80,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 79,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
              lineNumber: 77,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 bg-clip-text text-transparent", children: "Payment Link Management" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 85,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 mt-1 text-lg", children: "Manage and view payment link information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 88,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
              lineNumber: 83,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
            lineNumber: 76,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
            lineNumber: 75,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12", children: paymentInLinkMenuCategories.map((category) => {
            const Icon = category.icon;
            const SecondaryIcon = category.secondaryIcon;
            return /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV("div", { className: "relative h-full overflow-hidden rounded-3xl bg-white/80 backdrop-blur-xl border border-white/20 shadow-2xl hover:shadow-3xl transition-all duration-700 transform hover:-translate-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-3xl bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-700 p-[2px]", children: /* @__PURE__ */ jsxDEV("div", { className: `w-full h-full rounded-3xl bg-gradient-to-r ${category.gradient}` }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 103,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 102,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative h-full bg-white rounded-3xl p-8", children: [
                /* @__PURE__ */ jsxDEV("div", { className: `absolute top-4 right-4 w-32 h-32 rounded-full bg-gradient-to-br ${category.bgGradient} opacity-30 blur-2xl` }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 109,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-6 relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-3 bg-gradient-to-r from-violet-400 to-purple-400 rounded-2xl blur-lg opacity-0 group-hover:opacity-40 transition duration-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                      lineNumber: 114,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: `relative w-16 h-16 rounded-2xl ${category.bgColor} flex items-center justify-center shadow-xl border border-white/50 group-hover:scale-110 transition-transform duration-500`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-8 h-8 ${category.iconColor}` }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                      lineNumber: 116,
                      columnNumber: 31
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                      lineNumber: 115,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 113,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-2xl bg-gradient-to-br from-slate-50 to-white shadow-lg border border-slate-200/50 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-x-4 group-hover:translate-x-0", children: /* @__PURE__ */ jsxDEV(SecondaryIcon, { className: "w-5 h-5 text-slate-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 120,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 119,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 112,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6 relative", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-slate-900 mb-3 group-hover:bg-gradient-to-r group-hover:from-violet-600 group-hover:to-purple-600 group-hover:bg-clip-text group-hover:text-transparent transition-all duration-500", children: category.title }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 126,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 leading-relaxed mb-2", children: category.description }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 129,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-3 py-1 text-xs font-medium text-slate-500 bg-slate-100 rounded-full", children: category.subtitle }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 132,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 125,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-6 border-t border-slate-200/50 relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-green-500 rounded-full animate-pulse" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                        lineNumber: 141,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 w-2 h-2 bg-green-500 rounded-full animate-ping" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                        lineNumber: 142,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                      lineNumber: 140,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-slate-500 uppercase tracking-wide", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                      lineNumber: 144,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 139,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-violet-600 opacity-0 group-hover:opacity-100 transform translate-x-4 group-hover:translate-x-0 transition-all duration-500", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold", children: "Explore" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                      lineNumber: 149,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-5 h-5" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                      lineNumber: 150,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 148,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 138,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 107,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
              lineNumber: 100,
              columnNumber: 21
            }, this) }, category.id, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
              lineNumber: 99,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
            lineNumber: 94,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative p-8 bg-gradient-to-br from-violet-50 via-purple-50 to-pink-50 rounded-3xl border border-white/50 shadow-2xl overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-violet-200/30 to-transparent rounded-full blur-3xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
              lineNumber: 163,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-40 h-40 bg-gradient-to-tr from-purple-200/30 to-transparent rounded-full blur-3xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
              lineNumber: 164,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-2 bg-gradient-to-r from-violet-500 to-purple-500 rounded-2xl blur-lg opacity-50 group-hover:opacity-75 transition duration-300" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 168,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative w-14 h-14 rounded-2xl bg-white shadow-xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-7 h-7 text-violet-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 170,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 169,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 167,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-slate-900 mb-2 flex items-center gap-2", children: [
                  "Quick Tips",
                  /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-5 h-5 text-violet-500 animate-pulse" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 176,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 174,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("ul", { className: "text-slate-700 leading-relaxed space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("li", { children: "• Use the Chit Payment Link directory to manage Chit Payment Link transaction details and view payment information all in one place." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 179,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("li", { children: "• Use the Bulk Chit Payment directory to manage Bulk Chit Payment transaction details and view payment information all in one place." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 180,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("li", { children: "• Use the Chit Registration Payment Link directory to manage Registration Payment Link transaction details and view payment information all in one place." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                    lineNumber: 181,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                  lineNumber: 178,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
                lineNumber: 173,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
              lineNumber: 166,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
            lineNumber: 161,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
          lineNumber: 72,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        @keyframes tilt {
          0%, 50%, 100% {
            transform: rotate(0deg);
          }
          25% {
            transform: rotate(0.5deg);
          }
          75% {
            transform: rotate(-0.5deg);
          }
        }
        .animate-tilt {
          animation: tilt 10s infinite;
        }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
      lineNumber: 190,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
};
_c = PaymentLinkMenu;
export default PaymentLinkMenu;
var _c;
$RefreshReg$(_c, "PaymentLinkMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentLinkMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VRO0FBcEVSLE9BQU9BLG9CQUFZO0FBQUEsTUFBOEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2pELE9BQU9DLGFBQWE7QUFFcEIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxVQUFVQyxXQUFXQyxhQUFhQyxnQkFBZ0JDLGNBQWNDLEtBQUtDLFVBQVVDLG9CQUFvQjtBQUM1RyxPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsa0JBQWtCQSxNQUFNO0FBQzVCLFFBQU1DLDhCQUE4QjtBQUFBLElBQ2xDO0FBQUEsTUFDRUMsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsVUFBVTtBQUFBLE1BQ1ZDLE1BQU1uQjtBQUFBQSxNQUNOb0IsVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLGVBQWViO0FBQUFBLE1BQ2ZjLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFWCxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxVQUFVO0FBQUEsTUFDVkMsTUFBTWpCO0FBQUFBLE1BQ05rQixVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZWI7QUFBQUEsTUFDZmMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLE1BQ0VYLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEUsVUFBVTtBQUFBLE1BQ1ZELGFBQWE7QUFBQSxNQUNiRSxNQUFNaEI7QUFBQUEsTUFDTmlCLFVBQVU7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxlQUFlYjtBQUFBQSxNQUNmYyxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLElBQ1g7QUFBQSxFQUFDO0FBR0gsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxxREFVYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwrQkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQ3pCLHVCQUFDLFNBQUksV0FBVSxnQkFDVDtBQUFBLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVc7QUFBQSxVQUVmLHVCQUFDLFNBQUksV0FBVSxTQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw0TEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3TTtBQUFBLGNBQ3hNLHVCQUFDLFNBQUksV0FBVSw4SEFDYixpQ0FBQyxZQUFTLFdBQVUsd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUVDO0FBQUEscUNBQUMsUUFBRyxXQUFVLGdIQUErRyx1Q0FBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUE4Qix3REFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUY7QUFBQSxpQkFMckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsOERBQ1paLHNDQUE0QmEsSUFBSSxDQUFDQyxhQUFhO0FBQzdDLGtCQUFNQyxPQUFPRCxTQUFTVDtBQUN0QixrQkFBTVcsZ0JBQWdCRixTQUFTSjtBQUMvQixtQkFDRSx1QkFBQyxRQUF1QixJQUFJSSxTQUFTTixNQUFNLFdBQVUsU0FDbkQsaUNBQUMsU0FBSSxXQUFVLDBMQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJIQUNiLGlDQUFDLFNBQUksV0FBVyw4Q0FBOENNLFNBQVNSLFFBQVEsTUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUYsS0FEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDRDQUViO0FBQUEsdUNBQUMsU0FBSSxXQUFXLG1FQUFtRVEsU0FBU1AsVUFBVSwwQkFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEg7QUFBQSxnQkFHOUgsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLG1KQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStKO0FBQUEsb0JBQy9KLHVCQUFDLFNBQUksV0FBVyxrQ0FBa0NPLFNBQVNGLE9BQU8sOEhBQ2hFLGlDQUFDLFFBQUssV0FBVyxXQUFXRSxTQUFTSCxTQUFTLE1BQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlELEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlOQUNiLGlDQUFDLGlCQUFjLFdBQVUsNEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlELEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLCtNQUNYRyxtQkFBU1osU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHVDQUNWWSxtQkFBU1gsZUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHVGQUNiVyxtQkFBU1YsWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnRkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHFEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlFO0FBQUEsc0JBQ2pFLHVCQUFDLFNBQUksV0FBVSxxRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRjtBQUFBLHlCQUZuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDhEQUNiVSxtQkFBU0wsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwySkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSx5QkFBd0IsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStDO0FBQUEsb0JBQy9DLHVCQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQSx1QkFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBY0E7QUFBQSxtQkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4Q0E7QUFBQSxpQkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzREEsS0F2RFNLLFNBQVNiLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0RBO0FBQUEsVUFFSixDQUFDLEtBL0RIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0VBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsd0lBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0hBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEg7QUFBQSxZQUM1SCx1QkFBQyxTQUFJLFdBQVUsa0hBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEg7QUFBQSxZQUU5SCx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsb0pBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0s7QUFBQSxnQkFDaEssdUJBQUMsU0FBSSxXQUFVLHNGQUNiLGlDQUFDLE9BQUksV0FBVSw2QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QyxLQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsaUVBQWdFO0FBQUE7QUFBQSxrQkFFNUUsdUJBQUMsWUFBUyxXQUFVLDJDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRDtBQUFBLHFCQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDRDQUNaO0FBQUEseUNBQUMsUUFBRyxvSkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3STtBQUFBLGtCQUN4SSx1QkFBQyxRQUFHLG9KQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdJO0FBQUEsa0JBQ3hJLHVCQUFDLFFBQUcseUtBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNko7QUFBQSxxQkFIL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxlQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLGFBakhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrSEE7QUFBQSxXQXBIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUhBO0FBQUEsU0FoSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlJQTtBQUFBLElBRUEsdUJBQUMsV0FBTSxLQUFHLE1BQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNDRTtBQUFBLE9BMUtKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyS0E7QUFFSjtBQUFFZ0IsS0E1TklsQjtBQThOTixlQUFlQTtBQUFnQixJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5hdmJhciIsIlNpZGViYXIiLCJNZEFkZExpbmsiLCJMaW5rIiwiUGlMaW5rU2ltcGxlQnJlYWtGaWxsIiwiRmFXcGZvcm1zIiwiQmFua25vdGUiLCJCcmllZmNhc2UiLCJUaWNrZXRDaGVjayIsIk1vcmVIb3Jpem9udGFsIiwiQ2hldnJvblJpZ2h0IiwiWmFwIiwiU3BhcmtsZXMiLCJBcnJvd1VwUmlnaHQiLCJCcmVhZGNydW1iIiwiUGF5bWVudExpbmtNZW51IiwicGF5bWVudEluTGlua01lbnVDYXRlZ29yaWVzIiwiaWQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic3VidGl0bGUiLCJpY29uIiwiZ3JhZGllbnQiLCJiZ0dyYWRpZW50IiwiaHJlZiIsInN0YXRzIiwic2Vjb25kYXJ5SWNvbiIsImljb25Db2xvciIsImJnQ29sb3IiLCJtYXAiLCJjYXRlZ29yeSIsIkljb24iLCJTZWNvbmRhcnlJY29uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5bWVudExpbmtNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5cclxuaW1wb3J0IHsgTWRBZGRMaW5rIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBQaUxpbmtTaW1wbGVCcmVha0ZpbGwgfSBmcm9tIFwicmVhY3QtaWNvbnMvcGlcIjtcclxuaW1wb3J0IHsgRmFXcGZvcm1zIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhNlwiO1xyXG5pbXBvcnQgeyBCYW5rbm90ZSwgQnJpZWZjYXNlLCBUaWNrZXRDaGVjaywgTW9yZUhvcml6b250YWwsIENoZXZyb25SaWdodCwgWmFwLCBTcGFya2xlcywgQXJyb3dVcFJpZ2h0IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCBQYXltZW50TGlua01lbnUgPSAoKSA9PiB7XHJcbiAgY29uc3QgcGF5bWVudEluTGlua01lbnVDYXRlZ29yaWVzID0gW1xyXG4gICAge1xyXG4gICAgICBpZDogMSxcclxuICAgICAgdGl0bGU6IFwiQ2hpdCBQYXltZW50IExpbmtcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGN1c3RvbWVyIGNoaXQgcGF5bWVudCBsaW5rIHRyYW5zYWN0aW9uIGluZm9ybWF0aW9uLlwiLFxyXG4gICAgICBzdWJ0aXRsZTogXCJJbmRpdmlkdWFsIE1vZGVcIixcclxuICAgICAgaWNvbjogTWRBZGRMaW5rLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLXZpb2xldC01MDAgdmlhLXB1cnBsZS01MDAgdG8tcGluay01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLXZpb2xldC01MCB2aWEtcHVycGxlLTUwIHRvLXBpbmstNTBcIixcclxuICAgICAgaHJlZjogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvcGF5bWVudC1saW5rLW1lbnUvY2hpdC1wYXltZW50XCIsXHJcbiAgICAgIHN0YXRzOiBcIkNoaXQgUGF5bWVudCBMaW5rIEluZm9ybWF0aW9uXCIsXHJcbiAgICAgIHNlY29uZGFyeUljb246IEFycm93VXBSaWdodCxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtdmlvbGV0LTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLXZpb2xldC0xMDBcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IDIsXHJcbiAgICAgIHRpdGxlOiBcIkJ1bGsgQ2hpdCBQYXltZW50IExpbmtcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGN1c3RvbWVyIEJ1bGsgY2hpdCBwYXltZW50IGxpbmsgdHJhbnNhY3Rpb24gaW5mb3JtYXRpb24uXCIsXHJcbiAgICAgIHN1YnRpdGxlOiBcIkJ1bGsgTW9kZVwiLFxyXG4gICAgICBpY29uOiBQaUxpbmtTaW1wbGVCcmVha0ZpbGwsXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tdmlvbGV0LTUwMCB2aWEtaW5kaWdvLTUwMCB0by1wdXJwbGUtNTAwXCIsXHJcbiAgICAgIGJnR3JhZGllbnQ6IFwiZnJvbS12aW9sZXQtNTAgdmlhLWluZGlnby01MCB0by1wdXJwbGUtNTBcIixcclxuICAgICAgaHJlZjogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvcGF5bWVudC1saW5rLW1lbnUvY2hpdC1idWxrLXBheW1lbnRcIixcclxuICAgICAgc3RhdHM6IFwiQnVsayBDaGl0IFBheW1lbnQgTGluayBJbmZvcm1hdGlvblwiLFxyXG4gICAgICBzZWNvbmRhcnlJY29uOiBBcnJvd1VwUmlnaHQsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LXZpb2xldC02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy12aW9sZXQtMTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAzLFxyXG4gICAgICB0aXRsZTogXCJDaGl0IFJlZ2lzdHJhdGlvbiBQYXltZW50IExpbmtcIixcclxuICAgICAgc3VidGl0bGU6IFwiSW5kaXZpZHVhbCBNb2RlXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBjdXN0b21lciBjaGl0IFJlZ2lzdHJhdGlvbiBwYXltZW50IGxpbmsgdHJhbnNhY3Rpb24gaW5mb3JtYXRpb24uXCIsXHJcbiAgICAgIGljb246IEZhV3Bmb3JtcyxcclxuICAgICAgZ3JhZGllbnQ6IFwiZnJvbS1lbWVyYWxkLTUwMCB2aWEtdGVhbC01MDAgdG8tY3lhbi01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLWVtZXJhbGQtNTAgdmlhLXRlYWwtNTAgdG8tY3lhbi01MFwiLFxyXG4gICAgICBocmVmOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9wYXltZW50LWxpbmstbWVudS9yZWdpc3RyYXRpb24tY2hpdC1wYXltZW50XCIsXHJcbiAgICAgIHN0YXRzOiBcIkNoaXQgUmVnaXN0cmF0aW9uIFBheW1lbnQgTGluayBJbmZvcm1hdGlvblwiLFxyXG4gICAgICBzZWNvbmRhcnlJY29uOiBBcnJvd1VwUmlnaHQsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LWVtZXJhbGQtNjAwXCIsXHJcbiAgICAgIGJnQ29sb3I6IFwiYmctZW1lcmFsZC0xMDBcIlxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgXHJcbiAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTUwIHZpYS13aGl0ZSB0by1ncmF5LTUwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCAtbGVmdC00IHctNzIgaC03MiBiZy1wdXJwbGUtMzAwIHJvdW5kZWQtZnVsbCBtaXgtYmxlbmQtbXVsdGlwbHkgZmlsdGVyIGJsdXIteGwgb3BhY2l0eS0yMCBhbmltYXRlLWJsb2JcIj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCAtcmlnaHQtNCB3LTcyIGgtNzIgYmcteWVsbG93LTMwMCByb3VuZGVkLWZ1bGwgbWl4LWJsZW5kLW11bHRpcGx5IGZpbHRlciBibHVyLXhsIG9wYWNpdHktMjAgYW5pbWF0ZS1ibG9iIGFuaW1hdGlvbi1kZWxheS0yMDAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWJvdHRvbS04IGxlZnQtMjAgdy03MiBoLTcyIGJnLXBpbmstMzAwIHJvdW5kZWQtZnVsbCBtaXgtYmxlbmQtbXVsdGlwbHkgZmlsdGVyIGJsdXIteGwgb3BhY2l0eS0yMCBhbmltYXRlLWJsb2IgYW5pbWF0aW9uLWRlbGF5LTQwMDBcIj48L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PiAqL31cclxuXHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgc2VjdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtaW5zZXQtMSBiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTYwMCB0by1wdXJwbGUtNjAwIHJvdW5kZWQtMnhsIGJsdXItbGcgb3BhY2l0eS03NSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTEwMDAgZ3JvdXAtaG92ZXI6ZHVyYXRpb24tMjAwIGFuaW1hdGUtdGlsdFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctMTYgaC0xNiByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MDAgdG8tcHVycGxlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctMnhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJhbmtub3RlIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1zbGF0ZS05MDAgdmlhLXB1cnBsZS05MDAgdG8tc2xhdGUtOTAwIGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBMaW5rIE1hbmFnZW1lbnRcclxuICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgbXQtMSB0ZXh0LWxnXCI+TWFuYWdlIGFuZCB2aWV3IHBheW1lbnQgbGluayBpbmZvcm1hdGlvbjwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBDYXJkcyBzZWN0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTggbWItMTJcIj5cclxuICAgICAgICAgICAgICB7cGF5bWVudEluTGlua01lbnVDYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IEljb24gPSBjYXRlZ29yeS5pY29uO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgU2Vjb25kYXJ5SWNvbiA9IGNhdGVnb3J5LnNlY29uZGFyeUljb247XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8TGluayBrZXk9e2NhdGVnb3J5LmlkfSB0bz17Y2F0ZWdvcnkuaHJlZn0gY2xhc3NOYW1lPVwiZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0zeGwgYmctd2hpdGUvODAgYmFja2Ryb3AtYmx1ci14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzIwIHNoYWRvdy0yeGwgaG92ZXI6c2hhZG93LTN4bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi03MDAgdHJhbnNmb3JtIGhvdmVyOi10cmFuc2xhdGUteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogR3JhZGllbnQgYm9yZGVyIG9uIGhvdmVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHJvdW5kZWQtM3hsIGJnLWdyYWRpZW50LXRvLXIgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi03MDAgcC1bMnB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCBoLWZ1bGwgcm91bmRlZC0zeGwgYmctZ3JhZGllbnQtdG8tciAke2NhdGVnb3J5LmdyYWRpZW50fWB9PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBDYXJkIGNvbnRlbnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtZnVsbCBiZy13aGl0ZSByb3VuZGVkLTN4bCBwLThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJhY2tncm91bmQgZGVjb3JhdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtNCByaWdodC00IHctMzIgaC0zMiByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgJHtjYXRlZ29yeS5iZ0dyYWRpZW50fSBvcGFjaXR5LTMwIGJsdXItMnhsYH0+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogSWNvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gbWItNiByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC00MDAgdG8tcHVycGxlLTQwMCByb3VuZGVkLTJ4bCBibHVyLWxnIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTQwIHRyYW5zaXRpb24gZHVyYXRpb24tNTAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHJlbGF0aXZlIHctMTYgaC0xNiByb3VuZGVkLTJ4bCAke2NhdGVnb3J5LmJnQ29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzUwIGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPXtgdy04IGgtOCAke2NhdGVnb3J5Lmljb25Db2xvcn1gfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS01MCB0by13aGl0ZSBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNTAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCB0cmFuc2Zvcm0gdHJhbnNsYXRlLXgtNCBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2Vjb25kYXJ5SWNvbiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc2xhdGUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQ29udGVudCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi0zIGdyb3VwLWhvdmVyOmJnLWdyYWRpZW50LXRvLXIgZ3JvdXAtaG92ZXI6ZnJvbS12aW9sZXQtNjAwIGdyb3VwLWhvdmVyOnRvLXB1cnBsZS02MDAgZ3JvdXAtaG92ZXI6YmctY2xpcC10ZXh0IGdyb3VwLWhvdmVyOnRleHQtdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBsZWFkaW5nLXJlbGF4ZWQgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgYmctc2xhdGUtMTAwIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LnN1YnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9vdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC02IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAvNTAgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yIGgtMiBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2VcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHctMiBoLTIgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXBpbmdcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuc3RhdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXZpb2xldC02MDAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zZm9ybSB0cmFuc2xhdGUteC00IGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5FeHBsb3JlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB7LyogVGlwcyBzZWN0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtOCBiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MCB2aWEtcHVycGxlLTUwIHRvLXBpbmstNTAgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci13aGl0ZS81MCBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgIHsvKiBCYWNrZ3JvdW5kIGRlY29yYXRpb25zICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTQwIGgtNDAgYmctZ3JhZGllbnQtdG8tYmwgZnJvbS12aW9sZXQtMjAwLzMwIHRvLXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBibHVyLTN4bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHctNDAgaC00MCBiZy1ncmFkaWVudC10by10ciBmcm9tLXB1cnBsZS0yMDAvMzAgdG8tdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGJsdXItM3hsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAwIHRvLXB1cnBsZS01MDAgcm91bmRlZC0yeGwgYmx1ci1sZyBvcGFjaXR5LTUwIGdyb3VwLWhvdmVyOm9wYWNpdHktNzUgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctd2hpdGUgc2hhZG93LXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtdmlvbGV0LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFF1aWNrIFRpcHNcclxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXZpb2xldC01MDAgYW5pbWF0ZS1wdWxzZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBsZWFkaW5nLXJlbGF4ZWQgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPuKAoiBVc2UgdGhlIENoaXQgUGF5bWVudCBMaW5rIGRpcmVjdG9yeSB0byBtYW5hZ2UgQ2hpdCBQYXltZW50IExpbmsgdHJhbnNhY3Rpb24gZGV0YWlscyBhbmQgdmlldyBwYXltZW50IGluZm9ybWF0aW9uIGFsbCBpbiBvbmUgcGxhY2UuPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGk+4oCiIFVzZSB0aGUgQnVsayBDaGl0IFBheW1lbnQgZGlyZWN0b3J5IHRvIG1hbmFnZSBCdWxrIENoaXQgUGF5bWVudCB0cmFuc2FjdGlvbiBkZXRhaWxzIGFuZCB2aWV3IHBheW1lbnQgaW5mb3JtYXRpb24gYWxsIGluIG9uZSBwbGFjZS48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaT7igKIgVXNlIHRoZSBDaGl0IFJlZ2lzdHJhdGlvbiBQYXltZW50IExpbmsgZGlyZWN0b3J5IHRvIG1hbmFnZSBSZWdpc3RyYXRpb24gUGF5bWVudCBMaW5rIHRyYW5zYWN0aW9uIGRldGFpbHMgYW5kIHZpZXcgcGF5bWVudCBpbmZvcm1hdGlvbiBhbGwgaW4gb25lIHBsYWNlLjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8c3R5bGUganN4PntgXHJcbiAgICAgICAgQGtleWZyYW1lcyBibG9iIHtcclxuICAgICAgICAgIDAlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMHB4LCAwcHgpIHNjYWxlKDEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgMzMlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMzBweCwgLTUwcHgpIHNjYWxlKDEuMSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICA2NiUge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMjBweCwgMjBweCkgc2NhbGUoMC45KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDEwMCUge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgwcHgsIDBweCkgc2NhbGUoMSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRlLWJsb2Ige1xyXG4gICAgICAgICAgYW5pbWF0aW9uOiBibG9iIDdzIGluZmluaXRlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuYW5pbWF0aW9uLWRlbGF5LTIwMDAge1xyXG4gICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAycztcclxuICAgICAgICB9XHJcbiAgICAgICAgLmFuaW1hdGlvbi1kZWxheS00MDAwIHtcclxuICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogNHM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIEBrZXlmcmFtZXMgdGlsdCB7XHJcbiAgICAgICAgICAwJSwgNTAlLCAxMDAlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAyNSUge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwLjVkZWcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgNzUlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoLTAuNWRlZyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRlLXRpbHQge1xyXG4gICAgICAgICAgYW5pbWF0aW9uOiB0aWx0IDEwcyBpbmZpbml0ZTtcclxuICAgICAgICB9XHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYXltZW50TGlua01lbnU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BheW1lbnRMaW5rTWVudS5qc3gifQ==