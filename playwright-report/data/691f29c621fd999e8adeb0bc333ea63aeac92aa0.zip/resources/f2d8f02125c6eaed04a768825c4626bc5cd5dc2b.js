import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeCollectionCustomerReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import api from "/src/instance/TokenInstance.js";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const EmployeeCollectionCustomerReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState({
    totalCustomers: 0,
    totalEnrollments: 0,
    totalOutstanding: 0,
    totalInvestment: 0
  });
  const [formData, setFormData] = useState({
    employee: "",
    customer: "",
    filterType: "Today"
  });
  const hasFetched = useRef(false);
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value || ""
    }));
  };
  const fetchEmployees = async () => {
    try {
      const response = await api.get("/employee/");
      const verifiedEmployees = (response.data?.employee || []).filter((emp) => emp.isVerified);
      setEmployees(verifiedEmployees);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const fetchCustomers = async (employeeId) => {
    try {
      if (!employeeId) {
        setCustomers([]);
        return;
      }
      const response = await api.get("/user/get-user");
      setCustomers(response.data || []);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchCustomers(formData.employee);
  }, [formData.employee]);
  const fetchEmployeeCustomers = useCallback(
    async () => {
      try {
        setLoading(true);
        let data = [];
        if (formData.employee) {
          const response = await api.get(
            `/v1/admin/employees/${formData.employee}/collection-customers`
          );
          data = response.data?.data || [];
        } else {
          const responses = await Promise.all(
            employees.map(
              (emp) => api.get(
                `/v1/admin/employees/${emp._id}/collection-customers`
              )
            )
          );
          data = responses.flatMap(
            (res) => res.data?.data || []
          );
        }
        if (formData.customer) {
          data = data.filter(
            (item) => item.user_id?._id === formData.customer
          );
        }
        setSummary({
          totalCustomers: new Set(
            data.map((item) => item.user_id?._id)
          ).size,
          totalEnrollments: data.length,
          totalOutstanding: data.reduce(
            (sum, item) => sum + (item.total_balance || 0),
            0
          ),
          totalInvestment: data.reduce(
            (sum, item) => sum + (item.total_investment || 0),
            0
          )
        });
        const formatted = data.map((item, index) => ({
          id: item._id,
          slNo: index + 1,
          customerName: item.user_id?.full_name || "-",
          phone: item.user_id?.phone_number || "-",
          group: item.group_id?.group_name || "-",
          tickets: item.tickets || 0,
          installment: item.group_install || 0,
          investment: item.total_investment || 0,
          outstanding: item.total_balance || 0,
          isPrized: item.is_prized === true ? "Prized" : "Not Prized",
          totalProfit: item.total_profit || 0,
          totalPenalty: item.total_penalty || 0,
          totalLateFee: item.total_late_fee || 0,
          status: item.customer_status || "-",
          joinedDate: item.createdAt ? new Date(item.createdAt).toLocaleDateString("en-GB").replace(/\//g, "-") : "-"
        }));
        setReportData(formatted);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    },
    [
      employees,
      formData.employee,
      formData.customer
    ]
  );
  useEffect(() => {
    if (!employees.length) return;
    if (!hasFetched.current) {
      hasFetched.current = true;
      fetchEmployeeCustomers();
    }
  }, [employees, fetchEmployeeCustomers]);
  useEffect(
    () => {
      if (!employees.length) return;
      if (hasFetched.current) {
        fetchEmployeeCustomers();
      }
    },
    [
      formData.employee,
      formData.customer
    ]
  );
  const columns = [
    {
      key: "slNo",
      header: "Sl No"
    },
    {
      key: "status",
      header: "Customer Status"
    },
    {
      key: "isPrized",
      header: "Auction Status"
    },
    {
      key: "joinedDate",
      header: "Joined Date"
    },
    {
      key: "customerName",
      header: "Customer Name"
    },
    {
      key: "phone",
      header: "Phone"
    },
    {
      key: "group",
      header: "Group"
    },
    {
      key: "tickets",
      header: "Ticket"
    },
    {
      key: "installment",
      header: "Group Installment"
    },
    {
      key: "totalProfit",
      header: "Total Profit"
    },
    {
      key: "investment",
      header: "Total Investment"
    },
    {
      key: "totalPenalty",
      header: "Total Penalty"
    },
    {
      key: "totalLateFee",
      header: "Total Late Fee"
    },
    {
      key: "outstanding",
      header: "Balance"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10 w-full overflow-x-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow min-w-[900px] p-7", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Employee Collection Customer Report" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
      lineNumber: 273,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Employee" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 279,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-12",
            placeholder: "Select Employee",
            value: formData.employee || void 0,
            onChange: (value) => {
              setFormData((prev) => ({
                ...prev,
                employee: value,
                customer: ""
              }));
            },
            allowClear: true,
            showSearch: true,
            optionFilterProp: "children",
            filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Employees" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
                lineNumber: 301,
                columnNumber: 29
              }, this),
              employees.map(
                (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: emp.name }, emp._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
                  lineNumber: 303,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
            lineNumber: 281,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 278,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 311,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-12",
            placeholder: "All Customers",
            value: formData.customer || void 0,
            onChange: (value) => handleAntDSelect("customer", value),
            allowClear: true,
            showSearch: true,
            optionFilterProp: "children",
            filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
                lineNumber: 327,
                columnNumber: 29
              }, this),
              customers.map(
                (customer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: customer._id, children: customer.full_name }, customer._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
                  lineNumber: 329,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
            lineNumber: 313,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 310,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
      lineNumber: 277,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Customers" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 341,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: summary.totalCustomers }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 342,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 340,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Enrollments" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 346,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: summary.totalEnrollments }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 347,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 345,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Balance" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 351,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: [
          "₹",
          summary.totalOutstanding
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 352,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 350,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Investment" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 356,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: [
          "₹",
          summary.totalInvestment
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
          lineNumber: 357,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 355,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
      lineNumber: 339,
      columnNumber: 17
    }, this),
    reportData.length > 0 && !loading ? /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        columns,
        data: reportData,
        exportedFileName: "Employee Referred Customer Report",
        exportedPdfName: "Employee Referred Customer Report"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 362,
        columnNumber: 9
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      CircularLoader,
      {
        isLoading: loading,
        failure: !loading && reportData.length === 0,
        data: "Employee Referred Customers"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
        lineNumber: 369,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
    lineNumber: 272,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx",
    lineNumber: 271,
    columnNumber: 5
  }, this);
};
_s(EmployeeCollectionCustomerReport, "Eer3RjgPFCrpKg+M1s02vm1FY7g=");
_c = EmployeeCollectionCustomerReport;
export default EmployeeCollectionCustomerReport;
var _c;
$RefreshReg$(_c, "EmployeeCollectionCustomerReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeCollectionCustomerReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1JnQjsyQkFoUmhCO0FBQWdCQSxNQUFXQyxjQUFVQyxPQUFRQyxzQkFBbUIsZUFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN2RSxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxjQUFjO0FBRXZCLE1BQU1DLG1DQUFtQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQzNDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJWixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDYSxXQUFXQyxZQUFZLElBQUlkLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNlLFlBQVlDLGFBQWEsSUFBSWhCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNpQixTQUFTQyxVQUFVLElBQUlsQixTQUFTLEtBQUs7QUFFNUMsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBUztBQUFBLElBQ25DcUIsZ0JBQWdCO0FBQUEsSUFDaEJDLGtCQUFrQjtBQUFBLElBQ2xCQyxrQkFBa0I7QUFBQSxJQUNsQkMsaUJBQWlCO0FBQUEsRUFDckIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJMUIsU0FBUztBQUFBLElBQ3JDMkIsVUFBVTtBQUFBLElBQ1ZDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsRUFDaEIsQ0FBQztBQUVELFFBQU1DLGFBQWE3QixPQUFPLEtBQUs7QUFFL0IsUUFBTThCLG1CQUFtQkEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN2Q1AsZ0JBQVksQ0FBQ1EsVUFBVTtBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHQyxTQUFTO0FBQUEsSUFDdEIsRUFBRTtBQUFBLEVBQ047QUFHQSxRQUFNRSxpQkFBaUIsWUFBWTtBQUMvQixRQUFJO0FBQ0EsWUFBTUMsV0FBVyxNQUFNN0IsSUFBSThCLElBQUksWUFBWTtBQUUzQyxZQUFNQyxxQkFDRkYsU0FBU0csTUFBTVosWUFBWSxJQUM3QmEsT0FBTyxDQUFDQyxRQUFRQSxJQUFJQyxVQUFVO0FBRWhDOUIsbUJBQWEwQixpQkFBaUI7QUFBQSxJQUNsQyxTQUFTSyxPQUFPO0FBQ1pDLGNBQVFDLElBQUlGLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0o7QUFFQTVDLFlBQVUsTUFBTTtBQUNab0MsbUJBQWU7QUFBQSxFQUNuQixHQUFHLEVBQUU7QUFHTCxRQUFNVyxpQkFBaUIsT0FBT0MsZUFBZTtBQUN6QyxRQUFJO0FBQ0EsVUFBSSxDQUFDQSxZQUFZO0FBQ2JqQyxxQkFBYSxFQUFFO0FBQ2Y7QUFBQSxNQUNKO0FBRUEsWUFBTXNCLFdBQVcsTUFBTTdCLElBQUk4QixJQUFJLGdCQUFnQjtBQUUvQ3ZCLG1CQUFhc0IsU0FBU0csUUFBUSxFQUFFO0FBQUEsSUFDcEMsU0FBU0ksT0FBTztBQUNaQyxjQUFRQyxJQUFJRixLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNKO0FBRUE1QyxZQUFVLE1BQU07QUFDWitDLG1CQUFlckIsU0FBU0UsUUFBUTtBQUFBLEVBQ3BDLEdBQUcsQ0FBQ0YsU0FBU0UsUUFBUSxDQUFDO0FBR3RCLFFBQU1xQix5QkFBeUI5QztBQUFBQSxJQUFZLFlBQVk7QUFDbkQsVUFBSTtBQUNBZ0IsbUJBQVcsSUFBSTtBQUVmLFlBQUlxQixPQUFPO0FBRVgsWUFBSWQsU0FBU0UsVUFBVTtBQUNuQixnQkFBTVMsV0FBVyxNQUFNN0IsSUFBSThCO0FBQUFBLFlBQ3ZCLHVCQUF1QlosU0FBU0UsUUFBUTtBQUFBLFVBQzVDO0FBRUFZLGlCQUFPSCxTQUFTRyxNQUFNQSxRQUFRO0FBQUEsUUFFbEMsT0FBTztBQUNILGdCQUFNVSxZQUFZLE1BQU1DLFFBQVFDO0FBQUFBLFlBQzVCeEMsVUFBVXlDO0FBQUFBLGNBQUksQ0FBQ1gsUUFDWGxDLElBQUk4QjtBQUFBQSxnQkFDQSx1QkFBdUJJLElBQUlZLEdBQUc7QUFBQSxjQUNsQztBQUFBLFlBQ0o7QUFBQSxVQUNKO0FBRUFkLGlCQUFPVSxVQUFVSztBQUFBQSxZQUNiLENBQUNDLFFBQVFBLElBQUloQixNQUFNQSxRQUFRO0FBQUEsVUFDL0I7QUFBQSxRQUdKO0FBR0EsWUFBSWQsU0FBU0csVUFBVTtBQUNuQlcsaUJBQU9BLEtBQUtDO0FBQUFBLFlBQ1IsQ0FBQ2dCLFNBQ0dBLEtBQUtDLFNBQVNKLFFBQVE1QixTQUFTRztBQUFBQSxVQUN2QztBQUFBLFFBQ0o7QUFFQVIsbUJBQVc7QUFBQSxVQUNQQyxnQkFBZ0IsSUFBSXFDO0FBQUFBLFlBQ2hCbkIsS0FBS2EsSUFBSSxDQUFDSSxTQUFTQSxLQUFLQyxTQUFTSixHQUFHO0FBQUEsVUFDeEMsRUFBRU07QUFBQUEsVUFFRnJDLGtCQUFrQmlCLEtBQUtxQjtBQUFBQSxVQUV2QnJDLGtCQUFrQmdCLEtBQUtzQjtBQUFBQSxZQUNuQixDQUFDQyxLQUFLTixTQUNGTSxPQUFPTixLQUFLTyxpQkFBaUI7QUFBQSxZQUNqQztBQUFBLFVBQ0o7QUFBQSxVQUVBdkMsaUJBQWlCZSxLQUFLc0I7QUFBQUEsWUFDbEIsQ0FBQ0MsS0FBS04sU0FDRk0sT0FBT04sS0FBS1Esb0JBQW9CO0FBQUEsWUFDcEM7QUFBQSxVQUNKO0FBQUEsUUFDSixDQUFDO0FBRUQsY0FBTUMsWUFBWTFCLEtBQUthLElBQUksQ0FBQ0ksTUFBTVUsV0FBVztBQUFBLFVBQ3pDQyxJQUFJWCxLQUFLSDtBQUFBQSxVQUNUZSxNQUFNRixRQUFRO0FBQUEsVUFDZEcsY0FDSWIsS0FBS0MsU0FBU2EsYUFBYTtBQUFBLFVBQy9CQyxPQUNJZixLQUFLQyxTQUFTZSxnQkFBZ0I7QUFBQSxVQUNsQ0MsT0FDSWpCLEtBQUtrQixVQUFVQyxjQUFjO0FBQUEsVUFDakNDLFNBQVNwQixLQUFLb0IsV0FBVztBQUFBLFVBQ3pCQyxhQUNJckIsS0FBS3NCLGlCQUFpQjtBQUFBLFVBQzFCQyxZQUNJdkIsS0FBS1Esb0JBQW9CO0FBQUEsVUFDN0JnQixhQUNJeEIsS0FBS08saUJBQWlCO0FBQUEsVUFFMUJrQixVQUNJekIsS0FBSzBCLGNBQWMsT0FDYixXQUNBO0FBQUEsVUFFVkMsYUFDSTNCLEtBQUs0QixnQkFBZ0I7QUFBQSxVQUV6QkMsY0FDSTdCLEtBQUs4QixpQkFBaUI7QUFBQSxVQUUxQkMsY0FDSS9CLEtBQUtnQyxrQkFBa0I7QUFBQSxVQUUzQkMsUUFDSWpDLEtBQUtrQyxtQkFBbUI7QUFBQSxVQUU1QkMsWUFBWW5DLEtBQUtvQyxZQUNYLElBQUlDLEtBQUtyQyxLQUFLb0MsU0FBUyxFQUNwQkUsbUJBQW1CLE9BQU8sRUFDMUJDLFFBQVEsT0FBTyxHQUFHLElBQ3JCO0FBQUEsUUFDVixFQUFFO0FBRUYvRSxzQkFBY2lELFNBQVM7QUFBQSxNQUMzQixTQUFTdEIsT0FBTztBQUNaQyxnQkFBUUMsSUFBSUYsS0FBSztBQUFBLE1BQ3JCLFVBQUM7QUFDR3pCLG1CQUFXLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0o7QUFBQSxJQUFHO0FBQUEsTUFDQ1A7QUFBQUEsTUFDQWMsU0FBU0U7QUFBQUEsTUFDVEYsU0FBU0c7QUFBQUEsSUFBUTtBQUFBLEVBQ3BCO0FBR0Q3QixZQUFVLE1BQU07QUFDWixRQUFJLENBQUNZLFVBQVVpRCxPQUFRO0FBR3ZCLFFBQUksQ0FBQzlCLFdBQVdrRSxTQUFTO0FBQ3JCbEUsaUJBQVdrRSxVQUFVO0FBQ3JCaEQsNkJBQXVCO0FBQUEsSUFDM0I7QUFBQSxFQUNKLEdBQUcsQ0FBQ3JDLFdBQVdxQyxzQkFBc0IsQ0FBQztBQUd0Q2pEO0FBQUFBLElBQVUsTUFBTTtBQUNaLFVBQUksQ0FBQ1ksVUFBVWlELE9BQVE7QUFFdkIsVUFBSTlCLFdBQVdrRSxTQUFTO0FBQ3BCaEQsK0JBQXVCO0FBQUEsTUFDM0I7QUFBQSxJQUNKO0FBQUEsSUFBRztBQUFBLE1BQ0N2QixTQUFTRTtBQUFBQSxNQUNURixTQUFTRztBQUFBQSxJQUFRO0FBQUEsRUFDcEI7QUFFRCxRQUFNcUUsVUFBVTtBQUFBLElBQ1o7QUFBQSxNQUNJQyxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUVBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsRUFBQztBQUdMLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHFDQUNYLGlDQUFDLFNBQUksV0FBVSwrQkFDWDtBQUFBLDJCQUFDLFFBQUcsV0FBVSwrQkFBOEIsbURBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFNBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsc0JBQXFCLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFFOUM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQSxZQUNaLE9BQU8xRSxTQUFTRSxZQUFZeUU7QUFBQUEsWUFDNUIsVUFBVSxDQUFDbkUsVUFBVTtBQUNqQlAsMEJBQVksQ0FBQ1EsVUFBVTtBQUFBLGdCQUNuQixHQUFHQTtBQUFBQSxnQkFDSFAsVUFBVU07QUFBQUEsZ0JBQ1ZMLFVBQVU7QUFBQSxjQUNkLEVBQUU7QUFBQSxZQUNOO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLGtCQUFpQjtBQUFBLFlBQ2pCLGNBQWMsQ0FBQ3lFLE9BQU9DLFlBQ2pCQSxRQUFRQyxZQUFZLElBQ2hCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLFlBR3JDO0FBQUEscUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLDZCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGNBQ3BDN0YsVUFBVXlDO0FBQUFBLGdCQUFJLENBQUNYLFFBQ1osdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUlZLEtBQ25DWixjQUFJaUUsUUFEV2pFLElBQUlZLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQTtBQUFBLFVBekJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTBCQTtBQUFBLFdBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHNCQUFxQix3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFFBRTlDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFVO0FBQUEsWUFDVixhQUFZO0FBQUEsWUFDWixPQUFPNUIsU0FBU0csWUFBWXdFO0FBQUFBLFlBQzVCLFVBQVUsQ0FBQ25FLFVBQVVGLGlCQUFpQixZQUFZRSxLQUFLO0FBQUEsWUFDdkQ7QUFBQSxZQUNBO0FBQUEsWUFDQSxrQkFBaUI7QUFBQSxZQUNqQixjQUFjLENBQUNvRSxPQUFPQyxZQUNqQkEsUUFBUUMsWUFBWSxJQUNoQkMsWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxZQUdyQztBQUFBLHFDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNwQzNGLFVBQVV1QztBQUFBQSxnQkFBSSxDQUFDeEIsYUFDWix1QkFBQyxPQUFPLFFBQVAsRUFBaUMsT0FBT0EsU0FBU3lCLEtBQzdDekIsbUJBQVMwQyxhQURNMUMsU0FBU3lCLEtBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQTtBQUFBLFVBbkJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9CQTtBQUFBLFdBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxTQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsSUFJQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSwrQkFBQyxPQUFFLCtCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUNsQix1QkFBQyxRQUFJbEMsa0JBQVFFLGtCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxXQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLCtCQUFDLE9BQUUsaUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBLFFBQ3BCLHVCQUFDLFFBQUlGLGtCQUFRRyxvQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsV0FGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1g7QUFBQSwrQkFBQyxPQUFFLDZCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUNoQix1QkFBQyxRQUFHO0FBQUE7QUFBQSxVQUFFSCxRQUFRSTtBQUFBQSxhQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxXQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBLCtCQUFDLE9BQUUsZ0NBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFFBQ25CLHVCQUFDLFFBQUc7QUFBQTtBQUFBLFVBQUVKLFFBQVFLO0FBQUFBLGFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVDVCxXQUFXNkMsU0FBUyxLQUFLLENBQUMzQyxVQUN2QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0c7QUFBQSxRQUNBLE1BQU1GO0FBQUFBLFFBQ04sa0JBQWlCO0FBQUEsUUFDakIsaUJBQWdCO0FBQUE7QUFBQSxNQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJdUQsSUFHdkQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFdBQVdFO0FBQUFBLFFBQ1gsU0FBUyxDQUFDQSxXQUFXRixXQUFXNkMsV0FBVztBQUFBLFFBQzNDLE1BQUs7QUFBQTtBQUFBLE1BSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR3NDO0FBQUEsT0FwRzlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1R0EsS0F4R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlHQTtBQUdSO0FBQUVsRCxHQWxYSUQsa0NBQWdDO0FBQUFrRyxLQUFoQ2xHO0FBcVhOLGVBQWVBO0FBQWlDLElBQUFrRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VDYWxsYmFjayIsIk5hdmJhciIsIlNpZGViYXIiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsImFwaSIsIlNlbGVjdCIsIkVtcGxveWVlQ29sbGVjdGlvbkN1c3RvbWVyUmVwb3J0IiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJjdXN0b21lcnMiLCJzZXRDdXN0b21lcnMiLCJyZXBvcnREYXRhIiwic2V0UmVwb3J0RGF0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic3VtbWFyeSIsInNldFN1bW1hcnkiLCJ0b3RhbEN1c3RvbWVycyIsInRvdGFsRW5yb2xsbWVudHMiLCJ0b3RhbE91dHN0YW5kaW5nIiwidG90YWxJbnZlc3RtZW50IiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImVtcGxveWVlIiwiY3VzdG9tZXIiLCJmaWx0ZXJUeXBlIiwiaGFzRmV0Y2hlZCIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInZhbHVlIiwicHJldiIsImZldGNoRW1wbG95ZWVzIiwicmVzcG9uc2UiLCJnZXQiLCJ2ZXJpZmllZEVtcGxveWVlcyIsImRhdGEiLCJmaWx0ZXIiLCJlbXAiLCJpc1ZlcmlmaWVkIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwiZmV0Y2hDdXN0b21lcnMiLCJlbXBsb3llZUlkIiwiZmV0Y2hFbXBsb3llZUN1c3RvbWVycyIsInJlc3BvbnNlcyIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJfaWQiLCJmbGF0TWFwIiwicmVzIiwiaXRlbSIsInVzZXJfaWQiLCJTZXQiLCJzaXplIiwibGVuZ3RoIiwicmVkdWNlIiwic3VtIiwidG90YWxfYmFsYW5jZSIsInRvdGFsX2ludmVzdG1lbnQiLCJmb3JtYXR0ZWQiLCJpbmRleCIsImlkIiwic2xObyIsImN1c3RvbWVyTmFtZSIsImZ1bGxfbmFtZSIsInBob25lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXAiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXRzIiwiaW5zdGFsbG1lbnQiLCJncm91cF9pbnN0YWxsIiwiaW52ZXN0bWVudCIsIm91dHN0YW5kaW5nIiwiaXNQcml6ZWQiLCJpc19wcml6ZWQiLCJ0b3RhbFByb2ZpdCIsInRvdGFsX3Byb2ZpdCIsInRvdGFsUGVuYWx0eSIsInRvdGFsX3BlbmFsdHkiLCJ0b3RhbExhdGVGZWUiLCJ0b3RhbF9sYXRlX2ZlZSIsInN0YXR1cyIsImN1c3RvbWVyX3N0YXR1cyIsImpvaW5lZERhdGUiLCJjcmVhdGVkQXQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwicmVwbGFjZSIsImN1cnJlbnQiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRW1wbG95ZWVDb2xsZWN0aW9uQ3VzdG9tZXJSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VSZWYsIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuY29uc3QgRW1wbG95ZWVDb2xsZWN0aW9uQ3VzdG9tZXJSZXBvcnQgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtyZXBvcnREYXRhLCBzZXRSZXBvcnREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgdG90YWxDdXN0b21lcnM6IDAsXHJcbiAgICAgICAgdG90YWxFbnJvbGxtZW50czogMCxcclxuICAgICAgICB0b3RhbE91dHN0YW5kaW5nOiAwLFxyXG4gICAgICAgIHRvdGFsSW52ZXN0bWVudDogMCxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIGVtcGxveWVlOiBcIlwiLFxyXG4gICAgICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgIGZpbHRlclR5cGU6IFwiVG9kYXlcIixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGhhc0ZldGNoZWQgPSB1c2VSZWYoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIFtmaWVsZF06IHZhbHVlIHx8IFwiXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcblxyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlL1wiKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHZlcmlmaWVkRW1wbG95ZWVzID0gKFxyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW11cclxuICAgICAgICAgICAgKS5maWx0ZXIoKGVtcCkgPT4gZW1wLmlzVmVyaWZpZWQpO1xyXG5cclxuICAgICAgICAgICAgc2V0RW1wbG95ZWVzKHZlcmlmaWVkRW1wbG95ZWVzKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG5cclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJzID0gYXN5bmMgKGVtcGxveWVlSWQpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoIWVtcGxveWVlSWQpIHtcclxuICAgICAgICAgICAgICAgIHNldEN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG5cclxuICAgICAgICAgICAgc2V0Q3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEgfHwgW10pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgZmV0Y2hDdXN0b21lcnMoZm9ybURhdGEuZW1wbG95ZWUpO1xyXG4gICAgfSwgW2Zvcm1EYXRhLmVtcGxveWVlXSk7XHJcblxyXG5cclxuICAgIGNvbnN0IGZldGNoRW1wbG95ZWVDdXN0b21lcnMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgICAgIGxldCBkYXRhID0gW107XHJcblxyXG4gICAgICAgICAgICBpZiAoZm9ybURhdGEuZW1wbG95ZWUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgICAgICAgICAgICBgL3YxL2FkbWluL2VtcGxveWVlcy8ke2Zvcm1EYXRhLmVtcGxveWVlfS9jb2xsZWN0aW9uLWN1c3RvbWVyc2BcclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgZGF0YSA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2VzID0gYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICAgICAgICAgICAgZW1wbG95ZWVzLm1hcCgoZW1wKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcGkuZ2V0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYC92MS9hZG1pbi9lbXBsb3llZXMvJHtlbXAuX2lkfS9jb2xsZWN0aW9uLWN1c3RvbWVyc2BcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgZGF0YSA9IHJlc3BvbnNlcy5mbGF0TWFwKFxyXG4gICAgICAgICAgICAgICAgICAgIChyZXMpID0+IHJlcy5kYXRhPy5kYXRhIHx8IFtdXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGN1c3RvbWVyIGZpbHRlclxyXG4gICAgICAgICAgICBpZiAoZm9ybURhdGEuY3VzdG9tZXIpIHtcclxuICAgICAgICAgICAgICAgIGRhdGEgPSBkYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgICAoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS51c2VyX2lkPy5faWQgPT09IGZvcm1EYXRhLmN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgICAgICAgICAgIHRvdGFsQ3VzdG9tZXJzOiBuZXcgU2V0KFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEubWFwKChpdGVtKSA9PiBpdGVtLnVzZXJfaWQ/Ll9pZClcclxuICAgICAgICAgICAgICAgICkuc2l6ZSxcclxuXHJcbiAgICAgICAgICAgICAgICB0b3RhbEVucm9sbG1lbnRzOiBkYXRhLmxlbmd0aCxcclxuXHJcbiAgICAgICAgICAgICAgICB0b3RhbE91dHN0YW5kaW5nOiBkYXRhLnJlZHVjZShcclxuICAgICAgICAgICAgICAgICAgICAoc3VtLCBpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gKyAoaXRlbS50b3RhbF9iYWxhbmNlIHx8IDApLFxyXG4gICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgICAgICAgdG90YWxJbnZlc3RtZW50OiBkYXRhLnJlZHVjZShcclxuICAgICAgICAgICAgICAgICAgICAoc3VtLCBpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gKyAoaXRlbS50b3RhbF9pbnZlc3RtZW50IHx8IDApLFxyXG4gICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gZGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJOYW1lOlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgcGhvbmU6XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBncm91cDpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgdGlja2V0czogaXRlbS50aWNrZXRzIHx8IDAsXHJcbiAgICAgICAgICAgICAgICBpbnN0YWxsbWVudDpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLmdyb3VwX2luc3RhbGwgfHwgMCxcclxuICAgICAgICAgICAgICAgIGludmVzdG1lbnQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS50b3RhbF9pbnZlc3RtZW50IHx8IDAsXHJcbiAgICAgICAgICAgICAgICBvdXRzdGFuZGluZzpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRvdGFsX2JhbGFuY2UgfHwgMCxcclxuXHJcbiAgICAgICAgICAgICAgICBpc1ByaXplZDpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLmlzX3ByaXplZCA9PT0gdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiUHJpemVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk5vdCBQcml6ZWRcIixcclxuXHJcbiAgICAgICAgICAgICAgICB0b3RhbFByb2ZpdDpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRvdGFsX3Byb2ZpdCB8fCAwLFxyXG5cclxuICAgICAgICAgICAgICAgIHRvdGFsUGVuYWx0eTpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRvdGFsX3BlbmFsdHkgfHwgMCxcclxuXHJcbiAgICAgICAgICAgICAgICB0b3RhbExhdGVGZWU6XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS50b3RhbF9sYXRlX2ZlZSB8fCAwLFxyXG5cclxuICAgICAgICAgICAgICAgIHN0YXR1czpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLmN1c3RvbWVyX3N0YXR1cyB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgICBqb2luZWREYXRlOiBpdGVtLmNyZWF0ZWRBdFxyXG4gICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoaXRlbS5jcmVhdGVkQXQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFwvL2csIFwiLVwiKVxyXG4gICAgICAgICAgICAgICAgICAgIDogXCItXCIsXHJcbiAgICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgICAgIHNldFJlcG9ydERhdGEoZm9ybWF0dGVkKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW1xyXG4gICAgICAgIGVtcGxveWVlcyxcclxuICAgICAgICBmb3JtRGF0YS5lbXBsb3llZSxcclxuICAgICAgICBmb3JtRGF0YS5jdXN0b21lcixcclxuICAgIF0pO1xyXG5cclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGlmICghZW1wbG95ZWVzLmxlbmd0aCkgcmV0dXJuO1xyXG5cclxuICAgICAgICAvLyBQcmV2ZW50IGR1cGxpY2F0ZSBjYWxsIGluIFJlYWN0IFN0cmljdE1vZGVcclxuICAgICAgICBpZiAoIWhhc0ZldGNoZWQuY3VycmVudCkge1xyXG4gICAgICAgICAgICBoYXNGZXRjaGVkLmN1cnJlbnQgPSB0cnVlO1xyXG4gICAgICAgICAgICBmZXRjaEVtcGxveWVlQ3VzdG9tZXJzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW2VtcGxveWVlcywgZmV0Y2hFbXBsb3llZUN1c3RvbWVyc10pO1xyXG5cclxuICAgIC8vIEVtcGxveWVlIGNoYW5nZWRcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFlbXBsb3llZXMubGVuZ3RoKSByZXR1cm47XHJcblxyXG4gICAgICAgIGlmIChoYXNGZXRjaGVkLmN1cnJlbnQpIHtcclxuICAgICAgICAgICAgZmV0Y2hFbXBsb3llZUN1c3RvbWVycygpO1xyXG4gICAgICAgIH1cclxuICAgIH0sIFtcclxuICAgICAgICBmb3JtRGF0YS5lbXBsb3llZSxcclxuICAgICAgICBmb3JtRGF0YS5jdXN0b21lcixcclxuICAgIF0pO1xyXG5cclxuICAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwic2xOb1wiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiU2wgTm9cIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcInN0YXR1c1wiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiQ3VzdG9tZXIgU3RhdHVzXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJpc1ByaXplZFwiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiQXVjdGlvbiBTdGF0dXNcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcImpvaW5lZERhdGVcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIkpvaW5lZCBEYXRlXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJjdXN0b21lck5hbWVcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcInBob25lXCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJQaG9uZVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwiZ3JvdXBcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIkdyb3VwXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJ0aWNrZXRzXCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJUaWNrZXRcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcImluc3RhbGxtZW50XCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJHcm91cCBJbnN0YWxsbWVudFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwidG90YWxQcm9maXRcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIlRvdGFsIFByb2ZpdFwiLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcImludmVzdG1lbnRcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIlRvdGFsIEludmVzdG1lbnRcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcInRvdGFsUGVuYWx0eVwiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiVG90YWwgUGVuYWx0eVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwidG90YWxMYXRlRmVlXCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJUb3RhbCBMYXRlIEZlZVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwib3V0c3RhbmRpbmdcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIkJhbGFuY2VcIixcclxuICAgICAgICB9LFxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0xMCB3LWZ1bGwgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IG1pbi13LVs5MDBweF0gcC03XCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1wbG95ZWUgQ29sbGVjdGlvbiBDdXN0b21lciBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5FbXBsb3llZTwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1wbG95ZWUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbXBsb3llZTogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5jaGlsZHJlbiA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgRW1wbG95ZWVzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5DdXN0b21lcjwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmN1c3RvbWVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJjdXN0b21lclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5jaGlsZHJlbiA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgQ3VzdG9tZXJzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVycy5tYXAoKGN1c3RvbWVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjdXN0b21lci5faWR9IHZhbHVlPXtjdXN0b21lci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyPntzdW1tYXJ5LnRvdGFsQ3VzdG9tZXJzfTwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIEVucm9sbG1lbnRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDI+e3N1bW1hcnkudG90YWxFbnJvbGxtZW50c308L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC0xMDAgcC00IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+VG90YWwgQmFsYW5jZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyPuKCuXtzdW1tYXJ5LnRvdGFsT3V0c3RhbmRpbmd9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIEludmVzdG1lbnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMj7igrl7c3VtbWFyeS50b3RhbEludmVzdG1lbnR9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtyZXBvcnREYXRhLmxlbmd0aCA+IDAgJiYgIWxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtyZXBvcnREYXRhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiRW1wbG95ZWUgUmVmZXJyZWQgQ3VzdG9tZXIgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiRW1wbG95ZWUgUmVmZXJyZWQgQ3VzdG9tZXIgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXshbG9hZGluZyAmJiByZXBvcnREYXRhLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT1cIkVtcGxveWVlIFJlZmVycmVkIEN1c3RvbWVyc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW1wbG95ZWVDb2xsZWN0aW9uQ3VzdG9tZXJSZXBvcnQ7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0VtcGxveWVlQ29sbGVjdGlvbkN1c3RvbWVyUmVwb3J0LmpzeCJ9