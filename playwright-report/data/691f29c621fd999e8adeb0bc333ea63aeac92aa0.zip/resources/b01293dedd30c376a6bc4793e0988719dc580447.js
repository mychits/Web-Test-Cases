import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DateWiseRewardreport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select, Button, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const DateWiseRewardreport = () => {
  _s();
  const [employee, setEmployee] = useState([]);
  const [employeeId, setEmployeeId] = useState(null);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [rewardtable, setRewardTable] = useState([]);
  const [loading, setLoading] = useState(false);
  const [runFetch, setRunFetch] = useState(0);
  useEffect(() => {
    const fetchEmployeeData = async () => {
      try {
        const response = await api.get("/agent/get-employee");
        setEmployee(response.data?.employee || []);
      } catch (error) {
        console.error("unable to fetch employee data", error);
      }
    };
    fetchEmployeeData();
  }, []);
  useEffect(() => {
    const fetchEmployeeRewardPoints = async () => {
      if (!employeeId || !fromDate || !toDate) {
        message.warning("Select employee and date range");
        return;
      }
      try {
        setLoading(true);
        const response = await api.post("/reward-points/datewise-list", {
          employee_id: employeeId,
          from_date: fromDate,
          to_date: toDate
        });
        console.info(response?.data?.data, "test");
        const formattedData = response.data?.data?.map((reward, index) => {
          let referenceName = "-";
          if (reward?.group_id) {
            referenceName = reward?.group_id?.group_name;
          } else if (reward?.loan_id) {
            referenceName = reward?.loan_id?.loan_id;
          } else if (reward?.pigme_id) {
            referenceName = reward?.pigme_id?.pigme_id;
          }
          return {
            _id: reward?._id,
            slNo: index + 1,
            userName: reward?.user_id?.full_name || "-",
            userPhone: reward?.user_id?.phone_number || "-",
            groupName: referenceName,
            groupValue: reward?.group_id?.group_value,
            ticket: reward?.ticket || "-",
            sourceType: reward?.source_type || "-",
            rewardPoints: reward?.reward_points || 0,
            rewardAmount: reward?.rewarded_amount || 0,
            status: reward?.status || "N/A",
            remarks: reward?.remarks || "-",
            createdAt: new Date(reward.createdAt).toLocaleString()
          };
        });
        setRewardTable(formattedData);
      } catch (error) {
        console.error("unable to fetch employee reward points", error);
      } finally {
        setLoading(false);
      }
    };
    fetchEmployeeRewardPoints();
  }, [runFetch]);
  const columns = [
    { header: "Sl No", key: "slNo" },
    { header: "Customer", key: "userName" },
    { header: "Phone", key: "userPhone" },
    { header: "Reference", key: "reference" },
    { header: "Group Value", key: "groupValue" },
    { header: "Ticket", key: "ticket" },
    { header: "Type", key: "sourceType" },
    { header: "Points", key: "rewardPoints" },
    { header: "Amount", key: "rewardAmount" },
    { header: "Status", key: "status" },
    { header: "Remarks", key: "remarks" },
    { header: "Reward created On", key: "createdAt" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-6", children: "Date Wise Reward Points" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
        lineNumber: 102,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-64 mr-3",
            popupMatchSelectWidth: false,
            showSearch: true,
            placeholder: "Select Employee",
            value: employeeId || void 0,
            onChange: (value) => setEmployeeId(value),
            optionFilterProp: "children",
            filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
            children: employee.map(
              (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                emp.name,
                " - ",
                emp.phone_number
              ] }, emp._id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
                lineNumber: 122,
                columnNumber: 15
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
            lineNumber: 106,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            className: "border p-4 rounded mr-3",
            value: fromDate,
            onChange: (e) => setFromDate(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
            lineNumber: 127,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            className: "border p-4 rounded mr-3",
            value: toDate,
            onChange: (e) => setToDate(e.target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
            lineNumber: 134,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            type: "primary",
            className: "h-14 text-base px-6 mr-3 rounded-lg mb-10",
            onClick: () => setRunFetch((v) => v + 1),
            loading,
            children: "Continue"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
            lineNumber: 141,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
        lineNumber: 105,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DataTable, { data: rewardtable, columns, exportedFileName: "DateWise Reward Report.csv", exportedPdfName: "DateWise Reward Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
        lineNumber: 150,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
      lineNumber: 101,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
      lineNumber: 100,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx",
    lineNumber: 98,
    columnNumber: 5
  }, this);
};
_s(DateWiseRewardreport, "i90K6hq+9+h8zPghm7jEDT0LyWg=");
_c = DateWiseRewardreport;
export default DateWiseRewardreport;
var _c;
$RefreshReg$(_c, "DateWiseRewardreport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DateWiseRewardreport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0dNOzJCQWxHTjtBQUFtQkEsb0JBQWlCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsUUFBUUMsUUFBUUMsZUFBZTtBQUV4QyxNQUFNQyx1QkFBdUJBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUMsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJRixTQUFTLElBQUk7QUFFakQsUUFBTSxDQUFDRyxVQUFVQyxXQUFXLElBQUlKLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNLLFFBQVFDLFNBQVMsSUFBSU4sU0FBUyxFQUFFO0FBRXZDLFFBQU0sQ0FBQ08sYUFBYUMsY0FBYyxJQUFJUixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDUyxTQUFTQyxVQUFVLElBQUlWLFNBQVMsS0FBSztBQUU1QyxRQUFNLENBQUNXLFVBQVVDLFdBQVcsSUFBSVosU0FBUyxDQUFDO0FBRTFDWCxZQUFVLE1BQU07QUFDZCxVQUFNd0Isb0JBQW9CLFlBQVk7QUFDcEMsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTXhCLElBQUl5QixJQUFJLHFCQUFxQjtBQUNwRGhCLG9CQUFZZSxTQUFTRSxNQUFNbEIsWUFBWSxFQUFFO0FBQUEsTUFDM0MsU0FBU21CLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQUEsTUFDdEQ7QUFBQSxJQUNGO0FBQ0FKLHNCQUFrQjtBQUFBLEVBQ3BCLEdBQUcsRUFBRTtBQUVMeEIsWUFBVSxNQUFNO0FBQ2QsVUFBTThCLDRCQUE0QixZQUFZO0FBQzVDLFVBQUksQ0FBQ2xCLGNBQWMsQ0FBQ0UsWUFBWSxDQUFDRSxRQUFRO0FBQ3ZDVixnQkFBUXlCLFFBQVEsZ0NBQWdDO0FBQ2hEO0FBQUEsTUFDRjtBQUNBLFVBQUk7QUFDRlYsbUJBQVcsSUFBSTtBQUNmLGNBQU1JLFdBQVcsTUFBTXhCLElBQUkrQixLQUFLLGdDQUFnQztBQUFBLFVBQzlEQyxhQUFhckI7QUFBQUEsVUFDYnNCLFdBQVdwQjtBQUFBQSxVQUNYcUIsU0FBU25CO0FBQUFBLFFBQ1gsQ0FBQztBQUNEYSxnQkFBUU8sS0FBS1gsVUFBVUUsTUFBTUEsTUFBTSxNQUFNO0FBRXpDLGNBQU1VLGdCQUFnQlosU0FBU0UsTUFBTUEsTUFBTVcsSUFBSSxDQUFDQyxRQUFRQyxVQUFVO0FBQ2hFLGNBQUlDLGdCQUFnQjtBQUVwQixjQUFJRixRQUFRRyxVQUFVO0FBQ3BCRCw0QkFBZ0JGLFFBQVFHLFVBQVVDO0FBQUFBLFVBQ3BDLFdBQVdKLFFBQVFLLFNBQVM7QUFDMUJILDRCQUFnQkYsUUFBUUssU0FBU0E7QUFBQUEsVUFDbkMsV0FBV0wsUUFBUU0sVUFBVTtBQUMzQkosNEJBQWdCRixRQUFRTSxVQUFVQTtBQUFBQSxVQUNwQztBQUVBLGlCQUFPO0FBQUEsWUFDTEMsS0FBS1AsUUFBUU87QUFBQUEsWUFDYkMsTUFBTVAsUUFBUTtBQUFBLFlBQ2RRLFVBQVVULFFBQVFVLFNBQVNDLGFBQWE7QUFBQSxZQUN4Q0MsV0FBV1osUUFBUVUsU0FBU0csZ0JBQWdCO0FBQUEsWUFDNUNDLFdBQVdaO0FBQUFBLFlBQ1hhLFlBQVlmLFFBQVFHLFVBQVVhO0FBQUFBLFlBQzlCQyxRQUFRakIsUUFBUWlCLFVBQVU7QUFBQSxZQUMxQkMsWUFBWWxCLFFBQVFtQixlQUFlO0FBQUEsWUFDbkNDLGNBQWNwQixRQUFRcUIsaUJBQWlCO0FBQUEsWUFDdkNDLGNBQWN0QixRQUFRdUIsbUJBQW1CO0FBQUEsWUFDekNDLFFBQVF4QixRQUFRd0IsVUFBVTtBQUFBLFlBQzFCQyxTQUFTekIsUUFBUXlCLFdBQVc7QUFBQSxZQUM1QkMsV0FBVyxJQUFJQyxLQUFLM0IsT0FBTzBCLFNBQVMsRUFBRUUsZUFBZTtBQUFBLFVBQ3ZEO0FBQUEsUUFDRixDQUFDO0FBQ0RoRCx1QkFBZWtCLGFBQWE7QUFBQSxNQUM5QixTQUFTVCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDBDQUEwQ0EsS0FBSztBQUFBLE1BQy9ELFVBQUM7QUFDQ1AsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUNBUyw4QkFBMEI7QUFBQSxFQUM1QixHQUFHLENBQUNSLFFBQVEsQ0FBQztBQUViLFFBQU04QyxVQUFVO0FBQUEsSUFDZCxFQUFFQyxRQUFRLFNBQVNDLEtBQUssT0FBTztBQUFBLElBQy9CLEVBQUVELFFBQVEsWUFBWUMsS0FBSyxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsUUFBUSxTQUFTQyxLQUFLLFlBQVk7QUFBQSxJQUNwQyxFQUFFRCxRQUFRLGFBQWFDLEtBQUssWUFBWTtBQUFBLElBQ3hDLEVBQUVELFFBQVEsZUFBZUMsS0FBSyxhQUFhO0FBQUEsSUFDM0MsRUFBRUQsUUFBUSxVQUFVQyxLQUFLLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxRQUFRLFFBQVFDLEtBQUssYUFBYTtBQUFBLElBQ3BDLEVBQUVELFFBQVEsVUFBVUMsS0FBSyxlQUFlO0FBQUEsSUFDeEMsRUFBRUQsUUFBUSxVQUFVQyxLQUFLLGVBQWU7QUFBQSxJQUN4QyxFQUFFRCxRQUFRLFVBQVVDLEtBQUssU0FBUztBQUFBLElBQ2xDLEVBQUVELFFBQVEsV0FBV0MsS0FBSyxVQUFVO0FBQUEsSUFDcEMsRUFBRUQsUUFBUSxxQkFBcUJDLEtBQUssWUFBWTtBQUFBLEVBQUM7QUFFbkQsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFNBQUksV0FBVSxnQkFDYixpQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsK0JBQThCLHVDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsdUJBQXVCO0FBQUEsWUFDdkI7QUFBQSxZQUNBLGFBQVk7QUFBQSxZQUNaLE9BQU8xRCxjQUFjMkQ7QUFBQUEsWUFDckIsVUFBVSxDQUFDQyxVQUFVM0QsY0FBYzJELEtBQUs7QUFBQSxZQUN4QyxrQkFBaUI7QUFBQSxZQUNqQixjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsWUFHaENwRSxtQkFBUzZCO0FBQUFBLGNBQUksQ0FBQ3lDLFFBQ2IsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUlqQyxLQUNyQ2lDO0FBQUFBLG9CQUFJQztBQUFBQSxnQkFBSztBQUFBLGdCQUFJRCxJQUFJM0I7QUFBQUEsbUJBREEyQixJQUFJakMsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9CQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLE9BQU9oQztBQUFBQSxZQUNQLFVBQVUsQ0FBQ21FLE1BQU1sRSxZQUFZa0UsRUFBRUMsT0FBT1YsS0FBSztBQUFBO0FBQUEsVUFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSStDO0FBQUEsUUFHL0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLE9BQU94RDtBQUFBQSxZQUNQLFVBQVUsQ0FBQ2lFLE1BQU1oRSxVQUFVZ0UsRUFBRUMsT0FBT1YsS0FBSztBQUFBO0FBQUEsVUFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTZDO0FBQUEsUUFHN0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTWpELFlBQVksQ0FBQzRELE1BQU1BLElBQUksQ0FBQztBQUFBLFlBQ3ZDO0FBQUEsWUFBaUI7QUFBQTtBQUFBLFVBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRDQTtBQUFBLE1BQ0ksdUJBQUMsYUFBVSxNQUFNakUsYUFBYSxTQUFrQixrQkFBaUIsOEJBQTZCLGlCQUFnQiw0QkFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzSTtBQUFBLFNBakQ1STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbURBLEtBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxREE7QUFBQSxPQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0RBO0FBRUo7QUFBRVYsR0FySklELHNCQUFvQjtBQUFBNkUsS0FBcEI3RTtBQXVKTixlQUFlQTtBQUFxQixJQUFBNkU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsImFwaSIsIk5hdmJhciIsIkRhdGFUYWJsZSIsIlNlbGVjdCIsIkJ1dHRvbiIsIm1lc3NhZ2UiLCJEYXRlV2lzZVJld2FyZHJlcG9ydCIsIl9zIiwiZW1wbG95ZWUiLCJzZXRFbXBsb3llZSIsInVzZVN0YXRlIiwiZW1wbG95ZWVJZCIsInNldEVtcGxveWVlSWQiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9EYXRlIiwic2V0VG9EYXRlIiwicmV3YXJkdGFibGUiLCJzZXRSZXdhcmRUYWJsZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwicnVuRmV0Y2giLCJzZXRSdW5GZXRjaCIsImZldGNoRW1wbG95ZWVEYXRhIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hFbXBsb3llZVJld2FyZFBvaW50cyIsIndhcm5pbmciLCJwb3N0IiwiZW1wbG95ZWVfaWQiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwiaW5mbyIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJyZXdhcmQiLCJpbmRleCIsInJlZmVyZW5jZU5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJsb2FuX2lkIiwicGlnbWVfaWQiLCJfaWQiLCJzbE5vIiwidXNlck5hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwidXNlclBob25lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBOYW1lIiwiZ3JvdXBWYWx1ZSIsImdyb3VwX3ZhbHVlIiwidGlja2V0Iiwic291cmNlVHlwZSIsInNvdXJjZV90eXBlIiwicmV3YXJkUG9pbnRzIiwicmV3YXJkX3BvaW50cyIsInJld2FyZEFtb3VudCIsInJld2FyZGVkX2Ftb3VudCIsInN0YXR1cyIsInJlbWFya3MiLCJjcmVhdGVkQXQiLCJEYXRlIiwidG9Mb2NhbGVTdHJpbmciLCJjb2x1bW5zIiwiaGVhZGVyIiwia2V5IiwidW5kZWZpbmVkIiwidmFsdWUiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZW1wIiwibmFtZSIsImUiLCJ0YXJnZXQiLCJ2IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGF0ZVdpc2VSZXdhcmRyZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBCdXR0b24sIG1lc3NhZ2UgfSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuY29uc3QgRGF0ZVdpc2VSZXdhcmRyZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2VtcGxveWVlLCBzZXRFbXBsb3llZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlSWQsIHNldEVtcGxveWVlSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBbcmV3YXJkdGFibGUsIHNldFJld2FyZFRhYmxlXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtydW5GZXRjaCwgc2V0UnVuRmV0Y2hdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWVtcGxveWVlXCIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlKHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwidW5hYmxlIHRvIGZldGNoIGVtcGxveWVlIGRhdGFcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZURhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlUmV3YXJkUG9pbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBpZiAoIWVtcGxveWVlSWQgfHwgIWZyb21EYXRlIHx8ICF0b0RhdGUpIHtcclxuICAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJTZWxlY3QgZW1wbG95ZWUgYW5kIGRhdGUgcmFuZ2VcIik7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL3Jld2FyZC1wb2ludHMvZGF0ZXdpc2UtbGlzdFwiLCB7XHJcbiAgICAgICAgICBlbXBsb3llZV9pZDogZW1wbG95ZWVJZCxcclxuICAgICAgICAgIGZyb21fZGF0ZTogZnJvbURhdGUsXHJcbiAgICAgICAgICB0b19kYXRlOiB0b0RhdGUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlPy5kYXRhPy5kYXRhLCBcInRlc3RcIik7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhPy5tYXAoKHJld2FyZCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGxldCByZWZlcmVuY2VOYW1lID0gXCItXCI7XHJcblxyXG4gICAgICAgICAgaWYgKHJld2FyZD8uZ3JvdXBfaWQpIHtcclxuICAgICAgICAgICAgcmVmZXJlbmNlTmFtZSA9IHJld2FyZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWU7XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKHJld2FyZD8ubG9hbl9pZCkge1xyXG4gICAgICAgICAgICByZWZlcmVuY2VOYW1lID0gcmV3YXJkPy5sb2FuX2lkPy5sb2FuX2lkO1xyXG4gICAgICAgICAgfSBlbHNlIGlmIChyZXdhcmQ/LnBpZ21lX2lkKSB7XHJcbiAgICAgICAgICAgIHJlZmVyZW5jZU5hbWUgPSByZXdhcmQ/LnBpZ21lX2lkPy5waWdtZV9pZDtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBfaWQ6IHJld2FyZD8uX2lkLFxyXG4gICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIHVzZXJOYW1lOiByZXdhcmQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgdXNlclBob25lOiByZXdhcmQ/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgICAgZ3JvdXBOYW1lOiByZWZlcmVuY2VOYW1lLFxyXG4gICAgICAgICAgICBncm91cFZhbHVlOiByZXdhcmQ/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSxcclxuICAgICAgICAgICAgdGlja2V0OiByZXdhcmQ/LnRpY2tldCB8fCBcIi1cIixcclxuICAgICAgICAgICAgc291cmNlVHlwZTogcmV3YXJkPy5zb3VyY2VfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgcmV3YXJkUG9pbnRzOiByZXdhcmQ/LnJld2FyZF9wb2ludHMgfHwgMCxcclxuICAgICAgICAgICAgcmV3YXJkQW1vdW50OiByZXdhcmQ/LnJld2FyZGVkX2Ftb3VudCB8fCAwLFxyXG4gICAgICAgICAgICBzdGF0dXM6IHJld2FyZD8uc3RhdHVzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHJlbWFya3M6IHJld2FyZD8ucmVtYXJrcyB8fCBcIi1cIixcclxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZShyZXdhcmQuY3JlYXRlZEF0KS50b0xvY2FsZVN0cmluZygpLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRSZXdhcmRUYWJsZShmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwidW5hYmxlIHRvIGZldGNoIGVtcGxveWVlIHJld2FyZCBwb2ludHNcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZVJld2FyZFBvaW50cygpO1xyXG4gIH0sIFtydW5GZXRjaF0pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBoZWFkZXI6IFwiU2wgTm9cIiwga2V5OiBcInNsTm9cIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiQ3VzdG9tZXJcIiwga2V5OiBcInVzZXJOYW1lXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIlBob25lXCIsIGtleTogXCJ1c2VyUGhvbmVcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiUmVmZXJlbmNlXCIsIGtleTogXCJyZWZlcmVuY2VcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiwga2V5OiBcImdyb3VwVmFsdWVcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiVGlja2V0XCIsIGtleTogXCJ0aWNrZXRcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiVHlwZVwiLCBrZXk6IFwic291cmNlVHlwZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJQb2ludHNcIiwga2V5OiBcInJld2FyZFBvaW50c1wiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJBbW91bnRcIiwga2V5OiBcInJld2FyZEFtb3VudFwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJTdGF0dXNcIiwga2V5OiBcInN0YXR1c1wiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJSZW1hcmtzXCIsIGtleTogXCJyZW1hcmtzXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIlJld2FyZCBjcmVhdGVkIE9uXCIsIGtleTogXCJjcmVhdGVkQXRcIiB9LFxyXG4gIF07XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxOYXZiYXIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbXQtMjBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTZcIj5cclxuICAgICAgICAgICAgRGF0ZSBXaXNlIFJld2FyZCBQb2ludHNcclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy02NCBtci0zXCJcclxuICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEVtcGxveWVlSWQodmFsdWUpfVxyXG4gICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7ZW1wbG95ZWUubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IC0ge2VtcC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtNCByb3VuZGVkIG1yLTNcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtmcm9tRGF0ZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC00IHJvdW5kZWQgbXItM1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3RvRGF0ZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgdGV4dC1iYXNlIHB4LTYgbXItMyByb3VuZGVkLWxnIG1iLTEwXCIgXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UnVuRmV0Y2goKHYpID0+IHYgKyAxKX1cclxuICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ29udGludWVcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlIGRhdGE9e3Jld2FyZHRhYmxlfSBjb2x1bW5zPXtjb2x1bW5zfSBleHBvcnRlZEZpbGVOYW1lPVwiRGF0ZVdpc2UgUmV3YXJkIFJlcG9ydC5jc3ZcIiBleHBvcnRlZFBkZk5hbWU9XCJEYXRlV2lzZSBSZXdhcmQgUmVwb3J0XCIgLz5cclxuXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERhdGVXaXNlUmV3YXJkcmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRGF0ZVdpc2VSZXdhcmRyZXBvcnQuanN4In0=