import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RegistrationReceipt.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
import { BiPrinter } from "/node_modules/.vite/deps/react-icons_bi.js?v=819e0a34";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import mychitsLogo from "/src/assets/images/mychits.png?import";
const RegistrationReceipt = () => {
  _s();
  const { id } = useParams();
  const [payment, setPayment] = useState({});
  useEffect(() => {
    const fetchPayment = async () => {
      try {
        const response = await api.get(
          `/registration-fee/get-registration-fee-by-id/${id}`
        );
        if (response.data) {
          console.log(response.data);
          setPayment(response.data);
        } else {
          setPayment({});
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setPayment({});
      }
    };
    fetchPayment();
  }, [id]);
  useEffect(() => {
    console.log(payment);
  }, [payment]);
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    const options = { day: "numeric", month: "short", year: "numeric" };
    return date.toLocaleDateString("en-US", options);
  };
  const handlePrint = async () => {
    const receiptElement = document.getElementById("receipt");
    const canvas = await html2canvas(receiptElement, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("portrait", "mm", "a4");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    pdf.addImage(imgData, "PNG", 0, 0, pageWidth, pageHeight);
    pdf.save("Registration Receipt.pdf");
  };
  return /* @__PURE__ */ jsxDEV("div", { align: "center", style: { marginTop: "80px" }, children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: handlePrint,
        className: "border border-violet-400 text-white px-4 py-2 mb-5 rounded-md shadow hover:border-violet-700 transition duration-200 mt-4",
        children: /* @__PURE__ */ jsxDEV(BiPrinter, { color: "violet" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
          lineNumber: 63,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
        lineNumber: 59,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        id: "receipt",
        style: {
          width: "210mm",
          height: "297mm",
          padding: "10mm",
          border: "1px solid #ddd",
          backgroundColor: "#fff",
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          gap: "10mm"
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                width: "48%",
                border: "1px solid #ddd",
                borderRadius: "8px",
                padding: "15px",
                boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)"
              },
              children: [
                " ",
                /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: mychitsLogo,
                    alt: "Company Logo",
                    width: "40",
                    style: { margin: "0 auto 8px", display: "block" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 89,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("h2", { style: { textAlign: "center", margin: 0 }, children: "MY CHITS" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 95,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("p", { style: { textAlign: "center", fontSize: "12px", margin: "5px 0" }, children: [
                  "No.11/36-25, 2nd Main, Kathriguppe Main Road,",
                  /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 98,
                    columnNumber: 13
                  }, this),
                  "Bangalore, 560085 9483900777"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 96,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 101,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { style: { textAlign: "center", margin: "5px 0" }, children: "Registration Receipt" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 102,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "start" }, children: [
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Receipt No:",
                    " ",
                    payment.receipt_no ? payment.receipt_no : payment.old_receipt_no
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 104,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Date: ",
                    formatPayDate(payment.pay_date)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 108,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "4px" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 109,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Name: ",
                    payment?.user_id?.full_name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 110,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Mobile No: ",
                    payment?.user_id?.phone_number
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 111,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "4px" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 112,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Group: ",
                    payment?.group_id?.group_name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 113,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Ticket: ",
                    payment?.ticket
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 114,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 103,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      textAlign: "center",
                      fontWeight: "bold",
                      border: "1px solid #000",
                      padding: "10px",
                      margin: "10px 0"
                    },
                    children: [
                      "Received Amount | Rs.",
                      payment?.amount
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 116,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "start" }, children: [
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Mode: ",
                    payment?.pay_type
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 128,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Total: Rs.",
                    payment?.amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 129,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Collected by: ",
                    payment?.collected_by?.name || "Admin"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 130,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 127,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "4px" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 132,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("p", { children: "Customer Copy" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 133,
                  columnNumber: 11
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
              lineNumber: 79,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                width: "48%",
                border: "1px solid #ddd",
                borderRadius: "8px",
                padding: "15px",
                boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)"
              },
              children: [
                /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: mychitsLogo,
                    alt: "Company Logo",
                    width: "40",
                    style: { margin: "0 auto 8px", display: "block" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 145,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("h2", { style: { textAlign: "center", margin: 0 }, children: "MY CHITS" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 151,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("p", { style: { textAlign: "center", fontSize: "12px", margin: "5px 0" }, children: [
                  "No.11/36-25, 2nd Main, Kathriguppe Main Road,",
                  /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 154,
                    columnNumber: 13
                  }, this),
                  "Bangalore, 560085 9483900777"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 152,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 157,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { style: { textAlign: "center", margin: "5px 0" }, children: "Registration Receipt" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 158,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "start" }, children: [
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Receipt No:",
                    " ",
                    payment.receipt_no ? payment.receipt_no : payment.old_receipt_no
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 160,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Date: ",
                    formatPayDate(payment.pay_date)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 164,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "4px" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 165,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Name: ",
                    payment?.user_id?.full_name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 166,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Mobile No: ",
                    payment?.user_id?.phone_number
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 167,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "4px" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 168,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Group: ",
                    payment?.group_id?.group_name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 169,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Ticket: ",
                    payment?.ticket
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 170,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 159,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      textAlign: "center",
                      fontWeight: "bold",
                      border: "1px solid #000",
                      padding: "10px",
                      margin: "10px 0"
                    },
                    children: [
                      "Received Amount | Rs.",
                      payment?.amount
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 172,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "start" }, children: [
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Mode: ",
                    payment?.pay_type
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 184,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Total: Rs.",
                    payment?.amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 185,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Collected by: ",
                    payment?.collected_by?.name || "Admin"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                    lineNumber: 186,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 183,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "4px" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 188,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("p", { children: "Admin Copy" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
                  lineNumber: 189,
                  columnNumber: 11
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
              lineNumber: 136,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
        lineNumber: 65,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
};
_s(RegistrationReceipt, "nAWbC//I6CYWWJT41S3DS6wLXAc=", false, function() {
  return [useParams];
});
_c = RegistrationReceipt;
export default RegistrationReceipt;
var _c;
$RefreshReg$(_c, "RegistrationReceipt");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationReceipt.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERROzJCQTlEUjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxpQkFBaUI7QUFFeEIsTUFBTUMsc0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxFQUFFQyxHQUFHLElBQUlMLFVBQVU7QUFDekIsUUFBTSxDQUFDTSxTQUFTQyxVQUFVLElBQUlYLFNBQVMsQ0FBQyxDQUFDO0FBRXpDRCxZQUFVLE1BQU07QUFDZCxVQUFNYSxlQUFlLFlBQVk7QUFDL0IsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTVIsSUFBSVM7QUFBQUEsVUFDekIsZ0RBQWdETCxFQUFFO0FBQUEsUUFDcEQ7QUFDQSxZQUFJSSxTQUFTRSxNQUFNO0FBQ2pCQyxrQkFBUUMsSUFBSUosU0FBU0UsSUFBSTtBQUN6QkoscUJBQVdFLFNBQVNFLElBQUk7QUFBQSxRQUMxQixPQUFPO0FBQ0xKLHFCQUFXLENBQUMsQ0FBQztBQUFBLFFBQ2Y7QUFBQSxNQUNGLFNBQVNPLE9BQU87QUFDZEYsZ0JBQVFFLE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EUCxtQkFBVyxDQUFDLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRjtBQUVBQyxpQkFBYTtBQUFBLEVBQ2YsR0FBRyxDQUFDSCxFQUFFLENBQUM7QUFFUFYsWUFBVSxNQUFNO0FBQ2RpQixZQUFRQyxJQUFJUCxPQUFPO0FBQUEsRUFDckIsR0FBRyxDQUFDQSxPQUFPLENBQUM7QUFFWixRQUFNUyxnQkFBZ0JBLENBQUNDLGVBQWU7QUFDcEMsVUFBTUMsT0FBTyxJQUFJQyxLQUFLRixVQUFVO0FBQ2hDLFVBQU1HLFVBQVUsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFNBQVNDLE1BQU0sVUFBVTtBQUNsRSxXQUFPTCxLQUFLTSxtQkFBbUIsU0FBU0osT0FBTztBQUFBLEVBQ2pEO0FBRUEsUUFBTUssY0FBYyxZQUFZO0FBQzlCLFVBQU1DLGlCQUFpQkMsU0FBU0MsZUFBZSxTQUFTO0FBQ3hELFVBQU1DLFNBQVMsTUFBTTlCLFlBQVkyQixnQkFBZ0IsRUFBRUksT0FBTyxFQUFFLENBQUM7QUFDN0QsVUFBTUMsVUFBVUYsT0FBT0csVUFBVSxXQUFXO0FBRTVDLFVBQU1DLE1BQU0sSUFBSW5DLE1BQU0sWUFBWSxNQUFNLElBQUk7QUFDNUMsVUFBTW9DLFlBQVlELElBQUlFLFNBQVNDLFNBQVNDLFNBQVM7QUFDakQsVUFBTUMsYUFBYUwsSUFBSUUsU0FBU0MsU0FBU0csVUFBVTtBQUVuRE4sUUFBSU8sU0FBU1QsU0FBUyxPQUFPLEdBQUcsR0FBR0csV0FBV0ksVUFBVTtBQUN4REwsUUFBSVEsS0FBSywwQkFBMEI7QUFBQSxFQUNyQztBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFNLFVBQVMsT0FBTyxFQUFFQyxXQUFXLE9BQU8sR0FDN0M7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBU2pCO0FBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBRVYsaUNBQUMsYUFBVSxPQUFNLFlBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQTtBQUFBLE1BSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBRztBQUFBLFFBQ0gsT0FBTztBQUFBLFVBQ0xrQixPQUFPO0FBQUEsVUFDUEMsUUFBUTtBQUFBLFVBQ1JDLFNBQVM7QUFBQSxVQUNUQyxRQUFRO0FBQUEsVUFDUkMsaUJBQWlCO0FBQUEsVUFDakJDLFNBQVM7QUFBQSxVQUNUQyxlQUFlO0FBQUEsVUFDZkMsZ0JBQWdCO0FBQUEsVUFDaEJDLEtBQUs7QUFBQSxRQUNQO0FBQUEsUUFFQTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPO0FBQUEsZ0JBQ0xSLE9BQU87QUFBQSxnQkFDUEcsUUFBUTtBQUFBLGdCQUNSTSxjQUFjO0FBQUEsZ0JBQ2RQLFNBQVM7QUFBQSxnQkFDVFEsV0FBVztBQUFBLGNBQ2I7QUFBQSxjQUVDO0FBQUE7QUFBQSxnQkFDRDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxLQUFLbEQ7QUFBQUEsb0JBQ0wsS0FBSTtBQUFBLG9CQUNKLE9BQU07QUFBQSxvQkFDTixPQUFPLEVBQUVtRCxRQUFRLGNBQWNOLFNBQVMsUUFBUTtBQUFBO0FBQUEsa0JBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJb0Q7QUFBQSxnQkFFcEQsdUJBQUMsUUFBRyxPQUFPLEVBQUVPLFdBQVcsVUFBVUQsUUFBUSxFQUFFLEdBQUcsd0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsZ0JBQ3ZELHVCQUFDLE9BQUUsT0FBTyxFQUFFQyxXQUFXLFVBQVVDLFVBQVUsUUFBUUYsUUFBUSxRQUFRLEdBQUc7QUFBQTtBQUFBLGtCQUVwRSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQUc7QUFBQSxrQkFBRztBQUFBLHFCQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQUc7QUFBQSxnQkFDSCx1QkFBQyxRQUFHLE9BQU8sRUFBRUMsV0FBVyxVQUFVRCxRQUFRLFFBQVEsR0FBRyxvQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUU7QUFBQSxnQkFDekUsdUJBQUMsU0FBSSxPQUFPLEVBQUVDLFdBQVcsUUFBUSxHQUMvQjtBQUFBLHlDQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUNXO0FBQUEsb0JBQ1hoRCxRQUFRa0QsYUFBYWxELFFBQVFrRCxhQUFhbEQsUUFBUW1EO0FBQUFBLHVCQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQU8xQyxjQUFjVCxRQUFRb0QsUUFBUTtBQUFBLHVCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQztBQUFBLGtCQUMxQyx1QkFBQyxTQUFJLE9BQU8sRUFBRWpCLFdBQVcsTUFBTSxLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQztBQUFBLGtCQUNsQyx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBT25DLFNBQVNxRCxTQUFTQztBQUFBQSx1QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDdEMsdUJBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQVl0RCxTQUFTcUQsU0FBU0U7QUFBQUEsdUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDO0FBQUEsa0JBQzlDLHVCQUFDLFNBQUksT0FBTyxFQUFFcEIsV0FBVyxNQUFNLEtBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUEsa0JBQ2xDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFRbkMsU0FBU3dELFVBQVVDO0FBQUFBLHVCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QztBQUFBLGtCQUN6Qyx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBU3pELFNBQVMwRDtBQUFBQSx1QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEI7QUFBQSxxQkFYOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU87QUFBQSxzQkFDTFYsV0FBVztBQUFBLHNCQUNYVyxZQUFZO0FBQUEsc0JBQ1pwQixRQUFRO0FBQUEsc0JBQ1JELFNBQVM7QUFBQSxzQkFDVFMsUUFBUTtBQUFBLG9CQUNWO0FBQUEsb0JBQUU7QUFBQTtBQUFBLHNCQUVvQi9DLFNBQVM0RDtBQUFBQTtBQUFBQTtBQUFBQSxrQkFUakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVaLFdBQVcsUUFBUSxHQUMvQjtBQUFBLHlDQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFPaEQsU0FBUzZEO0FBQUFBLHVCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBLGtCQUM1Qix1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBVzdELFNBQVM0RDtBQUFBQSx1QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFDOUIsdUJBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQWU1RCxTQUFTOEQsY0FBY0MsUUFBUTtBQUFBLHVCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLHFCQUgzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU1QixXQUFXLE1BQU0sS0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxnQkFDbEMsdUJBQUMsT0FBRSw2QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQjtBQUFBO0FBQUE7QUFBQSxZQXREbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBdURBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTztBQUFBLGdCQUNMQyxPQUFPO0FBQUEsZ0JBQ1BHLFFBQVE7QUFBQSxnQkFDUk0sY0FBYztBQUFBLGdCQUNkUCxTQUFTO0FBQUEsZ0JBQ1RRLFdBQVc7QUFBQSxjQUNiO0FBQUEsY0FFQTtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLEtBQUtsRDtBQUFBQSxvQkFDTCxLQUFJO0FBQUEsb0JBQ0osT0FBTTtBQUFBLG9CQUNOLE9BQU8sRUFBRW1ELFFBQVEsY0FBY04sU0FBUyxRQUFRO0FBQUE7QUFBQSxrQkFKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlvRDtBQUFBLGdCQUVwRCx1QkFBQyxRQUFHLE9BQU8sRUFBRU8sV0FBVyxVQUFVRCxRQUFRLEVBQUUsR0FBRyx3QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxnQkFDdkQsdUJBQUMsT0FBRSxPQUFPLEVBQUVDLFdBQVcsVUFBVUMsVUFBVSxRQUFRRixRQUFRLFFBQVEsR0FBRztBQUFBO0FBQUEsa0JBRXBFLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBRztBQUFBLGtCQUFHO0FBQUEscUJBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBRztBQUFBLGdCQUNILHVCQUFDLFFBQUcsT0FBTyxFQUFFQyxXQUFXLFVBQVVELFFBQVEsUUFBUSxHQUFHLG9DQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RTtBQUFBLGdCQUN6RSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsV0FBVyxRQUFRLEdBQy9CO0FBQUEseUNBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQ1c7QUFBQSxvQkFDWGhELFFBQVFrRCxhQUFhbEQsUUFBUWtELGFBQWFsRCxRQUFRbUQ7QUFBQUEsdUJBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBTzFDLGNBQWNULFFBQVFvRCxRQUFRO0FBQUEsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBDO0FBQUEsa0JBQzFDLHVCQUFDLFNBQUksT0FBTyxFQUFFakIsV0FBVyxNQUFNLEtBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUEsa0JBQ2xDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFPbkMsU0FBU3FELFNBQVNDO0FBQUFBLHVCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUN0Qyx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBWXRELFNBQVNxRCxTQUFTRTtBQUFBQSx1QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQSxrQkFDOUMsdUJBQUMsU0FBSSxPQUFPLEVBQUVwQixXQUFXLE1BQU0sS0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0M7QUFBQSxrQkFDbEMsdUJBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQVFuQyxTQUFTd0QsVUFBVUM7QUFBQUEsdUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlDO0FBQUEsa0JBQ3pDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFTekQsU0FBUzBEO0FBQUFBLHVCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QjtBQUFBLHFCQVg5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVlBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTztBQUFBLHNCQUNMVixXQUFXO0FBQUEsc0JBQ1hXLFlBQVk7QUFBQSxzQkFDWnBCLFFBQVE7QUFBQSxzQkFDUkQsU0FBUztBQUFBLHNCQUNUUyxRQUFRO0FBQUEsb0JBQ1Y7QUFBQSxvQkFBRTtBQUFBO0FBQUEsc0JBRW9CL0MsU0FBUzREO0FBQUFBO0FBQUFBO0FBQUFBLGtCQVRqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVosV0FBVyxRQUFRLEdBQy9CO0FBQUEseUNBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQU9oRCxTQUFTNkQ7QUFBQUEsdUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRCO0FBQUEsa0JBQzVCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFXN0QsU0FBUzREO0FBQUFBLHVCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QjtBQUFBLGtCQUM5Qix1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBZTVELFNBQVM4RCxjQUFjQyxRQUFRO0FBQUEsdUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlEO0FBQUEscUJBSDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRTVCLFdBQVcsTUFBTSxLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQztBQUFBLGdCQUNsQyx1QkFBQyxPQUFFLDBCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWE7QUFBQTtBQUFBO0FBQUEsWUFyRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBc0RBO0FBQUE7QUFBQTtBQUFBLE1BN0hGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQThIQTtBQUFBLE9BcklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3SUE7QUFFSjtBQUFFckMsR0EzTElELHFCQUFtQjtBQUFBLFVBQ1JILFNBQVM7QUFBQTtBQUFBc0UsS0FEcEJuRTtBQTZMTixlQUFlQTtBQUFvQixJQUFBbUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwianNQREYiLCJodG1sMmNhbnZhcyIsIkJpUHJpbnRlciIsInVzZVBhcmFtcyIsImFwaSIsIm15Y2hpdHNMb2dvIiwiUmVnaXN0cmF0aW9uUmVjZWlwdCIsIl9zIiwiaWQiLCJwYXltZW50Iiwic2V0UGF5bWVudCIsImZldGNoUGF5bWVudCIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImNvbnNvbGUiLCJsb2ciLCJlcnJvciIsImZvcm1hdFBheURhdGUiLCJkYXRlU3RyaW5nIiwiZGF0ZSIsIkRhdGUiLCJvcHRpb25zIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiaGFuZGxlUHJpbnQiLCJyZWNlaXB0RWxlbWVudCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJjYW52YXMiLCJzY2FsZSIsImltZ0RhdGEiLCJ0b0RhdGFVUkwiLCJwZGYiLCJwYWdlV2lkdGgiLCJpbnRlcm5hbCIsInBhZ2VTaXplIiwiZ2V0V2lkdGgiLCJwYWdlSGVpZ2h0IiwiZ2V0SGVpZ2h0IiwiYWRkSW1hZ2UiLCJzYXZlIiwibWFyZ2luVG9wIiwid2lkdGgiLCJoZWlnaHQiLCJwYWRkaW5nIiwiYm9yZGVyIiwiYmFja2dyb3VuZENvbG9yIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJqdXN0aWZ5Q29udGVudCIsImdhcCIsImJvcmRlclJhZGl1cyIsImJveFNoYWRvdyIsIm1hcmdpbiIsInRleHRBbGlnbiIsImZvbnRTaXplIiwicmVjZWlwdF9ubyIsIm9sZF9yZWNlaXB0X25vIiwicGF5X2RhdGUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwidGlja2V0IiwiZm9udFdlaWdodCIsImFtb3VudCIsInBheV90eXBlIiwiY29sbGVjdGVkX2J5IiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdHJhdGlvblJlY2VpcHQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBqc1BERiBmcm9tIFwianNwZGZcIjtcclxuaW1wb3J0IGh0bWwyY2FudmFzIGZyb20gXCJodG1sMmNhbnZhc1wiO1xyXG5pbXBvcnQgeyBCaVByaW50ZXIgfSBmcm9tIFwicmVhY3QtaWNvbnMvYmlcIjtcclxuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgbXljaGl0c0xvZ28gZnJvbSBcIi4uL2Fzc2V0cy9pbWFnZXMvbXljaGl0cy5wbmdcIjtcclxuXHJcbmNvbnN0IFJlZ2lzdHJhdGlvblJlY2VpcHQgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgY29uc3QgW3BheW1lbnQsIHNldFBheW1lbnRdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hQYXltZW50ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvcmVnaXN0cmF0aW9uLWZlZS9nZXQtcmVnaXN0cmF0aW9uLWZlZS1ieS1pZC8ke2lkfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICAgIHNldFBheW1lbnQocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldFBheW1lbnQoe30pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0UGF5bWVudCh7fSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hQYXltZW50KCk7XHJcbiAgfSwgW2lkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhwYXltZW50KTtcclxuICB9LCBbcGF5bWVudF0pO1xyXG5cclxuICBjb25zdCBmb3JtYXRQYXlEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKTtcclxuICAgIGNvbnN0IG9wdGlvbnMgPSB7IGRheTogXCJudW1lcmljXCIsIG1vbnRoOiBcInNob3J0XCIsIHllYXI6IFwibnVtZXJpY1wiIH07XHJcbiAgICByZXR1cm4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1VU1wiLCBvcHRpb25zKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQcmludCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHJlY2VpcHRFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyZWNlaXB0XCIpO1xyXG4gICAgY29uc3QgY2FudmFzID0gYXdhaXQgaHRtbDJjYW52YXMocmVjZWlwdEVsZW1lbnQsIHsgc2NhbGU6IDIgfSk7XHJcbiAgICBjb25zdCBpbWdEYXRhID0gY2FudmFzLnRvRGF0YVVSTChcImltYWdlL3BuZ1wiKTtcclxuXHJcbiAgICBjb25zdCBwZGYgPSBuZXcganNQREYoXCJwb3J0cmFpdFwiLCBcIm1tXCIsIFwiYTRcIik7XHJcbiAgICBjb25zdCBwYWdlV2lkdGggPSBwZGYuaW50ZXJuYWwucGFnZVNpemUuZ2V0V2lkdGgoKTtcclxuICAgIGNvbnN0IHBhZ2VIZWlnaHQgPSBwZGYuaW50ZXJuYWwucGFnZVNpemUuZ2V0SGVpZ2h0KCk7XHJcblxyXG4gICAgcGRmLmFkZEltYWdlKGltZ0RhdGEsIFwiUE5HXCIsIDAsIDAsIHBhZ2VXaWR0aCwgcGFnZUhlaWdodCk7XHJcbiAgICBwZGYuc2F2ZShcIlJlZ2lzdHJhdGlvbiBSZWNlaXB0LnBkZlwiKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBhbGlnbj1cImNlbnRlclwiIHN0eWxlPXt7IG1hcmdpblRvcDogXCI4MHB4XCIgfX0+XHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmludH1cclxuICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXZpb2xldC00MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgbWItNSByb3VuZGVkLW1kIHNoYWRvdyBob3Zlcjpib3JkZXItdmlvbGV0LTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBtdC00XCJcclxuICAgICAgPlxyXG4gICAgICAgIDxCaVByaW50ZXIgY29sb3I9XCJ2aW9sZXRcIiAvPlxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGlkPVwicmVjZWlwdFwiXHJcbiAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgIHdpZHRoOiBcIjIxMG1tXCIsXHJcbiAgICAgICAgICBoZWlnaHQ6IFwiMjk3bW1cIixcclxuICAgICAgICAgIHBhZGRpbmc6IFwiMTBtbVwiLFxyXG4gICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZGRkXCIsXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcInJvd1wiLFxyXG4gICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICAgICAgZ2FwOiBcIjEwbW1cIixcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgd2lkdGg6IFwiNDglXCIsXHJcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgI2RkZFwiLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiOHB4XCIsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IFwiMTVweFwiLFxyXG4gICAgICAgICAgICBib3hTaGFkb3c6IFwiMCAwIDEwcHggcmdiYSgwLCAwLCAwLCAwLjEpXCIsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgc3JjPXtteWNoaXRzTG9nb31cclxuICAgICAgICAgICAgYWx0PVwiQ29tcGFueSBMb2dvXCJcclxuICAgICAgICAgICAgd2lkdGg9XCI0MFwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbjogXCIwIGF1dG8gOHB4XCIsIGRpc3BsYXk6IFwiYmxvY2tcIiB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxoMiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIG1hcmdpbjogMCB9fT5NWSBDSElUUzwvaDI+XHJcbiAgICAgICAgICA8cCBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIGZvbnRTaXplOiBcIjEycHhcIiwgbWFyZ2luOiBcIjVweCAwXCIgfX0+XHJcbiAgICAgICAgICAgIE5vLjExLzM2LTI1LCAybmQgTWFpbiwgS2F0aHJpZ3VwcGUgTWFpbiBSb2FkLFxyXG4gICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgQmFuZ2Fsb3JlLCA1NjAwODUgOTQ4MzkwMDc3N1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPGhyIC8+XHJcbiAgICAgICAgICA8aDMgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBtYXJnaW46IFwiNXB4IDBcIiB9fT5SZWdpc3RyYXRpb24gUmVjZWlwdDwvaDM+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJzdGFydFwiIH19PlxyXG4gICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICBSZWNlaXB0IE5vOntcIiBcIn1cclxuICAgICAgICAgICAgICB7cGF5bWVudC5yZWNlaXB0X25vID8gcGF5bWVudC5yZWNlaXB0X25vIDogcGF5bWVudC5vbGRfcmVjZWlwdF9ub31cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8cD5EYXRlOiB7Zm9ybWF0UGF5RGF0ZShwYXltZW50LnBheV9kYXRlKX08L3A+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiBcIjRweFwiIH19PjwvZGl2PlxyXG4gICAgICAgICAgICA8cD5OYW1lOiB7cGF5bWVudD8udXNlcl9pZD8uZnVsbF9uYW1lfTwvcD5cclxuICAgICAgICAgICAgPHA+TW9iaWxlIE5vOiB7cGF5bWVudD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyfTwvcD5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IFwiNHB4XCIgfX0+PC9kaXY+XHJcbiAgICAgICAgICAgIDxwPkdyb3VwOiB7cGF5bWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9PC9wPlxyXG4gICAgICAgICAgICA8cD5UaWNrZXQ6IHtwYXltZW50Py50aWNrZXR9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgdGV4dEFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLFxyXG4gICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgIzAwMFwiLFxyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTBweFwiLFxyXG4gICAgICAgICAgICAgIG1hcmdpbjogXCIxMHB4IDBcIixcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmVjZWl2ZWQgQW1vdW50IHwgUnMue3BheW1lbnQ/LmFtb3VudH1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwic3RhcnRcIiB9fT5cclxuICAgICAgICAgICAgPHA+TW9kZToge3BheW1lbnQ/LnBheV90eXBlfTwvcD5cclxuICAgICAgICAgICAgPHA+VG90YWw6IFJzLntwYXltZW50Py5hbW91bnR9PC9wPlxyXG4gICAgICAgICAgICA8cD5Db2xsZWN0ZWQgYnk6IHtwYXltZW50Py5jb2xsZWN0ZWRfYnk/Lm5hbWUgfHwgXCJBZG1pblwifTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IFwiNHB4XCIgfX0+PC9kaXY+XHJcbiAgICAgICAgICA8cD5DdXN0b21lciBDb3B5PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICB3aWR0aDogXCI0OCVcIixcclxuICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZGRkXCIsXHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCI4cHhcIixcclxuICAgICAgICAgICAgcGFkZGluZzogXCIxNXB4XCIsXHJcbiAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDAgMTBweCByZ2JhKDAsIDAsIDAsIDAuMSlcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICBzcmM9e215Y2hpdHNMb2dvfVxyXG4gICAgICAgICAgICBhbHQ9XCJDb21wYW55IExvZ29cIlxyXG4gICAgICAgICAgICB3aWR0aD1cIjQwXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luOiBcIjAgYXV0byA4cHhcIiwgZGlzcGxheTogXCJibG9ja1wiIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGgyIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgbWFyZ2luOiAwIH19Pk1ZIENISVRTPC9oMj5cclxuICAgICAgICAgIDxwIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgZm9udFNpemU6IFwiMTJweFwiLCBtYXJnaW46IFwiNXB4IDBcIiB9fT5cclxuICAgICAgICAgICAgTm8uMTEvMzYtMjUsIDJuZCBNYWluLCBLYXRocmlndXBwZSBNYWluIFJvYWQsXHJcbiAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICBCYW5nYWxvcmUsIDU2MDA4NSA5NDgzOTAwNzc3XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8aHIgLz5cclxuICAgICAgICAgIDxoMyBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIG1hcmdpbjogXCI1cHggMFwiIH19PlJlZ2lzdHJhdGlvbiBSZWNlaXB0PC9oMz5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcInN0YXJ0XCIgfX0+XHJcbiAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgIFJlY2VpcHQgTm86e1wiIFwifVxyXG4gICAgICAgICAgICAgIHtwYXltZW50LnJlY2VpcHRfbm8gPyBwYXltZW50LnJlY2VpcHRfbm8gOiBwYXltZW50Lm9sZF9yZWNlaXB0X25vfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxwPkRhdGU6IHtmb3JtYXRQYXlEYXRlKHBheW1lbnQucGF5X2RhdGUpfTwvcD5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IFwiNHB4XCIgfX0+PC9kaXY+XHJcbiAgICAgICAgICAgIDxwPk5hbWU6IHtwYXltZW50Py51c2VyX2lkPy5mdWxsX25hbWV9PC9wPlxyXG4gICAgICAgICAgICA8cD5Nb2JpbGUgTm86IHtwYXltZW50Py51c2VyX2lkPy5waG9uZV9udW1iZXJ9PC9wPlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogXCI0cHhcIiB9fT48L2Rpdj5cclxuICAgICAgICAgICAgPHA+R3JvdXA6IHtwYXltZW50Py5ncm91cF9pZD8uZ3JvdXBfbmFtZX08L3A+XHJcbiAgICAgICAgICAgIDxwPlRpY2tldDoge3BheW1lbnQ/LnRpY2tldH08L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgICAgZm9udFdlaWdodDogXCJib2xkXCIsXHJcbiAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjMDAwXCIsXHJcbiAgICAgICAgICAgICAgcGFkZGluZzogXCIxMHB4XCIsXHJcbiAgICAgICAgICAgICAgbWFyZ2luOiBcIjEwcHggMFwiLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBSZWNlaXZlZCBBbW91bnQgfCBScy57cGF5bWVudD8uYW1vdW50fVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJzdGFydFwiIH19PlxyXG4gICAgICAgICAgICA8cD5Nb2RlOiB7cGF5bWVudD8ucGF5X3R5cGV9PC9wPlxyXG4gICAgICAgICAgICA8cD5Ub3RhbDogUnMue3BheW1lbnQ/LmFtb3VudH08L3A+XHJcbiAgICAgICAgICAgIDxwPkNvbGxlY3RlZCBieToge3BheW1lbnQ/LmNvbGxlY3RlZF9ieT8ubmFtZSB8fCBcIkFkbWluXCJ9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogXCI0cHhcIiB9fT48L2Rpdj5cclxuICAgICAgICAgIDxwPkFkbWluIENvcHk8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICBcclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZWdpc3RyYXRpb25SZWNlaXB0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUmVnaXN0cmF0aW9uUmVjZWlwdC5qc3gifQ==