import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerAppEvents.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const CustomerAppEvents = () => {
  _s();
  const [usereventlogDataTable, setUsereventlogDataTable] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedToDate, setSelectedToDate] = useState("");
  const [showFilterField, setShowFilterField] = useState(false);
  const [summary, setSummary] = useState({
    totalEvents: 0,
    totalSuccess: 0,
    totalFailed: 0,
    totalUsers: 0
  });
  const [formData, setFormData] = useState({
    user: "",
    filterType: "Today"
  });
  const [errors, setErrors] = useState({});
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value
    }));
    setErrors((prev) => ({
      ...prev,
      [field]: ""
    }));
  };
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const formatDate = (date) => date.toLocaleDateString("en-CA");
  const handleSelectFilter = (value) => {
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    let from = "";
    let to = "";
    if (value === "Today") {
      from = formatDate(today);
      to = formatDate(today);
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(today.getDate() - 1);
      from = formatDate(y);
      to = formatDate(y);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "Custom") {
      setShowFilterField(true);
      return;
    }
    setSelectedFromDate(from);
    setSelectedToDate(to);
  };
  useEffect(() => {
    handleSelectFilter(formData.filterType);
  }, [formData.filterType]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await api.get("/user/get-user");
        setUsers(res.data || []);
      } catch (err) {
        console.error(err);
      }
    };
    fetchUsers();
  }, []);
  const fetchUserEventslog = async () => {
    try {
      setLoading(true);
      let url = "/user-event-logger/user-events-logger";
      if (formData.user) {
        url += `/${formData.user}`;
      }
      const params = [];
      if (selectedFromDate && selectedToDate) {
        params.push(`from_date=${selectedFromDate}`);
        params.push(`to_date=${selectedToDate}`);
      }
      if (params.length > 0) {
        url += `?${params.join("&")}`;
      }
      const response = await api.get(url);
      setSummary(response.data?.summary || {});
      const formatted = response.data?.data?.map((user, index) => ({
        id: user._id,
        slNo: index + 1,
        userName: user.user_id?.full_name || "-",
        userPhone: user.user_id?.phone_number || "-",
        appPhone: user.phone || "-",
        activity: user.action || "-",
        status: user.status || "-",
        reason: user.reason || "-",
        createdAt: user.createdAt ? new Date(user.createdAt).toLocaleString() : "-"
      }));
      setUsereventlogDataTable(formatted);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (selectedFromDate && selectedToDate) {
      fetchUserEventslog();
    }
  }, [selectedFromDate, selectedToDate, formData.user]);
  useEffect(() => {
    handleSelectFilter("Today");
  }, []);
  useEffect(() => {
    if (formData.filterType === "Custom" && selectedFromDate && selectedToDate) {
      fetchUserEventslog();
    }
  }, [selectedFromDate, selectedToDate]);
  const column = [
    { key: "slNo", header: "Sl No" },
    { key: "userName", header: "Name" },
    { key: "userPhone", header: "Phone" },
    { key: "appPhone", header: "App Phone" },
    { key: "activity", header: "Activity" },
    { key: "status", header: "Status" },
    { key: "reason", header: "Reason" },
    { key: "createdAt", header: "Date & Time" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
      lineNumber: 288,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-1", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Mobile Customer App Activity Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
        lineNumber: 291,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 items-center mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Select Customer " }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 300,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-12",
              placeholder: "All Users",
              value: formData.user || void 0,
              onChange: (value) => handleAntDSelect("user", value),
              allowClear: true,
              showSearch: true,
              optionFilterProp: "children",
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customer" }, "all", false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
                  lineNumber: 310,
                  columnNumber: 17
                }, this),
                users.map(
                  (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: u.full_name }, u._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
                    lineNumber: 312,
                    columnNumber: 15
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
              lineNumber: 301,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 299,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Date Filter" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 321,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-12",
              value: formData.filterType,
              onChange: (value) => handleAntDSelect("filterType", value),
              children: groupOptions.map(
                (opt) => /* @__PURE__ */ jsxDEV(Select.Option, { value: opt.value, children: opt.label }, opt.value, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
                  lineNumber: 330,
                  columnNumber: 15
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
              lineNumber: 322,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 320,
          columnNumber: 11
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 items-end w-1/3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm", children: "From" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
              lineNumber: 341,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "border p-2 rounded",
                value: selectedFromDate,
                onChange: (e) => setSelectedFromDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
                lineNumber: 342,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 340,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm", children: "To" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
              lineNumber: 353,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "border p-2 rounded",
                value: selectedToDate,
                onChange: (e) => setSelectedToDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
                lineNumber: 354,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 352,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 339,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
        lineNumber: 296,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Events" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 369,
            columnNumber: 5
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalEvents }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 370,
            columnNumber: 5
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 368,
          columnNumber: 3
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Success" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 374,
            columnNumber: 5
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalSuccess }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 375,
            columnNumber: 5
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 373,
          columnNumber: 3
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Failed" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 379,
            columnNumber: 5
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalFailed }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 380,
            columnNumber: 5
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 378,
          columnNumber: 3
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 384,
            columnNumber: 5
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalUsers }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
            lineNumber: 385,
            columnNumber: 5
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 383,
          columnNumber: 3
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
        lineNumber: 367,
        columnNumber: 9
      }, this),
      usereventlogDataTable.length > 0 && !loading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: column,
          data: usereventlogDataTable,
          exportedFileName: "Customer App Events Report",
          exportedPdfName: "Customer App Events Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 391,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: loading,
          failure: loading <= 0,
          data: "Customer App Events"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
          lineNumber: 398,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
      lineNumber: 290,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx",
    lineNumber: 287,
    columnNumber: 5
  }, this);
};
_s(CustomerAppEvents, "os2XsAESLcHnrnNmFLx7k2aVgjU=");
_c = CustomerAppEvents;
export default CustomerAppEvents;
var _c;
$RefreshReg$(_c, "CustomerAppEvents");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppEvents.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK1JNOzJCQS9STjtBQUFtQkEsb0JBQWlCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixTQUFRQyxjQUFhO0FBQ3JCLE9BQU9DLG9CQUFvQjtBQUUzQixNQUFNQyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUM5QixRQUFNLENBQUNDLHVCQUF1QkMsd0JBQXdCLElBQUlDLFNBQVMsRUFBRTtBQUNyRSxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUYsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ0csU0FBU0MsVUFBVSxJQUFJSixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDSyxXQUFXQyxZQUFZLElBQUlOLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNPLGtCQUFrQkMsbUJBQW1CLElBQUlSLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNTLGdCQUFnQkMsaUJBQWlCLElBQUlWLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNXLGlCQUFpQkMsa0JBQWtCLElBQUlaLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBSWQsU0FBUztBQUFBLElBQ3JDZSxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLElBQ2RDLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBRUMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlwQixTQUFTO0FBQUEsSUFDdkNxQixNQUFNO0FBQUEsSUFDTkMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJeEIsU0FBUyxDQUFDLENBQUM7QUFHdkMsUUFBTXlCLG1CQUFtQkEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN6Q1AsZ0JBQVksQ0FBQ1EsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHQztBQUFBQSxJQUNYLEVBQUU7QUFFRkgsY0FBVSxDQUFDSSxVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixLQUFLLEdBQUc7QUFBQSxJQUNYLEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTUcsZUFBZTtBQUFBLElBQ25CLEVBQUVGLE9BQU8sU0FBU0csT0FBTyxRQUFRO0FBQUEsSUFDakMsRUFBRUgsT0FBTyxhQUFhRyxPQUFPLFlBQVk7QUFBQSxJQUN6QyxFQUFFSCxPQUFPLGFBQWFHLE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUVILE9BQU8sYUFBYUcsT0FBTyxhQUFhO0FBQUEsSUFDMUMsRUFBRUgsT0FBTyxZQUFZRyxPQUFPLFlBQVk7QUFBQSxJQUN4QyxFQUFFSCxPQUFPLFVBQVVHLE9BQU8sU0FBUztBQUFBLEVBQUM7QUFHdEMsUUFBTUMsYUFBYUEsQ0FBQ0MsU0FBU0EsS0FBS0MsbUJBQW1CLE9BQU87QUErQzdELFFBQU1DLHFCQUFxQkEsQ0FBQ1AsVUFBVTtBQUNyQ2YsdUJBQW1CLEtBQUs7QUFFeEIsVUFBTXVCLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsUUFBSUMsT0FBTztBQUNYLFFBQUlDLEtBQUs7QUFFVCxRQUFJWCxVQUFVLFNBQVM7QUFDckJVLGFBQU9OLFdBQVdJLEtBQUs7QUFDdkJHLFdBQUtQLFdBQVdJLEtBQUs7QUFBQSxJQUN2QixXQUFXUixVQUFVLGFBQWE7QUFDaEMsWUFBTVksSUFBSSxJQUFJSCxLQUFLRCxLQUFLO0FBQ3hCSSxRQUFFQyxRQUFRTCxNQUFNTSxRQUFRLElBQUksQ0FBQztBQUM3QkosYUFBT04sV0FBV1EsQ0FBQztBQUNuQkQsV0FBS1AsV0FBV1EsQ0FBQztBQUFBLElBQ25CLFdBQVdaLFVBQVUsYUFBYTtBQUNoQyxZQUFNZSxRQUFRLElBQUlOLEtBQUtELE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTUMsTUFBTSxJQUFJVCxLQUFLRCxNQUFNUSxZQUFZLEdBQUdSLE1BQU1TLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakVQLGFBQU9OLFdBQVdXLEtBQUs7QUFDdkJKLFdBQUtQLFdBQVdjLEdBQUc7QUFBQSxJQUNyQixXQUFXbEIsVUFBVSxhQUFhO0FBQ2hDLFlBQU1lLFFBQVEsSUFBSU4sS0FBS0QsTUFBTVEsWUFBWSxHQUFHUixNQUFNUyxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ25FLFlBQU1DLE1BQU0sSUFBSVQsS0FBS0QsTUFBTVEsWUFBWSxHQUFHUixNQUFNUyxTQUFTLEdBQUcsQ0FBQztBQUM3RFAsYUFBT04sV0FBV1csS0FBSztBQUN2QkosV0FBS1AsV0FBV2MsR0FBRztBQUFBLElBQ3JCLFdBQVdsQixVQUFVLFlBQVk7QUFDL0IsWUFBTWUsUUFBUSxJQUFJTixLQUFLRCxNQUFNUSxZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSVQsS0FBS0QsTUFBTVEsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRE4sYUFBT04sV0FBV1csS0FBSztBQUN2QkosV0FBS1AsV0FBV2MsR0FBRztBQUFBLElBQ3JCLFdBQVdsQixVQUFVLFVBQVU7QUFDN0JmLHlCQUFtQixJQUFJO0FBQ3ZCO0FBQUEsSUFDRjtBQUdBSix3QkFBb0I2QixJQUFJO0FBQ3hCM0Isc0JBQWtCNEIsRUFBRTtBQUFBLEVBQ3RCO0FBRUVqRCxZQUFVLE1BQU07QUFDZDZDLHVCQUFtQmYsU0FBU0csVUFBVTtBQUFBLEVBQ3hDLEdBQUcsQ0FBQ0gsU0FBU0csVUFBVSxDQUFDO0FBR3hCakMsWUFBVSxNQUFNO0FBQ2QsVUFBTXlELGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNeEQsSUFBSXlELElBQUksZ0JBQWdCO0FBQzFDOUMsaUJBQVM2QyxJQUFJRSxRQUFRLEVBQUU7QUFBQSxNQUN6QixTQUFTQyxLQUFLO0FBQ1pDLGdCQUFRQyxNQUFNRixHQUFHO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQ0FKLGVBQVc7QUFBQSxFQUNiLEdBQUcsRUFBRTtBQW1ETCxRQUFNTyxxQkFBcUIsWUFBWTtBQUN2QyxRQUFJO0FBQ0ZqRCxpQkFBVyxJQUFJO0FBRWYsVUFBSWtELE1BQU07QUFFVixVQUFJbkMsU0FBU0UsTUFBTTtBQUNqQmlDLGVBQU8sSUFBSW5DLFNBQVNFLElBQUk7QUFBQSxNQUMxQjtBQUVBLFlBQU1rQyxTQUFTO0FBRWYsVUFBSWhELG9CQUFvQkUsZ0JBQWdCO0FBQ3RDOEMsZUFBT0MsS0FBSyxhQUFhakQsZ0JBQWdCLEVBQUU7QUFDM0NnRCxlQUFPQyxLQUFLLFdBQVcvQyxjQUFjLEVBQUU7QUFBQSxNQUN6QztBQUVBLFVBQUk4QyxPQUFPRSxTQUFTLEdBQUc7QUFDckJILGVBQU8sSUFBSUMsT0FBT0csS0FBSyxHQUFHLENBQUM7QUFBQSxNQUM3QjtBQUVBLFlBQU1DLFdBQVcsTUFBTXBFLElBQUl5RCxJQUFJTSxHQUFHO0FBR2xDeEMsaUJBQVc2QyxTQUFTVixNQUFNcEMsV0FBVyxDQUFDLENBQUM7QUFHdkMsWUFBTStDLFlBQVlELFNBQVNWLE1BQU1BLE1BQU1ZLElBQUksQ0FBQ3hDLE1BQU15QyxXQUFXO0FBQUEsUUFDM0RDLElBQUkxQyxLQUFLMkM7QUFBQUEsUUFDVEMsTUFBTUgsUUFBUTtBQUFBLFFBQ2RJLFVBQVU3QyxLQUFLOEMsU0FBU0MsYUFBYTtBQUFBLFFBQ3JDQyxXQUFXaEQsS0FBSzhDLFNBQVNHLGdCQUFnQjtBQUFBLFFBQ3pDQyxVQUFVbEQsS0FBS21ELFNBQVM7QUFBQSxRQUN4QkMsVUFBVXBELEtBQUtxRCxVQUFVO0FBQUEsUUFDekJDLFFBQVF0RCxLQUFLc0QsVUFBVTtBQUFBLFFBQ3ZCQyxRQUFRdkQsS0FBS3VELFVBQVU7QUFBQSxRQUN2QkMsV0FBV3hELEtBQUt3RCxZQUNaLElBQUl6QyxLQUFLZixLQUFLd0QsU0FBUyxFQUFFQyxlQUFlLElBQ3hDO0FBQUEsTUFDTixFQUFFO0FBRUYvRSwrQkFBeUI2RCxTQUFTO0FBQUEsSUFDcEMsU0FBU1YsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQUEsSUFDbkIsVUFBQztBQUNDOUMsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUdFZixZQUFVLE1BQU07QUFDZCxRQUFJa0Isb0JBQW9CRSxnQkFBZ0I7QUFDdEM0Qyx5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0YsR0FBRyxDQUFDOUMsa0JBQWtCRSxnQkFBZ0JVLFNBQVNFLElBQUksQ0FBQztBQUdwRGhDLFlBQVUsTUFBTTtBQUNkNkMsdUJBQW1CLE9BQU87QUFBQSxFQUM1QixHQUFHLEVBQUU7QUFFTDdDLFlBQVUsTUFBTTtBQUNoQixRQUFJOEIsU0FBU0csZUFBZSxZQUFZZixvQkFBb0JFLGdCQUFnQjtBQUMxRTRDLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUM5QyxrQkFBa0JFLGNBQWMsQ0FBQztBQUduQyxRQUFNc0UsU0FBUztBQUFBLElBQ2IsRUFBRUMsS0FBSyxRQUFRQyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFRCxLQUFLLFlBQVlDLFFBQVEsT0FBTztBQUFBLElBQ2xDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxRQUFRO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLFlBQVk7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBQ0QsS0FBSyxVQUFVQyxRQUFRLFNBQVE7QUFBQSxJQUNoQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsY0FBYztBQUFBLEVBQUM7QUFHN0MsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFFekIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtCQUE4QixtREFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0NBR2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxzQkFBcUIsZ0NBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNEO0FBQUEsVUFDdEQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU85RCxTQUFTRSxRQUFRNkQ7QUFBQUEsY0FDeEIsVUFBVSxDQUFDdkQsVUFBVUYsaUJBQWlCLFFBQVFFLEtBQUs7QUFBQSxjQUNuRDtBQUFBLGNBQ0E7QUFBQSxjQUNBLGtCQUFpQjtBQUFBLGNBRWY7QUFBQSx1Q0FBQyxPQUFPLFFBQVAsRUFBd0IsT0FBTSxJQUFHLDRCQUFmLE9BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDO0FBQUEsZ0JBQy9DMUIsTUFBTTREO0FBQUFBLGtCQUFJLENBQUNzQixNQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxFQUFFbkIsS0FDakNtQixZQUFFZixhQURlZSxFQUFFbkIsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQTtBQUFBLFlBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZUE7QUFBQSxhQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxzQkFBcUIsMkJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU83QyxTQUFTRztBQUFBQSxjQUNoQixVQUFVLENBQUNLLFVBQ1RGLGlCQUFpQixjQUFjRSxLQUFLO0FBQUEsY0FHckNFLHVCQUFhZ0M7QUFBQUEsZ0JBQUksQ0FBQ3VCLFFBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxJQUFJekQsT0FDdkN5RCxjQUFJdEQsU0FEYXNELElBQUl6RCxPQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFHQ2hCLG1CQUNDLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsaUJBQWdCLG9CQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ3JDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFPSjtBQUFBQSxnQkFDUCxVQUFVLENBQUM4RSxNQUNUN0Usb0JBQW9CNkUsRUFBRUMsT0FBTzNELEtBQUs7QUFBQTtBQUFBLGNBTHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1HO0FBQUEsZUFSTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGlCQUFnQixrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUM7QUFBQSxZQUNuQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsT0FBT2xCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQzRFLE1BQ1QzRSxrQkFBa0IyRSxFQUFFQyxPQUFPM0QsS0FBSztBQUFBO0FBQUEsY0FMcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUc7QUFBQSxlQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsV0FuRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNyQjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLE9BQUUsNEJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQ2YsdUJBQUMsUUFBSWQsa0JBQVFFLGVBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxhQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLGlDQUFDLE9BQUUsdUJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVTtBQUFBLFVBQ1YsdUJBQUMsUUFBSUYsa0JBQVFHLGdCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsYUFGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxPQUFFLHNCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVM7QUFBQSxVQUNULHVCQUFDLFFBQUlILGtCQUFRSSxlQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUEsYUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxPQUFFLHlCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxVQUNaLHVCQUFDLFFBQUlKLGtCQUFRSyxjQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsYUFGMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FuQk07QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CUjtBQUFBLE1BR1NwQixzQkFBc0IyRCxTQUFTLEtBQUssQ0FBQ3RELFVBQ3BDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRCxTQUFTNEU7QUFBQUEsVUFDVCxNQUFNakY7QUFBQUEsVUFDTixrQkFBaUI7QUFBQSxVQUNqQixpQkFBZ0I7QUFBQTtBQUFBLFFBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUk0QyxJQUcxQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0QsV0FBV0s7QUFBQUEsVUFDWCxTQUFVQSxXQUFVO0FBQUEsVUFDcEIsTUFBSztBQUFBO0FBQUEsUUFITDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHMEI7QUFBQSxTQS9HaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtIQTtBQUFBLE9BckhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzSEE7QUFFSjtBQUFFTixHQTlZSUQsbUJBQWlCO0FBQUEyRixLQUFqQjNGO0FBZ1pOLGVBQWVBO0FBQWtCLElBQUEyRjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiRGF0YVRhYmxlIiwiYXBpIiwiTmF2YmFyIiwiU2lkZWJhciIsIlNlbGVjdCIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tZXJBcHBFdmVudHMiLCJfcyIsInVzZXJldmVudGxvZ0RhdGFUYWJsZSIsInNldFVzZXJldmVudGxvZ0RhdGFUYWJsZSIsInVzZVN0YXRlIiwidXNlcnMiLCJzZXRVc2VycyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZFRvRGF0ZSIsInNldFNlbGVjdGVkVG9EYXRlIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwic3VtbWFyeSIsInNldFN1bW1hcnkiLCJ0b3RhbEV2ZW50cyIsInRvdGFsU3VjY2VzcyIsInRvdGFsRmFpbGVkIiwidG90YWxVc2VycyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ1c2VyIiwiZmlsdGVyVHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInZhbHVlIiwicHJldiIsImdyb3VwT3B0aW9ucyIsImxhYmVsIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ0b2RheSIsIkRhdGUiLCJmcm9tIiwidG8iLCJ5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJmZXRjaFVzZXJzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoVXNlckV2ZW50c2xvZyIsInVybCIsInBhcmFtcyIsInB1c2giLCJsZW5ndGgiLCJqb2luIiwicmVzcG9uc2UiLCJmb3JtYXR0ZWQiLCJtYXAiLCJpbmRleCIsImlkIiwiX2lkIiwic2xObyIsInVzZXJOYW1lIiwidXNlcl9pZCIsImZ1bGxfbmFtZSIsInVzZXJQaG9uZSIsInBob25lX251bWJlciIsImFwcFBob25lIiwicGhvbmUiLCJhY3Rpdml0eSIsImFjdGlvbiIsInN0YXR1cyIsInJlYXNvbiIsImNyZWF0ZWRBdCIsInRvTG9jYWxlU3RyaW5nIiwiY29sdW1uIiwia2V5IiwiaGVhZGVyIiwidW5kZWZpbmVkIiwidSIsIm9wdCIsImUiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDdXN0b21lckFwcEV2ZW50cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHtTZWxlY3R9IGZyb20gXCJhbnRkXCJcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuXHJcbmNvbnN0IEN1c3RvbWVyQXBwRXZlbnRzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFt1c2VyZXZlbnRsb2dEYXRhVGFibGUsIHNldFVzZXJldmVudGxvZ0RhdGFUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRUb0RhdGUsIHNldFNlbGVjdGVkVG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93RmlsdGVyRmllbGQsIHNldFNob3dGaWx0ZXJGaWVsZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbmNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICB0b3RhbEV2ZW50czogMCxcclxuICB0b3RhbFN1Y2Nlc3M6IDAsXHJcbiAgdG90YWxGYWlsZWQ6IDAsXHJcbiAgdG90YWxVc2VyczogMCxcclxufSk7XHJcbiAgLy8g4pyFIFVuaWZpZWQgc3RhdGVcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXI6IFwiXCIsXHJcbiAgICBmaWx0ZXJUeXBlOiBcIlRvZGF5XCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIC8vIOKchSBDb21tb24gaGFuZGxlclxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbZmllbGRdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIC8vIOKchSBGaWx0ZXIgb3B0aW9uc1xyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcblxyXG4vLyBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuLy8gICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuLy8gICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbi8vICAgbGV0IGZyb20gPSBcIlwiO1xyXG4vLyAgIGxldCB0byA9IFwiXCI7XHJcblxyXG4vLyAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbi8vICAgICBmcm9tID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbi8vICAgICB0byA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4vLyAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgIGNvbnN0IHkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbi8vICAgICB5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbi8vICAgICBmcm9tID0gZm9ybWF0RGF0ZSh5KTtcclxuLy8gICAgIHRvID0gZm9ybWF0RGF0ZSh5KTtcclxuLy8gICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbi8vICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4vLyAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4vLyAgICAgZnJvbSA9IGZvcm1hdERhdGUoc3RhcnQpO1xyXG4vLyAgICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbi8vICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4vLyAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbi8vICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuLy8gICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuLy8gICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4vLyAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4vLyAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuLy8gICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbi8vICAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbi8vICAgICB0byA9IGZvcm1hdERhdGUoZW5kKTtcclxuLy8gICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbi8vICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbi8vICAgICByZXR1cm47XHJcbi8vICAgfVxyXG5cclxuLy8gICAvLyDinIUgU2V0IHN0YXRlXHJcbi8vICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmcm9tKTtcclxuLy8gICBzZXRTZWxlY3RlZFRvRGF0ZSh0byk7XHJcblxyXG4vLyAgIC8vIOKchSBDQUxMIEFQSSBESVJFQ1RMWSAoRklYKVxyXG4vLyAgIGZldGNoVXNlckV2ZW50c2xvZyhmcm9tLCB0byk7XHJcbi8vIH07XHJcblxyXG4gIC8vIOKchSBTeW5jIGZpbHRlclR5cGUg4oaSIGRhdGVcclxuIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICBsZXQgZnJvbSA9IFwiXCI7XHJcbiAgbGV0IHRvID0gXCJcIjtcclxuXHJcbiAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuICAgIGZyb20gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICAgIHRvID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbiAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgIHkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSAxKTtcclxuICAgIGZyb20gPSBmb3JtYXREYXRlKHkpO1xyXG4gICAgdG8gPSBmb3JtYXREYXRlKHkpO1xyXG4gIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbiAgICB0byA9IGZvcm1hdERhdGUoZW5kKTtcclxuICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4gICAgZnJvbSA9IGZvcm1hdERhdGUoc3RhcnQpO1xyXG4gICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbiAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbiAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4gIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIC8vIOKchSBPTkxZIHVwZGF0ZSBzdGF0ZSAoTk8gQVBJIENBTEwgSEVSRSlcclxuICBzZXRTZWxlY3RlZEZyb21EYXRlKGZyb20pO1xyXG4gIHNldFNlbGVjdGVkVG9EYXRlKHRvKTtcclxufTtcclxuIFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoZm9ybURhdGEuZmlsdGVyVHlwZSk7XHJcbiAgfSwgW2Zvcm1EYXRhLmZpbHRlclR5cGVdKTtcclxuXHJcbiAgLy8g4pyFIEZldGNoIFVzZXJzXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlcy5kYXRhIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8g4pyFIEZldGNoIExvZ3NcclxuICAvLyBjb25zdCBmZXRjaFVzZXJFdmVudHNsb2cgPSBhc3luYyAoKSA9PiB7XHJcbiAgLy8gICB0cnkge1xyXG4gICAgICAgIFxyXG4gIC8vICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuICAvLyAgICAgbGV0IHVybCA9IFwiL3VzZXItZXZlbnQtbG9nZ2VyL3VzZXItZXZlbnRzLWxvZ2dlclwiO1xyXG5cclxuICAvLyAgICAgaWYgKGZvcm1EYXRhLnVzZXIpIHtcclxuICAvLyAgICAgICB1cmwgKz0gYC8ke2Zvcm1EYXRhLnVzZXJ9YDtcclxuICAvLyAgICAgfVxyXG5cclxuICAvLyAgICAgY29uc3QgcGFyYW1zID0gW107XHJcblxyXG4gIC8vICAgICBpZiAoc2VsZWN0ZWRGcm9tRGF0ZSAmJiBzZWxlY3RlZFRvRGF0ZSkge1xyXG4gIC8vICAgICAgIHBhcmFtcy5wdXNoKGBmcm9tX2RhdGU9JHtzZWxlY3RlZEZyb21EYXRlfWApO1xyXG4gIC8vICAgICAgIHBhcmFtcy5wdXNoKGB0b19kYXRlPSR7c2VsZWN0ZWRUb0RhdGV9YCk7XHJcbiAgLy8gICAgIH1cclxuXHJcbiAgLy8gICAgIGlmIChwYXJhbXMubGVuZ3RoID4gMCkge1xyXG4gIC8vICAgICAgIHVybCArPSBgPyR7cGFyYW1zLmpvaW4oXCImXCIpfWA7XHJcbiAgLy8gICAgIH1cclxuXHJcbiAgLy8gICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG5cclxuICAvLyAgICAgc2V0U3VtbWFyeShyZXNwb25zZS5kYXRhPy5zdW1tYXJ5IHx8IHt9KTtcclxuXHJcbiAgLy8gICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlc3BvbnNlLmRhdGE/LmRhdGE/Lm1hcCgodXNlciwgaW5kZXgpID0+ICh7XHJcbiAgLy8gICAgICAgaWQ6IHVzZXIuX2lkLFxyXG4gIC8vICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAvLyAgICAgICB1c2VyTmFtZTogdXNlci51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgLy8gICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAvLyAgICAgICBhcHBQaG9uZTogdXNlci5waG9uZSB8fCBcIi1cIixcclxuICAvLyAgICAgICBhY3Rpdml0eTogdXNlci5hY3Rpb24gfHwgXCItXCIsXHJcbiAgLy8gICAgICAgc3RhdHVzOiB1c2VyLnN0YXR1cyB8fCBcIi1cIixcclxuICAvLyAgICAgICByZWFzb246IHVzZXIucmVhc29uIHx8IFwiLVwiLFxyXG4gIC8vICAgICAgIGNyZWF0ZWRBdDogdXNlci5jcmVhdGVkQXRcclxuICAvLyAgICAgICAgID8gbmV3IERhdGUodXNlci5jcmVhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKClcclxuICAvLyAgICAgICAgIDogXCItXCIsXHJcbiAgLy8gICAgIH0pKTtcclxuXHJcbiAgLy8gICAgIHNldFVzZXJldmVudGxvZ0RhdGFUYWJsZShmb3JtYXR0ZWQpO1xyXG4gIC8vICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgLy8gICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAvLyAgIH0gZmluYWxseSB7XHJcbiAgLy8gICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gIC8vICAgfVxyXG4gIC8vIH07XHJcblxyXG4gIGNvbnN0IGZldGNoVXNlckV2ZW50c2xvZyA9IGFzeW5jICgpID0+IHtcclxuICB0cnkge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICBsZXQgdXJsID0gXCIvdXNlci1ldmVudC1sb2dnZXIvdXNlci1ldmVudHMtbG9nZ2VyXCI7XHJcblxyXG4gICAgaWYgKGZvcm1EYXRhLnVzZXIpIHtcclxuICAgICAgdXJsICs9IGAvJHtmb3JtRGF0YS51c2VyfWA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcGFyYW1zID0gW107XHJcblxyXG4gICAgaWYgKHNlbGVjdGVkRnJvbURhdGUgJiYgc2VsZWN0ZWRUb0RhdGUpIHtcclxuICAgICAgcGFyYW1zLnB1c2goYGZyb21fZGF0ZT0ke3NlbGVjdGVkRnJvbURhdGV9YCk7XHJcbiAgICAgIHBhcmFtcy5wdXNoKGB0b19kYXRlPSR7c2VsZWN0ZWRUb0RhdGV9YCk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHBhcmFtcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHVybCArPSBgPyR7cGFyYW1zLmpvaW4oXCImXCIpfWA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcblxyXG4gICAgLy8g4pyFIFNFVCBTVU1NQVJZXHJcbiAgICBzZXRTdW1tYXJ5KHJlc3BvbnNlLmRhdGE/LnN1bW1hcnkgfHwge30pO1xyXG5cclxuICAgIC8vIOKchSBUQUJMRSBEQVRBXHJcbiAgICBjb25zdCBmb3JtYXR0ZWQgPSByZXNwb25zZS5kYXRhPy5kYXRhPy5tYXAoKHVzZXIsIGluZGV4KSA9PiAoe1xyXG4gICAgICBpZDogdXNlci5faWQsXHJcbiAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgdXNlck5hbWU6IHVzZXIudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICB1c2VyUGhvbmU6IHVzZXIudXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICBhcHBQaG9uZTogdXNlci5waG9uZSB8fCBcIi1cIixcclxuICAgICAgYWN0aXZpdHk6IHVzZXIuYWN0aW9uIHx8IFwiLVwiLFxyXG4gICAgICBzdGF0dXM6IHVzZXIuc3RhdHVzIHx8IFwiLVwiLFxyXG4gICAgICByZWFzb246IHVzZXIucmVhc29uIHx8IFwiLVwiLFxyXG4gICAgICBjcmVhdGVkQXQ6IHVzZXIuY3JlYXRlZEF0XHJcbiAgICAgICAgPyBuZXcgRGF0ZSh1c2VyLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKVxyXG4gICAgICAgIDogXCItXCIsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0VXNlcmV2ZW50bG9nRGF0YVRhYmxlKGZvcm1hdHRlZCk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gIH1cclxufTtcclxuXHJcbiAgLy8g4pyFIFRyaWdnZXIgZmV0Y2hcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkRnJvbURhdGUgJiYgc2VsZWN0ZWRUb0RhdGUpIHtcclxuICAgICAgZmV0Y2hVc2VyRXZlbnRzbG9nKCk7XHJcbiAgICB9XHJcbiAgfSwgW3NlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkVG9EYXRlLCBmb3JtRGF0YS51c2VyXSk7XHJcblxyXG4gIC8vIOKchSBEZWZhdWx0IGxvYWRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaGFuZGxlU2VsZWN0RmlsdGVyKFwiVG9kYXlcIik7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gIGlmIChmb3JtRGF0YS5maWx0ZXJUeXBlID09PSBcIkN1c3RvbVwiICYmIHNlbGVjdGVkRnJvbURhdGUgJiYgc2VsZWN0ZWRUb0RhdGUpIHtcclxuICAgIGZldGNoVXNlckV2ZW50c2xvZygpO1xyXG4gIH1cclxufSwgW3NlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkVG9EYXRlXSk7XHJcblxyXG4gIC8vIOKchSBUYWJsZSBjb2x1bW5zXHJcbiAgY29uc3QgY29sdW1uID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIk5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJhcHBQaG9uZVwiLCBoZWFkZXI6IFwiQXBwIFBob25lXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGl2aXR5XCIsIGhlYWRlcjogXCJBY3Rpdml0eVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7a2V5OiBcInJlYXNvblwiLCBoZWFkZXI6IFwiUmVhc29uXCJ9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJEYXRlICYgVGltZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0xMFwiPlxyXG4gICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTFcIj5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbiAgICAgICAgICBNb2JpbGUgQ3VzdG9tZXIgQXBwIEFjdGl2aXR5IFJlcG9ydFxyXG4gICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgIHsvKiDinIUgRmlsdGVycyBSb3cgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcblxyXG4gICAgICAgICAgey8qIFVzZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5TZWxlY3QgQ3VzdG9tZXIgPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBVc2Vyc1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnVzZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJ1c2VyXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT1cImFsbFwiIHZhbHVlPVwiXCI+QWxsIEN1c3RvbWVyPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHUpID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dS5faWR9IHZhbHVlPXt1Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgIHt1LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRGF0ZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5EYXRlIEZpbHRlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmZpbHRlclR5cGV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJmaWx0ZXJUeXBlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChvcHQpID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17b3B0LnZhbHVlfSB2YWx1ZT17b3B0LnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAge29wdC5sYWJlbH1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ3VzdG9tIERhdGUgKi99XHJcbiAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIGl0ZW1zLWVuZCB3LTEvM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbVwiPkZyb208L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc21cIj5UbzwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRUb0RhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRvRGF0ZShlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgcC00IHJvdW5kZWRcIj5cclxuICAgIDxwPlRvdGFsIEV2ZW50czwvcD5cclxuICAgIDxoMj57c3VtbWFyeS50b3RhbEV2ZW50c308L2gyPlxyXG4gIDwvZGl2PlxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBwLTQgcm91bmRlZFwiPlxyXG4gICAgPHA+U3VjY2VzczwvcD5cclxuICAgIDxoMj57c3VtbWFyeS50b3RhbFN1Y2Nlc3N9PC9oMj5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICA8cD5GYWlsZWQ8L3A+XHJcbiAgICA8aDI+e3N1bW1hcnkudG90YWxGYWlsZWR9PC9oMj5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICA8cD5DdXN0b21lcnM8L3A+XHJcbiAgICA8aDI+e3N1bW1hcnkudG90YWxVc2Vyc308L2gyPlxyXG4gIDwvZGl2PlxyXG48L2Rpdj5cclxuXHJcbiAgICAgICBcclxuICAgICAgICB7dXNlcmV2ZW50bG9nRGF0YVRhYmxlLmxlbmd0aCA+IDAgJiYgIWxvYWRpbmcgPyAgKFxyXG4gICAgICAgICAgPERhdGFUYWJsZSBcclxuICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbn0gXHJcbiAgICAgICAgICBkYXRhPXt1c2VyZXZlbnRsb2dEYXRhVGFibGV9IFxyXG4gICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkN1c3RvbWVyIEFwcCBFdmVudHMgUmVwb3J0XCJcclxuICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkN1c3RvbWVyIEFwcCBFdmVudHMgUmVwb3J0XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgIGlzTG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgZmFpbHVyZSA9e2xvYWRpbmcgPD0wfVxyXG4gICAgICAgICAgICBkYXRhPVwiQ3VzdG9tZXIgQXBwIEV2ZW50c1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tZXJBcHBFdmVudHM7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DdXN0b21lckFwcEV2ZW50cy5qc3gifQ==