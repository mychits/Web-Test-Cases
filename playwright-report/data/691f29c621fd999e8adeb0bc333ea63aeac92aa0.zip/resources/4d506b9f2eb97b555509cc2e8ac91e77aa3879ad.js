import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/WhatsappPromo.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import whatsappApi from "/src/instance/WhatsappInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const WhatsappPromo = () => {
  _s();
  const [TableUsers, setTableUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const now = /* @__PURE__ */ new Date();
  const todayString = now.toISOString().split("T")[0];
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedToDate, setSelectedToDate] = useState(todayString);
  const [whatsappData, setWhatsappData] = useState([]);
  const [disabled, setDisabled] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [isLoading, setIsLoading] = useState(false);
  const [selectUser, setSelectUser] = useState({});
  const [customerCount, setCustomerCount] = useState(0);
  const [selectAll, setSelectAll] = useState({ msg: "All", checked: false });
  const [formData, setFormData] = useState({
    template_name: ""
  });
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [errors, setErrors] = useState({});
  const [userType, setUserType] = useState("customer");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [selectedReferrerName, setSelectedReferrerName] = useState("");
  const [selectedReferrerType, setSelectedReferrerType] = useState("");
  const [agentList, setAgentList] = useState([]);
  const [leadList, setLeadList] = useState([]);
  const [customerList, setCustomerList] = useState([]);
  const [leadsMap, setLeadsMap] = useState({});
  const [groupNameFilter, setGroupNameFilter] = useState("");
  const [groupList, setGroupList] = useState([]);
  const [selectedGroupName, setSelectedGroupName] = useState("");
  const [allLeads, setAllLeads] = useState([]);
  const [allEnrolls, setAllEnrolls] = useState([]);
  const [selectedLabel, setSelectedLabel] = useState("All");
  useEffect(() => {
    const typeMap = {
      customer: "Staff",
      agent: "Agent",
      employee: "Employee",
      lead: "Leads"
    };
    setUserType(typeMap[selectedReferrerType] || "Users");
  }, [selectedReferrerType]);
  useEffect(() => {
    const fetchLeads = async () => {
      try {
        const res = await api.get("/lead/get-lead");
        const data = Array.isArray(res.data) ? res.data : res.data?.leads || [];
        const map = {};
        for (const lead of data) {
          let lead_type_name = "";
          if (lead.lead_type === "customer") {
            lead_type_name = lead?.lead_customer?.full_name;
          } else if (lead.lead_type === "agent") {
            lead_type_name = lead?.lead_agent?.name;
          }
          map[lead._id] = lead_type_name?.toLowerCase();
        }
        setLeadsMap(map);
      } catch (err) {
        console.error("Failed to fetch leads", err);
      }
    };
    fetchLeads();
  }, []);
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "All") {
      const start = new Date(2e3, 0, 1);
      const end = today;
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "Custom") {
    }
  };
  useEffect(() => {
    handleSelectFilter("All");
  }, []);
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [leadRes, enrollRes] = await Promise.all(
          [
            api.get("/lead/get-lead"),
            api.get("/enroll-report/get-enroll-report")
          ]
        );
        setAllLeads(
          Array.isArray(leadRes.data) ? leadRes.data : leadRes.data?.leads || []
        );
        setAllEnrolls(enrollRes.data || []);
      } catch (err) {
        console.error("Error fetching data:", err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);
  useEffect(() => {
    const fetchReferrers = async () => {
      try {
        if (selectedReferrerType === "agent") {
          const res = await api.get("/agent/get");
          const allAgents = Array.isArray(res.data) ? res.data : res.data.agent || [];
          const filtered = allAgents.filter((a) => a.agent_type === "agent");
          setAgentList(filtered);
        } else if (selectedReferrerType === "employee") {
          const res = await api.get("/employee");
          const employees = Array.isArray(res.data.employee) ? res.data.employee : [];
          setAgentList(employees);
        } else if (selectedReferrerType === "lead") {
          const res = await api.get("/lead/get-lead");
          setLeadList(
            Array.isArray(res.data) ? res.data : res.data.leads || []
          );
        } else if (selectedReferrerType === "customer") {
          try {
            const agentRes = await api.get("/agent/get");
            const allAgents = Array.isArray(agentRes.data) ? agentRes.data : agentRes.data.agent || [];
            const filteredAgents = allAgents.filter(
              (a) => a.agent_type === "agent"
            );
            const empRes = await api.get("/employee");
            const employees = Array.isArray(empRes.data.employee) ? empRes.data.employee : [];
            setAgentList([...filteredAgents, ...employees]);
          } catch (error) {
            console.error("Error fetching agents and employees:", error);
          }
        }
      } catch (err) {
        console.error("Error fetching referrer list:", err);
      }
    };
    fetchReferrers();
  }, [selectedReferrerType]);
  const filteredUsers = useMemo(() => {
    const filtered = TableUsers.filter((u) => {
      const enrollmentDate = u.createdAt ? new Date(u.createdAt) : null;
      const matchFrom = selectedFromDate ? enrollmentDate >= new Date(selectedFromDate) : true;
      const matchTo = selectedToDate ? enrollmentDate <= /* @__PURE__ */ new Date(selectedToDate + "T23:59:59") : true;
      return matchFrom && matchTo;
    });
    return filtered.map((user, index) => {
      const isSelected = !!selectUser[user._id];
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => handleCheckboxChange(e.target.checked, user)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
            lineNumber: 231,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [TableUsers, selectedFromDate, selectedToDate, selectUser]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const res = await api.get("/group/get-group-admin");
        const groups = Array.isArray(res.data) ? res.data : res.data?.groups || [];
        setGroupList(groups);
      } catch (err) {
        console.error("Failed to fetch groups:", err);
      }
    };
    fetchGroups();
  }, []);
  const sendWhatsapp = async () => {
    const payload = {
      receivers: {}
    };
    whatsappData.forEach((user, index) => {
      payload.receivers[`user${index}`] = user;
    });
    if (Object.keys(payload.receivers).length === 0) {
      setAlertConfig({
        type: "warning",
        message: "Please select at least one user to send WhatsApp message.",
        visibility: true
      });
      return;
    }
    try {
      const res = await api.post("/whatsapp/whatsapp-promo-message", payload);
      console.info(res, "test");
      setAlertConfig({
        type: "success",
        message: `Messages sent! Success: ${res.data.successCount}, Failed: ${res.data.errorCount}`,
        visibility: true
      });
      const updatedSelection = { ...selectUser };
      whatsappData.forEach((entry) => {
        updatedSelection[entry.info.userId] = false;
      });
      setSelectUser(updatedSelection);
      setWhatsappData([]);
    } catch (err) {
      console.error("WhatsApp Error:", err);
      setAlertConfig({
        type: "error",
        message: "Failed to send WhatsApp messages.",
        visibility: true
      });
    }
  };
  const filteredData = useMemo(
    () => {
      const from = selectedFromDate ? moment(selectedFromDate, "YYYY-MM-DD").startOf("day") : null;
      const to = selectedToDate ? moment(selectedToDate, "YYYY-MM-DD").endOf("day") : null;
      const filterFn = (item) => {
        const created = item?.createdAt ? moment(item.createdAt) : null;
        const isWithinDateRange = (!from || created && created.isSameOrAfter(from)) && (!to || created && created.isSameOrBefore(to));
        const normalizedName = selectedReferrerName.trim().toLowerCase();
        if (selectedReferrerType === "lead") {
          if (!item?.lead_customer?.full_name && !item?.group_id?.group_name && !item?.lead_customer?.phone_number) {
            return false;
          }
          const leadTypeName = item.lead_type === "customer" ? item?.lead_customer?.full_name : item.lead_type === "agent" ? item?.lead_agent?.name : "";
          const nameMatches = !normalizedName || (leadTypeName || "").toLowerCase().includes(normalizedName);
          const matchesGroup2 = !selectedGroupName || (item?.group_id?.group_name || "").toLowerCase() === selectedGroupName.toLowerCase();
          return isWithinDateRange && nameMatches && matchesGroup2;
        }
        const agentName = item?.agent?.name?.toLowerCase();
        const agentType = item?.agent?.agent_type;
        const matchesAgent = selectedReferrerType === "agent" && agentType === "agent" && agentName?.includes(normalizedName);
        const matchesEmployee = selectedReferrerType === "employee" && agentType === "employee" && agentName?.includes(normalizedName);
        const matchesCustomer = selectedReferrerType === "customer" && item?.agent?.name?.toLowerCase().includes(normalizedName);
        const typeMatch = selectedReferrerType === "" || matchesAgent || matchesEmployee || matchesCustomer;
        const matchesGroup = !selectedGroupName || (item?.group_id?.group_name || "").toLowerCase() === selectedGroupName.toLowerCase();
        return typeMatch && isWithinDateRange && matchesGroup;
      };
      return selectedReferrerType === "lead" ? allLeads.filter(filterFn) : allEnrolls.filter(filterFn);
    },
    [
      allLeads,
      allEnrolls,
      selectedReferrerName,
      selectedReferrerType,
      selectedFromDate,
      //  FIXED
      selectedToDate,
      //  FIXED
      selectedGroupName
    ]
  );
  useEffect(() => {
    const formatted = filteredData.filter((item) => {
      const fullName = selectedReferrerType === "lead" ? item?.lead_name : item?.user_id?.full_name;
      const phoneNumber = selectedReferrerType === "lead" ? item?.lead_phone : item?.user_id?.phone_number;
      const groupName = item?.group_id?.group_name;
      return fullName && phoneNumber && groupName;
    }).map((item, index) => ({
      _id: item._id,
      id: index + 1,
      full_name: selectedReferrerType === "lead" ? item?.lead_name || "NA" : item?.user_id?.full_name || "NA",
      phone_number: selectedReferrerType === "lead" ? item?.lead_phone || "NA" : item?.user_id?.phone_number || "NA",
      group_name: item?.group_id?.group_name || "NA",
      group_id: item?.group_id?._id || "NA",
      createdAt: item?.createdAt ? new Date(item.createdAt) : null,
      enrollment_date: item?.createdAt ? new Date(item.createdAt).toISOString().split("T")[0] : "NA"
    }));
    const newSelection = {};
    formatted.forEach((u) => newSelection[u._id] = false);
    setSelectUser(newSelection);
    setTableUsers(formatted);
  }, [filteredData]);
  useEffect(() => {
    const selectedIds = Object.values(selectUser).filter((v) => v).length;
    const total = TableUsers.length;
    setCustomerCount(selectedIds);
    setSelectAll((prev) => ({
      ...prev,
      checked: selectedIds === total && total > 0,
      msg: selectedIds === total && total > 0 ? "No" : "All"
    }));
  }, [selectUser, TableUsers]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!formData.template_name.trim()) {
      newErrors.template_name = "Template name is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleCheckboxChange = (checked, user) => {
    setSelectUser((prev) => ({
      ...prev,
      [user._id]: checked
    }));
    const userData = {
      info: {
        userId: user._id,
        userName: user.full_name || user.lead_name,
        userPhone: user.phone_number || user.lead_phone,
        groupName: user.group_name,
        groupId: user.group_id?._id || user.group_id || "NA"
      }
    };
    setWhatsappData((prev) => {
      if (checked) {
        return [...prev, userData];
      } else {
        return prev.filter((entry) => entry.info.userId !== user._id);
      }
    });
  };
  const handleSelectAll = (checked) => {
    const newSelection = {};
    const newWhatsappData = [];
    TableUsers.forEach((user) => {
      newSelection[user._id] = checked;
      if (checked) {
        newWhatsappData.push({
          info: {
            userId: user._id,
            userName: user.full_name || user.lead_name,
            userPhone: user.phone_number || user.lead_phone,
            groupName: user.group_name,
            groupId: user.group_id?._id || user.group_id || "NA"
          }
        });
        console.info(newWhatsappData, "whatsapp test");
      }
    });
    setSelectUser(newSelection);
    setWhatsappData(newWhatsappData);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        setDisabled(true);
        const response = await whatsappApi.post("/marketing", {
          selectUser,
          template_name: formData?.template_name
        });
        if (response.status >= 400) {
          setShowModal(false);
          setDisabled(false);
          setErrors({});
          setFormData({
            template_name: ""
          });
          setAlertConfig({
            type: "error",
            message: "Whatsapp Failure",
            visibility: true
          });
        }
        if (response.status === 201) {
          setShowModal(false);
          setErrors({});
          setFormData({
            template_name: ""
          });
          setReloadTrigger((prev) => prev + 1);
          setAlertConfig({
            type: "success",
            message: "Whatsapped Successfully",
            visibility: true
          });
        }
        setShowModal(false);
        setErrors({});
        setFormData({
          template_name: ""
        });
      }
    } catch (err) {
      setAlertConfig({
        type: "error",
        message: "Whatsapp Failure",
        visibility: true
      });
      setDisabled(false);
      console.error("whatsapp error", err.message);
    }
  };
  useEffect(() => {
    const countCustomer = () => {
      let counter = 0;
      Object.values(selectUser).forEach((ele) => {
        if (ele) {
          counter++;
        }
      });
      setCustomerCount(counter);
    };
    countCustomer();
  }, [selectUser, reloadTrigger]);
  const columns = [
    { key: "checkBoxs", header: "Select" },
    { key: "sl_no", header: "SL. NO" },
    { key: "enrollment_date", header: "Enrolled On" },
    { key: "full_name", header: "Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
          lineNumber: 598,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
        lineNumber: 602,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
          lineNumber: 603,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
          lineNumber: 613,
          columnNumber: 16
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Whatsapp Promotion Message" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
          lineNumber: 614,
          columnNumber: 12
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { color: "green", size: "30", className: "m-2 mb-10" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 622,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold flex items-center mb-10", children: [
                  "Whatsapp ",
                  userType
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 623,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                lineNumber: 621,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center space-x-4 mt-4 mb-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "Select Any" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                    lineNumber: 630,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      className: "border rounded px-10 py-2 text-sm",
                      value: selectedReferrerType,
                      onChange: (e) => setSelectedReferrerType(e.target.value),
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "All" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 638,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "agent", children: "Agent" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 639,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "lead", children: "Lead" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 640,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "customer", children: "Customer" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 641,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "employee", children: "Employee" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 642,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 631,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 629,
                  columnNumber: 21
                }, this),
                selectedReferrerType && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: [
                    "Select ",
                    userType,
                    " Name"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                    lineNumber: 649,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      className: "border p-2 px-8 rounded text-sm min-w-[200px]",
                      value: selectedReferrerName,
                      onChange: (e) => setSelectedReferrerName(e.target.value),
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "All" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 659,
                          columnNumber: 27
                        }, this),
                        selectedReferrerType === "agent" && agentList.map(
                          (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent.name, children: [
                            agent.name,
                            " (",
                            agent.phone_number,
                            ")"
                          ] }, agent._id, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                            lineNumber: 662,
                            columnNumber: 27
                          }, this)
                        ),
                        selectedReferrerType === "employee" && agentList.map(
                          (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent.name, children: [
                            agent.name,
                            " (",
                            agent.phone_number,
                            ")"
                          ] }, agent._id, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                            lineNumber: 668,
                            columnNumber: 27
                          }, this)
                        ),
                        selectedReferrerType === "lead" && leadList.map((lead) => {
                          const lead_type_name = lead?.lead_type === "customer" ? lead?.lead_customer?.full_name : lead?.lead_type === "agent" ? lead?.lead_agent?.name : "";
                          return /* @__PURE__ */ jsxDEV("option", { value: lead_type_name, children: [
                            lead_type_name,
                            " (",
                            lead?.lead_phone || "NA",
                            ")"
                          ] }, lead._id, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                            lineNumber: 682,
                            columnNumber: 31
                          }, this);
                        }),
                        selectedReferrerType === "customer" && agentList.map(
                          (person) => /* @__PURE__ */ jsxDEV("option", { value: person.name, children: [
                            person.name,
                            " (",
                            person.phone_number,
                            ")"
                          ] }, person._id, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                            lineNumber: 695,
                            columnNumber: 27
                          }, this)
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 652,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 648,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "Select Date Filter" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                    lineNumber: 704,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      className: "border p-2 rounded text-sm",
                      value: selectedLabel,
                      onChange: (e) => handleSelectFilter(e.target.value),
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "Today", children: "Today" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 710,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 711,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "ThisMonth", children: "This Month" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 712,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "LastMonth", children: "Last Month" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 713,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "ThisYear", children: "This Year" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 714,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "All", children: "All" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 715,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "Custom", children: "Custom" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 716,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 705,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 703,
                  columnNumber: 21
                }, this),
                selectedLabel === "Custom" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "From Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 723,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        className: "border p-2 rounded text-sm",
                        value: selectedFromDate,
                        onChange: (e) => setSelectedFromDate(e.target.value)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                        lineNumber: 724,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                    lineNumber: 722,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "To Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 735,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        className: "border p-2 rounded text-sm",
                        value: selectedToDate,
                        onChange: (e) => setSelectedToDate(e.target.value)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                        lineNumber: 736,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                    lineNumber: 734,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 721,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-2 mb-5", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "font-medium", children: "Select Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                    lineNumber: 748,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      className: "border p-2 rounded text-sm min-w-[200px]",
                      value: selectedGroupName,
                      onChange: (e) => setSelectedGroupName(e.target.value),
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "All" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                          lineNumber: 754,
                          columnNumber: 25
                        }, this),
                        groupList.map(
                          (group) => /* @__PURE__ */ jsxDEV("option", { value: group.group_name, children: group.group_name }, group._id, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                            lineNumber: 756,
                            columnNumber: 27
                          }, this)
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 749,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 747,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2 mt-2", children: /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 font-medium", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "checkbox",
                      checked: TableUsers.length > 0 && TableUsers.every((u) => selectUser[u._id]),
                      onChange: (e) => handleSelectAll(e.target.checked)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 766,
                      columnNumber: 25
                    },
                    this
                  ),
                  "Select All"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 765,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                  lineNumber: 764,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                lineNumber: 627,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
              lineNumber: 620,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: sendWhatsapp,
                className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
                children: [
                  visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                      title: `Message will be sent to total ${visibleSelectedCount} customers`,
                      children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                        lineNumber: 789,
                        columnNumber: 23
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                      lineNumber: 785,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                    lineNumber: 792,
                    columnNumber: 19
                  }, this),
                  "WhatsApp"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
                lineNumber: 780,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
            lineNumber: 619,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
            lineNumber: 618,
            columnNumber: 13
          }, this),
          filteredUsers.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              isExportEnabled: true,
              data: filteredUsers,
              columns,
              exportedPdfName: "Whatsapp Promo",
              printHeaderKeys: [
                "Referrer Name",
                "Date Filter",
                "To Date",
                "Group Name",
                "From Date"
              ],
              printHeaderValues: [
                selectedReferrerName || "All",
                selectedLabel || "All",
                selectedToDate || "NA",
                selectedGroupName || "All",
                selectedFromDate || "NA"
              ],
              exportedFileName: `whatsapp Promo.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
              lineNumber: 798,
              columnNumber: 15
            },
            this
          ) : /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              failure: filteredUsers.length <= 0 && !isLoading,
              data: "Group Data"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
              lineNumber: 820,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
          lineNumber: 617,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
        lineNumber: 612,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
      lineNumber: 597,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Send Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
        lineNumber: 831,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "template",
              children: "Template Name"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
              lineNumber: 836,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              name: "template_name",
              value: formData.template_name,
              onChange: handleChange,
              id: "templateName",
              placeholder: "Paste template name",
              required: true,
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 w-full p-2.5"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
              lineNumber: 842,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
          lineNumber: 835,
          columnNumber: 15
        }, this),
        errors.template_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.template_name }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
          lineNumber: 854,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            disabled,
            className: "w-full text-white bg-green-700 hover:bg-green-800\r\n             focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Send"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
            lineNumber: 858,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
        lineNumber: 834,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
      lineNumber: 830,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
      lineNumber: 829,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
    lineNumber: 596,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx",
    lineNumber: 595,
    columnNumber: 5
  }, this);
};
_s(WhatsappPromo, "5pqm5yOc4uvVRF14HH+afLOshGk=");
_c = WhatsappPromo;
export default WhatsappPromo;
var _c;
$RefreshReg$(_c, "WhatsappPromo");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappPromo.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc09VLFNBMGVZLFVBMWVaOzJCQXRPVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLFVBQVVDLGVBQWU7QUFDN0MsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGdCQUFnQjtBQUV2QixNQUFNQyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWhCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNpQixXQUFXQyxZQUFZLElBQUlsQixTQUFTLEtBQUs7QUFDaEQsUUFBTW1CLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsUUFBTUMsY0FBY0YsSUFBSUcsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ2xELFFBQU0sQ0FBQ0Msa0JBQWtCQyxtQkFBbUIsSUFBSXpCLFNBQVNxQixXQUFXO0FBQ3BFLFFBQU0sQ0FBQ0ssZ0JBQWdCQyxpQkFBaUIsSUFBSTNCLFNBQVNxQixXQUFXO0FBQ2hFLFFBQU0sQ0FBQ08sY0FBY0MsZUFBZSxJQUFJN0IsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQzhCLFVBQVVDLFdBQVcsSUFBSS9CLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNnQyxhQUFhQyxjQUFjLElBQUlqQyxTQUFTO0FBQUEsSUFDN0NrQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXRDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN1QyxZQUFZQyxhQUFhLElBQUl4QyxTQUFTLENBQUMsQ0FBQztBQUMvQyxRQUFNLENBQUN5QyxlQUFlQyxnQkFBZ0IsSUFBSTFDLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUMyQyxXQUFXQyxZQUFZLElBQUk1QyxTQUFTLEVBQUU2QyxLQUFLLE9BQU9DLFNBQVMsTUFBTSxDQUFDO0FBQ3pFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJaEQsU0FBUztBQUFBLElBQ3ZDaUQsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJbkQsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQ29ELFFBQVFDLFNBQVMsSUFBSXJELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3NELFVBQVVDLFdBQVcsSUFBSXZELFNBQVMsVUFBVTtBQUNuRCxRQUFNLENBQUN3RCxVQUFVQyxXQUFXLElBQUl6RCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDMEQsUUFBUUMsU0FBUyxJQUFJM0QsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzRELHNCQUFzQkMsdUJBQXVCLElBQUk3RCxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDOEQsc0JBQXNCQyx1QkFBdUIsSUFBSS9ELFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNnRSxXQUFXQyxZQUFZLElBQUlqRSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDa0UsVUFBVUMsV0FBVyxJQUFJbkUsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ29FLGNBQWNDLGVBQWUsSUFBSXJFLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNzRSxVQUFVQyxXQUFXLElBQUl2RSxTQUFTLENBQUMsQ0FBQztBQUMzQyxRQUFNLENBQUN3RSxpQkFBaUJDLGtCQUFrQixJQUFJekUsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzBFLFdBQVdDLFlBQVksSUFBSTNFLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM0RSxtQkFBbUJDLG9CQUFvQixJQUFJN0UsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQzhFLFVBQVVDLFdBQVcsSUFBSS9FLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNnRixZQUFZQyxhQUFhLElBQUlqRixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDa0YsZUFBZUMsZ0JBQWdCLElBQUluRixTQUFTLEtBQUs7QUFHeERELFlBQVUsTUFBTTtBQUNkLFVBQU1xRixVQUFVO0FBQUEsTUFDZEMsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLElBQ1I7QUFDQWpDLGdCQUFZNkIsUUFBUXRCLG9CQUFvQixLQUFLLE9BQU87QUFBQSxFQUN0RCxHQUFHLENBQUNBLG9CQUFvQixDQUFDO0FBQ3pCL0QsWUFBVSxNQUFNO0FBQ2QsVUFBTTBGLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNckYsSUFBSXNGLElBQUksZ0JBQWdCO0FBQzFDLGNBQU1DLE9BQU9DLE1BQU1DLFFBQVFKLElBQUlFLElBQUksSUFBSUYsSUFBSUUsT0FBT0YsSUFBSUUsTUFBTUcsU0FBUztBQUNyRSxjQUFNQyxNQUFNLENBQUM7QUFDYixtQkFBV1IsUUFBUUksTUFBTTtBQUN2QixjQUFJSyxpQkFBaUI7QUFDckIsY0FBSVQsS0FBS1UsY0FBYyxZQUFZO0FBQ2pDRCw2QkFBaUJULE1BQU1XLGVBQWVDO0FBQUFBLFVBQ3hDLFdBQVdaLEtBQUtVLGNBQWMsU0FBUztBQUNyQ0QsNkJBQWlCVCxNQUFNYSxZQUFZQztBQUFBQSxVQUNyQztBQUNBTixjQUFJUixLQUFLZSxHQUFHLElBQUlOLGdCQUFnQk8sWUFBWTtBQUFBLFFBQzlDO0FBQ0FqQyxvQkFBWXlCLEdBQUc7QUFBQSxNQUNqQixTQUFTUyxLQUFLO0FBQ1pDLGdCQUFRQyxNQUFNLHlCQUF5QkYsR0FBRztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUVBaEIsZUFBVztBQUFBLEVBQ2IsR0FBRyxFQUFFO0FBRUwsUUFBTW1CLHFCQUFxQkEsQ0FBQ0MsVUFBVTtBQUNwQzFCLHFCQUFpQjBCLEtBQUs7QUFFdEIsVUFBTUMsUUFBUSxvQkFBSTFGLEtBQUs7QUFDdkIsVUFBTTJGLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRTVELFFBQUlKLFVBQVUsU0FBUztBQUNyQixZQUFNSyxZQUFZSCxXQUFXRCxLQUFLO0FBQ2xDckYsMEJBQW9CeUYsU0FBUztBQUM3QnZGLHdCQUFrQnVGLFNBQVM7QUFBQSxJQUM3QixXQUFXTCxVQUFVLGFBQWE7QUFDaEMsWUFBTU0sWUFBWSxJQUFJL0YsS0FBSzBGLEtBQUs7QUFDaENLLGdCQUFVQyxRQUFRRCxVQUFVRSxRQUFRLElBQUksQ0FBQztBQUN6QyxZQUFNSCxZQUFZSCxXQUFXSSxTQUFTO0FBQ3RDMUYsMEJBQW9CeUYsU0FBUztBQUM3QnZGLHdCQUFrQnVGLFNBQVM7QUFBQSxJQUM3QixXQUFXTCxVQUFVLGFBQWE7QUFDaEMsWUFBTVMsUUFBUSxJQUFJbEcsS0FBSzBGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTUMsTUFBTSxJQUFJckcsS0FBSzBGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRS9GLDBCQUFvQnNGLFdBQVdPLEtBQUssQ0FBQztBQUNyQzNGLHdCQUFrQm9GLFdBQVdVLEdBQUcsQ0FBQztBQUFBLElBQ25DLFdBQVdaLFVBQVUsYUFBYTtBQUNoQyxZQUFNUyxRQUFRLElBQUlsRyxLQUFLMEYsTUFBTVMsWUFBWSxHQUFHVCxNQUFNVSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ25FLFlBQU1DLE1BQU0sSUFBSXJHLEtBQUswRixNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsR0FBRyxDQUFDO0FBQzdEL0YsMEJBQW9Cc0YsV0FBV08sS0FBSyxDQUFDO0FBQ3JDM0Ysd0JBQWtCb0YsV0FBV1UsR0FBRyxDQUFDO0FBQUEsSUFDbkMsV0FBV1osVUFBVSxZQUFZO0FBQy9CLFlBQU1TLFFBQVEsSUFBSWxHLEtBQUswRixNQUFNUyxZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSXJHLEtBQUswRixNQUFNUyxZQUFZLEdBQUcsSUFBSSxFQUFFO0FBQ2hEOUYsMEJBQW9Cc0YsV0FBV08sS0FBSyxDQUFDO0FBQ3JDM0Ysd0JBQWtCb0YsV0FBV1UsR0FBRyxDQUFDO0FBQUEsSUFDbkMsV0FBV1osVUFBVSxPQUFPO0FBQzFCLFlBQU1TLFFBQVEsSUFBSWxHLEtBQUssS0FBTSxHQUFHLENBQUM7QUFDakMsWUFBTXFHLE1BQU1YO0FBQ1pyRiwwQkFBb0JzRixXQUFXTyxLQUFLLENBQUM7QUFDckMzRix3QkFBa0JvRixXQUFXVSxHQUFHLENBQUM7QUFBQSxJQUNuQyxXQUFXWixVQUFVLFVBQVU7QUFBQSxJQUU3QjtBQUFBLEVBRUo7QUFDQTlHLFlBQVUsTUFBTTtBQUNkNkcsdUJBQW1CLEtBQUs7QUFBQSxFQUMxQixHQUFHLEVBQUU7QUFFTDdHLFlBQVUsTUFBTTtBQUNkLFVBQU0ySCxZQUFZLFlBQVk7QUFDNUJwRixtQkFBYSxJQUFJO0FBQ2pCLFVBQUk7QUFDRixjQUFNLENBQUNxRixTQUFTQyxTQUFTLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQzdDekgsSUFBSXNGLElBQUksZ0JBQWdCO0FBQUEsWUFDeEJ0RixJQUFJc0YsSUFBSSxrQ0FBa0M7QUFBQSxVQUFDO0FBQUEsUUFDNUM7QUFFRFo7QUFBQUEsVUFDRWMsTUFBTUMsUUFBUTZCLFFBQVEvQixJQUFJLElBQUkrQixRQUFRL0IsT0FBTytCLFFBQVEvQixNQUFNRyxTQUFTO0FBQUEsUUFDdEU7QUFDQWQsc0JBQWMyQyxVQUFVaEMsUUFBUSxFQUFFO0FBQUEsTUFDcEMsU0FBU2EsS0FBSztBQUNaQyxnQkFBUUMsTUFBTSx3QkFBd0JGLEdBQUc7QUFBQSxNQUMzQyxVQUFDO0FBQ0NuRSxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBRUFvRixjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFDTDNILFlBQVUsTUFBTTtBQUNkLFVBQU1nSSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsWUFBSWpFLHlCQUF5QixTQUFTO0FBQ3BDLGdCQUFNNEIsTUFBTSxNQUFNckYsSUFBSXNGLElBQUksWUFBWTtBQUN0QyxnQkFBTXFDLFlBQVluQyxNQUFNQyxRQUFRSixJQUFJRSxJQUFJLElBQ3BDRixJQUFJRSxPQUNKRixJQUFJRSxLQUFLTixTQUFTO0FBQ3RCLGdCQUFNMkMsV0FBV0QsVUFBVUUsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxlQUFlLE9BQU87QUFDakVuRSx1QkFBYWdFLFFBQVE7QUFBQSxRQUN2QixXQUFXbkUseUJBQXlCLFlBQVk7QUFDOUMsZ0JBQU00QixNQUFNLE1BQU1yRixJQUFJc0YsSUFBSSxXQUFXO0FBQ3JDLGdCQUFNMEMsWUFBWXhDLE1BQU1DLFFBQVFKLElBQUlFLEtBQUtMLFFBQVEsSUFDN0NHLElBQUlFLEtBQUtMLFdBQ1Q7QUFDSnRCLHVCQUFhb0UsU0FBUztBQUFBLFFBQ3hCLFdBQVd2RSx5QkFBeUIsUUFBUTtBQUMxQyxnQkFBTTRCLE1BQU0sTUFBTXJGLElBQUlzRixJQUFJLGdCQUFnQjtBQUMxQ3hCO0FBQUFBLFlBQ0UwQixNQUFNQyxRQUFRSixJQUFJRSxJQUFJLElBQUlGLElBQUlFLE9BQU9GLElBQUlFLEtBQUtHLFNBQVM7QUFBQSxVQUN6RDtBQUFBLFFBQ0YsV0FBV2pDLHlCQUF5QixZQUFZO0FBSzlDLGNBQUk7QUFFRixrQkFBTXdFLFdBQVcsTUFBTWpJLElBQUlzRixJQUFJLFlBQVk7QUFDM0Msa0JBQU1xQyxZQUFZbkMsTUFBTUMsUUFBUXdDLFNBQVMxQyxJQUFJLElBQ3pDMEMsU0FBUzFDLE9BQ1QwQyxTQUFTMUMsS0FBS04sU0FBUztBQUMzQixrQkFBTWlELGlCQUFpQlAsVUFBVUU7QUFBQUEsY0FDL0IsQ0FBQ0MsTUFBTUEsRUFBRUMsZUFBZTtBQUFBLFlBQzFCO0FBR0Esa0JBQU1JLFNBQVMsTUFBTW5JLElBQUlzRixJQUFJLFdBQVc7QUFDeEMsa0JBQU0wQyxZQUFZeEMsTUFBTUMsUUFBUTBDLE9BQU81QyxLQUFLTCxRQUFRLElBQ2hEaUQsT0FBTzVDLEtBQUtMLFdBQ1o7QUFHSnRCLHlCQUFhLENBQUMsR0FBR3NFLGdCQUFnQixHQUFHRixTQUFTLENBQUM7QUFBQSxVQUNoRCxTQUFTMUIsT0FBTztBQUNkRCxvQkFBUUMsTUFBTSx3Q0FBd0NBLEtBQUs7QUFBQSxVQUM3RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVNGLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0saUNBQWlDRixHQUFHO0FBQUEsTUFDcEQ7QUFBQSxJQUNGO0FBRUFzQixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ2pFLG9CQUFvQixDQUFDO0FBRXpCLFFBQU0yRSxnQkFBZ0J4SSxRQUFRLE1BQU07QUFDbEMsVUFBTWdJLFdBQVdsSCxXQUFXbUgsT0FBTyxDQUFDUSxNQUFNO0FBRXhDLFlBQU1DLGlCQUFpQkQsRUFBRUUsWUFBWSxJQUFJeEgsS0FBS3NILEVBQUVFLFNBQVMsSUFBSTtBQUM3RCxZQUFNQyxZQUFZckgsbUJBQ2RtSCxrQkFBa0IsSUFBSXZILEtBQUtJLGdCQUFnQixJQUMzQztBQUNKLFlBQU1zSCxVQUFVcEgsaUJBQ1ppSCxrQkFBa0Isb0JBQUl2SCxLQUFLTSxpQkFBaUIsV0FBVyxJQUN2RDtBQUNKLGFBQU9tSCxhQUFhQztBQUFBQSxJQUN0QixDQUFDO0FBRUQsV0FBT2IsU0FBU2pDLElBQUksQ0FBQytDLE1BQU1DLFVBQVU7QUFDbkMsWUFBTUMsYUFBYSxDQUFDLENBQUMxRyxXQUFXd0csS0FBS3hDLEdBQUc7QUFFeEMsYUFBTztBQUFBLFFBQ0wsR0FBR3dDO0FBQUFBLFFBQ0hHLE9BQU9GLFFBQVE7QUFBQSxRQUNmRyxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTRjtBQUFBQSxZQUNULFVBQVUsQ0FBQ0csTUFBTUMscUJBQXFCRCxFQUFFRSxPQUFPeEcsU0FBU2lHLElBQUk7QUFBQTtBQUFBLFVBSDlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdnRTtBQUFBLFFBR2xFRTtBQUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNsSSxZQUFZUyxrQkFBa0JFLGdCQUFnQmEsVUFBVSxDQUFDO0FBRTdELFFBQU1nSCx1QkFBdUJ0SixRQUFRLE1BQU07QUFDekMsV0FBT3dJLGNBQWNQLE9BQU8sQ0FBQ2EsU0FBU0EsS0FBS0UsVUFBVSxFQUFFTztBQUFBQSxFQUN6RCxHQUFHLENBQUNmLGFBQWEsQ0FBQztBQUVsQjFJLFlBQVUsTUFBTTtBQUNkLFVBQU0wSixjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU0vRCxNQUFNLE1BQU1yRixJQUFJc0YsSUFBSSx3QkFBd0I7QUFDbEQsY0FBTStELFNBQVM3RCxNQUFNQyxRQUFRSixJQUFJRSxJQUFJLElBQ2pDRixJQUFJRSxPQUNKRixJQUFJRSxNQUFNOEQsVUFBVTtBQUN4Qi9FLHFCQUFhK0UsTUFBTTtBQUFBLE1BQ3JCLFNBQVNqRCxLQUFLO0FBQ1pDLGdCQUFRQyxNQUFNLDJCQUEyQkYsR0FBRztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUVBZ0QsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUNMLFFBQU1FLGVBQWUsWUFBWTtBQUUvQixVQUFNQyxVQUFVO0FBQUEsTUFDZEMsV0FBVyxDQUFDO0FBQUEsSUFDZDtBQUVBakksaUJBQWFrSSxRQUFRLENBQUNmLE1BQU1DLFVBQVU7QUFDcENZLGNBQVFDLFVBQVUsT0FBT2IsS0FBSyxFQUFFLElBQUlEO0FBQUFBLElBQ3RDLENBQUM7QUFHRCxRQUFJZ0IsT0FBT0MsS0FBS0osUUFBUUMsU0FBUyxFQUFFTCxXQUFXLEdBQUc7QUFDL0N2SCxxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTO0FBQUEsUUFDVEQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNd0QsTUFBTSxNQUFNckYsSUFBSTRKLEtBQUssb0NBQW9DTCxPQUFPO0FBQ3RFbEQsY0FBUXdELEtBQUt4RSxLQUFLLE1BQU07QUFFeEJ6RCxxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTLDJCQUEyQnVELElBQUlFLEtBQUt1RSxZQUFZLGFBQWF6RSxJQUFJRSxLQUFLd0UsVUFBVTtBQUFBLFFBQ3pGbEksWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUdELFlBQU1tSSxtQkFBbUIsRUFBRSxHQUFHOUgsV0FBVztBQUN6Q1gsbUJBQWFrSSxRQUFRLENBQUNRLFVBQVU7QUFDOUJELHlCQUFpQkMsTUFBTUosS0FBS0ssTUFBTSxJQUFJO0FBQUEsTUFDeEMsQ0FBQztBQUNEL0gsb0JBQWM2SCxnQkFBZ0I7QUFDOUJ4SSxzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFNBQVM0RSxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sbUJBQW1CRixHQUFHO0FBQ3BDeEUscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FBUztBQUFBLFFBQ1RELFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1zSSxlQUFldks7QUFBQUEsSUFBUSxNQUFNO0FBRWpDLFlBQU13SyxPQUFPakosbUJBQ1RkLE9BQU9jLGtCQUFrQixZQUFZLEVBQUVrSixRQUFRLEtBQUssSUFDcEQ7QUFFSixZQUFNQyxLQUFLakosaUJBQ1BoQixPQUFPZ0IsZ0JBQWdCLFlBQVksRUFBRWtKLE1BQU0sS0FBSyxJQUNoRDtBQUVKLFlBQU1DLFdBQVdBLENBQUNDLFNBQVM7QUFDekIsY0FBTUMsVUFBVUQsTUFBTWxDLFlBQVlsSSxPQUFPb0ssS0FBS2xDLFNBQVMsSUFBSTtBQUczRCxjQUFNb0MscUJBQ0gsQ0FBQ1AsUUFBU00sV0FBV0EsUUFBUUUsY0FBY1IsSUFBSSxPQUMvQyxDQUFDRSxNQUFPSSxXQUFXQSxRQUFRRyxlQUFlUCxFQUFFO0FBRS9DLGNBQU1RLGlCQUFpQnZILHFCQUFxQndILEtBQUssRUFBRTVFLFlBQVk7QUFFL0QsWUFBSTFDLHlCQUF5QixRQUFRO0FBQ25DLGNBQ0UsQ0FBQ2dILE1BQU0zRSxlQUFlQyxhQUN0QixDQUFDMEUsTUFBTU8sVUFBVUMsY0FDakIsQ0FBQ1IsTUFBTTNFLGVBQWVvRixjQUN0QjtBQUNBLG1CQUFPO0FBQUEsVUFDVDtBQUNBLGdCQUFNQyxlQUNKVixLQUFLNUUsY0FBYyxhQUNmNEUsTUFBTTNFLGVBQWVDLFlBQ3JCMEUsS0FBSzVFLGNBQWMsVUFDbkI0RSxNQUFNekUsWUFBWUMsT0FDbEI7QUFFTixnQkFBTW1GLGNBQ0osQ0FBQ04sbUJBQ0FLLGdCQUFnQixJQUFJaEYsWUFBWSxFQUFFa0YsU0FBU1AsY0FBYztBQUU1RCxnQkFBTVEsZ0JBQ0osQ0FBQy9HLHNCQUNBa0csTUFBTU8sVUFBVUMsY0FBYyxJQUFJOUUsWUFBWSxNQUM3QzVCLGtCQUFrQjRCLFlBQVk7QUFFbEMsaUJBQU93RSxxQkFBcUJTLGVBQWVFO0FBQUFBLFFBQzdDO0FBRUEsY0FBTUMsWUFBWWQsTUFBTXhGLE9BQU9nQixNQUFNRSxZQUFZO0FBQ2pELGNBQU1xRixZQUFZZixNQUFNeEYsT0FBTzhDO0FBRS9CLGNBQU0wRCxlQUNKaEkseUJBQXlCLFdBQ3pCK0gsY0FBYyxXQUNkRCxXQUFXRixTQUFTUCxjQUFjO0FBRXBDLGNBQU1ZLGtCQUNKakkseUJBQXlCLGNBQ3pCK0gsY0FBYyxjQUNkRCxXQUFXRixTQUFTUCxjQUFjO0FBRXBDLGNBQU1hLGtCQUNKbEkseUJBQXlCLGNBQ3pCZ0gsTUFBTXhGLE9BQU9nQixNQUFNRSxZQUFZLEVBQUVrRixTQUFTUCxjQUFjO0FBRTFELGNBQU1jLFlBQ0puSSx5QkFBeUIsTUFDekJnSSxnQkFDQUMsbUJBQ0FDO0FBRUYsY0FBTUwsZUFDSixDQUFDL0csc0JBQ0FrRyxNQUFNTyxVQUFVQyxjQUFjLElBQUk5RSxZQUFZLE1BQzdDNUIsa0JBQWtCNEIsWUFBWTtBQUVsQyxlQUFPeUYsYUFBYWpCLHFCQUFxQlc7QUFBQUEsTUFDM0M7QUFFQSxhQUFPN0gseUJBQXlCLFNBQzVCZ0IsU0FBU29ELE9BQU8yQyxRQUFRLElBQ3hCN0YsV0FBV2tELE9BQU8yQyxRQUFRO0FBQUEsSUFDaEM7QUFBQSxJQUFHO0FBQUEsTUFDRC9GO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FwQjtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBdEM7QUFBQUE7QUFBQUEsTUFDQUU7QUFBQUE7QUFBQUEsTUFDQWtEO0FBQUFBLElBQWlCO0FBQUEsRUFDbEI7QUFFRDdFLFlBQVUsTUFBTTtBQUNkLFVBQU1tSCxZQUFZc0QsYUFDZnRDLE9BQU8sQ0FBQzRDLFNBQVM7QUFDaEIsWUFBTW9CLFdBQ0pwSSx5QkFBeUIsU0FDckJnSCxNQUFNcUIsWUFDTnJCLE1BQU1zQixTQUFTaEc7QUFDckIsWUFBTWlHLGNBQ0p2SSx5QkFBeUIsU0FDckJnSCxNQUFNd0IsYUFDTnhCLE1BQU1zQixTQUFTYjtBQUNyQixZQUFNZ0IsWUFBWXpCLE1BQU1PLFVBQVVDO0FBRWxDLGFBQU9ZLFlBQVlHLGVBQWVFO0FBQUFBLElBQ3BDLENBQUMsRUFDQXZHLElBQUksQ0FBQzhFLE1BQU05QixXQUFXO0FBQUEsTUFDckJ6QyxLQUFLdUUsS0FBS3ZFO0FBQUFBLE1BQ1ZpRyxJQUFJeEQsUUFBUTtBQUFBLE1BQ1o1QyxXQUNFdEMseUJBQXlCLFNBQ3JCZ0gsTUFBTXFCLGFBQWEsT0FDbkJyQixNQUFNc0IsU0FBU2hHLGFBQWE7QUFBQSxNQUNsQ21GLGNBQ0V6SCx5QkFBeUIsU0FDckJnSCxNQUFNd0IsY0FBYyxPQUNwQnhCLE1BQU1zQixTQUFTYixnQkFBZ0I7QUFBQSxNQUNyQ0QsWUFBWVIsTUFBTU8sVUFBVUMsY0FBYztBQUFBLE1BQzFDRCxVQUFVUCxNQUFNTyxVQUFVOUUsT0FBTztBQUFBLE1BQ2pDcUMsV0FBV2tDLE1BQU1sQyxZQUFZLElBQUl4SCxLQUFLMEosS0FBS2xDLFNBQVMsSUFBSTtBQUFBLE1BQ3hENkQsaUJBQWlCM0IsTUFBTWxDLFlBQ25CLElBQUl4SCxLQUFLMEosS0FBS2xDLFNBQVMsRUFBRXRILFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNuRDtBQUFBLElBQ04sRUFBRTtBQUVKLFVBQU1tTCxlQUFlLENBQUM7QUFDdEJ4RixjQUFVNEMsUUFBUSxDQUFDcEIsTUFBT2dFLGFBQWFoRSxFQUFFbkMsR0FBRyxJQUFJLEtBQU07QUFDdEQvRCxrQkFBY2tLLFlBQVk7QUFDMUIxTCxrQkFBY2tHLFNBQVM7QUFBQSxFQUN6QixHQUFHLENBQUNzRCxZQUFZLENBQUM7QUFFakJ6SyxZQUFVLE1BQU07QUFDZCxVQUFNNE0sY0FBYzVDLE9BQU82QyxPQUFPckssVUFBVSxFQUFFMkYsT0FBTyxDQUFDMkUsTUFBTUEsQ0FBQyxFQUFFckQ7QUFDL0QsVUFBTXNELFFBQVEvTCxXQUFXeUk7QUFFekI5RyxxQkFBaUJpSyxXQUFXO0FBQzVCL0osaUJBQWEsQ0FBQ21LLFVBQVU7QUFBQSxNQUN0QixHQUFHQTtBQUFBQSxNQUNIakssU0FBUzZKLGdCQUFnQkcsU0FBU0EsUUFBUTtBQUFBLE1BQzFDakssS0FBSzhKLGdCQUFnQkcsU0FBU0EsUUFBUSxJQUFJLE9BQU87QUFBQSxJQUNuRCxFQUFFO0FBQUEsRUFDSixHQUFHLENBQUN2SyxZQUFZeEIsVUFBVSxDQUFDO0FBRTNCLFFBQU1pTSxlQUFlQSxDQUFDNUQsTUFBTTtBQUMxQixVQUFNLEVBQUU5QyxNQUFNTyxNQUFNLElBQUl1QyxFQUFFRTtBQUMxQnRHLGdCQUFZLENBQUNpSyxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDM0csSUFBSSxHQUFHTztBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTXFHLGVBQWVBLE1BQU07QUFDekIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQ3BLLFNBQVNFLGNBQWNtSSxLQUFLLEdBQUc7QUFDbEMrQixnQkFBVWxLLGdCQUFnQjtBQUFBLElBQzVCO0FBQ0FJLGNBQVU4SixTQUFTO0FBQ25CLFdBQU9wRCxPQUFPQyxLQUFLbUQsU0FBUyxFQUFFM0QsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTUgsdUJBQXVCQSxDQUFDdkcsU0FBU2lHLFNBQVM7QUFDOUN2RyxrQkFBYyxDQUFDdUssVUFBVTtBQUFBLE1BQ3ZCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2hFLEtBQUt4QyxHQUFHLEdBQUd6RDtBQUFBQSxJQUNkLEVBQUU7QUFFRixVQUFNc0ssV0FBVztBQUFBLE1BQ2ZsRCxNQUFNO0FBQUEsUUFDSkssUUFBUXhCLEtBQUt4QztBQUFBQSxRQUNiOEcsVUFBVXRFLEtBQUszQyxhQUFhMkMsS0FBS29EO0FBQUFBLFFBQ2pDbUIsV0FBV3ZFLEtBQUt3QyxnQkFBZ0J4QyxLQUFLdUQ7QUFBQUEsUUFDckNDLFdBQVd4RCxLQUFLdUM7QUFBQUEsUUFDaEJpQyxTQUFTeEUsS0FBS3NDLFVBQVU5RSxPQUFPd0MsS0FBS3NDLFlBQVk7QUFBQSxNQUNsRDtBQUFBLElBQ0Y7QUFFQXhKLG9CQUFnQixDQUFDa0wsU0FBUztBQUN4QixVQUFJakssU0FBUztBQUNYLGVBQU8sQ0FBQyxHQUFHaUssTUFBTUssUUFBUTtBQUFBLE1BQzNCLE9BQU87QUFDTCxlQUFPTCxLQUFLN0UsT0FBTyxDQUFDb0MsVUFBVUEsTUFBTUosS0FBS0ssV0FBV3hCLEtBQUt4QyxHQUFHO0FBQUEsTUFDOUQ7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTWlILGtCQUFrQkEsQ0FBQzFLLFlBQVk7QUFDbkMsVUFBTTRKLGVBQWUsQ0FBQztBQUN0QixVQUFNZSxrQkFBa0I7QUFFeEIxTSxlQUFXK0ksUUFBUSxDQUFDZixTQUFTO0FBQzNCMkQsbUJBQWEzRCxLQUFLeEMsR0FBRyxJQUFJekQ7QUFDekIsVUFBSUEsU0FBUztBQUNYMkssd0JBQWdCQyxLQUFLO0FBQUEsVUFDbkJ4RCxNQUFNO0FBQUEsWUFDSkssUUFBUXhCLEtBQUt4QztBQUFBQSxZQUNiOEcsVUFBVXRFLEtBQUszQyxhQUFhMkMsS0FBS29EO0FBQUFBLFlBQ2pDbUIsV0FBV3ZFLEtBQUt3QyxnQkFBZ0J4QyxLQUFLdUQ7QUFBQUEsWUFDckNDLFdBQVd4RCxLQUFLdUM7QUFBQUEsWUFDaEJpQyxTQUFTeEUsS0FBS3NDLFVBQVU5RSxPQUFPd0MsS0FBS3NDLFlBQVk7QUFBQSxVQUNsRDtBQUFBLFFBQ0YsQ0FBQztBQUNEM0UsZ0JBQVF3RCxLQUFLdUQsaUJBQWlCLGVBQWU7QUFBQSxNQUMvQztBQUFBLElBQ0YsQ0FBQztBQUVEakwsa0JBQWNrSyxZQUFZO0FBQzFCN0ssb0JBQWdCNEwsZUFBZTtBQUFBLEVBQ2pDO0FBRUEsUUFBTUUsZUFBZSxPQUFPdkUsTUFBTTtBQUNoQ0EsTUFBRXdFLGVBQWU7QUFDakIsVUFBTUMsVUFBVVgsYUFBYTtBQUM3QixRQUFJO0FBQ0YsVUFBSVcsU0FBUztBQUNYOUwsb0JBQVksSUFBSTtBQUNoQixjQUFNK0wsV0FBVyxNQUFNdE4sWUFBWXlKLEtBQUssY0FBYztBQUFBLFVBQ3BEMUg7QUFBQUEsVUFDQVUsZUFBZUYsVUFBVUU7QUFBQUEsUUFDM0IsQ0FBQztBQUNELFlBQUk2SyxTQUFTQyxVQUFVLEtBQUs7QUFDMUI3TSx1QkFBYSxLQUFLO0FBQ2xCYSxzQkFBWSxLQUFLO0FBQ2pCc0Isb0JBQVUsQ0FBQyxDQUFDO0FBQ1pMLHNCQUFZO0FBQUEsWUFDVkMsZUFBZTtBQUFBLFVBQ2pCLENBQUM7QUFFRGhCLHlCQUFlO0FBQUEsWUFDYkcsTUFBTTtBQUFBLFlBQ05ELFNBQVM7QUFBQSxZQUNURCxZQUFZO0FBQUEsVUFDZCxDQUFDO0FBQUEsUUFDSDtBQUNBLFlBQUk0TCxTQUFTQyxXQUFXLEtBQUs7QUFDM0I3TSx1QkFBYSxLQUFLO0FBQ2xCbUMsb0JBQVUsQ0FBQyxDQUFDO0FBQ1pMLHNCQUFZO0FBQUEsWUFDVkMsZUFBZTtBQUFBLFVBQ2pCLENBQUM7QUFDREUsMkJBQWlCLENBQUM0SixTQUFTQSxPQUFPLENBQUM7QUFDbkM5Syx5QkFBZTtBQUFBLFlBQ2JHLE1BQU07QUFBQSxZQUNORCxTQUFTO0FBQUEsWUFDVEQsWUFBWTtBQUFBLFVBQ2QsQ0FBQztBQUFBLFFBQ0g7QUFFQWhCLHFCQUFhLEtBQUs7QUFDbEJtQyxrQkFBVSxDQUFDLENBQUM7QUFDWkwsb0JBQVk7QUFBQSxVQUNWQyxlQUFlO0FBQUEsUUFDakIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVN3RCxLQUFLO0FBQ1p4RSxxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTO0FBQUEsUUFDVEQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUNESCxrQkFBWSxLQUFLO0FBQ2pCMkUsY0FBUUMsTUFBTSxrQkFBa0JGLElBQUl0RSxPQUFPO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUFwQyxZQUFVLE1BQU07QUFDZCxVQUFNaU8sZ0JBQWdCQSxNQUFNO0FBQzFCLFVBQUlDLFVBQVU7QUFDZGxFLGFBQU82QyxPQUFPckssVUFBVSxFQUFFdUgsUUFBUSxDQUFDb0UsUUFBUTtBQUN6QyxZQUFJQSxLQUFLO0FBQ1BEO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFDRHZMLHVCQUFpQnVMLE9BQU87QUFBQSxJQUMxQjtBQUNBRCxrQkFBYztBQUFBLEVBQ2hCLEdBQUcsQ0FBQ3pMLFlBQVlXLGFBQWEsQ0FBQztBQUU5QixRQUFNaUwsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxhQUFhQyxRQUFRLFNBQVM7QUFBQSxJQUNyQyxFQUFFRCxLQUFLLFNBQVNDLFFBQVEsU0FBUztBQUFBLElBQ2pDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGNBQWM7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsT0FBTztBQUFBLElBQ25DLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLEVBQUM7QUFHN0MsU0FDRSxtQ0FDTSxpQ0FBQyxTQUFJLFdBQVUsVUFDakI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDUyw2QkFBNkIsQ0FBQ2pGLE1BQU1rRixjQUFjbEYsRUFBRUUsT0FBT3pDLEtBQUs7QUFBQSxVQUNoRSxZQUFZO0FBQUE7QUFBQSxRQUZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFMkI7QUFBQSxNQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ2hCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNN0UsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUM4SyxVQUFVLEVBQUUsR0FBR0EsTUFBTTdLLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BR0gsdUJBQUMsU0FBSSxXQUFVLGlCQUNWO0FBQUEsK0JBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDZix1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLDBDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUM7QUFBQSxRQUNBLHVCQUFDLFNBQ0Q7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLGNBQVcsT0FBTSxTQUFRLE1BQUssTUFBSyxXQUFVLGVBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlEO0FBQUEsZ0JBQ3pELHVCQUFDLFFBQUcsV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUNuRG9CO0FBQUFBLHFCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsbURBRWI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZUFBYywwQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUM7QUFBQSxrQkFDekM7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLE9BQU9RO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ3NGLE1BQ1RyRix3QkFBd0JxRixFQUFFRSxPQUFPekMsS0FBSztBQUFBLHNCQUd4QztBQUFBLCtDQUFDLFlBQU8sT0FBTSxJQUFHLG1CQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFvQjtBQUFBLHdCQUNwQix1QkFBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMkI7QUFBQSx3QkFDM0IsdUJBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXlCO0FBQUEsd0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpQztBQUFBLHdCQUNqQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQTtBQUFBO0FBQUEsb0JBWG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFZQTtBQUFBLHFCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFHQy9DLHdCQUNDLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxlQUFjO0FBQUE7QUFBQSxvQkFDckJSO0FBQUFBLG9CQUFTO0FBQUEsdUJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsT0FBT007QUFBQUEsc0JBQ1AsVUFBVSxDQUFDd0YsTUFDVHZGLHdCQUF3QnVGLEVBQUVFLE9BQU96QyxLQUFLO0FBQUEsc0JBR3hDO0FBQUEsK0NBQUMsWUFBTyxPQUFNLElBQUcsbUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW9CO0FBQUEsd0JBQ25CL0MseUJBQXlCLFdBQ3hCRSxVQUFVZ0M7QUFBQUEsMEJBQUksQ0FBQ1YsVUFDYix1QkFBQyxZQUF1QixPQUFPQSxNQUFNZ0IsTUFDbENoQjtBQUFBQSxrQ0FBTWdCO0FBQUFBLDRCQUFLO0FBQUEsNEJBQUdoQixNQUFNaUc7QUFBQUEsNEJBQWE7QUFBQSwrQkFEdkJqRyxNQUFNaUIsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUEsd0JBQ0Z6Qyx5QkFBeUIsY0FDeEJFLFVBQVVnQztBQUFBQSwwQkFBSSxDQUFDVixVQUNiLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1nQixNQUNsQ2hCO0FBQUFBLGtDQUFNZ0I7QUFBQUEsNEJBQUs7QUFBQSw0QkFBR2hCLE1BQU1pRztBQUFBQSw0QkFBYTtBQUFBLCtCQUR2QmpHLE1BQU1pQixLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQSx3QkFDRnpDLHlCQUF5QixVQUN4QkksU0FBUzhCLElBQUksQ0FBQ1IsU0FBUztBQUNyQixnQ0FBTVMsaUJBQ0pULE1BQU1VLGNBQWMsYUFDaEJWLE1BQU1XLGVBQWVDLFlBQ3JCWixNQUFNVSxjQUFjLFVBQ3BCVixNQUFNYSxZQUFZQyxPQUNsQjtBQUVOLGlDQUNFLHVCQUFDLFlBQXNCLE9BQU9MLGdCQUMzQkE7QUFBQUE7QUFBQUEsNEJBQWU7QUFBQSw0QkFBR1QsTUFBTThHLGNBQWM7QUFBQSw0QkFBSztBQUFBLCtCQURqQzlHLEtBQUtlLEtBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFFSixDQUFDO0FBQUEsd0JBT0Z6Qyx5QkFBeUIsY0FDeEJFLFVBQVVnQztBQUFBQSwwQkFBSSxDQUFDdUksV0FDYix1QkFBQyxZQUF3QixPQUFPQSxPQUFPakksTUFDcENpSTtBQUFBQSxtQ0FBT2pJO0FBQUFBLDRCQUFLO0FBQUEsNEJBQUdpSSxPQUFPaEQ7QUFBQUEsNEJBQWE7QUFBQSwrQkFEekJnRCxPQUFPaEksS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUE7QUFBQTtBQUFBLG9CQTlDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBK0NBO0FBQUEscUJBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0RBO0FBQUEsZ0JBR0YsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGVBQWMsa0NBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlEO0FBQUEsa0JBQ2pEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixPQUFPckI7QUFBQUEsc0JBQ1AsVUFBVSxDQUFDa0UsTUFBTXhDLG1CQUFtQndDLEVBQUVFLE9BQU96QyxLQUFLO0FBQUEsc0JBRWxEO0FBQUEsK0NBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTJCO0FBQUEsd0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtQztBQUFBLHdCQUNuQyx1QkFBQyxZQUFPLE9BQU0sYUFBWSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBb0M7QUFBQSx3QkFDcEMsdUJBQUMsWUFBTyxPQUFNLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW9DO0FBQUEsd0JBQ3BDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrQztBQUFBLHdCQUNsQyx1QkFBQyxZQUFPLE9BQU0sT0FBTSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBdUI7QUFBQSx3QkFDdkIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUE7QUFBQTtBQUFBLG9CQVgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBWUE7QUFBQSxxQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWVBO0FBQUEsZ0JBRUMzQixrQkFBa0IsWUFDakIsbUNBQ0U7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZUFBYyx5QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0M7QUFBQSxvQkFDeEM7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixPQUFPMUQ7QUFBQUEsd0JBQ1AsVUFBVSxDQUFDNEgsTUFDVDNILG9CQUFvQjJILEVBQUVFLE9BQU96QyxLQUFLO0FBQUE7QUFBQSxzQkFMdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1HO0FBQUEsdUJBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFVQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxlQUFjLHVCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzQztBQUFBLG9CQUN0QztBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLE9BQU9uRjtBQUFBQSx3QkFDUCxVQUFVLENBQUMwSCxNQUFNekgsa0JBQWtCeUgsRUFBRUUsT0FBT3pDLEtBQUs7QUFBQTtBQUFBLHNCQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSXFEO0FBQUEsdUJBTnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxxQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzQkE7QUFBQSxnQkFJRix1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZUFBYyw0QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkM7QUFBQSxrQkFDM0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLE9BQU9qQztBQUFBQSxzQkFDUCxVQUFVLENBQUN3RSxNQUFNdkUscUJBQXFCdUUsRUFBRUUsT0FBT3pDLEtBQUs7QUFBQSxzQkFFcEQ7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sSUFBRyxtQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBb0I7QUFBQSx3QkFDbkJuQyxVQUFVc0I7QUFBQUEsMEJBQUksQ0FBQ3dJLFVBQ2QsdUJBQUMsWUFBdUIsT0FBT0EsTUFBTWxELFlBQ2xDa0QsZ0JBQU1sRCxjQURJa0QsTUFBTWpJLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFDRDtBQUFBO0FBQUE7QUFBQSxvQkFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0E7QUFBQSxxQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNiLGlDQUFDLFdBQU0sV0FBVSx1Q0FDZjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUNFeEYsV0FBV3lJLFNBQVMsS0FDcEJ6SSxXQUFXME4sTUFBTSxDQUFDL0YsTUFBTW5HLFdBQVdtRyxFQUFFbkMsR0FBRyxDQUFDO0FBQUEsc0JBRTNDLFVBQVUsQ0FBQzZDLE1BQU1vRSxnQkFBZ0JwRSxFQUFFRSxPQUFPeEcsT0FBTztBQUFBO0FBQUEsb0JBTm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNcUQ7QUFBQTtBQUFBLHFCQVB2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLG1CQXJKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNKQTtBQUFBLGlCQTdKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThKQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTNkc7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVUSjtBQUFBQSx5Q0FBdUIsS0FDdEI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLE9BQU8saUNBQWlDQSxvQkFBb0I7QUFBQSxzQkFFNUQsaUNBQUMsVUFBTUEsa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEI7QUFBQTtBQUFBLG9CQUo5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFFRix1QkFBQyxjQUFXLFdBQVUsUUFBTyxNQUFNLE1BQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDO0FBQUEsa0JBQUc7QUFBQTtBQUFBO0FBQUEsY0FaM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQS9LRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdMQSxLQWpMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtMQTtBQUFBLFVBQ0NkLGNBQWNlLFNBQVMsS0FBSyxDQUFDbkgsWUFDNUI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGlCQUFpQjtBQUFBLGNBQ2pCLE1BQU1vRztBQUFBQSxjQUNOO0FBQUEsY0FDQSxpQkFBZ0I7QUFBQSxjQUNoQixpQkFBaUI7QUFBQSxnQkFDZjtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsY0FBVztBQUFBLGNBRWIsbUJBQW1CO0FBQUEsZ0JBQ2pCN0Usd0JBQXdCO0FBQUEsZ0JBQ3hCc0IsaUJBQWlCO0FBQUEsZ0JBQ2pCeEQsa0JBQWtCO0FBQUEsZ0JBQ2xCa0QscUJBQXFCO0FBQUEsZ0JBQ3JCcEQsb0JBQW9CO0FBQUEsY0FBSTtBQUFBLGNBRTFCLGtCQUFrQjtBQUFBO0FBQUEsWUFuQnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CeUMsSUFHekM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxTQUFTaUgsY0FBY2UsVUFBVSxLQUFLLENBQUNuSDtBQUFBQSxjQUN2QyxNQUFNO0FBQUE7QUFBQSxZQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdxQjtBQUFBLGFBOU12QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaU5BO0FBQUEsV0F0TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVOQTtBQUFBLFNBdE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1T0E7QUFBQSxJQUNBLHVCQUFDLFNBQU0sV0FBV3BCLFdBQVcsU0FBUyxNQUFNQyxhQUFhLEtBQUssR0FDNUQsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdDQUF1Qyw0QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVeU0sY0FBYyxZQUFVLE1BQzVEO0FBQUEsK0JBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBVTtBQUFBO0FBQUEsWUFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPNUssU0FBU0U7QUFBQUEsY0FDaEIsVUFBVStKO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLFdBQVU7QUFBQTtBQUFBLFlBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUXlJO0FBQUEsYUFmM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0M1SixPQUFPSCxpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZHLGlCQUFPSCxpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTDtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQytGO0FBQUE7QUFBQSxVQUozRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxTQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUNBLEtBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1Q0E7QUFBQSxPQWhSRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaVJKLEtBbFJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtUkE7QUFFSjtBQUFFbkMsR0F6MUJJRCxlQUFhO0FBQUE2TixLQUFiN047QUEyMUJOLGVBQWVBO0FBQWMsSUFBQTZOO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJTaWRlYmFyIiwiTW9kYWwiLCJGYVdoYXRzYXBwIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJ3aGF0c2FwcEFwaSIsIkNpcmN1bGFyTG9hZGVyIiwibW9tZW50IiwiTmF2YmFyIiwiQnJlYWRjcnVtYiIsIldoYXRzYXBwUHJvbW8iLCJfcyIsIlRhYmxlVXNlcnMiLCJzZXRUYWJsZVVzZXJzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwibm93IiwiRGF0ZSIsInRvZGF5U3RyaW5nIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInNlbGVjdGVkRnJvbURhdGUiLCJzZXRTZWxlY3RlZEZyb21EYXRlIiwic2VsZWN0ZWRUb0RhdGUiLCJzZXRTZWxlY3RlZFRvRGF0ZSIsIndoYXRzYXBwRGF0YSIsInNldFdoYXRzYXBwRGF0YSIsImRpc2FibGVkIiwic2V0RGlzYWJsZWQiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VsZWN0VXNlciIsInNldFNlbGVjdFVzZXIiLCJjdXN0b21lckNvdW50Iiwic2V0Q3VzdG9tZXJDb3VudCIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsIm1zZyIsImNoZWNrZWQiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwidGVtcGxhdGVfbmFtZSIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwidXNlclR5cGUiLCJzZXRVc2VyVHlwZSIsImZyb21EYXRlIiwic2V0RnJvbURhdGUiLCJ0b0RhdGUiLCJzZXRUb0RhdGUiLCJzZWxlY3RlZFJlZmVycmVyTmFtZSIsInNldFNlbGVjdGVkUmVmZXJyZXJOYW1lIiwic2VsZWN0ZWRSZWZlcnJlclR5cGUiLCJzZXRTZWxlY3RlZFJlZmVycmVyVHlwZSIsImFnZW50TGlzdCIsInNldEFnZW50TGlzdCIsImxlYWRMaXN0Iiwic2V0TGVhZExpc3QiLCJjdXN0b21lckxpc3QiLCJzZXRDdXN0b21lckxpc3QiLCJsZWFkc01hcCIsInNldExlYWRzTWFwIiwiZ3JvdXBOYW1lRmlsdGVyIiwic2V0R3JvdXBOYW1lRmlsdGVyIiwiZ3JvdXBMaXN0Iiwic2V0R3JvdXBMaXN0Iiwic2VsZWN0ZWRHcm91cE5hbWUiLCJzZXRTZWxlY3RlZEdyb3VwTmFtZSIsImFsbExlYWRzIiwic2V0QWxsTGVhZHMiLCJhbGxFbnJvbGxzIiwic2V0QWxsRW5yb2xscyIsInNlbGVjdGVkTGFiZWwiLCJzZXRTZWxlY3RlZExhYmVsIiwidHlwZU1hcCIsImN1c3RvbWVyIiwiYWdlbnQiLCJlbXBsb3llZSIsImxlYWQiLCJmZXRjaExlYWRzIiwicmVzIiwiZ2V0IiwiZGF0YSIsIkFycmF5IiwiaXNBcnJheSIsImxlYWRzIiwibWFwIiwibGVhZF90eXBlX25hbWUiLCJsZWFkX3R5cGUiLCJsZWFkX2N1c3RvbWVyIiwiZnVsbF9uYW1lIiwibGVhZF9hZ2VudCIsIm5hbWUiLCJfaWQiLCJ0b0xvd2VyQ2FzZSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZVNlbGVjdEZpbHRlciIsInZhbHVlIiwidG9kYXkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImZvcm1hdHRlZCIsInllc3RlcmRheSIsInNldERhdGUiLCJnZXREYXRlIiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwiZmV0Y2hEYXRhIiwibGVhZFJlcyIsImVucm9sbFJlcyIsIlByb21pc2UiLCJhbGwiLCJmZXRjaFJlZmVycmVycyIsImFsbEFnZW50cyIsImZpbHRlcmVkIiwiZmlsdGVyIiwiYSIsImFnZW50X3R5cGUiLCJlbXBsb3llZXMiLCJhZ2VudFJlcyIsImZpbHRlcmVkQWdlbnRzIiwiZW1wUmVzIiwiZmlsdGVyZWRVc2VycyIsInUiLCJlbnJvbGxtZW50RGF0ZSIsImNyZWF0ZWRBdCIsIm1hdGNoRnJvbSIsIm1hdGNoVG8iLCJ1c2VyIiwiaW5kZXgiLCJpc1NlbGVjdGVkIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwiaGFuZGxlQ2hlY2tib3hDaGFuZ2UiLCJ0YXJnZXQiLCJ2aXNpYmxlU2VsZWN0ZWRDb3VudCIsImxlbmd0aCIsImZldGNoR3JvdXBzIiwiZ3JvdXBzIiwic2VuZFdoYXRzYXBwIiwicGF5bG9hZCIsInJlY2VpdmVycyIsImZvckVhY2giLCJPYmplY3QiLCJrZXlzIiwicG9zdCIsImluZm8iLCJzdWNjZXNzQ291bnQiLCJlcnJvckNvdW50IiwidXBkYXRlZFNlbGVjdGlvbiIsImVudHJ5IiwidXNlcklkIiwiZmlsdGVyZWREYXRhIiwiZnJvbSIsInN0YXJ0T2YiLCJ0byIsImVuZE9mIiwiZmlsdGVyRm4iLCJpdGVtIiwiY3JlYXRlZCIsImlzV2l0aGluRGF0ZVJhbmdlIiwiaXNTYW1lT3JBZnRlciIsImlzU2FtZU9yQmVmb3JlIiwibm9ybWFsaXplZE5hbWUiLCJ0cmltIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwicGhvbmVfbnVtYmVyIiwibGVhZFR5cGVOYW1lIiwibmFtZU1hdGNoZXMiLCJpbmNsdWRlcyIsIm1hdGNoZXNHcm91cCIsImFnZW50TmFtZSIsImFnZW50VHlwZSIsIm1hdGNoZXNBZ2VudCIsIm1hdGNoZXNFbXBsb3llZSIsIm1hdGNoZXNDdXN0b21lciIsInR5cGVNYXRjaCIsImZ1bGxOYW1lIiwibGVhZF9uYW1lIiwidXNlcl9pZCIsInBob25lTnVtYmVyIiwibGVhZF9waG9uZSIsImdyb3VwTmFtZSIsImlkIiwiZW5yb2xsbWVudF9kYXRlIiwibmV3U2VsZWN0aW9uIiwic2VsZWN0ZWRJZHMiLCJ2YWx1ZXMiLCJ2IiwidG90YWwiLCJwcmV2IiwiaGFuZGxlQ2hhbmdlIiwicHJldkRhdGEiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJ1c2VyRGF0YSIsInVzZXJOYW1lIiwidXNlclBob25lIiwiZ3JvdXBJZCIsImhhbmRsZVNlbGVjdEFsbCIsIm5ld1doYXRzYXBwRGF0YSIsInB1c2giLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWQiLCJyZXNwb25zZSIsInN0YXR1cyIsImNvdW50Q3VzdG9tZXIiLCJjb3VudGVyIiwiZWxlIiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsInNldFNlYXJjaFRleHQiLCJwZXJzb24iLCJncm91cCIsImV2ZXJ5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiV2hhdHNhcHBQcm9tby5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB3aGF0c2FwcEFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvV2hhdHNhcHBJbnN0YW5jZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgbW9tZW50IGZyb20gXCJtb21lbnRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCBXaGF0c2FwcFByb21vID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtUYWJsZVVzZXJzLCBzZXRUYWJsZVVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgdG9kYXlTdHJpbmcgPSBub3cudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFRvRGF0ZSwgc2V0U2VsZWN0ZWRUb0RhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFt3aGF0c2FwcERhdGEsIHNldFdoYXRzYXBwRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2Rpc2FibGVkLCBzZXREaXNhYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RVc2VyLCBzZXRTZWxlY3RVc2VyXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbY3VzdG9tZXJDb3VudCwgc2V0Q3VzdG9tZXJDb3VudF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoeyBtc2c6IFwiQWxsXCIsIGNoZWNrZWQ6IGZhbHNlIH0pO1xyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdGVtcGxhdGVfbmFtZTogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFt1c2VyVHlwZSwgc2V0VXNlclR5cGVdID0gdXNlU3RhdGUoXCJjdXN0b21lclwiKTsgLy8gU3RhdGUgZm9yIGR5bmFtaWMgaGVhZGVyIHRpdGxlXHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUmVmZXJyZXJOYW1lLCBzZXRTZWxlY3RlZFJlZmVycmVyTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRSZWZlcnJlclR5cGUsIHNldFNlbGVjdGVkUmVmZXJyZXJUeXBlXSA9IHVzZVN0YXRlKFwiXCIpOyAvLyBJbml0aWFsIGZpbHRlciB0eXBlXHJcbiAgY29uc3QgW2FnZW50TGlzdCwgc2V0QWdlbnRMaXN0XSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbGVhZExpc3QsIHNldExlYWRMaXN0XSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VzdG9tZXJMaXN0LCBzZXRDdXN0b21lckxpc3RdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsZWFkc01hcCwgc2V0TGVhZHNNYXBdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtncm91cE5hbWVGaWx0ZXIsIHNldEdyb3VwTmFtZUZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZ3JvdXBMaXN0LCBzZXRHcm91cExpc3RdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwTmFtZSwgc2V0U2VsZWN0ZWRHcm91cE5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FsbExlYWRzLCBzZXRBbGxMZWFkc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FsbEVucm9sbHMsIHNldEFsbEVucm9sbHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiQWxsXCIpO1xyXG5cclxuICAvLyBFZmZlY3QgdG8gdXBkYXRlIHRoZSBoZWFkZXIgdGl0bGUgYmFzZWQgb24gc2VsZWN0ZWRSZWZlcnJlclR5cGVcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdHlwZU1hcCA9IHtcclxuICAgICAgY3VzdG9tZXI6IFwiU3RhZmZcIixcclxuICAgICAgYWdlbnQ6IFwiQWdlbnRcIixcclxuICAgICAgZW1wbG95ZWU6IFwiRW1wbG95ZWVcIixcclxuICAgICAgbGVhZDogXCJMZWFkc1wiLFxyXG4gICAgfTtcclxuICAgIHNldFVzZXJUeXBlKHR5cGVNYXBbc2VsZWN0ZWRSZWZlcnJlclR5cGVdIHx8IFwiVXNlcnNcIik7IC8vIERlZmF1bHQgdG8gXCJVc2Vyc1wiXHJcbiAgfSwgW3NlbGVjdGVkUmVmZXJyZXJUeXBlXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTGVhZHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9sZWFkL2dldC1sZWFkXCIpO1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBBcnJheS5pc0FycmF5KHJlcy5kYXRhKSA/IHJlcy5kYXRhIDogcmVzLmRhdGE/LmxlYWRzIHx8IFtdO1xyXG4gICAgICAgIGNvbnN0IG1hcCA9IHt9O1xyXG4gICAgICAgIGZvciAoY29uc3QgbGVhZCBvZiBkYXRhKSB7XHJcbiAgICAgICAgICBsZXQgbGVhZF90eXBlX25hbWUgPSBcIlwiO1xyXG4gICAgICAgICAgaWYgKGxlYWQubGVhZF90eXBlID09PSBcImN1c3RvbWVyXCIpIHtcclxuICAgICAgICAgICAgbGVhZF90eXBlX25hbWUgPSBsZWFkPy5sZWFkX2N1c3RvbWVyPy5mdWxsX25hbWU7XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKGxlYWQubGVhZF90eXBlID09PSBcImFnZW50XCIpIHtcclxuICAgICAgICAgICAgbGVhZF90eXBlX25hbWUgPSBsZWFkPy5sZWFkX2FnZW50Py5uYW1lO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgbWFwW2xlYWQuX2lkXSA9IGxlYWRfdHlwZV9uYW1lPy50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZXRMZWFkc01hcChtYXApO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGxlYWRzXCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hMZWFkcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKTtcclxuXHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0dGVkKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4gICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh5ZXN0ZXJkYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJBbGxcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKDIwMDAsIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSB0b2RheTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIC8vICBEbyBOT1Qgb3ZlcnJpZGUgZGF0ZXMuIEFsbG93IHVzZXIgdG8gc2VsZWN0IG1hbnVhbGx5LlxyXG4gICAgICAvLyBKdXN0IGtlZXAgdGhlIGN1cnJlbnRseSBzZWxlY3RlZEZyb21EYXRlIC8gc2VsZWN0ZWRUb0RhdGVcclxuICAgIH1cclxuICB9O1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoXCJBbGxcIik7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgW2xlYWRSZXMsIGVucm9sbFJlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL2xlYWQvZ2V0LWxlYWRcIiksXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL2Vucm9sbC1yZXBvcnQvZ2V0LWVucm9sbC1yZXBvcnRcIiksXHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIHNldEFsbExlYWRzKFxyXG4gICAgICAgICAgQXJyYXkuaXNBcnJheShsZWFkUmVzLmRhdGEpID8gbGVhZFJlcy5kYXRhIDogbGVhZFJlcy5kYXRhPy5sZWFkcyB8fCBbXVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0QWxsRW5yb2xscyhlbnJvbGxSZXMuZGF0YSB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnIpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFJlZmVycmVycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwiYWdlbnRcIikge1xyXG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXRcIik7XHJcbiAgICAgICAgICBjb25zdCBhbGxBZ2VudHMgPSBBcnJheS5pc0FycmF5KHJlcy5kYXRhKVxyXG4gICAgICAgICAgICA/IHJlcy5kYXRhXHJcbiAgICAgICAgICAgIDogcmVzLmRhdGEuYWdlbnQgfHwgW107XHJcbiAgICAgICAgICBjb25zdCBmaWx0ZXJlZCA9IGFsbEFnZW50cy5maWx0ZXIoKGEpID0+IGEuYWdlbnRfdHlwZSA9PT0gXCJhZ2VudFwiKTtcclxuICAgICAgICAgIHNldEFnZW50TGlzdChmaWx0ZXJlZCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFJlZmVycmVyVHlwZSA9PT0gXCJlbXBsb3llZVwiKSB7XHJcbiAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgICAgY29uc3QgZW1wbG95ZWVzID0gQXJyYXkuaXNBcnJheShyZXMuZGF0YS5lbXBsb3llZSlcclxuICAgICAgICAgICAgPyByZXMuZGF0YS5lbXBsb3llZVxyXG4gICAgICAgICAgICA6IFtdO1xyXG4gICAgICAgICAgc2V0QWdlbnRMaXN0KGVtcGxveWVlcyk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFJlZmVycmVyVHlwZSA9PT0gXCJsZWFkXCIpIHtcclxuICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvbGVhZC9nZXQtbGVhZFwiKTtcclxuICAgICAgICAgIHNldExlYWRMaXN0KFxyXG4gICAgICAgICAgICBBcnJheS5pc0FycmF5KHJlcy5kYXRhKSA/IHJlcy5kYXRhIDogcmVzLmRhdGEubGVhZHMgfHwgW11cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFJlZmVycmVyVHlwZSA9PT0gXCJjdXN0b21lclwiKSB7XHJcbiAgICAgICAgICAvLyBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgICAvLyBzZXRDdXN0b21lckxpc3QoXHJcbiAgICAgICAgICAvLyAgIEFycmF5LmlzQXJyYXkocmVzLmRhdGEpID8gcmVzLmRhdGEgOiByZXMuZGF0YS51c2VycyB8fCBbXVxyXG4gICAgICAgICAgLy8gKTtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIC8vICBGZXRjaCBBZ2VudHNcclxuICAgICAgICAgICAgY29uc3QgYWdlbnRSZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgICAgICAgY29uc3QgYWxsQWdlbnRzID0gQXJyYXkuaXNBcnJheShhZ2VudFJlcy5kYXRhKVxyXG4gICAgICAgICAgICAgID8gYWdlbnRSZXMuZGF0YVxyXG4gICAgICAgICAgICAgIDogYWdlbnRSZXMuZGF0YS5hZ2VudCB8fCBbXTtcclxuICAgICAgICAgICAgY29uc3QgZmlsdGVyZWRBZ2VudHMgPSBhbGxBZ2VudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgIChhKSA9PiBhLmFnZW50X3R5cGUgPT09IFwiYWdlbnRcIlxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgLy8gIEZldGNoIEVtcGxveWVlc1xyXG4gICAgICAgICAgICBjb25zdCBlbXBSZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgICAgICBjb25zdCBlbXBsb3llZXMgPSBBcnJheS5pc0FycmF5KGVtcFJlcy5kYXRhLmVtcGxveWVlKVxyXG4gICAgICAgICAgICAgID8gZW1wUmVzLmRhdGEuZW1wbG95ZWVcclxuICAgICAgICAgICAgICA6IFtdO1xyXG5cclxuICAgICAgICAgICAgLy8gIENvbWJpbmUgQWdlbnRzICsgRW1wbG95ZWVzXHJcbiAgICAgICAgICAgIHNldEFnZW50TGlzdChbLi4uZmlsdGVyZWRBZ2VudHMsIC4uLmVtcGxveWVlc10pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFnZW50cyBhbmQgZW1wbG95ZWVzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcmVmZXJyZXIgbGlzdDpcIiwgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFJlZmVycmVycygpO1xyXG4gIH0sIFtzZWxlY3RlZFJlZmVycmVyVHlwZV0pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IFRhYmxlVXNlcnMuZmlsdGVyKCh1KSA9PiB7XHJcbiAgICAgIC8vY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmNyZWF0ZWRBdCB8fCB1LmVucm9sbG1lbnREYXRlKTtcclxuICAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSB1LmNyZWF0ZWRBdCA/IG5ldyBEYXRlKHUuY3JlYXRlZEF0KSA6IG51bGw7XHJcbiAgICAgIGNvbnN0IG1hdGNoRnJvbSA9IHNlbGVjdGVkRnJvbURhdGVcclxuICAgICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKHNlbGVjdGVkRnJvbURhdGUpXHJcbiAgICAgICAgOiB0cnVlO1xyXG4gICAgICBjb25zdCBtYXRjaFRvID0gc2VsZWN0ZWRUb0RhdGVcclxuICAgICAgICA/IGVucm9sbG1lbnREYXRlIDw9IG5ldyBEYXRlKHNlbGVjdGVkVG9EYXRlICsgXCJUMjM6NTk6NTlcIilcclxuICAgICAgICA6IHRydWU7XHJcbiAgICAgIHJldHVybiBtYXRjaEZyb20gJiYgbWF0Y2hUbztcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBmaWx0ZXJlZC5tYXAoKHVzZXIsIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSAhIXNlbGVjdFVzZXJbdXNlci5faWRdO1xyXG5cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi51c2VyLFxyXG4gICAgICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICAgICAgY2hlY2tCb3hzOiAoXHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgY2hlY2tlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGVja2JveENoYW5nZShlLnRhcmdldC5jaGVja2VkLCB1c2VyKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSxcclxuICAgICAgICBpc1NlbGVjdGVkLFxyXG4gICAgICB9O1xyXG4gICAgfSk7XHJcbiAgfSwgW1RhYmxlVXNlcnMsIHNlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkVG9EYXRlLCBzZWxlY3RVc2VyXSk7XHJcblxyXG4gIGNvbnN0IHZpc2libGVTZWxlY3RlZENvdW50ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHVzZXIpID0+IHVzZXIuaXNTZWxlY3RlZCkubGVuZ3RoO1xyXG4gIH0sIFtmaWx0ZXJlZFVzZXJzXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgICBjb25zdCBncm91cHMgPSBBcnJheS5pc0FycmF5KHJlcy5kYXRhKVxyXG4gICAgICAgICAgPyByZXMuZGF0YVxyXG4gICAgICAgICAgOiByZXMuZGF0YT8uZ3JvdXBzIHx8IFtdO1xyXG4gICAgICAgIHNldEdyb3VwTGlzdChncm91cHMpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGdyb3VwczpcIiwgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyAgQ29uc3RydWN0IHBheWxvYWQgd2l0aCAncmVjZWl2ZXJzJyBvYmplY3QgYXMgYmFja2VuZCBleHBlY3RzXHJcbiAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICByZWNlaXZlcnM6IHt9LFxyXG4gICAgfTtcclxuXHJcbiAgICB3aGF0c2FwcERhdGEuZm9yRWFjaCgodXNlciwgaW5kZXgpID0+IHtcclxuICAgICAgcGF5bG9hZC5yZWNlaXZlcnNbYHVzZXIke2luZGV4fWBdID0gdXNlcjtcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIENoZWNrIGlmIHRoZXJlIGlzIGF0IGxlYXN0IG9uZSBzZWxlY3RlZCB1c2VyXHJcbiAgICBpZiAoT2JqZWN0LmtleXMocGF5bG9hZC5yZWNlaXZlcnMpLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGF0IGxlYXN0IG9uZSB1c2VyIHRvIHNlbmQgV2hhdHNBcHAgbWVzc2FnZS5cIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5wb3N0KFwiL3doYXRzYXBwL3doYXRzYXBwLXByb21vLW1lc3NhZ2VcIiwgcGF5bG9hZCk7XHJcbiAgICAgIGNvbnNvbGUuaW5mbyhyZXMsIFwidGVzdFwiKTtcclxuXHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICBtZXNzYWdlOiBgTWVzc2FnZXMgc2VudCEgU3VjY2VzczogJHtyZXMuZGF0YS5zdWNjZXNzQ291bnR9LCBGYWlsZWQ6ICR7cmVzLmRhdGEuZXJyb3JDb3VudH1gLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gIFJlc2V0IHNlbGVjdGlvbiBhZnRlciBzZW5kaW5nXHJcbiAgICAgIGNvbnN0IHVwZGF0ZWRTZWxlY3Rpb24gPSB7IC4uLnNlbGVjdFVzZXIgfTtcclxuICAgICAgd2hhdHNhcHBEYXRhLmZvckVhY2goKGVudHJ5KSA9PiB7XHJcbiAgICAgICAgdXBkYXRlZFNlbGVjdGlvbltlbnRyeS5pbmZvLnVzZXJJZF0gPSBmYWxzZTtcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNlbGVjdFVzZXIodXBkYXRlZFNlbGVjdGlvbik7XHJcbiAgICAgIHNldFdoYXRzYXBwRGF0YShbXSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIldoYXRzQXBwIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIHNlbmQgV2hhdHNBcHAgbWVzc2FnZXMuXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWREYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAvLyAgVXNlIHNlbGVjdGVkRnJvbURhdGUgYW5kIHNlbGVjdGVkVG9EYXRlXHJcbiAgICBjb25zdCBmcm9tID0gc2VsZWN0ZWRGcm9tRGF0ZVxyXG4gICAgICA/IG1vbWVudChzZWxlY3RlZEZyb21EYXRlLCBcIllZWVktTU0tRERcIikuc3RhcnRPZihcImRheVwiKVxyXG4gICAgICA6IG51bGw7XHJcblxyXG4gICAgY29uc3QgdG8gPSBzZWxlY3RlZFRvRGF0ZVxyXG4gICAgICA/IG1vbWVudChzZWxlY3RlZFRvRGF0ZSwgXCJZWVlZLU1NLUREXCIpLmVuZE9mKFwiZGF5XCIpXHJcbiAgICAgIDogbnVsbDtcclxuXHJcbiAgICBjb25zdCBmaWx0ZXJGbiA9IChpdGVtKSA9PiB7XHJcbiAgICAgIGNvbnN0IGNyZWF0ZWQgPSBpdGVtPy5jcmVhdGVkQXQgPyBtb21lbnQoaXRlbS5jcmVhdGVkQXQpIDogbnVsbDtcclxuXHJcbiAgICAgIC8vICBPbmx5IGFwcGx5IGRhdGUgcmFuZ2UgaWYgbGFiZWwgaXMgbm90IFwiQWxsXCJcclxuICAgICAgY29uc3QgaXNXaXRoaW5EYXRlUmFuZ2UgPVxyXG4gICAgICAgICghZnJvbSB8fCAoY3JlYXRlZCAmJiBjcmVhdGVkLmlzU2FtZU9yQWZ0ZXIoZnJvbSkpKSAmJlxyXG4gICAgICAgICghdG8gfHwgKGNyZWF0ZWQgJiYgY3JlYXRlZC5pc1NhbWVPckJlZm9yZSh0bykpKTtcclxuXHJcbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWROYW1lID0gc2VsZWN0ZWRSZWZlcnJlck5hbWUudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICBpZiAoc2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwibGVhZFwiKSB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgIWl0ZW0/LmxlYWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSAmJlxyXG4gICAgICAgICAgIWl0ZW0/Lmdyb3VwX2lkPy5ncm91cF9uYW1lICYmXHJcbiAgICAgICAgICAhaXRlbT8ubGVhZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGxlYWRUeXBlTmFtZSA9XHJcbiAgICAgICAgICBpdGVtLmxlYWRfdHlwZSA9PT0gXCJjdXN0b21lclwiXHJcbiAgICAgICAgICAgID8gaXRlbT8ubGVhZF9jdXN0b21lcj8uZnVsbF9uYW1lXHJcbiAgICAgICAgICAgIDogaXRlbS5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIlxyXG4gICAgICAgICAgICA/IGl0ZW0/LmxlYWRfYWdlbnQ/Lm5hbWVcclxuICAgICAgICAgICAgOiBcIlwiO1xyXG5cclxuICAgICAgICBjb25zdCBuYW1lTWF0Y2hlcyA9XHJcbiAgICAgICAgICAhbm9ybWFsaXplZE5hbWUgfHxcclxuICAgICAgICAgIChsZWFkVHlwZU5hbWUgfHwgXCJcIikudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhub3JtYWxpemVkTmFtZSk7XHJcblxyXG4gICAgICAgIGNvbnN0IG1hdGNoZXNHcm91cCA9XHJcbiAgICAgICAgICAhc2VsZWN0ZWRHcm91cE5hbWUgfHxcclxuICAgICAgICAgIChpdGVtPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpID09PVxyXG4gICAgICAgICAgICBzZWxlY3RlZEdyb3VwTmFtZS50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgICByZXR1cm4gaXNXaXRoaW5EYXRlUmFuZ2UgJiYgbmFtZU1hdGNoZXMgJiYgbWF0Y2hlc0dyb3VwO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBhZ2VudE5hbWUgPSBpdGVtPy5hZ2VudD8ubmFtZT8udG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3QgYWdlbnRUeXBlID0gaXRlbT8uYWdlbnQ/LmFnZW50X3R5cGU7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaGVzQWdlbnQgPVxyXG4gICAgICAgIHNlbGVjdGVkUmVmZXJyZXJUeXBlID09PSBcImFnZW50XCIgJiZcclxuICAgICAgICBhZ2VudFR5cGUgPT09IFwiYWdlbnRcIiAmJlxyXG4gICAgICAgIGFnZW50TmFtZT8uaW5jbHVkZXMobm9ybWFsaXplZE5hbWUpO1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hlc0VtcGxveWVlID1cclxuICAgICAgICBzZWxlY3RlZFJlZmVycmVyVHlwZSA9PT0gXCJlbXBsb3llZVwiICYmXHJcbiAgICAgICAgYWdlbnRUeXBlID09PSBcImVtcGxveWVlXCIgJiZcclxuICAgICAgICBhZ2VudE5hbWU/LmluY2x1ZGVzKG5vcm1hbGl6ZWROYW1lKTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoZXNDdXN0b21lciA9XHJcbiAgICAgICAgc2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwiY3VzdG9tZXJcIiAmJlxyXG4gICAgICAgIGl0ZW0/LmFnZW50Py5uYW1lPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG5vcm1hbGl6ZWROYW1lKTtcclxuXHJcbiAgICAgIGNvbnN0IHR5cGVNYXRjaCA9XHJcbiAgICAgICAgc2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwiXCIgfHxcclxuICAgICAgICBtYXRjaGVzQWdlbnQgfHxcclxuICAgICAgICBtYXRjaGVzRW1wbG95ZWUgfHxcclxuICAgICAgICBtYXRjaGVzQ3VzdG9tZXI7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaGVzR3JvdXAgPVxyXG4gICAgICAgICFzZWxlY3RlZEdyb3VwTmFtZSB8fFxyXG4gICAgICAgIChpdGVtPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpID09PVxyXG4gICAgICAgICAgc2VsZWN0ZWRHcm91cE5hbWUudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgIHJldHVybiB0eXBlTWF0Y2ggJiYgaXNXaXRoaW5EYXRlUmFuZ2UgJiYgbWF0Y2hlc0dyb3VwO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gc2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwibGVhZFwiXHJcbiAgICAgID8gYWxsTGVhZHMuZmlsdGVyKGZpbHRlckZuKVxyXG4gICAgICA6IGFsbEVucm9sbHMuZmlsdGVyKGZpbHRlckZuKTtcclxuICB9LCBbXHJcbiAgICBhbGxMZWFkcyxcclxuICAgIGFsbEVucm9sbHMsXHJcbiAgICBzZWxlY3RlZFJlZmVycmVyTmFtZSxcclxuICAgIHNlbGVjdGVkUmVmZXJyZXJUeXBlLFxyXG4gICAgc2VsZWN0ZWRGcm9tRGF0ZSwgLy8gIEZJWEVEXHJcbiAgICBzZWxlY3RlZFRvRGF0ZSwgLy8gIEZJWEVEXHJcbiAgICBzZWxlY3RlZEdyb3VwTmFtZSxcclxuICBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZpbHRlcmVkRGF0YVxyXG4gICAgICAuZmlsdGVyKChpdGVtKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZnVsbE5hbWUgPVxyXG4gICAgICAgICAgc2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwibGVhZFwiXHJcbiAgICAgICAgICAgID8gaXRlbT8ubGVhZF9uYW1lXHJcbiAgICAgICAgICAgIDogaXRlbT8udXNlcl9pZD8uZnVsbF9uYW1lO1xyXG4gICAgICAgIGNvbnN0IHBob25lTnVtYmVyID1cclxuICAgICAgICAgIHNlbGVjdGVkUmVmZXJyZXJUeXBlID09PSBcImxlYWRcIlxyXG4gICAgICAgICAgICA/IGl0ZW0/LmxlYWRfcGhvbmVcclxuICAgICAgICAgICAgOiBpdGVtPy51c2VyX2lkPy5waG9uZV9udW1iZXI7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBOYW1lID0gaXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWU7XHJcblxyXG4gICAgICAgIHJldHVybiBmdWxsTmFtZSAmJiBwaG9uZU51bWJlciAmJiBncm91cE5hbWU7IC8vIGtlZXAgb25seSB2YWxpZCByb3dzXHJcbiAgICAgIH0pXHJcbiAgICAgIC5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIF9pZDogaXRlbS5faWQsXHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICBmdWxsX25hbWU6XHJcbiAgICAgICAgICBzZWxlY3RlZFJlZmVycmVyVHlwZSA9PT0gXCJsZWFkXCJcclxuICAgICAgICAgICAgPyBpdGVtPy5sZWFkX25hbWUgfHwgXCJOQVwiXHJcbiAgICAgICAgICAgIDogaXRlbT8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTkFcIixcclxuICAgICAgICBwaG9uZV9udW1iZXI6XHJcbiAgICAgICAgICBzZWxlY3RlZFJlZmVycmVyVHlwZSA9PT0gXCJsZWFkXCJcclxuICAgICAgICAgICAgPyBpdGVtPy5sZWFkX3Bob25lIHx8IFwiTkFcIlxyXG4gICAgICAgICAgICA6IGl0ZW0/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk5BXCIsXHJcbiAgICAgICAgZ3JvdXBfbmFtZTogaXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOQVwiLFxyXG4gICAgICAgIGdyb3VwX2lkOiBpdGVtPy5ncm91cF9pZD8uX2lkIHx8IFwiTkFcIixcclxuICAgICAgICBjcmVhdGVkQXQ6IGl0ZW0/LmNyZWF0ZWRBdCA/IG5ldyBEYXRlKGl0ZW0uY3JlYXRlZEF0KSA6IG51bGwsXHJcbiAgICAgICAgZW5yb2xsbWVudF9kYXRlOiBpdGVtPy5jcmVhdGVkQXRcclxuICAgICAgICAgID8gbmV3IERhdGUoaXRlbS5jcmVhdGVkQXQpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICA6IFwiTkFcIixcclxuICAgICAgfSkpO1xyXG5cclxuICAgIGNvbnN0IG5ld1NlbGVjdGlvbiA9IHt9O1xyXG4gICAgZm9ybWF0dGVkLmZvckVhY2goKHUpID0+IChuZXdTZWxlY3Rpb25bdS5faWRdID0gZmFsc2UpKTtcclxuICAgIHNldFNlbGVjdFVzZXIobmV3U2VsZWN0aW9uKTtcclxuICAgIHNldFRhYmxlVXNlcnMoZm9ybWF0dGVkKTtcclxuICB9LCBbZmlsdGVyZWREYXRhXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZElkcyA9IE9iamVjdC52YWx1ZXMoc2VsZWN0VXNlcikuZmlsdGVyKCh2KSA9PiB2KS5sZW5ndGg7XHJcbiAgICBjb25zdCB0b3RhbCA9IFRhYmxlVXNlcnMubGVuZ3RoO1xyXG5cclxuICAgIHNldEN1c3RvbWVyQ291bnQoc2VsZWN0ZWRJZHMpO1xyXG4gICAgc2V0U2VsZWN0QWxsKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBjaGVja2VkOiBzZWxlY3RlZElkcyA9PT0gdG90YWwgJiYgdG90YWwgPiAwLFxyXG4gICAgICBtc2c6IHNlbGVjdGVkSWRzID09PSB0b3RhbCAmJiB0b3RhbCA+IDAgPyBcIk5vXCIgOiBcIkFsbFwiLFxyXG4gICAgfSkpO1xyXG4gIH0sIFtzZWxlY3RVc2VyLCBUYWJsZVVzZXJzXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBpZiAoIWZvcm1EYXRhLnRlbXBsYXRlX25hbWUudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy50ZW1wbGF0ZV9uYW1lID0gXCJUZW1wbGF0ZSBuYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGVja2JveENoYW5nZSA9IChjaGVja2VkLCB1c2VyKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RVc2VyKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbdXNlci5faWRdOiBjaGVja2VkLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIGNvbnN0IHVzZXJEYXRhID0ge1xyXG4gICAgICBpbmZvOiB7XHJcbiAgICAgICAgdXNlcklkOiB1c2VyLl9pZCxcclxuICAgICAgICB1c2VyTmFtZTogdXNlci5mdWxsX25hbWUgfHwgdXNlci5sZWFkX25hbWUsXHJcbiAgICAgICAgdXNlclBob25lOiB1c2VyLnBob25lX251bWJlciB8fCB1c2VyLmxlYWRfcGhvbmUsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiB1c2VyLmdyb3VwX25hbWUsXHJcbiAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cF9pZD8uX2lkIHx8IHVzZXIuZ3JvdXBfaWQgfHwgXCJOQVwiLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuXHJcbiAgICBzZXRXaGF0c2FwcERhdGEoKHByZXYpID0+IHtcclxuICAgICAgaWYgKGNoZWNrZWQpIHtcclxuICAgICAgICByZXR1cm4gWy4uLnByZXYsIHVzZXJEYXRhXTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gcHJldi5maWx0ZXIoKGVudHJ5KSA9PiBlbnRyeS5pbmZvLnVzZXJJZCAhPT0gdXNlci5faWQpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RBbGwgPSAoY2hlY2tlZCkgPT4ge1xyXG4gICAgY29uc3QgbmV3U2VsZWN0aW9uID0ge307XHJcbiAgICBjb25zdCBuZXdXaGF0c2FwcERhdGEgPSBbXTtcclxuXHJcbiAgICBUYWJsZVVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgbmV3U2VsZWN0aW9uW3VzZXIuX2lkXSA9IGNoZWNrZWQ7XHJcbiAgICAgIGlmIChjaGVja2VkKSB7XHJcbiAgICAgICAgbmV3V2hhdHNhcHBEYXRhLnB1c2goe1xyXG4gICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICB1c2VySWQ6IHVzZXIuX2lkLFxyXG4gICAgICAgICAgICB1c2VyTmFtZTogdXNlci5mdWxsX25hbWUgfHwgdXNlci5sZWFkX25hbWUsXHJcbiAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci5waG9uZV9udW1iZXIgfHwgdXNlci5sZWFkX3Bob25lLFxyXG4gICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cF9pZD8uX2lkIHx8IHVzZXIuZ3JvdXBfaWQgfHwgXCJOQVwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25zb2xlLmluZm8obmV3V2hhdHNhcHBEYXRhLCBcIndoYXRzYXBwIHRlc3RcIik7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHNldFNlbGVjdFVzZXIobmV3U2VsZWN0aW9uKTtcclxuICAgIHNldFdoYXRzYXBwRGF0YShuZXdXaGF0c2FwcERhdGEpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIHNldERpc2FibGVkKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgd2hhdHNhcHBBcGkucG9zdChcIi9tYXJrZXRpbmdcIiwge1xyXG4gICAgICAgICAgc2VsZWN0VXNlcixcclxuICAgICAgICAgIHRlbXBsYXRlX25hbWU6IGZvcm1EYXRhPy50ZW1wbGF0ZV9uYW1lLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB7XHJcbiAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgdGVtcGxhdGVfbmFtZTogXCJcIixcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIEZhaWx1cmVcIixcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDEpIHtcclxuICAgICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICB0ZW1wbGF0ZV9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICB0ZW1wbGF0ZV9uYW1lOiBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIEZhaWx1cmVcIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwid2hhdHNhcHAgZXJyb3JcIiwgZXJyLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBjb3VudEN1c3RvbWVyID0gKCkgPT4ge1xyXG4gICAgICBsZXQgY291bnRlciA9IDA7XHJcbiAgICAgIE9iamVjdC52YWx1ZXMoc2VsZWN0VXNlcikuZm9yRWFjaCgoZWxlKSA9PiB7XHJcbiAgICAgICAgaWYgKGVsZSkge1xyXG4gICAgICAgICAgY291bnRlcisrO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIHNldEN1c3RvbWVyQ291bnQoY291bnRlcik7XHJcbiAgICB9O1xyXG4gICAgY291bnRDdXN0b21lcigpO1xyXG4gIH0sIFtzZWxlY3RVc2VyLCByZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdFwiIH0sXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbG1lbnRfZGF0ZVwiLCBoZWFkZXI6IFwiRW5yb2xsZWQgT25cIiB9LFxyXG4gICAgeyBrZXk6IFwiZnVsbF9uYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9eyhlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8U2lkZWJhci8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG10LTJcIj5cclxuICAgICAgICAgICAgICBXaGF0c2FwcCBQcm9tb3Rpb24gTWVzc2FnZVxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjb2xvcj1cImdyZWVuXCIgc2l6ZT1cIjMwXCIgY2xhc3NOYW1lPVwibS0yIG1iLTEwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBtYi0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgV2hhdHNhcHAge3VzZXJUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBzcGFjZS14LTQgbXQtNCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFNlbGVjdCBBbnkgRHJvcGRvd24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMiBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5TZWxlY3QgQW55PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcHgtMTAgcHktMiB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUmVmZXJyZXJUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRSZWZlcnJlclR5cGUoZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWdlbnRcIj5BZ2VudDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibGVhZFwiPkxlYWQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImN1c3RvbWVyXCI+Q3VzdG9tZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImVtcGxveWVlXCI+RW1wbG95ZWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogU2VsZWN0IHt1c2VyVHlwZX0gTmFtZSBEcm9wZG93biAqL31cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSZWZlcnJlclR5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMiBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCB7dXNlclR5cGV9IE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgcHgtOCByb3VuZGVkIHRleHQtc20gbWluLXctWzIwMHB4XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUmVmZXJyZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUmVmZXJyZXJOYW1lKGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwiYWdlbnRcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRMaXN0Lm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Lm5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSAoe2FnZW50LnBob25lX251bWJlcn0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmVmZXJyZXJUeXBlID09PSBcImVtcGxveWVlXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFnZW50TGlzdC5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX0gKHthZ2VudC5waG9uZV9udW1iZXJ9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlZmVycmVyVHlwZSA9PT0gXCJsZWFkXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlYWRMaXN0Lm1hcCgobGVhZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsZWFkX3R5cGVfbmFtZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVhZD8ubGVhZF90eXBlID09PSBcImN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbGVhZD8ubGVhZF9jdXN0b21lcj8uZnVsbF9uYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGxlYWQ/LmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGxlYWQ/LmxlYWRfYWdlbnQ/Lm5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2xlYWQuX2lkfSB2YWx1ZT17bGVhZF90eXBlX25hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xlYWRfdHlwZV9uYW1lfSAoe2xlYWQ/LmxlYWRfcGhvbmUgfHwgXCJOQVwifSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiB7c2VsZWN0ZWRSZWZlcnJlclR5cGUgPT09IFwiY3VzdG9tZXJcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJMaXN0Lm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLmZ1bGxfbmFtZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfSAoe3VzZXIucGhvbmVfbnVtYmVyfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmVmZXJyZXJUeXBlID09PSBcImN1c3RvbWVyXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFnZW50TGlzdC5tYXAoKHBlcnNvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cGVyc29uLl9pZH0gdmFsdWU9e3BlcnNvbi5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVyc29uLm5hbWV9ICh7cGVyc29uLnBob25lX251bWJlcn0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMiBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5TZWxlY3QgRGF0ZSBGaWx0ZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZVNlbGVjdEZpbHRlcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUb2RheVwiPlRvZGF5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJZZXN0ZXJkYXlcIj5ZZXN0ZXJkYXk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRoaXNNb250aFwiPlRoaXMgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RNb250aFwiPkxhc3QgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRoaXNZZWFyXCI+VGhpcyBZZWFyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBbGxcIj5BbGw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkN1c3RvbVwiPkN1c3RvbTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZExhYmVsID09PSBcIkN1c3RvbVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTIgbWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkZyb20gRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTIgbWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlRvIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogU2VsZWN0IEdyb3VwICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTIgbWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2VsZWN0IEdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkIHRleHQtc20gbWluLXctWzIwMHB4XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEdyb3VwTmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwTGlzdC5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLmdyb3VwX25hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTZWxlY3QgQWxsIENoZWNrYm94ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVVc2Vycy5sZW5ndGggPiAwICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYWJsZVVzZXJzLmV2ZXJ5KCh1KSA9PiBzZWxlY3RVc2VyW3UuX2lkXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTZWxlY3RBbGwoZS50YXJnZXQuY2hlY2tlZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBBbGxcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtaW4tdy02IGgtNiBhYnNvbHV0ZSAtcmlnaHQtMyAtdG9wLTIgc2hhZG93LWxnIGhvdmVyOmJnLXJlZC02MDAgYmctcmVkLTQwMCByb3VuZGVkLWZ1bGwgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dmlzaWJsZVNlbGVjdGVkQ291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJtci0yXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtmaWx0ZXJlZFVzZXJzLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBpc0V4cG9ydEVuYWJsZWQ9e3RydWV9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIldoYXRzYXBwIFByb21vXCJcclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICBcIlJlZmVycmVyIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgXCJEYXRlIEZpbHRlclwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvIERhdGVcIixcclxuICAgICAgICAgICAgICAgICAgXCJHcm91cCBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiRnJvbSBEYXRlXCIsXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRSZWZlcnJlck5hbWUgfHwgXCJBbGxcIixcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRMYWJlbCB8fCBcIkFsbFwiLFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZFRvRGF0ZSB8fCBcIk5BXCIsXHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkR3JvdXBOYW1lIHx8IFwiQWxsXCIsXHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRnJvbURhdGUgfHwgXCJOQVwiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2B3aGF0c2FwcCBQcm9tby5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e2ZpbHRlcmVkVXNlcnMubGVuZ3RoIDw9IDAgJiYgIWlzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGRhdGE9e1wiR3JvdXAgRGF0YVwifVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBTZW5kIE1lc3NhZ2VcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInRlbXBsYXRlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVGVtcGxhdGUgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0ZW1wbGF0ZV9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRlbXBsYXRlX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidGVtcGxhdGVOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXN0ZSB0ZW1wbGF0ZSBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctZ3JlZW4tNTAwIGZvY3VzOmJvcmRlci1ncmVlbi01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy50ZW1wbGF0ZV9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy50ZW1wbGF0ZV9uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1ncmVlbi03MDAgaG92ZXI6YmctZ3JlZW4tODAwXHJcbiAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctZ3JlZW4tMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgU2VuZFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBXaGF0c2FwcFByb21vO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvV2hhdHNhcHBQcm9tby5qc3gifQ==