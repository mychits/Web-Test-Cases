import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/search/GlobalSearchBar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { ChevronDown } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { FiSearch } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
const GlobalSearchBar = ({
  onGlobalSearchChangeHandler,
  onFocus,
  onQuickActionToggle,
  quickActionsOpen = false,
  quickActionsPanelId,
  value,
  visibility
}) => {
  _s();
  const placeholderPhrases = useMemo(
    () => [
      "Search quick actions...",
      'Try "Payment In"',
      'Open "Unverified"',
      "Find customer or receipt",
      "Jump to reports",
      "Search loans, agents, pigmy...",
      "Type to search or open actions"
    ],
    []
  );
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [characterCount, setCharacterCount] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  useEffect(() => {
    if (value) return void 0;
    const currentPhrase = placeholderPhrases[phraseIndex];
    const delay = isPaused ? 1400 : isDeleting ? 32 : 58;
    const timeoutId = window.setTimeout(() => {
      if (isPaused) {
        setIsPaused(false);
        setIsDeleting(true);
        return;
      }
      if (!isDeleting && characterCount < currentPhrase.length) {
        setCharacterCount((count) => count + 1);
        return;
      }
      if (!isDeleting && characterCount === currentPhrase.length) {
        setIsPaused(true);
        return;
      }
      if (isDeleting && characterCount > 0) {
        setCharacterCount((count) => count - 1);
        return;
      }
      setIsDeleting(false);
      setPhraseIndex((index) => (index + 1) % placeholderPhrases.length);
    }, delay);
    return () => window.clearTimeout(timeoutId);
  }, [characterCount, isDeleting, isPaused, phraseIndex, placeholderPhrases, value]);
  if (!visibility) return null;
  const animatedPlaceholder = value ? "" : placeholderPhrases[phraseIndex].slice(0, characterCount);
  return /* @__PURE__ */ jsxDEV("div", { className: "relative flex min-h-full w-full items-center", children: [
    /* @__PURE__ */ jsxDEV(FiSearch, { className: "ml-1 h-[18px] w-[18px] shrink-0 text-slate-500" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx",
      lineNumber: 75,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "search",
        placeholder: animatedPlaceholder,
        value,
        onFocus,
        onChange: (e) => onGlobalSearchChangeHandler(e),
        className: "h-full w-full cursor-text select-none border-0 bg-transparent px-3 py-2 pr-12 text-left text-sm font-medium text-slate-900 outline-none transition-all placeholder:text-sm placeholder:font-medium placeholder:text-slate-500 focus:outline-none focus:ring-0"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx",
        lineNumber: 76,
        columnNumber: 4
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        "aria-label": quickActionsOpen ? "Close quick actions" : "Open quick actions",
        "aria-expanded": quickActionsOpen,
        "aria-controls": quickActionsPanelId,
        onMouseDown: (event) => event.preventDefault(),
        onClick: onQuickActionToggle,
        className: `absolute right-1.5 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full border backdrop-blur-xl transition duration-200 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 ${quickActionsOpen ? "border-[#0071e3]/30 bg-[#0071e3]/12 text-[#0071e3] shadow-sm shadow-blue-900/[0.04]" : "border-slate-300/70 bg-white/70 text-slate-600 shadow-sm shadow-slate-900/[0.03] hover:border-[#0071e3]/30 hover:bg-white hover:text-[#0071e3]"}`,
        children: /* @__PURE__ */ jsxDEV(
          ChevronDown,
          {
            className: `h-3.5 w-3.5 transition-transform duration-200 ${quickActionsOpen ? "rotate-180" : ""}`,
            strokeWidth: 1.85
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx",
            lineNumber: 96,
            columnNumber: 5
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx",
        lineNumber: 84,
        columnNumber: 4
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx",
    lineNumber: 74,
    columnNumber: 5
  }, this);
};
_s(GlobalSearchBar, "LzhfPp3bX0WHkK+U0LaWKtu9H5s=");
_c = GlobalSearchBar;
export default GlobalSearchBar;
var _c;
$RefreshReg$(_c, "GlobalSearchBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/search/GlobalSearchBar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEVHOzJCQTFFSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUM3QyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLGtCQUFrQkEsQ0FBQztBQUFBLEVBQ3hCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxtQkFBbUI7QUFBQSxFQUNuQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRCxNQUFNO0FBQUFDLEtBQUE7QUFDTCxRQUFNQyxxQkFBcUJiO0FBQUFBLElBQzFCLE1BQU07QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFBZ0M7QUFBQSxJQUVqQztBQUFBLEVBQ0Q7QUFDQSxRQUFNLENBQUNjLGFBQWFDLGNBQWMsSUFBSWQsU0FBUyxDQUFDO0FBQ2hELFFBQU0sQ0FBQ2UsZ0JBQWdCQyxpQkFBaUIsSUFBSWhCLFNBQVMsQ0FBQztBQUN0RCxRQUFNLENBQUNpQixZQUFZQyxhQUFhLElBQUlsQixTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDbUIsVUFBVUMsV0FBVyxJQUFJcEIsU0FBUyxLQUFLO0FBRTlDRixZQUFVLE1BQU07QUFDZixRQUFJVyxNQUFPLFFBQU9ZO0FBRWxCLFVBQU1DLGdCQUFnQlYsbUJBQW1CQyxXQUFXO0FBQ3BELFVBQU1VLFFBQVFKLFdBQVcsT0FBT0YsYUFBYSxLQUFLO0FBRWxELFVBQU1PLFlBQVlDLE9BQU9DLFdBQVcsTUFBTTtBQUN6QyxVQUFJUCxVQUFVO0FBQ2JDLG9CQUFZLEtBQUs7QUFDakJGLHNCQUFjLElBQUk7QUFDbEI7QUFBQSxNQUNEO0FBRUEsVUFBSSxDQUFDRCxjQUFjRixpQkFBaUJPLGNBQWNLLFFBQVE7QUFDekRYLDBCQUFrQixDQUFDWSxVQUFVQSxRQUFRLENBQUM7QUFDdEM7QUFBQSxNQUNEO0FBRUEsVUFBSSxDQUFDWCxjQUFjRixtQkFBbUJPLGNBQWNLLFFBQVE7QUFDM0RQLG9CQUFZLElBQUk7QUFDaEI7QUFBQSxNQUNEO0FBRUEsVUFBSUgsY0FBY0YsaUJBQWlCLEdBQUc7QUFDckNDLDBCQUFrQixDQUFDWSxVQUFVQSxRQUFRLENBQUM7QUFDdEM7QUFBQSxNQUNEO0FBRUFWLG9CQUFjLEtBQUs7QUFDbkJKLHFCQUFlLENBQUNlLFdBQVdBLFFBQVEsS0FBS2pCLG1CQUFtQmUsTUFBTTtBQUFBLElBQ2xFLEdBQUdKLEtBQUs7QUFFUixXQUFPLE1BQU1FLE9BQU9LLGFBQWFOLFNBQVM7QUFBQSxFQUMzQyxHQUFHLENBQUNULGdCQUFnQkUsWUFBWUUsVUFBVU4sYUFBYUQsb0JBQW9CSCxLQUFLLENBQUM7QUFFakYsTUFBSSxDQUFDQyxXQUFZLFFBQU87QUFFeEIsUUFBTXFCLHNCQUFzQnRCLFFBQ3pCLEtBQ0FHLG1CQUFtQkMsV0FBVyxFQUFFbUIsTUFBTSxHQUFHakIsY0FBYztBQUUxRCxTQUNDLHVCQUFDLFNBQUksV0FBVSxnREFDZDtBQUFBLDJCQUFDLFlBQVMsV0FBVSxvREFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRTtBQUFBLElBQ3BFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQSxNQUFLO0FBQUEsUUFDTCxhQUFhZ0I7QUFBQUEsUUFDYjtBQUFBLFFBQ0E7QUFBQSxRQUNBLFVBQVUsQ0FBQ0UsTUFBTTdCLDRCQUE0QjZCLENBQUM7QUFBQSxRQUM5QyxXQUFVO0FBQUE7QUFBQSxNQU5YO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU0wUTtBQUFBLElBRTFRO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQSxNQUFLO0FBQUEsUUFDTCxjQUFZMUIsbUJBQW1CLHdCQUF3QjtBQUFBLFFBQ3ZELGlCQUFlQTtBQUFBQSxRQUNmLGlCQUFlQztBQUFBQSxRQUNmLGFBQWEsQ0FBQzBCLFVBQVVBLE1BQU1DLGVBQWU7QUFBQSxRQUM3QyxTQUFTN0I7QUFBQUEsUUFDVCxXQUFXLG9NQUFvTUMsbUJBQzVNLHdGQUNBLGdKQUFnSjtBQUFBLFFBR25KO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQSxXQUFXLGlEQUFpREEsbUJBQW1CLGVBQWUsRUFBRTtBQUFBLFlBQ2hHLGFBQWE7QUFBQTtBQUFBLFVBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRW1CO0FBQUE7QUFBQSxNQWRwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnQkE7QUFBQSxPQTFCRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkJBO0FBRUY7QUFBRUksR0FqR0lSLGlCQUFlO0FBQUFpQyxLQUFmakM7QUFtR04sZUFBZUE7QUFBZ0IsSUFBQWlDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJDaGV2cm9uRG93biIsIkZpU2VhcmNoIiwiR2xvYmFsU2VhcmNoQmFyIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwib25Gb2N1cyIsIm9uUXVpY2tBY3Rpb25Ub2dnbGUiLCJxdWlja0FjdGlvbnNPcGVuIiwicXVpY2tBY3Rpb25zUGFuZWxJZCIsInZhbHVlIiwidmlzaWJpbGl0eSIsIl9zIiwicGxhY2Vob2xkZXJQaHJhc2VzIiwicGhyYXNlSW5kZXgiLCJzZXRQaHJhc2VJbmRleCIsImNoYXJhY3RlckNvdW50Iiwic2V0Q2hhcmFjdGVyQ291bnQiLCJpc0RlbGV0aW5nIiwic2V0SXNEZWxldGluZyIsImlzUGF1c2VkIiwic2V0SXNQYXVzZWQiLCJ1bmRlZmluZWQiLCJjdXJyZW50UGhyYXNlIiwiZGVsYXkiLCJ0aW1lb3V0SWQiLCJ3aW5kb3ciLCJzZXRUaW1lb3V0IiwibGVuZ3RoIiwiY291bnQiLCJpbmRleCIsImNsZWFyVGltZW91dCIsImFuaW1hdGVkUGxhY2Vob2xkZXIiLCJzbGljZSIsImUiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR2xvYmFsU2VhcmNoQmFyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQ2hldnJvbkRvd24gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEZpU2VhcmNoIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcblxyXG5jb25zdCBHbG9iYWxTZWFyY2hCYXIgPSAoe1xyXG5cdG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcixcclxuXHRvbkZvY3VzLFxyXG5cdG9uUXVpY2tBY3Rpb25Ub2dnbGUsXHJcblx0cXVpY2tBY3Rpb25zT3BlbiA9IGZhbHNlLFxyXG5cdHF1aWNrQWN0aW9uc1BhbmVsSWQsXHJcblx0dmFsdWUsXHJcblx0dmlzaWJpbGl0eSxcclxufSkgPT4ge1xyXG5cdGNvbnN0IHBsYWNlaG9sZGVyUGhyYXNlcyA9IHVzZU1lbW8oXHJcblx0XHQoKSA9PiBbXHJcblx0XHRcdFwiU2VhcmNoIHF1aWNrIGFjdGlvbnMuLi5cIixcclxuXHRcdFx0J1RyeSBcIlBheW1lbnQgSW5cIicsXHJcblx0XHRcdCdPcGVuIFwiVW52ZXJpZmllZFwiJyxcclxuXHRcdFx0XCJGaW5kIGN1c3RvbWVyIG9yIHJlY2VpcHRcIixcclxuXHRcdFx0XCJKdW1wIHRvIHJlcG9ydHNcIixcclxuXHRcdFx0XCJTZWFyY2ggbG9hbnMsIGFnZW50cywgcGlnbXkuLi5cIixcclxuXHRcdFx0XCJUeXBlIHRvIHNlYXJjaCBvciBvcGVuIGFjdGlvbnNcIixcclxuXHRcdF0sXHJcblx0XHRbXVxyXG5cdCk7XHJcblx0Y29uc3QgW3BocmFzZUluZGV4LCBzZXRQaHJhc2VJbmRleF0gPSB1c2VTdGF0ZSgwKTtcclxuXHRjb25zdCBbY2hhcmFjdGVyQ291bnQsIHNldENoYXJhY3RlckNvdW50XSA9IHVzZVN0YXRlKDApO1xyXG5cdGNvbnN0IFtpc0RlbGV0aW5nLCBzZXRJc0RlbGV0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHRjb25zdCBbaXNQYXVzZWQsIHNldElzUGF1c2VkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcblx0dXNlRWZmZWN0KCgpID0+IHtcclxuXHRcdGlmICh2YWx1ZSkgcmV0dXJuIHVuZGVmaW5lZDtcclxuXHJcblx0XHRjb25zdCBjdXJyZW50UGhyYXNlID0gcGxhY2Vob2xkZXJQaHJhc2VzW3BocmFzZUluZGV4XTtcclxuXHRcdGNvbnN0IGRlbGF5ID0gaXNQYXVzZWQgPyAxNDAwIDogaXNEZWxldGluZyA/IDMyIDogNTg7XHJcblxyXG5cdFx0Y29uc3QgdGltZW91dElkID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xyXG5cdFx0XHRpZiAoaXNQYXVzZWQpIHtcclxuXHRcdFx0XHRzZXRJc1BhdXNlZChmYWxzZSk7XHJcblx0XHRcdFx0c2V0SXNEZWxldGluZyh0cnVlKTtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmICghaXNEZWxldGluZyAmJiBjaGFyYWN0ZXJDb3VudCA8IGN1cnJlbnRQaHJhc2UubGVuZ3RoKSB7XHJcblx0XHRcdFx0c2V0Q2hhcmFjdGVyQ291bnQoKGNvdW50KSA9PiBjb3VudCArIDEpO1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYgKCFpc0RlbGV0aW5nICYmIGNoYXJhY3RlckNvdW50ID09PSBjdXJyZW50UGhyYXNlLmxlbmd0aCkge1xyXG5cdFx0XHRcdHNldElzUGF1c2VkKHRydWUpO1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYgKGlzRGVsZXRpbmcgJiYgY2hhcmFjdGVyQ291bnQgPiAwKSB7XHJcblx0XHRcdFx0c2V0Q2hhcmFjdGVyQ291bnQoKGNvdW50KSA9PiBjb3VudCAtIDEpO1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0c2V0SXNEZWxldGluZyhmYWxzZSk7XHJcblx0XHRcdHNldFBocmFzZUluZGV4KChpbmRleCkgPT4gKGluZGV4ICsgMSkgJSBwbGFjZWhvbGRlclBocmFzZXMubGVuZ3RoKTtcclxuXHRcdH0sIGRlbGF5KTtcclxuXHJcblx0XHRyZXR1cm4gKCkgPT4gd2luZG93LmNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xyXG5cdH0sIFtjaGFyYWN0ZXJDb3VudCwgaXNEZWxldGluZywgaXNQYXVzZWQsIHBocmFzZUluZGV4LCBwbGFjZWhvbGRlclBocmFzZXMsIHZhbHVlXSk7XHJcblxyXG5cdGlmICghdmlzaWJpbGl0eSkgcmV0dXJuIG51bGw7XHJcblxyXG5cdGNvbnN0IGFuaW1hdGVkUGxhY2Vob2xkZXIgPSB2YWx1ZVxyXG5cdFx0PyBcIlwiXHJcblx0XHQ6IHBsYWNlaG9sZGVyUGhyYXNlc1twaHJhc2VJbmRleF0uc2xpY2UoMCwgY2hhcmFjdGVyQ291bnQpO1xyXG5cclxuXHRyZXR1cm4gKFxyXG5cdFx0PGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IG1pbi1oLWZ1bGwgdy1mdWxsIGl0ZW1zLWNlbnRlclwiPlxyXG5cdFx0XHQ8RmlTZWFyY2ggY2xhc3NOYW1lPVwibWwtMSBoLVsxOHB4XSB3LVsxOHB4XSBzaHJpbmstMCB0ZXh0LXNsYXRlLTUwMFwiIC8+XHJcblx0XHRcdDxpbnB1dFxyXG5cdFx0XHRcdHR5cGU9XCJzZWFyY2hcIlxyXG5cdFx0XHRcdHBsYWNlaG9sZGVyPXthbmltYXRlZFBsYWNlaG9sZGVyfVxyXG5cdFx0XHRcdHZhbHVlPXt2YWx1ZX1cclxuXHRcdFx0XHRvbkZvY3VzPXtvbkZvY3VzfVxyXG5cdFx0XHRcdG9uQ2hhbmdlPXsoZSkgPT4gb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyKGUpfVxyXG5cdFx0XHRcdGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgY3Vyc29yLXRleHQgc2VsZWN0LW5vbmUgYm9yZGVyLTAgYmctdHJhbnNwYXJlbnQgcHgtMyBweS0yIHByLTEyIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtOTAwIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWFsbCBwbGFjZWhvbGRlcjp0ZXh0LXNtIHBsYWNlaG9sZGVyOmZvbnQtbWVkaXVtIHBsYWNlaG9sZGVyOnRleHQtc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTBcIlxyXG5cdFx0XHQvPlxyXG5cdFx0XHQ8YnV0dG9uXHJcblx0XHRcdFx0dHlwZT1cImJ1dHRvblwiXHJcblx0XHRcdFx0YXJpYS1sYWJlbD17cXVpY2tBY3Rpb25zT3BlbiA/IFwiQ2xvc2UgcXVpY2sgYWN0aW9uc1wiIDogXCJPcGVuIHF1aWNrIGFjdGlvbnNcIn1cclxuXHRcdFx0XHRhcmlhLWV4cGFuZGVkPXtxdWlja0FjdGlvbnNPcGVufVxyXG5cdFx0XHRcdGFyaWEtY29udHJvbHM9e3F1aWNrQWN0aW9uc1BhbmVsSWR9XHJcblx0XHRcdFx0b25Nb3VzZURvd249eyhldmVudCkgPT4gZXZlbnQucHJldmVudERlZmF1bHQoKX1cclxuXHRcdFx0XHRvbkNsaWNrPXtvblF1aWNrQWN0aW9uVG9nZ2xlfVxyXG5cdFx0XHRcdGNsYXNzTmFtZT17YGFic29sdXRlIHJpZ2h0LTEuNSB0b3AtMS8yIGdyaWQgaC03IHctNyAtdHJhbnNsYXRlLXktMS8yIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLWZ1bGwgYm9yZGVyIGJhY2tkcm9wLWJsdXIteGwgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yNSAke3F1aWNrQWN0aW9uc09wZW5cclxuXHRcdFx0XHRcdD8gXCJib3JkZXItWyMwMDcxZTNdLzMwIGJnLVsjMDA3MWUzXS8xMiB0ZXh0LVsjMDA3MWUzXSBzaGFkb3ctc20gc2hhZG93LWJsdWUtOTAwL1swLjA0XVwiXHJcblx0XHRcdFx0XHQ6IFwiYm9yZGVyLXNsYXRlLTMwMC83MCBiZy13aGl0ZS83MCB0ZXh0LXNsYXRlLTYwMCBzaGFkb3ctc20gc2hhZG93LXNsYXRlLTkwMC9bMC4wM10gaG92ZXI6Ym9yZGVyLVsjMDA3MWUzXS8zMCBob3ZlcjpiZy13aGl0ZSBob3Zlcjp0ZXh0LVsjMDA3MWUzXVwiXHJcblx0XHRcdFx0fWB9XHJcblx0XHRcdD5cclxuXHRcdFx0XHQ8Q2hldnJvbkRvd25cclxuXHRcdFx0XHRcdGNsYXNzTmFtZT17YGgtMy41IHctMy41IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMCAke3F1aWNrQWN0aW9uc09wZW4gPyBcInJvdGF0ZS0xODBcIiA6IFwiXCJ9YH1cclxuXHRcdFx0XHRcdHN0cm9rZVdpZHRoPXsxLjg1fVxyXG5cdFx0XHRcdC8+XHJcblx0XHRcdDwvYnV0dG9uPlxyXG5cdFx0PC9kaXY+XHJcblx0KTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEdsb2JhbFNlYXJjaEJhcjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL2NvbXBvbmVudHMvc2VhcmNoL0dsb2JhbFNlYXJjaEJhci5qc3gifQ==