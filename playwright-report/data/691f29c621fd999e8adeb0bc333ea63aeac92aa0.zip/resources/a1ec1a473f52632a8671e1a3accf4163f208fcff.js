import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DueEmailMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { MdEmail } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { RiMoneyRupeeCircleLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const DueEmailMenu = () => {
  const emailmarketingCategories = [
    {
      id: 1,
      title: "Outstanding Email",
      description: "Manage Outstanding Email",
      icon: /* @__PURE__ */ jsxDEV(MdEmail, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
        lineNumber: 19,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/email-marketing/due-email-marketing/due-email",
      stats: "Active Due Mails"
    },
    {
      id: 2,
      title: "Outstanding Email [Over]",
      description: "Manage Over Outstanding Email",
      icon: /* @__PURE__ */ jsxDEV(MdEmail, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
        lineNumber: 30,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/email-marketing/due-email-marketing/over-due-email",
      stats: "Active Over Due Mails"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
      lineNumber: 44,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
        lineNumber: 46,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
          lineNumber: 48,
          columnNumber: 16
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-gray-900", children: "Outstanding Email Marketing Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
            lineNumber: 50,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Manage and organize your Outstanding Email Marketing" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
            lineNumber: 53,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
          lineNumber: 49,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6", children: emailmarketingCategories.map(
          (category) => /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `relative h-full overflow-hidden rounded-xl bg-white border ${category.borderColor} shadow-md hover:shadow-lg transition-all duration-300`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                    lineNumber: 64,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `inline-flex items-center justify-center w-14 h-14 ${category.lightColor} rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300`,
                      children: /* @__PURE__ */ jsxDEV("div", { children: category.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                        lineNumber: 72,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                      lineNumber: 69,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: category.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                      lineNumber: 76,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: category.description }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                      lineNumber: 79,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                    lineNumber: 75,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                      lineNumber: 85,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `p-1.5 rounded-lg bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300`,
                        children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                          lineNumber: 91,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                        lineNumber: 88,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                    lineNumber: 84,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                  lineNumber: 68,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
                    lineNumber: 96,
                    columnNumber: 21
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
              lineNumber: 61,
              columnNumber: 19
            },
            this
          ) }, category.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
            lineNumber: 60,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
          lineNumber: 58,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-violet-50 to-indigo-50 rounded-2xl border border-violet-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-violet-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
            lineNumber: 106,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
            lineNumber: 105,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
              lineNumber: 109,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Manage Outsatnding email, and more with Marketing Management—everything in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
              lineNumber: 110,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
            lineNumber: 108,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
          lineNumber: 104,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
          lineNumber: 103,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
        lineNumber: 47,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
      lineNumber: 45,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
    lineNumber: 43,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
};
_c = DueEmailMenu;
export default DueEmailMenu;
var _c;
$RefreshReg$(_c, "DueEmailMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmailMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JZO0FBbEJaLDJCQUFxQjtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkMsT0FBT0EsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLE9BQU9DLFdBQVdDLGNBQWFDLFdBQVk7QUFDcEQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsOEJBQThCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQUl2QixNQUFNQyxlQUFlQSxNQUFNO0FBQ3pCLFFBQU1DLDJCQUEyQjtBQUFBLElBRS9CO0FBQUEsTUFDRUMsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxXQUFRLFdBQVUsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLE1BQ2xDQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNDO0FBQUEsTUFDQ1IsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxXQUFRLFdBQVUsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLE1BQ2xDQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUFDO0FBS0gsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwyQkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1IsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2QkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFNBQUksV0FBVSxPQUNWO0FBQUEsK0JBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDZCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUMsc0RBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsb0VBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNaVCxtQ0FBeUJVO0FBQUFBLFVBQUksQ0FBQ0MsYUFDN0IsdUJBQUMsUUFBdUIsSUFBSUEsU0FBU0gsTUFBTSxXQUFVLFNBQ25EO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLDhEQUE4REcsU0FBU0osV0FBVztBQUFBLGNBRTdGO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyxzREFBc0RJLFNBQVNOLEtBQUs7QUFBQTtBQUFBLGtCQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ29MO0FBQUEsZ0JBR3BMLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcscURBQXFETSxTQUFTTCxVQUFVO0FBQUEsc0JBRW5GLGlDQUFDLFNBQUtLLG1CQUFTUCxRQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9CO0FBQUE7QUFBQSxvQkFIdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsb0ZBQ1hPLG1CQUFTVCxTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUseUNBQ1ZTLG1CQUFTUixlQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLGlIQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlHQUNiUSxtQkFBU0YsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxzQ0FBc0NFLFNBQVNOLEtBQUs7QUFBQSx3QkFFL0QsaUNBQUMsZ0JBQWEsV0FBVSx3QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNEM7QUFBQTtBQUFBLHNCQUg5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSUE7QUFBQSx1QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEscUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMEJBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyx3REFBd0RNLFNBQVNOLEtBQUs7QUFBQTtBQUFBLGtCQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ3dKO0FBQUE7QUFBQTtBQUFBLFlBcEMxSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFzQ0EsS0F2Q1NNLFNBQVNWLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0NBO0FBQUEsUUFDRCxLQTNDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNENBO0FBQUEsUUFDRSx1QkFBQyxTQUFJLFdBQVUsZ0dBQ2pCLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLE9BQUksV0FBVSxrQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDZDQUE0QywwQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxPQUFFLFdBQVUsa0JBQWlCLHFHQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSDtBQUFBLGVBRnJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVSjtBQUFBLFdBbEVBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtRUE7QUFBQSxTQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0VBO0FBQUEsT0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlFQSxLQTFFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkVBO0FBRUo7QUFBRVcsS0EzR0liO0FBNkdOLGVBQWVBO0FBQWEsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5hdmJhciIsIlNpZGViYXIiLCJVc2VycyIsIkJyaWVmY2FzZSIsIkNoZXZyb25SaWdodCIsIlphcCIsIk1kRW1haWwiLCJGYVdoYXRzYXBwIiwiUmlNb25leVJ1cGVlQ2lyY2xlTGluZSIsIkJyZWFkY3J1bWIiLCJEdWVFbWFpbE1lbnUiLCJlbWFpbG1hcmtldGluZ0NhdGVnb3JpZXMiLCJpZCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJpY29uIiwiY29sb3IiLCJsaWdodENvbG9yIiwiYm9yZGVyQ29sb3IiLCJocmVmIiwic3RhdHMiLCJtYXAiLCJjYXRlZ29yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkR1ZUVtYWlsTWVudS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IFVzZXJzLCBCcmllZmNhc2UsIENoZXZyb25SaWdodCxaYXAgIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBNZEVtYWlsIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHAgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgUmlNb25leVJ1cGVlQ2lyY2xlTGluZSB9IGZyb20gXCJyZWFjdC1pY29ucy9yaVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5cclxuXHJcbmNvbnN0IER1ZUVtYWlsTWVudSA9ICgpID0+IHtcclxuICBjb25zdCBlbWFpbG1hcmtldGluZ0NhdGVnb3JpZXMgPSBbXHJcbiAgXHJcbiAgICB7XHJcbiAgICAgIGlkOiAxLFxyXG4gICAgICB0aXRsZTogXCJPdXRzdGFuZGluZyBFbWFpbFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgT3V0c3RhbmRpbmcgRW1haWxcIixcclxuICAgICAgaWNvbjogPE1kRW1haWwgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS9lbWFpbC1tYXJrZXRpbmcvZHVlLWVtYWlsLW1hcmtldGluZy9kdWUtZW1haWxcIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIER1ZSBNYWlsc1wiLFxyXG4gICAgfSxcclxuICAgICB7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICB0aXRsZTogXCJPdXRzdGFuZGluZyBFbWFpbCBbT3Zlcl1cIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIE92ZXIgT3V0c3RhbmRpbmcgRW1haWxcIixcclxuICAgICAgaWNvbjogPE1kRW1haWwgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS9lbWFpbC1tYXJrZXRpbmcvZHVlLWVtYWlsLW1hcmtldGluZy9vdmVyLWR1ZS1lbWFpbFwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgT3ZlciBEdWUgTWFpbHNcIixcclxuICAgIH0sXHJcbiAgIFxyXG4gICAgIFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctZ3JheS01MFwiPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04XCI+XHJcbiAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICBPdXRzdGFuZGluZyBFbWFpbCBNYXJrZXRpbmcgTWFuYWdlbWVudFxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICBNYW5hZ2UgYW5kIG9yZ2FuaXplIHlvdXIgT3V0c3RhbmRpbmcgRW1haWwgTWFya2V0aW5nXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgIHtlbWFpbG1hcmtldGluZ0NhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPExpbmsga2V5PXtjYXRlZ29yeS5pZH0gdG89e2NhdGVnb3J5LmhyZWZ9IGNsYXNzTmFtZT1cImdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBoLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyICR7Y2F0ZWdvcnkuYm9yZGVyQ29sb3J9IHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy0zMiBoLTMyIGJnLWdyYWRpZW50LXRvLWJyICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktNSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwIHJvdW5kZWQtZnVsbCAtbXItMTYgLW10LTE2IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBibHVyLXhsYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtN1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xNCBoLTE0ICR7Y2F0ZWdvcnkubGlnaHRDb2xvcn0gcm91bmRlZC1sZyBtYi01IGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PntjYXRlZ29yeS5pY29ufTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTIgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTk1MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZ3JvdXAtaG92ZXI6Ym9yZGVyLWdyYXktMjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBncm91cC1ob3Zlcjp0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LnN0YXRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2Zvcm0gdHJhbnNsYXRlLXgtMSBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC0wIGxlZnQtMCByaWdodC0wIGgtMC41IGJnLWdyYWRpZW50LXRvLXIgJHtjYXRlZ29yeS5jb2xvcn0gb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTE2IHAtOCBiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MCB0by1pbmRpZ28tNTAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci12aW9sZXQtMTAwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtdmlvbGV0LTYwMCBtdC0xXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi0yXCI+UXVpY2sgVGlwczwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMFwiPk1hbmFnZSBPdXRzYXRuZGluZyBlbWFpbCwgYW5kIG1vcmUgd2l0aCBNYXJrZXRpbmcgTWFuYWdlbWVudOKAlGV2ZXJ5dGhpbmcgaW4gb25lIHBsYWNlLjwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEdWVFbWFpbE1lbnU7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9EdWVFbWFpbE1lbnUuanN4In0=