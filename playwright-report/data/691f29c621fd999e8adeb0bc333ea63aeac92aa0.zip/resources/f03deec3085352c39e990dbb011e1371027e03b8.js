import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeRelationshipManagerReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import api from "/src/instance/TokenInstance.js";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const EmployeeRelationshipManagerReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState({
    totalCustomers: 0,
    totalEnrollments: 0,
    totalOutstanding: 0,
    totalInvestment: 0
  });
  const [formData, setFormData] = useState({
    employee: "",
    customer: "",
    filterType: "Today"
  });
  const hasFetched = useRef(false);
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value || ""
    }));
  };
  const fetchEmployees = async () => {
    try {
      const response = await api.get("/employee/");
      const verifiedEmployees = (response.data?.employee || []).filter((emp) => emp.isVerified);
      setEmployees(verifiedEmployees);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const fetchCustomers = async (employeeId) => {
    try {
      if (!employeeId) {
        setCustomers([]);
        return;
      }
      const response = await api.get("/user/get-user");
      setCustomers(response.data || []);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchCustomers(formData.employee);
  }, [formData.employee]);
  const fetchEmployeeCustomers = useCallback(
    async () => {
      try {
        setLoading(true);
        let data = [];
        if (formData.employee) {
          const response = await api.get(
            `/v1/admin/employees/${formData.employee}/group-relationship-manager`
          );
          data = response.data?.data || [];
        } else {
          const responses = await Promise.all(
            employees.map(
              (emp) => api.get(
                `/v1/admin/employees/${emp._id}/group-relationship-manager`
              )
            )
          );
          data = responses.flatMap(
            (res) => res.data?.data || []
          );
        }
        if (formData.customer) {
          data = data.filter(
            (item) => item.user_id?._id === formData.customer
          );
        }
        setSummary({
          totalCustomers: new Set(
            data.map((item) => item.user_id?._id)
          ).size,
          totalEnrollments: data.length,
          totalOutstanding: data.reduce(
            (sum, item) => sum + (item.total_balance || 0),
            0
          ),
          totalInvestment: data.reduce(
            (sum, item) => sum + (item.total_investment || 0),
            0
          )
        });
        const formatted = data.map((item, index) => ({
          id: item._id,
          slNo: index + 1,
          customerName: item.user_id?.full_name || "-",
          phone: item.user_id?.phone_number || "-",
          group: item.group_id?.group_name || "-",
          tickets: item.tickets || 0,
          installment: item.group_install || 0,
          investment: item.total_investment || 0,
          outstanding: item.total_balance || 0,
          isPrized: item.is_prized === true ? "Prized" : "Not Prized",
          totalProfit: item.total_profit || 0,
          totalPenalty: item.total_penalty || 0,
          totalLateFee: item.total_late_fee || 0,
          status: item.customer_status || "-",
          joinedDate: item.createdAt ? new Date(item.createdAt).toLocaleDateString("en-GB").replace(/\//g, "-") : "-"
        }));
        setReportData(formatted);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    },
    [
      employees,
      formData.employee,
      formData.customer
    ]
  );
  useEffect(() => {
    if (!employees.length) return;
    if (!hasFetched.current) {
      hasFetched.current = true;
      fetchEmployeeCustomers();
    }
  }, [employees, fetchEmployeeCustomers]);
  useEffect(
    () => {
      if (!employees.length) return;
      if (hasFetched.current) {
        fetchEmployeeCustomers();
      }
    },
    [
      formData.employee,
      formData.customer
    ]
  );
  const columns = [
    {
      key: "slNo",
      header: "Sl No"
    },
    {
      key: "status",
      header: "Customer Status"
    },
    {
      key: "isPrized",
      header: "Auction Status"
    },
    {
      key: "joinedDate",
      header: "Joined Date"
    },
    {
      key: "customerName",
      header: "Customer Name"
    },
    {
      key: "phone",
      header: "Phone"
    },
    {
      key: "group",
      header: "Group"
    },
    {
      key: "tickets",
      header: "Ticket"
    },
    {
      key: "installment",
      header: "Group Installment"
    },
    {
      key: "totalProfit",
      header: "Total Profit"
    },
    {
      key: "investment",
      header: "Total Investment"
    },
    {
      key: "totalPenalty",
      header: "Total Penalty"
    },
    {
      key: "totalLateFee",
      header: "Total Late Fee"
    },
    {
      key: "outstanding",
      header: "Balance"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10 overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 min-w-0", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Employee Relationship Manager Report" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
      lineNumber: 278,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Employee" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 284,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-12",
            placeholder: "Select Employee",
            value: formData.employee || void 0,
            onChange: (value) => {
              setFormData((prev) => ({
                ...prev,
                employee: value,
                customer: ""
              }));
            },
            allowClear: true,
            showSearch: true,
            optionFilterProp: "children",
            filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Employees" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
                lineNumber: 306,
                columnNumber: 15
              }, this),
              employees.map(
                (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: emp.name }, emp._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
                  lineNumber: 308,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
            lineNumber: 286,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 283,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 316,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-12",
            placeholder: "All Customers",
            value: formData.customer || void 0,
            onChange: (value) => handleAntDSelect("customer", value),
            allowClear: true,
            showSearch: true,
            optionFilterProp: "children",
            filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
                lineNumber: 332,
                columnNumber: 15
              }, this),
              customers.map(
                (customer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: customer._id, children: customer.full_name }, customer._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
                  lineNumber: 334,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
            lineNumber: 318,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 315,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
      lineNumber: 282,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Customers" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 384,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: summary.totalCustomers }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 385,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 383,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Enrollments" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 389,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: summary.totalEnrollments }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 390,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 388,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Balance" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 394,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: [
          "₹",
          summary.totalOutstanding
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 395,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 393,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Investment" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 399,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: [
          "₹",
          summary.totalInvestment
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
          lineNumber: 400,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 398,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
      lineNumber: 382,
      columnNumber: 9
    }, this),
    reportData.length > 0 && !loading ? /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        columns,
        data: reportData,
        exportedFileName: "Employee Referred Customer Report",
        exportedPdfName: "Employee Referred Customer Report"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 405,
        columnNumber: 9
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      CircularLoader,
      {
        isLoading: loading,
        failure: !loading && reportData.length === 0,
        data: "Employee Referred Customers"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
        lineNumber: 412,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
    lineNumber: 277,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx",
    lineNumber: 276,
    columnNumber: 5
  }, this);
};
_s(EmployeeRelationshipManagerReport, "P67JoSmhOHUjzmish+F/FJ2q2Gs=");
_c = EmployeeRelationshipManagerReport;
export default EmployeeRelationshipManagerReport;
var _c;
$RefreshReg$(_c, "EmployeeRelationshipManagerReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRelationshipManagerReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcVJROzJCQXJSUjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBUUMsc0JBQW1CLGVBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkUsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsY0FBYztBQUV2QixNQUFNQyxvQ0FBb0NBLE1BQU07QUFBQUMsS0FBQTtBQUM5QyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSVosU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2EsV0FBV0MsWUFBWSxJQUFJZCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDZSxZQUFZQyxhQUFhLElBQUloQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDaUIsU0FBU0MsVUFBVSxJQUFJbEIsU0FBUyxLQUFLO0FBRTVDLFFBQU0sQ0FBQ21CLFNBQVNDLFVBQVUsSUFBSXBCLFNBQVM7QUFBQSxJQUNyQ3FCLGdCQUFnQjtBQUFBLElBQ2hCQyxrQkFBa0I7QUFBQSxJQUNsQkMsa0JBQWtCO0FBQUEsSUFDbEJDLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSTFCLFNBQVM7QUFBQSxJQUN2QzJCLFVBQVU7QUFBQSxJQUNWQyxVQUFVO0FBQUEsSUFDVkMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU1DLGFBQWE3QixPQUFPLEtBQUs7QUFFL0IsUUFBTThCLG1CQUFtQkEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN6Q1AsZ0JBQVksQ0FBQ1EsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHQyxTQUFTO0FBQUEsSUFDcEIsRUFBRTtBQUFBLEVBQ0o7QUFLQSxRQUFNRSxpQkFBaUIsWUFBWTtBQUNqQyxRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNN0IsSUFBSThCLElBQUksWUFBWTtBQUUzQyxZQUFNQyxxQkFDSkYsU0FBU0csTUFBTVosWUFBWSxJQUMzQmEsT0FBTyxDQUFDQyxRQUFRQSxJQUFJQyxVQUFVO0FBRWhDOUIsbUJBQWEwQixpQkFBaUI7QUFBQSxJQUNoQyxTQUFTSyxPQUFPO0FBQ2RDLGNBQVFDLElBQUlGLEtBQUs7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQTVDLFlBQVUsTUFBTTtBQUNkb0MsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFLTCxRQUFNVyxpQkFBaUIsT0FBT0MsZUFBZTtBQUMzQyxRQUFJO0FBQ0YsVUFBSSxDQUFDQSxZQUFZO0FBQ2ZqQyxxQkFBYSxFQUFFO0FBQ2Y7QUFBQSxNQUNGO0FBRUEsWUFBTXNCLFdBQVcsTUFBTTdCLElBQUk4QixJQUFJLGdCQUFnQjtBQUUvQ3ZCLG1CQUFhc0IsU0FBU0csUUFBUSxFQUFFO0FBQUEsSUFDbEMsU0FBU0ksT0FBTztBQUNkQyxjQUFRQyxJQUFJRixLQUFLO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUE1QyxZQUFVLE1BQU07QUFDZCtDLG1CQUFlckIsU0FBU0UsUUFBUTtBQUFBLEVBQ2xDLEdBQUcsQ0FBQ0YsU0FBU0UsUUFBUSxDQUFDO0FBS3RCLFFBQU1xQix5QkFBeUI5QztBQUFBQSxJQUFZLFlBQVk7QUFDckQsVUFBSTtBQUNGZ0IsbUJBQVcsSUFBSTtBQUVmLFlBQUlxQixPQUFPO0FBRVgsWUFBSWQsU0FBU0UsVUFBVTtBQUNyQixnQkFBTVMsV0FBVyxNQUFNN0IsSUFBSThCO0FBQUFBLFlBQ3pCLHVCQUF1QlosU0FBU0UsUUFBUTtBQUFBLFVBQzFDO0FBRUFZLGlCQUFPSCxTQUFTRyxNQUFNQSxRQUFRO0FBQUEsUUFDaEMsT0FBTztBQUNMLGdCQUFNVSxZQUFZLE1BQU1DLFFBQVFDO0FBQUFBLFlBQzlCeEMsVUFBVXlDO0FBQUFBLGNBQUksQ0FBQ1gsUUFDYmxDLElBQUk4QjtBQUFBQSxnQkFDRix1QkFBdUJJLElBQUlZLEdBQUc7QUFBQSxjQUNoQztBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBRUFkLGlCQUFPVSxVQUFVSztBQUFBQSxZQUNmLENBQUNDLFFBQVFBLElBQUloQixNQUFNQSxRQUFRO0FBQUEsVUFDN0I7QUFBQSxRQUNGO0FBR0EsWUFBSWQsU0FBU0csVUFBVTtBQUNyQlcsaUJBQU9BLEtBQUtDO0FBQUFBLFlBQ1YsQ0FBQ2dCLFNBQ0NBLEtBQUtDLFNBQVNKLFFBQVE1QixTQUFTRztBQUFBQSxVQUNuQztBQUFBLFFBQ0Y7QUFFQVIsbUJBQVc7QUFBQSxVQUNUQyxnQkFBZ0IsSUFBSXFDO0FBQUFBLFlBQ2xCbkIsS0FBS2EsSUFBSSxDQUFDSSxTQUFTQSxLQUFLQyxTQUFTSixHQUFHO0FBQUEsVUFDdEMsRUFBRU07QUFBQUEsVUFFRnJDLGtCQUFrQmlCLEtBQUtxQjtBQUFBQSxVQUV2QnJDLGtCQUFrQmdCLEtBQUtzQjtBQUFBQSxZQUNyQixDQUFDQyxLQUFLTixTQUNKTSxPQUFPTixLQUFLTyxpQkFBaUI7QUFBQSxZQUMvQjtBQUFBLFVBQ0Y7QUFBQSxVQUVBdkMsaUJBQWlCZSxLQUFLc0I7QUFBQUEsWUFDcEIsQ0FBQ0MsS0FBS04sU0FDSk0sT0FBT04sS0FBS1Esb0JBQW9CO0FBQUEsWUFDbEM7QUFBQSxVQUNGO0FBQUEsUUFDRixDQUFDO0FBRUQsY0FBTUMsWUFBWTFCLEtBQUthLElBQUksQ0FBQ0ksTUFBTVUsV0FBVztBQUFBLFVBQzNDQyxJQUFJWCxLQUFLSDtBQUFBQSxVQUNUZSxNQUFNRixRQUFRO0FBQUEsVUFDZEcsY0FDRWIsS0FBS0MsU0FBU2EsYUFBYTtBQUFBLFVBQzdCQyxPQUNFZixLQUFLQyxTQUFTZSxnQkFBZ0I7QUFBQSxVQUNoQ0MsT0FDRWpCLEtBQUtrQixVQUFVQyxjQUFjO0FBQUEsVUFDL0JDLFNBQVNwQixLQUFLb0IsV0FBVztBQUFBLFVBQ3pCQyxhQUNFckIsS0FBS3NCLGlCQUFpQjtBQUFBLFVBQ3hCQyxZQUNFdkIsS0FBS1Esb0JBQW9CO0FBQUEsVUFDM0JnQixhQUNFeEIsS0FBS08saUJBQWlCO0FBQUEsVUFFeEJrQixVQUNFekIsS0FBSzBCLGNBQWMsT0FDZixXQUNBO0FBQUEsVUFFTkMsYUFDRTNCLEtBQUs0QixnQkFBZ0I7QUFBQSxVQUV2QkMsY0FDRTdCLEtBQUs4QixpQkFBaUI7QUFBQSxVQUV4QkMsY0FDRS9CLEtBQUtnQyxrQkFBa0I7QUFBQSxVQUV6QkMsUUFDRWpDLEtBQUtrQyxtQkFBbUI7QUFBQSxVQUUxQkMsWUFBWW5DLEtBQUtvQyxZQUNiLElBQUlDLEtBQUtyQyxLQUFLb0MsU0FBUyxFQUNwQkUsbUJBQW1CLE9BQU8sRUFDMUJDLFFBQVEsT0FBTyxHQUFHLElBQ3JCO0FBQUEsUUFDTixFQUFFO0FBRUYvRSxzQkFBY2lELFNBQVM7QUFBQSxNQUN6QixTQUFTdEIsT0FBTztBQUNkQyxnQkFBUUMsSUFBSUYsS0FBSztBQUFBLE1BQ25CLFVBQUM7QUFDQ3pCLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFBQSxJQUFHO0FBQUEsTUFDRFA7QUFBQUEsTUFDQWMsU0FBU0U7QUFBQUEsTUFDVEYsU0FBU0c7QUFBQUEsSUFBUTtBQUFBLEVBQ2xCO0FBS0Q3QixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNZLFVBQVVpRCxPQUFRO0FBR3ZCLFFBQUksQ0FBQzlCLFdBQVdrRSxTQUFTO0FBQ3ZCbEUsaUJBQVdrRSxVQUFVO0FBQ3JCaEQsNkJBQXVCO0FBQUEsSUFDekI7QUFBQSxFQUNGLEdBQUcsQ0FBQ3JDLFdBQVdxQyxzQkFBc0IsQ0FBQztBQUd0Q2pEO0FBQUFBLElBQVUsTUFBTTtBQUNkLFVBQUksQ0FBQ1ksVUFBVWlELE9BQVE7QUFFdkIsVUFBSTlCLFdBQVdrRSxTQUFTO0FBQ3RCaEQsK0JBQXVCO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQUEsSUFBRztBQUFBLE1BQ0R2QixTQUFTRTtBQUFBQSxNQUNURixTQUFTRztBQUFBQSxJQUFRO0FBQUEsRUFDbEI7QUFFQyxRQUFNcUUsVUFBVTtBQUFBLElBQ2hCO0FBQUEsTUFDRUMsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0E7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0E7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0E7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFFQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0E7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLEVBQUM7QUFHRCxTQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYixpQ0FBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsK0JBQThCLG9EQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHNCQUFxQix3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFFBRTlDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixhQUFZO0FBQUEsWUFDWixPQUFPMUUsU0FBU0UsWUFBWXlFO0FBQUFBLFlBQzVCLFVBQVUsQ0FBQ25FLFVBQVU7QUFDbkJQLDBCQUFZLENBQUNRLFVBQVU7QUFBQSxnQkFDckIsR0FBR0E7QUFBQUEsZ0JBQ0hQLFVBQVVNO0FBQUFBLGdCQUNWTCxVQUFVO0FBQUEsY0FDWixFQUFFO0FBQUEsWUFDSjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQSxrQkFBaUI7QUFBQSxZQUNqQixjQUFjLENBQUN5RSxPQUFPQyxZQUNuQkEsUUFBUUMsWUFBWSxJQUNsQkMsWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxZQUdqQztBQUFBLHFDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNwQzdGLFVBQVV5QztBQUFBQSxnQkFBSSxDQUFDWCxRQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxJQUFJWSxLQUNyQ1osY0FBSWlFLFFBRGFqRSxJQUFJWSxLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUE7QUFBQSxVQXpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUEwQkE7QUFBQSxXQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxzQkFBcUIsd0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUU5QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBLFlBQ1osT0FBTzVCLFNBQVNHLFlBQVl3RTtBQUFBQSxZQUM1QixVQUFVLENBQUNuRSxVQUFVRixpQkFBaUIsWUFBWUUsS0FBSztBQUFBLFlBQ3ZEO0FBQUEsWUFDQTtBQUFBLFlBQ0Esa0JBQWlCO0FBQUEsWUFDakIsY0FBYyxDQUFDb0UsT0FBT0MsWUFDbkJBLFFBQVFDLFlBQVksSUFDbEJDLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsWUFHakM7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsY0FDcEMzRixVQUFVdUM7QUFBQUEsZ0JBQUksQ0FBQ3hCLGFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLFNBQVN5QixLQUMvQ3pCLG1CQUFTMEMsYUFEUTFDLFNBQVN5QixLQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUE7QUFBQSxVQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQkE7QUFBQSxXQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsU0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBEQTtBQUFBLElBMENBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLE9BQUUsK0JBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQjtBQUFBLFFBQ2xCLHVCQUFDLFFBQUlsQyxrQkFBUUUsa0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFdBRjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsK0JBQUMsT0FBRSxpQ0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsUUFDcEIsdUJBQUMsUUFBSUYsa0JBQVFHLG9CQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxXQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLCtCQUFDLE9BQUUsNkJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQjtBQUFBLFFBQ2hCLHVCQUFDLFFBQUc7QUFBQTtBQUFBLFVBQUVILFFBQVFJO0FBQUFBLGFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFdBRmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsT0FBRSxnQ0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CO0FBQUEsUUFDbkIsdUJBQUMsUUFBRztBQUFBO0FBQUEsVUFBRUosUUFBUUs7QUFBQUEsYUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsV0FGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBRUNULFdBQVc2QyxTQUFTLEtBQUssQ0FBQzNDLFVBQ3pCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsTUFBTUY7QUFBQUEsUUFDTixrQkFBaUI7QUFBQSxRQUNqQixpQkFBZ0I7QUFBQTtBQUFBLE1BSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlxRCxJQUdyRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV0U7QUFBQUEsUUFDWCxTQUFTLENBQUNBLFdBQVdGLFdBQVc2QyxXQUFXO0FBQUEsUUFDM0MsTUFBSztBQUFBO0FBQUEsTUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHb0M7QUFBQSxPQTFJeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZJQSxLQTlJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0lBO0FBR0o7QUFBRWxELEdBN1pJRCxtQ0FBaUM7QUFBQWtHLEtBQWpDbEc7QUFnYU4sZUFBZUE7QUFBa0MsSUFBQWtHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZVJlZiIsInVzZUNhbGxiYWNrIiwiTmF2YmFyIiwiU2lkZWJhciIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiYXBpIiwiU2VsZWN0IiwiRW1wbG95ZWVSZWxhdGlvbnNoaXBNYW5hZ2VyUmVwb3J0IiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJjdXN0b21lcnMiLCJzZXRDdXN0b21lcnMiLCJyZXBvcnREYXRhIiwic2V0UmVwb3J0RGF0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic3VtbWFyeSIsInNldFN1bW1hcnkiLCJ0b3RhbEN1c3RvbWVycyIsInRvdGFsRW5yb2xsbWVudHMiLCJ0b3RhbE91dHN0YW5kaW5nIiwidG90YWxJbnZlc3RtZW50IiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImVtcGxveWVlIiwiY3VzdG9tZXIiLCJmaWx0ZXJUeXBlIiwiaGFzRmV0Y2hlZCIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInZhbHVlIiwicHJldiIsImZldGNoRW1wbG95ZWVzIiwicmVzcG9uc2UiLCJnZXQiLCJ2ZXJpZmllZEVtcGxveWVlcyIsImRhdGEiLCJmaWx0ZXIiLCJlbXAiLCJpc1ZlcmlmaWVkIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwiZmV0Y2hDdXN0b21lcnMiLCJlbXBsb3llZUlkIiwiZmV0Y2hFbXBsb3llZUN1c3RvbWVycyIsInJlc3BvbnNlcyIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJfaWQiLCJmbGF0TWFwIiwicmVzIiwiaXRlbSIsInVzZXJfaWQiLCJTZXQiLCJzaXplIiwibGVuZ3RoIiwicmVkdWNlIiwic3VtIiwidG90YWxfYmFsYW5jZSIsInRvdGFsX2ludmVzdG1lbnQiLCJmb3JtYXR0ZWQiLCJpbmRleCIsImlkIiwic2xObyIsImN1c3RvbWVyTmFtZSIsImZ1bGxfbmFtZSIsInBob25lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXAiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXRzIiwiaW5zdGFsbG1lbnQiLCJncm91cF9pbnN0YWxsIiwiaW52ZXN0bWVudCIsIm91dHN0YW5kaW5nIiwiaXNQcml6ZWQiLCJpc19wcml6ZWQiLCJ0b3RhbFByb2ZpdCIsInRvdGFsX3Byb2ZpdCIsInRvdGFsUGVuYWx0eSIsInRvdGFsX3BlbmFsdHkiLCJ0b3RhbExhdGVGZWUiLCJ0b3RhbF9sYXRlX2ZlZSIsInN0YXR1cyIsImN1c3RvbWVyX3N0YXR1cyIsImpvaW5lZERhdGUiLCJjcmVhdGVkQXQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwicmVwbGFjZSIsImN1cnJlbnQiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRW1wbG95ZWVSZWxhdGlvbnNoaXBNYW5hZ2VyUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VDYWxsYmFjayB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmNvbnN0IEVtcGxveWVlUmVsYXRpb25zaGlwTWFuYWdlclJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXN0b21lcnMsIHNldEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3JlcG9ydERhdGEsIHNldFJlcG9ydERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW3N1bW1hcnksIHNldFN1bW1hcnldID0gdXNlU3RhdGUoe1xyXG4gICAgdG90YWxDdXN0b21lcnM6IDAsXHJcbiAgICB0b3RhbEVucm9sbG1lbnRzOiAwLFxyXG4gICAgdG90YWxPdXRzdGFuZGluZzogMCxcclxuICAgIHRvdGFsSW52ZXN0bWVudDogMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBlbXBsb3llZTogXCJcIixcclxuICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgZmlsdGVyVHlwZTogXCJUb2RheVwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBoYXNGZXRjaGVkID0gdXNlUmVmKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSB8fCBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gRkVUQ0ggRU1QTE9ZRUVTXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZS9cIik7XHJcblxyXG4gICAgICBjb25zdCB2ZXJpZmllZEVtcGxveWVlcyA9IChcclxuICAgICAgICByZXNwb25zZS5kYXRhPy5lbXBsb3llZSB8fCBbXVxyXG4gICAgICApLmZpbHRlcigoZW1wKSA9PiBlbXAuaXNWZXJpZmllZCk7XHJcblxyXG4gICAgICBzZXRFbXBsb3llZXModmVyaWZpZWRFbXBsb3llZXMpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBGRVRDSCBDVVNUT01FUlNcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJzID0gYXN5bmMgKGVtcGxveWVlSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmICghZW1wbG95ZWVJZCkge1xyXG4gICAgICAgIHNldEN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuXHJcbiAgICAgIHNldEN1c3RvbWVycyhyZXNwb25zZS5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hDdXN0b21lcnMoZm9ybURhdGEuZW1wbG95ZWUpO1xyXG4gIH0sIFtmb3JtRGF0YS5lbXBsb3llZV0pO1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIEZFVENIIFJFUE9SVFxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZUN1c3RvbWVycyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBsZXQgZGF0YSA9IFtdO1xyXG5cclxuICAgICAgaWYgKGZvcm1EYXRhLmVtcGxveWVlKSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC92MS9hZG1pbi9lbXBsb3llZXMvJHtmb3JtRGF0YS5lbXBsb3llZX0vZ3JvdXAtcmVsYXRpb25zaGlwLW1hbmFnZXJgXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgZGF0YSA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW107XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2VzID0gYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICBlbXBsb3llZXMubWFwKChlbXApID0+XHJcbiAgICAgICAgICAgIGFwaS5nZXQoXHJcbiAgICAgICAgICAgICAgYC92MS9hZG1pbi9lbXBsb3llZXMvJHtlbXAuX2lkfS9ncm91cC1yZWxhdGlvbnNoaXAtbWFuYWdlcmBcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGRhdGEgPSByZXNwb25zZXMuZmxhdE1hcChcclxuICAgICAgICAgIChyZXMpID0+IHJlcy5kYXRhPy5kYXRhIHx8IFtdXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gY3VzdG9tZXIgZmlsdGVyXHJcbiAgICAgIGlmIChmb3JtRGF0YS5jdXN0b21lcikge1xyXG4gICAgICAgIGRhdGEgPSBkYXRhLmZpbHRlcihcclxuICAgICAgICAgIChpdGVtKSA9PlxyXG4gICAgICAgICAgICBpdGVtLnVzZXJfaWQ/Ll9pZCA9PT0gZm9ybURhdGEuY3VzdG9tZXJcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgICB0b3RhbEN1c3RvbWVyczogbmV3IFNldChcclxuICAgICAgICAgIGRhdGEubWFwKChpdGVtKSA9PiBpdGVtLnVzZXJfaWQ/Ll9pZClcclxuICAgICAgICApLnNpemUsXHJcblxyXG4gICAgICAgIHRvdGFsRW5yb2xsbWVudHM6IGRhdGEubGVuZ3RoLFxyXG5cclxuICAgICAgICB0b3RhbE91dHN0YW5kaW5nOiBkYXRhLnJlZHVjZShcclxuICAgICAgICAgIChzdW0sIGl0ZW0pID0+XHJcbiAgICAgICAgICAgIHN1bSArIChpdGVtLnRvdGFsX2JhbGFuY2UgfHwgMCksXHJcbiAgICAgICAgICAwXHJcbiAgICAgICAgKSxcclxuXHJcbiAgICAgICAgdG90YWxJbnZlc3RtZW50OiBkYXRhLnJlZHVjZShcclxuICAgICAgICAgIChzdW0sIGl0ZW0pID0+XHJcbiAgICAgICAgICAgIHN1bSArIChpdGVtLnRvdGFsX2ludmVzdG1lbnQgfHwgMCksXHJcbiAgICAgICAgICAwXHJcbiAgICAgICAgKSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBkYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICBjdXN0b21lck5hbWU6XHJcbiAgICAgICAgICBpdGVtLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICBwaG9uZTpcclxuICAgICAgICAgIGl0ZW0udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgIGdyb3VwOlxyXG4gICAgICAgICAgaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICB0aWNrZXRzOiBpdGVtLnRpY2tldHMgfHwgMCxcclxuICAgICAgICBpbnN0YWxsbWVudDpcclxuICAgICAgICAgIGl0ZW0uZ3JvdXBfaW5zdGFsbCB8fCAwLFxyXG4gICAgICAgIGludmVzdG1lbnQ6XHJcbiAgICAgICAgICBpdGVtLnRvdGFsX2ludmVzdG1lbnQgfHwgMCxcclxuICAgICAgICBvdXRzdGFuZGluZzpcclxuICAgICAgICAgIGl0ZW0udG90YWxfYmFsYW5jZSB8fCAwLFxyXG5cclxuICAgICAgICBpc1ByaXplZDpcclxuICAgICAgICAgIGl0ZW0uaXNfcHJpemVkID09PSB0cnVlXHJcbiAgICAgICAgICAgID8gXCJQcml6ZWRcIlxyXG4gICAgICAgICAgICA6IFwiTm90IFByaXplZFwiLFxyXG5cclxuICAgICAgICB0b3RhbFByb2ZpdDpcclxuICAgICAgICAgIGl0ZW0udG90YWxfcHJvZml0IHx8IDAsXHJcblxyXG4gICAgICAgIHRvdGFsUGVuYWx0eTpcclxuICAgICAgICAgIGl0ZW0udG90YWxfcGVuYWx0eSB8fCAwLFxyXG5cclxuICAgICAgICB0b3RhbExhdGVGZWU6XHJcbiAgICAgICAgICBpdGVtLnRvdGFsX2xhdGVfZmVlIHx8IDAsXHJcblxyXG4gICAgICAgIHN0YXR1czpcclxuICAgICAgICAgIGl0ZW0uY3VzdG9tZXJfc3RhdHVzIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICBqb2luZWREYXRlOiBpdGVtLmNyZWF0ZWRBdFxyXG4gICAgICAgICAgPyBuZXcgRGF0ZShpdGVtLmNyZWF0ZWRBdClcclxuICAgICAgICAgICAgICAudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgICAucmVwbGFjZSgvXFwvL2csIFwiLVwiKVxyXG4gICAgICAgICAgOiBcIi1cIixcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0UmVwb3J0RGF0YShmb3JtYXR0ZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW1xyXG4gICAgZW1wbG95ZWVzLFxyXG4gICAgZm9ybURhdGEuZW1wbG95ZWUsXHJcbiAgICBmb3JtRGF0YS5jdXN0b21lcixcclxuICBdKTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBDQUxMIFJFUE9SVCBBUElcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIWVtcGxveWVlcy5sZW5ndGgpIHJldHVybjtcclxuXHJcbiAgICAvLyBQcmV2ZW50IGR1cGxpY2F0ZSBjYWxsIGluIFJlYWN0IFN0cmljdE1vZGVcclxuICAgIGlmICghaGFzRmV0Y2hlZC5jdXJyZW50KSB7XHJcbiAgICAgIGhhc0ZldGNoZWQuY3VycmVudCA9IHRydWU7XHJcbiAgICAgIGZldGNoRW1wbG95ZWVDdXN0b21lcnMoKTtcclxuICAgIH1cclxuICB9LCBbZW1wbG95ZWVzLCBmZXRjaEVtcGxveWVlQ3VzdG9tZXJzXSk7XHJcblxyXG4gIC8vIEVtcGxveWVlIGNoYW5nZWRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFlbXBsb3llZXMubGVuZ3RoKSByZXR1cm47XHJcblxyXG4gICAgaWYgKGhhc0ZldGNoZWQuY3VycmVudCkge1xyXG4gICAgICBmZXRjaEVtcGxveWVlQ3VzdG9tZXJzKCk7XHJcbiAgICB9XHJcbiAgfSwgW1xyXG4gICAgZm9ybURhdGEuZW1wbG95ZWUsXHJcbiAgICBmb3JtRGF0YS5jdXN0b21lcixcclxuICBdKTtcclxuXHJcbiAgICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAge1xyXG4gICAgICBrZXk6IFwic2xOb1wiLFxyXG4gICAgICBoZWFkZXI6IFwiU2wgTm9cIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJzdGF0dXNcIixcclxuICAgICAgaGVhZGVyOiBcIkN1c3RvbWVyIFN0YXR1c1wiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcImlzUHJpemVkXCIsXHJcbiAgICAgIGhlYWRlcjogXCJBdWN0aW9uIFN0YXR1c1wiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcImpvaW5lZERhdGVcIixcclxuICAgICAgaGVhZGVyOiBcIkpvaW5lZCBEYXRlXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiY3VzdG9tZXJOYW1lXCIsXHJcbiAgICAgIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwicGhvbmVcIixcclxuICAgICAgaGVhZGVyOiBcIlBob25lXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiZ3JvdXBcIixcclxuICAgICAgaGVhZGVyOiBcIkdyb3VwXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidGlja2V0c1wiLFxyXG4gICAgICBoZWFkZXI6IFwiVGlja2V0XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiaW5zdGFsbG1lbnRcIixcclxuICAgICAgaGVhZGVyOiBcIkdyb3VwIEluc3RhbGxtZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidG90YWxQcm9maXRcIixcclxuICAgICAgaGVhZGVyOiBcIlRvdGFsIFByb2ZpdFwiLFxyXG4gICAgfSxcclxuXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJpbnZlc3RtZW50XCIsXHJcbiAgICAgIGhlYWRlcjogXCJUb3RhbCBJbnZlc3RtZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidG90YWxQZW5hbHR5XCIsXHJcbiAgICAgIGhlYWRlcjogXCJUb3RhbCBQZW5hbHR5XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidG90YWxMYXRlRmVlXCIsXHJcbiAgICAgIGhlYWRlcjogXCJUb3RhbCBMYXRlIEZlZVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIm91dHN0YW5kaW5nXCIsXHJcbiAgICAgIGhlYWRlcjogXCJCYWxhbmNlXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0xMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IG1pbi13LTBcIj5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbiAgICAgICAgICBFbXBsb3llZSBSZWxhdGlvbnNoaXAgTWFuYWdlciBSZXBvcnRcclxuICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvM1wiPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtXCI+RW1wbG95ZWU8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgZW1wbG95ZWU6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcjogXCJcIixcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgRW1wbG95ZWVzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvM1wiPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtXCI+Q3VzdG9tZXI8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcImN1c3RvbWVyXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgIChvcHRpb24/LmNoaWxkcmVuID8/IFwiXCIpXHJcbiAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIEN1c3RvbWVyczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICB7Y3VzdG9tZXJzLm1hcCgoY3VzdG9tZXIpID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Y3VzdG9tZXIuX2lkfSB2YWx1ZT17Y3VzdG9tZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAge2N1c3RvbWVyLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgICAgICBGcm9tIERhdGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcC0yXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRGcm9tRGF0ZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgICAgICAgVG8gRGF0ZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBwLTJcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZFRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRvRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZVxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfSAqL31cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgcC00IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgPHA+VG90YWwgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICAgICAgICA8aDI+e3N1bW1hcnkudG90YWxDdXN0b21lcnN9PC9oMj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgIDxwPlRvdGFsIEVucm9sbG1lbnRzPC9wPlxyXG4gICAgICAgICAgICA8aDI+e3N1bW1hcnkudG90YWxFbnJvbGxtZW50c308L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgIDxwPlRvdGFsIEJhbGFuY2U8L3A+XHJcbiAgICAgICAgICAgIDxoMj7igrl7c3VtbWFyeS50b3RhbE91dHN0YW5kaW5nfTwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXllbGxvdy0xMDAgcC00IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgPHA+VG90YWwgSW52ZXN0bWVudDwvcD5cclxuICAgICAgICAgICAgPGgyPuKCuXtzdW1tYXJ5LnRvdGFsSW52ZXN0bWVudH08L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtyZXBvcnREYXRhLmxlbmd0aCA+IDAgJiYgIWxvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgIGRhdGE9e3JlcG9ydERhdGF9XHJcbiAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJFbXBsb3llZSBSZWZlcnJlZCBDdXN0b21lciBSZXBvcnRcIlxyXG4gICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJFbXBsb3llZSBSZWZlcnJlZCBDdXN0b21lciBSZXBvcnRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgIGlzTG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgZmFpbHVyZT17IWxvYWRpbmcgJiYgcmVwb3J0RGF0YS5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgIGRhdGE9XCJFbXBsb3llZSBSZWZlcnJlZCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcblxyXG59O1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVtcGxveWVlUmVsYXRpb25zaGlwTWFuYWdlclJlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW1wbG95ZWVSZWxhdGlvbnNoaXBNYW5hZ2VyUmVwb3J0LmpzeCJ9