import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EnrollmentRequestForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
const EnrollmentRequestForm = () => {
  _s();
  const [selectedGroup, setSelectedGroup] = useState("");
  const [searchParams] = useSearchParams();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [step, setStep] = useState(1);
  const [districts, setDistricts] = useState([]);
  const [errors, setErrors] = useState({});
  const [enrollData, setEnrollData] = useState({
    selected_plan: "",
    title: "",
    full_name: "",
    password: "",
    gender: "",
    marital_status: "",
    dateofbirth: null,
    nationality: "",
    village: "",
    taluk: "",
    father_name: "",
    district: "",
    state: "",
    phone_number: "",
    alternate_number: "",
    referral_name: "",
    address: "",
    area: "",
    email: "",
    pincode: "",
    nominee_name: "",
    nominee_dateofbirth: null,
    nominee_phone_number: "",
    nominee_relationship: "",
    adhaar_no: "",
    pan_no: "",
    aadhar_frontphoto: "null",
    aadhar_backphoto: "null",
    pan_frontphoto: "null",
    pan_backphoto: "null",
    profilephoto: "null",
    bank_name: "",
    bank_branch_name: "",
    bank_account_number: "",
    bank_IFSC_code: "",
    customer_status: "inactive",
    track_source: "enrollment_form"
  });
  useEffect(() => {
    const fetchSelectedGroup = async () => {
      try {
        const group_id = searchParams.get("group_id");
        const res = await api.get(`group/get-by-id-group/${group_id}`);
        const data = res.data;
        setSelectedGroup(data);
      } catch (err) {
        console.error("failed to fetch group", err);
      }
    };
    fetchSelectedGroup();
  }, []);
  useEffect(() => {
    const fetchDistricts = async () => {
      try {
        const response = await api.get("/user/district");
        setDistricts(response.data?.data?.districts);
      } catch (error) {
        console.error("Error fetching districts:", error);
      }
    };
    fetchDistricts();
  }, []);
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addEnrollCustomer" ? enrollData : null;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      pincode: /^\d{6}$/,
      adhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
    };
    if (!data.first_name.trim()) {
      newErrors.full_name = "Full Name is required";
    }
    if (data.email && !regex.email.test(data.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!data.phone_number) {
      newErrors.phone_number = "Phone number is required";
    } else if (!regex.phone.test(data.phone_number)) {
      newErrors.phone_number = "Invalid  phone number";
    }
    if (!data.password) {
      newErrors.password = "Password is required";
    }
    if (!data.pincode) {
      newErrors.pincode = "Pincode is required";
    } else if (!regex.pincode.test(data.pincode)) {
      newErrors.pincode = "Invalid pincode (6 digits required)";
    }
    if (!data.adhaar_no) {
      newErrors.adhaar_no = "Aadhar number is required";
    } else if (!regex.adhaar.test(data.adhaar_no)) {
      newErrors.adhaar_no = "Invalid Aadhar number (12 digits required)";
    }
    if (data.pan_no && !regex.pan.test(data.pan_no.toUpperCase())) {
      newErrors.pan_no = "Invalid PAN format (e.g., ABCDE1234F)";
    }
    if (!data.address.trim()) {
      newErrors.address = "Address is required";
    } else if (data.address.trim().length < 3) {
      newErrors.address = "Address should be at least 3 characters";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    setEnrollData({ ...enrollData, [e.target.name]: e.target.value });
  };
  const handleFileChange = (e) => {
    setEnrollData({ ...enrollData, [e.target.name]: e.target.files[0] });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const fullName = `${enrollData.first_name || ""} ${enrollData.last_name || ""}`.trim();
    const fullNameEnrollData = { ...enrollData, full_name: fullName };
    const isValid = validateForm("addEnrollCustomer");
    if (isValid) {
      try {
        const url = `user/add-enrollment-request-data`;
        const enrollDataObj = new FormData();
        const { selected_plan, ...restEnrollData } = fullNameEnrollData;
        Object.entries(restEnrollData).forEach(([key, value]) => {
          if (value !== null && value !== void 0) {
            enrollDataObj.append(key, value);
          }
        });
        if (selectedGroup && selectedGroup._id && selectedGroup.group_name && selectedGroup.group_value && selectedGroup.group_install && selectedGroup.group_duration)
          enrollDataObj.append("selected_plan", selectedGroup._id);
        const config = {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        };
        const response = await api.post(url, enrollDataObj, config);
        setIsSubmitted(true);
        alert("Enrollment successful!");
      } catch (error) {
        console.error("Error submitting enrollment:", error);
        alert("Failed to submit enrollment. Please try again.");
      }
    }
  };
  if (isSubmitted) {
    return /* @__PURE__ */ jsxDEV("div", { className: "border-2  mx-auto bg-white rounded-lg shadow-md overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 flex flex-col items-center space-y-4", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-medium text-gray-900", children: "Thank You!" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 203,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-center", children: "Your enrollment was successful. We're excited to have you on board!" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 205,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "https://maps.app.goo.gl/X7FezFRPiTjuYoVt5", children: /* @__PURE__ */ jsxDEV("button", { className: "mt-4 px-6 py-2 bg-violet-600 text-white font-semibold rounded hover:bg-violet-700 focus:outline-none focus:ring-2 focus:ring-violet-300 transition", children: "Our Location" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 210,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 209,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
      lineNumber: 202,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
      lineNumber: 201,
      columnNumber: 7
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-md shadow-2xl sm:my-10 sm:mx-64", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "m-3 mt-3 p-4 text-xl sm:text-4xl font-bold rounded-md text-amber-50 bg-custom-violet", children: /* @__PURE__ */ jsxDEV("h2", { children: " Chit Enrollment Form " }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 222,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 221,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "m-4", children: /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-left text-white sm:text-lg text-sm font-semibold mt-6", children: "Change Chit Plan" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 227,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-left  sm:text-lg text-sm font-semibold ", children: "Group Name" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 230,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            disabled: true,
            className: "w-full p-2 border border-gray-300 rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50  focus:ring-violet-500  focus:border-violet-500 cursor-not-allowed",
            children: /* @__PURE__ */ jsxDEV("option", { value: selectedGroup?._id, className: "text-gray-600", children: selectedGroup?.group_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 237,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 233,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-left  sm:text-lg text-sm font-semibold ", children: "Group Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 244,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "w-full p-2 border border-gray-300 bg-gray-50 rounded-md mb-4 mt-1 sm:text-lg text-sm  text-gray-600 focus:ring-violet-500  focus:border-violet-500 cursor-not-allowed",
                name: "",
                type: "text",
                placeholder: "",
                value: `${selectedGroup?.group_type?.charAt(0)?.toUpperCase() + selectedGroup?.group_type?.slice(1)} Group` || "",
                disabled: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 247,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 243,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "Group Value" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 262,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "w-full p-2 border  border-gray-300 rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 text-gray-600 focus:ring-violet-500  focus:border-violet-500 hover:cursor-not-allowed",
                name: "",
                type: "text",
                placeholder: "50000 ",
                value: selectedGroup?.group_value || "",
                disabled: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 265,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 261,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 242,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Group Installment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 278,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-600 focus:ring-violet-500  focus:border-violet-500 hover:cursor-not-allowed",
                name: "",
                type: "text",
                placeholder: "400 ",
                value: selectedGroup?.group_install || "",
                disabled: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 281,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 277,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "Group Duration" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 291,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-600 focus:ring-violet-500  focus:border-violet-500 hover:cursor-not-allowed",
                name: "",
                type: "text",
                placeholder: "13.2 ",
                value: selectedGroup?.group_duration || "",
                disabled: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 294,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 290,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 276,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 226,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 225,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-[#4c107e] rounded-md m-3 ", children: /* @__PURE__ */ jsxDEV("h2", { className: "p-4 text-left text-white rounded-md font-bold text-xl bg-custom-violet ", children: [
          " ",
          "Customer Details"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 309,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 308,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "m-4", children: /* @__PURE__ */ jsxDEV(Fragment, { children: [
          step === 1 && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex  gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/6 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Title" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 321,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "title",
                    value: enrollData?.title,
                    onChange: handleChange,
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select " }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 330,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Mr", children: "Mr" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 331,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Ms", children: "Ms" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 332,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Mrs", children: "Mrs" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 333,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "M/S", children: "Mrs" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 334,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Dr", children: "Dr" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 335,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 324,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 320,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "First Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 339,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "bg-gray-50 w-full p-2 rounded-lg mb-4 mt-1 sm:text-lg text-sm  border border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "first_name",
                    type: "text",
                    required: true,
                    placeholder: "Enter First Name",
                    value: enrollData?.first_name || "",
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 342,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 338,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Last Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 353,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "bg-gray-50 w-full p-2 rounded-lg mb-4 mt-1 sm:text-lg text-sm  border border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "last_name",
                    type: "text",
                    placeholder: "Enter Last Name",
                    value: enrollData?.last_name || "",
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 356,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 352,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 319,
              columnNumber: 21
            }, this),
            errors.full_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.full_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 367,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex  gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Password" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 374,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 placeholder:text-black bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "password",
                    type: "password",
                    placeholder: "Enter Password",
                    value: enrollData?.password || "",
                    onChange: handleChange,
                    required: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 377,
                    columnNumber: 25
                  },
                  this
                ),
                errors.password && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.password }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 387,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 373,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Date of Birth" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 394,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 placeholder:text-black bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "dateofbirth",
                    type: "date",
                    placeholder: "dd-mm-yyyy",
                    value: enrollData?.dateofbirth || "",
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 397,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 393,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Gender" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 408,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "gender",
                    value: enrollData?.gender,
                    onChange: handleChange,
                    className: "w-full p-2 border rounded-md mb-4 sm:text-lg text-sm  mt-1 bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Gender" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 417,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Male", children: "Male" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 418,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Female", children: "Female" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 419,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 411,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 407,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 372,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Phone Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 426,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "phone_number",
                    type: "tel",
                    inputMode: "numeric",
                    placeholder: "Enter Phone Number",
                    value: enrollData?.phone_number,
                    onChange: handleChange,
                    required: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 430,
                    columnNumber: 25
                  },
                  this
                ),
                errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 441,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 425,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Email ID" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 448,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "email",
                    type: "email",
                    placeholder: "Enter Email ID",
                    value: enrollData?.email,
                    onChange: handleChange,
                    required: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 452,
                    columnNumber: 25
                  },
                  this
                ),
                errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 462,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 447,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 424,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Marital Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 471,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "marital_status",
                    value: enrollData?.marital_status,
                    onChange: handleChange,
                    className: "w-full p-2 border rounded-md mb-4 sm:text-lg text-sm mt-1 bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Marital Status" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 480,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Married", children: "Married" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 481,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Unmarried", children: "Unmarried" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 482,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 474,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 470,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Referral Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 487,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "referral_name",
                    type: "text",
                    placeholder: "Enter Referral Name",
                    value: enrollData?.referral_name,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 490,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 486,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 469,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Nationality" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 503,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "nationality",
                    value: enrollData?.nationality,
                    onChange: handleChange,
                    className: "w-full p-2 border rounded-md mb-4 sm:text-lg text-sm mt-1 bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Nationality" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 512,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Indian", children: "Indian" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 513,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Other", children: "Other" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 514,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 506,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 502,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full sm:w-1/2", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Alternate Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 519,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "alternate_number",
                    type: "tel",
                    inputMode: "numeric",
                    placeholder: "Enter Alternate Number",
                    value: enrollData?.alternate_number,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 522,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 518,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 501,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Village" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 536,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "village",
                    type: "text",
                    placeholder: "Enter Village ",
                    value: enrollData?.village,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 539,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 535,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "Taluk" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 550,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "taluk",
                    type: "text",
                    placeholder: "Enter Taluk ",
                    value: enrollData?.taluk,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 553,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 549,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 534,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "State" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 566,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "state",
                    value: enrollData?.state,
                    onChange: handleChange,
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500 focus:border-violet-500",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select State" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 575,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Karnataka", children: "Karnataka" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 576,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Maharashtra", children: "Maharashtra" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 577,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Tamil Nadu", children: "Tamil Nadu" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 578,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 569,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 565,
                columnNumber: 23
              }, this),
              enrollData?.state === "Karnataka" ? /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "District" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 584,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "district",
                    value: enrollData?.district,
                    onChange: handleChange,
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500 focus:border-violet-500",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select District" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 593,
                        columnNumber: 29
                      }, this),
                      districts.map(
                        (district, index) => /* @__PURE__ */ jsxDEV("option", { value: district, children: district }, index, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                          lineNumber: 595,
                          columnNumber: 25
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 587,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 583,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "District" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 603,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "district",
                    value: enrollData?.district,
                    onChange: handleChange,
                    placeholder: "Enter District",
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500 focus:border-violet-500"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 606,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 602,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 564,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Address" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 618,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                name: "address",
                type: "text",
                placeholder: "Address",
                value: enrollData?.address,
                onChange: handleChange,
                required: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 621,
                columnNumber: 21
              },
              this
            ),
            errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 631,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Father Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 637,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "father_name",
                    type: "text",
                    placeholder: "Enter Customer Father Name",
                    value: enrollData?.father_name,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 640,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 636,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Pincode" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 651,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "pincode",
                    type: "number",
                    placeholder: "Enter Pincode",
                    inputMode: "numeric",
                    value: enrollData?.pincode,
                    onChange: handleChange,
                    required: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 654,
                    columnNumber: 25
                  },
                  this
                ),
                errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 665,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 650,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 635,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-3", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "w-40 active:scale-95 font-semibold border-2 border-black shadow-md bg-custom-violet hover:bg-violet-600 text-white p-2 rounded-md",
                onClick: () => setStep(2),
                children: "Add Nominee"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 673,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 672,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 318,
            columnNumber: 17
          }, this),
          step === 2 && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-[#17216D] rounded-md mb-3", children: /* @__PURE__ */ jsxDEV("h2", { className: "p-4 text-left font-bold rounded-md bg-custom-violet text-xl text-white", children: [
              " ",
              "Nominee Details"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 687,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 686,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Nominee Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 695,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "nominee_name",
                    type: "text",
                    placeholder: "Enter Nominee Name",
                    value: enrollData?.nominee_name,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 698,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 694,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Nominee Date of Birth" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 709,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "nominee_dateofbirth",
                    type: "date",
                    placeholder: "dd-mm-yyyy",
                    value: enrollData?.nominee_dateofbirth || "",
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 712,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 708,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 693,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Nominee Relationship" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 725,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "nominee_relationship",
                    value: enrollData?.nominee_relationship,
                    onChange: handleChange,
                    className: "w-full p-2 border rounded-md  sm:text-lg text-sm mb-4 mt-1 bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Relationship" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 734,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Father", children: "Father" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 735,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Mother", children: "Mother" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 736,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Brother/Sister", children: "Brother/Sister" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 737,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Spouse", children: "Spouse" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 738,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Son/Daughter", children: "Son/Daughter" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 739,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Other", children: "Other" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                        lineNumber: 740,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 728,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 724,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold  ", children: "Nominee Phone Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 745,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "nominee_phone_number",
                    type: "numeric",
                    placeholder: "Enter Nominee Phone Number",
                    value: enrollData?.nominee_phone_number,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 748,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 744,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 723,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "w-40 active:scale-95 font-semibold border-2 border-black shadow-md bg-custom-violet hover:bg-violet-600 text-white p-2 rounded-md",
                  onClick: () => setStep(1),
                  children: "Back"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 759,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "w-40 active:scale-95 font-semibold border-2 border-black shadow-md bg-custom-violet hover:bg-violet-600 text-white p-2 rounded-md",
                  onClick: () => setStep(3),
                  children: "Add Documents"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 767,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 758,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 685,
            columnNumber: 17
          }, this),
          step === 3 && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-[#17216D] rounded-md", children: /* @__PURE__ */ jsxDEV("h2", { className: "p-4 text-left font-bold rounded-md bg-custom-violet text-xl text-white mb-3", children: [
              " ",
              "Document Details"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 781,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 780,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Aadhar Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 789,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "adhaar_no",
                    type: "numeric",
                    placeholder: "Enter Adhaar Number",
                    value: enrollData?.adhaar_no,
                    onChange: handleChange,
                    required: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 792,
                    columnNumber: 25
                  },
                  this
                ),
                errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 802,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 788,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Pan Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 809,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "pan_no",
                    type: "text",
                    accept: "image/*",
                    placeholder: "Enter Pan Number",
                    value: enrollData?.pan_no,
                    onChange: handleChange,
                    required: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 813,
                    columnNumber: 25
                  },
                  this
                ),
                errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 824,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 808,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 787,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Aadhaar Front Photo" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 833,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "aadhar_frontphoto",
                    type: "file",
                    accept: "image/*",
                    placeholder: "No file choosen",
                    onChange: handleFileChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 837,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 832,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Aadhaar Back photo" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 848,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "aadhar_backphoto",
                    type: "file",
                    accept: "image/*",
                    placeholder: "No file choosen",
                    onChange: handleFileChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 852,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 847,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 831,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Pan Front photo" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 865,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "pan_frontphoto",
                    type: "file",
                    accept: "image/*",
                    placeholder: "No file choosen",
                    onChange: handleFileChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 869,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 864,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Pan Back photo" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 880,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "pan_backphoto",
                    type: "file",
                    accept: "image/*",
                    placeholder: "No file choosen",
                    onChange: handleFileChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 884,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 879,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 863,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("h1", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Upload Profile Photo" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 895,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("img", { src: "path/to image", alt: "" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 898,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "w-full p-4 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                name: "profilephoto",
                type: "file",
                accept: "image/*",
                placeholder: "No file choosen",
                onChange: handleFileChange
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 899,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "w-40 active:scale-95 font-semibold border-2 border-black shadow-md bg-custom-violet hover:bg-violet-600 text-white p-2 rounded-md",
                  onClick: () => setStep(2),
                  children: "Back"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 908,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "w-40 active:scale-95 font-semibold border-2 border-black shadow-md bg-custom-violet hover:bg-violet-600 text-white p-2 rounded-md",
                  onClick: () => setStep(4),
                  children: "Add Bank Details"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 916,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 907,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 779,
            columnNumber: 17
          }, this),
          step === 4 && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-[#17216D] rounded-md mb-3", children: /* @__PURE__ */ jsxDEV("h2", { className: "p-4 text-left font-bold rounded-md bg-custom-violet text-xl text-white", children: [
              " ",
              "Bank Details"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 930,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 929,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Bank Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 938,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "bank_name",
                    type: "text",
                    placeholder: "Enter Bank Name ",
                    value: enrollData?.bank_name,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 941,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 937,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "Bank Branch Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 952,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "bank_branch_name",
                    type: "text",
                    placeholder: "Enter Bank Branch Name",
                    value: enrollData?.bank_branch_name,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 956,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 951,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 936,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold ", children: "Bank Account Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 969,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "bank_account_number",
                    type: "text",
                    placeholder: "Enter Bank Account Number ",
                    value: enrollData?.bank_account_number,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 972,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 968,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "sm:w-1/2 w-full", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-left sm:text-lg text-sm font-semibold", children: "Bank IFSC Code" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 983,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    className: "w-full p-2 border rounded-md mb-4 mt-1 sm:text-lg text-sm bg-gray-50 border-gray-300 text-gray-900 focus:ring-violet-500  focus:border-violet-500",
                    name: "bank_IFSC_code",
                    type: "text",
                    placeholder: "Enter Customer Bank IFSC Code",
                    value: enrollData?.bank_IFSC_code,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                    lineNumber: 987,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                lineNumber: 982,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 967,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:flex gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "w-40 active:scale-95 font-semibold border-2 border-black shadow-md bg-custom-violet hover:bg-violet-600 text-white p-2 rounded-md",
                  onClick: () => setStep(3),
                  children: "Back"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 998,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-40 active:scale-95 font-semibold border-2 border-black shadow-md bg-custom-violet hover:bg-violet-600 text-white p-2 rounded-md",
                  children: "Submit"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
                  lineNumber: 1006,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
              lineNumber: 997,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
            lineNumber: 928,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 316,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
          lineNumber: 315,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
        lineNumber: 307,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
      lineNumber: 220,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx",
      lineNumber: 219,
      columnNumber: 7
    }, this);
  }
};
_s(EnrollmentRequestForm, "bmzOP+x6qHmRWJBx5QsQVwUXmzY=", false, function() {
  return [useSearchParams];
});
_c = EnrollmentRequestForm;
export default EnrollmentRequestForm;
var _c;
$RefreshReg$(_c, "EnrollmentRequestForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnrollmentRequestForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBME1VLFNBdUJFLFVBdkJGOzJCQTFNVjtBQUFtQkEsb0JBQWlCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsU0FBU0MsTUFBTUMsdUJBQXVCO0FBQ3RDLE9BQU9DLFNBQVM7QUFFaEIsTUFBTUMsd0JBQXdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSUMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ0MsWUFBWSxJQUFJUCxnQkFBZ0I7QUFDdkMsUUFBTSxDQUFDUSxhQUFhQyxjQUFjLElBQUlILFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNJLE1BQU1DLE9BQU8sSUFBSUwsU0FBUyxDQUFDO0FBQ2xDLFFBQU0sQ0FBQ00sV0FBV0MsWUFBWSxJQUFJUCxTQUFTLEVBQUU7QUFFN0MsUUFBTSxDQUFDUSxRQUFRQyxTQUFTLElBQUlULFNBQVMsQ0FBQyxDQUFDO0FBRXZDLFFBQU0sQ0FBQ1UsWUFBWUMsYUFBYSxJQUFJWCxTQUFTO0FBQUEsSUFDM0NZLGVBQWU7QUFBQSxJQUNmQyxPQUFPO0FBQUEsSUFDUEMsV0FBVztBQUFBLElBQ1hDLFVBQVU7QUFBQSxJQUNWQyxRQUFRO0FBQUEsSUFDUkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsU0FBUztBQUFBLElBQ1RDLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsSUFDZEMsa0JBQWtCO0FBQUEsSUFDbEJDLGVBQWU7QUFBQSxJQUNmQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLElBQ2RDLHFCQUFxQjtBQUFBLElBQ3JCQyxzQkFBc0I7QUFBQSxJQUN0QkMsc0JBQXNCO0FBQUEsSUFDdEJDLFdBQVc7QUFBQSxJQUNYQyxRQUFRO0FBQUEsSUFDUkMsbUJBQW1CO0FBQUEsSUFDbkJDLGtCQUFrQjtBQUFBLElBQ2xCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZUFBZTtBQUFBLElBQ2ZDLGNBQWM7QUFBQSxJQUNkQyxXQUFXO0FBQUEsSUFDWEMsa0JBQWtCO0FBQUEsSUFDbEJDLHFCQUFxQjtBQUFBLElBQ3JCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsaUJBQWlCO0FBQUEsSUFDakJDLGNBQWM7QUFBQSxFQUNoQixDQUFDO0FBRUR4RCxZQUFVLE1BQU07QUFDZCxVQUFNeUQscUJBQXFCLFlBQVk7QUFDckMsVUFBSTtBQUNGLGNBQU1DLFdBQVdqRCxhQUFha0QsSUFBSSxVQUFVO0FBQzVDLGNBQU1DLE1BQU0sTUFBTXpELElBQUl3RCxJQUFJLHlCQUF5QkQsUUFBUSxFQUFFO0FBQzdELGNBQU1HLE9BQU9ELElBQUlDO0FBQ2pCdEQseUJBQWlCc0QsSUFBSTtBQUFBLE1BQ3ZCLFNBQVNDLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0seUJBQXlCRixHQUFHO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQ0FMLHVCQUFtQjtBQUFBLEVBQ3JCLEdBQUcsRUFBRTtBQUVMekQsWUFBVSxNQUFNO0FBQ2QsVUFBTWlFLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU0vRCxJQUFJd0QsSUFBSSxnQkFBZ0I7QUFDL0M1QyxxQkFBYW1ELFNBQVNMLE1BQU1BLE1BQU0vQyxTQUFTO0FBQUEsTUFDN0MsU0FBU2tELE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBRUFDLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBQ0wsUUFBTUUsZUFBZUEsQ0FBQ0MsU0FBUztBQUM3QixVQUFNQyxZQUFZLENBQUM7QUFDbkIsVUFBTVIsT0FBT08sU0FBUyxzQkFBc0JsRCxhQUFhO0FBQ3pELFVBQU1vRCxRQUFRO0FBQUEsTUFDWmhDLE9BQU87QUFBQSxNQUNQaUMsT0FBTztBQUFBLE1BQ1BoQyxTQUFTO0FBQUEsTUFDVGlDLFFBQVE7QUFBQSxNQUNSQyxLQUFLO0FBQUEsSUFDUDtBQUVBLFFBQUksQ0FBQ1osS0FBS2EsV0FBV0MsS0FBSyxHQUFHO0FBQzNCTixnQkFBVS9DLFlBQVk7QUFBQSxJQUN4QjtBQUtBLFFBQUl1QyxLQUFLdkIsU0FBUyxDQUFDZ0MsTUFBTWhDLE1BQU1zQyxLQUFLZixLQUFLdkIsS0FBSyxHQUFHO0FBQy9DK0IsZ0JBQVUvQixRQUFRO0FBQUEsSUFDcEI7QUFFQSxRQUFJLENBQUN1QixLQUFLNUIsY0FBYztBQUN0Qm9DLGdCQUFVcEMsZUFBZTtBQUFBLElBQzNCLFdBQVcsQ0FBQ3FDLE1BQU1DLE1BQU1LLEtBQUtmLEtBQUs1QixZQUFZLEdBQUc7QUFDL0NvQyxnQkFBVXBDLGVBQWU7QUFBQSxJQUMzQjtBQUVBLFFBQUksQ0FBQzRCLEtBQUt0QyxVQUFVO0FBQ2xCOEMsZ0JBQVU5QyxXQUFXO0FBQUEsSUFDdkI7QUFNQSxRQUFJLENBQUNzQyxLQUFLdEIsU0FBUztBQUNqQjhCLGdCQUFVOUIsVUFBVTtBQUFBLElBQ3RCLFdBQVcsQ0FBQytCLE1BQU0vQixRQUFRcUMsS0FBS2YsS0FBS3RCLE9BQU8sR0FBRztBQUM1QzhCLGdCQUFVOUIsVUFBVTtBQUFBLElBQ3RCO0FBRUEsUUFBSSxDQUFDc0IsS0FBS2pCLFdBQVc7QUFDbkJ5QixnQkFBVXpCLFlBQVk7QUFBQSxJQUN4QixXQUFXLENBQUMwQixNQUFNRSxPQUFPSSxLQUFLZixLQUFLakIsU0FBUyxHQUFHO0FBQzdDeUIsZ0JBQVV6QixZQUFZO0FBQUEsSUFDeEI7QUFDQSxRQUFJaUIsS0FBS2hCLFVBQVUsQ0FBQ3lCLE1BQU1HLElBQUlHLEtBQUtmLEtBQUtoQixPQUFPZ0MsWUFBWSxDQUFDLEdBQUc7QUFDN0RSLGdCQUFVeEIsU0FBUztBQUFBLElBQ3JCO0FBRUEsUUFBSSxDQUFDZ0IsS0FBS3pCLFFBQVF1QyxLQUFLLEdBQUc7QUFDeEJOLGdCQUFVakMsVUFBVTtBQUFBLElBQ3RCLFdBQVd5QixLQUFLekIsUUFBUXVDLEtBQUssRUFBRUcsU0FBUyxHQUFHO0FBQ3pDVCxnQkFBVWpDLFVBQVU7QUFBQSxJQUN0QjtBQUVBbkIsY0FBVW9ELFNBQVM7QUFDbkIsV0FBT1UsT0FBT0MsS0FBS1gsU0FBUyxFQUFFUyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNRyxlQUFlQSxDQUFDQyxNQUFNO0FBQzFCL0Qsa0JBQWMsRUFBRSxHQUFHRCxZQUFZLENBQUNnRSxFQUFFQyxPQUFPQyxJQUFJLEdBQUdGLEVBQUVDLE9BQU9FLE1BQU0sQ0FBQztBQUFBLEVBQ2xFO0FBRUEsUUFBTUMsbUJBQW1CQSxDQUFDSixNQUFNO0FBQzlCL0Qsa0JBQWMsRUFBRSxHQUFHRCxZQUFZLENBQUNnRSxFQUFFQyxPQUFPQyxJQUFJLEdBQUdGLEVBQUVDLE9BQU9JLE1BQU0sQ0FBQyxFQUFFLENBQUM7QUFBQSxFQUNyRTtBQUVBLFFBQU1DLGVBQWUsT0FBT04sTUFBTTtBQUNoQ0EsTUFBRU8sZUFBZTtBQUVqQixVQUFNQyxXQUFXLEdBQUd4RSxXQUFXd0QsY0FBYyxFQUFFLElBQzdDeEQsV0FBV3lFLGFBQWEsRUFBRSxHQUN6QmhCLEtBQUs7QUFDUixVQUFNaUIscUJBQXFCLEVBQUUsR0FBRzFFLFlBQVlJLFdBQVdvRSxTQUFTO0FBQ2hFLFVBQU1HLFVBQVUxQixhQUFhLG1CQUFtQjtBQUVoRCxRQUFJMEIsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNQyxNQUFNO0FBRVosY0FBTUMsZ0JBQWdCLElBQUlDLFNBQVM7QUFFbkMsY0FBTSxFQUFFNUUsZUFBZSxHQUFHNkUsZUFBZSxJQUFJTDtBQUU3Q2IsZUFBT21CLFFBQVFELGNBQWMsRUFBRUUsUUFBUSxDQUFDLENBQUNDLEtBQUtmLEtBQUssTUFBTTtBQUN2RCxjQUFJQSxVQUFVLFFBQVFBLFVBQVVnQixRQUFXO0FBQ3pDTiwwQkFBY08sT0FBT0YsS0FBS2YsS0FBSztBQUFBLFVBQ2pDO0FBQUEsUUFDRixDQUFDO0FBRUQsWUFDRS9FLGlCQUNBQSxjQUFjaUcsT0FDZGpHLGNBQWNrRyxjQUNkbEcsY0FBY21HLGVBQ2RuRyxjQUFjb0csaUJBQ2RwRyxjQUFjcUc7QUFFZFosd0JBQWNPLE9BQU8saUJBQWlCaEcsY0FBY2lHLEdBQUc7QUFFekQsY0FBTUssU0FBUztBQUFBLFVBQ2JDLFNBQVM7QUFBQSxZQUNQLGdCQUFnQjtBQUFBLFVBQ2xCO0FBQUEsUUFDRjtBQUVBLGNBQU0zQyxXQUFXLE1BQU0vRCxJQUFJMkcsS0FBS2hCLEtBQUtDLGVBQWVhLE1BQU07QUFFMURqRyx1QkFBZSxJQUFJO0FBRW5Cb0csY0FBTSx3QkFBd0I7QUFBQSxNQUNoQyxTQUFTL0MsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkQrQyxjQUFNLGdEQUFnRDtBQUFBLE1BQ3hEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJckcsYUFBYTtBQUNmLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsMEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxNQUU3RCx1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLG1GQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLFFBQUssSUFBSSw2Q0FDUixpQ0FBQyxZQUFPLFdBQVUsc0pBQXFKLDRCQUF2SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLEVBRUosT0FBTztBQUNMLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHdEQUNiLGlDQUFDLFVBQUssVUFBVThFLGNBQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsUUFBRyxzQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCLEtBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsNkNBQ0U7QUFBQSwrQkFBQyxRQUFHLFdBQVUsOERBQTZELGdDQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxnREFBK0MsMEJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFFVixpQ0FBQyxZQUFPLE9BQU9sRixlQUFlaUcsS0FBSyxXQUFVLGlCQUMxQ2pHLHlCQUFla0csY0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBO0FBQUEsVUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGdEQUErQywwQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FDRSxHQUNFbEcsZUFBZTBHLFlBQVlDLE9BQU8sQ0FBQyxHQUFHcEMsWUFBWSxJQUNsRHZFLGVBQWUwRyxZQUFZRSxNQUFNLENBQUMsQ0FBQyxZQUN6QjtBQUFBLGdCQUVkLFVBQVE7QUFBQTtBQUFBLGNBWFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV1U7QUFBQSxlQWZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsOENBQTZDLDJCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixPQUFPNUcsZUFBZW1HLGVBQWU7QUFBQSxnQkFDckMsVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLGVBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQ0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSwrQ0FBOEMsaUNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU9uRyxlQUFlb0csaUJBQWlCO0FBQUEsZ0JBQ3ZDLFVBQVE7QUFBQTtBQUFBLGNBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTVU7QUFBQSxlQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw4Q0FBNkMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU9wRyxlQUFlcUcsa0JBQWtCO0FBQUEsZ0JBQ3hDLFVBQVE7QUFBQTtBQUFBLGNBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTVU7QUFBQSxlQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsV0E3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThFQSxLQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0ZBO0FBQUEsTUFFQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFFBQUcsV0FBVSwyRUFDWDtBQUFBO0FBQUEsVUFBSTtBQUFBLGFBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsT0FDYiw2Q0FDRy9GO0FBQUFBLG1CQUFTLEtBQ1IsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwrQ0FBOEMscUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT00sWUFBWUc7QUFBQUEsb0JBQ25CLFVBQVU0RDtBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sSUFBRyx1QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBd0I7QUFBQSxzQkFDeEIsdUJBQUMsWUFBTyxPQUFNLE1BQUssa0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFCO0FBQUEsc0JBQ3JCLHVCQUFDLFlBQU8sT0FBTSxNQUFLLGtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxQjtBQUFBLHNCQUNyQix1QkFBQyxZQUFPLE9BQU0sT0FBTSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUI7QUFBQSxzQkFDdkIsdUJBQUMsWUFBTyxPQUFNLE9BQU0sbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVCO0FBQUEsc0JBQ3ZCLHVCQUFDLFlBQU8sT0FBTSxNQUFLLGtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxQjtBQUFBO0FBQUE7QUFBQSxrQkFYdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLDBCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0w7QUFBQSxvQkFDQSxhQUFZO0FBQUEsb0JBQ1osT0FBTy9ELFlBQVl3RCxjQUFjO0FBQUEsb0JBQ2pDLFVBQVVPO0FBQUFBO0FBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPeUI7QUFBQSxtQkFYM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLCtDQUE4Qyx5QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWXlFLGFBQWE7QUFBQSxvQkFDaEMsVUFBVVY7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU15QjtBQUFBLG1CQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOENBO0FBQUEsWUFDQ2pFLE9BQU9NLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWTixpQkFBT00sYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHRix1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLHdCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU9KLFlBQVlLLFlBQVk7QUFBQSxvQkFDL0IsVUFBVTBEO0FBQUFBLG9CQUNWLFVBQVE7QUFBQTtBQUFBLGtCQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPVTtBQUFBLGdCQUVUakUsT0FBT08sWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZQLGlCQUFPTyxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwrQ0FBOEMsNkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBT0wsWUFBWVEsZUFBZTtBQUFBLG9CQUNsQyxVQUFVdUQ7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU15QjtBQUFBLG1CQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsZ0RBQStDLHNCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8vRCxZQUFZTTtBQUFBQSxvQkFDbkIsVUFBVXlEO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxJQUFHLDZCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4QjtBQUFBLHNCQUM5Qix1QkFBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUI7QUFBQSxzQkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUE7QUFBQTtBQUFBLGtCQVIvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0RBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLDRCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWWU7QUFBQUEsb0JBQ25CLFVBQVVnRDtBQUFBQSxvQkFDVixVQUFRO0FBQUE7QUFBQSxrQkFSVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUVU7QUFBQSxnQkFFVGpFLE9BQU9pQixnQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqQixpQkFBT2lCLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSxnREFBK0Msd0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBT2YsWUFBWW9CO0FBQUFBLG9CQUNuQixVQUFVMkM7QUFBQUEsb0JBQ1YsVUFBUTtBQUFBO0FBQUEsa0JBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9VO0FBQUEsZ0JBRVRqRSxPQUFPc0IsU0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z0QixpQkFBT3NCLFNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGdEQUErQyw4QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPcEIsWUFBWU87QUFBQUEsb0JBQ25CLFVBQVV3RDtBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sSUFBRyxxQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0M7QUFBQSxzQkFDdEMsdUJBQUMsWUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStCO0FBQUEsc0JBQy9CLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtQztBQUFBO0FBQUE7QUFBQSxrQkFSckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGdEQUErQyw2QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWWlCO0FBQUFBLG9CQUNuQixVQUFVOEM7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU15QjtBQUFBLG1CQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLDJCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8vRCxZQUFZUztBQUFBQSxvQkFDbkIsVUFBVXNEO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxJQUFHLGtDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtQztBQUFBLHNCQUNuQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSxzQkFDN0IsdUJBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCO0FBQUE7QUFBQTtBQUFBLGtCQVI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLGdDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWWdCO0FBQUFBLG9CQUNuQixVQUFVK0M7QUFBQUE7QUFBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU95QjtBQUFBLG1CQVgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLHVCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU8vRCxZQUFZVTtBQUFBQSxvQkFDbkIsVUFBVXFEO0FBQUFBO0FBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNeUI7QUFBQSxtQkFWM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDhDQUE2QyxxQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWVc7QUFBQUEsb0JBQ25CLFVBQVVvRDtBQUFBQTtBQUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXlCO0FBQUEsbUJBVjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxpQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw4Q0FBNkMscUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBTy9ELFlBQVljO0FBQUFBLG9CQUNuQixVQUFVaUQ7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUEsc0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtQztBQUFBLHNCQUNuQyx1QkFBQyxZQUFPLE9BQU0sZUFBYywyQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUM7QUFBQSxzQkFDdkMsdUJBQUMsWUFBTyxPQUFNLGNBQWEsMEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFDO0FBQUE7QUFBQTtBQUFBLGtCQVR2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxtQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsY0FFQy9ELFlBQVljLFVBQVUsY0FDckIsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDhDQUE2Qyx3QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPZCxZQUFZYTtBQUFBQSxvQkFDbkIsVUFBVWtEO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxJQUFHLCtCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHNCQUMvQm5FLFVBQVVxRztBQUFBQSx3QkFBSSxDQUFDcEYsVUFBVXFGLFVBQ3hCLHVCQUFDLFlBQW1CLE9BQU9yRixVQUN4QkEsc0JBRFVxRixPQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDRDtBQUFBO0FBQUE7QUFBQSxrQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWUE7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsOENBQTZDLHdCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPbEcsWUFBWWE7QUFBQUEsb0JBQ25CLFVBQVVrRDtBQUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBO0FBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU04SjtBQUFBLG1CQVZoSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBbERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0RBO0FBQUEsWUFFQSx1QkFBQyxRQUFHLFdBQVUsZ0RBQStDLHVCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixPQUFPL0QsWUFBWWtCO0FBQUFBLGdCQUNuQixVQUFVNkM7QUFBQUEsZ0JBQ1YsVUFBUTtBQUFBO0FBQUEsY0FQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPVTtBQUFBLFlBRVRqRSxPQUFPb0IsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZwQixpQkFBT29CLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUYsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGdEQUErQywyQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUFPbEIsWUFBWVk7QUFBQUEsb0JBQ25CLFVBQVVtRDtBQUFBQTtBQUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXlCO0FBQUEsbUJBVjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSxnREFBK0MsdUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBLG9CQUNWLE9BQU8vRCxZQUFZcUI7QUFBQUEsb0JBQ25CLFVBQVUwQztBQUFBQSxvQkFDVixVQUFRO0FBQUE7QUFBQSxrQkFSVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUVU7QUFBQSxnQkFFVGpFLE9BQU91QixXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnZCLGlCQUFPdUIsV0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsaUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFNBQVMsTUFBTTFCLFFBQVEsQ0FBQztBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUg1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQTFXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJXQTtBQUFBLFVBR0RELFNBQVMsS0FDUix1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFFBQUcsV0FBVSwwRUFDWDtBQUFBO0FBQUEsY0FBSTtBQUFBLGlCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsZ0RBQStDLDRCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU9NLFlBQVlzQjtBQUFBQSxvQkFDbkIsVUFBVXlDO0FBQUFBO0FBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNeUI7QUFBQSxtQkFWM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGdEQUErQyxxQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWXVCLHVCQUF1QjtBQUFBLG9CQUMxQyxVQUFVd0M7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU15QjtBQUFBLG1CQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsZ0RBQStDLG9DQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8vRCxZQUFZeUI7QUFBQUEsb0JBQ25CLFVBQVVzQztBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sSUFBRyxtQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0M7QUFBQSxzQkFDcEMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUEsc0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBLHNCQUM3Qix1QkFBQyxZQUFPLE9BQU0sa0JBQWlCLDhCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QztBQUFBLHNCQUM3Qyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSxzQkFDN0IsdUJBQUMsWUFBTyxPQUFNLGdCQUFlLDRCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMkI7QUFBQTtBQUFBO0FBQUEsa0JBWjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBLG1CQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGdEQUErQyxvQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWXdCO0FBQUFBLG9CQUNuQixVQUFVdUM7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU15QjtBQUFBLG1CQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFNBQVMsTUFBTXBFLFFBQVEsQ0FBQztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFINUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNQSxRQUFRLENBQUM7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxlQXpGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBGQTtBQUFBLFVBR0RELFNBQVMsS0FDUix1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUNiLGlDQUFDLFFBQUcsV0FBVSwrRUFDWDtBQUFBO0FBQUEsY0FBSTtBQUFBLGlCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLDZCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU9NLFlBQVkwQjtBQUFBQSxvQkFDbkIsVUFBVXFDO0FBQUFBLG9CQUNWLFVBQVE7QUFBQTtBQUFBLGtCQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPVTtBQUFBLGdCQUVUakUsT0FBTzRCLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUIsaUJBQU80QixhQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwrQ0FBOEMsMEJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxRQUFPO0FBQUEsb0JBQ1AsYUFBWTtBQUFBLG9CQUNaLE9BQU8xQixZQUFZMkI7QUFBQUEsb0JBQ25CLFVBQVVvQztBQUFBQSxvQkFDVixVQUFRO0FBQUE7QUFBQSxrQkFSVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUVU7QUFBQSxnQkFFVGpFLE9BQU82QixVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsVUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsaUJBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMENBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLG1DQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsUUFBTztBQUFBLG9CQUNQLGFBQVk7QUFBQSxvQkFDWixVQUFVeUM7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU02QjtBQUFBLG1CQVgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLGtDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsUUFBTztBQUFBLG9CQUNQLGFBQVk7QUFBQSxvQkFDWixVQUFVQTtBQUFBQTtBQUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTTZCO0FBQUEsbUJBWC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxpQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwrQ0FBOEMsK0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxRQUFPO0FBQUEsb0JBQ1AsYUFBWTtBQUFBLG9CQUNaLFVBQVVBO0FBQUFBO0FBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNNkI7QUFBQSxtQkFYL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLCtDQUE4Qyw4QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLFFBQU87QUFBQSxvQkFDUCxhQUFZO0FBQUEsb0JBQ1osVUFBVUE7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU02QjtBQUFBLG1CQVgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsWUFFQSx1QkFBQyxRQUFHLFdBQVUsK0NBQThDLG9DQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLEtBQUksaUJBQWdCLEtBQUksTUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxZQUMvQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLFFBQU87QUFBQSxnQkFDUCxhQUFZO0FBQUEsZ0JBQ1osVUFBVUE7QUFBQUE7QUFBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNNkI7QUFBQSxZQUU3Qix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFNBQVMsTUFBTXpFLFFBQVEsQ0FBQztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFINUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNQSxRQUFRLENBQUM7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxlQWhKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlKQTtBQUFBLFVBR0RELFNBQVMsS0FDUix1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFFBQUcsV0FBVSwwRUFDWDtBQUFBO0FBQUEsY0FBSTtBQUFBLGlCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLHlCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU9NLFlBQVlpQztBQUFBQSxvQkFDbkIsVUFBVThCO0FBQUFBO0FBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNeUI7QUFBQSxtQkFWM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDhDQUE2QyxnQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUFPL0QsWUFBWWtDO0FBQUFBLG9CQUNuQixVQUFVNkI7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU15QjtBQUFBLG1CQVgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsK0NBQThDLG1DQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU8vRCxZQUFZbUM7QUFBQUEsb0JBQ25CLFVBQVU0QjtBQUFBQTtBQUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXlCO0FBQUEsbUJBVjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw4Q0FBNkMsOEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBTy9ELFlBQVlvQztBQUFBQSxvQkFDbkIsVUFBVTJCO0FBQUFBO0FBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNeUI7QUFBQSxtQkFYM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGlCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU1wRSxRQUFRLENBQUM7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUFtSTtBQUFBO0FBQUEsZ0JBRi9JO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLGVBcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUZBO0FBQUEsYUF6ckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyckJBLEtBNXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNnJCQTtBQUFBLFdBcnNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc3NCQTtBQUFBLFNBN3hCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOHhCQSxLQS94QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWd5QkE7QUFBQSxFQUVKO0FBQ0Y7QUFBRVIsR0F6L0JJRCx1QkFBcUI7QUFBQSxVQUVGRixlQUFlO0FBQUE7QUFBQW1ILEtBRmxDakg7QUEwL0JOLGVBQWVBO0FBQXNCLElBQUFpSDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiTGluayIsInVzZVNlYXJjaFBhcmFtcyIsImFwaSIsIkVucm9sbG1lbnRSZXF1ZXN0Rm9ybSIsIl9zIiwic2VsZWN0ZWRHcm91cCIsInNldFNlbGVjdGVkR3JvdXAiLCJ1c2VTdGF0ZSIsInNlYXJjaFBhcmFtcyIsImlzU3VibWl0dGVkIiwic2V0SXNTdWJtaXR0ZWQiLCJzdGVwIiwic2V0U3RlcCIsImRpc3RyaWN0cyIsInNldERpc3RyaWN0cyIsImVycm9ycyIsInNldEVycm9ycyIsImVucm9sbERhdGEiLCJzZXRFbnJvbGxEYXRhIiwic2VsZWN0ZWRfcGxhbiIsInRpdGxlIiwiZnVsbF9uYW1lIiwicGFzc3dvcmQiLCJnZW5kZXIiLCJtYXJpdGFsX3N0YXR1cyIsImRhdGVvZmJpcnRoIiwibmF0aW9uYWxpdHkiLCJ2aWxsYWdlIiwidGFsdWsiLCJmYXRoZXJfbmFtZSIsImRpc3RyaWN0Iiwic3RhdGUiLCJwaG9uZV9udW1iZXIiLCJhbHRlcm5hdGVfbnVtYmVyIiwicmVmZXJyYWxfbmFtZSIsImFkZHJlc3MiLCJhcmVhIiwiZW1haWwiLCJwaW5jb2RlIiwibm9taW5lZV9uYW1lIiwibm9taW5lZV9kYXRlb2ZiaXJ0aCIsIm5vbWluZWVfcGhvbmVfbnVtYmVyIiwibm9taW5lZV9yZWxhdGlvbnNoaXAiLCJhZGhhYXJfbm8iLCJwYW5fbm8iLCJhYWRoYXJfZnJvbnRwaG90byIsImFhZGhhcl9iYWNrcGhvdG8iLCJwYW5fZnJvbnRwaG90byIsInBhbl9iYWNrcGhvdG8iLCJwcm9maWxlcGhvdG8iLCJiYW5rX25hbWUiLCJiYW5rX2JyYW5jaF9uYW1lIiwiYmFua19hY2NvdW50X251bWJlciIsImJhbmtfSUZTQ19jb2RlIiwiY3VzdG9tZXJfc3RhdHVzIiwidHJhY2tfc291cmNlIiwiZmV0Y2hTZWxlY3RlZEdyb3VwIiwiZ3JvdXBfaWQiLCJnZXQiLCJyZXMiLCJkYXRhIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hEaXN0cmljdHMiLCJyZXNwb25zZSIsInZhbGlkYXRlRm9ybSIsInR5cGUiLCJuZXdFcnJvcnMiLCJyZWdleCIsInBob25lIiwiYWRoYWFyIiwicGFuIiwiZmlyc3RfbmFtZSIsInRyaW0iLCJ0ZXN0IiwidG9VcHBlckNhc2UiLCJsZW5ndGgiLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlQ2hhbmdlIiwiZSIsInRhcmdldCIsIm5hbWUiLCJ2YWx1ZSIsImhhbmRsZUZpbGVDaGFuZ2UiLCJmaWxlcyIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiZnVsbE5hbWUiLCJsYXN0X25hbWUiLCJmdWxsTmFtZUVucm9sbERhdGEiLCJpc1ZhbGlkIiwidXJsIiwiZW5yb2xsRGF0YU9iaiIsIkZvcm1EYXRhIiwicmVzdEVucm9sbERhdGEiLCJlbnRyaWVzIiwiZm9yRWFjaCIsImtleSIsInVuZGVmaW5lZCIsImFwcGVuZCIsIl9pZCIsImdyb3VwX25hbWUiLCJncm91cF92YWx1ZSIsImdyb3VwX2luc3RhbGwiLCJncm91cF9kdXJhdGlvbiIsImNvbmZpZyIsImhlYWRlcnMiLCJwb3N0IiwiYWxlcnQiLCJncm91cF90eXBlIiwiY2hhckF0Iiwic2xpY2UiLCJtYXAiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVucm9sbG1lbnRSZXF1ZXN0Rm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcblxyXG5jb25zdCBFbnJvbGxtZW50UmVxdWVzdEZvcm0gPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICBjb25zdCBbaXNTdWJtaXR0ZWQsIHNldElzU3VibWl0dGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgxKTtcclxuICBjb25zdCBbZGlzdHJpY3RzLCBzZXREaXN0cmljdHNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICBjb25zdCBbZW5yb2xsRGF0YSwgc2V0RW5yb2xsRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBzZWxlY3RlZF9wbGFuOiBcIlwiLFxyXG4gICAgdGl0bGU6IFwiXCIsXHJcbiAgICBmdWxsX25hbWU6IFwiXCIsXHJcbiAgICBwYXNzd29yZDogXCJcIixcclxuICAgIGdlbmRlcjogXCJcIixcclxuICAgIG1hcml0YWxfc3RhdHVzOiBcIlwiLFxyXG4gICAgZGF0ZW9mYmlydGg6IG51bGwsXHJcbiAgICBuYXRpb25hbGl0eTogXCJcIixcclxuICAgIHZpbGxhZ2U6IFwiXCIsXHJcbiAgICB0YWx1azogXCJcIixcclxuICAgIGZhdGhlcl9uYW1lOiBcIlwiLFxyXG4gICAgZGlzdHJpY3Q6IFwiXCIsXHJcbiAgICBzdGF0ZTogXCJcIixcclxuICAgIHBob25lX251bWJlcjogXCJcIixcclxuICAgIGFsdGVybmF0ZV9udW1iZXI6IFwiXCIsXHJcbiAgICByZWZlcnJhbF9uYW1lOiBcIlwiLFxyXG4gICAgYWRkcmVzczogXCJcIixcclxuICAgIGFyZWE6IFwiXCIsXHJcbiAgICBlbWFpbDogXCJcIixcclxuICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICBub21pbmVlX25hbWU6IFwiXCIsXHJcbiAgICBub21pbmVlX2RhdGVvZmJpcnRoOiBudWxsLFxyXG4gICAgbm9taW5lZV9waG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICBub21pbmVlX3JlbGF0aW9uc2hpcDogXCJcIixcclxuICAgIGFkaGFhcl9ubzogXCJcIixcclxuICAgIHBhbl9ubzogXCJcIixcclxuICAgIGFhZGhhcl9mcm9udHBob3RvOiBcIm51bGxcIixcclxuICAgIGFhZGhhcl9iYWNrcGhvdG86IFwibnVsbFwiLFxyXG4gICAgcGFuX2Zyb250cGhvdG86IFwibnVsbFwiLFxyXG4gICAgcGFuX2JhY2twaG90bzogXCJudWxsXCIsXHJcbiAgICBwcm9maWxlcGhvdG86IFwibnVsbFwiLFxyXG4gICAgYmFua19uYW1lOiBcIlwiLFxyXG4gICAgYmFua19icmFuY2hfbmFtZTogXCJcIixcclxuICAgIGJhbmtfYWNjb3VudF9udW1iZXI6IFwiXCIsXHJcbiAgICBiYW5rX0lGU0NfY29kZTogXCJcIixcclxuICAgIGN1c3RvbWVyX3N0YXR1czogXCJpbmFjdGl2ZVwiLFxyXG4gICAgdHJhY2tfc291cmNlOiBcImVucm9sbG1lbnRfZm9ybVwiLFxyXG4gIH0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hTZWxlY3RlZEdyb3VwID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGdyb3VwX2lkID0gc2VhcmNoUGFyYW1zLmdldChcImdyb3VwX2lkXCIpO1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoYGdyb3VwL2dldC1ieS1pZC1ncm91cC8ke2dyb3VwX2lkfWApO1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSByZXMuZGF0YTtcclxuICAgICAgICBzZXRTZWxlY3RlZEdyb3VwKGRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiZmFpbGVkIHRvIGZldGNoIGdyb3VwXCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFNlbGVjdGVkR3JvdXAoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERpc3RyaWN0cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9kaXN0cmljdFwiKTtcclxuICAgICAgICBzZXREaXN0cmljdHMocmVzcG9uc2UuZGF0YT8uZGF0YT8uZGlzdHJpY3RzKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGlzdHJpY3RzOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hEaXN0cmljdHMoKTtcclxuICB9LCBbXSk7XHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkRW5yb2xsQ3VzdG9tZXJcIiA/IGVucm9sbERhdGEgOiBudWxsO1xyXG4gICAgY29uc3QgcmVnZXggPSB7XHJcbiAgICAgIGVtYWlsOiAvXlteXFxzQF0rQFteXFxzQF0rXFwuW15cXHNAXSskLyxcclxuICAgICAgcGhvbmU6IC9eWzYtOV1cXGR7OX0kLyxcclxuICAgICAgcGluY29kZTogL15cXGR7Nn0kLyxcclxuICAgICAgYWRoYWFyOiAvXlxcZHsxMn0kLyxcclxuICAgICAgcGFuOiAvXltBLVpdezV9WzAtOV17NH1bQS1aXXsxfSQvLFxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIWRhdGEuZmlyc3RfbmFtZS50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmZ1bGxfbmFtZSA9IFwiRnVsbCBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gaWYgKCFkYXRhLmVtYWlsKSB7XHJcbiAgICAvLyAgIG5ld0Vycm9ycy5lbWFpbCA9IFwiRW1haWwgaXMgcmVxdWlyZWRcIjtcclxuICAgIC8vIH0gZWxzZVxyXG4gICAgaWYgKGRhdGEuZW1haWwgJiYgIXJlZ2V4LmVtYWlsLnRlc3QoZGF0YS5lbWFpbCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmVtYWlsID0gXCJJbnZhbGlkIGVtYWlsIGZvcm1hdFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5waG9uZV9udW1iZXIpIHtcclxuICAgICAgbmV3RXJyb3JzLnBob25lX251bWJlciA9IFwiUGhvbmUgbnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5waG9uZS50ZXN0KGRhdGEucGhvbmVfbnVtYmVyKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGhvbmVfbnVtYmVyID0gXCJJbnZhbGlkICBwaG9uZSBudW1iZXJcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGFzc3dvcmQpIHtcclxuICAgICAgbmV3RXJyb3JzLnBhc3N3b3JkID0gXCJQYXNzd29yZCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgLy8gZWxzZSBpZiAoIXJlZ2V4LnBhc3N3b3JkLnRlc3QoZGF0YS5wYXNzd29yZCkpIHtcclxuICAgIC8vICAgbmV3RXJyb3JzLnBhc3N3b3JkID1cclxuICAgIC8vICAgICBcIlBhc3N3b3JkIG11c3QgY29udGFpbiBhdCBsZWFzdCA1IGNoYXJhY3RlcnMsIG9uZSB1cHBlcmNhc2UsIG9uZSBsb3dlcmNhc2UsIG9uZSBudW1iZXIsIGFuZCBvbmUgc3BlY2lhbCBjaGFyYWN0ZXJcIjtcclxuICAgIC8vIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGluY29kZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGluY29kZSA9IFwiUGluY29kZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGluY29kZS50ZXN0KGRhdGEucGluY29kZSkpIHtcclxuICAgICAgbmV3RXJyb3JzLnBpbmNvZGUgPSBcIkludmFsaWQgcGluY29kZSAoNiBkaWdpdHMgcmVxdWlyZWQpXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmFkaGFhcl9ubykge1xyXG4gICAgICBuZXdFcnJvcnMuYWRoYWFyX25vID0gXCJBYWRoYXIgbnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5hZGhhYXIudGVzdChkYXRhLmFkaGFhcl9ubykpIHtcclxuICAgICAgbmV3RXJyb3JzLmFkaGFhcl9ubyA9IFwiSW52YWxpZCBBYWRoYXIgbnVtYmVyICgxMiBkaWdpdHMgcmVxdWlyZWQpXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoZGF0YS5wYW5fbm8gJiYgIXJlZ2V4LnBhbi50ZXN0KGRhdGEucGFuX25vLnRvVXBwZXJDYXNlKCkpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYW5fbm8gPSBcIkludmFsaWQgUEFOIGZvcm1hdCAoZS5nLiwgQUJDREUxMjM0RilcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEuYWRkcmVzcy50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmFkZHJlc3MgPSBcIkFkZHJlc3MgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoZGF0YS5hZGRyZXNzLnRyaW0oKS5sZW5ndGggPCAzKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGRyZXNzID0gXCJBZGRyZXNzIHNob3VsZCBiZSBhdCBsZWFzdCAzIGNoYXJhY3RlcnNcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgc2V0RW5yb2xsRGF0YSh7IC4uLmVucm9sbERhdGEsIFtlLnRhcmdldC5uYW1lXTogZS50YXJnZXQudmFsdWUgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRmlsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBzZXRFbnJvbGxEYXRhKHsgLi4uZW5yb2xsRGF0YSwgW2UudGFyZ2V0Lm5hbWVdOiBlLnRhcmdldC5maWxlc1swXSB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IGZ1bGxOYW1lID0gYCR7ZW5yb2xsRGF0YS5maXJzdF9uYW1lIHx8IFwiXCJ9ICR7XHJcbiAgICAgIGVucm9sbERhdGEubGFzdF9uYW1lIHx8IFwiXCJcclxuICAgIH1gLnRyaW0oKTtcclxuICAgIGNvbnN0IGZ1bGxOYW1lRW5yb2xsRGF0YSA9IHsgLi4uZW5yb2xsRGF0YSwgZnVsbF9uYW1lOiBmdWxsTmFtZSB9O1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybShcImFkZEVucm9sbEN1c3RvbWVyXCIpO1xyXG5cclxuICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYHVzZXIvYWRkLWVucm9sbG1lbnQtcmVxdWVzdC1kYXRhYDtcclxuXHJcbiAgICAgICAgY29uc3QgZW5yb2xsRGF0YU9iaiA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgICAgICBjb25zdCB7IHNlbGVjdGVkX3BsYW4sIC4uLnJlc3RFbnJvbGxEYXRhIH0gPSBmdWxsTmFtZUVucm9sbERhdGE7XHJcblxyXG4gICAgICAgIE9iamVjdC5lbnRyaWVzKHJlc3RFbnJvbGxEYXRhKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcclxuICAgICAgICAgIGlmICh2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGVucm9sbERhdGFPYmouYXBwZW5kKGtleSwgdmFsdWUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBzZWxlY3RlZEdyb3VwICYmXHJcbiAgICAgICAgICBzZWxlY3RlZEdyb3VwLl9pZCAmJlxyXG4gICAgICAgICAgc2VsZWN0ZWRHcm91cC5ncm91cF9uYW1lICYmXHJcbiAgICAgICAgICBzZWxlY3RlZEdyb3VwLmdyb3VwX3ZhbHVlICYmXHJcbiAgICAgICAgICBzZWxlY3RlZEdyb3VwLmdyb3VwX2luc3RhbGwgJiZcclxuICAgICAgICAgIHNlbGVjdGVkR3JvdXAuZ3JvdXBfZHVyYXRpb25cclxuICAgICAgICApXHJcbiAgICAgICAgICBlbnJvbGxEYXRhT2JqLmFwcGVuZChcInNlbGVjdGVkX3BsYW5cIiwgc2VsZWN0ZWRHcm91cC5faWQpO1xyXG5cclxuICAgICAgICBjb25zdCBjb25maWcgPSB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KHVybCwgZW5yb2xsRGF0YU9iaiwgY29uZmlnKTtcclxuXHJcbiAgICAgICAgc2V0SXNTdWJtaXR0ZWQodHJ1ZSk7XHJcblxyXG4gICAgICAgIGFsZXJ0KFwiRW5yb2xsbWVudCBzdWNjZXNzZnVsIVwiKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc3VibWl0dGluZyBlbnJvbGxtZW50OlwiLCBlcnJvcik7XHJcbiAgICAgICAgYWxlcnQoXCJGYWlsZWQgdG8gc3VibWl0IGVucm9sbG1lbnQuIFBsZWFzZSB0cnkgYWdhaW4uXCIpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuICBpZiAoaXNTdWJtaXR0ZWQpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLTIgIG14LWF1dG8gYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlRoYW5rIFlvdSE8L2gyPlxyXG5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgWW91ciBlbnJvbGxtZW50IHdhcyBzdWNjZXNzZnVsLiBXZSdyZSBleGNpdGVkIHRvIGhhdmUgeW91IG9uIGJvYXJkIVxyXG4gICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgIDxMaW5rIHRvPXtcImh0dHBzOi8vbWFwcy5hcHAuZ29vLmdsL1g3RmV6RlJQaVRqdVlvVnQ1XCJ9PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cIm10LTQgcHgtNiBweS0yIGJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQgaG92ZXI6YmctdmlvbGV0LTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTMwMCB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgT3VyIExvY2F0aW9uXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbWQgc2hhZG93LTJ4bCBzbTpteS0xMCBzbTpteC02NFwiPlxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTMgbXQtMyBwLTQgdGV4dC14bCBzbTp0ZXh0LTR4bCBmb250LWJvbGQgcm91bmRlZC1tZCB0ZXh0LWFtYmVyLTUwIGJnLWN1c3RvbS12aW9sZXRcIj5cclxuICAgICAgICAgICAgPGgyPiBDaGl0IEVucm9sbG1lbnQgRm9ybSA8L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTRcIj5cclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHRleHQtd2hpdGUgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgQ2hhbmdlIENoaXQgUGxhblxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCAgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICBHcm91cCBOYW1lXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwICBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17c2VsZWN0ZWRHcm91cD8uX2lkfSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEdyb3VwPy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCAgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgVHlwZVxyXG4gICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gIHRleHQtZ3JheS02MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgYCR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkR3JvdXA/Lmdyb3VwX3R5cGU/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkR3JvdXA/Lmdyb3VwX3R5cGU/LnNsaWNlKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9IEdyb3VwYCB8fCBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cCBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciAgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIHRleHQtZ3JheS02MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBob3ZlcjpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjUwMDAwIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXA/Lmdyb3VwX3ZhbHVlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgSW5zdGFsbG1lbnRcclxuICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS02MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBob3ZlcjpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjQwMCBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwPy5ncm91cF9pbnN0YWxsIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIER1cmF0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNjAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIxMy4yIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXA/Lmdyb3VwX2R1cmF0aW9uIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyM0YzEwN2VdIHJvdW5kZWQtbWQgbS0zIFwiPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJwLTQgdGV4dC1sZWZ0IHRleHQtd2hpdGUgcm91bmRlZC1tZCBmb250LWJvbGQgdGV4dC14bCBiZy1jdXN0b20tdmlvbGV0IFwiPlxyXG4gICAgICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICAgICAgQ3VzdG9tZXIgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTRcIj5cclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAge3N0ZXAgPT09IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCAgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzYgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVGl0bGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNclwiPk1yPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1zXCI+TXM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTXJzXCI+TXJzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk0vU1wiPk1yczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEclwiPkRyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEZpcnN0IE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCB3LWZ1bGwgcC0yIHJvdW5kZWQtbGcgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJmaXJzdF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpcnN0IE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5maXJzdF9uYW1lIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBMYXN0IE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCB3LWZ1bGwgcC0yIHJvdW5kZWQtbGcgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsYXN0X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIExhc3QgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/Lmxhc3RfbmFtZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmZ1bGxfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCAgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGFzc3dvcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgcGxhY2Vob2xkZXI6dGV4dC1ibGFjayBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8ucGFzc3dvcmQgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEYXRlIG9mIEJpcnRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHBsYWNlaG9sZGVyOnRleHQtYmxhY2sgYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGF0ZW9mYmlydGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImRkLW1tLXl5eXlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5kYXRlb2ZiaXJ0aCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkICBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHZW5kZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJnZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5nZW5kZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgc206dGV4dC1sZyB0ZXh0LXNtICBtdC0xIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEdlbmRlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNYWxlXCI+TWFsZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGZW1hbGVcIj5GZW1hbGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRNb2RlPVwibnVtZXJpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRW1haWwgSURcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtYWlsIElEXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8uZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtYWlsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE1hcml0YWwgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibWFyaXRhbF9zdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5tYXJpdGFsX3N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBzbTp0ZXh0LWxnIHRleHQtc20gbXQtMSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBNYXJpdGFsIFN0YXR1czwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNYXJyaWVkXCI+TWFycmllZDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJVbm1hcnJpZWRcIj5Vbm1hcnJpZWQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkICBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBSZWZlcnJhbCBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJhbF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBSZWZlcnJhbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8ucmVmZXJyYWxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOYXRpb25hbGl0eVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5hdGlvbmFsaXR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8ubmF0aW9uYWxpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgc206dGV4dC1sZyB0ZXh0LXNtIG10LTEgYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgTmF0aW9uYWxpdHk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSW5kaWFuXCI+SW5kaWFuPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk90aGVyXCI+T3RoZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEFsdGVybmF0ZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFsdGVybmF0ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWx0ZXJuYXRlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/LmFsdGVybmF0ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmlsbGFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidmlsbGFnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgVmlsbGFnZSBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy52aWxsYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVGFsdWtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRhbHVrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBUYWx1ayBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy50YWx1a31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5zdGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFN0YXRlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkthcm5hdGFrYVwiPkthcm5hdGFrYTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNYWhhcmFzaHRyYVwiPk1haGFyYXNodHJhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRhbWlsIE5hZHVcIj5UYW1pbCBOYWR1PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vucm9sbERhdGE/LnN0YXRlID09PSBcIkthcm5hdGFrYVwiID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpc3RyaWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/LmRpc3RyaWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBEaXN0cmljdDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Rpc3RyaWN0cy5tYXAoKGRpc3RyaWN0LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17aW5kZXh9IHZhbHVlPXtkaXN0cmljdH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Rpc3RyaWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRGlzdHJpY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRpc3RyaWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5kaXN0cmljdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIERpc3RyaWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkICBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/LmFkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRmF0aGVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImZhdGhlcl9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDdXN0b21lciBGYXRoZXIgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/LmZhdGhlcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkICBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQaW5jb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBhY3RpdmU6c2NhbGUtOTUgZm9udC1zZW1pYm9sZCBib3JkZXItMiBib3JkZXItYmxhY2sgc2hhZG93LW1kIGJnLWN1c3RvbS12aW9sZXQgaG92ZXI6YmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkLW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgyKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkIE5vbWluZWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge3N0ZXAgPT09IDIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyMxNzIxNkRdIHJvdW5kZWQtbWQgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInAtNCB0ZXh0LWxlZnQgZm9udC1ib2xkIHJvdW5kZWQtbWQgYmctY3VzdG9tLXZpb2xldCB0ZXh0LXhsIHRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBOb21pbmVlIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTm9taW5lZSBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub21pbmVlX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIE5vbWluZWUgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/Lm5vbWluZWVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTm9taW5lZSBEYXRlIG9mIEJpcnRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub21pbmVlX2RhdGVvZmJpcnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJkZC1tbS15eXl5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8ubm9taW5lZV9kYXRlb2ZiaXJ0aCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkICBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOb21pbmVlIFJlbGF0aW9uc2hpcFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vbWluZWVfcmVsYXRpb25zaGlwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8ubm9taW5lZV9yZWxhdGlvbnNoaXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kICBzbTp0ZXh0LWxnIHRleHQtc20gbWItNCBtdC0xIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFJlbGF0aW9uc2hpcDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGYXRoZXJcIj5GYXRoZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTW90aGVyXCI+TW90aGVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkJyb3RoZXIvU2lzdGVyXCI+QnJvdGhlci9TaXN0ZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU3BvdXNlXCI+U3BvdXNlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNvbi9EYXVnaHRlclwiPlNvbi9EYXVnaHRlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPdGhlclwiPk90aGVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTm9taW5lZSBQaG9uZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vbWluZWVfcGhvbmVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtZXJpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBOb21pbmVlIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/Lm5vbWluZWVfcGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNDAgYWN0aXZlOnNjYWxlLTk1IGZvbnQtc2VtaWJvbGQgYm9yZGVyLTIgYm9yZGVyLWJsYWNrIHNoYWRvdy1tZCBiZy1jdXN0b20tdmlvbGV0IGhvdmVyOmJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBwLTIgcm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoMSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEJhY2tcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNDAgYWN0aXZlOnNjYWxlLTk1IGZvbnQtc2VtaWJvbGQgYm9yZGVyLTIgYm9yZGVyLWJsYWNrIHNoYWRvdy1tZCBiZy1jdXN0b20tdmlvbGV0IGhvdmVyOmJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBwLTIgcm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoMyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkZCBEb2N1bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge3N0ZXAgPT09IDMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyMxNzIxNkRdIHJvdW5kZWQtbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJwLTQgdGV4dC1sZWZ0IGZvbnQtYm9sZCByb3VuZGVkLW1kIGJnLWN1c3RvbS12aW9sZXQgdGV4dC14bCB0ZXh0LXdoaXRlIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBEb2N1bWVudCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWFkaGFyIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRoYWFyX25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtZXJpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGhhYXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8uYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGhhYXJfbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGFuIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhbl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFuIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vucm9sbERhdGE/LnBhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFuX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEFhZGhhYXIgRnJvbnQgUGhvdG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQtbWQgbWItNCBtdC0xIHNtOnRleHQtbGcgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIGZvY3VzOnJpbmctdmlvbGV0LTUwMCAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhYWRoYXJfZnJvbnRwaG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm8gZmlsZSBjaG9vc2VuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWFkaGFhciBCYWNrIHBob3RvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWFkaGFyX2JhY2twaG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm8gZmlsZSBjaG9vc2VuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206dy0xLzIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGFuIEZyb250IHBob3RvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFuX2Zyb250cGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vIGZpbGUgY2hvb3NlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBhbiBCYWNrIHBob3RvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFuX2JhY2twaG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm8gZmlsZSBjaG9vc2VuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVXBsb2FkIFByb2ZpbGUgUGhvdG9cclxuICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwicGF0aC90byBpbWFnZVwiIGFsdD1cIlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC00IGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwcm9maWxlcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vIGZpbGUgY2hvb3NlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBhY3RpdmU6c2NhbGUtOTUgZm9udC1zZW1pYm9sZCBib3JkZXItMiBib3JkZXItYmxhY2sgc2hhZG93LW1kIGJnLWN1c3RvbS12aW9sZXQgaG92ZXI6YmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkLW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgyKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFja1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBhY3RpdmU6c2NhbGUtOTUgZm9udC1zZW1pYm9sZCBib3JkZXItMiBib3JkZXItYmxhY2sgc2hhZG93LW1kIGJnLWN1c3RvbS12aW9sZXQgaG92ZXI6YmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkLW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCg0KX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkIEJhbmsgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7c3RlcCA9PT0gNCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bIzE3MjE2RF0gcm91bmRlZC1tZCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwicC00IHRleHQtbGVmdCBmb250LWJvbGQgcm91bmRlZC1tZCBiZy1jdXN0b20tdmlvbGV0IHRleHQteGwgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCYW5rIE5hbWUgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8uYmFua19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBCcmFuY2ggTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImJhbmtfYnJhbmNoX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJhbmsgQnJhbmNoIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbnJvbGxEYXRhPy5iYW5rX2JyYW5jaF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOnctMS8yIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNtOnRleHQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgQWNjb3VudCBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZC1tZCBtYi00IG10LTEgc206dGV4dC1sZyB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgZm9jdXM6cmluZy12aW9sZXQtNTAwICBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImJhbmtfYWNjb3VudF9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJhbmsgQWNjb3VudCBOdW1iZXIgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8uYmFua19hY2NvdW50X251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTp3LTEvMiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGVmdCBzbTp0ZXh0LWxnIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgSUZTQyBDb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkLW1kIG1iLTQgbXQtMSBzbTp0ZXh0LWxnIHRleHQtc20gYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYmFua19JRlNDX2NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEN1c3RvbWVyIEJhbmsgSUZTQyBDb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsRGF0YT8uYmFua19JRlNDX2NvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBhY3RpdmU6c2NhbGUtOTUgZm9udC1zZW1pYm9sZCBib3JkZXItMiBib3JkZXItYmxhY2sgc2hhZG93LW1kIGJnLWN1c3RvbS12aW9sZXQgaG92ZXI6YmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkLW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgzKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFja1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBhY3RpdmU6c2NhbGUtOTUgZm9udC1zZW1pYm9sZCBib3JkZXItMiBib3JkZXItYmxhY2sgc2hhZG93LW1kIGJnLWN1c3RvbS12aW9sZXQgaG92ZXI6YmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkLW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU3VibWl0XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufTtcclxuZXhwb3J0IGRlZmF1bHQgRW5yb2xsbWVudFJlcXVlc3RGb3JtO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW5yb2xsbWVudFJlcXVlc3RGb3JtLmpzeCJ9