import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuctionTermsandCondition.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const AuctionTermsandCondition = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const [auctionData, setAuctionData] = useState([]);
  const groupOptions = [
    ...new Set(
      usersData.filter(
        (u) => u.groupName !== void 0 && u.groupName !== "" && u.groupName !== "   "
      ).map((u) => u.groupName)
    )
  ];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    userPhone: user.userPhone,
                    groupName: user.groupName,
                    userName: user.userName,
                    ticket: user.ticket
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
            lineNumber: 62,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/bid-rules-regulation-message", {
        receivers: visibleActiveUsers
      });
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/auction/get-auction");
      const usersList = [];
      const tempActive = {};
      const auctionData2 = reportResponse.data?.auction.map((auction, index) => {
        const id = auction._id;
        const userName = auction?.user_id?.full_name;
        const userPhone = auction?.user_id?.phone_number;
        const groupName = auction?.group_id?.group_name;
        const ticket = auction?.ticket;
        tempActive[id] = {
          info: { status: false }
        };
        const tempUser = {
          _id: id,
          userName,
          userPhone,
          groupName,
          ticket,
          enrollmentDate: auction.group_id?.createdAt
        };
        usersList.push(tempUser);
        return {
          slNo: index + 1,
          groupName,
          userName,
          userPhone,
          ticket
        };
      });
      setAuctionData(auctionData2);
      setUsersData(usersList);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    // { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" }
    //  {key: "paymentsTicket", header: "Ticket"},
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
        lineNumber: 205,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
      lineNumber: 209,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
        lineNumber: 212,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Auction Terms and Condition" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
        lineNumber: 213,
        columnNumber: 13
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
          lineNumber: 219,
          columnNumber: 15
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
          lineNumber: 222,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
          lineNumber: 221,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                  lineNumber: 229,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                  lineNumber: 230,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                lineNumber: 228,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                lineNumber: 234,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
              lineNumber: 227,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                  lineNumber: 239,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                  lineNumber: 240,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                lineNumber: 238,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                lineNumber: 244,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
              lineNumber: 237,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
            lineNumber: 226,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                lineNumber: 249,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  value: groupFilter || void 0,
                  className: "w-full max-w-xs h-11 ",
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                      lineNumber: 261,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                  lineNumber: 252,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
              lineNumber: 248,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-5", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                lineNumber: 269,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "ml-4 w-4 h-4 mb-3",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updatedData = { ...activeUserData };
                    filteredUsers.forEach((user) => {
                      updatedData[user._id] = {
                        info: {
                          status: checked,
                          userPhone: user.userPhone,
                          groupName: user.groupName,
                          userName: user.userName,
                          ticket: user.ticket
                        }
                      };
                    });
                    setActiveUserData(updatedData);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                  lineNumber: 272,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
              lineNumber: 268,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
            lineNumber: 247,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                      lineNumber: 310,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                    lineNumber: 306,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
                  lineNumber: 313,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
              lineNumber: 301,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
            lineNumber: 300,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Auction Bid Terms and Condition",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Auction Bid Terms and Condition.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
              lineNumber: 317,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
          lineNumber: 225,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
        lineNumber: 218,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
      lineNumber: 211,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
    lineNumber: 204,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx",
    lineNumber: 203,
    columnNumber: 5
  }, this);
};
_s(AuctionTermsandCondition, "dnqT5GpkUh6a2lVfloJw0nfr/G0=", false, function() {
  return [notification.useNotification];
});
_c = AuctionTermsandCondition;
export default AuctionTermsandCondition;
var _c;
$RefreshReg$(_c, "AuctionTermsandCondition");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionTermsandCondition.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRVOzJCQTdEVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFHdkIsTUFBTUMsMkJBQTJCQSxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlqQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDa0IsV0FBV0MsWUFBWSxJQUFJbkIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ29CLGFBQWFDLGNBQWMsSUFBSXJCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNzQixVQUFVQyxXQUFXLElBQUl2QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDd0IsUUFBUUMsU0FBUyxJQUFJekIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzBCLGdCQUFnQkMsaUJBQWlCLElBQUkzQixTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUM0QixXQUFXQyxZQUFZLElBQUk3QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDOEIsWUFBWUMsYUFBYSxJQUFJL0IsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ2dDLFVBQVVDLGFBQWEsSUFBSXhCLGFBQWF5QixnQkFBZ0I7QUFDL0QsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlwQyxTQUFTLEtBQUs7QUFFaEQsUUFBTSxDQUFDcUMsYUFBYUMsY0FBYyxJQUFJdEMsU0FBUyxFQUFFO0FBRWpELFFBQU11QyxlQUFlO0FBQUEsSUFDbkIsR0FBRyxJQUFJQztBQUFBQSxNQUNMdEIsVUFDR3VCO0FBQUFBLFFBQ0MsQ0FBQ0MsTUFDQ0EsRUFBRUMsY0FBY0MsVUFDaEJGLEVBQUVDLGNBQWMsTUFDaEJELEVBQUVDLGNBQWM7QUFBQSxNQUNwQixFQUNDRSxJQUFJLENBQUNILE1BQU1BLEVBQUVDLFNBQVM7QUFBQSxJQUMzQjtBQUFBLEVBQUM7QUFFSCxRQUFNRyxnQkFBZ0I3QyxRQUFRLE1BQU07QUFDbEMsVUFBTThDLFdBQVd4QztBQUFBQSxNQUNmVyxVQUFVdUIsT0FBTyxDQUFDQyxNQUFNO0FBQ3RCLGNBQU1NLGFBQWE1QixjQUFjc0IsRUFBRUMsY0FBY3ZCLGNBQWM7QUFDL0QsY0FBTTZCLGlCQUFpQixJQUFJQyxLQUFLUixFQUFFTyxjQUFjO0FBQ2hELGNBQU1FLGdCQUFnQjdCLFdBQ2xCMkIsa0JBQWtCLElBQUlDLEtBQUs1QixRQUFRLElBQ25DO0FBQ0osY0FBTThCLGNBQWM1QixTQUFTeUIsa0JBQWtCLElBQUlDLEtBQUsxQixNQUFNLElBQUk7QUFDbEUsZUFBT3dCLGNBQWNHLGlCQUFpQkM7QUFBQUEsTUFDeEMsQ0FBQztBQUFBLE1BQ0RwQztBQUFBQSxJQUNGO0FBRUEsV0FBTytCLFNBQVNGLElBQUksQ0FBQ1EsTUFBTUMsVUFBVTtBQUNuQyxZQUFNQyxhQUFhLENBQUMsQ0FBQzdCLGVBQWUyQixLQUFLRyxHQUFHLEdBQUdDLE1BQU1DO0FBRXJELGFBQU87QUFBQSxRQUNMLEdBQUdMO0FBQUFBLFFBQ0hNLE9BQU9MLFFBQVE7QUFBQSxRQUNmTSxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTTDtBQUFBQSxZQUNULFVBQVUsQ0FBQ00sTUFBTTtBQUNmbEMsZ0NBQWtCLENBQUNtQyxVQUFVO0FBQUEsZ0JBQzNCLEdBQUdBO0FBQUFBLGdCQUNILENBQUNULEtBQUtHLEdBQUcsR0FBRztBQUFBLGtCQUNWQyxNQUFNO0FBQUEsb0JBQ0pDLFFBQVFHLEVBQUVFLE9BQU9DO0FBQUFBLG9CQUNqQkMsV0FBV1osS0FBS1k7QUFBQUEsb0JBQ2hCdEIsV0FBV1UsS0FBS1Y7QUFBQUEsb0JBQ2hCdUIsVUFBVWIsS0FBS2E7QUFBQUEsb0JBQ2ZDLFFBQVFkLEtBQUtjO0FBQUFBLGtCQUNmO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGLEVBQUU7QUFBQSxZQUNKO0FBQUE7QUFBQSxVQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFnQkk7QUFBQSxRQUdOWjtBQUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNyQyxXQUFXRSxhQUFhRSxVQUFVRSxRQUFRUixZQUFZVSxjQUFjLENBQUM7QUFFekUsUUFBTTBDLHVCQUF1Qm5FLFFBQVEsTUFBTTtBQUN6QyxXQUFPNkMsY0FBY0wsT0FBTyxDQUFDWSxTQUFTQSxLQUFLRSxVQUFVLEVBQUVjO0FBQUFBLEVBQ3pELEdBQUcsQ0FBQ3ZCLGFBQWEsQ0FBQztBQUVsQixRQUFNd0IsZUFBZSxZQUFZO0FBQy9CLFVBQU1DLE1BQU07QUFDWixRQUFJO0FBQ0Z2QyxlQUFTd0MsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFFRCxZQUFNQyxxQkFBcUIsQ0FBQztBQUM1Qi9CLG9CQUFjZ0MsUUFBUSxDQUFDekIsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxjQUFjN0IsZUFBZTJCLEtBQUtHLEdBQUcsR0FBRztBQUMvQ3FCLDZCQUFtQnhCLEtBQUtHLEdBQUcsSUFBSTlCLGVBQWUyQixLQUFLRyxHQUFHO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNdEQsSUFBSTZFLEtBQUssMENBQTBDO0FBQUEsUUFDdkRDLFdBQVdIO0FBQUFBLE1BQ2IsQ0FBQztBQUVELFlBQU1JLG9CQUFvQixFQUFFLEdBQUd2RCxlQUFlO0FBQzlDb0Isb0JBQWNnQyxRQUFRLENBQUN6QixTQUFTO0FBQzlCLFlBQUlBLEtBQUtFLFlBQVk7QUFDbkIsaUJBQU8wQixrQkFBa0I1QixLQUFLRyxHQUFHO0FBQUEsUUFDbkM7QUFBQSxNQUNGLENBQUM7QUFDRDdCLHdCQUFrQnNELGlCQUFpQjtBQUVuQ2pELGVBQVN3QyxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsU0FBU00sS0FBSztBQUNabEQsZUFBU3dDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYVEsSUFBSVQsV0FBVztBQUFBLFFBQzVCRSxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0E3RSxZQUFVLE1BQU07QUFFZCxVQUFNb0YsYUFDSnJDLGNBQWN1QixTQUFTLEtBQ3ZCdkIsY0FBY3NDLE1BQU0sQ0FBQy9CLFNBQVMzQixlQUFlMkIsS0FBS0csR0FBRyxHQUFHQyxNQUFNQyxNQUFNO0FBQ3RFdEIsaUJBQWErQyxVQUFVO0FBQUEsRUFDekIsR0FBRyxDQUFDckMsZUFBZXBCLGNBQWMsQ0FBQztBQUNsQyxRQUFNMkQsWUFBWSxZQUFZO0FBQzVCLFFBQUk7QUFDRnhELG1CQUFhLElBQUk7QUFDakIsWUFBTXlELGlCQUFpQixNQUFNcEYsSUFBSXFGLElBQUksc0JBQXNCO0FBQzNELFlBQU1DLFlBQVk7QUFDbEIsWUFBTUMsYUFBYSxDQUFDO0FBRXBCLFlBQU1wRCxlQUFjaUQsZUFBZUksTUFBTUMsUUFBUTlDLElBQUksQ0FBQzhDLFNBQVNyQyxVQUFVO0FBQ3ZFLGNBQU1zQyxLQUFLRCxRQUFRbkM7QUFDbkIsY0FBTVUsV0FBV3lCLFNBQVNFLFNBQVNDO0FBQ25DLGNBQU03QixZQUFZMEIsU0FBU0UsU0FBU0U7QUFDcEMsY0FBTXBELFlBQVlnRCxTQUFTSyxVQUFVQztBQUNyQyxjQUFNOUIsU0FBU3dCLFNBQVN4QjtBQUN4QnNCLG1CQUFXRyxFQUFFLElBQUk7QUFBQSxVQUNmbkMsTUFBTSxFQUFFQyxRQUFRLE1BQU07QUFBQSxRQUN4QjtBQUNBLGNBQU13QyxXQUFXO0FBQUEsVUFDZjFDLEtBQUtvQztBQUFBQSxVQUNMMUI7QUFBQUEsVUFDQUQ7QUFBQUEsVUFDQXRCO0FBQUFBLFVBQ0F3QjtBQUFBQSxVQUNBbEIsZ0JBQWdCMEMsUUFBUUssVUFBVUc7QUFBQUEsUUFDcEM7QUFDQVgsa0JBQVVZLEtBQUtGLFFBQVE7QUFFdkIsZUFBTztBQUFBLFVBQ0xHLE1BQU0vQyxRQUFRO0FBQUEsVUFDZFg7QUFBQUEsVUFDQXVCO0FBQUFBLFVBQ0FEO0FBQUFBLFVBQ0FFO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFDRDdCLHFCQUFlRCxZQUFXO0FBQzFCbEIsbUJBQWFxRSxTQUFTO0FBQ3RCekQsb0JBQWN5RCxVQUFVbkIsTUFBTTtBQUFBLElBQ2hDLFNBQVNpQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0MsVUFBQztBQUNDekUsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBOUIsWUFBVSxNQUFNO0FBQ2RzRixjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxRQUFNbUIsaUJBQWlCO0FBQUEsSUFDckIsRUFBRWpDLEtBQUssU0FBU2tDLFFBQVEsU0FBUztBQUFBLElBQ2pDLEVBQUVsQyxLQUFLLGFBQWFrQyxRQUFRLGNBQWM7QUFBQSxJQUMxQyxFQUFFbEMsS0FBSyxZQUFZa0MsUUFBUSxnQkFBZ0I7QUFBQSxJQUMzQyxFQUFFbEMsS0FBSyxhQUFha0MsUUFBUSxlQUFlO0FBQUE7QUFBQSxJQUUzQyxFQUFFbEMsS0FBSyxhQUFha0MsUUFBUSxhQUFhO0FBQUE7QUFBQSxFQUN6QztBQUdGLFNBQ0QsdUJBQUMsU0FBSSxXQUFVLFVBQ1YsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCLENBQUM1QyxNQUFNNUMsY0FBYzRDLEVBQUVFLE9BQU8yQyxLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBRU4sdUJBQUMsU0FBSSxXQUFVLGlCQUNWO0FBQUEsNkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDZCx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLDJDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVDekU7QUFBQUEsTUFDRCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFDakVMLFlBQ0wsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsa0JBQWUsT0FBTSxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFSSx1QkFBQyxTQUFJLFdBQVUsU0FDRDtBQUFBLGlDQUFDLFNBQUksV0FBVSxtREFDekM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQSxnQkFDcEQsdUJBQUMsT0FBRSxXQUFVLHNDQUNWa0Isd0JBQWN1QixVQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsV0FBUSxXQUFVLDhCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBLGlCQVAvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QixrQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxnQkFDdkQsdUJBQUMsT0FBRSxXQUFVLHFDQUNWRCxrQ0FESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsaUJBQWMsV0FBVSw2QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Q7QUFBQSxpQkFQcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBbkIwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CNUI7QUFBQSxVQUNnQix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTyxFQUFFdUMsT0FBTyxJQUFJO0FBQUEsa0JBQ3BCO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLFVBQVUsQ0FBQ0QsVUFBVXJGLGVBQWVxRixLQUFLO0FBQUEsa0JBQ3pDLE9BQU90RixlQUFld0I7QUFBQUEsa0JBQ3RCLFdBQVU7QUFBQSxrQkFFVEwsdUJBQWFNO0FBQUFBLG9CQUFJLENBQUMrRCxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBU3pFO0FBQUFBLGtCQUNULFVBQVUsQ0FBQzBCLE1BQU07QUFDZiwwQkFBTUcsVUFBVUgsRUFBRUUsT0FBT0M7QUFDekI1QixpQ0FBYTRCLE9BQU87QUFFcEIsMEJBQU02QyxjQUFjLEVBQUUsR0FBR25GLGVBQWU7QUFHeENvQixrQ0FBY2dDLFFBQVEsQ0FBQ3pCLFNBQVM7QUFDOUJ3RCxrQ0FBWXhELEtBQUtHLEdBQUcsSUFBSTtBQUFBLHdCQUN0QkMsTUFBTTtBQUFBLDBCQUNKQyxRQUFRTTtBQUFBQSwwQkFDUkMsV0FBV1osS0FBS1k7QUFBQUEsMEJBQ2hCdEIsV0FBV1UsS0FBS1Y7QUFBQUEsMEJBQ2hCdUIsVUFBVWIsS0FBS2E7QUFBQUEsMEJBQ2ZDLFFBQVFkLEtBQUtjO0FBQUFBLHdCQUNmO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRixDQUFDO0FBRUR4QyxzQ0FBa0JrRixXQUFXO0FBQUEsa0JBQy9CO0FBQUE7QUFBQSxnQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBd0JJO0FBQUEsaUJBNUJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsZUFuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvREE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3ZDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVRGO0FBQUFBLHVDQUF1QixLQUN0QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxpQ0FBaUNBLG9CQUFvQjtBQUFBLG9CQUU1RCxpQ0FBQyxVQUFNQSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QjtBQUFBO0FBQUEsa0JBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUVGLHVCQUFDLGNBQVcsV0FBVSxRQUFPLE1BQU0sTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQVozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTXRCO0FBQUFBLGNBQ04sU0FBUzBEO0FBQUFBLGNBQ1QsU0FBUTtBQUFBLGNBQ1IsaUJBQWdCO0FBQUEsY0FDaEIsaUJBQWlCLENBQUMsWUFBWTtBQUFBLGNBQzlCLG1CQUFtQixDQUFDcEYsV0FBVztBQUFBLGNBQy9CLGtCQUFrQjtBQUFBO0FBQUEsWUFQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTzBEO0FBQUEsYUFuRzVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxR0E7QUFBQSxXQTVHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEdBO0FBQUEsU0FySEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNIQTtBQUFBLE9BN0hKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErSEEsS0FoSUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlJRztBQUVKO0FBQUVMLEdBL1RJRCwwQkFBd0I7QUFBQSxVQVNNTCxhQUFheUIsZUFBZTtBQUFBO0FBQUE0RSxLQVQxRGhHO0FBaVVOLGVBQWVBO0FBQXlCLElBQUFnRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJGYVdoYXRzYXBwIiwibm90aWZpY2F0aW9uIiwiU2lkZWJhciIsIkZhVXNlcnMiLCJGYUNoZWNrQ2lyY2xlIiwiQnJlYWRjcnVtYiIsIkF1Y3Rpb25UZXJtc2FuZENvbmRpdGlvbiIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImF1Y3Rpb25EYXRhIiwic2V0QXVjdGlvbkRhdGEiLCJncm91cE9wdGlvbnMiLCJTZXQiLCJmaWx0ZXIiLCJ1IiwiZ3JvdXBOYW1lIiwidW5kZWZpbmVkIiwibWFwIiwiZmlsdGVyZWRVc2VycyIsImZpbHRlcmVkIiwibWF0Y2hHcm91cCIsImVucm9sbG1lbnREYXRlIiwiRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJfaWQiLCJpbmZvIiwic3RhdHVzIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJ1c2VyUGhvbmUiLCJ1c2VyTmFtZSIsInRpY2tldCIsInZpc2libGVTZWxlY3RlZENvdW50IiwibGVuZ3RoIiwic2VuZFdoYXRzYXBwIiwia2V5Iiwib3BlbiIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsImNsYXNzTmFtZSIsImR1cmF0aW9uIiwidmlzaWJsZUFjdGl2ZVVzZXJzIiwiZm9yRWFjaCIsInBvc3QiLCJyZWNlaXZlcnMiLCJuZXdBY3RpdmVVc2VyRGF0YSIsImVyciIsImFsbENoZWNrZWQiLCJldmVyeSIsImZldGNoRGF0YSIsInJlcG9ydFJlc3BvbnNlIiwiZ2V0IiwidXNlcnNMaXN0IiwidGVtcEFjdGl2ZSIsImRhdGEiLCJhdWN0aW9uIiwiaWQiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwidGVtcFVzZXIiLCJjcmVhdGVkQXQiLCJwdXNoIiwic2xObyIsImVycm9yIiwiY29uc29sZSIsIkF1Y3Rpb25jb2x1bW5zIiwiaGVhZGVyIiwidmFsdWUiLCJ3aWR0aCIsImdyb3VwIiwidXBkYXRlZERhdGEiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdWN0aW9uVGVybXNhbmRDb25kaXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHAgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IEZhVXNlcnMsIEZhQ2hlY2tDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuXHJcbmNvbnN0IEF1Y3Rpb25UZXJtc2FuZENvbmRpdGlvbiA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFthdWN0aW9uRGF0YSwgc2V0QXVjdGlvbkRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIC8vY29uc3QgZ3JvdXBPcHRpb25zID0gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpKV07XHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gW1xyXG4gICAgLi4ubmV3IFNldChcclxuICAgICAgdXNlcnNEYXRhXHJcbiAgICAgICAgLmZpbHRlcihcclxuICAgICAgICAgICh1KSA9PlxyXG4gICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gdW5kZWZpbmVkICYmXHJcbiAgICAgICAgICAgIHUuZ3JvdXBOYW1lICE9PSBcIlwiICYmXHJcbiAgICAgICAgICAgIHUuZ3JvdXBOYW1lICE9PSBcIiAgIFwiXHJcbiAgICAgICAgKSAvLyBGaWx0ZXIgb3V0IHVuZGVmaW5lZCwgZW1wdHksIGFuZCB3aGl0ZXNwYWNlLW9ubHkgdmFsdWVzXHJcbiAgICAgICAgLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpXHJcbiAgICApLFxyXG4gIF07XHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBmaWx0ZXJPcHRpb24oXHJcbiAgICAgIHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuICAgICAgICBjb25zdCBtYXRjaEdyb3VwID0gZ3JvdXBGaWx0ZXIgPyB1Lmdyb3VwTmFtZSA9PT0gZ3JvdXBGaWx0ZXIgOiB0cnVlO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gbmV3IERhdGUodS5lbnJvbGxtZW50RGF0ZSk7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hGcm9tRGF0ZSA9IGZyb21EYXRlXHJcbiAgICAgICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZyb21EYXRlKVxyXG4gICAgICAgICAgOiB0cnVlO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoVG9EYXRlID0gdG9EYXRlID8gZW5yb2xsbWVudERhdGUgPD0gbmV3IERhdGUodG9EYXRlKSA6IHRydWU7XHJcbiAgICAgICAgcmV0dXJuIG1hdGNoR3JvdXAgJiYgbWF0Y2hGcm9tRGF0ZSAmJiBtYXRjaFRvRGF0ZTtcclxuICAgICAgfSksXHJcbiAgICAgIHNlYXJjaFRleHRcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnVzZXIsXHJcbiAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgICBjaGVja0JveHM6IChcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbiAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHRpY2tldDogdXNlci50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSxcclxuICAgICAgICBpc1NlbGVjdGVkLFxyXG4gICAgICB9O1xyXG4gICAgfSk7XHJcbiAgfSwgW3VzZXJzRGF0YSwgZ3JvdXBGaWx0ZXIsIGZyb21EYXRlLCB0b0RhdGUsIHNlYXJjaFRleHQsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIGNvbnN0IHZpc2libGVTZWxlY3RlZENvdW50ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHVzZXIpID0+IHVzZXIuaXNTZWxlY3RlZCkubGVuZ3RoO1xyXG4gIH0sIFtmaWx0ZXJlZFVzZXJzXSk7XHJcblxyXG4gIGNvbnN0IHNlbmRXaGF0c2FwcCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGtleSA9IFwidXBkYXRhYmxlXCI7XHJcbiAgICB0cnkge1xyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJTZW5kaW5nIE1lc3NhZ2VzIFZpYSBXaGF0c2FwcC4uXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvY2Vzc2luZy4uLlwiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCB2aXNpYmxlQWN0aXZlVXNlcnMgPSB7fTtcclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCAmJiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0pIHtcclxuICAgICAgICAgIHZpc2libGVBY3RpdmVVc2Vyc1t1c2VyLl9pZF0gPSBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3doYXRzYXBwL2JpZC1ydWxlcy1yZWd1bGF0aW9uLW1lc3NhZ2VcIiwge1xyXG4gICAgICAgIHJlY2VpdmVyczogdmlzaWJsZUFjdGl2ZVVzZXJzLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IG5ld0FjdGl2ZVVzZXJEYXRhID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgICBpZiAodXNlci5pc1NlbGVjdGVkKSB7XHJcbiAgICAgICAgICBkZWxldGUgbmV3QWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKG5ld0FjdGl2ZVVzZXJEYXRhKTtcclxuXHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIE1lc3NhZ2VzIEhhcyBCZWVuIFNlbnQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU3VjY2Vzc1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIFNlbmQgV2hhdHNhcHBcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyLm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIEF1dG9tYXRpY2FsbHkgdXBkYXRlIHNlbGVjdEFsbCBiYXNlZCBvbiBmaWx0ZXJlZFVzZXJzXHJcbiAgICBjb25zdCBhbGxDaGVja2VkID1cclxuICAgICAgZmlsdGVyZWRVc2Vycy5sZW5ndGggPiAwICYmXHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZXZlcnkoKHVzZXIpID0+IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXT8uaW5mbz8uc3RhdHVzKTtcclxuICAgIHNldFNlbGVjdEFsbChhbGxDaGVja2VkKTtcclxuICB9LCBbZmlsdGVyZWRVc2VycywgYWN0aXZlVXNlckRhdGFdKTtcclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hdWN0aW9uL2dldC1hdWN0aW9uXCIpO1xyXG4gICAgICBjb25zdCB1c2Vyc0xpc3QgPSBbXTtcclxuICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG5cclxuICAgICAgY29uc3QgYXVjdGlvbkRhdGEgPSByZXBvcnRSZXNwb25zZS5kYXRhPy5hdWN0aW9uLm1hcCgoYXVjdGlvbiwgaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBpZCA9IGF1Y3Rpb24uX2lkO1xyXG4gICAgICAgIGNvbnN0IHVzZXJOYW1lID0gYXVjdGlvbj8udXNlcl9pZD8uZnVsbF9uYW1lO1xyXG4gICAgICAgIGNvbnN0IHVzZXJQaG9uZSA9IGF1Y3Rpb24/LnVzZXJfaWQ/LnBob25lX251bWJlcjtcclxuICAgICAgICBjb25zdCBncm91cE5hbWUgPSBhdWN0aW9uPy5ncm91cF9pZD8uZ3JvdXBfbmFtZTtcclxuICAgICAgICBjb25zdCB0aWNrZXQgPSBhdWN0aW9uPy50aWNrZXQ7XHJcbiAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7XHJcbiAgICAgICAgICBpbmZvOiB7IHN0YXR1czogZmFsc2UgfSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IHRlbXBVc2VyID0ge1xyXG4gICAgICAgICAgX2lkOiBpZCxcclxuICAgICAgICAgIHVzZXJOYW1lLFxyXG4gICAgICAgICAgdXNlclBob25lLFxyXG4gICAgICAgICAgZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgdGlja2V0LFxyXG4gICAgICAgICAgZW5yb2xsbWVudERhdGU6IGF1Y3Rpb24uZ3JvdXBfaWQ/LmNyZWF0ZWRBdCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHVzZXJzTGlzdC5wdXNoKHRlbXBVc2VyKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgIHVzZXJOYW1lLFxyXG4gICAgICAgICAgdXNlclBob25lLFxyXG4gICAgICAgICAgdGlja2V0LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBdWN0aW9uRGF0YShhdWN0aW9uRGF0YSk7XHJcbiAgICAgIHNldFVzZXJzRGF0YSh1c2Vyc0xpc3QpO1xyXG4gICAgICBzZXRUb3RhbFVzZXJzKHVzZXJzTGlzdC5sZW5ndGgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgQXVjdGlvbmNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImNoZWNrQm94c1wiLCBoZWFkZXI6IFwiU2VsZWN0IFVzZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIC8vICB7a2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIn0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyLz5cclxuICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG10LTJcIj5cclxuICAgICAgICAgICAgICBBdWN0aW9uIFRlcm1zIGFuZCBDb25kaXRpb25cclxuICAgICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LXN0YXJ0IGJvcmRlci1iIGJvcmRlci1ncmF5LTMwMCBtYi00XCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC02IG10LTggbWItNlwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Ub3RhbCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDBcIj5cclxuICAgICAgICB7ZmlsdGVyZWRVc2Vycy5sZW5ndGh9XHJcbiAgICAgIDwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgPEZhVXNlcnMgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIHRleHQtNHhsXCIgLz5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgcm91bmRlZC14bCBwLTYgc2hhZG93IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgPGRpdj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+U2VsZWN0ZWQgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnR9XHJcbiAgICAgIDwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTEgXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IHctNCBoLTQgbWItM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTsgLy8gU2V0IGdsb2JhbCBjaGVja2JveCBzdGF0ZVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBMb29wIHRocm91Z2ggYWxsIGZpbHRlcmVkIHVzZXJzIGFuZCBhcHBseSB0aGUgc2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW3VzZXIuX2lkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0OiB1c2VyLnRpY2tldCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh1cGRhdGVkRGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTYgaC02IGFic29sdXRlIC1yaWdodC0zIC10b3AtMiBzaGFkb3ctbGcgaG92ZXI6YmctcmVkLTYwMCBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YE1lc3NhZ2Ugd2lsbCBiZSBzZW50IHRvIHRvdGFsICR7dmlzaWJsZVNlbGVjdGVkQ291bnR9IGN1c3RvbWVyc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt2aXNpYmxlU2VsZWN0ZWRDb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cIm1yLTJcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkF1Y3Rpb24gQmlkIFRlcm1zIGFuZCBDb25kaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcIkdyb3VwIE5hbWVcIl19XHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbZ3JvdXBGaWx0ZXJdfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgQXVjdGlvbiBCaWQgVGVybXMgYW5kIENvbmRpdGlvbi5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgIFxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWN0aW9uVGVybXNhbmRDb25kaXRpb247XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9BdWN0aW9uVGVybXNhbmRDb25kaXRpb24uanN4In0=