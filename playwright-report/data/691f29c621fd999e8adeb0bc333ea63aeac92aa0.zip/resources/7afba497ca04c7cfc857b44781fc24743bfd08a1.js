import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/WhatsappFailed.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import whatsappApi from "/src/instance/WhatsappInstance.js";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const WhatsappFailed = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [TableUsers, setTableUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [selectUser, setSelectUser] = useState({});
  const [customerCount, setCustomerCount] = useState(0);
  const [selectAll, setSelectAll] = useState({ msg: "No", checked: false });
  const [formData, setFormData] = useState({
    template_name: ""
  });
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [updateFormData, setUpdateFormData] = useState({
    full_name: "",
    phone_number: ""
  });
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [errors, setErrors] = useState({});
  const [templateErrors, setTemplateErrors] = useState({});
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/whatsapp/get-failed-users");
        setUsers(response.data);
        const initialSelected = {};
        response.data.forEach((user) => {
          initialSelected[user._id] = false;
        });
        setSelectUser(initialSelected);
      } catch (error) {
        console.error("Error fetching user data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  useEffect(() => {
    const updateUI = () => {
      const formattedData = users.map((group, index) => ({
        id: index + 1,
        name: group.full_name,
        phone_number: group.phone_number,
        customer_id: group.customer_id || `Updating soon...`,
        template_name: group.template_name,
        valid_mobile_number: group.phone_number?.match(/^[7-9][0-9]{9}$/) ? /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-green-700", children: "Valid" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 72,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-red-700", children: "InValid" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 74,
          columnNumber: 9
        }, this),
        select_customer: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "border border-red-400 text-white px-4 py-2 rounded-md shadow hover:border-red-700 transition duration-200",
            onClick: () => {
              setSelectUser((prevSelectedUser) => ({
                ...prevSelectedUser,
                [group._id]: !prevSelectedUser[group._id]
              }));
            },
            children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                checked: selectUser[group?._id] ?? false,
                className: "checked:text-red-600 focus:ring-0  rounded-lg p-2"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 87,
                columnNumber: 15
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 78,
            columnNumber: 13
          },
          this
        ) }, group._id, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 77,
          columnNumber: 9
        }, this),
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleUpdateModalOpen(group._id),
              className: "border border-green-400 text-white px-4 py-2 rounded-md shadow hover:border-green-700 transition duration-200",
              children: /* @__PURE__ */ jsxDEV(CiEdit, { color: "green" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 101,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 97,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleDeleteModalOpen(group._id),
              className: "border border-red-400 text-white px-4 py-2 rounded-md shadow hover:border-red-700 transition duration-200",
              children: /* @__PURE__ */ jsxDEV(MdDelete, { color: "red" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 107,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 103,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 96,
          columnNumber: 9
        }, this)
      }));
      setTableUsers(formattedData);
    };
    updateUI();
  }, [selectUser, reloadTrigger]);
  useEffect(() => {
    const countCustomer = () => {
      let counter = 0;
      Object.values(selectUser).forEach((ele) => {
        if (ele) {
          counter++;
        }
      });
      setCustomerCount(counter);
    };
    countCustomer();
  }, [selectUser, reloadTrigger]);
  const validateTemplate = (type) => {
    const newErrors = {};
    if (!formData.template_name.trim()) {
      newErrors.template_name = "Template name is required";
    }
    setTemplateErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateTemplate();
    try {
      if (isValid) {
        setDisabled(true);
        const response = await whatsappApi.post("/failed-customers", {
          selectUser,
          template_name: formData.template_name
        });
        if (response.status === 201) {
          setShowModal(false);
          setTemplateErrors({});
          setFormData({
            template_name: ""
          });
          setReloadTrigger((prev) => prev + 1);
          setAlertConfig({
            type: "success",
            message: "Whatsapped Successfully",
            visibility: true
          });
        }
        if (response.status >= 400) {
          setShowModal(false);
          setDisabled(false);
          setTemplateErrors({});
          setFormData({
            template_name: ""
          });
          setAlertConfig({
            type: "error",
            message: "Whatsapp Failure",
            visibility: true
          });
        }
        setShowModal(false);
        setTemplateErrors({});
        setFormData({
          template_name: ""
        });
      }
    } catch (err) {
      setAlertConfig({
        type: "error",
        message: "Whatsapp Failure",
        visibility: true
      });
    }
  };
  const handleSelectAll = () => {
    const checked = !selectAll.checked;
    setSelectAll({
      ...selectAll,
      msg: selectAll.msg === "All" ? "No" : "All",
      checked: !selectAll.checked
    });
    const tempSelectUser = {};
    Object.keys(selectUser).forEach((user_id) => {
      tempSelectUser[user_id] = checked;
    });
    setSelectUser(tempSelectUser);
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addCustomer" ? formData : updateFormData;
    const regex = {
      phone: /^[6-9]\d{9}$/
    };
    if (!data.full_name.trim()) {
      newErrors.full_name = "Full Name is required";
    }
    if (!data.phone_number) {
      newErrors.phone_number = "Phone number is required";
    } else if (!regex.phone.test(data.phone_number)) {
      newErrors.phone_number = "Invalid  phone number";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        await api.patch(
          `/whatsapp/update-failed-user-by-id/${currentUpdateUser._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "User Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating user:", error.message);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error?.response?.data?.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/whatsapp/get-failed-user-by-id/${userId}`
      );
      setCurrentUpdateUser(response.data);
      setUpdateFormData({
        full_name: response.data.full_name,
        phone_number: response.data.phone_number
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/whatsapp/get-failed-user-by-id/${userId}`
      );
      setCurrentUser(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(
          `/whatsapp/delete-failed-user-by-id/${currentUser._id}`
        );
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "User deleted successfully",
          type: "success"
        });
        setShowModalDelete(false);
        setCurrentUser(null);
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };
  const columns = [
    { key: "select_customer", header: "Select Customer" },
    { key: "id", header: "SL. NO" },
    { key: "customer_id", header: "Customer Id" },
    { key: "name", header: "Customer Name" },
    { key: "template_name", header: "Template Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "valid_mobile_number", header: "Valid Mobile Number" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-screen", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 348,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
              /* @__PURE__ */ jsxDEV(
                FaWhatsapp,
                {
                  size: "30",
                  className: "m-2 text-red-600 font-bold"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                  lineNumber: 362,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold flex items-center", children: "Whatsapp Failed Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 366,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 361,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "flex items-center my-2 cursor-pointer select-none",
                onClick: handleSelectAll,
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "checkbox",
                      checked: selectAll.checked,
                      className: "rounded-sm mx-2 text-red-400 focus:outline-none cursor-pointer "
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                      lineNumber: 375,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("h2", { className: "font-medium", children: `Select ${selectAll.msg} Customers` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                    lineNumber: 380,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 371,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 360,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
              },
              className: "relative ml-4 bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200",
              children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                customerCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-10 min-h-10 absolute -right-4 bottom-6 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white p-2",
                    title: `Message will be sent to total ${customerCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { className: "shadow-sm font-medium", children: customerCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                      lineNumber: 396,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                    lineNumber: 392,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mx-1", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                  lineNumber: 401,
                  columnNumber: 21
                }, this),
                "Whatsapp Again"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 390,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 384,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 359,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 358,
          columnNumber: 13
        }, this),
        TableUsers.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: TableUsers,
            columns,
            exportedFileName: `WhatsappFailedCustomers-${TableUsers.length > 0 ? TableUsers[0].name + " to " + TableUsers[TableUsers.length - 1].name : "empty"}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 408,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableUsers.length <= 0,
            data: "Group Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 419,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
        lineNumber: 357,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
      lineNumber: 346,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Send Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
        lineNumber: 429,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "template",
              children: "Template Name"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 434,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              name: "template_name",
              value: formData.template_name,
              onChange: handleChange,
              id: "templateName",
              placeholder: "Paste template name",
              required: true,
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 w-full p-2.5"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 440,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 433,
          columnNumber: 15
        }, this),
        templateErrors.template_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: templateErrors.template_name }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 452,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-full text-white bg-green-700 hover:bg-green-800\r\n              focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Send"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 456,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
        lineNumber: 432,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
      lineNumber: 428,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
      lineNumber: 427,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 473,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Full Name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                  lineNumber: 478,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "full_name",
                  value: updateFormData.full_name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Full Name",
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                  lineNumber: 484,
                  columnNumber: 17
                },
                this
              ),
              errors.full_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.full_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 495,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 477,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "date",
                  children: "Phone Number"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                  lineNumber: 502,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "phone_number",
                  value: updateFormData.phone_number,
                  onChange: handleInputChange,
                  id: "text",
                  placeholder: "Enter Phone Number",
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                  lineNumber: 508,
                  columnNumber: 19
                },
                this
              ),
              errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 519,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 501,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 500,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full text-white bg-violet-700 hover:bg-violet-800\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                lineNumber: 526,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 476,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 472,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
        lineNumber: 468,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
            lineNumber: 545,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                          lineNumber: 562,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion."
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                      lineNumber: 557,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the User Full Name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                      lineNumber: 567,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                  lineNumber: 556,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
                    lineNumber: 575,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
              lineNumber: 549,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
          lineNumber: 544,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
        lineNumber: 537,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
    lineNumber: 345,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx",
    lineNumber: 344,
    columnNumber: 5
  }, this);
};
_s(WhatsappFailed, "qgdI4HdangZUBdrHAfxceBCutZU=");
_c = WhatsappFailed;
export default WhatsappFailed;
var _c;
$RefreshReg$(_c, "WhatsappFailed");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/WhatsappFailed.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUVVLFNBZ1JOLFVBaFJNOzJCQXZFVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxvQkFBb0I7QUFDM0IsTUFBTUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlmLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNnQixXQUFXQyxZQUFZLElBQUlqQixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDa0IsWUFBWUMsYUFBYSxJQUFJbkIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ29CLFdBQVdDLFlBQVksSUFBSXJCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNzQixTQUFTQyxVQUFVLElBQUl2QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDd0IsVUFBVUMsV0FBVyxJQUFJekIsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzBCLGFBQWFDLGNBQWMsSUFBSTNCLFNBQVM7QUFBQSxJQUM3QzRCLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJaEMsU0FBUyxDQUFDLENBQUM7QUFDL0MsUUFBTSxDQUFDaUMsZUFBZUMsZ0JBQWdCLElBQUlsQyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDbUMsV0FBV0MsWUFBWSxJQUFJcEMsU0FBUyxFQUFFcUMsS0FBSyxNQUFNQyxTQUFTLE1BQU0sQ0FBQztBQUN4RSxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXhDLFNBQVM7QUFBQSxJQUN2Q3lDLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJM0MsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzRDLGdCQUFnQkMsaUJBQWlCLElBQUk3QyxTQUFTO0FBQUEsSUFDbkQ4QyxXQUFXO0FBQUEsSUFDWEMsY0FBYztBQUFBLEVBQ2hCLENBQUM7QUFDRCxRQUFNLENBQUNDLG1CQUFtQkMsb0JBQW9CLElBQUlqRCxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDa0QsUUFBUUMsU0FBUyxJQUFJbkQsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDb0QsZ0JBQWdCQyxpQkFBaUIsSUFBSXJELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQ3NELGlCQUFpQkMsa0JBQWtCLElBQUl2RCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDd0QsYUFBYUMsY0FBYyxJQUFJekQsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQzBELGVBQWVDLGdCQUFnQixJQUFJM0QsU0FBUyxDQUFDO0FBRXBERCxZQUFVLE1BQU07QUFDZCxVQUFNNkQsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRjNDLHFCQUFhLElBQUk7QUFDakIsY0FBTTRDLFdBQVcsTUFBTXpELElBQUkwRCxJQUFJLDRCQUE0QjtBQUMzRC9DLGlCQUFTOEMsU0FBU0UsSUFBSTtBQUN0QixjQUFNQyxrQkFBa0IsQ0FBQztBQUN6QkgsaUJBQVNFLEtBQUtFLFFBQVEsQ0FBQ0MsU0FBUztBQUM5QkYsMEJBQWdCRSxLQUFLQyxHQUFHLElBQUk7QUFBQSxRQUM5QixDQUFDO0FBQ0RuQyxzQkFBY2dDLGVBQWU7QUFBQSxNQUMvQixTQUFTSSxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsTUFBTXZDLE9BQU87QUFBQSxNQUMxRCxVQUFDO0FBQ0NaLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQTJDLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQ0YsYUFBYSxDQUFDO0FBQ2xCM0QsWUFBVSxNQUFNO0FBQ2QsVUFBTXVFLFdBQVdBLE1BQU07QUFDckIsWUFBTUMsZ0JBQWdCekQsTUFBTTBELElBQUksQ0FBQ0MsT0FBT0MsV0FBVztBQUFBLFFBQ2pEQyxJQUFJRCxRQUFRO0FBQUEsUUFDWkUsTUFBTUgsTUFBTTNCO0FBQUFBLFFBQ1pDLGNBQWMwQixNQUFNMUI7QUFBQUEsUUFDcEI4QixhQUFhSixNQUFNSSxlQUFlO0FBQUEsUUFDbENwQyxlQUFlZ0MsTUFBTWhDO0FBQUFBLFFBQ3JCcUMscUJBQXFCTCxNQUFNMUIsY0FBY2dDLE1BQU0saUJBQWlCLElBQzlELHVCQUFDLFNBQUksV0FBVSw0QkFBMkIscUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0MsSUFFL0MsdUJBQUMsU0FBSSxXQUFVLDBCQUF5Qix1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFFBRWpEQyxpQkFDRSx1QkFBQyxTQUFvQixXQUFVLDZCQUM3QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNO0FBQ2JoRCw0QkFBYyxDQUFDaUQsc0JBQXNCO0FBQUEsZ0JBQ25DLEdBQUdBO0FBQUFBLGdCQUNILENBQUNSLE1BQU1OLEdBQUcsR0FBRyxDQUFDYyxpQkFBaUJSLE1BQU1OLEdBQUc7QUFBQSxjQUMxQyxFQUFFO0FBQUEsWUFDSjtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3BDLFdBQVcwQyxPQUFPTixHQUFHLEtBQUs7QUFBQSxnQkFDbkMsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHK0Q7QUFBQTtBQUFBLFVBWmpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNBLEtBZlFNLE1BQU1OLEtBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVGZSxRQUNFLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1DLHNCQUFzQlYsTUFBTU4sR0FBRztBQUFBLGNBQzlDLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFVBQU8sT0FBTSxXQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCO0FBQUE7QUFBQSxZQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTWlCLHNCQUFzQlgsTUFBTU4sR0FBRztBQUFBLGNBQzlDLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsT0FBTSxTQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQjtBQUFBO0FBQUEsWUFKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLE1BRUosRUFBRTtBQUNGaEQsb0JBQWNvRCxhQUFhO0FBQUEsSUFDN0I7QUFDQUQsYUFBUztBQUFBLEVBQ1gsR0FBRyxDQUFDdkMsWUFBWTJCLGFBQWEsQ0FBQztBQUM5QjNELFlBQVUsTUFBTTtBQUNkLFVBQU1zRixnQkFBZ0JBLE1BQU07QUFDMUIsVUFBSUMsVUFBVTtBQUNkQyxhQUFPQyxPQUFPekQsVUFBVSxFQUFFa0MsUUFBUSxDQUFDd0IsUUFBUTtBQUN6QyxZQUFJQSxLQUFLO0FBQ1BIO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFDRHBELHVCQUFpQm9ELE9BQU87QUFBQSxJQUMxQjtBQUNBRCxrQkFBYztBQUFBLEVBQ2hCLEdBQUcsQ0FBQ3RELFlBQVkyQixhQUFhLENBQUM7QUFFOUIsUUFBTWdDLG1CQUFtQkEsQ0FBQzVELFNBQVM7QUFDakMsVUFBTTZELFlBQVksQ0FBQztBQUVuQixRQUFJLENBQUNwRCxTQUFTRSxjQUFjbUQsS0FBSyxHQUFHO0FBQ2xDRCxnQkFBVWxELGdCQUFnQjtBQUFBLElBQzVCO0FBRUFZLHNCQUFrQnNDLFNBQVM7QUFDM0IsV0FBT0osT0FBT00sS0FBS0YsU0FBUyxFQUFFRyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNQyxlQUFlQSxDQUFDQyxNQUFNO0FBQzFCLFVBQU0sRUFBRXBCLE1BQU1xQixNQUFNLElBQUlELEVBQUVFO0FBQzFCMUQsZ0JBQVksQ0FBQzJELGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUN2QixJQUFJLEdBQUdxQjtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTUcsZUFBZSxPQUFPSixNQUFNO0FBQ2hDQSxNQUFFSyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVVaLGlCQUFpQjtBQUNqQyxRQUFJO0FBQ0YsVUFBSVksU0FBUztBQUNYN0Usb0JBQVksSUFBSTtBQUNoQixjQUFNb0MsV0FBVyxNQUFNdEQsWUFBWWdHLEtBQUsscUJBQXFCO0FBQUEsVUFDM0R4RTtBQUFBQSxVQUNBVSxlQUFjRixTQUFTRTtBQUFBQSxRQUN6QixDQUFDO0FBQ0QsWUFBSW9CLFNBQVMyQyxXQUFXLEtBQUs7QUFDM0JuRix1QkFBYSxLQUFLO0FBQ2xCZ0MsNEJBQWtCLENBQUMsQ0FBQztBQUNwQmIsc0JBQVk7QUFBQSxZQUNWQyxlQUFlO0FBQUEsVUFDakIsQ0FBQztBQUNEa0IsMkJBQWlCLENBQUM4QyxTQUFTQSxPQUFPLENBQUM7QUFDbkM5RSx5QkFBZTtBQUFBLFlBQ2JHLE1BQU07QUFBQSxZQUNORCxTQUFTO0FBQUEsWUFDVEQsWUFBWTtBQUFBLFVBQ2QsQ0FBQztBQUFBLFFBQ0g7QUFDQSxZQUFJaUMsU0FBUzJDLFVBQVUsS0FBSztBQUMxQm5GLHVCQUFhLEtBQUs7QUFDbEJJLHNCQUFZLEtBQUs7QUFDakI0Qiw0QkFBa0IsQ0FBQyxDQUFDO0FBQ3BCYixzQkFBWTtBQUFBLFlBQ1ZDLGVBQWU7QUFBQSxVQUNqQixDQUFDO0FBQ0RkLHlCQUFlO0FBQUEsWUFDYkcsTUFBTTtBQUFBLFlBQ05ELFNBQVM7QUFBQSxZQUNURCxZQUFZO0FBQUEsVUFDZCxDQUFDO0FBQUEsUUFDSDtBQUVBUCxxQkFBYSxLQUFLO0FBQ2xCZ0MsMEJBQWtCLENBQUMsQ0FBQztBQUNwQmIsb0JBQVk7QUFBQSxVQUNWQyxlQUFlO0FBQUEsUUFDakIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNpRSxLQUFLO0FBQ1ovRSxxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTO0FBQUEsUUFDVEQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0EsUUFBTStFLGtCQUFrQkEsTUFBTTtBQUM1QixVQUFNckUsVUFBVSxDQUFDSCxVQUFVRztBQUMzQkYsaUJBQWE7QUFBQSxNQUNYLEdBQUdEO0FBQUFBLE1BQ0hFLEtBQUtGLFVBQVVFLFFBQVEsUUFBUSxPQUFPO0FBQUEsTUFDdENDLFNBQVMsQ0FBQ0gsVUFBVUc7QUFBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU1zRSxpQkFBaUIsQ0FBQztBQUN4QnJCLFdBQU9NLEtBQUs5RCxVQUFVLEVBQUVrQyxRQUFRLENBQUM0QyxZQUFZO0FBQzNDRCxxQkFBZUMsT0FBTyxJQUFJdkU7QUFBQUEsSUFDNUIsQ0FBQztBQUNETixrQkFBYzRFLGNBQWM7QUFBQSxFQUM5QjtBQUNBLFFBQU1FLGVBQWVBLENBQUNoRixTQUFTO0FBQzdCLFVBQU02RCxZQUFZLENBQUM7QUFDbkIsVUFBTTVCLE9BQU9qQyxTQUFTLGdCQUFnQlMsV0FBV0s7QUFDakQsVUFBTW1FLFFBQVE7QUFBQSxNQUNaQyxPQUFPO0FBQUEsSUFDVDtBQUVBLFFBQUksQ0FBQ2pELEtBQUtqQixVQUFVOEMsS0FBSyxHQUFHO0FBQzFCRCxnQkFBVTdDLFlBQVk7QUFBQSxJQUN4QjtBQUVBLFFBQUksQ0FBQ2lCLEtBQUtoQixjQUFjO0FBQ3RCNEMsZ0JBQVU1QyxlQUFlO0FBQUEsSUFDM0IsV0FBVyxDQUFDZ0UsTUFBTUMsTUFBTUMsS0FBS2xELEtBQUtoQixZQUFZLEdBQUc7QUFDL0M0QyxnQkFBVTVDLGVBQWU7QUFBQSxJQUMzQjtBQUVBSSxjQUFVd0MsU0FBUztBQUNuQixXQUFPSixPQUFPTSxLQUFLRixTQUFTLEVBQUVHLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1vQixlQUFlLE9BQU9sQixNQUFNO0FBQ2hDQSxNQUFFSyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVVRLGFBQWE7QUFFN0IsUUFBSTtBQUNGLFVBQUlSLFNBQVM7QUFFWCxjQUFNbEcsSUFBSStHO0FBQUFBLFVBQ1Isc0NBQXNDbkUsa0JBQWtCbUIsR0FBRztBQUFBLFVBQzNEdkI7QUFBQUEsUUFDRjtBQUNBRCwyQkFBbUIsS0FBSztBQUN4QmdCLHlCQUFpQixDQUFDOEMsU0FBU0EsT0FBTyxDQUFDO0FBQ25DOUUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTc0MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsTUFBTXZDLE9BQU87QUFDbkQsVUFDRXVDLE1BQU1QLFlBQ05PLE1BQU1QLFNBQVNFLFFBQ2ZLLE1BQU1QLFNBQVNFLEtBQUtsQyxTQUNwQjtBQUNBRix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTLEdBQUd1QyxPQUFPUCxVQUFVRSxNQUFNbEMsT0FBTztBQUFBLFVBQzFDQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xILHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXNGLG9CQUFvQkEsQ0FBQ3BCLE1BQU07QUFDL0IsVUFBTSxFQUFFcEIsTUFBTXFCLE1BQU0sSUFBSUQsRUFBRUU7QUFDMUJyRCxzQkFBa0IsQ0FBQ3NELGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUN2QixJQUFJLEdBQUdxQjtBQUFBQSxJQUNWLEVBQUU7QUFDRjlDLGNBQVUsQ0FBQ2dELGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUN2QixJQUFJLEdBQUc7QUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTU8sd0JBQXdCLE9BQU9rQyxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNeEQsV0FBVyxNQUFNekQsSUFBSTBEO0FBQUFBLFFBQ3pCLG1DQUFtQ3VELE1BQU07QUFBQSxNQUMzQztBQUNBcEUsMkJBQXFCWSxTQUFTRSxJQUFJO0FBQ2xDbEIsd0JBQWtCO0FBQUEsUUFDaEJDLFdBQVdlLFNBQVNFLEtBQUtqQjtBQUFBQSxRQUN6QkMsY0FBY2MsU0FBU0UsS0FBS2hCO0FBQUFBLE1BQzlCLENBQUM7QUFDREoseUJBQW1CLElBQUk7QUFDdkJRLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU2lCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFDQSxRQUFNZ0Isd0JBQXdCLE9BQU9pQyxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNeEQsV0FBVyxNQUFNekQsSUFBSTBEO0FBQUFBLFFBQ3pCLG1DQUFtQ3VELE1BQU07QUFBQSxNQUMzQztBQUNBNUQscUJBQWVJLFNBQVNFLElBQUk7QUFDNUJSLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU2EsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUNBLFFBQU1rRCxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJOUQsYUFBYTtBQUNmLFVBQUk7QUFDRixjQUFNcEQsSUFBSW1IO0FBQUFBLFVBQ1Isc0NBQXNDL0QsWUFBWVcsR0FBRztBQUFBLFFBQ3ZEO0FBQ0FSLHlCQUFpQixDQUFDOEMsU0FBU0EsT0FBTyxDQUFDO0FBQ25DOUUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRHlCLDJCQUFtQixLQUFLO0FBQ3hCRSx1QkFBZSxJQUFJO0FBQUEsTUFDckIsU0FBU1csT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTW9ELFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssbUJBQW1CQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVELEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsd0JBQXdCO0FBQUEsSUFDdkQsRUFBRUQsS0FBSyx1QkFBdUJDLFFBQVEsc0JBQXNCO0FBQUEsSUFDNUQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFNBQ0UsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FFYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRCxNQUFNaEcsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUM4RSxVQUFVLEVBQUUsR0FBR0EsTUFBTTdFLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQztBQUFBLE1BR0QsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBO0FBQUEsZ0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRXdDO0FBQUEsY0FFeEMsdUJBQUMsUUFBRyxXQUFVLDRDQUEyQyx5Q0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVMrRTtBQUFBQSxnQkFFVDtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTeEUsVUFBVUc7QUFBQUEsc0JBQ25CLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHNkU7QUFBQSxrQkFFN0UsdUJBQUMsUUFBRyxXQUFVLGVBQWUsb0JBQVVILFVBQVVFLEdBQUcsZ0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlFO0FBQUE7QUFBQTtBQUFBLGNBVG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYmhCLDZCQUFhLElBQUk7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsU0FBSSxXQUFVLHFCQUNaWTtBQUFBQSxnQ0FBZ0IsS0FDZjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxpQ0FBaUNBLGFBQWE7QUFBQSxvQkFFckQsaUNBQUMsVUFBSyxXQUFVLHlCQUNiQSwyQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQSxrQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxnQkFFRix1QkFBQyxjQUFXLFdBQVUsUUFBTyxNQUFNLE1BQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUEsZ0JBQUc7QUFBQSxtQkFYM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBO0FBQUEsWUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0JBO0FBQUEsYUE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThDQSxLQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0RBO0FBQUEsUUFDQ2YsV0FBVzRFLFNBQVMsS0FBSyxDQUFDOUUsWUFDM0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU1FO0FBQUFBLFlBQ047QUFBQSxZQUNBLGtCQUFrQiwyQkFDaEJBLFdBQVc0RSxTQUFTLElBQ2hCNUUsV0FBVyxDQUFDLEVBQUUwRCxPQUNkLFNBQ0ExRCxXQUFXQSxXQUFXNEUsU0FBUyxDQUFDLEVBQUVsQixPQUNsQyxPQUFPO0FBQUE7QUFBQSxVQVJmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNTLElBRVA7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTMUQsV0FBVzRFLFVBQVU7QUFBQSxZQUM5QixNQUFNO0FBQUE7QUFBQSxVQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdxQjtBQUFBLFdBakV6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0VBO0FBQUEsU0EvRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdGQTtBQUFBLElBQ0EsdUJBQUMsU0FBTSxXQUFXMUUsV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVUrRSxjQUFjLFlBQVUsTUFDNUQ7QUFBQSwrQkFBQyxTQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFVO0FBQUE7QUFBQSxZQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU83RCxTQUFTRTtBQUFBQSxjQUNoQixVQUFVc0Q7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFReUk7QUFBQSxhQWYzSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFDQzNDLGVBQWVYLGlCQUNkLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlcseUJBQWVYLGlCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDZ0c7QUFBQTtBQUFBLFVBSDVHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStCQTtBQUFBLFNBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0EsS0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNDQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdDO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsK0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVV1RSxjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTztBQUFBO0FBQUEsZ0JBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU90RSxlQUFlRTtBQUFBQSxrQkFDdEIsVUFBVXNFO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRMkk7QUFBQSxjQUUxSWxFLE9BQU9KLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWSSxpQkFBT0osYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFNO0FBQUE7QUFBQSxnQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT0YsZUFBZUc7QUFBQUEsa0JBQ3RCLFVBQVVxRTtBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUTJJO0FBQUEsY0FFMUlsRSxPQUFPSCxnQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZHLGlCQUFPSCxnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ2lHO0FBQUE7QUFBQSxjQUg3RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeURBO0FBQUEsYUE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThEQTtBQUFBO0FBQUEsTUFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbUVBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV087QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJFLHlCQUFlLElBQUk7QUFBQSxRQUNyQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QywrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELGVBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ3dDLE1BQU07QUFDZkEsa0JBQUVLLGVBQWU7QUFDakJpQixpQ0FBaUI7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2I5RCxzQkFBWVYsYUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBO0FBQUE7QUFBQSxvQkFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLMkk7QUFBQSxxQkFoQjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDMkY7QUFBQTtBQUFBLGtCQUh2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUNBO0FBQUEsYUF0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBO0FBQUEsTUEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0RBO0FBQUEsT0FoUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlQQSxLQWxQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbVBBO0FBRUo7QUFBRWpDLEdBL2pCSUQsZ0JBQWM7QUFBQStHLEtBQWQvRztBQWlrQk4sZUFBZUE7QUFBZSxJQUFBK0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiRmFXaGF0c2FwcCIsImFwaSIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0Iiwid2hhdHNhcHBBcGkiLCJNZERlbGV0ZSIsIkNpRWRpdCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiQ2lyY3VsYXJMb2FkZXIiLCJXaGF0c2FwcEZhaWxlZCIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsIlRhYmxlVXNlcnMiLCJzZXRUYWJsZVVzZXJzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwibG9hZGluZyIsInNldExvYWRpbmciLCJkaXNhYmxlZCIsInNldERpc2FibGVkIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsInNlbGVjdFVzZXIiLCJzZXRTZWxlY3RVc2VyIiwiY3VzdG9tZXJDb3VudCIsInNldEN1c3RvbWVyQ291bnQiLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJtc2ciLCJjaGVja2VkIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInRlbXBsYXRlX25hbWUiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJ1cGRhdGVGb3JtRGF0YSIsInNldFVwZGF0ZUZvcm1EYXRhIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiY3VycmVudFVwZGF0ZVVzZXIiLCJzZXRDdXJyZW50VXBkYXRlVXNlciIsImVycm9ycyIsInNldEVycm9ycyIsInRlbXBsYXRlRXJyb3JzIiwic2V0VGVtcGxhdGVFcnJvcnMiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJjdXJyZW50VXNlciIsInNldEN1cnJlbnRVc2VyIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJmZXRjaFVzZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiaW5pdGlhbFNlbGVjdGVkIiwiZm9yRWFjaCIsInVzZXIiLCJfaWQiLCJlcnJvciIsImNvbnNvbGUiLCJ1cGRhdGVVSSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJncm91cCIsImluZGV4IiwiaWQiLCJuYW1lIiwiY3VzdG9tZXJfaWQiLCJ2YWxpZF9tb2JpbGVfbnVtYmVyIiwibWF0Y2giLCJzZWxlY3RfY3VzdG9tZXIiLCJwcmV2U2VsZWN0ZWRVc2VyIiwiYWN0aW9uIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiY291bnRDdXN0b21lciIsImNvdW50ZXIiLCJPYmplY3QiLCJ2YWx1ZXMiLCJlbGUiLCJ2YWxpZGF0ZVRlbXBsYXRlIiwibmV3RXJyb3JzIiwidHJpbSIsImtleXMiLCJsZW5ndGgiLCJoYW5kbGVDaGFuZ2UiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJwcmV2RGF0YSIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBvc3QiLCJzdGF0dXMiLCJwcmV2IiwiZXJyIiwiaGFuZGxlU2VsZWN0QWxsIiwidGVtcFNlbGVjdFVzZXIiLCJ1c2VyX2lkIiwidmFsaWRhdGVGb3JtIiwicmVnZXgiLCJwaG9uZSIsInRlc3QiLCJoYW5kbGVVcGRhdGUiLCJwYXRjaCIsImhhbmRsZUlucHV0Q2hhbmdlIiwidXNlcklkIiwiaGFuZGxlRGVsZXRlVXNlciIsImRlbGV0ZSIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJXaGF0c2FwcEZhaWxlZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCB3aGF0c2FwcEFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvV2hhdHNhcHBJbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBNZERlbGV0ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBDaUVkaXQgfSBmcm9tIFwicmVhY3QtaWNvbnMvY2lcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5jb25zdCBXaGF0c2FwcEZhaWxlZCA9ICgpID0+IHtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtUYWJsZVVzZXJzLCBzZXRUYWJsZVVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZGlzYWJsZWQsIHNldERpc2FibGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtzZWxlY3RVc2VyLCBzZXRTZWxlY3RVc2VyXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbY3VzdG9tZXJDb3VudCwgc2V0Q3VzdG9tZXJDb3VudF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoeyBtc2c6IFwiTm9cIiwgY2hlY2tlZDogZmFsc2UgfSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0ZW1wbGF0ZV9uYW1lOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBmdWxsX25hbWU6IFwiXCIsXHJcbiAgICBwaG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVVc2VyLCBzZXRDdXJyZW50VXBkYXRlVXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFt0ZW1wbGF0ZUVycm9ycywgc2V0VGVtcGxhdGVFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRVc2VyLCBzZXRDdXJyZW50VXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi93aGF0c2FwcC9nZXQtZmFpbGVkLXVzZXJzXCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIGNvbnN0IGluaXRpYWxTZWxlY3RlZCA9IHt9O1xyXG4gICAgICAgIHJlc3BvbnNlLmRhdGEuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgICAgaW5pdGlhbFNlbGVjdGVkW3VzZXIuX2lkXSA9IGZhbHNlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNlbGVjdFVzZXIoaW5pdGlhbFNlbGVjdGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgfWZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXBkYXRlVUkgPSAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB1c2Vycy5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgIG5hbWU6IGdyb3VwLmZ1bGxfbmFtZSxcclxuICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwLnBob25lX251bWJlcixcclxuICAgICAgICBjdXN0b21lcl9pZDogZ3JvdXAuY3VzdG9tZXJfaWQgfHwgYFVwZGF0aW5nIHNvb24uLi5gLFxyXG4gICAgICAgIHRlbXBsYXRlX25hbWU6IGdyb3VwLnRlbXBsYXRlX25hbWUsXHJcbiAgICAgICAgdmFsaWRfbW9iaWxlX251bWJlcjogZ3JvdXAucGhvbmVfbnVtYmVyPy5tYXRjaCgvXls3LTldWzAtOV17OX0kLykgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlZhbGlkPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcmVkLTcwMFwiPkluVmFsaWQ8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICAgIHNlbGVjdF9jdXN0b21lcjogKFxyXG4gICAgICAgICAgPGRpdiBrZXk9e2dyb3VwLl9pZH0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1yZWQtNDAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbWQgc2hhZG93IGhvdmVyOmJvcmRlci1yZWQtNzAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RVc2VyKChwcmV2U2VsZWN0ZWRVc2VyKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAuLi5wcmV2U2VsZWN0ZWRVc2VyLFxyXG4gICAgICAgICAgICAgICAgICBbZ3JvdXAuX2lkXTogIXByZXZTZWxlY3RlZFVzZXJbZ3JvdXAuX2lkXSxcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0VXNlcltncm91cD8uX2lkXSA/PyBmYWxzZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNoZWNrZWQ6dGV4dC1yZWQtNjAwIGZvY3VzOnJpbmctMCAgcm91bmRlZC1sZyBwLTJcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmVlbi00MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1tZCBzaGFkb3cgaG92ZXI6Ym9yZGVyLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8Q2lFZGl0IGNvbG9yPVwiZ3JlZW5cIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItcmVkLTQwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLW1kIHNoYWRvdyBob3Zlcjpib3JkZXItcmVkLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8TWREZWxldGUgY29sb3I9XCJyZWRcIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0VGFibGVVc2Vycyhmb3JtYXR0ZWREYXRhKTtcclxuICAgIH07XHJcbiAgICB1cGRhdGVVSSgpO1xyXG4gIH0sIFtzZWxlY3RVc2VyLCByZWxvYWRUcmlnZ2VyXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGNvdW50Q3VzdG9tZXIgPSAoKSA9PiB7XHJcbiAgICAgIGxldCBjb3VudGVyID0gMDtcclxuICAgICAgT2JqZWN0LnZhbHVlcyhzZWxlY3RVc2VyKS5mb3JFYWNoKChlbGUpID0+IHtcclxuICAgICAgICBpZiAoZWxlKSB7XHJcbiAgICAgICAgICBjb3VudGVyKys7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgICAgc2V0Q3VzdG9tZXJDb3VudChjb3VudGVyKTtcclxuICAgIH07XHJcbiAgICBjb3VudEN1c3RvbWVyKCk7XHJcbiAgfSwgW3NlbGVjdFVzZXIsIHJlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVUZW1wbGF0ZSA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuXHJcbiAgICBpZiAoIWZvcm1EYXRhLnRlbXBsYXRlX25hbWUudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy50ZW1wbGF0ZV9uYW1lID0gXCJUZW1wbGF0ZSBuYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0VGVtcGxhdGVFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVUZW1wbGF0ZSgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgICBzZXREaXNhYmxlZCh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHdoYXRzYXBwQXBpLnBvc3QoXCIvZmFpbGVkLWN1c3RvbWVyc1wiLCB7XHJcbiAgICAgICAgICBzZWxlY3RVc2VyLFxyXG4gICAgICAgICAgdGVtcGxhdGVfbmFtZTpmb3JtRGF0YS50ZW1wbGF0ZV9uYW1lXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAxKSB7XHJcbiAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0VGVtcGxhdGVFcnJvcnMoe30pO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICB0ZW1wbGF0ZV9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApIHtcclxuICAgICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICBzZXREaXNhYmxlZChmYWxzZSk7XHJcbiAgICAgICAgICBzZXRUZW1wbGF0ZUVycm9ycyh7fSk7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgIHRlbXBsYXRlX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIEZhaWx1cmVcIixcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRUZW1wbGF0ZUVycm9ycyh7fSk7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgdGVtcGxhdGVfbmFtZTogXCJcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBGYWlsdXJlXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVTZWxlY3RBbGwgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBjaGVja2VkID0gIXNlbGVjdEFsbC5jaGVja2VkO1xyXG4gICAgc2V0U2VsZWN0QWxsKHtcclxuICAgICAgLi4uc2VsZWN0QWxsLFxyXG4gICAgICBtc2c6IHNlbGVjdEFsbC5tc2cgPT09IFwiQWxsXCIgPyBcIk5vXCIgOiBcIkFsbFwiLFxyXG4gICAgICBjaGVja2VkOiAhc2VsZWN0QWxsLmNoZWNrZWQsXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHRlbXBTZWxlY3RVc2VyID0ge307XHJcbiAgICBPYmplY3Qua2V5cyhzZWxlY3RVc2VyKS5mb3JFYWNoKCh1c2VyX2lkKSA9PiB7XHJcbiAgICAgIHRlbXBTZWxlY3RVc2VyW3VzZXJfaWRdID0gY2hlY2tlZDtcclxuICAgIH0pO1xyXG4gICAgc2V0U2VsZWN0VXNlcih0ZW1wU2VsZWN0VXNlcik7XHJcbiAgfTtcclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAodHlwZSkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBjb25zdCBkYXRhID0gdHlwZSA9PT0gXCJhZGRDdXN0b21lclwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuICAgIGNvbnN0IHJlZ2V4ID0ge1xyXG4gICAgICBwaG9uZTogL15bNi05XVxcZHs5fSQvLFxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIWRhdGEuZnVsbF9uYW1lLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuZnVsbF9uYW1lID0gXCJGdWxsIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGhvbmVfbnVtYmVyKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5waG9uZV9udW1iZXIgPSBcIlBob25lIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGhvbmUudGVzdChkYXRhLnBob25lX251bWJlcikpIHtcclxuICAgICAgbmV3RXJyb3JzLnBob25lX251bWJlciA9IFwiSW52YWxpZCAgcGhvbmUgbnVtYmVyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgXHJcbiAgICAgICAgYXdhaXQgYXBpLnBhdGNoKFxyXG4gICAgICAgICAgYC93aGF0c2FwcC91cGRhdGUtZmFpbGVkLXVzZXItYnktaWQvJHtjdXJyZW50VXBkYXRlVXNlci5faWR9YCxcclxuICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJVc2VyIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHVzZXI6XCIsIGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3doYXRzYXBwL2dldC1mYWlsZWQtdXNlci1ieS1pZC8ke3VzZXJJZH1gXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVVc2VyKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgZnVsbF9uYW1lOiByZXNwb25zZS5kYXRhLmZ1bGxfbmFtZSxcclxuICAgICAgICBwaG9uZV9udW1iZXI6IHJlc3BvbnNlLmRhdGEucGhvbmVfbnVtYmVyLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXI6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3doYXRzYXBwL2dldC1mYWlsZWQtdXNlci1ieS1pZC8ke3VzZXJJZH1gXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEN1cnJlbnRVc2VyKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlVXNlciA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50VXNlcikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoXHJcbiAgICAgICAgICBgL3doYXRzYXBwL2RlbGV0ZS1mYWlsZWQtdXNlci1ieS1pZC8ke2N1cnJlbnRVc2VyLl9pZH1gXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiVXNlciBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50VXNlcihudWxsKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNlbGVjdF9jdXN0b21lclwiLCBoZWFkZXI6IFwiU2VsZWN0IEN1c3RvbWVyXCIgfSxcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGVtcGxhdGVfbmFtZVwiLCBoZWFkZXI6IFwiVGVtcGxhdGUgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJ2YWxpZF9tb2JpbGVfbnVtYmVyXCIsIGhlYWRlcjogXCJWYWxpZCBNb2JpbGUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgey8qIDxTaWRlYmFyIC8+ICovfVxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwiMzBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibS0yIHRleHQtcmVkLTYwMCBmb250LWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFdoYXRzYXBwIEZhaWxlZCBDdXN0b21lcnNcclxuICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBteS0yIGN1cnNvci1wb2ludGVyIHNlbGVjdC1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGwuY2hlY2tlZH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtc20gbXgtMiB0ZXh0LXJlZC00MDAgZm9jdXM6b3V0bGluZS1ub25lIGN1cnNvci1wb2ludGVyIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57YFNlbGVjdCAke3NlbGVjdEFsbC5tc2d9IEN1c3RvbWVyc2B9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIG1sLTQgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtaW4tdy0xMCBtaW4taC0xMCBhYnNvbHV0ZSAtcmlnaHQtNCBib3R0b20tNiBzaGFkb3ctbGcgaG92ZXI6YmctcmVkLTYwMCBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIHAtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHtjdXN0b21lckNvdW50fSBjdXN0b21lcnNgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaGFkb3ctc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJDb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJteC0xXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgV2hhdHNhcHAgQWdhaW5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgeyhUYWJsZVVzZXJzLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZykgPyAoXHJcbiAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICBkYXRhPXtUYWJsZVVzZXJzfVxyXG4gICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFdoYXRzYXBwRmFpbGVkQ3VzdG9tZXJzLSR7XHJcbiAgICAgICAgICAgICAgICBUYWJsZVVzZXJzLmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgPyBUYWJsZVVzZXJzWzBdLm5hbWUgK1xyXG4gICAgICAgICAgICAgICAgICAgIFwiIHRvIFwiICtcclxuICAgICAgICAgICAgICAgICAgICBUYWJsZVVzZXJzW1RhYmxlVXNlcnMubGVuZ3RoIC0gMV0ubmFtZVxyXG4gICAgICAgICAgICAgICAgICA6IFwiZW1wdHlcIlxyXG4gICAgICAgICAgICAgIH0uY3N2YH1cclxuICAgICAgICAgICAgLz4pOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlVXNlcnMubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtcIkdyb3VwIERhdGFcIn1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBTZW5kIE1lc3NhZ2VcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInRlbXBsYXRlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVGVtcGxhdGUgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0ZW1wbGF0ZV9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRlbXBsYXRlX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidGVtcGxhdGVOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXN0ZSB0ZW1wbGF0ZSBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctZ3JlZW4tNTAwIGZvY3VzOmJvcmRlci1ncmVlbi01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge3RlbXBsYXRlRXJyb3JzLnRlbXBsYXRlX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7dGVtcGxhdGVFcnJvcnMudGVtcGxhdGVfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctZ3JlZW4tNzAwIGhvdmVyOmJnLWdyZWVuLTgwMFxyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ncmVlbi0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTZW5kXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIHsvKiBpbnNlcnRlZCBmcm9tIGhlcmUgKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSBDdXN0b21lclxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBGdWxsIE5hbWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZnVsbF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBGdWxsIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5mdWxsX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDBcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIHsvKiBkZWxldGUgY3VzdG9tZXIgKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgQ3VzdG9tZXJcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAge2N1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlVXNlcigpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIFVzZXIgRnVsbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFdoYXRzYXBwRmFpbGVkO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvV2hhdHNhcHBGYWlsZWQuanN4In0=