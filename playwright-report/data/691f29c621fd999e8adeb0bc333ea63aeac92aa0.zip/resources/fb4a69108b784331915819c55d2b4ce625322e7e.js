import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuctionReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { BsEye } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { EyeIcon } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Dropdown, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const AuctionReport = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableAuctions, setTableAuctions] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [double, setDouble] = useState({});
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    ticket: "",
    bid_amount: "",
    commission: "",
    win_amount: "",
    divident: "",
    divident_head: "",
    payable: "",
    auction_date: "",
    next_date: "",
    group_type: "",
    auction_type: "normal"
  });
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const totalCustomers = filteredAuction.length;
  const totalBidAmount = filteredAuction.reduce(
    (sum, item) => sum + ((parseInt(item.divident) || 0) + (parseInt(item.commission) || 0)),
    0
  );
  const totalWinAmount = filteredAuction.reduce(
    (sum, item) => sum + (parseInt(item.win_amount) || 0),
    0
  );
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchDouble = async () => {
      setIsLoading(true);
      try {
        const response = await api.get(`/double/get-double/${selectedAuctionGroupId}`);
        setDouble(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchDouble();
  }, [selectedAuctionGroupId]);
  const handleGroupAuction = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    handleGroupAuctionChange(groupId);
  };
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    const options = { day: "numeric", month: "short", year: "numeric" };
    return date.toLocaleDateString("en-US", options).replace(",", " ");
  };
  const prevDate = (dateString) => {
    const date = new Date(dateString);
    date.setDate(date.getDate() - 10);
    const options = { day: "numeric", month: "short", year: "numeric" };
    return date.toLocaleDateString("en-US", options).replace(",", " ");
  };
  const handleGroupAuctionChange = async (groupId) => {
    setSelectedAuctionGroup(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/auction/get-group-auction/${groupId}`);
        if (response.data && response.data.length > 0) {
          setFilteredAuction(response.data);
          const formattedData = [
            {
              id: 1,
              date: prevDate(response?.data[0]?.auction_date),
              name: "Commencement",
              phone_number: "Commencement",
              ticket: "Commencement",
              bid_amount: 0,
              amount: 0,
              auction_type: "Commencement Auction"
            },
            ...response.data.map((group, index) => ({
              _id: group._id,
              id: index + 2,
              date: formatPayDate(group.auction_date),
              name: group.user_id?.full_name,
              phone_number: group.user_id?.phone_number,
              ticket: group.ticket,
              bid_amount: parseInt(group.divident) + parseInt(group.commission),
              status: !group?.isPrized ? "Un Prized" : group?.isPrized === "true" ? "Prized" : "Un Prized",
              auction_type: group?.auction_type.charAt(0).toUpperCase() + group?.auction_type.slice(1) + " Auction",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(group._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                            lineNumber: 160,
                            columnNumber: 21
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(group._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                            lineNumber: 171,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                    lineNumber: 183,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                  lineNumber: 154,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 153,
                columnNumber: 13
              }, this)
            }))
          ];
          setTableAuctions(formattedData);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching auction data:", error);
        setFilteredAuction([]);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Auction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "ticket", header: "Ticket" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "amount", header: "Win Amount" },
    { key: "auction_type", header: "Auction Type" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action" }
  ];
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setCurrentUpdateGroup(response.data);
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching auction:", error);
    }
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/auction/delete-auction/${currentGroup._id}`);
        alert("Auction deleted successfully");
        setShowModalDelete(false);
        setCurrentGroup(null);
        window.location.reload();
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const selectednewGroup = groups.find((g) => g._id === selectedAuctionGroupId);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
        lineNumber: 253,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
        lineNumber: 257,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mb-6", children: "Reports - Auction " }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
        lineNumber: 266,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center w-full gap-4 bg-violet-50 p-2 w-30 h-40  rounded-3xl  border   space-x-2 mb-10", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-lg text-gray-500 text-center font-semibold mb-2", children: "Auction Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
            lineNumber: 270,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              popupMatchSelectWidth: false,
              value: selectedAuctionGroupId || void 0,
              onChange: handleGroupAuction,
              placeholder: "Search or Select Auction",
              style: { height: "50px", width: "600px" },
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              children: groups.map(
                (group) => /* @__PURE__ */ jsxDEV("option", { value: group._id, children: group.group_name }, group._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                  lineNumber: 287,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
              lineNumber: 274,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
          lineNumber: 269,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
          lineNumber: 268,
          columnNumber: 15
        }, this),
        filteredAuction && filteredAuction.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              updateHandler: handleUpdateModalOpen,
              data: filterOption(TableAuctions, searchText),
              columns,
              exportedPdfName: `Auction Report`,
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [
                selectednewGroup?.group_name || "N/A"
              ],
              exportedFileName: `AuctionsReport.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
              lineNumber: 298,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-6 bg-white p-6 rounded-xl shadow-sm mt-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-500 uppercase tracking-wide", children: "Total Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 315,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-2xl font-bold text-violet-700", children: totalCustomers || 0 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 319,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-400 text-center leading-snug", children: numberToIndianWords(totalCustomers || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 323,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
              lineNumber: 314,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-500 uppercase tracking-wide", children: "Total Bid Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 330,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-2xl font-bold text-green-700", children: [
                "₹",
                (totalBidAmount || 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 334,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-400 text-center leading-snug", children: numberToIndianWords(Math.floor(totalBidAmount || 0)) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 338,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
              lineNumber: 329,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-500 uppercase tracking-wide", children: "Total Win Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 345,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-2xl font-bold text-red-700", children: [
                "₹",
                (totalWinAmount || 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 349,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-400 text-center leading-snug", children: numberToIndianWords(Math.floor(totalWinAmount || 0)) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
                lineNumber: 353,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
              lineNumber: 344,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
            lineNumber: 311,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
          lineNumber: 297,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
          lineNumber: 362,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
        lineNumber: 267,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
      lineNumber: 265,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
    lineNumber: 252,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
    lineNumber: 251,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx",
    lineNumber: 250,
    columnNumber: 5
  }, this);
};
_s(AuctionReport, "xH9vBiaXUgf1MAgATlarjo8ykDQ=");
_c = AuctionReport;
export default AuctionReport;
var _c;
$RefreshReg$(_c, "AuctionReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0o0QixTQXlJWixVQXpJWTsyQkEvSjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxhQUFhO0FBQ3RCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLFVBQVVDLGNBQWM7QUFDakMsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFFekIsU0FBU0MsMkJBQTJCO0FBRXBDLE1BQU1DLGdCQUFnQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJcEIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3FCLGVBQWVDLGdCQUFnQixJQUFJdEIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3VCLGVBQWVDLGdCQUFnQixJQUFJeEIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3lCLHNCQUFzQkMsdUJBQXVCLElBQUkxQixTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDMkIsaUJBQWlCQyxrQkFBa0IsSUFBSTVCLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUM2Qix3QkFBd0JDLHlCQUF5QixJQUFJOUIsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQytCLGVBQWVDLGdCQUFnQixJQUFJaEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2lDLGlCQUFpQkMsa0JBQWtCLElBQUlsQyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDbUMsV0FBV0MsWUFBWSxJQUFJcEMsU0FBUyxDQUFDLENBQUM7QUFDN0MsUUFBTSxDQUFDcUMsV0FBV0MsWUFBWSxJQUFJdEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3VDLGlCQUFpQkMsa0JBQWtCLElBQUl4QyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDeUMsY0FBY0MsZUFBZSxJQUFJMUMsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzJDLGlCQUFpQkMsa0JBQWtCLElBQUk1QyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNkMsb0JBQW9CQyxxQkFBcUIsSUFBSTlDLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUMrQyxRQUFRQyxTQUFTLElBQUloRCxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNpRCxZQUFZQyxhQUFhLElBQUlsRCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUQsV0FBV0MsWUFBWSxJQUFJcEQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3FELFVBQVVDLFdBQVcsSUFBSXRELFNBQVM7QUFBQSxJQUN2Q3VELFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLFlBQVk7QUFBQSxJQUNaQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxlQUFlO0FBQUEsSUFDZkMsU0FBUztBQUFBLElBQ1RDLGNBQWM7QUFBQSxJQUNkQyxXQUFXO0FBQUEsSUFDWEMsWUFBWTtBQUFBLElBQ1pDLGNBQWM7QUFBQSxFQUNoQixDQUFDO0FBRUQsUUFBTUMsOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDbkIsa0JBQWNtQixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFDQSxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXpFLFNBQVM7QUFBQSxJQUM3QzBFLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUdELFFBQU1DLGlCQUFpQjVDLGdCQUFnQjZDO0FBQ3ZDLFFBQU1DLGlCQUFpQjlDLGdCQUFnQitDO0FBQUFBLElBQ3JDLENBQUNDLEtBQUtDLFNBQVNELFFBQVFFLFNBQVNELEtBQUtyQixRQUFRLEtBQUssTUFBTXNCLFNBQVNELEtBQUt2QixVQUFVLEtBQUs7QUFBQSxJQUNyRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNeUIsaUJBQWlCbkQsZ0JBQWdCK0M7QUFBQUEsSUFDckMsQ0FBQ0MsS0FBS0MsU0FBU0QsT0FBT0UsU0FBU0QsS0FBS3RCLFVBQVUsS0FBSztBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUVBN0QsWUFBVSxNQUFNO0FBQ2QsVUFBTXNGLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNcEYsSUFBSXFGLElBQUksd0JBQXdCO0FBQ3ZEbkUsa0JBQVVrRSxTQUFTRSxJQUFJO0FBQUEsTUFDekIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUosZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMdEYsWUFBVSxNQUFNO0FBQ2QsVUFBTTRGLGNBQWMsWUFBWTtBQUM5QnZDLG1CQUFhLElBQUk7QUFDakIsVUFBSTtBQUNGLGNBQU1rQyxXQUFXLE1BQU1wRixJQUFJcUYsSUFBSSxzQkFBc0IxRCxzQkFBc0IsRUFBRTtBQUM3RW1CLGtCQUFVc0MsU0FBU0UsSUFBSTtBQUFBLE1BQ3pCLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQsVUFBQztBQUNDckMscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBdUMsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQzlELHNCQUFzQixDQUFDO0FBRTNCLFFBQU0rRCxxQkFBcUIsT0FBT0MsWUFBWTtBQUM1Qy9ELDhCQUEwQitELE9BQU87QUFDakNDLDZCQUF5QkQsT0FBTztBQUFBLEVBQ2xDO0FBQ0EsUUFBTUUsZ0JBQWdCQSxDQUFDQyxlQUFlO0FBQ3BDLFVBQU1DLE9BQU8sSUFBSUMsS0FBS0YsVUFBVTtBQUNoQyxVQUFNRyxVQUFVLEVBQUVDLEtBQUssV0FBV0MsT0FBTyxTQUFTQyxNQUFNLFVBQVU7QUFDbEUsV0FBT0wsS0FBS00sbUJBQW1CLFNBQVNKLE9BQU8sRUFBRUssUUFBUSxLQUFLLEdBQUc7QUFBQSxFQUNuRTtBQUNBLFFBQU1DLFdBQVdBLENBQUNULGVBQWU7QUFDL0IsVUFBTUMsT0FBTyxJQUFJQyxLQUFLRixVQUFVO0FBQ2hDQyxTQUFLUyxRQUFRVCxLQUFLVSxRQUFRLElBQUksRUFBRTtBQUNoQyxVQUFNUixVQUFVLEVBQUVDLEtBQUssV0FBV0MsT0FBTyxTQUFTQyxNQUFNLFVBQVU7QUFDbEUsV0FBT0wsS0FBS00sbUJBQW1CLFNBQVNKLE9BQU8sRUFBRUssUUFBUSxLQUFLLEdBQUc7QUFBQSxFQUNuRTtBQUVBLFFBQU1WLDJCQUEyQixPQUFPRCxZQUFZO0FBQ2xEbkUsNEJBQXdCbUUsT0FBTztBQUMvQixRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU1QLFdBQVcsTUFBTXBGLElBQUlxRixJQUFJLDhCQUE4Qk0sT0FBTyxFQUFFO0FBQ3RFLFlBQUlQLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtWLFNBQVMsR0FBRztBQUM3QzVDLDZCQUFtQm9ELFNBQVNFLElBQUk7QUFDaEMsZ0JBQU1vQixnQkFBZ0I7QUFBQSxZQUNwQjtBQUFBLGNBQ0VDLElBQUk7QUFBQSxjQUNKWixNQUFNUSxTQUFTbkIsVUFBVUUsS0FBSyxDQUFDLEdBQUd4QixZQUFZO0FBQUEsY0FDOUM4QyxNQUFNO0FBQUEsY0FDTkMsY0FBYztBQUFBLGNBQ2R0RCxRQUFRO0FBQUEsY0FDUkMsWUFBWTtBQUFBLGNBQ1pzRCxRQUFRO0FBQUEsY0FDUjdDLGNBQWM7QUFBQSxZQUNoQjtBQUFBLFlBQ0EsR0FBR21CLFNBQVNFLEtBQUt5QixJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxjQUN0Q0MsS0FBS0YsTUFBTUU7QUFBQUEsY0FDWFAsSUFBSU0sUUFBUTtBQUFBLGNBQ1psQixNQUFNRixjQUFjbUIsTUFBTWxELFlBQVk7QUFBQSxjQUN0QzhDLE1BQU1JLE1BQU0xRCxTQUFTNkQ7QUFBQUEsY0FDckJOLGNBQWNHLE1BQU0xRCxTQUFTdUQ7QUFBQUEsY0FDN0J0RCxRQUFReUQsTUFBTXpEO0FBQUFBLGNBQ2RDLFlBQVl5QixTQUFTK0IsTUFBTXJELFFBQVEsSUFBSXNCLFNBQVMrQixNQUFNdkQsVUFBVTtBQUFBLGNBQ2hFMkQsUUFBUSxDQUFDSixPQUFPSyxXQUNaLGNBQ0FMLE9BQU9LLGFBQWEsU0FDbEIsV0FDQTtBQUFBLGNBQ05wRCxjQUNFK0MsT0FBTy9DLGFBQWFxRCxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUMxQ1AsT0FBTy9DLGFBQWF1RCxNQUFNLENBQUMsSUFDM0I7QUFBQSxjQUNGQyxRQUNFLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFNO0FBQUEsb0JBQ0pDLE9BQU87QUFBQSxzQkFDTDtBQUFBLHdCQUNFQyxLQUFLO0FBQUEsd0JBQ0xDLE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFBTUMsc0JBQXNCYixNQUFNRSxHQUFHO0FBQUEsNEJBQUU7QUFBQTtBQUFBLDBCQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0E7QUFBQSxzQkFFSjtBQUFBLHNCQUNBO0FBQUEsd0JBQ0VTLEtBQUs7QUFBQSx3QkFDTEMsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxNQUFNRSxzQkFBc0JkLE1BQU1FLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQTdCakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0NBO0FBQUEsWUFFSixFQUFFO0FBQUEsVUFBQztBQUVMOUYsMkJBQWlCc0YsYUFBYTtBQUFBLFFBQ2hDLE9BQU87QUFDTDFFLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVN1RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRHZELDJCQUFtQixFQUFFO0FBQUEsTUFDdkI7QUFBQSxJQUNGLE9BQU87QUFDTEEseUJBQW1CLEVBQUU7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0YsVUFBVTtBQUFBLElBQ2QsRUFBRUosS0FBSyxNQUFNSyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFTCxLQUFLLFFBQVFLLFFBQVEsZUFBZTtBQUFBLElBQ3RDLEVBQUVMLEtBQUssUUFBUUssUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFTCxLQUFLLGdCQUFnQkssUUFBUSx3QkFBd0I7QUFBQSxJQUN2RCxFQUFFTCxLQUFLLFVBQVVLLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVMLEtBQUssY0FBY0ssUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUwsS0FBSyxVQUFVSyxRQUFRLGFBQWE7QUFBQSxJQUN0QyxFQUFFTCxLQUFLLGdCQUFnQkssUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUwsS0FBSyxVQUFVSyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFTCxLQUFLLFVBQVVLLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUgsd0JBQXdCLE9BQU9sQyxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNUCxXQUFXLE1BQU1wRixJQUFJcUYsSUFBSSw4QkFBOEJNLE9BQU8sRUFBRTtBQUN0RS9DLDRCQUFzQndDLFNBQVNFLElBQUk7QUFDbkM1Qyx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVM2QyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTXVDLHdCQUF3QixPQUFPbkMsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTVAsV0FBVyxNQUFNcEYsSUFBSXFGLElBQUksOEJBQThCTSxPQUFPLEVBQUU7QUFDdEVuRCxzQkFBZ0I0QyxTQUFTRSxJQUFJO0FBQzdCaEQseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTaUQsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUVBLFFBQU0wQyxzQkFBc0IsWUFBWTtBQUN0QyxRQUFJMUYsY0FBYztBQUNoQixVQUFJO0FBQ0YsY0FBTXZDLElBQUlrSSxPQUFPLDJCQUEyQjNGLGFBQWEyRSxHQUFHLEVBQUU7QUFDOURpQixjQUFNLDhCQUE4QjtBQUNwQzdGLDJCQUFtQixLQUFLO0FBQ3hCRSx3QkFBZ0IsSUFBSTtBQUNwQjRGLGVBQU9DLFNBQVNDLE9BQU87QUFBQSxNQUN6QixTQUFTL0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFBQSxNQUNoRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTWdELG1CQUFtQnRILE9BQU91SCxLQUFLLENBQUFDLE1BQUtBLEVBQUV2QixRQUFRdkYsc0JBQXNCO0FBQzFFLFNBQ0UsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTTJDLFlBQVlJO0FBQUFBLFFBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFFBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDbUUsVUFBVSxFQUFFLEdBQUdBLE1BQU1sRSxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVILHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx1Q0FBc0Msa0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtSEFDYixpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw4REFBNkQsNkJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsdUJBQXVCO0FBQUEsY0FDdkIsT0FBTzdDLDBCQUEwQmdIO0FBQUFBLGNBQ2pDLFVBQVVqRDtBQUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU8sRUFBRWtELFFBQVEsUUFBUUMsT0FBTyxRQUFRO0FBQUEsY0FDeEMsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsU0FBUyxFQUFFQyxZQUFZLEVBQUVDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGNBSXRFakksaUJBQU84RjtBQUFBQSxnQkFBSSxDQUFDQyxVQUNYLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1FLEtBQ2xDRixnQkFBTW9DLGNBRElwQyxNQUFNRSxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUJBO0FBQUEsYUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsUUFHQ25GLG1CQUFtQkEsZ0JBQWdCNkMsU0FBUyxLQUFLLENBQUMzQixZQUNqRCxtQ0FDRTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxlQUFlNEU7QUFBQUEsY0FDZixNQUFNaEgsYUFBYU0sZUFBZTRCLFVBQVU7QUFBQSxjQUM1QztBQUFBLGNBQ0EsaUJBQWlCO0FBQUEsY0FDakIsaUJBQWlCLENBQUMsWUFBWTtBQUFBLGNBQzlCLG1CQUFtQjtBQUFBLGdCQUNqQndGLGtCQUFrQmEsY0FBYztBQUFBLGNBQUs7QUFBQSxjQUV2QyxrQkFBa0I7QUFBQTtBQUFBLFlBVHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVN5QztBQUFBLFVBSXpDLHVCQUFDLFNBQUksV0FBVSxnRkFHYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSwyREFBMEQsK0JBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLE9BQUUsV0FBVSwyQ0FDVnpFLDRCQUFrQixLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQSx1QkFBQyxPQUFFLFdBQVUsdURBQ1Y3RCw4QkFBb0I2RCxrQkFBa0IsQ0FBQyxLQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDJEQUEwRCxnQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUEsdUJBQUMsT0FBRSxXQUFVLDBDQUF5QztBQUFBO0FBQUEsaUJBQ2pERSxrQkFBa0IsR0FBR3dFLGVBQWUsT0FBTztBQUFBLG1CQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQSx1QkFBQyxPQUFFLFdBQVUsdURBQ1Z2SSw4QkFBb0J3SSxLQUFLQyxNQUFNMUUsa0JBQWtCLENBQUMsQ0FBQyxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDJEQUEwRCxnQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUEsdUJBQUMsT0FBRSxXQUFVLHdDQUF1QztBQUFBO0FBQUEsaUJBQy9DSyxrQkFBa0IsR0FBR21FLGVBQWUsT0FBTztBQUFBLG1CQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQSx1QkFBQyxPQUFFLFdBQVUsdURBQ1Z2SSw4QkFBb0J3SSxLQUFLQyxNQUFNckUsa0JBQWtCLENBQUMsQ0FBQyxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0NBO0FBQUEsYUE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStEQSxJQUVBLHVCQUFDLGtCQUFlLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxXQS9GekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlHQTtBQUFBLFNBbkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvR0E7QUFBQSxPQWpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0hBLEtBbkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvSEEsS0FySEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNIQTtBQUVKO0FBQUVsRSxHQTlWSUQsZUFBYTtBQUFBeUksS0FBYnpJO0FBZ1dOLGVBQWVBO0FBQWMsSUFBQXlJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJNZERlbGV0ZSIsIkNpRWRpdCIsIk1vZGFsIiwiSW9NZE1vcmUiLCJCc0V5ZSIsIkRhdGFUYWJsZSIsIkV5ZUljb24iLCJDaXJjdWxhckxvYWRlciIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiRHJvcGRvd24iLCJTZWxlY3QiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJudW1iZXJUb0luZGlhbldvcmRzIiwiQXVjdGlvblJlcG9ydCIsIl9zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiVGFibGVBdWN0aW9ucyIsInNldFRhYmxlQXVjdGlvbnMiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZWxlY3RlZEdyb3VwSWQiLCJzZXRTZWxlY3RlZEdyb3VwSWQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWRBdWN0aW9uIiwic2V0RmlsdGVyZWRBdWN0aW9uIiwiZ3JvdXBJbmZvIiwic2V0R3JvdXBJbmZvIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwiZG91YmxlIiwic2V0RG91YmxlIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZ3JvdXBfaWQiLCJ1c2VyX2lkIiwidGlja2V0IiwiYmlkX2Ftb3VudCIsImNvbW1pc3Npb24iLCJ3aW5fYW1vdW50IiwiZGl2aWRlbnQiLCJkaXZpZGVudF9oZWFkIiwicGF5YWJsZSIsImF1Y3Rpb25fZGF0ZSIsIm5leHRfZGF0ZSIsImdyb3VwX3R5cGUiLCJhdWN0aW9uX3R5cGUiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwidG90YWxDdXN0b21lcnMiLCJsZW5ndGgiLCJ0b3RhbEJpZEFtb3VudCIsInJlZHVjZSIsInN1bSIsIml0ZW0iLCJwYXJzZUludCIsInRvdGFsV2luQW1vdW50IiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaERvdWJsZSIsImhhbmRsZUdyb3VwQXVjdGlvbiIsImdyb3VwSWQiLCJoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UiLCJmb3JtYXRQYXlEYXRlIiwiZGF0ZVN0cmluZyIsImRhdGUiLCJEYXRlIiwib3B0aW9ucyIsImRheSIsIm1vbnRoIiwieWVhciIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInJlcGxhY2UiLCJwcmV2RGF0ZSIsInNldERhdGUiLCJnZXREYXRlIiwiZm9ybWF0dGVkRGF0YSIsImlkIiwibmFtZSIsInBob25lX251bWJlciIsImFtb3VudCIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJmdWxsX25hbWUiLCJzdGF0dXMiLCJpc1ByaXplZCIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiY29sdW1ucyIsImhlYWRlciIsImhhbmRsZURlbGV0ZUF1Y3Rpb24iLCJkZWxldGUiLCJhbGVydCIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIiwic2VsZWN0ZWRuZXdHcm91cCIsImZpbmQiLCJnIiwicHJldiIsInVuZGVmaW5lZCIsImhlaWdodCIsIndpZHRoIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImdyb3VwX25hbWUiLCJ0b0xvY2FsZVN0cmluZyIsIk1hdGgiLCJmbG9vciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1Y3Rpb25SZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgTWREZWxldGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgQ2lFZGl0IH0gZnJvbSBcInJlYWN0LWljb25zL2NpXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgQnNFeWUgfSBmcm9tIFwicmVhY3QtaWNvbnMvYnNcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBFeWVJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IERyb3Bkb3duLCBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcblxyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiXHJcblxyXG5jb25zdCBBdWN0aW9uUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlQXVjdGlvbnMsIHNldFRhYmxlQXVjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRBdWN0aW9uLCBzZXRGaWx0ZXJlZEF1Y3Rpb25dID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEluZm8sIHNldEdyb3VwSW5mb10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3JvdXAsIHNldEN1cnJlbnRHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlR3JvdXAsIHNldEN1cnJlbnRVcGRhdGVHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZG91YmxlLCBzZXREb3VibGVdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cF9pZDogXCJcIixcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICB0aWNrZXQ6IFwiXCIsXHJcbiAgICBiaWRfYW1vdW50OiBcIlwiLFxyXG4gICAgY29tbWlzc2lvbjogXCJcIixcclxuICAgIHdpbl9hbW91bnQ6IFwiXCIsXHJcbiAgICBkaXZpZGVudDogXCJcIixcclxuICAgIGRpdmlkZW50X2hlYWQ6IFwiXCIsXHJcbiAgICBwYXlhYmxlOiBcIlwiLFxyXG4gICAgYXVjdGlvbl9kYXRlOiBcIlwiLFxyXG4gICAgbmV4dF9kYXRlOiBcIlwiLFxyXG4gICAgZ3JvdXBfdHlwZTogXCJcIixcclxuICAgIGF1Y3Rpb25fdHlwZTogXCJub3JtYWxcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcblxyXG4gIGNvbnN0IHRvdGFsQ3VzdG9tZXJzID0gZmlsdGVyZWRBdWN0aW9uLmxlbmd0aDtcclxuICBjb25zdCB0b3RhbEJpZEFtb3VudCA9IGZpbHRlcmVkQXVjdGlvbi5yZWR1Y2UoXHJcbiAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyAoKHBhcnNlSW50KGl0ZW0uZGl2aWRlbnQpIHx8IDApICsgKHBhcnNlSW50KGl0ZW0uY29tbWlzc2lvbikgfHwgMCkpLFxyXG4gICAgMFxyXG4gICk7XHJcbiAgY29uc3QgdG90YWxXaW5BbW91bnQgPSBmaWx0ZXJlZEF1Y3Rpb24ucmVkdWNlKFxyXG4gICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgKHBhcnNlSW50KGl0ZW0ud2luX2Ftb3VudCkgfHwgMCksXHJcbiAgICAwXHJcbiAgKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRG91YmxlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZG91YmxlL2dldC1kb3VibGUvJHtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkfWApO1xyXG4gICAgICAgIHNldERvdWJsZShyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaERvdWJsZSgpO1xyXG4gIH0sIFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkKGdyb3VwSWQpO1xyXG4gICAgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlKGdyb3VwSWQpO1xyXG4gIH07XHJcbiAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICBjb25zdCBvcHRpb25zID0geyBkYXk6IFwibnVtZXJpY1wiLCBtb250aDogXCJzaG9ydFwiLCB5ZWFyOiBcIm51bWVyaWNcIiB9O1xyXG4gICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tVVNcIiwgb3B0aW9ucykucmVwbGFjZShcIixcIiwgXCIgXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgcHJldkRhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgZGF0ZS5zZXREYXRlKGRhdGUuZ2V0RGF0ZSgpIC0gMTApO1xyXG4gICAgY29uc3Qgb3B0aW9ucyA9IHsgZGF5OiBcIm51bWVyaWNcIiwgbW9udGg6IFwic2hvcnRcIiwgeWVhcjogXCJudW1lcmljXCIgfTtcclxuICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIG9wdGlvbnMpLnJlcGxhY2UoXCIsXCIsIFwiIFwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXAoZ3JvdXBJZCk7XHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2F1Y3Rpb24vZ2V0LWdyb3VwLWF1Y3Rpb24vJHtncm91cElkfWApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGlkOiAxLFxyXG4gICAgICAgICAgICAgIGRhdGU6IHByZXZEYXRlKHJlc3BvbnNlPy5kYXRhWzBdPy5hdWN0aW9uX2RhdGUpLFxyXG4gICAgICAgICAgICAgIG5hbWU6IFwiQ29tbWVuY2VtZW50XCIsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBcIkNvbW1lbmNlbWVudFwiLFxyXG4gICAgICAgICAgICAgIHRpY2tldDogXCJDb21tZW5jZW1lbnRcIixcclxuICAgICAgICAgICAgICBiaWRfYW1vdW50OiAwLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogMCxcclxuICAgICAgICAgICAgICBhdWN0aW9uX3R5cGU6IFwiQ29tbWVuY2VtZW50IEF1Y3Rpb25cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgLi4ucmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgICBfaWQ6IGdyb3VwLl9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAyLFxyXG4gICAgICAgICAgICAgIGRhdGU6IGZvcm1hdFBheURhdGUoZ3JvdXAuYXVjdGlvbl9kYXRlKSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cC51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cC51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgYmlkX2Ftb3VudDogcGFyc2VJbnQoZ3JvdXAuZGl2aWRlbnQpICsgcGFyc2VJbnQoZ3JvdXAuY29tbWlzc2lvbiksXHJcbiAgICAgICAgICAgICAgc3RhdHVzOiAhZ3JvdXA/LmlzUHJpemVkXHJcbiAgICAgICAgICAgICAgICA/IFwiVW4gUHJpemVkXCJcclxuICAgICAgICAgICAgICAgIDogZ3JvdXA/LmlzUHJpemVkID09PSBcInRydWVcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiUHJpemVkXCJcclxuICAgICAgICAgICAgICAgICAgOiBcIlVuIFByaXplZFwiLFxyXG4gICAgICAgICAgICAgIGF1Y3Rpb25fdHlwZTpcclxuICAgICAgICAgICAgICAgIGdyb3VwPy5hdWN0aW9uX3R5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmF1Y3Rpb25fdHlwZS5zbGljZSgxKSArXHJcbiAgICAgICAgICAgICAgICBcIiBBdWN0aW9uXCIsXHJcbiAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfSkpLFxyXG4gICAgICAgICAgXTtcclxuICAgICAgICAgIHNldFRhYmxlQXVjdGlvbnMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhdWN0aW9uIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImJpZF9hbW91bnRcIiwgaGVhZGVyOiBcIkJpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJXaW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fdHlwZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF1Y3Rpb246XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUF1Y3Rpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2F1Y3Rpb24vZGVsZXRlLWF1Y3Rpb24vJHtjdXJyZW50R3JvdXAuX2lkfWApO1xyXG4gICAgICAgIGFsZXJ0KFwiQXVjdGlvbiBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGF1Y3Rpb246XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3Qgc2VsZWN0ZWRuZXdHcm91cCA9IGdyb3Vwcy5maW5kKGcgPT4gZy5faWQgPT09IHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtdC0zMFwiPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG1iLTZcIj5SZXBvcnRzIC0gQXVjdGlvbiA8L2gxPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdy1mdWxsIGdhcC00IGJnLXZpb2xldC01MCBwLTIgdy0zMCBoLTQwICByb3VuZGVkLTN4bCAgYm9yZGVyICAgc3BhY2UteC0yIG1iLTEwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtbGcgdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlciBmb250LXNlbWlib2xkIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cEF1Y3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3IgU2VsZWN0IEF1Y3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogXCI1MHB4XCIsIHdpZHRoOiBcIjYwMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogVGFibGUgYW5kIFN1bW1hcnkgKi99XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkQXVjdGlvbiAmJiBmaWx0ZXJlZEF1Y3Rpb24ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24oVGFibGVBdWN0aW9ucywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BBdWN0aW9uIFJlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZG5ld0dyb3VwPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgQXVjdGlvbnNSZXBvcnQuY3N2YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiDinIUgU3VtbWFyeSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTYgYmctd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LXNtIG10LTZcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIEN1c3RvbWVycyAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBDdXN0b21lcnNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC12aW9sZXQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbEN1c3RvbWVycyB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNDAwIHRleHQtY2VudGVyIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0b3RhbEN1c3RvbWVycyB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIEJpZCBBbW91bnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgQmlkIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrl7KHRvdGFsQmlkQW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS00MDAgdGV4dC1jZW50ZXIgbGVhZGluZy1zbnVnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKE1hdGguZmxvb3IodG90YWxCaWRBbW91bnQgfHwgMCkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVG90YWwgV2luIEFtb3VudCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBXaW4gQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtcmVkLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrl7KHRvdGFsV2luQW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS00MDAgdGV4dC1jZW50ZXIgbGVhZGluZy1zbnVnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKE1hdGguZmxvb3IodG90YWxXaW5BbW91bnQgfHwgMCkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e2lzTG9hZGluZ30gLz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWN0aW9uUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQXVjdGlvblJlcG9ydC5qc3gifQ==