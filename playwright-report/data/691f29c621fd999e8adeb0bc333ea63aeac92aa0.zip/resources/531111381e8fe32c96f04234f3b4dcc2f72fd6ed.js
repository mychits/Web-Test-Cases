import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PaymentMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { HiCurrencyRupee } from "/node_modules/.vite/deps/react-icons_hi2.js?v=819e0a34";
import {
  Banknote,
  TicketCheck,
  ChevronRight,
  Zap,
  Shield,
  Sparkles,
  CreditCard,
  Receipt,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Wallet,
  TrendingUp,
  TrendingDown,
  FileText,
  DollarSign,
  AlertCircle,
  Gift,
  Users,
  Home,
  HelpCircle
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
const PaymentMenu = () => {
  _s();
  const [paymentInData, setPaymentInData] = useState({
    registrationFee: 0,
    chitPayment: 0,
    penaltyPayment: 0,
    // not fetched from API (placeholder)
    suspensePayments: 0,
    // not fetched
    paymentLinks: 0,
    // not fetched
    loading: true,
    error: null
  });
  const getCurrentMonthRange = () => {
    const now = /* @__PURE__ */ new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const fromDateAPI = firstDay.toISOString().split("T")[0];
    const toDateAPI = lastDay.toISOString().split("T")[0];
    const formatDisplay = (date) => {
      const d = date.getDate();
      const m = date.getMonth() + 1;
      const y = date.getFullYear();
      return `${d.toString().padStart(2, "0")}-${m.toString().padStart(2, "0")}-${y}`;
    };
    const fromDateDisplay2 = formatDisplay(firstDay);
    const toDateDisplay2 = formatDisplay(lastDay);
    return { fromDateAPI, toDateAPI, fromDateDisplay: fromDateDisplay2, toDateDisplay: toDateDisplay2 };
  };
  const fetchPaymentAmount = async (payFor) => {
    const { fromDateAPI, toDateAPI } = getCurrentMonthRange();
    try {
      const response = await api.get("/payment/paydate-report", {
        params: {
          from_date: fromDateAPI,
          to_date: toDateAPI,
          groupId: "",
          userId: "",
          account_type: "",
          collected_by: "",
          admin_type: "",
          pay_for: [payFor]
        }
      });
      const payments = response.data || [];
      const total = payments.reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0);
      return total;
    } catch (error) {
      console.error(`Error fetching ${payFor}:`, error);
      return 0;
    }
  };
  useEffect(() => {
    const loadPaymentData = async () => {
      setPaymentInData((prev) => ({ ...prev, loading: true, error: null }));
      try {
        const [chitTotal, pigmeTotal, loanTotal, registrationTotal] = await Promise.all(
          [
            fetchPaymentAmount("Chit"),
            fetchPaymentAmount("Pigme"),
            fetchPaymentAmount("Loan"),
            fetchPaymentAmount("Registration")
          ]
        );
        setPaymentInData({
          registrationFee: registrationTotal,
          chitPayment: chitTotal,
          penaltyPayment: 0,
          // no API provided
          suspensePayments: 0,
          paymentLinks: 0,
          loading: false,
          error: null
        });
      } catch (err) {
        setPaymentInData((prev) => ({ ...prev, loading: false, error: err.message }));
      }
    };
    loadPaymentData();
  }, []);
  const paymentCategories = [
    {
      id: "#1",
      title: "Payments",
      description: "Manage customer payment-in, payment-out records",
      icon: TicketCheck,
      gradient: "from-violet-500 via-purple-500 to-pink-500",
      bgGradient: "from-violet-50 via-purple-50 to-pink-50",
      href: "/payment-menu/payment-in-out-menu",
      stats: "Payment Information",
      secondaryIcon: Shield,
      iconColor: "text-violet-600",
      bgColor: "bg-violet-100"
    }
  ];
  const basePaymentInCategories = [
    { id: 1, name: "Registration Fee", amountKey: "registrationFee", trend: "up", icon: FileText },
    { id: 2, name: "CHIT PAYMENT", amountKey: "chitPayment", trend: "up", icon: Wallet },
    { id: 3, name: "PENALTY PAYMENT", amountKey: "penaltyPayment", trend: "up", icon: AlertCircle },
    { id: 4, name: "SUSPENSE PAYMENTS", amountKey: "suspensePayments", trend: "neutral", icon: HelpCircle, note: "No transactions" },
    { id: 5, name: "PAYMENT LINKS", amountKey: "paymentLinks", trend: "up", icon: DollarSign }
  ];
  const paymentInCategories = basePaymentInCategories.map((cat) => ({
    ...cat,
    amount: paymentInData[cat.amountKey] ?? 0
  }));
  const totalPaymentIn = paymentInCategories.reduce((sum, cat) => sum + cat.amount, 0);
  const paymentOutCategories = [
    { id: 1, name: "CHIT", amount: 312e4, trend: "down", icon: Wallet },
    { id: 2, name: "SALARY", amount: 89e4, trend: "down", icon: Users },
    { id: 3, name: "PETTY CASH", amount: 45600, trend: "down", icon: Banknote },
    { id: 4, name: "INCENTIVE", amount: 125e3, trend: "down", icon: Gift },
    { id: 5, name: "ADVANCES", amount: 275e3, trend: "down", icon: TrendingUp },
    { id: 6, name: "LOAN", amount: 98e4, trend: "down", icon: Home },
    { id: 7, name: "OTHERS", amount: 34200, trend: "down", icon: HelpCircle }
  ];
  const totalPaymentOut = paymentOutCategories.reduce((sum, cat) => sum + cat.amount, 0);
  const formatIndianCurrency = (amount) => {
    const formatter = new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    });
    return formatter.format(amount);
  };
  const { fromDateDisplay, toDateDisplay } = getCurrentMonthRange();
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full relative overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
        lineNumber: 175,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
          lineNumber: 177,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-8 relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-600 to-purple-600 rounded-2xl blur-lg opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 183,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-2xl", children: /* @__PURE__ */ jsxDEV(Banknote, { className: "w-8 h-8 text-white" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 185,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 184,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
              lineNumber: 182,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 bg-clip-text text-transparent", children: "Payment Management" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 189,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 mt-1 text-lg", children: "Manage and view payment information and transactions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 192,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
              lineNumber: 188,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
            lineNumber: 181,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
            lineNumber: 180,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-1", children: paymentCategories.map((category) => {
            const Icon = category.icon;
            const SecondaryIcon = category.secondaryIcon;
            return /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV("div", { className: "relative h-full overflow-hidden rounded-3xl bg-white/80 backdrop-blur-xl border border-white/20 shadow-2xl hover:shadow-3xl transition-all duration-700 transform hover:-translate-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-3xl bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-700 p-[2px]", children: /* @__PURE__ */ jsxDEV("div", { className: `w-full h-full rounded-3xl bg-gradient-to-r ${category.gradient}` }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 207,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 206,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative h-full bg-white rounded-3xl p-8", children: [
                /* @__PURE__ */ jsxDEV("div", { className: `absolute top-4 right-4 w-32 h-32 rounded-full bg-gradient-to-br ${category.bgGradient} opacity-30 blur-2xl` }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                  lineNumber: 210,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-6 relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-3 bg-gradient-to-r from-violet-400 to-purple-400 rounded-2xl blur-lg opacity-0 group-hover:opacity-40 transition duration-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                      lineNumber: 213,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: `relative w-16 h-16 rounded-2xl ${category.bgColor} flex items-center justify-center shadow-xl border border-white/50 group-hover:scale-110 transition-transform duration-500`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-8 h-8 ${category.iconColor}` }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                      lineNumber: 215,
                      columnNumber: 31
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                      lineNumber: 214,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                    lineNumber: 212,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-2xl bg-gradient-to-br from-slate-50 to-white shadow-lg border border-slate-200/50 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-x-4 group-hover:translate-x-0", children: /* @__PURE__ */ jsxDEV(SecondaryIcon, { className: "w-5 h-5 text-slate-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                    lineNumber: 219,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                    lineNumber: 218,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                  lineNumber: 211,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6 relative", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-slate-900 mb-3 group-hover:bg-gradient-to-r group-hover:from-violet-600 group-hover:to-purple-600 group-hover:bg-clip-text group-hover:text-transparent transition-all duration-500", children: category.title }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                    lineNumber: 223,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 leading-relaxed", children: category.description }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                    lineNumber: 226,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                  lineNumber: 222,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-6 border-t border-slate-200/50 relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-green-500 rounded-full animate-pulse" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                        lineNumber: 233,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 w-2 h-2 bg-green-500 rounded-full animate-ping" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                        lineNumber: 234,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                      lineNumber: 232,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-slate-500 uppercase tracking-wide", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                      lineNumber: 236,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                    lineNumber: 231,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-violet-600 opacity-0 group-hover:opacity-100 transform translate-x-4 group-hover:translate-x-0 transition-all duration-500", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold", children: "Explore" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                      lineNumber: 241,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-5 h-5" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                      lineNumber: 242,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                    lineNumber: 240,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                  lineNumber: 230,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
                lineNumber: 209,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
              lineNumber: 205,
              columnNumber: 21
            }, this) }, category.id, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
              lineNumber: 204,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
            lineNumber: 199,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8 mt-5" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
            lineNumber: 253,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
          lineNumber: 178,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
        lineNumber: 176,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
      lineNumber: 174,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob { animation: blob 7s infinite; }
        .animation-delay-2000 { animation-delay: 2s; }
        .animation-delay-4000 { animation-delay: 4s; }
        @keyframes tilt {
          0%, 50%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(0.5deg); }
          75% { transform: rotate(-0.5deg); }
        }
        .animate-tilt { animation: tilt 10s infinite; }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
      lineNumber: 417,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx",
    lineNumber: 173,
    columnNumber: 5
  }, this);
};
_s(PaymentMenu, "UHCcFGluyD6HrEPpFY1bpl+pOsE=");
_c = PaymentMenu;
export default PaymentMenu;
var _c;
$RefreshReg$(_c, "PaymentMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEtROzJCQTlLUjtBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLHVCQUF1QjtBQUNoQztBQUFBLEVBQ0VDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQWFDO0FBQUFBLEVBQWNDO0FBQUFBLEVBQUtDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQVlDO0FBQUFBLEVBQ3hFQztBQUFBQSxFQUFTQztBQUFBQSxFQUFXQztBQUFBQSxFQUFXQztBQUFBQSxFQUFRQztBQUFBQSxFQUFZQztBQUFBQSxFQUNuREM7QUFBQUEsRUFBVUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFBYUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBTUM7QUFBQUEsT0FDakQ7QUFDUCxTQUFTQyxZQUFZO0FBQ3JCLE9BQU9DLFNBQVM7QUFFaEIsTUFBTUMsY0FBY0EsTUFBTTtBQUFBQyxLQUFBO0FBRXhCLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUk5QixTQUFTO0FBQUEsSUFDakQrQixpQkFBaUI7QUFBQSxJQUNqQkMsYUFBYTtBQUFBLElBQ2JDLGdCQUFnQjtBQUFBO0FBQUEsSUFDaEJDLGtCQUFrQjtBQUFBO0FBQUEsSUFDbEJDLGNBQWM7QUFBQTtBQUFBLElBQ2RDLFNBQVM7QUFBQSxJQUNUQyxPQUFPO0FBQUEsRUFDVCxDQUFDO0FBSUQsUUFBTUMsdUJBQXVCQSxNQUFNO0FBQ2pDLFVBQU1DLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsVUFBTUMsT0FBT0YsSUFBSUcsWUFBWTtBQUM3QixVQUFNQyxRQUFRSixJQUFJSyxTQUFTO0FBQzNCLFVBQU1DLFdBQVcsSUFBSUwsS0FBS0MsTUFBTUUsT0FBTyxDQUFDO0FBQ3hDLFVBQU1HLFVBQVUsSUFBSU4sS0FBS0MsTUFBTUUsUUFBUSxHQUFHLENBQUM7QUFHM0MsVUFBTUksY0FBY0YsU0FBU0csWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3ZELFVBQU1DLFlBQVlKLFFBQVFFLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUdwRCxVQUFNRSxnQkFBZ0JBLENBQUNDLFNBQVM7QUFDOUIsWUFBTUMsSUFBSUQsS0FBS0UsUUFBUTtBQUN2QixZQUFNQyxJQUFJSCxLQUFLUixTQUFTLElBQUk7QUFDNUIsWUFBTVksSUFBSUosS0FBS1YsWUFBWTtBQUMzQixhQUFPLEdBQUdXLEVBQUVJLFNBQVMsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxJQUFJSCxFQUFFRSxTQUFTLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSUYsQ0FBQztBQUFBLElBQy9FO0FBQ0EsVUFBTUcsbUJBQWtCUixjQUFjTixRQUFRO0FBQzlDLFVBQU1lLGlCQUFnQlQsY0FBY0wsT0FBTztBQUUzQyxXQUFPLEVBQUVDLGFBQWFHLFdBQVdTLG1DQUFpQkMsOEJBQWM7QUFBQSxFQUNsRTtBQUdBLFFBQU1DLHFCQUFxQixPQUFPQyxXQUFXO0FBQzNDLFVBQU0sRUFBRWYsYUFBYUcsVUFBVSxJQUFJWixxQkFBcUI7QUFDeEQsUUFBSTtBQUNGLFlBQU15QixXQUFXLE1BQU1yQyxJQUFJc0MsSUFBSSwyQkFBMkI7QUFBQSxRQUN4REMsUUFBUTtBQUFBLFVBQ05DLFdBQVduQjtBQUFBQSxVQUNYb0IsU0FBU2pCO0FBQUFBLFVBQ1RrQixTQUFTO0FBQUEsVUFDVEMsUUFBUTtBQUFBLFVBQ1JDLGNBQWM7QUFBQSxVQUNkQyxjQUFjO0FBQUEsVUFDZEMsWUFBWTtBQUFBLFVBQ1pDLFNBQVMsQ0FBQ1gsTUFBTTtBQUFBLFFBQ2xCO0FBQUEsTUFDRixDQUFDO0FBRUQsWUFBTVksV0FBV1gsU0FBU1ksUUFBUTtBQUNsQyxZQUFNQyxRQUFRRixTQUFTRyxPQUFPLENBQUNDLEtBQUtDLE1BQU1ELE9BQU9FLFdBQVdELEVBQUVFLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFDOUUsYUFBT0w7QUFBQUEsSUFDVCxTQUFTdkMsT0FBTztBQUNkNkMsY0FBUTdDLE1BQU0sa0JBQWtCeUIsTUFBTSxLQUFLekIsS0FBSztBQUNoRCxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQThDLFlBQVUsTUFBTTtBQUNkLFVBQU1DLGtCQUFrQixZQUFZO0FBQ2xDdEQsdUJBQWlCLENBQUF1RCxVQUFTLEVBQUUsR0FBR0EsTUFBTWpELFNBQVMsTUFBTUMsT0FBTyxLQUFLLEVBQUU7QUFDbEUsVUFBSTtBQUVGLGNBQU0sQ0FBQ2lELFdBQVdDLFlBQVlDLFdBQVdDLGlCQUFpQixJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUM5RTlCLG1CQUFtQixNQUFNO0FBQUEsWUFDekJBLG1CQUFtQixPQUFPO0FBQUEsWUFDMUJBLG1CQUFtQixNQUFNO0FBQUEsWUFDekJBLG1CQUFtQixjQUFjO0FBQUEsVUFBQztBQUFBLFFBQ25DO0FBVUQvQix5QkFBaUI7QUFBQSxVQUNmQyxpQkFBaUIwRDtBQUFBQSxVQUNqQnpELGFBQWFzRDtBQUFBQSxVQUNickQsZ0JBQWdCO0FBQUE7QUFBQSxVQUNoQkMsa0JBQWtCO0FBQUEsVUFDbEJDLGNBQWM7QUFBQSxVQUNkQyxTQUFTO0FBQUEsVUFDVEMsT0FBTztBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0gsU0FBU3VELEtBQUs7QUFDWjlELHlCQUFpQixDQUFBdUQsVUFBUyxFQUFFLEdBQUdBLE1BQU1qRCxTQUFTLE9BQU9DLE9BQU91RCxJQUFJQyxRQUFRLEVBQUU7QUFBQSxNQUM1RTtBQUFBLElBQ0Y7QUFFQVQsb0JBQWdCO0FBQUEsRUFDbEIsR0FBRyxFQUFFO0FBR0wsUUFBTVUsb0JBQW9CO0FBQUEsSUFDeEI7QUFBQSxNQUNFQyxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNN0Y7QUFBQUEsTUFDTjhGLFVBQVU7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxlQUFlL0Y7QUFBQUEsTUFDZmdHLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsSUFDWDtBQUFBLEVBQUM7QUFJSCxRQUFNQywwQkFBMEI7QUFBQSxJQUM5QixFQUFFWCxJQUFJLEdBQUdZLE1BQU0sb0JBQW9CQyxXQUFXLG1CQUFtQkMsT0FBTyxNQUFNWCxNQUFNaEYsU0FBUztBQUFBLElBQzdGLEVBQUU2RSxJQUFJLEdBQUdZLE1BQU0sZ0JBQWdCQyxXQUFXLGVBQWVDLE9BQU8sTUFBTVgsTUFBTW5GLE9BQU87QUFBQSxJQUNuRixFQUFFZ0YsSUFBSSxHQUFHWSxNQUFNLG1CQUFtQkMsV0FBVyxrQkFBa0JDLE9BQU8sTUFBTVgsTUFBTTlFLFlBQVk7QUFBQSxJQUM5RixFQUFFMkUsSUFBSSxHQUFHWSxNQUFNLHFCQUFxQkMsV0FBVyxvQkFBb0JDLE9BQU8sV0FBV1gsTUFBTTFFLFlBQVlzRixNQUFNLGtCQUFrQjtBQUFBLElBQy9ILEVBQUVmLElBQUksR0FBR1ksTUFBTSxpQkFBaUJDLFdBQVcsZ0JBQWdCQyxPQUFPLE1BQU1YLE1BQU0vRSxXQUFXO0FBQUEsRUFBQztBQUk1RixRQUFNNEYsc0JBQXNCTCx3QkFBd0JNLElBQUksQ0FBQUMsU0FBUTtBQUFBLElBQzlELEdBQUdBO0FBQUFBLElBQ0hoQyxRQUFRcEQsY0FBY29GLElBQUlMLFNBQVMsS0FBSztBQUFBLEVBQzFDLEVBQUU7QUFFRixRQUFNTSxpQkFBaUJILG9CQUFvQmxDLE9BQU8sQ0FBQ0MsS0FBS21DLFFBQVFuQyxNQUFNbUMsSUFBSWhDLFFBQVEsQ0FBQztBQUduRixRQUFNa0MsdUJBQXVCO0FBQUEsSUFDM0IsRUFBRXBCLElBQUksR0FBR1ksTUFBTSxRQUFRMUIsUUFBUSxPQUFTNEIsT0FBTyxRQUFRWCxNQUFNbkYsT0FBTztBQUFBLElBQ3BFLEVBQUVnRixJQUFJLEdBQUdZLE1BQU0sVUFBVTFCLFFBQVEsTUFBUTRCLE9BQU8sUUFBUVgsTUFBTTVFLE1BQU07QUFBQSxJQUNwRSxFQUFFeUUsSUFBSSxHQUFHWSxNQUFNLGNBQWMxQixRQUFRLE9BQU80QixPQUFPLFFBQVFYLE1BQU05RixTQUFTO0FBQUEsSUFDMUUsRUFBRTJGLElBQUksR0FBR1ksTUFBTSxhQUFhMUIsUUFBUSxPQUFRNEIsT0FBTyxRQUFRWCxNQUFNN0UsS0FBSztBQUFBLElBQ3RFLEVBQUUwRSxJQUFJLEdBQUdZLE1BQU0sWUFBWTFCLFFBQVEsT0FBUTRCLE9BQU8sUUFBUVgsTUFBTWxGLFdBQVc7QUFBQSxJQUMzRSxFQUFFK0UsSUFBSSxHQUFHWSxNQUFNLFFBQVExQixRQUFRLE1BQVE0QixPQUFPLFFBQVFYLE1BQU0zRSxLQUFLO0FBQUEsSUFDakUsRUFBRXdFLElBQUksR0FBR1ksTUFBTSxVQUFVMUIsUUFBUSxPQUFPNEIsT0FBTyxRQUFRWCxNQUFNMUUsV0FBVztBQUFBLEVBQUM7QUFHM0UsUUFBTTRGLGtCQUFrQkQscUJBQXFCdEMsT0FBTyxDQUFDQyxLQUFLbUMsUUFBUW5DLE1BQU1tQyxJQUFJaEMsUUFBUSxDQUFDO0FBR3JGLFFBQU1vQyx1QkFBdUJBLENBQUNwQyxXQUFXO0FBQ3ZDLFVBQU1xQyxZQUFZLElBQUlDLEtBQUtDLGFBQWEsU0FBUztBQUFBLE1BQy9DQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLE1BQ1ZDLHVCQUF1QjtBQUFBLE1BQ3ZCQyx1QkFBdUI7QUFBQSxJQUN6QixDQUFDO0FBQ0QsV0FBT04sVUFBVU8sT0FBTzVDLE1BQU07QUFBQSxFQUNoQztBQUNGLFFBQU0sRUFBRXRCLGlCQUFpQkMsY0FBYyxJQUFJdEIscUJBQXFCO0FBQzlELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1IsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsK0JBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxRQUN6Qix1QkFBQyxTQUFJLFdBQVUsZ0JBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseURBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDRMQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdNO0FBQUEsY0FDeE0sdUJBQUMsU0FBSSxXQUFVLDhIQUNiLGlDQUFDLFlBQVMsV0FBVSx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsZ0hBQStHLGtDQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLG9FQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRjtBQUFBLGlCQUpqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSw2REFDWndELDRCQUFrQmtCLElBQUksQ0FBQ2MsYUFBYTtBQUNuQyxrQkFBTUMsT0FBT0QsU0FBUzVCO0FBQ3RCLGtCQUFNOEIsZ0JBQWdCRixTQUFTdkI7QUFDL0IsbUJBQ0UsdUJBQUMsUUFBdUIsSUFBSXVCLFNBQVN6QixNQUFNLFdBQVUsU0FDbkQsaUNBQUMsU0FBSSxXQUFVLDBMQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJIQUNiLGlDQUFDLFNBQUksV0FBVyw4Q0FBOEN5QixTQUFTM0IsUUFBUSxNQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRixLQURyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVcsbUVBQW1FMkIsU0FBUzFCLFVBQVUsMEJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThIO0FBQUEsZ0JBQzlILHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxtSkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErSjtBQUFBLG9CQUMvSix1QkFBQyxTQUFJLFdBQVcsa0NBQWtDMEIsU0FBU3JCLE9BQU8sOEhBQ2hFLGlDQUFDLFFBQUssV0FBVyxXQUFXcUIsU0FBU3RCLFNBQVMsTUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsaU5BQ2IsaUNBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsK01BQ1hzQixtQkFBUzlCLFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVjhCLG1CQUFTN0IsZUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxnRkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHFEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlFO0FBQUEsc0JBQ2pFLHVCQUFDLFNBQUksV0FBVSxxRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRjtBQUFBLHlCQUZuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDhEQUNiNkIsbUJBQVN4QixTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJKQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlCQUF3Qix1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFDL0MsdUJBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBLHVCQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLG1CQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9DQTtBQUFBLGlCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlDQSxLQTFDU3dCLFNBQVMvQixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJDQTtBQUFBLFVBRUosQ0FBQyxLQWxESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1EQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUZFO0FBQUEsYUFwS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJPQTtBQUFBLFdBN09GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4T0E7QUFBQSxTQWhQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaVBBO0FBQUEsSUFFQSx1QkFBQyxXQUFNLEtBQUcsTUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCRTtBQUFBLE9BcFFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxUUE7QUFFSjtBQUFFbkUsR0F2YUlELGFBQVc7QUFBQXNHLEtBQVh0RztBQXlhTixlQUFlQTtBQUFZLElBQUFzRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJOYXZiYXIiLCJTaWRlYmFyIiwiSGlDdXJyZW5jeVJ1cGVlIiwiQmFua25vdGUiLCJUaWNrZXRDaGVjayIsIkNoZXZyb25SaWdodCIsIlphcCIsIlNoaWVsZCIsIlNwYXJrbGVzIiwiQ3JlZGl0Q2FyZCIsIlJlY2VpcHQiLCJBcnJvd1VwIiwiQXJyb3dEb3duIiwiUmVmcmVzaEN3IiwiV2FsbGV0IiwiVHJlbmRpbmdVcCIsIlRyZW5kaW5nRG93biIsIkZpbGVUZXh0IiwiRG9sbGFyU2lnbiIsIkFsZXJ0Q2lyY2xlIiwiR2lmdCIsIlVzZXJzIiwiSG9tZSIsIkhlbHBDaXJjbGUiLCJMaW5rIiwiYXBpIiwiUGF5bWVudE1lbnUiLCJfcyIsInBheW1lbnRJbkRhdGEiLCJzZXRQYXltZW50SW5EYXRhIiwicmVnaXN0cmF0aW9uRmVlIiwiY2hpdFBheW1lbnQiLCJwZW5hbHR5UGF5bWVudCIsInN1c3BlbnNlUGF5bWVudHMiLCJwYXltZW50TGlua3MiLCJsb2FkaW5nIiwiZXJyb3IiLCJnZXRDdXJyZW50TW9udGhSYW5nZSIsIm5vdyIsIkRhdGUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJtb250aCIsImdldE1vbnRoIiwiZmlyc3REYXkiLCJsYXN0RGF5IiwiZnJvbURhdGVBUEkiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwidG9EYXRlQVBJIiwiZm9ybWF0RGlzcGxheSIsImRhdGUiLCJkIiwiZ2V0RGF0ZSIsIm0iLCJ5IiwidG9TdHJpbmciLCJwYWRTdGFydCIsImZyb21EYXRlRGlzcGxheSIsInRvRGF0ZURpc3BsYXkiLCJmZXRjaFBheW1lbnRBbW91bnQiLCJwYXlGb3IiLCJyZXNwb25zZSIsImdldCIsInBhcmFtcyIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJncm91cElkIiwidXNlcklkIiwiYWNjb3VudF90eXBlIiwiY29sbGVjdGVkX2J5IiwiYWRtaW5fdHlwZSIsInBheV9mb3IiLCJwYXltZW50cyIsImRhdGEiLCJ0b3RhbCIsInJlZHVjZSIsInN1bSIsInAiLCJwYXJzZUZsb2F0IiwiYW1vdW50IiwiY29uc29sZSIsInVzZUVmZmVjdCIsImxvYWRQYXltZW50RGF0YSIsInByZXYiLCJjaGl0VG90YWwiLCJwaWdtZVRvdGFsIiwibG9hblRvdGFsIiwicmVnaXN0cmF0aW9uVG90YWwiLCJQcm9taXNlIiwiYWxsIiwiZXJyIiwibWVzc2FnZSIsInBheW1lbnRDYXRlZ29yaWVzIiwiaWQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiaWNvbiIsImdyYWRpZW50IiwiYmdHcmFkaWVudCIsImhyZWYiLCJzdGF0cyIsInNlY29uZGFyeUljb24iLCJpY29uQ29sb3IiLCJiZ0NvbG9yIiwiYmFzZVBheW1lbnRJbkNhdGVnb3JpZXMiLCJuYW1lIiwiYW1vdW50S2V5IiwidHJlbmQiLCJub3RlIiwicGF5bWVudEluQ2F0ZWdvcmllcyIsIm1hcCIsImNhdCIsInRvdGFsUGF5bWVudEluIiwicGF5bWVudE91dENhdGVnb3JpZXMiLCJ0b3RhbFBheW1lbnRPdXQiLCJmb3JtYXRJbmRpYW5DdXJyZW5jeSIsImZvcm1hdHRlciIsIkludGwiLCJOdW1iZXJGb3JtYXQiLCJzdHlsZSIsImN1cnJlbmN5IiwibWluaW11bUZyYWN0aW9uRGlnaXRzIiwibWF4aW11bUZyYWN0aW9uRGlnaXRzIiwiZm9ybWF0IiwiY2F0ZWdvcnkiLCJJY29uIiwiU2Vjb25kYXJ5SWNvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBheW1lbnRNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IEhpQ3VycmVuY3lSdXBlZSB9IGZyb20gXCJyZWFjdC1pY29ucy9oaTJcIjtcclxuaW1wb3J0IHtcclxuICBCYW5rbm90ZSwgVGlja2V0Q2hlY2ssIENoZXZyb25SaWdodCwgWmFwLCBTaGllbGQsIFNwYXJrbGVzLCBDcmVkaXRDYXJkLCBSZWNlaXB0LFxyXG4gIEFycm93VXAsIEFycm93RG93biwgUmVmcmVzaEN3LCBXYWxsZXQsIFRyZW5kaW5nVXAsIFRyZW5kaW5nRG93bixcclxuICBGaWxlVGV4dCwgRG9sbGFyU2lnbiwgQWxlcnRDaXJjbGUsIEdpZnQsIFVzZXJzLCBIb21lLCBIZWxwQ2lyY2xlXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiOyAvLyBhZGp1c3QgcGF0aCBpZiBuZWVkZWRcclxuXHJcbmNvbnN0IFBheW1lbnRNZW51ID0gKCkgPT4ge1xyXG4gIC8vIFN0YXRlIGZvciBkeW5hbWljIHBheW1lbnQgaW4gZGF0YVxyXG4gIGNvbnN0IFtwYXltZW50SW5EYXRhLCBzZXRQYXltZW50SW5EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHJlZ2lzdHJhdGlvbkZlZTogMCxcclxuICAgIGNoaXRQYXltZW50OiAwLFxyXG4gICAgcGVuYWx0eVBheW1lbnQ6IDAsICAgICAgLy8gbm90IGZldGNoZWQgZnJvbSBBUEkgKHBsYWNlaG9sZGVyKVxyXG4gICAgc3VzcGVuc2VQYXltZW50czogMCwgICAgLy8gbm90IGZldGNoZWRcclxuICAgIHBheW1lbnRMaW5rczogMCwgICAgICAgIC8vIG5vdCBmZXRjaGVkXHJcbiAgICBsb2FkaW5nOiB0cnVlLFxyXG4gICAgZXJyb3I6IG51bGwsXHJcbiAgfSk7XHJcblxyXG4gIC8vIEhlbHBlcjogZ2V0IGZpcnN0IGFuZCBsYXN0IGRheSBvZiBjdXJyZW50IG1vbnRoIGFzIFlZWVktTU0tRERcclxuICAvLyBIZWxwZXI6IGdldCBmaXJzdCBhbmQgbGFzdCBkYXkgb2YgY3VycmVudCBtb250aFxyXG4gIGNvbnN0IGdldEN1cnJlbnRNb250aFJhbmdlID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IHllYXIgPSBub3cuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gbm93LmdldE1vbnRoKCk7IC8vIDAtaW5kZXhlZFxyXG4gICAgY29uc3QgZmlyc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMSk7XHJcbiAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGggKyAxLCAwKTtcclxuXHJcbiAgICAvLyBGb3IgQVBJOiBZWVlZLU1NLUREXHJcbiAgICBjb25zdCBmcm9tRGF0ZUFQSSA9IGZpcnN0RGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcclxuICAgIGNvbnN0IHRvRGF0ZUFQSSA9IGxhc3REYXkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xyXG5cclxuICAgIC8vIEZvciBkaXNwbGF5OiBERC1NTS1ZWVlZXHJcbiAgICBjb25zdCBmb3JtYXREaXNwbGF5ID0gKGRhdGUpID0+IHtcclxuICAgICAgY29uc3QgZCA9IGRhdGUuZ2V0RGF0ZSgpO1xyXG4gICAgICBjb25zdCBtID0gZGF0ZS5nZXRNb250aCgpICsgMTtcclxuICAgICAgY29uc3QgeSA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICAgICAgcmV0dXJuIGAke2QudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfS0ke20udG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfS0ke3l9YDtcclxuICAgIH07XHJcbiAgICBjb25zdCBmcm9tRGF0ZURpc3BsYXkgPSBmb3JtYXREaXNwbGF5KGZpcnN0RGF5KTtcclxuICAgIGNvbnN0IHRvRGF0ZURpc3BsYXkgPSBmb3JtYXREaXNwbGF5KGxhc3REYXkpO1xyXG5cclxuICAgIHJldHVybiB7IGZyb21EYXRlQVBJLCB0b0RhdGVBUEksIGZyb21EYXRlRGlzcGxheSwgdG9EYXRlRGlzcGxheSB9O1xyXG4gIH07XHJcblxyXG4gIC8vIEZldGNoIHBheW1lbnQgZGF0YSBmb3IgYSBnaXZlbiBwYXlfZm9yW10gdmFsdWVcclxuICBjb25zdCBmZXRjaFBheW1lbnRBbW91bnQgPSBhc3luYyAocGF5Rm9yKSA9PiB7XHJcbiAgICBjb25zdCB7IGZyb21EYXRlQVBJLCB0b0RhdGVBUEkgfSA9IGdldEN1cnJlbnRNb250aFJhbmdlKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoJy9wYXltZW50L3BheWRhdGUtcmVwb3J0Jywge1xyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgZnJvbV9kYXRlOiBmcm9tRGF0ZUFQSSxcclxuICAgICAgICAgIHRvX2RhdGU6IHRvRGF0ZUFQSSxcclxuICAgICAgICAgIGdyb3VwSWQ6ICcnLFxyXG4gICAgICAgICAgdXNlcklkOiAnJyxcclxuICAgICAgICAgIGFjY291bnRfdHlwZTogJycsXHJcbiAgICAgICAgICBjb2xsZWN0ZWRfYnk6ICcnLFxyXG4gICAgICAgICAgYWRtaW5fdHlwZTogJycsXHJcbiAgICAgICAgICBwYXlfZm9yOiBbcGF5Rm9yXSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuICAgICAgLy8gQXNzdW1pbmcgcmVzcG9uc2UuZGF0YSBpcyBhbiBhcnJheSBvZiBwYXltZW50cyB3aXRoIGBhbW91bnRgIGZpZWxkXHJcbiAgICAgIGNvbnN0IHBheW1lbnRzID0gcmVzcG9uc2UuZGF0YSB8fCBbXTtcclxuICAgICAgY29uc3QgdG90YWwgPSBwYXltZW50cy5yZWR1Y2UoKHN1bSwgcCkgPT4gc3VtICsgKHBhcnNlRmxvYXQocC5hbW91bnQpIHx8IDApLCAwKTtcclxuICAgICAgcmV0dXJuIHRvdGFsO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgJHtwYXlGb3J9OmAsIGVycm9yKTtcclxuICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGxvYWRQYXltZW50RGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0UGF5bWVudEluRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGxvYWRpbmc6IHRydWUsIGVycm9yOiBudWxsIH0pKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBGZXRjaCBhbGwgZm91ciBjYXRlZ29yaWVzIGNvbmN1cnJlbnRseVxyXG4gICAgICAgIGNvbnN0IFtjaGl0VG90YWwsIHBpZ21lVG90YWwsIGxvYW5Ub3RhbCwgcmVnaXN0cmF0aW9uVG90YWxdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgZmV0Y2hQYXltZW50QW1vdW50KCdDaGl0JyksXHJcbiAgICAgICAgICBmZXRjaFBheW1lbnRBbW91bnQoJ1BpZ21lJyksXHJcbiAgICAgICAgICBmZXRjaFBheW1lbnRBbW91bnQoJ0xvYW4nKSxcclxuICAgICAgICAgIGZldGNoUGF5bWVudEFtb3VudCgnUmVnaXN0cmF0aW9uJyksXHJcbiAgICAgICAgXSk7XHJcblxyXG4gICAgICAgIC8vIE1hcCB0byBVSSBjYXRlZ29yaWVzOlxyXG4gICAgICAgIC8vIFwiQ0hJVCBQQVlNRU5UXCIgLT4gY2hpdFRvdGFsXHJcbiAgICAgICAgLy8gXCJSZWdpc3RyYXRpb24gRmVlXCIgLT4gcmVnaXN0cmF0aW9uVG90YWxcclxuICAgICAgICAvLyBcIlBFTkFMVFkgUEFZTUVOVFwiIC0+IG5vdCBmZXRjaGVkLCBrZWVwIDAgKG9yIGNvdWxkIGJlIGZyb20gYW5vdGhlciBlbmRwb2ludClcclxuICAgICAgICAvLyBcIlNVU1BFTlNFIFBBWU1FTlRTXCIgLT4gbm90IGZldGNoZWRcclxuICAgICAgICAvLyBcIlBBWU1FTlQgTElOS1NcIiAtPiBub3QgZmV0Y2hlZFxyXG4gICAgICAgIC8vIFBpZ21lIGFuZCBMb2FuIGFyZSBub3QgaW4gc3RhdGljIGxpc3QsIGJ1dCB5b3UgbWF5IGNob29zZSB0byBhZGQgdGhlbSBvciBpZ25vcmUuXHJcblxyXG4gICAgICAgIHNldFBheW1lbnRJbkRhdGEoe1xyXG4gICAgICAgICAgcmVnaXN0cmF0aW9uRmVlOiByZWdpc3RyYXRpb25Ub3RhbCxcclxuICAgICAgICAgIGNoaXRQYXltZW50OiBjaGl0VG90YWwsXHJcbiAgICAgICAgICBwZW5hbHR5UGF5bWVudDogMCwgICAgICAgIC8vIG5vIEFQSSBwcm92aWRlZFxyXG4gICAgICAgICAgc3VzcGVuc2VQYXltZW50czogMCxcclxuICAgICAgICAgIHBheW1lbnRMaW5rczogMCxcclxuICAgICAgICAgIGxvYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIHNldFBheW1lbnRJbkRhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBsb2FkaW5nOiBmYWxzZSwgZXJyb3I6IGVyci5tZXNzYWdlIH0pKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBsb2FkUGF5bWVudERhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIFBheW1lbnQgQ2F0ZWdvcmllcyAoc3RhdGljIGRlc2NyaXB0aW9uICsgbGluaylcclxuICBjb25zdCBwYXltZW50Q2F0ZWdvcmllcyA9IFtcclxuICAgIHtcclxuICAgICAgaWQ6IFwiIzFcIixcclxuICAgICAgdGl0bGU6IFwiUGF5bWVudHNcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGN1c3RvbWVyIHBheW1lbnQtaW4sIHBheW1lbnQtb3V0IHJlY29yZHNcIixcclxuICAgICAgaWNvbjogVGlja2V0Q2hlY2ssXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tdmlvbGV0LTUwMCB2aWEtcHVycGxlLTUwMCB0by1waW5rLTUwMFwiLFxyXG4gICAgICBiZ0dyYWRpZW50OiBcImZyb20tdmlvbGV0LTUwIHZpYS1wdXJwbGUtNTAgdG8tcGluay01MFwiLFxyXG4gICAgICBocmVmOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudVwiLFxyXG4gICAgICBzdGF0czogXCJQYXltZW50IEluZm9ybWF0aW9uXCIsXHJcbiAgICAgIHNlY29uZGFyeUljb246IFNoaWVsZCxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtdmlvbGV0LTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLXZpb2xldC0xMDBcIlxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICAvLyBCYXNlIHN0YXRpYyBjYXRlZ29yaWVzIGZvciBkaXNwbGF5IChhbW91bnRzIHdpbGwgYmUgcmVwbGFjZWQgYnkgZHluYW1pYyB2YWx1ZXMpXHJcbiAgY29uc3QgYmFzZVBheW1lbnRJbkNhdGVnb3JpZXMgPSBbXHJcbiAgICB7IGlkOiAxLCBuYW1lOiBcIlJlZ2lzdHJhdGlvbiBGZWVcIiwgYW1vdW50S2V5OiBcInJlZ2lzdHJhdGlvbkZlZVwiLCB0cmVuZDogXCJ1cFwiLCBpY29uOiBGaWxlVGV4dCB9LFxyXG4gICAgeyBpZDogMiwgbmFtZTogXCJDSElUIFBBWU1FTlRcIiwgYW1vdW50S2V5OiBcImNoaXRQYXltZW50XCIsIHRyZW5kOiBcInVwXCIsIGljb246IFdhbGxldCB9LFxyXG4gICAgeyBpZDogMywgbmFtZTogXCJQRU5BTFRZIFBBWU1FTlRcIiwgYW1vdW50S2V5OiBcInBlbmFsdHlQYXltZW50XCIsIHRyZW5kOiBcInVwXCIsIGljb246IEFsZXJ0Q2lyY2xlIH0sXHJcbiAgICB7IGlkOiA0LCBuYW1lOiBcIlNVU1BFTlNFIFBBWU1FTlRTXCIsIGFtb3VudEtleTogXCJzdXNwZW5zZVBheW1lbnRzXCIsIHRyZW5kOiBcIm5ldXRyYWxcIiwgaWNvbjogSGVscENpcmNsZSwgbm90ZTogXCJObyB0cmFuc2FjdGlvbnNcIiB9LFxyXG4gICAgeyBpZDogNSwgbmFtZTogXCJQQVlNRU5UIExJTktTXCIsIGFtb3VudEtleTogXCJwYXltZW50TGlua3NcIiwgdHJlbmQ6IFwidXBcIiwgaWNvbjogRG9sbGFyU2lnbiB9XHJcbiAgXTtcclxuXHJcbiAgLy8gQnVpbGQgZHluYW1pYyBwYXltZW50SW5DYXRlZ29yaWVzIHdpdGggcmVhbCBhbW91bnRzXHJcbiAgY29uc3QgcGF5bWVudEluQ2F0ZWdvcmllcyA9IGJhc2VQYXltZW50SW5DYXRlZ29yaWVzLm1hcChjYXQgPT4gKHtcclxuICAgIC4uLmNhdCxcclxuICAgIGFtb3VudDogcGF5bWVudEluRGF0YVtjYXQuYW1vdW50S2V5XSA/PyAwLFxyXG4gIH0pKTtcclxuXHJcbiAgY29uc3QgdG90YWxQYXltZW50SW4gPSBwYXltZW50SW5DYXRlZ29yaWVzLnJlZHVjZSgoc3VtLCBjYXQpID0+IHN1bSArIGNhdC5hbW91bnQsIDApO1xyXG5cclxuICAvLyBQYXltZW50IG91dCBzdGF5cyBzdGF0aWMgKG5vIEFQSXMgcHJvdmlkZWQpXHJcbiAgY29uc3QgcGF5bWVudE91dENhdGVnb3JpZXMgPSBbXHJcbiAgICB7IGlkOiAxLCBuYW1lOiBcIkNISVRcIiwgYW1vdW50OiAzMTIwMDAwLCB0cmVuZDogXCJkb3duXCIsIGljb246IFdhbGxldCB9LFxyXG4gICAgeyBpZDogMiwgbmFtZTogXCJTQUxBUllcIiwgYW1vdW50OiA4OTAwMDAsIHRyZW5kOiBcImRvd25cIiwgaWNvbjogVXNlcnMgfSxcclxuICAgIHsgaWQ6IDMsIG5hbWU6IFwiUEVUVFkgQ0FTSFwiLCBhbW91bnQ6IDQ1NjAwLCB0cmVuZDogXCJkb3duXCIsIGljb246IEJhbmtub3RlIH0sXHJcbiAgICB7IGlkOiA0LCBuYW1lOiBcIklOQ0VOVElWRVwiLCBhbW91bnQ6IDEyNTAwMCwgdHJlbmQ6IFwiZG93blwiLCBpY29uOiBHaWZ0IH0sXHJcbiAgICB7IGlkOiA1LCBuYW1lOiBcIkFEVkFOQ0VTXCIsIGFtb3VudDogMjc1MDAwLCB0cmVuZDogXCJkb3duXCIsIGljb246IFRyZW5kaW5nVXAgfSxcclxuICAgIHsgaWQ6IDYsIG5hbWU6IFwiTE9BTlwiLCBhbW91bnQ6IDk4MDAwMCwgdHJlbmQ6IFwiZG93blwiLCBpY29uOiBIb21lIH0sXHJcbiAgICB7IGlkOiA3LCBuYW1lOiBcIk9USEVSU1wiLCBhbW91bnQ6IDM0MjAwLCB0cmVuZDogXCJkb3duXCIsIGljb246IEhlbHBDaXJjbGUgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHRvdGFsUGF5bWVudE91dCA9IHBheW1lbnRPdXRDYXRlZ29yaWVzLnJlZHVjZSgoc3VtLCBjYXQpID0+IHN1bSArIGNhdC5hbW91bnQsIDApO1xyXG5cclxuICAvLyBGb3JtYXQgYW1vdW50IGluIEluZGlhbiBudW1iZXIgc3lzdGVtXHJcbiAgY29uc3QgZm9ybWF0SW5kaWFuQ3VycmVuY3kgPSAoYW1vdW50KSA9PiB7XHJcbiAgICBjb25zdCBmb3JtYXR0ZXIgPSBuZXcgSW50bC5OdW1iZXJGb3JtYXQoJ2VuLUlOJywge1xyXG4gICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcclxuICAgICAgY3VycmVuY3k6ICdJTlInLFxyXG4gICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDAsXHJcbiAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMCxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGZvcm1hdHRlci5mb3JtYXQoYW1vdW50KTtcclxuICB9O1xyXG5jb25zdCB7IGZyb21EYXRlRGlzcGxheSwgdG9EYXRlRGlzcGxheSB9ID0gZ2V0Q3VycmVudE1vbnRoUmFuZ2UoKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcmVsYXRpdmVcIj5cclxuICAgICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTEgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tcHVycGxlLTYwMCByb3VuZGVkLTJ4bCBibHVyLWxnIG9wYWNpdHktNzUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0xMDAwIGdyb3VwLWhvdmVyOmR1cmF0aW9uLTIwMCBhbmltYXRlLXRpbHRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTE2IGgtMTYgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAwIHRvLXB1cnBsZS02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LTJ4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCYW5rbm90ZSBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtOTAwIHZpYS1wdXJwbGUtOTAwIHRvLXNsYXRlLTkwMCBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgTWFuYWdlbWVudFxyXG4gICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBtdC0xIHRleHQtbGdcIj5NYW5hZ2UgYW5kIHZpZXcgcGF5bWVudCBpbmZvcm1hdGlvbiBhbmQgdHJhbnNhY3Rpb25zPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBFeGlzdGluZyBQYXltZW50IENhdGVnb3JpZXMgR3JpZCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC04IG1iLTFcIj5cclxuICAgICAgICAgICAgICB7cGF5bWVudENhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGNhdGVnb3J5Lmljb247XHJcbiAgICAgICAgICAgICAgICBjb25zdCBTZWNvbmRhcnlJY29uID0gY2F0ZWdvcnkuc2Vjb25kYXJ5SWNvbjtcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIGtleT17Y2F0ZWdvcnkuaWR9IHRvPXtjYXRlZ29yeS5ocmVmfSBjbGFzc05hbWU9XCJncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTN4bCBiZy13aGl0ZS84MCBiYWNrZHJvcC1ibHVyLXhsIGJvcmRlciBib3JkZXItd2hpdGUvMjAgc2hhZG93LTJ4bCBob3ZlcjpzaGFkb3ctM3hsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTcwMCB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCByb3VuZGVkLTN4bCBiZy1ncmFkaWVudC10by1yIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tNzAwIHAtWzJweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtM3hsIGJnLWdyYWRpZW50LXRvLXIgJHtjYXRlZ29yeS5ncmFkaWVudH1gfT48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLWZ1bGwgYmctd2hpdGUgcm91bmRlZC0zeGwgcC04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCB3LTMyIGgtMzIgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLWJyICR7Y2F0ZWdvcnkuYmdHcmFkaWVudH0gb3BhY2l0eS0zMCBibHVyLTJ4bGB9PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTYgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNDAwIHRvLXB1cnBsZS00MDAgcm91bmRlZC0yeGwgYmx1ci1sZyBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS00MCB0cmFuc2l0aW9uIGR1cmF0aW9uLTUwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2ByZWxhdGl2ZSB3LTE2IGgtMTYgcm91bmRlZC0yeGwgJHtjYXRlZ29yeS5iZ0NvbG9yfSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3cteGwgYm9yZGVyIGJvcmRlci13aGl0ZS81MCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNTAwYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT17YHctOCBoLTggJHtjYXRlZ29yeS5pY29uQ29sb3J9YH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2xhdGUtNTAgdG8td2hpdGUgc2hhZG93LWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzUwIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgdHJhbnNmb3JtIHRyYW5zbGF0ZS14LTQgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlY29uZGFyeUljb24gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNsYXRlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG1iLTMgZ3JvdXAtaG92ZXI6YmctZ3JhZGllbnQtdG8tciBncm91cC1ob3Zlcjpmcm9tLXZpb2xldC02MDAgZ3JvdXAtaG92ZXI6dG8tcHVycGxlLTYwMCBncm91cC1ob3ZlcjpiZy1jbGlwLXRleHQgZ3JvdXAtaG92ZXI6dGV4dC10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMC81MCByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIgaC0yIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgdy0yIGgtMiBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcGluZ1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5zdGF0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtdmlvbGV0LTYwMCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNmb3JtIHRyYW5zbGF0ZS14LTQgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZFwiPkV4cGxvcmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNRVJHRUQgQ0FSRFM6IFRvdGFsICsgQ2F0ZWdvcmllcyB0b2dldGhlciAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC04IG10LTVcIj5cclxuICAgICAgICAgICAgICB7LyogUGF5bWVudCBJbiBDYXJkICovfVxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctbGcgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMFwiPiAqL31cclxuICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy00MCBoLTQwIGJnLWVtZXJhbGQtMTAwLzIwIHJvdW5kZWQtZnVsbCBibHVyLTJ4bFwiPjwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNlwiPiAqL31cclxuICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIFBheW1lbnQgSW4gU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwibWItNiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctZW1lcmFsZC0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZW1lcmFsZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgUGF5bWVudCBJbjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZW1lcmFsZC02MDAvNzBcIj5JbmNsdWRlcyBhbGwgY3VzdG9tZXIgcmVjZWlwdHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtZW1lcmFsZC02MDAgYmctZW1lcmFsZC0xMDAvODAgcHgtMiBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1VwIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5JbmZsb3c8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7cGF5bWVudEluRGF0YS5sb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy01IGgtNSBib3JkZXItMiBib3JkZXItZW1lcmFsZC02MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpblwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZW1lcmFsZC02MDBcIj5Mb2FkaW5nLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMSBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxIaUN1cnJlbmN5UnVwZWUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWVtZXJhbGQtNzAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdGV4dC1lbWVyYWxkLTgwMCB0cmFja2luZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRJbmRpYW5DdXJyZW5jeSh0b3RhbFBheW1lbnRJbikucmVwbGFjZSgn4oK5JywgJycpLnJlcGxhY2UoLywvZywgJywnKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LWVtZXJhbGQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5UaGlzIG1vbnRoOiB7ZnJvbURhdGVEaXNwbGF5fSB0byB7dG9EYXRlRGlzcGxheX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZWFsLXRpbWUgZGF0YTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFBheW1lbnQgSW4gQ2F0ZWdvcmllcyAqL31cclxuICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UmVjZWlwdCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPlBheW1lbnQgSW48L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e3BheW1lbnRJbkNhdGVnb3JpZXMubGVuZ3RofSBjYXRlZ29yaWVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTIgcHktMC41IGJnLWVtZXJhbGQtNTAgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1lbWVyYWxkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbDoge2Zvcm1hdEluZGlhbkN1cnJlbmN5KHRvdGFsUGF5bWVudEluKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYXltZW50SW5EYXRhLmxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLWVtZXJhbGQtNjAwIGJvcmRlci10LXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW5cIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudEluQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGNhdGVnb3J5Lmljb247XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjYXRlZ29yeS5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTUwLzUwIGhvdmVyOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1zbGF0ZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWVtZXJhbGQtMTAwLzYwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIHRleHQtc21cIj57Y2F0ZWdvcnkubmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkubm90ZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e2NhdGVnb3J5Lm5vdGV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LmFtb3VudCA9PT0gMCA/ICfigrkwJyA6IGZvcm1hdEluZGlhbkN1cnJlbmN5KGNhdGVnb3J5LmFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS50cmVuZCA9PT0gJ3VwJyAmJiBjYXRlZ29yeS5hbW91bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0wLjUgdGV4dC14cyB0ZXh0LWVtZXJhbGQtNjAwIGJnLWVtZXJhbGQtNTAgcHgtMS41IHB5LTAuNSByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93VXAgY2xhc3NOYW1lPVwidy0yLjUgaC0yLjVcIiAvPiBJbmZsb3dcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgey8qIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFBheW1lbnQgT3V0IENhcmQgKHJlbWFpbnMgc3RhdGljKSAqL31cclxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LWxnIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTQwIGgtNDAgYmctcm9zZS0xMDAvMjAgcm91bmRlZC1mdWxsIGJsdXItMnhsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLXJvc2UtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nRG93biBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcm9zZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXJvc2UtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgUGF5bWVudCBPdXQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJvc2UtNjAwLzcwXCI+SW5jbHVkZXMgYWxsIHBheW91dHMgJiBleHBlbnNlczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1yb3NlLTYwMCBiZy1yb3NlLTEwMC84MCBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEFycm93RG93biBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+T3V0Zmxvdzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMSBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SGlDdXJyZW5jeVJ1cGVlIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1yb3NlLTcwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXJvc2UtODAwIHRyYWNraW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRJbmRpYW5DdXJyZW5jeSh0b3RhbFBheW1lbnRPdXQpLnJlcGxhY2UoJ+KCuScsICcnKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LXJvc2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TdGF0aWMgZGF0YSDigJMgQVBJIGludGVncmF0aW9uIHBlbmRpbmc8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5MYXN0IHVwZGF0ZWQ6IGRlbW8gdmFsdWVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yb3NlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwXCI+UGF5bWVudCBPdXQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+e3BheW1lbnRPdXRDYXRlZ29yaWVzLmxlbmd0aH0gY2F0ZWdvcmllczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSBiZy1yb3NlLTUwIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtcm9zZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVG90YWw6IHtmb3JtYXRJbmRpYW5DdXJyZW5jeSh0b3RhbFBheW1lbnRPdXQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50T3V0Q2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IEljb24gPSBjYXRlZ29yeS5pY29uO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjYXRlZ29yeS5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTUwLzUwIGhvdmVyOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1zbGF0ZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbGcgYmctcm9zZS0xMDAvNjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcm9zZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCB0ZXh0LXNtXCI+e2NhdGVnb3J5Lm5hbWV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEluZGlhbkN1cnJlbmN5KGNhdGVnb3J5LmFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSB0ZXh0LXhzIHRleHQtcm9zZS02MDAgYmctcm9zZS01MCBweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0Rvd24gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjVcIiAvPiBPdXRmbG93XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICB7LyogPC9kaXY+ICovfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgIEBrZXlmcmFtZXMgYmxvYiB7XHJcbiAgICAgICAgICAwJSB7IHRyYW5zZm9ybTogdHJhbnNsYXRlKDBweCwgMHB4KSBzY2FsZSgxKTsgfVxyXG4gICAgICAgICAgMzMlIHsgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMzBweCwgLTUwcHgpIHNjYWxlKDEuMSk7IH1cclxuICAgICAgICAgIDY2JSB7IHRyYW5zZm9ybTogdHJhbnNsYXRlKC0yMHB4LCAyMHB4KSBzY2FsZSgwLjkpOyB9XHJcbiAgICAgICAgICAxMDAlIHsgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMHB4LCAwcHgpIHNjYWxlKDEpOyB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRlLWJsb2IgeyBhbmltYXRpb246IGJsb2IgN3MgaW5maW5pdGU7IH1cclxuICAgICAgICAuYW5pbWF0aW9uLWRlbGF5LTIwMDAgeyBhbmltYXRpb24tZGVsYXk6IDJzOyB9XHJcbiAgICAgICAgLmFuaW1hdGlvbi1kZWxheS00MDAwIHsgYW5pbWF0aW9uLWRlbGF5OiA0czsgfVxyXG4gICAgICAgIEBrZXlmcmFtZXMgdGlsdCB7XHJcbiAgICAgICAgICAwJSwgNTAlLCAxMDAlIHsgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7IH1cclxuICAgICAgICAgIDI1JSB7IHRyYW5zZm9ybTogcm90YXRlKDAuNWRlZyk7IH1cclxuICAgICAgICAgIDc1JSB7IHRyYW5zZm9ybTogcm90YXRlKC0wLjVkZWcpOyB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRlLXRpbHQgeyBhbmltYXRpb246IHRpbHQgMTBzIGluZmluaXRlOyB9XHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYXltZW50TWVudTsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGF5bWVudE1lbnUuanN4In0=