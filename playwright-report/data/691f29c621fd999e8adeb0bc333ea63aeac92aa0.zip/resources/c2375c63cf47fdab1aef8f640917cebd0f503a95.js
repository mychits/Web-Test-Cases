import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/modals/PageWrapper.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/PageWrapper.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import __vite__cjsImport4_reactDom from "/node_modules/.vite/deps/react-dom.js?v=819e0a34"; const createPortal = __vite__cjsImport4_reactDom["createPortal"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
const PageWrapper = ({ isVisible, onClose, isNewTab, children }) => {
  _s();
  const newWindowRef = useRef(null);
  const containerRef = useRef(null);
  useEffect(() => {
    if (isVisible && isNewTab) {
      newWindowRef.current = window.open(
        "",
        "_blank",
        "width=1200,height=800"
      );
      containerRef.current = newWindowRef.current.document.createElement("div");
      newWindowRef.current.document.body.appendChild(
        containerRef.current
      );
      newWindowRef.current.document.title = "Add Group";
      return () => {
        newWindowRef.current?.close();
      };
    }
  }, [isVisible, isNewTab]);
  if (!isVisible) return null;
  if (isNewTab && containerRef.current) {
    return createPortal(children, containerRef.current);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 bg-gray-50 overflow-y-auto flex", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/PageWrapper.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-3xl bg-white rounded shadow p-6", children }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/PageWrapper.jsx",
      lineNumber: 44,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/PageWrapper.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/PageWrapper.jsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
};
_s(PageWrapper, "URKl8leqkiu9Zd+fe6BjvGyc/IU=");
_c = PageWrapper;
export default PageWrapper;
var _c;
$RefreshReg$(_c, "PageWrapper");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/PageWrapper.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/PageWrapper.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNNOzJCQXpDTjtBQUFvQkEsTUFBTSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pDLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBRXBCLE1BQU1DLGNBQWNBLENBQUMsRUFBRUMsV0FBV0MsU0FBU0MsVUFBVUMsU0FBUyxNQUFNO0FBQUFDLEtBQUE7QUFDbEUsUUFBTUMsZUFBZVQsT0FBTyxJQUFJO0FBQ2hDLFFBQU1VLGVBQWVWLE9BQU8sSUFBSTtBQUVoQ1csWUFBVSxNQUFNO0FBQ2QsUUFBSVAsYUFBYUUsVUFBVTtBQUN6QkcsbUJBQWFHLFVBQVVDLE9BQU9DO0FBQUFBLFFBQzVCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBRUFKLG1CQUFhRSxVQUNYSCxhQUFhRyxRQUFRRyxTQUFTQyxjQUFjLEtBQUs7QUFFbkRQLG1CQUFhRyxRQUFRRyxTQUFTRSxLQUFLQztBQUFBQSxRQUNqQ1IsYUFBYUU7QUFBQUEsTUFDZjtBQUVBSCxtQkFBYUcsUUFBUUcsU0FBU0ksUUFBUTtBQUV0QyxhQUFPLE1BQU07QUFDWFYscUJBQWFHLFNBQVNRLE1BQU07QUFBQSxNQUM5QjtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ2hCLFdBQVdFLFFBQVEsQ0FBQztBQUV4QixNQUFJLENBQUNGLFVBQVcsUUFBTztBQUd2QixNQUFJRSxZQUFZSSxhQUFhRSxTQUFTO0FBQ3BDLFdBQU9YLGFBQWFNLFVBQVVHLGFBQWFFLE9BQU87QUFBQSxFQUNwRDtBQUdBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFNBQUksV0FBVSw4QkFDYixpQ0FBQyxTQUFJLFdBQVUseURBQ1pMLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFFQyxHQTdDSUwsYUFBVztBQUFBa0IsS0FBWGxCO0FBK0NOLGVBQWVBO0FBQVksSUFBQWtCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VSZWYiLCJjcmVhdGVQb3J0YWwiLCJTaWRlYmFyIiwiUGFnZVdyYXBwZXIiLCJpc1Zpc2libGUiLCJvbkNsb3NlIiwiaXNOZXdUYWIiLCJjaGlsZHJlbiIsIl9zIiwibmV3V2luZG93UmVmIiwiY29udGFpbmVyUmVmIiwidXNlRWZmZWN0IiwiY3VycmVudCIsIndpbmRvdyIsIm9wZW4iLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJib2R5IiwiYXBwZW5kQ2hpbGQiLCJ0aXRsZSIsImNsb3NlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGFnZVdyYXBwZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCB9IGZyb20gXCJyZWFjdC1kb21cIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2xheW91dHMvU2lkZWJhclwiO1xyXG5cclxuY29uc3QgUGFnZVdyYXBwZXIgPSAoeyBpc1Zpc2libGUsIG9uQ2xvc2UsIGlzTmV3VGFiLCBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgY29uc3QgbmV3V2luZG93UmVmID0gdXNlUmVmKG51bGwpO1xyXG4gIGNvbnN0IGNvbnRhaW5lclJlZiA9IHVzZVJlZihudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChpc1Zpc2libGUgJiYgaXNOZXdUYWIpIHtcclxuICAgICAgbmV3V2luZG93UmVmLmN1cnJlbnQgPSB3aW5kb3cub3BlbihcclxuICAgICAgICBcIlwiLFxyXG4gICAgICAgIFwiX2JsYW5rXCIsXHJcbiAgICAgICAgXCJ3aWR0aD0xMjAwLGhlaWdodD04MDBcIlxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29udGFpbmVyUmVmLmN1cnJlbnQgPVxyXG4gICAgICAgIG5ld1dpbmRvd1JlZi5jdXJyZW50LmRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XHJcblxyXG4gICAgICBuZXdXaW5kb3dSZWYuY3VycmVudC5kb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKFxyXG4gICAgICAgIGNvbnRhaW5lclJlZi5jdXJyZW50XHJcbiAgICAgICk7XHJcblxyXG4gICAgICBuZXdXaW5kb3dSZWYuY3VycmVudC5kb2N1bWVudC50aXRsZSA9IFwiQWRkIEdyb3VwXCI7XHJcblxyXG4gICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgIG5ld1dpbmRvd1JlZi5jdXJyZW50Py5jbG9zZSgpO1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gIH0sIFtpc1Zpc2libGUsIGlzTmV3VGFiXSk7XHJcblxyXG4gIGlmICghaXNWaXNpYmxlKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgLy8g4pyFIFJlbmRlciBpbiBuZXcgdGFiXHJcbiAgaWYgKGlzTmV3VGFiICYmIGNvbnRhaW5lclJlZi5jdXJyZW50KSB7XHJcbiAgICByZXR1cm4gY3JlYXRlUG9ydGFsKGNoaWxkcmVuLCBjb250YWluZXJSZWYuY3VycmVudCk7XHJcbiAgfVxyXG5cclxuICAvLyDinIUgUmVuZGVyIG5vcm1hbCBtb2RhbFxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBiZy1ncmF5LTUwIG92ZXJmbG93LXktYXV0byBmbGV4XCI+XHJcbiAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy0zeGwgYmctd2hpdGUgcm91bmRlZCBzaGFkb3cgcC02XCI+XHJcbiAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBhZ2VXcmFwcGVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvY29tcG9uZW50cy9tb2RhbHMvUGFnZVdyYXBwZXIuanN4In0=