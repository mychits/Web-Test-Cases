import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/alerts/CustomAlertDialog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import {
  FaCheckCircle,
  FaTimesCircle,
  FaExclamationTriangle,
  FaInfoCircle,
  FaTimes
} from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const memo = __vite__cjsImport4_react["memo"]; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"];
const CustomAlertDialog = _s(memo(_c = _s(({ isVisible = false, type = "info", message, onClose }) => {
  _s();
  const [isClosing, setIsClosing] = useState(false);
  const alertConfig = {
    success: {
      bg: "bg-green-50",
      text: "text-green-800",
      border: "border-green-300",
      icon: /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "h-5 w-5 text-green-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
        lineNumber: 18,
        columnNumber: 13
      }, this)
    },
    error: {
      bg: "bg-red-50",
      text: "text-red-800",
      border: "border-red-300",
      icon: /* @__PURE__ */ jsxDEV(FaTimesCircle, { className: "h-5 w-5 text-red-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
        lineNumber: 24,
        columnNumber: 13
      }, this)
    },
    warning: {
      bg: "bg-yellow-50",
      text: "text-yellow-800",
      border: "border-yellow-300",
      icon: /* @__PURE__ */ jsxDEV(FaExclamationTriangle, { className: "h-5 w-5 text-yellow-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
        lineNumber: 30,
        columnNumber: 13
      }, this)
    },
    info: {
      bg: "bg-violet-50",
      text: "text-violet-800",
      border: "border-violet-300",
      icon: /* @__PURE__ */ jsxDEV(FaInfoCircle, { className: "h-5 w-5 text-violet-400" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
        lineNumber: 36,
        columnNumber: 13
      }, this)
    }
  };
  useEffect(() => {
    if (isVisible) {
      setIsClosing(false);
      const autoCloseTimer = setTimeout(() => {
        setIsClosing(true);
        const notifyTimer = setTimeout(() => onClose?.(), 300);
        return () => clearTimeout(notifyTimer);
      }, 2e3);
      return () => clearTimeout(autoCloseTimer);
    }
  }, [isVisible, onClose]);
  const handleManualClose = () => {
    setIsClosing(true);
    setTimeout(() => onClose?.(), 300);
  };
  if (!isVisible && !isClosing) return null;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed top-4 left-1/2 -translate-x-1/2 transform",
      style: { zIndex: 9999 },
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `${alertConfig[type].bg} ${alertConfig[type].border} ${alertConfig[type].text} flex w-full max-w-xs items-center rounded-lg p-4 shadow-lg transition-all duration-300 md:max-w-md ${isClosing ? "translate-y-[-100%] opacity-0" : "translate-y-0 opacity-100"}`,
          role: "alert",
          "aria-live": "assertive",
          children: [
            alertConfig[type].icon,
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 flex-1 break-words text-sm font-medium", children: message }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
              lineNumber: 75,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleManualClose,
                className: `ml-auto -mx-1.5 -my-1.5 rounded-full p-1.5 hover:bg-gray-200 hover:bg-opacity-90`,
                "aria-label": "Close",
                children: /* @__PURE__ */ jsxDEV(FaTimes, { className: "h-5 w-5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
                  lineNumber: 83,
                  columnNumber: 11
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
                lineNumber: 78,
                columnNumber: 9
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
          lineNumber: 63,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx",
      lineNumber: 59,
      columnNumber: 5
    },
    this
  );
}, "ipWZdoaKtkla/sNXeWUi9+m3qRw=")), "ipWZdoaKtkla/sNXeWUi9+m3qRw=");
_c2 = CustomAlertDialog;
export default CustomAlertDialog;
var _c, _c2;
$RefreshReg$(_c, "CustomAlertDialog$memo");
$RefreshReg$(_c2, "CustomAlertDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/alerts/CustomAlertDialog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJZOzJCQWpCWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLE1BQU1DLFdBQVdDLGdCQUFnQjtBQUUxQyxNQUFNQyxvQkFBaUJDLEdBQUdKLEtBQUlLLEtBQUFELEdBQUMsQ0FBQyxFQUFFRSxZQUFVLE9BQU9DLE9BQU8sUUFBUUMsU0FBU0MsUUFBUSxNQUFNO0FBQUFMLEtBQUE7QUFDdkYsUUFBTSxDQUFDTSxXQUFXQyxZQUFZLElBQUlULFNBQVMsS0FBSztBQUVoRCxRQUFNVSxjQUFjO0FBQUEsSUFDbEJDLFNBQVM7QUFBQSxNQUNQQyxJQUFJO0FBQUEsTUFDSkMsTUFBTTtBQUFBLE1BQ05DLFFBQVE7QUFBQSxNQUNSQyxNQUFNLHVCQUFDLGlCQUFjLFdBQVUsNEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxJQUN6RDtBQUFBLElBQ0FDLE9BQU87QUFBQSxNQUNMSixJQUFJO0FBQUEsTUFDSkMsTUFBTTtBQUFBLE1BQ05DLFFBQVE7QUFBQSxNQUNSQyxNQUFNLHVCQUFDLGlCQUFjLFdBQVUsMEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxJQUN2RDtBQUFBLElBQ0FFLFNBQVM7QUFBQSxNQUNQTCxJQUFJO0FBQUEsTUFDSkMsTUFBTTtBQUFBLE1BQ05DLFFBQVE7QUFBQSxNQUNSQyxNQUFNLHVCQUFDLHlCQUFzQixXQUFVLDZCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsSUFDbEU7QUFBQSxJQUNBRyxNQUFNO0FBQUEsTUFDSk4sSUFBSTtBQUFBLE1BQ0pDLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsTUFBTSx1QkFBQyxnQkFBYSxXQUFVLDZCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsSUFDekQ7QUFBQSxFQUNGO0FBQ0ZoQixZQUFVLE1BQU07QUFDWixRQUFJSyxXQUFXO0FBQ2JLLG1CQUFhLEtBQUs7QUFDbEIsWUFBTVUsaUJBQWlCQyxXQUFXLE1BQU07QUFDdENYLHFCQUFhLElBQUk7QUFFakIsY0FBTVksY0FBY0QsV0FBVyxNQUFNYixVQUFVLEdBQUcsR0FBRztBQUNyRCxlQUFPLE1BQU1lLGFBQWFELFdBQVc7QUFBQSxNQUN2QyxHQUFHLEdBQUk7QUFDUCxhQUFPLE1BQU1DLGFBQWFILGNBQWM7QUFBQSxJQUMxQztBQUFBLEVBQ0YsR0FBRyxDQUFDZixXQUFXRyxPQUFPLENBQUM7QUFFeEIsUUFBTWdCLG9CQUFvQkEsTUFBTTtBQUM3QmQsaUJBQWEsSUFBSTtBQUNqQlcsZUFBVyxNQUFNYixVQUFVLEdBQUcsR0FBRztBQUFBLEVBQ25DO0FBRUEsTUFBSSxDQUFDSCxhQUFhLENBQUNJLFVBQVcsUUFBTztBQUNyQyxTQUNHO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDSixXQUFVO0FBQUEsTUFDVixPQUFPLEVBQUVnQixRQUFRLEtBQUs7QUFBQSxNQUVsQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVyxHQUFHZCxZQUFZTCxJQUFJLEVBQUVPLEVBQUUsSUFBSUYsWUFBWUwsSUFBSSxFQUFFUyxNQUFNLElBQzVESixZQUFZTCxJQUFJLEVBQUVRLElBQUksdUdBRXRCTCxZQUNJLGtDQUNBLDJCQUEyQjtBQUFBLFVBRWpDLE1BQUs7QUFBQSxVQUNMLGFBQVU7QUFBQSxVQUVURTtBQUFBQSx3QkFBWUwsSUFBSSxFQUFFVTtBQUFBQSxZQUNuQix1QkFBQyxVQUFLLFdBQVUsK0NBQ2JULHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU2lCO0FBQUFBLGdCQUNULFdBQVc7QUFBQSxnQkFDWCxjQUFXO0FBQUEsZ0JBRVgsaUNBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCO0FBQUE7QUFBQSxjQUw5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBO0FBQUE7QUFBQSxRQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzQkE7QUFBQTtBQUFBLElBMUJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTJCRDtBQUVKLEdBQUMsa0NBQUM7QUFBQ0UsTUE5RUd4QjtBQWdGTixlQUFlQTtBQUFrQixJQUFBRSxJQUFBc0I7QUFBQUMsYUFBQXZCLElBQUE7QUFBQXVCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJGYUNoZWNrQ2lyY2xlIiwiRmFUaW1lc0NpcmNsZSIsIkZhRXhjbGFtYXRpb25UcmlhbmdsZSIsIkZhSW5mb0NpcmNsZSIsIkZhVGltZXMiLCJtZW1vIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJDdXN0b21BbGVydERpYWxvZyIsIl9zIiwiX2MiLCJpc1Zpc2libGUiLCJ0eXBlIiwibWVzc2FnZSIsIm9uQ2xvc2UiLCJpc0Nsb3NpbmciLCJzZXRJc0Nsb3NpbmciLCJhbGVydENvbmZpZyIsInN1Y2Nlc3MiLCJiZyIsInRleHQiLCJib3JkZXIiLCJpY29uIiwiZXJyb3IiLCJ3YXJuaW5nIiwiaW5mbyIsImF1dG9DbG9zZVRpbWVyIiwic2V0VGltZW91dCIsIm5vdGlmeVRpbWVyIiwiY2xlYXJUaW1lb3V0IiwiaGFuZGxlTWFudWFsQ2xvc2UiLCJ6SW5kZXgiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tQWxlcnREaWFsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgRmFDaGVja0NpcmNsZSxcclxuICBGYVRpbWVzQ2lyY2xlLFxyXG4gIEZhRXhjbGFtYXRpb25UcmlhbmdsZSxcclxuICBGYUluZm9DaXJjbGUsXHJcbiAgRmFUaW1lcyxcclxufSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgbWVtbywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuY29uc3QgQ3VzdG9tQWxlcnREaWFsb2cgPSBtZW1vKCh7IGlzVmlzaWJsZT1mYWxzZSwgdHlwZSA9IFwiaW5mb1wiLCBtZXNzYWdlLCBvbkNsb3NlIH0pID0+IHtcclxuICBjb25zdCBbaXNDbG9zaW5nLCBzZXRJc0Nsb3NpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBhbGVydENvbmZpZyA9IHtcclxuICAgIHN1Y2Nlc3M6IHtcclxuICAgICAgYmc6IFwiYmctZ3JlZW4tNTBcIixcclxuICAgICAgdGV4dDogXCJ0ZXh0LWdyZWVuLTgwMFwiLFxyXG4gICAgICBib3JkZXI6IFwiYm9yZGVyLWdyZWVuLTMwMFwiLFxyXG4gICAgICBpY29uOiA8RmFDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtZ3JlZW4tNDAwXCIgLz4sXHJcbiAgICB9LFxyXG4gICAgZXJyb3I6IHtcclxuICAgICAgYmc6IFwiYmctcmVkLTUwXCIsXHJcbiAgICAgIHRleHQ6IFwidGV4dC1yZWQtODAwXCIsXHJcbiAgICAgIGJvcmRlcjogXCJib3JkZXItcmVkLTMwMFwiLFxyXG4gICAgICBpY29uOiA8RmFUaW1lc0NpcmNsZSBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtcmVkLTQwMFwiIC8+LFxyXG4gICAgfSxcclxuICAgIHdhcm5pbmc6IHtcclxuICAgICAgYmc6IFwiYmcteWVsbG93LTUwXCIsXHJcbiAgICAgIHRleHQ6IFwidGV4dC15ZWxsb3ctODAwXCIsXHJcbiAgICAgIGJvcmRlcjogXCJib3JkZXIteWVsbG93LTMwMFwiLFxyXG4gICAgICBpY29uOiA8RmFFeGNsYW1hdGlvblRyaWFuZ2xlIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC15ZWxsb3ctNDAwXCIgLz4sXHJcbiAgICB9LFxyXG4gICAgaW5mbzoge1xyXG4gICAgICBiZzogXCJiZy12aW9sZXQtNTBcIixcclxuICAgICAgdGV4dDogXCJ0ZXh0LXZpb2xldC04MDBcIixcclxuICAgICAgYm9yZGVyOiBcImJvcmRlci12aW9sZXQtMzAwXCIsXHJcbiAgICAgIGljb246IDxGYUluZm9DaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LXZpb2xldC00MDBcIiAvPixcclxuICAgIH0sXHJcbiAgfTtcclxudXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChpc1Zpc2libGUpIHtcclxuICAgICAgc2V0SXNDbG9zaW5nKGZhbHNlKTtcclxuICAgICAgY29uc3QgYXV0b0Nsb3NlVGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRJc0Nsb3NpbmcodHJ1ZSk7XHJcbiAgICBcclxuICAgICAgICBjb25zdCBub3RpZnlUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4gb25DbG9zZT8uKCksIDMwMCk7XHJcbiAgICAgICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dChub3RpZnlUaW1lcik7XHJcbiAgICAgIH0sIDIwMDApO1xyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KGF1dG9DbG9zZVRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbaXNWaXNpYmxlLCBvbkNsb3NlXSk7XHJcblxyXG4gY29uc3QgaGFuZGxlTWFudWFsQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICBzZXRJc0Nsb3NpbmcodHJ1ZSk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IG9uQ2xvc2U/LigpLCAzMDApO1xyXG4gIH07XHJcbiBcclxuICBpZiAoIWlzVmlzaWJsZSAmJiAhaXNDbG9zaW5nKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4gKFxyXG4gICAgIDxkaXZcclxuICBjbGFzc05hbWU9XCJmaXhlZCB0b3AtNCBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHRyYW5zZm9ybVwiXHJcbiAgc3R5bGU9e3sgekluZGV4OiA5OTk5IH19XHJcbiAgPlxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgJHthbGVydENvbmZpZ1t0eXBlXS5iZ30gJHthbGVydENvbmZpZ1t0eXBlXS5ib3JkZXJ9ICR7XHJcbiAgICAgICAgICBhbGVydENvbmZpZ1t0eXBlXS50ZXh0XHJcbiAgICAgICAgfSBmbGV4IHctZnVsbCBtYXgtdy14cyBpdGVtcy1jZW50ZXIgcm91bmRlZC1sZyBwLTQgc2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBtZDptYXgtdy1tZCAke1xyXG4gICAgICAgICAgaXNDbG9zaW5nXHJcbiAgICAgICAgICAgID8gXCJ0cmFuc2xhdGUteS1bLTEwMCVdIG9wYWNpdHktMFwiXHJcbiAgICAgICAgICAgIDogXCJ0cmFuc2xhdGUteS0wIG9wYWNpdHktMTAwXCJcclxuICAgICAgICB9YH1cclxuICAgICAgICByb2xlPVwiYWxlcnRcIlxyXG4gICAgICAgIGFyaWEtbGl2ZT1cImFzc2VydGl2ZVwiXHJcbiAgICAgID5cclxuICAgICAgICB7YWxlcnRDb25maWdbdHlwZV0uaWNvbn1cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIGZsZXgtMSBicmVhay13b3JkcyB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICB7bWVzc2FnZX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlTWFudWFsQ2xvc2V9IFxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgbWwtYXV0byAtbXgtMS41IC1teS0xLjUgcm91bmRlZC1mdWxsIHAtMS41IGhvdmVyOmJnLWdyYXktMjAwIGhvdmVyOmJnLW9wYWNpdHktOTBgfVxyXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8RmFUaW1lcyBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEN1c3RvbUFsZXJ0RGlhbG9nO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2cuanN4In0=