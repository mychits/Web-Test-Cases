import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Lead.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import axios from "/node_modules/.vite/deps/axios.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Input, Select, Dropdown, Tooltip, DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FaBriefcase, FaBuilding, FaUser, FaUsers, FaUserTie, FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
const { RangePicker } = DatePicker;
const Lead = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableGroups, setTableGroups] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [leads, setLeads] = useState([]);
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const whatsappEnable = true;
  const [leadShowModal, setLeadShowModal] = useState(false);
  const [selectedLeadData, setSelectedLeadData] = useState(null);
  const [isModalLoading, setIsModalLoading] = useState(false);
  const [filterAgent, setFilterAgent] = useState("all");
  const [filterDateRange, setFilterDateRange] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const navigate = useNavigate();
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const handleGroupChange = async (event) => {
    const groupId = event.target.value;
    setSelectedGroup(groupId);
  };
  const [formData, setFormData] = useState({
    lead_name: "",
    lead_phone: "",
    lead_profession: "",
    group_id: "",
    lead_type: "",
    lead_customer: "",
    lead_employee: "",
    lead_agent: "",
    lead_needs: "",
    note: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    lead_name: "",
    lead_phone: "",
    lead_profession: "",
    group_id: "",
    lead_type: "",
    lead_customer: "",
    lead_agent: "",
    lead_employee: "",
    lead_agent_name: "",
    lead_employee_name: "",
    lead_needs: "",
    note: ""
  });
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [reloadTrigger]);
  const handleAssignTask = (leadId, leadTypeName) => {
    navigate("/task", { state: { leadId, leadTypeName } });
  };
  const filterOptions = useMemo(() => {
    if (!leads || leads.length === 0) return { agents: [], types: [] };
    const agents2 = /* @__PURE__ */ new Set();
    const types = /* @__PURE__ */ new Set();
    leads.forEach((lead) => {
      if (lead.lead_agent?.name) agents2.add(lead.lead_agent.name);
      if (lead.lead_type) types.add(lead.lead_type);
    });
    return {
      agents: Array.from(agents2).sort(),
      types: Array.from(types).sort()
    };
  }, [leads]);
  const filteredLeads = useMemo(() => {
    let data = leads;
    if (filterAgent !== "all") {
      data = data.filter((item) => item.lead_agent?.name === filterAgent);
    }
    if (filterType !== "all") {
      data = data.filter((item) => item.lead_type === filterType);
    }
    if (filterDateRange && filterDateRange.length === 2) {
      const [start, end] = filterDateRange;
      data = data.filter((item) => {
        if (!item.createdAt) return false;
        const itemDate = new Date(item.createdAt);
        return itemDate >= start.toDate() && itemDate <= end.toDate();
      });
    }
    return data;
  }, [leads, filterAgent, filterDateRange, filterType]);
  const filteredTableData = useMemo(() => {
    let data = TableGroups;
    if (filterAgent !== "all") {
      data = data.filter((item) => item.lead_type_name === filterAgent);
    }
    if (filterType !== "all") {
      data = data.filter((item) => item.lead_type === filterType);
    }
    if (filterDateRange && filterDateRange.length === 2) {
      const [start, end] = filterDateRange;
      data = data.filter((item) => {
        if (!item.date) return false;
        const itemDate = new Date(item.date);
        return itemDate >= start.toDate() && itemDate <= end.toDate();
      });
    }
    if (searchText) {
      data = data.filter(
        (item) => Object.values(item).some(
          (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
        )
      );
    }
    return data;
  }, [TableGroups, filterAgent, filterDateRange, filterType, searchText]);
  useEffect(() => {
    const fetchLeads = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/lead/new-non-converted");
        setLeads(response.data);
        const formattedData = response.data.map((group, index) => ({
          _id: group._id,
          id: index + 1,
          lead_code: group?.lead_code,
          name: group?.lead_name,
          phone: group?.lead_phone,
          profession: group?.lead_profession,
          lead_needs: group?.lead_needs,
          group_id: group?.group_id?.group_name || group?.group_name || "",
          date: group?.createdAt?.split("T")[0] || "",
          lead_type: group.lead_type,
          note: group?.note,
          lead_type_name: group.lead_type === "customer" ? group?.lead_customer?.full_name : group.lead_type === "agent" || group.lead_type === "employee" ? group?.lead_agent?.name : "",
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 218,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(Tooltip, { title: "Lead to Customer", children: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-purple-900 cursor-pointer font-bold",
                        onClick: () => handleOpenConvertCustomerModal(group._id),
                        children: "L ↔ C"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 230,
                        columnNumber: 27
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 229,
                      columnNumber: 19
                    }, this)
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-blue-600",
                        onClick: () => handleAssignTask(group._id, group.lead_type_name),
                        children: "Assign Task"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 244,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "4",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-rose-500",
                        onClick: () => handleSoftRemove(group._id),
                        children: "Remove"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 257,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 269,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 211,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 210,
            columnNumber: 11
          }, this)
        }));
        setTableGroups(formattedData);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchLeads();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchAgent = async () => {
      try {
        const response = await api.get("/agent/get");
        setAgents(response?.data?.agent);
      } catch (error) {
        console.error("Error fetching agent data:", error);
      }
    };
    fetchAgent();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchEmployee = async () => {
      try {
        const response = await api.get("/employee");
        setEmployees(response?.data?.employee);
      } catch (error) {
        console.error("Error fetching Employee data:", error);
      }
    };
    fetchEmployee();
  }, [reloadTrigger]);
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleSoftRemove = async (leadId) => {
    try {
      await api.put(`/lead/soft-delete-lead/${leadId}`);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Lead removed successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error soft removing lead:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to remove lead",
        type: "error"
      });
    }
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addLead" ? formData : updateFormData;
    if (!data.lead_name?.toString().trim()) {
      newErrors.lead_name = "Lead Name is required";
    }
    if (!data.lead_phone) {
      newErrors.lead_phone = "Phone Number is required";
    } else if (!/^[6-9]\d{9}$/.test(data.lead_phone)) {
      newErrors.lead_phone = "Invalid phone number (must be 10 digits)";
    }
    if (!data.lead_profession) {
      newErrors.lead_profession = "Profession is required";
    }
    if (!data.lead_type) {
      newErrors.lead_type = "Lead Source Type is required";
    }
    if (data.lead_type === "customer" && !data.lead_customer) {
      newErrors.lead_customer = "Customer selection is required";
    }
    if (data.lead_type === "agent" && !data.lead_agent) {
      newErrors.lead_agent = "Agent selection is required";
    }
    if (data.lead_type === "employee" && !data.lead_employee) {
      newErrors.lead_employee = "Employee selection is required";
    }
    if (!data.lead_needs?.toString()) {
      newErrors.lead_needs = "Lead Needs and Goals is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addLead");
    if (!isValid) return;
    try {
      const response = await api.post("/lead/add-lead", formData);
      setShowModal(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Lead added successfully",
        type: "success"
      });
      setFormData({
        lead_name: "",
        lead_phone: "",
        lead_profession: "",
        group_id: "",
        lead_type: "",
        lead_customer: "",
        lead_agent: "",
        lead_employee: "",
        lead_needs: "",
        note: ""
      });
    } catch (error) {
      console.log("Error:", error.response?.data);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Something went wrong",
        type: "error"
      });
    }
  };
  const filteredGroups = groups.filter(
    (group) => group.group_name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/v1/admin/lead/lead-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching lead:", error);
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/v1/admin/lead/lead-by-id/${groupId}`);
      const data = response.data;
      setCurrentUpdateGroup(data);
      let agentId = "";
      let employeeId = "";
      if (data?.lead_type === "agent" && data?.lead_agent) {
        agentId = String(data.lead_agent._id || data.lead_agent);
      } else if (data?.lead_type === "employee" && data?.lead_agent) {
        employeeId = String(data.lead_agent._id || data.lead_agent);
      }
      setUpdateFormData({
        lead_name: data?.lead_name || "",
        lead_phone: data?.lead_phone || "",
        lead_profession: data?.lead_profession || "",
        group_id: data?.group_id?._id || data?.group_id || "",
        lead_type: data?.lead_type || "",
        lead_agent: agentId,
        lead_employee: employeeId,
        lead_customer: data?.lead_customer?._id || data?.lead_customer || "",
        lead_needs: data?.lead_needs || "",
        note: data?.note || ""
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching lead:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to load lead details",
        type: "error"
      });
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };
  const handleDeleteGroup = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/lead/delete-lead/${currentGroup._id}`);
        setShowModalDelete(false);
        setCurrentGroup(null);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Lead deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting lead:", error);
      }
    }
  };
  const regex = {
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    // Validates email format
    pincode: /^\d{6}$/,
    // Validates 6 digits for pincode
    adhaar: /^\d{12}$/
    // Validates 12 digits for Aadhar number
  };
  const validateConvertToCustomer = (data) => {
    const newErrors = {};
    if (!data.full_name?.trim()) {
      newErrors.full_name = "Full name is required";
    }
    if (!data.phone_number || !/^[6-9]\d{9}$/.test(data.phone_number)) {
      newErrors.phone_number = "Valid phone number is required";
    }
    if (!data.password) {
      newErrors.password = "Password is required";
    }
    if (!data.pincode || !regex.pincode.test(data.pincode)) {
      newErrors.pincode = "Invalid pincode (6 digits required)";
    }
    if (!data.adhaar_no || !regex.adhaar.test(data.adhaar_no)) {
      newErrors.adhaar_no = "Invalid Aadhar number (12 digits required)";
    }
    if (data.pan_no && data.pan_no.trim().length !== 10) {
      newErrors.pan_no = "Invalid PAN format (e.g., ABCDE1234F)";
    }
    if (!data.address || data.address.trim().length < 3) {
      newErrors.address = "Address should be at least 3 characters";
    }
    if (!data.no_of_tickets) {
      newErrors.no_of_tickets = "Number of Tickets is required";
    }
    if (!data.payment_type) {
      newErrors.payment_type = "Payment type is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm("updateLead");
    try {
      if (isValid) {
        const submitData = {
          ...updateFormData,
          // If lead_type is agent, send lead_agent; if employee, send lead_employee
          lead_agent: updateFormData.lead_type === "agent" ? updateFormData.lead_agent : null,
          lead_employee: updateFormData.lead_type === "employee" ? updateFormData.lead_employee : null,
          lead_customer: updateFormData.lead_type === "customer" ? updateFormData.lead_customer : null
        };
        await api.put(
          `/lead/update-lead/${currentUpdateGroup._id}`,
          submitData
        );
        setShowModalUpdate(false);
        setAlertConfig({
          visibility: true,
          message: "Lead Updated Successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
      }
    } catch (error) {
      console.error("Error updating lead:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to update lead",
        type: "error"
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "lead_code", header: "Lead ID" },
    // <--- ADDED LEAD_ID COLUMN
    { key: "name", header: "Lead Name" },
    { key: "phone", header: "Lead Phone Number" },
    { key: "profession", header: "Lead Profession" },
    { key: "date", header: "Date" },
    { key: "group_id", header: "Group Name" },
    { key: "lead_type", header: "Lead Source Type" },
    { key: "lead_needs", header: "Lead Needs And Goals" },
    { key: "lead_type_name", header: "Lead Source Name" },
    { key: "note", header: "Note" },
    { key: "action", header: "Action" }
  ];
  const handleConvertCustomerSubmit = async (e) => {
    e.preventDefault();
    const valid = validateConvertToCustomer(formData);
    if (!valid) return;
    try {
      if (valid) {
        const response = await api.post(
          "/lead/convert-lead-to-customer",
          formData
        );
        setAlertConfig({
          type: "success",
          message: response.data.message || "Lead converted successfully",
          visibility: true
        });
        setLeadShowModal(false);
        setReloadTrigger((prev) => prev + 1);
        setErrors({});
      }
    } catch (error) {
      const errMsg = error?.response?.data?.message;
      if (errMsg?.toLowerCase().includes("phone number")) {
        setErrors((prev) => ({
          ...prev,
          phone_number: "Phone number already exists."
        }));
      }
      if (errMsg?.toLowerCase().includes("group is already full")) {
        setErrors((prev) => ({ ...prev, group_id: errMsg }));
      }
      if (errMsg?.toLowerCase().includes("agent already exists")) {
        setErrors((prev) => ({ ...prev, agent: errMsg }));
      }
      setAlertConfig({
        type: "error",
        message: errMsg || "Something went wrong",
        visibility: true
      });
    }
  };
  const handleOpenConvertCustomerModal = async (leadId) => {
    try {
      const { data } = await api.get(
        `/lead/get-lead-to-customer-by-id/${leadId}`
      );
      setFormData({
        full_name: data?.lead_name || "",
        phone_number: data?.lead_phone || "",
        lead_profession: data?.lead_profession || "",
        //  Ensure added
        group_id: data?.group_id?._id || "",
        //  Ensure added
        lead_type: data?.lead_type || "",
        //  Ensure added
        lead_agent: data?.lead_agent?._id || "",
        email: "",
        password: "",
        lead_customer: data?.lead_customer?._id || "",
        pincode: data?.pincode || "",
        address: data?.lead_address || "",
        adhaar_no: "",
        pan_no: "",
        lead_needs: data?.lead_needs || "",
        note: data?.note || "",
        referred_type: data?.lead_type || "",
        payment_type: data?.payment_type || "",
        no_of_tickets: data?.no_of_tickets || ""
      });
      setLeadShowModal(true);
    } catch (error) {
      console.error("Error opening convert modal:", error);
      setAlertConfig({
        type: "error",
        message: "Failed to load lead details.",
        visibility: true
      });
    }
  };
  const agentLeadCounts = useMemo(() => {
    if (!leads || leads.length === 0) return [];
    const counts = {};
    leads.forEach((lead) => {
      const agentName = lead.lead_agent?.name;
      if (agentName) {
        counts[agentName] = (counts[agentName] || 0) + 1;
      }
    });
    return Object.entries(counts).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
  }, [leads]);
  const stats = useMemo(() => {
    if (!filteredLeads || filteredLeads.length === 0) return null;
    const total = leads.length;
    const typeCount = {};
    const professionCount = {};
    const groupCount = {};
    leads.forEach((lead) => {
      const type = lead.lead_type || "unknown";
      typeCount[type] = (typeCount[type] || 0) + 1;
      const prof = lead.lead_profession || "not-specified";
      professionCount[prof] = (professionCount[prof] || 0) + 1;
      const group = lead.group_name || "Unassigned";
      groupCount[group] = (groupCount[group] || 0) + 1;
    });
    const topGroups = Object.entries(groupCount).sort((a, b) => b[1] - a[1]).slice(0, 5);
    return { total, typeCount, professionCount, topGroups };
  }, [leads]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "mt-20 overflow-x-hidden", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 897,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 901,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 910,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0 p-7 overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8 ", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full ", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold ", children: "Leads" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 915,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
                setErrors({});
              },
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Add Lead"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 916,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 914,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 913,
          columnNumber: 15
        }, this),
        stats && /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 shadow-sm border border-blue-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-blue-700", children: "Total Leads" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 936,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: stats.total }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 937,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 935,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-500 rounded-full text-white", children: /* @__PURE__ */ jsxDEV(FaUsers, { className: "w-6 h-6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 940,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 939,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 934,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 933,
            columnNumber: 21
          }, this),
          Object.entries(stats.typeCount).map(
            ([type, count]) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-4 shadow-sm border border-gray-200",
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-700 capitalize", children: type + " Leads" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 952,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: count }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 955,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 951,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gray-300 rounded-full text-gray-700", children: [
                    type === "agent" && /* @__PURE__ */ jsxDEV(FaUserTie, { className: "text-blue-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 958,
                      columnNumber: 50
                    }, this),
                    type === "employee" && /* @__PURE__ */ jsxDEV(FaUser, { className: "text-green-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 959,
                      columnNumber: 53
                    }, this),
                    type === "social media" && /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-purple-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 960,
                      columnNumber: 57
                    }, this),
                    type === "customer" && /* @__PURE__ */ jsxDEV(FaUser, { className: "text-yellow-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 961,
                      columnNumber: 53
                    }, this),
                    !["agent", "employee", "social media", "customer"].includes(type) && /* @__PURE__ */ jsxDEV(FaUsers, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 962,
                      columnNumber: 99
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 957,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 950,
                  columnNumber: 25
                }, this)
              },
              type,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 946,
                columnNumber: 19
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 932,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 930,
          columnNumber: 15
        }, this),
        agentLeadCounts.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 mb-3", children: "Leads by Agent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 973,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-8 gap-4", children: agentLeadCounts.map(
            ({ name, count }) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl p-2 shadow-sm border border-indigo-200",
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-indigo-700 truncate max-w-[120px]", title: name, children: name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 982,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: count }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 985,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 981,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 980,
                  columnNumber: 25
                }, this)
              },
              name,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 976,
                columnNumber: 19
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 974,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 972,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "AGENT" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1003,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "w-full",
                placeholder: "All Agents",
                value: filterAgent,
                onChange: (value) => setFilterAgent(value),
                options: [
                  { value: "all", label: "All Agents" },
                  ...filterOptions.agents.map((agent) => ({ value: agent, label: agent }))
                ],
                showSearch: true,
                filterOption: (input, option) => option.label.toLowerCase().includes(input.toLowerCase())
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1004,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1002,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "DATE RANGE" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1022,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                className: "w-full",
                value: filterDateRange,
                onChange: (dates) => setFilterDateRange(dates),
                placeholder: ["Start date", "End date"]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1023,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1021,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "TYPE" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1033,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "w-full",
                placeholder: "All Types",
                value: filterType,
                onChange: (value) => setFilterType(value),
                options: [
                  { value: "all", label: "All Types" },
                  ...filterOptions.types.map((type) => ({ value: type, label: type }))
                ]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1034,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1032,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-xl shadow-lg w-1/2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold tracking-wide", children: "Total Leads" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1048,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bg-white text-blue-700 px-3 py-1 rounded-full text-lg font-bold min-w-[45px] text-center", children: filteredTableData?.length || 0 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1052,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1047,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 1e3,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 999,
          columnNumber: 15
        }, this),
        TableGroups.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: handleUpdateModalOpen,
            data: filteredTableData,
            columns,
            exportedPdfName: "Lead",
            exportedFileName: `Leads.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1059,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 1074,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 1076,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 912,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
      lineNumber: 909,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setShowModal(false);
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1137,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Lead Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1144,
                      columnNumber: 31
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1140,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "lead_name",
                  value: formData.lead_name,
                  onChange: handleChange,
                  id: "name",
                  placeholder: "Enter the Lead Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1146,
                  columnNumber: 19
                },
                this
              ),
              errors.lead_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1157,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1139,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Lead Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1168,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1164,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "lead_phone",
                    value: formData.lead_phone,
                    onChange: handleChange,
                    id: "text",
                    placeholder: "Enter Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1170,
                    columnNumber: 21
                  },
                  this
                ),
                errors.lead_phone && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_phone }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1181,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1163,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Lead Work/Profession",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1192,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1187,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Lead Work/Profession ",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "lead_profession",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: formData?.lead_profession || void 0,
                    onChange: (value) => handleAntDSelect("lead_profession", value),
                    children: ["Employed", "Self Employed"].map(
                      (lProf) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lProf.toLowerCase(), children: lProf }, lProf, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1212,
                        columnNumber: 23
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1195,
                    columnNumber: 21
                  },
                  this
                ),
                errors.lead_profession && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_profession }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1218,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1186,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1162,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Group"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1225,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Group ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "group_id",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.group_id || void 0,
                  onChange: (value) => handleAntDSelect("group_id", value),
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1259,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1246,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1224,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Lead Source Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1270,
                      columnNumber: 38
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1266,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Lead Source Type ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.lead_type || void 0,
                  onChange: (value) => handleAntDSelect("lead_type", value),
                  children: [
                    "Social Media",
                    "Customer",
                    "Agent",
                    "Employee",
                    "Walkin"
                  ].map(
                    (lType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lType.toLowerCase(), children: lType }, lType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1292,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1273,
                  columnNumber: 19
                },
                this
              ),
              errors.lead_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1298,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1265,
              columnNumber: 17
            }, this),
            formData.lead_type === "customer" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Customers"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1306,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_customer",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.lead_customer || void 0,
                  onChange: (value) => handleAntDSelect("lead_customer", value),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1331,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1313,
                  columnNumber: 23
                },
                this
              ),
              errors.lead_customer && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1337,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1305,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1304,
              columnNumber: 17
            }, this),
            formData.lead_type === "agent" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Agent"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1348,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Agent",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_agent",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.lead_agent || void 0,
                  onChange: (value) => handleAntDSelect("lead_agent", value),
                  children: agents.map(
                    (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: agent.name }, agent._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1373,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1355,
                  columnNumber: 23
                },
                this
              ),
              errors.lead_agent && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_agent }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1379,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1347,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1346,
              columnNumber: 17
            }, this),
            formData.lead_type === "employee" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Employee"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1390,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Employee",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_employee",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.lead_employee || void 0,
                  onChange: (value) => handleAntDSelect("lead_employee", value),
                  children: employees.map(
                    (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: emp.name }, emp._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1414,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1396,
                  columnNumber: 23
                },
                this
              ),
              errors.lead_employee && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_employee }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1420,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1389,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1388,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Lead Needs and Goals ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1433,
                      columnNumber: 42
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1429,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Lead Needs and Goals ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_needs",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.lead_needs || void 0,
                  onChange: (value) => handleAntDSelect("lead_needs", value),
                  children: ["Savings", "Borrowings"].map(
                    (lNeeds) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lNeeds.toLowerCase(), children: lNeeds }, lNeeds, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1460,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1447,
                  columnNumber: 19
                },
                this
              ),
              errors.lead_needs && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_needs }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1466,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1428,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "date",
                  children: "Note"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1472,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  rows: 2,
                  name: "note",
                  value: formData.note,
                  onChange: handleChange,
                  id: "text",
                  placeholder: "Specify note if any!",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1478,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1471,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center p-4 max-w-full bg-white rounded-lg shadow-sm space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
                /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { color: "green", className: "w-10 h-10" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1492,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: "WhatsApp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1493,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1491,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: whatsappEnable,
                    className: "text-green-500 checked:ring-2  checked:ring-green-700  rounded-full w-4 h-4"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1499,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: "Send Via Whatsapp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1504,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1498,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1490,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n                                focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Save Lead"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1509,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1508,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1138,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 1136,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 1129,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => {
          setShowModalUpdate(false);
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1528,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Lead Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1538,
                      columnNumber: 31
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1534,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "lead_name",
                  value: updateFormData.lead_name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Group Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1540,
                  columnNumber: 19
                },
                this
              ),
              errors.lead_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1551,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1533,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Lead Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1562,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1558,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "lead_phone",
                    value: updateFormData.lead_phone,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Lead Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1564,
                    columnNumber: 21
                  },
                  this
                ),
                errors.lead_phone && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_phone }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1575,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1557,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Lead Work/Profession",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1586,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1581,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Lead Work/Profession ",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "lead_profession",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.lead_profession || void 0,
                    onChange: (value) => handleAntInputDSelect("lead_profession", value),
                    children: ["Employed", "Self Employed"].map(
                      (lProf) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lProf.toLowerCase(), children: lProf }, lProf, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1606,
                        columnNumber: 23
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1589,
                    columnNumber: 21
                  },
                  this
                ),
                errors.lead_profession && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_profession }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1612,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1580,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1556,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Group"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1619,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Group ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "group_id",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.group_id || void 0,
                  onChange: (value) => handleAntInputDSelect("group_id", value),
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1653,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1640,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1618,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Lead Source Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1664,
                      columnNumber: 38
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1660,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Lead Source Type ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.lead_type || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_type", value),
                  children: [
                    "Social Media",
                    "Customer",
                    "Agent",
                    "Employee",
                    "Walkin"
                  ].map(
                    (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type.toLowerCase(), children: type }, type, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1701,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1680,
                  columnNumber: 19
                },
                this
              ),
              errors.lead_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1707,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1659,
              columnNumber: 17
            }, this),
            updateFormData.lead_type === "customer" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Customers"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1715,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customers",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_customer",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.lead_customer || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_customer", value),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1754,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1736,
                  columnNumber: 23
                },
                this
              ),
              errors.lead_customer && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1760,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1714,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1713,
              columnNumber: 17
            }, this),
            " ",
            updateFormData.lead_type === "agent" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Agents"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1770,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Agent",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_agent",
                  filterOption: (input, option) => {
                    const optionText = String(option?.children || "");
                    return optionText.toLowerCase().includes(String(input).toLowerCase());
                  },
                  value: updateFormData?.lead_agent || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_agent", value),
                  children: employees.map(
                    (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: emp?.name }, emp._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1795,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1776,
                  columnNumber: 23
                },
                this
              ),
              errors.lead_agent && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_agent }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1801,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1769,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1768,
              columnNumber: 17
            }, this),
            updateFormData.lead_type === "employee" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Employee"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1811,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Employee",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_employee",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.lead_employee || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_employee", value),
                  children: employees.map(
                    (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: emp?.name }, emp._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1835,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1817,
                  columnNumber: 23
                },
                this
              ),
              errors.lead_employee && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_employee }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1841,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1810,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1809,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: "Note"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1848,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "note",
                value: updateFormData.note,
                onChange: handleInputChange,
                id: "text",
                placeholder: "Specify note if any!",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1854,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Lead Needs and Goals ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1869,
                      columnNumber: 42
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1865,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Lead Needs and Goals ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "lead_needs",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.lead_needs || void 0,
                  onChange: (value) => handleAntInputDSelect("lead_needs", value),
                  children: ["Savings", "Borrowings"].map(
                    (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type.toLowerCase(), children: type }, type, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1898,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1883,
                  columnNumber: 19
                },
                this
              ),
              errors.lead_needs && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_needs }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1904,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1864,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                lineNumber: 1910,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1909,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1532,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 1527,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 1520,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: leadShowModal,
        onClose: () => setLeadShowModal(false),
        leadData: selectedLeadData,
        setReloadTrigger,
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Convert Lead to Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 1928,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "form",
            {
              className: "space-y-6",
              onSubmit: handleConvertCustomerSubmit,
              noValidate: true,
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "name",
                        children: [
                          "Lead Name ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 1942,
                            columnNumber: 33
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1938,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "full_name",
                        value: formData.full_name,
                        onChange: handleChange,
                        id: "name",
                        placeholder: "Enter the Group Name",
                        readOnly: true,
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1944,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.full_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.full_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 1956,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1937,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Lead Email ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 1966,
                            columnNumber: 34
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1962,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "email",
                        value: formData.email,
                        onChange: handleChange,
                        id: "text",
                        placeholder: "Enter Email",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1968,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1961,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1936,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Lead Phone Number ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 1986,
                            columnNumber: 41
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1982,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "phone_number",
                        value: formData.phone_number,
                        onChange: handleChange,
                        id: "text",
                        placeholder: "Enter Lead Phone Number",
                        readOnly: true,
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 1988,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.phone_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2e3,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 1981,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Lead Work/Profession",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2011,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2006,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Lead Work/Profession ",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "lead_profession",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData?.lead_profession || void 0,
                        onChange: (value) => handleAntDSelect("lead_profession", value),
                        children: ["Employed", "Self Employed"].map(
                          (lProf) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lProf.toLowerCase(), children: lProf }, lProf, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2031,
                            columnNumber: 23
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2014,
                        columnNumber: 21
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2005,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 1980,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: "Group"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2044,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select Group ",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "group_id",
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      value: formData?.group_id || void 0,
                      onChange: (value) => handleAntDSelect("group_id", value),
                      children: groups.map(
                        (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2064,
                          columnNumber: 21
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2051,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.group_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors.group_id }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2070,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2043,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: [
                        "Lead Source Type ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2078,
                          columnNumber: 38
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2074,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select or Search Lead Source Type ",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "lead_type",
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      value: formData?.lead_type || void 0,
                      onChange: (value) => handleAntDSelect("lead_type", value),
                      children: [
                        "Social Media",
                        "Customer",
                        "Agent",
                        "Employee",
                        "Walkin"
                      ].map(
                        (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type.toLowerCase(), children: type }, type, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2100,
                          columnNumber: 21
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2081,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.lead_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_type }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2106,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2073,
                  columnNumber: 17
                }, this),
                formData.lead_type === "customer" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: "Customers"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2114,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                      placeholder: "Select Or Search Customers",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "lead_customer",
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      value: formData?.lead_customer || void 0,
                      onChange: (value) => handleAntDSelect("lead_customer", value),
                      children: users.map(
                        (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2139,
                          columnNumber: 23
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2121,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2113,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2112,
                  columnNumber: 17
                }, this),
                " ",
                formData.lead_type === "agent" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: "Agents"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2155,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select or Search Agent ",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "lead_agent",
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      value: formData?.lead_agent || void 0,
                      onChange: (value) => handleAntDSelect("lead_agent", value),
                      children: agents.map(
                        (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: agent.name }, agent._id, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2179,
                          columnNumber: 23
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2162,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.lead_agent && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_agent }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2185,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2154,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2153,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Password ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2198,
                            columnNumber: 32
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2194,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "password",
                        value: formData.password,
                        onChange: handleChange,
                        id: "text",
                        placeholder: "Enter Password",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2200,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.password && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.password }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2211,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2193,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Pincode ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2221,
                            columnNumber: 31
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2217,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        name: "pincode",
                        value: formData.pincode,
                        onChange: handleChange,
                        id: "text",
                        placeholder: "Enter Pincode",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2223,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2234,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2216,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2192,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "email",
                      children: [
                        "Address ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2245,
                          columnNumber: 29
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2241,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "address",
                      value: formData.address,
                      onChange: handleChange,
                      id: "name",
                      placeholder: "Enter the Address",
                      required: true,
                      className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2247,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2240,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "payment_type",
                      children: [
                        "Select Payment Type ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2266,
                          columnNumber: 41
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2262,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                      placeholder: "Select Payment Type",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      name: "payment_type",
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      value: formData?.payment_type || void 0,
                      onChange: (value) => handleAntDSelect("payment_type", value),
                      children: ["Daily", "Weekly", "Monthly"].map(
                        (pType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: pType, children: pType }, pType, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2281,
                          columnNumber: 21
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2268,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.payment_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.payment_type }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2287,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2261,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "date",
                        children: [
                          "Adhaar Number ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2298,
                            columnNumber: 37
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2294,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "number",
                        name: "adhaar_no",
                        value: formData.adhaar_no,
                        onChange: handleChange,
                        id: "text",
                        placeholder: "Enter Adhaar Number",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2300,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2311,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2293,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "category",
                        children: [
                          "Pan Number ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2322,
                            columnNumber: 34
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2318,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "pan_no",
                        value: formData?.pan_no,
                        onChange: handleChange,
                        id: "text",
                        placeholder: "Enter Pan Number",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2324,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2335,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2317,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2292,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "date",
                      children: "Note"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2340,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "note",
                      value: formData.note,
                      onChange: handleChange,
                      id: "text",
                      placeholder: "Specify note if any!",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2346,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2339,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "no_of_tickets",
                        children: [
                          "Number of Tickets ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2363,
                            columnNumber: 41
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2359,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "no_of_tickets",
                        value: formData.no_of_tickets,
                        onChange: handleChange,
                        id: "text",
                        placeholder: "Enter Number of Tickets",
                        required: true,
                        className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2365,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.no_of_tickets && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.no_of_tickets }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2376,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2358,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "category",
                        children: [
                          "Lead Needs and Goals",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2387,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2382,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select or Search Lead Needs and Goals ",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "lead_needs",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData?.lead_needs || void 0,
                        onChange: (value) => handleAntDSelect("lead_needs", value),
                        children: ["Savings", "Borrowings"].map(
                          (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type.toLowerCase(), children: type }, type, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                            lineNumber: 2405,
                            columnNumber: 23
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                        lineNumber: 2390,
                        columnNumber: 21
                      },
                      this
                    ),
                    errors.lead_needs && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.lead_needs }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2411,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2381,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2357,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Convert To Customer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2418,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2417,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 1931,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 1927,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 1921,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
            lineNumber: 2437,
            columnNumber: 15
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteGroup();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentGroup.lead_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2454,
                          columnNumber: 23
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                          lineNumber: 2458,
                          columnNumber: 23
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2449,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the Lead Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                      lineNumber: 2460,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                  lineNumber: 2448,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
                    lineNumber: 2468,
                    columnNumber: 19
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
              lineNumber: 2441,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
          lineNumber: 2436,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
        lineNumber: 2429,
        columnNumber: 11
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
    lineNumber: 896,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
    lineNumber: 895,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx",
    lineNumber: 894,
    columnNumber: 5
  }, this);
};
_s(Lead, "ui/g46p7CcjjKhj/v9kL26AAclw=", false, function() {
  return [useNavigate];
});
_c = Lead;
export default Lead;
var _c;
$RefreshReg$(_c, "Lead");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Lead.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeU53QixTQThqQ04sVUE5akNNOzJCQXpOeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDN0MsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxRQUFRQyxVQUFVQyxTQUFTQyxrQkFBa0I7QUFDN0QsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxhQUFhQyxZQUFZQyxRQUFRQyxTQUFTQyxXQUFXQyx3QkFBd0I7QUFDdEYsU0FBU0MsbUJBQW1CO0FBQzVCLE1BQU0sRUFBRUMsWUFBWSxJQUFJVjtBQUV4QixNQUFNVyxPQUFPQSxNQUFNO0FBQUFDLEtBQUE7QUFDakIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUk3QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDOEIsYUFBYUMsY0FBYyxJQUFJL0IsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ2dDLFlBQVlDLGFBQWEsSUFBSWpDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDb0MsaUJBQWlCQyxrQkFBa0IsSUFBSXJDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNzQyxpQkFBaUJDLGtCQUFrQixJQUFJdkMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3dDLGNBQWNDLGVBQWUsSUFBSXpDLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUMwQyxvQkFBb0JDLHFCQUFxQixJQUFJM0MsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQzRDLGVBQWVDLGdCQUFnQixJQUFJN0MsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQzhDLGVBQWVDLGdCQUFnQixJQUFJL0MsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2dELE9BQU9DLFFBQVEsSUFBSWpELFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNrRCxPQUFPQyxRQUFRLElBQUluRCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDb0QsUUFBUUMsU0FBUyxJQUFJckQsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3NELFdBQVdDLFlBQVksSUFBSXZELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUN3RCxRQUFRQyxTQUFTLElBQUl6RCxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUMwRCxXQUFXQyxZQUFZLElBQUkzRCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDNEQsWUFBWUMsYUFBYSxJQUFJN0QsU0FBUyxFQUFFO0FBQy9DLFFBQU04RCxpQkFBaUI7QUFDdkIsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSWhFLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNpRSxrQkFBa0JDLG1CQUFtQixJQUFJbEUsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQ21FLGdCQUFnQkMsaUJBQWlCLElBQUlwRSxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDcUUsYUFBYUMsY0FBYyxJQUFJdEUsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ3VFLGlCQUFpQkMsa0JBQWtCLElBQUl4RSxTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDeUUsWUFBWUMsYUFBYSxJQUFJMUUsU0FBUyxLQUFLO0FBRWxELFFBQU0yRSw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCakIsa0JBQWNnQixLQUFLO0FBQUEsRUFDckI7QUFDQSxRQUFNRSxXQUFXdkQsWUFBWTtBQUM3QixRQUFNLENBQUN3RCxhQUFhQyxjQUFjLElBQUlqRixTQUFTO0FBQUEsSUFDN0NrRixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNQyxvQkFBb0IsT0FBT0MsVUFBVTtBQUN6QyxVQUFNQyxVQUFVRCxNQUFNUixPQUFPRDtBQUM3QjlCLHFCQUFpQndDLE9BQU87QUFBQSxFQUMxQjtBQUVBLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJekYsU0FBUztBQUFBLElBQ3ZDMEYsV0FBVztBQUFBLElBQ1hDLFlBQVk7QUFBQSxJQUNaQyxpQkFBaUI7QUFBQSxJQUNqQkMsVUFBVTtBQUFBLElBQ1ZDLFdBQVc7QUFBQSxJQUNYQyxlQUFlO0FBQUEsSUFDZkMsZUFBZTtBQUFBLElBQ2ZDLFlBQVk7QUFBQSxJQUNaQyxZQUFZO0FBQUEsSUFDWkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXJHLFNBQVM7QUFBQSxJQUNuRDBGLFdBQVc7QUFBQSxJQUNYQyxZQUFZO0FBQUEsSUFDWkMsaUJBQWlCO0FBQUEsSUFDakJDLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsSUFDWEMsZUFBZTtBQUFBLElBQ2ZFLFlBQVk7QUFBQSxJQUNaRCxlQUFlO0FBQUEsSUFDZk0saUJBQWlCO0FBQUEsSUFDakJDLG9CQUFvQjtBQUFBLElBQ3BCTCxZQUFZO0FBQUEsSUFDWkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVEckcsWUFBVSxNQUFNO0FBQ2QsVUFBTTBHLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNbkcsSUFBSW9HLElBQUksd0JBQXdCO0FBQ3ZEN0Usa0JBQVU0RSxTQUFTRSxJQUFJO0FBQUEsTUFDekIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUosZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQzVELGFBQWEsQ0FBQztBQUVsQixRQUFNa0UsbUJBQW1CQSxDQUFDQyxRQUFRQyxpQkFBaUI7QUFDakRqQyxhQUFTLFNBQVMsRUFBRWtDLE9BQU8sRUFBRUYsUUFBUUMsYUFBYSxFQUFFLENBQUM7QUFBQSxFQUN2RDtBQUVBLFFBQU1FLGdCQUFnQm5ILFFBQVEsTUFBTTtBQUNsQyxRQUFJLENBQUNpRCxTQUFTQSxNQUFNbUUsV0FBVyxFQUFHLFFBQU8sRUFBRS9ELFFBQVEsSUFBSWdFLE9BQU8sR0FBRztBQUVqRSxVQUFNaEUsVUFBUyxvQkFBSWlFLElBQUk7QUFDdkIsVUFBTUQsUUFBUSxvQkFBSUMsSUFBSTtBQUV0QnJFLFVBQU1zRSxRQUFRLENBQUFDLFNBQVE7QUFDcEIsVUFBSUEsS0FBS3RCLFlBQVl1QixLQUFNcEUsU0FBT3FFLElBQUlGLEtBQUt0QixXQUFXdUIsSUFBSTtBQUMxRCxVQUFJRCxLQUFLekIsVUFBV3NCLE9BQU1LLElBQUlGLEtBQUt6QixTQUFTO0FBQUEsSUFDOUMsQ0FBQztBQUVELFdBQU87QUFBQSxNQUNMMUMsUUFBUXNFLE1BQU1DLEtBQUt2RSxPQUFNLEVBQUV3RSxLQUFLO0FBQUEsTUFDaENSLE9BQU9NLE1BQU1DLEtBQUtQLEtBQUssRUFBRVEsS0FBSztBQUFBLElBQ2hDO0FBQUEsRUFDRixHQUFHLENBQUM1RSxLQUFLLENBQUM7QUFFVixRQUFNNkUsZ0JBQWdCOUgsUUFBUSxNQUFNO0FBQ2xDLFFBQUk0RyxPQUFPM0Q7QUFHWCxRQUFJcUIsZ0JBQWdCLE9BQU87QUFDekJzQyxhQUFPQSxLQUFLbUIsT0FBTyxDQUFBQyxTQUFRQSxLQUFLOUIsWUFBWXVCLFNBQVNuRCxXQUFXO0FBQUEsSUFDbEU7QUFHQSxRQUFJSSxlQUFlLE9BQU87QUFDeEJrQyxhQUFPQSxLQUFLbUIsT0FBTyxDQUFBQyxTQUFRQSxLQUFLakMsY0FBY3JCLFVBQVU7QUFBQSxJQUMxRDtBQUdBLFFBQUlGLG1CQUFtQkEsZ0JBQWdCNEMsV0FBVyxHQUFHO0FBQ25ELFlBQU0sQ0FBQ2EsT0FBT0MsR0FBRyxJQUFJMUQ7QUFDckJvQyxhQUFPQSxLQUFLbUIsT0FBTyxDQUFBQyxTQUFRO0FBQ3pCLFlBQUksQ0FBQ0EsS0FBS0csVUFBVyxRQUFPO0FBQzVCLGNBQU1DLFdBQVcsSUFBSUMsS0FBS0wsS0FBS0csU0FBUztBQUN4QyxlQUFPQyxZQUFZSCxNQUFNSyxPQUFPLEtBQUtGLFlBQVlGLElBQUlJLE9BQU87QUFBQSxNQUM5RCxDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU8xQjtBQUFBQSxFQUNULEdBQUcsQ0FBQzNELE9BQU9xQixhQUFhRSxpQkFBaUJFLFVBQVUsQ0FBQztBQUdwRCxRQUFNNkQsb0JBQW9CdkksUUFBUSxNQUFNO0FBQ3RDLFFBQUk0RyxPQUFPN0U7QUFHWCxRQUFJdUMsZ0JBQWdCLE9BQU87QUFDekJzQyxhQUFPQSxLQUFLbUIsT0FBTyxDQUFBQyxTQUFRQSxLQUFLUSxtQkFBbUJsRSxXQUFXO0FBQUEsSUFDaEU7QUFHQSxRQUFJSSxlQUFlLE9BQU87QUFDeEJrQyxhQUFPQSxLQUFLbUIsT0FBTyxDQUFBQyxTQUFRQSxLQUFLakMsY0FBY3JCLFVBQVU7QUFBQSxJQUMxRDtBQUdBLFFBQUlGLG1CQUFtQkEsZ0JBQWdCNEMsV0FBVyxHQUFHO0FBQ25ELFlBQU0sQ0FBQ2EsT0FBT0MsR0FBRyxJQUFJMUQ7QUFDckJvQyxhQUFPQSxLQUFLbUIsT0FBTyxDQUFBQyxTQUFRO0FBQ3pCLFlBQUksQ0FBQ0EsS0FBS1MsS0FBTSxRQUFPO0FBQ3ZCLGNBQU1MLFdBQVcsSUFBSUMsS0FBS0wsS0FBS1MsSUFBSTtBQUNuQyxlQUFPTCxZQUFZSCxNQUFNSyxPQUFPLEtBQUtGLFlBQVlGLElBQUlJLE9BQU87QUFBQSxNQUM5RCxDQUFDO0FBQUEsSUFDSDtBQUdBLFFBQUl6RSxZQUFZO0FBQ2QrQyxhQUFPQSxLQUFLbUI7QUFBQUEsUUFBTyxDQUFBQyxTQUNqQlUsT0FBT0MsT0FBT1gsSUFBSSxFQUFFWTtBQUFBQSxVQUFLLENBQUE5RCxVQUN2QitELE9BQU8vRCxLQUFLLEVBQUVnRSxZQUFZLEVBQUVDLFNBQVNsRixXQUFXaUYsWUFBWSxDQUFDO0FBQUEsUUFDL0Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFdBQU9sQztBQUFBQSxFQUNULEdBQUcsQ0FBQzdFLGFBQWF1QyxhQUFhRSxpQkFBaUJFLFlBQVliLFVBQVUsQ0FBQztBQUV0RTlELFlBQVUsTUFBTTtBQUNkLFVBQU1pSixhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGcEYscUJBQWEsSUFBSTtBQUNqQixjQUFNOEMsV0FBVyxNQUFNbkcsSUFBSW9HLElBQUkseUJBQXlCO0FBQ3hEekQsaUJBQVN3RCxTQUFTRSxJQUFJO0FBQ3RCLGNBQU1xQyxnQkFBZ0J2QyxTQUFTRSxLQUFLc0MsSUFBSSxDQUFDQyxPQUFPQyxXQUFXO0FBQUEsVUFDekRDLEtBQUtGLE1BQU1FO0FBQUFBLFVBQ1hDLElBQUlGLFFBQVE7QUFBQSxVQUNaRyxXQUFXSixPQUFPSTtBQUFBQSxVQUNsQjlCLE1BQU0wQixPQUFPeEQ7QUFBQUEsVUFDYjZELE9BQU9MLE9BQU92RDtBQUFBQSxVQUNkNkQsWUFBWU4sT0FBT3REO0FBQUFBLFVBQ25CTSxZQUFZZ0QsT0FBT2hEO0FBQUFBLFVBQ25CTCxVQUFVcUQsT0FBT3JELFVBQVU0RCxjQUFjUCxPQUFPTyxjQUFjO0FBQUEsVUFDOURqQixNQUFNVSxPQUFPaEIsV0FBV3dCLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLFVBQ3pDNUQsV0FBV29ELE1BQU1wRDtBQUFBQSxVQUNqQkssTUFBTStDLE9BQU8vQztBQUFBQSxVQUNib0MsZ0JBQ0VXLE1BQU1wRCxjQUFjLGFBQ2hCb0QsT0FBT25ELGVBQWU0RCxZQUN0QlQsTUFBTXBELGNBQWMsV0FBV29ELE1BQU1wRCxjQUFjLGFBQ2pEb0QsT0FBT2pELFlBQVl1QixPQUNuQjtBQUFBLFVBQ1JvQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxDQUFDLE9BQU87QUFBQSxjQUNqQixNQUFNO0FBQUEsZ0JBQ0pDLE9BQU87QUFBQSxrQkFDTDtBQUFBLG9CQUNFQyxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUMsc0JBQXNCZCxNQUFNRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VVLEtBQUs7QUFBQSxvQkFDTEMsT0FDRSx1QkFBQyxXQUFRLE9BQU0sb0JBQ2I7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFDUEUsK0JBQStCZixNQUFNRSxHQUFHO0FBQUEsd0JBQ3pDO0FBQUE7QUFBQSxzQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFVSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFDUGpELGlCQUFpQm9DLE1BQU1FLEtBQUtGLE1BQU1YLGNBQWM7QUFBQSx3QkFDakQ7QUFBQTtBQUFBLHNCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRXVCLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNRyxpQkFBaUJoQixNQUFNRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQSxZQTFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBMkRBLEtBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkRBO0FBQUEsUUFFSixFQUFFO0FBQ0ZySCx1QkFBZWlILGFBQWE7QUFBQSxNQUM5QixTQUFTcEMsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRCxVQUFDO0FBQ0NqRCxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0FvRixlQUFXO0FBQUEsRUFDYixHQUFHLENBQUNuRyxhQUFhLENBQUM7QUFFbEI5QyxZQUFVLE1BQU07QUFDZCxVQUFNcUssYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNMUQsV0FBVyxNQUFNbkcsSUFBSW9HLElBQUksZ0JBQWdCO0FBQy9DdkQsaUJBQVNzRCxTQUFTRSxJQUFJO0FBQUEsTUFDeEIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFBQSxNQUNsRDtBQUFBLElBQ0Y7QUFDQXVELGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQ3ZILGFBQWEsQ0FBQztBQWFsQjlDLFlBQVUsTUFBTTtBQUNkLFVBQU1zSyxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGLGNBQU0zRCxXQUFXLE1BQU1uRyxJQUFJb0csSUFBSSxZQUFZO0FBQzNDckQsa0JBQVVvRCxVQUFVRSxNQUFNMEQsS0FBSztBQUFBLE1BQ2pDLFNBQVN6RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBd0QsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDeEgsYUFBYSxDQUFDO0FBRWxCOUMsWUFBVSxNQUFNO0FBQ2QsVUFBTXdLLGdCQUFnQixZQUFZO0FBQ2hDLFVBQUk7QUFDRixjQUFNN0QsV0FBVyxNQUFNbkcsSUFBSW9HLElBQUksV0FBVztBQUMxQ25ELHFCQUFha0QsVUFBVUUsTUFBTTRELFFBQVE7QUFBQSxNQUN2QyxTQUFTM0QsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFBQSxNQUN0RDtBQUFBLElBQ0Y7QUFDQTBELGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxDQUFDMUgsYUFBYSxDQUFDO0FBRWxCLFFBQU00SCxtQkFBbUJBLENBQUNDLE9BQU81RixVQUFVO0FBQ3pDWSxnQkFBWSxDQUFDaUYsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsS0FBSyxHQUFHNUY7QUFBQUEsSUFDWCxFQUFFO0FBRUZwQixjQUFVLENBQUNrSCxnQkFBZ0I7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNGLEtBQUssR0FBRztBQUFBLElBQ1gsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNUCxtQkFBbUIsT0FBT25ELFdBQVc7QUFDekMsUUFBSTtBQUNGLFlBQU16RyxJQUFJc0ssSUFBSSwwQkFBMEI3RCxNQUFNLEVBQUU7QUFDaERsRSx1QkFBaUIsQ0FBQ2dJLFNBQVNBLE9BQU8sQ0FBQztBQUNuQzVGLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxTQUFTd0IsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUNoRDNCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEYsd0JBQXdCQSxDQUFDTCxPQUFPNUYsVUFBVTtBQUM5Q3dCLHNCQUFrQixDQUFDcUUsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsS0FBSyxHQUFHNUY7QUFBQUEsSUFDWCxFQUFFO0FBRUZwQixjQUFVLENBQUNrSCxnQkFBZ0IsRUFBRSxHQUFHQSxZQUFZLENBQUNGLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUM1RDtBQUVBLFFBQU1NLGVBQWVBLENBQUNuRyxNQUFNO0FBQzFCLFVBQU0sRUFBRTRDLE1BQU0zQyxNQUFNLElBQUlELEVBQUVFO0FBQzFCVyxnQkFBWSxDQUFDaUYsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2xELElBQUksR0FBRzNDO0FBQUFBLElBQ1YsRUFBRTtBQUNGcEIsY0FBVSxDQUFDa0gsZ0JBQWdCLEVBQUUsR0FBR0EsWUFBWSxDQUFDbkQsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQzNEO0FBRUEsUUFBTXdELGVBQWVBLENBQUM1RixTQUFTO0FBQzdCLFVBQU02RixZQUFZLENBQUM7QUFDbkIsVUFBTXRFLE9BQU92QixTQUFTLFlBQVlJLFdBQVdZO0FBRTdDLFFBQUksQ0FBQ08sS0FBS2pCLFdBQVd3RixTQUFTLEVBQUVDLEtBQUssR0FBRztBQUN0Q0YsZ0JBQVV2RixZQUFZO0FBQUEsSUFDeEI7QUFFQSxRQUFJLENBQUNpQixLQUFLaEIsWUFBWTtBQUNwQnNGLGdCQUFVdEYsYUFBYTtBQUFBLElBQ3pCLFdBQVcsQ0FBQyxlQUFleUYsS0FBS3pFLEtBQUtoQixVQUFVLEdBQUc7QUFDaERzRixnQkFBVXRGLGFBQWE7QUFBQSxJQUN6QjtBQUVBLFFBQUksQ0FBQ2dCLEtBQUtmLGlCQUFpQjtBQUN6QnFGLGdCQUFVckYsa0JBQWtCO0FBQUEsSUFDOUI7QUFFQSxRQUFJLENBQUNlLEtBQUtiLFdBQVc7QUFDbkJtRixnQkFBVW5GLFlBQVk7QUFBQSxJQUN4QjtBQUVBLFFBQUlhLEtBQUtiLGNBQWMsY0FBYyxDQUFDYSxLQUFLWixlQUFlO0FBQ3hEa0YsZ0JBQVVsRixnQkFBZ0I7QUFBQSxJQUM1QjtBQUVBLFFBQUlZLEtBQUtiLGNBQWMsV0FBVyxDQUFDYSxLQUFLVixZQUFZO0FBQ2xEZ0YsZ0JBQVVoRixhQUFhO0FBQUEsSUFDekI7QUFFQSxRQUFJVSxLQUFLYixjQUFjLGNBQWMsQ0FBQ2EsS0FBS1gsZUFBZTtBQUN4RGlGLGdCQUFVakYsZ0JBQWdCO0FBQUEsSUFDNUI7QUFFQSxRQUFJLENBQUNXLEtBQUtULFlBQVlnRixTQUFTLEdBQUc7QUFDaENELGdCQUFVL0UsYUFBYTtBQUFBLElBQ3pCO0FBRUF6QyxjQUFVd0gsU0FBUztBQUNuQixXQUFPeEMsT0FBTzRDLEtBQUtKLFNBQVMsRUFBRTlELFdBQVc7QUFBQSxFQUMzQztBQTRDQSxRQUFNbUUsZUFBZSxPQUFPMUcsTUFBTTtBQUNoQ0EsTUFBRTJHLGVBQWU7QUFFakIsVUFBTUMsVUFBVVIsYUFBYSxTQUFTO0FBQ3RDLFFBQUksQ0FBQ1EsUUFBUztBQUVkLFFBQUk7QUFDRixZQUFNL0UsV0FBVyxNQUFNbkcsSUFBSW1MLEtBQUssa0JBQWtCakcsUUFBUTtBQUMxRHJELG1CQUFhLEtBQUs7QUFDbEJVLHVCQUFpQixDQUFDZ0ksU0FBU0EsT0FBTyxDQUFDO0FBQ25DNUYscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDREssa0JBQVk7QUFBQSxRQUNWQyxXQUFXO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLGlCQUFpQjtBQUFBLFFBQ2pCQyxVQUFVO0FBQUEsUUFDVkMsV0FBVztBQUFBLFFBQ1hDLGVBQWU7QUFBQSxRQUNmRSxZQUFZO0FBQUEsUUFDWkQsZUFBZTtBQUFBLFFBQ2ZFLFlBQVk7QUFBQSxRQUNaQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxTQUFTUyxPQUFPO0FBQ2RDLGNBQVE2RSxJQUFJLFVBQVU5RSxNQUFNSCxVQUFVRSxJQUFJO0FBQzFDMUIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBU3lCLE1BQU1ILFVBQVVFLE1BQU14QixXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU11RyxpQkFBaUIvSixPQUFPa0c7QUFBQUEsSUFBTyxDQUFDb0IsVUFDcENBLE1BQU1PLFdBQVdaLFlBQVksRUFBRUMsU0FBUzlHLFdBQVc2RyxZQUFZLENBQUM7QUFBQSxFQUNsRTtBQUVBLFFBQU0rQyx3QkFBd0IsT0FBT3JHLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1rQixXQUFXLE1BQU1uRyxJQUFJb0csSUFBSSw2QkFBNkJuQixPQUFPLEVBQUU7QUFDckU5QyxzQkFBZ0JnRSxTQUFTRSxJQUFJO0FBQzdCdEUseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTdUUsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUVBLFFBQU1vRCx3QkFBd0IsT0FBT3pFLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1rQixXQUFXLE1BQU1uRyxJQUFJb0csSUFBSSw2QkFBNkJuQixPQUFPLEVBQUU7QUFDckUsWUFBTW9CLE9BQU9GLFNBQVNFO0FBRXRCaEUsNEJBQXNCZ0UsSUFBSTtBQUUxQixVQUFJa0YsVUFBVTtBQUNkLFVBQUlDLGFBQWE7QUFFakIsVUFBSW5GLE1BQU1iLGNBQWMsV0FBV2EsTUFBTVYsWUFBWTtBQUVuRDRGLGtCQUFVakQsT0FBT2pDLEtBQUtWLFdBQVdtRCxPQUFPekMsS0FBS1YsVUFBVTtBQUFBLE1BQ3pELFdBQVdVLE1BQU1iLGNBQWMsY0FBY2EsTUFBTVYsWUFBWTtBQUM3RDZGLHFCQUFhbEQsT0FBT2pDLEtBQUtWLFdBQVdtRCxPQUFPekMsS0FBS1YsVUFBVTtBQUFBLE1BQzVEO0FBRUFJLHdCQUFrQjtBQUFBLFFBQ2hCWCxXQUFXaUIsTUFBTWpCLGFBQWE7QUFBQSxRQUM5QkMsWUFBWWdCLE1BQU1oQixjQUFjO0FBQUEsUUFDaENDLGlCQUFpQmUsTUFBTWYsbUJBQW1CO0FBQUEsUUFDMUNDLFVBQVVjLE1BQU1kLFVBQVV1RCxPQUFPekMsTUFBTWQsWUFBWTtBQUFBLFFBQ25EQyxXQUFXYSxNQUFNYixhQUFhO0FBQUEsUUFDOUJHLFlBQVk0RjtBQUFBQSxRQUNaN0YsZUFBZThGO0FBQUFBLFFBQ2YvRixlQUFlWSxNQUFNWixlQUFlcUQsT0FBT3pDLE1BQU1aLGlCQUFpQjtBQUFBLFFBQ2xFRyxZQUFZUyxNQUFNVCxjQUFjO0FBQUEsUUFDaENDLE1BQU1RLE1BQU1SLFFBQVE7QUFBQSxNQUN0QixDQUFDO0FBRUQ1RCx5QkFBbUIsSUFBSTtBQUN2QmtCLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU21ELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFDM0MzQixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBc0RBLFFBQU0yRyxvQkFBb0JBLENBQUNuSCxNQUFNO0FBQy9CLFVBQU0sRUFBRTRDLE1BQU0zQyxNQUFNLElBQUlELEVBQUVFO0FBQzFCdUIsc0JBQWtCLENBQUNxRSxjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDbEQsSUFBSSxHQUFHM0M7QUFBQUEsSUFDVixFQUFFO0FBQ0ZwQixjQUFVLENBQUNrSCxnQkFBZ0IsRUFBRSxHQUFHQSxZQUFZLENBQUNuRCxJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDM0Q7QUFFQSxRQUFNd0Usb0JBQW9CLFlBQVk7QUFDcEMsUUFBSXhKLGNBQWM7QUFDaEIsVUFBSTtBQUNGLGNBQU1sQyxJQUFJMkwsT0FBTyxxQkFBcUJ6SixhQUFhNEcsR0FBRyxFQUFFO0FBQ3hEL0csMkJBQW1CLEtBQUs7QUFDeEJJLHdCQUFnQixJQUFJO0FBQ3BCSSx5QkFBaUIsQ0FBQ2dJLFNBQVNBLE9BQU8sQ0FBQztBQUNuQzVGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxTQUFTd0IsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXNGLFFBQVE7QUFBQSxJQUNaQyxPQUFPO0FBQUE7QUFBQSxJQUNQQyxTQUFTO0FBQUE7QUFBQSxJQUNUQyxRQUFRO0FBQUE7QUFBQSxFQUNWO0FBRUEsUUFBTUMsNEJBQTRCQSxDQUFDM0YsU0FBUztBQUMxQyxVQUFNc0UsWUFBWSxDQUFDO0FBRW5CLFFBQUksQ0FBQ3RFLEtBQUtnRCxXQUFXd0IsS0FBSyxHQUFHO0FBQzNCRixnQkFBVXRCLFlBQVk7QUFBQSxJQUN4QjtBQUVBLFFBQUksQ0FBQ2hELEtBQUs0RixnQkFBZ0IsQ0FBQyxlQUFlbkIsS0FBS3pFLEtBQUs0RixZQUFZLEdBQUc7QUFDakV0QixnQkFBVXNCLGVBQWU7QUFBQSxJQUMzQjtBQUVBLFFBQUksQ0FBQzVGLEtBQUs2RixVQUFVO0FBQ2xCdkIsZ0JBQVV1QixXQUFXO0FBQUEsSUFDdkI7QUFFQSxRQUFJLENBQUM3RixLQUFLeUYsV0FBVyxDQUFDRixNQUFNRSxRQUFRaEIsS0FBS3pFLEtBQUt5RixPQUFPLEdBQUc7QUFDdERuQixnQkFBVW1CLFVBQVU7QUFBQSxJQUN0QjtBQUVBLFFBQUksQ0FBQ3pGLEtBQUs4RixhQUFhLENBQUNQLE1BQU1HLE9BQU9qQixLQUFLekUsS0FBSzhGLFNBQVMsR0FBRztBQUN6RHhCLGdCQUFVd0IsWUFBWTtBQUFBLElBQ3hCO0FBRUEsUUFBSTlGLEtBQUsrRixVQUFVL0YsS0FBSytGLE9BQU92QixLQUFLLEVBQUVoRSxXQUFXLElBQUk7QUFDbkQ4RCxnQkFBVXlCLFNBQVM7QUFBQSxJQUNyQjtBQUVBLFFBQUksQ0FBQy9GLEtBQUtnRyxXQUFXaEcsS0FBS2dHLFFBQVF4QixLQUFLLEVBQUVoRSxTQUFTLEdBQUc7QUFDbkQ4RCxnQkFBVTBCLFVBQVU7QUFBQSxJQUN0QjtBQUVBLFFBQUksQ0FBQ2hHLEtBQUtpRyxlQUFlO0FBQ3ZCM0IsZ0JBQVUyQixnQkFBZ0I7QUFBQSxJQUM1QjtBQUVBLFFBQUksQ0FBQ2pHLEtBQUtrRyxjQUFjO0FBQ3RCNUIsZ0JBQVU0QixlQUFlO0FBQUEsSUFDM0I7QUFFQXBKLGNBQVV3SCxTQUFTO0FBQ25CLFdBQU94QyxPQUFPNEMsS0FBS0osU0FBUyxFQUFFOUQsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTTJGLGVBQWUsT0FBT2xJLE1BQU07QUFDaENBLE1BQUUyRyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVVSLGFBQWEsWUFBWTtBQUN6QyxRQUFJO0FBQ0YsVUFBSVEsU0FBUztBQUVYLGNBQU11QixhQUFhO0FBQUEsVUFDakIsR0FBRzNHO0FBQUFBO0FBQUFBLFVBRUhILFlBQ0VHLGVBQWVOLGNBQWMsVUFDekJNLGVBQWVILGFBQ2Y7QUFBQSxVQUNORCxlQUNFSSxlQUFlTixjQUFjLGFBQ3pCTSxlQUFlSixnQkFDZjtBQUFBLFVBQ05ELGVBQ0VLLGVBQWVOLGNBQWMsYUFDekJNLGVBQWVMLGdCQUNmO0FBQUEsUUFDUjtBQUVBLGNBQU16RixJQUFJc0s7QUFBQUEsVUFDUixxQkFBcUJsSSxtQkFBbUIwRyxHQUFHO0FBQUEsVUFDM0MyRDtBQUFBQSxRQUNGO0FBQ0F4SywyQkFBbUIsS0FBSztBQUN4QjBDLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQ0R2Qyx5QkFBaUIsQ0FBQ2dJLFNBQVNBLE9BQU8sQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRixTQUFTakUsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUMzQzNCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVN5QixNQUFNSCxVQUFVRSxNQUFNeEIsV0FBVztBQUFBLFFBQzFDQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUF5QkEsUUFBTTRILFVBQVU7QUFBQSxJQUNkLEVBQUVsRCxLQUFLLE1BQU1tRCxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFbkQsS0FBSyxhQUFhbUQsUUFBUSxVQUFVO0FBQUE7QUFBQSxJQUN0QyxFQUFFbkQsS0FBSyxRQUFRbUQsUUFBUSxZQUFZO0FBQUEsSUFDbkMsRUFBRW5ELEtBQUssU0FBU21ELFFBQVEsb0JBQW9CO0FBQUEsSUFDNUMsRUFBRW5ELEtBQUssY0FBY21ELFFBQVEsa0JBQWtCO0FBQUEsSUFDL0MsRUFBRW5ELEtBQUssUUFBUW1ELFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVuRCxLQUFLLFlBQVltRCxRQUFRLGFBQWE7QUFBQSxJQUN4QyxFQUFFbkQsS0FBSyxhQUFhbUQsUUFBUSxtQkFBbUI7QUFBQSxJQUMvQyxFQUFFbkQsS0FBSyxjQUFjbUQsUUFBUSx1QkFBdUI7QUFBQSxJQUNwRCxFQUFFbkQsS0FBSyxrQkFBa0JtRCxRQUFRLG1CQUFtQjtBQUFBLElBQ3BELEVBQUVuRCxLQUFLLFFBQVFtRCxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFbkQsS0FBSyxVQUFVbUQsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyw4QkFBOEIsT0FBT3RJLE1BQU07QUFDL0NBLE1BQUUyRyxlQUFlO0FBRWpCLFVBQU00QixRQUFRYiwwQkFBMEI5RyxRQUFRO0FBQ2hELFFBQUksQ0FBQzJILE1BQU87QUFDWixRQUFJO0FBQ0YsVUFBSUEsT0FBTztBQUNULGNBQU0xRyxXQUFXLE1BQU1uRyxJQUFJbUw7QUFBQUEsVUFDekI7QUFBQSxVQUNBakc7QUFBQUEsUUFDRjtBQUVBUCx1QkFBZTtBQUFBLFVBQ2JHLE1BQU07QUFBQSxVQUNORCxTQUFTc0IsU0FBU0UsS0FBS3hCLFdBQVc7QUFBQSxVQUNsQ0QsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUNEbEIseUJBQWlCLEtBQUs7QUFDdEJuQix5QkFBaUIsQ0FBQ2dJLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3BILGtCQUFVLENBQUMsQ0FBQztBQUFBLE1BQ2Q7QUFBQSxJQUNGLFNBQVNtRCxPQUFPO0FBQ2QsWUFBTXdHLFNBQVN4RyxPQUFPSCxVQUFVRSxNQUFNeEI7QUFFdEMsVUFBSWlJLFFBQVF2RSxZQUFZLEVBQUVDLFNBQVMsY0FBYyxHQUFHO0FBQ2xEckYsa0JBQVUsQ0FBQ29ILFVBQVU7QUFBQSxVQUNuQixHQUFHQTtBQUFBQSxVQUNIMEIsY0FBYztBQUFBLFFBQ2hCLEVBQUU7QUFBQSxNQUNKO0FBQ0EsVUFBSWEsUUFBUXZFLFlBQVksRUFBRUMsU0FBUyx1QkFBdUIsR0FBRztBQUMzRHJGLGtCQUFVLENBQUNvSCxVQUFVLEVBQUUsR0FBR0EsTUFBTWhGLFVBQVV1SCxPQUFPLEVBQUU7QUFBQSxNQUNyRDtBQUNBLFVBQUlBLFFBQVF2RSxZQUFZLEVBQUVDLFNBQVMsc0JBQXNCLEdBQUc7QUFDMURyRixrQkFBVSxDQUFDb0gsVUFBVSxFQUFFLEdBQUdBLE1BQU1SLE9BQU8rQyxPQUFPLEVBQUU7QUFBQSxNQUNsRDtBQUNBbkkscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FBU2lJLFVBQVU7QUFBQSxRQUNuQmxJLFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0rRSxpQ0FBaUMsT0FBT2xELFdBQVc7QUFDdkQsUUFBSTtBQUNGLFlBQU0sRUFBRUosS0FBSyxJQUFJLE1BQU1yRyxJQUFJb0c7QUFBQUEsUUFDekIsb0NBQW9DSyxNQUFNO0FBQUEsTUFDNUM7QUFFQXRCLGtCQUFZO0FBQUEsUUFDVmtFLFdBQVdoRCxNQUFNakIsYUFBYTtBQUFBLFFBQzlCNkcsY0FBYzVGLE1BQU1oQixjQUFjO0FBQUEsUUFDbENDLGlCQUFpQmUsTUFBTWYsbUJBQW1CO0FBQUE7QUFBQSxRQUMxQ0MsVUFBVWMsTUFBTWQsVUFBVXVELE9BQU87QUFBQTtBQUFBLFFBQ2pDdEQsV0FBV2EsTUFBTWIsYUFBYTtBQUFBO0FBQUEsUUFDOUJHLFlBQVlVLE1BQU1WLFlBQVltRCxPQUFPO0FBQUEsUUFDckMrQyxPQUFPO0FBQUEsUUFDUEssVUFBVTtBQUFBLFFBQ1Z6RyxlQUFlWSxNQUFNWixlQUFlcUQsT0FBTztBQUFBLFFBQzNDZ0QsU0FBU3pGLE1BQU15RixXQUFXO0FBQUEsUUFDMUJPLFNBQVNoRyxNQUFNMEcsZ0JBQWdCO0FBQUEsUUFDL0JaLFdBQVc7QUFBQSxRQUNYQyxRQUFRO0FBQUEsUUFDUnhHLFlBQVlTLE1BQU1ULGNBQWM7QUFBQSxRQUNoQ0MsTUFBTVEsTUFBTVIsUUFBUTtBQUFBLFFBQ3BCbUgsZUFBZTNHLE1BQU1iLGFBQWE7QUFBQSxRQUNsQytHLGNBQWNsRyxNQUFNa0csZ0JBQWdCO0FBQUEsUUFDcENELGVBQWVqRyxNQUFNaUcsaUJBQWlCO0FBQUEsTUFDeEMsQ0FBQztBQUVENUksdUJBQWlCLElBQUk7QUFBQSxJQUN2QixTQUFTNEMsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRDNCLHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVM7QUFBQSxRQUNURCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNcUksa0JBQWtCeE4sUUFBUSxNQUFNO0FBQ3BDLFFBQUksQ0FBQ2lELFNBQVNBLE1BQU1tRSxXQUFXLEVBQUcsUUFBTztBQUV6QyxVQUFNcUcsU0FBUyxDQUFDO0FBRWhCeEssVUFBTXNFLFFBQVEsQ0FBQ0MsU0FBUztBQUN0QixZQUFNa0csWUFBWWxHLEtBQUt0QixZQUFZdUI7QUFDbkMsVUFBSWlHLFdBQVc7QUFDYkQsZUFBT0MsU0FBUyxLQUFLRCxPQUFPQyxTQUFTLEtBQUssS0FBSztBQUFBLE1BQ2pEO0FBQUEsSUFDRixDQUFDO0FBRUQsV0FBT2hGLE9BQU9pRixRQUFRRixNQUFNLEVBQ3pCdkUsSUFBSSxDQUFDLENBQUN6QixNQUFNbUcsS0FBSyxPQUFPLEVBQUVuRyxNQUFNbUcsTUFBTSxFQUFFLEVBQ3hDL0YsS0FBSyxDQUFDZ0csR0FBR0MsTUFBTUEsRUFBRUYsUUFBUUMsRUFBRUQsS0FBSztBQUFBLEVBQ3JDLEdBQUcsQ0FBQzNLLEtBQUssQ0FBQztBQUVWLFFBQU04SyxRQUFRL04sUUFBUSxNQUFNO0FBQzFCLFFBQUksQ0FBQzhILGlCQUFpQkEsY0FBY1YsV0FBVyxFQUFHLFFBQU87QUFFekQsVUFBTTRHLFFBQVEvSyxNQUFNbUU7QUFDcEIsVUFBTTZHLFlBQVksQ0FBQztBQUNuQixVQUFNQyxrQkFBa0IsQ0FBQztBQUN6QixVQUFNQyxhQUFhLENBQUM7QUFFcEJsTCxVQUFNc0UsUUFBUSxDQUFDQyxTQUFTO0FBQ3RCLFlBQU1uQyxPQUFPbUMsS0FBS3pCLGFBQWE7QUFDL0JrSSxnQkFBVTVJLElBQUksS0FBSzRJLFVBQVU1SSxJQUFJLEtBQUssS0FBSztBQUUzQyxZQUFNK0ksT0FBTzVHLEtBQUszQixtQkFBbUI7QUFDckNxSSxzQkFBZ0JFLElBQUksS0FBS0YsZ0JBQWdCRSxJQUFJLEtBQUssS0FBSztBQUV2RCxZQUFNakYsUUFBUTNCLEtBQUtrQyxjQUFjO0FBQ2pDeUUsaUJBQVdoRixLQUFLLEtBQUtnRixXQUFXaEYsS0FBSyxLQUFLLEtBQUs7QUFBQSxJQUNqRCxDQUFDO0FBRUQsVUFBTWtGLFlBQVkzRixPQUFPaUYsUUFBUVEsVUFBVSxFQUN4Q3RHLEtBQUssQ0FBQ2dHLEdBQUdDLE1BQU1BLEVBQUUsQ0FBQyxJQUFJRCxFQUFFLENBQUMsQ0FBQyxFQUMxQlMsTUFBTSxHQUFHLENBQUM7QUFFYixXQUFPLEVBQUVOLE9BQU9DLFdBQVdDLGlCQUFpQkcsVUFBVTtBQUFBLEVBQ3hELEdBQUcsQ0FBQ3BMLEtBQUssQ0FBQztBQUVWLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDQyxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1nQyxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQzRGLFVBQVUsRUFBRSxHQUFHQSxNQUFNM0YsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLE1BTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFFSCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFFUix1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMkJBQTBCLHFCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQzdDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYi9DLDZCQUFhLElBQUk7QUFDakJzQiwwQkFBVSxDQUFDLENBQUM7QUFBQSxjQUNkO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBbUc7QUFBQTtBQUFBLFlBTC9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUdDcUssU0FDQyx1QkFBQyxTQUFJLFdBQVUsUUFFYixpQ0FBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsOEZBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsMkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTREO0FBQUEsY0FDNUQsdUJBQUMsT0FBRSxXQUFVLG9DQUFvQ0EsZ0JBQU1DLFNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsaUJBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYixpQ0FBQyxXQUFRLFdBQVUsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVDdEYsT0FBT2lGLFFBQVFJLE1BQU1FLFNBQVMsRUFBRS9FO0FBQUFBLFlBQUksQ0FBQyxDQUFDN0QsTUFBTXVJLEtBQUssTUFDaEQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSxnREFDVnZJLGlCQUFPLFlBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0N1SSxtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUQ7QUFBQSx1QkFKekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw4Q0FDWnZJO0FBQUFBLDZCQUFTLFdBQVcsdUJBQUMsYUFBVSxXQUFVLG1CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQztBQUFBLG9CQUN4REEsU0FBUyxjQUFjLHVCQUFDLFVBQU8sV0FBVSxvQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0M7QUFBQSxvQkFDekRBLFNBQVMsa0JBQWtCLHVCQUFDLFdBQVEsV0FBVSxxQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0M7QUFBQSxvQkFDL0RBLFNBQVMsY0FBYyx1QkFBQyxVQUFPLFdBQVUscUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1DO0FBQUEsb0JBQzFELENBQUMsQ0FBQyxTQUFTLFlBQVksZ0JBQWdCLFVBQVUsRUFBRTBELFNBQVMxRCxJQUFJLEtBQUssdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFRO0FBQUEsdUJBTGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxxQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUE7QUFBQSxjQWpCS0E7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbUJBO0FBQUEsVUFDRDtBQUFBLGFBbENIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0EsS0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNDQTtBQUFBLFFBR0RtSSxnQkFBZ0JwRyxTQUFTLEtBQ3hCLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDRDQUEyQyw4QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQSxVQUN2RSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1pvRywwQkFBZ0J0RTtBQUFBQSxZQUFJLENBQUMsRUFBRXpCLE1BQU1tRyxNQUFNLE1BQ2xDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLFNBQUksV0FBVSxxQ0FDYixpQ0FBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLDhEQUE2RCxPQUFPbkcsTUFDOUVBLGtCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsbUNBQW1DbUcsbUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNEO0FBQUEscUJBSnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUE7QUFBQSxjQWJLbkc7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZUE7QUFBQSxVQUNELEtBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFFBS0YsdUJBQUMsU0FBSSxXQUFVLGlFQUNiLGlDQUFDLFNBQUksV0FBVSxrRUFFYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLFlBQ3JFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixPQUFPbkQ7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDUSxVQUFVUCxlQUFlTyxLQUFLO0FBQUEsZ0JBQ3pDLFNBQVM7QUFBQSxrQkFDUCxFQUFFQSxPQUFPLE9BQU9rRixPQUFPLGFBQWE7QUFBQSxrQkFDcEMsR0FBRzdDLGNBQWM5RCxPQUFPNkYsSUFBSSxDQUFBb0IsV0FBVSxFQUFFeEYsT0FBT3dGLE9BQU9OLE9BQU9NLE1BQU0sRUFBRTtBQUFBLGdCQUFDO0FBQUEsZ0JBRXhFO0FBQUEsZ0JBQ0EsY0FBYyxDQUFDaUUsT0FBT0MsV0FDcEJBLE9BQU94RSxNQUFNbEIsWUFBWSxFQUFFQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBO0FBQUEsY0FYM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWUc7QUFBQSxlQWRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUMxRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPdEU7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDaUssVUFBVWhLLG1CQUFtQmdLLEtBQUs7QUFBQSxnQkFDN0MsYUFBYSxDQUFDLGNBQWMsVUFBVTtBQUFBO0FBQUEsY0FKeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTBDO0FBQUEsZUFONUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0Msb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLE9BQU8vSjtBQUFBQSxnQkFDUCxVQUFVLENBQUNJLFVBQVVILGNBQWNHLEtBQUs7QUFBQSxnQkFDeEMsU0FBUztBQUFBLGtCQUNQLEVBQUVBLE9BQU8sT0FBT2tGLE9BQU8sWUFBWTtBQUFBLGtCQUNuQyxHQUFHN0MsY0FBY0UsTUFBTTZCLElBQUksQ0FBQTdELFVBQVMsRUFBRVAsT0FBT08sTUFBTTJFLE9BQU8zRSxLQUFLLEVBQUU7QUFBQSxnQkFBQztBQUFBO0FBQUEsY0FQdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUk7QUFBQSxlQVZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwrSEFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSx1Q0FBc0MsMkJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBLHVCQUFDLFVBQUssV0FBVSw0RkFDYmtELDZCQUFtQm5CLFVBQVUsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3REEsS0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBEQTtBQUFBLFFBQ0NyRixZQUFZcUYsU0FBUyxLQUFLLENBQUN6RCxZQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsZUFBZXNHO0FBQUFBLFlBUWYsTUFBTTFCO0FBQUFBLFlBQ047QUFBQSxZQUNBLGlCQUFnQjtBQUFBLFlBQ2hCLGtCQUFrQjtBQUFBO0FBQUEsVUFacEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWWdDLElBR2hDLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZTtBQUFBLFFBRWpCLHVCQUFDLFNBQUksV0FBVSx5RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0RBO0FBQUEsV0F0TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVOQTtBQUFBLFNBMU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyTkE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXcEc7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsdUJBQWEsS0FBSztBQUNsQnNCLG9CQUFVLENBQUMsQ0FBQztBQUFBLFFBQ2Q7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsd0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsVUFDN0QsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVTZILGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFPO0FBQUE7QUFBQSxvQkFFTCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBTzlGLFNBQVNFO0FBQUFBLGtCQUNoQixVQUFVcUY7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDL0osVUFBVXlOLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNko7QUFBQSxjQUU1SmpMLE9BQU9rQyxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxDLGlCQUFPa0MsYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVJLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9GLFNBQVNHO0FBQUFBLG9CQUNoQixVQUFVb0Y7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDL0osVUFBVXlOLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKakwsT0FBT21DLGNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWbkMsaUJBQU9tQyxjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRU87QUFBQSxzQkFDckIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQzJJLE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUNKN0YsWUFBWSxFQUNaQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPckQsVUFBVUksbUJBQW1CK0k7QUFBQUEsb0JBQ3BDLFVBQVUsQ0FBQzlKLFVBQ1QyRixpQkFBaUIsbUJBQW1CM0YsS0FBSztBQUFBLG9CQUcxQyxXQUFDLFlBQVksZUFBZSxFQUFFb0U7QUFBQUEsc0JBQUksQ0FBQzJGLFVBQ2xDLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxNQUFNL0YsWUFBWSxHQUNqRCtGLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXFCQTtBQUFBLGdCQUNDcEwsT0FBT29DLG1CQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnBDLGlCQUFPb0MsbUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9DQTtBQUFBLGlCQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZEQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQWdCQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUMwSSxPQUFPQyxXQUNwQkEsT0FBT0csU0FBUzdGLFlBQVksRUFBRUMsU0FBU3dGLE1BQU16RixZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBT3JELFVBQVVLLFlBQVk4STtBQUFBQSxrQkFDN0IsVUFBVSxDQUFDOUosVUFBVTJGLGlCQUFpQixZQUFZM0YsS0FBSztBQUFBLGtCQUV0RGpELGlCQUFPcUg7QUFBQUEsb0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUUsS0FDekNGLGdCQUFNTyxjQURXUCxNQUFNRSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQSxpQkF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3Q0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsb0JBRUQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUNrRixPQUFPQyxXQUNwQkEsT0FBT0csU0FBUzdGLFlBQVksRUFBRUMsU0FBU3dGLE1BQU16RixZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBT3JELFVBQVVNLGFBQWE2STtBQUFBQSxrQkFDOUIsVUFBVSxDQUFDOUosVUFBVTJGLGlCQUFpQixhQUFhM0YsS0FBSztBQUFBLGtCQUV2RDtBQUFBLG9CQUNDO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxrQkFBUSxFQUNSb0U7QUFBQUEsb0JBQUksQ0FBQzRGLFVBQ0wsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE1BQU1oRyxZQUFZLEdBQ2pEZ0csbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F1QkE7QUFBQSxjQUNDckwsT0FBT3NDLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWdEMsaUJBQU9zQyxhQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQ0E7QUFBQSxZQUNDTixTQUFTTSxjQUFjLGNBQ3RCLG1DQUNFLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsZ0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQzlFLFVBQVV5TixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDSCxPQUFPQyxXQUNwQkEsT0FBT0csU0FDSnhELFNBQVMsRUFDVHJDLFlBQVksRUFDWkMsU0FBU3dGLE1BQU16RixZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBT3JELFVBQVVPLGlCQUFpQjRJO0FBQUFBLGtCQUNsQyxVQUFVLENBQUM5SixVQUNUMkYsaUJBQWlCLGlCQUFpQjNGLEtBQUs7QUFBQSxrQkFHeEMzQixnQkFBTStGO0FBQUFBLG9CQUFJLENBQUM2RixTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLMUYsS0FDdkMwRixlQUFLbkYsYUFEWW1GLEtBQUsxRixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FzQkE7QUFBQSxjQUNDNUYsT0FBT3VDLGlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnZDLGlCQUFPdUMsaUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9DQSxLQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNDQTtBQUFBLFlBR0RQLFNBQVNNLGNBQWMsV0FDdEIsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcscUNBQXFDOUUsVUFBVXlOLE1BQU07QUFBQSxrQkFDaEUsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUNILE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUNKeEQsU0FBUyxFQUNUckMsWUFBWSxFQUNaQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPckQsVUFBVVMsY0FBYzBJO0FBQUFBLGtCQUMvQixVQUFVLENBQUM5SixVQUNUMkYsaUJBQWlCLGNBQWMzRixLQUFLO0FBQUEsa0JBR3JDekIsaUJBQU82RjtBQUFBQSxvQkFBSSxDQUFDb0IsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTWpCLEtBQ3pDaUIsZ0JBQU03QyxRQURXNkMsTUFBTWpCLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXNCQTtBQUFBLGNBQ0M1RixPQUFPeUMsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z6QyxpQkFBT3lDLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9DQSxLQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNDQTtBQUFBLFlBR0RULFNBQVNNLGNBQWMsY0FDdEIsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcscUNBQXFDOUUsVUFBVXlOLE1BQU07QUFBQSxrQkFDaEUsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUNILE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUNKeEQsU0FBUyxFQUNUckMsWUFBWSxFQUNaQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPckQsVUFBVVEsaUJBQWlCMkk7QUFBQUEsa0JBQ2xDLFVBQVUsQ0FBQzlKLFVBQ1QyRixpQkFBaUIsaUJBQWlCM0YsS0FBSztBQUFBLGtCQUd4Q3ZCLG9CQUFVMkY7QUFBQUEsb0JBQUksQ0FBQzhGLFFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUkzRixLQUNyQzJGLGNBQUl2SCxRQURhdUgsSUFBSTNGLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXNCQTtBQUFBLGNBQ0M1RixPQUFPd0MsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWeEMsaUJBQU93QyxpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBakNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUNBO0FBQUEsWUFHRix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVHLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBYUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDc0ksT0FBT0MsV0FDcEJBLE9BQU9HLFNBQVM3RixZQUFZLEVBQUVDLFNBQVN3RixNQUFNekYsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU9yRCxVQUFVVSxjQUFjeUk7QUFBQUEsa0JBQy9CLFVBQVUsQ0FBQzlKLFVBQVUyRixpQkFBaUIsY0FBYzNGLEtBQUs7QUFBQSxrQkFFeEQsV0FBQyxXQUFXLFlBQVksRUFBRW9FO0FBQUFBLG9CQUFJLENBQUMrRixXQUM5Qix1QkFBQyxPQUFPLFFBQVAsRUFBMkIsT0FBT0EsT0FBT25HLFlBQVksR0FDbkRtRyxvQkFEaUJBLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCQTtBQUFBLGNBQ0N4TCxPQUFPMEMsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YxQyxpQkFBTzBDLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFNO0FBQUE7QUFBQSxnQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLE1BQU07QUFBQSxrQkFDTixNQUFLO0FBQUEsa0JBQ0wsT0FBT1YsU0FBU1c7QUFBQUEsa0JBQ2hCLFVBQVU0RTtBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVyxxQ0FBcUMvSixVQUFVeU4sTUFBTTtBQUFBO0FBQUEsZ0JBVGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVM2SjtBQUFBLGlCQWhCL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHVDQUFDLG9CQUFpQixPQUFNLFNBQVEsV0FBVSxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRDtBQUFBLGdCQUNyRCx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHdCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMzSztBQUFBQSxvQkFDVCxXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR3lGO0FBQUEsZ0JBRXpGLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUNBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlEO0FBQUEsbUJBTm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDNkc7QUFBQTtBQUFBLGNBSHpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBMVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMlhBO0FBQUEsYUE3WEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThYQTtBQUFBO0FBQUEsTUFyWUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBc1lBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3hCO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCa0Isb0JBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDZDtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QywyQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVXFKLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFPO0FBQUE7QUFBQSxvQkFFTCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBTzFHLGVBQWVWO0FBQUFBLGtCQUN0QixVQUFVcUc7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDL0ssVUFBVXlOLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNko7QUFBQSxjQUU1SmpMLE9BQU9rQyxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxDLGlCQUFPa0MsYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVJLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9VLGVBQWVUO0FBQUFBLG9CQUN0QixVQUFVb0c7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDL0ssVUFBVXlOLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKakwsT0FBT21DLGNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWbkMsaUJBQU9tQyxjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRU87QUFBQSxzQkFDckIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQzJJLE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUNKN0YsWUFBWSxFQUNaQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPekMsZ0JBQWdCUixtQkFBbUIrSTtBQUFBQSxvQkFDMUMsVUFBVSxDQUFDOUosVUFDVGlHLHNCQUFzQixtQkFBbUJqRyxLQUFLO0FBQUEsb0JBRy9DLFdBQUMsWUFBWSxlQUFlLEVBQUVvRTtBQUFBQSxzQkFBSSxDQUFDMkYsVUFDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE1BQU0vRixZQUFZLEdBQ2pEK0YsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBcUJBO0FBQUEsZ0JBQ0NwTCxPQUFPb0MsbUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWcEMsaUJBQU9vQyxtQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0NBO0FBQUEsaUJBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkRBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLGdCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBZ0JBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQzBJLE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUFTN0YsWUFBWSxFQUFFQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLGtCQUU1RCxPQUFPekMsZ0JBQWdCUCxZQUFZOEk7QUFBQUEsa0JBQ25DLFVBQVUsQ0FBQzlKLFVBQVVpRyxzQkFBc0IsWUFBWWpHLEtBQUs7QUFBQSxrQkFFM0RqRCxpQkFBT3FIO0FBQUFBLG9CQUFJLENBQUNDLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1FLEtBQ3pDRixnQkFBTU8sY0FEV1AsTUFBTUUsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUJBO0FBQUEsaUJBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUpwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBZUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDa0YsT0FBT0MsV0FDcEJBLE9BQU9HLFNBQVM3RixZQUFZLEVBQUVDLFNBQVN3RixNQUFNekYsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU96QyxnQkFBZ0JOLGFBQWE2STtBQUFBQSxrQkFDcEMsVUFBVSxDQUFDOUosVUFDVGlHLHNCQUFzQixhQUFhakcsS0FBSztBQUFBLGtCQUd6QztBQUFBLG9CQUNDO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxrQkFBUSxFQUNSb0U7QUFBQUEsb0JBQUksQ0FBQzdELFNBQ0wsdUJBQUMsT0FBTyxRQUFQLEVBQXlCLE9BQU9BLEtBQUt5RCxZQUFZLEdBQy9DekQsa0JBRGlCQSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F5QkE7QUFBQSxjQUNDNUIsT0FBT3NDLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWdEMsaUJBQU9zQyxhQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFsREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvREE7QUFBQSxZQUNDTSxlQUFlTixjQUFjLGNBQzVCLG1DQUNFLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsZ0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FnQkE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxxQ0FBcUM5RSxVQUFVeU4sTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0gsT0FBT0MsV0FDcEJBLE9BQU9HLFNBQ0p4RCxTQUFTLEVBQ1RyQyxZQUFZLEVBQ1pDLFNBQVN3RixNQUFNekYsWUFBWSxDQUFDO0FBQUEsa0JBRWpDLE9BQU96QyxnQkFBZ0JMLGlCQUFpQjRJO0FBQUFBLGtCQUN4QyxVQUFVLENBQUM5SixVQUNUaUcsc0JBQXNCLGlCQUFpQmpHLEtBQUs7QUFBQSxrQkFHN0MzQixnQkFBTStGO0FBQUFBLG9CQUFJLENBQUM2RixTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLMUYsS0FDdkMwRixlQUFLbkYsYUFEWW1GLEtBQUsxRixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FzQkE7QUFBQSxjQUNDNUYsT0FBT3VDLGlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnZDLGlCQUFPdUMsaUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtEQSxLQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBLFlBQ0M7QUFBQSxZQUNGSyxlQUFlTixjQUFjLFdBQzVCLG1DQUNFLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsZ0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUN3SSxPQUFPQyxXQUFXO0FBRS9CLDBCQUFNVSxhQUFhckcsT0FBTzJGLFFBQVFHLFlBQVksRUFBRTtBQUNoRCwyQkFBT08sV0FDSnBHLFlBQVksRUFDWkMsU0FBU0YsT0FBTzBGLEtBQUssRUFBRXpGLFlBQVksQ0FBQztBQUFBLGtCQUN6QztBQUFBLGtCQUNBLE9BQU96QyxnQkFBZ0JILGNBQWMwSTtBQUFBQSxrQkFDckMsVUFBVSxDQUFDOUosVUFDVGlHLHNCQUFzQixjQUFjakcsS0FBSztBQUFBLGtCQUcxQ3ZCLG9CQUFVMkY7QUFBQUEsb0JBQUksQ0FBQzhGLFFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUkzRixLQUNyQzJGLGVBQUt2SCxRQURZdUgsSUFBSTNGLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXVCQTtBQUFBLGNBQ0M1RixPQUFPeUMsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z6QyxpQkFBT3lDLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9DQSxLQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNDQTtBQUFBLFlBRURHLGVBQWVOLGNBQWMsY0FDNUIsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcscUNBQXFDOUUsVUFBVXlOLE1BQU07QUFBQSxrQkFDaEUsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUNILE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUNKeEQsU0FBUyxFQUNUckMsWUFBWSxFQUNaQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPekMsZ0JBQWdCSixpQkFBaUIySTtBQUFBQSxrQkFDeEMsVUFBVSxDQUFDOUosVUFDVGlHLHNCQUFzQixpQkFBaUJqRyxLQUFLO0FBQUEsa0JBRzdDdkIsb0JBQVUyRjtBQUFBQSxvQkFBSSxDQUFDOEYsUUFDZCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsSUFBSTNGLEtBQ3JDMkYsZUFBS3ZILFFBRFl1SCxJQUFJM0YsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBc0JBO0FBQUEsY0FDQzVGLE9BQU93QyxpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4QyxpQkFBT3dDLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQ0EsS0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQ0E7QUFBQSxZQUVGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsY0FGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPSSxlQUFlRDtBQUFBQSxnQkFDdEIsVUFBVTRGO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQy9LLFVBQVV5TixNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRNko7QUFBQSxZQUU3Six1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVHLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBYUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDSCxPQUFPQyxXQUNwQkEsT0FBT0csU0FBUzdGLFlBQVksRUFBRUMsU0FBU3dGLE1BQU16RixZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBT3pDLGdCQUFnQkYsY0FBY3lJO0FBQUFBLGtCQUNyQyxVQUFVLENBQUM5SixVQUNUaUcsc0JBQXNCLGNBQWNqRyxLQUFLO0FBQUEsa0JBRzFDLFdBQUMsV0FBVyxZQUFZLEVBQUVvRTtBQUFBQSxvQkFBSSxDQUFDN0QsU0FDOUIsdUJBQUMsT0FBTyxRQUFQLEVBQXlCLE9BQU9BLEtBQUt5RCxZQUFZLEdBQy9DekQsa0JBRGlCQSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxjQUNDNUIsT0FBTzBDLGNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWMUMsaUJBQU8wQyxjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0Q0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQzJGO0FBQUE7QUFBQSxjQUh2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQWpZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtZQTtBQUFBLGFBdllGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3WUE7QUFBQTtBQUFBLE1BL1lGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWdaQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVduQztBQUFBQSxRQUNYLFNBQVMsTUFBTUMsaUJBQWlCLEtBQUs7QUFBQSxRQUNyQyxVQUFVQztBQUFBQSxRQUNWO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLHdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsVUFBVWlKO0FBQUFBLGNBQ1YsWUFBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVKLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUE7QUFBQTtBQUFBLHNCQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU8xSCxTQUFTbUU7QUFBQUEsd0JBQ2hCLFVBQVVvQjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQSxXQUFXLHFDQUFxQy9KLFVBQVV5TixNQUFNO0FBQUE7QUFBQSxzQkFUbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVM2SjtBQUFBLG9CQUU1SmpMLE9BQU9tRyxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVm5HLGlCQUFPbUcsYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdUJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFSCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpQztBQUFBO0FBQUE7QUFBQSxzQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPbkUsU0FBUzJHO0FBQUFBLHdCQUNoQixVQUFVcEI7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcscUNBQXFDL0osVUFBVXlOLE1BQU07QUFBQTtBQUFBLHNCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUTZKO0FBQUEsdUJBZi9KO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFSSx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpQztBQUFBO0FBQUE7QUFBQSxzQkFKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPakosU0FBUytHO0FBQUFBLHdCQUNoQixVQUFVeEI7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBO0FBQUEsd0JBQ0EsV0FBVyxxQ0FBcUMvSixVQUFVeU4sTUFBTTtBQUFBO0FBQUEsc0JBVGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFTNko7QUFBQSxvQkFFNUpqTCxPQUFPK0ksZ0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWL0ksaUJBQU8rSSxnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdUJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFNO0FBQUE7QUFBQSwwQkFFTztBQUFBLDBCQUNyQix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpQztBQUFBO0FBQUE7QUFBQSxzQkFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1BO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWix1QkFBdUI7QUFBQSx3QkFDdkI7QUFBQSx3QkFDQSxNQUFLO0FBQUEsd0JBQ0wsY0FBYyxDQUFDK0IsT0FBT0MsV0FDcEJBLE9BQU9HLFNBQ0o3RixZQUFZLEVBQ1pDLFNBQVN3RixNQUFNekYsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQU9yRCxVQUFVSSxtQkFBbUIrSTtBQUFBQSx3QkFDcEMsVUFBVSxDQUFDOUosVUFDVDJGLGlCQUFpQixtQkFBbUIzRixLQUFLO0FBQUEsd0JBRzFDLFdBQUMsWUFBWSxlQUFlLEVBQUVvRTtBQUFBQSwwQkFBSSxDQUFDMkYsVUFDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE1BQU0vRixZQUFZLEdBQ2pEK0YsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBcUJBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBb0NBO0FBQUEscUJBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOERBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFVO0FBQUE7QUFBQSxvQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWix1QkFBdUI7QUFBQSxzQkFDdkI7QUFBQSxzQkFDQSxNQUFLO0FBQUEsc0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUNwQkEsT0FBT0csU0FBUzdGLFlBQVksRUFBRUMsU0FBU3dGLE1BQU16RixZQUFZLENBQUM7QUFBQSxzQkFFNUQsT0FBT3JELFVBQVVLLFlBQVk4STtBQUFBQSxzQkFDN0IsVUFBVSxDQUFDOUosVUFBVTJGLGlCQUFpQixZQUFZM0YsS0FBSztBQUFBLHNCQUV0RGpELGlCQUFPcUg7QUFBQUEsd0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUUsS0FDekNGLGdCQUFNTyxjQURXUCxNQUFNRSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBQ0Q7QUFBQTtBQUFBLG9CQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBaUJBO0FBQUEsa0JBQ0M1RixPQUFPcUMsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCckMsaUJBQU9xQyxZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRDtBQUFBLHFCQTNCOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE2QkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVU7QUFBQTtBQUFBLHdCQUVELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQUpwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLHVCQUF1QjtBQUFBLHNCQUN2QjtBQUFBLHNCQUNBLE1BQUs7QUFBQSxzQkFDTCxjQUFjLENBQUN5SSxPQUFPQyxXQUNwQkEsT0FBT0csU0FBUzdGLFlBQVksRUFBRUMsU0FBU3dGLE1BQU16RixZQUFZLENBQUM7QUFBQSxzQkFFNUQsT0FBT3JELFVBQVVNLGFBQWE2STtBQUFBQSxzQkFDOUIsVUFBVSxDQUFDOUosVUFBVTJGLGlCQUFpQixhQUFhM0YsS0FBSztBQUFBLHNCQUV2RDtBQUFBLHdCQUNDO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSxzQkFBUSxFQUNSb0U7QUFBQUEsd0JBQUksQ0FBQzdELFNBQ0wsdUJBQUMsT0FBTyxRQUFQLEVBQXlCLE9BQU9BLEtBQUt5RCxZQUFZLEdBQy9DekQsa0JBRGlCQSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBQ0Q7QUFBQTtBQUFBLG9CQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBdUJBO0FBQUEsa0JBQ0M1QixPQUFPc0MsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z0QyxpQkFBT3NDLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLGdCQUNDTixTQUFTTSxjQUFjLGNBQ3RCLG1DQUNFLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVTtBQUFBO0FBQUEsb0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcscUNBQXFDOUUsVUFBVXlOLE1BQU07QUFBQSxzQkFDaEUsYUFBWTtBQUFBLHNCQUNaLHVCQUF1QjtBQUFBLHNCQUN2QjtBQUFBLHNCQUNBLE1BQUs7QUFBQSxzQkFDTCxjQUFjLENBQUNILE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUNKeEQsU0FBUyxFQUNUckMsWUFBWSxFQUNaQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLHNCQUVqQyxPQUFPckQsVUFBVU8saUJBQWlCNEk7QUFBQUEsc0JBQ2xDLFVBQVUsQ0FBQzlKLFVBQ1QyRixpQkFBaUIsaUJBQWlCM0YsS0FBSztBQUFBLHNCQUd4QzNCLGdCQUFNK0Y7QUFBQUEsd0JBQUksQ0FBQzZGLFNBQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUsxRixLQUN2QzBGLGVBQUtuRixhQURZbUYsS0FBSzFGLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFzQkE7QUFBQSxxQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQ0EsS0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzQ0E7QUFBQSxnQkFDQztBQUFBLGdCQUNGNUQsU0FBU00sY0FBYyxXQUN0QixtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVU7QUFBQTtBQUFBLG9CQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLHVCQUF1QjtBQUFBLHNCQUN2QjtBQUFBLHNCQUNBLE1BQUs7QUFBQSxzQkFDTCxjQUFjLENBQUN3SSxPQUFPQyxXQUNwQkEsT0FBT0csU0FDSjdGLFlBQVksRUFDWkMsU0FBU3dGLE1BQU16RixZQUFZLENBQUM7QUFBQSxzQkFFakMsT0FBT3JELFVBQVVTLGNBQWMwSTtBQUFBQSxzQkFDL0IsVUFBVSxDQUFDOUosVUFDVDJGLGlCQUFpQixjQUFjM0YsS0FBSztBQUFBLHNCQUdyQ3pCLGlCQUFPNkY7QUFBQUEsd0JBQUksQ0FBQ29CLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1qQixLQUN6Q2lCLGdCQUFNN0MsUUFEVzZDLE1BQU1qQixLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBQ0Q7QUFBQTtBQUFBLG9CQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBcUJBO0FBQUEsa0JBQ0M1RixPQUFPeUMsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z6QyxpQkFBT3lDLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1DQSxLQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLGdCQUVGLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBTTtBQUFBO0FBQUEsMEJBRUwsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBaUM7QUFBQTtBQUFBO0FBQUEsc0JBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT1QsU0FBU2dIO0FBQUFBLHdCQUNoQixVQUFVekI7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcscUNBQXFDL0osVUFBVXlOLE1BQU07QUFBQTtBQUFBLHNCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUTZKO0FBQUEsb0JBRTVKakwsT0FBT2dKLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEosaUJBQU9nSixZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFzQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVOLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUE7QUFBQTtBQUFBLHNCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9oSCxTQUFTNEc7QUFBQUEsd0JBQ2hCLFVBQVVyQjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxxQ0FBcUMvSixVQUFVeU4sTUFBTTtBQUFBO0FBQUEsc0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRNko7QUFBQSxvQkFFNUpqTCxPQUFPNEksV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y1SSxpQkFBTzRJLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNCQTtBQUFBLHFCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQStDQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFPO0FBQUE7QUFBQSx3QkFFUCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpQztBQUFBO0FBQUE7QUFBQSxvQkFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPNUcsU0FBU21IO0FBQUFBLHNCQUNoQixVQUFVNUI7QUFBQUEsc0JBQ1YsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUJBQXFCL0osVUFBVXlOLE1BQU07QUFBQTtBQUFBLG9CQVJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUTZHO0FBQUEscUJBZi9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0JBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFjO0FBQUE7QUFBQSx3QkFFRix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpQztBQUFBO0FBQUE7QUFBQSxvQkFKdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxxQ0FBcUN6TixVQUFVeU4sTUFBTTtBQUFBLHNCQUNoRSxhQUFZO0FBQUEsc0JBQ1osdUJBQXVCO0FBQUEsc0JBQ3ZCO0FBQUEsc0JBQ0EsTUFBSztBQUFBLHNCQUNMLGNBQWMsQ0FBQ0gsT0FBT0MsV0FDcEJBLE9BQU9HLFNBQVM3RixZQUFZLEVBQUVDLFNBQVN3RixNQUFNekYsWUFBWSxDQUFDO0FBQUEsc0JBRTVELE9BQU9yRCxVQUFVcUgsZ0JBQWdCOEI7QUFBQUEsc0JBQ2pDLFVBQVUsQ0FBQzlKLFVBQVUyRixpQkFBaUIsZ0JBQWdCM0YsS0FBSztBQUFBLHNCQUUxRCxXQUFDLFNBQVMsVUFBVSxTQUFTLEVBQUVvRTtBQUFBQSx3QkFBSSxDQUFDaUcsVUFDbkMsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE9BQy9CQSxtQkFEaUJBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQkE7QUFBQSxrQkFDQzFMLE9BQU9xSixnQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZySixpQkFBT3FKLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4QkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFRO0FBQUEsd0JBQU07QUFBQTtBQUFBLDBCQUVBLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUE7QUFBQTtBQUFBLHNCQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9ySCxTQUFTaUg7QUFBQUEsd0JBQ2hCLFVBQVUxQjtBQUFBQSx3QkFDVixJQUFHO0FBQUEsd0JBQ0gsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVyxxQ0FBcUMvSixVQUFVeU4sTUFBTTtBQUFBO0FBQUEsc0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRNko7QUFBQSxvQkFFNUpqTCxPQUFPaUosYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqSixpQkFBT2lKLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBVTtBQUFBO0FBQUEsMEJBRVAsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBaUM7QUFBQTtBQUFBO0FBQUEsc0JBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT2pILFVBQVVrSDtBQUFBQSx3QkFDakIsVUFBVTNCO0FBQUFBLHdCQUNWLElBQUc7QUFBQSx3QkFDSCxhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFXLHFDQUFxQy9KLFVBQVV5TixNQUFNO0FBQUE7QUFBQSxzQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVE2SjtBQUFBLG9CQUU1SmpMLE9BQU9rSixVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJsSixpQkFBT2tKLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdEO0FBQUEsdUJBbEI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW9CQTtBQUFBLHFCQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThDQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBTTtBQUFBO0FBQUEsb0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT2xILFNBQVNXO0FBQUFBLHNCQUNoQixVQUFVNEU7QUFBQUEsc0JBQ1YsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDL0osVUFBVXlOLE1BQU07QUFBQTtBQUFBLG9CQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUTZKO0FBQUEscUJBZi9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFlO0FBQUE7QUFBQSwwQkFFTCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpQztBQUFBO0FBQUE7QUFBQSxzQkFKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPakosU0FBU29IO0FBQUFBLHdCQUNoQixVQUFVN0I7QUFBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVcscUNBQXFDL0osVUFBVXlOLE1BQU07QUFBQTtBQUFBLHNCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUTZKO0FBQUEsb0JBRTVKakwsT0FBT29KLGlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnBKLGlCQUFPb0osaUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVE7QUFBQSx3QkFBVTtBQUFBO0FBQUEsMEJBRUc7QUFBQSwwQkFDckIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBaUM7QUFBQTtBQUFBO0FBQUEsc0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osdUJBQXVCO0FBQUEsd0JBQ3ZCO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQzBCLE9BQU9DLFdBQ3BCQSxPQUFPRyxTQUNKN0YsWUFBWSxFQUNaQyxTQUFTd0YsTUFBTXpGLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPckQsVUFBVVUsY0FBY3lJO0FBQUFBLHdCQUMvQixVQUFVLENBQUM5SixVQUFVMkYsaUJBQWlCLGNBQWMzRixLQUFLO0FBQUEsd0JBRXhELFdBQUMsV0FBVyxZQUFZLEVBQUVvRTtBQUFBQSwwQkFBSSxDQUFDN0QsU0FDOUIsdUJBQUMsT0FBTyxRQUFQLEVBQXlCLE9BQU9BLEtBQUt5RCxZQUFZLEdBQy9DekQsa0JBRGlCQSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBbUJBO0FBQUEsb0JBQ0M1QixPQUFPMEMsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YxQyxpQkFBTzBDLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtDQTtBQUFBLHFCQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJEQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUMyRjtBQUFBO0FBQUEsa0JBSHZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQTtBQUFBO0FBQUEsWUE5ZUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBK2VBO0FBQUEsYUFuZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9mQTtBQUFBO0FBQUEsTUExZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMmZBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzlEO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSSwwQkFBZ0IsSUFBSTtBQUFBLFFBQ3RCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDJCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsZ0JBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ29DLE1BQU07QUFDZkEsa0JBQUUyRyxlQUFlO0FBQ2pCUyxrQ0FBa0I7QUFBQSxjQUNwQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2J4Six1QkFBYWtELGFBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFBUTtBQUFBLHdCQUFJO0FBQUEsd0JBQ1M7QUFBQSx3QkFDckIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQTtBQUFBO0FBQUEsb0JBVG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVyxxQ0FBcUMxRSxVQUFVeU4sTUFBTTtBQUFBO0FBQUEsb0JBTGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLNko7QUFBQSxxQkFqQi9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDdUY7QUFBQTtBQUFBLGtCQUhuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBO0FBQUEsYUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlDQTtBQUFBO0FBQUEsTUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBaURBO0FBQUEsT0E5aURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EraURBLEtBaGpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaWpEQSxLQWxqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1qREE7QUFFSjtBQUFFOU0sR0EvNUVJRCxNQUFJO0FBQUEsVUE4QlNGLFdBQVc7QUFBQTtBQUFBMk4sS0E5QnhCek47QUFpNkVOLGVBQWVBO0FBQUssSUFBQXlOO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiTWREZWxldGUiLCJDaUVkaXQiLCJNb2RhbCIsImF4aW9zIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJOYXZiYXIiLCJJb01kTW9yZSIsIklucHV0IiwiU2VsZWN0IiwiRHJvcGRvd24iLCJUb29sdGlwIiwiRGF0ZVBpY2tlciIsImZpZWxkU2l6ZSIsIkNpcmN1bGFyTG9hZGVyIiwiRmFCcmllZmNhc2UiLCJGYUJ1aWxkaW5nIiwiRmFVc2VyIiwiRmFVc2VycyIsIkZhVXNlclRpZSIsIkZhV2hhdHNhcHBTcXVhcmUiLCJ1c2VOYXZpZ2F0ZSIsIlJhbmdlUGlja2VyIiwiTGVhZCIsIl9zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiVGFibGVHcm91cHMiLCJzZXRUYWJsZUdyb3VwcyIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsImxlYWRzIiwic2V0TGVhZHMiLCJ1c2VycyIsInNldFVzZXJzIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ3aGF0c2FwcEVuYWJsZSIsImxlYWRTaG93TW9kYWwiLCJzZXRMZWFkU2hvd01vZGFsIiwic2VsZWN0ZWRMZWFkRGF0YSIsInNldFNlbGVjdGVkTGVhZERhdGEiLCJpc01vZGFsTG9hZGluZyIsInNldElzTW9kYWxMb2FkaW5nIiwiZmlsdGVyQWdlbnQiLCJzZXRGaWx0ZXJBZ2VudCIsImZpbHRlckRhdGVSYW5nZSIsInNldEZpbHRlckRhdGVSYW5nZSIsImZpbHRlclR5cGUiLCJzZXRGaWx0ZXJUeXBlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwibmF2aWdhdGUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiaGFuZGxlR3JvdXBDaGFuZ2UiLCJldmVudCIsImdyb3VwSWQiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwibGVhZF9uYW1lIiwibGVhZF9waG9uZSIsImxlYWRfcHJvZmVzc2lvbiIsImdyb3VwX2lkIiwibGVhZF90eXBlIiwibGVhZF9jdXN0b21lciIsImxlYWRfZW1wbG95ZWUiLCJsZWFkX2FnZW50IiwibGVhZF9uZWVkcyIsIm5vdGUiLCJ1cGRhdGVGb3JtRGF0YSIsInNldFVwZGF0ZUZvcm1EYXRhIiwibGVhZF9hZ2VudF9uYW1lIiwibGVhZF9lbXBsb3llZV9uYW1lIiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVBc3NpZ25UYXNrIiwibGVhZElkIiwibGVhZFR5cGVOYW1lIiwic3RhdGUiLCJmaWx0ZXJPcHRpb25zIiwibGVuZ3RoIiwidHlwZXMiLCJTZXQiLCJmb3JFYWNoIiwibGVhZCIsIm5hbWUiLCJhZGQiLCJBcnJheSIsImZyb20iLCJzb3J0IiwiZmlsdGVyZWRMZWFkcyIsImZpbHRlciIsIml0ZW0iLCJzdGFydCIsImVuZCIsImNyZWF0ZWRBdCIsIml0ZW1EYXRlIiwiRGF0ZSIsInRvRGF0ZSIsImZpbHRlcmVkVGFibGVEYXRhIiwibGVhZF90eXBlX25hbWUiLCJkYXRlIiwiT2JqZWN0IiwidmFsdWVzIiwic29tZSIsIlN0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJmZXRjaExlYWRzIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJpZCIsImxlYWRfY29kZSIsInBob25lIiwicHJvZmVzc2lvbiIsImdyb3VwX25hbWUiLCJzcGxpdCIsImZ1bGxfbmFtZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVPcGVuQ29udmVydEN1c3RvbWVyTW9kYWwiLCJoYW5kbGVTb2Z0UmVtb3ZlIiwiZmV0Y2hVc2VycyIsImZldGNoQWdlbnQiLCJhZ2VudCIsImZldGNoRW1wbG95ZWUiLCJlbXBsb3llZSIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInByZXZEYXRhIiwicHJldkVycm9ycyIsInB1dCIsInByZXYiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJoYW5kbGVDaGFuZ2UiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJ0b1N0cmluZyIsInRyaW0iLCJ0ZXN0Iiwia2V5cyIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBvc3QiLCJsb2ciLCJmaWx0ZXJlZEdyb3VwcyIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImFnZW50SWQiLCJlbXBsb3llZUlkIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVEZWxldGVHcm91cCIsImRlbGV0ZSIsInJlZ2V4IiwiZW1haWwiLCJwaW5jb2RlIiwiYWRoYWFyIiwidmFsaWRhdGVDb252ZXJ0VG9DdXN0b21lciIsInBob25lX251bWJlciIsInBhc3N3b3JkIiwiYWRoYWFyX25vIiwicGFuX25vIiwiYWRkcmVzcyIsIm5vX29mX3RpY2tldHMiLCJwYXltZW50X3R5cGUiLCJoYW5kbGVVcGRhdGUiLCJzdWJtaXREYXRhIiwiY29sdW1ucyIsImhlYWRlciIsImhhbmRsZUNvbnZlcnRDdXN0b21lclN1Ym1pdCIsInZhbGlkIiwiZXJyTXNnIiwibGVhZF9hZGRyZXNzIiwicmVmZXJyZWRfdHlwZSIsImFnZW50TGVhZENvdW50cyIsImNvdW50cyIsImFnZW50TmFtZSIsImVudHJpZXMiLCJjb3VudCIsImEiLCJiIiwic3RhdHMiLCJ0b3RhbCIsInR5cGVDb3VudCIsInByb2Zlc3Npb25Db3VudCIsImdyb3VwQ291bnQiLCJwcm9mIiwidG9wR3JvdXBzIiwic2xpY2UiLCJpbnB1dCIsIm9wdGlvbiIsImRhdGVzIiwiaGVpZ2h0IiwiY2hpbGRyZW4iLCJ1bmRlZmluZWQiLCJsUHJvZiIsImxUeXBlIiwidXNlciIsImVtcCIsImxOZWVkcyIsIm9wdGlvblRleHQiLCJwVHlwZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxlYWQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IE1kRGVsZXRlIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IENpRWRpdCB9IGZyb20gXCJyZWFjdC1pY29ucy9jaVwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biwgVG9vbHRpcCwgRGF0ZVBpY2tlciB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBGYUJyaWVmY2FzZSwgRmFCdWlsZGluZywgRmFVc2VyLCBGYVVzZXJzLCBGYVVzZXJUaWUsIEZhV2hhdHNhcHBTcXVhcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5jb25zdCB7IFJhbmdlUGlja2VyIH0gPSBEYXRlUGlja2VyO1xyXG5cclxuY29uc3QgTGVhZCA9ICgpID0+IHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUdyb3Vwcywgc2V0VGFibGVHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3JvdXAsIHNldEN1cnJlbnRHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2xlYWRzLCBzZXRMZWFkc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCB3aGF0c2FwcEVuYWJsZSA9IHRydWU7XHJcbiAgY29uc3QgW2xlYWRTaG93TW9kYWwsIHNldExlYWRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExlYWREYXRhLCBzZXRTZWxlY3RlZExlYWREYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc01vZGFsTG9hZGluZywgc2V0SXNNb2RhbExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtmaWx0ZXJBZ2VudCwgc2V0RmlsdGVyQWdlbnRdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcbiAgY29uc3QgW2ZpbHRlckRhdGVSYW5nZSwgc2V0RmlsdGVyRGF0ZVJhbmdlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtmaWx0ZXJUeXBlLCBzZXRGaWx0ZXJUeXBlXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG5cclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgY29uc3QgZ3JvdXBJZCA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuICAgIHNldFNlbGVjdGVkR3JvdXAoZ3JvdXBJZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBsZWFkX25hbWU6IFwiXCIsXHJcbiAgICBsZWFkX3Bob25lOiBcIlwiLFxyXG4gICAgbGVhZF9wcm9mZXNzaW9uOiBcIlwiLFxyXG4gICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICBsZWFkX3R5cGU6IFwiXCIsXHJcbiAgICBsZWFkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgbGVhZF9lbXBsb3llZTogXCJcIixcclxuICAgIGxlYWRfYWdlbnQ6IFwiXCIsXHJcbiAgICBsZWFkX25lZWRzOiBcIlwiLFxyXG4gICAgbm90ZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBsZWFkX25hbWU6IFwiXCIsXHJcbiAgICBsZWFkX3Bob25lOiBcIlwiLFxyXG4gICAgbGVhZF9wcm9mZXNzaW9uOiBcIlwiLFxyXG4gICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICBsZWFkX3R5cGU6IFwiXCIsXHJcbiAgICBsZWFkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgbGVhZF9hZ2VudDogXCJcIixcclxuICAgIGxlYWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICBsZWFkX2FnZW50X25hbWU6IFwiXCIsXHJcbiAgICBsZWFkX2VtcGxveWVlX25hbWU6IFwiXCIsXHJcbiAgICBsZWFkX25lZWRzOiBcIlwiLFxyXG4gICAgbm90ZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFzc2lnblRhc2sgPSAobGVhZElkLCBsZWFkVHlwZU5hbWUpID0+IHtcclxuICAgIG5hdmlnYXRlKFwiL3Rhc2tcIiwgeyBzdGF0ZTogeyBsZWFkSWQsIGxlYWRUeXBlTmFtZSB9IH0pOyAvLyAgcGFzcyBsZWFkSWRcclxuICB9O1xyXG5cclxuICBjb25zdCBmaWx0ZXJPcHRpb25zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIWxlYWRzIHx8IGxlYWRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHsgYWdlbnRzOiBbXSwgdHlwZXM6IFtdIH07XHJcblxyXG4gICAgY29uc3QgYWdlbnRzID0gbmV3IFNldCgpO1xyXG4gICAgY29uc3QgdHlwZXMgPSBuZXcgU2V0KCk7XHJcblxyXG4gICAgbGVhZHMuZm9yRWFjaChsZWFkID0+IHtcclxuICAgICAgaWYgKGxlYWQubGVhZF9hZ2VudD8ubmFtZSkgYWdlbnRzLmFkZChsZWFkLmxlYWRfYWdlbnQubmFtZSk7XHJcbiAgICAgIGlmIChsZWFkLmxlYWRfdHlwZSkgdHlwZXMuYWRkKGxlYWQubGVhZF90eXBlKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGFnZW50czogQXJyYXkuZnJvbShhZ2VudHMpLnNvcnQoKSxcclxuICAgICAgdHlwZXM6IEFycmF5LmZyb20odHlwZXMpLnNvcnQoKSxcclxuICAgIH07XHJcbiAgfSwgW2xlYWRzXSk7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkTGVhZHMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGxldCBkYXRhID0gbGVhZHM7XHJcblxyXG4gICAgLy8gRmlsdGVyIGJ5IEFnZW50ICh1c2luZyBsZWFkX2FnZW50Lm5hbWUpXHJcbiAgICBpZiAoZmlsdGVyQWdlbnQgIT09IFwiYWxsXCIpIHtcclxuICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKGl0ZW0gPT4gaXRlbS5sZWFkX2FnZW50Py5uYW1lID09PSBmaWx0ZXJBZ2VudCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRmlsdGVyIGJ5IFR5cGVcclxuICAgIGlmIChmaWx0ZXJUeXBlICE9PSBcImFsbFwiKSB7XHJcbiAgICAgIGRhdGEgPSBkYXRhLmZpbHRlcihpdGVtID0+IGl0ZW0ubGVhZF90eXBlID09PSBmaWx0ZXJUeXBlKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBGaWx0ZXIgYnkgRGF0ZSBSYW5nZSAodXNpbmcgY3JlYXRlZEF0KVxyXG4gICAgaWYgKGZpbHRlckRhdGVSYW5nZSAmJiBmaWx0ZXJEYXRlUmFuZ2UubGVuZ3RoID09PSAyKSB7XHJcbiAgICAgIGNvbnN0IFtzdGFydCwgZW5kXSA9IGZpbHRlckRhdGVSYW5nZTtcclxuICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKGl0ZW0gPT4ge1xyXG4gICAgICAgIGlmICghaXRlbS5jcmVhdGVkQXQpIHJldHVybiBmYWxzZTtcclxuICAgICAgICBjb25zdCBpdGVtRGF0ZSA9IG5ldyBEYXRlKGl0ZW0uY3JlYXRlZEF0KTtcclxuICAgICAgICByZXR1cm4gaXRlbURhdGUgPj0gc3RhcnQudG9EYXRlKCkgJiYgaXRlbURhdGUgPD0gZW5kLnRvRGF0ZSgpO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gZGF0YTtcclxuICB9LCBbbGVhZHMsIGZpbHRlckFnZW50LCBmaWx0ZXJEYXRlUmFuZ2UsIGZpbHRlclR5cGVdKTtcclxuXHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVGFibGVEYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBsZXQgZGF0YSA9IFRhYmxlR3JvdXBzO1xyXG5cclxuICAgIC8vIEZpbHRlciBieSBBZ2VudCAodXNpbmcgbGVhZF90eXBlX25hbWUgb3IgbGVhZF9hZ2VudCBuYW1lKVxyXG4gICAgaWYgKGZpbHRlckFnZW50ICE9PSBcImFsbFwiKSB7XHJcbiAgICAgIGRhdGEgPSBkYXRhLmZpbHRlcihpdGVtID0+IGl0ZW0ubGVhZF90eXBlX25hbWUgPT09IGZpbHRlckFnZW50KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBGaWx0ZXIgYnkgVHlwZVxyXG4gICAgaWYgKGZpbHRlclR5cGUgIT09IFwiYWxsXCIpIHtcclxuICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKGl0ZW0gPT4gaXRlbS5sZWFkX3R5cGUgPT09IGZpbHRlclR5cGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEZpbHRlciBieSBEYXRlIFJhbmdlXHJcbiAgICBpZiAoZmlsdGVyRGF0ZVJhbmdlICYmIGZpbHRlckRhdGVSYW5nZS5sZW5ndGggPT09IDIpIHtcclxuICAgICAgY29uc3QgW3N0YXJ0LCBlbmRdID0gZmlsdGVyRGF0ZVJhbmdlO1xyXG4gICAgICBkYXRhID0gZGF0YS5maWx0ZXIoaXRlbSA9PiB7XHJcbiAgICAgICAgaWYgKCFpdGVtLmRhdGUpIHJldHVybiBmYWxzZTtcclxuICAgICAgICBjb25zdCBpdGVtRGF0ZSA9IG5ldyBEYXRlKGl0ZW0uZGF0ZSk7XHJcbiAgICAgICAgcmV0dXJuIGl0ZW1EYXRlID49IHN0YXJ0LnRvRGF0ZSgpICYmIGl0ZW1EYXRlIDw9IGVuZC50b0RhdGUoKTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gR2xvYmFsIHNlYXJjaCAoYWxyZWFkeSBoYW5kbGVkIGJ5IERhdGFUYWJsZSwgYnV0IHdlIGNhbiBwcmUtZmlsdGVyIGZvciBwZXJmb3JtYW5jZSlcclxuICAgIGlmIChzZWFyY2hUZXh0KSB7XHJcbiAgICAgIGRhdGEgPSBkYXRhLmZpbHRlcihpdGVtID0+XHJcbiAgICAgICAgT2JqZWN0LnZhbHVlcyhpdGVtKS5zb21lKHZhbHVlID0+XHJcbiAgICAgICAgICBTdHJpbmcodmFsdWUpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgIClcclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gZGF0YTtcclxuICB9LCBbVGFibGVHcm91cHMsIGZpbHRlckFnZW50LCBmaWx0ZXJEYXRlUmFuZ2UsIGZpbHRlclR5cGUsIHNlYXJjaFRleHRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTGVhZHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9sZWFkL25ldy1ub24tY29udmVydGVkXCIpO1xyXG4gICAgICAgIHNldExlYWRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgbGVhZF9jb2RlOiBncm91cD8ubGVhZF9jb2RlLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXA/LmxlYWRfbmFtZSxcclxuICAgICAgICAgIHBob25lOiBncm91cD8ubGVhZF9waG9uZSxcclxuICAgICAgICAgIHByb2Zlc3Npb246IGdyb3VwPy5sZWFkX3Byb2Zlc3Npb24sXHJcbiAgICAgICAgICBsZWFkX25lZWRzOiBncm91cD8ubGVhZF9uZWVkcyxcclxuICAgICAgICAgIGdyb3VwX2lkOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgZ3JvdXA/Lmdyb3VwX25hbWUgfHwgXCJcIixcclxuICAgICAgICAgIGRhdGU6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwiLFxyXG4gICAgICAgICAgbGVhZF90eXBlOiBncm91cC5sZWFkX3R5cGUsXHJcbiAgICAgICAgICBub3RlOiBncm91cD8ubm90ZSxcclxuICAgICAgICAgIGxlYWRfdHlwZV9uYW1lOlxyXG4gICAgICAgICAgICBncm91cC5sZWFkX3R5cGUgPT09IFwiY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgID8gZ3JvdXA/LmxlYWRfY3VzdG9tZXI/LmZ1bGxfbmFtZVxyXG4gICAgICAgICAgICAgIDogZ3JvdXAubGVhZF90eXBlID09PSBcImFnZW50XCIgfHwgZ3JvdXAubGVhZF90eXBlID09PSBcImVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgID8gZ3JvdXA/LmxlYWRfYWdlbnQ/Lm5hbWVcclxuICAgICAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJMZWFkIHRvIEN1c3RvbWVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtOTAwIGN1cnNvci1wb2ludGVyIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVPcGVuQ29udmVydEN1c3RvbWVyTW9kYWwoZ3JvdXAuX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEwg4oaUIENcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFzc2lnblRhc2soZ3JvdXAuX2lkLCBncm91cC5sZWFkX3R5cGVfbmFtZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBc3NpZ24gVGFza1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiNFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNvZnRSZW1vdmUoZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFRhYmxlR3JvdXBzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoTGVhZHMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gIC8vICAgICB0cnkge1xyXG4gIC8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIik7XHJcbiAgLy8gICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gIC8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhZ2VudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgLy8gICAgIH1cclxuICAvLyAgIH07XHJcbiAgLy8gICBmZXRjaEFnZW50cygpO1xyXG4gIC8vIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgICBzZXRBZ2VudHMocmVzcG9uc2U/LmRhdGE/LmFnZW50KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWdlbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudCgpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuICAgICAgICBzZXRFbXBsb3llZXMocmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgRW1wbG95ZWUgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZSgpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuXHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7XHJcbiAgICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgICAgIFtmaWVsZF06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU29mdFJlbW92ZSA9IGFzeW5jIChsZWFkSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoYC9sZWFkL3NvZnQtZGVsZXRlLWxlYWQvJHtsZWFkSWR9YCk7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJMZWFkIHJlbW92ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNvZnQgcmVtb3ZpbmcgbGVhZDpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byByZW1vdmUgbGVhZFwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoeyAuLi5wcmV2RXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoeyAuLi5wcmV2RXJyb3JzLCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZExlYWRcIiA/IGZvcm1EYXRhIDogdXBkYXRlRm9ybURhdGE7XHJcblxyXG4gICAgaWYgKCFkYXRhLmxlYWRfbmFtZT8udG9TdHJpbmcoKS50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfbmFtZSA9IFwiTGVhZCBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmxlYWRfcGhvbmUpIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfcGhvbmUgPSBcIlBob25lIE51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghL15bNi05XVxcZHs5fSQvLnRlc3QoZGF0YS5sZWFkX3Bob25lKSkge1xyXG4gICAgICBuZXdFcnJvcnMubGVhZF9waG9uZSA9IFwiSW52YWxpZCBwaG9uZSBudW1iZXIgKG11c3QgYmUgMTAgZGlnaXRzKVwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5sZWFkX3Byb2Zlc3Npb24pIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfcHJvZmVzc2lvbiA9IFwiUHJvZmVzc2lvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5sZWFkX3R5cGUpIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfdHlwZSA9IFwiTGVhZCBTb3VyY2UgVHlwZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChkYXRhLmxlYWRfdHlwZSA9PT0gXCJjdXN0b21lclwiICYmICFkYXRhLmxlYWRfY3VzdG9tZXIpIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfY3VzdG9tZXIgPSBcIkN1c3RvbWVyIHNlbGVjdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChkYXRhLmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiICYmICFkYXRhLmxlYWRfYWdlbnQpIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfYWdlbnQgPSBcIkFnZW50IHNlbGVjdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChkYXRhLmxlYWRfdHlwZSA9PT0gXCJlbXBsb3llZVwiICYmICFkYXRhLmxlYWRfZW1wbG95ZWUpIHtcclxuICAgICAgbmV3RXJyb3JzLmxlYWRfZW1wbG95ZWUgPSBcIkVtcGxveWVlIHNlbGVjdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5sZWFkX25lZWRzPy50b1N0cmluZygpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5sZWFkX25lZWRzID0gXCJMZWFkIE5lZWRzIGFuZCBHb2FscyBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcbiAgLy8gY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAvLyAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gIC8vICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkTGVhZFwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuICAvLyAgIGlmICghZGF0YS5sZWFkX25hbWUudG9TdHJpbmcoKS50cmltKCkpIHtcclxuICAvLyAgICAgbmV3RXJyb3JzLmxlYWRfbmFtZSA9IFwiTGVhZCBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgLy8gICB9XHJcblxyXG4gIC8vICAgaWYgKCFkYXRhLmxlYWRfcGhvbmUpIHtcclxuICAvLyAgICAgbmV3RXJyb3JzLmxlYWRfcGhvbmUgPSBcIlBob25lIE51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gIC8vICAgfSBlbHNlIGlmICghL15bNi05XVxcZHs5fSQvLnRlc3QoZGF0YS5sZWFkX3Bob25lKSkge1xyXG4gIC8vICAgICBuZXdFcnJvcnMubGVhZF9waG9uZSA9IFwiSW52YWxpZCBwaG9uZSBudW1iZXIgKG11c3QgYmUgMTAgZGlnaXRzKVwiO1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyAgIGlmICghZGF0YS5sZWFkX3Byb2Zlc3Npb24pIHtcclxuICAvLyAgICAgbmV3RXJyb3JzLmxlYWRfcHJvZmVzc2lvbiA9IFwiUHJvZmVzc2lvbiBpcyByZXF1aXJlZFwiO1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyAgIGlmICghZGF0YS5sZWFkX3R5cGUpIHtcclxuICAvLyAgICAgbmV3RXJyb3JzLmxlYWRfdHlwZSA9IFwiTGVhZCBTb3VyY2UgVHlwZSBpcyByZXF1aXJlZFwiO1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyAgIGlmIChkYXRhLmxlYWRfdHlwZSA9PT0gXCJjdXN0b21lclwiICYmICFkYXRhLmxlYWRfY3VzdG9tZXIpIHtcclxuICAvLyAgICAgbmV3RXJyb3JzLmxlYWRfY3VzdG9tZXIgPSBcIkN1c3RvbWVyIHNlbGVjdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyAgIGlmIChkYXRhLmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiICYmICFkYXRhLmxlYWRfYWdlbnQpIHtcclxuICAvLyAgICAgbmV3RXJyb3JzLmxlYWRfYWdlbnQgPSBcIkFnZW50IHNlbGVjdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gIC8vICAgfVxyXG4gIC8vICAgaWYgKGRhdGEubGVhZF90eXBlID09PSBcImVtcGxveWVlXCIgJiYgIWRhdGEubGVhZF9lbXBsb3llZSkge1xyXG4gIC8vICAgICBuZXdFcnJvcnMubGVhZF9lbXBsb3llZSA9IFwiRW1wbG95ZWUgc2VsZWN0aW9uIGlzIHJlcXVpcmVkXCI7XHJcbiAgLy8gICB9XHJcbiAgLy8gICBpZiAoIWRhdGEubGVhZF9uZWVkcy50b1N0cmluZygpKSB7XHJcbiAgLy8gICAgIG5ld0Vycm9ycy5sZWFkX25lZWRzID0gXCJMZWFkIE5lZWRzIGFuZCBHb2FscyBpcyByZXF1aXJlZFwiO1xyXG4gIC8vICAgfVxyXG5cclxuICAvLyAgIC8vICAgaWYgKCFkYXRhLm5vdGU/LnRvU3RyaW5nKCkudHJpbSgpKSB7XHJcbiAgLy8gICAvLyAgIG5ld0Vycm9ycy5ub3RlID0gXCJOb3RlIEZpZWxkIGlzIE1hbmRhdG9yeVwiO1xyXG4gIC8vICAgLy8gfVxyXG5cclxuICAvLyAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gIC8vICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIC8vIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybShcImFkZExlYWRcIik7XHJcbiAgICBpZiAoIWlzVmFsaWQpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL2xlYWQvYWRkLWxlYWRcIiwgZm9ybURhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiTGVhZCBhZGRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICBsZWFkX25hbWU6IFwiXCIsXHJcbiAgICAgICAgbGVhZF9waG9uZTogXCJcIixcclxuICAgICAgICBsZWFkX3Byb2Zlc3Npb246IFwiXCIsXHJcbiAgICAgICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICAgICAgbGVhZF90eXBlOiBcIlwiLFxyXG4gICAgICAgIGxlYWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgICAgbGVhZF9hZ2VudDogXCJcIixcclxuICAgICAgICBsZWFkX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgICAgIGxlYWRfbmVlZHM6IFwiXCIsXHJcbiAgICAgICAgbm90ZTogXCJcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkVycm9yOlwiLCBlcnJvci5yZXNwb25zZT8uZGF0YSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkR3JvdXBzID0gZ3JvdXBzLmZpbHRlcigoZ3JvdXApID0+XHJcbiAgICBncm91cC5ncm91cF9uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSxcclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vbGVhZC9sZWFkLWJ5LWlkLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbGVhZDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9sZWFkL2xlYWQtYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuXHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cChkYXRhKTtcclxuXHJcbiAgICAgIGxldCBhZ2VudElkID0gXCJcIjtcclxuICAgICAgbGV0IGVtcGxveWVlSWQgPSBcIlwiO1xyXG5cclxuICAgICAgaWYgKGRhdGE/LmxlYWRfdHlwZSA9PT0gXCJhZ2VudFwiICYmIGRhdGE/LmxlYWRfYWdlbnQpIHtcclxuICAgICAgICAvLyBDb252ZXJ0IHRvIHN0cmluZyB0byBlbnN1cmUgbWF0Y2ggd2l0aCBTZWxlY3Qgb3B0aW9uc1xyXG4gICAgICAgIGFnZW50SWQgPSBTdHJpbmcoZGF0YS5sZWFkX2FnZW50Ll9pZCB8fCBkYXRhLmxlYWRfYWdlbnQpO1xyXG4gICAgICB9IGVsc2UgaWYgKGRhdGE/LmxlYWRfdHlwZSA9PT0gXCJlbXBsb3llZVwiICYmIGRhdGE/LmxlYWRfYWdlbnQpIHtcclxuICAgICAgICBlbXBsb3llZUlkID0gU3RyaW5nKGRhdGEubGVhZF9hZ2VudC5faWQgfHwgZGF0YS5sZWFkX2FnZW50KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIGxlYWRfbmFtZTogZGF0YT8ubGVhZF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgbGVhZF9waG9uZTogZGF0YT8ubGVhZF9waG9uZSB8fCBcIlwiLFxyXG4gICAgICAgIGxlYWRfcHJvZmVzc2lvbjogZGF0YT8ubGVhZF9wcm9mZXNzaW9uIHx8IFwiXCIsXHJcbiAgICAgICAgZ3JvdXBfaWQ6IGRhdGE/Lmdyb3VwX2lkPy5faWQgfHwgZGF0YT8uZ3JvdXBfaWQgfHwgXCJcIixcclxuICAgICAgICBsZWFkX3R5cGU6IGRhdGE/LmxlYWRfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIGxlYWRfYWdlbnQ6IGFnZW50SWQsXHJcbiAgICAgICAgbGVhZF9lbXBsb3llZTogZW1wbG95ZWVJZCxcclxuICAgICAgICBsZWFkX2N1c3RvbWVyOiBkYXRhPy5sZWFkX2N1c3RvbWVyPy5faWQgfHwgZGF0YT8ubGVhZF9jdXN0b21lciB8fCBcIlwiLFxyXG4gICAgICAgIGxlYWRfbmVlZHM6IGRhdGE/LmxlYWRfbmVlZHMgfHwgXCJcIixcclxuICAgICAgICBub3RlOiBkYXRhPy5ub3RlIHx8IFwiXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGxlYWQ6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gbG9hZCBsZWFkIGRldGFpbHNcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgLy8gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgLy8gICB0cnkge1xyXG4gIC8vICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9sZWFkL2dldC1sZWFkLWJ5LWlkLyR7Z3JvdXBJZH1gKTtcclxuICAvLyAgICAgY29uc3QgZGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcblxyXG4gIC8vICAgICAvLyBjb25zb2xlLmxvZyhcIkxlYWQgZGF0YSBmb3IgdXBkYXRlOlwiLCBkYXRhKTtcclxuXHJcbiAgLy8gICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cChkYXRhKTtcclxuICAvLyAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgLy8gICBsZWFkX25hbWU6IGRhdGE/LmxlYWRfbmFtZSB8fCBcIlwiLFxyXG4gIC8vICAgbGVhZF9waG9uZTogZGF0YT8ubGVhZF9waG9uZSB8fCBcIlwiLFxyXG4gIC8vICAgbGVhZF9wcm9mZXNzaW9uOiBkYXRhPy5sZWFkX3Byb2Zlc3Npb24gfHwgXCJcIixcclxuICAvLyAgIGdyb3VwX2lkOiBkYXRhPy5ncm91cF9pZD8uX2lkIHx8IGRhdGE/Lmdyb3VwX2lkIHx8IFwiXCIsXHJcblxyXG4gIC8vICAgbGVhZF90eXBlOiBkYXRhPy5sZWFkX3R5cGUgfHwgXCJcIixcclxuXHJcbiAgLy8gICBsZWFkX2FnZW50OlxyXG4gIC8vICAgICBkYXRhPy5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIlxyXG4gIC8vICAgICAgID8gZGF0YT8ubGVhZF9hZ2VudD8uX2lkIHx8IFwiXCJcclxuICAvLyAgICAgICA6IFwiXCIsXHJcblxyXG4gIC8vICAgbGVhZF9hZ2VudF9uYW1lOlxyXG4gIC8vICAgICBkYXRhPy5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIlxyXG4gIC8vICAgICAgID8gZGF0YT8ubGVhZF9hZ2VudD8ubmFtZSB8fCBcIlwiXHJcbiAgLy8gICAgICAgOiBcIlwiLFxyXG5cclxuICAvLyAgIGxlYWRfZW1wbG95ZWU6XHJcbiAgLy8gICAgIGRhdGE/LmxlYWRfdHlwZSA9PT0gXCJlbXBsb3llZVwiXHJcbiAgLy8gICAgICAgPyBkYXRhPy5sZWFkX2FnZW50Py5faWQgfHwgXCJcIlxyXG4gIC8vICAgICAgIDogXCJcIixcclxuXHJcbiAgLy8gICBsZWFkX2VtcGxveWVlX25hbWU6XHJcbiAgLy8gICAgIGRhdGE/LmxlYWRfdHlwZSA9PT0gXCJlbXBsb3llZVwiXHJcbiAgLy8gICAgICAgPyBkYXRhPy5sZWFkX2FnZW50Py5uYW1lIHx8IFwiXCJcclxuICAvLyAgICAgICA6IFwiXCIsXHJcblxyXG4gIC8vICAgbGVhZF9jdXN0b21lcjogZGF0YT8ubGVhZF9jdXN0b21lcj8uX2lkIHx8IGRhdGE/LmxlYWRfY3VzdG9tZXIgfHwgXCJcIixcclxuICAvLyAgIGxlYWRfbmVlZHM6IGRhdGE/LmxlYWRfbmVlZHMgfHwgXCJcIixcclxuICAvLyAgIG5vdGU6IGRhdGE/Lm5vdGUgfHwgXCJcIixcclxuICAvLyB9KTtcclxuXHJcbiAgLy8gICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAvLyAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAvLyAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgLy8gICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsZWFkOlwiLCBlcnJvcik7XHJcbiAgLy8gICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAvLyAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gIC8vICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgbGVhZCBkZXRhaWxzXCIsXHJcbiAgLy8gICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gIC8vICAgICB9KTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7IC4uLnByZXZFcnJvcnMsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlR3JvdXAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2xlYWQvZGVsZXRlLWxlYWQvJHtjdXJyZW50R3JvdXAuX2lkfWApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJMZWFkIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgbGVhZDpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVnZXggPSB7XHJcbiAgICBlbWFpbDogL15bXlxcc0BdK0BbXlxcc0BdK1xcLlteXFxzQF0rJC8sIC8vIFZhbGlkYXRlcyBlbWFpbCBmb3JtYXRcclxuICAgIHBpbmNvZGU6IC9eXFxkezZ9JC8sIC8vIFZhbGlkYXRlcyA2IGRpZ2l0cyBmb3IgcGluY29kZVxyXG4gICAgYWRoYWFyOiAvXlxcZHsxMn0kLywgLy8gVmFsaWRhdGVzIDEyIGRpZ2l0cyBmb3IgQWFkaGFyIG51bWJlclxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlQ29udmVydFRvQ3VzdG9tZXIgPSAoZGF0YSkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcblxyXG4gICAgaWYgKCFkYXRhLmZ1bGxfbmFtZT8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5mdWxsX25hbWUgPSBcIkZ1bGwgbmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5waG9uZV9udW1iZXIgfHwgIS9eWzYtOV1cXGR7OX0kLy50ZXN0KGRhdGEucGhvbmVfbnVtYmVyKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGhvbmVfbnVtYmVyID0gXCJWYWxpZCBwaG9uZSBudW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGFzc3dvcmQpIHtcclxuICAgICAgbmV3RXJyb3JzLnBhc3N3b3JkID0gXCJQYXNzd29yZCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5waW5jb2RlIHx8ICFyZWdleC5waW5jb2RlLnRlc3QoZGF0YS5waW5jb2RlKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGluY29kZSA9IFwiSW52YWxpZCBwaW5jb2RlICg2IGRpZ2l0cyByZXF1aXJlZClcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEuYWRoYWFyX25vIHx8ICFyZWdleC5hZGhhYXIudGVzdChkYXRhLmFkaGFhcl9ubykpIHtcclxuICAgICAgbmV3RXJyb3JzLmFkaGFhcl9ubyA9IFwiSW52YWxpZCBBYWRoYXIgbnVtYmVyICgxMiBkaWdpdHMgcmVxdWlyZWQpXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGRhdGEucGFuX25vICYmIGRhdGEucGFuX25vLnRyaW0oKS5sZW5ndGggIT09IDEwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYW5fbm8gPSBcIkludmFsaWQgUEFOIGZvcm1hdCAoZS5nLiwgQUJDREUxMjM0RilcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEuYWRkcmVzcyB8fCBkYXRhLmFkZHJlc3MudHJpbSgpLmxlbmd0aCA8IDMpIHtcclxuICAgICAgbmV3RXJyb3JzLmFkZHJlc3MgPSBcIkFkZHJlc3Mgc2hvdWxkIGJlIGF0IGxlYXN0IDMgY2hhcmFjdGVyc1wiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5ub19vZl90aWNrZXRzKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ub19vZl90aWNrZXRzID0gXCJOdW1iZXIgb2YgVGlja2V0cyBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5wYXltZW50X3R5cGUpIHtcclxuICAgICAgbmV3RXJyb3JzLnBheW1lbnRfdHlwZSA9IFwiUGF5bWVudCB0eXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJ1cGRhdGVMZWFkXCIpOyAvLyBQYXNzIHR5cGUgdG8gdmFsaWRhdGVcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgICAgLy8gQ2xlYW4gdXAgdGhlIGRhdGEgYmVmb3JlIHNlbmRpbmdcclxuICAgICAgICBjb25zdCBzdWJtaXREYXRhID0ge1xyXG4gICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAvLyBJZiBsZWFkX3R5cGUgaXMgYWdlbnQsIHNlbmQgbGVhZF9hZ2VudDsgaWYgZW1wbG95ZWUsIHNlbmQgbGVhZF9lbXBsb3llZVxyXG4gICAgICAgICAgbGVhZF9hZ2VudDpcclxuICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEubGVhZF90eXBlID09PSBcImFnZW50XCJcclxuICAgICAgICAgICAgICA/IHVwZGF0ZUZvcm1EYXRhLmxlYWRfYWdlbnRcclxuICAgICAgICAgICAgICA6IG51bGwsXHJcbiAgICAgICAgICBsZWFkX2VtcGxveWVlOlxyXG4gICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5sZWFkX3R5cGUgPT09IFwiZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgID8gdXBkYXRlRm9ybURhdGEubGVhZF9lbXBsb3llZVxyXG4gICAgICAgICAgICAgIDogbnVsbCxcclxuICAgICAgICAgIGxlYWRfY3VzdG9tZXI6XHJcbiAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmxlYWRfdHlwZSA9PT0gXCJjdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgPyB1cGRhdGVGb3JtRGF0YS5sZWFkX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgOiBudWxsLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL2xlYWQvdXBkYXRlLWxlYWQvJHtjdXJyZW50VXBkYXRlR3JvdXAuX2lkfWAsXHJcbiAgICAgICAgICBzdWJtaXREYXRhLFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJMZWFkIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBsZWFkOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHVwZGF0ZSBsZWFkXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gIC8vICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIC8vICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG5cclxuICAvLyAgIHRyeSB7XHJcbiAgLy8gICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgLy8gICAgICAgYXdhaXQgYXBpLnB1dChcclxuICAvLyAgICAgICAgIGAvbGVhZC91cGRhdGUtbGVhZC8ke2N1cnJlbnRVcGRhdGVHcm91cC5faWR9YCxcclxuICAvLyAgICAgICAgIHVwZGF0ZUZvcm1EYXRhXHJcbiAgLy8gICAgICAgKTtcclxuICAvLyAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gIC8vICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAvLyAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgLy8gICAgICAgICBtZXNzYWdlOiBcIkxlYWQgVXBkYXRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAvLyAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gIC8vICAgICAgIH0pO1xyXG4gIC8vICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAvLyAgICAgfVxyXG4gIC8vICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgLy8gICB9XHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwibGVhZF9jb2RlXCIsIGhlYWRlcjogXCJMZWFkIElEXCIgfSwgLy8gPC0tLSBBRERFRCBMRUFEX0lEIENPTFVNTlxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiTGVhZCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lXCIsIGhlYWRlcjogXCJMZWFkIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJwcm9mZXNzaW9uXCIsIGhlYWRlcjogXCJMZWFkIFByb2Zlc3Npb25cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9pZFwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJsZWFkX3R5cGVcIiwgaGVhZGVyOiBcIkxlYWQgU291cmNlIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibGVhZF9uZWVkc1wiLCBoZWFkZXI6IFwiTGVhZCBOZWVkcyBBbmQgR29hbHNcIiB9LFxyXG4gICAgeyBrZXk6IFwibGVhZF90eXBlX25hbWVcIiwgaGVhZGVyOiBcIkxlYWQgU291cmNlIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29udmVydEN1c3RvbWVyU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBjb25zdCB2YWxpZCA9IHZhbGlkYXRlQ29udmVydFRvQ3VzdG9tZXIoZm9ybURhdGEpO1xyXG4gICAgaWYgKCF2YWxpZCkgcmV0dXJuO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKHZhbGlkKSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgIFwiL2xlYWQvY29udmVydC1sZWFkLXRvLWN1c3RvbWVyXCIsXHJcbiAgICAgICAgICBmb3JtRGF0YSxcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLmRhdGEubWVzc2FnZSB8fCBcIkxlYWQgY29udmVydGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRMZWFkU2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc3QgZXJyTXNnID0gZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlO1xyXG4gICAgICAvLyBIYW5kbGUgZmllbGQtc3BlY2lmaWMgZXJyb3JzXHJcbiAgICAgIGlmIChlcnJNc2c/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJwaG9uZSBudW1iZXJcIikpIHtcclxuICAgICAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBcIlBob25lIG51bWJlciBhbHJlYWR5IGV4aXN0cy5cIixcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGVyck1zZz8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImdyb3VwIGlzIGFscmVhZHkgZnVsbFwiKSkge1xyXG4gICAgICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgZ3JvdXBfaWQ6IGVyck1zZyB9KSk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGVyck1zZz8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImFnZW50IGFscmVhZHkgZXhpc3RzXCIpKSB7XHJcbiAgICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhZ2VudDogZXJyTXNnIH0pKTtcclxuICAgICAgfVxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVyck1zZyB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlT3BlbkNvbnZlcnRDdXN0b21lck1vZGFsID0gYXN5bmMgKGxlYWRJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvbGVhZC9nZXQtbGVhZC10by1jdXN0b21lci1ieS1pZC8ke2xlYWRJZH1gLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIGZ1bGxfbmFtZTogZGF0YT8ubGVhZF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgcGhvbmVfbnVtYmVyOiBkYXRhPy5sZWFkX3Bob25lIHx8IFwiXCIsXHJcbiAgICAgICAgbGVhZF9wcm9mZXNzaW9uOiBkYXRhPy5sZWFkX3Byb2Zlc3Npb24gfHwgXCJcIiwgLy8gIEVuc3VyZSBhZGRlZFxyXG4gICAgICAgIGdyb3VwX2lkOiBkYXRhPy5ncm91cF9pZD8uX2lkIHx8IFwiXCIsIC8vICBFbnN1cmUgYWRkZWRcclxuICAgICAgICBsZWFkX3R5cGU6IGRhdGE/LmxlYWRfdHlwZSB8fCBcIlwiLCAvLyAgRW5zdXJlIGFkZGVkXHJcbiAgICAgICAgbGVhZF9hZ2VudDogZGF0YT8ubGVhZF9hZ2VudD8uX2lkIHx8IFwiXCIsXHJcbiAgICAgICAgZW1haWw6IFwiXCIsXHJcbiAgICAgICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICAgICAgbGVhZF9jdXN0b21lcjogZGF0YT8ubGVhZF9jdXN0b21lcj8uX2lkIHx8IFwiXCIsXHJcbiAgICAgICAgcGluY29kZTogZGF0YT8ucGluY29kZSB8fCBcIlwiLFxyXG4gICAgICAgIGFkZHJlc3M6IGRhdGE/LmxlYWRfYWRkcmVzcyB8fCBcIlwiLFxyXG4gICAgICAgIGFkaGFhcl9ubzogXCJcIixcclxuICAgICAgICBwYW5fbm86IFwiXCIsXHJcbiAgICAgICAgbGVhZF9uZWVkczogZGF0YT8ubGVhZF9uZWVkcyB8fCBcIlwiLFxyXG4gICAgICAgIG5vdGU6IGRhdGE/Lm5vdGUgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF90eXBlOiBkYXRhPy5sZWFkX3R5cGUgfHwgXCJcIixcclxuICAgICAgICBwYXltZW50X3R5cGU6IGRhdGE/LnBheW1lbnRfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIG5vX29mX3RpY2tldHM6IGRhdGE/Lm5vX29mX3RpY2tldHMgfHwgXCJcIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRMZWFkU2hvd01vZGFsKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIG9wZW5pbmcgY29udmVydCBtb2RhbDpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgbGVhZCBkZXRhaWxzLlwiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFnZW50TGVhZENvdW50cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFsZWFkcyB8fCBsZWFkcy5sZW5ndGggPT09IDApIHJldHVybiBbXTtcclxuXHJcbiAgICBjb25zdCBjb3VudHMgPSB7fTtcclxuXHJcbiAgICBsZWFkcy5mb3JFYWNoKChsZWFkKSA9PiB7XHJcbiAgICAgIGNvbnN0IGFnZW50TmFtZSA9IGxlYWQubGVhZF9hZ2VudD8ubmFtZTtcclxuICAgICAgaWYgKGFnZW50TmFtZSkge1xyXG4gICAgICAgIGNvdW50c1thZ2VudE5hbWVdID0gKGNvdW50c1thZ2VudE5hbWVdIHx8IDApICsgMTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKGNvdW50cylcclxuICAgICAgLm1hcCgoW25hbWUsIGNvdW50XSkgPT4gKHsgbmFtZSwgY291bnQgfSkpXHJcbiAgICAgIC5zb3J0KChhLCBiKSA9PiBiLmNvdW50IC0gYS5jb3VudCk7XHJcbiAgfSwgW2xlYWRzXSk7XHJcblxyXG4gIGNvbnN0IHN0YXRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIWZpbHRlcmVkTGVhZHMgfHwgZmlsdGVyZWRMZWFkcy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsID0gbGVhZHMubGVuZ3RoO1xyXG4gICAgY29uc3QgdHlwZUNvdW50ID0ge307XHJcbiAgICBjb25zdCBwcm9mZXNzaW9uQ291bnQgPSB7fTtcclxuICAgIGNvbnN0IGdyb3VwQ291bnQgPSB7fTtcclxuXHJcbiAgICBsZWFkcy5mb3JFYWNoKChsZWFkKSA9PiB7XHJcbiAgICAgIGNvbnN0IHR5cGUgPSBsZWFkLmxlYWRfdHlwZSB8fCBcInVua25vd25cIjtcclxuICAgICAgdHlwZUNvdW50W3R5cGVdID0gKHR5cGVDb3VudFt0eXBlXSB8fCAwKSArIDE7XHJcblxyXG4gICAgICBjb25zdCBwcm9mID0gbGVhZC5sZWFkX3Byb2Zlc3Npb24gfHwgXCJub3Qtc3BlY2lmaWVkXCI7XHJcbiAgICAgIHByb2Zlc3Npb25Db3VudFtwcm9mXSA9IChwcm9mZXNzaW9uQ291bnRbcHJvZl0gfHwgMCkgKyAxO1xyXG5cclxuICAgICAgY29uc3QgZ3JvdXAgPSBsZWFkLmdyb3VwX25hbWUgfHwgXCJVbmFzc2lnbmVkXCI7XHJcbiAgICAgIGdyb3VwQ291bnRbZ3JvdXBdID0gKGdyb3VwQ291bnRbZ3JvdXBdIHx8IDApICsgMTtcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHRvcEdyb3VwcyA9IE9iamVjdC5lbnRyaWVzKGdyb3VwQ291bnQpXHJcbiAgICAgIC5zb3J0KChhLCBiKSA9PiBiWzFdIC0gYVsxXSlcclxuICAgICAgLnNsaWNlKDAsIDUpO1xyXG5cclxuICAgIHJldHVybiB7IHRvdGFsLCB0eXBlQ291bnQsIHByb2Zlc3Npb25Db3VudCwgdG9wR3JvdXBzIH07XHJcbiAgfSwgW2xlYWRzXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMjAgb3ZlcmZsb3cteC1oaWRkZW5cIj5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgcC03IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04IFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsIFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBcIj5MZWFkczwvaDE+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICArIEFkZCBMZWFkXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiAtLS0gU3VtbWFyeSBDYXJkcyAtLS0gKi99XHJcbiAgICAgICAgICAgICAge3N0YXRzICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogVG90YWwgTGVhZHMgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy01IGdhcC00IG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1ibHVlLTEwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ibHVlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYmx1ZS03MDBcIj5Ub3RhbCBMZWFkczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntzdGF0cy50b3RhbH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ibHVlLTUwMCByb3VuZGVkLWZ1bGwgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVVzZXJzIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoc3RhdHMudHlwZUNvdW50KS5tYXAoKFt0eXBlLCBjb3VudF0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyYXktNTAgdG8tZ3JheS0xMDAgcm91bmRlZC14bCBwLTQgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHlwZSArIFwiIExlYWRzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntjb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctZ3JheS0zMDAgcm91bmRlZC1mdWxsIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eXBlID09PSBcImFnZW50XCIgJiYgPEZhVXNlclRpZSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHlwZSA9PT0gXCJlbXBsb3llZVwiICYmIDxGYVVzZXIgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eXBlID09PSBcInNvY2lhbCBtZWRpYVwiICYmIDxGYVVzZXJzIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3R5cGUgPT09IFwiY3VzdG9tZXJcIiAmJiA8RmFVc2VyIGNsYXNzTmFtZT1cInRleHQteWVsbG93LTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFbXCJhZ2VudFwiLCBcImVtcGxveWVlXCIsIFwic29jaWFsIG1lZGlhXCIsIFwiY3VzdG9tZXJcIl0uaW5jbHVkZXModHlwZSkgJiYgPEZhVXNlcnMgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2FnZW50TGVhZENvdW50cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItM1wiPkxlYWRzIGJ5IEFnZW50PC9oMj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy04IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FnZW50TGVhZENvdW50cy5tYXAoKHsgbmFtZSwgY291bnQgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20taW5kaWdvLTUwIHRvLWluZGlnby0xMDAgcm91bmRlZC14bCBwLTIgc2hhZG93LXNtIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmRpZ28tNzAwIHRydW5jYXRlIG1heC13LVsxMjBweF1cIiB0aXRsZT17bmFtZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntjb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWluZGlnby01MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVVzZXJUaWUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBGaWx0ZXIgQmFyICovfVxyXG4gICAgICAgICAgICAgIHsvKiBGaWx0ZXIgQmFyICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQteGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogQWdlbnQgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkFHRU5UPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgQWdlbnRzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJBZ2VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZpbHRlckFnZW50KHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogXCJhbGxcIiwgbGFiZWw6IFwiQWxsIEFnZW50c1wiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZpbHRlck9wdGlvbnMuYWdlbnRzLm1hcChhZ2VudCA9PiAoeyB2YWx1ZTogYWdlbnQsIGxhYmVsOiBhZ2VudCB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24ubGFiZWwudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIERhdGUgUmFuZ2UgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+REFURSBSQU5HRTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJhbmdlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlckRhdGVSYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZGF0ZXMpID0+IHNldEZpbHRlckRhdGVSYW5nZShkYXRlcyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17W1wiU3RhcnQgZGF0ZVwiLCBcIkVuZCBkYXRlXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFR5cGUgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlRZUEU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBUeXBlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVyVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZpbHRlclR5cGUodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHZhbHVlOiBcImFsbFwiLCBsYWJlbDogXCJBbGwgVHlwZXNcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5maWx0ZXJPcHRpb25zLnR5cGVzLm1hcCh0eXBlID0+ICh7IHZhbHVlOiB0eXBlLCBsYWJlbDogdHlwZSB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogQ2xlYXIgRmlsdGVycyBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQteGwgc2hhZG93LWxnIHctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIExlYWRzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy13aGl0ZSB0ZXh0LWJsdWUtNzAwIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1sZyBmb250LWJvbGQgbWluLXctWzQ1cHhdIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRUYWJsZURhdGE/Lmxlbmd0aCB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7VGFibGVHcm91cHMubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICAgIC8vIGRhdGE9e1RhYmxlR3JvdXBzLmZpbHRlcigoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgLy8gICBPYmplY3QudmFsdWVzKGl0ZW0pLnNvbWUoKHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgU3RyaW5nKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKSxcclxuICAgICAgICAgICAgICAgICAgLy8gICApLFxyXG4gICAgICAgICAgICAgICAgICAvLyApfVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFRhYmxlRGF0YX1cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiTGVhZFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BMZWFkcy5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTQgZ2FwLThcIj5cclxuICAgICAgICAgICAgICAgIHsvKiB7ZmlsdGVyZWRHcm91cHMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTY0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1sZ1wiPk5vIGdyb3VwcyBhZGRlZCB5ZXQ8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyZWRHcm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtncm91cC5pZH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgcC02IHNoYWRvdy1sZyB0cmFuc2Zvcm0gdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDAgaG92ZXI6c2NhbGUtMTA1IGhvdmVyOnNoYWRvdy14bFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgbWItMyB0ZXh0LWdyYXktNzAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIlwiPntncm91cC5ncm91cF90eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgZ3JvdXAuZ3JvdXBfdHlwZS5zbGljZSgxKX0gR3JvdXA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTE2IHB5LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBtYi0yIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbWVtYmVyc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc21cIj5NZW1iZXJzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgbWItNCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2dyb3VwLmdyb3VwX2luc3RhbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtXCI+SW5zdGFsbG1lbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmVlbi00MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZC1tZCBzaGFkb3cgaG92ZXI6Ym9yZGVyLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaUVkaXQgY29sb3I9XCJncmVlblwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItcmVkLTQwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLW1kIHNoYWRvdyBob3Zlcjpib3JkZXItcmVkLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxNZERlbGV0ZSBjb2xvcj1cInJlZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICl9ICovfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5BZGQgTGVhZDwvaDM+XHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTGVhZCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmxlYWRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgTGVhZCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBMZWFkIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9waG9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubGVhZF9waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfcGhvbmUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfcGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBMZWFkIFdvcmsvUHJvZmVzc2lvbntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBMZWFkIFdvcmsvUHJvZmVzc2lvbiBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX3Byb2Zlc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF9wcm9mZXNzaW9uIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJsZWFkX3Byb2Zlc3Npb25cIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge1tcIkVtcGxveWVkXCIsIFwiU2VsZiBFbXBsb3llZFwiXS5tYXAoKGxQcm9mKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bFByb2Z9IHZhbHVlPXtsUHJvZi50b0xvd2VyQ2FzZSgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bFByb2Z9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9wcm9mZXNzaW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX3Byb2Zlc3Npb259XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgey8qIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgR3JvdXA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9yIFNlYXJjaCBHcm91cCBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJncm91cF9pZFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIExlYWQgU291cmNlIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBMZWFkIFNvdXJjZSBUeXBlIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF90eXBlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwibGVhZF90eXBlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlNvY2lhbCBNZWRpYVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJBZ2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJXYWxraW5cIixcclxuICAgICAgICAgICAgICAgICAgICBdLm1hcCgobFR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bFR5cGV9IHZhbHVlPXtsVHlwZS50b0xvd2VyQ2FzZSgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLmxlYWRfdHlwZSA9PT0gXCJjdXN0b21lclwiICYmIChcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImxlYWRfY3VzdG9tZXJcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX2N1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFnZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9hZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF9hZ2VudCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImxlYWRfYWdlbnRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX2FnZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9hZ2VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5sZWFkX3R5cGUgPT09IFwiZW1wbG95ZWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX2VtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5sZWFkX2VtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwibGVhZF9lbXBsb3llZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX2VtcGxveWVlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9lbXBsb3llZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTGVhZCBOZWVkcyBhbmQgR29hbHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX25lZWRzXCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5sZWFkX25lZWRzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBMZWFkIE5lZWRzIGFuZCBHb2Fsczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic2F2aW5nc1wiPlNhdmluZ3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJvcnJvd2luZ3NcIj5Cb3Jyb3dpbmdzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IExlYWQgTmVlZHMgYW5kIEdvYWxzIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfbmVlZHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmxlYWRfbmVlZHMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJsZWFkX25lZWRzXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJTYXZpbmdzXCIsIFwiQm9ycm93aW5nc1wiXS5tYXAoKGxOZWVkcykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtsTmVlZHN9IHZhbHVlPXtsTmVlZHMudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsTmVlZHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfbmVlZHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9uZWVkc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBOb3RlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICByb3dzPXsyfSAvLyBhZGp1c3QgaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNwZWNpZnkgbm90ZSBpZiBhbnkhXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcC00IG1heC13LWZ1bGwgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHBTcXVhcmUgY29sb3I9XCJncmVlblwiIGNsYXNzTmFtZT1cInctMTAgaC0xMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt3aGF0c2FwcEVuYWJsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwIGNoZWNrZWQ6cmluZy0yICBjaGVja2VkOnJpbmctZ3JlZW4tNzAwICByb3VuZGVkLWZ1bGwgdy00IGgtNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwXCI+U2VuZCBWaWEgV2hhdHNhcHA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhdmUgTGVhZFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIFVwZGF0ZSBMZWFkXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZX0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTGVhZCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmxlYWRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBHcm91cCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBMZWFkIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfcGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmxlYWRfcGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMZWFkIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9waG9uZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIExlYWQgV29yay9Qcm9mZXNzaW9ue1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IExlYWQgV29yay9Qcm9mZXNzaW9uIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfcHJvZmVzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5sZWFkX3Byb2Zlc3Npb24gfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwibGVhZF9wcm9mZXNzaW9uXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtbXCJFbXBsb3llZFwiLCBcIlNlbGYgRW1wbG95ZWRcIl0ubWFwKChsUHJvZikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2xQcm9mfSB2YWx1ZT17bFByb2YudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2xQcm9mfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfcHJvZmVzc2lvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9wcm9mZXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfaWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgR3JvdXA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5ncm91cF9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiZ3JvdXBfaWRcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBMZWFkIFNvdXJjZSBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5sZWFkX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgTGVhZCBTb3VyY2UgVHlwZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic29jaWFsXCI+U29jaWFsIE1lZGlhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjdXN0b21lclwiPkN1c3RvbWVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhZ2VudFwiPkVtcGxveWVlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ3YWxraW5cIj5XYWxraW48L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIExlYWQgU291cmNlIFR5cGUgXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5sZWFkX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJsZWFkX3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgIFwiU29jaWFsIE1lZGlhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkFnZW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkVtcGxveWVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIldhbGtpblwiLFxyXG4gICAgICAgICAgICAgICAgICAgIF0ubWFwKCh0eXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3R5cGV9IHZhbHVlPXt0eXBlLnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5sZWFkX3R5cGUgPT09IFwiY3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5sZWFkX2N1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQ3VzdG9tZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX2N1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5sZWFkX2N1c3RvbWVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJsZWFkX2N1c3RvbWVyXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9jdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEubGVhZF90eXBlID09PSBcImFnZW50XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBZ2VudHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9yIFNlYXJjaCBBZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfYWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRW5zdXJlIGJvdGggYXJlIHN0cmluZ3MgZm9yIGNvbXBhcmlzb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25UZXh0ID0gU3RyaW5nKG9wdGlvbj8uY2hpbGRyZW4gfHwgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9wdGlvblRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoU3RyaW5nKGlucHV0KS50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5sZWFkX2FnZW50IHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJsZWFkX2FnZW50XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXA/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX2FnZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9hZ2VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmxlYWRfdHlwZSA9PT0gXCJlbXBsb3llZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRW1wbG95ZWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmxlYWRfZW1wbG95ZWUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcImxlYWRfZW1wbG95ZWVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcD8ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfZW1wbG95ZWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX2VtcGxveWVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU3BlY2lmeSBub3RlIGlmIGFueSFcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTGVhZCBOZWVkcyBhbmQgR29hbHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX25lZWRzXCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5sZWFkX25lZWRzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IExlYWQgTmVlZHMgYW5kIEdvYWxzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzYXZpbmdzXCI+U2F2aW5nczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYm9ycm93aW5nc1wiPkJvcnJvd2luZ3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIExlYWQgTmVlZHMgYW5kIEdvYWxzIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfbmVlZHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmxlYWRfbmVlZHMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJsZWFkX25lZWRzXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJTYXZpbmdzXCIsIFwiQm9ycm93aW5nc1wiXS5tYXAoKHR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dHlwZX0gdmFsdWU9e3R5cGUudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX25lZWRzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfbmVlZHN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgVXBkYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgaXNWaXNpYmxlPXtsZWFkU2hvd01vZGFsfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRMZWFkU2hvd01vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgbGVhZERhdGE9e3NlbGVjdGVkTGVhZERhdGF9XHJcbiAgICAgICAgICAgIHNldFJlbG9hZFRyaWdnZXI9e3NldFJlbG9hZFRyaWdnZXJ9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgQ29udmVydCBMZWFkIHRvIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVDb252ZXJ0Q3VzdG9tZXJTdWJtaXR9XHJcbiAgICAgICAgICAgICAgICBub1ZhbGlkYXRlXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIExlYWQgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImZ1bGxfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBHcm91cCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZnVsbF9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBMZWFkIEVtYWlsIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTGVhZCBQaG9uZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMZWFkIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTGVhZCBXb3JrL1Byb2Zlc3Npb257XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTGVhZCBXb3JrL1Byb2Zlc3Npb24gXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9wcm9mZXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmxlYWRfcHJvZmVzc2lvbiB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwibGVhZF9wcm9mZXNzaW9uXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtbXCJFbXBsb3llZFwiLCBcIlNlbGYgRW1wbG95ZWRcIl0ubWFwKChsUHJvZikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2xQcm9mfSB2YWx1ZT17bFByb2YudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2xQcm9mfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICB7Lyoge2Vycm9ycy5sZWFkX3Byb2Zlc3Npb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9wcm9mZXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX0gKi99XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cCBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJncm91cF9pZFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5ncm91cF9pZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTGVhZCBTb3VyY2UgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9yIFNlYXJjaCBMZWFkIFNvdXJjZSBUeXBlIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF90eXBlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwibGVhZF90eXBlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlNvY2lhbCBNZWRpYVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJBZ2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJXYWxraW5cIixcclxuICAgICAgICAgICAgICAgICAgICBdLm1hcCgodHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0eXBlfSB2YWx1ZT17dHlwZS50b0xvd2VyQ2FzZSgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sZWFkX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7Zm9ybURhdGEubGVhZF90eXBlID09PSBcImN1c3RvbWVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lcnNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQ3VzdG9tZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibGVhZF9jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImxlYWRfY3VzdG9tZXJcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIHtlcnJvcnMubGVhZF9jdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfXtcIiBcIn1cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5sZWFkX3R5cGUgPT09IFwiYWdlbnRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFnZW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9yIFNlYXJjaCBBZ2VudCBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkX2FnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmxlYWRfYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJsZWFkX2FnZW50XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGVhZF9hZ2VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfYWdlbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQYXNzd29yZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGluY29kZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkZHJlc3MgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgJHtmaWVsZFNpemUuaGVpZ2h0fSBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgey8qIHtlcnJvcnMuYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmFkZHJlc3N9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX0gKi99XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGF5bWVudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBQYXltZW50IFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFBheW1lbnQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheW1lbnRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucGF5bWVudF90eXBlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicGF5bWVudF90eXBlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJEYWlseVwiLCBcIldlZWtseVwiLCBcIk1vbnRobHlcIl0ubWFwKChwVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtwVHlwZX0gdmFsdWU9e3BUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5bWVudF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFkaGFhcl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkaGFhciBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQYW4gTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucGFuX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhbiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhbl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5wYW5fbm99PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTm90ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNwZWNpZnkgbm90ZSBpZiBhbnkhXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJub19vZl90aWNrZXRzXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIgb2YgVGlja2V0cyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vX29mX3RpY2tldHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5vX29mX3RpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTnVtYmVyIG9mIFRpY2tldHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5vX29mX3RpY2tldHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5vX29mX3RpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTGVhZCBOZWVkcyBhbmQgR29hbHN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIExlYWQgTmVlZHMgYW5kIEdvYWxzIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYWRfbmVlZHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubGVhZF9uZWVkcyB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwibGVhZF9uZWVkc1wiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge1tcIlNhdmluZ3NcIiwgXCJCb3Jyb3dpbmdzXCJdLm1hcCgodHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3R5cGV9IHZhbHVlPXt0eXBlLnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfbmVlZHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxlYWRfbmVlZHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDb252ZXJ0IFRvIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBEZWxldGUgTGVhZFxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlR3JvdXAoKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRHcm91cC5sZWFkX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgTGVhZCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExlYWQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9MZWFkLmpzeCJ9