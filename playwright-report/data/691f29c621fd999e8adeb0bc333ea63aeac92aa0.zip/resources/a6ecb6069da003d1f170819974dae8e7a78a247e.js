import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/Datatable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import {
  Search,
  Download,
  Printer,
  ChevronLeft,
  ChevronRight,
  X,
  GripVertical
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import imageInput from "/src/assets/images/Agent.png?import";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Modal, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import logo from "/src/assets/images/mychits.png?import";
import { FaFileExcel } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { FaFilePdf } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport11_reactDom_server from "/node_modules/.vite/deps/react-dom_server.js?v=819e0a34"; const ReactDOMServer = __vite__cjsImport11_reactDom_server.__esModule ? __vite__cjsImport11_reactDom_server.default : __vite__cjsImport11_reactDom_server;
const DataTable = ({
  updateHandler = () => {
  },
  printHeaderValues = [],
  printHeaderKeys = [],
  catcher = "_id",
  isExportEnabled = true,
  isSearchRequired = true,
  data = [],
  columns = [],
  exportCols = [],
  exportedFileName = "export.csv",
  exportedPdfName = "export.pdf",
  createdDateColumn = "createdAt",
  pinnedRightColumns = null
  // array of colum keys to pin right
}) => {
  _s();
  const safeData = Array.isArray(data) ? data : [];
  const safeColumns = Array.isArray(columns) ? columns : [];
  const exportColumns = exportCols?.length <= 0 ? Array.isArray(columns) ? columns : [] : Array.isArray(exportCols) ? exportCols : [];
  const [currentPage, setCurrentPage] = useState(1);
  const [currentUserName, setCurrentUserName] = useState("System User");
  const [active, setActive] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({});
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const [pageSize, setPageSize] = useState(100);
  const [localData, setLocalData] = useState(safeData);
  const [draggedRowId, setDraggedRowId] = useState(null);
  const [dragOverRowId, setDragOverRowId] = useState(null);
  useEffect(() => {
    setLocalData(Array.isArray(data) ? data : []);
  }, [data]);
  const [columnOrder, setColumnOrder] = useState(
    safeColumns.map((col) => col.key)
  );
  const [draggedColumnKey, setDraggedColumnKey] = useState(null);
  const [dragOverColumnKey, setDragOverColumnKey] = useState(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportType, setExportType] = useState("excel");
  const [selectedExportColumns, setSelectedExportColumns] = useState(
    exportColumns.map((col) => col.key)
  );
  const defaultVisibleColumns = [
    ...safeColumns.map((col) => col.key)
  ];
  const [visibleColumns, setVisibleColumns] = useState(defaultVisibleColumns);
  const pinnedKeys = useMemo(() => {
    if (pinnedRightColumns && Array.isArray(pinnedRightColumns)) {
      return pinnedRightColumns;
    }
    const actionCol = safeColumns.find(
      (col) => col.key.toLowerCase() === "action" || col.header && ["action", "actions"].includes(col.header.toLowerCase().trim())
    );
    return actionCol ? [actionCol.key] : [];
  }, [pinnedRightColumns, safeColumns]);
  const isLongContentColumn = (header) => {
    const longContentHeaders = [
      "address",
      "description",
      "name",
      "customer name",
      "full name",
      "location",
      "details",
      "remarks",
      "notes",
      "comment",
      "comments"
    ];
    return longContentHeaders.some(
      (longHeader) => header.toLowerCase().includes(longHeader)
    );
  };
  const getColumnWidth = (column) => {
    if (column.width) {
      return typeof column.width === "number" ? `${column.width}px` : column.width;
    }
    if (isLongContentColumn(column.header)) {
      return "300px";
    }
    if (column.key.toLowerCase() === "action") {
      return "100px";
    }
    return "auto";
  };
  const getWidthInPx = (widthStr) => {
    if (typeof widthStr === "number") return widthStr;
    if (typeof widthStr === "string") {
      const num = parseFloat(widthStr);
      return isNaN(num) ? 100 : num;
    }
    return 100;
  };
  const isToday = (dateString) => {
    if (!dateString) return false;
    const date = new Date(dateString);
    const today = /* @__PURE__ */ new Date();
    date.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);
    return date.getTime() === today.getTime();
  };
  const toggleColumn = (key) => {
    if (visibleColumns.includes(key)) {
      setVisibleColumns(visibleColumns.filter((col) => col !== key));
    } else {
      setVisibleColumns([...visibleColumns, key]);
    }
  };
  useEffect(() => {
    const tempData = {};
    data.forEach((ele, index) => {
      tempData[ele._id] = false;
    });
    setActive(tempData);
  }, [data]);
  useEffect(() => {
    if (showExportModal) {
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = "";
      };
    }
  }, [showExportModal]);
  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      try {
        const userObj = JSON.parse(user);
        const name = userObj?.full_name || userObj?.name || userObj?.user?.full_name || userObj?.user?.name || "System User";
        setCurrentUserName(name);
      } catch (e) {
        console.error("Failed to parse user from localStorage:", e);
      }
    }
  }, []);
  const onSelectRow = (_id) => {
    const tempActive = active;
    if (Object.keys(active).length > 1) {
      Object.keys(active).forEach((key) => {
        tempActive[key] = false;
      });
      setActive({ ...tempActive, [_id]: true });
    }
  };
  const handleDragStart = (e, row) => {
    e.stopPropagation();
    setDraggedRowId(row[catcher]);
    try {
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", String(row[catcher]));
    } catch (err) {
    }
  };
  const handleDragOverRow = (e, row) => {
    e.preventDefault();
    if (draggedRowId != null && row[catcher] !== draggedRowId) {
      setDragOverRowId(row[catcher]);
    }
  };
  const handleDragLeaveRow = (row) => {
    setDragOverRowId((current) => current === row[catcher] ? null : current);
  };
  const handleDropRow = (e, targetRow) => {
    e.preventDefault();
    e.stopPropagation();
    if (draggedRowId == null || draggedRowId === targetRow[catcher]) {
      setDraggedRowId(null);
      setDragOverRowId(null);
      return;
    }
    setLocalData((prev) => {
      const updated = [...prev];
      const fromIndex = updated.findIndex((item) => item[catcher] === draggedRowId);
      const toIndex = updated.findIndex((item) => item[catcher] === targetRow[catcher]);
      if (fromIndex === -1 || toIndex === -1) return prev;
      const [movedItem] = updated.splice(fromIndex, 1);
      updated.splice(toIndex, 0, movedItem);
      return updated;
    });
    setSortConfig({ key: null, direction: "asc" });
    setDraggedRowId(null);
    setDragOverRowId(null);
  };
  const handleDragEndRow = () => {
    setDraggedRowId(null);
    setDragOverRowId(null);
  };
  const handleColumnDragStart = (e, column) => {
    e.stopPropagation();
    setDraggedColumnKey(column.key);
    try {
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", column.key);
    } catch (err) {
    }
  };
  const handleColumnDragOver = (e, column) => {
    e.preventDefault();
    e.stopPropagation();
    if (draggedColumnKey != null && column.key !== draggedColumnKey) {
      setDragOverColumnKey(column.key);
    }
  };
  const handleColumnDragLeave = (column) => {
    setDragOverColumnKey((current) => current === column.key ? null : current);
  };
  const handleColumnDrop = (e, targetColumn) => {
    e.preventDefault();
    e.stopPropagation();
    if (draggedColumnKey == null || draggedColumnKey === targetColumn.key) {
      setDraggedColumnKey(null);
      setDragOverColumnKey(null);
      return;
    }
    setColumnOrder((prev) => {
      const updated = [...prev];
      const fromIndex = updated.indexOf(draggedColumnKey);
      const toIndex = updated.indexOf(targetColumn.key);
      if (fromIndex === -1 || toIndex === -1) return prev;
      updated.splice(fromIndex, 1);
      updated.splice(toIndex, 0, draggedColumnKey);
      return updated;
    });
    setDraggedColumnKey(null);
    setDragOverColumnKey(null);
  };
  const handleColumnDragEnd = () => {
    setDraggedColumnKey(null);
    setDragOverColumnKey(null);
  };
  const searchData = (data2) => {
    if (!searchQuery) return data2;
    return data2.filter(
      (item) => Object.values(item).some(
        (value) => String(value).toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
  };
  const filterData = (data2) => {
    return data2.filter((item) => {
      return Object.entries(filters).every(([key, value]) => {
        if (!value) return true;
        return String(item[key]).toLowerCase() === value.toLowerCase();
      });
    });
  };
  const sortData = (data2) => {
    if (!sortConfig.key) return data2;
    return [...data2].sort((a, b) => {
      const aVal = a[sortConfig.key];
      const bVal = b[sortConfig.key];
      if (aVal < bVal) return sortConfig.direction === "asc" ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === "asc" ? 1 : -1;
      return 0;
    });
  };
  const processedData = useMemo(() => {
    let processed = [...localData];
    processed = searchData(processed);
    processed = filterData(processed);
    processed = sortData(processed);
    return processed;
  }, [localData, searchQuery, filters, sortConfig]);
  const totalPages = Math.ceil(processedData.length / pageSize);
  const paginatedData = processedData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );
  const getCellText = (value) => {
    if (React.isValidElement(value)) {
      const html = ReactDOMServer.renderToStaticMarkup(value);
      const div = document.createElement("div");
      div.innerHTML = html;
      return div.textContent || div.innerText || "";
    }
    return value ?? "";
  };
  const exportToExcel = () => {
    const now = /* @__PURE__ */ new Date();
    const fileNameExcel = `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}-${now.getFullYear()}_${String(now.getHours()).padStart(2, "0")}-${String(now.getMinutes()).padStart(2, "0")}-${String(now.getSeconds()).padStart(2, "0")}`;
    const selectedCols = exportColumns.filter(
      (col) => selectedExportColumns.includes(col.key) && col.header.toLowerCase() !== "action"
    );
    const headers = selectedCols.map((col) => col.header).join(",");
    const rows = processedData.map(
      (item) => selectedCols.map((col) => {
        const val = getCellText(item[col.key]);
        const clean = String(val ?? "-").replace(/"/g, '""');
        return `"${clean}"`;
      }).join(",")
    ).join("\n");
    const csv = `${headers}
${rows}`;
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const fileBaseName = exportedFileName.replace(/\.csv$/i, "").trim();
    a.download = `${fileBaseName}_${fileNameExcel}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    setShowExportModal(false);
  };
  const handleColumnSelection = (columnKey, isChecked) => {
    if (isChecked) {
      setSelectedExportColumns([...selectedExportColumns, columnKey]);
    } else {
      setSelectedExportColumns(
        selectedExportColumns.filter((key) => key !== columnKey)
      );
    }
  };
  const handleSelectAll = (isChecked) => {
    if (isChecked) {
      setSelectedExportColumns(exportColumns.map((col) => col.key));
    } else {
      setSelectedExportColumns([]);
    }
  };
  const changeColor = (index) => {
    return index % 2 === 0;
  };
  const printToPDF = () => {
    let showSummaryCards = true;
    let showCountCards = true;
    const date = `${String((/* @__PURE__ */ new Date()).getDate()).padStart(2, "0")}-${String((/* @__PURE__ */ new Date()).getMonth() + 1).padStart(2, "0")}-${(/* @__PURE__ */ new Date()).getFullYear()}_${String((/* @__PURE__ */ new Date()).getHours()).padStart(2, "0")}-${String((/* @__PURE__ */ new Date()).getMinutes()).padStart(2, "0")}-${String((/* @__PURE__ */ new Date()).getSeconds()).padStart(2, "0")}`;
    const reportType = String(exportedPdfName || "").trim();
    const fileName = `${reportType}_${date}`;
    switch (reportType) {
      case "Groups":
      case "Customers":
      case "UnApproved Customer":
      case "Enrollments":
      case "Staff":
      case "Agents":
      case "Employees":
      case "Leads":
      case "Loans":
      case "Pigme":
      case "Auction":
      case "Chit Payments":
      case "Mobile App Enrollments":
      case "Guarantor":
      case "Tasks":
      case "All Customer Report":
      case "Group Report":
      case "Basic Group Report":
      case "Enrollment Report":
      case "Customer Report":
      case "Customer Ledger Report":
      case "Customer Payout Report":
      case "Employee Report":
      case "Commission Report":
      case "Auction Report":
      case "Lead Report":
      case "Pigme Report":
      case "Loan Report":
      case "Sales Report":
      case "Date-wise Group Report":
      case "Payment Summary Report":
      case "Collection Area":
      case "Dream Asset":
      case "Agent Approval":
        showSummaryCards = false;
        showCountCards = false;
        break;
      case "Daybook Report":
      case "Receipt Report":
        showSummaryCards = true;
        showCountCards = true;
        break;
      default:
        showSummaryCards = false;
        showCountCards = false;
        break;
    }
    const selectedCols = exportColumns.filter(
      (col) => selectedExportColumns.includes(col.key) && col.key.toLowerCase() !== "action"
    );
    const printContent = document.createElement("div");
    const now = /* @__PURE__ */ new Date();
    const dateTimeString = now.toLocaleString("en-IN", {
      dateStyle: "medium",
      timeStyle: "short"
    });
    const totalAmount = processedData.reduce((sum, row) => {
      const amount = parseFloat(row.amount || row.Amount || 0);
      return sum + (isNaN(amount) ? 0 : amount);
    }, 0);
    const totalCash = processedData.filter((row) => row.mode?.toLowerCase() === "cash").reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const totalOnline = processedData.filter((row) => row.mode?.toLowerCase() === "online").reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const totalCustomers = new Set(
      processedData.map((row) => row.name || row.user_id?.full_name)
    ).size;
    const totalOnlineCount = processedData.filter(
      (row) => row.mode?.toLowerCase() === "online"
    ).length;
    const totalCashCount = processedData.filter(
      (row) => row.mode?.toLowerCase() === "cash"
    ).length;
    const isSpecialReport = reportType.toLowerCase().includes("daybook") || reportType.toLowerCase().includes("receipt report");
    let totalInOutRowHtml = "";
    let remainingCardsHtml = "";
    if (isSpecialReport && printHeaderKeys.length >= 2) {
      totalInOutRowHtml = `
        <div style="display: flex; gap: 20px; justify-content: space-between; margin-bottom: 24px;">
          <div class="card" style="flex: 1; margin: 0;">
            <div class="card-title">${printHeaderKeys[0]}</div>
            <div class="card-value">${printHeaderValues[0]}</div>
          </div>
          <div class="card" style="flex: 1; margin: 0;">
            <div class="card-title">${printHeaderKeys[1]}</div>
            <div class="card-value">${printHeaderValues[1]}</div>
          </div>
        </div>
      `;
      if (printHeaderKeys.length > 2) {
        const remainingKeys = printHeaderKeys.slice(2);
        const remainingValues = printHeaderValues.slice(2);
        remainingCardsHtml = `
          <div class="info-grid">
            ${remainingKeys.map(
          (key, idx) => `
                  <div class="card">
                    <div class="card-title">${key}</div>
                    <div class="card-value">${remainingValues[idx]}</div>
                  </div>
                `
        ).join("")}
          </div>
        `;
      }
    } else {
      remainingCardsHtml = `
        <div class="info-grid">
          ${printHeaderKeys.map(
        (key, i) => `
              <div class="card">
                <div class="card-title">${key}</div>
                <div class="card-value">${printHeaderValues[i]}</div>
              </div>
            `
      ).join("")}
        </div>
      `;
    }
    printContent.innerHTML = `
      <style>
        @media print {
          body * { visibility: hidden; }
          .printable, .printable * { visibility: visible; }
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 13px; color: #333; margin: 0; }
          .printable { position: absolute; top: 0; left: 0; width: 100%; padding: 30px 40px; background: #fff; box-sizing: border-box; }
          .a4-border { border: 1px solid #d2d6dc; border-radius: 10px; padding: 20px; height: 100%; background-color: #ffffff; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
          .header-wrapper { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 10px; border-bottom: 1px solid #e5e7eb; }
          .logo-image { width: 260px; height: 130px; object-fit: contain; border-radius: 6px; }
          .title-block { max-width: 600px; font-family: Arial, sans-serif; line-height: 1.5; }
          .title { font-size: 20px; font-weight: 700; color: #222; margin-bottom: 6px; }
          .sub-title { font-size: 14px; color: #555; margin-bottom: 8px; }
          .address { font-size: 14px; color: #666; }
          .report-heading { text-align: center; font-size: 22px; font-weight: 600; color: #111827; margin: 20px 0 6px; padding: 10px 0; background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; letter-spacing: 0.8px; }
          .report-date { text-align: center; font-size: 12px; color: #6b7280; margin-bottom: 20px; }
          .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; margin-bottom: 20px; }
          .info-grid h3 { font-size: 13px; margin: 4px 0; color: #374151; font-weight: 500; }
          .summary-cards { display: flex; gap: 14px; margin: 10px 0 24px; }
          .card { flex: 1; border-radius: 8px; text-align: center; padding: 14px 12px; background-color: #f8fafc; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
          .card-title { font-size: 14px; color: #4b5563; margin: 0; font-weight: 600; }
          .card-value { font-size: 18px; font-weight: bold; color: #0f172a; margin-top: 4px; }
          .count-summary-cards { display: flex; gap: 14px; margin: 16px 0 20px; }
          .count-card { flex: 1; padding: 14px 12px; border-radius: 8px; text-align: center; font-weight: 600; background: #f8fafc; border: 1px solid #e2e8f0; }
          .count-card.customer { background-color: #fef3c7; color: #92400e; }
          .count-card.cash { background-color: #bbf7d0; color: #047857; }
          .count-card.online { background-color: #dbeafe; color: #1e40af; }
          .count-card span { font-size: 18px; font-weight: bold; display: block; margin-top: 4px; }
          table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 12.5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 6px; overflow: hidden; }
          th { background-color: #eff6ff; color: #1e40af; font-weight: 600; padding: 10px 8px; border-bottom: 2px solid #bfdbfe; }
          td { padding: 8px; border-bottom: 1px solid #e2e8f0; color: #334155; }
          tr:nth-child(even) { background-color: #f9fafb; }
          tr:hover { background-color: #f1f5f9; }
          .signatures { margin-top: 36px; display: flex; justify-content: space-between; font-size: 13px; color: #1f2937; }
          .footer { font-size: 11px; color: #6b7280; text-align: center; margin-top: 30px; font-style: italic; }
        }
      </style>

      <div class="printable">
        <div class="a4-border">
          <div class="header-wrapper">
            ${imageInput ? `<img src="${imageInput}" class="logo-image" alt="Logo" />` : ""}
            <div class="title-block">
              <div class="title">VIJAYA VINAYAK CHITFUNDS PRIVATE LIMITED</div>
              <div class="sub-title">CIN: U65999KA2022PTC161858</div>
              <div class="address">
                No 11/36-25, 2nd Main, Kathriguppe Main Road,<br>
                Bangalore, Karnataka, India - 560070
              </div>
            </div>
          </div>

          <div class="report-heading">${reportType || "Transaction Summary Report"}</div>
          <div class="report-date">${dateTimeString}</div>

          ${isSpecialReport ? totalInOutRowHtml : ""}
          ${remainingCardsHtml}

          <table style="width: 100%; border-collapse: collapse;">
            <thead>
              <tr>
                ${selectedCols.map(
      (col) => `<th style="border: 1px solid #e2e8f0; padding: 6px; text-align: left;">${col.header}</th>`
    ).join("")}
              </tr>
            </thead>
            <tbody>
              ${processedData.map(
      (row) => `
                  <tr>
                    ${selectedCols.map((col) => {
        const val = getCellText(row[col.key]);
        return `<td style="border: 1px solid #e2e8f0; padding: 6px;">${val || "-"}</td>`;
      }).join("")}
                  </tr>`
    ).join("")}
            </tbody>
          </table>

          <div class="signatures">
            <div><strong>Issued By: </strong>${currentUserName}</div>
          </div>

          <div class="footer">
            <span class="auto-note">*** This is a computer generated document, no signature is required ***</span>
          </div>
        </div>
      </div>
    `;
    if (imageInput) {
      const img = new Image();
      img.src = imageInput;
      img.onload = () => {
        document.body.appendChild(printContent);
        document.title = fileName || "MyChits";
        window.print();
        document.body.removeChild(printContent);
        document.title = "MyChits";
        setShowExportModal(false);
      };
    } else {
      document.body.appendChild(printContent);
      document.title = fileName || "MyChits";
      window.print();
      document.body.removeChild(printContent);
      document.title = "MyChits";
      setShowExportModal(false);
    }
  };
  const handleSort = (key) => {
    setSortConfig((current) => ({
      key,
      direction: current.key === key && current.direction === "asc" ? "desc" : "asc"
    }));
  };
  const orderedSafeColumns = useMemo(() => {
    const byKey = new Map(safeColumns.map((col) => [col.key, col]));
    const known = columnOrder.filter((key) => byKey.has(key)).map((key) => byKey.get(key));
    const unknownCols = safeColumns.filter(
      (col) => !columnOrder.includes(col.key)
    );
    return [...known, ...unknownCols];
  }, [safeColumns, columnOrder]);
  const visibleColumnsSet = new Set(visibleColumns);
  const visibleSafeColumns = orderedSafeColumns.filter(
    (col) => visibleColumnsSet.has(col.key)
  );
  const regularColumns = visibleSafeColumns.filter(
    (col) => !pinnedKeys.includes(col.key)
  );
  const pinnedColumns = visibleSafeColumns.filter(
    (col) => pinnedKeys.includes(col.key)
  );
  const orderedColumns = [...regularColumns, ...pinnedColumns];
  const pinnedWidths = pinnedColumns.map((col) => getWidthInPx(getColumnWidth(col)));
  let cumulativeOffset = 0;
  const pinnedOffsets = pinnedColumns.map((col, index) => {
    const reversedIndex = pinnedColumns.length - 1 - index;
    const offset = cumulativeOffset;
    cumulativeOffset += pinnedWidths[reversedIndex];
    return { key: col.key, offset };
  });
  const offsetMap = {};
  pinnedOffsets.forEach((item) => {
    offsetMap[item.key] = item.offset;
  });
  if (!safeData.length || !safeColumns.length) {
    return /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
      lineNumber: 725,
      columnNumber: 12
    }, this);
  }
  const handleSelectAllColumns = (checked) => {
    if (checked) {
      setVisibleColumns(safeColumns.map((col) => col.key));
    } else {
      setVisibleColumns([]);
    }
  };
  const allColumnsSelected = visibleColumns.length === safeColumns.length && safeColumns.length > 0;
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-white rounded-lg shadow-md p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: `flex flex-col sm:flex-row items-center gap-4 mb-6 ${isSearchRequired ? "justify-between" : "justify-end"}`, children: [
      isSearchRequired && /* @__PURE__ */ jsxDEV("div", { className: "relative w-full sm:w-64", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 744,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-3 top-2.5 w-5 h-5 text-gray-400" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
          lineNumber: 751,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 743,
        columnNumber: 9
      }, this),
      isExportEnabled && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 w-full sm:w-auto", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setExportType("excel");
              setShowExportModal(true);
            },
            className: "flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-green-600 hover:bg-green-700 text-white transition-all duration-200 shadow-sm hover:shadow-md font-medium w-full sm:w-auto",
            children: [
              /* @__PURE__ */ jsxDEV(FaFileExcel, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 763,
                columnNumber: 15
              }, this),
              "Export Excel"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 756,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setExportType("pdf");
              setShowExportModal(true);
            },
            className: "flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white transition-all duration-200 shadow-sm hover:shadow-md font-medium w-full sm:w-auto",
            children: [
              /* @__PURE__ */ jsxDEV(FaFilePdf, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 773,
                columnNumber: 15
              }, this),
              "Print PDF"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 766,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 755,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
      lineNumber: 741,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-semibold text-gray-800 border-b pb-2", children: [
          "Select Columns to ",
          exportType === "excel" ? "Export" : "Print"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
          lineNumber: 782,
          columnNumber: 9
        }, this),
        open: showExportModal,
        onCancel: () => setShowExportModal(false),
        footer: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowExportModal(false),
              className: "px-5 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-all duration-200 font-medium mr-2",
              children: "Cancel"
            },
            "cancel",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
              lineNumber: 789,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                if (exportType === "excel") {
                  exportToExcel();
                } else {
                  printToPDF();
                }
              },
              disabled: selectedExportColumns.length === 0,
              className: `px-5 py-2.5 text-white rounded-lg disabled:bg-gray-300 disabled:cursor-not-allowed transition-all duration-200 font-medium ${exportType === "excel" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}`,
              children: exportType === "excel" ? "Export" : "Print PDF"
            },
            "export",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
              lineNumber: 796,
              columnNumber: 9
            },
            this
          )
        ],
        width: 600,
        className: "export-modal",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-3 bg-gray-50 rounded-lg", children: /* @__PURE__ */ jsxDEV("label", { className: "flex items-center space-x-3 ml-3 cursor-pointer hover:bg-gray-100 rounded transition-colors", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                checked: selectedExportColumns.length === exportColumns.length,
                onChange: (e) => handleSelectAll(e.target.checked),
                className: "w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 819,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Select All" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
              lineNumber: 825,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 818,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 817,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-0 max-h-60 overflow-y-auto pr-2", children: exportColumns.map(
            (column) => /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors",
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "checkbox",
                      checked: selectedExportColumns.includes(column.key),
                      onChange: (e) => handleColumnSelection(column.key, e.target.checked),
                      className: "w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                      lineNumber: 835,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: column.header }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                    lineNumber: 843,
                    columnNumber: 15
                  }, this)
                ]
              },
              column.key,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 831,
                columnNumber: 11
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 829,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 780,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 p-3 bg-blue-50 border border-blue-100 rounded-lg mb-4", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-blue-800 self-center", children: "Columns:" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 850,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-1 ml-4 text-xs bg-white px-2 py-1 rounded-full border border-blue-200 cursor-pointer hover:bg-blue-100 transition-colors", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: allColumnsSelected,
            onChange: (e) => handleSelectAllColumns(e.target.checked),
            className: "w-3 h-3 text-blue-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 855,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 font-medium", children: "Select All" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
          lineNumber: 861,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 854,
        columnNumber: 9
      }, this),
      safeColumns.map(
        (column) => /* @__PURE__ */ jsxDEV(
          "label",
          {
            className: "flex items-center gap-1 text-xs bg-white px-2 py-1 rounded-full border border-blue-200 cursor-pointer hover:bg-blue-100 transition-colors",
            children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: visibleColumns.includes(column.key),
                  onChange: () => toggleColumn(column.key),
                  className: "w-3 h-3 text-blue-600 rounded focus:ring-blue-500"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                  lineNumber: 869,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: column.header }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 875,
                columnNumber: 13
              }, this)
            ]
          },
          column.key,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 865,
            columnNumber: 9
          },
          this
        )
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
      lineNumber: 849,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 rounded-lg shadow-sm overflow-hidden", children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "relative",
        style: {
          maxHeight: "500px",
          overflowY: "auto",
          overflowX: "auto"
        },
        children: /* @__PURE__ */ jsxDEV(
          "table",
          {
            className: "divide-y divide-gray-200",
            style: {
              minWidth: "100%",
              tableLayout: "fixed"
            },
            children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 sticky top-0 z-20", children: [
                /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "th",
                    {
                      className: "px-2 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider",
                      style: { width: "36px", minWidth: "36px" },
                      title: "Drag rows to reorder"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                      lineNumber: 899,
                      columnNumber: 17
                    },
                    this
                  ),
                  orderedColumns.map((column) => {
                    const isPinned = pinnedKeys.includes(column.key);
                    const rightOffset = isPinned ? offsetMap[column.key] : void 0;
                    const isColumnDragged = draggedColumnKey === column.key;
                    const isColumnDropTarget = dragOverColumnKey === column.key;
                    const style = {
                      width: getColumnWidth(column),
                      minWidth: isLongContentColumn(column.header) ? "200px" : "100px",
                      position: isPinned ? "sticky" : "static",
                      right: isPinned ? `${rightOffset}px` : "auto",
                      zIndex: isPinned ? 3 : 1,
                      background: isPinned ? "#eff6ff" : void 0
                      // match header background
                    };
                    return /* @__PURE__ */ jsxDEV(
                      "th",
                      {
                        className: `px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider cursor-pointer hover:bg-blue-100 transition-colors ${isColumnDragged ? "opacity-40" : ""} ${isColumnDropTarget ? "border-l-2 border-blue-500" : ""}`,
                        style,
                        onClick: () => handleSort(column.key),
                        draggable: !isPinned,
                        onDragStart: (e) => !isPinned && handleColumnDragStart(e, column),
                        onDragOver: (e) => !isPinned && handleColumnDragOver(e, column),
                        onDragLeave: () => !isPinned && handleColumnDragLeave(column),
                        onDrop: (e) => !isPinned && handleColumnDrop(e, column),
                        onDragEnd: handleColumnDragEnd,
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
                          !isPinned && /* @__PURE__ */ jsxDEV(GripVertical, { className: "w-3 h-3 text-gray-400 cursor-move flex-shrink-0" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                            lineNumber: 940,
                            columnNumber: 25
                          }, this),
                          column.header,
                          sortConfig.key === column.key && /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600", children: sortConfig.direction === "asc" ? "↑" : "↓" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                            lineNumber: 944,
                            columnNumber: 25
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                          lineNumber: 938,
                          columnNumber: 23
                        }, this)
                      },
                      column.key,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                        lineNumber: 920,
                        columnNumber: 21
                      },
                      this
                    );
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                  lineNumber: 897,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("th", { style: { width: "36px", minWidth: "36px" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                    lineNumber: 955,
                    columnNumber: 17
                  }, this),
                  orderedColumns.map((column) => {
                    const isPinned = pinnedKeys.includes(column.key);
                    const rightOffset = isPinned ? offsetMap[column.key] : void 0;
                    const style = {
                      width: getColumnWidth(column),
                      minWidth: isLongContentColumn(column.header) ? "200px" : "100px",
                      position: isPinned ? "sticky" : "static",
                      right: isPinned ? `${rightOffset}px` : "auto",
                      zIndex: isPinned ? 2 : 1,
                      background: isPinned ? "#f9fafb" : void 0
                    };
                    return /* @__PURE__ */ jsxDEV(
                      "th",
                      {
                        className: "px-6 py-3",
                        style,
                        children: column.key.toLowerCase() !== "action" && /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            className: "w-full",
                            popupMatchSelectWidth: false,
                            showSearch: true,
                            value: filters[column.key] || "",
                            onChange: (value) => setFilters((prev) => ({
                              ...prev,
                              [column.key]: value
                            })),
                            filterOption: (input, option) => {
                              const label = option?.children?.toString().toLowerCase() || "";
                              return label.includes(input.toLowerCase());
                            },
                            children: [
                              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                                lineNumber: 991,
                                columnNumber: 27
                              }, this),
                              [...new Set(safeData.map((item) => item[column.key]))].map(
                                (value) => /* @__PURE__ */ jsxDEV(Select.Option, { value: String(value), children: value }, String(value), false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                                  lineNumber: 994,
                                  columnNumber: 27
                                }, this)
                              )
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                            lineNumber: 974,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      `filter-${column.key}`,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                        lineNumber: 968,
                        columnNumber: 21
                      },
                      this
                    );
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                  lineNumber: 953,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 896,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: paginatedData.map((row, index) => {
                const isCreatedToday = isToday(row[createdDateColumn]);
                const isBeingDragged = draggedRowId === row[catcher];
                const isDropTarget = dragOverRowId === row[catcher];
                return /* @__PURE__ */ jsxDEV(
                  "tr",
                  {
                    onClick: () => onSelectRow(row._id),
                    onDragOver: (e) => handleDragOverRow(e, row),
                    onDragLeave: () => handleDragLeaveRow(row),
                    onDrop: (e) => handleDropRow(e, row),
                    className: `${active[row._id] ? "bg-blue-100" : isCreatedToday ? "bg-green-50 border-l-4 border-green-500" : index % 2 === 0 ? "bg-white hover:bg-gray-50" : "bg-gray-50 hover:bg-gray-100"} ${isBeingDragged ? "opacity-40" : ""} ${isDropTarget ? "border-t-2 border-blue-500" : ""} cursor-pointer transition-colors duration-150`,
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        "td",
                        {
                          className: "px-2 py-4 text-gray-400 hover:text-gray-600",
                          style: { width: "36px", minWidth: "36px" },
                          draggable: true,
                          onClick: (e) => e.stopPropagation(),
                          onDragStart: (e) => handleDragStart(e, row),
                          onDragEnd: handleDragEndRow,
                          title: "Drag to reorder",
                          children: /* @__PURE__ */ jsxDEV(GripVertical, { className: "w-4 h-4 cursor-move" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                            lineNumber: 1039,
                            columnNumber: 23
                          }, this)
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                          lineNumber: 1030,
                          columnNumber: 21
                        },
                        this
                      ),
                      orderedColumns.map((column) => {
                        const isPinned = pinnedKeys.includes(column.key);
                        const rightOffset = isPinned ? offsetMap[column.key] : void 0;
                        const style = {
                          width: getColumnWidth(column),
                          minWidth: isLongContentColumn(column.header) ? "200px" : "100px",
                          wordWrap: "break-word",
                          whiteSpace: "normal",
                          maxWidth: isLongContentColumn(column.header) ? "300px" : "none",
                          position: isPinned ? "sticky" : "static",
                          right: isPinned ? `${rightOffset}px` : "auto",
                          zIndex: isPinned ? 2 : 1,
                          background: isPinned ? index % 2 === 0 ? "#ffffff" : "#f9fafb" : void 0
                        };
                        return /* @__PURE__ */ jsxDEV(
                          "td",
                          {
                            className: "px-6 py-4 text-sm text-gray-900",
                            style,
                            onDoubleClick: () => updateHandler(row[catcher]),
                            children: row[column.key]
                          },
                          `${index}-${column.key}`,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                            lineNumber: 1056,
                            columnNumber: 25
                          },
                          this
                        );
                      })
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                    lineNumber: 1012,
                    columnNumber: 19
                  },
                  this
                );
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 1006,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 889,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 881,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
      lineNumber: 880,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row justify-between items-center mt-6 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 relative", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: "Show" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
          lineNumber: 1076,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: pageSize,
            onChange: (value) => setPageSize(Number(value)),
            className: "w-20",
            size: "middle",
            getPopupContainer: (triggerNode) => triggerNode.parentElement,
            children: [5, 10, 20, 50, 100].map(
              (size) => /* @__PURE__ */ jsxDEV(Select.Option, { value: size, children: size }, size, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
                lineNumber: 1085,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 1077,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: "entries" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
          lineNumber: 1090,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 1075,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setCurrentPage((prev) => Math.max(1, prev - 1)),
            disabled: currentPage === 1,
            className: "p-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200",
            children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "w-5 h-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
              lineNumber: 1099,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 1094,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700 px-3 py-1", children: [
          "Page ",
          currentPage,
          " of ",
          Math.max(1, totalPages)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
          lineNumber: 1101,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setCurrentPage((prev) => Math.min(totalPages, prev + 1)),
            disabled: currentPage === totalPages || totalPages === 0,
            className: "p-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200",
            children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-5 h-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
              lineNumber: 1111,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
            lineNumber: 1104,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
        lineNumber: 1093,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
      lineNumber: 1074,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx",
    lineNumber: 740,
    columnNumber: 5
  }, this);
};
_s(DataTable, "aq1q1+2nmFVOOoMjEkYsP+7AxQ0=");
_c = DataTable;
export default DataTable;
var _c;
$RefreshReg$(_c, "DataTable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Datatable.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb3RCVzsyQkFwdEJYO0FBQWdCQSxNQUFVQyxjQUFTQyxPQUFTLHNCQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsT0FBT0MsY0FBYztBQUM5QixPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0Msb0JBQW9CO0FBRTNCLE1BQU1DLFlBQVlBLENBQUM7QUFBQSxFQUNqQkMsZ0JBQWdCQSxNQUFNO0FBQUEsRUFBRTtBQUFBLEVBQ3hCQyxvQkFBb0I7QUFBQSxFQUNwQkMsa0JBQWtCO0FBQUEsRUFDbEJDLFVBQVU7QUFBQSxFQUNWQyxrQkFBa0I7QUFBQSxFQUNsQkMsbUJBQW1CO0FBQUEsRUFDbkJDLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQUEsRUFDVkMsYUFBYTtBQUFBLEVBQ2JDLG1CQUFtQjtBQUFBLEVBQ25CQyxrQkFBa0I7QUFBQSxFQUNsQkMsb0JBQW9CO0FBQUEsRUFDcEJDLHFCQUFxQjtBQUFBO0FBQ3ZCLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU1DLFdBQVdDLE1BQU1DLFFBQVFWLElBQUksSUFBSUEsT0FBTztBQUM5QyxRQUFNVyxjQUFjRixNQUFNQyxRQUFRVCxPQUFPLElBQUlBLFVBQVU7QUFDdkQsUUFBTVcsZ0JBQ0pWLFlBQVlXLFVBQVUsSUFDbEJKLE1BQU1DLFFBQVFULE9BQU8sSUFDbkJBLFVBQ0EsS0FDRlEsTUFBTUMsUUFBUVIsVUFBVSxJQUN0QkEsYUFDQTtBQUVSLFFBQU0sQ0FBQ1ksYUFBYUMsY0FBYyxJQUFJeEMsU0FBUyxDQUFDO0FBQ2hELFFBQU0sQ0FBQ3lDLGlCQUFpQkMsa0JBQWtCLElBQUkxQyxTQUFTLGFBQWE7QUFDcEUsUUFBTSxDQUFDMkMsUUFBUUMsU0FBUyxJQUFJNUMsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDNkMsYUFBYUMsY0FBYyxJQUFJOUMsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQytDLFNBQVNDLFVBQVUsSUFBSWhELFNBQVMsQ0FBQyxDQUFDO0FBQ3pDLFFBQU0sQ0FBQ2lELFlBQVlDLGFBQWEsSUFBSWxELFNBQVMsRUFBRW1ELEtBQUssTUFBTUMsV0FBVyxNQUFNLENBQUM7QUFDNUUsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUl0RCxTQUFTLEdBQUc7QUFPNUMsUUFBTSxDQUFDdUQsV0FBV0MsWUFBWSxJQUFJeEQsU0FBU2lDLFFBQVE7QUFDbkQsUUFBTSxDQUFDd0IsY0FBY0MsZUFBZSxJQUFJMUQsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzJELGVBQWVDLGdCQUFnQixJQUFJNUQsU0FBUyxJQUFJO0FBRXZERSxZQUFVLE1BQU07QUFDZHNELGlCQUFhdEIsTUFBTUMsUUFBUVYsSUFBSSxJQUFJQSxPQUFPLEVBQUU7QUFBQSxFQUM5QyxHQUFHLENBQUNBLElBQUksQ0FBQztBQU1ULFFBQU0sQ0FBQ29DLGFBQWFDLGNBQWMsSUFBSTlEO0FBQUFBLElBQ3BDb0MsWUFBWTJCLElBQUksQ0FBQ0MsUUFBUUEsSUFBSWIsR0FBRztBQUFBLEVBQ2xDO0FBQ0EsUUFBTSxDQUFDYyxrQkFBa0JDLG1CQUFtQixJQUFJbEUsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQ21FLG1CQUFtQkMsb0JBQW9CLElBQUlwRSxTQUFTLElBQUk7QUFHL0QsUUFBTSxDQUFDcUUsaUJBQWlCQyxrQkFBa0IsSUFBSXRFLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUN1RSxZQUFZQyxhQUFhLElBQUl4RSxTQUFTLE9BQU87QUFDcEQsUUFBTSxDQUFDeUUsdUJBQXVCQyx3QkFBd0IsSUFBSTFFO0FBQUFBLElBQ3hEcUMsY0FBYzBCLElBQUksQ0FBQ0MsUUFBUUEsSUFBSWIsR0FBRztBQUFBLEVBQ3BDO0FBR0EsUUFBTXdCLHdCQUF3QjtBQUFBLElBQzVCLEdBQUd2QyxZQUFZMkIsSUFBSSxDQUFDQyxRQUFRQSxJQUFJYixHQUFHO0FBQUEsRUFBQztBQUd0QyxRQUFNLENBQUN5QixnQkFBZ0JDLGlCQUFpQixJQUFJN0UsU0FBUzJFLHFCQUFxQjtBQUsxRSxRQUFNRyxhQUFhN0UsUUFBUSxNQUFNO0FBQy9CLFFBQUk4QixzQkFBc0JHLE1BQU1DLFFBQVFKLGtCQUFrQixHQUFHO0FBQzNELGFBQU9BO0FBQUFBLElBQ1Q7QUFDQSxVQUFNZ0QsWUFBWTNDLFlBQVk0QztBQUFBQSxNQUM1QixDQUFDaEIsUUFDQ0EsSUFBSWIsSUFBSThCLFlBQVksTUFBTSxZQUN6QmpCLElBQUlrQixVQUFVLENBQUMsVUFBVSxTQUFTLEVBQUVDLFNBQVNuQixJQUFJa0IsT0FBT0QsWUFBWSxFQUFFRyxLQUFLLENBQUM7QUFBQSxJQUNqRjtBQUNBLFdBQU9MLFlBQVksQ0FBQ0EsVUFBVTVCLEdBQUcsSUFBSTtBQUFBLEVBQ3ZDLEdBQUcsQ0FBQ3BCLG9CQUFvQkssV0FBVyxDQUFDO0FBR3BDLFFBQU1pRCxzQkFBc0JBLENBQUNILFdBQVc7QUFDdEMsVUFBTUkscUJBQXFCO0FBQUEsTUFDekI7QUFBQSxNQUFXO0FBQUEsTUFBZTtBQUFBLE1BQVE7QUFBQSxNQUFpQjtBQUFBLE1BQ25EO0FBQUEsTUFBWTtBQUFBLE1BQVc7QUFBQSxNQUFXO0FBQUEsTUFBUztBQUFBLE1BQVc7QUFBQSxJQUFVO0FBRWxFLFdBQU9BLG1CQUFtQkM7QUFBQUEsTUFBSyxDQUFBQyxlQUM3Qk4sT0FBT0QsWUFBWSxFQUFFRSxTQUFTSyxVQUFVO0FBQUEsSUFDMUM7QUFBQSxFQUNGO0FBR0EsUUFBTUMsaUJBQWlCQSxDQUFDQyxXQUFXO0FBQ2pDLFFBQUlBLE9BQU9DLE9BQU87QUFDaEIsYUFBTyxPQUFPRCxPQUFPQyxVQUFVLFdBQVcsR0FBR0QsT0FBT0MsS0FBSyxPQUFPRCxPQUFPQztBQUFBQSxJQUN6RTtBQUNBLFFBQUlOLG9CQUFvQkssT0FBT1IsTUFBTSxHQUFHO0FBQ3RDLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSVEsT0FBT3ZDLElBQUk4QixZQUFZLE1BQU0sVUFBVTtBQUN6QyxhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBR0EsUUFBTVcsZUFBZUEsQ0FBQ0MsYUFBYTtBQUNqQyxRQUFJLE9BQU9BLGFBQWEsU0FBVSxRQUFPQTtBQUN6QyxRQUFJLE9BQU9BLGFBQWEsVUFBVTtBQUNoQyxZQUFNQyxNQUFNQyxXQUFXRixRQUFRO0FBQy9CLGFBQU9HLE1BQU1GLEdBQUcsSUFBSSxNQUFNQTtBQUFBQSxJQUM1QjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTUcsVUFBVUEsQ0FBQ0MsZUFBZTtBQUM5QixRQUFJLENBQUNBLFdBQVksUUFBTztBQUN4QixVQUFNQyxPQUFPLElBQUlDLEtBQUtGLFVBQVU7QUFDaEMsVUFBTUcsUUFBUSxvQkFBSUQsS0FBSztBQUN2QkQsU0FBS0csU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQ3hCRCxVQUFNQyxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDekIsV0FBT0gsS0FBS0ksUUFBUSxNQUFNRixNQUFNRSxRQUFRO0FBQUEsRUFDMUM7QUFFQSxRQUFNQyxlQUFlQSxDQUFDckQsUUFBUTtBQUM1QixRQUFJeUIsZUFBZU8sU0FBU2hDLEdBQUcsR0FBRztBQUNoQzBCLHdCQUFrQkQsZUFBZTZCLE9BQU8sQ0FBQ3pDLFFBQVFBLFFBQVFiLEdBQUcsQ0FBQztBQUFBLElBQy9ELE9BQU87QUFDTDBCLHdCQUFrQixDQUFDLEdBQUdELGdCQUFnQnpCLEdBQUcsQ0FBQztBQUFBLElBQzVDO0FBQUEsRUFDRjtBQUVBakQsWUFBVSxNQUFNO0FBQ2QsVUFBTXdHLFdBQVcsQ0FBQztBQUNsQmpGLFNBQUtrRixRQUFRLENBQUNDLEtBQUtDLFVBQVU7QUFDM0JILGVBQVNFLElBQUlFLEdBQUcsSUFBSTtBQUFBLElBQ3RCLENBQUM7QUFDRGxFLGNBQVU4RCxRQUFRO0FBQUEsRUFDcEIsR0FBRyxDQUFDakYsSUFBSSxDQUFDO0FBRVR2QixZQUFVLE1BQU07QUFDZCxRQUFJbUUsaUJBQWlCO0FBQ25CMEMsZUFBU0MsS0FBS0MsTUFBTUMsV0FBVztBQUMvQixhQUFPLE1BQU07QUFDWEgsaUJBQVNDLEtBQUtDLE1BQU1DLFdBQVc7QUFBQSxNQUNqQztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQzdDLGVBQWUsQ0FBQztBQUVwQm5FLFlBQVUsTUFBTTtBQUNkLFVBQU1pSCxPQUFPQyxhQUFhQyxRQUFRLE1BQU07QUFDeEMsUUFBSUYsTUFBTTtBQUNSLFVBQUk7QUFDRixjQUFNRyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBQy9CLGNBQU1NLE9BQ0pILFNBQVNJLGFBQ1RKLFNBQVNHLFFBQ1RILFNBQVNILE1BQU1PLGFBQ2ZKLFNBQVNILE1BQU1NLFFBQ2Y7QUFDRi9FLDJCQUFtQitFLElBQUk7QUFBQSxNQUN6QixTQUFTRSxHQUFHO0FBQ1ZDLGdCQUFRQyxNQUFNLDJDQUEyQ0YsQ0FBQztBQUFBLE1BQzVEO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUcsY0FBY0EsQ0FBQ2hCLFFBQVE7QUFDM0IsVUFBTWlCLGFBQWFwRjtBQUNuQixRQUFJcUYsT0FBT0MsS0FBS3RGLE1BQU0sRUFBRUwsU0FBUyxHQUFHO0FBQ2xDMEYsYUFBT0MsS0FBS3RGLE1BQU0sRUFBRWdFLFFBQVEsQ0FBQ3hELFFBQVE7QUFDbkM0RSxtQkFBVzVFLEdBQUcsSUFBSTtBQUFBLE1BQ3BCLENBQUM7QUFDRFAsZ0JBQVUsRUFBRSxHQUFHbUYsWUFBWSxDQUFDakIsR0FBRyxHQUFHLEtBQUssQ0FBQztBQUFBLElBQzFDO0FBQUEsRUFDRjtBQUdBLFFBQU1vQixrQkFBa0JBLENBQUNQLEdBQUdRLFFBQVE7QUFDbENSLE1BQUVTLGdCQUFnQjtBQUNsQjFFLG9CQUFnQnlFLElBQUk3RyxPQUFPLENBQUM7QUFFNUIsUUFBSTtBQUNGcUcsUUFBRVUsYUFBYUMsZ0JBQWdCO0FBQy9CWCxRQUFFVSxhQUFhRSxRQUFRLGNBQWNDLE9BQU9MLElBQUk3RyxPQUFPLENBQUMsQ0FBQztBQUFBLElBQzNELFNBQVNtSCxLQUFLO0FBQUEsSUFDWjtBQUFBLEVBRUo7QUFFQSxRQUFNQyxvQkFBb0JBLENBQUNmLEdBQUdRLFFBQVE7QUFDcENSLE1BQUVnQixlQUFlO0FBQ2pCLFFBQUlsRixnQkFBZ0IsUUFBUTBFLElBQUk3RyxPQUFPLE1BQU1tQyxjQUFjO0FBQ3pERyx1QkFBaUJ1RSxJQUFJN0csT0FBTyxDQUFDO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBRUEsUUFBTXNILHFCQUFxQkEsQ0FBQ1QsUUFBUTtBQUNsQ3ZFLHFCQUFpQixDQUFDaUYsWUFBYUEsWUFBWVYsSUFBSTdHLE9BQU8sSUFBSSxPQUFPdUgsT0FBUTtBQUFBLEVBQzNFO0FBRUEsUUFBTUMsZ0JBQWdCQSxDQUFDbkIsR0FBR29CLGNBQWM7QUFDdENwQixNQUFFZ0IsZUFBZTtBQUNqQmhCLE1BQUVTLGdCQUFnQjtBQUVsQixRQUFJM0UsZ0JBQWdCLFFBQVFBLGlCQUFpQnNGLFVBQVV6SCxPQUFPLEdBQUc7QUFDL0RvQyxzQkFBZ0IsSUFBSTtBQUNwQkUsdUJBQWlCLElBQUk7QUFDckI7QUFBQSxJQUNGO0FBRUFKLGlCQUFhLENBQUN3RixTQUFTO0FBQ3JCLFlBQU1DLFVBQVUsQ0FBQyxHQUFHRCxJQUFJO0FBQ3hCLFlBQU1FLFlBQVlELFFBQVFFLFVBQVUsQ0FBQ0MsU0FBU0EsS0FBSzlILE9BQU8sTUFBTW1DLFlBQVk7QUFDNUUsWUFBTTRGLFVBQVVKLFFBQVFFLFVBQVUsQ0FBQ0MsU0FBU0EsS0FBSzlILE9BQU8sTUFBTXlILFVBQVV6SCxPQUFPLENBQUM7QUFDaEYsVUFBSTRILGNBQWMsTUFBTUcsWUFBWSxHQUFJLFFBQU9MO0FBQy9DLFlBQU0sQ0FBQ00sU0FBUyxJQUFJTCxRQUFRTSxPQUFPTCxXQUFXLENBQUM7QUFDL0NELGNBQVFNLE9BQU9GLFNBQVMsR0FBR0MsU0FBUztBQUNwQyxhQUFPTDtBQUFBQSxJQUNULENBQUM7QUFLRC9GLGtCQUFjLEVBQUVDLEtBQUssTUFBTUMsV0FBVyxNQUFNLENBQUM7QUFFN0NNLG9CQUFnQixJQUFJO0FBQ3BCRSxxQkFBaUIsSUFBSTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTTRGLG1CQUFtQkEsTUFBTTtBQUM3QjlGLG9CQUFnQixJQUFJO0FBQ3BCRSxxQkFBaUIsSUFBSTtBQUFBLEVBQ3ZCO0FBR0EsUUFBTTZGLHdCQUF3QkEsQ0FBQzlCLEdBQUdqQyxXQUFXO0FBQzNDaUMsTUFBRVMsZ0JBQWdCO0FBQ2xCbEUsd0JBQW9Cd0IsT0FBT3ZDLEdBQUc7QUFDOUIsUUFBSTtBQUNGd0UsUUFBRVUsYUFBYUMsZ0JBQWdCO0FBQy9CWCxRQUFFVSxhQUFhRSxRQUFRLGNBQWM3QyxPQUFPdkMsR0FBRztBQUFBLElBQ2pELFNBQVNzRixLQUFLO0FBQUEsSUFDWjtBQUFBLEVBRUo7QUFFQSxRQUFNaUIsdUJBQXVCQSxDQUFDL0IsR0FBR2pDLFdBQVc7QUFDMUNpQyxNQUFFZ0IsZUFBZTtBQUNqQmhCLE1BQUVTLGdCQUFnQjtBQUNsQixRQUFJbkUsb0JBQW9CLFFBQVF5QixPQUFPdkMsUUFBUWMsa0JBQWtCO0FBQy9ERywyQkFBcUJzQixPQUFPdkMsR0FBRztBQUFBLElBQ2pDO0FBQUEsRUFDRjtBQUVBLFFBQU13Ryx3QkFBd0JBLENBQUNqRSxXQUFXO0FBQ3hDdEIseUJBQXFCLENBQUN5RSxZQUFhQSxZQUFZbkQsT0FBT3ZDLE1BQU0sT0FBTzBGLE9BQVE7QUFBQSxFQUM3RTtBQUVBLFFBQU1lLG1CQUFtQkEsQ0FBQ2pDLEdBQUdrQyxpQkFBaUI7QUFDNUNsQyxNQUFFZ0IsZUFBZTtBQUNqQmhCLE1BQUVTLGdCQUFnQjtBQUVsQixRQUFJbkUsb0JBQW9CLFFBQVFBLHFCQUFxQjRGLGFBQWExRyxLQUFLO0FBQ3JFZSwwQkFBb0IsSUFBSTtBQUN4QkUsMkJBQXFCLElBQUk7QUFDekI7QUFBQSxJQUNGO0FBRUFOLG1CQUFlLENBQUNrRixTQUFTO0FBQ3ZCLFlBQU1DLFVBQVUsQ0FBQyxHQUFHRCxJQUFJO0FBQ3hCLFlBQU1FLFlBQVlELFFBQVFhLFFBQVE3RixnQkFBZ0I7QUFDbEQsWUFBTW9GLFVBQVVKLFFBQVFhLFFBQVFELGFBQWExRyxHQUFHO0FBQ2hELFVBQUkrRixjQUFjLE1BQU1HLFlBQVksR0FBSSxRQUFPTDtBQUMvQ0MsY0FBUU0sT0FBT0wsV0FBVyxDQUFDO0FBQzNCRCxjQUFRTSxPQUFPRixTQUFTLEdBQUdwRixnQkFBZ0I7QUFDM0MsYUFBT2dGO0FBQUFBLElBQ1QsQ0FBQztBQUVEL0Usd0JBQW9CLElBQUk7QUFDeEJFLHlCQUFxQixJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNMkYsc0JBQXNCQSxNQUFNO0FBQ2hDN0Ysd0JBQW9CLElBQUk7QUFDeEJFLHlCQUFxQixJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNNEYsYUFBYUEsQ0FBQ3ZJLFVBQVM7QUFDM0IsUUFBSSxDQUFDb0IsWUFBYSxRQUFPcEI7QUFDekIsV0FBT0EsTUFBS2dGO0FBQUFBLE1BQU8sQ0FBQzJDLFNBQ2xCcEIsT0FBT2lDLE9BQU9iLElBQUksRUFBRTdEO0FBQUFBLFFBQUssQ0FBQzJFLFVBQ3hCMUIsT0FBTzBCLEtBQUssRUFBRWpGLFlBQVksRUFBRUUsU0FBU3RDLFlBQVlvQyxZQUFZLENBQUM7QUFBQSxNQUNoRTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTWtGLGFBQWFBLENBQUMxSSxVQUFTO0FBQzNCLFdBQU9BLE1BQUtnRixPQUFPLENBQUMyQyxTQUFTO0FBQzNCLGFBQU9wQixPQUFPb0MsUUFBUXJILE9BQU8sRUFBRXNILE1BQU0sQ0FBQyxDQUFDbEgsS0FBSytHLEtBQUssTUFBTTtBQUNyRCxZQUFJLENBQUNBLE1BQU8sUUFBTztBQUNuQixlQUFPMUIsT0FBT1ksS0FBS2pHLEdBQUcsQ0FBQyxFQUFFOEIsWUFBWSxNQUFNaUYsTUFBTWpGLFlBQVk7QUFBQSxNQUMvRCxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1xRixXQUFXQSxDQUFDN0ksVUFBUztBQUN6QixRQUFJLENBQUN3QixXQUFXRSxJQUFLLFFBQU8xQjtBQUM1QixXQUFPLENBQUMsR0FBR0EsS0FBSSxFQUFFOEksS0FBSyxDQUFDQyxHQUFHQyxNQUFNO0FBQzlCLFlBQU1DLE9BQU9GLEVBQUV2SCxXQUFXRSxHQUFHO0FBQzdCLFlBQU13SCxPQUFPRixFQUFFeEgsV0FBV0UsR0FBRztBQUM3QixVQUFJdUgsT0FBT0MsS0FBTSxRQUFPMUgsV0FBV0csY0FBYyxRQUFRLEtBQUs7QUFDOUQsVUFBSXNILE9BQU9DLEtBQU0sUUFBTzFILFdBQVdHLGNBQWMsUUFBUSxJQUFJO0FBQzdELGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTXdILGdCQUFnQjNLLFFBQVEsTUFBTTtBQUNsQyxRQUFJNEssWUFBWSxDQUFDLEdBQUd0SCxTQUFTO0FBQzdCc0gsZ0JBQVliLFdBQVdhLFNBQVM7QUFDaENBLGdCQUFZVixXQUFXVSxTQUFTO0FBQ2hDQSxnQkFBWVAsU0FBU08sU0FBUztBQUM5QixXQUFPQTtBQUFBQSxFQUNULEdBQUcsQ0FBQ3RILFdBQVdWLGFBQWFFLFNBQVNFLFVBQVUsQ0FBQztBQUVoRCxRQUFNNkgsYUFBYUMsS0FBS0MsS0FBS0osY0FBY3RJLFNBQVNlLFFBQVE7QUFDNUQsUUFBTTRILGdCQUFnQkwsY0FBY007QUFBQUEsS0FDakMzSSxjQUFjLEtBQUtjO0FBQUFBLElBQ3BCZCxjQUFjYztBQUFBQSxFQUNoQjtBQUVBLFFBQU04SCxjQUFjQSxDQUFDakIsVUFBVTtBQUM3QixRQUFJa0IsTUFBTUMsZUFBZW5CLEtBQUssR0FBRztBQUMvQixZQUFNb0IsT0FBT3JLLGVBQWVzSyxxQkFBcUJyQixLQUFLO0FBQ3RELFlBQU1zQixNQUFNekUsU0FBUzBFLGNBQWMsS0FBSztBQUN4Q0QsVUFBSUUsWUFBWUo7QUFDaEIsYUFBT0UsSUFBSUcsZUFBZUgsSUFBSUksYUFBYTtBQUFBLElBQzdDO0FBQ0EsV0FBTzFCLFNBQVM7QUFBQSxFQUNsQjtBQUVBLFFBQU0yQixnQkFBZ0JBLE1BQU07QUFDMUIsVUFBTUMsTUFBTSxvQkFBSTFGLEtBQUs7QUFDckIsVUFBTTJGLGdCQUFnQixHQUFHdkQsT0FBT3NELElBQUlFLFFBQVEsQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUl6RCxPQUFPc0QsSUFBSUksU0FBUyxJQUFJLENBQUMsRUFBRUQsU0FBUyxHQUFHLEdBQUcsQ0FBQyxJQUN4R0gsSUFBSUssWUFBWSxDQUFDLElBQUkzRCxPQUFPc0QsSUFBSU0sU0FBUyxDQUFDLEVBQUVILFNBQVMsR0FBRyxHQUFHLENBQUMsSUFDNUR6RCxPQUFPc0QsSUFBSU8sV0FBVyxDQUFDLEVBQUVKLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFDekN6RCxPQUFPc0QsSUFBSVEsV0FBVyxDQUFDLEVBQUVMLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFFL0MsVUFBTU0sZUFBZWxLLGNBQWNvRTtBQUFBQSxNQUNqQyxDQUFDekMsUUFDQ1Msc0JBQXNCVSxTQUFTbkIsSUFBSWIsR0FBRyxLQUN0Q2EsSUFBSWtCLE9BQU9ELFlBQVksTUFBTTtBQUFBLElBQ2pDO0FBRUEsVUFBTXVILFVBQVVELGFBQWF4SSxJQUFJLENBQUNDLFFBQVFBLElBQUlrQixNQUFNLEVBQUV1SCxLQUFLLEdBQUc7QUFFOUQsVUFBTUMsT0FBTzlCLGNBQ1Y3RztBQUFBQSxNQUFJLENBQUNxRixTQUNKbUQsYUFDR3hJLElBQUksQ0FBQ0MsUUFBUTtBQUNaLGNBQU0ySSxNQUFNeEIsWUFBWS9CLEtBQUtwRixJQUFJYixHQUFHLENBQUM7QUFDckMsY0FBTXlKLFFBQVFwRSxPQUFPbUUsT0FBTyxHQUFHLEVBQUVFLFFBQVEsTUFBTSxJQUFJO0FBQ25ELGVBQU8sSUFBSUQsS0FBSztBQUFBLE1BQ2xCLENBQUMsRUFDQUgsS0FBSyxHQUFHO0FBQUEsSUFDYixFQUNDQSxLQUFLLElBQUk7QUFFWixVQUFNSyxNQUFNLEdBQUdOLE9BQU87QUFBQSxFQUFLRSxJQUFJO0FBQy9CLFVBQU1LLE9BQU8sSUFBSUMsS0FBSyxDQUFDLFdBQVdGLEdBQUcsR0FBRyxFQUFFRyxNQUFNLDBCQUEwQixDQUFDO0FBQzNFLFVBQU1DLE1BQU1DLE9BQU9DLElBQUlDLGdCQUFnQk4sSUFBSTtBQUMzQyxVQUFNdkMsSUFBSXpELFNBQVMwRSxjQUFjLEdBQUc7QUFDcENqQixNQUFFOEMsT0FBT0o7QUFDVCxVQUFNSyxlQUFlM0wsaUJBQWlCaUwsUUFBUSxXQUFXLEVBQUUsRUFBRXpILEtBQUs7QUFDbEVvRixNQUFFZ0QsV0FBVyxHQUFHRCxZQUFZLElBQUl4QixhQUFhO0FBQzdDdkIsTUFBRWlELE1BQU07QUFDUk4sV0FBT0MsSUFBSU0sZ0JBQWdCUixHQUFHO0FBRTlCNUksdUJBQW1CLEtBQUs7QUFBQSxFQUMxQjtBQUVBLFFBQU1xSix3QkFBd0JBLENBQUNDLFdBQVdDLGNBQWM7QUFDdEQsUUFBSUEsV0FBVztBQUNibkosK0JBQXlCLENBQUMsR0FBR0QsdUJBQXVCbUosU0FBUyxDQUFDO0FBQUEsSUFDaEUsT0FBTztBQUNMbEo7QUFBQUEsUUFDRUQsc0JBQXNCZ0MsT0FBTyxDQUFDdEQsUUFBUUEsUUFBUXlLLFNBQVM7QUFBQSxNQUN6RDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTUUsa0JBQWtCQSxDQUFDRCxjQUFjO0FBQ3JDLFFBQUlBLFdBQVc7QUFDYm5KLCtCQUF5QnJDLGNBQWMwQixJQUFJLENBQUNDLFFBQVFBLElBQUliLEdBQUcsQ0FBQztBQUFBLElBQzlELE9BQU87QUFDTHVCLCtCQUF5QixFQUFFO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsUUFBTXFKLGNBQWNBLENBQUNsSCxVQUFVO0FBQzdCLFdBQU9BLFFBQVEsTUFBTTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTW1ILGFBQWFBLE1BQU07QUFDdkIsUUFBSUMsbUJBQW1CO0FBQ3ZCLFFBQUlDLGlCQUFpQjtBQUVyQixVQUFNL0gsT0FBTyxHQUFHcUMsUUFBTyxvQkFBSXBDLEtBQUssR0FBRTRGLFFBQVEsQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUl6RCxRQUFPLG9CQUFJcEMsS0FBSyxHQUFFOEYsU0FBUyxJQUFJLENBQUMsRUFBRUQsU0FBUyxHQUFHLEdBQUcsQ0FBQyxLQUM3RyxvQkFBSTdGLEtBQUssR0FBRStGLFlBQVksQ0FBQyxJQUFJM0QsUUFBTyxvQkFBSXBDLEtBQUssR0FBRWdHLFNBQVMsQ0FBQyxFQUFFSCxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQzFFekQsUUFBTyxvQkFBSXBDLEtBQUssR0FBRWlHLFdBQVcsQ0FBQyxFQUFFSixTQUFTLEdBQUcsR0FBRyxDQUFDLElBQ2hEekQsUUFBTyxvQkFBSXBDLEtBQUssR0FBRWtHLFdBQVcsQ0FBQyxFQUFFTCxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3RELFVBQU1rQyxhQUFhM0YsT0FBTzNHLG1CQUFtQixFQUFFLEVBQUV1RCxLQUFLO0FBQ3RELFVBQU1nSixXQUFXLEdBQUdELFVBQVUsSUFBSWhJLElBQUk7QUFFdEMsWUFBUWdJLFlBQVU7QUFBQSxNQUNoQixLQUFLO0FBQUEsTUFBVSxLQUFLO0FBQUEsTUFBYSxLQUFLO0FBQUEsTUFBdUIsS0FBSztBQUFBLE1BQ2xFLEtBQUs7QUFBQSxNQUFTLEtBQUs7QUFBQSxNQUFVLEtBQUs7QUFBQSxNQUFhLEtBQUs7QUFBQSxNQUFTLEtBQUs7QUFBQSxNQUNsRSxLQUFLO0FBQUEsTUFBUyxLQUFLO0FBQUEsTUFBVyxLQUFLO0FBQUEsTUFBaUIsS0FBSztBQUFBLE1BQ3pELEtBQUs7QUFBQSxNQUFhLEtBQUs7QUFBQSxNQUFTLEtBQUs7QUFBQSxNQUF1QixLQUFLO0FBQUEsTUFDakUsS0FBSztBQUFBLE1BQXNCLEtBQUs7QUFBQSxNQUFxQixLQUFLO0FBQUEsTUFDMUQsS0FBSztBQUFBLE1BQTBCLEtBQUs7QUFBQSxNQUEwQixLQUFLO0FBQUEsTUFDbkUsS0FBSztBQUFBLE1BQXFCLEtBQUs7QUFBQSxNQUFrQixLQUFLO0FBQUEsTUFBZSxLQUFLO0FBQUEsTUFDMUUsS0FBSztBQUFBLE1BQWUsS0FBSztBQUFBLE1BQWdCLEtBQUs7QUFBQSxNQUM5QyxLQUFLO0FBQUEsTUFBMEIsS0FBSztBQUFBLE1BQW1CLEtBQUs7QUFBQSxNQUFlLEtBQUs7QUFDOUVGLDJCQUFtQjtBQUNuQkMseUJBQWlCO0FBQ2pCO0FBQUEsTUFDRixLQUFLO0FBQUEsTUFBa0IsS0FBSztBQUMxQkQsMkJBQW1CO0FBQ25CQyx5QkFBaUI7QUFDakI7QUFBQSxNQUNGO0FBQ0VELDJCQUFtQjtBQUNuQkMseUJBQWlCO0FBQ2pCO0FBQUEsSUFDSjtBQUVBLFVBQU0zQixlQUFlbEssY0FBY29FO0FBQUFBLE1BQ2pDLENBQUN6QyxRQUNDUyxzQkFBc0JVLFNBQVNuQixJQUFJYixHQUFHLEtBQ3RDYSxJQUFJYixJQUFJOEIsWUFBWSxNQUFNO0FBQUEsSUFDOUI7QUFFQSxVQUFNb0osZUFBZXRILFNBQVMwRSxjQUFjLEtBQUs7QUFDakQsVUFBTUssTUFBTSxvQkFBSTFGLEtBQUs7QUFDckIsVUFBTWtJLGlCQUFpQnhDLElBQUl5QyxlQUFlLFNBQVM7QUFBQSxNQUNqREMsV0FBVztBQUFBLE1BQ1hDLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFFRCxVQUFNQyxjQUFjOUQsY0FBYytELE9BQU8sQ0FBQ0MsS0FBS3pHLFFBQVE7QUFDckQsWUFBTTBHLFNBQVM5SSxXQUFXb0MsSUFBSTBHLFVBQVUxRyxJQUFJMkcsVUFBVSxDQUFDO0FBQ3ZELGFBQU9GLE9BQU81SSxNQUFNNkksTUFBTSxJQUFJLElBQUlBO0FBQUFBLElBQ3BDLEdBQUcsQ0FBQztBQUVKLFVBQU1FLFlBQVluRSxjQUNmbkUsT0FBTyxDQUFDMEIsUUFBUUEsSUFBSTZHLE1BQU0vSixZQUFZLE1BQU0sTUFBTSxFQUNsRDBKLE9BQU8sQ0FBQ0MsS0FBS3pHLFFBQVF5RyxNQUFNSyxPQUFPOUcsSUFBSTBHLFVBQVUsQ0FBQyxHQUFHLENBQUM7QUFFeEQsVUFBTUssY0FBY3RFLGNBQ2pCbkUsT0FBTyxDQUFDMEIsUUFBUUEsSUFBSTZHLE1BQU0vSixZQUFZLE1BQU0sUUFBUSxFQUNwRDBKLE9BQU8sQ0FBQ0MsS0FBS3pHLFFBQVF5RyxNQUFNSyxPQUFPOUcsSUFBSTBHLFVBQVUsQ0FBQyxHQUFHLENBQUM7QUFFeEQsVUFBTU0saUJBQWlCLElBQUlDO0FBQUFBLE1BQ3pCeEUsY0FBYzdHLElBQUksQ0FBQ29FLFFBQVFBLElBQUlWLFFBQVFVLElBQUlrSCxTQUFTM0gsU0FBUztBQUFBLElBQy9ELEVBQUU0SDtBQUVGLFVBQU1DLG1CQUFtQjNFLGNBQWNuRTtBQUFBQSxNQUNyQyxDQUFDMEIsUUFBUUEsSUFBSTZHLE1BQU0vSixZQUFZLE1BQU07QUFBQSxJQUN2QyxFQUFFM0M7QUFFRixVQUFNa04saUJBQWlCNUUsY0FBY25FO0FBQUFBLE1BQ25DLENBQUMwQixRQUFRQSxJQUFJNkcsTUFBTS9KLFlBQVksTUFBTTtBQUFBLElBQ3ZDLEVBQUUzQztBQUVGLFVBQU1tTixrQkFBa0J0QixXQUFXbEosWUFBWSxFQUFFRSxTQUFTLFNBQVMsS0FBS2dKLFdBQVdsSixZQUFZLEVBQUVFLFNBQVMsZ0JBQWdCO0FBQzFILFFBQUl1SyxvQkFBb0I7QUFDeEIsUUFBSUMscUJBQXFCO0FBRXpCLFFBQUlGLG1CQUFtQnBPLGdCQUFnQmlCLFVBQVUsR0FBRztBQUNsRG9OLDBCQUFvQjtBQUFBO0FBQUE7QUFBQSxzQ0FHWXJPLGdCQUFnQixDQUFDLENBQUM7QUFBQSxzQ0FDbEJELGtCQUFrQixDQUFDLENBQUM7QUFBQTtBQUFBO0FBQUEsc0NBR3BCQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQUEsc0NBQ2xCRCxrQkFBa0IsQ0FBQyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBS3BELFVBQUlDLGdCQUFnQmlCLFNBQVMsR0FBRztBQUM5QixjQUFNc04sZ0JBQWdCdk8sZ0JBQWdCNkosTUFBTSxDQUFDO0FBQzdDLGNBQU0yRSxrQkFBa0J6TyxrQkFBa0I4SixNQUFNLENBQUM7QUFDakR5RSw2QkFBcUI7QUFBQTtBQUFBLGNBRWZDLGNBQ0Q3TDtBQUFBQSxVQUNDLENBQUNaLEtBQUsyTSxRQUFRO0FBQUE7QUFBQSw4Q0FFa0IzTSxHQUFHO0FBQUEsOENBQ0gwTSxnQkFBZ0JDLEdBQUcsQ0FBQztBQUFBO0FBQUE7QUFBQSxRQUd0RCxFQUNDckQsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUEsTUFHZjtBQUFBLElBQ0YsT0FBTztBQUNMa0QsMkJBQXFCO0FBQUE7QUFBQSxZQUVmdE8sZ0JBQWdCMEM7QUFBQUEsUUFDcEIsQ0FBQ1osS0FBSzRNLE1BQU07QUFBQTtBQUFBLDBDQUVzQjVNLEdBQUc7QUFBQSwwQ0FDSC9CLGtCQUFrQjJPLENBQUMsQ0FBQztBQUFBO0FBQUE7QUFBQSxNQUd4RCxFQUFFdEQsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUEsSUFHWjtBQUVBNEIsaUJBQWEzQyxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXlDZmhMLGFBQWEsYUFBYUEsVUFBVSx1Q0FBdUMsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0NBV25EeU4sY0FBYyw0QkFBNEI7QUFBQSxxQ0FDN0NHLGNBQWM7QUFBQTtBQUFBLFlBRXZDbUIsa0JBQWtCQyxvQkFBb0IsRUFBRTtBQUFBLFlBQ3hDQyxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtacEQsYUFDVHhJO0FBQUFBLE1BQ0MsQ0FBQ0MsUUFDQywwRUFBMEVBLElBQUlrQixNQUFNO0FBQUEsSUFDeEYsRUFDQ3VILEtBQUssRUFBRSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSUQ3QixjQUNQN0c7QUFBQUEsTUFDQyxDQUFDb0UsUUFBUTtBQUFBO0FBQUEsc0JBRUdvRSxhQUNQeEksSUFBSSxDQUFDQyxRQUFRO0FBQ1osY0FBTTJJLE1BQU14QixZQUFZaEQsSUFBSW5FLElBQUliLEdBQUcsQ0FBQztBQUNwQyxlQUFPLHdEQUF3RHdKLE9BQU8sR0FBRztBQUFBLE1BQzNFLENBQUMsRUFDQUYsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLElBRWYsRUFDQ0EsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtDQUs4QmhLLGVBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVTFELFFBQUkvQixZQUFZO0FBQ2QsWUFBTXNQLE1BQU0sSUFBSUMsTUFBTTtBQUN0QkQsVUFBSUUsTUFBTXhQO0FBQ1ZzUCxVQUFJRyxTQUFTLE1BQU07QUFDakJwSixpQkFBU0MsS0FBS29KLFlBQVkvQixZQUFZO0FBQ3RDdEgsaUJBQVNzSixRQUFRakMsWUFBWTtBQUM3QmpCLGVBQU9tRCxNQUFNO0FBQ2J2SixpQkFBU0MsS0FBS3VKLFlBQVlsQyxZQUFZO0FBQ3RDdEgsaUJBQVNzSixRQUFRO0FBQ2pCL0wsMkJBQW1CLEtBQUs7QUFBQSxNQUMxQjtBQUFBLElBQ0YsT0FBTztBQUNMeUMsZUFBU0MsS0FBS29KLFlBQVkvQixZQUFZO0FBQ3RDdEgsZUFBU3NKLFFBQVFqQyxZQUFZO0FBQzdCakIsYUFBT21ELE1BQU07QUFDYnZKLGVBQVNDLEtBQUt1SixZQUFZbEMsWUFBWTtBQUN0Q3RILGVBQVNzSixRQUFRO0FBQ2pCL0wseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNa00sYUFBYUEsQ0FBQ3JOLFFBQVE7QUFDMUJELGtCQUFjLENBQUMyRixhQUFhO0FBQUEsTUFDMUIxRjtBQUFBQSxNQUNBQyxXQUFXeUYsUUFBUTFGLFFBQVFBLE9BQU8wRixRQUFRekYsY0FBYyxRQUFRLFNBQVM7QUFBQSxJQUMzRSxFQUFFO0FBQUEsRUFDSjtBQU1BLFFBQU1xTixxQkFBcUJ4USxRQUFRLE1BQU07QUFDdkMsVUFBTXlRLFFBQVEsSUFBSUMsSUFBSXZPLFlBQVkyQixJQUFJLENBQUNDLFFBQVEsQ0FBQ0EsSUFBSWIsS0FBS2EsR0FBRyxDQUFDLENBQUM7QUFDOUQsVUFBTTRNLFFBQVEvTSxZQUNYNEMsT0FBTyxDQUFDdEQsUUFBUXVOLE1BQU1HLElBQUkxTixHQUFHLENBQUMsRUFDOUJZLElBQUksQ0FBQ1osUUFBUXVOLE1BQU1JLElBQUkzTixHQUFHLENBQUM7QUFDOUIsVUFBTTROLGNBQWMzTyxZQUFZcUU7QUFBQUEsTUFDOUIsQ0FBQ3pDLFFBQVEsQ0FBQ0gsWUFBWXNCLFNBQVNuQixJQUFJYixHQUFHO0FBQUEsSUFDeEM7QUFDQSxXQUFPLENBQUMsR0FBR3lOLE9BQU8sR0FBR0csV0FBVztBQUFBLEVBQ2xDLEdBQUcsQ0FBQzNPLGFBQWF5QixXQUFXLENBQUM7QUFFN0IsUUFBTW1OLG9CQUFvQixJQUFJNUIsSUFBSXhLLGNBQWM7QUFDaEQsUUFBTXFNLHFCQUFxQlIsbUJBQW1CaEs7QUFBQUEsSUFBTyxDQUFDekMsUUFDcERnTixrQkFBa0JILElBQUk3TSxJQUFJYixHQUFHO0FBQUEsRUFDL0I7QUFHQSxRQUFNK04saUJBQWlCRCxtQkFBbUJ4SztBQUFBQSxJQUN4QyxDQUFDekMsUUFBUSxDQUFDYyxXQUFXSyxTQUFTbkIsSUFBSWIsR0FBRztBQUFBLEVBQ3ZDO0FBQ0EsUUFBTWdPLGdCQUFnQkYsbUJBQW1CeEs7QUFBQUEsSUFBTyxDQUFDekMsUUFDL0NjLFdBQVdLLFNBQVNuQixJQUFJYixHQUFHO0FBQUEsRUFDN0I7QUFHQSxRQUFNaU8saUJBQWlCLENBQUMsR0FBR0YsZ0JBQWdCLEdBQUdDLGFBQWE7QUFJM0QsUUFBTUUsZUFBZUYsY0FBY3BOLElBQUksQ0FBQ0MsUUFBUTRCLGFBQWFILGVBQWV6QixHQUFHLENBQUMsQ0FBQztBQUNqRixNQUFJc04sbUJBQW1CO0FBQ3ZCLFFBQU1DLGdCQUFnQkosY0FBY3BOLElBQUksQ0FBQ0MsS0FBSzZDLFVBQVU7QUFDdEQsVUFBTTJLLGdCQUFnQkwsY0FBYzdPLFNBQVMsSUFBSXVFO0FBQ2pELFVBQU00SyxTQUFTSDtBQUNmQSx3QkFBb0JELGFBQWFHLGFBQWE7QUFDOUMsV0FBTyxFQUFFck8sS0FBS2EsSUFBSWIsS0FBS3NPLE9BQU87QUFBQSxFQUNoQyxDQUFDO0FBRUQsUUFBTUMsWUFBWSxDQUFDO0FBQ25CSCxnQkFBYzVLLFFBQVEsQ0FBQ3lDLFNBQVM7QUFDOUJzSSxjQUFVdEksS0FBS2pHLEdBQUcsSUFBSWlHLEtBQUtxSTtBQUFBQSxFQUM3QixDQUFDO0FBR0QsTUFBSSxDQUFDeFAsU0FBU0ssVUFBVSxDQUFDRixZQUFZRSxRQUFRO0FBQzNDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFFO0FBQUEsRUFDWDtBQUVBLFFBQU1xUCx5QkFBeUJBLENBQUNDLFlBQVk7QUFDMUMsUUFBSUEsU0FBUztBQUNYL00sd0JBQWtCekMsWUFBWTJCLElBQUksQ0FBQ0MsUUFBUUEsSUFBSWIsR0FBRyxDQUFDO0FBQUEsSUFDckQsT0FBTztBQUNMMEIsd0JBQWtCLEVBQUU7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ04scUJBQ0pqTixlQUFldEMsV0FBV0YsWUFBWUUsVUFBVUYsWUFBWUUsU0FBUztBQUV2RSxTQUNFLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVyxxREFBcURkLG1CQUFtQixvQkFBb0IsYUFBYSxJQUN0SEE7QUFBQUEsMEJBQ0MsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLE9BQU9xQjtBQUFBQSxZQUNQLFVBQVUsQ0FBQzhFLE1BQU03RSxlQUFlNkUsRUFBRW1LLE9BQU81SCxLQUFLO0FBQUEsWUFDOUMsV0FBVTtBQUFBO0FBQUEsVUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLK0s7QUFBQSxRQUUvSyx1QkFBQyxVQUFPLFdBQVUsbURBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxXQVJuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVEM0ksbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTtBQUNiaUQsNEJBQWMsT0FBTztBQUNyQkYsaUNBQW1CLElBQUk7QUFBQSxZQUN6QjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUFHO0FBQUE7QUFBQTtBQUFBLFVBUHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQ2JFLDRCQUFjLEtBQUs7QUFDbkJGLGlDQUFtQixJQUFJO0FBQUEsWUFDekI7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FBRztBQUFBO0FBQUE7QUFBQSxVQVBuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUNBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUscURBQW9EO0FBQUE7QUFBQSxVQUM5Q0MsZUFBZSxVQUFVLFdBQVc7QUFBQSxhQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGLE1BQU1GO0FBQUFBLFFBQ04sVUFBVSxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBQ3hDLFFBQVE7QUFBQSxVQUNOO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU1BLG1CQUFtQixLQUFLO0FBQUEsY0FDdkMsV0FBVTtBQUFBLGNBQTJIO0FBQUE7QUFBQSxZQUZqSTtBQUFBLFlBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNO0FBQ2Isb0JBQUlDLGVBQWUsU0FBUztBQUMxQnNILGdDQUFjO0FBQUEsZ0JBQ2hCLE9BQU87QUFDTG1DLDZCQUFXO0FBQUEsZ0JBQ2I7QUFBQSxjQUNGO0FBQUEsY0FDQSxVQUFVdkosc0JBQXNCbkMsV0FBVztBQUFBLGNBQzNDLFdBQVcsOEhBQThIaUMsZUFBZSxVQUNwSixvQ0FDQSw2QkFBNkI7QUFBQSxjQUdoQ0EseUJBQWUsVUFBVSxXQUFXO0FBQUE7QUFBQSxZQWRqQztBQUFBLFlBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWdCQTtBQUFBLFFBQVM7QUFBQSxRQUVYLE9BQU87QUFBQSxRQUNQLFdBQVU7QUFBQSxRQUVWO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDhCQUNiLGlDQUFDLFdBQU0sV0FBVSwrRkFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNFLHNCQUFzQm5DLFdBQVdELGNBQWNDO0FBQUFBLGdCQUN4RCxVQUFVLENBQUNxRixNQUFNbUcsZ0JBQWdCbkcsRUFBRW1LLE9BQU9GLE9BQU87QUFBQSxnQkFDakQsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJK0Q7QUFBQSxZQUUvRCx1QkFBQyxVQUFLLFdBQVUsZUFBYywwQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0M7QUFBQSxlQVAxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNadlAsd0JBQWMwQjtBQUFBQSxZQUFJLENBQUMyQixXQUNsQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLFdBQVU7QUFBQSxnQkFFVjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTakIsc0JBQXNCVSxTQUFTTyxPQUFPdkMsR0FBRztBQUFBLHNCQUNsRCxVQUFVLENBQUN3RSxNQUNUZ0csc0JBQXNCakksT0FBT3ZDLEtBQUt3RSxFQUFFbUssT0FBT0YsT0FBTztBQUFBLHNCQUVwRCxXQUFVO0FBQUE7QUFBQSxvQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTStEO0FBQUEsa0JBRS9ELHVCQUFDLFVBQUssV0FBVSxpQkFBaUJsTSxpQkFBT1IsVUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQTtBQUFBO0FBQUEsY0FYMUNRLE9BQU92QztBQUFBQSxjQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhQTtBQUFBLFVBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQTtBQUFBO0FBQUEsTUFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsOEVBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsbURBQWtELHdCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLFdBQU0sV0FBVSxrSkFDZjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTME87QUFBQUEsWUFDVCxVQUFVLENBQUNsSyxNQUFNZ0ssdUJBQXVCaEssRUFBRW1LLE9BQU9GLE9BQU87QUFBQSxZQUN4RCxXQUFVO0FBQUE7QUFBQSxVQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUltQztBQUFBLFFBRW5DLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsMEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxXQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVDeFAsWUFBWTJCO0FBQUFBLFFBQUksQ0FBQzJCLFdBQ2hCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFVO0FBQUEsWUFFVjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTZCxlQUFlTyxTQUFTTyxPQUFPdkMsR0FBRztBQUFBLGtCQUMzQyxVQUFVLE1BQU1xRCxhQUFhZCxPQUFPdkMsR0FBRztBQUFBLGtCQUN2QyxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJK0Q7QUFBQSxjQUUvRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCdUMsaUJBQU9SLFVBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStDO0FBQUE7QUFBQTtBQUFBLFVBVDFDUSxPQUFPdkM7QUFBQUEsVUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxNQUNEO0FBQUEsU0E1Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixPQUFPO0FBQUEsVUFDTDRPLFdBQVc7QUFBQSxVQUNYQyxXQUFXO0FBQUEsVUFDWEMsV0FBVztBQUFBLFFBQ2I7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFPO0FBQUEsY0FDTEMsVUFBVTtBQUFBLGNBQ1ZDLGFBQWE7QUFBQSxZQUNmO0FBQUEsWUFFQTtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnRUFDZjtBQUFBLHVDQUFDLFFBRUM7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsT0FBTyxFQUFFeE0sT0FBTyxRQUFRdU0sVUFBVSxPQUFPO0FBQUEsc0JBQ3pDLE9BQU07QUFBQTtBQUFBLG9CQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUNDZCxlQUFlck4sSUFBSSxDQUFDMkIsV0FBVztBQUM5QiwwQkFBTTBNLFdBQVd0TixXQUFXSyxTQUFTTyxPQUFPdkMsR0FBRztBQUMvQywwQkFBTWtQLGNBQWNELFdBQVdWLFVBQVVoTSxPQUFPdkMsR0FBRyxJQUFJbVA7QUFDdkQsMEJBQU1DLGtCQUFrQnRPLHFCQUFxQnlCLE9BQU92QztBQUNwRCwwQkFBTXFQLHFCQUFxQnJPLHNCQUFzQnVCLE9BQU92QztBQUN4RCwwQkFBTThELFFBQVE7QUFBQSxzQkFDWnRCLE9BQU9GLGVBQWVDLE1BQU07QUFBQSxzQkFDNUJ3TSxVQUFVN00sb0JBQW9CSyxPQUFPUixNQUFNLElBQUksVUFBVTtBQUFBLHNCQUN6RHVOLFVBQVVMLFdBQVcsV0FBVztBQUFBLHNCQUNoQ00sT0FBT04sV0FBVyxHQUFHQyxXQUFXLE9BQU87QUFBQSxzQkFDdkNNLFFBQVFQLFdBQVcsSUFBSTtBQUFBLHNCQUN2QlEsWUFBWVIsV0FBVyxZQUFZRTtBQUFBQTtBQUFBQSxvQkFDckM7QUFDQSwyQkFDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFFQyxXQUFXLHFJQUNUQyxrQkFBa0IsZUFBZSxFQUFFLElBRW5DQyxxQkFBcUIsK0JBQStCLEVBQUU7QUFBQSx3QkFFeEQ7QUFBQSx3QkFDQSxTQUFTLE1BQU1oQyxXQUFXOUssT0FBT3ZDLEdBQUc7QUFBQSx3QkFHcEMsV0FBVyxDQUFDaVA7QUFBQUEsd0JBQ1osYUFBYSxDQUFDekssTUFBTSxDQUFDeUssWUFBWTNJLHNCQUFzQjlCLEdBQUdqQyxNQUFNO0FBQUEsd0JBQ2hFLFlBQVksQ0FBQ2lDLE1BQU0sQ0FBQ3lLLFlBQVkxSSxxQkFBcUIvQixHQUFHakMsTUFBTTtBQUFBLHdCQUM5RCxhQUFhLE1BQU0sQ0FBQzBNLFlBQVl6SSxzQkFBc0JqRSxNQUFNO0FBQUEsd0JBQzVELFFBQVEsQ0FBQ2lDLE1BQU0sQ0FBQ3lLLFlBQVl4SSxpQkFBaUJqQyxHQUFHakMsTUFBTTtBQUFBLHdCQUN0RCxXQUFXcUU7QUFBQUEsd0JBRVgsaUNBQUMsU0FBSSxXQUFVLDJCQUNaO0FBQUEsMkJBQUNxSSxZQUNBLHVCQUFDLGdCQUFhLFdBQVUscURBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXlFO0FBQUEsMEJBRTFFMU0sT0FBT1I7QUFBQUEsMEJBQ1BqQyxXQUFXRSxRQUFRdUMsT0FBT3ZDLE9BQ3pCLHVCQUFDLFVBQUssV0FBVSxpQkFDYkYscUJBQVdHLGNBQWMsUUFBUSxNQUFNLE9BRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVVBO0FBQUE7QUFBQSxzQkEzQktzQyxPQUFPdkM7QUFBQUEsc0JBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkE2QkE7QUFBQSxrQkFFSixDQUFDO0FBQUEscUJBdERIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdURBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGNBRVo7QUFBQSx5Q0FBQyxRQUFHLE9BQU8sRUFBRXdDLE9BQU8sUUFBUXVNLFVBQVUsT0FBTyxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRDtBQUFBLGtCQUMvQ2QsZUFBZXJOLElBQUksQ0FBQzJCLFdBQVc7QUFDOUIsMEJBQU0wTSxXQUFXdE4sV0FBV0ssU0FBU08sT0FBT3ZDLEdBQUc7QUFDL0MsMEJBQU1rUCxjQUFjRCxXQUFXVixVQUFVaE0sT0FBT3ZDLEdBQUcsSUFBSW1QO0FBQ3ZELDBCQUFNckwsUUFBUTtBQUFBLHNCQUNadEIsT0FBT0YsZUFBZUMsTUFBTTtBQUFBLHNCQUM1QndNLFVBQVU3TSxvQkFBb0JLLE9BQU9SLE1BQU0sSUFBSSxVQUFVO0FBQUEsc0JBQ3pEdU4sVUFBVUwsV0FBVyxXQUFXO0FBQUEsc0JBQ2hDTSxPQUFPTixXQUFXLEdBQUdDLFdBQVcsT0FBTztBQUFBLHNCQUN2Q00sUUFBUVAsV0FBVyxJQUFJO0FBQUEsc0JBQ3ZCUSxZQUFZUixXQUFXLFlBQVlFO0FBQUFBLG9CQUNyQztBQUNBLDJCQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLFdBQVU7QUFBQSx3QkFDVjtBQUFBLHdCQUVDNU0saUJBQU92QyxJQUFJOEIsWUFBWSxNQUFNLFlBQzVCO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVix1QkFBdUI7QUFBQSw0QkFDdkI7QUFBQSw0QkFDQSxPQUFPbEMsUUFBUTJDLE9BQU92QyxHQUFHLEtBQUs7QUFBQSw0QkFDOUIsVUFBVSxDQUFDK0csVUFDVGxILFdBQVcsQ0FBQ2dHLFVBQVU7QUFBQSw4QkFDcEIsR0FBR0E7QUFBQUEsOEJBQ0gsQ0FBQ3RELE9BQU92QyxHQUFHLEdBQUcrRztBQUFBQSw0QkFDaEIsRUFBRTtBQUFBLDRCQUVKLGNBQWMsQ0FBQzJJLE9BQU9DLFdBQVc7QUFDL0Isb0NBQU1DLFFBQ0pELFFBQVFFLFVBQVVDLFNBQVMsRUFBRWhPLFlBQVksS0FBSztBQUNoRCxxQ0FBTzhOLE1BQU01TixTQUFTME4sTUFBTTVOLFlBQVksQ0FBQztBQUFBLDRCQUMzQztBQUFBLDRCQUVBO0FBQUEscURBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUEyQjtBQUFBLDhCQUMxQixDQUFDLEdBQUcsSUFBSW1LLElBQUluTixTQUFTOEIsSUFBSSxDQUFDcUYsU0FBU0EsS0FBSzFELE9BQU92QyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUVZO0FBQUFBLGdDQUN0RCxDQUFDbUcsVUFDQyx1QkFBQyxPQUFPLFFBQVAsRUFBa0MsT0FBTzFCLE9BQU8wQixLQUFLLEdBQ25EQSxtQkFEaUIxQixPQUFPMEIsS0FBSyxHQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsOEJBRUo7QUFBQTtBQUFBO0FBQUEsMEJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF5QkE7QUFBQTtBQUFBLHNCQTlCRyxVQUFVeEUsT0FBT3ZDLEdBQUc7QUFBQSxzQkFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFpQ0E7QUFBQSxrQkFFSixDQUFDO0FBQUEscUJBbERIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbURBO0FBQUEsbUJBNUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkdBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ2Q4SCx3QkFBY2xILElBQUksQ0FBQ29FLEtBQUt0QixVQUFVO0FBQ2pDLHNCQUFNcU0saUJBQWlCak4sUUFBUWtDLElBQUlyRyxpQkFBaUIsQ0FBQztBQUNyRCxzQkFBTXFSLGlCQUFpQjFQLGlCQUFpQjBFLElBQUk3RyxPQUFPO0FBQ25ELHNCQUFNOFIsZUFBZXpQLGtCQUFrQndFLElBQUk3RyxPQUFPO0FBQ2xELHVCQUNFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLFNBQVMsTUFBTXdHLFlBQVlLLElBQUlyQixHQUFHO0FBQUEsb0JBQ2xDLFlBQVksQ0FBQ2EsTUFBTWUsa0JBQWtCZixHQUFHUSxHQUFHO0FBQUEsb0JBQzNDLGFBQWEsTUFBTVMsbUJBQW1CVCxHQUFHO0FBQUEsb0JBQ3pDLFFBQVEsQ0FBQ1IsTUFBTW1CLGNBQWNuQixHQUFHUSxHQUFHO0FBQUEsb0JBQ25DLFdBQVcsR0FBR3hGLE9BQU93RixJQUFJckIsR0FBRyxJQUN4QixnQkFDQW9NLGlCQUNFLDRDQUNBck0sUUFBUSxNQUFNLElBQ1osOEJBQ0EsOEJBQThCLElBQ2hDc00saUJBQWlCLGVBQWUsRUFBRSxJQUFJQyxlQUFlLCtCQUErQixFQUFFO0FBQUEsb0JBSzVGO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLE9BQU8sRUFBRXpOLE9BQU8sUUFBUXVNLFVBQVUsT0FBTztBQUFBLDBCQUN6QztBQUFBLDBCQUNBLFNBQVMsQ0FBQ3ZLLE1BQU1BLEVBQUVTLGdCQUFnQjtBQUFBLDBCQUNsQyxhQUFhLENBQUNULE1BQU1PLGdCQUFnQlAsR0FBR1EsR0FBRztBQUFBLDBCQUMxQyxXQUFXcUI7QUFBQUEsMEJBQ1gsT0FBTTtBQUFBLDBCQUVOLGlDQUFDLGdCQUFhLFdBQVUseUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTZDO0FBQUE7QUFBQSx3QkFUL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVVBO0FBQUEsc0JBQ0M0SCxlQUFlck4sSUFBSSxDQUFDMkIsV0FBVztBQUM5Qiw4QkFBTTBNLFdBQVd0TixXQUFXSyxTQUFTTyxPQUFPdkMsR0FBRztBQUMvQyw4QkFBTWtQLGNBQWNELFdBQVdWLFVBQVVoTSxPQUFPdkMsR0FBRyxJQUFJbVA7QUFDdkQsOEJBQU1yTCxRQUFRO0FBQUEsMEJBQ1p0QixPQUFPRixlQUFlQyxNQUFNO0FBQUEsMEJBQzVCd00sVUFBVTdNLG9CQUFvQkssT0FBT1IsTUFBTSxJQUFJLFVBQVU7QUFBQSwwQkFDekRtTyxVQUFVO0FBQUEsMEJBQ1ZDLFlBQVk7QUFBQSwwQkFDWkMsVUFBVWxPLG9CQUFvQkssT0FBT1IsTUFBTSxJQUFJLFVBQVU7QUFBQSwwQkFDekR1TixVQUFVTCxXQUFXLFdBQVc7QUFBQSwwQkFDaENNLE9BQU9OLFdBQVcsR0FBR0MsV0FBVyxPQUFPO0FBQUEsMEJBQ3ZDTSxRQUFRUCxXQUFXLElBQUk7QUFBQSwwQkFDdkJRLFlBQVlSLFdBQVl2TCxRQUFRLE1BQU0sSUFBSSxZQUFZLFlBQWF5TDtBQUFBQSx3QkFDckU7QUFDQSwrQkFDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFFQyxXQUFVO0FBQUEsNEJBQ1Y7QUFBQSw0QkFDQSxlQUFlLE1BQU1uUixjQUFjZ0gsSUFBSTdHLE9BQU8sQ0FBQztBQUFBLDRCQUU5QzZHLGNBQUl6QyxPQUFPdkMsR0FBRztBQUFBO0FBQUEsMEJBTFYsR0FBRzBELEtBQUssSUFBSW5CLE9BQU92QyxHQUFHO0FBQUEsMEJBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT0E7QUFBQSxzQkFFSixDQUFDO0FBQUE7QUFBQTtBQUFBLGtCQXBESTBEO0FBQUFBLGtCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0RBO0FBQUEsY0FFSixDQUFDLEtBOURIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0RBO0FBQUE7QUFBQTtBQUFBLFVBcExGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXFMQTtBQUFBO0FBQUEsTUE3TEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOExBLEtBL0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnTUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSx5QkFBd0Isb0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxRQUM1QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT3hEO0FBQUFBLFlBQ1AsVUFBVSxDQUFDNkcsVUFBVTVHLFlBQVkyTCxPQUFPL0UsS0FBSyxDQUFDO0FBQUEsWUFDOUMsV0FBVTtBQUFBLFlBQ1YsTUFBSztBQUFBLFlBQ0wsbUJBQW1CLENBQUNzSixnQkFBZ0JBLFlBQVlDO0FBQUFBLFlBRS9DLFdBQUMsR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLEVBQUUxUDtBQUFBQSxjQUFJLENBQUN1TCxTQUN6Qix1QkFBQyxPQUFPLFFBQVAsRUFBeUIsT0FBT0EsTUFDOUJBLGtCQURpQkEsTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxXQWZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNOU0sZUFBZSxDQUFDd0csU0FBUytCLEtBQUsySSxJQUFJLEdBQUcxSyxPQUFPLENBQUMsQ0FBQztBQUFBLFlBQzdELFVBQVV6RyxnQkFBZ0I7QUFBQSxZQUMxQixXQUFVO0FBQUEsWUFFVixpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQTtBQUFBLFVBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxVQUMxQ0E7QUFBQUEsVUFBWTtBQUFBLFVBQUt3SSxLQUFLMkksSUFBSSxHQUFHNUksVUFBVTtBQUFBLGFBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFDUHRJLGVBQWUsQ0FBQ3dHLFNBQVMrQixLQUFLNEksSUFBSTdJLFlBQVk5QixPQUFPLENBQUMsQ0FBQztBQUFBLFlBRXpELFVBQVV6RyxnQkFBZ0J1SSxjQUFjQSxlQUFlO0FBQUEsWUFDdkQsV0FBVTtBQUFBLFlBRVYsaUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBO0FBQUEsVUFQbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsU0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdDQTtBQUFBLE9BdFhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1WEE7QUFFSjtBQUFFOUksR0Exa0NJZCxXQUFTO0FBQUEwUyxLQUFUMVM7QUE0a0NOLGVBQWVBO0FBQVUsSUFBQTBTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJ1c2VFZmZlY3QiLCJTZWFyY2giLCJEb3dubG9hZCIsIlByaW50ZXIiLCJDaGV2cm9uTGVmdCIsIkNoZXZyb25SaWdodCIsIlgiLCJHcmlwVmVydGljYWwiLCJpbWFnZUlucHV0IiwiQ2lyY3VsYXJMb2FkZXIiLCJNb2RhbCIsIlNlbGVjdCIsImxvZ28iLCJGYUZpbGVFeGNlbCIsIkZhRmlsZVBkZiIsIlJlYWN0RE9NU2VydmVyIiwiRGF0YVRhYmxlIiwidXBkYXRlSGFuZGxlciIsInByaW50SGVhZGVyVmFsdWVzIiwicHJpbnRIZWFkZXJLZXlzIiwiY2F0Y2hlciIsImlzRXhwb3J0RW5hYmxlZCIsImlzU2VhcmNoUmVxdWlyZWQiLCJkYXRhIiwiY29sdW1ucyIsImV4cG9ydENvbHMiLCJleHBvcnRlZEZpbGVOYW1lIiwiZXhwb3J0ZWRQZGZOYW1lIiwiY3JlYXRlZERhdGVDb2x1bW4iLCJwaW5uZWRSaWdodENvbHVtbnMiLCJfcyIsInNhZmVEYXRhIiwiQXJyYXkiLCJpc0FycmF5Iiwic2FmZUNvbHVtbnMiLCJleHBvcnRDb2x1bW5zIiwibGVuZ3RoIiwiY3VycmVudFBhZ2UiLCJzZXRDdXJyZW50UGFnZSIsImN1cnJlbnRVc2VyTmFtZSIsInNldEN1cnJlbnRVc2VyTmFtZSIsImFjdGl2ZSIsInNldEFjdGl2ZSIsInNlYXJjaFF1ZXJ5Iiwic2V0U2VhcmNoUXVlcnkiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsInNvcnRDb25maWciLCJzZXRTb3J0Q29uZmlnIiwia2V5IiwiZGlyZWN0aW9uIiwicGFnZVNpemUiLCJzZXRQYWdlU2l6ZSIsImxvY2FsRGF0YSIsInNldExvY2FsRGF0YSIsImRyYWdnZWRSb3dJZCIsInNldERyYWdnZWRSb3dJZCIsImRyYWdPdmVyUm93SWQiLCJzZXREcmFnT3ZlclJvd0lkIiwiY29sdW1uT3JkZXIiLCJzZXRDb2x1bW5PcmRlciIsIm1hcCIsImNvbCIsImRyYWdnZWRDb2x1bW5LZXkiLCJzZXREcmFnZ2VkQ29sdW1uS2V5IiwiZHJhZ092ZXJDb2x1bW5LZXkiLCJzZXREcmFnT3ZlckNvbHVtbktleSIsInNob3dFeHBvcnRNb2RhbCIsInNldFNob3dFeHBvcnRNb2RhbCIsImV4cG9ydFR5cGUiLCJzZXRFeHBvcnRUeXBlIiwic2VsZWN0ZWRFeHBvcnRDb2x1bW5zIiwic2V0U2VsZWN0ZWRFeHBvcnRDb2x1bW5zIiwiZGVmYXVsdFZpc2libGVDb2x1bW5zIiwidmlzaWJsZUNvbHVtbnMiLCJzZXRWaXNpYmxlQ29sdW1ucyIsInBpbm5lZEtleXMiLCJhY3Rpb25Db2wiLCJmaW5kIiwidG9Mb3dlckNhc2UiLCJoZWFkZXIiLCJpbmNsdWRlcyIsInRyaW0iLCJpc0xvbmdDb250ZW50Q29sdW1uIiwibG9uZ0NvbnRlbnRIZWFkZXJzIiwic29tZSIsImxvbmdIZWFkZXIiLCJnZXRDb2x1bW5XaWR0aCIsImNvbHVtbiIsIndpZHRoIiwiZ2V0V2lkdGhJblB4Iiwid2lkdGhTdHIiLCJudW0iLCJwYXJzZUZsb2F0IiwiaXNOYU4iLCJpc1RvZGF5IiwiZGF0ZVN0cmluZyIsImRhdGUiLCJEYXRlIiwidG9kYXkiLCJzZXRIb3VycyIsImdldFRpbWUiLCJ0b2dnbGVDb2x1bW4iLCJmaWx0ZXIiLCJ0ZW1wRGF0YSIsImZvckVhY2giLCJlbGUiLCJpbmRleCIsIl9pZCIsImRvY3VtZW50IiwiYm9keSIsInN0eWxlIiwib3ZlcmZsb3ciLCJ1c2VyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInVzZXJPYmoiLCJKU09OIiwicGFyc2UiLCJuYW1lIiwiZnVsbF9uYW1lIiwiZSIsImNvbnNvbGUiLCJlcnJvciIsIm9uU2VsZWN0Um93IiwidGVtcEFjdGl2ZSIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVEcmFnU3RhcnQiLCJyb3ciLCJzdG9wUHJvcGFnYXRpb24iLCJkYXRhVHJhbnNmZXIiLCJlZmZlY3RBbGxvd2VkIiwic2V0RGF0YSIsIlN0cmluZyIsImVyciIsImhhbmRsZURyYWdPdmVyUm93IiwicHJldmVudERlZmF1bHQiLCJoYW5kbGVEcmFnTGVhdmVSb3ciLCJjdXJyZW50IiwiaGFuZGxlRHJvcFJvdyIsInRhcmdldFJvdyIsInByZXYiLCJ1cGRhdGVkIiwiZnJvbUluZGV4IiwiZmluZEluZGV4IiwiaXRlbSIsInRvSW5kZXgiLCJtb3ZlZEl0ZW0iLCJzcGxpY2UiLCJoYW5kbGVEcmFnRW5kUm93IiwiaGFuZGxlQ29sdW1uRHJhZ1N0YXJ0IiwiaGFuZGxlQ29sdW1uRHJhZ092ZXIiLCJoYW5kbGVDb2x1bW5EcmFnTGVhdmUiLCJoYW5kbGVDb2x1bW5Ecm9wIiwidGFyZ2V0Q29sdW1uIiwiaW5kZXhPZiIsImhhbmRsZUNvbHVtbkRyYWdFbmQiLCJzZWFyY2hEYXRhIiwidmFsdWVzIiwidmFsdWUiLCJmaWx0ZXJEYXRhIiwiZW50cmllcyIsImV2ZXJ5Iiwic29ydERhdGEiLCJzb3J0IiwiYSIsImIiLCJhVmFsIiwiYlZhbCIsInByb2Nlc3NlZERhdGEiLCJwcm9jZXNzZWQiLCJ0b3RhbFBhZ2VzIiwiTWF0aCIsImNlaWwiLCJwYWdpbmF0ZWREYXRhIiwic2xpY2UiLCJnZXRDZWxsVGV4dCIsIlJlYWN0IiwiaXNWYWxpZEVsZW1lbnQiLCJodG1sIiwicmVuZGVyVG9TdGF0aWNNYXJrdXAiLCJkaXYiLCJjcmVhdGVFbGVtZW50IiwiaW5uZXJIVE1MIiwidGV4dENvbnRlbnQiLCJpbm5lclRleHQiLCJleHBvcnRUb0V4Y2VsIiwibm93IiwiZmlsZU5hbWVFeGNlbCIsImdldERhdGUiLCJwYWRTdGFydCIsImdldE1vbnRoIiwiZ2V0RnVsbFllYXIiLCJnZXRIb3VycyIsImdldE1pbnV0ZXMiLCJnZXRTZWNvbmRzIiwic2VsZWN0ZWRDb2xzIiwiaGVhZGVycyIsImpvaW4iLCJyb3dzIiwidmFsIiwiY2xlYW4iLCJyZXBsYWNlIiwiY3N2IiwiYmxvYiIsIkJsb2IiLCJ0eXBlIiwidXJsIiwid2luZG93IiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiaHJlZiIsImZpbGVCYXNlTmFtZSIsImRvd25sb2FkIiwiY2xpY2siLCJyZXZva2VPYmplY3RVUkwiLCJoYW5kbGVDb2x1bW5TZWxlY3Rpb24iLCJjb2x1bW5LZXkiLCJpc0NoZWNrZWQiLCJoYW5kbGVTZWxlY3RBbGwiLCJjaGFuZ2VDb2xvciIsInByaW50VG9QREYiLCJzaG93U3VtbWFyeUNhcmRzIiwic2hvd0NvdW50Q2FyZHMiLCJyZXBvcnRUeXBlIiwiZmlsZU5hbWUiLCJwcmludENvbnRlbnQiLCJkYXRlVGltZVN0cmluZyIsInRvTG9jYWxlU3RyaW5nIiwiZGF0ZVN0eWxlIiwidGltZVN0eWxlIiwidG90YWxBbW91bnQiLCJyZWR1Y2UiLCJzdW0iLCJhbW91bnQiLCJBbW91bnQiLCJ0b3RhbENhc2giLCJtb2RlIiwiTnVtYmVyIiwidG90YWxPbmxpbmUiLCJ0b3RhbEN1c3RvbWVycyIsIlNldCIsInVzZXJfaWQiLCJzaXplIiwidG90YWxPbmxpbmVDb3VudCIsInRvdGFsQ2FzaENvdW50IiwiaXNTcGVjaWFsUmVwb3J0IiwidG90YWxJbk91dFJvd0h0bWwiLCJyZW1haW5pbmdDYXJkc0h0bWwiLCJyZW1haW5pbmdLZXlzIiwicmVtYWluaW5nVmFsdWVzIiwiaWR4IiwiaSIsImltZyIsIkltYWdlIiwic3JjIiwib25sb2FkIiwiYXBwZW5kQ2hpbGQiLCJ0aXRsZSIsInByaW50IiwicmVtb3ZlQ2hpbGQiLCJoYW5kbGVTb3J0Iiwib3JkZXJlZFNhZmVDb2x1bW5zIiwiYnlLZXkiLCJNYXAiLCJrbm93biIsImhhcyIsImdldCIsInVua25vd25Db2xzIiwidmlzaWJsZUNvbHVtbnNTZXQiLCJ2aXNpYmxlU2FmZUNvbHVtbnMiLCJyZWd1bGFyQ29sdW1ucyIsInBpbm5lZENvbHVtbnMiLCJvcmRlcmVkQ29sdW1ucyIsInBpbm5lZFdpZHRocyIsImN1bXVsYXRpdmVPZmZzZXQiLCJwaW5uZWRPZmZzZXRzIiwicmV2ZXJzZWRJbmRleCIsIm9mZnNldCIsIm9mZnNldE1hcCIsImhhbmRsZVNlbGVjdEFsbENvbHVtbnMiLCJjaGVja2VkIiwiYWxsQ29sdW1uc1NlbGVjdGVkIiwidGFyZ2V0IiwibWF4SGVpZ2h0Iiwib3ZlcmZsb3dZIiwib3ZlcmZsb3dYIiwibWluV2lkdGgiLCJ0YWJsZUxheW91dCIsImlzUGlubmVkIiwicmlnaHRPZmZzZXQiLCJ1bmRlZmluZWQiLCJpc0NvbHVtbkRyYWdnZWQiLCJpc0NvbHVtbkRyb3BUYXJnZXQiLCJwb3NpdGlvbiIsInJpZ2h0IiwiekluZGV4IiwiYmFja2dyb3VuZCIsImlucHV0Iiwib3B0aW9uIiwibGFiZWwiLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwiaXNDcmVhdGVkVG9kYXkiLCJpc0JlaW5nRHJhZ2dlZCIsImlzRHJvcFRhcmdldCIsIndvcmRXcmFwIiwid2hpdGVTcGFjZSIsIm1heFdpZHRoIiwidHJpZ2dlck5vZGUiLCJwYXJlbnRFbGVtZW50IiwibWF4IiwibWluIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGF0YXRhYmxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZU1lbW8sIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIFNlYXJjaCxcclxuICBEb3dubG9hZCxcclxuICBQcmludGVyLFxyXG4gIENoZXZyb25MZWZ0LFxyXG4gIENoZXZyb25SaWdodCxcclxuICBYLFxyXG4gIEdyaXBWZXJ0aWNhbCxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCBpbWFnZUlucHV0IGZyb20gXCIuLi8uLi9hc3NldHMvaW1hZ2VzL0FnZW50LnBuZ1wiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgTW9kYWwsIFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBsb2dvIGZyb20gXCIuLi8uLi9hc3NldHMvaW1hZ2VzL215Y2hpdHMucG5nXCI7XHJcbmltcG9ydCB7IEZhRmlsZUV4Y2VsIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IEZhRmlsZVBkZiB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgUmVhY3RET01TZXJ2ZXIgZnJvbSBcInJlYWN0LWRvbS9zZXJ2ZXJcIjtcclxuXHJcbmNvbnN0IERhdGFUYWJsZSA9ICh7XHJcbiAgdXBkYXRlSGFuZGxlciA9ICgpID0+IHsgfSxcclxuICBwcmludEhlYWRlclZhbHVlcyA9IFtdLFxyXG4gIHByaW50SGVhZGVyS2V5cyA9IFtdLFxyXG4gIGNhdGNoZXIgPSBcIl9pZFwiLFxyXG4gIGlzRXhwb3J0RW5hYmxlZCA9IHRydWUsXHJcbiAgaXNTZWFyY2hSZXF1aXJlZCA9IHRydWUsXHJcbiAgZGF0YSA9IFtdLFxyXG4gIGNvbHVtbnMgPSBbXSxcclxuICBleHBvcnRDb2xzID0gW10sXHJcbiAgZXhwb3J0ZWRGaWxlTmFtZSA9IFwiZXhwb3J0LmNzdlwiLFxyXG4gIGV4cG9ydGVkUGRmTmFtZSA9IFwiZXhwb3J0LnBkZlwiLFxyXG4gIGNyZWF0ZWREYXRlQ29sdW1uID0gXCJjcmVhdGVkQXRcIixcclxuICBwaW5uZWRSaWdodENvbHVtbnMgPSBudWxsLCAvLyBhcnJheSBvZiBjb2x1bSBrZXlzIHRvIHBpbiByaWdodFxyXG59KSA9PiB7XHJcbiAgY29uc3Qgc2FmZURhdGEgPSBBcnJheS5pc0FycmF5KGRhdGEpID8gZGF0YSA6IFtdO1xyXG4gIGNvbnN0IHNhZmVDb2x1bW5zID0gQXJyYXkuaXNBcnJheShjb2x1bW5zKSA/IGNvbHVtbnMgOiBbXTtcclxuICBjb25zdCBleHBvcnRDb2x1bW5zID1cclxuICAgIGV4cG9ydENvbHM/Lmxlbmd0aCA8PSAwXHJcbiAgICAgID8gQXJyYXkuaXNBcnJheShjb2x1bW5zKVxyXG4gICAgICAgID8gY29sdW1uc1xyXG4gICAgICAgIDogW11cclxuICAgICAgOiBBcnJheS5pc0FycmF5KGV4cG9ydENvbHMpXHJcbiAgICAgICAgPyBleHBvcnRDb2xzXHJcbiAgICAgICAgOiBbXTtcclxuXHJcbiAgY29uc3QgW2N1cnJlbnRQYWdlLCBzZXRDdXJyZW50UGFnZV0gPSB1c2VTdGF0ZSgxKTtcclxuICBjb25zdCBbY3VycmVudFVzZXJOYW1lLCBzZXRDdXJyZW50VXNlck5hbWVdID0gdXNlU3RhdGUoXCJTeXN0ZW0gVXNlclwiKTtcclxuICBjb25zdCBbYWN0aXZlLCBzZXRBY3RpdmVdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2ZpbHRlcnMsIHNldEZpbHRlcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzb3J0Q29uZmlnLCBzZXRTb3J0Q29uZmlnXSA9IHVzZVN0YXRlKHsga2V5OiBudWxsLCBkaXJlY3Rpb246IFwiYXNjXCIgfSk7XHJcbiAgY29uc3QgW3BhZ2VTaXplLCBzZXRQYWdlU2l6ZV0gPSB1c2VTdGF0ZSgxMDApO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIE5FVzogbG9jYWwsIHJlLW9yZGVyYWJsZSBjb3B5IG9mIHRoZSBpbmNvbWluZyBkYXRhIC0tLS0tLS0tLS1cclxuICAvLyBUaGlzIGxldHMgcm93cyBiZSBkcmFnZ2VkL2Ryb3BwZWQgdG8gcmVhcnJhbmdlIHRoZW0gd2l0aG91dCB0b3VjaGluZ1xyXG4gIC8vIGFueSBvZiB0aGUgZXhpc3Rpbmcgc2VhcmNoL2ZpbHRlci9zb3J0L2V4cG9ydC9wcmludC9wYWdpbmF0aW9uIGxvZ2ljLFxyXG4gIC8vIHdoaWNoIGFsbCBjb250aW51ZSB0byByZWFkIGZyb20gdGhpcyBhcnJheSBleGFjdGx5IGFzIHRoZXkgdXNlZCB0b1xyXG4gIC8vIHJlYWQgZnJvbSBgc2FmZURhdGFgLlxyXG4gIGNvbnN0IFtsb2NhbERhdGEsIHNldExvY2FsRGF0YV0gPSB1c2VTdGF0ZShzYWZlRGF0YSk7XHJcbiAgY29uc3QgW2RyYWdnZWRSb3dJZCwgc2V0RHJhZ2dlZFJvd0lkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtkcmFnT3ZlclJvd0lkLCBzZXREcmFnT3ZlclJvd0lkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0TG9jYWxEYXRhKEFycmF5LmlzQXJyYXkoZGF0YSkgPyBkYXRhIDogW10pO1xyXG4gIH0sIFtkYXRhXSk7XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gTkVXOiByZS1vcmRlcmFibGUgY29sdW1uIG9yZGVyIChtaXJyb3JzIHRoZSByb3cgZHJhZyBwYXR0ZXJuKSAtLS0tLS0tLS0tXHJcbiAgLy8gSG9sZHMgY29sdW1uICprZXlzKiBpbiB0aGUgb3JkZXIgdGhlIHVzZXIgd2FudHMgdGhlbSBkaXNwbGF5ZWQuIEluaXRpYWxpemVkXHJcbiAgLy8gb25jZSBmcm9tIHRoZSBpbmNvbWluZyBjb2x1bW5zLCBqdXN0IGxpa2UgYHZpc2libGVDb2x1bW5zYCBiZWxvdywgc28gaXRcclxuICAvLyB3b24ndCBnZXQgc3RvbXBlZCBvbiBldmVyeSByZS1yZW5kZXIuXHJcbiAgY29uc3QgW2NvbHVtbk9yZGVyLCBzZXRDb2x1bW5PcmRlcl0gPSB1c2VTdGF0ZShcclxuICAgIHNhZmVDb2x1bW5zLm1hcCgoY29sKSA9PiBjb2wua2V5KVxyXG4gICk7XHJcbiAgY29uc3QgW2RyYWdnZWRDb2x1bW5LZXksIHNldERyYWdnZWRDb2x1bW5LZXldID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2RyYWdPdmVyQ29sdW1uS2V5LCBzZXREcmFnT3ZlckNvbHVtbktleV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgLy8gTmV3IHN0YXRlcyBmb3IgZXhwb3J0IG1vZGFsXHJcbiAgY29uc3QgW3Nob3dFeHBvcnRNb2RhbCwgc2V0U2hvd0V4cG9ydE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZXhwb3J0VHlwZSwgc2V0RXhwb3J0VHlwZV0gPSB1c2VTdGF0ZShcImV4Y2VsXCIpOyAvLyBUcmFja3Mgd2hldGhlciBleHBvcnRpbmcgdG8gRXhjZWwgb3IgUERGXHJcbiAgY29uc3QgW3NlbGVjdGVkRXhwb3J0Q29sdW1ucywgc2V0U2VsZWN0ZWRFeHBvcnRDb2x1bW5zXSA9IHVzZVN0YXRlKFxyXG4gICAgZXhwb3J0Q29sdW1ucy5tYXAoKGNvbCkgPT4gY29sLmtleSlcclxuICApO1xyXG5cclxuICAvLyBDb2x1bW4gdmlzaWJpbGl0eSBjb250cm9sXHJcbiAgY29uc3QgZGVmYXVsdFZpc2libGVDb2x1bW5zID0gW1xyXG4gICAgLi4uc2FmZUNvbHVtbnMubWFwKChjb2wpID0+IGNvbC5rZXkpLFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IFt2aXNpYmxlQ29sdW1ucywgc2V0VmlzaWJsZUNvbHVtbnNdID0gdXNlU3RhdGUoZGVmYXVsdFZpc2libGVDb2x1bW5zKTtcclxuXHJcbiAgLy8gLS0tLS0tLS0tLSBEZXRlcm1pbmUgcGlubmVkIGNvbHVtbnMgLS0tLS0tLS0tLVxyXG4gIC8vIElmIHByb3AgaXMgcHJvdmlkZWQgKGFuZCBub3QgbnVsbCksIHVzZSBleGFjdGx5IHRoYXQgbGlzdC5cclxuICAvLyBPdGhlcndpc2UsIGF1dG/igJFkZXRlY3QgYW4gXCJhY3Rpb25cIiBjb2x1bW4gKGtleSA9PT0gJ2FjdGlvbicgb3IgaGVhZGVyIGluY2x1ZGVzICdBY3Rpb24nKS5cclxuICBjb25zdCBwaW5uZWRLZXlzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAocGlubmVkUmlnaHRDb2x1bW5zICYmIEFycmF5LmlzQXJyYXkocGlubmVkUmlnaHRDb2x1bW5zKSkge1xyXG4gICAgICByZXR1cm4gcGlubmVkUmlnaHRDb2x1bW5zOyAvLyB1c2VyIGhhcyBmdWxsIGNvbnRyb2xcclxuICAgIH1cclxuICAgIGNvbnN0IGFjdGlvbkNvbCA9IHNhZmVDb2x1bW5zLmZpbmQoXHJcbiAgICAgIChjb2wpID0+XHJcbiAgICAgICAgY29sLmtleS50b0xvd2VyQ2FzZSgpID09PSBcImFjdGlvblwiIHx8XHJcbiAgICAgICAgKGNvbC5oZWFkZXIgJiYgW1wiYWN0aW9uXCIsIFwiYWN0aW9uc1wiXS5pbmNsdWRlcyhjb2wuaGVhZGVyLnRvTG93ZXJDYXNlKCkudHJpbSgpKSlcclxuICAgICk7XHJcbiAgICByZXR1cm4gYWN0aW9uQ29sID8gW2FjdGlvbkNvbC5rZXldIDogW107XHJcbiAgfSwgW3Bpbm5lZFJpZ2h0Q29sdW1ucywgc2FmZUNvbHVtbnNdKTtcclxuXHJcbiAgLy8gSGVscGVyIGZ1bmN0aW9uIHRvIGlkZW50aWZ5IGNvbHVtbnMgd2l0aCBsb25nIGNvbnRlbnRcclxuICBjb25zdCBpc0xvbmdDb250ZW50Q29sdW1uID0gKGhlYWRlcikgPT4ge1xyXG4gICAgY29uc3QgbG9uZ0NvbnRlbnRIZWFkZXJzID0gW1xyXG4gICAgICAnYWRkcmVzcycsICdkZXNjcmlwdGlvbicsICduYW1lJywgJ2N1c3RvbWVyIG5hbWUnLCAnZnVsbCBuYW1lJyxcclxuICAgICAgJ2xvY2F0aW9uJywgJ2RldGFpbHMnLCAncmVtYXJrcycsICdub3RlcycsICdjb21tZW50JywgJ2NvbW1lbnRzJ1xyXG4gICAgXTtcclxuICAgIHJldHVybiBsb25nQ29udGVudEhlYWRlcnMuc29tZShsb25nSGVhZGVyID0+XHJcbiAgICAgIGhlYWRlci50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGxvbmdIZWFkZXIpXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIEdldCBjb2x1bW4gd2lkdGggYmFzZWQgb24gY29sdW1uLndpZHRoIG9yIGNvbnRlbnQgdHlwZVxyXG4gIGNvbnN0IGdldENvbHVtbldpZHRoID0gKGNvbHVtbikgPT4ge1xyXG4gICAgaWYgKGNvbHVtbi53aWR0aCkge1xyXG4gICAgICByZXR1cm4gdHlwZW9mIGNvbHVtbi53aWR0aCA9PT0gJ251bWJlcicgPyBgJHtjb2x1bW4ud2lkdGh9cHhgIDogY29sdW1uLndpZHRoO1xyXG4gICAgfVxyXG4gICAgaWYgKGlzTG9uZ0NvbnRlbnRDb2x1bW4oY29sdW1uLmhlYWRlcikpIHtcclxuICAgICAgcmV0dXJuICczMDBweCc7XHJcbiAgICB9XHJcbiAgICBpZiAoY29sdW1uLmtleS50b0xvd2VyQ2FzZSgpID09PSAnYWN0aW9uJykge1xyXG4gICAgICByZXR1cm4gJzEwMHB4JztcclxuICAgIH1cclxuICAgIHJldHVybiAnYXV0byc7XHJcbiAgfTtcclxuXHJcbiAgLy8gUGFyc2Ugd2lkdGggdG8gbnVtYmVyIG9mIHBpeGVscyAoZm9yIG9mZnNldCBjYWxjdWxhdGlvbilcclxuICBjb25zdCBnZXRXaWR0aEluUHggPSAod2lkdGhTdHIpID0+IHtcclxuICAgIGlmICh0eXBlb2Ygd2lkdGhTdHIgPT09ICdudW1iZXInKSByZXR1cm4gd2lkdGhTdHI7XHJcbiAgICBpZiAodHlwZW9mIHdpZHRoU3RyID09PSAnc3RyaW5nJykge1xyXG4gICAgICBjb25zdCBudW0gPSBwYXJzZUZsb2F0KHdpZHRoU3RyKTtcclxuICAgICAgcmV0dXJuIGlzTmFOKG51bSkgPyAxMDAgOiBudW07IC8vIGZhbGxiYWNrXHJcbiAgICB9XHJcbiAgICByZXR1cm4gMTAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGlzVG9kYXkgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgaWYgKCFkYXRlU3RyaW5nKSByZXR1cm4gZmFsc2U7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBkYXRlLnNldEhvdXJzKDAsIDAsIDAsIDApO1xyXG4gICAgdG9kYXkuc2V0SG91cnMoMCwgMCwgMCwgMCk7XHJcbiAgICByZXR1cm4gZGF0ZS5nZXRUaW1lKCkgPT09IHRvZGF5LmdldFRpbWUoKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB0b2dnbGVDb2x1bW4gPSAoa2V5KSA9PiB7XHJcbiAgICBpZiAodmlzaWJsZUNvbHVtbnMuaW5jbHVkZXMoa2V5KSkge1xyXG4gICAgICBzZXRWaXNpYmxlQ29sdW1ucyh2aXNpYmxlQ29sdW1ucy5maWx0ZXIoKGNvbCkgPT4gY29sICE9PSBrZXkpKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFZpc2libGVDb2x1bW5zKFsuLi52aXNpYmxlQ29sdW1ucywga2V5XSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHRlbXBEYXRhID0ge307XHJcbiAgICBkYXRhLmZvckVhY2goKGVsZSwgaW5kZXgpID0+IHtcclxuICAgICAgdGVtcERhdGFbZWxlLl9pZF0gPSBmYWxzZTtcclxuICAgIH0pO1xyXG4gICAgc2V0QWN0aXZlKHRlbXBEYXRhKTtcclxuICB9LCBbZGF0YV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNob3dFeHBvcnRNb2RhbCkge1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gXCJoaWRkZW5cIjtcclxuICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gXCJcIjtcclxuICAgICAgfTtcclxuICAgIH1cclxuICB9LCBbc2hvd0V4cG9ydE1vZGFsXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgaWYgKHVzZXIpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuICAgICAgICBjb25zdCBuYW1lID1cclxuICAgICAgICAgIHVzZXJPYmo/LmZ1bGxfbmFtZSB8fFxyXG4gICAgICAgICAgdXNlck9iaj8ubmFtZSB8fFxyXG4gICAgICAgICAgdXNlck9iaj8udXNlcj8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICB1c2VyT2JqPy51c2VyPy5uYW1lIHx8XHJcbiAgICAgICAgICBcIlN5c3RlbSBVc2VyXCI7XHJcbiAgICAgICAgc2V0Q3VycmVudFVzZXJOYW1lKG5hbWUpO1xyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSB1c2VyIGZyb20gbG9jYWxTdG9yYWdlOlwiLCBlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3Qgb25TZWxlY3RSb3cgPSAoX2lkKSA9PiB7XHJcbiAgICBjb25zdCB0ZW1wQWN0aXZlID0gYWN0aXZlO1xyXG4gICAgaWYgKE9iamVjdC5rZXlzKGFjdGl2ZSkubGVuZ3RoID4gMSkge1xyXG4gICAgICBPYmplY3Qua2V5cyhhY3RpdmUpLmZvckVhY2goKGtleSkgPT4ge1xyXG4gICAgICAgIHRlbXBBY3RpdmVba2V5XSA9IGZhbHNlO1xyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWN0aXZlKHsgLi4udGVtcEFjdGl2ZSwgW19pZF06IHRydWUgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gLS0tLS0tLS0tLSBORVc6IGRyYWctYW5kLWRyb3Agcm93IHJlb3JkZXJpbmcgaGFuZGxlcnMgLS0tLS0tLS0tLVxyXG4gIGNvbnN0IGhhbmRsZURyYWdTdGFydCA9IChlLCByb3cpID0+IHtcclxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICBzZXREcmFnZ2VkUm93SWQocm93W2NhdGNoZXJdKTtcclxuICAgIC8vIE5lZWRlZCBmb3IgRmlyZWZveCB0byBhbGxvdyB0aGUgZHJhZyB0byBzdGFydFxyXG4gICAgdHJ5IHtcclxuICAgICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9IFwibW92ZVwiO1xyXG4gICAgICBlLmRhdGFUcmFuc2Zlci5zZXREYXRhKFwidGV4dC9wbGFpblwiLCBTdHJpbmcocm93W2NhdGNoZXJdKSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgLy8gbm8tb3A6IHNvbWUgYnJvd3NlcnMgYXJlIHBpY2t5IGFib3V0IGRhdGFUcmFuc2ZlciwgZHJhZyBzdGlsbCB3b3Jrc1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURyYWdPdmVyUm93ID0gKGUsIHJvdykgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKGRyYWdnZWRSb3dJZCAhPSBudWxsICYmIHJvd1tjYXRjaGVyXSAhPT0gZHJhZ2dlZFJvd0lkKSB7XHJcbiAgICAgIHNldERyYWdPdmVyUm93SWQocm93W2NhdGNoZXJdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEcmFnTGVhdmVSb3cgPSAocm93KSA9PiB7XHJcbiAgICBzZXREcmFnT3ZlclJvd0lkKChjdXJyZW50KSA9PiAoY3VycmVudCA9PT0gcm93W2NhdGNoZXJdID8gbnVsbCA6IGN1cnJlbnQpKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEcm9wUm93ID0gKGUsIHRhcmdldFJvdykgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHJcbiAgICBpZiAoZHJhZ2dlZFJvd0lkID09IG51bGwgfHwgZHJhZ2dlZFJvd0lkID09PSB0YXJnZXRSb3dbY2F0Y2hlcl0pIHtcclxuICAgICAgc2V0RHJhZ2dlZFJvd0lkKG51bGwpO1xyXG4gICAgICBzZXREcmFnT3ZlclJvd0lkKG51bGwpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9jYWxEYXRhKChwcmV2KSA9PiB7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4ucHJldl07XHJcbiAgICAgIGNvbnN0IGZyb21JbmRleCA9IHVwZGF0ZWQuZmluZEluZGV4KChpdGVtKSA9PiBpdGVtW2NhdGNoZXJdID09PSBkcmFnZ2VkUm93SWQpO1xyXG4gICAgICBjb25zdCB0b0luZGV4ID0gdXBkYXRlZC5maW5kSW5kZXgoKGl0ZW0pID0+IGl0ZW1bY2F0Y2hlcl0gPT09IHRhcmdldFJvd1tjYXRjaGVyXSk7XHJcbiAgICAgIGlmIChmcm9tSW5kZXggPT09IC0xIHx8IHRvSW5kZXggPT09IC0xKSByZXR1cm4gcHJldjtcclxuICAgICAgY29uc3QgW21vdmVkSXRlbV0gPSB1cGRhdGVkLnNwbGljZShmcm9tSW5kZXgsIDEpO1xyXG4gICAgICB1cGRhdGVkLnNwbGljZSh0b0luZGV4LCAwLCBtb3ZlZEl0ZW0pO1xyXG4gICAgICByZXR1cm4gdXBkYXRlZDtcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIEEgbWFudWFsIHNvcnQga2V5IHdvdWxkIGltbWVkaWF0ZWx5IG92ZXJyaWRlIHRoZSBuZXcgb3JkZXIgb24gdGhlXHJcbiAgICAvLyBuZXh0IHJlbmRlciwgc28gY2xlYXIgaXQg4oCUIHRoaXMgaXMgdGhlIG9ubHkgZXhpc3RpbmctYmVoYXZpb3IgY2hhbmdlLFxyXG4gICAgLy8gYW5kIG9ubHkga2lja3MgaW4gb25jZSB0aGUgdXNlciBhY3R1YWxseSBkcmFncyBhIHJvdy5cclxuICAgIHNldFNvcnRDb25maWcoeyBrZXk6IG51bGwsIGRpcmVjdGlvbjogXCJhc2NcIiB9KTtcclxuXHJcbiAgICBzZXREcmFnZ2VkUm93SWQobnVsbCk7XHJcbiAgICBzZXREcmFnT3ZlclJvd0lkKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURyYWdFbmRSb3cgPSAoKSA9PiB7XHJcbiAgICBzZXREcmFnZ2VkUm93SWQobnVsbCk7XHJcbiAgICBzZXREcmFnT3ZlclJvd0lkKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gTkVXOiBkcmFnLWFuZC1kcm9wIGNvbHVtbiByZW9yZGVyaW5nIGhhbmRsZXJzIC0tLS0tLS0tLS1cclxuICBjb25zdCBoYW5kbGVDb2x1bW5EcmFnU3RhcnQgPSAoZSwgY29sdW1uKSA9PiB7XHJcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgc2V0RHJhZ2dlZENvbHVtbktleShjb2x1bW4ua2V5KTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGUuZGF0YVRyYW5zZmVyLmVmZmVjdEFsbG93ZWQgPSBcIm1vdmVcIjtcclxuICAgICAgZS5kYXRhVHJhbnNmZXIuc2V0RGF0YShcInRleHQvcGxhaW5cIiwgY29sdW1uLmtleSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgLy8gbm8tb3A6IHNvbWUgYnJvd3NlcnMgYXJlIHBpY2t5IGFib3V0IGRhdGFUcmFuc2ZlciwgZHJhZyBzdGlsbCB3b3Jrc1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbHVtbkRyYWdPdmVyID0gKGUsIGNvbHVtbikgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIGlmIChkcmFnZ2VkQ29sdW1uS2V5ICE9IG51bGwgJiYgY29sdW1uLmtleSAhPT0gZHJhZ2dlZENvbHVtbktleSkge1xyXG4gICAgICBzZXREcmFnT3ZlckNvbHVtbktleShjb2x1bW4ua2V5KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb2x1bW5EcmFnTGVhdmUgPSAoY29sdW1uKSA9PiB7XHJcbiAgICBzZXREcmFnT3ZlckNvbHVtbktleSgoY3VycmVudCkgPT4gKGN1cnJlbnQgPT09IGNvbHVtbi5rZXkgPyBudWxsIDogY3VycmVudCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbHVtbkRyb3AgPSAoZSwgdGFyZ2V0Q29sdW1uKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG5cclxuICAgIGlmIChkcmFnZ2VkQ29sdW1uS2V5ID09IG51bGwgfHwgZHJhZ2dlZENvbHVtbktleSA9PT0gdGFyZ2V0Q29sdW1uLmtleSkge1xyXG4gICAgICBzZXREcmFnZ2VkQ29sdW1uS2V5KG51bGwpO1xyXG4gICAgICBzZXREcmFnT3ZlckNvbHVtbktleShudWxsKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldENvbHVtbk9yZGVyKChwcmV2KSA9PiB7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4ucHJldl07XHJcbiAgICAgIGNvbnN0IGZyb21JbmRleCA9IHVwZGF0ZWQuaW5kZXhPZihkcmFnZ2VkQ29sdW1uS2V5KTtcclxuICAgICAgY29uc3QgdG9JbmRleCA9IHVwZGF0ZWQuaW5kZXhPZih0YXJnZXRDb2x1bW4ua2V5KTtcclxuICAgICAgaWYgKGZyb21JbmRleCA9PT0gLTEgfHwgdG9JbmRleCA9PT0gLTEpIHJldHVybiBwcmV2O1xyXG4gICAgICB1cGRhdGVkLnNwbGljZShmcm9tSW5kZXgsIDEpO1xyXG4gICAgICB1cGRhdGVkLnNwbGljZSh0b0luZGV4LCAwLCBkcmFnZ2VkQ29sdW1uS2V5KTtcclxuICAgICAgcmV0dXJuIHVwZGF0ZWQ7XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXREcmFnZ2VkQ29sdW1uS2V5KG51bGwpO1xyXG4gICAgc2V0RHJhZ092ZXJDb2x1bW5LZXkobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29sdW1uRHJhZ0VuZCA9ICgpID0+IHtcclxuICAgIHNldERyYWdnZWRDb2x1bW5LZXkobnVsbCk7XHJcbiAgICBzZXREcmFnT3ZlckNvbHVtbktleShudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBzZWFyY2hEYXRhID0gKGRhdGEpID0+IHtcclxuICAgIGlmICghc2VhcmNoUXVlcnkpIHJldHVybiBkYXRhO1xyXG4gICAgcmV0dXJuIGRhdGEuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICBPYmplY3QudmFsdWVzKGl0ZW0pLnNvbWUoKHZhbHVlKSA9PlxyXG4gICAgICAgIFN0cmluZyh2YWx1ZSkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICApXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZpbHRlckRhdGEgPSAoZGF0YSkgPT4ge1xyXG4gICAgcmV0dXJuIGRhdGEuZmlsdGVyKChpdGVtKSA9PiB7XHJcbiAgICAgIHJldHVybiBPYmplY3QuZW50cmllcyhmaWx0ZXJzKS5ldmVyeSgoW2tleSwgdmFsdWVdKSA9PiB7XHJcbiAgICAgICAgaWYgKCF2YWx1ZSkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgcmV0dXJuIFN0cmluZyhpdGVtW2tleV0pLnRvTG93ZXJDYXNlKCkgPT09IHZhbHVlLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc29ydERhdGEgPSAoZGF0YSkgPT4ge1xyXG4gICAgaWYgKCFzb3J0Q29uZmlnLmtleSkgcmV0dXJuIGRhdGE7XHJcbiAgICByZXR1cm4gWy4uLmRhdGFdLnNvcnQoKGEsIGIpID0+IHtcclxuICAgICAgY29uc3QgYVZhbCA9IGFbc29ydENvbmZpZy5rZXldO1xyXG4gICAgICBjb25zdCBiVmFsID0gYltzb3J0Q29uZmlnLmtleV07XHJcbiAgICAgIGlmIChhVmFsIDwgYlZhbCkgcmV0dXJuIHNvcnRDb25maWcuZGlyZWN0aW9uID09PSBcImFzY1wiID8gLTEgOiAxO1xyXG4gICAgICBpZiAoYVZhbCA+IGJWYWwpIHJldHVybiBzb3J0Q29uZmlnLmRpcmVjdGlvbiA9PT0gXCJhc2NcIiA/IDEgOiAtMTtcclxuICAgICAgcmV0dXJuIDA7XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBwcm9jZXNzZWREYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBsZXQgcHJvY2Vzc2VkID0gWy4uLmxvY2FsRGF0YV07XHJcbiAgICBwcm9jZXNzZWQgPSBzZWFyY2hEYXRhKHByb2Nlc3NlZCk7XHJcbiAgICBwcm9jZXNzZWQgPSBmaWx0ZXJEYXRhKHByb2Nlc3NlZCk7XHJcbiAgICBwcm9jZXNzZWQgPSBzb3J0RGF0YShwcm9jZXNzZWQpO1xyXG4gICAgcmV0dXJuIHByb2Nlc3NlZDtcclxuICB9LCBbbG9jYWxEYXRhLCBzZWFyY2hRdWVyeSwgZmlsdGVycywgc29ydENvbmZpZ10pO1xyXG5cclxuICBjb25zdCB0b3RhbFBhZ2VzID0gTWF0aC5jZWlsKHByb2Nlc3NlZERhdGEubGVuZ3RoIC8gcGFnZVNpemUpO1xyXG4gIGNvbnN0IHBhZ2luYXRlZERhdGEgPSBwcm9jZXNzZWREYXRhLnNsaWNlKFxyXG4gICAgKGN1cnJlbnRQYWdlIC0gMSkgKiBwYWdlU2l6ZSxcclxuICAgIGN1cnJlbnRQYWdlICogcGFnZVNpemVcclxuICApO1xyXG5cclxuICBjb25zdCBnZXRDZWxsVGV4dCA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgaWYgKFJlYWN0LmlzVmFsaWRFbGVtZW50KHZhbHVlKSkge1xyXG4gICAgICBjb25zdCBodG1sID0gUmVhY3RET01TZXJ2ZXIucmVuZGVyVG9TdGF0aWNNYXJrdXAodmFsdWUpO1xyXG4gICAgICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICBkaXYuaW5uZXJIVE1MID0gaHRtbDtcclxuICAgICAgcmV0dXJuIGRpdi50ZXh0Q29udGVudCB8fCBkaXYuaW5uZXJUZXh0IHx8IFwiXCI7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdmFsdWUgPz8gXCJcIjtcclxuICB9O1xyXG5cclxuICBjb25zdCBleHBvcnRUb0V4Y2VsID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGZpbGVOYW1lRXhjZWwgPSBgJHtTdHJpbmcobm93LmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpfS0ke1N0cmluZyhub3cuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKVxyXG4gICAgICB9LSR7bm93LmdldEZ1bGxZZWFyKCl9XyR7U3RyaW5nKG5vdy5nZXRIb3VycygpKS5wYWRTdGFydCgyLCBcIjBcIilcclxuICAgICAgfS0ke1N0cmluZyhub3cuZ2V0TWludXRlcygpKS5wYWRTdGFydCgyLCBcIjBcIilcclxuICAgICAgfS0ke1N0cmluZyhub3cuZ2V0U2Vjb25kcygpKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuXHJcbiAgICBjb25zdCBzZWxlY3RlZENvbHMgPSBleHBvcnRDb2x1bW5zLmZpbHRlcihcclxuICAgICAgKGNvbCkgPT5cclxuICAgICAgICBzZWxlY3RlZEV4cG9ydENvbHVtbnMuaW5jbHVkZXMoY29sLmtleSkgJiZcclxuICAgICAgICBjb2wuaGVhZGVyLnRvTG93ZXJDYXNlKCkgIT09IFwiYWN0aW9uXCJcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgaGVhZGVycyA9IHNlbGVjdGVkQ29scy5tYXAoKGNvbCkgPT4gY29sLmhlYWRlcikuam9pbihcIixcIik7XHJcblxyXG4gICAgY29uc3Qgcm93cyA9IHByb2Nlc3NlZERhdGFcclxuICAgICAgLm1hcCgoaXRlbSkgPT5cclxuICAgICAgICBzZWxlY3RlZENvbHNcclxuICAgICAgICAgIC5tYXAoKGNvbCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB2YWwgPSBnZXRDZWxsVGV4dChpdGVtW2NvbC5rZXldKTtcclxuICAgICAgICAgICAgY29uc3QgY2xlYW4gPSBTdHJpbmcodmFsID8/IFwiLVwiKS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpO1xyXG4gICAgICAgICAgICByZXR1cm4gYFwiJHtjbGVhbn1cImA7XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgLmpvaW4oXCIsXCIpXHJcbiAgICAgIClcclxuICAgICAgLmpvaW4oXCJcXG5cIik7XHJcblxyXG4gICAgY29uc3QgY3N2ID0gYCR7aGVhZGVyc31cXG4ke3Jvd3N9YDtcclxuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbXCJcXHVGRUZGXCIgKyBjc3ZdLCB7IHR5cGU6IFwidGV4dC9jc3Y7Y2hhcnNldD11dGYtODtcIiB9KTtcclxuICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xyXG4gICAgYS5ocmVmID0gdXJsO1xyXG4gICAgY29uc3QgZmlsZUJhc2VOYW1lID0gZXhwb3J0ZWRGaWxlTmFtZS5yZXBsYWNlKC9cXC5jc3YkL2ksIFwiXCIpLnRyaW0oKTtcclxuICAgIGEuZG93bmxvYWQgPSBgJHtmaWxlQmFzZU5hbWV9XyR7ZmlsZU5hbWVFeGNlbH0uY3N2YDtcclxuICAgIGEuY2xpY2soKTtcclxuICAgIHdpbmRvdy5VUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XHJcblxyXG4gICAgc2V0U2hvd0V4cG9ydE1vZGFsKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb2x1bW5TZWxlY3Rpb24gPSAoY29sdW1uS2V5LCBpc0NoZWNrZWQpID0+IHtcclxuICAgIGlmIChpc0NoZWNrZWQpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRFeHBvcnRDb2x1bW5zKFsuLi5zZWxlY3RlZEV4cG9ydENvbHVtbnMsIGNvbHVtbktleV0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0U2VsZWN0ZWRFeHBvcnRDb2x1bW5zKFxyXG4gICAgICAgIHNlbGVjdGVkRXhwb3J0Q29sdW1ucy5maWx0ZXIoKGtleSkgPT4ga2V5ICE9PSBjb2x1bW5LZXkpXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKGlzQ2hlY2tlZCkgPT4ge1xyXG4gICAgaWYgKGlzQ2hlY2tlZCkge1xyXG4gICAgICBzZXRTZWxlY3RlZEV4cG9ydENvbHVtbnMoZXhwb3J0Q29sdW1ucy5tYXAoKGNvbCkgPT4gY29sLmtleSkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0U2VsZWN0ZWRFeHBvcnRDb2x1bW5zKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjaGFuZ2VDb2xvciA9IChpbmRleCkgPT4ge1xyXG4gICAgcmV0dXJuIGluZGV4ICUgMiA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBwcmludFRvUERGID0gKCkgPT4ge1xyXG4gICAgbGV0IHNob3dTdW1tYXJ5Q2FyZHMgPSB0cnVlO1xyXG4gICAgbGV0IHNob3dDb3VudENhcmRzID0gdHJ1ZTtcclxuXHJcbiAgICBjb25zdCBkYXRlID0gYCR7U3RyaW5nKG5ldyBEYXRlKCkuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCBcIjBcIil9LSR7U3RyaW5nKG5ldyBEYXRlKCkuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKVxyXG4gICAgICB9LSR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfV8ke1N0cmluZyhuZXcgRGF0ZSgpLmdldEhvdXJzKCkpLnBhZFN0YXJ0KDIsIFwiMFwiKVxyXG4gICAgICB9LSR7U3RyaW5nKG5ldyBEYXRlKCkuZ2V0TWludXRlcygpKS5wYWRTdGFydCgyLCBcIjBcIilcclxuICAgICAgfS0ke1N0cmluZyhuZXcgRGF0ZSgpLmdldFNlY29uZHMoKSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgICBjb25zdCByZXBvcnRUeXBlID0gU3RyaW5nKGV4cG9ydGVkUGRmTmFtZSB8fCBcIlwiKS50cmltKCk7XHJcbiAgICBjb25zdCBmaWxlTmFtZSA9IGAke3JlcG9ydFR5cGV9XyR7ZGF0ZX1gO1xyXG5cclxuICAgIHN3aXRjaCAocmVwb3J0VHlwZSkge1xyXG4gICAgICBjYXNlIFwiR3JvdXBzXCI6IGNhc2UgXCJDdXN0b21lcnNcIjogY2FzZSBcIlVuQXBwcm92ZWQgQ3VzdG9tZXJcIjogY2FzZSBcIkVucm9sbG1lbnRzXCI6XHJcbiAgICAgIGNhc2UgXCJTdGFmZlwiOiBjYXNlIFwiQWdlbnRzXCI6IGNhc2UgXCJFbXBsb3llZXNcIjogY2FzZSBcIkxlYWRzXCI6IGNhc2UgXCJMb2Fuc1wiOlxyXG4gICAgICBjYXNlIFwiUGlnbWVcIjogY2FzZSBcIkF1Y3Rpb25cIjogY2FzZSBcIkNoaXQgUGF5bWVudHNcIjogY2FzZSBcIk1vYmlsZSBBcHAgRW5yb2xsbWVudHNcIjpcclxuICAgICAgY2FzZSBcIkd1YXJhbnRvclwiOiBjYXNlIFwiVGFza3NcIjogY2FzZSBcIkFsbCBDdXN0b21lciBSZXBvcnRcIjogY2FzZSBcIkdyb3VwIFJlcG9ydFwiOlxyXG4gICAgICBjYXNlIFwiQmFzaWMgR3JvdXAgUmVwb3J0XCI6IGNhc2UgXCJFbnJvbGxtZW50IFJlcG9ydFwiOiBjYXNlIFwiQ3VzdG9tZXIgUmVwb3J0XCI6XHJcbiAgICAgIGNhc2UgXCJDdXN0b21lciBMZWRnZXIgUmVwb3J0XCI6IGNhc2UgXCJDdXN0b21lciBQYXlvdXQgUmVwb3J0XCI6IGNhc2UgXCJFbXBsb3llZSBSZXBvcnRcIjpcclxuICAgICAgY2FzZSBcIkNvbW1pc3Npb24gUmVwb3J0XCI6IGNhc2UgXCJBdWN0aW9uIFJlcG9ydFwiOiBjYXNlIFwiTGVhZCBSZXBvcnRcIjogY2FzZSBcIlBpZ21lIFJlcG9ydFwiOlxyXG4gICAgICBjYXNlIFwiTG9hbiBSZXBvcnRcIjogY2FzZSBcIlNhbGVzIFJlcG9ydFwiOiBjYXNlIFwiRGF0ZS13aXNlIEdyb3VwIFJlcG9ydFwiOlxyXG4gICAgICBjYXNlIFwiUGF5bWVudCBTdW1tYXJ5IFJlcG9ydFwiOiBjYXNlIFwiQ29sbGVjdGlvbiBBcmVhXCI6IGNhc2UgXCJEcmVhbSBBc3NldFwiOiBjYXNlIFwiQWdlbnQgQXBwcm92YWxcIjpcclxuICAgICAgICBzaG93U3VtbWFyeUNhcmRzID0gZmFsc2U7XHJcbiAgICAgICAgc2hvd0NvdW50Q2FyZHMgPSBmYWxzZTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcIkRheWJvb2sgUmVwb3J0XCI6IGNhc2UgXCJSZWNlaXB0IFJlcG9ydFwiOlxyXG4gICAgICAgIHNob3dTdW1tYXJ5Q2FyZHMgPSB0cnVlO1xyXG4gICAgICAgIHNob3dDb3VudENhcmRzID0gdHJ1ZTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICBzaG93U3VtbWFyeUNhcmRzID0gZmFsc2U7XHJcbiAgICAgICAgc2hvd0NvdW50Q2FyZHMgPSBmYWxzZTtcclxuICAgICAgICBicmVhaztcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzZWxlY3RlZENvbHMgPSBleHBvcnRDb2x1bW5zLmZpbHRlcihcclxuICAgICAgKGNvbCkgPT5cclxuICAgICAgICBzZWxlY3RlZEV4cG9ydENvbHVtbnMuaW5jbHVkZXMoY29sLmtleSkgJiZcclxuICAgICAgICBjb2wua2V5LnRvTG93ZXJDYXNlKCkgIT09IFwiYWN0aW9uXCJcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgcHJpbnRDb250ZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBkYXRlVGltZVN0cmluZyA9IG5vdy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgZGF0ZVN0eWxlOiBcIm1lZGl1bVwiLFxyXG4gICAgICB0aW1lU3R5bGU6IFwic2hvcnRcIixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsQW1vdW50ID0gcHJvY2Vzc2VkRGF0YS5yZWR1Y2UoKHN1bSwgcm93KSA9PiB7XHJcbiAgICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQocm93LmFtb3VudCB8fCByb3cuQW1vdW50IHx8IDApO1xyXG4gICAgICByZXR1cm4gc3VtICsgKGlzTmFOKGFtb3VudCkgPyAwIDogYW1vdW50KTtcclxuICAgIH0sIDApO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsQ2FzaCA9IHByb2Nlc3NlZERhdGFcclxuICAgICAgLmZpbHRlcigocm93KSA9PiByb3cubW9kZT8udG9Mb3dlckNhc2UoKSA9PT0gXCJjYXNoXCIpXHJcbiAgICAgIC5yZWR1Y2UoKHN1bSwgcm93KSA9PiBzdW0gKyBOdW1iZXIocm93LmFtb3VudCB8fCAwKSwgMCk7XHJcblxyXG4gICAgY29uc3QgdG90YWxPbmxpbmUgPSBwcm9jZXNzZWREYXRhXHJcbiAgICAgIC5maWx0ZXIoKHJvdykgPT4gcm93Lm1vZGU/LnRvTG93ZXJDYXNlKCkgPT09IFwib25saW5lXCIpXHJcbiAgICAgIC5yZWR1Y2UoKHN1bSwgcm93KSA9PiBzdW0gKyBOdW1iZXIocm93LmFtb3VudCB8fCAwKSwgMCk7XHJcblxyXG4gICAgY29uc3QgdG90YWxDdXN0b21lcnMgPSBuZXcgU2V0KFxyXG4gICAgICBwcm9jZXNzZWREYXRhLm1hcCgocm93KSA9PiByb3cubmFtZSB8fCByb3cudXNlcl9pZD8uZnVsbF9uYW1lKVxyXG4gICAgKS5zaXplO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsT25saW5lQ291bnQgPSBwcm9jZXNzZWREYXRhLmZpbHRlcihcclxuICAgICAgKHJvdykgPT4gcm93Lm1vZGU/LnRvTG93ZXJDYXNlKCkgPT09IFwib25saW5lXCJcclxuICAgICkubGVuZ3RoO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsQ2FzaENvdW50ID0gcHJvY2Vzc2VkRGF0YS5maWx0ZXIoXHJcbiAgICAgIChyb3cpID0+IHJvdy5tb2RlPy50b0xvd2VyQ2FzZSgpID09PSBcImNhc2hcIlxyXG4gICAgKS5sZW5ndGg7XHJcblxyXG4gICAgY29uc3QgaXNTcGVjaWFsUmVwb3J0ID0gcmVwb3J0VHlwZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwiZGF5Ym9va1wiKSB8fCByZXBvcnRUeXBlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJyZWNlaXB0IHJlcG9ydFwiKTtcclxuICAgIGxldCB0b3RhbEluT3V0Um93SHRtbCA9IFwiXCI7XHJcbiAgICBsZXQgcmVtYWluaW5nQ2FyZHNIdG1sID0gXCJcIjtcclxuXHJcbiAgICBpZiAoaXNTcGVjaWFsUmVwb3J0ICYmIHByaW50SGVhZGVyS2V5cy5sZW5ndGggPj0gMikge1xyXG4gICAgICB0b3RhbEluT3V0Um93SHRtbCA9IGBcclxuICAgICAgICA8ZGl2IHN0eWxlPVwiZGlzcGxheTogZmxleDsgZ2FwOiAyMHB4OyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47IG1hcmdpbi1ib3R0b206IDI0cHg7XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZFwiIHN0eWxlPVwiZmxleDogMTsgbWFyZ2luOiAwO1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC10aXRsZVwiPiR7cHJpbnRIZWFkZXJLZXlzWzBdfTwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC12YWx1ZVwiPiR7cHJpbnRIZWFkZXJWYWx1ZXNbMF19PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkXCIgc3R5bGU9XCJmbGV4OiAxOyBtYXJnaW46IDA7XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLXRpdGxlXCI+JHtwcmludEhlYWRlcktleXNbMV19PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLXZhbHVlXCI+JHtwcmludEhlYWRlclZhbHVlc1sxXX08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICBgO1xyXG5cclxuICAgICAgaWYgKHByaW50SGVhZGVyS2V5cy5sZW5ndGggPiAyKSB7XHJcbiAgICAgICAgY29uc3QgcmVtYWluaW5nS2V5cyA9IHByaW50SGVhZGVyS2V5cy5zbGljZSgyKTtcclxuICAgICAgICBjb25zdCByZW1haW5pbmdWYWx1ZXMgPSBwcmludEhlYWRlclZhbHVlcy5zbGljZSgyKTtcclxuICAgICAgICByZW1haW5pbmdDYXJkc0h0bWwgPSBgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1ncmlkXCI+XHJcbiAgICAgICAgICAgICR7cmVtYWluaW5nS2V5c1xyXG4gICAgICAgICAgICAubWFwKFxyXG4gICAgICAgICAgICAgIChrZXksIGlkeCkgPT4gYFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkLXRpdGxlXCI+JHtrZXl9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtdmFsdWVcIj4ke3JlbWFpbmluZ1ZhbHVlc1tpZHhdfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIGBcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAuam9pbihcIlwiKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIGA7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlbWFpbmluZ0NhcmRzSHRtbCA9IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1ncmlkXCI+XHJcbiAgICAgICAgICAke3ByaW50SGVhZGVyS2V5cy5tYXAoXHJcbiAgICAgICAgKGtleSwgaSkgPT4gYFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC10aXRsZVwiPiR7a2V5fTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtdmFsdWVcIj4ke3ByaW50SGVhZGVyVmFsdWVzW2ldfTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBgXHJcbiAgICAgICkuam9pbihcIlwiKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgYDtcclxuICAgIH1cclxuXHJcbiAgICBwcmludENvbnRlbnQuaW5uZXJIVE1MID0gYFxyXG4gICAgICA8c3R5bGU+XHJcbiAgICAgICAgQG1lZGlhIHByaW50IHtcclxuICAgICAgICAgIGJvZHkgKiB7IHZpc2liaWxpdHk6IGhpZGRlbjsgfVxyXG4gICAgICAgICAgLnByaW50YWJsZSwgLnByaW50YWJsZSAqIHsgdmlzaWJpbGl0eTogdmlzaWJsZTsgfVxyXG4gICAgICAgICAgYm9keSB7IGZvbnQtZmFtaWx5OiAnU2Vnb2UgVUknLCBUYWhvbWEsIEdlbmV2YSwgVmVyZGFuYSwgc2Fucy1zZXJpZjsgZm9udC1zaXplOiAxM3B4OyBjb2xvcjogIzMzMzsgbWFyZ2luOiAwOyB9XHJcbiAgICAgICAgICAucHJpbnRhYmxlIHsgcG9zaXRpb246IGFic29sdXRlOyB0b3A6IDA7IGxlZnQ6IDA7IHdpZHRoOiAxMDAlOyBwYWRkaW5nOiAzMHB4IDQwcHg7IGJhY2tncm91bmQ6ICNmZmY7IGJveC1zaXppbmc6IGJvcmRlci1ib3g7IH1cclxuICAgICAgICAgIC5hNC1ib3JkZXIgeyBib3JkZXI6IDFweCBzb2xpZCAjZDJkNmRjOyBib3JkZXItcmFkaXVzOiAxMHB4OyBwYWRkaW5nOiAyMHB4OyBoZWlnaHQ6IDEwMCU7IGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7IGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2JhKDAsMCwwLDAuMDUpOyB9XHJcbiAgICAgICAgICAuaGVhZGVyLXdyYXBwZXIgeyBkaXNwbGF5OiBmbGV4OyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47IGFsaWduLWl0ZW1zOiBjZW50ZXI7IG1hcmdpbi1ib3R0b206IDE2cHg7IHBhZGRpbmctYm90dG9tOiAxMHB4OyBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U1ZTdlYjsgfVxyXG4gICAgICAgICAgLmxvZ28taW1hZ2UgeyB3aWR0aDogMjYwcHg7IGhlaWdodDogMTMwcHg7IG9iamVjdC1maXQ6IGNvbnRhaW47IGJvcmRlci1yYWRpdXM6IDZweDsgfVxyXG4gICAgICAgICAgLnRpdGxlLWJsb2NrIHsgbWF4LXdpZHRoOiA2MDBweDsgZm9udC1mYW1pbHk6IEFyaWFsLCBzYW5zLXNlcmlmOyBsaW5lLWhlaWdodDogMS41OyB9XHJcbiAgICAgICAgICAudGl0bGUgeyBmb250LXNpemU6IDIwcHg7IGZvbnQtd2VpZ2h0OiA3MDA7IGNvbG9yOiAjMjIyOyBtYXJnaW4tYm90dG9tOiA2cHg7IH1cclxuICAgICAgICAgIC5zdWItdGl0bGUgeyBmb250LXNpemU6IDE0cHg7IGNvbG9yOiAjNTU1OyBtYXJnaW4tYm90dG9tOiA4cHg7IH1cclxuICAgICAgICAgIC5hZGRyZXNzIHsgZm9udC1zaXplOiAxNHB4OyBjb2xvcjogIzY2NjsgfVxyXG4gICAgICAgICAgLnJlcG9ydC1oZWFkaW5nIHsgdGV4dC1hbGlnbjogY2VudGVyOyBmb250LXNpemU6IDIycHg7IGZvbnQtd2VpZ2h0OiA2MDA7IGNvbG9yOiAjMTExODI3OyBtYXJnaW46IDIwcHggMCA2cHg7IHBhZGRpbmc6IDEwcHggMDsgYmFja2dyb3VuZC1jb2xvcjogI2Y5ZmFmYjsgYm9yZGVyOiAxcHggc29saWQgI2U1ZTdlYjsgYm9yZGVyLXJhZGl1czogOHB4OyBsZXR0ZXItc3BhY2luZzogMC44cHg7IH1cclxuICAgICAgICAgIC5yZXBvcnQtZGF0ZSB7IHRleHQtYWxpZ246IGNlbnRlcjsgZm9udC1zaXplOiAxMnB4OyBjb2xvcjogIzZiNzI4MDsgbWFyZ2luLWJvdHRvbTogMjBweDsgfVxyXG4gICAgICAgICAgLmluZm8tZ3JpZCB7IGRpc3BsYXk6IGdyaWQ7IGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KGF1dG8tZml0LCBtaW5tYXgoMjAwcHgsIDFmcikpOyBnYXA6IDEwcHg7IG1hcmdpbi1ib3R0b206IDIwcHg7IH1cclxuICAgICAgICAgIC5pbmZvLWdyaWQgaDMgeyBmb250LXNpemU6IDEzcHg7IG1hcmdpbjogNHB4IDA7IGNvbG9yOiAjMzc0MTUxOyBmb250LXdlaWdodDogNTAwOyB9XHJcbiAgICAgICAgICAuc3VtbWFyeS1jYXJkcyB7IGRpc3BsYXk6IGZsZXg7IGdhcDogMTRweDsgbWFyZ2luOiAxMHB4IDAgMjRweDsgfVxyXG4gICAgICAgICAgLmNhcmQgeyBmbGV4OiAxOyBib3JkZXItcmFkaXVzOiA4cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgcGFkZGluZzogMTRweCAxMnB4OyBiYWNrZ3JvdW5kLWNvbG9yOiAjZjhmYWZjOyBib3JkZXI6IDFweCBzb2xpZCAjZTJlOGYwOyBib3gtc2hhZG93OiAwIDFweCAzcHggcmdiYSgwLDAsMCwwLjA1KTsgfVxyXG4gICAgICAgICAgLmNhcmQtdGl0bGUgeyBmb250LXNpemU6IDE0cHg7IGNvbG9yOiAjNGI1NTYzOyBtYXJnaW46IDA7IGZvbnQtd2VpZ2h0OiA2MDA7IH1cclxuICAgICAgICAgIC5jYXJkLXZhbHVlIHsgZm9udC1zaXplOiAxOHB4OyBmb250LXdlaWdodDogYm9sZDsgY29sb3I6ICMwZjE3MmE7IG1hcmdpbi10b3A6IDRweDsgfVxyXG4gICAgICAgICAgLmNvdW50LXN1bW1hcnktY2FyZHMgeyBkaXNwbGF5OiBmbGV4OyBnYXA6IDE0cHg7IG1hcmdpbjogMTZweCAwIDIwcHg7IH1cclxuICAgICAgICAgIC5jb3VudC1jYXJkIHsgZmxleDogMTsgcGFkZGluZzogMTRweCAxMnB4OyBib3JkZXItcmFkaXVzOiA4cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgZm9udC13ZWlnaHQ6IDYwMDsgYmFja2dyb3VuZDogI2Y4ZmFmYzsgYm9yZGVyOiAxcHggc29saWQgI2UyZThmMDsgfVxyXG4gICAgICAgICAgLmNvdW50LWNhcmQuY3VzdG9tZXIgeyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmVmM2M3OyBjb2xvcjogIzkyNDAwZTsgfVxyXG4gICAgICAgICAgLmNvdW50LWNhcmQuY2FzaCB7IGJhY2tncm91bmQtY29sb3I6ICNiYmY3ZDA7IGNvbG9yOiAjMDQ3ODU3OyB9XHJcbiAgICAgICAgICAuY291bnQtY2FyZC5vbmxpbmUgeyBiYWNrZ3JvdW5kLWNvbG9yOiAjZGJlYWZlOyBjb2xvcjogIzFlNDBhZjsgfVxyXG4gICAgICAgICAgLmNvdW50LWNhcmQgc3BhbiB7IGZvbnQtc2l6ZTogMThweDsgZm9udC13ZWlnaHQ6IGJvbGQ7IGRpc3BsYXk6IGJsb2NrOyBtYXJnaW4tdG9wOiA0cHg7IH1cclxuICAgICAgICAgIHRhYmxlIHsgd2lkdGg6IDEwMCU7IGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7IG1hcmdpbi10b3A6IDE2cHg7IGZvbnQtc2l6ZTogMTIuNXB4OyBib3gtc2hhZG93OiAwIDFweCAzcHggcmdiYSgwLDAsMCwwLjEpOyBib3JkZXItcmFkaXVzOiA2cHg7IG92ZXJmbG93OiBoaWRkZW47IH1cclxuICAgICAgICAgIHRoIHsgYmFja2dyb3VuZC1jb2xvcjogI2VmZjZmZjsgY29sb3I6ICMxZTQwYWY7IGZvbnQtd2VpZ2h0OiA2MDA7IHBhZGRpbmc6IDEwcHggOHB4OyBib3JkZXItYm90dG9tOiAycHggc29saWQgI2JmZGJmZTsgfVxyXG4gICAgICAgICAgdGQgeyBwYWRkaW5nOiA4cHg7IGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZTJlOGYwOyBjb2xvcjogIzMzNDE1NTsgfVxyXG4gICAgICAgICAgdHI6bnRoLWNoaWxkKGV2ZW4pIHsgYmFja2dyb3VuZC1jb2xvcjogI2Y5ZmFmYjsgfVxyXG4gICAgICAgICAgdHI6aG92ZXIgeyBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmNWY5OyB9XHJcbiAgICAgICAgICAuc2lnbmF0dXJlcyB7IG1hcmdpbi10b3A6IDM2cHg7IGRpc3BsYXk6IGZsZXg7IGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjsgZm9udC1zaXplOiAxM3B4OyBjb2xvcjogIzFmMjkzNzsgfVxyXG4gICAgICAgICAgLmZvb3RlciB7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM2YjcyODA7IHRleHQtYWxpZ246IGNlbnRlcjsgbWFyZ2luLXRvcDogMzBweDsgZm9udC1zdHlsZTogaXRhbGljOyB9XHJcbiAgICAgICAgfVxyXG4gICAgICA8L3N0eWxlPlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cInByaW50YWJsZVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJhNC1ib3JkZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJoZWFkZXItd3JhcHBlclwiPlxyXG4gICAgICAgICAgICAke2ltYWdlSW5wdXQgPyBgPGltZyBzcmM9XCIke2ltYWdlSW5wdXR9XCIgY2xhc3M9XCJsb2dvLWltYWdlXCIgYWx0PVwiTG9nb1wiIC8+YCA6IFwiXCJ9XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0aXRsZS1ibG9ja1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0aXRsZVwiPlZJSkFZQSBWSU5BWUFLIENISVRGVU5EUyBQUklWQVRFIExJTUlURUQ8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3ViLXRpdGxlXCI+Q0lOOiBVNjU5OTlLQTIwMjJQVEMxNjE4NTg8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWRkcmVzc1wiPlxyXG4gICAgICAgICAgICAgICAgTm8gMTEvMzYtMjUsIDJuZCBNYWluLCBLYXRocmlndXBwZSBNYWluIFJvYWQsPGJyPlxyXG4gICAgICAgICAgICAgICAgQmFuZ2Fsb3JlLCBLYXJuYXRha2EsIEluZGlhIC0gNTYwMDcwXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInJlcG9ydC1oZWFkaW5nXCI+JHtyZXBvcnRUeXBlIHx8IFwiVHJhbnNhY3Rpb24gU3VtbWFyeSBSZXBvcnRcIn08L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZXBvcnQtZGF0ZVwiPiR7ZGF0ZVRpbWVTdHJpbmd9PC9kaXY+XHJcblxyXG4gICAgICAgICAgJHtpc1NwZWNpYWxSZXBvcnQgPyB0b3RhbEluT3V0Um93SHRtbCA6IFwiXCJ9XHJcbiAgICAgICAgICAke3JlbWFpbmluZ0NhcmRzSHRtbH1cclxuXHJcbiAgICAgICAgICA8dGFibGUgc3R5bGU9XCJ3aWR0aDogMTAwJTsgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcIj5cclxuICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICR7c2VsZWN0ZWRDb2xzXHJcbiAgICAgICAgLm1hcChcclxuICAgICAgICAgIChjb2wpID0+XHJcbiAgICAgICAgICAgIGA8dGggc3R5bGU9XCJib3JkZXI6IDFweCBzb2xpZCAjZTJlOGYwOyBwYWRkaW5nOiA2cHg7IHRleHQtYWxpZ246IGxlZnQ7XCI+JHtjb2wuaGVhZGVyfTwvdGg+YFxyXG4gICAgICAgIClcclxuICAgICAgICAuam9pbihcIlwiKX1cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgJHtwcm9jZXNzZWREYXRhXHJcbiAgICAgICAgLm1hcChcclxuICAgICAgICAgIChyb3cpID0+IGBcclxuICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICR7c2VsZWN0ZWRDb2xzXHJcbiAgICAgICAgICAgICAgLm1hcCgoY29sKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBnZXRDZWxsVGV4dChyb3dbY29sLmtleV0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGA8dGQgc3R5bGU9XCJib3JkZXI6IDFweCBzb2xpZCAjZTJlOGYwOyBwYWRkaW5nOiA2cHg7XCI+JHt2YWwgfHwgXCItXCJ9PC90ZD5gO1xyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgLmpvaW4oXCJcIil9XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+YFxyXG4gICAgICAgIClcclxuICAgICAgICAuam9pbihcIlwiKX1cclxuICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgIDwvdGFibGU+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25hdHVyZXNcIj5cclxuICAgICAgICAgICAgPGRpdj48c3Ryb25nPklzc3VlZCBCeTogPC9zdHJvbmc+JHtjdXJyZW50VXNlck5hbWV9PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9vdGVyXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYXV0by1ub3RlXCI+KioqIFRoaXMgaXMgYSBjb21wdXRlciBnZW5lcmF0ZWQgZG9jdW1lbnQsIG5vIHNpZ25hdHVyZSBpcyByZXF1aXJlZCAqKio8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICBgO1xyXG5cclxuICAgIGlmIChpbWFnZUlucHV0KSB7XHJcbiAgICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xyXG4gICAgICBpbWcuc3JjID0gaW1hZ2VJbnB1dDtcclxuICAgICAgaW1nLm9ubG9hZCA9ICgpID0+IHtcclxuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHByaW50Q29udGVudCk7XHJcbiAgICAgICAgZG9jdW1lbnQudGl0bGUgPSBmaWxlTmFtZSB8fCBcIk15Q2hpdHNcIjtcclxuICAgICAgICB3aW5kb3cucHJpbnQoKTtcclxuICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHByaW50Q29udGVudCk7XHJcbiAgICAgICAgZG9jdW1lbnQudGl0bGUgPSBcIk15Q2hpdHNcIjtcclxuICAgICAgICBzZXRTaG93RXhwb3J0TW9kYWwoZmFsc2UpOyAvLyBDbG9zZSBtb2RhbCBhZnRlciBwcmludFxyXG4gICAgICB9O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChwcmludENvbnRlbnQpO1xyXG4gICAgICBkb2N1bWVudC50aXRsZSA9IGZpbGVOYW1lIHx8IFwiTXlDaGl0c1wiO1xyXG4gICAgICB3aW5kb3cucHJpbnQoKTtcclxuICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChwcmludENvbnRlbnQpO1xyXG4gICAgICBkb2N1bWVudC50aXRsZSA9IFwiTXlDaGl0c1wiO1xyXG4gICAgICBzZXRTaG93RXhwb3J0TW9kYWwoZmFsc2UpOyAvLyBDbG9zZSBtb2RhbCBhZnRlciBwcmludFxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNvcnQgPSAoa2V5KSA9PiB7XHJcbiAgICBzZXRTb3J0Q29uZmlnKChjdXJyZW50KSA9PiAoe1xyXG4gICAgICBrZXksXHJcbiAgICAgIGRpcmVjdGlvbjogY3VycmVudC5rZXkgPT09IGtleSAmJiBjdXJyZW50LmRpcmVjdGlvbiA9PT0gXCJhc2NcIiA/IFwiZGVzY1wiIDogXCJhc2NcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEJ1aWxkIG9yZGVyZWQgY29sdW1ucyB3aXRoIHBpbm5lZCBsb2dpYyAtLS0tLS0tLS0tXHJcbiAgLy8gTkVXOiBhcHBseSB0aGUgdXNlcidzIGRyYWctYW5kLWRyb3AgY29sdW1uIG9yZGVyIGZpcnN0LiBBbnkgY29sdW1uIG5vdFxyXG4gIC8vIHlldCBwcmVzZW50IGluIGNvbHVtbk9yZGVyIChlLmcuIGFkZGVkIGxhdGVyIGJ5IHRoZSBwYXJlbnQpIGlzIGFwcGVuZGVkXHJcbiAgLy8gYXQgdGhlIGVuZCBzbyBub3RoaW5nIHNpbGVudGx5IGRpc2FwcGVhcnMuXHJcbiAgY29uc3Qgb3JkZXJlZFNhZmVDb2x1bW5zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBieUtleSA9IG5ldyBNYXAoc2FmZUNvbHVtbnMubWFwKChjb2wpID0+IFtjb2wua2V5LCBjb2xdKSk7XHJcbiAgICBjb25zdCBrbm93biA9IGNvbHVtbk9yZGVyXHJcbiAgICAgIC5maWx0ZXIoKGtleSkgPT4gYnlLZXkuaGFzKGtleSkpXHJcbiAgICAgIC5tYXAoKGtleSkgPT4gYnlLZXkuZ2V0KGtleSkpO1xyXG4gICAgY29uc3QgdW5rbm93bkNvbHMgPSBzYWZlQ29sdW1ucy5maWx0ZXIoXHJcbiAgICAgIChjb2wpID0+ICFjb2x1bW5PcmRlci5pbmNsdWRlcyhjb2wua2V5KVxyXG4gICAgKTtcclxuICAgIHJldHVybiBbLi4ua25vd24sIC4uLnVua25vd25Db2xzXTtcclxuICB9LCBbc2FmZUNvbHVtbnMsIGNvbHVtbk9yZGVyXSk7XHJcblxyXG4gIGNvbnN0IHZpc2libGVDb2x1bW5zU2V0ID0gbmV3IFNldCh2aXNpYmxlQ29sdW1ucyk7XHJcbiAgY29uc3QgdmlzaWJsZVNhZmVDb2x1bW5zID0gb3JkZXJlZFNhZmVDb2x1bW5zLmZpbHRlcigoY29sKSA9PlxyXG4gICAgdmlzaWJsZUNvbHVtbnNTZXQuaGFzKGNvbC5rZXkpXHJcbiAgKTtcclxuXHJcbiAgLy8gU2VwYXJhdGUgcmVndWxhciBhbmQgcGlubmVkIGNvbHVtbnMgKGJvdGggbXVzdCBiZSB2aXNpYmxlKVxyXG4gIGNvbnN0IHJlZ3VsYXJDb2x1bW5zID0gdmlzaWJsZVNhZmVDb2x1bW5zLmZpbHRlcihcclxuICAgIChjb2wpID0+ICFwaW5uZWRLZXlzLmluY2x1ZGVzKGNvbC5rZXkpXHJcbiAgKTtcclxuICBjb25zdCBwaW5uZWRDb2x1bW5zID0gdmlzaWJsZVNhZmVDb2x1bW5zLmZpbHRlcigoY29sKSA9PlxyXG4gICAgcGlubmVkS2V5cy5pbmNsdWRlcyhjb2wua2V5KVxyXG4gICk7XHJcblxyXG4gIC8vIEZpbmFsIG9yZGVyOiByZWd1bGFyIGZpcnN0LCB0aGVuIHBpbm5lZFxyXG4gIGNvbnN0IG9yZGVyZWRDb2x1bW5zID0gWy4uLnJlZ3VsYXJDb2x1bW5zLCAuLi5waW5uZWRDb2x1bW5zXTtcclxuXHJcbiAgLy8gQ29tcHV0ZSByaWdodCBvZmZzZXRzIGZvciBwaW5uZWQgY29sdW1ucyAocmlnaHRtb3N0IGdldHMgMClcclxuICAvLyBXZSBuZWVkIHdpZHRocyBmb3IgcGlubmVkIGNvbHVtbnMgaW4gcmV2ZXJzZSBvcmRlci5cclxuICBjb25zdCBwaW5uZWRXaWR0aHMgPSBwaW5uZWRDb2x1bW5zLm1hcCgoY29sKSA9PiBnZXRXaWR0aEluUHgoZ2V0Q29sdW1uV2lkdGgoY29sKSkpO1xyXG4gIGxldCBjdW11bGF0aXZlT2Zmc2V0ID0gMDtcclxuICBjb25zdCBwaW5uZWRPZmZzZXRzID0gcGlubmVkQ29sdW1ucy5tYXAoKGNvbCwgaW5kZXgpID0+IHtcclxuICAgIGNvbnN0IHJldmVyc2VkSW5kZXggPSBwaW5uZWRDb2x1bW5zLmxlbmd0aCAtIDEgLSBpbmRleDtcclxuICAgIGNvbnN0IG9mZnNldCA9IGN1bXVsYXRpdmVPZmZzZXQ7XHJcbiAgICBjdW11bGF0aXZlT2Zmc2V0ICs9IHBpbm5lZFdpZHRoc1tyZXZlcnNlZEluZGV4XTtcclxuICAgIHJldHVybiB7IGtleTogY29sLmtleSwgb2Zmc2V0IH07XHJcbiAgfSk7XHJcbiAgLy8gTWFwIGtleSB0byBvZmZzZXQgZm9yIGVhc3kgbG9va3VwXHJcbiAgY29uc3Qgb2Zmc2V0TWFwID0ge307XHJcbiAgcGlubmVkT2Zmc2V0cy5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICBvZmZzZXRNYXBbaXRlbS5rZXldID0gaXRlbS5vZmZzZXQ7XHJcbiAgfSk7XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gUmVuZGVyIC0tLS0tLS0tLS1cclxuICBpZiAoIXNhZmVEYXRhLmxlbmd0aCB8fCAhc2FmZUNvbHVtbnMubGVuZ3RoKSB7XHJcbiAgICByZXR1cm4gPD48Lz47XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RBbGxDb2x1bW5zID0gKGNoZWNrZWQpID0+IHtcclxuICAgIGlmIChjaGVja2VkKSB7XHJcbiAgICAgIHNldFZpc2libGVDb2x1bW5zKHNhZmVDb2x1bW5zLm1hcCgoY29sKSA9PiBjb2wua2V5KSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRWaXNpYmxlQ29sdW1ucyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgYWxsQ29sdW1uc1NlbGVjdGVkID1cclxuICAgIHZpc2libGVDb2x1bW5zLmxlbmd0aCA9PT0gc2FmZUNvbHVtbnMubGVuZ3RoICYmIHNhZmVDb2x1bW5zLmxlbmd0aCA+IDA7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBwLTZcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi02ICR7aXNTZWFyY2hSZXF1aXJlZCA/ICdqdXN0aWZ5LWJldHdlZW4nIDogJ2p1c3RpZnktZW5kJ31gfT5cclxuICAgICAgICB7aXNTZWFyY2hSZXF1aXJlZCAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBzbTp3LTY0XCI+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaC4uLlwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoUXVlcnkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNSB3LTUgaC01IHRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7aXNFeHBvcnRFbmFibGVkICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIHNtOnctYXV0b1wiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RXhwb3J0VHlwZShcImV4Y2VsXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2hvd0V4cG9ydE1vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yLjUgcm91bmRlZC1sZyBiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwIHRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgZm9udC1tZWRpdW0gdy1mdWxsIHNtOnctYXV0b1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8RmFGaWxlRXhjZWwgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgRXhwb3J0IEV4Y2VsXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RXhwb3J0VHlwZShcInBkZlwiKTtcclxuICAgICAgICAgICAgICAgIHNldFNob3dFeHBvcnRNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgYmctcmVkLTYwMCBob3ZlcjpiZy1yZWQtNzAwIHRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgZm9udC1tZWRpdW0gdy1mdWxsIHNtOnctYXV0b1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8RmFGaWxlUGRmIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIFByaW50IFBERlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgIFNlbGVjdCBDb2x1bW5zIHRvIHtleHBvcnRUeXBlID09PSBcImV4Y2VsXCIgPyBcIkV4cG9ydFwiIDogXCJQcmludFwifVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9wZW49e3Nob3dFeHBvcnRNb2RhbH1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd0V4cG9ydE1vZGFsKGZhbHNlKX1cclxuICAgICAgICBmb290ZXI9e1tcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAga2V5PVwiY2FuY2VsXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0V4cG9ydE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZm9udC1tZWRpdW0gbXItMlwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgPC9idXR0b24+LFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9XCJleHBvcnRcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKGV4cG9ydFR5cGUgPT09IFwiZXhjZWxcIikge1xyXG4gICAgICAgICAgICAgICAgZXhwb3J0VG9FeGNlbCgpO1xyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwcmludFRvUERGKCk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17c2VsZWN0ZWRFeHBvcnRDb2x1bW5zLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yLjUgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGRpc2FibGVkOmJnLWdyYXktMzAwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZm9udC1tZWRpdW0gJHtleHBvcnRUeXBlID09PSBcImV4Y2VsXCJcclxuICAgICAgICAgICAgICA/IFwiYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgOiBcImJnLXJlZC02MDAgaG92ZXI6YmctcmVkLTcwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtleHBvcnRUeXBlID09PSBcImV4Y2VsXCIgPyBcIkV4cG9ydFwiIDogXCJQcmludCBQREZcIn1cclxuICAgICAgICAgIDwvYnV0dG9uPixcclxuICAgICAgICBdfVxyXG4gICAgICAgIHdpZHRoPXs2MDB9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiZXhwb3J0LW1vZGFsXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBiZy1ncmF5LTUwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTMgbWwtMyBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1ncmF5LTEwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRFeHBvcnRDb2x1bW5zLmxlbmd0aCA9PT0gZXhwb3J0Q29sdW1ucy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTZWxlY3RBbGwoZS50YXJnZXQuY2hlY2tlZCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNjAwIHJvdW5kZWQgZm9jdXM6cmluZy1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2VsZWN0IEFsbDwvc3Bhbj5cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wIG1heC1oLTYwIG92ZXJmbG93LXktYXV0byBwci0yXCI+XHJcbiAgICAgICAgICB7ZXhwb3J0Q29sdW1ucy5tYXAoKGNvbHVtbikgPT4gKFxyXG4gICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICBrZXk9e2NvbHVtbi5rZXl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zIHAtMyBob3ZlcjpiZy1ncmF5LTUwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRFeHBvcnRDb2x1bW5zLmluY2x1ZGVzKGNvbHVtbi5rZXkpfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVDb2x1bW5TZWxlY3Rpb24oY29sdW1uLmtleSwgZS50YXJnZXQuY2hlY2tlZClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ibHVlLTYwMCByb3VuZGVkIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMFwiPntjb2x1bW4uaGVhZGVyfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBwLTMgYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMTAwIHJvdW5kZWQtbGcgbWItNFwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtODAwIHNlbGYtY2VudGVyXCI+XHJcbiAgICAgICAgICBDb2x1bW5zOlxyXG4gICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIG1sLTQgdGV4dC14cyBiZy13aGl0ZSBweC0yIHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgY3Vyc29yLXBvaW50ZXIgaG92ZXI6YmctYmx1ZS0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBjaGVja2VkPXthbGxDb2x1bW5zU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0QWxsQ29sdW1ucyhlLnRhcmdldC5jaGVja2VkKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIGZvbnQtbWVkaXVtXCI+U2VsZWN0IEFsbDwvc3Bhbj5cclxuICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICB7c2FmZUNvbHVtbnMubWFwKChjb2x1bW4pID0+IChcclxuICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICBrZXk9e2NvbHVtbi5rZXl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQteHMgYmctd2hpdGUgcHgtMiBweS0xIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWJsdWUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICBjaGVja2VkPXt2aXNpYmxlQ29sdW1ucy5pbmNsdWRlcyhjb2x1bW4ua2V5KX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gdG9nZ2xlQ29sdW1uKGNvbHVtbi5rZXkpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1ibHVlLTYwMCByb3VuZGVkIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwXCI+e2NvbHVtbi5oZWFkZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBzaGFkb3ctc20gb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmVcIlxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgbWF4SGVpZ2h0OiAnNTAwcHgnLFxyXG4gICAgICAgICAgICBvdmVyZmxvd1k6ICdhdXRvJyxcclxuICAgICAgICAgICAgb3ZlcmZsb3dYOiAnYXV0bycsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDx0YWJsZVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIlxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIG1pbldpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgICAgICAgdGFibGVMYXlvdXQ6ICdmaXhlZCcsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgc3RpY2t5IHRvcC0wIHotMjBcIj5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICB7LyogTkVXOiBkcmFnLWhhbmRsZSBoZWFkZXIgY2VsbCwga2VlcHMgZXhpc3RpbmcgY29sdW1ucyB1bnRvdWNoZWQgKi99XHJcbiAgICAgICAgICAgICAgICA8dGhcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICczNnB4JywgbWluV2lkdGg6ICczNnB4JyB9fVxyXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIkRyYWcgcm93cyB0byByZW9yZGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgey8qIGludGVudGlvbmFsbHkgYmxhbmsgKi99XHJcbiAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAge29yZGVyZWRDb2x1bW5zLm1hcCgoY29sdW1uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUGlubmVkID0gcGlubmVkS2V5cy5pbmNsdWRlcyhjb2x1bW4ua2V5KTtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgcmlnaHRPZmZzZXQgPSBpc1Bpbm5lZCA/IG9mZnNldE1hcFtjb2x1bW4ua2V5XSA6IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNDb2x1bW5EcmFnZ2VkID0gZHJhZ2dlZENvbHVtbktleSA9PT0gY29sdW1uLmtleTtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNDb2x1bW5Ecm9wVGFyZ2V0ID0gZHJhZ092ZXJDb2x1bW5LZXkgPT09IGNvbHVtbi5rZXk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHN0eWxlID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiBnZXRDb2x1bW5XaWR0aChjb2x1bW4pLFxyXG4gICAgICAgICAgICAgICAgICAgIG1pbldpZHRoOiBpc0xvbmdDb250ZW50Q29sdW1uKGNvbHVtbi5oZWFkZXIpID8gJzIwMHB4JyA6ICcxMDBweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGlzUGlubmVkID8gJ3N0aWNreScgOiAnc3RhdGljJyxcclxuICAgICAgICAgICAgICAgICAgICByaWdodDogaXNQaW5uZWQgPyBgJHtyaWdodE9mZnNldH1weGAgOiAnYXV0bycsXHJcbiAgICAgICAgICAgICAgICAgICAgekluZGV4OiBpc1Bpbm5lZCA/IDMgOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzUGlubmVkID8gJyNlZmY2ZmYnIDogdW5kZWZpbmVkLCAvLyBtYXRjaCBoZWFkZXIgYmFja2dyb3VuZFxyXG4gICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDx0aFxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtjb2x1bW4ua2V5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWJsdWUtMTAwIHRyYW5zaXRpb24tY29sb3JzICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29sdW1uRHJhZ2dlZCA/IFwib3BhY2l0eS00MFwiIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfSAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0NvbHVtbkRyb3BUYXJnZXQgPyBcImJvcmRlci1sLTIgYm9yZGVyLWJsdWUtNTAwXCIgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXtzdHlsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNvcnQoY29sdW1uLmtleSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBORVc6IGNvbHVtbiByZW9yZGVyaW5nIOKAlCBwaW5uZWQgY29sdW1ucyBzdGF5IGZpeGVkIGFuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gYXJlIGludGVudGlvbmFsbHkgbm90IGRyYWdnYWJsZS5cclxuICAgICAgICAgICAgICAgICAgICAgIGRyYWdnYWJsZT17IWlzUGlubmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9eyhlKSA9PiAhaXNQaW5uZWQgJiYgaGFuZGxlQ29sdW1uRHJhZ1N0YXJ0KGUsIGNvbHVtbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkRyYWdPdmVyPXsoZSkgPT4gIWlzUGlubmVkICYmIGhhbmRsZUNvbHVtbkRyYWdPdmVyKGUsIGNvbHVtbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkRyYWdMZWF2ZT17KCkgPT4gIWlzUGlubmVkICYmIGhhbmRsZUNvbHVtbkRyYWdMZWF2ZShjb2x1bW4pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25Ecm9wPXsoZSkgPT4gIWlzUGlubmVkICYmIGhhbmRsZUNvbHVtbkRyb3AoZSwgY29sdW1uKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uRHJhZ0VuZD17aGFuZGxlQ29sdW1uRHJhZ0VuZH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHshaXNQaW5uZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxHcmlwVmVydGljYWwgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWdyYXktNDAwIGN1cnNvci1tb3ZlIGZsZXgtc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y29sdW1uLmhlYWRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAge3NvcnRDb25maWcua2V5ID09PSBjb2x1bW4ua2V5ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c29ydENvbmZpZy5kaXJlY3Rpb24gPT09IFwiYXNjXCIgPyBcIuKGkVwiIDogXCLihpNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIE5FVzoga2VlcCBmaWx0ZXIgcm93IGFsaWduZWQgd2l0aCB0aGUgZHJhZy1oYW5kbGUgY29sdW1uIGFib3ZlICovfVxyXG4gICAgICAgICAgICAgICAgPHRoIHN0eWxlPXt7IHdpZHRoOiAnMzZweCcsIG1pbldpZHRoOiAnMzZweCcgfX0+PC90aD5cclxuICAgICAgICAgICAgICAgIHtvcmRlcmVkQ29sdW1ucy5tYXAoKGNvbHVtbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBpc1Bpbm5lZCA9IHBpbm5lZEtleXMuaW5jbHVkZXMoY29sdW1uLmtleSk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHJpZ2h0T2Zmc2V0ID0gaXNQaW5uZWQgPyBvZmZzZXRNYXBbY29sdW1uLmtleV0gOiB1bmRlZmluZWQ7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHN0eWxlID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiBnZXRDb2x1bW5XaWR0aChjb2x1bW4pLFxyXG4gICAgICAgICAgICAgICAgICAgIG1pbldpZHRoOiBpc0xvbmdDb250ZW50Q29sdW1uKGNvbHVtbi5oZWFkZXIpID8gJzIwMHB4JyA6ICcxMDBweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGlzUGlubmVkID8gJ3N0aWNreScgOiAnc3RhdGljJyxcclxuICAgICAgICAgICAgICAgICAgICByaWdodDogaXNQaW5uZWQgPyBgJHtyaWdodE9mZnNldH1weGAgOiAnYXV0bycsXHJcbiAgICAgICAgICAgICAgICAgICAgekluZGV4OiBpc1Bpbm5lZCA/IDIgOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzUGlubmVkID8gJyNmOWZhZmInIDogdW5kZWZpbmVkLFxyXG4gICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDx0aFxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtgZmlsdGVyLSR7Y29sdW1uLmtleX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0zXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXtzdHlsZX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y29sdW1uLmtleS50b0xvd2VyQ2FzZSgpICE9PSBcImFjdGlvblwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnNbY29sdW1uLmtleV0gfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RmlsdGVycygocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NvbHVtbi5rZXldOiB2YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsYWJlbCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKSB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGxhYmVsLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Wy4uLm5ldyBTZXQoc2FmZURhdGEubWFwKChpdGVtKSA9PiBpdGVtW2NvbHVtbi5rZXldKSldLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICh2YWx1ZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e1N0cmluZyh2YWx1ZSl9IHZhbHVlPXtTdHJpbmcodmFsdWUpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICB7cGFnaW5hdGVkRGF0YS5tYXAoKHJvdywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGlzQ3JlYXRlZFRvZGF5ID0gaXNUb2RheShyb3dbY3JlYXRlZERhdGVDb2x1bW5dKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGlzQmVpbmdEcmFnZ2VkID0gZHJhZ2dlZFJvd0lkID09PSByb3dbY2F0Y2hlcl07XHJcbiAgICAgICAgICAgICAgICBjb25zdCBpc0Ryb3BUYXJnZXQgPSBkcmFnT3ZlclJvd0lkID09PSByb3dbY2F0Y2hlcl07XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHJcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0Um93KHJvdy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uRHJhZ092ZXI9eyhlKSA9PiBoYW5kbGVEcmFnT3ZlclJvdyhlLCByb3cpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uRHJhZ0xlYXZlPXsoKSA9PiBoYW5kbGVEcmFnTGVhdmVSb3cocm93KX1cclxuICAgICAgICAgICAgICAgICAgICBvbkRyb3A9eyhlKSA9PiBoYW5kbGVEcm9wUm93KGUsIHJvdyl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHthY3RpdmVbcm93Ll9pZF1cclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IGlzQ3JlYXRlZFRvZGF5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmVlbi01MCBib3JkZXItbC00IGJvcmRlci1ncmVlbi01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGluZGV4ICUgMiA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSBob3ZlcjpiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9ICR7aXNCZWluZ0RyYWdnZWQgPyBcIm9wYWNpdHktNDBcIiA6IFwiXCJ9ICR7aXNEcm9wVGFyZ2V0ID8gXCJib3JkZXItdC0yIGJvcmRlci1ibHVlLTUwMFwiIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfSBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE5FVzogZHJhZy1oYW5kbGUgY2VsbCwgb25seSB0aGlzIGNlbGwgaXMgZHJhZ2dhYmxlIHNvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0IGRvZXNuJ3QgaW50ZXJmZXJlIHdpdGggcm93IHNlbGVjdGlvbiAvIGRvdWJsZS1jbGljayAqL31cclxuICAgICAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktNCB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICczNnB4JywgbWluV2lkdGg6ICczNnB4JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgZHJhZ2dhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uRHJhZ1N0YXJ0PXsoZSkgPT4gaGFuZGxlRHJhZ1N0YXJ0KGUsIHJvdyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkRyYWdFbmQ9e2hhbmRsZURyYWdFbmRSb3d9XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRyYWcgdG8gcmVvcmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEdyaXBWZXJ0aWNhbCBjbGFzc05hbWU9XCJ3LTQgaC00IGN1cnNvci1tb3ZlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIHtvcmRlcmVkQ29sdW1ucy5tYXAoKGNvbHVtbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNQaW5uZWQgPSBwaW5uZWRLZXlzLmluY2x1ZGVzKGNvbHVtbi5rZXkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmlnaHRPZmZzZXQgPSBpc1Bpbm5lZCA/IG9mZnNldE1hcFtjb2x1bW4ua2V5XSA6IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0eWxlID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogZ2V0Q29sdW1uV2lkdGgoY29sdW1uKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluV2lkdGg6IGlzTG9uZ0NvbnRlbnRDb2x1bW4oY29sdW1uLmhlYWRlcikgPyAnMjAwcHgnIDogJzEwMHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgd29yZFdyYXA6ICdicmVhay13b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2hpdGVTcGFjZTogJ25vcm1hbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heFdpZHRoOiBpc0xvbmdDb250ZW50Q29sdW1uKGNvbHVtbi5oZWFkZXIpID8gJzMwMHB4JyA6ICdub25lJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGlzUGlubmVkID8gJ3N0aWNreScgOiAnc3RhdGljJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IGlzUGlubmVkID8gYCR7cmlnaHRPZmZzZXR9cHhgIDogJ2F1dG8nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB6SW5kZXg6IGlzUGlubmVkID8gMiA6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzUGlubmVkID8gKGluZGV4ICUgMiA9PT0gMCA/ICcjZmZmZmZmJyA6ICcjZjlmYWZiJykgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtgJHtpbmRleH0tJHtjb2x1bW4ua2V5fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS00IHRleHQtc20gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3N0eWxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uRG91YmxlQ2xpY2s9eygpID0+IHVwZGF0ZUhhbmRsZXIocm93W2NhdGNoZXJdKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtyb3dbY29sdW1uLmtleV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbXQtNiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcmVsYXRpdmVcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlNob3c8L3NwYW4+XHJcbiAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgIHZhbHVlPXtwYWdlU2l6ZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0UGFnZVNpemUoTnVtYmVyKHZhbHVlKSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjBcIlxyXG4gICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgZ2V0UG9wdXBDb250YWluZXI9eyh0cmlnZ2VyTm9kZSkgPT4gdHJpZ2dlck5vZGUucGFyZW50RWxlbWVudH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge1s1LCAxMCwgMjAsIDUwLCAxMDBdLm1hcCgoc2l6ZSkgPT4gKFxyXG4gICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c2l6ZX0gdmFsdWU9e3NpemV9PlxyXG4gICAgICAgICAgICAgICAge3NpemV9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+ZW50cmllczwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZSgocHJldikgPT4gTWF0aC5tYXgoMSwgcHJldiAtIDEpKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlID09PSAxfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktNTAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPENoZXZyb25MZWZ0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDAgcHgtMyBweS0xXCI+XHJcbiAgICAgICAgICAgIFBhZ2Uge2N1cnJlbnRQYWdlfSBvZiB7TWF0aC5tYXgoMSwgdG90YWxQYWdlcyl9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgc2V0Q3VycmVudFBhZ2UoKHByZXYpID0+IE1hdGgubWluKHRvdGFsUGFnZXMsIHByZXYgKyAxKSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17Y3VycmVudFBhZ2UgPT09IHRvdGFsUGFnZXMgfHwgdG90YWxQYWdlcyA9PT0gMH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTUwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGF0YVRhYmxlOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlLmpzeCJ9