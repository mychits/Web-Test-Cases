import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitUpgrade.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Dropdown, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Modal as antModal } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const { confirm } = antModal;
const ChitUpgrade = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [users, setUsers] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [fromEnrollments, setFromEnrollments] = useState([]);
  const [toEnrollments, setToEnrollments] = useState([]);
  const [upgrades, setUpgrades] = useState([]);
  const [tableUpgrades, setTableUpgrades] = useState([]);
  const [formData, setFormData] = useState({
    fromEnrollment: "",
    toEnrollment: "",
    user_id: ""
    // keep track of selected customer
  });
  const [modalVisible, setModalVisible] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [currentUpgrade, setCurrentUpgrade] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [differenceAmount, setDifferenceAmount] = useState(null);
  const [isVerified, setIsVerified] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  useEffect(() => {
    const fetchAllCustomers = async () => {
      try {
        const response = await api.get("user/verified");
        setUsers(response?.data?.data);
      } catch (error) {
        setUsers([]);
        console.error("Error fetching group data:", error);
      }
    };
    fetchAllCustomers();
  }, []);
  const fetchAllData = async () => {
    try {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      const userId = user?.userId || user?._id || user?.id;
      setIsLoading(true);
      const [empRes, upgradeRes] = await Promise.all(
        [
          api.get("/agent/get-agent"),
          api.get("/v1/admin/chit-business-upgradation/")
        ]
      );
      setEmployees(empRes.data || []);
      const upgrades2 = Array.isArray(upgradeRes.data) ? upgradeRes.data : upgradeRes.data?.data || [];
      const formatted = upgrades2.map((upgrade, index) => {
        const fromEnroll = upgrade.from_enroll_id || {};
        const toEnroll = upgrade.to_enroll_id || {};
        const agent = upgrade.agent_id || {};
        const fromUser = fromEnroll.user_id || {};
        const toUser = toEnroll.user_id || {};
        const fromGroup = fromEnroll.group_id || {};
        const toGroup = toEnroll.group_id || {};
        const formatCurrency = (value) => `₹${Number(value).toLocaleString("en-IN")}`;
        const fromDisplay = fromUser.full_name && fromGroup.group_name ? `${fromUser.full_name} | ${fromGroup.group_name} | ${formatCurrency(fromGroup.group_value)} | Tickets: ${fromEnroll.tickets ?? 0}` : "N/A";
        const toDisplay = toUser.full_name && toGroup.group_name ? `${toUser.full_name} | ${toGroup.group_name} | ${formatCurrency(toGroup.group_value)} | Tickets: ${toEnroll.tickets ?? 0}` : "N/A";
        return {
          _id: upgrade._id,
          id: index + 1,
          // Table columns (must match the keys in the columns array)
          upgradeCode: upgrade.upgrade_code || "N/A",
          upgradeDate: upgrade.createdAt ? new Date(upgrade.createdAt).toLocaleDateString("en-GB") : "N/A",
          fromEnrollment: fromDisplay,
          toEnrollment: toDisplay,
          employeeName: `${agent?.name || "N/A"} - ${agent?.phone_number || "N/A"}`,
          // employeeCode: agent.phone_number || "N/A",
          amount: formatCurrency(upgrade.diff_group_value || 0),
          status: toEnroll.customer_status || "Active",
          // using the target enrollment status
          action: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => openEdit(upgrade),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                        lineNumber: 131,
                        columnNumber: 17
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDelete(upgrade._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                        lineNumber: 142,
                        columnNumber: 17
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                lineNumber: 154,
                columnNumber: 29
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 125,
              columnNumber: 11
            },
            this
          ),
          // ─── Additional raw fields (useful if you later expand the table) ───
          fromCustomer: fromUser.full_name || "N/A",
          fromPhone: fromUser.phone_number || "N/A",
          fromEnrollCode: fromEnroll.enroll_code || "N/A",
          fromGroupName: fromGroup.group_name || "N/A",
          fromGroupValue: formatCurrency(fromGroup.group_value),
          fromTickets: fromEnroll.tickets ?? 0,
          fromStatus: fromEnroll.customer_status || "In Active",
          toCustomer: toUser.full_name || "N/A",
          toPhone: toUser.phone_number || "N/A",
          toEnrollCode: toEnroll.enroll_code || "N/A",
          toGroupName: toGroup.group_name || "N/A",
          toGroupValue: formatCurrency(toGroup.group_value),
          toTickets: toEnroll.tickets ?? 0,
          toStatus: toEnroll.customer_status || "Active",
          diffAmount: formatCurrency(upgrade.diff_group_value || 0)
        };
      });
      setTableUpgrades(formatted);
    } catch (err) {
      console.error("Error fetching data:", err);
      setAlertConfig({
        visibility: true,
        message: "Failed to load data",
        type: "error"
      });
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchAllData();
  }, [reloadTrigger]);
  const handleCustomer = async (userId) => {
    setSelectedUserId(userId);
    setFormData((prev) => ({ ...prev, user_id: userId, fromEnrollment: "", toEnrollment: "" }));
    setIsVerified(false);
    setDifferenceAmount(null);
    if (!userId) {
      setFromEnrollments([]);
      setToEnrollments([]);
      return;
    }
    try {
      const fromRes = await api.get(`/v1/admin/enrolls/upgraded-enrollments/${userId}`);
      setFromEnrollments(fromRes?.data?.data || []);
      const toRes = await api.get(`/v1/admin/enrolls/all-enrollments/${userId}`);
      setToEnrollments(toRes?.data?.data || []);
    } catch (error) {
      console.error("Error fetching enrollments:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to load enrollments for selected customer.",
        type: "error"
      });
      setFromEnrollments([]);
      setToEnrollments([]);
    }
  };
  const handleAntDSelect = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (isVerified) setIsVerified(false);
    if (differenceAmount) setDifferenceAmount(null);
  };
  const resetForm = () => {
    setFormData({
      fromEnrollment: "",
      toEnrollment: "",
      user_id: ""
    });
    setSelectedUserId("");
    setFromEnrollments([]);
    setToEnrollments([]);
    setCurrentUpgrade(null);
    setIsVerified(false);
    setDifferenceAmount(null);
  };
  const openEdit = (upgrade) => {
    const customerId = upgrade.fromEnrollment?.user_id?._id || upgrade.fromEnrollment?.user_id || "";
    if (customerId) {
      setSelectedUserId(customerId);
      setFormData((prev) => ({
        ...prev,
        user_id: customerId,
        fromEnrollment: upgrade.fromEnrollment?._id || upgrade.fromEnrollment || "",
        toEnrollment: upgrade.toEnrollment?._id || upgrade.toEnrollment || ""
      }));
      Promise.all(
        [
          api.get(`/v1/admin/enrolls/deleted-enrollments/${customerId}`),
          api.get(`/v1/admin/enrolls/all-enrollments/${customerId}`)
        ]
      ).then(([fromRes, toRes]) => {
        setFromEnrollments(fromRes?.data?.data || []);
        setToEnrollments(toRes?.data?.data || []);
      }).catch((err) => {
        console.error("Failed to load enrollments for edit:", err);
        setAlertConfig({ visibility: true, message: "Failed to load enrollments", type: "error" });
      });
    } else {
      setFormData({
        fromEnrollment: upgrade.fromEnrollment?._id || upgrade.fromEnrollment || "",
        toEnrollment: upgrade.toEnrollment?._id || upgrade.toEnrollment || "",
        user_id: ""
      });
    }
    setCurrentUpgrade(upgrade._id);
    setIsVerified(false);
    setDifferenceAmount(null);
    setModalVisible(true);
  };
  const handleVerifyAndSubmit = async (e) => {
    e.preventDefault();
    if (!formData.fromEnrollment || !formData.toEnrollment) {
      setAlertConfig({
        visibility: true,
        message: "Please select both From and To enrollments",
        type: "error"
      });
      return;
    }
    if (!isVerified) {
      setIsVerifying(true);
      try {
        const verifyRes = await api.get(
          "/v1/admin/chit-business-upgradation/verify",
          {
            params: {
              fromEnrollId: formData.fromEnrollment,
              toEnrollId: formData.toEnrollment
            }
          }
        );
        if (!verifyRes.data?.data?.upgradation) {
          setAlertConfig({
            visibility: true,
            message: "Chit upgrade is not possible for the selected enrollments.",
            type: "error"
          });
          setIsVerifying(false);
          return;
        }
        setDifferenceAmount(verifyRes.data?.data);
        setIsVerified(true);
        setAlertConfig({
          visibility: true,
          message: "Verification successful. Click 'Submit' to complete the upgrade.",
          type: "success"
        });
      } catch (err) {
        console.error("Verification error:", err);
        if (err.response?.data?.data?.upgradation === false) {
          setAlertConfig({
            visibility: true,
            message: "Chit upgrade is not possible for the selected enrollments.",
            type: "error"
          });
        } else {
          setAlertConfig({
            visibility: true,
            message: err.response?.data?.message || "Verification failed.",
            type: "error"
          });
        }
      } finally {
        setIsVerifying(false);
      }
      return;
    }
    const fromEnroll = fromEnrollments.find((e2) => e2._id === formData.fromEnrollment);
    const toEnroll = toEnrollments.find((e2) => e2._id === formData.toEnrollment);
    const confirmMessage = `Do you want to upgrade from "${fromEnroll?.user_id?.full_name || "N/A"} (${fromEnroll?.group_id?.group_name || "N/A"})" to "${toEnroll?.user_id?.full_name || "N/A"} (${toEnroll?.group_id?.group_name || "N/A"})"?`;
    confirm({
      title: "Confirm Chit Upgrade",
      content: confirmMessage,
      okText: "Yes",
      cancelText: "No",
      centered: true,
      okType: "primary",
      onOk: async () => {
        setIsVerifying(true);
        try {
          const user = JSON.parse(localStorage.getItem("user") || "{}");
          const upgradedBy = user?._id || user?.userId || user?.id || "";
          if (!upgradedBy) {
            setAlertConfig({
              visibility: true,
              message: "User not logged in.",
              type: "error"
            });
            setIsVerifying(false);
            return;
          }
          const payload = {
            fromEnrollId: formData.fromEnrollment,
            toEnrollId: formData.toEnrollment,
            upgradedBy
          };
          if (currentUpgrade) {
            await api.put(`/chit-upgrade/update-upgrade/${currentUpgrade}`, payload);
            setAlertConfig({
              visibility: true,
              message: "Upgrade updated successfully.",
              type: "success"
            });
          } else {
            await api.post("/v1/admin/chit-business-upgradation", payload);
            setAlertConfig({
              visibility: true,
              message: "Upgrade created successfully.",
              type: "success"
            });
          }
          setModalVisible(false);
          resetForm();
          setReloadTrigger((prev) => prev + 1);
        } catch (err) {
          console.error("Submission error:", err);
          setAlertConfig({
            visibility: true,
            message: err.response?.data?.message || "Failed to submit upgrade.",
            type: "error"
          });
        } finally {
          setIsVerifying(false);
        }
      }
    });
  };
  const handleDelete = async (id) => {
    try {
      await api.delete(`/chit-upgrade/delete-upgrade/${id}`);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Upgrade deleted",
        type: "success"
      });
    } catch (err) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error"
      });
    }
  };
  const columns = [
    { key: "id", header: "SL No" },
    { key: "upgradeCode", header: "Upgrade Code" },
    { key: "upgradeDate", header: "Upgrade Date" },
    { key: "fromEnrollment", header: "From Enrollment" },
    { key: "toEnrollment", header: "To Enrollment" },
    { key: "employeeName", header: "Agent Name | Mobile" },
    // { key: "employeeCode", header: "Agent Mobile" },
    { key: "amount", header: "Business Amount" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
        lineNumber: 460,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
          lineNumber: 461,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
        lineNumber: 467,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Chit Upgrade" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
            lineNumber: 472,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setModalVisible(true);
                resetForm();
              },
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Upgrade Chit"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 473,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
          lineNumber: 471,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
          lineNumber: 470,
          columnNumber: 21
        }, this),
        tableUpgrades.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: (id) => {
              const upgrade = upgrades.find((u) => u._id === id);
              if (upgrade) openEdit(upgrade);
            },
            data: tableUpgrades,
            columns,
            exportedPdfName: "ChitUpgrades",
            exportedFileName: "ChitUpgrades.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
            lineNumber: 486,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: !isLoading,
            data: "Chit Upgrade Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
            lineNumber: 497,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
        lineNumber: 469,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
      lineNumber: 459,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: modalVisible, onClose: () => setModalVisible(false), children: /* @__PURE__ */ jsxDEV("div", { className: "p-5 w-full", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold mb-6", children: currentUpgrade ? "Update Chit Upgrade" : "Upgrade Chit" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
        lineNumber: 509,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleVerifyAndSubmit, className: "space-y-8", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
            "Customer ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 518,
              columnNumber: 42
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
            lineNumber: 517,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "Select Or Search Customer",
              popupMatchSelectWidth: false,
              showSearch: true,
              className: "w-full h-12",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              value: selectedUserId || void 0,
              onChange: handleCustomer,
              children: users.map(
                (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: `${user.full_name} | ${user.phone_number}` }, user._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                  lineNumber: 535,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 520,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
          lineNumber: 516,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "From Enrollment ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 545,
              columnNumber: 49
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
            lineNumber: 544,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "Select From Enrollment",
              className: "w-full",
              size: "large",
              showSearch: true,
              optionFilterProp: "children",
              value: formData.fromEnrollment || void 0,
              onChange: (value) => handleAntDSelect("fromEnrollment", value),
              disabled: !selectedUserId,
              children: fromEnrollments.map(
                (e) => /* @__PURE__ */ jsxDEV(Select.Option, { value: e._id, children: `${e.user_id?.full_name || "N/A"} | ${e.user_id?.phone_number || "N/A"} | ${e.group_id?.group_name || "N/A"} | Ticket: ${e.tickets}` }, e._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                  lineNumber: 558,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 547,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
          lineNumber: 543,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "To Enrollment ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 568,
              columnNumber: 47
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
            lineNumber: 567,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "Select To Enrollment",
              className: "w-full",
              size: "large",
              showSearch: true,
              optionFilterProp: "children",
              value: formData.toEnrollment || void 0,
              onChange: (value) => handleAntDSelect("toEnrollment", value),
              disabled: !selectedUserId,
              children: toEnrollments.filter((e) => e._id !== formData.fromEnrollment).map(
                (e) => /* @__PURE__ */ jsxDEV(Select.Option, { value: e._id, children: `${e.user_id?.full_name || "N/A"} | ${e.user_id?.phone_number || "N/A"} | ${e.group_id?.group_name || "N/A"} | Ticket: ${e.tickets}` }, e._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                  lineNumber: 583,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 570,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
          lineNumber: 566,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center border-t pt-5 mt-6 gap-4", children: [
          isVerified && differenceAmount && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 rounded-lg border border-blue-200 bg-blue-50 px-5 py-3 shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Upgrade Status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                lineNumber: 595,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex mt-1 rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700", children: "Approved" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                lineNumber: 596,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 594,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Difference Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                lineNumber: 601,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 font-bold text-blue-700", children: [
                "₹ ",
                differenceAmount?.diff_group_value?.toLocaleString("en-IN") || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
                lineNumber: 602,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 600,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
            lineNumber: 593,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isVerifying,
              className: `ml-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-2.5 rounded-lg shadow-md transition-all ${isVerifying ? "opacity-50 cursor-not-allowed" : ""}`,
              children: isVerifying ? "Processing..." : isVerified ? "Submit" : "Verify"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
              lineNumber: 609,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
          lineNumber: 591,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
        lineNumber: 513,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
      lineNumber: 508,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
      lineNumber: 507,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx",
    lineNumber: 458,
    columnNumber: 5
  }, this);
};
_s(ChitUpgrade, "D+0dE7opqjia9WwfIi9IYUTpSMQ=");
_c = ChitUpgrade;
export default ChitUpgrade;
var _c;
$RefreshReg$(_c, "ChitUpgrade");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitUpgrade.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0k0QyxTQXVVcEMsVUF2VW9DOzJCQWxJNUM7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNQLFNBQVNRLGdCQUFnQjtBQUVsQyxNQUFNLEVBQUVDLFFBQVEsSUFBSUQ7QUFFcEIsTUFBTUUsY0FBY0EsTUFBTTtBQUFBQyxLQUFBO0FBRXRCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJaEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2lCLE9BQU9DLFFBQVEsSUFBSWxCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNtQixnQkFBZ0JDLGlCQUFpQixJQUFJcEIsU0FBUyxFQUFFO0FBRXZELFFBQU0sQ0FBQ3FCLGlCQUFpQkMsa0JBQWtCLElBQUl0QixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDdUIsZUFBZUMsZ0JBQWdCLElBQUl4QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDeUIsVUFBVUMsV0FBVyxJQUFJMUIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQzJCLGVBQWVDLGdCQUFnQixJQUFJNUIsU0FBUyxFQUFFO0FBR3JELFFBQU0sQ0FBQzZCLFVBQVVDLFdBQVcsSUFBSTlCLFNBQVM7QUFBQSxJQUNyQytCLGdCQUFnQjtBQUFBLElBQ2hCQyxjQUFjO0FBQUEsSUFDZEMsU0FBUztBQUFBO0FBQUEsRUFDYixDQUFDO0FBRUQsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUluQyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDb0MsZUFBZUMsZ0JBQWdCLElBQUlyQyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDc0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXZDLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUN3QyxXQUFXQyxZQUFZLElBQUl6QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMEMsYUFBYUMsY0FBYyxJQUFJM0MsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQzRDLGtCQUFrQkMsbUJBQW1CLElBQUk3QyxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDOEMsWUFBWUMsYUFBYSxJQUFJL0MsU0FBUyxLQUFLO0FBR2xELFFBQU0sQ0FBQ2dELGFBQWFDLGNBQWMsSUFBSWpELFNBQVM7QUFBQSxJQUMzQ2tELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1YsQ0FBQztBQUdEQyxZQUFVLE1BQU07QUFDWixVQUFNQyxvQkFBb0IsWUFBWTtBQUNsQyxVQUFJO0FBQ0EsY0FBTUMsV0FBVyxNQUFNbEQsSUFBSW1ELElBQUksZUFBZTtBQUM5Q3RDLGlCQUFTcUMsVUFBVUUsTUFBTUEsSUFBSTtBQUFBLE1BQ2pDLFNBQVNDLE9BQU87QUFDWnhDLGlCQUFTLEVBQUU7QUFDWHlDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ3JEO0FBQUEsSUFDSjtBQUNBSixzQkFBa0I7QUFBQSxFQUN0QixHQUFHLEVBQUU7QUFFTCxRQUFNTSxlQUFlLFlBQVk7QUFDN0IsUUFBSTtBQUNBLFlBQU1DLE9BQU9DLEtBQUtDLE1BQU1DLGFBQWFDLFFBQVEsTUFBTSxLQUFLLElBQUk7QUFDNUQsWUFBTUMsU0FBU0wsTUFBTUssVUFBVUwsTUFBTU0sT0FBT04sTUFBTU87QUFFbEQzQixtQkFBYSxJQUFJO0FBR2pCLFlBQU0sQ0FBQzRCLFFBQVFDLFVBQVUsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDM0NuRSxJQUFJbUQsSUFBSSxrQkFBa0I7QUFBQSxVQUMxQm5ELElBQUltRCxJQUFJLHNDQUFzQztBQUFBLFFBQUM7QUFBQSxNQUNsRDtBQUVEeEMsbUJBQWFxRCxPQUFPWixRQUFRLEVBQUU7QUFHOUIsWUFBTWhDLFlBQVdnRCxNQUFNQyxRQUFRSixXQUFXYixJQUFJLElBQ3hDYSxXQUFXYixPQUNYYSxXQUFXYixNQUFNQSxRQUFRO0FBRy9CLFlBQU1rQixZQUFZbEQsVUFBU21ELElBQUksQ0FBQ0MsU0FBU0MsVUFBVTtBQUMvQyxjQUFNQyxhQUFhRixRQUFRRyxrQkFBa0IsQ0FBQztBQUM5QyxjQUFNQyxXQUFXSixRQUFRSyxnQkFBZ0IsQ0FBQztBQUMxQyxjQUFNQyxRQUFRTixRQUFRTyxZQUFZLENBQUM7QUFHbkMsY0FBTUMsV0FBV04sV0FBVzlDLFdBQVcsQ0FBQztBQUN4QyxjQUFNcUQsU0FBU0wsU0FBU2hELFdBQVcsQ0FBQztBQUNwQyxjQUFNc0QsWUFBWVIsV0FBV1MsWUFBWSxDQUFDO0FBQzFDLGNBQU1DLFVBQVVSLFNBQVNPLFlBQVksQ0FBQztBQUd0QyxjQUFNRSxpQkFBaUJBLENBQUNDLFVBQ3BCLElBQUlDLE9BQU9ELEtBQUssRUFBRUUsZUFBZSxPQUFPLENBQUM7QUFHN0MsY0FBTUMsY0FDRlQsU0FBU1UsYUFBYVIsVUFBVVMsYUFDMUIsR0FBR1gsU0FBU1UsU0FBUyxNQUFNUixVQUFVUyxVQUFVLE1BQU1OLGVBQWVILFVBQVVVLFdBQVcsQ0FBQyxlQUFlbEIsV0FBV21CLFdBQVcsQ0FBQyxLQUNoSTtBQUVWLGNBQU1DLFlBQ0ZiLE9BQU9TLGFBQWFOLFFBQVFPLGFBQ3RCLEdBQUdWLE9BQU9TLFNBQVMsTUFBTU4sUUFBUU8sVUFBVSxNQUFNTixlQUFlRCxRQUFRUSxXQUFXLENBQUMsZUFBZWhCLFNBQVNpQixXQUFXLENBQUMsS0FDeEg7QUFFVixlQUFPO0FBQUEsVUFDSC9CLEtBQUtVLFFBQVFWO0FBQUFBLFVBQ2JDLElBQUlVLFFBQVE7QUFBQTtBQUFBLFVBR1pzQixhQUFhdkIsUUFBUXdCLGdCQUFnQjtBQUFBLFVBQ3JDQyxhQUFhekIsUUFBUTBCLFlBQ2YsSUFBSUMsS0FBSzNCLFFBQVEwQixTQUFTLEVBQUVFLG1CQUFtQixPQUFPLElBQ3REO0FBQUEsVUFDTjFFLGdCQUFnQitEO0FBQUFBLFVBQ2hCOUQsY0FBY21FO0FBQUFBLFVBQ2RPLGNBQWMsR0FBR3ZCLE9BQU93QixRQUFRLEtBQUssTUFBTXhCLE9BQU95QixnQkFBZ0IsS0FBSztBQUFBO0FBQUEsVUFFdkVDLFFBQVFuQixlQUFlYixRQUFRaUMsb0JBQW9CLENBQUM7QUFBQSxVQUNwREMsUUFBUTlCLFNBQVMrQixtQkFBbUI7QUFBQTtBQUFBLFVBQ3BDQyxRQUNJO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFNO0FBQUEsZ0JBQ0ZDLE9BQU87QUFBQSxrQkFDSDtBQUFBLG9CQUNJQyxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0k7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUMsU0FBU3hDLE9BQU87QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVSO0FBQUEsa0JBQ0E7QUFBQSxvQkFDSXNDLEtBQUs7QUFBQSxvQkFDTEMsT0FDSTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNRSxhQUFhekMsUUFBUVYsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRVI7QUFBQSxnQkFBQztBQUFBLGNBRVQ7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQTtBQUFBLFlBN0J4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUE4QkE7QUFBQTtBQUFBLFVBSUpvRCxjQUFjbEMsU0FBU1UsYUFBYTtBQUFBLFVBQ3BDeUIsV0FBV25DLFNBQVN1QixnQkFBZ0I7QUFBQSxVQUNwQ2EsZ0JBQWdCMUMsV0FBVzJDLGVBQWU7QUFBQSxVQUMxQ0MsZUFBZXBDLFVBQVVTLGNBQWM7QUFBQSxVQUN2QzRCLGdCQUFnQmxDLGVBQWVILFVBQVVVLFdBQVc7QUFBQSxVQUNwRDRCLGFBQWE5QyxXQUFXbUIsV0FBVztBQUFBLFVBQ25DNEIsWUFBWS9DLFdBQVdpQyxtQkFBbUI7QUFBQSxVQUUxQ2UsWUFBWXpDLE9BQU9TLGFBQWE7QUFBQSxVQUNoQ2lDLFNBQVMxQyxPQUFPc0IsZ0JBQWdCO0FBQUEsVUFDaENxQixjQUFjaEQsU0FBU3lDLGVBQWU7QUFBQSxVQUN0Q1EsYUFBYXpDLFFBQVFPLGNBQWM7QUFBQSxVQUNuQ21DLGNBQWN6QyxlQUFlRCxRQUFRUSxXQUFXO0FBQUEsVUFDaERtQyxXQUFXbkQsU0FBU2lCLFdBQVc7QUFBQSxVQUMvQm1DLFVBQVVwRCxTQUFTK0IsbUJBQW1CO0FBQUEsVUFFdENzQixZQUFZNUMsZUFBZWIsUUFBUWlDLG9CQUFvQixDQUFDO0FBQUEsUUFDNUQ7QUFBQSxNQUNKLENBQUM7QUFFRGxGLHVCQUFpQitDLFNBQVM7QUFBQSxJQUM5QixTQUFTNEQsS0FBSztBQUNWNUUsY0FBUUQsTUFBTSx3QkFBd0I2RSxHQUFHO0FBQ3pDdEYscUJBQWU7QUFBQSxRQUNYQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNWLENBQUM7QUFBQSxJQUNMLFVBQUM7QUFDR1gsbUJBQWEsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDSjtBQUVBWSxZQUFVLE1BQU07QUFDWk8saUJBQWE7QUFBQSxFQUNqQixHQUFHLENBQUN4QixhQUFhLENBQUM7QUFHbEIsUUFBTW9HLGlCQUFpQixPQUFPdEUsV0FBVztBQUNyQzlDLHNCQUFrQjhDLE1BQU07QUFDeEJwQyxnQkFBWSxDQUFDMkcsVUFBVSxFQUFFLEdBQUdBLE1BQU14RyxTQUFTaUMsUUFBUW5DLGdCQUFnQixJQUFJQyxjQUFjLEdBQUcsRUFBRTtBQUMxRmUsa0JBQWMsS0FBSztBQUNuQkYsd0JBQW9CLElBQUk7QUFFeEIsUUFBSSxDQUFDcUIsUUFBUTtBQUNUNUMseUJBQW1CLEVBQUU7QUFDckJFLHVCQUFpQixFQUFFO0FBQ25CO0FBQUEsSUFDSjtBQUVBLFFBQUk7QUFFQSxZQUFNa0gsVUFBVSxNQUFNckksSUFBSW1ELElBQUksMENBQTBDVSxNQUFNLEVBQUU7QUFDaEY1Qyx5QkFBbUJvSCxTQUFTakYsTUFBTUEsUUFBUSxFQUFFO0FBRzVDLFlBQU1rRixRQUFRLE1BQU10SSxJQUFJbUQsSUFBSSxxQ0FBcUNVLE1BQU0sRUFBRTtBQUN6RTFDLHVCQUFpQm1ILE9BQU9sRixNQUFNQSxRQUFRLEVBQUU7QUFBQSxJQUM1QyxTQUFTQyxPQUFPO0FBQ1pDLGNBQVFELE1BQU0sK0JBQStCQSxLQUFLO0FBQ2xEVCxxQkFBZTtBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1YsQ0FBQztBQUNEOUIseUJBQW1CLEVBQUU7QUFDckJFLHVCQUFpQixFQUFFO0FBQUEsSUFDdkI7QUFBQSxFQUNKO0FBR0EsUUFBTW9ILG1CQUFtQkEsQ0FBQ2pDLE1BQU1oQixVQUFVO0FBQ3RDN0QsZ0JBQVksQ0FBQzJHLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUM5QixJQUFJLEdBQUdoQixNQUFNLEVBQUU7QUFDbEQsUUFBSTdDLFdBQVlDLGVBQWMsS0FBSztBQUNuQyxRQUFJSCxpQkFBa0JDLHFCQUFvQixJQUFJO0FBQUEsRUFDbEQ7QUFFQSxRQUFNZ0csWUFBWUEsTUFBTTtBQUNwQi9HLGdCQUFZO0FBQUEsTUFDUkMsZ0JBQWdCO0FBQUEsTUFDaEJDLGNBQWM7QUFBQSxNQUNkQyxTQUFTO0FBQUEsSUFDYixDQUFDO0FBQ0RiLHNCQUFrQixFQUFFO0FBQ3BCRSx1QkFBbUIsRUFBRTtBQUNyQkUscUJBQWlCLEVBQUU7QUFDbkJlLHNCQUFrQixJQUFJO0FBQ3RCUSxrQkFBYyxLQUFLO0FBQ25CRix3QkFBb0IsSUFBSTtBQUFBLEVBQzVCO0FBR0EsUUFBTXdFLFdBQVdBLENBQUN4QyxZQUFZO0FBRTFCLFVBQU1pRSxhQUFhakUsUUFBUTlDLGdCQUFnQkUsU0FBU2tDLE9BQU9VLFFBQVE5QyxnQkFBZ0JFLFdBQVc7QUFDOUYsUUFBSTZHLFlBQVk7QUFFWjFILHdCQUFrQjBILFVBQVU7QUFDNUJoSCxrQkFBWSxDQUFDMkcsVUFBVTtBQUFBLFFBQ25CLEdBQUdBO0FBQUFBLFFBQ0h4RyxTQUFTNkc7QUFBQUEsUUFDVC9HLGdCQUFnQjhDLFFBQVE5QyxnQkFBZ0JvQyxPQUFPVSxRQUFROUMsa0JBQWtCO0FBQUEsUUFDekVDLGNBQWM2QyxRQUFRN0MsY0FBY21DLE9BQU9VLFFBQVE3QyxnQkFBZ0I7QUFBQSxNQUN2RSxFQUFFO0FBRUZ1QyxjQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDUm5FLElBQUltRCxJQUFJLHlDQUF5Q3NGLFVBQVUsRUFBRTtBQUFBLFVBQzdEekksSUFBSW1ELElBQUkscUNBQXFDc0YsVUFBVSxFQUFFO0FBQUEsUUFBQztBQUFBLE1BQzdELEVBQUVDLEtBQUssQ0FBQyxDQUFDTCxTQUFTQyxLQUFLLE1BQU07QUFDMUJySCwyQkFBbUJvSCxTQUFTakYsTUFBTUEsUUFBUSxFQUFFO0FBQzVDakMseUJBQWlCbUgsT0FBT2xGLE1BQU1BLFFBQVEsRUFBRTtBQUFBLE1BQzVDLENBQUMsRUFBRXVGLE1BQU0sQ0FBQVQsUUFBTztBQUNaNUUsZ0JBQVFELE1BQU0sd0NBQXdDNkUsR0FBRztBQUN6RHRGLHVCQUFlLEVBQUVDLFlBQVksTUFBTUMsU0FBUyw4QkFBOEJDLE1BQU0sUUFBUSxDQUFDO0FBQUEsTUFDN0YsQ0FBQztBQUFBLElBQ0wsT0FBTztBQUVIdEIsa0JBQVk7QUFBQSxRQUNSQyxnQkFBZ0I4QyxRQUFROUMsZ0JBQWdCb0MsT0FBT1UsUUFBUTlDLGtCQUFrQjtBQUFBLFFBQ3pFQyxjQUFjNkMsUUFBUTdDLGNBQWNtQyxPQUFPVSxRQUFRN0MsZ0JBQWdCO0FBQUEsUUFDbkVDLFNBQVM7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNMO0FBQ0FNLHNCQUFrQnNDLFFBQVFWLEdBQUc7QUFDN0JwQixrQkFBYyxLQUFLO0FBQ25CRix3QkFBb0IsSUFBSTtBQUN4QlYsb0JBQWdCLElBQUk7QUFBQSxFQUN4QjtBQUdBLFFBQU04Ryx3QkFBd0IsT0FBT0MsTUFBTTtBQUN2Q0EsTUFBRUMsZUFBZTtBQUVqQixRQUFJLENBQUN0SCxTQUFTRSxrQkFBa0IsQ0FBQ0YsU0FBU0csY0FBYztBQUNwRGlCLHFCQUFlO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDVixDQUFDO0FBQ0Q7QUFBQSxJQUNKO0FBR0EsUUFBSSxDQUFDTixZQUFZO0FBQ2JILHFCQUFlLElBQUk7QUFDbkIsVUFBSTtBQUNBLGNBQU15RyxZQUFZLE1BQU0vSSxJQUFJbUQ7QUFBQUEsVUFDeEI7QUFBQSxVQUNBO0FBQUEsWUFDSTZGLFFBQVE7QUFBQSxjQUNKQyxjQUFjekgsU0FBU0U7QUFBQUEsY0FDdkJ3SCxZQUFZMUgsU0FBU0c7QUFBQUEsWUFDekI7QUFBQSxVQUNKO0FBQUEsUUFDSjtBQUVBLFlBQUksQ0FBQ29ILFVBQVUzRixNQUFNQSxNQUFNK0YsYUFBYTtBQUNwQ3ZHLHlCQUFlO0FBQUEsWUFDWEMsWUFBWTtBQUFBLFlBQ1pDLFNBQVM7QUFBQSxZQUNUQyxNQUFNO0FBQUEsVUFDVixDQUFDO0FBQ0RULHlCQUFlLEtBQUs7QUFDcEI7QUFBQSxRQUNKO0FBRUFFLDRCQUFvQnVHLFVBQVUzRixNQUFNQSxJQUFJO0FBQ3hDVixzQkFBYyxJQUFJO0FBQ2xCRSx1QkFBZTtBQUFBLFVBQ1hDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1YsQ0FBQztBQUFBLE1BQ0wsU0FBU21GLEtBQUs7QUFDVjVFLGdCQUFRRCxNQUFNLHVCQUF1QjZFLEdBQUc7QUFDeEMsWUFBSUEsSUFBSWhGLFVBQVVFLE1BQU1BLE1BQU0rRixnQkFBZ0IsT0FBTztBQUNqRHZHLHlCQUFlO0FBQUEsWUFDWEMsWUFBWTtBQUFBLFlBQ1pDLFNBQVM7QUFBQSxZQUNUQyxNQUFNO0FBQUEsVUFDVixDQUFDO0FBQUEsUUFDTCxPQUFPO0FBQ0hILHlCQUFlO0FBQUEsWUFDWEMsWUFBWTtBQUFBLFlBQ1pDLFNBQVNvRixJQUFJaEYsVUFBVUUsTUFBTU4sV0FBVztBQUFBLFlBQ3hDQyxNQUFNO0FBQUEsVUFDVixDQUFDO0FBQUEsUUFDTDtBQUFBLE1BQ0osVUFBQztBQUNHVCx1QkFBZSxLQUFLO0FBQUEsTUFDeEI7QUFDQTtBQUFBLElBQ0o7QUFJQSxVQUFNb0MsYUFBYTFELGdCQUFnQm9JLEtBQUssQ0FBQ1AsT0FBTUEsR0FBRS9FLFFBQVF0QyxTQUFTRSxjQUFjO0FBQ2hGLFVBQU1rRCxXQUFXMUQsY0FBY2tJLEtBQUssQ0FBQ1AsT0FBTUEsR0FBRS9FLFFBQVF0QyxTQUFTRyxZQUFZO0FBRTFFLFVBQU0wSCxpQkFBaUIsZ0NBQWdDM0UsWUFBWTlDLFNBQVM4RCxhQUFhLEtBQUssS0FDckZoQixZQUFZUyxVQUFVUSxjQUFjLEtBQUssVUFBVWYsVUFBVWhELFNBQVM4RCxhQUFhLEtBQUssS0FDeEZkLFVBQVVPLFVBQVVRLGNBQWMsS0FBSztBQUVoRHBGLFlBQVE7QUFBQSxNQUNKK0ksT0FBTztBQUFBLE1BQ1BDLFNBQVNGO0FBQUFBLE1BQ1RHLFFBQVE7QUFBQSxNQUNSQyxZQUFZO0FBQUEsTUFDWkMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNSQyxNQUFNLFlBQVk7QUFDZHRILHVCQUFlLElBQUk7QUFDbkIsWUFBSTtBQUNBLGdCQUFNa0IsT0FBT0MsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxNQUFNLEtBQUssSUFBSTtBQUM1RCxnQkFBTWlHLGFBQWFyRyxNQUFNTSxPQUFPTixNQUFNSyxVQUFVTCxNQUFNTyxNQUFNO0FBRTVELGNBQUksQ0FBQzhGLFlBQVk7QUFDYmpILDJCQUFlO0FBQUEsY0FDWEMsWUFBWTtBQUFBLGNBQ1pDLFNBQVM7QUFBQSxjQUNUQyxNQUFNO0FBQUEsWUFDVixDQUFDO0FBQ0RULDJCQUFlLEtBQUs7QUFDcEI7QUFBQSxVQUNKO0FBRUEsZ0JBQU13SCxVQUFVO0FBQUEsWUFDWmIsY0FBY3pILFNBQVNFO0FBQUFBLFlBQ3ZCd0gsWUFBWTFILFNBQVNHO0FBQUFBLFlBQ3JCa0k7QUFBQUEsVUFDSjtBQUVBLGNBQUk1SCxnQkFBZ0I7QUFDaEIsa0JBQU1qQyxJQUFJK0osSUFBSSxnQ0FBZ0M5SCxjQUFjLElBQUk2SCxPQUFPO0FBQ3ZFbEgsMkJBQWU7QUFBQSxjQUNYQyxZQUFZO0FBQUEsY0FDWkMsU0FBUztBQUFBLGNBQ1RDLE1BQU07QUFBQSxZQUNWLENBQUM7QUFBQSxVQUNMLE9BQU87QUFDSCxrQkFBTS9DLElBQUlnSyxLQUFLLHVDQUF1Q0YsT0FBTztBQUM3RGxILDJCQUFlO0FBQUEsY0FDWEMsWUFBWTtBQUFBLGNBQ1pDLFNBQVM7QUFBQSxjQUNUQyxNQUFNO0FBQUEsWUFDVixDQUFDO0FBQUEsVUFDTDtBQUVBakIsMEJBQWdCLEtBQUs7QUFDckIwRyxvQkFBVTtBQUNWeEcsMkJBQWlCLENBQUNvRyxTQUFTQSxPQUFPLENBQUM7QUFBQSxRQUN2QyxTQUFTRixLQUFLO0FBQ1Y1RSxrQkFBUUQsTUFBTSxxQkFBcUI2RSxHQUFHO0FBQ3RDdEYseUJBQWU7QUFBQSxZQUNYQyxZQUFZO0FBQUEsWUFDWkMsU0FBU29GLElBQUloRixVQUFVRSxNQUFNTixXQUFXO0FBQUEsWUFDeENDLE1BQU07QUFBQSxVQUNWLENBQUM7QUFBQSxRQUNMLFVBQUM7QUFDR1QseUJBQWUsS0FBSztBQUFBLFFBQ3hCO0FBQUEsTUFDSjtBQUFBLElBQ0osQ0FBQztBQUFBLEVBQ0w7QUFHQSxRQUFNMkUsZUFBZSxPQUFPbEQsT0FBTztBQUMvQixRQUFJO0FBQ0EsWUFBTS9ELElBQUlpSyxPQUFPLGdDQUFnQ2xHLEVBQUUsRUFBRTtBQUNyRC9CLHVCQUFpQixDQUFDb0csU0FBU0EsT0FBTyxDQUFDO0FBQ25DeEYscUJBQWU7QUFBQSxRQUNYQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNWLENBQUM7QUFBQSxJQUNMLFNBQVNtRixLQUFLO0FBQ1Z0RixxQkFBZTtBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1YsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNKO0FBR0EsUUFBTW1ILFVBQVU7QUFBQSxJQUNaLEVBQUVwRCxLQUFLLE1BQU1xRCxRQUFRLFFBQVE7QUFBQSxJQUM3QixFQUFFckQsS0FBSyxlQUFlcUQsUUFBUSxlQUFlO0FBQUEsSUFDN0MsRUFBRXJELEtBQUssZUFBZXFELFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUVyRCxLQUFLLGtCQUFrQnFELFFBQVEsa0JBQWtCO0FBQUEsSUFDbkQsRUFBRXJELEtBQUssZ0JBQWdCcUQsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFckQsS0FBSyxnQkFBZ0JxRCxRQUFRLHNCQUFzQjtBQUFBO0FBQUEsSUFFckQsRUFBRXJELEtBQUssVUFBVXFELFFBQVEsa0JBQWtCO0FBQUEsSUFDM0MsRUFBRXJELEtBQUssVUFBVXFELFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVyRCxLQUFLLFVBQVVxRCxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3ZDLFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNHLE1BQU14SCxZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixTQUFTLE1BQU1GLGVBQWUsQ0FBQ3dGLFVBQVUsRUFBRSxHQUFHQSxNQUFNdkYsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLFFBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUk4RTtBQUFBLE1BRTlFLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFFUix1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFDWCxpQ0FBQyxTQUFJLFdBQVUsNENBQ1g7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLDRCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25EO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFTLE1BQU07QUFDWGYsZ0NBQWdCLElBQUk7QUFDcEIwRywwQkFBVTtBQUFBLGNBQ2Q7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUFtRztBQUFBO0FBQUEsWUFMakg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQSxLQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUNsSCxjQUFjOEksU0FBUyxLQUFLLENBQUNqSSxZQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csZUFBZSxDQUFDNEIsT0FBTztBQUNuQixvQkFBTVMsVUFBVXBELFNBQVNnSSxLQUFLLENBQUNpQixNQUFNQSxFQUFFdkcsUUFBUUMsRUFBRTtBQUNqRCxrQkFBSVMsUUFBU3dDLFVBQVN4QyxPQUFPO0FBQUEsWUFDakM7QUFBQSxZQUNBLE1BQU1sRDtBQUFBQSxZQUNOO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBaUI7QUFBQTtBQUFBLFVBUnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVF1QyxJQUd2QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0c7QUFBQSxZQUNBLFNBQVMsQ0FBQ2E7QUFBQUEsWUFDVixNQUFLO0FBQUE7QUFBQSxVQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc0QjtBQUFBLFdBL0JwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsU0E1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZDQTtBQUFBLElBR0EsdUJBQUMsU0FBTSxXQUFXTixjQUFjLFNBQVMsTUFBTUMsZ0JBQWdCLEtBQUssR0FDaEUsaUNBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQSw2QkFBQyxRQUFHLFdBQVUsMEJBQ1RHLDJCQUFpQix3QkFBd0Isa0JBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVMkcsdUJBQXVCLFdBQVUsYUFHN0M7QUFBQSwrQkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsWUFDckQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxhQUFZO0FBQUEsY0FDWix1QkFBdUI7QUFBQSxjQUN2QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1YsY0FBYyxDQUFDMEIsT0FBT0MsV0FDbEJBLE9BQU9DLFNBQ0ZDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxjQUVyQyxPQUFPNUosa0JBQWtCOEo7QUFBQUEsY0FDekIsVUFBVXpDO0FBQUFBLGNBRVR2SCxnQkFBTTJEO0FBQUFBLGdCQUFJLENBQUNmLFNBQ1IsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUtNLEtBQ3JDLGFBQUdOLEtBQUtrQyxTQUFTLE1BQU1sQyxLQUFLK0MsWUFBWSxNQUR6Qi9DLEtBQUtNLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQSxZQWxCTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxhQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFHQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsWUFDOUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0Esa0JBQWlCO0FBQUEsY0FDakIsT0FBT3RDLFNBQVNFLGtCQUFrQmtKO0FBQUFBLGNBQ2xDLFVBQVUsQ0FBQ3RGLFVBQVVpRCxpQkFBaUIsa0JBQWtCakQsS0FBSztBQUFBLGNBQzdELFVBQVUsQ0FBQ3hFO0FBQUFBLGNBRVZFLDBCQUFnQnVEO0FBQUFBLGdCQUFJLENBQUNzRSxNQUNsQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsRUFBRS9FLEtBQy9CLGFBQUcrRSxFQUFFakgsU0FBUzhELGFBQWEsS0FBSyxNQUFNbUQsRUFBRWpILFNBQVMyRSxnQkFBZ0IsS0FBSyxNQUFNc0MsRUFBRTFELFVBQVVRLGNBQWMsS0FBSyxjQUFja0QsRUFBRWhELE9BQU8sTUFEbkhnRCxFQUFFL0UsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0g7QUFBQTtBQUFBLFlBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZUE7QUFBQSxhQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFHQSx1QkFBQyxTQUNHO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsWUFDaEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0Esa0JBQWlCO0FBQUEsY0FDakIsT0FBT3RDLFNBQVNHLGdCQUFnQmlKO0FBQUFBLGNBQ2hDLFVBQVUsQ0FBQ3RGLFVBQVVpRCxpQkFBaUIsZ0JBQWdCakQsS0FBSztBQUFBLGNBQzNELFVBQVUsQ0FBQ3hFO0FBQUFBLGNBRVZJLHdCQUNJMkosT0FBTyxDQUFDaEMsTUFBTUEsRUFBRS9FLFFBQVF0QyxTQUFTRSxjQUFjLEVBQy9DNkM7QUFBQUEsZ0JBQUksQ0FBQ3NFLE1BQ0YsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUUvRSxLQUMvQixhQUFHK0UsRUFBRWpILFNBQVM4RCxhQUFhLEtBQUssTUFBTW1ELEVBQUVqSCxTQUFTMkUsZ0JBQWdCLEtBQUssTUFBTXNDLEVBQUUxRCxVQUFVUSxjQUFjLEtBQUssY0FBY2tELEVBQUVoRCxPQUFPLE1BRG5IZ0QsRUFBRS9FLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQSxZQWhCVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkE7QUFBQSxhQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsOENBQ1ZyQjtBQUFBQSx3QkFBY0Ysb0JBQ1gsdUJBQUMsU0FBSSxXQUFVLDRGQUNYO0FBQUEsbUNBQUMsU0FDRztBQUFBLHFDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsOEJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsY0FDL0QsdUJBQUMsVUFBSyxXQUFVLDZGQUE0Rix3QkFBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0c7QUFBQSxxQ0FBQyxPQUFFLFdBQVUscUNBQW9DLGlDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGNBQ2xFLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0I7QUFBQTtBQUFBLGdCQUNyQ0Esa0JBQWtCa0Usa0JBQWtCakIsZUFBZSxPQUFPLEtBQUs7QUFBQSxtQkFEdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUdKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxVQUFVbkQ7QUFBQUEsY0FDVixXQUFXLGtIQUFrSEEsY0FBYyxrQ0FBa0MsRUFBRTtBQUFBLGNBRzlLQSx3QkFBYyxrQkFBa0JJLGFBQWEsV0FBVztBQUFBO0FBQUEsWUFON0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsV0F4R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlHQTtBQUFBLFNBOUdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErR0EsS0FoSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlIQTtBQUFBLE9BbEtKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtS0E7QUFFUjtBQUFFaEMsR0FobUJJRCxhQUFXO0FBQUFzSyxLQUFYdEs7QUFrbUJOLGVBQWVBO0FBQVksSUFBQXNLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJOYXZiYXIiLCJNb2RhbCIsIkRhdGFUYWJsZSIsImFwaSIsIkNpcmN1bGFyTG9hZGVyIiwiRHJvcGRvd24iLCJTZWxlY3QiLCJJb01kTW9yZSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiYW50TW9kYWwiLCJjb25maXJtIiwiQ2hpdFVwZ3JhZGUiLCJfcyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInVzZXJzIiwic2V0VXNlcnMiLCJzZWxlY3RlZFVzZXJJZCIsInNldFNlbGVjdGVkVXNlcklkIiwiZnJvbUVucm9sbG1lbnRzIiwic2V0RnJvbUVucm9sbG1lbnRzIiwidG9FbnJvbGxtZW50cyIsInNldFRvRW5yb2xsbWVudHMiLCJ1cGdyYWRlcyIsInNldFVwZ3JhZGVzIiwidGFibGVVcGdyYWRlcyIsInNldFRhYmxlVXBncmFkZXMiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZnJvbUVucm9sbG1lbnQiLCJ0b0Vucm9sbG1lbnQiLCJ1c2VyX2lkIiwibW9kYWxWaXNpYmxlIiwic2V0TW9kYWxWaXNpYmxlIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJjdXJyZW50VXBncmFkZSIsInNldEN1cnJlbnRVcGdyYWRlIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiaXNWZXJpZnlpbmciLCJzZXRJc1ZlcmlmeWluZyIsImRpZmZlcmVuY2VBbW91bnQiLCJzZXREaWZmZXJlbmNlQW1vdW50IiwiaXNWZXJpZmllZCIsInNldElzVmVyaWZpZWQiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwidXNlRWZmZWN0IiwiZmV0Y2hBbGxDdXN0b21lcnMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaEFsbERhdGEiLCJ1c2VyIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInVzZXJJZCIsIl9pZCIsImlkIiwiZW1wUmVzIiwidXBncmFkZVJlcyIsIlByb21pc2UiLCJhbGwiLCJBcnJheSIsImlzQXJyYXkiLCJmb3JtYXR0ZWQiLCJtYXAiLCJ1cGdyYWRlIiwiaW5kZXgiLCJmcm9tRW5yb2xsIiwiZnJvbV9lbnJvbGxfaWQiLCJ0b0Vucm9sbCIsInRvX2Vucm9sbF9pZCIsImFnZW50IiwiYWdlbnRfaWQiLCJmcm9tVXNlciIsInRvVXNlciIsImZyb21Hcm91cCIsImdyb3VwX2lkIiwidG9Hcm91cCIsImZvcm1hdEN1cnJlbmN5IiwidmFsdWUiLCJOdW1iZXIiLCJ0b0xvY2FsZVN0cmluZyIsImZyb21EaXNwbGF5IiwiZnVsbF9uYW1lIiwiZ3JvdXBfbmFtZSIsImdyb3VwX3ZhbHVlIiwidGlja2V0cyIsInRvRGlzcGxheSIsInVwZ3JhZGVDb2RlIiwidXBncmFkZV9jb2RlIiwidXBncmFkZURhdGUiLCJjcmVhdGVkQXQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZW1wbG95ZWVOYW1lIiwibmFtZSIsInBob25lX251bWJlciIsImFtb3VudCIsImRpZmZfZ3JvdXBfdmFsdWUiLCJzdGF0dXMiLCJjdXN0b21lcl9zdGF0dXMiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwib3BlbkVkaXQiLCJoYW5kbGVEZWxldGUiLCJmcm9tQ3VzdG9tZXIiLCJmcm9tUGhvbmUiLCJmcm9tRW5yb2xsQ29kZSIsImVucm9sbF9jb2RlIiwiZnJvbUdyb3VwTmFtZSIsImZyb21Hcm91cFZhbHVlIiwiZnJvbVRpY2tldHMiLCJmcm9tU3RhdHVzIiwidG9DdXN0b21lciIsInRvUGhvbmUiLCJ0b0Vucm9sbENvZGUiLCJ0b0dyb3VwTmFtZSIsInRvR3JvdXBWYWx1ZSIsInRvVGlja2V0cyIsInRvU3RhdHVzIiwiZGlmZkFtb3VudCIsImVyciIsImhhbmRsZUN1c3RvbWVyIiwicHJldiIsImZyb21SZXMiLCJ0b1JlcyIsImhhbmRsZUFudERTZWxlY3QiLCJyZXNldEZvcm0iLCJjdXN0b21lcklkIiwidGhlbiIsImNhdGNoIiwiaGFuZGxlVmVyaWZ5QW5kU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwidmVyaWZ5UmVzIiwicGFyYW1zIiwiZnJvbUVucm9sbElkIiwidG9FbnJvbGxJZCIsInVwZ3JhZGF0aW9uIiwiZmluZCIsImNvbmZpcm1NZXNzYWdlIiwidGl0bGUiLCJjb250ZW50Iiwib2tUZXh0IiwiY2FuY2VsVGV4dCIsImNlbnRlcmVkIiwib2tUeXBlIiwib25PayIsInVwZ3JhZGVkQnkiLCJwYXlsb2FkIiwicHV0IiwicG9zdCIsImRlbGV0ZSIsImNvbHVtbnMiLCJoZWFkZXIiLCJsZW5ndGgiLCJ1IiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVuZGVmaW5lZCIsImZpbHRlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoaXRVcGdyYWRlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IERyb3Bkb3duLCBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IE1vZGFsIGFzIGFudE1vZGFsIH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmNvbnN0IHsgY29uZmlybSB9ID0gYW50TW9kYWw7XHJcblxyXG5jb25zdCBDaGl0VXBncmFkZSA9ICgpID0+IHtcclxuICAgIC8vIC0tLS0tLS0tLS0gRGF0YSBzdGF0ZXMgLS0tLS0tLS0tLVxyXG4gICAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkVXNlcklkLCBzZXRTZWxlY3RlZFVzZXJJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIC8vIFJlcGxhY2VkIGBlbnJvbGxtZW50c2Agd2l0aCB0d28gc2VwYXJhdGUgbGlzdHNcclxuICAgIGNvbnN0IFtmcm9tRW5yb2xsbWVudHMsIHNldEZyb21FbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbdG9FbnJvbGxtZW50cywgc2V0VG9FbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbdXBncmFkZXMsIHNldFVwZ3JhZGVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFt0YWJsZVVwZ3JhZGVzLCBzZXRUYWJsZVVwZ3JhZGVzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgICAvLyAtLS0tLS0tLS0tIE1vZGFsIGZvcm0gc3RhdGUgLS0tLS0tLS0tLVxyXG4gICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgZnJvbUVucm9sbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgdG9FbnJvbGxtZW50OiBcIlwiLFxyXG4gICAgICAgIHVzZXJfaWQ6IFwiXCIsIC8vIGtlZXAgdHJhY2sgb2Ygc2VsZWN0ZWQgY3VzdG9tZXJcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IFttb2RhbFZpc2libGUsIHNldE1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICAgIGNvbnN0IFtjdXJyZW50VXBncmFkZSwgc2V0Q3VycmVudFVwZ3JhZGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2lzVmVyaWZ5aW5nLCBzZXRJc1ZlcmlmeWluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbZGlmZmVyZW5jZUFtb3VudCwgc2V0RGlmZmVyZW5jZUFtb3VudF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICAgIGNvbnN0IFtpc1ZlcmlmaWVkLCBzZXRJc1ZlcmlmaWVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICAvLyBBbGVydFxyXG4gICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICAgICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgICAgICB0eXBlOiBcImluZm9cIixcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIC0tLS0tLS0tLS0gTG9hZCBhbGwgY3VzdG9tZXJzICh1bmNoYW5nZWQpIC0tLS0tLS0tLS1cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZmV0Y2hBbGxDdXN0b21lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCJ1c2VyL3ZlcmlmaWVkXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0VXNlcnMocmVzcG9uc2U/LmRhdGE/LmRhdGEpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgc2V0VXNlcnMoW10pO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZmV0Y2hBbGxDdXN0b21lcnMoKTtcclxuICAgIH0sIFtdKTtcclxuICAgIC8vIC0tLS0tLS0tLS0gRmV0Y2ggYWxsIG5lZWRlZCBkYXRhIChleGNlcHQgZW5yb2xsbWVudHMpIC0tLS0tLS0tLS1cclxuICAgIGNvbnN0IGZldGNoQWxsRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIikgfHwgXCJ7fVwiKTtcclxuICAgICAgICAgICAgY29uc3QgdXNlcklkID0gdXNlcj8udXNlcklkIHx8IHVzZXI/Ll9pZCB8fCB1c2VyPy5pZDtcclxuXHJcbiAgICAgICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgICAgIC8vIEZldGNoIGVtcGxveWVlcyBhbmQgdXBncmFkYXRpb25zIGluIHBhcmFsbGVsXHJcbiAgICAgICAgICAgIGNvbnN0IFtlbXBSZXMsIHVwZ3JhZGVSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICAgICAgYXBpLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIiksXHJcbiAgICAgICAgICAgICAgICBhcGkuZ2V0KFwiL3YxL2FkbWluL2NoaXQtYnVzaW5lc3MtdXBncmFkYXRpb24vXCIpLFxyXG4gICAgICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgICAgIHNldEVtcGxveWVlcyhlbXBSZXMuZGF0YSB8fCBbXSk7XHJcblxyXG4gICAgICAgICAgICAvLyBTYWZlbHkgZXh0cmFjdCB0aGUgdXBncmFkZXMgYXJyYXkgZnJvbSB0aGUgQVBJIHJlc3BvbnNlXHJcbiAgICAgICAgICAgIGNvbnN0IHVwZ3JhZGVzID0gQXJyYXkuaXNBcnJheSh1cGdyYWRlUmVzLmRhdGEpXHJcbiAgICAgICAgICAgICAgICA/IHVwZ3JhZGVSZXMuZGF0YVxyXG4gICAgICAgICAgICAgICAgOiB1cGdyYWRlUmVzLmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAgICAgICAvLyBGb3JtYXQgZWFjaCB1cGdyYWRlIGZvciB0aGUgdGFibGVcclxuICAgICAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gdXBncmFkZXMubWFwKCh1cGdyYWRlLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZnJvbUVucm9sbCA9IHVwZ3JhZGUuZnJvbV9lbnJvbGxfaWQgfHwge307XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0b0Vucm9sbCA9IHVwZ3JhZGUudG9fZW5yb2xsX2lkIHx8IHt9O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgYWdlbnQgPSB1cGdyYWRlLmFnZW50X2lkIHx8IHt9O1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIEV4dHJhY3QgbmVzdGVkIHVzZXIgYW5kIGdyb3VwIG9iamVjdHNcclxuICAgICAgICAgICAgICAgIGNvbnN0IGZyb21Vc2VyID0gZnJvbUVucm9sbC51c2VyX2lkIHx8IHt9O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdG9Vc2VyID0gdG9FbnJvbGwudXNlcl9pZCB8fCB7fTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGZyb21Hcm91cCA9IGZyb21FbnJvbGwuZ3JvdXBfaWQgfHwge307XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0b0dyb3VwID0gdG9FbnJvbGwuZ3JvdXBfaWQgfHwge307XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gSGVscGVyIHRvIGZvcm1hdCBjdXJyZW5jeVxyXG4gICAgICAgICAgICAgICAgY29uc3QgZm9ybWF0Q3VycmVuY3kgPSAodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgYOKCuSR7TnVtYmVyKHZhbHVlKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWA7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gQnVpbGQgZGlzcGxheSBzdHJpbmdzIGZvciB0aGUgXCJGcm9tIEVucm9sbG1lbnRcIiBhbmQgXCJUbyBFbnJvbGxtZW50XCIgY2VsbHNcclxuICAgICAgICAgICAgICAgIGNvbnN0IGZyb21EaXNwbGF5ID1cclxuICAgICAgICAgICAgICAgICAgICBmcm9tVXNlci5mdWxsX25hbWUgJiYgZnJvbUdyb3VwLmdyb3VwX25hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBgJHtmcm9tVXNlci5mdWxsX25hbWV9IHwgJHtmcm9tR3JvdXAuZ3JvdXBfbmFtZX0gfCAke2Zvcm1hdEN1cnJlbmN5KGZyb21Hcm91cC5ncm91cF92YWx1ZSl9IHwgVGlja2V0czogJHtmcm9tRW5yb2xsLnRpY2tldHMgPz8gMH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJOL0FcIjtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCB0b0Rpc3BsYXkgPVxyXG4gICAgICAgICAgICAgICAgICAgIHRvVXNlci5mdWxsX25hbWUgJiYgdG9Hcm91cC5ncm91cF9uYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gYCR7dG9Vc2VyLmZ1bGxfbmFtZX0gfCAke3RvR3JvdXAuZ3JvdXBfbmFtZX0gfCAke2Zvcm1hdEN1cnJlbmN5KHRvR3JvdXAuZ3JvdXBfdmFsdWUpfSB8IFRpY2tldHM6ICR7dG9FbnJvbGwudGlja2V0cyA/PyAwfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwiO1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgX2lkOiB1cGdyYWRlLl9pZCxcclxuICAgICAgICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBUYWJsZSBjb2x1bW5zIChtdXN0IG1hdGNoIHRoZSBrZXlzIGluIHRoZSBjb2x1bW5zIGFycmF5KVxyXG4gICAgICAgICAgICAgICAgICAgIHVwZ3JhZGVDb2RlOiB1cGdyYWRlLnVwZ3JhZGVfY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHVwZ3JhZGVEYXRlOiB1cGdyYWRlLmNyZWF0ZWRBdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHVwZ3JhZGUuY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZnJvbUVucm9sbG1lbnQ6IGZyb21EaXNwbGF5LFxyXG4gICAgICAgICAgICAgICAgICAgIHRvRW5yb2xsbWVudDogdG9EaXNwbGF5LFxyXG4gICAgICAgICAgICAgICAgICAgIGVtcGxveWVlTmFtZTogYCR7YWdlbnQ/Lm5hbWUgfHwgXCJOL0FcIn0gLSAke2FnZW50Py5waG9uZV9udW1iZXIgfHwgXCJOL0FcIn1gLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGVtcGxveWVlQ29kZTogYWdlbnQucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBmb3JtYXRDdXJyZW5jeSh1cGdyYWRlLmRpZmZfZ3JvdXBfdmFsdWUgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiB0b0Vucm9sbC5jdXN0b21lcl9zdGF0dXMgfHwgXCJBY3RpdmVcIiwgLy8gdXNpbmcgdGhlIHRhcmdldCBlbnJvbGxtZW50IHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlbkVkaXQodXBncmFkZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZSh1cGdyYWRlLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyDilIDilIDilIAgQWRkaXRpb25hbCByYXcgZmllbGRzICh1c2VmdWwgaWYgeW91IGxhdGVyIGV4cGFuZCB0aGUgdGFibGUpIOKUgOKUgOKUgFxyXG4gICAgICAgICAgICAgICAgICAgIGZyb21DdXN0b21lcjogZnJvbVVzZXIuZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZnJvbVBob25lOiBmcm9tVXNlci5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgICBmcm9tRW5yb2xsQ29kZTogZnJvbUVucm9sbC5lbnJvbGxfY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGZyb21Hcm91cE5hbWU6IGZyb21Hcm91cC5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZnJvbUdyb3VwVmFsdWU6IGZvcm1hdEN1cnJlbmN5KGZyb21Hcm91cC5ncm91cF92YWx1ZSksXHJcbiAgICAgICAgICAgICAgICAgICAgZnJvbVRpY2tldHM6IGZyb21FbnJvbGwudGlja2V0cyA/PyAwLFxyXG4gICAgICAgICAgICAgICAgICAgIGZyb21TdGF0dXM6IGZyb21FbnJvbGwuY3VzdG9tZXJfc3RhdHVzIHx8IFwiSW4gQWN0aXZlXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRvQ3VzdG9tZXI6IHRvVXNlci5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgICB0b1Bob25lOiB0b1VzZXIucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdG9FbnJvbGxDb2RlOiB0b0Vucm9sbC5lbnJvbGxfY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHRvR3JvdXBOYW1lOiB0b0dyb3VwLmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgICB0b0dyb3VwVmFsdWU6IGZvcm1hdEN1cnJlbmN5KHRvR3JvdXAuZ3JvdXBfdmFsdWUpLFxyXG4gICAgICAgICAgICAgICAgICAgIHRvVGlja2V0czogdG9FbnJvbGwudGlja2V0cyA/PyAwLFxyXG4gICAgICAgICAgICAgICAgICAgIHRvU3RhdHVzOiB0b0Vucm9sbC5jdXN0b21lcl9zdGF0dXMgfHwgXCJBY3RpdmVcIixcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgZGlmZkFtb3VudDogZm9ybWF0Q3VycmVuY3kodXBncmFkZS5kaWZmX2dyb3VwX3ZhbHVlIHx8IDApLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBzZXRUYWJsZVVwZ3JhZGVzKGZvcm1hdHRlZCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnIpO1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gbG9hZCBkYXRhXCIsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGZldGNoQWxsRGF0YSgpO1xyXG4gICAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgICAvLyAtLS0tLS0tLS0tIEN1c3RvbWVyIHNlbGVjdGlvbiBoYW5kbGVyIC0tLS0tLS0tLS1cclxuICAgIGNvbnN0IGhhbmRsZUN1c3RvbWVyID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgICAgIHNldFNlbGVjdGVkVXNlcklkKHVzZXJJZCk7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIHVzZXJfaWQ6IHVzZXJJZCwgZnJvbUVucm9sbG1lbnQ6IFwiXCIsIHRvRW5yb2xsbWVudDogXCJcIiB9KSk7XHJcbiAgICAgICAgc2V0SXNWZXJpZmllZChmYWxzZSk7XHJcbiAgICAgICAgc2V0RGlmZmVyZW5jZUFtb3VudChudWxsKTtcclxuXHJcbiAgICAgICAgaWYgKCF1c2VySWQpIHtcclxuICAgICAgICAgICAgc2V0RnJvbUVucm9sbG1lbnRzKFtdKTtcclxuICAgICAgICAgICAgc2V0VG9FbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIC8vIEZldGNoIEZyb20gRW5yb2xsbWVudHMgKGRlbGV0ZWQgZW5yb2xsbWVudHMpXHJcbiAgICAgICAgICAgIGNvbnN0IGZyb21SZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vZW5yb2xscy91cGdyYWRlZC1lbnJvbGxtZW50cy8ke3VzZXJJZH1gKTtcclxuICAgICAgICAgICAgc2V0RnJvbUVucm9sbG1lbnRzKGZyb21SZXM/LmRhdGE/LmRhdGEgfHwgW10pO1xyXG5cclxuICAgICAgICAgICAgLy8gRmV0Y2ggVG8gRW5yb2xsbWVudHMgKGFsbCBlbnJvbGxtZW50cylcclxuICAgICAgICAgICAgY29uc3QgdG9SZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vZW5yb2xscy9hbGwtZW5yb2xsbWVudHMvJHt1c2VySWR9YCk7XHJcbiAgICAgICAgICAgIHNldFRvRW5yb2xsbWVudHModG9SZXM/LmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gbG9hZCBlbnJvbGxtZW50cyBmb3Igc2VsZWN0ZWQgY3VzdG9tZXIuXCIsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzZXRGcm9tRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgICAgICBzZXRUb0Vucm9sbG1lbnRzKFtdKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIC0tLS0tLS0tLS0gRm9ybSBoYW5kbGVycyAtLS0tLS0tLS0tXHJcbiAgICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKG5hbWUsIHZhbHVlKSA9PiB7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gICAgICAgIGlmIChpc1ZlcmlmaWVkKSBzZXRJc1ZlcmlmaWVkKGZhbHNlKTtcclxuICAgICAgICBpZiAoZGlmZmVyZW5jZUFtb3VudCkgc2V0RGlmZmVyZW5jZUFtb3VudChudWxsKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgZnJvbUVucm9sbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHRvRW5yb2xsbWVudDogXCJcIixcclxuICAgICAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRTZWxlY3RlZFVzZXJJZChcIlwiKTtcclxuICAgICAgICBzZXRGcm9tRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgIHNldFRvRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgIHNldEN1cnJlbnRVcGdyYWRlKG51bGwpO1xyXG4gICAgICAgIHNldElzVmVyaWZpZWQoZmFsc2UpO1xyXG4gICAgICAgIHNldERpZmZlcmVuY2VBbW91bnQobnVsbCk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIC0tLS0tLS0tLS0gT3BlbiBtb2RhbCBmb3IgZWRpdCAtLS0tLS0tLS0tXHJcbiAgICBjb25zdCBvcGVuRWRpdCA9ICh1cGdyYWRlKSA9PiB7XHJcbiAgICAgICAgLy8gRXh0cmFjdCBjdXN0b21lciBJRCBmcm9tIGZyb21FbnJvbGxtZW50IG9yIHRvRW5yb2xsbWVudCAoYXNzdW1lIGZyb21FbnJvbGxtZW50IGhhcyB1c2VyX2lkKVxyXG4gICAgICAgIGNvbnN0IGN1c3RvbWVySWQgPSB1cGdyYWRlLmZyb21FbnJvbGxtZW50Py51c2VyX2lkPy5faWQgfHwgdXBncmFkZS5mcm9tRW5yb2xsbWVudD8udXNlcl9pZCB8fCBcIlwiO1xyXG4gICAgICAgIGlmIChjdXN0b21lcklkKSB7XHJcbiAgICAgICAgICAgIC8vIFNldCB0aGUgY3VzdG9tZXIgYW5kIGxvYWQgaXRzIGVucm9sbG1lbnRzXHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVXNlcklkKGN1c3RvbWVySWQpO1xyXG4gICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICB1c2VyX2lkOiBjdXN0b21lcklkLFxyXG4gICAgICAgICAgICAgICAgZnJvbUVucm9sbG1lbnQ6IHVwZ3JhZGUuZnJvbUVucm9sbG1lbnQ/Ll9pZCB8fCB1cGdyYWRlLmZyb21FbnJvbGxtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICB0b0Vucm9sbG1lbnQ6IHVwZ3JhZGUudG9FbnJvbGxtZW50Py5faWQgfHwgdXBncmFkZS50b0Vucm9sbG1lbnQgfHwgXCJcIixcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAvLyBGZXRjaCB0aGUgdHdvIGxpc3RzIGZvciB0aGlzIGN1c3RvbWVyXHJcbiAgICAgICAgICAgIFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgICAgIGFwaS5nZXQoYC92MS9hZG1pbi9lbnJvbGxzL2RlbGV0ZWQtZW5yb2xsbWVudHMvJHtjdXN0b21lcklkfWApLFxyXG4gICAgICAgICAgICAgICAgYXBpLmdldChgL3YxL2FkbWluL2Vucm9sbHMvYWxsLWVucm9sbG1lbnRzLyR7Y3VzdG9tZXJJZH1gKVxyXG4gICAgICAgICAgICBdKS50aGVuKChbZnJvbVJlcywgdG9SZXNdKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRGcm9tRW5yb2xsbWVudHMoZnJvbVJlcz8uZGF0YT8uZGF0YSB8fCBbXSk7XHJcbiAgICAgICAgICAgICAgICBzZXRUb0Vucm9sbG1lbnRzKHRvUmVzPy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgICAgICAgICAgfSkuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBlbnJvbGxtZW50cyBmb3IgZWRpdDpcIiwgZXJyKTtcclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHsgdmlzaWJpbGl0eTogdHJ1ZSwgbWVzc2FnZTogXCJGYWlsZWQgdG8gbG9hZCBlbnJvbGxtZW50c1wiLCB0eXBlOiBcImVycm9yXCIgfSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIEZhbGxiYWNrOiBpZiBubyBjdXN0b21lciwgc3RpbGwgc2V0IHRoZSBJRHMgYnV0IGN1c3RvbWVyIHdvbid0IGJlIHNlbGVjdGVkXHJcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgIGZyb21FbnJvbGxtZW50OiB1cGdyYWRlLmZyb21FbnJvbGxtZW50Py5faWQgfHwgdXBncmFkZS5mcm9tRW5yb2xsbWVudCB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgdG9FbnJvbGxtZW50OiB1cGdyYWRlLnRvRW5yb2xsbWVudD8uX2lkIHx8IHVwZ3JhZGUudG9FbnJvbGxtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0Q3VycmVudFVwZ3JhZGUodXBncmFkZS5faWQpO1xyXG4gICAgICAgIHNldElzVmVyaWZpZWQoZmFsc2UpO1xyXG4gICAgICAgIHNldERpZmZlcmVuY2VBbW91bnQobnVsbCk7XHJcbiAgICAgICAgc2V0TW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyAtLS0tLS0tLS0tIFZlcmlmeSBhbmQgU3VibWl0ICh0d28tc3RlcCkgLS0tLS0tLS0tLVxyXG4gICAgY29uc3QgaGFuZGxlVmVyaWZ5QW5kU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgICAgIGlmICghZm9ybURhdGEuZnJvbUVucm9sbG1lbnQgfHwgIWZvcm1EYXRhLnRvRW5yb2xsbWVudCkge1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGJvdGggRnJvbSBhbmQgVG8gZW5yb2xsbWVudHNcIixcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PSBTVEVQIDE6IFZFUklGWSA9PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICBpZiAoIWlzVmVyaWZpZWQpIHtcclxuICAgICAgICAgICAgc2V0SXNWZXJpZnlpbmcodHJ1ZSk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB2ZXJpZnlSZXMgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgICAgICAgICAgIFwiL3YxL2FkbWluL2NoaXQtYnVzaW5lc3MtdXBncmFkYXRpb24vdmVyaWZ5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZyb21FbnJvbGxJZDogZm9ybURhdGEuZnJvbUVucm9sbG1lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b0Vucm9sbElkOiBmb3JtRGF0YS50b0Vucm9sbG1lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoIXZlcmlmeVJlcy5kYXRhPy5kYXRhPy51cGdyYWRhdGlvbikge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJDaGl0IHVwZ3JhZGUgaXMgbm90IHBvc3NpYmxlIGZvciB0aGUgc2VsZWN0ZWQgZW5yb2xsbWVudHMuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRJc1ZlcmlmeWluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHNldERpZmZlcmVuY2VBbW91bnQodmVyaWZ5UmVzLmRhdGE/LmRhdGEpO1xyXG4gICAgICAgICAgICAgICAgc2V0SXNWZXJpZmllZCh0cnVlKTtcclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiVmVyaWZpY2F0aW9uIHN1Y2Nlc3NmdWwuIENsaWNrICdTdWJtaXQnIHRvIGNvbXBsZXRlIHRoZSB1cGdyYWRlLlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIlZlcmlmaWNhdGlvbiBlcnJvcjpcIiwgZXJyKTtcclxuICAgICAgICAgICAgICAgIGlmIChlcnIucmVzcG9uc2U/LmRhdGE/LmRhdGE/LnVwZ3JhZGF0aW9uID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJDaGl0IHVwZ3JhZGUgaXMgbm90IHBvc3NpYmxlIGZvciB0aGUgc2VsZWN0ZWQgZW5yb2xsbWVudHMuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJWZXJpZmljYXRpb24gZmFpbGVkLlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgICAgICBzZXRJc1ZlcmlmeWluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09IFNURVAgMjogQ09ORklSTSA9PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAvLyBGaW5kIHRoZSBzZWxlY3RlZCBlbnJvbGxtZW50cyBmcm9tIHRoZSBsb2FkZWQgbGlzdHNcclxuICAgICAgICBjb25zdCBmcm9tRW5yb2xsID0gZnJvbUVucm9sbG1lbnRzLmZpbmQoKGUpID0+IGUuX2lkID09PSBmb3JtRGF0YS5mcm9tRW5yb2xsbWVudCk7XHJcbiAgICAgICAgY29uc3QgdG9FbnJvbGwgPSB0b0Vucm9sbG1lbnRzLmZpbmQoKGUpID0+IGUuX2lkID09PSBmb3JtRGF0YS50b0Vucm9sbG1lbnQpO1xyXG5cclxuICAgICAgICBjb25zdCBjb25maXJtTWVzc2FnZSA9IGBEbyB5b3Ugd2FudCB0byB1cGdyYWRlIGZyb20gXCIke2Zyb21FbnJvbGw/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiXHJcbiAgICAgICAgICAgIH0gKCR7ZnJvbUVucm9sbD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIn0pXCIgdG8gXCIke3RvRW5yb2xsPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIlxyXG4gICAgICAgICAgICB9ICgke3RvRW5yb2xsPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwifSlcIj9gO1xyXG5cclxuICAgICAgICBjb25maXJtKHtcclxuICAgICAgICAgICAgdGl0bGU6IFwiQ29uZmlybSBDaGl0IFVwZ3JhZGVcIixcclxuICAgICAgICAgICAgY29udGVudDogY29uZmlybU1lc3NhZ2UsXHJcbiAgICAgICAgICAgIG9rVGV4dDogXCJZZXNcIixcclxuICAgICAgICAgICAgY2FuY2VsVGV4dDogXCJOb1wiLFxyXG4gICAgICAgICAgICBjZW50ZXJlZDogdHJ1ZSxcclxuICAgICAgICAgICAgb2tUeXBlOiBcInByaW1hcnlcIixcclxuICAgICAgICAgICAgb25PazogYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0SXNWZXJpZnlpbmcodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKSB8fCBcInt9XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZ3JhZGVkQnkgPSB1c2VyPy5faWQgfHwgdXNlcj8udXNlcklkIHx8IHVzZXI/LmlkIHx8IFwiXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdXBncmFkZWRCeSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJVc2VyIG5vdCBsb2dnZWQgaW4uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRJc1ZlcmlmeWluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyb21FbnJvbGxJZDogZm9ybURhdGEuZnJvbUVucm9sbG1lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvRW5yb2xsSWQ6IGZvcm1EYXRhLnRvRW5yb2xsbWVudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBncmFkZWRCeSxcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudFVwZ3JhZGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXBpLnB1dChgL2NoaXQtdXBncmFkZS91cGRhdGUtdXBncmFkZS8ke2N1cnJlbnRVcGdyYWRlfWAsIHBheWxvYWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJVcGdyYWRlIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5LlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3YxL2FkbWluL2NoaXQtYnVzaW5lc3MtdXBncmFkYXRpb25cIiwgcGF5bG9hZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlVwZ3JhZGUgY3JlYXRlZCBzdWNjZXNzZnVsbHkuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBzZXRNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJTdWJtaXNzaW9uIGVycm9yOlwiLCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZXJyLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHN1Ym1pdCB1cGdyYWRlLlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldElzVmVyaWZ5aW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gLS0tLS0tLS0tLSBEZWxldGUgLS0tLS0tLS0tLVxyXG4gICAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2NoaXQtdXBncmFkZS9kZWxldGUtdXBncmFkZS8ke2lkfWApO1xyXG4gICAgICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlVwZ3JhZGUgZGVsZXRlZFwiLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJEZWxldGUgZmFpbGVkXCIsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gLS0tLS0tLS0tLSBUYWJsZSBjb2x1bW5zIC0tLS0tLS0tLS1cclxuICAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMIE5vXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ1cGdyYWRlQ29kZVwiLCBoZWFkZXI6IFwiVXBncmFkZSBDb2RlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ1cGdyYWRlRGF0ZVwiLCBoZWFkZXI6IFwiVXBncmFkZSBEYXRlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJmcm9tRW5yb2xsbWVudFwiLCBoZWFkZXI6IFwiRnJvbSBFbnJvbGxtZW50XCIgfSxcclxuICAgICAgICB7IGtleTogXCJ0b0Vucm9sbG1lbnRcIiwgaGVhZGVyOiBcIlRvIEVucm9sbG1lbnRcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImVtcGxveWVlTmFtZVwiLCBoZWFkZXI6IFwiQWdlbnQgTmFtZSB8IE1vYmlsZVwiIH0sXHJcbiAgICAgICAgLy8geyBrZXk6IFwiZW1wbG95ZWVDb2RlXCIsIGhlYWRlcjogXCJBZ2VudCBNb2JpbGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQnVzaW5lc3MgQW1vdW50XCIgfSxcclxuICAgICAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxTaWRlYmFyIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkNoaXQgVXBncmFkZTwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBVcGdyYWRlIENoaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge3RhYmxlVXBncmFkZXMubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXsoaWQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGdyYWRlID0gdXBncmFkZXMuZmluZCgodSkgPT4gdS5faWQgPT09IGlkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXBncmFkZSkgb3BlbkVkaXQodXBncmFkZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17dGFibGVVcGdyYWRlc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDaGl0VXBncmFkZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkNoaXRVcGdyYWRlcy5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXshaXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT1cIkNoaXQgVXBncmFkZSBEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIE1vZGFsICovfVxyXG4gICAgICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXttb2RhbFZpc2libGV9IG9uQ2xvc2U9eygpID0+IHNldE1vZGFsVmlzaWJsZShmYWxzZSl9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRVcGdyYWRlID8gXCJVcGRhdGUgQ2hpdCBVcGdyYWRlXCIgOiBcIlVwZ3JhZGUgQ2hpdFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVWZXJpZnlBbmRTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIFNlbGVjdCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRVc2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YCR7dXNlci5mdWxsX25hbWV9IHwgJHt1c2VyLnBob25lX251bWJlcn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRnJvbSBFbnJvbGxtZW50IC0gdXNlcyBmcm9tRW5yb2xsbWVudHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZyb20gRW5yb2xsbWVudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBGcm9tIEVucm9sbG1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZnJvbUVucm9sbG1lbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJmcm9tRW5yb2xsbWVudFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3RlZFVzZXJJZH0gLy8gZW5hYmxlIG9ubHkgYWZ0ZXIgY3VzdG9tZXIgc2VsZWN0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZnJvbUVucm9sbG1lbnRzLm1hcCgoZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2UuX2lkfSB2YWx1ZT17ZS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake2UudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCJ9IHwgJHtlLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwifSB8ICR7ZS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwifSB8IFRpY2tldDogJHtlLnRpY2tldHN9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRvIEVucm9sbG1lbnQgLSB1c2VzIHRvRW5yb2xsbWVudHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvIEVucm9sbG1lbnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgVG8gRW5yb2xsbWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50b0Vucm9sbG1lbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJ0b0Vucm9sbG1lbnRcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRVc2VySWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RvRW5yb2xsbWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZSkgPT4gZS5faWQgIT09IGZvcm1EYXRhLmZyb21FbnJvbGxtZW50KSAvLyBleGNsdWRlIHRoZSBvbmUgc2VsZWN0ZWQgYXMgXCJGcm9tXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcCgoZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlLl9pZH0gdmFsdWU9e2UuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YCR7ZS51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIn0gfCAke2UudXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCJ9IHwgJHtlLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCJ9IHwgVGlja2V0OiAke2UudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCb3R0b20gU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBib3JkZXItdCBwdC01IG10LTYgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZlcmlmaWVkICYmIGRpZmZlcmVuY2VBbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTYgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIGJnLWJsdWUtNTAgcHgtNSBweS0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+VXBncmFkZSBTdGF0dXM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBtdC0xIHJvdW5kZWQtZnVsbCBiZy1ncmVlbi0xMDAgcHgtMyBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFwcHJvdmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+RGlmZmVyZW5jZSBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5IHtkaWZmZXJlbmNlQW1vdW50Py5kaWZmX2dyb3VwX3ZhbHVlPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVmVyaWZ5aW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1sLWF1dG8gYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHB4LTggcHktMi41IHJvdW5kZWQtbGcgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsICR7aXNWZXJpZnlpbmcgPyBcIm9wYWNpdHktNTAgY3Vyc29yLW5vdC1hbGxvd2VkXCIgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZlcmlmeWluZyA/IFwiUHJvY2Vzc2luZy4uLlwiIDogaXNWZXJpZmllZCA/IFwiU3VibWl0XCIgOiBcIlZlcmlmeVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENoaXRVcGdyYWRlOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DaGl0VXBncmFkZS5qc3gifQ==