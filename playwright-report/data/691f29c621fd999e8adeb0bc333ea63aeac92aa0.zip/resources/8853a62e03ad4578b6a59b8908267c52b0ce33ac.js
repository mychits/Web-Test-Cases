import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/QuickSearchContent.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { Table, Tooltip, Card, Input, Button, Tag, Avatar } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  UserOutlined,
  PhoneOutlined,
  CheckCircleOutlined,
  EyeOutlined,
  SearchOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Fuse from "/node_modules/.vite/deps/fuse__js.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
function useDebounce(value, delay) {
  _s();
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}
_s(useDebounce, "KDuPAtDOgxm8PU6legVJOb3oOmA=");
const FILTERS_CONFIG = [
  { id: "1", filterName: "ID", key: "customer_id" },
  { id: "2", filterName: "Name", key: "name" },
  { id: "3", filterName: "Phone", key: "phone_number" },
  { id: "4", filterName: "Aadhaar", key: "aadhaar_number" },
  { id: "5", filterName: "Pan", key: "pan_number" },
  { id: "7", filterName: "Status", key: "customer_status" }
];
const QuickSearchContent = ({ onSelect }) => {
  _s2();
  const navigate = useNavigate();
  const [tableUsers, setTableUsers] = useState([]);
  const [tableLeads, setTableLeads] = useState([]);
  const [tableAgents, setTableAgents] = useState([]);
  const [tableEmployees, setTableEmployees] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [activeFilters, setActiveFilters] = useState([]);
  const [selectedExactMatch, setSelectedExactMatch] = useState(null);
  const [apiLoaders, setApiLoaders] = useState({
    users: false,
    leads: false,
    agents: false,
    employees: false
  });
  const isAnyApiLoading = Object.values(apiLoaders).some(Boolean);
  const updateApiLoader = useCallback((key, loading) => {
    setApiLoaders((prev) => ({ ...prev, [key]: loading }));
  }, []);
  useEffect(() => {
    const fetchUsers = async () => {
      updateApiLoader("users", true);
      try {
        const response = await api.get("/user/get-user");
        const formatted = response.data.map((u, i) => ({
          _id: u._id,
          id: i + 1,
          name: u.full_name,
          phone_number: u.phone_number,
          address: u.address,
          pincode: u.pincode,
          customer_id: u.customer_id,
          collection_area: u.collection_area?.route_name,
          aadhaar_number: u.adhaar_no || "—",
          pan_number: u.pan_no || "—",
          isCustomer: true,
          approval_status: u.approval_status
        }));
        setTableUsers(formatted);
      } catch (error) {
        console.error("Error fetching users:", error);
      } finally {
        updateApiLoader("users", false);
      }
    };
    fetchUsers();
  }, [updateApiLoader]);
  useEffect(() => {
    const fetchLeads = async () => {
      updateApiLoader("leads", true);
      try {
        const response = await api.get("/lead/get-lead");
        const formatted = response.data.map((l, i) => ({
          _id: l._id,
          id: i + 1,
          name: l.lead_name || "—",
          phone_number: l.lead_phone || "—",
          address: l.lead_address || "—",
          pincode: l.pincode || "—",
          customer_id: l.leadCode,
          collection_area: l.group_id?.group_name || "—",
          customer_status: "Active",
          aadhaar_number: l.adhaar_no || l.lead_aadhaar || "—",
          pan_number: l.pan_no || l.lead_pan || "—",
          isLead: true
        }));
        setTableLeads(formatted);
      } catch (error) {
        console.error("Error fetching leads:", error);
      } finally {
        updateApiLoader("leads", false);
      }
    };
    fetchLeads();
  }, [updateApiLoader]);
  useEffect(() => {
    const fetchAgents = async () => {
      updateApiLoader("agents", true);
      try {
        const response = await api.get("/agent/get");
        const formatted = (response.data?.agent || []).map((a, i) => ({
          _id: a._id,
          id: i + 1,
          name: a.name || "—",
          phone_number: a.phone_number || "—",
          address: a.address || "—",
          pincode: a.pincode || "—",
          customer_id: a.employeeCode,
          collection_area: a.designation_id?.title || "—",
          customer_status: "Active",
          aadhaar_number: a.adhaar_no || "—",
          pan_number: a.pan_no || "—",
          isAgent: true
        }));
        setTableAgents(formatted);
      } catch (error) {
        console.error("Error fetching agents:", error);
      } finally {
        updateApiLoader("agents", false);
      }
    };
    fetchAgents();
  }, [updateApiLoader]);
  useEffect(() => {
    const fetchEmployees = async () => {
      updateApiLoader("employees", true);
      try {
        const response = await api.get("/agent/get-employee");
        const formatted = (response.data?.employee || []).map((e, i) => ({
          _id: e._id,
          id: i + 1,
          name: e.name || "—",
          phone_number: e.phone_number || "—",
          address: e.address || "—",
          pincode: e.pincode || "—",
          customer_id: e.employeeCode,
          collection_area: e.designation_id?.title || "—",
          customer_status: "Active",
          aadhaar_number: e.adhaar_no || "—",
          pan_number: e.pan_no || "—",
          isEmployee: true
        }));
        setTableEmployees(formatted);
      } catch (error) {
        console.error("Error fetching employees:", error);
      } finally {
        updateApiLoader("employees", false);
      }
    };
    fetchEmployees();
  }, [updateApiLoader]);
  const combinedData = useMemo(() => {
    const customerPhoneSet = new Set(tableUsers.map((u) => u.phone_number));
    const uniqueLeadsMap = /* @__PURE__ */ new Map();
    tableLeads.forEach((lead) => {
      if (customerPhoneSet.has(lead.phone_number)) return;
      if (!uniqueLeadsMap.has(lead.phone_number)) {
        uniqueLeadsMap.set(lead.phone_number, lead);
      }
    });
    return [
      ...tableUsers,
      ...Array.from(uniqueLeadsMap.values()),
      ...tableAgents,
      ...tableEmployees
    ];
  }, [tableUsers, tableLeads, tableAgents, tableEmployees]);
  const searchableKeys = useMemo(() => {
    if (activeFilters.length > 0) {
      return FILTERS_CONFIG.filter((f) => activeFilters.includes(f.id)).map((f) => f.key);
    }
    return FILTERS_CONFIG.map((f) => f.key);
  }, [activeFilters]);
  const debouncedSearchText = useDebounce(searchText, 300);
  const fuseInstance = useMemo(() => {
    if (combinedData.length === 0) return null;
    return new Fuse(combinedData, {
      includeScore: true,
      keys: searchableKeys,
      threshold: 0.3
    });
  }, [combinedData, searchableKeys]);
  const rawSearchResults = useMemo(() => {
    if (!debouncedSearchText.trim() || !fuseInstance) return [];
    return fuseInstance.search(debouncedSearchText);
  }, [debouncedSearchText, fuseInstance]);
  const getProcessedResults = useCallback(() => {
    if (!debouncedSearchText.trim()) {
      return { mode: "idle" };
    }
    if (rawSearchResults.length === 0) {
      return { mode: "search", hasResults: false };
    }
    let exactMatches = rawSearchResults.filter((r) => r.score <= 0.05).map((r) => r.item);
    let relatedMatches = rawSearchResults.filter((r) => r.score > 0.05).map((r) => r.item);
    if (selectedExactMatch) {
      if (!exactMatches.find((m) => m._id === selectedExactMatch._id)) {
        exactMatches = [selectedExactMatch];
      }
      relatedMatches = relatedMatches.filter((item) => item._id !== selectedExactMatch._id);
    }
    return { mode: "search", exactMatches, relatedMatches, hasResults: true };
  }, [debouncedSearchText, rawSearchResults, selectedExactMatch]);
  const getTypeInfo = (record) => {
    if (record.isLead) return { label: "Lead", color: "orange" };
    if (record.isAgent) return { label: "Agent", color: "purple" };
    if (record.isEmployee) return { label: "Employee", color: "cyan" };
    if (record.isCustomer) return { label: "Customer", color: "blue" };
    return { label: "Unknown", color: "default" };
  };
  const columns = useMemo(
    () => [
      {
        title: "SL. NO",
        key: "s_no",
        width: 80,
        align: "center",
        render: (_, __, index) => index + 1
      },
      {
        title: "Type",
        key: "type",
        width: 100,
        render: (_, record) => {
          const info = getTypeInfo(record);
          return /* @__PURE__ */ jsxDEV(Tag, { color: info.color, children: info.label }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 257,
            columnNumber: 16
          }, this);
        }
      },
      { dataIndex: "customer_id", title: "ID", key: "customer_id", width: 120 },
      { dataIndex: "name", title: "Name", key: "name", width: 180 },
      { dataIndex: "phone_number", title: "Phone", key: "phone_number", width: 140 },
      {
        dataIndex: "aadhaar_number",
        title: "Aadhaar",
        key: "aadhaar_number",
        width: 150,
        render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-sm", children: text }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
          lineNumber: 268,
          columnNumber: 25
        }, this)
      },
      {
        dataIndex: "pan_number",
        title: "Pan",
        key: "pan_number",
        width: 140,
        render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-sm uppercase", children: text }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
          lineNumber: 275,
          columnNumber: 25
        }, this)
      },
      {
        key: "action",
        width: 100,
        render: (_, record) => {
          const handleAction = () => {
            if (onSelect) {
              onSelect(record);
            } else {
              let route = "#";
              if (record.isLead) route = `/reports/lead-report?lead_id=${record._id}`;
              else if (record.isAgent) route = `/staff-menu/agent?agent_id=${record._id}`;
              else if (record.isEmployee) route = `/staff-menu/employee-menu/employee?employee_id=${record._id}`;
              else
                route = `/customer-view?user_id=${record._id}`;
              navigate(route);
            }
          };
          return /* @__PURE__ */ jsxDEV(Tooltip, { title: onSelect ? "Select Customer" : "View Profile", children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: handleAction,
              icon: onSelect ? /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
                lineNumber: 297,
                columnNumber: 32
              }, this) : /* @__PURE__ */ jsxDEV(EyeOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
                lineNumber: 297,
                columnNumber: 58
              }, this),
              size: "small",
              className: `flex items-center justify-center gap-1 border-gray-300 text-gray-700 hover:bg-violet-600 hover:text-white hover:shadow transition ${onSelect ? "bg-green-50 border-green-300 text-green-700 hover:bg-green-600" : ""}`,
              children: onSelect ? "Select" : "View"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
              lineNumber: 295,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 294,
            columnNumber: 11
          }, this);
        }
      }
    ],
    [navigate, onSelect]
  );
  const handleFilterToggle = (id) => {
    setActiveFilters((prev) => prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]);
  };
  useEffect(() => {
    setSelectedExactMatch(null);
  }, [searchText]);
  const searchState = getProcessedResults();
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "mb-4 shadow-sm border border-gray-200 rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5", children: [
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          prefix: /* @__PURE__ */ jsxDEV(SearchOutlined, { className: "text-gray-400" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 330,
            columnNumber: 21
          }, this),
          placeholder: "Search by ID, Name, Phone, Aadhaar, or Pan...",
          value: searchText,
          onChange: (e) => setSearchText(e.target.value),
          className: "w-full lg:w-1/3",
          allowClear: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
          lineNumber: 329,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: FILTERS_CONFIG.map((filter) => {
        const isActive = activeFilters.includes(filter.id);
        return /* @__PURE__ */ jsxDEV(Tooltip, { title: `Search by ${filter.filterName}`, children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleFilterToggle(filter.id),
            className: `px-4 py-1.5 text-sm font-medium rounded-lg transition-all ${isActive ? "bg-violet-600 text-white shadow" : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"}`,
            children: filter.filterName
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 342,
            columnNumber: 19
          },
          this
        ) }, filter.id, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
          lineNumber: 341,
          columnNumber: 17
        }, this);
      }) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
        lineNumber: 337,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
      lineNumber: 328,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
      lineNumber: 327,
      columnNumber: 7
    }, this),
    isAnyApiLoading && /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Records" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
      lineNumber: 360,
      columnNumber: 27
    }, this),
    !isAnyApiLoading && searchText.trim().length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      searchState.mode === "search" && !searchState.hasResults && /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No matches found." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
        lineNumber: 367,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
        lineNumber: 366,
        columnNumber: 9
      }, this),
      searchState.mode === "search" && searchState.hasResults && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        searchState.exactMatches.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 p-5 rounded-xl shadow-md border-l-8 border-violet-500 bg-white", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
          /* @__PURE__ */ jsxDEV(Avatar, { size: 48, icon: /* @__PURE__ */ jsxDEV(UserOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 377,
            columnNumber: 45
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 377,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV(Tag, { color: "violet", children: "Exact Match" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
              lineNumber: 379,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold", children: searchState.exactMatches[0].name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
              lineNumber: 380,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 flex items-center gap-2 mt-1", children: [
              /* @__PURE__ */ jsxDEV(PhoneOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
                lineNumber: 382,
                columnNumber: 25
              }, this),
              " ",
              searchState.exactMatches[0].phone_number
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
              lineNumber: 381,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 mt-2 text-sm", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Aadhaar: ",
                searchState.exactMatches[0].aadhaar_number
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
                lineNumber: 385,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Pan: ",
                searchState.exactMatches[0].pan_number
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
                lineNumber: 386,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
              lineNumber: 384,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "small",
                className: "mt-3 bg-violet-600 border-none",
                onClick: () => {
                  if (onSelect) {
                    onSelect(searchState.exactMatches[0]);
                  } else {
                    const record = searchState.exactMatches[0];
                    let route = "#";
                    if (record.isLead) route = `/reports/lead-report?lead_id=${record._id}`;
                    else if (record.isAgent) route = `/staff-menu/agent?agent_id=${record._id}`;
                    else if (record.isEmployee) route = `/staff-menu/employee-menu/employee?employee_id=${record._id}`;
                    else
                      route = `/customer-view?user_id=${record._id}`;
                    navigate(route);
                  }
                },
                children: onSelect ? "Select this Customer" : "View Profile"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
                lineNumber: 388,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 378,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
          lineNumber: 376,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
          lineNumber: 375,
          columnNumber: 11
        }, this),
        searchState.relatedMatches.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-gray-600 font-semibold mb-3", children: "Other Results" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
            lineNumber: 416,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Table,
            {
              columns,
              dataSource: searchState.relatedMatches,
              rowKey: "_id",
              pagination: { pageSize: 5, hideOnSinglePage: true },
              scroll: { x: "max-content" },
              size: "middle",
              onRow: (record) => ({
                onClick: () => setSelectedExactMatch(record)
              }),
              rowClassName: () => "cursor-pointer hover:bg-gray-50"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
              lineNumber: 417,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
          lineNumber: 415,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
        lineNumber: 372,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
      lineNumber: 364,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx",
    lineNumber: 325,
    columnNumber: 5
  }, this);
};
_s2(QuickSearchContent, "eLmM9OQyUpB7u0Y9VEh6xDqPs/s=", false, function() {
  return [useNavigate, useDebounce];
});
_c = QuickSearchContent;
export default QuickSearchContent;
var _c;
$RefreshReg$(_c, "QuickSearchContent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/QuickSearchContent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1FpQixTQW1ITCxVQW5ISzs7QUFoUWpCLG9CQUFvQkEsNkJBQW1CQyxlQUFtQixnQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNqRSxTQUFTQyxPQUFPQyxTQUFTQyxNQUFNQyxPQUFPQyxRQUFRQyxLQUFLQyxjQUFjO0FBQ2pFO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0Msb0JBQW9CO0FBRzNCLFNBQVNDLFlBQVlDLE9BQU9DLE9BQU87QUFBQUMsS0FBQTtBQUNqQyxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUl2QixTQUFTbUIsS0FBSztBQUMxREssWUFBVSxNQUFNO0FBQ2QsVUFBTUMsVUFBVUMsV0FBVyxNQUFNSCxrQkFBa0JKLEtBQUssR0FBR0MsS0FBSztBQUNoRSxXQUFPLE1BQU1PLGFBQWFGLE9BQU87QUFBQSxFQUNuQyxHQUFHLENBQUNOLE9BQU9DLEtBQUssQ0FBQztBQUNqQixTQUFPRTtBQUNUO0FBQUNELEdBUFFILGFBQVc7QUFTcEIsTUFBTVUsaUJBQWlCO0FBQUEsRUFDckIsRUFBRUMsSUFBSSxLQUFLQyxZQUFZLE1BQU1DLEtBQUssY0FBYztBQUFBLEVBQ2hELEVBQUVGLElBQUksS0FBS0MsWUFBWSxRQUFRQyxLQUFLLE9BQU87QUFBQSxFQUMzQyxFQUFFRixJQUFJLEtBQUtDLFlBQVksU0FBU0MsS0FBSyxlQUFlO0FBQUEsRUFDcEQsRUFBRUYsSUFBSSxLQUFLQyxZQUFZLFdBQVdDLEtBQUssaUJBQWlCO0FBQUEsRUFDeEQsRUFBRUYsSUFBSSxLQUFLQyxZQUFZLE9BQU9DLEtBQUssYUFBYTtBQUFBLEVBQ2hELEVBQUVGLElBQUksS0FBS0MsWUFBWSxVQUFVQyxLQUFLLGtCQUFrQjtBQUFDO0FBRzNELE1BQU1DLHFCQUFxQkEsQ0FBQyxFQUFFQyxTQUFTLE1BQU07QUFBQUMsTUFBQTtBQUMzQyxRQUFNQyxXQUFXckIsWUFBWTtBQUU3QixRQUFNLENBQUNzQixZQUFZQyxhQUFhLElBQUlyQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDc0MsWUFBWUMsYUFBYSxJQUFJdkMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3dDLGFBQWFDLGNBQWMsSUFBSXpDLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUMwQyxnQkFBZ0JDLGlCQUFpQixJQUFJM0MsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzRDLFlBQVlDLGFBQWEsSUFBSTdDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM4QyxlQUFlQyxnQkFBZ0IsSUFBSS9DLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNnRCxvQkFBb0JDLHFCQUFxQixJQUFJakQsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ2tELFlBQVlDLGFBQWEsSUFBSW5ELFNBQVM7QUFBQSxJQUMzQ29ELE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsSUFDUEMsUUFBUTtBQUFBLElBQ1JDLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNQyxrQkFBa0JDLE9BQU9DLE9BQU9SLFVBQVUsRUFBRVMsS0FBS0MsT0FBTztBQUc5RCxRQUFNQyxrQkFBa0I1RCxZQUFZLENBQUM4QixLQUFLK0IsWUFBWTtBQUNwRFgsa0JBQWMsQ0FBQ1ksVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ2hDLEdBQUcsR0FBRytCLFFBQVEsRUFBRTtBQUFBLEVBQ3ZELEdBQUcsRUFBRTtBQUVMdEMsWUFBVSxNQUFNO0FBQ2QsVUFBTXdDLGFBQWEsWUFBWTtBQUM3Qkgsc0JBQWdCLFNBQVMsSUFBSTtBQUM3QixVQUFJO0FBQ0YsY0FBTUksV0FBVyxNQUFNakQsSUFBSWtELElBQUksZ0JBQWdCO0FBQy9DLGNBQU1DLFlBQVlGLFNBQVNHLEtBQUtDLElBQUksQ0FBQ0MsR0FBR0MsT0FBTztBQUFBLFVBQzdDQyxLQUFLRixFQUFFRTtBQUFBQSxVQUNQM0MsSUFBSTBDLElBQUk7QUFBQSxVQUNSRSxNQUFNSCxFQUFFSTtBQUFBQSxVQUNSQyxjQUFjTCxFQUFFSztBQUFBQSxVQUNoQkMsU0FBU04sRUFBRU07QUFBQUEsVUFDWEMsU0FBU1AsRUFBRU87QUFBQUEsVUFDWEMsYUFBYVIsRUFBRVE7QUFBQUEsVUFDZkMsaUJBQWlCVCxFQUFFUyxpQkFBaUJDO0FBQUFBLFVBQ3BDQyxnQkFBZ0JYLEVBQUVZLGFBQWE7QUFBQSxVQUMvQkMsWUFBWWIsRUFBRWMsVUFBVTtBQUFBLFVBQ3hCQyxZQUFZO0FBQUEsVUFDWkMsaUJBQWlCaEIsRUFBRWdCO0FBQUFBLFFBQ3JCLEVBQUU7QUFDRmpELHNCQUFjOEIsU0FBUztBQUFBLE1BQ3pCLFNBQVNvQixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDLFVBQUM7QUFDQzFCLHdCQUFnQixTQUFTLEtBQUs7QUFBQSxNQUNoQztBQUFBLElBQ0Y7QUFDQUcsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDSCxlQUFlLENBQUM7QUFFcEJyQyxZQUFVLE1BQU07QUFDZCxVQUFNaUUsYUFBYSxZQUFZO0FBQzdCNUIsc0JBQWdCLFNBQVMsSUFBSTtBQUM3QixVQUFJO0FBQ0YsY0FBTUksV0FBVyxNQUFNakQsSUFBSWtELElBQUksZ0JBQWdCO0FBQy9DLGNBQU1DLFlBQVlGLFNBQVNHLEtBQUtDLElBQUksQ0FBQ3FCLEdBQUduQixPQUFPO0FBQUEsVUFDN0NDLEtBQUtrQixFQUFFbEI7QUFBQUEsVUFDUDNDLElBQUkwQyxJQUFJO0FBQUEsVUFDUkUsTUFBTWlCLEVBQUVDLGFBQWE7QUFBQSxVQUNyQmhCLGNBQWNlLEVBQUVFLGNBQWM7QUFBQSxVQUM5QmhCLFNBQVNjLEVBQUVHLGdCQUFnQjtBQUFBLFVBQzNCaEIsU0FBU2EsRUFBRWIsV0FBVztBQUFBLFVBQ3RCQyxhQUFhWSxFQUFFSTtBQUFBQSxVQUNmZixpQkFBaUJXLEVBQUVLLFVBQVVDLGNBQWM7QUFBQSxVQUMzQ0MsaUJBQWlCO0FBQUEsVUFDakJoQixnQkFBZ0JTLEVBQUVSLGFBQWFRLEVBQUVRLGdCQUFnQjtBQUFBLFVBQ2pEZixZQUFZTyxFQUFFTixVQUFVTSxFQUFFUyxZQUFZO0FBQUEsVUFDdENDLFFBQVE7QUFBQSxRQUNWLEVBQUU7QUFDRjdELHNCQUFjNEIsU0FBUztBQUFBLE1BQ3pCLFNBQVNvQixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDLFVBQUM7QUFDQzFCLHdCQUFnQixTQUFTLEtBQUs7QUFBQSxNQUNoQztBQUFBLElBQ0Y7QUFDQTRCLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQzVCLGVBQWUsQ0FBQztBQUVwQnJDLFlBQVUsTUFBTTtBQUNkLFVBQU02RSxjQUFjLFlBQVk7QUFDOUJ4QyxzQkFBZ0IsVUFBVSxJQUFJO0FBQzlCLFVBQUk7QUFDRixjQUFNSSxXQUFXLE1BQU1qRCxJQUFJa0QsSUFBSSxZQUFZO0FBQzNDLGNBQU1DLGFBQWFGLFNBQVNHLE1BQU1rQyxTQUFTLElBQUlqQyxJQUFJLENBQUNrQyxHQUFHaEMsT0FBTztBQUFBLFVBQzVEQyxLQUFLK0IsRUFBRS9CO0FBQUFBLFVBQ1AzQyxJQUFJMEMsSUFBSTtBQUFBLFVBQ1JFLE1BQU04QixFQUFFOUIsUUFBUTtBQUFBLFVBQ2hCRSxjQUFjNEIsRUFBRTVCLGdCQUFnQjtBQUFBLFVBQ2hDQyxTQUFTMkIsRUFBRTNCLFdBQVc7QUFBQSxVQUN0QkMsU0FBUzBCLEVBQUUxQixXQUFXO0FBQUEsVUFDdEJDLGFBQWF5QixFQUFFQztBQUFBQSxVQUNmekIsaUJBQWlCd0IsRUFBRUUsZ0JBQWdCQyxTQUFTO0FBQUEsVUFDNUNULGlCQUFpQjtBQUFBLFVBQ2pCaEIsZ0JBQWdCc0IsRUFBRXJCLGFBQWE7QUFBQSxVQUMvQkMsWUFBWW9CLEVBQUVuQixVQUFVO0FBQUEsVUFDeEJ1QixTQUFTO0FBQUEsUUFDWCxFQUFFO0FBQ0ZsRSx1QkFBZTBCLFNBQVM7QUFBQSxNQUMxQixTQUFTb0IsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxNQUMvQyxVQUFDO0FBQ0MxQix3QkFBZ0IsVUFBVSxLQUFLO0FBQUEsTUFDakM7QUFBQSxJQUNGO0FBQ0F3QyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDeEMsZUFBZSxDQUFDO0FBRXBCckMsWUFBVSxNQUFNO0FBQ2QsVUFBTW9GLGlCQUFpQixZQUFZO0FBQ2pDL0Msc0JBQWdCLGFBQWEsSUFBSTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUksV0FBVyxNQUFNakQsSUFBSWtELElBQUkscUJBQXFCO0FBQ3BELGNBQU1DLGFBQWFGLFNBQVNHLE1BQU15QyxZQUFZLElBQUl4QyxJQUFJLENBQUN5QyxHQUFHdkMsT0FBTztBQUFBLFVBQy9EQyxLQUFLc0MsRUFBRXRDO0FBQUFBLFVBQ1AzQyxJQUFJMEMsSUFBSTtBQUFBLFVBQ1JFLE1BQU1xQyxFQUFFckMsUUFBUTtBQUFBLFVBQ2hCRSxjQUFjbUMsRUFBRW5DLGdCQUFnQjtBQUFBLFVBQ2hDQyxTQUFTa0MsRUFBRWxDLFdBQVc7QUFBQSxVQUN0QkMsU0FBU2lDLEVBQUVqQyxXQUFXO0FBQUEsVUFDdEJDLGFBQWFnQyxFQUFFTjtBQUFBQSxVQUNmekIsaUJBQWlCK0IsRUFBRUwsZ0JBQWdCQyxTQUFTO0FBQUEsVUFDNUNULGlCQUFpQjtBQUFBLFVBQ2pCaEIsZ0JBQWdCNkIsRUFBRTVCLGFBQWE7QUFBQSxVQUMvQkMsWUFBWTJCLEVBQUUxQixVQUFVO0FBQUEsVUFDeEIyQixZQUFZO0FBQUEsUUFDZCxFQUFFO0FBQ0ZwRSwwQkFBa0J3QixTQUFTO0FBQUEsTUFDN0IsU0FBU29CLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQsVUFBQztBQUNDMUIsd0JBQWdCLGFBQWEsS0FBSztBQUFBLE1BQ3BDO0FBQUEsSUFDRjtBQUNBK0MsbUJBQWU7QUFBQSxFQUNqQixHQUFHLENBQUMvQyxlQUFlLENBQUM7QUFHcEIsUUFBTW1ELGVBQWVDLFFBQVEsTUFBTTtBQUNqQyxVQUFNQyxtQkFBbUIsSUFBSUMsSUFBSS9FLFdBQVdpQyxJQUFJLENBQUNDLE1BQU1BLEVBQUVLLFlBQVksQ0FBQztBQUN0RSxVQUFNeUMsaUJBQWlCLG9CQUFJQyxJQUFJO0FBQy9CL0UsZUFBV2dGLFFBQVEsQ0FBQ0MsU0FBUztBQUMzQixVQUFJTCxpQkFBaUJNLElBQUlELEtBQUs1QyxZQUFZLEVBQUc7QUFDN0MsVUFBSSxDQUFDeUMsZUFBZUksSUFBSUQsS0FBSzVDLFlBQVksR0FBRztBQUMxQ3lDLHVCQUFlSyxJQUFJRixLQUFLNUMsY0FBYzRDLElBQUk7QUFBQSxNQUM1QztBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU87QUFBQSxNQUNMLEdBQUduRjtBQUFBQSxNQUNILEdBQUdzRixNQUFNQyxLQUFLUCxlQUFlMUQsT0FBTyxDQUFDO0FBQUEsTUFDckMsR0FBR2xCO0FBQUFBLE1BQ0gsR0FBR0U7QUFBQUEsSUFBYztBQUFBLEVBRXJCLEdBQUcsQ0FBQ04sWUFBWUUsWUFBWUUsYUFBYUUsY0FBYyxDQUFDO0FBRXhELFFBQU1rRixpQkFBaUJYLFFBQVEsTUFBTTtBQUNuQyxRQUFJbkUsY0FBYytFLFNBQVMsR0FBRztBQUM1QixhQUFPakcsZUFBZWtHLE9BQU8sQ0FBQ0MsTUFBTWpGLGNBQWNrRixTQUFTRCxFQUFFbEcsRUFBRSxDQUFDLEVBQUV3QyxJQUFJLENBQUMwRCxNQUFNQSxFQUFFaEcsR0FBRztBQUFBLElBQ3BGO0FBQ0EsV0FBT0gsZUFBZXlDLElBQUksQ0FBQzBELE1BQU1BLEVBQUVoRyxHQUFHO0FBQUEsRUFDeEMsR0FBRyxDQUFDZSxhQUFhLENBQUM7QUFFbEIsUUFBTW1GLHNCQUFzQi9HLFlBQVkwQixZQUFZLEdBQUc7QUFFdkQsUUFBTXNGLGVBQWVqQixRQUFRLE1BQU07QUFDakMsUUFBSUQsYUFBYWEsV0FBVyxFQUFHLFFBQU87QUFDdEMsV0FBTyxJQUFJOUcsS0FBS2lHLGNBQWM7QUFBQSxNQUM1Qm1CLGNBQWM7QUFBQSxNQUNkQyxNQUFNUjtBQUFBQSxNQUNOUyxXQUFXO0FBQUEsSUFDYixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNyQixjQUFjWSxjQUFjLENBQUM7QUFFakMsUUFBTVUsbUJBQW1CckIsUUFBUSxNQUFNO0FBQ3JDLFFBQUksQ0FBQ2dCLG9CQUFvQk0sS0FBSyxLQUFLLENBQUNMLGFBQWMsUUFBTztBQUN6RCxXQUFPQSxhQUFhTSxPQUFPUCxtQkFBbUI7QUFBQSxFQUNoRCxHQUFHLENBQUNBLHFCQUFxQkMsWUFBWSxDQUFDO0FBRXRDLFFBQU1PLHNCQUFzQnhJLFlBQVksTUFBTTtBQUM1QyxRQUFJLENBQUNnSSxvQkFBb0JNLEtBQUssR0FBRztBQUMvQixhQUFPLEVBQUVHLE1BQU0sT0FBTztBQUFBLElBQ3hCO0FBQ0EsUUFBSUosaUJBQWlCVCxXQUFXLEdBQUc7QUFDakMsYUFBTyxFQUFFYSxNQUFNLFVBQVVDLFlBQVksTUFBTTtBQUFBLElBQzdDO0FBQ0EsUUFBSUMsZUFBZU4saUJBQWlCUixPQUFPLENBQUNlLE1BQU1BLEVBQUVDLFNBQVMsSUFBSSxFQUFFekUsSUFBSSxDQUFDd0UsTUFBTUEsRUFBRUUsSUFBSTtBQUNwRixRQUFJQyxpQkFBaUJWLGlCQUFpQlIsT0FBTyxDQUFDZSxNQUFNQSxFQUFFQyxRQUFRLElBQUksRUFBRXpFLElBQUksQ0FBQ3dFLE1BQU1BLEVBQUVFLElBQUk7QUFFckYsUUFBSS9GLG9CQUFvQjtBQUN0QixVQUFJLENBQUM0RixhQUFhSyxLQUFLLENBQUNDLE1BQU1BLEVBQUUxRSxRQUFReEIsbUJBQW1Cd0IsR0FBRyxHQUFHO0FBQy9Eb0UsdUJBQWUsQ0FBQzVGLGtCQUFrQjtBQUFBLE1BQ3BDO0FBQ0FnRyx1QkFBaUJBLGVBQWVsQixPQUFPLENBQUNpQixTQUFTQSxLQUFLdkUsUUFBUXhCLG1CQUFtQndCLEdBQUc7QUFBQSxJQUN0RjtBQUNBLFdBQU8sRUFBRWtFLE1BQU0sVUFBVUUsY0FBY0ksZ0JBQWdCTCxZQUFZLEtBQUs7QUFBQSxFQUMxRSxHQUFHLENBQUNWLHFCQUFxQkssa0JBQWtCdEYsa0JBQWtCLENBQUM7QUFFOUQsUUFBTW1HLGNBQWNBLENBQUNDLFdBQVc7QUFDOUIsUUFBSUEsT0FBT2hELE9BQVEsUUFBTyxFQUFFaUQsT0FBTyxRQUFRQyxPQUFPLFNBQVM7QUFDM0QsUUFBSUYsT0FBT3pDLFFBQVMsUUFBTyxFQUFFMEMsT0FBTyxTQUFTQyxPQUFPLFNBQVM7QUFDN0QsUUFBSUYsT0FBT3JDLFdBQVksUUFBTyxFQUFFc0MsT0FBTyxZQUFZQyxPQUFPLE9BQU87QUFDakUsUUFBSUYsT0FBTy9ELFdBQVksUUFBTyxFQUFFZ0UsT0FBTyxZQUFZQyxPQUFPLE9BQU87QUFDakUsV0FBTyxFQUFFRCxPQUFPLFdBQVdDLE9BQU8sVUFBVTtBQUFBLEVBQzlDO0FBRUEsUUFBTUMsVUFBVXRDO0FBQUFBLElBQ2QsTUFBTTtBQUFBLE1BQ0o7QUFBQSxRQUNFUCxPQUFPO0FBQUEsUUFDUDNFLEtBQUs7QUFBQSxRQUNMeUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxRQUFRQSxDQUFDQyxHQUFHQyxJQUFJQyxVQUFVQSxRQUFRO0FBQUEsTUFDcEM7QUFBQSxNQUNBO0FBQUEsUUFDRW5ELE9BQU87QUFBQSxRQUNQM0UsS0FBSztBQUFBLFFBQ0x5SCxPQUFPO0FBQUEsUUFDUEUsUUFBUUEsQ0FBQ0MsR0FBR1AsV0FBVztBQUNyQixnQkFBTVUsT0FBT1gsWUFBWUMsTUFBTTtBQUMvQixpQkFBTyx1QkFBQyxPQUFJLE9BQU9VLEtBQUtSLE9BQVFRLGVBQUtULFNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DO0FBQUEsUUFDN0M7QUFBQSxNQUNGO0FBQUEsTUFDQSxFQUFFVSxXQUFXLGVBQWVyRCxPQUFPLE1BQU0zRSxLQUFLLGVBQWV5SCxPQUFPLElBQUk7QUFBQSxNQUN4RSxFQUFFTyxXQUFXLFFBQVFyRCxPQUFPLFFBQVEzRSxLQUFLLFFBQVF5SCxPQUFPLElBQUk7QUFBQSxNQUM1RCxFQUFFTyxXQUFXLGdCQUFnQnJELE9BQU8sU0FBUzNFLEtBQUssZ0JBQWdCeUgsT0FBTyxJQUFJO0FBQUEsTUFDN0U7QUFBQSxRQUNFTyxXQUFXO0FBQUEsUUFDWHJELE9BQU87QUFBQSxRQUNQM0UsS0FBSztBQUFBLFFBQ0x5SCxPQUFPO0FBQUEsUUFDUEUsUUFBUUEsQ0FBQ00sU0FBUyx1QkFBQyxVQUFLLFdBQVUscUJBQXFCQSxrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLE1BQzlEO0FBQUEsTUFDQTtBQUFBLFFBQ0VELFdBQVc7QUFBQSxRQUNYckQsT0FBTztBQUFBLFFBQ1AzRSxLQUFLO0FBQUEsUUFDTHlILE9BQU87QUFBQSxRQUNQRSxRQUFRQSxDQUFDTSxTQUFTLHVCQUFDLFVBQUssV0FBVSwrQkFBK0JBLGtCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsTUFDeEU7QUFBQSxNQUNBO0FBQUEsUUFDRWpJLEtBQUs7QUFBQSxRQUNMeUgsT0FBTztBQUFBLFFBQ1BFLFFBQVFBLENBQUNDLEdBQUdQLFdBQVc7QUFDckIsZ0JBQU1hLGVBQWVBLE1BQU07QUFDekIsZ0JBQUloSSxVQUFVO0FBQ1pBLHVCQUFTbUgsTUFBTTtBQUFBLFlBQ2pCLE9BQU87QUFDTCxrQkFBSWMsUUFBUTtBQUNaLGtCQUFJZCxPQUFPaEQsT0FBUThELFNBQVEsZ0NBQWdDZCxPQUFPNUUsR0FBRztBQUFBLHVCQUM1RDRFLE9BQU96QyxRQUFTdUQsU0FBUSw4QkFBOEJkLE9BQU81RSxHQUFHO0FBQUEsdUJBQ2hFNEUsT0FBT3JDLFdBQVltRCxTQUFRLGtEQUFrRGQsT0FBTzVFLEdBQUc7QUFBQTtBQUMzRjBGLHdCQUFRLDBCQUEwQmQsT0FBTzVFLEdBQUc7QUFDakRyQyx1QkFBUytILEtBQUs7QUFBQSxZQUNoQjtBQUFBLFVBQ0Y7QUFDQSxpQkFDRSx1QkFBQyxXQUFRLE9BQU9qSSxXQUFXLG9CQUFvQixnQkFDN0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNnSTtBQUFBQSxjQUNULE1BQU1oSSxXQUFXLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9CLElBQU0sdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWTtBQUFBLGNBQ3ZELE1BQUs7QUFBQSxjQUNMLFdBQVcscUlBQ1RBLFdBQVcsbUVBQW1FLEVBQUU7QUFBQSxjQUdqRkEscUJBQVcsV0FBVztBQUFBO0FBQUEsWUFSekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsUUFFSjtBQUFBLE1BQ0Y7QUFBQSxJQUFDO0FBQUEsSUFFSCxDQUFDRSxVQUFVRixRQUFRO0FBQUEsRUFDckI7QUFFQSxRQUFNa0kscUJBQXFCQSxDQUFDdEksT0FBTztBQUNqQ2tCLHFCQUFpQixDQUFDZ0IsU0FBVUEsS0FBS2lFLFNBQVNuRyxFQUFFLElBQUlrQyxLQUFLK0QsT0FBTyxDQUFDQyxNQUFNQSxNQUFNbEcsRUFBRSxJQUFJLENBQUMsR0FBR2tDLE1BQU1sQyxFQUFFLENBQUU7QUFBQSxFQUMvRjtBQUdBTCxZQUFVLE1BQU07QUFDZHlCLDBCQUFzQixJQUFJO0FBQUEsRUFDNUIsR0FBRyxDQUFDTCxVQUFVLENBQUM7QUFFZixRQUFNd0gsY0FBYzNCLG9CQUFvQjtBQUV4QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsMkJBQUMsUUFBSyxXQUFVLG9EQUNkLGlDQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxRQUFRLHVCQUFDLGtCQUFlLFdBQVUsbUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsVUFDakQsYUFBWTtBQUFBLFVBQ1osT0FBTzdGO0FBQUFBLFVBQ1AsVUFBVSxDQUFDa0UsTUFBTWpFLGNBQWNpRSxFQUFFdUQsT0FBT2xKLEtBQUs7QUFBQSxVQUM3QyxXQUFVO0FBQUEsVUFDVixZQUFVO0FBQUE7QUFBQSxRQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1ZO0FBQUEsTUFFWix1QkFBQyxTQUFJLFdBQVUsd0JBQ1pTLHlCQUFleUMsSUFBSSxDQUFDeUQsV0FBVztBQUM5QixjQUFNd0MsV0FBV3hILGNBQWNrRixTQUFTRixPQUFPakcsRUFBRTtBQUNqRCxlQUNFLHVCQUFDLFdBQXdCLE9BQU8sYUFBYWlHLE9BQU9oRyxVQUFVLElBQzVEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1xSSxtQkFBbUJyQyxPQUFPakcsRUFBRTtBQUFBLFlBQzNDLFdBQVcsNkRBQ1R5SSxXQUNJLG9DQUNBLG9FQUFvRTtBQUFBLFlBR3pFeEMsaUJBQU9oRztBQUFBQTtBQUFBQSxVQVJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBLEtBVllnRyxPQUFPakcsSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsTUFFSixDQUFDLEtBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxJQUdDMkIsbUJBQW1CLHVCQUFDLGtCQUFlLFdBQVcsTUFBTSxNQUFLLGFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0M7QUFBQSxJQUdsRSxDQUFDQSxtQkFBbUJaLFdBQVcyRixLQUFLLEVBQUVWLFNBQVMsS0FDOUMsbUNBQ0d1QztBQUFBQSxrQkFBWTFCLFNBQVMsWUFBWSxDQUFDMEIsWUFBWXpCLGNBQzdDLHVCQUFDLFNBQUksV0FBVSxxQkFDYixpQ0FBQyxPQUFFLFdBQVUsaUJBQWdCLGlDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0R5QixZQUFZMUIsU0FBUyxZQUFZMEIsWUFBWXpCLGNBQzVDLG1DQUVHeUI7QUFBQUEsb0JBQVl4QixhQUFhZixTQUFTLEtBQ2pDLHVCQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxVQUFPLE1BQU0sSUFBSSxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWEsS0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUN6Qyx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBSSxPQUFNLFVBQVMsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUEsWUFDL0IsdUJBQUMsUUFBRyxXQUFVLHFCQUFxQnVDLHNCQUFZeEIsYUFBYSxDQUFDLEVBQUVuRSxRQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLE9BQUUsV0FBVSw4Q0FDWDtBQUFBLHFDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWM7QUFBQSxjQUFHO0FBQUEsY0FBRTJGLFlBQVl4QixhQUFhLENBQUMsRUFBRWpFO0FBQUFBLGlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxVQUFLO0FBQUE7QUFBQSxnQkFBVXlGLFlBQVl4QixhQUFhLENBQUMsRUFBRTNEO0FBQUFBLG1CQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGNBQzNELHVCQUFDLFVBQUs7QUFBQTtBQUFBLGdCQUFNbUYsWUFBWXhCLGFBQWEsQ0FBQyxFQUFFekQ7QUFBQUEsbUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsaUJBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBUyxNQUFNO0FBQ2Isc0JBQUlsRCxVQUFVO0FBQ1pBLDZCQUFTbUksWUFBWXhCLGFBQWEsQ0FBQyxDQUFDO0FBQUEsa0JBQ3RDLE9BQU87QUFDTCwwQkFBTVEsU0FBU2dCLFlBQVl4QixhQUFhLENBQUM7QUFDekMsd0JBQUlzQixRQUFRO0FBQ1osd0JBQUlkLE9BQU9oRCxPQUFROEQsU0FBUSxnQ0FBZ0NkLE9BQU81RSxHQUFHO0FBQUEsNkJBQzVENEUsT0FBT3pDLFFBQVN1RCxTQUFRLDhCQUE4QmQsT0FBTzVFLEdBQUc7QUFBQSw2QkFDaEU0RSxPQUFPckMsV0FBWW1ELFNBQVEsa0RBQWtEZCxPQUFPNUUsR0FBRztBQUFBO0FBQzNGMEYsOEJBQVEsMEJBQTBCZCxPQUFPNUUsR0FBRztBQUNqRHJDLDZCQUFTK0gsS0FBSztBQUFBLGtCQUNoQjtBQUFBLGdCQUNGO0FBQUEsZ0JBRUNqSSxxQkFBVyx5QkFBeUI7QUFBQTtBQUFBLGNBbEJ2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtQkE7QUFBQSxlQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLGFBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ0EsS0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1DQTtBQUFBLFFBSURtSSxZQUFZcEIsZUFBZW5CLFNBQVMsS0FDbkMsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUMsNkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsVUFDOUQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxZQUFZdUMsWUFBWXBCO0FBQUFBLGNBQ3hCLFFBQU87QUFBQSxjQUNQLFlBQVksRUFBRXVCLFVBQVUsR0FBR0Msa0JBQWtCLEtBQUs7QUFBQSxjQUNsRCxRQUFRLEVBQUVDLEdBQUcsY0FBYztBQUFBLGNBQzNCLE1BQUs7QUFBQSxjQUNMLE9BQU8sQ0FBQ3JCLFlBQVk7QUFBQSxnQkFDbEJzQixTQUFTQSxNQUFNekgsc0JBQXNCbUcsTUFBTTtBQUFBLGNBQzdDO0FBQUEsY0FDQSxjQUFjLE1BQU07QUFBQTtBQUFBLFlBVnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVV3RDtBQUFBLGFBWjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBekRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyREE7QUFBQSxTQW5FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsT0E1R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThHQTtBQUVKO0FBQUVsSCxJQW5aSUYsb0JBQWtCO0FBQUEsVUFDTGxCLGFBb0tXSSxXQUFXO0FBQUE7QUFBQXlKLEtBcktuQzNJO0FBcVpOLGVBQWVBO0FBQW1CLElBQUEySTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsIlRhYmxlIiwiVG9vbHRpcCIsIkNhcmQiLCJJbnB1dCIsIkJ1dHRvbiIsIlRhZyIsIkF2YXRhciIsIlVzZXJPdXRsaW5lZCIsIlBob25lT3V0bGluZWQiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiRXllT3V0bGluZWQiLCJTZWFyY2hPdXRsaW5lZCIsInVzZU5hdmlnYXRlIiwiRnVzZSIsImFwaSIsIkNpcmN1bGFyTG9hZGVyIiwidXNlRGVib3VuY2UiLCJ2YWx1ZSIsImRlbGF5IiwiX3MiLCJkZWJvdW5jZWRWYWx1ZSIsInNldERlYm91bmNlZFZhbHVlIiwidXNlRWZmZWN0IiwiaGFuZGxlciIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJGSUxURVJTX0NPTkZJRyIsImlkIiwiZmlsdGVyTmFtZSIsImtleSIsIlF1aWNrU2VhcmNoQ29udGVudCIsIm9uU2VsZWN0IiwiX3MyIiwibmF2aWdhdGUiLCJ0YWJsZVVzZXJzIiwic2V0VGFibGVVc2VycyIsInRhYmxlTGVhZHMiLCJzZXRUYWJsZUxlYWRzIiwidGFibGVBZ2VudHMiLCJzZXRUYWJsZUFnZW50cyIsInRhYmxlRW1wbG95ZWVzIiwic2V0VGFibGVFbXBsb3llZXMiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImFjdGl2ZUZpbHRlcnMiLCJzZXRBY3RpdmVGaWx0ZXJzIiwic2VsZWN0ZWRFeGFjdE1hdGNoIiwic2V0U2VsZWN0ZWRFeGFjdE1hdGNoIiwiYXBpTG9hZGVycyIsInNldEFwaUxvYWRlcnMiLCJ1c2VycyIsImxlYWRzIiwiYWdlbnRzIiwiZW1wbG95ZWVzIiwiaXNBbnlBcGlMb2FkaW5nIiwiT2JqZWN0IiwidmFsdWVzIiwic29tZSIsIkJvb2xlYW4iLCJ1cGRhdGVBcGlMb2FkZXIiLCJsb2FkaW5nIiwicHJldiIsImZldGNoVXNlcnMiLCJyZXNwb25zZSIsImdldCIsImZvcm1hdHRlZCIsImRhdGEiLCJtYXAiLCJ1IiwiaSIsIl9pZCIsIm5hbWUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJhZGRyZXNzIiwicGluY29kZSIsImN1c3RvbWVyX2lkIiwiY29sbGVjdGlvbl9hcmVhIiwicm91dGVfbmFtZSIsImFhZGhhYXJfbnVtYmVyIiwiYWRoYWFyX25vIiwicGFuX251bWJlciIsInBhbl9ubyIsImlzQ3VzdG9tZXIiLCJhcHByb3ZhbF9zdGF0dXMiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaExlYWRzIiwibCIsImxlYWRfbmFtZSIsImxlYWRfcGhvbmUiLCJsZWFkX2FkZHJlc3MiLCJsZWFkQ29kZSIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsImN1c3RvbWVyX3N0YXR1cyIsImxlYWRfYWFkaGFhciIsImxlYWRfcGFuIiwiaXNMZWFkIiwiZmV0Y2hBZ2VudHMiLCJhZ2VudCIsImEiLCJlbXBsb3llZUNvZGUiLCJkZXNpZ25hdGlvbl9pZCIsInRpdGxlIiwiaXNBZ2VudCIsImZldGNoRW1wbG95ZWVzIiwiZW1wbG95ZWUiLCJlIiwiaXNFbXBsb3llZSIsImNvbWJpbmVkRGF0YSIsInVzZU1lbW8iLCJjdXN0b21lclBob25lU2V0IiwiU2V0IiwidW5pcXVlTGVhZHNNYXAiLCJNYXAiLCJmb3JFYWNoIiwibGVhZCIsImhhcyIsInNldCIsIkFycmF5IiwiZnJvbSIsInNlYXJjaGFibGVLZXlzIiwibGVuZ3RoIiwiZmlsdGVyIiwiZiIsImluY2x1ZGVzIiwiZGVib3VuY2VkU2VhcmNoVGV4dCIsImZ1c2VJbnN0YW5jZSIsImluY2x1ZGVTY29yZSIsImtleXMiLCJ0aHJlc2hvbGQiLCJyYXdTZWFyY2hSZXN1bHRzIiwidHJpbSIsInNlYXJjaCIsImdldFByb2Nlc3NlZFJlc3VsdHMiLCJtb2RlIiwiaGFzUmVzdWx0cyIsImV4YWN0TWF0Y2hlcyIsInIiLCJzY29yZSIsIml0ZW0iLCJyZWxhdGVkTWF0Y2hlcyIsImZpbmQiLCJtIiwiZ2V0VHlwZUluZm8iLCJyZWNvcmQiLCJsYWJlbCIsImNvbG9yIiwiY29sdW1ucyIsIndpZHRoIiwiYWxpZ24iLCJyZW5kZXIiLCJfIiwiX18iLCJpbmRleCIsImluZm8iLCJkYXRhSW5kZXgiLCJ0ZXh0IiwiaGFuZGxlQWN0aW9uIiwicm91dGUiLCJoYW5kbGVGaWx0ZXJUb2dnbGUiLCJzZWFyY2hTdGF0ZSIsInRhcmdldCIsImlzQWN0aXZlIiwicGFnZVNpemUiLCJoaWRlT25TaW5nbGVQYWdlIiwieCIsIm9uQ2xpY2siLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJRdWlja1NlYXJjaENvbnRlbnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8sIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFRhYmxlLCBUb29sdGlwLCBDYXJkLCBJbnB1dCwgQnV0dG9uLCBUYWcsIEF2YXRhciB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgVXNlck91dGxpbmVkLFxyXG4gIFBob25lT3V0bGluZWQsXHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBFeWVPdXRsaW5lZCxcclxuICBTZWFyY2hPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgRnVzZSBmcm9tIFwiZnVzZS5qc1wiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcblxyXG4vLyBEZWJvdW5jZSBob29rICh1bmNoYW5nZWQpXHJcbmZ1bmN0aW9uIHVzZURlYm91bmNlKHZhbHVlLCBkZWxheSkge1xyXG4gIGNvbnN0IFtkZWJvdW5jZWRWYWx1ZSwgc2V0RGVib3VuY2VkVmFsdWVdID0gdXNlU3RhdGUodmFsdWUpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBoYW5kbGVyID0gc2V0VGltZW91dCgoKSA9PiBzZXREZWJvdW5jZWRWYWx1ZSh2YWx1ZSksIGRlbGF5KTtcclxuICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQoaGFuZGxlcik7XHJcbiAgfSwgW3ZhbHVlLCBkZWxheV0pO1xyXG4gIHJldHVybiBkZWJvdW5jZWRWYWx1ZTtcclxufVxyXG5cclxuY29uc3QgRklMVEVSU19DT05GSUcgPSBbXHJcbiAgeyBpZDogXCIxXCIsIGZpbHRlck5hbWU6IFwiSURcIiwga2V5OiBcImN1c3RvbWVyX2lkXCIgfSxcclxuICB7IGlkOiBcIjJcIiwgZmlsdGVyTmFtZTogXCJOYW1lXCIsIGtleTogXCJuYW1lXCIgfSxcclxuICB7IGlkOiBcIjNcIiwgZmlsdGVyTmFtZTogXCJQaG9uZVwiLCBrZXk6IFwicGhvbmVfbnVtYmVyXCIgfSxcclxuICB7IGlkOiBcIjRcIiwgZmlsdGVyTmFtZTogXCJBYWRoYWFyXCIsIGtleTogXCJhYWRoYWFyX251bWJlclwiIH0sXHJcbiAgeyBpZDogXCI1XCIsIGZpbHRlck5hbWU6IFwiUGFuXCIsIGtleTogXCJwYW5fbnVtYmVyXCIgfSxcclxuICB7IGlkOiBcIjdcIiwgZmlsdGVyTmFtZTogXCJTdGF0dXNcIiwga2V5OiBcImN1c3RvbWVyX3N0YXR1c1wiIH0sXHJcbl07XHJcblxyXG5jb25zdCBRdWlja1NlYXJjaENvbnRlbnQgPSAoeyBvblNlbGVjdCB9KSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICBjb25zdCBbdGFibGVVc2Vycywgc2V0VGFibGVVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlTGVhZHMsIHNldFRhYmxlTGVhZHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUFnZW50cywgc2V0VGFibGVBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUVtcGxveWVlcywgc2V0VGFibGVFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthY3RpdmVGaWx0ZXJzLCBzZXRBY3RpdmVGaWx0ZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFeGFjdE1hdGNoLCBzZXRTZWxlY3RlZEV4YWN0TWF0Y2hdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FwaUxvYWRlcnMsIHNldEFwaUxvYWRlcnNdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcnM6IGZhbHNlLFxyXG4gICAgbGVhZHM6IGZhbHNlLFxyXG4gICAgYWdlbnRzOiBmYWxzZSxcclxuICAgIGVtcGxveWVlczogZmFsc2UsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGlzQW55QXBpTG9hZGluZyA9IE9iamVjdC52YWx1ZXMoYXBpTG9hZGVycykuc29tZShCb29sZWFuKTtcclxuXHJcbiAgLy8gRGF0YSBmZXRjaGluZyAodW5jaGFuZ2VkKVxyXG4gIGNvbnN0IHVwZGF0ZUFwaUxvYWRlciA9IHVzZUNhbGxiYWNrKChrZXksIGxvYWRpbmcpID0+IHtcclxuICAgIHNldEFwaUxvYWRlcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtrZXldOiBsb2FkaW5nIH0pKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB1cGRhdGVBcGlMb2FkZXIoXCJ1c2Vyc1wiLCB0cnVlKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSByZXNwb25zZS5kYXRhLm1hcCgodSwgaSkgPT4gKHtcclxuICAgICAgICAgIF9pZDogdS5faWQsXHJcbiAgICAgICAgICBpZDogaSArIDEsXHJcbiAgICAgICAgICBuYW1lOiB1LmZ1bGxfbmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogdS5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICBhZGRyZXNzOiB1LmFkZHJlc3MsXHJcbiAgICAgICAgICBwaW5jb2RlOiB1LnBpbmNvZGUsXHJcbiAgICAgICAgICBjdXN0b21lcl9pZDogdS5jdXN0b21lcl9pZCxcclxuICAgICAgICAgIGNvbGxlY3Rpb25fYXJlYTogdS5jb2xsZWN0aW9uX2FyZWE/LnJvdXRlX25hbWUsXHJcbiAgICAgICAgICBhYWRoYWFyX251bWJlcjogdS5hZGhhYXJfbm8gfHwgXCLigJRcIixcclxuICAgICAgICAgIHBhbl9udW1iZXI6IHUucGFuX25vIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBpc0N1c3RvbWVyOiB0cnVlLFxyXG4gICAgICAgICAgYXBwcm92YWxfc3RhdHVzOiB1LmFwcHJvdmFsX3N0YXR1cyxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVVc2Vycyhmb3JtYXR0ZWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyczpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHVwZGF0ZUFwaUxvYWRlcihcInVzZXJzXCIsIGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoVXNlcnMoKTtcclxuICB9LCBbdXBkYXRlQXBpTG9hZGVyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaExlYWRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB1cGRhdGVBcGlMb2FkZXIoXCJsZWFkc1wiLCB0cnVlKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvbGVhZC9nZXQtbGVhZFwiKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSByZXNwb25zZS5kYXRhLm1hcCgobCwgaSkgPT4gKHtcclxuICAgICAgICAgIF9pZDogbC5faWQsXHJcbiAgICAgICAgICBpZDogaSArIDEsXHJcbiAgICAgICAgICBuYW1lOiBsLmxlYWRfbmFtZSB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBsLmxlYWRfcGhvbmUgfHwgXCLigJRcIixcclxuICAgICAgICAgIGFkZHJlc3M6IGwubGVhZF9hZGRyZXNzIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBwaW5jb2RlOiBsLnBpbmNvZGUgfHwgXCLigJRcIixcclxuICAgICAgICAgIGN1c3RvbWVyX2lkOiBsLmxlYWRDb2RlLFxyXG4gICAgICAgICAgY29sbGVjdGlvbl9hcmVhOiBsLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBjdXN0b21lcl9zdGF0dXM6IFwiQWN0aXZlXCIsXHJcbiAgICAgICAgICBhYWRoYWFyX251bWJlcjogbC5hZGhhYXJfbm8gfHwgbC5sZWFkX2FhZGhhYXIgfHwgXCLigJRcIixcclxuICAgICAgICAgIHBhbl9udW1iZXI6IGwucGFuX25vIHx8IGwubGVhZF9wYW4gfHwgXCLigJRcIixcclxuICAgICAgICAgIGlzTGVhZDogdHJ1ZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVMZWFkcyhmb3JtYXR0ZWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsZWFkczpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHVwZGF0ZUFwaUxvYWRlcihcImxlYWRzXCIsIGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoTGVhZHMoKTtcclxuICB9LCBbdXBkYXRlQXBpTG9hZGVyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdXBkYXRlQXBpTG9hZGVyKFwiYWdlbnRzXCIsIHRydWUpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXRcIik7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gKHJlc3BvbnNlLmRhdGE/LmFnZW50IHx8IFtdKS5tYXAoKGEsIGkpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGEuX2lkLFxyXG4gICAgICAgICAgaWQ6IGkgKyAxLFxyXG4gICAgICAgICAgbmFtZTogYS5uYW1lIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IGEucGhvbmVfbnVtYmVyIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBhZGRyZXNzOiBhLmFkZHJlc3MgfHwgXCLigJRcIixcclxuICAgICAgICAgIHBpbmNvZGU6IGEucGluY29kZSB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJfaWQ6IGEuZW1wbG95ZWVDb2RlLFxyXG4gICAgICAgICAgY29sbGVjdGlvbl9hcmVhOiBhLmRlc2lnbmF0aW9uX2lkPy50aXRsZSB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJfc3RhdHVzOiBcIkFjdGl2ZVwiLFxyXG4gICAgICAgICAgYWFkaGFhcl9udW1iZXI6IGEuYWRoYWFyX25vIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBwYW5fbnVtYmVyOiBhLnBhbl9ubyB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgaXNBZ2VudDogdHJ1ZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVBZ2VudHMoZm9ybWF0dGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWdlbnRzOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgdXBkYXRlQXBpTG9hZGVyKFwiYWdlbnRzXCIsIGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQWdlbnRzKCk7XHJcbiAgfSwgW3VwZGF0ZUFwaUxvYWRlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHVwZGF0ZUFwaUxvYWRlcihcImVtcGxveWVlc1wiLCB0cnVlKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWVtcGxveWVlXCIpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IChyZXNwb25zZS5kYXRhPy5lbXBsb3llZSB8fCBbXSkubWFwKChlLCBpKSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBlLl9pZCxcclxuICAgICAgICAgIGlkOiBpICsgMSxcclxuICAgICAgICAgIG5hbWU6IGUubmFtZSB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBlLnBob25lX251bWJlciB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgYWRkcmVzczogZS5hZGRyZXNzIHx8IFwi4oCUXCIsXHJcbiAgICAgICAgICBwaW5jb2RlOiBlLnBpbmNvZGUgfHwgXCLigJRcIixcclxuICAgICAgICAgIGN1c3RvbWVyX2lkOiBlLmVtcGxveWVlQ29kZSxcclxuICAgICAgICAgIGNvbGxlY3Rpb25fYXJlYTogZS5kZXNpZ25hdGlvbl9pZD8udGl0bGUgfHwgXCLigJRcIixcclxuICAgICAgICAgIGN1c3RvbWVyX3N0YXR1czogXCJBY3RpdmVcIixcclxuICAgICAgICAgIGFhZGhhYXJfbnVtYmVyOiBlLmFkaGFhcl9ubyB8fCBcIuKAlFwiLFxyXG4gICAgICAgICAgcGFuX251bWJlcjogZS5wYW5fbm8gfHwgXCLigJRcIixcclxuICAgICAgICAgIGlzRW1wbG95ZWU6IHRydWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFRhYmxlRW1wbG95ZWVzKGZvcm1hdHRlZCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlczpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHVwZGF0ZUFwaUxvYWRlcihcImVtcGxveWVlc1wiLCBmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFt1cGRhdGVBcGlMb2FkZXJdKTtcclxuXHJcbiAgLy8gQ29tYmluZSBkYXRhICh1bmNoYW5nZWQpXHJcbiAgY29uc3QgY29tYmluZWREYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBjdXN0b21lclBob25lU2V0ID0gbmV3IFNldCh0YWJsZVVzZXJzLm1hcCgodSkgPT4gdS5waG9uZV9udW1iZXIpKTtcclxuICAgIGNvbnN0IHVuaXF1ZUxlYWRzTWFwID0gbmV3IE1hcCgpO1xyXG4gICAgdGFibGVMZWFkcy5mb3JFYWNoKChsZWFkKSA9PiB7XHJcbiAgICAgIGlmIChjdXN0b21lclBob25lU2V0LmhhcyhsZWFkLnBob25lX251bWJlcikpIHJldHVybjtcclxuICAgICAgaWYgKCF1bmlxdWVMZWFkc01hcC5oYXMobGVhZC5waG9uZV9udW1iZXIpKSB7XHJcbiAgICAgICAgdW5pcXVlTGVhZHNNYXAuc2V0KGxlYWQucGhvbmVfbnVtYmVyLCBsZWFkKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gW1xyXG4gICAgICAuLi50YWJsZVVzZXJzLFxyXG4gICAgICAuLi5BcnJheS5mcm9tKHVuaXF1ZUxlYWRzTWFwLnZhbHVlcygpKSxcclxuICAgICAgLi4udGFibGVBZ2VudHMsXHJcbiAgICAgIC4uLnRhYmxlRW1wbG95ZWVzLFxyXG4gICAgXTtcclxuICB9LCBbdGFibGVVc2VycywgdGFibGVMZWFkcywgdGFibGVBZ2VudHMsIHRhYmxlRW1wbG95ZWVzXSk7XHJcblxyXG4gIGNvbnN0IHNlYXJjaGFibGVLZXlzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoYWN0aXZlRmlsdGVycy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHJldHVybiBGSUxURVJTX0NPTkZJRy5maWx0ZXIoKGYpID0+IGFjdGl2ZUZpbHRlcnMuaW5jbHVkZXMoZi5pZCkpLm1hcCgoZikgPT4gZi5rZXkpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIEZJTFRFUlNfQ09ORklHLm1hcCgoZikgPT4gZi5rZXkpO1xyXG4gIH0sIFthY3RpdmVGaWx0ZXJzXSk7XHJcblxyXG4gIGNvbnN0IGRlYm91bmNlZFNlYXJjaFRleHQgPSB1c2VEZWJvdW5jZShzZWFyY2hUZXh0LCAzMDApO1xyXG5cclxuICBjb25zdCBmdXNlSW5zdGFuY2UgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmIChjb21iaW5lZERhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcclxuICAgIHJldHVybiBuZXcgRnVzZShjb21iaW5lZERhdGEsIHtcclxuICAgICAgaW5jbHVkZVNjb3JlOiB0cnVlLFxyXG4gICAgICBrZXlzOiBzZWFyY2hhYmxlS2V5cyxcclxuICAgICAgdGhyZXNob2xkOiAwLjMsXHJcbiAgICB9KTtcclxuICB9LCBbY29tYmluZWREYXRhLCBzZWFyY2hhYmxlS2V5c10pO1xyXG5cclxuICBjb25zdCByYXdTZWFyY2hSZXN1bHRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIWRlYm91bmNlZFNlYXJjaFRleHQudHJpbSgpIHx8ICFmdXNlSW5zdGFuY2UpIHJldHVybiBbXTtcclxuICAgIHJldHVybiBmdXNlSW5zdGFuY2Uuc2VhcmNoKGRlYm91bmNlZFNlYXJjaFRleHQpO1xyXG4gIH0sIFtkZWJvdW5jZWRTZWFyY2hUZXh0LCBmdXNlSW5zdGFuY2VdKTtcclxuXHJcbiAgY29uc3QgZ2V0UHJvY2Vzc2VkUmVzdWx0cyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIGlmICghZGVib3VuY2VkU2VhcmNoVGV4dC50cmltKCkpIHtcclxuICAgICAgcmV0dXJuIHsgbW9kZTogXCJpZGxlXCIgfTsgLy8gaW5zdGVhZCBvZiBzaG93aW5nIGFsbCBkYXRhXHJcbiAgICB9XHJcbiAgICBpZiAocmF3U2VhcmNoUmVzdWx0cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgcmV0dXJuIHsgbW9kZTogXCJzZWFyY2hcIiwgaGFzUmVzdWx0czogZmFsc2UgfTtcclxuICAgIH1cclxuICAgIGxldCBleGFjdE1hdGNoZXMgPSByYXdTZWFyY2hSZXN1bHRzLmZpbHRlcigocikgPT4gci5zY29yZSA8PSAwLjA1KS5tYXAoKHIpID0+IHIuaXRlbSk7XHJcbiAgICBsZXQgcmVsYXRlZE1hdGNoZXMgPSByYXdTZWFyY2hSZXN1bHRzLmZpbHRlcigocikgPT4gci5zY29yZSA+IDAuMDUpLm1hcCgocikgPT4gci5pdGVtKTtcclxuXHJcbiAgICBpZiAoc2VsZWN0ZWRFeGFjdE1hdGNoKSB7XHJcbiAgICAgIGlmICghZXhhY3RNYXRjaGVzLmZpbmQoKG0pID0+IG0uX2lkID09PSBzZWxlY3RlZEV4YWN0TWF0Y2guX2lkKSkge1xyXG4gICAgICAgIGV4YWN0TWF0Y2hlcyA9IFtzZWxlY3RlZEV4YWN0TWF0Y2hdO1xyXG4gICAgICB9XHJcbiAgICAgIHJlbGF0ZWRNYXRjaGVzID0gcmVsYXRlZE1hdGNoZXMuZmlsdGVyKChpdGVtKSA9PiBpdGVtLl9pZCAhPT0gc2VsZWN0ZWRFeGFjdE1hdGNoLl9pZCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4geyBtb2RlOiBcInNlYXJjaFwiLCBleGFjdE1hdGNoZXMsIHJlbGF0ZWRNYXRjaGVzLCBoYXNSZXN1bHRzOiB0cnVlIH07XHJcbiAgfSwgW2RlYm91bmNlZFNlYXJjaFRleHQsIHJhd1NlYXJjaFJlc3VsdHMsIHNlbGVjdGVkRXhhY3RNYXRjaF0pO1xyXG5cclxuICBjb25zdCBnZXRUeXBlSW5mbyA9IChyZWNvcmQpID0+IHtcclxuICAgIGlmIChyZWNvcmQuaXNMZWFkKSByZXR1cm4geyBsYWJlbDogXCJMZWFkXCIsIGNvbG9yOiBcIm9yYW5nZVwiIH07XHJcbiAgICBpZiAocmVjb3JkLmlzQWdlbnQpIHJldHVybiB7IGxhYmVsOiBcIkFnZW50XCIsIGNvbG9yOiBcInB1cnBsZVwiIH07XHJcbiAgICBpZiAocmVjb3JkLmlzRW1wbG95ZWUpIHJldHVybiB7IGxhYmVsOiBcIkVtcGxveWVlXCIsIGNvbG9yOiBcImN5YW5cIiB9O1xyXG4gICAgaWYgKHJlY29yZC5pc0N1c3RvbWVyKSByZXR1cm4geyBsYWJlbDogXCJDdXN0b21lclwiLCBjb2xvcjogXCJibHVlXCIgfTtcclxuICAgIHJldHVybiB7IGxhYmVsOiBcIlVua25vd25cIiwgY29sb3I6IFwiZGVmYXVsdFwiIH07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PiBbXHJcbiAgICAgIHtcclxuICAgICAgICB0aXRsZTogXCJTTC4gTk9cIixcclxuICAgICAgICBrZXk6IFwic19ub1wiLFxyXG4gICAgICAgIHdpZHRoOiA4MCxcclxuICAgICAgICBhbGlnbjogXCJjZW50ZXJcIixcclxuICAgICAgICByZW5kZXI6IChfLCBfXywgaW5kZXgpID0+IGluZGV4ICsgMSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIHRpdGxlOiBcIlR5cGVcIixcclxuICAgICAgICBrZXk6IFwidHlwZVwiLFxyXG4gICAgICAgIHdpZHRoOiAxMDAsXHJcbiAgICAgICAgcmVuZGVyOiAoXywgcmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBpbmZvID0gZ2V0VHlwZUluZm8ocmVjb3JkKTtcclxuICAgICAgICAgIHJldHVybiA8VGFnIGNvbG9yPXtpbmZvLmNvbG9yfT57aW5mby5sYWJlbH08L1RhZz47XHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgeyBkYXRhSW5kZXg6IFwiY3VzdG9tZXJfaWRcIiwgdGl0bGU6IFwiSURcIiwga2V5OiBcImN1c3RvbWVyX2lkXCIsIHdpZHRoOiAxMjAgfSxcclxuICAgICAgeyBkYXRhSW5kZXg6IFwibmFtZVwiLCB0aXRsZTogXCJOYW1lXCIsIGtleTogXCJuYW1lXCIsIHdpZHRoOiAxODAgfSxcclxuICAgICAgeyBkYXRhSW5kZXg6IFwicGhvbmVfbnVtYmVyXCIsIHRpdGxlOiBcIlBob25lXCIsIGtleTogXCJwaG9uZV9udW1iZXJcIiwgd2lkdGg6IDE0MCB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgZGF0YUluZGV4OiBcImFhZGhhYXJfbnVtYmVyXCIsXHJcbiAgICAgICAgdGl0bGU6IFwiQWFkaGFhclwiLFxyXG4gICAgICAgIGtleTogXCJhYWRoYWFyX251bWJlclwiLFxyXG4gICAgICAgIHdpZHRoOiAxNTAsXHJcbiAgICAgICAgcmVuZGVyOiAodGV4dCkgPT4gPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc21cIj57dGV4dH08L3NwYW4+LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgZGF0YUluZGV4OiBcInBhbl9udW1iZXJcIixcclxuICAgICAgICB0aXRsZTogXCJQYW5cIixcclxuICAgICAgICBrZXk6IFwicGFuX251bWJlclwiLFxyXG4gICAgICAgIHdpZHRoOiAxNDAsXHJcbiAgICAgICAgcmVuZGVyOiAodGV4dCkgPT4gPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc20gdXBwZXJjYXNlXCI+e3RleHR9PC9zcGFuPixcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCJhY3Rpb25cIixcclxuICAgICAgICB3aWR0aDogMTAwLFxyXG4gICAgICAgIHJlbmRlcjogKF8sIHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgaGFuZGxlQWN0aW9uID0gKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAob25TZWxlY3QpIHtcclxuICAgICAgICAgICAgICBvblNlbGVjdChyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIGxldCByb3V0ZSA9IFwiI1wiO1xyXG4gICAgICAgICAgICAgIGlmIChyZWNvcmQuaXNMZWFkKSByb3V0ZSA9IGAvcmVwb3J0cy9sZWFkLXJlcG9ydD9sZWFkX2lkPSR7cmVjb3JkLl9pZH1gO1xyXG4gICAgICAgICAgICAgIGVsc2UgaWYgKHJlY29yZC5pc0FnZW50KSByb3V0ZSA9IGAvc3RhZmYtbWVudS9hZ2VudD9hZ2VudF9pZD0ke3JlY29yZC5faWR9YDtcclxuICAgICAgICAgICAgICBlbHNlIGlmIChyZWNvcmQuaXNFbXBsb3llZSkgcm91dGUgPSBgL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudS9lbXBsb3llZT9lbXBsb3llZV9pZD0ke3JlY29yZC5faWR9YDtcclxuICAgICAgICAgICAgICBlbHNlIHJvdXRlID0gYC9jdXN0b21lci12aWV3P3VzZXJfaWQ9JHtyZWNvcmQuX2lkfWA7XHJcbiAgICAgICAgICAgICAgbmF2aWdhdGUocm91dGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9e29uU2VsZWN0ID8gXCJTZWxlY3QgQ3VzdG9tZXJcIiA6IFwiVmlldyBQcm9maWxlXCJ9PlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFjdGlvbn1cclxuICAgICAgICAgICAgICAgIGljb249e29uU2VsZWN0ID8gPENoZWNrQ2lyY2xlT3V0bGluZWQgLz4gOiA8RXllT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS03MDAgaG92ZXI6YmctdmlvbGV0LTYwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOnNoYWRvdyB0cmFuc2l0aW9uICR7XHJcbiAgICAgICAgICAgICAgICAgIG9uU2VsZWN0ID8gXCJiZy1ncmVlbi01MCBib3JkZXItZ3JlZW4tMzAwIHRleHQtZ3JlZW4tNzAwIGhvdmVyOmJnLWdyZWVuLTYwMFwiIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge29uU2VsZWN0ID8gXCJTZWxlY3RcIiA6IFwiVmlld1wifVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gICAgW25hdmlnYXRlLCBvblNlbGVjdF1cclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWx0ZXJUb2dnbGUgPSAoaWQpID0+IHtcclxuICAgIHNldEFjdGl2ZUZpbHRlcnMoKHByZXYpID0+IChwcmV2LmluY2x1ZGVzKGlkKSA/IHByZXYuZmlsdGVyKChmKSA9PiBmICE9PSBpZCkgOiBbLi4ucHJldiwgaWRdKSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gcmVzZXQgZXhhY3QgbWF0Y2ggd2hlbiBzZWFyY2ggY2hhbmdlc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEV4YWN0TWF0Y2gobnVsbCk7XHJcbiAgfSwgW3NlYXJjaFRleHRdKTtcclxuXHJcbiAgY29uc3Qgc2VhcmNoU3RhdGUgPSBnZXRQcm9jZXNzZWRSZXN1bHRzKCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxyXG4gICAgICB7LyogU2VhcmNoIGJhciBhbmQgZmlsdGVycyAoYWx3YXlzIHZpc2libGUpICovfVxyXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJtYi00IHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtY2VudGVyIGxnOmp1c3RpZnktYmV0d2VlbiBnYXAtNVwiPlxyXG4gICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgIHByZWZpeD17PFNlYXJjaE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPn1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgSUQsIE5hbWUsIFBob25lLCBBYWRoYWFyLCBvciBQYW4uLi5cIlxyXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNoVGV4dH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGxnOnctMS8zXCJcclxuICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAge0ZJTFRFUlNfQ09ORklHLm1hcCgoZmlsdGVyKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBhY3RpdmVGaWx0ZXJzLmluY2x1ZGVzKGZpbHRlci5pZCk7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIGtleT17ZmlsdGVyLmlkfSB0aXRsZT17YFNlYXJjaCBieSAke2ZpbHRlci5maWx0ZXJOYW1lfWB9PlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRmlsdGVyVG9nZ2xlKGZpbHRlci5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHNoYWRvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgaG92ZXI6YmctZ3JheS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpbHRlci5maWx0ZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0NhcmQ+XHJcblxyXG4gICAgICB7LyogTG9hZGluZyBzdGF0ZSAqL31cclxuICAgICAge2lzQW55QXBpTG9hZGluZyAmJiA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSBkYXRhPVwiUmVjb3Jkc1wiIC8+fVxyXG5cclxuICAgICAgey8qIFJlc3VsdHMg4oCTIG9ubHkgc2hvd24gd2hlbiBzZWFyY2ggdGV4dCBpcyBub24tZW1wdHkgKi99XHJcbiAgICAgIHshaXNBbnlBcGlMb2FkaW5nICYmIHNlYXJjaFRleHQudHJpbSgpLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICB7c2VhcmNoU3RhdGUubW9kZSA9PT0gXCJzZWFyY2hcIiAmJiAhc2VhcmNoU3RhdGUuaGFzUmVzdWx0cyAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+Tm8gbWF0Y2hlcyBmb3VuZC48L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c2VhcmNoU3RhdGUubW9kZSA9PT0gXCJzZWFyY2hcIiAmJiBzZWFyY2hTdGF0ZS5oYXNSZXN1bHRzICYmIChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICB7LyogSGVybyBjYXJkIGZvciBleGFjdCBtYXRjaCAqL31cclxuICAgICAgICAgICAgICB7c2VhcmNoU3RhdGUuZXhhY3RNYXRjaGVzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IHAtNSByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXItbC04IGJvcmRlci12aW9sZXQtNTAwIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxBdmF0YXIgc2l6ZT17NDh9IGljb249ezxVc2VyT3V0bGluZWQgLz59IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUYWcgY29sb3I9XCJ2aW9sZXRcIj5FeGFjdCBNYXRjaDwvVGFnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkXCI+e3NlYXJjaFN0YXRlLmV4YWN0TWF0Y2hlc1swXS5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBob25lT3V0bGluZWQgLz4ge3NlYXJjaFN0YXRlLmV4YWN0TWF0Y2hlc1swXS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgbXQtMiB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFhZGhhYXI6IHtzZWFyY2hTdGF0ZS5leGFjdE1hdGNoZXNbMF0uYWFkaGFhcl9udW1iZXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QYW46IHtzZWFyY2hTdGF0ZS5leGFjdE1hdGNoZXNbMF0ucGFuX251bWJlcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0zIGJnLXZpb2xldC02MDAgYm9yZGVyLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9uU2VsZWN0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblNlbGVjdChzZWFyY2hTdGF0ZS5leGFjdE1hdGNoZXNbMF0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZWNvcmQgPSBzZWFyY2hTdGF0ZS5leGFjdE1hdGNoZXNbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm91dGUgPSBcIiNcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZWNvcmQuaXNMZWFkKSByb3V0ZSA9IGAvcmVwb3J0cy9sZWFkLXJlcG9ydD9sZWFkX2lkPSR7cmVjb3JkLl9pZH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAocmVjb3JkLmlzQWdlbnQpIHJvdXRlID0gYC9zdGFmZi1tZW51L2FnZW50P2FnZW50X2lkPSR7cmVjb3JkLl9pZH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAocmVjb3JkLmlzRW1wbG95ZWUpIHJvdXRlID0gYC9zdGFmZi1tZW51L2VtcGxveWVlLW1lbnUvZW1wbG95ZWU/ZW1wbG95ZWVfaWQ9JHtyZWNvcmQuX2lkfWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHJvdXRlID0gYC9jdXN0b21lci12aWV3P3VzZXJfaWQ9JHtyZWNvcmQuX2lkfWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShyb3V0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7b25TZWxlY3QgPyBcIlNlbGVjdCB0aGlzIEN1c3RvbWVyXCIgOiBcIlZpZXcgUHJvZmlsZVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIFJlbGF0ZWQgbWF0Y2hlcyB0YWJsZSAqL31cclxuICAgICAgICAgICAgICB7c2VhcmNoU3RhdGUucmVsYXRlZE1hdGNoZXMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBmb250LXNlbWlib2xkIG1iLTNcIj5PdGhlciBSZXN1bHRzPC9oND5cclxuICAgICAgICAgICAgICAgICAgPFRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlPXtzZWFyY2hTdGF0ZS5yZWxhdGVkTWF0Y2hlc31cclxuICAgICAgICAgICAgICAgICAgICByb3dLZXk9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBhZ2luYXRpb249e3sgcGFnZVNpemU6IDUsIGhpZGVPblNpbmdsZVBhZ2U6IHRydWUgfX1cclxuICAgICAgICAgICAgICAgICAgICBzY3JvbGw9e3sgeDogXCJtYXgtY29udGVudFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cIm1pZGRsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25Sb3c9eyhyZWNvcmQpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBzZXRTZWxlY3RlZEV4YWN0TWF0Y2gocmVjb3JkKSxcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICByb3dDbGFzc05hbWU9eygpID0+IFwiY3Vyc29yLXBvaW50ZXIgaG92ZXI6YmctZ3JheS01MFwifVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFF1aWNrU2VhcmNoQ29udGVudDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUXVpY2tTZWFyY2hDb250ZW50LmpzeCJ9