import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/GeneralPaymentOut.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import { Button, Drawer, Modal, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { SearchOutlined, InfoCircleOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaRupeeSign, FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import ChitCancelPaymentOut from "/src/pages/ChitCancelPaymentOut.jsx";
const GeneralPaymentOut = () => {
  _s();
  const [activeTab, setActiveTab] = useState("general");
  const [showSidebar, setShowSidebar] = useState(true);
  const [groups, setGroups] = useState([]);
  const [TableAuctions, setTableAuctions] = useState([]);
  const [paymentMode, setPaymentMode] = useState("cash");
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedGroup, setSelectedGroup] = useState("");
  const [groupId, setGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [double, setDouble] = useState({});
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [modifyPayment, setModifyPayment] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentDetails, setPaymentDetails] = useState(null);
  const [disabled, setDisabled] = useState(false);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [paymentGroupTicketsPayment, setPaymentGroupTicketsPayment] = useState(
    []
  );
  const [disbursementType, setDisbursementType] = useState("");
  const [showOthersField, setShowOthersField] = useState(false);
  const [paymentType, setPaymentType] = useState("Auction Winning Payout");
  const [rerender, setRerender] = useState(0);
  const [showRecentPayouts, setShowRecentPayouts] = useState(true);
  const [recentPayouts, setRecentPayouts] = useState([]);
  const [isLoadingRecent, setIsLoadingRecent] = useState(false);
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [selectedTicketValue, setSelectedTicketValue] = useState(null);
  const [whatsappEnabled, setWhatsappEnabled] = useState(true);
  const [users, setUsers] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [paymentModePayment, setPaymentModePayment] = useState("cash");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    pay_date: today,
    ticket: "",
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: "",
    disbursement_type: "Auction Winning Payout",
    note: ""
  });
  const [payoutData, setPayoutData] = useState({
    user_id: "",
    pay_date: today,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: "",
    payment_group_tickets: [],
    disbursement_type: "",
    note: ""
  });
  const disbursementTypes = [
    {
      key: "#1",
      title: "Chit Cancellation",
      value: "Chit Cancellation"
    },
    {
      key: "#2",
      title: "Refund to Member",
      value: "Refund to Member"
    },
    {
      key: "#3",
      title: "Foreman Commission Disbursement",
      value: "Refund to Member"
    },
    {
      key: "#4",
      title: "Reinvestment Transfer",
      value: "Reinvestment Transfer"
    },
    {
      key: "#5",
      title: "Advance Payout Before Auction",
      value: "Advance Payout Before Auction"
    },
    {
      key: "#6",
      title: "Divident Share Disbursement",
      value: "Divident Share Disbursement"
    },
    {
      key: "#7",
      title: "Group Closure Settlement",
      value: "Group Closure Settlement"
    },
    {
      key: "#8",
      title: "Emergency Withdrawal",
      value: "Emergency Withdrawal"
    },
    {
      key: "#9",
      title: "Mistaken Payment Reversal",
      value: "Mistaken Payment Reversal"
    },
    {
      key: "#10",
      title: "Others",
      value: "Others"
    }
  ];
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const handlePaymentTicketChange = (value) => {
    setSelectedTicketValue(value);
    setPaymentGroupTicketsPayment(value);
  };
  const handlePaymentModeChangePayment = (e) => {
    const mode = e.target.value;
    setPaymentModePayment(mode);
    setPayoutData((prev) => ({
      ...prev,
      pay_type: mode,
      transaction_id: mode === "online" ? prev.transaction_id : ""
    }));
  };
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prev) => ({
      ...prev,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prev.transaction_id : ""
    }));
  };
  const handleGroupChange = async (groupId2) => {
    setSelectedGroup(groupId2);
    if (groupId2) {
      try {
        const response = await api.get(`/enroll/get-group-enroll/${groupId2}`);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
    setSelectedTicketValue(values);
  };
  const handleCustomerPayment = async (userId) => {
    setSelectedGroup(userId);
    setPayoutData((prev) => ({
      ...prev,
      user_id: userId
    }));
    setSelectedTicketValue(null);
    setPaymentGroupTickets([]);
    setErrors((prev) => ({
      ...prev,
      customer: "",
      payment_group_tickets: ""
    }));
    handleGroupChange(userId);
    handleGroupAuctChange(userId);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "disbursement_type") {
      if (value === "Others") {
        setShowOthersField(true);
        setDisbursementType("");
      } else {
        setShowOthersField(false);
        setDisbursementType(value);
      }
    }
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handleChangePayment = (e) => {
    const { name, value } = e.target;
    if (name === "disbursement_type") {
      if (value === "Others") {
        setShowOthersField(true);
        setDisbursementType("");
      } else {
        setShowOthersField(false);
      }
    }
    setPayoutData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({ ...prevData, [name]: "" }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!selectedGroupId) newErrors.customer = "Please select a customer";
    if (!formData.ticket)
      newErrors.payment_group_tickets = "Please Provide ticket";
    if (!formData.pay_date) newErrors.pay_date = "Payment date is required";
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0)
      newErrors.amount = "Please enter a valid positive amount";
    if (paymentMode === "online" && !formData.transaction_id?.trim())
      newErrors.transaction_id = "Transaction ID is required for online payments";
    if (paymentMode === "cheque" && !formData.cheque_date?.trim()) {
      newErrors.cheque_date = "Cheque Date is required for cheque payments";
    }
    if (paymentMode === "cheque" && !formData.cheque_number?.trim()) {
      newErrors.cheque_number = "Cheque Number is required for cheque payments";
    }
    if (!formData.disbursement_type)
      newErrors.disbursement_type = "Disbursement Type is Required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const validatePaymentForm = () => {
    const newErrors = {};
    if (!selectedGroup) {
      newErrors.customer = "Please select a customer";
    }
    if (!selectedTicketValue) {
      newErrors.payment_group_tickets = "Please select a group and ticket";
    }
    if (!payoutData.pay_date) {
      newErrors.pay_date = "Payment date is required";
    }
    const amount = parseFloat(payoutData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    if (paymentModePayment === "online" && !payoutData.transaction_id?.trim()) {
      newErrors.transaction_id = "Transaction ID is required";
    }
    if (paymentModePayment === "cheque" && !payoutData.cheque_date?.trim()) {
      newErrors.cheque_date = "Cheque Date is required for cheque payments";
    }
    if (paymentModePayment === "cheque" && !payoutData.cheque_number?.trim()) {
      newErrors.cheque_number = "Cheque Number is required for cheque payments";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const fetchRecentPayouts = async () => {
    setIsLoadingRecent(true);
    try {
      const { data } = await api.get("/v1/admin/auctions/payment-outs");
      if (data?.success && Array.isArray(data?.data)) {
        const formattedPayouts = data.data.filter((payout) => {
          const name = payout.user_id?.full_name?.trim() || "";
          const phone = payout.user_id?.phone_number?.trim() || "";
          return name !== "" && name !== "N/A" && phone !== "" && phone !== "N/A";
        }).map((payout, index) => ({
          _id: payout._id,
          id: index + 1,
          date: payout.auction_date ? new Date(payout.auction_date).toLocaleDateString("en-US", {
            day: "numeric",
            month: "short",
            year: "numeric"
          }) : "N/A",
          name: payout.user_id?.full_name || "N/A",
          phone_number: payout.user_id?.phone_number || "N/A",
          ticket: payout.ticket || "N/A",
          bid_amount: (parseInt(payout.divident) || 0) + (parseInt(payout.commission) || 0),
          amount: payout.win_amount || 0,
          auction_type: payout.auction_type || "N/A",
          // status: "Prized", // Since these are completed auction payouts
          group_name: payout.group_id?.group_name || "N/A",
          group_value: payout.group_id?.group_value || "N/A",
          auction_code: payout.auction_code || "N/A",
          group_id: payout.group_id?._id || payout._id,
          // Use group_id._id if available
          user_id: payout.user_id?._id,
          win_amount: payout.win_amount || 0,
          auction_id: payout._id,
          // The auction ID is the _id from the response
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handlePaymentOutFromRecent(
                          payout.group_id?._id || payout._id,
                          payout.user_id?._id,
                          payout.ticket
                        ),
                        children: "Payment out"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 377,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-blue-600",
                        onClick: () => handleViewAuction(payout._id),
                        children: "View"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 394,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold text-xl cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 406,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 370,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 369,
            columnNumber: 11
          }, this)
        }));
        setRecentPayouts(formattedPayouts);
      } else {
        setRecentPayouts([]);
      }
    } catch (error) {
      console.error("Error fetching recent payouts:", error);
      setRecentPayouts([]);
    } finally {
      setIsLoadingRecent(false);
    }
  };
  const handlePaymentOutFromRecent = async (groupId2, userId, ticket) => {
    if (!userId || !groupId2 || !ticket) {
      Modal.warning({
        title: "Missing Information",
        content: "Customer information not found for this payout."
      });
      return;
    }
    try {
      const { data } = await api.get(
        "/auction/get-auction-by-user-group-ticket",
        { params: { user_id: userId, group_id: groupId2, ticket } }
      );
      setPaymentDetails({
        customerName: data.user_id?.full_name,
        groupName: data.group_id?.group_name,
        winAmount: data.win_amount
      });
      setFormData((prev) => ({
        ...prev,
        group_id: data.group_id?._id,
        user_id: userId,
        amount: data.win_amount,
        ticket
      }));
      setSelectedGroupId(groupId2);
      setShowPaymentModal(true);
    } catch (error) {
      const msg = error?.response?.data?.message;
      if (error.response?.status === 404 && msg === "Auction not found") {
        Modal.warning({
          title: "Auction Not Found",
          content: "No auction was found for the selected user, group, and ticket."
        });
      } else {
        Modal.error({
          title: "Error Fetching Win Amount",
          content: "Something went wrong while trying to fetch win amount."
        });
      }
    }
  };
  const handleViewAuction = async (auctionId) => {
    try {
      const { data } = await api.get(`/auction/get-auction-by-id/${auctionId}`);
      setCurrentUpdateGroup(data);
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching auction details:", error);
      Modal.error({
        title: "Error",
        content: "Failed to fetch auction details"
      });
    }
  };
  const resetToGroupView = () => {
    setShowRecentPayouts(false);
    setSelectedAuctionGroupId("");
    setSelectedAuctionGroup("");
    setTableAuctions([]);
    setFilteredAuction([]);
  };
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const { data } = await api.get("/group/get-group-admin");
        setGroups(data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchGroups();
    fetchRecentPayouts();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [alertConfig]);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    setAdminName(user.name || "");
    const canEdit = user?.admin_access_right_id?.access_permissions?.edit_payment === "true";
    setModifyPayment(canEdit);
  }, []);
  useEffect(() => {
    if (!selectedAuctionGroupId) return;
    const fetchDouble = async () => {
      try {
        const { data } = await api.get(
          `/double/get-double/${selectedAuctionGroupId}`
        );
        setDouble(data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchDouble();
  }, [selectedAuctionGroupId]);
  const handleGroupAuctChange = async (groupId2) => {
    if (groupId2) {
      try {
        const response = await api.post(
          `/enroll/get-user-tickets-report/${groupId2}`
        );
        if (response.data && response.data.length > 0) {
          const validAuctions = response.data.filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setFilteredAuction(validAuctions);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const handleGroupAuction = (groupId2) => {
    setSelectedAuctionGroupId(groupId2);
    handleGroupAuctionChange(groupId2);
  };
  const handleGroupAuctionChange = async (groupId2) => {
    setSelectedAuctionGroup(groupId2);
    if (!groupId2) {
      setFilteredAuction([]);
      return;
    }
    setTableAuctions([]);
    setIsLoading(true);
    try {
      const { data } = await api.get(`/auction/unprized/group/${groupId2}`);
      if (data?.length) {
        setFilteredAuction(data);
        const formatted = [
          {
            id: 1,
            date: new Date(
              new Date(data[0].auction_date).getTime() - 10 * 864e5
            ).toLocaleDateString("en-US", {
              day: "numeric",
              month: "short",
              year: "numeric"
            }).replace(",", ""),
            name: "Commencement",
            phone_number: "Commencement",
            ticket: "Commencement",
            bid_amount: 0,
            amount: 0,
            auction_type: "Commencement Auction",
            status: "Commencement",
            action: null
          },
          ...data.map((g, idx) => ({
            _id: g._id,
            id: idx + 2,
            date: new Date(g.auction_date).toLocaleDateString("en-US", {
              day: "numeric",
              month: "short",
              year: "numeric"
            }),
            name: g.user_id?.full_name,
            phone_number: g.user_id?.phone_number,
            ticket: g.ticket,
            bid_amount: Number(g.divident) + Number(g.commission),
            amount: g.win_amount,
            auction_type: g.auction_type.charAt(0).toUpperCase() + g.auction_type.slice(1) + " Auction",
            status: !g?.isPrized ? "Un Prized" : g?.isPrized === "true" ? "Prized" : "Un Prized",
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                trigger: ["click"],
                menu: {
                  items: [
                    {
                      key: "1",
                      disabled: !g?.user_id?._id || !g?.group_id?._id,
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-green-600",
                          onClick: () => handlePaymentOut(
                            g.group_id?._id,
                            g.user_id?._id,
                            g.ticket
                          ),
                          children: "Payment out"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 634,
                          columnNumber: 19
                        },
                        this
                      )
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-blue-600",
                          onClick: () => handleUpdateModalOpen(g._id, idx + 2),
                          children: "View"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 651,
                          columnNumber: 19
                        },
                        this
                      )
                    }
                  ]
                },
                placement: "bottomLeft",
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold text-xl cursor-pointer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 665,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 626,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 625,
              columnNumber: 11
            }, this)
          }))
        ];
        setTableAuctions(formatted);
      } else {
        setFilteredAuction([]);
        setTableAuctions([]);
      }
    } catch (err) {
      console.error(err);
      setFilteredAuction([]);
      setTableAuctions([]);
    } finally {
      setIsLoading(false);
    }
  };
  const handlePaymentOut = async (groupId2, userId, ticket) => {
    if (!userId || !groupId2 || !ticket) return;
    try {
      const { data } = await api.get(
        "/auction/get-auction-by-user-group-ticket",
        { params: { user_id: userId, group_id: groupId2, ticket } }
      );
      setPaymentDetails({
        customerName: data.user_id?.full_name,
        groupName: data.group_id?.group_name,
        winAmount: data.win_amount
      });
      setFormData((prev) => ({
        ...prev,
        group_id: data.group_id?._id,
        user_id: userId,
        amount: data.win_amount,
        ticket
      }));
      setSelectedGroupId(groupId2);
      setShowPaymentModal(true);
    } catch (error) {
      const msg = error?.response?.data?.message;
      if (error.response?.status === 404 && msg === "Auction not found") {
        Modal.warning({
          title: "Auction Not Found",
          content: "No auction was found for the selected user, group, and ticket."
        });
      } else {
        Modal.error({
          title: "Error Fetching Win Amount",
          content: "Something went wrong while trying to fetch win amount."
        });
      }
    }
  };
  const handleUpdateModalOpen = async (groupId2, si) => {
    try {
      const { data } = await api.get(`/auction/get-auction-by-id/${groupId2}`);
      setCurrentUpdateGroup({ ...data, SI_number: si });
      setShowModalUpdate(true);
    } catch (err) {
      console.error(err);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (!isValid) return;
    try {
      setDisabled(true);
      setShowPaymentModal(false);
      setAlertConfig((prev) => ({ ...prev, visibility: false }));
      const usr = localStorage.getItem("user");
      let admin_type = null;
      if (usr) {
        try {
          admin_type = JSON.parse(usr);
        } catch (e2) {
          console.error("Failed to parse user from localStorage:", e2);
        }
      }
      if (formData.disbursement_type === "Others" && disbursementType) {
        formData.disbursement_type = disbursementType;
      }
      const formattedTickets = paymentGroupTickets.map(
        ({ group_id, ticket }) => ({
          group_id,
          ticket_number: ticket
        })
      );
      const payload = {
        ...formData,
        payment_group_tickets: formattedTickets,
        admin_type: admin_type?._id,
        pay_for: paymentType
      };
      if (!formattedTickets.length && selectedGroupId && paymentGroupTickets[0]?.ticket) {
        payload.group_id = selectedGroupId;
        payload.ticket = paymentGroupTickets[0].ticket;
      }
      setOpenBackdropLoader(true);
      const response = await api.post(
        "/payment-out/add-payments-and-mark-prized",
        payload
      );
      if (response.status >= 200 && response.status < 300) {
        setSelectedGroupId("");
        setPaymentGroupTickets([]);
        setFormData({
          group_id: "",
          user_id: "",
          pay_date: today,
          amount: "",
          pay_type: "cash",
          transaction_id: "",
          ticket: "",
          disbursement_type: "Auction Winning Payout",
          note: ""
        });
        fetchRecentPayouts();
      }
    } catch (error) {
      console.error("Error submitting payment data:", error);
      setShowPaymentModal(false);
      setSelectedGroupId("");
      setFormData({
        group_id: "",
        user_id: "",
        pay_date: today,
        amount: "",
        pay_type: "cash",
        transaction_id: "",
        ticket: "",
        disbursement_type: "Auction Winning Payout",
        note: ""
      });
    } finally {
      setOpenBackdropLoader(false);
      setRerender((prev) => prev + 1);
      setDisabled(false);
    }
  };
  const handleSubmitPaymentout = async (e) => {
    e.preventDefault();
    const isValid = validatePaymentForm();
    if (!isValid) return;
    try {
      const usr = localStorage.getItem("user");
      let admin_type = null;
      try {
        if (usr) admin_type = JSON.parse(usr);
      } catch (e2) {
        console.error("Failed to parse user:", e2);
      }
      let payload = {
        pay_date: payoutData.pay_date,
        amount: payoutData.amount,
        pay_type: payoutData.pay_type,
        transaction_id: payoutData.transaction_id || void 0,
        cheque_number: payoutData.cheque_number || "",
        cheque_date: payoutData.cheque_date || "",
        cheque_bank_name: payoutData.cheque_bank_name || "",
        cheque_bank_branch: payoutData.cheque_bank_branch || "",
        note: payoutData.note || "",
        admin_type: admin_type?._id,
        disbursement_type: payoutData.disbursement_type === "Others" ? disbursementType || "Others" : payoutData.disbursement_type
      };
      payload.user_id = selectedGroup;
      if (selectedTicketValue) {
        const parts = selectedTicketValue.split("|");
        if (parts.length === 2) {
          payload.group_id = parts[0].replace("chit-", "");
          payload.ticket = parts[1];
        }
      }
      const response = await api.post(
        "/v1/admin/payments-out/otherss",
        payload
      );
      if (response.status === 200 || response.status === 201) {
        setSelectedGroup("");
        setSelectedTicketValue(null);
        setPaymentGroupTickets([]);
        setPaymentModePayment("cash");
        setPayoutData({
          user_id: "",
          pay_date: today,
          amount: "",
          pay_type: "cash",
          transaction_id: "",
          cheque_number: "",
          cheque_date: "",
          cheque_bank_name: "",
          cheque_bank_branch: "",
          disbursement_type: "",
          note: ""
        });
        setAlertConfig({
          visibility: true,
          noReload: true,
          message: "Payment Out Added Successfully",
          type: "success"
        });
      } else {
        setAlertConfig({
          visibility: true,
          noReload: true,
          message: "Payment Added Failed",
          type: "error"
        });
      }
    } catch (error) {
      console.error("Error submitting payment data:", error);
      setAlertConfig({
        visibility: true,
        noReload: true,
        message: error.response?.data?.message || "Error submitting payment data",
        type: "error"
      });
    } finally {
      setShowPaymentModal(false);
      setOpenBackdropLoader(false);
      setRerender((prev) => prev + 1);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Auction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_value", header: "Group Value" },
    { key: "group_name", header: "Group" },
    { key: "ticket", header: "Ticket" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "amount", header: "Win Amount" },
    { key: "auction_type", header: "Auction Type" },
    // { key: "status", header: "Status" },
    { key: "action", header: "Action" }
  ];
  const selectednewGroup = groups.find((g) => g._id === selectedAuctionGroupId);
  const displayData = showRecentPayouts ? recentPayouts : TableAuctions;
  const totalWinAmount = displayData.reduce(
    (sum, item) => sum + (Number(item.win_amount) || 0),
    0
  );
  const totalBidAmount = displayData.reduce(
    (sum, item) => sum + (Number(item.bid_amount) || 0),
    0
  );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        .custom-select :global(.ant-select-selector) {
          border: 2px solid #d1d5db;
          border-radius: 0.5rem;
          padding: 0.5rem 0.75rem;
          transition: all 0.3s ease;
          box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }

        .custom-select:hover :global(.ant-select-selector) {
          border-color: #60a5fa;
          box-shadow:
            0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .custom-select-focused :global(.ant-select-selector) {
          border-color: #3b82f6 !important;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
        }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
      lineNumber: 953,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 975,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
        lineNumber: 979,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 981,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 988,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200 mb-6", children: /* @__PURE__ */ jsxDEV("nav", { className: "-mb-px flex space-x-8", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setActiveTab("general");
                },
                className: `py-2 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === "general" ? "border-violet-600 text-violet-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`,
                children: "Chit Payment Out"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 993,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setActiveTab("chit-cancel");
                  setShowSidebar(false);
                },
                className: `py-2 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === "chit-cancel" ? "border-violet-600 text-violet-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`,
                children: "Chit Cancellation Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1006,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 992,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 991,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowPayoutModal(true);
                },
                className: "bg-violet-950 text-white px-4 py-2 rounded hover:bg-violet-900 transition",
                children: "+ Add Pre-Auction Payout"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1022,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: "/reports/prized-customer-report",
                className: "inline-flex items-center px-4 py-2 text-sm border border-blue-500 text-blue-600 rounded\r\n      hover:bg-blue-50 hover:text-blue-700 hover:border-blue-600\r\n      transition-all duration-200 font-medium",
                children: "View Report"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1031,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1021,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 989,
          columnNumber: 11
        }, this),
        activeTab === "general" ? /* @__PURE__ */ jsxDEV("div", { className: "mt-0 mb-8", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-red-600", children: "CHIT" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1045,
              columnNumber: 17
            }, this),
            " Payment Out"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1044,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: showRecentPayouts ? isLoadingRecent ? /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading: isLoadingRecent,
              data: "Recent Payouts"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1115,
              columnNumber: 15
            },
            this
          ) : recentPayouts.length > 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 border-l-4 border-green-500 rounded-lg p-4 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: "Recent Payment Out Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1125,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Showing recently completed chit payouts" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1128,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1124,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl px-4 py-3 shadow-sm border border-green-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-800 text-sm font-semibold", children: [
                  "Total Records: ",
                  recentPayouts.length
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1134,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-800 text-sm font-semibold", children: [
                  "Total Win Amount: ₹",
                  totalWinAmount.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1138,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-800 text-sm font-semibold", children: [
                  "Total Bid Amount: ₹",
                  totalBidAmount.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1143,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1133,
                columnNumber: 31
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1132,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1123,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1122,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1121,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: filterOption(recentPayouts, searchText),
                columns,
                exportedFileName: "Recent_Payouts.csv",
                exportedPdfName: "Recent Payouts Report"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1152,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1120,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No recent payouts found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1160,
            columnNumber: 15
          }, this) : TableAuctions.length ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            !showRecentPayouts && TableAuctions.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 border-l-4 border-green-500 rounded-lg p-4 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: [
                  selectednewGroup?.group_name || "Group",
                  " - Auction Details"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1171,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Showing auction winners for selected group" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1175,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1170,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl px-4 py-3 shadow-sm border border-green-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-800 text-sm font-semibold", children: [
                  "Total Records: ",
                  TableAuctions.length
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1181,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-green-800 text-sm font-semibold", children: [
                  "Total Win Amount: ₹",
                  totalWinAmount.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1184,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1180,
                columnNumber: 31
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1179,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1169,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1168,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1167,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                updateHandler: handleUpdateModalOpen,
                data: filterOption(TableAuctions, searchText),
                columns,
                exportedPdfName: "General Payment Out",
                printHeaderKeys: ["Group Name", "Balance"],
                printHeaderValues: [
                  selectednewGroup?.group_name,
                  double.amount
                ],
                exportedFileName: `General Payment Out.csv`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1194,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1165,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              data: "Auction Data",
              failure: TableAuctions.length === 0 && !!selectedAuctionGroupId
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1208,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1112,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 1043,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(ChitCancelPaymentOut, { showSidebar }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 1219,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
        lineNumber: 987,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Drawer,
        {
          title: /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-semibold text-gray-800 border-b pb-2 block", children: "Chit Payment Out" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1226,
            columnNumber: 11
          }, this),
          open: showPaymentModal,
          okText: "Submit",
          onClose: () => setShowPaymentModal(false),
          className: "payment-drawer",
          width: 500,
          children: paymentDetails ? /* @__PURE__ */ jsxDEV("form", { className: "space-y-5 p-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Customer Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1239,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: paymentDetails.customerName,
                  readOnly: true,
                  className: "border border-gray-300 bg-gray-100 rounded-lg w-full p-3 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1242,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1238,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Group Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1250,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: paymentDetails.groupName,
                  readOnly: true,
                  className: "border border-gray-300 bg-gray-100 rounded-lg w-full p-3 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1253,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1249,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Ticket" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1261,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  name: "ticket",
                  value: formData.ticket,
                  readOnly: true,
                  className: "bg-gray-100 border border-gray-300 rounded-lg w-full p-3 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1264,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-gray-600 mt-1 block", children: numberToIndianWords(formData.ticket || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1270,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1260,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Win Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1276,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  value: paymentDetails.winAmount,
                  className: "border border-gray-300 bg-gray-100 rounded-lg w-full p-3 cursor-not-allowed",
                  readOnly: true
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1279,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-gray-600 mt-1 block", children: numberToIndianWords(paymentDetails.winAmount || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1285,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1275,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
                "Payable Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1291,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1290,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "amount",
                  value: formData.amount,
                  onChange: handleChange,
                  className: "border border-gray-300 rounded-lg w-full p-3"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1293,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-gray-600 mt-1 block", children: numberToIndianWords(formData.amount || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1300,
                columnNumber: 17
              }, this),
              errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1304,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1289,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Disbursement Type" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1309,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  name: "disbursement_type",
                  value: formData.disbursement_type,
                  readOnly: true,
                  className: "bg-gray-100 border border-gray-300 rounded-lg w-full p-3 cursor-not-allowed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1312,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1308,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Payment Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1321,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: formData.pay_date,
                  onChange: (e) => setFormData((p) => ({ ...p, pay_date: e.target.value })),
                  className: "border border-gray-300 rounded-lg w-full p-3"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1324,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1320,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Payment Mode" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1335,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "pay_mode",
                  value: paymentMode,
                  onChange: handlePaymentModeChange,
                  className: "border border-gray-300 rounded-lg w-full p-3 bg-white",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1344,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1345,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1346,
                      columnNumber: 19
                    }, this),
                    modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "suspense", children: "Suspense" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1349,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "credit", children: "Credit" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1350,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "adjustment", children: "Adjustment" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1351,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "others", children: "Others" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1352,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1348,
                      columnNumber: 17
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1338,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1334,
              columnNumber: 15
            }, this),
            paymentMode === "online" && /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Transaction ID *" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1360,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "transaction_id",
                  value: formData.transaction_id,
                  onChange: handleChange,
                  className: "border border-gray-300 rounded-lg w-full p-3"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1363,
                  columnNumber: 19
                },
                this
              ),
              errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1371,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1359,
              columnNumber: 13
            }, this),
            paymentMode === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h5", { className: "text-base font-semibold text-gray-900 mb-3", children: "Cheque Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1380,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                    "Cheque Number ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1386,
                      columnNumber: 39
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1385,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_number",
                      id: "cheque_number",
                      value: formData.cheque_number,
                      onChange: handleChange,
                      placeholder: "Enter Cheque Number",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1388,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1398,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1384,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                    "Cheque Date ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1406,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1405,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "cheque_date",
                      id: "cheque_date",
                      value: formData?.cheque_date?.split("T")[0],
                      onChange: handleChange,
                      placeholder: "Enter Cheque Date",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1408,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1418,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1404,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1425,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_bank_name",
                      id: "cheque_bank_name",
                      value: formData.cheque_bank_name,
                      onChange: handleChange,
                      placeholder: "Enter Bank Name",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1428,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1424,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Branch" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1440,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_bank_branch",
                      id: "cheque_bank_branch",
                      value: formData.cheque_bank_branch,
                      onChange: handleChange,
                      placeholder: "Enter Bank Branch",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1443,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1439,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1383,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1379,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Note" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1458,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  value: paymentDetails.note || "",
                  onChange: (e) => setPaymentDetails((p) => ({ ...p, note: e.target.value })),
                  className: "border border-gray-300 rounded-lg w-full p-3 resize-none",
                  rows: 3,
                  placeholder: "Add any additional notes here..."
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1461,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1457,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between pt-4 border-t mt-6", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => setShowPaymentModal(false),
                  className: "px-6 py-2 rounded-lg border border-gray-300",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1473,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: handleSubmit,
                  type: "primary",
                  className: "px-6 py-2 rounded-lg bg-blue-600 text-white",
                  children: "Submit"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1479,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1472,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1237,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-64", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1490,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1489,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 1224,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          open: showModalUpdate,
          footer: null,
          onCancel: () => setShowModalUpdate(false),
          width: 800,
          className: "auction-modal",
          children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200 pb-4 mb-6", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "View Auction Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1507,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1506,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-base font-semibold text-gray-700 mb-4", children: "Basic Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1514,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-600 mb-1", children: "SI No" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1519,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-300 rounded px-3 py-2", children: currentUpdateGroup?.SI_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1522,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1518,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-600 mb-1", children: "Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1527,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-300 rounded px-3 py-2", children: currentUpdateGroup?.group_id?.group_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1530,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1526,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-600 mb-1", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1535,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-300 rounded px-3 py-2", children: `${currentUpdateGroup?.user_id?.full_name} | ${currentUpdateGroup?.ticket}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1538,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1534,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-600 mb-1", children: "Winning Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1543,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-300 rounded px-3 py-2", children: [
                    "₹",
                    currentUpdateGroup?.win_amount?.toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1546,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1542,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1517,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1513,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1512,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1505,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 1498,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          open: showPayoutModal,
          onCancel: () => {
            setSelectedGroupId("");
            setSelectedTicketValue(null);
            setShowPayoutModal(false);
            setErrors({});
          },
          width: 800,
          className: "auction-modal",
          footer: null,
          children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left ", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Pre-Auction Payout" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1568,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", noValidate: true, children: [
              /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "category",
                      children: [
                        "Customer ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1579,
                          columnNumber: 30
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1575,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full ${fieldSize.height}`,
                      placeholder: "Select Or Search Customer",
                      popupMatchSelectWidth: false,
                      showSearch: true,
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      value: selectedGroup || void 0,
                      onChange: handleCustomerPayment,
                      children: users.map(
                        (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: `${group.full_name} | ${group.phone_number}` }, group._id, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1597,
                          columnNumber: 21
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1582,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1604,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1574,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Group & Ticket" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1611,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      placeholder: "Select Group | Ticket",
                      onChange: handlePaymentTicketChange,
                      value: selectedTicketValue,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full h-14",
                      allowClear: true,
                      children: filteredAuction.map((entry, index) => {
                        const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                        const groupId2 = entry?.enrollment?.group?._id || `missing-${index}`;
                        const ticket = entry?.enrollment?.tickets || "Unknown";
                        const key = `chit-${groupId2}|${ticket}`;
                        return /* @__PURE__ */ jsxDEV(Select.Option, { value: key, children: [
                          groupName,
                          " | ",
                          ticket
                        ] }, key, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1629,
                          columnNumber: 25
                        }, this);
                      })
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1614,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.payment_group_tickets }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1636,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1610,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1573,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "group_install",
                      children: "Payment Date"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1645,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      disabled: !modifyPayment,
                      type: "date",
                      name: "pay_date",
                      value: payoutData.pay_date,
                      id: "pay_date",
                      onChange: handleChangePayment,
                      placeholder: "",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full h-14"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1651,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1663,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1644,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "group_value",
                      children: [
                        "Amount ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1673,
                          columnNumber: 28
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1669,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      name: "amount",
                      value: payoutData.amount,
                      id: "amount",
                      onChange: handleChangePayment,
                      placeholder: "Enter Amount",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1676,
                      columnNumber: 21
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1675,
                    columnNumber: 19
                  }, this),
                  errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1689,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1668,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1643,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "pay_mode",
                      children: "Disbursement Type"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1696,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      name: "disbursement_type",
                      id: "pay_mode",
                      value: payoutData.disbursement_type || "Advance Payout Before Auction",
                      disabled: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                      onChange: handleChangePayment,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select any" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1713,
                          columnNumber: 21
                        }, this),
                        disbursementTypes.map(
                          (dType) => /* @__PURE__ */ jsxDEV("option", { value: dType.value, children: dType.title }, dType.key, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                            lineNumber: 1715,
                            columnNumber: 21
                          }, this)
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1702,
                      columnNumber: 19
                    },
                    this
                  ),
                  errors.disbursement_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.disbursement_type }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1721,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1695,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "pay_mode",
                      children: "Payment Mode"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1728,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      name: "pay_mode",
                      id: "pay_mode",
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                      onChange: handlePaymentModeChangePayment,
                      value: paymentModePayment,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1741,
                          columnNumber: 21
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1742,
                          columnNumber: 21
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1743,
                          columnNumber: 21
                        }, this),
                        modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                          /* @__PURE__ */ jsxDEV("option", { value: "suspense", children: "Suspense" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                            lineNumber: 1746,
                            columnNumber: 25
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "credit", children: "Credit" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                            lineNumber: 1747,
                            columnNumber: 25
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "adjustment", children: "Adjustment" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                            lineNumber: 1748,
                            columnNumber: 25
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "others", children: "Others" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                            lineNumber: 1749,
                            columnNumber: 25
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                          lineNumber: 1745,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1734,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1727,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1694,
                columnNumber: 15
              }, this),
              payoutData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "pay_mode",
                    children: "Individual Ticket Amount"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1758,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg hover:cursor-not-allowed w-full p-2.5",
                    placeholder: "totalAmount",
                    value: Number(payoutData.amount) / paymentGroupTickets.length,
                    disabled: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1765,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1757,
                columnNumber: 15
              }, this),
              paymentModePayment === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "transaction_id",
                    children: [
                      "Transaction ID ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1782,
                        columnNumber: 36
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1778,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "transaction_id",
                    id: "transaction_id",
                    value: payoutData.transaction_id,
                    onChange: handleChangePayment,
                    placeholder: "Enter Transaction ID",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1784,
                    columnNumber: 19
                  },
                  this
                ),
                errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1794,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1777,
                columnNumber: 15
              }, this),
              paymentModePayment === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("h5", { className: "text-base font-semibold text-gray-900 mb-3", children: "Cheque Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1802,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                      "Cheque Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1808,
                        columnNumber: 39
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1807,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "cheque_number",
                        id: "cheque_number",
                        value: payoutData.cheque_number,
                        onChange: handleChangePayment,
                        placeholder: "Enter Cheque Number",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1810,
                        columnNumber: 23
                      },
                      this
                    ),
                    errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1820,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1806,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                      "Cheque Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1828,
                        columnNumber: 37
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1827,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        name: "cheque_date",
                        id: "cheque_date",
                        value: payoutData?.cheque_date?.split("T")[0],
                        onChange: handleChangePayment,
                        placeholder: "Enter Cheque Date",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1830,
                        columnNumber: 23
                      },
                      this
                    ),
                    errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1840,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1826,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1847,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "cheque_bank_name",
                        id: "cheque_bank_name",
                        value: payoutData.cheque_bank_name,
                        onChange: handleChangePayment,
                        placeholder: "Enter Bank Name",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1850,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1846,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1862,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        name: "cheque_bank_branch",
                        id: "cheque_bank_branch",
                        value: payoutData.cheque_bank_branch,
                        onChange: handleChangePayment,
                        placeholder: "Enter Bank Branch",
                        className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                        lineNumber: 1865,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1861,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1805,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1801,
                columnNumber: 15
              }, this),
              showOthersField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "othersField",
                      children: "Others"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1882,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: " border border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                      id: "othersField",
                      name: "disbursement_type",
                      value: disbursementType,
                      placeholder: "Specify if your option is not listed above",
                      onChange: handleDisbursementTypeChange
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1888,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1881,
                  columnNumber: 19
                }, this),
                errors.disbursement_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.disbursement_type }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1899,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1880,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "note",
                    children: "Note"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1907,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    rows: 2,
                    type: "text",
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    id: "note",
                    name: "note",
                    value: payoutData.note,
                    placeholder: "Note if any?",
                    onChange: handleChangePayment
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1913,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1906,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-violet-50 p-3 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Disbursed By" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1926,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: adminName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1929,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1925,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1924,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between w-full", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "checkbox",
                      checked: whatsappEnabled,
                      onChange: (e) => setWhatsappEnabled(e.target.checked),
                      className: "w-4 h-4 accent-green-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                      lineNumber: 1936,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm", children: "Send via WhatsApp" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1943,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1935,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 text-green-600", children: [
                  /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { className: "w-6 h-6" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1950,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium", children: "WhatsApp" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1951,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1949,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1933,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setShowPayoutModal(false);
                      setSelectedGroup("");
                      setSelectedTicketValue(null);
                      setPayoutData({
                        user_id: "",
                        pay_date: today,
                        amount: "",
                        pay_type: "cash",
                        transaction_id: "",
                        cheque_number: "",
                        cheque_date: "",
                        cheque_bank_name: "",
                        cheque_bank_branch: "",
                        disbursement_type: "",
                        note: ""
                      });
                    },
                    className: "px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1955,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Tooltip, { title: "Saving Payment Out", children: /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    onClick: (e) => handleSubmitPaymentout(e),
                    className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Save Payment Out"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                    lineNumber: 1980,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                  lineNumber: 1979,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
                lineNumber: 1954,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
              lineNumber: 1571,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
            lineNumber: 1567,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
          lineNumber: 1555,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
      lineNumber: 974,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx",
    lineNumber: 952,
    columnNumber: 5
  }, this);
};
_s(GeneralPaymentOut, "5ghdp3URhZ65PRisMQV8CcjMfOw=");
_c = GeneralPaymentOut;
export default GeneralPaymentOut;
var _c;
$RefreshReg$(_c, "GeneralPaymentOut");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GeneralPaymentOut.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd1gwQixTQXV1Qk4sVUF2dUJNOzJCQXhYMUI7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxRQUFRQyxRQUFRQyxPQUFPQyxlQUFlO0FBQy9DLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLGdCQUFnQkMsMEJBQTBCO0FBQ25ELFNBQVNDLGFBQWFDLHdCQUF3QjtBQUM5QyxPQUFPQyxnQkFBZ0I7QUFDdkIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFlBQVk7QUFDckIsT0FBT0MsMEJBQTBCO0FBRWpDLE1BQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJM0IsU0FBUyxTQUFTO0FBQ3BELFFBQU0sQ0FBQzRCLGFBQWFDLGNBQWMsSUFBSTdCLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUM4QixRQUFRQyxTQUFTLElBQUkvQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDZ0MsZUFBZUMsZ0JBQWdCLElBQUlqQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDa0MsYUFBYUMsY0FBYyxJQUFJbkMsU0FBUyxNQUFNO0FBQ3JELFFBQU0sQ0FBQ29DLHNCQUFzQkMsdUJBQXVCLElBQUlyQyxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDc0MsaUJBQWlCQyxrQkFBa0IsSUFBSXZDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUN3QyxlQUFlQyxnQkFBZ0IsSUFBSXpDLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUMwQyxTQUFTQyxVQUFVLElBQUkzQyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDNEMsd0JBQXdCQyx5QkFBeUIsSUFBSTdDLFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUM4QyxpQkFBaUJDLGtCQUFrQixJQUFJL0MsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2dELGlCQUFpQkMsa0JBQWtCLElBQUlqRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDa0Qsb0JBQW9CQyxxQkFBcUIsSUFBSW5ELFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUNvRCxRQUFRQyxTQUFTLElBQUlyRCxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNzRCxRQUFRQyxTQUFTLElBQUl2RCxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN3RCxXQUFXQyxZQUFZLElBQUl6RCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMEQsWUFBWUMsYUFBYSxJQUFJM0QsU0FBUyxFQUFFO0FBQy9DLFFBQU00RCxTQUFRLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNuRCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJakUsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ2tFLFdBQVdDLFlBQVksSUFBSW5FLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNvRSxrQkFBa0JDLG1CQUFtQixJQUFJckUsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ3NFLGdCQUFnQkMsaUJBQWlCLElBQUl2RSxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDd0UsVUFBVUMsV0FBVyxJQUFJekUsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzBFLG9CQUFvQkMscUJBQXFCLElBQUkzRSxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDNEUscUJBQXFCQyxzQkFBc0IsSUFBSTdFLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUM4RSw0QkFBNEJDLDZCQUE2QixJQUFJL0U7QUFBQUEsSUFDbEU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxDQUFDZ0Ysa0JBQWtCQyxtQkFBbUIsSUFBSWpGLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNrRixpQkFBaUJDLGtCQUFrQixJQUFJbkYsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ29GLGFBQWFDLGNBQWMsSUFBSXJGLFNBQVMsd0JBQXdCO0FBQ3ZFLFFBQU0sQ0FBQ3NGLFVBQVVDLFdBQVcsSUFBSXZGLFNBQVMsQ0FBQztBQUMxQyxRQUFNLENBQUN3RixtQkFBbUJDLG9CQUFvQixJQUFJekYsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQzBGLGVBQWVDLGdCQUFnQixJQUFJM0YsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzRGLGlCQUFpQkMsa0JBQWtCLElBQUk3RixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDOEYsaUJBQWlCQyxrQkFBa0IsSUFBSS9GLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNnRyxxQkFBcUJDLHNCQUFzQixJQUFJakcsU0FBUyxJQUFJO0FBQ25FLFFBQU0sQ0FBQ2tHLGlCQUFpQkMsa0JBQWtCLElBQUluRyxTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDb0csT0FBT0MsUUFBUSxJQUFJckcsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3NHLFdBQVdDLFlBQVksSUFBSXZHLFNBQVMsQ0FBQyxDQUFDO0FBQzdDLFFBQU0sQ0FBQ3dHLG9CQUFvQkMscUJBQXFCLElBQUl6RyxTQUFTLE1BQU07QUFDbkUsUUFBTSxDQUFDMEcsZUFBZUMsZ0JBQWdCLElBQUkzRyxTQUFTLEVBQUU7QUFFckQsUUFBTSxDQUFDNEcsYUFBYUMsY0FBYyxJQUFJN0csU0FBUztBQUFBLElBQzdDOEcsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlsSCxTQUFTO0FBQUEsSUFDdkNtSCxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFVBQVV6RDtBQUFBQSxJQUNWMEQsUUFBUTtBQUFBLElBQ1JDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGVBQWU7QUFBQSxJQUNmQyxhQUFhO0FBQUEsSUFDYkMsa0JBQWtCO0FBQUEsSUFDbEJDLG9CQUFvQjtBQUFBLElBQ3BCQyxtQkFBbUI7QUFBQSxJQUNuQkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJakksU0FBUztBQUFBLElBQzNDb0gsU0FBUztBQUFBLElBRVRDLFVBQVV6RDtBQUFBQSxJQUNWMkQsUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZUFBZTtBQUFBLElBQ2ZDLGFBQWE7QUFBQSxJQUNiQyxrQkFBa0I7QUFBQSxJQUNsQkMsb0JBQW9CO0FBQUEsSUFDcEJLLHVCQUF1QjtBQUFBLElBQ3ZCSixtQkFBbUI7QUFBQSxJQUNuQkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU1JLG9CQUFvQjtBQUFBLElBQ3hCO0FBQUEsTUFDRUMsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFRixLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VGLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUVBO0FBQUEsTUFDRUYsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFRixLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VGLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRUYsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFRixLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VGLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRUYsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFHSCxRQUFNQyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekM3RSxrQkFBYzZFLEVBQUVDLE9BQU9ILEtBQUs7QUFBQSxFQUM5QjtBQUVBLFFBQU1JLDRCQUE0QkEsQ0FBQ0osVUFBVTtBQUMzQ3JDLDJCQUF1QnFDLEtBQUs7QUFDNUJ2RCxrQ0FBOEJ1RCxLQUFLO0FBQUEsRUFDckM7QUFFQSxRQUFNSyxpQ0FBaUNBLENBQUNILE1BQU07QUFDNUMsVUFBTUksT0FBT0osRUFBRUMsT0FBT0g7QUFFdEI3QiwwQkFBc0JtQyxJQUFJO0FBRTFCWCxrQkFBYyxDQUFDWSxVQUFVO0FBQUEsTUFDdkIsR0FBR0E7QUFBQUEsTUFDSHJCLFVBQVVvQjtBQUFBQSxNQUNWbkIsZ0JBQWdCbUIsU0FBUyxXQUFXQyxLQUFLcEIsaUJBQWlCO0FBQUEsSUFDNUQsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNcUIsMEJBQTBCQSxDQUFDTixNQUFNO0FBQ3JDLFVBQU1PLGVBQWVQLEVBQUVDLE9BQU9IO0FBQzlCbkcsbUJBQWU0RyxZQUFZO0FBQzNCN0IsZ0JBQVksQ0FBQzJCLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIckIsVUFBVXVCO0FBQUFBLE1BQ1Z0QixnQkFBZ0JzQixpQkFBaUIsV0FBV0YsS0FBS3BCLGlCQUFpQjtBQUFBLElBQ3BFLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTXVCLG9CQUFvQixPQUFPdEcsYUFBWTtBQUMzQ0QscUJBQWlCQyxRQUFPO0FBRXhCLFFBQUlBLFVBQVM7QUFDWCxVQUFJO0FBQ0YsY0FBTXVHLFdBQVcsTUFBTS9JLElBQUlnSixJQUFJLDRCQUE0QnhHLFFBQU8sRUFBRTtBQUNwRSxZQUFJdUcsU0FBU0UsUUFBUUYsU0FBU0UsS0FBS0MsU0FBUyxHQUFHO0FBQzdDekMsMkJBQWlCc0MsU0FBU0UsSUFBSTtBQUFBLFFBQ2hDLE9BQU87QUFDTHhDLDJCQUFpQixFQUFFO0FBQUEsUUFDckI7QUFBQSxNQUNGLFNBQVMwQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RDFDLHlCQUFpQixFQUFFO0FBQUEsTUFDckI7QUFBQSxJQUNGLE9BQU87QUFDTEEsdUJBQWlCLEVBQUU7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEMseUJBQXlCQSxDQUFDQyxXQUFXO0FBQ3pDM0UsMkJBQXVCMkUsTUFBTTtBQUM3QnZELDJCQUF1QnVELE1BQU07QUFBQSxFQUMvQjtBQUVBLFFBQU1DLHdCQUF3QixPQUFPQyxXQUFXO0FBQzlDakgscUJBQWlCaUgsTUFBTTtBQUV2QnpCLGtCQUFjLENBQUNZLFVBQVU7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNIekIsU0FBU3NDO0FBQUFBLElBQ1gsRUFBRTtBQUVGekQsMkJBQXVCLElBQUk7QUFDM0JwQiwyQkFBdUIsRUFBRTtBQUV6QnRCLGNBQVUsQ0FBQ3NGLFVBQVU7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNIYyxVQUFVO0FBQUEsTUFDVnpCLHVCQUF1QjtBQUFBLElBQ3pCLEVBQUU7QUFFRmMsc0JBQWtCVSxNQUFNO0FBQ3hCRSwwQkFBc0JGLE1BQU07QUFBQSxFQUM5QjtBQUVBLFFBQU1HLGVBQWVBLENBQUNyQixNQUFNO0FBQzFCLFVBQU0sRUFBRXNCLE1BQU14QixNQUFNLElBQUlFLEVBQUVDO0FBQzFCLFFBQUlxQixTQUFTLHFCQUFxQjtBQUNoQyxVQUFJeEIsVUFBVSxVQUFVO0FBQ3RCbkQsMkJBQW1CLElBQUk7QUFDdkJGLDRCQUFvQixFQUFFO0FBQUEsTUFDeEIsT0FBTztBQUNMRSwyQkFBbUIsS0FBSztBQUN4QkYsNEJBQW9CcUQsS0FBSztBQUFBLE1BQzNCO0FBQUEsSUFDRjtBQUNBcEIsZ0JBQVksQ0FBQzJCLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNpQixJQUFJLEdBQUd4QixNQUFNLEVBQUU7QUFDbEQvRSxjQUFVLENBQUNzRixVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDaUIsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQy9DO0FBQ0EsUUFBTUMsc0JBQXNCQSxDQUFDdkIsTUFBTTtBQUNqQyxVQUFNLEVBQUVzQixNQUFNeEIsTUFBTSxJQUFJRSxFQUFFQztBQUMxQixRQUFJcUIsU0FBUyxxQkFBcUI7QUFDaEMsVUFBSXhCLFVBQVUsVUFBVTtBQUN0Qm5ELDJCQUFtQixJQUFJO0FBQ3ZCRiw0QkFBb0IsRUFBRTtBQUFBLE1BQ3hCLE9BQU87QUFDTEUsMkJBQW1CLEtBQUs7QUFBQSxNQUMxQjtBQUFBLElBQ0Y7QUFDQThDLGtCQUFjLENBQUMrQixjQUFjO0FBQUEsTUFDM0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixJQUFJLEdBQUd4QjtBQUFBQSxJQUNWLEVBQUU7QUFDRi9FLGNBQVUsQ0FBQ3lHLGNBQWMsRUFBRSxHQUFHQSxVQUFVLENBQUNGLElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUN2RDtBQUVBLFFBQU1HLGVBQWVBLE1BQU07QUFDekIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQzVILGdCQUFpQjRILFdBQVVQLFdBQVc7QUFDM0MsUUFBSSxDQUFDMUMsU0FBU0s7QUFDWjRDLGdCQUFVaEMsd0JBQXdCO0FBQ3BDLFFBQUksQ0FBQ2pCLFNBQVNJLFNBQVU2QyxXQUFVN0MsV0FBVztBQUU3QyxVQUFNRSxTQUFTNEMsV0FBV2xELFNBQVNNLE1BQU07QUFDekMsUUFBSTZDLE1BQU03QyxNQUFNLEtBQUtBLFVBQVU7QUFDN0IyQyxnQkFBVTNDLFNBQVM7QUFFckIsUUFBSXJGLGdCQUFnQixZQUFZLENBQUMrRSxTQUFTUSxnQkFBZ0I0QyxLQUFLO0FBQzdESCxnQkFBVXpDLGlCQUNSO0FBQ0osUUFBSXZGLGdCQUFnQixZQUFZLENBQUMrRSxTQUFTVSxhQUFhMEMsS0FBSyxHQUFHO0FBQzdESCxnQkFBVXZDLGNBQWM7QUFBQSxJQUMxQjtBQUNBLFFBQUl6RixnQkFBZ0IsWUFBWSxDQUFDK0UsU0FBU1MsZUFBZTJDLEtBQUssR0FBRztBQUMvREgsZ0JBQVV4QyxnQkFBZ0I7QUFBQSxJQUM1QjtBQUNBLFFBQUksQ0FBQ1QsU0FBU2E7QUFDWm9DLGdCQUFVcEMsb0JBQW9CO0FBRWhDdkUsY0FBVTJHLFNBQVM7QUFDbkIsV0FBT0ksT0FBT0MsS0FBS0wsU0FBUyxFQUFFZCxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNb0Isc0JBQXNCQSxNQUFNO0FBQ2hDLFVBQU1OLFlBQVksQ0FBQztBQUVuQixRQUFJLENBQUMxSCxlQUFlO0FBQ2xCMEgsZ0JBQVVQLFdBQVc7QUFBQSxJQUN2QjtBQUNBLFFBQUksQ0FBQzNELHFCQUFxQjtBQUN4QmtFLGdCQUFVaEMsd0JBQXdCO0FBQUEsSUFDcEM7QUFFQSxRQUFJLENBQUNGLFdBQVdYLFVBQVU7QUFDeEI2QyxnQkFBVTdDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFVBQU1FLFNBQVM0QyxXQUFXbkMsV0FBV1QsTUFBTTtBQUMzQyxRQUFJNkMsTUFBTTdDLE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQ2hDMkMsZ0JBQVUzQyxTQUFTO0FBQUEsSUFDckI7QUFFQSxRQUFJZix1QkFBdUIsWUFBWSxDQUFDd0IsV0FBV1AsZ0JBQWdCNEMsS0FBSyxHQUFHO0FBQ3pFSCxnQkFBVXpDLGlCQUFpQjtBQUFBLElBQzdCO0FBQ0EsUUFBSWpCLHVCQUF1QixZQUFZLENBQUN3QixXQUFXTCxhQUFhMEMsS0FBSyxHQUFHO0FBQ3RFSCxnQkFBVXZDLGNBQWM7QUFBQSxJQUMxQjtBQUNBLFFBQUluQix1QkFBdUIsWUFBWSxDQUFDd0IsV0FBV04sZUFBZTJDLEtBQUssR0FBRztBQUN4RUgsZ0JBQVV4QyxnQkFBZ0I7QUFBQSxJQUM1QjtBQU1BbkUsY0FBVTJHLFNBQVM7QUFDbkIsV0FBT0ksT0FBT0MsS0FBS0wsU0FBUyxFQUFFZCxXQUFXO0FBQUEsRUFDM0M7QUFHQSxRQUFNcUIscUJBQXFCLFlBQVk7QUFDckM1RSx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YsWUFBTSxFQUFFc0QsS0FBSyxJQUFJLE1BQU1qSixJQUFJZ0osSUFBSSxpQ0FBaUM7QUFFaEUsVUFBSUMsTUFBTXVCLFdBQVdDLE1BQU1DLFFBQVF6QixNQUFNQSxJQUFJLEdBQUc7QUFDOUMsY0FBTTBCLG1CQUFtQjFCLEtBQUtBLEtBQzNCMkIsT0FBTyxDQUFDQyxXQUFXO0FBQ2xCLGdCQUFNakIsT0FBT2lCLE9BQU8zRCxTQUFTNEQsV0FBV1gsS0FBSyxLQUFLO0FBQ2xELGdCQUFNWSxRQUFRRixPQUFPM0QsU0FBUzhELGNBQWNiLEtBQUssS0FBSztBQUN0RCxpQkFDRVAsU0FBUyxNQUFNQSxTQUFTLFNBQVNtQixVQUFVLE1BQU1BLFVBQVU7QUFBQSxRQUUvRCxDQUFDLEVBQ0FFLElBQUksQ0FBQ0osUUFBUUssV0FBVztBQUFBLFVBQ3ZCQyxLQUFLTixPQUFPTTtBQUFBQSxVQUNaQyxJQUFJRixRQUFRO0FBQUEsVUFDWkcsTUFBTVIsT0FBT1MsZUFDVCxJQUFJM0gsS0FBS2tILE9BQU9TLFlBQVksRUFBRUMsbUJBQW1CLFNBQVM7QUFBQSxZQUN4REMsS0FBSztBQUFBLFlBQ0xDLE9BQU87QUFBQSxZQUNQQyxNQUFNO0FBQUEsVUFDUixDQUFDLElBQ0Q7QUFBQSxVQUNKOUIsTUFBTWlCLE9BQU8zRCxTQUFTNEQsYUFBYTtBQUFBLFVBQ25DRSxjQUFjSCxPQUFPM0QsU0FBUzhELGdCQUFnQjtBQUFBLFVBQzlDNUQsUUFBUXlELE9BQU96RCxVQUFVO0FBQUEsVUFDekJ1RSxhQUNHQyxTQUFTZixPQUFPZ0IsUUFBUSxLQUFLLE1BQzdCRCxTQUFTZixPQUFPaUIsVUFBVSxLQUFLO0FBQUEsVUFDbEN6RSxRQUFRd0QsT0FBT2tCLGNBQWM7QUFBQSxVQUM3QkMsY0FBY25CLE9BQU9tQixnQkFBZ0I7QUFBQTtBQUFBLFVBRXJDQyxZQUFZcEIsT0FBTzVELFVBQVVnRixjQUFjO0FBQUEsVUFDM0NDLGFBQWFyQixPQUFPNUQsVUFBVWlGLGVBQWU7QUFBQSxVQUM3Q0MsY0FBY3RCLE9BQU9zQixnQkFBZ0I7QUFBQSxVQUNyQ2xGLFVBQVU0RCxPQUFPNUQsVUFBVWtFLE9BQU9OLE9BQU9NO0FBQUFBO0FBQUFBLFVBQ3pDakUsU0FBUzJELE9BQU8zRCxTQUFTaUU7QUFBQUEsVUFDekJZLFlBQVlsQixPQUFPa0IsY0FBYztBQUFBLFVBQ2pDSyxZQUFZdkIsT0FBT007QUFBQUE7QUFBQUEsVUFDbkJrQixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxDQUFDLE9BQU87QUFBQSxjQUNqQixNQUFNO0FBQUEsZ0JBQ0pDLE9BQU87QUFBQSxrQkFDTDtBQUFBLG9CQUNFcEUsS0FBSztBQUFBLG9CQUNMcUUsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUNQQztBQUFBQSwwQkFDRTNCLE9BQU81RCxVQUFVa0UsT0FBT04sT0FBT007QUFBQUEsMEJBQy9CTixPQUFPM0QsU0FBU2lFO0FBQUFBLDBCQUNoQk4sT0FBT3pEO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRWMsS0FBSztBQUFBLG9CQUNMcUUsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNRSxrQkFBa0I1QixPQUFPTSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLHNDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBO0FBQUEsWUFwQ3hEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFDQSxLQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVDQTtBQUFBLFFBRUosRUFBRTtBQUNKMUYseUJBQWlCa0YsZ0JBQWdCO0FBQUEsTUFDbkMsT0FBTztBQUNMbEYseUJBQWlCLEVBQUU7QUFBQSxNQUNyQjtBQUFBLElBQ0YsU0FBUzBELE9BQU87QUFDZEMsY0FBUUQsTUFBTSxrQ0FBa0NBLEtBQUs7QUFDckQxRCx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCLFVBQUM7QUFDQ0UseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNkcsNkJBQTZCLE9BQU9oSyxVQUFTZ0gsUUFBUXBDLFdBQVc7QUFDcEUsUUFBSSxDQUFDb0MsVUFBVSxDQUFDaEgsWUFBVyxDQUFDNEUsUUFBUTtBQUNsQ2pILFlBQU11TSxRQUFRO0FBQUEsUUFDWnZFLE9BQU87QUFBQSxRQUNQd0UsU0FBUztBQUFBLE1BQ1gsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNLEVBQUUxRCxLQUFLLElBQUksTUFBTWpKLElBQUlnSjtBQUFBQSxRQUN6QjtBQUFBLFFBQ0EsRUFBRTRELFFBQVEsRUFBRTFGLFNBQVNzQyxRQUFRdkMsVUFBVXpFLFVBQVM0RSxPQUFPLEVBQUU7QUFBQSxNQUMzRDtBQUNBL0Msd0JBQWtCO0FBQUEsUUFDaEJ3SSxjQUFjNUQsS0FBSy9CLFNBQVM0RDtBQUFBQSxRQUM1QmdDLFdBQVc3RCxLQUFLaEMsVUFBVWdGO0FBQUFBLFFBQzFCYyxXQUFXOUQsS0FBSzhDO0FBQUFBLE1BQ2xCLENBQUM7QUFDRC9FLGtCQUFZLENBQUMyQixVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSDFCLFVBQVVnQyxLQUFLaEMsVUFBVWtFO0FBQUFBLFFBQ3pCakUsU0FBU3NDO0FBQUFBLFFBQ1RuQyxRQUFRNEIsS0FBSzhDO0FBQUFBLFFBQ2IzRTtBQUFBQSxNQUNGLEVBQUU7QUFDRi9FLHlCQUFtQkcsUUFBTztBQUMxQjJCLDBCQUFvQixJQUFJO0FBQUEsSUFDMUIsU0FBU2dGLE9BQU87QUFDZCxZQUFNNkQsTUFBTTdELE9BQU9KLFVBQVVFLE1BQU1wQztBQUNuQyxVQUFJc0MsTUFBTUosVUFBVWtFLFdBQVcsT0FBT0QsUUFBUSxxQkFBcUI7QUFDakU3TSxjQUFNdU0sUUFBUTtBQUFBLFVBQ1p2RSxPQUFPO0FBQUEsVUFDUHdFLFNBQ0U7QUFBQSxRQUNKLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTHhNLGNBQU1nSixNQUFNO0FBQUEsVUFDVmhCLE9BQU87QUFBQSxVQUNQd0UsU0FBUztBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1GLG9CQUFvQixPQUFPUyxjQUFjO0FBQzdDLFFBQUk7QUFDRixZQUFNLEVBQUVqRSxLQUFLLElBQUksTUFBTWpKLElBQUlnSixJQUFJLDhCQUE4QmtFLFNBQVMsRUFBRTtBQUN4RWpLLDRCQUFzQmdHLElBQUk7QUFDMUJsRyx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNvRyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REaEosWUFBTWdKLE1BQU07QUFBQSxRQUNWaEIsT0FBTztBQUFBLFFBQ1B3RSxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNUSxtQkFBbUJBLE1BQU07QUFDN0I1SCx5QkFBcUIsS0FBSztBQUMxQjVDLDhCQUEwQixFQUFFO0FBQzVCUiw0QkFBd0IsRUFBRTtBQUMxQkoscUJBQWlCLEVBQUU7QUFDbkJjLHVCQUFtQixFQUFFO0FBQUEsRUFDdkI7QUFFQXVLLFlBQVUsTUFBTTtBQUNkLFVBQU1DLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTSxFQUFFcEUsS0FBSyxJQUFJLE1BQU1qSixJQUFJZ0osSUFBSSx3QkFBd0I7QUFDdkRuSCxrQkFBVW9ILElBQUk7QUFBQSxNQUNoQixTQUFTcUUsS0FBSztBQUNabEUsZ0JBQVFELE1BQU1tRSxHQUFHO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQ0FELGdCQUFZO0FBRVo5Qyx1QkFBbUI7QUFBQSxFQUNyQixHQUFHLEVBQUU7QUFFTDZDLFlBQVUsTUFBTTtBQUNkLFVBQU1DLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTXRFLFdBQVcsTUFBTS9JLElBQUlnSixJQUFJLGdCQUFnQjtBQUMvQzdDLGlCQUFTNEMsU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVNFLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FrRSxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDM0csV0FBVyxDQUFDO0FBRWhCMEcsWUFBVSxNQUFNO0FBQ2QsVUFBTUcsT0FBT0MsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxNQUFNLEtBQUssSUFBSTtBQUM1RDFKLGlCQUFhc0osS0FBSzNELFFBQVEsRUFBRTtBQUM1QixVQUFNZ0UsVUFDSkwsTUFBTU0sdUJBQXVCQyxvQkFBb0JDLGlCQUFpQjtBQUNwRWhLLHFCQUFpQjZKLE9BQU87QUFBQSxFQUMxQixHQUFHLEVBQUU7QUFFTFIsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDMUssdUJBQXdCO0FBQzdCLFVBQU1zTCxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU0sRUFBRS9FLEtBQUssSUFBSSxNQUFNakosSUFBSWdKO0FBQUFBLFVBQ3pCLHNCQUFzQnRHLHNCQUFzQjtBQUFBLFFBQzlDO0FBQ0FTLGtCQUFVOEYsSUFBSTtBQUFBLE1BQ2hCLFNBQVNxRSxLQUFLO0FBQ1psRSxnQkFBUUQsTUFBTW1FLEdBQUc7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFDQVUsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ3RMLHNCQUFzQixDQUFDO0FBRTNCLFFBQU1nSCx3QkFBd0IsT0FBT2xILGFBQVk7QUFDL0MsUUFBSUEsVUFBUztBQUNYLFVBQUk7QUFDRixjQUFNdUcsV0FBVyxNQUFNL0ksSUFBSWlPO0FBQUFBLFVBQ3pCLG1DQUFtQ3pMLFFBQU87QUFBQSxRQUM1QztBQUNBLFlBQUl1RyxTQUFTRSxRQUFRRixTQUFTRSxLQUFLQyxTQUFTLEdBQUc7QUFDN0MsZ0JBQU1nRixnQkFBZ0JuRixTQUFTRSxLQUFLMkI7QUFBQUEsWUFDbEMsQ0FBQ3VELFlBQVlBLFFBQVFDLGNBQWNELFFBQVFDLFdBQVdDO0FBQUFBLFVBQ3hEO0FBQ0F4TCw2QkFBbUJxTCxhQUFhO0FBQUEsUUFDbEMsT0FBTztBQUNMckwsNkJBQW1CLEVBQUU7QUFBQSxRQUN2QjtBQUFBLE1BQ0YsU0FBU3NHLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REdEcsMkJBQW1CLEVBQUU7QUFBQSxNQUN2QjtBQUFBLElBQ0YsT0FBTztBQUNMQSx5QkFBbUIsRUFBRTtBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU15TCxxQkFBcUJBLENBQUM5TCxhQUFZO0FBQ3RDRyw4QkFBMEJILFFBQU87QUFDakMrTCw2QkFBeUIvTCxRQUFPO0FBQUEsRUFDbEM7QUFFQSxRQUFNK0wsMkJBQTJCLE9BQU8vTCxhQUFZO0FBQ2xETCw0QkFBd0JLLFFBQU87QUFDL0IsUUFBSSxDQUFDQSxVQUFTO0FBQ1pLLHlCQUFtQixFQUFFO0FBQ3JCO0FBQUEsSUFDRjtBQUVBZCxxQkFBaUIsRUFBRTtBQUNuQndCLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU0sRUFBRTBGLEtBQUssSUFBSSxNQUFNakosSUFBSWdKLElBQUksMkJBQTJCeEcsUUFBTyxFQUFFO0FBQ25FLFVBQUl5RyxNQUFNQyxRQUFRO0FBQ2hCckcsMkJBQW1Cb0csSUFBSTtBQUN2QixjQUFNdUYsWUFBWTtBQUFBLFVBQ2hCO0FBQUEsWUFDRXBELElBQUk7QUFBQSxZQUNKQyxNQUFNLElBQUkxSDtBQUFBQSxjQUNSLElBQUlBLEtBQUtzRixLQUFLLENBQUMsRUFBRXFDLFlBQVksRUFBRW1ELFFBQVEsSUFBSSxLQUFLO0FBQUEsWUFDbEQsRUFDR2xELG1CQUFtQixTQUFTO0FBQUEsY0FDM0JDLEtBQUs7QUFBQSxjQUNMQyxPQUFPO0FBQUEsY0FDUEMsTUFBTTtBQUFBLFlBQ1IsQ0FBQyxFQUNBZ0QsUUFBUSxLQUFLLEVBQUU7QUFBQSxZQUNsQjlFLE1BQU07QUFBQSxZQUNOb0IsY0FBYztBQUFBLFlBQ2Q1RCxRQUFRO0FBQUEsWUFDUnVFLFlBQVk7QUFBQSxZQUNadEUsUUFBUTtBQUFBLFlBQ1IyRSxjQUFjO0FBQUEsWUFDZGlCLFFBQVE7QUFBQSxZQUNSWixRQUFRO0FBQUEsVUFDVjtBQUFBLFVBQ0EsR0FBR3BELEtBQUtnQyxJQUFJLENBQUMwRCxHQUFHQyxTQUFTO0FBQUEsWUFDdkJ6RCxLQUFLd0QsRUFBRXhEO0FBQUFBLFlBQ1BDLElBQUl3RCxNQUFNO0FBQUEsWUFDVnZELE1BQU0sSUFBSTFILEtBQUtnTCxFQUFFckQsWUFBWSxFQUFFQyxtQkFBbUIsU0FBUztBQUFBLGNBQ3pEQyxLQUFLO0FBQUEsY0FDTEMsT0FBTztBQUFBLGNBQ1BDLE1BQU07QUFBQSxZQUNSLENBQUM7QUFBQSxZQUNEOUIsTUFBTStFLEVBQUV6SCxTQUFTNEQ7QUFBQUEsWUFDakJFLGNBQWMyRCxFQUFFekgsU0FBUzhEO0FBQUFBLFlBQ3pCNUQsUUFBUXVILEVBQUV2SDtBQUFBQSxZQUNWdUUsWUFBWWtELE9BQU9GLEVBQUU5QyxRQUFRLElBQUlnRCxPQUFPRixFQUFFN0MsVUFBVTtBQUFBLFlBQ3BEekUsUUFBUXNILEVBQUU1QztBQUFBQSxZQUNWQyxjQUNFMkMsRUFBRTNDLGFBQWE4QyxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUNyQ0osRUFBRTNDLGFBQWFnRCxNQUFNLENBQUMsSUFDdEI7QUFBQSxZQUNGL0IsUUFBUSxDQUFDMEIsR0FBR00sV0FDUixjQUNBTixHQUFHTSxhQUFhLFNBQ2QsV0FDQTtBQUFBLFlBQ041QyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsZ0JBQ2pCLE1BQU07QUFBQSxrQkFDSkMsT0FBTztBQUFBLG9CQUNMO0FBQUEsc0JBQ0VwRSxLQUFLO0FBQUEsc0JBQ0w1RCxVQUFVLENBQUNxSyxHQUFHekgsU0FBU2lFLE9BQU8sQ0FBQ3dELEdBQUcxSCxVQUFVa0U7QUFBQUEsc0JBQzVDb0IsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUNQMkM7QUFBQUEsNEJBQ0VQLEVBQUUxSCxVQUFVa0U7QUFBQUEsNEJBQ1p3RCxFQUFFekgsU0FBU2lFO0FBQUFBLDRCQUNYd0QsRUFBRXZIO0FBQUFBLDBCQUNKO0FBQUEsMEJBQ0Q7QUFBQTtBQUFBLHdCQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFXQTtBQUFBLG9CQUVKO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRWMsS0FBSztBQUFBLHNCQUNMcUUsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUNQNEMsc0JBQXNCUixFQUFFeEQsS0FBS3lELE1BQU0sQ0FBQztBQUFBLDBCQUNyQztBQUFBO0FBQUEsd0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU9BO0FBQUEsb0JBRUo7QUFBQSxrQkFBQztBQUFBLGdCQUVMO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLFlBQVMsV0FBVSxzQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQTtBQUFBLGNBdkN4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3Q0EsS0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQ0E7QUFBQSxVQUVKLEVBQUU7QUFBQSxRQUFDO0FBRUw3TSx5QkFBaUJ5TSxTQUFTO0FBQUEsTUFDNUIsT0FBTztBQUNMM0wsMkJBQW1CLEVBQUU7QUFDckJkLHlCQUFpQixFQUFFO0FBQUEsTUFDckI7QUFBQSxJQUNGLFNBQVN1TCxLQUFLO0FBQ1psRSxjQUFRRCxNQUFNbUUsR0FBRztBQUNqQnpLLHlCQUFtQixFQUFFO0FBQ3JCZCx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCLFVBQUM7QUFDQ3dCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkwsbUJBQW1CLE9BQU8xTSxVQUFTZ0gsUUFBUXBDLFdBQVc7QUFDMUQsUUFBSSxDQUFDb0MsVUFBVSxDQUFDaEgsWUFBVyxDQUFDNEUsT0FBUTtBQUNwQyxRQUFJO0FBQ0YsWUFBTSxFQUFFNkIsS0FBSyxJQUFJLE1BQU1qSixJQUFJZ0o7QUFBQUEsUUFDekI7QUFBQSxRQUNBLEVBQUU0RCxRQUFRLEVBQUUxRixTQUFTc0MsUUFBUXZDLFVBQVV6RSxVQUFTNEUsT0FBTyxFQUFFO0FBQUEsTUFDM0Q7QUFDQS9DLHdCQUFrQjtBQUFBLFFBQ2hCd0ksY0FBYzVELEtBQUsvQixTQUFTNEQ7QUFBQUEsUUFDNUJnQyxXQUFXN0QsS0FBS2hDLFVBQVVnRjtBQUFBQSxRQUMxQmMsV0FBVzlELEtBQUs4QztBQUFBQSxNQUNsQixDQUFDO0FBQ0QvRSxrQkFBWSxDQUFDMkIsVUFBVTtBQUFBLFFBQ3JCLEdBQUdBO0FBQUFBLFFBQ0gxQixVQUFVZ0MsS0FBS2hDLFVBQVVrRTtBQUFBQSxRQUN6QmpFLFNBQVNzQztBQUFBQSxRQUNUbkMsUUFBUTRCLEtBQUs4QztBQUFBQSxRQUNiM0U7QUFBQUEsTUFDRixFQUFFO0FBQ0YvRSx5QkFBbUJHLFFBQU87QUFDMUIyQiwwQkFBb0IsSUFBSTtBQUFBLElBQzFCLFNBQVNnRixPQUFPO0FBQ2QsWUFBTTZELE1BQU03RCxPQUFPSixVQUFVRSxNQUFNcEM7QUFDbkMsVUFBSXNDLE1BQU1KLFVBQVVrRSxXQUFXLE9BQU9ELFFBQVEscUJBQXFCO0FBQ2pFN00sY0FBTXVNLFFBQVE7QUFBQSxVQUNadkUsT0FBTztBQUFBLFVBQ1B3RSxTQUNFO0FBQUEsUUFDSixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0x4TSxjQUFNZ0osTUFBTTtBQUFBLFVBQ1ZoQixPQUFPO0FBQUEsVUFDUHdFLFNBQVM7QUFBQSxRQUNYLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0Msd0JBQXdCLE9BQU8zTSxVQUFTNE0sT0FBTztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxFQUFFbkcsS0FBSyxJQUFJLE1BQU1qSixJQUFJZ0osSUFBSSw4QkFBOEJ4RyxRQUFPLEVBQUU7QUFDdEVTLDRCQUFzQixFQUFFLEdBQUdnRyxNQUFNb0csV0FBV0QsR0FBRyxDQUFDO0FBQ2hEck0seUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTdUssS0FBSztBQUNabEUsY0FBUUQsTUFBTW1FLEdBQUc7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0MsZUFBZSxPQUFPaEgsTUFBTTtBQUNoQ0EsTUFBRWlILGVBQWU7QUFDakIsVUFBTUMsVUFBVXpGLGFBQWE7QUFFN0IsUUFBSSxDQUFDeUYsUUFBUztBQUVkLFFBQUk7QUFDRmpMLGtCQUFZLElBQUk7QUFDaEJKLDBCQUFvQixLQUFLO0FBQ3pCd0MscUJBQWUsQ0FBQ2dDLFVBQVUsRUFBRSxHQUFHQSxNQUFNL0IsWUFBWSxNQUFNLEVBQUU7QUFFekQsWUFBTTZJLE1BQU0vQixhQUFhQyxRQUFRLE1BQU07QUFDdkMsVUFBSStCLGFBQWE7QUFFakIsVUFBSUQsS0FBSztBQUNQLFlBQUk7QUFDRkMsdUJBQWFsQyxLQUFLQyxNQUFNZ0MsR0FBRztBQUFBLFFBQzdCLFNBQVNuSCxJQUFHO0FBQ1ZjLGtCQUFRRCxNQUFNLDJDQUEyQ2IsRUFBQztBQUFBLFFBQzVEO0FBQUEsTUFDRjtBQUVBLFVBQUl2QixTQUFTYSxzQkFBc0IsWUFBWTlDLGtCQUFrQjtBQUMvRGlDLGlCQUFTYSxvQkFBb0I5QztBQUFBQSxNQUMvQjtBQUVBLFlBQU02SyxtQkFBbUJqTCxvQkFBb0J1RztBQUFBQSxRQUMzQyxDQUFDLEVBQUVoRSxVQUFVRyxPQUFPLE9BQU87QUFBQSxVQUN6Qkg7QUFBQUEsVUFDQTJJLGVBQWV4STtBQUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFFQSxZQUFNeUksVUFBVTtBQUFBLFFBQ2QsR0FBRzlJO0FBQUFBLFFBQ0hpQix1QkFBdUIySDtBQUFBQSxRQUN2QkQsWUFBWUEsWUFBWXZFO0FBQUFBLFFBQ3hCMkUsU0FBUzVLO0FBQUFBLE1BQ1g7QUFFQSxVQUNFLENBQUN5SyxpQkFBaUJ6RyxVQUNsQjlHLG1CQUNBc0Msb0JBQW9CLENBQUMsR0FBRzBDLFFBQ3hCO0FBQ0F5SSxnQkFBUTVJLFdBQVc3RTtBQUNuQnlOLGdCQUFRekksU0FBUzFDLG9CQUFvQixDQUFDLEVBQUUwQztBQUFBQSxNQUMxQztBQUVBM0MsNEJBQXNCLElBQUk7QUFFMUIsWUFBTXNFLFdBQVcsTUFBTS9JLElBQUlpTztBQUFBQSxRQUN6QjtBQUFBLFFBQ0E0QjtBQUFBQSxNQUNGO0FBRUEsVUFBSTlHLFNBQVNrRSxVQUFVLE9BQU9sRSxTQUFTa0UsU0FBUyxLQUFLO0FBQ25ENUssMkJBQW1CLEVBQUU7QUFDckJzQywrQkFBdUIsRUFBRTtBQUN6QnFDLG9CQUFZO0FBQUEsVUFDVkMsVUFBVTtBQUFBLFVBQ1ZDLFNBQVM7QUFBQSxVQUNUQyxVQUFVekQ7QUFBQUEsVUFDVjJELFFBQVE7QUFBQSxVQUNSQyxVQUFVO0FBQUEsVUFDVkMsZ0JBQWdCO0FBQUEsVUFDaEJILFFBQVE7QUFBQSxVQUNSUSxtQkFBbUI7QUFBQSxVQUNuQkMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUVEMEMsMkJBQW1CO0FBQUEsTUFDckI7QUFBQSxJQUVGLFNBQVNwQixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JEaEYsMEJBQW9CLEtBQUs7QUFDekI5Qix5QkFBbUIsRUFBRTtBQUNyQjJFLGtCQUFZO0FBQUEsUUFDVkMsVUFBVTtBQUFBLFFBQ1ZDLFNBQVM7QUFBQSxRQUNUQyxVQUFVekQ7QUFBQUEsUUFDVjJELFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsZ0JBQWdCO0FBQUEsUUFDaEJILFFBQVE7QUFBQSxRQUNSUSxtQkFBbUI7QUFBQSxRQUNuQkMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDcEQsNEJBQXNCLEtBQUs7QUFDM0JZLGtCQUFZLENBQUNzRCxTQUFTQSxPQUFPLENBQUM7QUFDOUJwRSxrQkFBWSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsUUFBTXdMLHlCQUF5QixPQUFPekgsTUFBTTtBQUMxQ0EsTUFBRWlILGVBQWU7QUFDakIsVUFBTUMsVUFBVWxGLG9CQUFvQjtBQUNwQyxRQUFJLENBQUNrRixRQUFTO0FBRWQsUUFBSTtBQUNGLFlBQU1DLE1BQU0vQixhQUFhQyxRQUFRLE1BQU07QUFDdkMsVUFBSStCLGFBQWE7QUFDakIsVUFBSTtBQUNGLFlBQUlELElBQUtDLGNBQWFsQyxLQUFLQyxNQUFNZ0MsR0FBRztBQUFBLE1BQ3RDLFNBQVNuSCxJQUFHO0FBQ1ZjLGdCQUFRRCxNQUFNLHlCQUF5QmIsRUFBQztBQUFBLE1BQzFDO0FBR0EsVUFBSXVILFVBQVU7QUFBQSxRQUNaMUksVUFBVVcsV0FBV1g7QUFBQUEsUUFDckJFLFFBQVFTLFdBQVdUO0FBQUFBLFFBQ25CQyxVQUFVUSxXQUFXUjtBQUFBQSxRQUNyQkMsZ0JBQWdCTyxXQUFXUCxrQkFBa0J5STtBQUFBQSxRQUM3Q3hJLGVBQWVNLFdBQVdOLGlCQUFpQjtBQUFBLFFBQzNDQyxhQUFhSyxXQUFXTCxlQUFlO0FBQUEsUUFDdkNDLGtCQUFrQkksV0FBV0osb0JBQW9CO0FBQUEsUUFDakRDLG9CQUFvQkcsV0FBV0gsc0JBQXNCO0FBQUEsUUFDckRFLE1BQU1DLFdBQVdELFFBQVE7QUFBQSxRQUN6QjZILFlBQVlBLFlBQVl2RTtBQUFBQSxRQUN4QnZELG1CQUNFRSxXQUFXRixzQkFBc0IsV0FDN0I5QyxvQkFBb0IsV0FDcEJnRCxXQUFXRjtBQUFBQSxNQUNuQjtBQUNBaUksY0FBUTNJLFVBQVU1RTtBQUVsQixVQUFJd0QscUJBQXFCO0FBQ3ZCLGNBQU1tSyxRQUFRbkssb0JBQW9CakMsTUFBTSxHQUFHO0FBRTNDLFlBQUlvTSxNQUFNL0csV0FBVyxHQUFHO0FBQ3RCMkcsa0JBQVE1SSxXQUFXZ0osTUFBTSxDQUFDLEVBQUV2QixRQUFRLFNBQVMsRUFBRTtBQUMvQ21CLGtCQUFRekksU0FBUzZJLE1BQU0sQ0FBQztBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUNBLFlBQU1sSCxXQUFXLE1BQU0vSSxJQUFJaU87QUFBQUEsUUFDekI7QUFBQSxRQUNBNEI7QUFBQUEsTUFDRjtBQUVBLFVBQUk5RyxTQUFTa0UsV0FBVyxPQUFPbEUsU0FBU2tFLFdBQVcsS0FBSztBQUV0RDFLLHlCQUFpQixFQUFFO0FBQ25Cd0QsK0JBQXVCLElBQUk7QUFDM0JwQiwrQkFBdUIsRUFBRTtBQUN6QjRCLDhCQUFzQixNQUFNO0FBRTVCd0Isc0JBQWM7QUFBQSxVQUNaYixTQUFTO0FBQUEsVUFDVEMsVUFBVXpEO0FBQUFBLFVBQ1YyRCxRQUFRO0FBQUEsVUFDUkMsVUFBVTtBQUFBLFVBQ1ZDLGdCQUFnQjtBQUFBLFVBQ2hCQyxlQUFlO0FBQUEsVUFDZkMsYUFBYTtBQUFBLFVBQ2JDLGtCQUFrQjtBQUFBLFVBQ2xCQyxvQkFBb0I7QUFBQSxVQUNwQkMsbUJBQW1CO0FBQUEsVUFDbkJDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRGxCLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pzSixVQUFVO0FBQUEsVUFDVnJKLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xILHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pzSixVQUFVO0FBQUEsVUFDVnJKLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3FDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxrQ0FBa0NBLEtBQUs7QUFDckR4QyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNac0osVUFBVTtBQUFBLFFBQ1ZySixTQUNFc0MsTUFBTUosVUFBVUUsTUFBTXBDLFdBQVc7QUFBQSxRQUNuQ0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDM0MsMEJBQW9CLEtBQUs7QUFDekJNLDRCQUFzQixLQUFLO0FBRTNCWSxrQkFBWSxDQUFDc0QsU0FBU0EsT0FBTyxDQUFDO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsUUFBTXdILFVBQVU7QUFBQSxJQUNkLEVBQUVqSSxLQUFLLE1BQU1rSSxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFbEksS0FBSyxRQUFRa0ksUUFBUSxlQUFlO0FBQUEsSUFDdEMsRUFBRWxJLEtBQUssUUFBUWtJLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRWxJLEtBQUssZ0JBQWdCa0ksUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRWxJLEtBQUssZUFBZWtJLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVsSSxLQUFLLGNBQWNrSSxRQUFRLFFBQVE7QUFBQSxJQUNyQyxFQUFFbEksS0FBSyxVQUFVa0ksUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRWxJLEtBQUssY0FBY2tJLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVsSSxLQUFLLFVBQVVrSSxRQUFRLGFBQWE7QUFBQSxJQUN0QyxFQUFFbEksS0FBSyxnQkFBZ0JrSSxRQUFRLGVBQWU7QUFBQTtBQUFBLElBRTlDLEVBQUVsSSxLQUFLLFVBQVVrSSxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLG1CQUFtQnpPLE9BQU8wTyxLQUFLLENBQUMzQixNQUFNQSxFQUFFeEQsUUFBUXpJLHNCQUFzQjtBQUM1RSxRQUFNNk4sY0FBY2pMLG9CQUFvQkUsZ0JBQWdCMUQ7QUFDeEQsUUFBTTBPLGlCQUFpQkQsWUFBWUU7QUFBQUEsSUFDakMsQ0FBQ0MsS0FBS0MsU0FBU0QsT0FBTzdCLE9BQU84QixLQUFLNUUsVUFBVSxLQUFLO0FBQUEsSUFDakQ7QUFBQSxFQUNGO0FBQ0EsUUFBTTZFLGlCQUFpQkwsWUFBWUU7QUFBQUEsSUFDakMsQ0FBQ0MsS0FBS0MsU0FBU0QsT0FBTzdCLE9BQU84QixLQUFLaEYsVUFBVSxLQUFLO0FBQUEsSUFDakQ7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFdBQU0sS0FBRyxNQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkU7QUFBQSxJQUNGLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFFUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWpGLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBO0FBQUFBLFFBSHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcrQjtBQUFBLE1BRy9CLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsU0FBSSxXQUFVLDBDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlDQUNiLGlDQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2JwRiwrQkFBYSxTQUFTO0FBQUEsZ0JBRXhCO0FBQUEsZ0JBQ0EsV0FBVyw4REFDVEQsY0FBYyxZQUNWLHNDQUNBLDRFQUE0RTtBQUFBLGdCQUMvRTtBQUFBO0FBQUEsY0FUTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFDYkMsK0JBQWEsYUFBYTtBQUMxQkUsaUNBQWUsS0FBSztBQUFBLGdCQUN0QjtBQUFBLGdCQUNBLFdBQVcsOERBQ1RILGNBQWMsZ0JBQ1Ysc0NBQ0EsNEVBQTRFO0FBQUEsZ0JBQy9FO0FBQUE7QUFBQSxjQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2JxRSxxQ0FBbUIsSUFBSTtBQUFBLGdCQUN6QjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBMkU7QUFBQTtBQUFBLGNBSnZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxXQUFVO0FBQUEsZ0JBRW9CO0FBQUE7QUFBQSxjQUpoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUFsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1EQTtBQUFBLFFBRUNyRSxjQUFjLFlBQ2IsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsK0JBQ1o7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsMEJBQXlCLG9CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQU87QUFBQSxlQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFrRUEsdUJBQUMsU0FDRThELDhCQUNDSSxrQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBV0E7QUFBQUEsY0FDWCxNQUFLO0FBQUE7QUFBQSxZQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUV1QixJQUVyQkYsY0FBYzBELFNBQVMsSUFDekIsbUNBQ0U7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUscUdBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSx1Q0FBc0MsMENBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHVEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLGtCQUNyQzFELGNBQWMwRDtBQUFBQSxxQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFVBQUssV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLGtCQUVwRHNILGVBQWVLLGVBQWUsT0FBTztBQUFBLHFCQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRUEsdUJBQUMsVUFBSyxXQUFVLHdDQUF1QztBQUFBO0FBQUEsa0JBRXBERCxlQUFlQyxlQUFlLE9BQU87QUFBQSxxQkFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQSxLQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNbFEsYUFBYTZFLGVBQWVoQyxVQUFVO0FBQUEsZ0JBQzVDO0FBQUEsZ0JBQ0Esa0JBQWlCO0FBQUEsZ0JBQ2pCLGlCQUFnQjtBQUFBO0FBQUEsY0FKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXlDO0FBQUEsZUFwQzNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0NBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG1DQUFrQyx1Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxJQUVBMUIsY0FBY29ILFNBQ2hCLG1DQUNHO0FBQUEsYUFBQzVELHFCQUFxQnhELGNBQWNvSCxTQUFTLEtBQzVDLHVCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSxxR0FDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHVDQUNYbUg7QUFBQUEsb0NBQWtCcEUsY0FBYztBQUFBLGtCQUFRO0FBQUEscUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDBEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLGtCQUNyQ25LLGNBQWNvSDtBQUFBQSxxQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLGtCQUVwRHNILGVBQWVLLGVBQWUsT0FBTztBQUFBLHFCQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUVGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBZTFCO0FBQUFBLGdCQUNmLE1BQU14TyxhQUFhbUIsZUFBZTBCLFVBQVU7QUFBQSxnQkFDNUM7QUFBQSxnQkFDQSxpQkFBZ0I7QUFBQSxnQkFDaEIsaUJBQWlCLENBQUMsY0FBYyxTQUFTO0FBQUEsZ0JBQ3pDLG1CQUFtQjtBQUFBLGtCQUNqQjZNLGtCQUFrQnBFO0FBQUFBLGtCQUNsQi9JLE9BQU9tRTtBQUFBQSxnQkFBTTtBQUFBLGdCQUVmLGtCQUFrQjtBQUFBO0FBQUEsY0FWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVThDO0FBQUEsZUF2Q2hEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUNBLElBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxNQUFLO0FBQUEsY0FDTCxTQUNFdkYsY0FBY29ILFdBQVcsS0FBSyxDQUFDLENBQUN4RztBQUFBQTtBQUFBQSxZQUpwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLRyxLQXJHUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdHQTtBQUFBLGFBN0tGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4S0EsSUFFQSx1QkFBQyx3QkFBcUIsZUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFdBeE9uRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBME9BO0FBQUEsTUFHQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FDRSx1QkFBQyxVQUFLLFdBQVUsMkRBQTBELGdDQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFRixNQUFNd0I7QUFBQUEsVUFDTixRQUFPO0FBQUEsVUFDUCxTQUFTLE1BQU1DLG9CQUFvQixLQUFLO0FBQUEsVUFDeEMsV0FBVTtBQUFBLFVBQ1YsT0FBTztBQUFBLFVBRU5DLDJCQUNDLHVCQUFDLFVBQUssV0FBVSxpQkFDZDtBQUFBLG1DQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw2QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0EsZUFBZXlJO0FBQUFBLGtCQUN0QjtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUd5RjtBQUFBLGlCQVAzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU96SSxlQUFlMEk7QUFBQUEsa0JBQ3RCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR3lGO0FBQUEsaUJBUDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxzQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU8vRixTQUFTSztBQUFBQSxrQkFDaEI7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJeUY7QUFBQSxjQUV6Rix1QkFBQyxVQUFLLFdBQVUsOENBQ2J2Ryw4QkFBb0JrRyxTQUFTSyxVQUFVLENBQUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9oRCxlQUFlMkk7QUFBQUEsa0JBQ3RCLFdBQVU7QUFBQSxrQkFDVixVQUFRO0FBQUE7QUFBQSxnQkFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJVTtBQUFBLGNBRVYsdUJBQUMsVUFBSyxXQUFVLDhDQUNibE0sOEJBQW9CdUQsZUFBZTJJLGFBQWEsQ0FBQyxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDaEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9oRyxTQUFTTTtBQUFBQSxrQkFDaEIsVUFBVXNDO0FBQUFBLGtCQUNWLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUswRDtBQUFBLGNBRTFELHVCQUFDLFVBQUssV0FBVSw4Q0FDYjlJLDhCQUFvQmtHLFNBQVNNLFVBQVUsQ0FBQyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQ2pFLE9BQU9pRSxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJqRSxpQkFBT2lFLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdEO0FBQUEsaUJBZjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsaUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPTixTQUFTYTtBQUFBQSxrQkFDaEI7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJeUY7QUFBQSxpQkFSM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2IsU0FBU0k7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ21CLE1BQ1R0QixZQUFZLENBQUM4SixPQUFPLEVBQUUsR0FBR0EsR0FBRzNKLFVBQVVtQixFQUFFQyxPQUFPSCxNQUFNLEVBQUU7QUFBQSxrQkFFekQsV0FBVTtBQUFBO0FBQUEsZ0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTTBEO0FBQUEsaUJBVjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9wRztBQUFBQSxrQkFDUCxVQUFVNEc7QUFBQUEsa0JBQ1YsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlCO0FBQUEsb0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBLG9CQUM3Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQSxvQkFDNUI5RSxpQkFDQyxtQ0FDRTtBQUFBLDZDQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBLHNCQUNqQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSxzQkFDN0IsdUJBQUMsWUFBTyxPQUFNLGNBQWEsMEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFDO0FBQUEsc0JBQ3JDLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBLHlCQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUE7QUFBQTtBQUFBLGdCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCQTtBQUFBLGlCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQTtBQUFBLFlBRUM5QixnQkFBZ0IsWUFDZix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsZ0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBTytFLFNBQVNRO0FBQUFBLGtCQUNoQixVQUFVb0M7QUFBQUEsa0JBQ1YsV0FBVTtBQUFBO0FBQUEsZ0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSzBEO0FBQUEsY0FFekR2RyxPQUFPbUUsa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWbkUsaUJBQU9tRSxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUdEdkYsZ0JBQWdCLFlBQ2YsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDhDQUE2Qyw4QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLG9CQUNsRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxPQUFPK0UsU0FBU1M7QUFBQUEsc0JBQ2hCLFVBQVVtQztBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU91TDtBQUFBLGtCQUV0THZHLE9BQU9vRSxpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZwRSxpQkFBT29FLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxnQkFFQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsb0JBQ3BELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILE9BQU9ULFVBQVVVLGFBQWE1RCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsc0JBQzFDLFVBQVU4RjtBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU91TDtBQUFBLGtCQUV0THZHLE9BQU9xRSxlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnJFLGlCQUFPcUUsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxPQUFPVixTQUFTVztBQUFBQSxzQkFDaEIsVUFBVWlDO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT3VMO0FBQUEscUJBWHpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxnQkFFQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGtEQUFpRCwyQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILE9BQU81QyxTQUFTWTtBQUFBQSxzQkFDaEIsVUFBVWdDO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT3VMO0FBQUEscUJBWHpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxtQkFyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzRUE7QUFBQSxpQkExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyRUE7QUFBQSxZQUdGLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT3ZGLGVBQWV5RCxRQUFRO0FBQUEsa0JBQzlCLFVBQVUsQ0FBQ1MsTUFDVGpFLGtCQUFrQixDQUFDeU0sT0FBTyxFQUFFLEdBQUdBLEdBQUdqSixNQUFNUyxFQUFFQyxPQUFPSCxNQUFNLEVBQUU7QUFBQSxrQkFFM0QsV0FBVTtBQUFBLGtCQUNWLE1BQU07QUFBQSxrQkFDTixhQUFZO0FBQUE7QUFBQSxnQkFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPZ0Q7QUFBQSxpQkFYbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNakUsb0JBQW9CLEtBQUs7QUFBQSxrQkFDeEMsV0FBVTtBQUFBLGtCQUE2QztBQUFBO0FBQUEsZ0JBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTbUw7QUFBQUEsa0JBQ1QsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFBNkM7QUFBQTtBQUFBLGdCQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxlQXpQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBQQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBLFFBM1FKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTZRQTtBQUFBLE1BS0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU14TTtBQUFBQSxVQUNOLFFBQVE7QUFBQSxVQUNSLFVBQVUsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxVQUN4QyxPQUFPO0FBQUEsVUFDUCxXQUFVO0FBQUEsVUFFVixpQ0FBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsc0NBQ2IsaUNBQUMsUUFBRyxXQUFVLG1DQUFrQyxvQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSw4Q0FBNkMsaUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFEQUNaQyw4QkFBb0JxTSxhQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFEQUNack0sOEJBQW9CaUUsVUFBVWdGLGNBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0Msd0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscURBQ1osYUFBR2pKLG9CQUFvQmtFLFNBQVM0RCxTQUFTLE1BQU05SCxvQkFBb0JvRSxNQUFNLE1BRDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscURBQW9EO0FBQUE7QUFBQSxvQkFDL0RwRSxvQkFBb0IrSSxZQUFZOEUsZUFBZSxPQUFPO0FBQUEsdUJBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsaUJBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0NBLEtBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0NBO0FBQUEsZUEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnREE7QUFBQTtBQUFBLFFBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXdEQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1qTDtBQUFBQSxVQUNOLFVBQVUsTUFBTTtBQUNkdkQsK0JBQW1CLEVBQUU7QUFDckIwRCxtQ0FBdUIsSUFBSTtBQUMzQkYsK0JBQW1CLEtBQUs7QUFDeEJ4QyxzQkFBVSxDQUFDLENBQUM7QUFBQSxVQUNkO0FBQUEsVUFDQSxPQUFPO0FBQUEsVUFDUCxXQUFVO0FBQUEsVUFDVixRQUFRO0FBQUEsVUFFUixpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLHNDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxZQUFVLE1BRXBDO0FBQUEsaURBQ0U7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVU7QUFBQTtBQUFBLHdCQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLDZFQUE2RWxDLFVBQVU0UCxNQUFNO0FBQUEsc0JBQ3hHLGFBQVk7QUFBQSxzQkFDWix1QkFBdUI7QUFBQSxzQkFDdkI7QUFBQSxzQkFDQSxjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsc0JBRWpDLE9BQU85TyxpQkFBaUIwTjtBQUFBQSxzQkFDeEIsVUFBVXpHO0FBQUFBLHNCQUVUckQsZ0JBQU0rRTtBQUFBQSx3QkFBSSxDQUFDb0QsVUFDVix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTWxELEtBQ3pDLGFBQUdrRCxNQUFNdkQsU0FBUyxNQUFNdUQsTUFBTXJELFlBQVksTUFEekJxRCxNQUFNbEQsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUE7QUFBQSxvQkFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW1CQTtBQUFBLGtCQUVDL0gsT0FBT3FHLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWckcsaUJBQU9xRyxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQ0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxhQUFZO0FBQUEsc0JBQ1osVUFBVWpCO0FBQUFBLHNCQUNWLE9BQU8xQztBQUFBQSxzQkFDUCxXQUFVO0FBQUEsc0JBQ1YsWUFBVTtBQUFBLHNCQUVUbEQsMEJBQWdCcUksSUFBSSxDQUFDcUcsT0FBT3BHLFVBQVU7QUFDckMsOEJBQU00QixZQUNKd0UsT0FBT2xELFlBQVlDLE9BQU9wQyxjQUFjO0FBQzFDLDhCQUFNekosV0FDSjhPLE9BQU9sRCxZQUFZQyxPQUFPbEQsT0FBTyxXQUFXRCxLQUFLO0FBQ25ELDhCQUFNOUQsU0FBU2tLLE9BQU9sRCxZQUFZbUQsV0FBVztBQUM3Qyw4QkFBTXJKLE1BQU0sUUFBUTFGLFFBQU8sSUFBSTRFLE1BQU07QUFDckMsK0JBQ0UsdUJBQUMsT0FBTyxRQUFQLEVBQXdCLE9BQU9jLEtBQzdCNEU7QUFBQUE7QUFBQUEsMEJBQVU7QUFBQSwwQkFBSTFGO0FBQUFBLDZCQURHYyxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBRUosQ0FBQztBQUFBO0FBQUEsb0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFvQkE7QUFBQSxrQkFDQzlFLE9BQU80RSx5QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y1RSxpQkFBTzRFLHlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4QkE7QUFBQSxtQkFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvRUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBZTtBQUFBO0FBQUEsb0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFVBQVUsQ0FBQ2xFO0FBQUFBLHNCQUNYLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT2dFLFdBQVdYO0FBQUFBLHNCQUNsQixJQUFHO0FBQUEsc0JBQ0gsVUFBVTBDO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixXQUFVO0FBQUE7QUFBQSxvQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUTBJO0FBQUEsa0JBR3pJekcsT0FBTytELFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWL0QsaUJBQU8rRCxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1QkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQWE7QUFBQTtBQUFBLHdCQUVkLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLE9BQU9XLFdBQVdUO0FBQUFBLHNCQUNsQixJQUFHO0FBQUEsc0JBQ0gsVUFBVXdDO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFRMkksS0FUN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUVDekcsT0FBT2lFLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QmpFLGlCQUFPaUUsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0Q7QUFBQSxxQkFyQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUJBO0FBQUEsbUJBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaURBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVU7QUFBQTtBQUFBLG9CQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILE9BQ0VTLFdBQVdGLHFCQUNYO0FBQUEsc0JBRUY7QUFBQSxzQkFDQSxXQUFVO0FBQUEsc0JBQ1YsVUFBVWlDO0FBQUFBLHNCQUVWO0FBQUEsK0NBQUMsWUFBTyxPQUFNLElBQUcsMEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTJCO0FBQUEsd0JBQzFCNUIsa0JBQWtCZ0Q7QUFBQUEsMEJBQUksQ0FBQ3VHLFVBQ3RCLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1wSixPQUNsQ29KLGdCQUFNckosU0FESXFKLE1BQU10SixLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBO0FBQUEsb0JBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQkE7QUFBQSxrQkFDQzlFLE9BQU93RSxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4RSxpQkFBT3dFLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4QkE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVU7QUFBQTtBQUFBLG9CQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILFdBQVU7QUFBQSxzQkFDVixVQUFVYTtBQUFBQSxzQkFDVixPQUFPbkM7QUFBQUEsc0JBRVA7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUI7QUFBQSx3QkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUEsd0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2QjtBQUFBLHdCQUM1QnhDLGlCQUNDLG1DQUNFO0FBQUEsaURBQUMsWUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUEsMEJBQ2pDLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE2QjtBQUFBLDBCQUM3Qix1QkFBQyxZQUFPLE9BQU0sY0FBYSwwQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBcUM7QUFBQSwwQkFDckMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTZCO0FBQUEsNkJBSi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBS0E7QUFBQTtBQUFBO0FBQUEsb0JBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFrQkE7QUFBQSxxQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwQkE7QUFBQSxtQkEzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0REE7QUFBQSxjQUVDZ0UsV0FBV1QsVUFBVTNDLG9CQUFvQndFLFNBQVMsS0FDakQsdUJBQUMsU0FDQztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLGtCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUNFMkYsT0FBTy9HLFdBQVdULE1BQU0sSUFBSTNDLG9CQUFvQndFO0FBQUFBLG9CQUVsRCxVQUFRO0FBQUE7QUFBQSxrQkFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT1U7QUFBQSxtQkFmWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBRUQ1Qyx1QkFBdUIsWUFDdEIsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFnQjtBQUFBO0FBQUEsc0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsSUFBRztBQUFBLG9CQUNILE9BQU93QixXQUFXUDtBQUFBQSxvQkFDbEIsVUFBVXNDO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixXQUFVO0FBQUE7QUFBQSxrQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTzJJO0FBQUEsZ0JBRTFJekcsT0FBT21FLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVm5FLGlCQUFPbUUsa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGNBRURqQix1QkFBdUIsWUFDdEIsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDhDQUE2Qyw4QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxzQkFDbEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxJQUFHO0FBQUEsd0JBQ0gsT0FBT3dCLFdBQVdOO0FBQUFBLHdCQUNsQixVQUFVcUM7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPdUw7QUFBQSxvQkFFdEx6RyxPQUFPb0UsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWcEUsaUJBQU9vRSxpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLHNCQUNwRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLElBQUc7QUFBQSx3QkFDSCxPQUFPTSxZQUFZTCxhQUFhNUQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLHdCQUM1QyxVQUFVZ0c7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPdUw7QUFBQSxvQkFFdEx6RyxPQUFPcUUsZUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZyRSxpQkFBT3FFLGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxJQUFHO0FBQUEsd0JBQ0gsT0FBT0ssV0FBV0o7QUFBQUEsd0JBQ2xCLFVBQVVtQztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU91TDtBQUFBLHVCQVh6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLElBQUc7QUFBQSx3QkFDSCxPQUFPL0IsV0FBV0g7QUFBQUEsd0JBQ2xCLFVBQVVrQztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU91TDtBQUFBLHVCQVh6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0VBO0FBQUEsbUJBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkVBO0FBQUEsY0FHRDdFLG1CQUNDLG1DQUNFO0FBQUEsdUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFhO0FBQUE7QUFBQSxvQkFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixJQUFHO0FBQUEsc0JBQ0gsTUFBSztBQUFBLHNCQUNMLE9BQU9GO0FBQUFBLHNCQUNQLGFBQVk7QUFBQSxzQkFDWixVQUFVMk07QUFBQUE7QUFBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU95QztBQUFBLHFCQWQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdCQTtBQUFBLGdCQUNDck8sT0FBT3dFLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhFLGlCQUFPd0UscUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGNBR0YsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBTTtBQUFBLG9CQUNOLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILE1BQUs7QUFBQSxvQkFDTCxPQUFPRSxXQUFXRDtBQUFBQSxvQkFDbEIsYUFBWTtBQUFBLG9CQUNaLFVBQVVnQztBQUFBQTtBQUFBQSxrQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUWdDO0FBQUEsbUJBZmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUFpQjdGLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLG1CQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLDRDQUViO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVNnQztBQUFBQSxzQkFDVCxVQUFVLENBQUNzQyxNQUFNckMsbUJBQW1CcUMsRUFBRUMsT0FBT21KLE9BQU87QUFBQSxzQkFDcEQsV0FBVTtBQUFBO0FBQUEsb0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlzQztBQUFBLGtCQUd0Qyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGlDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLG9CQUFpQixXQUFVLGFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3JDLHVCQUFDLFVBQUssV0FBVSx1QkFBc0Isd0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDO0FBQUEscUJBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU07QUFDYjdMLHlDQUFtQixLQUFLO0FBQ3hCdEQsdUNBQWlCLEVBQUU7QUFDbkJ3RCw2Q0FBdUIsSUFBSTtBQUMzQmdDLG9DQUFjO0FBQUEsd0JBQ1piLFNBQVM7QUFBQSx3QkFDVEMsVUFBVXpEO0FBQUFBLHdCQUNWMkQsUUFBUTtBQUFBLHdCQUNSQyxVQUFVO0FBQUEsd0JBQ1ZDLGdCQUFnQjtBQUFBLHdCQUNoQkMsZUFBZTtBQUFBLHdCQUNmQyxhQUFhO0FBQUEsd0JBQ2JDLGtCQUFrQjtBQUFBLHdCQUNsQkMsb0JBQW9CO0FBQUEsd0JBQ3BCQyxtQkFBbUI7QUFBQSx3QkFDbkJDLE1BQU07QUFBQSxzQkFDUixDQUFDO0FBQUEsb0JBQ0g7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBQTZFO0FBQUE7QUFBQSxrQkFwQnpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF1QkE7QUFBQSxnQkFDQSx1QkFBQyxXQUFRLE9BQU0sc0JBQ2I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsQ0FBQ1MsTUFBTXlILHVCQUF1QnpILENBQUM7QUFBQSxvQkFDeEMsV0FBVTtBQUFBLG9CQUNpRztBQUFBO0FBQUEsa0JBSjdHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQ0E7QUFBQSxpQkFsYUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtYUE7QUFBQSxlQXZhRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdhQTtBQUFBO0FBQUEsUUFwYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcWJBO0FBQUEsU0ExL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyL0JBO0FBQUEsT0FqaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FraENBO0FBRUo7QUFBRS9HLEdBdjdESUQsbUJBQWlCO0FBQUFxUSxLQUFqQnJRO0FBeTdETixlQUFlQTtBQUFrQixJQUFBcVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2lkZWJhciIsImFwaSIsIkJ1dHRvbiIsIkRyYXdlciIsIk1vZGFsIiwiVG9vbHRpcCIsIkRyb3Bkb3duIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJOYXZiYXIiLCJTZWxlY3QiLCJJb01kTW9yZSIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIlNlYXJjaE91dGxpbmVkIiwiSW5mb0NpcmNsZU91dGxpbmVkIiwiRmFSdXBlZVNpZ24iLCJGYVdoYXRzYXBwU3F1YXJlIiwiQnJlYWRjcnVtYiIsImZpZWxkU2l6ZSIsIkxpbmsiLCJDaGl0Q2FuY2VsUGF5bWVudE91dCIsIkdlbmVyYWxQYXltZW50T3V0IiwiX3MiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJzaG93U2lkZWJhciIsInNldFNob3dTaWRlYmFyIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiVGFibGVBdWN0aW9ucyIsInNldFRhYmxlQXVjdGlvbnMiLCJwYXltZW50TW9kZSIsInNldFBheW1lbnRNb2RlIiwic2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cCIsInNlbGVjdGVkR3JvdXBJZCIsInNldFNlbGVjdGVkR3JvdXBJZCIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwiZ3JvdXBJZCIsInNldEdyb3VwSWQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkQXVjdGlvbiIsInNldEZpbHRlcmVkQXVjdGlvbiIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVcGRhdGVHcm91cCIsInNldEN1cnJlbnRVcGRhdGVHcm91cCIsImRvdWJsZSIsInNldERvdWJsZSIsImVycm9ycyIsInNldEVycm9ycyIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwidG9kYXkiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsIm1vZGlmeVBheW1lbnQiLCJzZXRNb2RpZnlQYXltZW50IiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwic2hvd1BheW1lbnRNb2RhbCIsInNldFNob3dQYXltZW50TW9kYWwiLCJwYXltZW50RGV0YWlscyIsInNldFBheW1lbnREZXRhaWxzIiwiZGlzYWJsZWQiLCJzZXREaXNhYmxlZCIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsInBheW1lbnRHcm91cFRpY2tldHMiLCJzZXRQYXltZW50R3JvdXBUaWNrZXRzIiwicGF5bWVudEdyb3VwVGlja2V0c1BheW1lbnQiLCJzZXRQYXltZW50R3JvdXBUaWNrZXRzUGF5bWVudCIsImRpc2J1cnNlbWVudFR5cGUiLCJzZXREaXNidXJzZW1lbnRUeXBlIiwic2hvd090aGVyc0ZpZWxkIiwic2V0U2hvd090aGVyc0ZpZWxkIiwicGF5bWVudFR5cGUiLCJzZXRQYXltZW50VHlwZSIsInJlcmVuZGVyIiwic2V0UmVyZW5kZXIiLCJzaG93UmVjZW50UGF5b3V0cyIsInNldFNob3dSZWNlbnRQYXlvdXRzIiwicmVjZW50UGF5b3V0cyIsInNldFJlY2VudFBheW91dHMiLCJpc0xvYWRpbmdSZWNlbnQiLCJzZXRJc0xvYWRpbmdSZWNlbnQiLCJzaG93UGF5b3V0TW9kYWwiLCJzZXRTaG93UGF5b3V0TW9kYWwiLCJzZWxlY3RlZFRpY2tldFZhbHVlIiwic2V0U2VsZWN0ZWRUaWNrZXRWYWx1ZSIsIndoYXRzYXBwRW5hYmxlZCIsInNldFdoYXRzYXBwRW5hYmxlZCIsInVzZXJzIiwic2V0VXNlcnMiLCJncm91cEluZm8iLCJzZXRHcm91cEluZm8iLCJwYXltZW50TW9kZVBheW1lbnQiLCJzZXRQYXltZW50TW9kZVBheW1lbnQiLCJmaWx0ZXJlZFVzZXJzIiwic2V0RmlsdGVyZWRVc2VycyIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZ3JvdXBfaWQiLCJ1c2VyX2lkIiwicGF5X2RhdGUiLCJ0aWNrZXQiLCJhbW91bnQiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwiY2hlcXVlX251bWJlciIsImNoZXF1ZV9kYXRlIiwiY2hlcXVlX2JhbmtfbmFtZSIsImNoZXF1ZV9iYW5rX2JyYW5jaCIsImRpc2J1cnNlbWVudF90eXBlIiwibm90ZSIsInBheW91dERhdGEiLCJzZXRQYXlvdXREYXRhIiwicGF5bWVudF9ncm91cF90aWNrZXRzIiwiZGlzYnVyc2VtZW50VHlwZXMiLCJrZXkiLCJ0aXRsZSIsInZhbHVlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsImhhbmRsZVBheW1lbnRUaWNrZXRDaGFuZ2UiLCJoYW5kbGVQYXltZW50TW9kZUNoYW5nZVBheW1lbnQiLCJtb2RlIiwicHJldiIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwic2VsZWN0ZWRNb2RlIiwiaGFuZGxlR3JvdXBDaGFuZ2UiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJsZW5ndGgiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVQYXltZW50QW50U2VsZWN0IiwidmFsdWVzIiwiaGFuZGxlQ3VzdG9tZXJQYXltZW50IiwidXNlcklkIiwiY3VzdG9tZXIiLCJoYW5kbGVHcm91cEF1Y3RDaGFuZ2UiLCJoYW5kbGVDaGFuZ2UiLCJuYW1lIiwiaGFuZGxlQ2hhbmdlUGF5bWVudCIsInByZXZEYXRhIiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwicGFyc2VGbG9hdCIsImlzTmFOIiwidHJpbSIsIk9iamVjdCIsImtleXMiLCJ2YWxpZGF0ZVBheW1lbnRGb3JtIiwiZmV0Y2hSZWNlbnRQYXlvdXRzIiwic3VjY2VzcyIsIkFycmF5IiwiaXNBcnJheSIsImZvcm1hdHRlZFBheW91dHMiLCJmaWx0ZXIiLCJwYXlvdXQiLCJmdWxsX25hbWUiLCJwaG9uZSIsInBob25lX251bWJlciIsIm1hcCIsImluZGV4IiwiX2lkIiwiaWQiLCJkYXRlIiwiYXVjdGlvbl9kYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwiYmlkX2Ftb3VudCIsInBhcnNlSW50IiwiZGl2aWRlbnQiLCJjb21taXNzaW9uIiwid2luX2Ftb3VudCIsImF1Y3Rpb25fdHlwZSIsImdyb3VwX25hbWUiLCJncm91cF92YWx1ZSIsImF1Y3Rpb25fY29kZSIsImF1Y3Rpb25faWQiLCJhY3Rpb24iLCJpdGVtcyIsImxhYmVsIiwiaGFuZGxlUGF5bWVudE91dEZyb21SZWNlbnQiLCJoYW5kbGVWaWV3QXVjdGlvbiIsIndhcm5pbmciLCJjb250ZW50IiwicGFyYW1zIiwiY3VzdG9tZXJOYW1lIiwiZ3JvdXBOYW1lIiwid2luQW1vdW50IiwibXNnIiwic3RhdHVzIiwiYXVjdGlvbklkIiwicmVzZXRUb0dyb3VwVmlldyIsInVzZUVmZmVjdCIsImZldGNoR3JvdXBzIiwiZXJyIiwidXNlciIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJjYW5FZGl0IiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiZmV0Y2hEb3VibGUiLCJwb3N0IiwidmFsaWRBdWN0aW9ucyIsImF1Y3Rpb24iLCJlbnJvbGxtZW50IiwiZ3JvdXAiLCJoYW5kbGVHcm91cEF1Y3Rpb24iLCJoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UiLCJmb3JtYXR0ZWQiLCJnZXRUaW1lIiwicmVwbGFjZSIsImciLCJpZHgiLCJOdW1iZXIiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInNsaWNlIiwiaXNQcml6ZWQiLCJoYW5kbGVQYXltZW50T3V0IiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwic2kiLCJTSV9udW1iZXIiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWQiLCJ1c3IiLCJhZG1pbl90eXBlIiwiZm9ybWF0dGVkVGlja2V0cyIsInRpY2tldF9udW1iZXIiLCJwYXlsb2FkIiwicGF5X2ZvciIsImhhbmRsZVN1Ym1pdFBheW1lbnRvdXQiLCJ1bmRlZmluZWQiLCJwYXJ0cyIsIm5vUmVsb2FkIiwiY29sdW1ucyIsImhlYWRlciIsInNlbGVjdGVkbmV3R3JvdXAiLCJmaW5kIiwiZGlzcGxheURhdGEiLCJ0b3RhbFdpbkFtb3VudCIsInJlZHVjZSIsInN1bSIsIml0ZW0iLCJ0b3RhbEJpZEFtb3VudCIsInRvTG9jYWxlU3RyaW5nIiwicCIsImhlaWdodCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJlbnRyeSIsInRpY2tldHMiLCJkVHlwZSIsImhhbmRsZURpc2J1cnNlbWVudFR5cGVDaGFuZ2UiLCJjaGVja2VkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR2VuZXJhbFBheW1lbnRPdXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgQnV0dG9uLCBEcmF3ZXIsIE1vZGFsLCBUb29sdGlwIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgRHJvcGRvd24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5pbXBvcnQgeyBTZWFyY2hPdXRsaW5lZCwgSW5mb0NpcmNsZU91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCB7IEZhUnVwZWVTaWduLCBGYVdoYXRzYXBwU3F1YXJlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgQ2hpdENhbmNlbFBheW1lbnRPdXQgZnJvbSBcIi4vQ2hpdENhbmNlbFBheW1lbnRPdXRcIjtcclxuXHJcbmNvbnN0IEdlbmVyYWxQYXltZW50T3V0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcImdlbmVyYWxcIik7XHJcbiAgY29uc3QgW3Nob3dTaWRlYmFyLCBzZXRTaG93U2lkZWJhcl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUF1Y3Rpb25zLCBzZXRUYWJsZUF1Y3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcGF5bWVudE1vZGUsIHNldFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlKFwiY2FzaFwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXAsIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwSWQsIHNldFNlbGVjdGVkR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZ3JvdXBJZCwgc2V0R3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZmlsdGVyZWRBdWN0aW9uLCBzZXRGaWx0ZXJlZEF1Y3Rpb25dID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVHcm91cCwgc2V0Q3VycmVudFVwZGF0ZUdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtkb3VibGUsIHNldERvdWJsZV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCBbbW9kaWZ5UGF5bWVudCwgc2V0TW9kaWZ5UGF5bWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkbWluTmFtZSwgc2V0QWRtaW5OYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93UGF5bWVudE1vZGFsLCBzZXRTaG93UGF5bWVudE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGF5bWVudERldGFpbHMsIHNldFBheW1lbnREZXRhaWxzXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtkaXNhYmxlZCwgc2V0RGlzYWJsZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtvcGVuQmFja2Ryb3BMb2FkZXIsIHNldE9wZW5CYWNrZHJvcExvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BheW1lbnRHcm91cFRpY2tldHMsIHNldFBheW1lbnRHcm91cFRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwYXltZW50R3JvdXBUaWNrZXRzUGF5bWVudCwgc2V0UGF5bWVudEdyb3VwVGlja2V0c1BheW1lbnRdID0gdXNlU3RhdGUoXHJcbiAgICBbXSxcclxuICApO1xyXG4gIGNvbnN0IFtkaXNidXJzZW1lbnRUeXBlLCBzZXREaXNidXJzZW1lbnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93T3RoZXJzRmllbGQsIHNldFNob3dPdGhlcnNGaWVsZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BheW1lbnRUeXBlLCBzZXRQYXltZW50VHlwZV0gPSB1c2VTdGF0ZShcIkF1Y3Rpb24gV2lubmluZyBQYXlvdXRcIik7XHJcbiAgY29uc3QgW3JlcmVuZGVyLCBzZXRSZXJlbmRlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2hvd1JlY2VudFBheW91dHMsIHNldFNob3dSZWNlbnRQYXlvdXRzXSA9IHVzZVN0YXRlKHRydWUpOyAvLyBEZWZhdWx0IHRvIHRydWVcclxuICBjb25zdCBbcmVjZW50UGF5b3V0cywgc2V0UmVjZW50UGF5b3V0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZ1JlY2VudCwgc2V0SXNMb2FkaW5nUmVjZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd1BheW91dE1vZGFsLCBzZXRTaG93UGF5b3V0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFRpY2tldFZhbHVlLCBzZXRTZWxlY3RlZFRpY2tldFZhbHVlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt3aGF0c2FwcEVuYWJsZWQsIHNldFdoYXRzYXBwRW5hYmxlZF0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtwYXltZW50TW9kZVBheW1lbnQsIHNldFBheW1lbnRNb2RlUGF5bWVudF0gPSB1c2VTdGF0ZShcImNhc2hcIik7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHBheV9kYXRlOiB0b2RheSxcclxuICAgIHRpY2tldDogXCJcIixcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICAgIGNoZXF1ZV9kYXRlOiBcIlwiLFxyXG4gICAgY2hlcXVlX2JhbmtfbmFtZTogXCJcIixcclxuICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgIGRpc2J1cnNlbWVudF90eXBlOiBcIkF1Y3Rpb24gV2lubmluZyBQYXlvdXRcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3BheW91dERhdGEsIHNldFBheW91dERhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcl9pZDogXCJcIixcclxuXHJcbiAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgIGNoZXF1ZV9udW1iZXI6IFwiXCIsXHJcbiAgICBjaGVxdWVfZGF0ZTogXCJcIixcclxuICAgIGNoZXF1ZV9iYW5rX25hbWU6IFwiXCIsXHJcbiAgICBjaGVxdWVfYmFua19icmFuY2g6IFwiXCIsXHJcbiAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IFtdLFxyXG4gICAgZGlzYnVyc2VtZW50X3R5cGU6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IGRpc2J1cnNlbWVudFR5cGVzID0gW1xyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzFcIixcclxuICAgICAgdGl0bGU6IFwiQ2hpdCBDYW5jZWxsYXRpb25cIixcclxuICAgICAgdmFsdWU6IFwiQ2hpdCBDYW5jZWxsYXRpb25cIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjMlwiLFxyXG4gICAgICB0aXRsZTogXCJSZWZ1bmQgdG8gTWVtYmVyXCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlZnVuZCB0byBNZW1iZXJcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjM1wiLFxyXG4gICAgICB0aXRsZTogXCJGb3JlbWFuIENvbW1pc3Npb24gRGlzYnVyc2VtZW50XCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlZnVuZCB0byBNZW1iZXJcIixcclxuICAgIH0sXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzRcIixcclxuICAgICAgdGl0bGU6IFwiUmVpbnZlc3RtZW50IFRyYW5zZmVyXCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlaW52ZXN0bWVudCBUcmFuc2ZlclwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM1XCIsXHJcbiAgICAgIHRpdGxlOiBcIkFkdmFuY2UgUGF5b3V0IEJlZm9yZSBBdWN0aW9uXCIsXHJcbiAgICAgIHZhbHVlOiBcIkFkdmFuY2UgUGF5b3V0IEJlZm9yZSBBdWN0aW9uXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzZcIixcclxuICAgICAgdGl0bGU6IFwiRGl2aWRlbnQgU2hhcmUgRGlzYnVyc2VtZW50XCIsXHJcbiAgICAgIHZhbHVlOiBcIkRpdmlkZW50IFNoYXJlIERpc2J1cnNlbWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM3XCIsXHJcbiAgICAgIHRpdGxlOiBcIkdyb3VwIENsb3N1cmUgU2V0dGxlbWVudFwiLFxyXG4gICAgICB2YWx1ZTogXCJHcm91cCBDbG9zdXJlIFNldHRsZW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjOFwiLFxyXG4gICAgICB0aXRsZTogXCJFbWVyZ2VuY3kgV2l0aGRyYXdhbFwiLFxyXG4gICAgICB2YWx1ZTogXCJFbWVyZ2VuY3kgV2l0aGRyYXdhbFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM5XCIsXHJcbiAgICAgIHRpdGxlOiBcIk1pc3Rha2VuIFBheW1lbnQgUmV2ZXJzYWxcIixcclxuICAgICAgdmFsdWU6IFwiTWlzdGFrZW4gUGF5bWVudCBSZXZlcnNhbFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiMxMFwiLFxyXG4gICAgICB0aXRsZTogXCJPdGhlcnNcIixcclxuICAgICAgdmFsdWU6IFwiT3RoZXJzXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50VGlja2V0Q2hhbmdlID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFRpY2tldFZhbHVlKHZhbHVlKTtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHNQYXltZW50KHZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZVBheW1lbnQgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgbW9kZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG5cclxuICAgIHNldFBheW1lbnRNb2RlUGF5bWVudChtb2RlKTtcclxuXHJcbiAgICBzZXRQYXlvdXREYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBwYXlfdHlwZTogbW9kZSxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IG1vZGUgPT09IFwib25saW5lXCIgPyBwcmV2LnRyYW5zYWN0aW9uX2lkIDogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vZGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFBheW1lbnRNb2RlKHNlbGVjdGVkTW9kZSk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcGF5X3R5cGU6IHNlbGVjdGVkTW9kZSxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IHNlbGVjdGVkTW9kZSA9PT0gXCJvbmxpbmVcIiA/IHByZXYudHJhbnNhY3Rpb25faWQgOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQ2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkR3JvdXAoZ3JvdXBJZCk7XHJcblxyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvZ2V0LWdyb3VwLWVucm9sbC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50QW50U2VsZWN0ID0gKHZhbHVlcykgPT4ge1xyXG4gICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyh2YWx1ZXMpO1xyXG4gICAgc2V0U2VsZWN0ZWRUaWNrZXRWYWx1ZSh2YWx1ZXMpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUN1c3RvbWVyUGF5bWVudCA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkR3JvdXAodXNlcklkKTtcclxuXHJcbiAgICBzZXRQYXlvdXREYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICB1c2VyX2lkOiB1c2VySWQsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRUaWNrZXRWYWx1ZShudWxsKTtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogXCJcIixcclxuICAgIH0pKTtcclxuXHJcbiAgICBoYW5kbGVHcm91cENoYW5nZSh1c2VySWQpO1xyXG4gICAgaGFuZGxlR3JvdXBBdWN0Q2hhbmdlKHVzZXJJZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgaWYgKG5hbWUgPT09IFwiZGlzYnVyc2VtZW50X3R5cGVcIikge1xyXG4gICAgICBpZiAodmFsdWUgPT09IFwiT3RoZXJzXCIpIHtcclxuICAgICAgICBzZXRTaG93T3RoZXJzRmllbGQodHJ1ZSk7XHJcbiAgICAgICAgc2V0RGlzYnVyc2VtZW50VHlwZShcIlwiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRTaG93T3RoZXJzRmllbGQoZmFsc2UpO1xyXG4gICAgICAgIHNldERpc2J1cnNlbWVudFR5cGUodmFsdWUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVDaGFuZ2VQYXltZW50ID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgaWYgKG5hbWUgPT09IFwiZGlzYnVyc2VtZW50X3R5cGVcIikge1xyXG4gICAgICBpZiAodmFsdWUgPT09IFwiT3RoZXJzXCIpIHtcclxuICAgICAgICBzZXRTaG93T3RoZXJzRmllbGQodHJ1ZSk7XHJcbiAgICAgICAgc2V0RGlzYnVyc2VtZW50VHlwZShcIlwiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRTaG93T3RoZXJzRmllbGQoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXRQYXlvdXREYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoeyAuLi5wcmV2RGF0YSwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghc2VsZWN0ZWRHcm91cElkKSBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgaWYgKCFmb3JtRGF0YS50aWNrZXQpXHJcbiAgICAgIG5ld0Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgPSBcIlBsZWFzZSBQcm92aWRlIHRpY2tldFwiO1xyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXlfZGF0ZSkgbmV3RXJyb3JzLnBheV9kYXRlID0gXCJQYXltZW50IGRhdGUgaXMgcmVxdWlyZWRcIjtcclxuXHJcbiAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KGZvcm1EYXRhLmFtb3VudCk7XHJcbiAgICBpZiAoaXNOYU4oYW1vdW50KSB8fCBhbW91bnQgPD0gMClcclxuICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgcG9zaXRpdmUgYW1vdW50XCI7XHJcblxyXG4gICAgaWYgKHBheW1lbnRNb2RlID09PSBcIm9ubGluZVwiICYmICFmb3JtRGF0YS50cmFuc2FjdGlvbl9pZD8udHJpbSgpKVxyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPVxyXG4gICAgICAgIFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWQgZm9yIG9ubGluZSBwYXltZW50c1wiO1xyXG4gICAgaWYgKHBheW1lbnRNb2RlID09PSBcImNoZXF1ZVwiICYmICFmb3JtRGF0YS5jaGVxdWVfZGF0ZT8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5jaGVxdWVfZGF0ZSA9IFwiQ2hlcXVlIERhdGUgaXMgcmVxdWlyZWQgZm9yIGNoZXF1ZSBwYXltZW50c1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKHBheW1lbnRNb2RlID09PSBcImNoZXF1ZVwiICYmICFmb3JtRGF0YS5jaGVxdWVfbnVtYmVyPy50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmNoZXF1ZV9udW1iZXIgPSBcIkNoZXF1ZSBOdW1iZXIgaXMgcmVxdWlyZWQgZm9yIGNoZXF1ZSBwYXltZW50c1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFmb3JtRGF0YS5kaXNidXJzZW1lbnRfdHlwZSlcclxuICAgICAgbmV3RXJyb3JzLmRpc2J1cnNlbWVudF90eXBlID0gXCJEaXNidXJzZW1lbnQgVHlwZSBpcyBSZXF1aXJlZFwiO1xyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlUGF5bWVudEZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuXHJcbiAgICBpZiAoIXNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgbmV3RXJyb3JzLmN1c3RvbWVyID0gXCJQbGVhc2Ugc2VsZWN0IGEgY3VzdG9tZXJcIjtcclxuICAgIH1cclxuICAgIGlmICghc2VsZWN0ZWRUaWNrZXRWYWx1ZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzID0gXCJQbGVhc2Ugc2VsZWN0IGEgZ3JvdXAgYW5kIHRpY2tldFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghcGF5b3V0RGF0YS5wYXlfZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGF5X2RhdGUgPSBcIlBheW1lbnQgZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQocGF5b3V0RGF0YS5hbW91bnQpO1xyXG4gICAgaWYgKGlzTmFOKGFtb3VudCkgfHwgYW1vdW50IDw9IDApIHtcclxuICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgcG9zaXRpdmUgYW1vdW50XCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHBheW1lbnRNb2RlUGF5bWVudCA9PT0gXCJvbmxpbmVcIiAmJiAhcGF5b3V0RGF0YS50cmFuc2FjdGlvbl9pZD8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy50cmFuc2FjdGlvbl9pZCA9IFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuICAgIGlmIChwYXltZW50TW9kZVBheW1lbnQgPT09IFwiY2hlcXVlXCIgJiYgIXBheW91dERhdGEuY2hlcXVlX2RhdGU/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuY2hlcXVlX2RhdGUgPSBcIkNoZXF1ZSBEYXRlIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuICAgIGlmIChwYXltZW50TW9kZVBheW1lbnQgPT09IFwiY2hlcXVlXCIgJiYgIXBheW91dERhdGEuY2hlcXVlX251bWJlcj8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5jaGVxdWVfbnVtYmVyID0gXCJDaGVxdWUgTnVtYmVyIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBpZiAoIXBheW91dERhdGEuZGlzYnVyc2VtZW50X3R5cGUpIHtcclxuICAgIC8vICAgbmV3RXJyb3JzLmRpc2J1cnNlbWVudF90eXBlID0gXCJEaXNidXJzZW1lbnQgVHlwZSBpcyBSZXF1aXJlZFwiO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIC8vIEZldGNoIHJlY2VudCBwYXlvdXRzIG9uIHBhZ2UgbG9hZFxyXG4gIGNvbnN0IGZldGNoUmVjZW50UGF5b3V0cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZ1JlY2VudCh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9hdWN0aW9ucy9wYXltZW50LW91dHNcIik7XHJcblxyXG4gICAgICBpZiAoZGF0YT8uc3VjY2VzcyAmJiBBcnJheS5pc0FycmF5KGRhdGE/LmRhdGEpKSB7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkUGF5b3V0cyA9IGRhdGEuZGF0YVxyXG4gICAgICAgICAgLmZpbHRlcigocGF5b3V0KSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBwYXlvdXQudXNlcl9pZD8uZnVsbF9uYW1lPy50cmltKCkgfHwgXCJcIjtcclxuICAgICAgICAgICAgY29uc3QgcGhvbmUgPSBwYXlvdXQudXNlcl9pZD8ucGhvbmVfbnVtYmVyPy50cmltKCkgfHwgXCJcIjtcclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICBuYW1lICE9PSBcIlwiICYmIG5hbWUgIT09IFwiTi9BXCIgJiYgcGhvbmUgIT09IFwiXCIgJiYgcGhvbmUgIT09IFwiTi9BXCJcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICAubWFwKChwYXlvdXQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICBfaWQ6IHBheW91dC5faWQsXHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIGRhdGU6IHBheW91dC5hdWN0aW9uX2RhdGVcclxuICAgICAgICAgICAgICA/IG5ldyBEYXRlKHBheW91dC5hdWN0aW9uX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIHtcclxuICAgICAgICAgICAgICAgICAgZGF5OiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgICAgICAgbW9udGg6IFwic2hvcnRcIixcclxuICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIDogXCJOL0FcIixcclxuICAgICAgICAgICAgbmFtZTogcGF5b3V0LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IHBheW91dC51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgdGlja2V0OiBwYXlvdXQudGlja2V0IHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGJpZF9hbW91bnQ6XHJcbiAgICAgICAgICAgICAgKHBhcnNlSW50KHBheW91dC5kaXZpZGVudCkgfHwgMCkgK1xyXG4gICAgICAgICAgICAgIChwYXJzZUludChwYXlvdXQuY29tbWlzc2lvbikgfHwgMCksXHJcbiAgICAgICAgICAgIGFtb3VudDogcGF5b3V0Lndpbl9hbW91bnQgfHwgMCxcclxuICAgICAgICAgICAgYXVjdGlvbl90eXBlOiBwYXlvdXQuYXVjdGlvbl90eXBlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIC8vIHN0YXR1czogXCJQcml6ZWRcIiwgLy8gU2luY2UgdGhlc2UgYXJlIGNvbXBsZXRlZCBhdWN0aW9uIHBheW91dHNcclxuICAgICAgICAgICAgZ3JvdXBfbmFtZTogcGF5b3V0Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGdyb3VwX3ZhbHVlOiBwYXlvdXQuZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fY29kZTogcGF5b3V0LmF1Y3Rpb25fY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBncm91cF9pZDogcGF5b3V0Lmdyb3VwX2lkPy5faWQgfHwgcGF5b3V0Ll9pZCwgLy8gVXNlIGdyb3VwX2lkLl9pZCBpZiBhdmFpbGFibGVcclxuICAgICAgICAgICAgdXNlcl9pZDogcGF5b3V0LnVzZXJfaWQ/Ll9pZCxcclxuICAgICAgICAgICAgd2luX2Ftb3VudDogcGF5b3V0Lndpbl9hbW91bnQgfHwgMCxcclxuICAgICAgICAgICAgYXVjdGlvbl9pZDogcGF5b3V0Ll9pZCwgLy8gVGhlIGF1Y3Rpb24gSUQgaXMgdGhlIF9pZCBmcm9tIHRoZSByZXNwb25zZVxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlUGF5bWVudE91dEZyb21SZWNlbnQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGF5b3V0Lmdyb3VwX2lkPy5faWQgfHwgcGF5b3V0Ll9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXlvdXQudXNlcl9pZD8uX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBheW91dC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IG91dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdBdWN0aW9uKHBheW91dC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpZXdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGQgdGV4dC14bCBjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFJlY2VudFBheW91dHMoZm9ybWF0dGVkUGF5b3V0cyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0UmVjZW50UGF5b3V0cyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZWNlbnQgcGF5b3V0czpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRSZWNlbnRQYXlvdXRzKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZ1JlY2VudChmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIHBheW1lbnQgb3V0IGZyb20gcmVjZW50IHBheW91dHNcclxuICBjb25zdCBoYW5kbGVQYXltZW50T3V0RnJvbVJlY2VudCA9IGFzeW5jIChncm91cElkLCB1c2VySWQsIHRpY2tldCkgPT4ge1xyXG4gICAgaWYgKCF1c2VySWQgfHwgIWdyb3VwSWQgfHwgIXRpY2tldCkge1xyXG4gICAgICBNb2RhbC53YXJuaW5nKHtcclxuICAgICAgICB0aXRsZTogXCJNaXNzaW5nIEluZm9ybWF0aW9uXCIsXHJcbiAgICAgICAgY29udGVudDogXCJDdXN0b21lciBpbmZvcm1hdGlvbiBub3QgZm91bmQgZm9yIHRoaXMgcGF5b3V0LlwiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBcIi9hdWN0aW9uL2dldC1hdWN0aW9uLWJ5LXVzZXItZ3JvdXAtdGlja2V0XCIsXHJcbiAgICAgICAgeyBwYXJhbXM6IHsgdXNlcl9pZDogdXNlcklkLCBncm91cF9pZDogZ3JvdXBJZCwgdGlja2V0IH0gfSxcclxuICAgICAgKTtcclxuICAgICAgc2V0UGF5bWVudERldGFpbHMoe1xyXG4gICAgICAgIGN1c3RvbWVyTmFtZTogZGF0YS51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiBkYXRhLmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgIHdpbkFtb3VudDogZGF0YS53aW5fYW1vdW50LFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBncm91cF9pZDogZGF0YS5ncm91cF9pZD8uX2lkLFxyXG4gICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuICAgICAgICBhbW91bnQ6IGRhdGEud2luX2Ftb3VudCxcclxuICAgICAgICB0aWNrZXQsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgICBzZXRTaG93UGF5bWVudE1vZGFsKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc3QgbXNnID0gZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlO1xyXG4gICAgICBpZiAoZXJyb3IucmVzcG9uc2U/LnN0YXR1cyA9PT0gNDA0ICYmIG1zZyA9PT0gXCJBdWN0aW9uIG5vdCBmb3VuZFwiKSB7XHJcbiAgICAgICAgTW9kYWwud2FybmluZyh7XHJcbiAgICAgICAgICB0aXRsZTogXCJBdWN0aW9uIE5vdCBGb3VuZFwiLFxyXG4gICAgICAgICAgY29udGVudDpcclxuICAgICAgICAgICAgXCJObyBhdWN0aW9uIHdhcyBmb3VuZCBmb3IgdGhlIHNlbGVjdGVkIHVzZXIsIGdyb3VwLCBhbmQgdGlja2V0LlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIE1vZGFsLmVycm9yKHtcclxuICAgICAgICAgIHRpdGxlOiBcIkVycm9yIEZldGNoaW5nIFdpbiBBbW91bnRcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IFwiU29tZXRoaW5nIHdlbnQgd3Jvbmcgd2hpbGUgdHJ5aW5nIHRvIGZldGNoIHdpbiBhbW91bnQuXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3QXVjdGlvbiA9IGFzeW5jIChhdWN0aW9uSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChgL2F1Y3Rpb24vZ2V0LWF1Y3Rpb24tYnktaWQvJHthdWN0aW9uSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cChkYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF1Y3Rpb24gZGV0YWlsczpcIiwgZXJyb3IpO1xyXG4gICAgICBNb2RhbC5lcnJvcih7XHJcbiAgICAgICAgdGl0bGU6IFwiRXJyb3JcIixcclxuICAgICAgICBjb250ZW50OiBcIkZhaWxlZCB0byBmZXRjaCBhdWN0aW9uIGRldGFpbHNcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVzZXRUb0dyb3VwVmlldyA9ICgpID0+IHtcclxuICAgIHNldFNob3dSZWNlbnRQYXlvdXRzKGZhbHNlKTtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoXCJcIik7XHJcbiAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cChcIlwiKTtcclxuICAgIHNldFRhYmxlQXVjdGlvbnMoW10pO1xyXG4gICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgICBzZXRHcm91cHMoZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgICAvLyBMb2FkIHJlY2VudCBwYXlvdXRzIGJ5IGRlZmF1bHRcclxuICAgIGZldGNoUmVjZW50UGF5b3V0cygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFthbGVydENvbmZpZ10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpIHx8IFwie31cIik7XHJcbiAgICBzZXRBZG1pbk5hbWUodXNlci5uYW1lIHx8IFwiXCIpO1xyXG4gICAgY29uc3QgY2FuRWRpdCA9XHJcbiAgICAgIHVzZXI/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09IFwidHJ1ZVwiO1xyXG4gICAgc2V0TW9kaWZ5UGF5bWVudChjYW5FZGl0KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkQXVjdGlvbkdyb3VwSWQpIHJldHVybjtcclxuICAgIGNvbnN0IGZldGNoRG91YmxlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvZG91YmxlL2dldC1kb3VibGUvJHtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkfWAsXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXREb3VibGUoZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRG91YmxlKCk7XHJcbiAgfSwgW3NlbGVjdGVkQXVjdGlvbkdyb3VwSWRdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBBdWN0Q2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgIGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7Z3JvdXBJZH1gLFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB2YWxpZEF1Y3Rpb25zID0gcmVzcG9uc2UuZGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChhdWN0aW9uKSA9PiBhdWN0aW9uLmVucm9sbG1lbnQgJiYgYXVjdGlvbi5lbnJvbGxtZW50Lmdyb3VwLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbih2YWxpZEF1Y3Rpb25zKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBBdWN0aW9uID0gKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UoZ3JvdXBJZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwKGdyb3VwSWQpO1xyXG4gICAgaWYgKCFncm91cElkKSB7XHJcbiAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRUYWJsZUF1Y3Rpb25zKFtdKTtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChgL2F1Y3Rpb24vdW5wcml6ZWQvZ3JvdXAvJHtncm91cElkfWApO1xyXG4gICAgICBpZiAoZGF0YT8ubGVuZ3RoKSB7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKGRhdGEpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAgICAgIGRhdGU6IG5ldyBEYXRlKFxyXG4gICAgICAgICAgICAgIG5ldyBEYXRlKGRhdGFbMF0uYXVjdGlvbl9kYXRlKS5nZXRUaW1lKCkgLSAxMCAqIDg2NDAwMDAwLFxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIHtcclxuICAgICAgICAgICAgICAgIGRheTogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxyXG4gICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAucmVwbGFjZShcIixcIiwgXCJcIiksXHJcbiAgICAgICAgICAgIG5hbWU6IFwiQ29tbWVuY2VtZW50XCIsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogXCJDb21tZW5jZW1lbnRcIixcclxuICAgICAgICAgICAgdGlja2V0OiBcIkNvbW1lbmNlbWVudFwiLFxyXG4gICAgICAgICAgICBiaWRfYW1vdW50OiAwLFxyXG4gICAgICAgICAgICBhbW91bnQ6IDAsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fdHlwZTogXCJDb21tZW5jZW1lbnQgQXVjdGlvblwiLFxyXG4gICAgICAgICAgICBzdGF0dXM6IFwiQ29tbWVuY2VtZW50XCIsXHJcbiAgICAgICAgICAgIGFjdGlvbjogbnVsbCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICAuLi5kYXRhLm1hcCgoZywgaWR4KSA9PiAoe1xyXG4gICAgICAgICAgICBfaWQ6IGcuX2lkLFxyXG4gICAgICAgICAgICBpZDogaWR4ICsgMixcclxuICAgICAgICAgICAgZGF0ZTogbmV3IERhdGUoZy5hdWN0aW9uX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIHtcclxuICAgICAgICAgICAgICBkYXk6IFwibnVtZXJpY1wiLFxyXG4gICAgICAgICAgICAgIG1vbnRoOiBcInNob3J0XCIsXHJcbiAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICBuYW1lOiBnLnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBnLnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgdGlja2V0OiBnLnRpY2tldCxcclxuICAgICAgICAgICAgYmlkX2Ftb3VudDogTnVtYmVyKGcuZGl2aWRlbnQpICsgTnVtYmVyKGcuY29tbWlzc2lvbiksXHJcbiAgICAgICAgICAgIGFtb3VudDogZy53aW5fYW1vdW50LFxyXG4gICAgICAgICAgICBhdWN0aW9uX3R5cGU6XHJcbiAgICAgICAgICAgICAgZy5hdWN0aW9uX3R5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgIGcuYXVjdGlvbl90eXBlLnNsaWNlKDEpICtcclxuICAgICAgICAgICAgICBcIiBBdWN0aW9uXCIsXHJcbiAgICAgICAgICAgIHN0YXR1czogIWc/LmlzUHJpemVkXHJcbiAgICAgICAgICAgICAgPyBcIlVuIFByaXplZFwiXHJcbiAgICAgICAgICAgICAgOiBnPy5pc1ByaXplZCA9PT0gXCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgID8gXCJQcml6ZWRcIlxyXG4gICAgICAgICAgICAgICAgOiBcIlVuIFByaXplZFwiLFxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiAhZz8udXNlcl9pZD8uX2lkIHx8ICFnPy5ncm91cF9pZD8uX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVBheW1lbnRPdXQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZy5ncm91cF9pZD8uX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGcudXNlcl9pZD8uX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGcudGlja2V0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBvdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZy5faWQsIGlkeCArIDIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZCB0ZXh0LXhsIGN1cnNvci1wb2ludGVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9KSksXHJcbiAgICAgICAgXTtcclxuICAgICAgICBzZXRUYWJsZUF1Y3Rpb25zKGZvcm1hdHRlZCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICBzZXRUYWJsZUF1Y3Rpb25zKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRPdXQgPSBhc3luYyAoZ3JvdXBJZCwgdXNlcklkLCB0aWNrZXQpID0+IHtcclxuICAgIGlmICghdXNlcklkIHx8ICFncm91cElkIHx8ICF0aWNrZXQpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBcIi9hdWN0aW9uL2dldC1hdWN0aW9uLWJ5LXVzZXItZ3JvdXAtdGlja2V0XCIsXHJcbiAgICAgICAgeyBwYXJhbXM6IHsgdXNlcl9pZDogdXNlcklkLCBncm91cF9pZDogZ3JvdXBJZCwgdGlja2V0IH0gfSxcclxuICAgICAgKTtcclxuICAgICAgc2V0UGF5bWVudERldGFpbHMoe1xyXG4gICAgICAgIGN1c3RvbWVyTmFtZTogZGF0YS51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiBkYXRhLmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgIHdpbkFtb3VudDogZGF0YS53aW5fYW1vdW50LFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBncm91cF9pZDogZGF0YS5ncm91cF9pZD8uX2lkLFxyXG4gICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuICAgICAgICBhbW91bnQ6IGRhdGEud2luX2Ftb3VudCxcclxuICAgICAgICB0aWNrZXQsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgICBzZXRTaG93UGF5bWVudE1vZGFsKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc3QgbXNnID0gZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlO1xyXG4gICAgICBpZiAoZXJyb3IucmVzcG9uc2U/LnN0YXR1cyA9PT0gNDA0ICYmIG1zZyA9PT0gXCJBdWN0aW9uIG5vdCBmb3VuZFwiKSB7XHJcbiAgICAgICAgTW9kYWwud2FybmluZyh7XHJcbiAgICAgICAgICB0aXRsZTogXCJBdWN0aW9uIE5vdCBGb3VuZFwiLFxyXG4gICAgICAgICAgY29udGVudDpcclxuICAgICAgICAgICAgXCJObyBhdWN0aW9uIHdhcyBmb3VuZCBmb3IgdGhlIHNlbGVjdGVkIHVzZXIsIGdyb3VwLCBhbmQgdGlja2V0LlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIE1vZGFsLmVycm9yKHtcclxuICAgICAgICAgIHRpdGxlOiBcIkVycm9yIEZldGNoaW5nIFdpbiBBbW91bnRcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IFwiU29tZXRoaW5nIHdlbnQgd3Jvbmcgd2hpbGUgdHJ5aW5nIHRvIGZldGNoIHdpbiBhbW91bnQuXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCwgc2kpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChgL2F1Y3Rpb24vZ2V0LWF1Y3Rpb24tYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAoeyAuLi5kYXRhLCBTSV9udW1iZXI6IHNpIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcblxyXG4gICAgaWYgKCFpc1ZhbGlkKSByZXR1cm47XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0RGlzYWJsZWQodHJ1ZSk7XHJcbiAgICAgIHNldFNob3dQYXltZW50TW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpO1xyXG5cclxuICAgICAgY29uc3QgdXNyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICBsZXQgYWRtaW5fdHlwZSA9IG51bGw7XHJcblxyXG4gICAgICBpZiAodXNyKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSB1c2VyIGZyb20gbG9jYWxTdG9yYWdlOlwiLCBlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChmb3JtRGF0YS5kaXNidXJzZW1lbnRfdHlwZSA9PT0gXCJPdGhlcnNcIiAmJiBkaXNidXJzZW1lbnRUeXBlKSB7XHJcbiAgICAgICAgZm9ybURhdGEuZGlzYnVyc2VtZW50X3R5cGUgPSBkaXNidXJzZW1lbnRUeXBlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWRUaWNrZXRzID0gcGF5bWVudEdyb3VwVGlja2V0cy5tYXAoXHJcbiAgICAgICAgKHsgZ3JvdXBfaWQsIHRpY2tldCB9KSA9PiAoe1xyXG4gICAgICAgICAgZ3JvdXBfaWQsXHJcbiAgICAgICAgICB0aWNrZXRfbnVtYmVyOiB0aWNrZXQsXHJcbiAgICAgICAgfSksXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogZm9ybWF0dGVkVGlja2V0cyxcclxuICAgICAgICBhZG1pbl90eXBlOiBhZG1pbl90eXBlPy5faWQsXHJcbiAgICAgICAgcGF5X2ZvcjogcGF5bWVudFR5cGUsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBpZiAoXHJcbiAgICAgICAgIWZvcm1hdHRlZFRpY2tldHMubGVuZ3RoICYmXHJcbiAgICAgICAgc2VsZWN0ZWRHcm91cElkICYmXHJcbiAgICAgICAgcGF5bWVudEdyb3VwVGlja2V0c1swXT8udGlja2V0XHJcbiAgICAgICkge1xyXG4gICAgICAgIHBheWxvYWQuZ3JvdXBfaWQgPSBzZWxlY3RlZEdyb3VwSWQ7XHJcbiAgICAgICAgcGF5bG9hZC50aWNrZXQgPSBwYXltZW50R3JvdXBUaWNrZXRzWzBdLnRpY2tldDtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICBcIi9wYXltZW50LW91dC9hZGQtcGF5bWVudHMtYW5kLW1hcmstcHJpemVkXCIsXHJcbiAgICAgICAgcGF5bG9hZCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gMjAwICYmIHJlc3BvbnNlLnN0YXR1cyA8IDMwMCkge1xyXG4gICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICBncm91cF9pZDogXCJcIixcclxuICAgICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgICAgIHRpY2tldDogXCJcIixcclxuICAgICAgICAgIGRpc2J1cnNlbWVudF90eXBlOiBcIkF1Y3Rpb24gV2lubmluZyBQYXlvdXRcIixcclxuICAgICAgICAgIG5vdGU6IFwiXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gUmVmcmVzaCByZWNlbnQgcGF5b3V0cyBhZnRlciBzdWNjZXNzZnVsIHBheW1lbnRcclxuICAgICAgICBmZXRjaFJlY2VudFBheW91dHMoKTtcclxuICAgICAgfVxyXG4gICAgICAvLyB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc3VibWl0dGluZyBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgc2V0U2hvd1BheW1lbnRNb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgdGlja2V0OiBcIlwiLFxyXG4gICAgICAgIGRpc2J1cnNlbWVudF90eXBlOiBcIkF1Y3Rpb24gV2lubmluZyBQYXlvdXRcIixcclxuICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICAgIHNldFJlcmVuZGVyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldERpc2FibGVkKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdFBheW1lbnRvdXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlUGF5bWVudEZvcm0oKTtcclxuICAgIGlmICghaXNWYWxpZCkgcmV0dXJuO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHVzciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgICAgbGV0IGFkbWluX3R5cGUgPSBudWxsO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGlmICh1c3IpIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHBhcnNlIHVzZXI6XCIsIGUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBCdWlsZCBiYXNlIHBheWxvYWRcclxuICAgICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgcGF5X2RhdGU6IHBheW91dERhdGEucGF5X2RhdGUsXHJcbiAgICAgICAgYW1vdW50OiBwYXlvdXREYXRhLmFtb3VudCxcclxuICAgICAgICBwYXlfdHlwZTogcGF5b3V0RGF0YS5wYXlfdHlwZSxcclxuICAgICAgICB0cmFuc2FjdGlvbl9pZDogcGF5b3V0RGF0YS50cmFuc2FjdGlvbl9pZCB8fCB1bmRlZmluZWQsXHJcbiAgICAgICAgY2hlcXVlX251bWJlcjogcGF5b3V0RGF0YS5jaGVxdWVfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgY2hlcXVlX2RhdGU6IHBheW91dERhdGEuY2hlcXVlX2RhdGUgfHwgXCJcIixcclxuICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBwYXlvdXREYXRhLmNoZXF1ZV9iYW5rX25hbWUgfHwgXCJcIixcclxuICAgICAgICBjaGVxdWVfYmFua19icmFuY2g6IHBheW91dERhdGEuY2hlcXVlX2JhbmtfYnJhbmNoIHx8IFwiXCIsXHJcbiAgICAgICAgbm90ZTogcGF5b3V0RGF0YS5ub3RlIHx8IFwiXCIsXHJcbiAgICAgICAgYWRtaW5fdHlwZTogYWRtaW5fdHlwZT8uX2lkLFxyXG4gICAgICAgIGRpc2J1cnNlbWVudF90eXBlOlxyXG4gICAgICAgICAgcGF5b3V0RGF0YS5kaXNidXJzZW1lbnRfdHlwZSA9PT0gXCJPdGhlcnNcIlxyXG4gICAgICAgICAgICA/IGRpc2J1cnNlbWVudFR5cGUgfHwgXCJPdGhlcnNcIlxyXG4gICAgICAgICAgICA6IHBheW91dERhdGEuZGlzYnVyc2VtZW50X3R5cGUsXHJcbiAgICAgIH07XHJcbiAgICAgIHBheWxvYWQudXNlcl9pZCA9IHNlbGVjdGVkR3JvdXA7XHJcblxyXG4gICAgICBpZiAoc2VsZWN0ZWRUaWNrZXRWYWx1ZSkge1xyXG4gICAgICAgIGNvbnN0IHBhcnRzID0gc2VsZWN0ZWRUaWNrZXRWYWx1ZS5zcGxpdChcInxcIik7XHJcblxyXG4gICAgICAgIGlmIChwYXJ0cy5sZW5ndGggPT09IDIpIHtcclxuICAgICAgICAgIHBheWxvYWQuZ3JvdXBfaWQgPSBwYXJ0c1swXS5yZXBsYWNlKFwiY2hpdC1cIiwgXCJcIik7XHJcbiAgICAgICAgICBwYXlsb2FkLnRpY2tldCA9IHBhcnRzWzFdO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgIFwiL3YxL2FkbWluL3BheW1lbnRzLW91dC9vdGhlcnNzXCIsXHJcbiAgICAgICAgcGF5bG9hZCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMCB8fCByZXNwb25zZS5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgIC8vIFJlc2V0IGZvcm1cclxuICAgICAgICBzZXRTZWxlY3RlZEdyb3VwKFwiXCIpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkVGlja2V0VmFsdWUobnVsbCk7XHJcbiAgICAgICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICAgICAgc2V0UGF5bWVudE1vZGVQYXltZW50KFwiY2FzaFwiKTtcclxuXHJcbiAgICAgICAgc2V0UGF5b3V0RGF0YSh7XHJcbiAgICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgICBjaGVxdWVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgICAgY2hlcXVlX2RhdGU6IFwiXCIsXHJcbiAgICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgY2hlcXVlX2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gICAgICAgICAgZGlzYnVyc2VtZW50X3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGF5bWVudCBPdXQgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlBheW1lbnQgQWRkZWQgRmFpbGVkXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzdWJtaXR0aW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJFcnJvciBzdWJtaXR0aW5nIHBheW1lbnQgZGF0YVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTaG93UGF5bWVudE1vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKGZhbHNlKTtcclxuICAgICAgLy8gc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICBzZXRSZXJlbmRlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3ZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cFwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJiaWRfYW1vdW50XCIsIGhlYWRlcjogXCJCaWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiV2luIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX3R5cGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gVHlwZVwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3Qgc2VsZWN0ZWRuZXdHcm91cCA9IGdyb3Vwcy5maW5kKChnKSA9PiBnLl9pZCA9PT0gc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCk7XHJcbiAgY29uc3QgZGlzcGxheURhdGEgPSBzaG93UmVjZW50UGF5b3V0cyA/IHJlY2VudFBheW91dHMgOiBUYWJsZUF1Y3Rpb25zO1xyXG4gIGNvbnN0IHRvdGFsV2luQW1vdW50ID0gZGlzcGxheURhdGEucmVkdWNlKFxyXG4gICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgKE51bWJlcihpdGVtLndpbl9hbW91bnQpIHx8IDApLFxyXG4gICAgMCxcclxuICApO1xyXG4gIGNvbnN0IHRvdGFsQmlkQW1vdW50ID0gZGlzcGxheURhdGEucmVkdWNlKFxyXG4gICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgKE51bWJlcihpdGVtLmJpZF9hbW91bnQpIHx8IDApLFxyXG4gICAgMCxcclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgIC5jdXN0b20tc2VsZWN0IDpnbG9iYWwoLmFudC1zZWxlY3Qtc2VsZWN0b3IpIHtcclxuICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICNkMWQ1ZGI7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAwLjVyZW07XHJcbiAgICAgICAgICBwYWRkaW5nOiAwLjVyZW0gMC43NXJlbTtcclxuICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcbiAgICAgICAgICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMDUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmN1c3RvbS1zZWxlY3Q6aG92ZXIgOmdsb2JhbCguYW50LXNlbGVjdC1zZWxlY3Rvcikge1xyXG4gICAgICAgICAgYm9yZGVyLWNvbG9yOiAjNjBhNWZhO1xyXG4gICAgICAgICAgYm94LXNoYWRvdzpcclxuICAgICAgICAgICAgMCA0cHggNnB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjEpLFxyXG4gICAgICAgICAgICAwIDJweCA0cHggLTFweCByZ2JhKDAsIDAsIDAsIDAuMDYpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmN1c3RvbS1zZWxlY3QtZm9jdXNlZCA6Z2xvYmFsKC5hbnQtc2VsZWN0LXNlbGVjdG9yKSB7XHJcbiAgICAgICAgICBib3JkZXItY29sb3I6ICMzYjgyZjYgIWltcG9ydGFudDtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDNweCByZ2JhKDU5LCAxMzAsIDI0NiwgMC4xKSAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgICAgYH08L3N0eWxlPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG5cclxuICAgICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgey8qIFRhYiBOYXZpZ2F0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCItbWItcHggZmxleCBzcGFjZS14LThcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYihcImdlbmVyYWxcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gc2V0U2hvd1NpZGViYXIodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMiBweC0xIGJvcmRlci1iLTIgZm9udC1tZWRpdW0gdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJnZW5lcmFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItdmlvbGV0LTYwMCB0ZXh0LXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENoaXQgUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVGFiKFwiY2hpdC1jYW5jZWxcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd1NpZGViYXIoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTEgYm9yZGVyLWItMiBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYW5zaXRpb24tY29sb3JzICR7XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImNoaXQtY2FuY2VsXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItdmlvbGV0LTYwMCB0ZXh0LXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENoaXQgQ2FuY2VsbGF0aW9uIFBheW1lbnRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd1BheW91dE1vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXZpb2xldC05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBob3ZlcjpiZy12aW9sZXQtOTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICsgQWRkIFByZS1BdWN0aW9uIFBheW91dFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9wcml6ZWQtY3VzdG9tZXItcmVwb3J0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgdGV4dC1zbSBib3JkZXIgYm9yZGVyLWJsdWUtNTAwIHRleHQtYmx1ZS02MDAgcm91bmRlZFxyXG4gICAgICBob3ZlcjpiZy1ibHVlLTUwIGhvdmVyOnRleHQtYmx1ZS03MDAgaG92ZXI6Ym9yZGVyLWJsdWUtNjAwXHJcbiAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgVmlldyBSZXBvcnRcclxuICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJnZW5lcmFsXCIgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMCBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPkNISVQ8L3NwYW4+IFBheW1lbnQgT3V0XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJtYi0zIHJlbGF0aXZlIG10LTNcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIG1iLTIgdGV4dC1ncmF5LTgwMCB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IG9yIFNlYXJjaCBHcm91cFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgbWwtMVwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXthc3luYyAodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSBcInJlY2VudF9wYXlvdXRcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGZldGNoUmVjZW50UGF5b3V0cygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoXCJyZWNlbnRfcGF5b3V0XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dSZWNlbnRQYXlvdXRzKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dSZWNlbnRQYXlvdXRzKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkKHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVHcm91cEF1Y3Rpb24odmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBvciBzZWxlY3QgYSBncm91cC4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdWZmaXhJY29uPXs8U2VhcmNoT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgbm90Rm91bmRDb250ZW50PVwiTm8gZ3JvdXBzIGZvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGRyb3Bkb3duQ2xhc3NOYW1lPVwicm91bmRlZC1sZyBzaGFkb3ctbGcgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9XCJyZWNlbnRfcGF5b3V0XCIgdmFsdWU9XCJyZWNlbnRfcGF5b3V0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlY2VudCBQYXlvdXRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2cuX2lkfSB2YWx1ZT17Zy5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtnLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbXQtMS41IHRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEluZm9DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJtci0xXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIFN0YXJ0IHR5cGluZyB0byBzZWFyY2ggb3IgY2xpY2sgdG8gc2VsZWN0IGZyb20gdGhlIGxpc3RcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7IXNob3dSZWNlbnRQYXlvdXRzICYmXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlcmVkQXVjdGlvblswXT8uZ3JvdXBfaWQ/Lmdyb3VwX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwLTMgYmctZ3JheS01MCByb3VuZGVkLW1kIGJvcmRlci1sLTQgYm9yZGVyLWJsdWUtNTAwIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtbWVkaXVtIG1yLTJcIj5CYWxhbmNlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCBtci0xIG10LTFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2RvdWJsZS5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAge3Nob3dSZWNlbnRQYXlvdXRzID8gKFxyXG4gICAgICAgICAgICAgICAgICBpc0xvYWRpbmdSZWNlbnQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ1JlY2VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGE9XCJSZWNlbnQgUGF5b3V0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKSA6IHJlY2VudFBheW91dHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTUwIHRvLWVtZXJhbGQtNTAgYm9yZGVyLWwtNCBib3JkZXItZ3JlZW4tNTAwIHJvdW5kZWQtbGcgcC00IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWNlbnQgUGF5bWVudCBPdXQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNob3dpbmcgcmVjZW50bHkgY29tcGxldGVkIGNoaXQgcGF5b3V0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHJvdW5kZWQteGwgcHgtNCBweS0zIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTgwMCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFJlY29yZHM6IHtyZWNlbnRQYXlvdXRzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tODAwIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgV2luIEFtb3VudDog4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG90YWxXaW5BbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tODAwIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgQmlkIEFtb3VudDog4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG90YWxCaWRBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihyZWNlbnRQYXlvdXRzLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlJlY2VudF9QYXlvdXRzLmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlJlY2VudCBQYXlvdXRzIFJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTAgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTm8gcmVjZW50IHBheW91dHMgZm91bmRcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKSA6IFRhYmxlQXVjdGlvbnMubGVuZ3RoID8gKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIHshc2hvd1JlY2VudFBheW91dHMgJiYgVGFibGVBdWN0aW9ucy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MCB0by1lbWVyYWxkLTUwIGJvcmRlci1sLTQgYm9yZGVyLWdyZWVuLTUwMCByb3VuZGVkLWxnIHAtNCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkbmV3R3JvdXA/Lmdyb3VwX25hbWUgfHwgXCJHcm91cFwifSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2hvd2luZyBhdWN0aW9uIHdpbm5lcnMgZm9yIHNlbGVjdGVkIGdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgcm91bmRlZC14bCBweC00IHB5LTMgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tODAwIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUmVjb3Jkczoge1RhYmxlQXVjdGlvbnMubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTgwMCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFdpbiBBbW91bnQ6IOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RvdGFsV2luQW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlQXVjdGlvbnMsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkdlbmVyYWwgUGF5bWVudCBPdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCIsIFwiQmFsYW5jZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkbmV3R3JvdXA/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvdWJsZS5hbW91bnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEdlbmVyYWwgUGF5bWVudCBPdXQuY3N2YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9XCJBdWN0aW9uIERhdGFcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgVGFibGVBdWN0aW9ucy5sZW5ndGggPT09IDAgJiYgISFzZWxlY3RlZEF1Y3Rpb25Hcm91cElkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8Q2hpdENhbmNlbFBheW1lbnRPdXQgc2hvd1NpZGViYXI9e3Nob3dTaWRlYmFyfSAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFBheW1lbnQgRHJhd2VyICovfVxyXG4gICAgICAgIDxEcmF3ZXJcclxuICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgYm9yZGVyLWIgcGItMiBibG9ja1wiPlxyXG4gICAgICAgICAgICAgIENoaXQgUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgb3Blbj17c2hvd1BheW1lbnRNb2RhbH1cclxuICAgICAgICAgIG9rVGV4dD1cIlN1Ym1pdFwiXHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93UGF5bWVudE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInBheW1lbnQtZHJhd2VyXCJcclxuICAgICAgICAgIHdpZHRoPXs1MDB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3BheW1lbnREZXRhaWxzID8gKFxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTUgcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudERldGFpbHMuY3VzdG9tZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktMTAwIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudERldGFpbHMuZ3JvdXBOYW1lfVxyXG4gICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktMTAwIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgVGlja2V0XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0aWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JheS02MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS50aWNrZXQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFdpbiBBbW91bnRcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50RGV0YWlscy53aW5BbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS0xMDAgcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmF5LTYwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHBheW1lbnREZXRhaWxzLndpbkFtb3VudCB8fCAwKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgIFBheWFibGUgQW1vdW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHctZnVsbCBwLTNcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JheS02MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5hbW91bnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmFtb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBEaXNidXJzZW1lbnQgVHlwZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZGlzYnVyc2VtZW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGlzYnVyc2VtZW50X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocCkgPT4gKHsgLi4ucCwgcGF5X2RhdGU6IGUudGFyZ2V0LnZhbHVlIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB3LWZ1bGwgcC0zXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRNb2RlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudE1vZGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmVcIj5PbmxpbmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPkNoZXF1ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7bW9kaWZ5UGF5bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzdXNwZW5zZVwiPlN1c3BlbnNlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY3JlZGl0XCI+Q3JlZGl0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWRqdXN0bWVudFwiPkFkanVzdG1lbnQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvdGhlcnNcIj5PdGhlcnM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7cGF5bWVudE1vZGUgPT09IFwib25saW5lXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEICpcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHctZnVsbCBwLTNcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDU+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDaGVxdWUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDaGVxdWUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uY2hlcXVlX2RhdGU/LnNwbGl0KFwiVFwiKVswXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDaGVxdWUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzFlM2E4YV0gZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IGJnLWdyYXktNTAgZm9jdXM6Ymctd2hpdGUgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQmFuayBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBCcmFuY2hcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX2JhbmtfYnJhbmNofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJhbmsgQnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnREZXRhaWxzLm5vdGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnREZXRhaWxzKChwKSA9PiAoeyAuLi5wLCBub3RlOiBlLnRhcmdldC52YWx1ZSB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyByZXNpemUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGFueSBhZGRpdGlvbmFsIG5vdGVzIGhlcmUuLi5cIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBwdC00IGJvcmRlci10IG10LTZcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1BheW1lbnRNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yIHJvdW5kZWQtbGcgYmctYmx1ZS02MDAgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFN1Ym1pdFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC02NFwiPlxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9EcmF3ZXI+XHJcblxyXG4gICAgICAgIHsvKiBhZGQgcGF5bWVudH1cclxuXHJcbiAgICAgICAgey8qIFZpZXcgQXVjdGlvbiBNb2RhbCAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIG9wZW49e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpfVxyXG4gICAgICAgICAgd2lkdGg9ezgwMH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1Y3Rpb24tbW9kYWxcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBwYi00IG1iLTZcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgVmlldyBBdWN0aW9uIERldGFpbHNcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIEJhc2ljIEluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTSSBOb1xyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFVwZGF0ZUdyb3VwPy5TSV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRVcGRhdGVHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Ake2N1cnJlbnRVcGRhdGVHcm91cD8udXNlcl9pZD8uZnVsbF9uYW1lfSB8ICR7Y3VycmVudFVwZGF0ZUdyb3VwPy50aWNrZXR9YH1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBXaW5uaW5nIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrl7Y3VycmVudFVwZGF0ZUdyb3VwPy53aW5fYW1vdW50Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBvcGVuPXtzaG93UGF5b3V0TW9kYWx9XHJcbiAgICAgICAgICBvbkNhbmNlbD17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7XHJcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVGlja2V0VmFsdWUobnVsbCk7XHJcbiAgICAgICAgICAgIHNldFNob3dQYXlvdXRNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgd2lkdGg9ezgwMH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1Y3Rpb24tbW9kYWxcIlxyXG4gICAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0IFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQWRkIFByZS1BdWN0aW9uIFBheW91dFxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIHsvKiBDVVNUT01FUiBTRUNUSU9OICovfVxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgJHtmaWVsZFNpemUuaGVpZ2h0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUN1c3RvbWVyUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtncm91cC5mdWxsX25hbWV9IHwgJHtncm91cC5waG9uZV9udW1iZXJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwICYgVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cCB8IFRpY2tldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRUaWNrZXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVGlja2V0VmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBoLTE0XCJcclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRBdWN0aW9uLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cE5hbWUgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRyeT8uZW5yb2xsbWVudD8uZ3JvdXA/Lmdyb3VwX25hbWUgfHwgXCJVbm5hbWVkIEdyb3VwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cElkID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5faWQgfHwgYG1pc3NpbmctJHtpbmRleH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGlja2V0ID0gZW50cnk/LmVucm9sbG1lbnQ/LnRpY2tldHMgfHwgXCJVbmtub3duXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBrZXkgPSBgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2tleX0gdmFsdWU9e2tleX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwTmFtZX0gfCB7dGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshbW9kaWZ5UGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5b3V0RGF0YS5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgaC0xNFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW91dERhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmFtb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBEaXNidXJzZW1lbnQgVHlwZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRpc2J1cnNlbWVudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICBwYXlvdXREYXRhLmRpc2J1cnNlbWVudF90eXBlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkFkdmFuY2UgUGF5b3V0IEJlZm9yZSBBdWN0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGFueTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHtkaXNidXJzZW1lbnRUeXBlcy5tYXAoKGRUeXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17ZFR5cGUua2V5fSB2YWx1ZT17ZFR5cGUudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZFR5cGUudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGlzYnVyc2VtZW50X3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGlzYnVyc2VtZW50X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRNb2RlQ2hhbmdlUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudE1vZGVQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPk9ubGluZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5DaGVxdWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7bW9kaWZ5UGF5bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic3VzcGVuc2VcIj5TdXNwZW5zZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY3JlZGl0XCI+Q3JlZGl0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhZGp1c3RtZW50XCI+QWRqdXN0bWVudDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3RoZXJzXCI+T3RoZXJzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsvKiBUaWNrZXQgc3BsaXQgY2FsY3VsYXRpb24gb25seSBmb3IgY3VzdG9tZXJzIHdpdGggdGlja2V0cyAqL31cclxuICAgICAgICAgICAgICB7cGF5b3V0RGF0YS5hbW91bnQgJiYgcGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGggPiAxICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgSW5kaXZpZHVhbCBUaWNrZXQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGhvdmVyOmN1cnNvci1ub3QtYWxsb3dlZCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwidG90YWxBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgIE51bWJlcihwYXlvdXREYXRhLmFtb3VudCkgLyBwYXltZW50R3JvdXBUaWNrZXRzLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7cGF5bWVudE1vZGVQYXltZW50ID09PSBcIm9ubGluZVwiICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW91dERhdGEudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBUcmFuc2FjdGlvbiBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge3BheW1lbnRNb2RlUGF5bWVudCA9PT0gXCJjaGVxdWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDU+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDaGVxdWUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5b3V0RGF0YS5jaGVxdWVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDaGVxdWUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXlvdXREYXRhPy5jaGVxdWVfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDaGVxdWUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzFlM2E4YV0gZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IGJnLWdyYXktNTAgZm9jdXM6Ymctd2hpdGUgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW91dERhdGEuY2hlcXVlX2JhbmtfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQmFuayBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBCcmFuY2hcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5b3V0RGF0YS5jaGVxdWVfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2VQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJhbmsgQnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtzaG93T3RoZXJzRmllbGQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJvdGhlcnNGaWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgT3RoZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm90aGVyc0ZpZWxkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkaXNidXJzZW1lbnRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGlzYnVyc2VtZW50VHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU3BlY2lmeSBpZiB5b3VyIG9wdGlvbiBpcyBub3QgbGlzdGVkIGFib3ZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVEaXNidXJzZW1lbnRUeXBlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRpc2J1cnNlbWVudF90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRpc2J1cnNlbWVudF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgcm93cz17Mn1cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW91dERhdGEubm90ZX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb3RlIGlmIGFueT9cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlUGF5bWVudH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXZpb2xldC01MCBwLTMgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBEaXNidXJzZWQgQnlcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2FkbWluTmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBMZWZ0IHNpZGUgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17d2hhdHNhcHBFbmFibGVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0V2hhdHNhcHBFbmFibGVkKGUudGFyZ2V0LmNoZWNrZWQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgYWNjZW50LWdyZWVuLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICBTZW5kIHZpYSBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogUmlnaHQgc2lkZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1ncmVlbi02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHBTcXVhcmUgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5XaGF0c0FwcDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgcHQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dQYXlvdXRNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRpY2tldFZhbHVlKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW91dERhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHBheV9kYXRlOiB0b2RheSxcclxuICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGNoZXF1ZV9kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlcXVlX2JhbmtfbmFtZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2J1cnNlbWVudF90eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbm90ZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiU2F2aW5nIFBheW1lbnQgT3V0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlU3VibWl0UGF5bWVudG91dChlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhdmUgUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEdlbmVyYWxQYXltZW50T3V0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvR2VuZXJhbFBheW1lbnRPdXQuanN4In0=