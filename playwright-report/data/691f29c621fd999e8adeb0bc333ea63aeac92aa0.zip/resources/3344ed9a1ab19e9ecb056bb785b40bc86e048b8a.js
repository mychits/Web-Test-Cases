import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoanPayoutReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import imageInput from "/src/assets/images/Agent.png?import";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
const LoanPayoutReport = () => {
  _s();
  const [dataTable, setDataTable] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedToDate, setSelectedToDate] = useState("");
  const [showFilterField, setShowFilterField] = useState(false);
  const [summary, setSummary] = useState({
    totalAmount: 0,
    totalCount: 0,
    totalUsers: 0
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    user: "",
    filterType: "Today"
  });
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };
  const formatDate = (date) => date.toLocaleDateString("en-CA");
  const handleSelectFilter = (value) => {
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    let from = "";
    let to = "";
    if (value === "Today") {
      from = to = formatDate(today);
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(today.getDate() - 1);
      from = to = formatDate(y);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "Custom") {
      setShowFilterField(true);
      return;
    }
    setSelectedFromDate(from);
    setSelectedToDate(to);
  };
  useEffect(() => {
    handleSelectFilter(formData.filterType);
  }, [formData.filterType]);
  useEffect(() => {
    const fetchUsers = async () => {
      const res = await api.get("/user/get-user");
      setUsers(res.data || []);
    };
    fetchUsers();
  }, []);
  const fetchLoanPayments = async () => {
    try {
      setLoading(true);
      let url = `/payment-out/get-loan-payout`;
      if (formData?.user) {
        url += `/${formData.user}`;
      }
      const queryParams = new URLSearchParams();
      if (selectedFromDate) {
        queryParams.append("from_date", selectedFromDate);
      }
      if (selectedToDate) {
        queryParams.append("to_date", selectedToDate);
      }
      if (queryParams.toString()) {
        url += `?${queryParams.toString()}`;
      }
      const res = await api.get(url);
      const data = res?.data?.data || [];
      const totalAmount = data.reduce(
        (sum, item) => sum + Number(item?.amount || 0),
        0
      );
      const uniqueUsers = new Set(
        data.map((d) => d?.user_id?._id).filter(Boolean)
      );
      setSummary({
        totalAmount,
        totalCount: data.length,
        totalUsers: uniqueUsers.size
      });
      const formatted = data.map((item, index) => ({
        id: item?._id,
        slNo: index + 1,
        name: item?.user_id?.full_name || "-",
        phone: item?.user_id?.phone_number || "-",
        loanId: item?.loan?.loan_id || "-",
        loanAmount: item?.loan?.loan_amount || "-",
        amount: Number(item?.amount || 0),
        payType: item?.pay_type || "-",
        transactionId: item?.transaction_id || "-",
        receipt: item?.receipt_no || "-",
        date: item?.pay_date || "-",
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: [
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-purple-600",
                      onClick: () => {
                        handlePrint(item.loan?._id);
                      },
                      children: "Print"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
                      lineNumber: 158,
                      columnNumber: 17
                    },
                    this
                  )
                }
              ]
            },
            placement: "bottomLeft",
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
              lineNumber: 172,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 151,
            columnNumber: 13
          },
          this
        ) }, item._id, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 150,
          columnNumber: 9
        }, this)
      }));
      setDataTable(formatted);
    } catch (err) {
      console.error("❌ Loan Payment Fetch Error:", err);
    } finally {
      setLoading(false);
    }
  };
  const generateAndOpenPDF = (downloadOnly = false, userData) => {
    const sections = [
      {
        title: "CUSTOMER DETAILS",
        icon: "👤",
        fields: [
          { label: "Full Name", value: userData?.user_id?.full_name },
          { label: "Phone Number", value: userData?.user_id?.phone_number },
          { label: "Email Address", value: userData?.user_id?.email },
          { label: "Address", value: userData?.user_id?.address }
        ]
      },
      {
        title: "LOAN SUMMARY",
        icon: "💰",
        fields: [
          { label: "Loan ID", value: userData?.loan?.loan_id },
          {
            label: "Start Date",
            value: new Date(userData?.loan?.start_date).toLocaleDateString("en-GB").replace(/\//g, "-")
          },
          { label: "Loan Amount", value: userData?.loan?.loan_amount },
          {
            label: "End Date",
            value: new Date(userData?.loan?.end_date).toLocaleDateString("en-GB").replace(/\//g, "-")
          },
          { label: "Service Charges", value: userData?.loan?.service_charges },
          {
            label: "Sanction Date",
            value: new Date(userData?.loan?.loan_sanction_date).toLocaleDateString("en-GB").replace(/\//g, "-")
          },
          {
            label: "Document Charges",
            value: userData?.loan?.document_charges
          },
          {
            label: "Daily Payment",
            value: userData?.loan?.daily_payment_amount
          },
          { label: "Disbursed Amount", value: userData?.amount },
          { label: "Tenure (Days)", value: userData?.loan?.tenure },
          { label: "Receipt No", value: userData?.receipt_no },
          { label: "Transaction ID", value: userData?.transaction_id }
        ]
      },
      {
        title: "REFERRAL INFORMATION",
        icon: "🤝",
        fields: [
          { label: "Referred By", value: userData?.loan?.referred_type },
          {
            label: "Employee Name",
            value: `${userData?.loan?.referred_employee?.name || ""} ${" | "}${userData?.loan?.referred_employee?.phone_number || ""}`.trim() || "N/A"
          }
        ]
      }
    ];
    const doc = new jsPDF("p", "mm", "a4");
    const safeText = (v) => v ? String(v) : "N/A";
    const colors = {
      primary: [0, 38, 124],
      // blue-900
      secondary: [240, 242, 245],
      // gray-100
      accent: [0, 38, 124],
      // blue-500
      textMain: [0, 0, 0],
      // gray-800
      textLight: [0, 0, 0],
      // gray-500
      border: [200, 205, 215]
      // gray-200
    };
    let y = 65;
    if (imageInput) {
      doc.addImage(imageInput, "PNG", 90, 8, 30, 30);
    }
    const loanId = userData?.loan?.loan_id || "N/A";
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(...colors.primary);
    doc.text(`Loan ID: ${loanId}`, 195, 20, { align: "right" });
    const processedBy = userData?.admin_type?.name || "N/A";
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...colors.textMain);
    doc.text(`Processed By: ${processedBy}`, 195, 28, { align: "right" });
    doc.setFillColor(...colors.primary);
    doc.rect(0, 40, 210, 15, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("LOAN SANCTION CERTIFICATE", 105, 49, { align: "center" });
    const drawField = (label, value, x, y2) => {
      const boxWidth2 = 85;
      const labelWidth = 38;
      const valueX = x + labelWidth;
      const safe = safeText(value);
      const wrappedValue = doc.splitTextToSize(safe, boxWidth2 - labelWidth - 5);
      const lineHeight = 4;
      const boxHeight2 = Math.max(9, wrappedValue.length * lineHeight + 4);
      doc.setDrawColor(...colors.border);
      doc.setLineWidth(0.1);
      doc.rect(x, y2, boxWidth2, boxHeight2);
      doc.setTextColor(...colors.primary);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.text(label.toUpperCase() + ":", x + 3, y2 + 5);
      doc.setTextColor(...colors.textMain);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      let textY = y2 + 5;
      wrappedValue.forEach((line) => {
        doc.text(line, valueX, textY);
        textY += lineHeight;
      });
      return y2 + boxHeight2 + 2;
    };
    sections.forEach((sec) => {
      const rectX = 15;
      const rectWidth = 180;
      const rectHeight = 10;
      doc.setFillColor(...colors.secondary);
      doc.rect(rectX, y, rectWidth, rectHeight, "F");
      doc.setFillColor(...colors.primary);
      doc.rect(rectX, y, 1.5, rectHeight, "F");
      doc.setTextColor(...colors.primary);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.text(sec.title, rectX + 5, y + 6.5);
      y += 14;
      for (let i = 0; i < sec.fields.length; i += 2) {
        const leftField = sec.fields[i];
        const rightField = sec.fields[i + 1];
        const startY = y;
        const leftY = drawField(leftField.label, leftField.value, 15, startY);
        let rightY = startY;
        if (rightField) {
          rightY = drawField(rightField.label, rightField.value, 110, startY);
        }
        y = Math.max(leftY, rightY);
      }
      y += 6;
    });
    doc.setFontSize(9);
    doc.setTextColor(...colors.textLight);
    doc.setFont("helvetica", "italic");
    doc.text(
      "I hereby declare that the above loan information is true and correct.",
      105,
      y + 10,
      { align: "center" }
    );
    const boxWidth = 50;
    const boxHeight = 18;
    const boxY = y + 18;
    const customerX = 40;
    doc.setDrawColor(...colors.primary);
    doc.setLineWidth(0.5);
    doc.rect(customerX, boxY, boxWidth, boxHeight);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...colors.textMain);
    doc.text(
      "Customer Signature",
      customerX + boxWidth / 2,
      boxY + boxHeight + 5,
      { align: "center" }
    );
    const authX = 120;
    doc.rect(authX, boxY, boxWidth, boxHeight);
    doc.text(
      "Authorized Signatory",
      authX + boxWidth / 2,
      boxY + boxHeight + 5,
      { align: "center" }
    );
    const pageHeight = doc.internal.pageSize.getHeight();
    const footerY = pageHeight - 20;
    doc.setFillColor(...colors.primary);
    doc.rect(0, footerY, 210, 20, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text("VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED", 105, footerY + 7, {
      align: "center"
    });
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.text(
      "#11/36-25, 3rd Floor, 2nd Main, Kathriguppe Main Road, Banashankari 3rd Stage, Bengaluru-560085",
      105,
      footerY + 11,
      { align: "center" }
    );
    doc.text(
      "Mob: 9483900777 | Ph: 080-4979 8763 | Email: info.mychits@gmail.com | www.mychits.co.in",
      105,
      footerY + 15,
      { align: "center" }
    );
    if (downloadOnly) {
      doc.save(`${userData?.borrower?.full_name}_Loan_Request.pdf`);
    } else {
      const pdfBlob = doc.output("blob");
      const pdfUrl = URL.createObjectURL(pdfBlob);
      window.open(pdfUrl, "_blank");
    }
  };
  const handlePrint = async (loanPrintId) => {
    try {
      const res = await api.get(
        `/payment-out/get-loan-payout-by-userid/${loanPrintId}`
      );
      generateAndOpenPDF(false, res.data?.data);
    } catch (error) {
      console.error("PRINT ERROR:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to generate PDF",
        type: "error"
      });
    }
  };
  useEffect(() => {
    if (selectedFromDate && selectedToDate) {
      fetchLoanPayments();
    }
  }, [selectedFromDate, selectedToDate, formData.user]);
  const columns = [
    { key: "slNo", header: "Sl No" },
    { key: "date", header: "Pay Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone", header: "Phone" },
    { key: "loanId", header: "Loan ID" },
    { key: "receipt", header: "Receipt No" },
    { key: "loanAmount", header: "Loan Amount" },
    { key: "payType", header: "Pay Type" },
    { key: "transactionId", header: "Transaction ID" },
    { key: "amount", header: "Paid Amount" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
      lineNumber: 487,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
        lineNumber: 488,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Loan Payment Out Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
        lineNumber: 498,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/3", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-[42px]",
            placeholder: "All Users",
            popupMatchSelectWidth: false,
            showSearch: true,
            filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
            value: formData.user || void 0,
            onChange: (val) => handleAntDSelect("user", val),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
                lineNumber: 515,
                columnNumber: 15
              }, this),
              users.map(
                (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: u.full_name }, u._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
                  lineNumber: 517,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 504,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 503,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/4", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-[42px]",
            value: formData.filterType,
            onChange: (val) => handleAntDSelect("filterType", val),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Today", children: "Today" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
                lineNumber: 531,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
                lineNumber: 532,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "ThisMonth", children: "This Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
                lineNumber: 533,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Custom", children: "Custom" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
                lineNumber: 534,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 526,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 525,
          columnNumber: 11
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/5", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              className: "w-full h-[42px] px-3 border border-gray-300 rounded-lg",
              value: selectedFromDate,
              onChange: (e) => setSelectedFromDate(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
              lineNumber: 542,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 541,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/5", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              className: "w-full h-[42px] px-3 border border-gray-300 rounded-lg",
              value: selectedToDate,
              onChange: (e) => setSelectedToDate(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
              lineNumber: 551,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 550,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 540,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
        lineNumber: 501,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Amount" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 565,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: [
            "₹",
            summary.totalAmount
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 566,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 564,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Transactions" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 570,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalCount }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 571,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 569,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 575,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalUsers }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
            lineNumber: 576,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 574,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
        lineNumber: 563,
        columnNumber: 9
      }, this),
      dataTable.length > 0 && !loading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns,
          data: dataTable,
          exportedFileName: "Loan Payment Out Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
          lineNumber: 582,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: loading }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
        lineNumber: 588,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
      lineNumber: 497,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx",
    lineNumber: 486,
    columnNumber: 5
  }, this);
};
_s(LoanPayoutReport, "hDgH+sv821X6+hs50vjsh1V4+Fg=");
_c = LoanPayoutReport;
export default LoanPayoutReport;
var _c;
$RefreshReg$(_c, "LoanPayoutReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPayoutReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkpzQixTQThYVixVQTlYVTsyQkE3SnRCO0FBQW1CQSxvQkFBaUIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNqQyxPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyx1QkFBdUI7QUFFOUIsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUYsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ0csU0FBU0MsVUFBVSxJQUFJSixTQUFTLEtBQUs7QUFFNUMsUUFBTSxDQUFDSyxrQkFBa0JDLG1CQUFtQixJQUFJTixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDTyxnQkFBZ0JDLGlCQUFpQixJQUFJUixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDUyxpQkFBaUJDLGtCQUFrQixJQUFJVixTQUFTLEtBQUs7QUFFNUQsUUFBTSxDQUFDVyxTQUFTQyxVQUFVLElBQUlaLFNBQVM7QUFBQSxJQUNyQ2EsYUFBYTtBQUFBLElBQ2JDLFlBQVk7QUFBQSxJQUNaQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlqQixTQUFTO0FBQUEsSUFDN0NrQixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXRCLFNBQVM7QUFBQSxJQUN2Q3VCLE1BQU07QUFBQSxJQUNOQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBR0QsUUFBTUMsbUJBQW1CQSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3pDTCxnQkFBWSxDQUFDTSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRixLQUFLLEdBQUdDLE1BQU0sRUFBRTtBQUFBLEVBQ3JEO0FBRUEsUUFBTUUsYUFBYUEsQ0FBQ0MsU0FBU0EsS0FBS0MsbUJBQW1CLE9BQU87QUFHNUQsUUFBTUMscUJBQXFCQSxDQUFDTCxVQUFVO0FBQ3BDakIsdUJBQW1CLEtBQUs7QUFFeEIsVUFBTXVCLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsUUFBSUMsT0FBTztBQUNYLFFBQUlDLEtBQUs7QUFFVCxRQUFJVCxVQUFVLFNBQVM7QUFDckJRLGFBQU9DLEtBQUtQLFdBQVdJLEtBQUs7QUFBQSxJQUM5QixXQUFXTixVQUFVLGFBQWE7QUFDaEMsWUFBTVUsSUFBSSxJQUFJSCxLQUFLRCxLQUFLO0FBQ3hCSSxRQUFFQyxRQUFRTCxNQUFNTSxRQUFRLElBQUksQ0FBQztBQUM3QkosYUFBT0MsS0FBS1AsV0FBV1EsQ0FBQztBQUFBLElBQzFCLFdBQVdWLFVBQVUsYUFBYTtBQUNoQyxZQUFNYSxRQUFRLElBQUlOLEtBQUtELE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTUMsTUFBTSxJQUFJVCxLQUFLRCxNQUFNUSxZQUFZLEdBQUdSLE1BQU1TLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakVQLGFBQU9OLFdBQVdXLEtBQUs7QUFDdkJKLFdBQUtQLFdBQVdjLEdBQUc7QUFBQSxJQUNyQixXQUFXaEIsVUFBVSxVQUFVO0FBQzdCakIseUJBQW1CLElBQUk7QUFDdkI7QUFBQSxJQUNGO0FBRUFKLHdCQUFvQjZCLElBQUk7QUFDeEIzQixzQkFBa0I0QixFQUFFO0FBQUEsRUFDdEI7QUFFQXJELFlBQVUsTUFBTTtBQUNkaUQsdUJBQW1CWCxTQUFTRyxVQUFVO0FBQUEsRUFDeEMsR0FBRyxDQUFDSCxTQUFTRyxVQUFVLENBQUM7QUFHeEJ6QyxZQUFVLE1BQU07QUFDZCxVQUFNNkQsYUFBYSxZQUFZO0FBQzdCLFlBQU1DLE1BQU0sTUFBTTVELElBQUk2RCxJQUFJLGdCQUFnQjtBQUMxQzVDLGVBQVMyQyxJQUFJRSxRQUFRLEVBQUU7QUFBQSxJQUN6QjtBQUNBSCxlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFHTCxRQUFNSSxvQkFBb0IsWUFBWTtBQUNwQyxRQUFJO0FBQ0Y1QyxpQkFBVyxJQUFJO0FBR2YsVUFBSTZDLE1BQU07QUFHVixVQUFJNUIsVUFBVUUsTUFBTTtBQUNsQjBCLGVBQU8sSUFBSTVCLFNBQVNFLElBQUk7QUFBQSxNQUMxQjtBQUdBLFlBQU0yQixjQUFjLElBQUlDLGdCQUFnQjtBQUV4QyxVQUFJOUMsa0JBQWtCO0FBQ3BCNkMsb0JBQVlFLE9BQU8sYUFBYS9DLGdCQUFnQjtBQUFBLE1BQ2xEO0FBRUEsVUFBSUUsZ0JBQWdCO0FBQ2xCMkMsb0JBQVlFLE9BQU8sV0FBVzdDLGNBQWM7QUFBQSxNQUM5QztBQUdBLFVBQUkyQyxZQUFZRyxTQUFTLEdBQUc7QUFDMUJKLGVBQU8sSUFBSUMsWUFBWUcsU0FBUyxDQUFDO0FBQUEsTUFDbkM7QUFHQSxZQUFNUixNQUFNLE1BQU01RCxJQUFJNkQsSUFBSUcsR0FBRztBQUM3QixZQUFNRixPQUFPRixLQUFLRSxNQUFNQSxRQUFRO0FBR2hDLFlBQU1sQyxjQUFja0MsS0FBS087QUFBQUEsUUFDdkIsQ0FBQ0MsS0FBS0MsU0FBU0QsTUFBTUUsT0FBT0QsTUFBTUUsVUFBVSxDQUFDO0FBQUEsUUFDN0M7QUFBQSxNQUNGO0FBRUEsWUFBTUMsY0FBYyxJQUFJQztBQUFBQSxRQUN0QmIsS0FBS2MsSUFBSSxDQUFDQyxNQUFNQSxHQUFHQyxTQUFTQyxHQUFHLEVBQUVDLE9BQU9DLE9BQU87QUFBQSxNQUNqRDtBQUVBdEQsaUJBQVc7QUFBQSxRQUNUQztBQUFBQSxRQUNBQyxZQUFZaUMsS0FBS29CO0FBQUFBLFFBQ2pCcEQsWUFBWTRDLFlBQVlTO0FBQUFBLE1BQzFCLENBQUM7QUFHRCxZQUFNQyxZQUFZdEIsS0FBS2MsSUFBSSxDQUFDTCxNQUFNYyxXQUFXO0FBQUEsUUFDM0NDLElBQUlmLE1BQU1RO0FBQUFBLFFBQ1ZRLE1BQU1GLFFBQVE7QUFBQSxRQUNkRyxNQUFNakIsTUFBTU8sU0FBU1csYUFBYTtBQUFBLFFBQ2xDQyxPQUFPbkIsTUFBTU8sU0FBU2EsZ0JBQWdCO0FBQUEsUUFDdENDLFFBQVFyQixNQUFNc0IsTUFBTUMsV0FBVztBQUFBLFFBQy9CQyxZQUFZeEIsTUFBTXNCLE1BQU1HLGVBQWU7QUFBQSxRQUN2Q3ZCLFFBQVFELE9BQU9ELE1BQU1FLFVBQVUsQ0FBQztBQUFBLFFBQ2hDd0IsU0FBUzFCLE1BQU0yQixZQUFZO0FBQUEsUUFDM0JDLGVBQWU1QixNQUFNNkIsa0JBQWtCO0FBQUEsUUFDdkNDLFNBQVM5QixNQUFNK0IsY0FBYztBQUFBLFFBQzdCekQsTUFBTTBCLE1BQU1nQyxZQUFZO0FBQUEsUUFDeEJDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLENBQUMsT0FBTztBQUFBLFlBQ2pCLE1BQU07QUFBQSxjQUNKQyxPQUFPO0FBQUEsZ0JBQ0w7QUFBQSxrQkFDRUMsS0FBSztBQUFBLGtCQUNMQyxPQUNFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFTLE1BQU07QUFDYkMsb0NBQVlyQyxLQUFLc0IsTUFBTWQsR0FBRztBQUFBLHNCQUM1QjtBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxnQkFFSjtBQUFBLGNBQUM7QUFBQSxZQUVMO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQTtBQUFBLFVBckJqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFzQkEsS0F2QjhDUixLQUFLUSxLQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsTUFFSixFQUFFO0FBRUZqRSxtQkFBYXNFLFNBQVM7QUFBQSxJQUN4QixTQUFTeUIsS0FBSztBQUNaQyxjQUFRQyxNQUFNLCtCQUErQkYsR0FBRztBQUFBLElBQ2xELFVBQUM7QUFDQzFGLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkYscUJBQXFCQSxDQUFDQyxlQUFlLE9BQU9DLGFBQWE7QUFDN0QsVUFBTUMsV0FBVztBQUFBLE1BQ2Y7QUFBQSxRQUNFQyxPQUFPO0FBQUEsUUFDUEMsTUFBTTtBQUFBLFFBQ05DLFFBQVE7QUFBQSxVQUNOLEVBQUVYLE9BQU8sYUFBYWpFLE9BQU93RSxVQUFVcEMsU0FBU1csVUFBVTtBQUFBLFVBQzFELEVBQUVrQixPQUFPLGdCQUFnQmpFLE9BQU93RSxVQUFVcEMsU0FBU2EsYUFBYTtBQUFBLFVBQ2hFLEVBQUVnQixPQUFPLGlCQUFpQmpFLE9BQU93RSxVQUFVcEMsU0FBU3lDLE1BQU07QUFBQSxVQUMxRCxFQUFFWixPQUFPLFdBQVdqRSxPQUFPd0UsVUFBVXBDLFNBQVMwQyxRQUFRO0FBQUEsUUFBQztBQUFBLE1BRTNEO0FBQUEsTUFDQTtBQUFBLFFBQ0VKLE9BQU87QUFBQSxRQUNQQyxNQUFNO0FBQUEsUUFDTkMsUUFBUTtBQUFBLFVBQ04sRUFBRVgsT0FBTyxXQUFXakUsT0FBT3dFLFVBQVVyQixNQUFNQyxRQUFRO0FBQUEsVUFDbkQ7QUFBQSxZQUNFYSxPQUFPO0FBQUEsWUFDUGpFLE9BQU8sSUFBSU8sS0FBS2lFLFVBQVVyQixNQUFNNEIsVUFBVSxFQUN2QzNFLG1CQUFtQixPQUFPLEVBQzFCNEUsUUFBUSxPQUFPLEdBQUc7QUFBQSxVQUN2QjtBQUFBLFVBQ0EsRUFBRWYsT0FBTyxlQUFlakUsT0FBT3dFLFVBQVVyQixNQUFNRyxZQUFZO0FBQUEsVUFDM0Q7QUFBQSxZQUNFVyxPQUFPO0FBQUEsWUFDUGpFLE9BQU8sSUFBSU8sS0FBS2lFLFVBQVVyQixNQUFNOEIsUUFBUSxFQUNyQzdFLG1CQUFtQixPQUFPLEVBQzFCNEUsUUFBUSxPQUFPLEdBQUc7QUFBQSxVQUN2QjtBQUFBLFVBQ0EsRUFBRWYsT0FBTyxtQkFBbUJqRSxPQUFPd0UsVUFBVXJCLE1BQU0rQixnQkFBZ0I7QUFBQSxVQUNuRTtBQUFBLFlBQ0VqQixPQUFPO0FBQUEsWUFDUGpFLE9BQU8sSUFBSU8sS0FBS2lFLFVBQVVyQixNQUFNZ0Msa0JBQWtCLEVBQy9DL0UsbUJBQW1CLE9BQU8sRUFDMUI0RSxRQUFRLE9BQU8sR0FBRztBQUFBLFVBQ3ZCO0FBQUEsVUFDQTtBQUFBLFlBQ0VmLE9BQU87QUFBQSxZQUNQakUsT0FBT3dFLFVBQVVyQixNQUFNaUM7QUFBQUEsVUFDekI7QUFBQSxVQUNBO0FBQUEsWUFDRW5CLE9BQU87QUFBQSxZQUNQakUsT0FBT3dFLFVBQVVyQixNQUFNa0M7QUFBQUEsVUFDekI7QUFBQSxVQUNBLEVBQUVwQixPQUFPLG9CQUFvQmpFLE9BQU93RSxVQUFVekMsT0FBTztBQUFBLFVBQ3JELEVBQUVrQyxPQUFPLGlCQUFpQmpFLE9BQU93RSxVQUFVckIsTUFBTW1DLE9BQU87QUFBQSxVQUN4RCxFQUFFckIsT0FBTyxjQUFjakUsT0FBT3dFLFVBQVVaLFdBQVc7QUFBQSxVQUNuRCxFQUFFSyxPQUFPLGtCQUFrQmpFLE9BQU93RSxVQUFVZCxlQUFlO0FBQUEsUUFBQztBQUFBLE1BRWhFO0FBQUEsTUFDQTtBQUFBLFFBQ0VnQixPQUFPO0FBQUEsUUFDUEMsTUFBTTtBQUFBLFFBQ05DLFFBQVE7QUFBQSxVQUNOLEVBQUVYLE9BQU8sZUFBZWpFLE9BQU93RSxVQUFVckIsTUFBTW9DLGNBQWM7QUFBQSxVQUM3RDtBQUFBLFlBQ0V0QixPQUFPO0FBQUEsWUFDUGpFLE9BQ0UsR0FBR3dFLFVBQVVyQixNQUFNcUMsbUJBQW1CMUMsUUFBUSxFQUFFLElBQUksS0FBSyxHQUFHMEIsVUFBVXJCLE1BQU1xQyxtQkFBbUJ2QyxnQkFBZ0IsRUFBRSxHQUFHd0MsS0FBSyxLQUN6SDtBQUFBLFVBQ0o7QUFBQSxRQUFDO0FBQUEsTUFFTDtBQUFBLElBQUM7QUFHSCxVQUFNQyxNQUFNLElBQUk3SCxNQUFNLEtBQUssTUFBTSxJQUFJO0FBQ3JDLFVBQU04SCxXQUFXQSxDQUFDQyxNQUFPQSxJQUFJQyxPQUFPRCxDQUFDLElBQUk7QUFHekMsVUFBTUUsU0FBUztBQUFBLE1BQ2JDLFNBQVMsQ0FBQyxHQUFHLElBQUksR0FBRztBQUFBO0FBQUEsTUFDcEJDLFdBQVcsQ0FBQyxLQUFLLEtBQUssR0FBRztBQUFBO0FBQUEsTUFDekJDLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBRztBQUFBO0FBQUEsTUFDbkJDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsQ0FBQztBQUFBO0FBQUEsTUFDbEJDLFdBQVcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztBQUFBO0FBQUEsTUFDbkJDLFFBQVEsQ0FBQyxLQUFLLEtBQUssR0FBRztBQUFBO0FBQUEsSUFDeEI7QUFFQSxRQUFJMUYsSUFBSTtBQUdSLFFBQUk1QyxZQUFZO0FBQ2Q0SCxVQUFJVyxTQUFTdkksWUFBWSxPQUFPLElBQUksR0FBRyxJQUFJLEVBQUU7QUFBQSxJQUMvQztBQUVBLFVBQU1vRixTQUFTc0IsVUFBVXJCLE1BQU1DLFdBQVc7QUFDMUNzQyxRQUFJWSxRQUFRLGFBQWEsTUFBTTtBQUMvQlosUUFBSWEsWUFBWSxFQUFFO0FBQ2xCYixRQUFJYyxhQUFhLEdBQUdWLE9BQU9DLE9BQU87QUFDbENMLFFBQUllLEtBQUssWUFBWXZELE1BQU0sSUFBSSxLQUFLLElBQUksRUFBRXdELE9BQU8sUUFBUSxDQUFDO0FBRTFELFVBQU1DLGNBQWNuQyxVQUFVb0MsWUFBWTlELFFBQVE7QUFDbEQ0QyxRQUFJYSxZQUFZLEVBQUU7QUFDbEJiLFFBQUlZLFFBQVEsYUFBYSxRQUFRO0FBQ2pDWixRQUFJYyxhQUFhLEdBQUdWLE9BQU9JLFFBQVE7QUFDbkNSLFFBQUllLEtBQUssaUJBQWlCRSxXQUFXLElBQUksS0FBSyxJQUFJLEVBQUVELE9BQU8sUUFBUSxDQUFDO0FBSXBFaEIsUUFBSW1CLGFBQWEsR0FBR2YsT0FBT0MsT0FBTztBQUNsQ0wsUUFBSW9CLEtBQUssR0FBRyxJQUFJLEtBQUssSUFBSSxHQUFHO0FBQzVCcEIsUUFBSWMsYUFBYSxLQUFLLEtBQUssR0FBRztBQUM5QmQsUUFBSVksUUFBUSxhQUFhLE1BQU07QUFDL0JaLFFBQUlhLFlBQVksRUFBRTtBQUNsQmIsUUFBSWUsS0FBSyw2QkFBNkIsS0FBSyxJQUFJLEVBQUVDLE9BQU8sU0FBUyxDQUFDO0FBRWxFLFVBQU1LLFlBQVlBLENBQUM5QyxPQUFPakUsT0FBT2dILEdBQUd0RyxPQUFNO0FBQ3hDLFlBQU11RyxZQUFXO0FBQ2pCLFlBQU1DLGFBQWE7QUFDbkIsWUFBTUMsU0FBU0gsSUFBSUU7QUFFbkIsWUFBTUUsT0FBT3pCLFNBQVMzRixLQUFLO0FBRzNCLFlBQU1xSCxlQUFlM0IsSUFBSTRCLGdCQUFnQkYsTUFBTUgsWUFBV0MsYUFBYSxDQUFDO0FBRXhFLFlBQU1LLGFBQWE7QUFDbkIsWUFBTUMsYUFBWUMsS0FBS0MsSUFBSSxHQUFHTCxhQUFhN0UsU0FBUytFLGFBQWEsQ0FBQztBQUdsRTdCLFVBQUlpQyxhQUFhLEdBQUc3QixPQUFPTSxNQUFNO0FBQ2pDVixVQUFJa0MsYUFBYSxHQUFHO0FBQ3BCbEMsVUFBSW9CLEtBQUtFLEdBQUd0RyxJQUFHdUcsV0FBVU8sVUFBUztBQUdsQzlCLFVBQUljLGFBQWEsR0FBR1YsT0FBT0MsT0FBTztBQUNsQ0wsVUFBSVksUUFBUSxhQUFhLE1BQU07QUFDL0JaLFVBQUlhLFlBQVksQ0FBQztBQUNqQmIsVUFBSWUsS0FBS3hDLE1BQU00RCxZQUFZLElBQUksS0FBS2IsSUFBSSxHQUFHdEcsS0FBSSxDQUFDO0FBR2hEZ0YsVUFBSWMsYUFBYSxHQUFHVixPQUFPSSxRQUFRO0FBQ25DUixVQUFJWSxRQUFRLGFBQWEsUUFBUTtBQUNqQ1osVUFBSWEsWUFBWSxDQUFDO0FBRWpCLFVBQUl1QixRQUFRcEgsS0FBSTtBQUNoQjJHLG1CQUFhVSxRQUFRLENBQUNDLFNBQVM7QUFDN0J0QyxZQUFJZSxLQUFLdUIsTUFBTWIsUUFBUVcsS0FBSztBQUM1QkEsaUJBQVNQO0FBQUFBLE1BQ1gsQ0FBQztBQUVELGFBQU83RyxLQUFJOEcsYUFBWTtBQUFBLElBQ3pCO0FBRUEvQyxhQUFTc0QsUUFBUSxDQUFDRSxRQUFRO0FBRXhCLFlBQU1DLFFBQVE7QUFDZCxZQUFNQyxZQUFZO0FBQ2xCLFlBQU1DLGFBQWE7QUFFbkIxQyxVQUFJbUIsYUFBYSxHQUFHZixPQUFPRSxTQUFTO0FBQ3BDTixVQUFJb0IsS0FBS29CLE9BQU94SCxHQUFHeUgsV0FBV0MsWUFBWSxHQUFHO0FBRzdDMUMsVUFBSW1CLGFBQWEsR0FBR2YsT0FBT0MsT0FBTztBQUNsQ0wsVUFBSW9CLEtBQUtvQixPQUFPeEgsR0FBRyxLQUFLMEgsWUFBWSxHQUFHO0FBRXZDMUMsVUFBSWMsYUFBYSxHQUFHVixPQUFPQyxPQUFPO0FBQ2xDTCxVQUFJWSxRQUFRLGFBQWEsTUFBTTtBQUMvQlosVUFBSWEsWUFBWSxFQUFFO0FBQ2xCYixVQUFJZSxLQUFLd0IsSUFBSXZELE9BQU93RCxRQUFRLEdBQUd4SCxJQUFJLEdBQUc7QUFFdENBLFdBQUs7QUFFTCxlQUFTMkgsSUFBSSxHQUFHQSxJQUFJSixJQUFJckQsT0FBT3BDLFFBQVE2RixLQUFLLEdBQUc7QUFDN0MsY0FBTUMsWUFBWUwsSUFBSXJELE9BQU95RCxDQUFDO0FBQzlCLGNBQU1FLGFBQWFOLElBQUlyRCxPQUFPeUQsSUFBSSxDQUFDO0FBRW5DLGNBQU1HLFNBQVM5SDtBQUVmLGNBQU0rSCxRQUFRMUIsVUFBVXVCLFVBQVVyRSxPQUFPcUUsVUFBVXRJLE9BQU8sSUFBSXdJLE1BQU07QUFFcEUsWUFBSUUsU0FBU0Y7QUFDYixZQUFJRCxZQUFZO0FBQ2RHLG1CQUFTM0IsVUFBVXdCLFdBQVd0RSxPQUFPc0UsV0FBV3ZJLE9BQU8sS0FBS3dJLE1BQU07QUFBQSxRQUNwRTtBQUVBOUgsWUFBSStHLEtBQUtDLElBQUllLE9BQU9DLE1BQU07QUFBQSxNQUM1QjtBQUVBaEksV0FBSztBQUFBLElBQ1AsQ0FBQztBQUdEZ0YsUUFBSWEsWUFBWSxDQUFDO0FBQ2pCYixRQUFJYyxhQUFhLEdBQUdWLE9BQU9LLFNBQVM7QUFDcENULFFBQUlZLFFBQVEsYUFBYSxRQUFRO0FBQ2pDWixRQUFJZTtBQUFBQSxNQUNGO0FBQUEsTUFDQTtBQUFBLE1BQ0EvRixJQUFJO0FBQUEsTUFDSixFQUFFZ0csT0FBTyxTQUFTO0FBQUEsSUFDcEI7QUFHQSxVQUFNTyxXQUFXO0FBQ2pCLFVBQU1PLFlBQVk7QUFDbEIsVUFBTW1CLE9BQU9qSSxJQUFJO0FBR2pCLFVBQU1rSSxZQUFZO0FBQ2xCbEQsUUFBSWlDLGFBQWEsR0FBRzdCLE9BQU9DLE9BQU87QUFDbENMLFFBQUlrQyxhQUFhLEdBQUc7QUFDcEJsQyxRQUFJb0IsS0FBSzhCLFdBQVdELE1BQU0xQixVQUFVTyxTQUFTO0FBQzdDOUIsUUFBSVksUUFBUSxhQUFhLE1BQU07QUFDL0JaLFFBQUljLGFBQWEsR0FBR1YsT0FBT0ksUUFBUTtBQUNuQ1IsUUFBSWU7QUFBQUEsTUFDRjtBQUFBLE1BQ0FtQyxZQUFZM0IsV0FBVztBQUFBLE1BQ3ZCMEIsT0FBT25CLFlBQVk7QUFBQSxNQUNuQixFQUFFZCxPQUFPLFNBQVM7QUFBQSxJQUNwQjtBQUdBLFVBQU1tQyxRQUFRO0FBQ2RuRCxRQUFJb0IsS0FBSytCLE9BQU9GLE1BQU0xQixVQUFVTyxTQUFTO0FBQ3pDOUIsUUFBSWU7QUFBQUEsTUFDRjtBQUFBLE1BQ0FvQyxRQUFRNUIsV0FBVztBQUFBLE1BQ25CMEIsT0FBT25CLFlBQVk7QUFBQSxNQUNuQixFQUFFZCxPQUFPLFNBQVM7QUFBQSxJQUNwQjtBQUdBLFVBQU1vQyxhQUFhcEQsSUFBSXFELFNBQVNDLFNBQVNDLFVBQVU7QUFDbkQsVUFBTUMsVUFBVUosYUFBYTtBQUU3QnBELFFBQUltQixhQUFhLEdBQUdmLE9BQU9DLE9BQU87QUFDbENMLFFBQUlvQixLQUFLLEdBQUdvQyxTQUFTLEtBQUssSUFBSSxHQUFHO0FBRWpDeEQsUUFBSWMsYUFBYSxLQUFLLEtBQUssR0FBRztBQUM5QmQsUUFBSWEsWUFBWSxFQUFFO0FBQ2xCYixRQUFJWSxRQUFRLGFBQWEsTUFBTTtBQUMvQlosUUFBSWUsS0FBSyw2Q0FBNkMsS0FBS3lDLFVBQVUsR0FBRztBQUFBLE1BQ3RFeEMsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUVEaEIsUUFBSVksUUFBUSxhQUFhLFFBQVE7QUFDakNaLFFBQUlhLFlBQVksQ0FBQztBQUNqQmIsUUFBSWU7QUFBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxNQUNBeUMsVUFBVTtBQUFBLE1BQ1YsRUFBRXhDLE9BQU8sU0FBUztBQUFBLElBQ3BCO0FBQ0FoQixRQUFJZTtBQUFBQSxNQUNGO0FBQUEsTUFDQTtBQUFBLE1BQ0F5QyxVQUFVO0FBQUEsTUFDVixFQUFFeEMsT0FBTyxTQUFTO0FBQUEsSUFDcEI7QUFFQSxRQUFJbkMsY0FBYztBQUNoQm1CLFVBQUl5RCxLQUFLLEdBQUczRSxVQUFVNEUsVUFBVXJHLFNBQVMsbUJBQW1CO0FBQUEsSUFDOUQsT0FBTztBQUNMLFlBQU1zRyxVQUFVM0QsSUFBSTRELE9BQU8sTUFBTTtBQUNqQyxZQUFNQyxTQUFTQyxJQUFJQyxnQkFBZ0JKLE9BQU87QUFDMUNLLGFBQU9DLEtBQUtKLFFBQVEsUUFBUTtBQUFBLElBQzlCO0FBQUEsRUFDRjtBQUNBLFFBQU1yRixjQUFjLE9BQU8wRixnQkFBZ0I7QUFDekMsUUFBSTtBQUNGLFlBQU0xSSxNQUFNLE1BQU01RCxJQUFJNkQ7QUFBQUEsUUFDcEIsMENBQTBDeUksV0FBVztBQUFBLE1BQ3ZEO0FBQ0F0Rix5QkFBbUIsT0FBT3BELElBQUlFLE1BQU1BLElBQUk7QUFBQSxJQUMxQyxTQUFTaUQsT0FBTztBQUNkRCxjQUFRQyxNQUFNLGdCQUFnQkEsS0FBSztBQUNuQy9FLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFHQXJDLFlBQVUsTUFBTTtBQUNkLFFBQUlzQixvQkFBb0JFLGdCQUFnQjtBQUN0Q3lDLHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsRUFDRixHQUFHLENBQUMzQyxrQkFBa0JFLGdCQUFnQmMsU0FBU0UsSUFBSSxDQUFDO0FBR3BELFFBQU1pSyxVQUFVO0FBQUEsSUFDZCxFQUFFN0YsS0FBSyxRQUFROEYsUUFBUSxRQUFRO0FBQUEsSUFDL0IsRUFBRTlGLEtBQUssUUFBUThGLFFBQVEsV0FBVztBQUFBLElBQ2xDLEVBQUU5RixLQUFLLFFBQVE4RixRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUU5RixLQUFLLFNBQVM4RixRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFOUYsS0FBSyxVQUFVOEYsUUFBUSxVQUFVO0FBQUEsSUFDbkMsRUFBRTlGLEtBQUssV0FBVzhGLFFBQVEsYUFBYTtBQUFBLElBQ3ZDLEVBQUU5RixLQUFLLGNBQWM4RixRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFOUYsS0FBSyxXQUFXOEYsUUFBUSxXQUFXO0FBQUEsSUFDckMsRUFBRTlGLEtBQUssaUJBQWlCOEYsUUFBUSxpQkFBaUI7QUFBQSxJQUNqRCxFQUFFOUYsS0FBSyxVQUFVOEYsUUFBUSxjQUFjO0FBQUEsSUFDdkMsRUFBRTlGLEtBQUssVUFBVThGLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFDekI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU16SyxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQ1csVUFBVSxFQUFFLEdBQUdBLE1BQU1WLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBR0gsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtCQUE4Qix1Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BR25FLHVCQUFDLFNBQUksV0FBVSx1Q0FFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBLFlBQ1osdUJBQXVCO0FBQUEsWUFDdkI7QUFBQSxZQUNBLGNBQWMsQ0FBQ3dLLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLFlBRTVELE9BQU94SyxTQUFTRSxRQUFRd0s7QUFBQUEsWUFDeEIsVUFBVSxDQUFDQyxRQUFRdkssaUJBQWlCLFFBQVF1SyxHQUFHO0FBQUEsWUFFL0M7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDMUIvTCxNQUFNNEQ7QUFBQUEsZ0JBQUksQ0FBQ29JLE1BQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUVqSSxLQUNqQ2lJLFlBQUV2SCxhQURldUgsRUFBRWpJLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQTtBQUFBLFVBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE9BQU8zQyxTQUFTRztBQUFBQSxZQUNoQixVQUFVLENBQUN3SyxRQUFRdkssaUJBQWlCLGNBQWN1SyxHQUFHO0FBQUEsWUFFckQ7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEscUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxhQUFZLHlCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQztBQUFBLGNBQzFDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sYUFBWSwwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQSxjQUMzQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUE7QUFBQTtBQUFBLFVBUnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFHQ3ZMLG1CQUNDLG1DQUNFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPSjtBQUFBQSxjQUNQLFVBQVUsQ0FBQzZMLE1BQU01TCxvQkFBb0I0TCxFQUFFQyxPQUFPeEssS0FBSztBQUFBO0FBQUEsWUFKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXVELEtBTHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBT3BCO0FBQUFBLGNBQ1AsVUFBVSxDQUFDMkwsTUFBTTFMLGtCQUFrQjBMLEVBQUVDLE9BQU94SyxLQUFLO0FBQUE7QUFBQSxZQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJcUQsS0FMdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxXQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkRBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxPQUFFLDRCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUNmLHVCQUFDLFFBQUc7QUFBQTtBQUFBLFlBQUVoQixRQUFRRTtBQUFBQSxlQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsYUFGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSxpQ0FBQyxPQUFFLGtDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFDckIsdUJBQUMsUUFBSUYsa0JBQVFHLGNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0I7QUFBQSxhQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGlDQUFDLE9BQUUsK0JBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0I7QUFBQSxVQUNsQix1QkFBQyxRQUFJSCxrQkFBUUksY0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLGFBRjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFHQ2pCLFVBQVVxRSxTQUFTLEtBQUssQ0FBQ2hFLFVBQ3hCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsTUFBTUw7QUFBQUEsVUFDTixrQkFBaUI7QUFBQTtBQUFBLFFBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUc0QyxJQUc1Qyx1QkFBQyxrQkFBZSxXQUFXSyxXQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DO0FBQUEsU0EzRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2RkE7QUFBQSxPQXhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUdBO0FBRUo7QUFBRU4sR0Fua0JJRCxrQkFBZ0I7QUFBQXdNLEtBQWhCeE07QUFxa0JOLGVBQWVBO0FBQWlCLElBQUF3TTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiRGF0YVRhYmxlIiwiYXBpIiwiTmF2YmFyIiwiU2lkZWJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiQ2lyY3VsYXJMb2FkZXIiLCJmaWVsZFNpemUiLCJqc1BERiIsImltYWdlSW5wdXQiLCJJb01kTW9yZSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiTG9hblBheW91dFJlcG9ydCIsIl9zIiwiZGF0YVRhYmxlIiwic2V0RGF0YVRhYmxlIiwidXNlU3RhdGUiLCJ1c2VycyIsInNldFVzZXJzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWxlY3RlZEZyb21EYXRlIiwic2V0U2VsZWN0ZWRGcm9tRGF0ZSIsInNlbGVjdGVkVG9EYXRlIiwic2V0U2VsZWN0ZWRUb0RhdGUiLCJzaG93RmlsdGVyRmllbGQiLCJzZXRTaG93RmlsdGVyRmllbGQiLCJzdW1tYXJ5Iiwic2V0U3VtbWFyeSIsInRvdGFsQW1vdW50IiwidG90YWxDb3VudCIsInRvdGFsVXNlcnMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXIiLCJmaWx0ZXJUeXBlIiwiaGFuZGxlQW50RFNlbGVjdCIsImZpZWxkIiwidmFsdWUiLCJwcmV2IiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ0b2RheSIsIkRhdGUiLCJmcm9tIiwidG8iLCJ5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJmZXRjaFVzZXJzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImZldGNoTG9hblBheW1lbnRzIiwidXJsIiwicXVlcnlQYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJhcHBlbmQiLCJ0b1N0cmluZyIsInJlZHVjZSIsInN1bSIsIml0ZW0iLCJOdW1iZXIiLCJhbW91bnQiLCJ1bmlxdWVVc2VycyIsIlNldCIsIm1hcCIsImQiLCJ1c2VyX2lkIiwiX2lkIiwiZmlsdGVyIiwiQm9vbGVhbiIsImxlbmd0aCIsInNpemUiLCJmb3JtYXR0ZWQiLCJpbmRleCIsImlkIiwic2xObyIsIm5hbWUiLCJmdWxsX25hbWUiLCJwaG9uZSIsInBob25lX251bWJlciIsImxvYW5JZCIsImxvYW4iLCJsb2FuX2lkIiwibG9hbkFtb3VudCIsImxvYW5fYW1vdW50IiwicGF5VHlwZSIsInBheV90eXBlIiwidHJhbnNhY3Rpb25JZCIsInRyYW5zYWN0aW9uX2lkIiwicmVjZWlwdCIsInJlY2VpcHRfbm8iLCJwYXlfZGF0ZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVQcmludCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImdlbmVyYXRlQW5kT3BlblBERiIsImRvd25sb2FkT25seSIsInVzZXJEYXRhIiwic2VjdGlvbnMiLCJ0aXRsZSIsImljb24iLCJmaWVsZHMiLCJlbWFpbCIsImFkZHJlc3MiLCJzdGFydF9kYXRlIiwicmVwbGFjZSIsImVuZF9kYXRlIiwic2VydmljZV9jaGFyZ2VzIiwibG9hbl9zYW5jdGlvbl9kYXRlIiwiZG9jdW1lbnRfY2hhcmdlcyIsImRhaWx5X3BheW1lbnRfYW1vdW50IiwidGVudXJlIiwicmVmZXJyZWRfdHlwZSIsInJlZmVycmVkX2VtcGxveWVlIiwidHJpbSIsImRvYyIsInNhZmVUZXh0IiwidiIsIlN0cmluZyIsImNvbG9ycyIsInByaW1hcnkiLCJzZWNvbmRhcnkiLCJhY2NlbnQiLCJ0ZXh0TWFpbiIsInRleHRMaWdodCIsImJvcmRlciIsImFkZEltYWdlIiwic2V0Rm9udCIsInNldEZvbnRTaXplIiwic2V0VGV4dENvbG9yIiwidGV4dCIsImFsaWduIiwicHJvY2Vzc2VkQnkiLCJhZG1pbl90eXBlIiwic2V0RmlsbENvbG9yIiwicmVjdCIsImRyYXdGaWVsZCIsIngiLCJib3hXaWR0aCIsImxhYmVsV2lkdGgiLCJ2YWx1ZVgiLCJzYWZlIiwid3JhcHBlZFZhbHVlIiwic3BsaXRUZXh0VG9TaXplIiwibGluZUhlaWdodCIsImJveEhlaWdodCIsIk1hdGgiLCJtYXgiLCJzZXREcmF3Q29sb3IiLCJzZXRMaW5lV2lkdGgiLCJ0b1VwcGVyQ2FzZSIsInRleHRZIiwiZm9yRWFjaCIsImxpbmUiLCJzZWMiLCJyZWN0WCIsInJlY3RXaWR0aCIsInJlY3RIZWlnaHQiLCJpIiwibGVmdEZpZWxkIiwicmlnaHRGaWVsZCIsInN0YXJ0WSIsImxlZnRZIiwicmlnaHRZIiwiYm94WSIsImN1c3RvbWVyWCIsImF1dGhYIiwicGFnZUhlaWdodCIsImludGVybmFsIiwicGFnZVNpemUiLCJnZXRIZWlnaHQiLCJmb290ZXJZIiwic2F2ZSIsImJvcnJvd2VyIiwicGRmQmxvYiIsIm91dHB1dCIsInBkZlVybCIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsIndpbmRvdyIsIm9wZW4iLCJsb2FuUHJpbnRJZCIsImNvbHVtbnMiLCJoZWFkZXIiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVuZGVmaW5lZCIsInZhbCIsInUiLCJlIiwidGFyZ2V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG9hblBheW91dFJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQganNQREYgZnJvbSBcImpzcGRmXCI7XHJcbmltcG9ydCBpbWFnZUlucHV0IGZyb20gXCIuLi8uLi9zcmMvYXNzZXRzL2ltYWdlcy9BZ2VudC5wbmdcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5cclxuY29uc3QgTG9hblBheW91dFJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbZGF0YVRhYmxlLCBzZXREYXRhVGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkVG9EYXRlLCBzZXRTZWxlY3RlZFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0b3RhbEFtb3VudDogMCxcclxuICAgIHRvdGFsQ291bnQ6IDAsXHJcbiAgICB0b3RhbFVzZXJzOiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcjogXCJcIixcclxuICAgIGZpbHRlclR5cGU6IFwiVG9kYXlcIixcclxuICB9KTtcclxuXHJcbiAgLy8g4pyFIEhhbmRsZSBTZWxlY3RcclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIFtmaWVsZF06IHZhbHVlIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4gIC8vIOKchSBGaWx0ZXIgTG9naWNcclxuICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgbGV0IGZyb20gPSBcIlwiO1xyXG4gICAgbGV0IHRvID0gXCJcIjtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBmcm9tID0gdG8gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuICAgICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgeS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICBmcm9tID0gdG8gPSBmb3JtYXREYXRlKHkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuICAgICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZnJvbSk7XHJcbiAgICBzZXRTZWxlY3RlZFRvRGF0ZSh0byk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGhhbmRsZVNlbGVjdEZpbHRlcihmb3JtRGF0YS5maWx0ZXJUeXBlKTtcclxuICB9LCBbZm9ybURhdGEuZmlsdGVyVHlwZV0pO1xyXG5cclxuICAvLyDinIUgRmV0Y2ggVXNlcnNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICBzZXRVc2VycyhyZXMuZGF0YSB8fCBbXSk7XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8g4pyFIEZldGNoIExvYW4gUGF5bWVudHNcclxuICBjb25zdCBmZXRjaExvYW5QYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAvLyDinIUgQmFzZSBVUkxcclxuICAgICAgbGV0IHVybCA9IGAvcGF5bWVudC1vdXQvZ2V0LWxvYW4tcGF5b3V0YDtcclxuXHJcbiAgICAgIC8vIOKchSBBZGQgdXNlcklkIE9OTFkgaWYgZXhpc3RzXHJcbiAgICAgIGlmIChmb3JtRGF0YT8udXNlcikge1xyXG4gICAgICAgIHVybCArPSBgLyR7Zm9ybURhdGEudXNlcn1gO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyDinIUgQnVpbGQgcXVlcnkgcGFyYW1zIHNhZmVseVxyXG4gICAgICBjb25zdCBxdWVyeVBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuXHJcbiAgICAgIGlmIChzZWxlY3RlZEZyb21EYXRlKSB7XHJcbiAgICAgICAgcXVlcnlQYXJhbXMuYXBwZW5kKFwiZnJvbV9kYXRlXCIsIHNlbGVjdGVkRnJvbURhdGUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoc2VsZWN0ZWRUb0RhdGUpIHtcclxuICAgICAgICBxdWVyeVBhcmFtcy5hcHBlbmQoXCJ0b19kYXRlXCIsIHNlbGVjdGVkVG9EYXRlKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8g4pyFIEF0dGFjaCBxdWVyeSBzdHJpbmcgaWYgZXhpc3RzXHJcbiAgICAgIGlmIChxdWVyeVBhcmFtcy50b1N0cmluZygpKSB7XHJcbiAgICAgICAgdXJsICs9IGA/JHtxdWVyeVBhcmFtcy50b1N0cmluZygpfWA7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIOKchSBBUEkgY2FsbFxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSByZXM/LmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAvLyDinIUgU1VNTUFSWSBDQUxDVUxBVElPTlxyXG4gICAgICBjb25zdCB0b3RhbEFtb3VudCA9IGRhdGEucmVkdWNlKFxyXG4gICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIE51bWJlcihpdGVtPy5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgMCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHVuaXF1ZVVzZXJzID0gbmV3IFNldChcclxuICAgICAgICBkYXRhLm1hcCgoZCkgPT4gZD8udXNlcl9pZD8uX2lkKS5maWx0ZXIoQm9vbGVhbiksXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgICB0b3RhbEFtb3VudCxcclxuICAgICAgICB0b3RhbENvdW50OiBkYXRhLmxlbmd0aCxcclxuICAgICAgICB0b3RhbFVzZXJzOiB1bmlxdWVVc2Vycy5zaXplLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIOKchSBGT1JNQVQgVEFCTEUgREFUQVxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBkYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgaWQ6IGl0ZW0/Ll9pZCxcclxuICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgbmFtZTogaXRlbT8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgIHBob25lOiBpdGVtPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgbG9hbklkOiBpdGVtPy5sb2FuPy5sb2FuX2lkIHx8IFwiLVwiLFxyXG4gICAgICAgIGxvYW5BbW91bnQ6IGl0ZW0/LmxvYW4/LmxvYW5fYW1vdW50IHx8IFwiLVwiLFxyXG4gICAgICAgIGFtb3VudDogTnVtYmVyKGl0ZW0/LmFtb3VudCB8fCAwKSxcclxuICAgICAgICBwYXlUeXBlOiBpdGVtPy5wYXlfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICB0cmFuc2FjdGlvbklkOiBpdGVtPy50cmFuc2FjdGlvbl9pZCB8fCBcIi1cIixcclxuICAgICAgICByZWNlaXB0OiBpdGVtPy5yZWNlaXB0X25vIHx8IFwiLVwiLFxyXG4gICAgICAgIGRhdGU6IGl0ZW0/LnBheV9kYXRlIHx8IFwiLVwiLFxyXG4gICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCIga2V5PXtpdGVtLl9pZH0+XHJcbiAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQcmludChpdGVtLmxvYW4/Ll9pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICBzZXREYXRhVGFibGUoZm9ybWF0dGVkKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwi4p2MIExvYW4gUGF5bWVudCBGZXRjaCBFcnJvcjpcIiwgZXJyKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdlbmVyYXRlQW5kT3BlblBERiA9IChkb3dubG9hZE9ubHkgPSBmYWxzZSwgdXNlckRhdGEpID0+IHtcclxuICAgIGNvbnN0IHNlY3Rpb25zID0gW1xyXG4gICAgICB7XHJcbiAgICAgICAgdGl0bGU6IFwiQ1VTVE9NRVIgREVUQUlMU1wiLFxyXG4gICAgICAgIGljb246IFwi8J+RpFwiLFxyXG4gICAgICAgIGZpZWxkczogW1xyXG4gICAgICAgICAgeyBsYWJlbDogXCJGdWxsIE5hbWVcIiwgdmFsdWU6IHVzZXJEYXRhPy51c2VyX2lkPy5mdWxsX25hbWUgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiUGhvbmUgTnVtYmVyXCIsIHZhbHVlOiB1c2VyRGF0YT8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIH0sXHJcbiAgICAgICAgICB7IGxhYmVsOiBcIkVtYWlsIEFkZHJlc3NcIiwgdmFsdWU6IHVzZXJEYXRhPy51c2VyX2lkPy5lbWFpbCB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJBZGRyZXNzXCIsIHZhbHVlOiB1c2VyRGF0YT8udXNlcl9pZD8uYWRkcmVzcyB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICB0aXRsZTogXCJMT0FOIFNVTU1BUllcIixcclxuICAgICAgICBpY29uOiBcIvCfkrBcIixcclxuICAgICAgICBmaWVsZHM6IFtcclxuICAgICAgICAgIHsgbGFiZWw6IFwiTG9hbiBJRFwiLCB2YWx1ZTogdXNlckRhdGE/LmxvYW4/LmxvYW5faWQgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwiU3RhcnQgRGF0ZVwiLFxyXG4gICAgICAgICAgICB2YWx1ZTogbmV3IERhdGUodXNlckRhdGE/LmxvYW4/LnN0YXJ0X2RhdGUpXHJcbiAgICAgICAgICAgICAgLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIpXHJcbiAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcLy9nLCBcIi1cIiksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJMb2FuIEFtb3VudFwiLCB2YWx1ZTogdXNlckRhdGE/LmxvYW4/LmxvYW5fYW1vdW50IH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIkVuZCBEYXRlXCIsXHJcbiAgICAgICAgICAgIHZhbHVlOiBuZXcgRGF0ZSh1c2VyRGF0YT8ubG9hbj8uZW5kX2RhdGUpXHJcbiAgICAgICAgICAgICAgLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIpXHJcbiAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcLy9nLCBcIi1cIiksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJTZXJ2aWNlIENoYXJnZXNcIiwgdmFsdWU6IHVzZXJEYXRhPy5sb2FuPy5zZXJ2aWNlX2NoYXJnZXMgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwiU2FuY3Rpb24gRGF0ZVwiLFxyXG4gICAgICAgICAgICB2YWx1ZTogbmV3IERhdGUodXNlckRhdGE/LmxvYW4/LmxvYW5fc2FuY3Rpb25fZGF0ZSlcclxuICAgICAgICAgICAgICAudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgICAucmVwbGFjZSgvXFwvL2csIFwiLVwiKSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIkRvY3VtZW50IENoYXJnZXNcIixcclxuICAgICAgICAgICAgdmFsdWU6IHVzZXJEYXRhPy5sb2FuPy5kb2N1bWVudF9jaGFyZ2VzLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbGFiZWw6IFwiRGFpbHkgUGF5bWVudFwiLFxyXG4gICAgICAgICAgICB2YWx1ZTogdXNlckRhdGE/LmxvYW4/LmRhaWx5X3BheW1lbnRfYW1vdW50LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHsgbGFiZWw6IFwiRGlzYnVyc2VkIEFtb3VudFwiLCB2YWx1ZTogdXNlckRhdGE/LmFtb3VudCB9LFxyXG4gICAgICAgICAgeyBsYWJlbDogXCJUZW51cmUgKERheXMpXCIsIHZhbHVlOiB1c2VyRGF0YT8ubG9hbj8udGVudXJlIH0sXHJcbiAgICAgICAgICB7IGxhYmVsOiBcIlJlY2VpcHQgTm9cIiwgdmFsdWU6IHVzZXJEYXRhPy5yZWNlaXB0X25vIH0sXHJcbiAgICAgICAgICB7IGxhYmVsOiBcIlRyYW5zYWN0aW9uIElEXCIsIHZhbHVlOiB1c2VyRGF0YT8udHJhbnNhY3Rpb25faWQgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdGl0bGU6IFwiUkVGRVJSQUwgSU5GT1JNQVRJT05cIixcclxuICAgICAgICBpY29uOiBcIvCfpJ1cIixcclxuICAgICAgICBmaWVsZHM6IFtcclxuICAgICAgICAgIHsgbGFiZWw6IFwiUmVmZXJyZWQgQnlcIiwgdmFsdWU6IHVzZXJEYXRhPy5sb2FuPy5yZWZlcnJlZF90eXBlIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGxhYmVsOiBcIkVtcGxveWVlIE5hbWVcIixcclxuICAgICAgICAgICAgdmFsdWU6XHJcbiAgICAgICAgICAgICAgYCR7dXNlckRhdGE/LmxvYW4/LnJlZmVycmVkX2VtcGxveWVlPy5uYW1lIHx8IFwiXCJ9ICR7XCIgfCBcIn0ke3VzZXJEYXRhPy5sb2FuPy5yZWZlcnJlZF9lbXBsb3llZT8ucGhvbmVfbnVtYmVyIHx8IFwiXCJ9YC50cmltKCkgfHxcclxuICAgICAgICAgICAgICBcIk4vQVwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCBkb2MgPSBuZXcganNQREYoXCJwXCIsIFwibW1cIiwgXCJhNFwiKTtcclxuICAgIGNvbnN0IHNhZmVUZXh0ID0gKHYpID0+ICh2ID8gU3RyaW5nKHYpIDogXCJOL0FcIik7XHJcblxyXG4gICAgLy8g4pyoIE5FVyBDT0xPUiBUSEVNRSAoRW1lcmFsZCBHcmVlbiAvIFNvZnQgTWludCkg4pyoXHJcbiAgICBjb25zdCBjb2xvcnMgPSB7XHJcbiAgICAgIHByaW1hcnk6IFswLCAzOCwgMTI0XSwgLy8gYmx1ZS05MDBcclxuICAgICAgc2Vjb25kYXJ5OiBbMjQwLCAyNDIsIDI0NV0sIC8vIGdyYXktMTAwXHJcbiAgICAgIGFjY2VudDogWzAsIDM4LCAxMjRdLCAvLyBibHVlLTUwMFxyXG4gICAgICB0ZXh0TWFpbjogWzAsIDAsIDBdLCAvLyBncmF5LTgwMFxyXG4gICAgICB0ZXh0TGlnaHQ6IFswLCAwLCAwXSwgLy8gZ3JheS01MDBcclxuICAgICAgYm9yZGVyOiBbMjAwLCAyMDUsIDIxNV0sIC8vIGdyYXktMjAwXHJcbiAgICB9O1xyXG5cclxuICAgIGxldCB5ID0gNjU7XHJcblxyXG4gICAgLy8gSGVhZGVyIExvZ28gJiBUaXRsZVxyXG4gICAgaWYgKGltYWdlSW5wdXQpIHtcclxuICAgICAgZG9jLmFkZEltYWdlKGltYWdlSW5wdXQsIFwiUE5HXCIsIDkwLCA4LCAzMCwgMzApO1xyXG4gICAgfVxyXG4gICAgLy8gTG9hbiBJRCAodG9wIHJpZ2h0LCBsYXJnZXIgZm9udClcclxuICAgIGNvbnN0IGxvYW5JZCA9IHVzZXJEYXRhPy5sb2FuPy5sb2FuX2lkIHx8IFwiTi9BXCI7XHJcbiAgICBkb2Muc2V0Rm9udChcImhlbHZldGljYVwiLCBcImJvbGRcIik7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTYpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvciguLi5jb2xvcnMucHJpbWFyeSk7XHJcbiAgICBkb2MudGV4dChgTG9hbiBJRDogJHtsb2FuSWR9YCwgMTk1LCAyMCwgeyBhbGlnbjogXCJyaWdodFwiIH0pO1xyXG5cclxuICAgIGNvbnN0IHByb2Nlc3NlZEJ5ID0gdXNlckRhdGE/LmFkbWluX3R5cGU/Lm5hbWUgfHwgXCJOL0FcIjtcclxuICAgIGRvYy5zZXRGb250U2l6ZSgxMCk7XHJcbiAgICBkb2Muc2V0Rm9udChcImhlbHZldGljYVwiLCBcIm5vcm1hbFwiKTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoLi4uY29sb3JzLnRleHRNYWluKTtcclxuICAgIGRvYy50ZXh0KGBQcm9jZXNzZWQgQnk6ICR7cHJvY2Vzc2VkQnl9YCwgMTk1LCAyOCwgeyBhbGlnbjogXCJyaWdodFwiIH0pO1xyXG5cclxuXHJcbiAgICAvLyBIZWFkZXIgQmFubmVyXHJcbiAgICBkb2Muc2V0RmlsbENvbG9yKC4uLmNvbG9ycy5wcmltYXJ5KTtcclxuICAgIGRvYy5yZWN0KDAsIDQwLCAyMTAsIDE1LCBcIkZcIik7XHJcbiAgICBkb2Muc2V0VGV4dENvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgZG9jLnNldEZvbnQoXCJoZWx2ZXRpY2FcIiwgXCJib2xkXCIpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE2KTtcclxuICAgIGRvYy50ZXh0KFwiTE9BTiBTQU5DVElPTiBDRVJUSUZJQ0FURVwiLCAxMDUsIDQ5LCB7IGFsaWduOiBcImNlbnRlclwiIH0pO1xyXG5cclxuICAgIGNvbnN0IGRyYXdGaWVsZCA9IChsYWJlbCwgdmFsdWUsIHgsIHkpID0+IHtcclxuICAgICAgY29uc3QgYm94V2lkdGggPSA4NTtcclxuICAgICAgY29uc3QgbGFiZWxXaWR0aCA9IDM4O1xyXG4gICAgICBjb25zdCB2YWx1ZVggPSB4ICsgbGFiZWxXaWR0aDtcclxuXHJcbiAgICAgIGNvbnN0IHNhZmUgPSBzYWZlVGV4dCh2YWx1ZSk7XHJcblxyXG4gICAgICAvLyBXcmFwIGxvbmcgdGV4dFxyXG4gICAgICBjb25zdCB3cmFwcGVkVmFsdWUgPSBkb2Muc3BsaXRUZXh0VG9TaXplKHNhZmUsIGJveFdpZHRoIC0gbGFiZWxXaWR0aCAtIDUpO1xyXG5cclxuICAgICAgY29uc3QgbGluZUhlaWdodCA9IDQ7XHJcbiAgICAgIGNvbnN0IGJveEhlaWdodCA9IE1hdGgubWF4KDksIHdyYXBwZWRWYWx1ZS5sZW5ndGggKiBsaW5lSGVpZ2h0ICsgNCk7XHJcblxyXG4gICAgICAvLyBCb3hcclxuICAgICAgZG9jLnNldERyYXdDb2xvciguLi5jb2xvcnMuYm9yZGVyKTtcclxuICAgICAgZG9jLnNldExpbmVXaWR0aCgwLjEpO1xyXG4gICAgICBkb2MucmVjdCh4LCB5LCBib3hXaWR0aCwgYm94SGVpZ2h0KTtcclxuXHJcbiAgICAgIC8vIExhYmVsXHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoLi4uY29sb3JzLnByaW1hcnkpO1xyXG4gICAgICBkb2Muc2V0Rm9udChcImhlbHZldGljYVwiLCBcImJvbGRcIik7XHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSg4KTtcclxuICAgICAgZG9jLnRleHQobGFiZWwudG9VcHBlckNhc2UoKSArIFwiOlwiLCB4ICsgMywgeSArIDUpO1xyXG5cclxuICAgICAgLy8gVmFsdWUgKHdyYXBwZWQpXHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoLi4uY29sb3JzLnRleHRNYWluKTtcclxuICAgICAgZG9jLnNldEZvbnQoXCJoZWx2ZXRpY2FcIiwgXCJub3JtYWxcIik7XHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuXHJcbiAgICAgIGxldCB0ZXh0WSA9IHkgKyA1O1xyXG4gICAgICB3cmFwcGVkVmFsdWUuZm9yRWFjaCgobGluZSkgPT4ge1xyXG4gICAgICAgIGRvYy50ZXh0KGxpbmUsIHZhbHVlWCwgdGV4dFkpO1xyXG4gICAgICAgIHRleHRZICs9IGxpbmVIZWlnaHQ7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgcmV0dXJuIHkgKyBib3hIZWlnaHQgKyAyO1xyXG4gICAgfTtcclxuXHJcbiAgICBzZWN0aW9ucy5mb3JFYWNoKChzZWMpID0+IHtcclxuICAgICAgLy8gU2VjdGlvbiBIZWFkZXJcclxuICAgICAgY29uc3QgcmVjdFggPSAxNTtcclxuICAgICAgY29uc3QgcmVjdFdpZHRoID0gMTgwO1xyXG4gICAgICBjb25zdCByZWN0SGVpZ2h0ID0gMTA7XHJcblxyXG4gICAgICBkb2Muc2V0RmlsbENvbG9yKC4uLmNvbG9ycy5zZWNvbmRhcnkpO1xyXG4gICAgICBkb2MucmVjdChyZWN0WCwgeSwgcmVjdFdpZHRoLCByZWN0SGVpZ2h0LCBcIkZcIik7XHJcblxyXG4gICAgICAvLyBMZWZ0IGFjY2VudCBib3JkZXJcclxuICAgICAgZG9jLnNldEZpbGxDb2xvciguLi5jb2xvcnMucHJpbWFyeSk7XHJcbiAgICAgIGRvYy5yZWN0KHJlY3RYLCB5LCAxLjUsIHJlY3RIZWlnaHQsIFwiRlwiKTtcclxuXHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoLi4uY29sb3JzLnByaW1hcnkpO1xyXG4gICAgICBkb2Muc2V0Rm9udChcImhlbHZldGljYVwiLCBcImJvbGRcIik7XHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSgxMSk7XHJcbiAgICAgIGRvYy50ZXh0KHNlYy50aXRsZSwgcmVjdFggKyA1LCB5ICsgNi41KTtcclxuXHJcbiAgICAgIHkgKz0gMTQ7XHJcblxyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlYy5maWVsZHMubGVuZ3RoOyBpICs9IDIpIHtcclxuICAgICAgICBjb25zdCBsZWZ0RmllbGQgPSBzZWMuZmllbGRzW2ldO1xyXG4gICAgICAgIGNvbnN0IHJpZ2h0RmllbGQgPSBzZWMuZmllbGRzW2kgKyAxXTtcclxuXHJcbiAgICAgICAgY29uc3Qgc3RhcnRZID0geTtcclxuXHJcbiAgICAgICAgY29uc3QgbGVmdFkgPSBkcmF3RmllbGQobGVmdEZpZWxkLmxhYmVsLCBsZWZ0RmllbGQudmFsdWUsIDE1LCBzdGFydFkpO1xyXG5cclxuICAgICAgICBsZXQgcmlnaHRZID0gc3RhcnRZO1xyXG4gICAgICAgIGlmIChyaWdodEZpZWxkKSB7XHJcbiAgICAgICAgICByaWdodFkgPSBkcmF3RmllbGQocmlnaHRGaWVsZC5sYWJlbCwgcmlnaHRGaWVsZC52YWx1ZSwgMTEwLCBzdGFydFkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgeSA9IE1hdGgubWF4KGxlZnRZLCByaWdodFkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICB5ICs9IDY7IC8vIFNlY3Rpb24gc3BhY2luZ1xyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gRGVjbGFyYXRpb25cclxuICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoLi4uY29sb3JzLnRleHRMaWdodCk7XHJcbiAgICBkb2Muc2V0Rm9udChcImhlbHZldGljYVwiLCBcIml0YWxpY1wiKTtcclxuICAgIGRvYy50ZXh0KFxyXG4gICAgICBcIkkgaGVyZWJ5IGRlY2xhcmUgdGhhdCB0aGUgYWJvdmUgbG9hbiBpbmZvcm1hdGlvbiBpcyB0cnVlIGFuZCBjb3JyZWN0LlwiLFxyXG4gICAgICAxMDUsXHJcbiAgICAgIHkgKyAxMCxcclxuICAgICAgeyBhbGlnbjogXCJjZW50ZXJcIiB9LFxyXG4gICAgKTtcclxuXHJcbiAgICAvLyDinKggVFdPIFNJR05BVFVSRSBCT1hFUzogQ3VzdG9tZXIgKyBBdXRob3JpemVkIFNpZ25hdG9yeSDinKhcclxuICAgIGNvbnN0IGJveFdpZHRoID0gNTA7XHJcbiAgICBjb25zdCBib3hIZWlnaHQgPSAxODtcclxuICAgIGNvbnN0IGJveFkgPSB5ICsgMTg7XHJcblxyXG4gICAgLy8gQ3VzdG9tZXIgU2lnbmF0dXJlIChsZWZ0KVxyXG4gICAgY29uc3QgY3VzdG9tZXJYID0gNDA7XHJcbiAgICBkb2Muc2V0RHJhd0NvbG9yKC4uLmNvbG9ycy5wcmltYXJ5KTtcclxuICAgIGRvYy5zZXRMaW5lV2lkdGgoMC41KTtcclxuICAgIGRvYy5yZWN0KGN1c3RvbWVyWCwgYm94WSwgYm94V2lkdGgsIGJveEhlaWdodCk7XHJcbiAgICBkb2Muc2V0Rm9udChcImhlbHZldGljYVwiLCBcImJvbGRcIik7XHJcbiAgICBkb2Muc2V0VGV4dENvbG9yKC4uLmNvbG9ycy50ZXh0TWFpbik7XHJcbiAgICBkb2MudGV4dChcclxuICAgICAgXCJDdXN0b21lciBTaWduYXR1cmVcIixcclxuICAgICAgY3VzdG9tZXJYICsgYm94V2lkdGggLyAyLFxyXG4gICAgICBib3hZICsgYm94SGVpZ2h0ICsgNSxcclxuICAgICAgeyBhbGlnbjogXCJjZW50ZXJcIiB9LFxyXG4gICAgKTtcclxuXHJcbiAgICAvLyBBdXRob3JpemVkIFNpZ25hdG9yeSAocmlnaHQpXHJcbiAgICBjb25zdCBhdXRoWCA9IDEyMDtcclxuICAgIGRvYy5yZWN0KGF1dGhYLCBib3hZLCBib3hXaWR0aCwgYm94SGVpZ2h0KTtcclxuICAgIGRvYy50ZXh0KFxyXG4gICAgICBcIkF1dGhvcml6ZWQgU2lnbmF0b3J5XCIsXHJcbiAgICAgIGF1dGhYICsgYm94V2lkdGggLyAyLFxyXG4gICAgICBib3hZICsgYm94SGVpZ2h0ICsgNSxcclxuICAgICAgeyBhbGlnbjogXCJjZW50ZXJcIiB9LFxyXG4gICAgKTtcclxuXHJcbiAgICAvLyBGb290ZXJcclxuICAgIGNvbnN0IHBhZ2VIZWlnaHQgPSBkb2MuaW50ZXJuYWwucGFnZVNpemUuZ2V0SGVpZ2h0KCk7XHJcbiAgICBjb25zdCBmb290ZXJZID0gcGFnZUhlaWdodCAtIDIwO1xyXG5cclxuICAgIGRvYy5zZXRGaWxsQ29sb3IoLi4uY29sb3JzLnByaW1hcnkpO1xyXG4gICAgZG9jLnJlY3QoMCwgZm9vdGVyWSwgMjEwLCAyMCwgXCJGXCIpO1xyXG5cclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoMjU1LCAyNTUsIDI1NSk7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTIpO1xyXG4gICAgZG9jLnNldEZvbnQoXCJoZWx2ZXRpY2FcIiwgXCJib2xkXCIpO1xyXG4gICAgZG9jLnRleHQoXCJWSUpBWUEgVklOQVlBSyBDSElUIEZVTkRTIFBSSVZBVEUgTElNSVRFRFwiLCAxMDUsIGZvb3RlclkgKyA3LCB7XHJcbiAgICAgIGFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgZG9jLnNldEZvbnQoXCJoZWx2ZXRpY2FcIiwgXCJub3JtYWxcIik7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoNyk7XHJcbiAgICBkb2MudGV4dChcclxuICAgICAgXCIjMTEvMzYtMjUsIDNyZCBGbG9vciwgMm5kIE1haW4sIEthdGhyaWd1cHBlIE1haW4gUm9hZCwgQmFuYXNoYW5rYXJpIDNyZCBTdGFnZSwgQmVuZ2FsdXJ1LTU2MDA4NVwiLFxyXG4gICAgICAxMDUsXHJcbiAgICAgIGZvb3RlclkgKyAxMSxcclxuICAgICAgeyBhbGlnbjogXCJjZW50ZXJcIiB9LFxyXG4gICAgKTtcclxuICAgIGRvYy50ZXh0KFxyXG4gICAgICBcIk1vYjogOTQ4MzkwMDc3NyB8IFBoOiAwODAtNDk3OSA4NzYzIHwgRW1haWw6IGluZm8ubXljaGl0c0BnbWFpbC5jb20gfCB3d3cubXljaGl0cy5jby5pblwiLFxyXG4gICAgICAxMDUsXHJcbiAgICAgIGZvb3RlclkgKyAxNSxcclxuICAgICAgeyBhbGlnbjogXCJjZW50ZXJcIiB9LFxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoZG93bmxvYWRPbmx5KSB7XHJcbiAgICAgIGRvYy5zYXZlKGAke3VzZXJEYXRhPy5ib3Jyb3dlcj8uZnVsbF9uYW1lfV9Mb2FuX1JlcXVlc3QucGRmYCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBwZGZCbG9iID0gZG9jLm91dHB1dChcImJsb2JcIik7XHJcbiAgICAgIGNvbnN0IHBkZlVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwocGRmQmxvYik7XHJcbiAgICAgIHdpbmRvdy5vcGVuKHBkZlVybCwgXCJfYmxhbmtcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVQcmludCA9IGFzeW5jIChsb2FuUHJpbnRJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3BheW1lbnQtb3V0L2dldC1sb2FuLXBheW91dC1ieS11c2VyaWQvJHtsb2FuUHJpbnRJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBnZW5lcmF0ZUFuZE9wZW5QREYoZmFsc2UsIHJlcy5kYXRhPy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJQUklOVCBFUlJPUjpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBnZW5lcmF0ZSBQREZcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIOKchSBUcmlnZ2VyIEZldGNoXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEZyb21EYXRlICYmIHNlbGVjdGVkVG9EYXRlKSB7XHJcbiAgICAgIGZldGNoTG9hblBheW1lbnRzKCk7XHJcbiAgICB9XHJcbiAgfSwgW3NlbGVjdGVkRnJvbURhdGUsIHNlbGVjdGVkVG9EYXRlLCBmb3JtRGF0YS51c2VyXSk7XHJcblxyXG4gIC8vIOKchSBUYWJsZSBDb2x1bW5zXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBheSBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5JZFwiLCBoZWFkZXI6IFwiTG9hbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0XCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5BbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheVR5cGVcIiwgaGVhZGVyOiBcIlBheSBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uSWRcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIElEXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMTBcIj5cclxuICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNlwiPkxvYW4gUGF5bWVudCBPdXQgUmVwb3J0PC9oMj5cclxuXHJcbiAgICAgICAgey8qIEZpbHRlcnMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgey8qIFVzZXIgU2VsZWN0ICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWQ6dy0xLzNcIj5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XVwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgVXNlcnNcIlxyXG4gICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudXNlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUFudERTZWxlY3QoXCJ1c2VyXCIsIHZhbCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3UuX2lkfSB2YWx1ZT17dS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICB7dS5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEZpbHRlciBUeXBlICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWQ6dy0xLzRcIj5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmZpbHRlclR5cGV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUFudERTZWxlY3QoXCJmaWx0ZXJUeXBlXCIsIHZhbCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlRvZGF5XCI+VG9kYXk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJZZXN0ZXJkYXlcIj5ZZXN0ZXJkYXk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJUaGlzTW9udGhcIj5UaGlzIE1vbnRoPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQ3VzdG9tXCI+Q3VzdG9tPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBEYXRlIEZpbHRlcnMgKi99XHJcbiAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvNVwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzQycHhdIHB4LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvNVwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzQycHhdIHB4LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFN1bW1hcnkgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgcC00IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgPHA+VG90YWwgQW1vdW50PC9wPlxyXG4gICAgICAgICAgICA8aDI+4oK5e3N1bW1hcnkudG90YWxBbW91bnR9PC9oMj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgIDxwPlRvdGFsIFRyYW5zYWN0aW9uczwvcD5cclxuICAgICAgICAgICAgPGgyPntzdW1tYXJ5LnRvdGFsQ291bnR9PC9oMj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmcteWVsbG93LTEwMCBwLTQgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICA8cD5Ub3RhbCBDdXN0b21lcnM8L3A+XHJcbiAgICAgICAgICAgIDxoMj57c3VtbWFyeS50b3RhbFVzZXJzfTwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFRhYmxlICovfVxyXG4gICAgICAgIHtkYXRhVGFibGUubGVuZ3RoID4gMCAmJiAhbG9hZGluZyA/IChcclxuICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgZGF0YT17ZGF0YVRhYmxlfVxyXG4gICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiTG9hbiBQYXltZW50IE91dCBSZXBvcnRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17bG9hZGluZ30gLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2FuUGF5b3V0UmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvTG9hblBheW91dFJlcG9ydC5qc3gifQ==