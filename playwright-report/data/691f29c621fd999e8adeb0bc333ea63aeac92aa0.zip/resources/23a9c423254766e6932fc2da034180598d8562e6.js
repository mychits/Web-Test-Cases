import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TargetPayOutCommissionIncentive.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tooltip, notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
const TargetPayOutCommissionIncentive = () => {
  _s();
  const paymentFor = "commission";
  const [api, contextHolder] = notification.useNotification();
  const [showCommissionModal, setShowCommissionModal] = useState(false);
  const [modifyPayment, setModifyPayment] = useState(false);
  const [adminId, setAdminId] = useState("");
  const [filterMode, setFilterMode] = useState("month");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [agentType, setAgentType] = useState("");
  const [calculatedAmount, setCalculatedAmount] = useState("0.00");
  const [alreadyPaid, setAlreadyPaid] = useState("0.00");
  const [remainingPayable, setRemainingPayable] = useState("0.00");
  const [selectedUserList, setSelectedUserList] = useState([]);
  const [commissionPayments, setCommissionPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingCommissionCalculation, setIsLoadingCommissionCalculation] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [errors, setErrors] = useState({});
  const [reRender, setReRender] = useState(0);
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    difference: 0,
    upToTarget: 0,
    beyondTarget: 0,
    targetCommission: 0,
    isTargetSet: false,
    targetDisplay: "Not Set",
    calculationType: "commission"
  });
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  const initFirstDay = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-01`;
  const initLastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split("T")[0];
  const [customDateRange, setCustomDateRange] = useState({
    from_date: initFirstDay,
    to_date: initLastDay
  });
  const [commissionForm, setCommissionForm] = useState({
    agent_id: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    selectedMonth: currentMonth,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: paymentFor,
    admin_type: ""
  });
  const [commissionBreakdown, setCommissionBreakdown] = useState([]);
  const [isTargetLoading, setIsTargetLoading] = useState(false);
  const fetchAgents = async () => {
    try {
      const res = await API.get("/agent/get-agent");
      const all = res.data || [];
      setAgents(
        all.filter((a) => a.agent_type === "agent" || a.agent_type === "both")
      );
      setEmployees(
        all.filter(
          (a) => a.agent_type === "employee" || a.agent_type === "both"
        )
      );
    } catch (err) {
      console.error("Agent fetch error", err);
    }
  };
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
    setCurrentPage(1);
    setCurrentPageRelated(1);
  };
  const formatDate = (date) => {
    if (!date) return "";
    if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return date;
    }
    const d = new Date(date);
    if (isNaN(d)) return "";
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const fetchTargetDetails = async (agentId, period, type, mode = "month") => {
    if (!agentId || mode === "custom" && (!period.from || !period.to)) {
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        upToTarget: 0,
        beyondTarget: 0,
        targetCommission: 0,
        isTargetSet: false,
        targetDisplay: "Not Set",
        calculationType: type === "employee" ? "incentive" : "commission"
      });
      setCommissionBreakdown([]);
      return;
    }
    setIsTargetLoading(true);
    try {
      let firstDay, lastDay;
      if (mode === "month") {
        const [year, monthStr] = period.split("-");
        firstDay = `${year}-${monthStr}-01`;
        lastDay = new Date(year, parseInt(monthStr), 0).toISOString().split("T")[0];
      } else {
        firstDay = formatDate(period.from);
        lastDay = formatDate(period.to);
      }
      let targetRes;
      if (type === "employee") {
        targetRes = await API.get(`/target/employees/${agentId}`, {
          params: { start_date: firstDay, end_date: lastDay }
        });
      } else {
        targetRes = await API.get(`/target/agents/${agentId}`, {
          params: { start_date: firstDay, end_date: lastDay }
        });
      }
      const targetForPeriod = targetRes?.data?.status && targetRes?.data?.total_target ? Number(targetRes.data.total_target) : 0;
      let comm;
      if (type === "employee") {
        comm = await API.get(`/enroll/employee/${agentId}/incentive`, {
          params: { start_date: firstDay, end_date: lastDay }
        });
      } else {
        comm = await API.get(`/enroll/agent/${agentId}/commission`, {
          params: { start_date: firstDay, end_date: lastDay }
        });
      }
      let achieved = type === "employee" ? comm?.data?.incentiveSummary?.total_group_value || 0 : comm?.data?.commissionSummary?.total_group_value || 0;
      if (typeof achieved === "string") {
        achieved = Number(achieved.replace(/[^0-9.-]+/g, ""));
      }
      let upToTarget = 0;
      let beyondTarget = 0;
      let totalCommission = 0;
      const remaining = Math.max(targetForPeriod - achieved, 0);
      const difference = achieved - targetForPeriod;
      if (type === "agent") {
        if (achieved <= targetForPeriod) {
          upToTarget = achieved * 5e-3;
        } else {
          upToTarget = targetForPeriod * 5e-3;
          beyondTarget = (achieved - targetForPeriod) * 0.01;
        }
        totalCommission = upToTarget + beyondTarget;
      } else {
        if (achieved > targetForPeriod) {
          beyondTarget = (achieved - targetForPeriod) * 0.01;
        }
        totalCommission = beyondTarget;
      }
      setTargetData({
        target: targetForPeriod,
        achieved,
        remaining,
        difference,
        upToTarget,
        beyondTarget,
        targetCommission: totalCommission,
        isTargetSet: targetForPeriod > 0,
        targetDisplay: targetForPeriod > 0 ? `₹${targetForPeriod.toLocaleString("en-IN")}` : "Not Set",
        calculationType: type === "employee" ? "incentive" : "commission"
      });
      setCalculatedAmount(totalCommission.toFixed(2));
      setCommissionForm((prev) => ({
        ...prev,
        amount: totalCommission.toFixed(2)
      }));
      const breakdownData = type === "employee" ? comm?.data?.incentiveData || [] : comm?.data?.commissionData || [];
      setCommissionBreakdown(breakdownData);
    } catch (error) {
      console.error("Failed to fetch target details", error);
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        upToTarget: 0,
        beyondTarget: 0,
        targetCommission: 0,
        isTargetSet: false,
        targetDisplay: "Not Set",
        calculationType: type === "employee" ? "incentive" : "commission"
      });
      setCommissionBreakdown([]);
    } finally {
      setIsTargetLoading(false);
    }
  };
  const fetchCommissionPayments = async () => {
    setIsLoading(true);
    try {
      const response = await API.get("/payment-out/get-commission-payments");
      const responseData = response.data.map((payment, index) => ({
        id: index + 1,
        _id: payment._id,
        agent_id: payment.agent_id,
        agent_name: payment.agent_id?.name,
        pay_date: payment.pay_date,
        amount: payment.amount,
        pay_type: payment.pay_type,
        commission_from: payment.commissionCalculationFromDate?.split("T")[0] || "-",
        commission_to: payment.commissionCalculationToDate?.split("T")[0] || "-",
        transaction_id: payment.transaction_id,
        note: payment.note,
        pay_for: payment.pay_for,
        disbursed_by: payment.admin_type?.name,
        receipt_no: payment.receipt_no
      }));
      setCommissionPayments(responseData);
    } catch (error) {
      console.error("Failed to fetch Commission payments", error);
      setCommissionPayments([]);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    setAdminId(userObj?._id);
    setAdminName(userObj?.full_name || userObj?.name || "");
    if (userObj?.admin_access_right_id?.access_permissions?.edit_payment) {
      setModifyPayment(
        userObj?.admin_access_right_id?.access_permissions?.edit_payment === "true"
      );
    }
    fetchAgents();
    fetchCommissionPayments();
  }, [reRender]);
  const getMonthRange = (selectedMonth) => {
    if (!selectedMonth) return { firstDay: "", lastDay: "" };
    const [year, month] = selectedMonth.split("-");
    const firstDay = `${year}-${month}-01`;
    const lastDay = new Date(year, month, 0).toISOString().split("T")[0];
    return { firstDay, lastDay };
  };
  const calculateTotalPayableCommission = async (agentId, period, type, mode = "month") => {
    if (!agentId || !period && mode === "month" || mode === "custom" && (!period.from || !period.to)) {
      setCommissionForm((prev) => ({ ...prev, amount: "" }));
      setCalculatedAmount("0.00");
      return;
    }
    setIsLoadingCommissionCalculation(true);
    try {
      await fetchTargetDetails(agentId, period, type, mode);
    } catch (error) {
      console.error("Failed to calculate commission:", error);
      setCommissionForm((prev) => ({ ...prev, amount: "" }));
      setCalculatedAmount("0.00");
    } finally {
      setIsLoadingCommissionCalculation(false);
    }
  };
  const handleCommissionChange = (e) => {
    const { name, value } = e.target;
    if (name === "from_date" || name === "to_date") {
      setCustomDateRange((prev) => ({
        ...prev,
        [name]: value
      }));
      setErrors((prev) => ({ ...prev, [name]: "" }));
      setCalculatedAmount("0.00");
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        upToTarget: 0,
        beyondTarget: 0,
        targetCommission: 0,
        isTargetSet: false,
        targetDisplay: "Not Set",
        calculationType: agentType === "employee" ? "incentive" : "commission"
      });
      setCommissionBreakdown([]);
      return;
    }
    setCommissionForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
    if (["agent_id", "selectedMonth"].includes(name)) {
      setCalculatedAmount("0.00");
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        upToTarget: 0,
        beyondTarget: 0,
        targetCommission: 0,
        isTargetSet: false,
        targetDisplay: "Not Set",
        calculationType: agentType === "employee" ? "incentive" : "commission"
      });
      setCommissionBreakdown([]);
    }
  };
  const validateForm = () => {
    const newErrors = {};
    if (!commissionForm.agent_id) {
      newErrors.agent_id = "Please select an agent";
    }
    if (!commissionForm.amount || isNaN(commissionForm.amount) || parseFloat(commissionForm.amount) <= 0) {
      newErrors.amount = "Please enter a valid amount";
    }
    if (filterMode === "month" && !commissionForm.selectedMonth) {
      newErrors.selectedMonth = "Please select a month";
    }
    if (filterMode === "custom") {
      if (!customDateRange.from_date) newErrors.from_date = "From date is required";
      if (!customDateRange.to_date) newErrors.to_date = "To date is required";
    }
    if (commissionForm.pay_type === "online" && !commissionForm.transaction_id) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleCommissionSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      try {
        setIsLoading(true);
        let commissionCalculationFromDate, commissionCalculationToDate;
        if (filterMode === "month") {
          const { firstDay, lastDay } = getMonthRange(commissionForm.selectedMonth);
          commissionCalculationFromDate = firstDay;
          commissionCalculationToDate = lastDay;
        } else {
          commissionCalculationFromDate = customDateRange.from_date;
          commissionCalculationToDate = customDateRange.to_date;
        }
        const payload = {
          ...commissionForm,
          admin_type: adminId,
          commissionCalculationFromDate,
          commissionCalculationToDate
        };
        await API.post("/payment-out/add-commission-payment", payload);
        api.open({
          message: "Commission PayOut Added",
          description: "Commission Payment Has Been Successfully Added",
          className: "bg-green-400 rounded-lg font-bold",
          showProgress: true,
          pauseOnHover: false
        });
        setShowCommissionModal(false);
        resetCommissionForm();
        setReRender((val) => val + 1);
        fetchCommissionPayments();
      } catch (error) {
        const message = error.message || "Something went wrong";
        api.open({
          message: "Failed to Add Commission Payout",
          description: message,
          showProgress: true,
          pauseOnHover: false,
          className: "bg-red-400 rounded-lg font-bold"
        });
      } finally {
        setIsLoading(false);
      }
    }
  };
  const commissionColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Pay Date" },
    { key: "agent_name", header: "Agent" },
    { key: "amount", header: "Amount (₹)" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "commission_from", header: "From Date" },
    { key: "commission_to", header: "To Date" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "note", header: "Note" },
    { key: "disbursed_by", header: "Disbursed by" }
  ];
  const resetCommissionForm = () => {
    setAgentType("");
    setSelectedUserList([]);
    setCommissionForm({
      agent_id: "",
      pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      selectedMonth: currentMonth,
      amount: "",
      pay_type: "cash",
      transaction_id: "",
      note: "",
      admin_type: adminId,
      pay_for: paymentFor
    });
    setCommissionBreakdown([]);
    setTargetData({
      target: 0,
      achieved: 0,
      remaining: 0,
      difference: 0,
      upToTarget: 0,
      beyondTarget: 0,
      targetCommission: 0,
      isTargetSet: false,
      targetDisplay: "Not Set",
      calculationType: "commission"
    });
    setCalculatedAmount("0.00");
    setErrors({});
    setAlreadyPaid("0.00");
    setRemainingPayable("0.00");
    setIsTargetLoading(false);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
        lineNumber: 860,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
          lineNumber: 861,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
          lineNumber: 865,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4 md:mb-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-red-500 font-bold", children: "Commission / Incentive" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
              lineNumber: 874,
              columnNumber: 17
            }, this),
            " ",
            "Payments Out"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
            lineNumber: 873,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { title: "Add Commission Payment", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowCommissionModal(true);
                resetCommissionForm();
              },
              className: "bg-violet-900 text-white px-4 py-2 rounded shadow-md hover:bg-violet-600 transition duration-200 flex items-center",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "+" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 887,
                  columnNumber: 19
                }, this),
                " Commission / Incentive Payment"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
              lineNumber: 880,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
            lineNumber: 879,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
          lineNumber: 872,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 bg-white p-6 rounded-lg shadow-md", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-violet-800 border-b pb-2", children: "Commission / Incentive Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
            lineNumber: 892,
            columnNumber: 15
          }, this),
          isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Commission Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
            lineNumber: 897,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
            lineNumber: 896,
            columnNumber: 15
          }, this) : commissionPayments.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: commissionPayments,
              columns: commissionColumns,
              exportedPdfName: "PayOut Commission",
              exportedFileName: `Commission Payments.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
              lineNumber: 900,
              columnNumber: 15
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: "No commission payments found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
            lineNumber: 907,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
          lineNumber: 891,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
        lineNumber: 871,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showCommissionModal,
          onClose: () => {
            setShowCommissionModal(false);
            resetCommissionForm();
          },
          width: "max-w-md",
          children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900 border-b pb-2", children: "Add Commission / Incentive Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
              lineNumber: 923,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleCommissionSubmit, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Select Type ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 929,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 928,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    value: agentType,
                    onChange: (e) => {
                      const selected = e.target.value;
                      setAgentType(selected);
                      setSelectedUserList(
                        selected === "agent" ? agents : employees
                      );
                      setCommissionForm((prev) => ({
                        ...prev,
                        agent_id: "",
                        amount: ""
                      }));
                      setAlreadyPaid("0.00");
                      setRemainingPayable("0.00");
                      setTargetData({
                        target: 0,
                        achieved: 0,
                        remaining: 0,
                        difference: 0,
                        upToTarget: 0,
                        beyondTarget: 0,
                        targetCommission: 0,
                        isTargetSet: false,
                        targetDisplay: "Not Set",
                        calculationType: selected === "employee" ? "incentive" : "commission"
                      });
                      setCommissionBreakdown([]);
                      setCalculatedAmount("0.00");
                      setErrors({});
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", disabled: true, children: "-- Select Type --" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 965,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "agent", children: "Agent" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 968,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "employee", children: "Employee" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 969,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 931,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 927,
                columnNumber: 17
              }, this),
              agentType && /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Select ",
                  agentType === "agent" ? "Agent" : "Employee",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 977,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 975,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full h-12",
                    placeholder: `Select ${agentType}`,
                    showSearch: true,
                    optionFilterProp: "children",
                    filterOption: (input, option) => String(option?.children)?.toLowerCase().includes(input.toLowerCase()),
                    value: commissionForm.agent_id || void 0,
                    onChange: (value) => {
                      setErrors((prev) => ({ ...prev, agent_id: "" }));
                      setCommissionForm((prev) => ({
                        ...prev,
                        agent_id: value
                      }));
                      setCalculatedAmount("0.00");
                      setTargetData({
                        target: 0,
                        achieved: 0,
                        remaining: 0,
                        difference: 0,
                        upToTarget: 0,
                        beyondTarget: 0,
                        targetCommission: 0,
                        isTargetSet: false,
                        targetDisplay: "Not Set",
                        calculationType: agentType === "employee" ? "incentive" : "commission"
                      });
                      setCommissionBreakdown([]);
                    },
                    children: (agentType === "agent" ? agents : employees).map(
                      (person) => /* @__PURE__ */ jsxDEV(Select.Option, { value: person._id, children: [
                        person.name,
                        " | ",
                        person.phone_number
                      ] }, person._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1018,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 980,
                    columnNumber: 21
                  },
                  this
                ),
                errors.agent_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.agent_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1025,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 974,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Filter By ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1035,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1034,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex space-x-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setFilterMode("month"),
                      className: `px-4 py-2 rounded-lg ${filterMode === "month" ? "bg-violet-600 text-white" : "bg-gray-200 text-gray-700"}`,
                      children: "Month"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1038,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setFilterMode("custom"),
                      className: `px-4 py-2 rounded-lg ${filterMode === "custom" ? "bg-violet-600 text-white" : "bg-gray-200 text-gray-700"}`,
                      children: "Custom Range"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1048,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1037,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1033,
                columnNumber: 17
              }, this),
              filterMode === "month" ? /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Month ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1064,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1063,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "month",
                    name: "selectedMonth",
                    value: commissionForm.selectedMonth,
                    max: currentMonth,
                    onChange: handleCommissionChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1066,
                    columnNumber: 21
                  },
                  this
                ),
                errors.selectedMonth && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.selectedMonth }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1075,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1062,
                columnNumber: 17
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "From Date ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1082,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1081,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "from_date",
                      value: customDateRange.from_date,
                      max: customDateRange.to_date || currentMonth,
                      onChange: handleCommissionChange,
                      className: "w-full p-3 border border-gray-300 rounded-lg"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1084,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.from_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.from_date }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1093,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1080,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "To Date ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1098,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1097,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "to_date",
                      value: customDateRange.to_date,
                      min: customDateRange.from_date,
                      max: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                      onChange: handleCommissionChange,
                      className: "w-full p-3 border border-gray-300 rounded-lg"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1100,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.to_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.to_date }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1110,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1096,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1079,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-2", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    if (filterMode === "month") {
                      calculateTotalPayableCommission(
                        commissionForm.agent_id,
                        commissionForm.selectedMonth,
                        agentType,
                        "month"
                      );
                    } else {
                      calculateTotalPayableCommission(
                        commissionForm.agent_id,
                        { from: customDateRange.from_date, to: customDateRange.to_date },
                        agentType,
                        "custom"
                      );
                    }
                  },
                  disabled: !commissionForm.agent_id || filterMode === "month" && !commissionForm.selectedMonth || filterMode === "custom" && (!customDateRange.from_date || !customDateRange.to_date) || isLoadingCommissionCalculation,
                  className: "px-3 py-2 bg-green-700 text-white rounded-lg shadow-md hover:bg-green-800 transition duration-200",
                  children: isLoadingCommissionCalculation ? "Calculating..." : "Calculate Amount"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1117,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1116,
                columnNumber: 17
              }, this),
              isTargetLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex justify-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Target Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1153,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1152,
                columnNumber: 17
              }, this),
              agentType && targetData && !isTargetLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: targetData.isTargetSet ? /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-100 p-4 rounded-lg shadow mb-6", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-yellow-800 mb-2", children: "Target Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1162,
                  columnNumber: 25
                }, this),
                targetData.achieved >= targetData.target && /* @__PURE__ */ jsxDEV("div", { className: "text-green-800 font-semibold mb-3", children: "🎉 Target Achieved" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1167,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-3 gap-4 bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Target Set" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1174,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: targetData.targetDisplay,
                        readOnly: true,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1177,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1173,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Achieved" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1184,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: `₹${targetData.achieved?.toLocaleString(
                          "en-IN"
                        )}`,
                        readOnly: true,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1187,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1183,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Difference" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1196,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: `₹${targetData.difference?.toLocaleString(
                          "en-IN"
                        )}`,
                        readOnly: true,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1199,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1195,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: [
                      "Total Payable",
                      " ",
                      targetData.calculationType === "incentive" ? "Incentive" : "Commission"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1209,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        readOnly: true,
                        value: `₹${targetData.targetCommission.toLocaleString(
                          "en-IN",
                          {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }
                        )}`,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 text-green-700 font-bold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1215,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1208,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1172,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1161,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-yellow-50 rounded-lg border border-yellow-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-yellow-800 font-medium", children: [
                "No target set for this ",
                agentType,
                ".",
                " ",
                targetData.calculationType === "incentive" ? "Incentive" : "Commission",
                " ",
                "will be calculated based on standard rules."
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1231,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1230,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1159,
                columnNumber: 17
              }, this),
              agentType && targetData.isTargetSet && !isTargetLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 bg-white p-4 rounded-lg shadow border", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-800 mb-3 text-lg", children: [
                  targetData.calculationType === "incentive" ? "Incentive" : "Commission",
                  " ",
                  "Breakdown"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1246,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm border", children: [
                  /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-violet-100 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Part" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1255,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "Amount (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1256,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1254,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1253,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { children: [
                    agentType === "agent" && /* @__PURE__ */ jsxDEV("tr", { children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: "0.5% up to Target" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1264,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: [
                        "₹",
                        targetData.upToTarget?.toLocaleString("en-IN", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        })
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1267,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1263,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("tr", { children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: agentType === "agent" ? "1% beyond Target" : "1% incentive on target difference" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1277,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: [
                        "₹",
                        targetData.beyondTarget?.toLocaleString("en-IN", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        })
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1282,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1276,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("tr", { className: "bg-green-100 font-semibold", children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: [
                        "Total Payable",
                        " ",
                        targetData.calculationType === "incentive" ? "Incentive" : "Commission"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1291,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right text-green-800", children: [
                        "₹",
                        targetData.targetCommission?.toLocaleString(
                          "en-IN",
                          {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1297,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1290,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1261,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1252,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1245,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1314,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "pay_date",
                    value: commissionForm.pay_date,
                    onChange: handleCommissionChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    disabled: !modifyPayment
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1317,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1326,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1313,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Total Payable (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1333,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: calculatedAmount,
                    readOnly: true,
                    className: "w-full p-3 border border-gray-300 rounded-lg bg-gray-100 font-semibold"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1336,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1332,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Enter Amount (₹) ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1346,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1345,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "amount",
                    min: 1,
                    value: commissionForm.amount,
                    onChange: (e) => {
                      const value = e.target.value;
                      setCommissionForm((prev) => ({
                        ...prev,
                        amount: value
                      }));
                      setErrors((prev) => ({ ...prev, amount: "" }));
                    },
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    placeholder: "Enter how much to pay"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1348,
                    columnNumber: 19
                  },
                  this
                ),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1365,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1344,
                columnNumber: 17
              }, this),
              agentType === "agent" && commissionBreakdown.length > 0 && !isLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-gray-100 p-3 rounded-lg shadow-inner border border-gray-300", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 mb-3 text-lg", children: "Commission Breakdown (Customer-wise)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1371,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "max-h-60 overflow-y-auto custom-scrollbar", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm border", children: [
                  /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-violet-100 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1378,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Phone" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1381,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1384,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "Group value (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1387,
                      columnNumber: 30
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "commission Percentage (%)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1390,
                      columnNumber: 30
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "commission value (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1393,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1377,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1376,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { children: commissionBreakdown.map(
                    (item, index) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.user_id?.full_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1401,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.user_id?.phone_number || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1404,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.group_id?.group_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1407,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.group_id?.group_value || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1410,
                        columnNumber: 34
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.group_id?.commission || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1413,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: item.commission_value || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1416,
                        columnNumber: 31
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1400,
                      columnNumber: 25
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1398,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1375,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1374,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1370,
                columnNumber: 17
              }, this),
              agentType === "employee" && commissionBreakdown.length > 0 && !isLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-gray-100 p-3 rounded-lg shadow-inner border border-gray-300", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 mb-3 text-lg", children: "Incentive Breakdown (Customer-wise)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1429,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "max-h-60 overflow-y-auto custom-scrollbar", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm border", children: [
                  /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-violet-100 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1436,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Phone" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1439,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1442,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "Group value (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1445,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "incentive percentage (%)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1448,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "incentive value (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1451,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1435,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1434,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { children: commissionBreakdown.map(
                    (item, index) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.user_id?.full_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1459,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.user_id?.phone_number || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1462,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item?.group_id?.group_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1465,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: item?.group_id?.group_value || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1468,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: item?.group_id?.incentives || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1471,
                        columnNumber: 32
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: item?.incentive_value || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1474,
                        columnNumber: 32
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                      lineNumber: 1458,
                      columnNumber: 25
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1456,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1433,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1432,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1428,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Mode" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1485,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "pay_type",
                    value: commissionForm.pay_type,
                    onChange: handleCommissionChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1494,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1495,
                        columnNumber: 21
                      }, this),
                      modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                          lineNumber: 1498,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "bank_transfer", children: "Bank Transfer" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                          lineNumber: 1499,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                        lineNumber: 1497,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1488,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pay_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_type }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1504,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1484,
                columnNumber: 17
              }, this),
              commissionForm.pay_type === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Transaction ID ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1513,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1512,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "transaction_id",
                    value: commissionForm.transaction_id,
                    onChange: handleCommissionChange,
                    placeholder: "Enter transaction ID",
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1515,
                    columnNumber: 21
                  },
                  this
                ),
                errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1524,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1511,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1532,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    name: "note",
                    value: commissionForm.note,
                    onChange: handleCommissionChange,
                    placeholder: "Additional details",
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    rows: "2"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1535,
                    columnNumber: 19
                  },
                  this
                ),
                errors.note && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.note }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1544,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1531,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-violet-50 p-3 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Disbursed By" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1549,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: adminName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                  lineNumber: 1552,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1548,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setShowCommissionModal(false);
                      resetCommissionForm();
                    },
                    className: "px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1556,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    disabled: isLoading || isLoadingCommissionCalculation,
                    className: "px-4 py-2 bg-violet-700 text-white rounded-lg hover:bg-violet-600 disabled:opacity-50",
                    children: isLoading ? "Processing..." : "Save Payment"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                    lineNumber: 1566,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
                lineNumber: 1555,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
              lineNumber: 926,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
            lineNumber: 922,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
          lineNumber: 914,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
      lineNumber: 859,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
    lineNumber: 857,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx",
    lineNumber: 856,
    columnNumber: 5
  }, this);
};
_s(TargetPayOutCommissionIncentive, "MfwzFMlpzRm7FA/meTE1KpLTMeQ=", false, function() {
  return [notification.useNotification];
});
_c = TargetPayOutCommissionIncentive;
export default TargetPayOutCommissionIncentive;
var _c;
$RefreshReg$(_c, "TargetPayOutCommissionIncentive");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayOutCommissionIncentive.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMjFCWSxTQTZuQlUsVUE3bkJWOzJCQTMxQlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0MsUUFBUUMsU0FBU0Msb0JBQW9CO0FBQzlDLE9BQU9DLG9CQUFvQjtBQUUzQixNQUFNQyxrQ0FBa0NBLE1BQU07QUFBQUMsS0FBQTtBQUM1QyxRQUFNQyxhQUFhO0FBQ25CLFFBQU0sQ0FBQ0MsS0FBS0MsYUFBYSxJQUFJTixhQUFhTyxnQkFBZ0I7QUFDMUQsUUFBTSxDQUFDQyxxQkFBcUJDLHNCQUFzQixJQUFJbkIsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQ29CLGVBQWVDLGdCQUFnQixJQUFJckIsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3NCLFNBQVNDLFVBQVUsSUFBSXZCLFNBQVMsRUFBRTtBQUV6QyxRQUFNLENBQUN3QixZQUFZQyxhQUFhLElBQUl6QixTQUFTLE9BQU87QUFHcEQsUUFBTSxDQUFDMEIsYUFBYUMsY0FBYyxJQUFJM0IsU0FBUztBQUFBLElBQzdDNEIsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJakMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2tDLFdBQVdDLFlBQVksSUFBSW5DLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNvQyxXQUFXQyxZQUFZLElBQUlyQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDc0Msa0JBQWtCQyxtQkFBbUIsSUFBSXZDLFNBQVMsTUFBTTtBQUMvRCxRQUFNLENBQUN3QyxhQUFhQyxjQUFjLElBQUl6QyxTQUFTLE1BQU07QUFDckQsUUFBTSxDQUFDMEMsa0JBQWtCQyxtQkFBbUIsSUFBSTNDLFNBQVMsTUFBTTtBQUMvRCxRQUFNLENBQUM0QyxrQkFBa0JDLG1CQUFtQixJQUFJN0MsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzhDLG9CQUFvQkMscUJBQXFCLElBQUkvQyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDZ0QsV0FBV0MsWUFBWSxJQUFJakQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2tELGdDQUFnQ0MsaUNBQWlDLElBQ3RFbkQsU0FBUyxLQUFLO0FBQ2hCLFFBQU0sQ0FBQ29ELFdBQVdDLFlBQVksSUFBSXJELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNzRCxRQUFRQyxTQUFTLElBQUl2RCxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN3RCxVQUFVQyxXQUFXLElBQUl6RCxTQUFTLENBQUM7QUFDMUMsUUFBTSxDQUFDMEQsWUFBWUMsYUFBYSxJQUFJM0QsU0FBUztBQUFBLElBQzNDNEQsUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsSUFDWEMsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxJQUNaQyxjQUFjO0FBQUEsSUFDZEMsa0JBQWtCO0FBQUEsSUFDbEJDLGFBQWE7QUFBQSxJQUNiQyxlQUFlO0FBQUEsSUFDZkMsaUJBQWlCO0FBQUEsRUFDbkIsQ0FBQztBQUdELFFBQU1DLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsUUFBTUMsZUFBZSxHQUFHRixNQUFNRyxZQUFZLENBQUMsSUFBSUM7QUFBQUEsSUFDN0NKLE1BQU1LLFNBQVMsSUFBSTtBQUFBLEVBQ3JCLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDbEIsUUFBTUMsZUFBZSxHQUFHUCxNQUFNRyxZQUFZLENBQUMsSUFBSUMsT0FBT0osTUFBTUssU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUM1RixRQUFNRSxjQUFjLElBQUlQLEtBQUtELE1BQU1HLFlBQVksR0FBR0gsTUFBTUssU0FBUyxJQUFJLEdBQUcsQ0FBQyxFQUFFSSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDckcsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJbEYsU0FBUztBQUFBLElBQ3JEbUYsV0FBV047QUFBQUEsSUFDWE8sU0FBU047QUFBQUEsRUFDWCxDQUFDO0FBR0QsUUFBTSxDQUFDTyxnQkFBZ0JDLGlCQUFpQixJQUFJdEYsU0FBUztBQUFBLElBQ25EdUYsVUFBVTtBQUFBLElBQ1ZDLFdBQVUsb0JBQUlqQixLQUFLLEdBQUVRLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLElBQy9DUyxlQUFlakI7QUFBQUEsSUFDZmtCLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLE1BQU07QUFBQSxJQUNOQyxTQUFTaEY7QUFBQUEsSUFDVGlGLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFJRCxRQUFNLENBQUNDLHFCQUFxQkMsc0JBQXNCLElBQUlqRyxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDa0csaUJBQWlCQyxrQkFBa0IsSUFBSW5HLFNBQVMsS0FBSztBQUU1RCxRQUFNb0csY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU1uRyxJQUFJb0csSUFBSSxrQkFBa0I7QUFDNUMsWUFBTUMsTUFBTUYsSUFBSUcsUUFBUTtBQUN4QnZFO0FBQUFBLFFBQ0VzRSxJQUFJRSxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLGVBQWUsV0FBV0QsRUFBRUMsZUFBZSxNQUFNO0FBQUEsTUFDdkU7QUFDQXhFO0FBQUFBLFFBQ0VvRSxJQUFJRTtBQUFBQSxVQUNGLENBQUNDLE1BQU1BLEVBQUVDLGVBQWUsY0FBY0QsRUFBRUMsZUFBZTtBQUFBLFFBQ3pEO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU0MsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHFCQUFxQkYsR0FBRztBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNELFFBQU1HLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN4Q0Msa0JBQWNELEVBQUVwRCxPQUFPc0QsS0FBSztBQUM1QkMsbUJBQWUsQ0FBQztBQUNoQkMsMEJBQXNCLENBQUM7QUFBQSxFQUN6QjtBQUNBLFFBQU1DLGFBQWFBLENBQUNDLFNBQVM7QUFDM0IsUUFBSSxDQUFDQSxLQUFNLFFBQU87QUFDbEIsUUFBSSxPQUFPQSxTQUFTLFlBQVksc0JBQXNCQyxLQUFLRCxJQUFJLEdBQUc7QUFDaEUsYUFBT0E7QUFBQUEsSUFDVDtBQUNBLFVBQU1FLElBQUksSUFBSWpELEtBQUsrQyxJQUFJO0FBQ3ZCLFFBQUlHLE1BQU1ELENBQUMsRUFBRyxRQUFPO0FBQ3JCLFVBQU1FLE9BQU9GLEVBQUUvQyxZQUFZO0FBQzNCLFVBQU1rRCxRQUFRakQsT0FBTzhDLEVBQUU3QyxTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUN0RCxVQUFNZ0QsTUFBTWxELE9BQU84QyxFQUFFSyxRQUFRLENBQUMsRUFBRWpELFNBQVMsR0FBRyxHQUFHO0FBQy9DLFdBQU8sR0FBRzhDLElBQUksSUFBSUMsS0FBSyxJQUFJQyxHQUFHO0FBQUEsRUFDaEM7QUFpU0EsUUFBTUUscUJBQXFCLE9BQU9DLFNBQVNDLFFBQVFqRyxNQUFNa0csT0FBTyxZQUFZO0FBQzFFLFFBQUksQ0FBQ0YsV0FBWUUsU0FBUyxhQUFhLENBQUNELE9BQU9FLFFBQVEsQ0FBQ0YsT0FBT0csS0FBTTtBQUNuRXhFLG9CQUFjO0FBQUEsUUFDWkMsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxXQUFXO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFlBQVk7QUFBQSxRQUNaQyxjQUFjO0FBQUEsUUFDZEMsa0JBQWtCO0FBQUEsUUFDbEJDLGFBQWE7QUFBQSxRQUNiQyxlQUFlO0FBQUEsUUFDZkMsaUJBQWlCdEMsU0FBUyxhQUFhLGNBQWM7QUFBQSxNQUN2RCxDQUFDO0FBQ0RrRSw2QkFBdUIsRUFBRTtBQUN6QjtBQUFBLElBQ0Y7QUFFQUUsdUJBQW1CLElBQUk7QUFDdkIsUUFBSTtBQUNGLFVBQUlpQyxVQUFVQztBQUNkLFVBQUlKLFNBQVMsU0FBUztBQUNwQixjQUFNLENBQUNQLE1BQU1ZLFFBQVEsSUFBSU4sT0FBT2hELE1BQU0sR0FBRztBQUN6Q29ELG1CQUFXLEdBQUdWLElBQUksSUFBSVksUUFBUTtBQUM5QkQsa0JBQVUsSUFBSTlELEtBQUttRCxNQUFNYSxTQUFTRCxRQUFRLEdBQUcsQ0FBQyxFQUMzQ3ZELFlBQVksRUFDWkMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2pCLE9BQU87QUFDTG9ELG1CQUFXZixXQUFXVyxPQUFPRSxJQUFJO0FBQ2pDRyxrQkFBVWhCLFdBQVdXLE9BQU9HLEVBQUU7QUFBQSxNQUNoQztBQUdBLFVBQUlLO0FBQ0osVUFBSXpHLFNBQVMsWUFBWTtBQUN2QnlHLG9CQUFZLE1BQU10SSxJQUFJb0csSUFBSSxxQkFBcUJ5QixPQUFPLElBQUk7QUFBQSxVQUN4RFUsUUFBUSxFQUFFQyxZQUFZTixVQUFVTyxVQUFVTixRQUFRO0FBQUEsUUFDcEQsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMRyxvQkFBWSxNQUFNdEksSUFBSW9HLElBQUksa0JBQWtCeUIsT0FBTyxJQUFJO0FBQUEsVUFDckRVLFFBQVEsRUFBRUMsWUFBWU4sVUFBVU8sVUFBVU4sUUFBUTtBQUFBLFFBQ3BELENBQUM7QUFBQSxNQUNIO0FBRUEsWUFBTU8sa0JBQ0pKLFdBQVdoQyxNQUFNcUMsVUFBVUwsV0FBV2hDLE1BQU1zQyxlQUN4Q0MsT0FBT1AsVUFBVWhDLEtBQUtzQyxZQUFZLElBQ2xDO0FBR04sVUFBSUU7QUFDSixVQUFJakgsU0FBUyxZQUFZO0FBQ3ZCaUgsZUFBTyxNQUFNOUksSUFBSW9HLElBQUksb0JBQW9CeUIsT0FBTyxjQUFjO0FBQUEsVUFDNURVLFFBQVEsRUFBRUMsWUFBWU4sVUFBVU8sVUFBVU4sUUFBUTtBQUFBLFFBQ3BELENBQUM7QUFBQSxNQUNILE9BQU87QUFDTFcsZUFBTyxNQUFNOUksSUFBSW9HLElBQUksaUJBQWlCeUIsT0FBTyxlQUFlO0FBQUEsVUFDMURVLFFBQVEsRUFBRUMsWUFBWU4sVUFBVU8sVUFBVU4sUUFBUTtBQUFBLFFBQ3BELENBQUM7QUFBQSxNQUNIO0FBRUEsVUFBSXhFLFdBQ0Y5QixTQUFTLGFBQ0xpSCxNQUFNeEMsTUFBTXlDLGtCQUFrQkMscUJBQXFCLElBQ25ERixNQUFNeEMsTUFBTTJDLG1CQUFtQkQscUJBQXFCO0FBQzFELFVBQUksT0FBT3JGLGFBQWEsVUFBVTtBQUNoQ0EsbUJBQVdrRixPQUFPbEYsU0FBU3VGLFFBQVEsY0FBYyxFQUFFLENBQUM7QUFBQSxNQUN0RDtBQUdBLFVBQUlwRixhQUFhO0FBQ2pCLFVBQUlDLGVBQWU7QUFDbkIsVUFBSW9GLGtCQUFrQjtBQUN0QixZQUFNdkYsWUFBWXdGLEtBQUtDLElBQUlYLGtCQUFrQi9FLFVBQVUsQ0FBQztBQUN4RCxZQUFNRSxhQUFhRixXQUFXK0U7QUFFOUIsVUFBSTdHLFNBQVMsU0FBUztBQUNwQixZQUFJOEIsWUFBWStFLGlCQUFpQjtBQUMvQjVFLHVCQUFhSCxXQUFXO0FBQUEsUUFDMUIsT0FBTztBQUNMRyx1QkFBYTRFLGtCQUFrQjtBQUMvQjNFLDBCQUFnQkosV0FBVytFLG1CQUFtQjtBQUFBLFFBQ2hEO0FBQ0FTLDBCQUFrQnJGLGFBQWFDO0FBQUFBLE1BQ2pDLE9BQU87QUFDTCxZQUFJSixXQUFXK0UsaUJBQWlCO0FBQzlCM0UsMEJBQWdCSixXQUFXK0UsbUJBQW1CO0FBQUEsUUFDaEQ7QUFDQVMsMEJBQWtCcEY7QUFBQUEsTUFDcEI7QUFHQU4sb0JBQWM7QUFBQSxRQUNaQyxRQUFRZ0Y7QUFBQUEsUUFDUi9FO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDLGtCQUFrQm1GO0FBQUFBLFFBQ2xCbEYsYUFBYXlFLGtCQUFrQjtBQUFBLFFBQy9CeEUsZUFDRXdFLGtCQUFrQixJQUNkLElBQUlBLGdCQUFnQlksZUFBZSxPQUFPLENBQUMsS0FDM0M7QUFBQSxRQUNObkYsaUJBQWlCdEMsU0FBUyxhQUFhLGNBQWM7QUFBQSxNQUN2RCxDQUFDO0FBRURRLDBCQUFvQjhHLGdCQUFnQkksUUFBUSxDQUFDLENBQUM7QUFDOUNuRSx3QkFBa0IsQ0FBQ29FLFVBQVU7QUFBQSxRQUMzQixHQUFHQTtBQUFBQSxRQUNIaEUsUUFBUTJELGdCQUFnQkksUUFBUSxDQUFDO0FBQUEsTUFDbkMsRUFBRTtBQUVGLFlBQU1FLGdCQUNKNUgsU0FBUyxhQUNMaUgsTUFBTXhDLE1BQU1vRCxpQkFBaUIsS0FDN0JaLE1BQU14QyxNQUFNcUQsa0JBQWtCO0FBQ3BDNUQsNkJBQXVCMEQsYUFBYTtBQUFBLElBQ3RDLFNBQVM3QyxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JEbkQsb0JBQWM7QUFBQSxRQUNaQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFdBQVc7QUFBQSxRQUNYQyxZQUFZO0FBQUEsUUFDWkMsWUFBWTtBQUFBLFFBQ1pDLGNBQWM7QUFBQSxRQUNkQyxrQkFBa0I7QUFBQSxRQUNsQkMsYUFBYTtBQUFBLFFBQ2JDLGVBQWU7QUFBQSxRQUNmQyxpQkFBaUJ0QyxTQUFTLGFBQWEsY0FBYztBQUFBLE1BQ3ZELENBQUM7QUFDRGtFLDZCQUF1QixFQUFFO0FBQUEsSUFDM0IsVUFBQztBQUNDRSx5QkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUdBLFFBQU0yRCwwQkFBMEIsWUFBWTtBQUMxQzdHLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU04RyxXQUFXLE1BQU03SixJQUFJb0csSUFBSSxzQ0FBc0M7QUFDckUsWUFBTTBELGVBQWVELFNBQVN2RCxLQUFLeUQsSUFBSSxDQUFDQyxTQUFTQyxXQUFXO0FBQUEsUUFDMURDLElBQUlELFFBQVE7QUFBQSxRQUNaRSxLQUFLSCxRQUFRRztBQUFBQSxRQUNiOUUsVUFBVTJFLFFBQVEzRTtBQUFBQSxRQUNsQitFLFlBQVlKLFFBQVEzRSxVQUFVZ0Y7QUFBQUEsUUFDOUIvRSxVQUFVMEUsUUFBUTFFO0FBQUFBLFFBQ2xCRSxRQUFRd0UsUUFBUXhFO0FBQUFBLFFBQ2hCQyxVQUFVdUUsUUFBUXZFO0FBQUFBLFFBQ2xCNkUsaUJBQ0VOLFFBQVFPLCtCQUErQnpGLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLFFBQzFEMEYsZUFDRVIsUUFBUVMsNkJBQTZCM0YsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsUUFDeERZLGdCQUFnQnNFLFFBQVF0RTtBQUFBQSxRQUN4QkMsTUFBTXFFLFFBQVFyRTtBQUFBQSxRQUNkQyxTQUFTb0UsUUFBUXBFO0FBQUFBLFFBQ2pCOEUsY0FBY1YsUUFBUW5FLFlBQVl3RTtBQUFBQSxRQUNsQ00sWUFBWVgsUUFBUVc7QUFBQUEsTUFDdEIsRUFBRTtBQUNGOUgsNEJBQXNCaUgsWUFBWTtBQUFBLElBQ3BDLFNBQVNsRCxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sdUNBQXVDQSxLQUFLO0FBQzFEL0QsNEJBQXNCLEVBQUU7QUFBQSxJQUMxQixVQUFDO0FBQ0NFLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQWxELFlBQVUsTUFBTTtBQUNkLFVBQU0rSyxPQUFPQyxhQUFhQyxRQUFRLE1BQU07QUFDeEMsVUFBTUMsVUFBVUMsS0FBS0MsTUFBTUwsSUFBSTtBQUMvQnZKLGVBQVcwSixTQUFTWixHQUFHO0FBQ3ZCaEgsaUJBQWE0SCxTQUFTRyxhQUFhSCxTQUFTVixRQUFRLEVBQUU7QUFDdEQsUUFBSVUsU0FBU0ksdUJBQXVCQyxvQkFBb0JDLGNBQWM7QUFDcEVsSztBQUFBQSxRQUNFNEosU0FBU0ksdUJBQXVCQyxvQkFBb0JDLGlCQUFpQjtBQUFBLE1BQ3ZFO0FBQUEsSUFDRjtBQUNBbkYsZ0JBQVk7QUFDWjBELDRCQUF3QjtBQUFBLEVBQzFCLEdBQUcsQ0FBQ3RHLFFBQVEsQ0FBQztBQUdiLFFBQU1nSSxnQkFBZ0JBLENBQUMvRixrQkFBa0I7QUFDdkMsUUFBSSxDQUFDQSxjQUFlLFFBQU8sRUFBRTJDLFVBQVUsSUFBSUMsU0FBUyxHQUFHO0FBQ3ZELFVBQU0sQ0FBQ1gsTUFBTUMsS0FBSyxJQUFJbEMsY0FBY1QsTUFBTSxHQUFHO0FBQzdDLFVBQU1vRCxXQUFXLEdBQUdWLElBQUksSUFBSUMsS0FBSztBQUNqQyxVQUFNVSxVQUFVLElBQUk5RCxLQUFLbUQsTUFBTUMsT0FBTyxDQUFDLEVBQUU1QyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkUsV0FBTyxFQUFFb0QsVUFBVUMsUUFBUTtBQUFBLEVBQzdCO0FBdURBLFFBQU1vRCxrQ0FBa0MsT0FBTzFELFNBQVNDLFFBQVFqRyxNQUFNa0csT0FBTyxZQUFZO0FBQ3ZGLFFBQUksQ0FBQ0YsV0FBWSxDQUFDQyxVQUFVQyxTQUFTLFdBQWFBLFNBQVMsYUFBYSxDQUFDRCxPQUFPRSxRQUFRLENBQUNGLE9BQU9HLEtBQU07QUFDcEc3Qyx3QkFBa0IsQ0FBQ29FLFVBQVUsRUFBRSxHQUFHQSxNQUFNaEUsUUFBUSxHQUFHLEVBQUU7QUFDckRuRCwwQkFBb0IsTUFBTTtBQUMxQjtBQUFBLElBQ0Y7QUFDQVksc0NBQWtDLElBQUk7QUFDdEMsUUFBSTtBQUNGLFlBQU0yRSxtQkFBbUJDLFNBQVNDLFFBQVFqRyxNQUFNa0csSUFBSTtBQUFBLElBQ3RELFNBQVNuQixPQUFPO0FBQ2RELGNBQVFDLE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REeEIsd0JBQWtCLENBQUNvRSxVQUFVLEVBQUUsR0FBR0EsTUFBTWhFLFFBQVEsR0FBRyxFQUFFO0FBQ3JEbkQsMEJBQW9CLE1BQU07QUFBQSxJQUM1QixVQUFDO0FBQ0NZLHdDQUFrQyxLQUFLO0FBQUEsSUFDekM7QUFBQSxFQUNGO0FBRUEsUUFBTXVJLHlCQUF5QkEsQ0FBQzFFLE1BQU07QUFDcEMsVUFBTSxFQUFFdUQsTUFBTXJELE1BQU0sSUFBSUYsRUFBRXBEO0FBRzFCLFFBQUkyRyxTQUFTLGVBQWVBLFNBQVMsV0FBVztBQUM5Q3JGLHlCQUFtQixDQUFDd0UsVUFBVTtBQUFBLFFBQzVCLEdBQUdBO0FBQUFBLFFBQ0gsQ0FBQ2EsSUFBSSxHQUFHckQ7QUFBQUEsTUFDVixFQUFFO0FBQ0YzRCxnQkFBVSxDQUFDbUcsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ2EsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUc3Q2hJLDBCQUFvQixNQUFNO0FBQzFCb0Isb0JBQWM7QUFBQSxRQUNaQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFdBQVc7QUFBQSxRQUNYQyxZQUFZO0FBQUEsUUFDWkMsWUFBWTtBQUFBLFFBQ1pDLGNBQWM7QUFBQSxRQUNkQyxrQkFBa0I7QUFBQSxRQUNsQkMsYUFBYTtBQUFBLFFBQ2JDLGVBQWU7QUFBQSxRQUNmQyxpQkFDRWpDLGNBQWMsYUFBYSxjQUFjO0FBQUEsTUFDN0MsQ0FBQztBQUNENkQsNkJBQXVCLEVBQUU7QUFDekI7QUFBQSxJQUNGO0FBR0FYLHNCQUFrQixDQUFDb0UsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ2EsSUFBSSxHQUFHckQsTUFBTSxFQUFFO0FBQ3hEM0QsY0FBVSxDQUFDbUcsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ2EsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUc3QyxRQUFJLENBQUMsWUFBWSxlQUFlLEVBQUVvQixTQUFTcEIsSUFBSSxHQUFHO0FBQ2hEaEksMEJBQW9CLE1BQU07QUFDMUJvQixvQkFBYztBQUFBLFFBQ1pDLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsV0FBVztBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxZQUFZO0FBQUEsUUFDWkMsY0FBYztBQUFBLFFBQ2RDLGtCQUFrQjtBQUFBLFFBQ2xCQyxhQUFhO0FBQUEsUUFDYkMsZUFBZTtBQUFBLFFBQ2ZDLGlCQUNFakMsY0FBYyxhQUFhLGNBQWM7QUFBQSxNQUM3QyxDQUFDO0FBQ0Q2RCw2QkFBdUIsRUFBRTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBLFFBQU0yRixlQUFlQSxNQUFNO0FBQ3pCLFVBQU1DLFlBQVksQ0FBQztBQUNuQixRQUFJLENBQUN4RyxlQUFlRSxVQUFVO0FBQzVCc0csZ0JBQVV0RyxXQUFXO0FBQUEsSUFDdkI7QUFDQSxRQUNFLENBQUNGLGVBQWVLLFVBQ2hCK0IsTUFBTXBDLGVBQWVLLE1BQU0sS0FDM0JvRyxXQUFXekcsZUFBZUssTUFBTSxLQUFLLEdBQ3JDO0FBQ0FtRyxnQkFBVW5HLFNBQVM7QUFBQSxJQUNyQjtBQUNBLFFBQUlsRSxlQUFlLFdBQVcsQ0FBQzZELGVBQWVJLGVBQWU7QUFDM0RvRyxnQkFBVXBHLGdCQUFnQjtBQUFBLElBQzVCO0FBQ0EsUUFBSWpFLGVBQWUsVUFBVTtBQUMzQixVQUFJLENBQUN5RCxnQkFBZ0JFLFVBQVcwRyxXQUFVMUcsWUFBWTtBQUN0RCxVQUFJLENBQUNGLGdCQUFnQkcsUUFBU3lHLFdBQVV6RyxVQUFVO0FBQUEsSUFDcEQ7QUFDQSxRQUNFQyxlQUFlTSxhQUFhLFlBQzVCLENBQUNOLGVBQWVPLGdCQUNoQjtBQUNBaUcsZ0JBQVVqRyxpQkFBaUI7QUFBQSxJQUM3QjtBQUNBckMsY0FBVXNJLFNBQVM7QUFDbkIsV0FBT0UsT0FBT0MsS0FBS0gsU0FBUyxFQUFFSSxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNQyx5QkFBeUIsT0FBT2xGLE1BQU07QUFDMUNBLE1BQUVtRixlQUFlO0FBQ2pCLFVBQU1DLFVBQVVSLGFBQWE7QUFDN0IsUUFBSVEsU0FBUztBQUNYLFVBQUk7QUFDRm5KLHFCQUFhLElBQUk7QUFFakIsWUFBSXdILCtCQUErQkU7QUFDbkMsWUFBSW5KLGVBQWUsU0FBUztBQUMxQixnQkFBTSxFQUFFNEcsVUFBVUMsUUFBUSxJQUFJbUQsY0FBY25HLGVBQWVJLGFBQWE7QUFDeEVnRiwwQ0FBZ0NyQztBQUNoQ3VDLHdDQUE4QnRDO0FBQUFBLFFBQ2hDLE9BQU87QUFDTG9DLDBDQUFnQ3hGLGdCQUFnQkU7QUFDaER3Rix3Q0FBOEIxRixnQkFBZ0JHO0FBQUFBLFFBQ2hEO0FBRUEsY0FBTWlILFVBQVU7QUFBQSxVQUNkLEdBQUdoSDtBQUFBQSxVQUNIVSxZQUFZekU7QUFBQUEsVUFDWm1KO0FBQUFBLFVBQ0FFO0FBQUFBLFFBQ0Y7QUFFQSxjQUFNekssSUFBSW9NLEtBQUssdUNBQXVDRCxPQUFPO0FBQzdEdEwsWUFBSXdMLEtBQUs7QUFBQSxVQUNQMUssU0FBUztBQUFBLFVBQ1QySyxhQUFhO0FBQUEsVUFDYkMsV0FBVztBQUFBLFVBQ1hDLGNBQWM7QUFBQSxVQUNkQyxjQUFjO0FBQUEsUUFDaEIsQ0FBQztBQUNEeEwsK0JBQXVCLEtBQUs7QUFDNUJ5TCw0QkFBb0I7QUFDcEJuSixvQkFBWSxDQUFDb0osUUFBUUEsTUFBTSxDQUFDO0FBQzVCL0MsZ0NBQXdCO0FBQUEsTUFDMUIsU0FBU2hELE9BQU87QUFDZCxjQUFNakYsVUFBVWlGLE1BQU1qRixXQUFXO0FBQ2pDZCxZQUFJd0wsS0FBSztBQUFBLFVBQ1AxSyxTQUFTO0FBQUEsVUFDVDJLLGFBQWEzSztBQUFBQSxVQUNiNkssY0FBYztBQUFBLFVBQ2RDLGNBQWM7QUFBQSxVQUNkRixXQUFXO0FBQUEsUUFDYixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0N4SixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU02SixvQkFBb0I7QUFBQSxJQUN4QixFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssWUFBWUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLFFBQVE7QUFBQSxJQUNyQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsYUFBYTtBQUFBLElBQ3RDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsWUFBWTtBQUFBLElBQzlDLEVBQUVELEtBQUssaUJBQWlCQyxRQUFRLFVBQVU7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssUUFBUUMsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLEVBQUM7QUFHakQsUUFBTUosc0JBQXNCQSxNQUFNO0FBQ2hDdkssaUJBQWEsRUFBRTtBQUNmUSx3QkFBb0IsRUFBRTtBQUN0QnlDLHNCQUFrQjtBQUFBLE1BQ2hCQyxVQUFVO0FBQUEsTUFDVkMsV0FBVSxvQkFBSWpCLEtBQUssR0FBRVEsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDL0NTLGVBQWVqQjtBQUFBQSxNQUNma0IsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxnQkFBZ0I7QUFBQSxNQUNoQkMsTUFBTTtBQUFBLE1BQ05FLFlBQVl6RTtBQUFBQSxNQUNad0UsU0FBU2hGO0FBQUFBLElBQ1gsQ0FBQztBQUNEbUYsMkJBQXVCLEVBQUU7QUFDekJ0QyxrQkFBYztBQUFBLE1BQ1pDLFFBQVE7QUFBQSxNQUNSQyxVQUFVO0FBQUEsTUFDVkMsV0FBVztBQUFBLE1BQ1hDLFlBQVk7QUFBQSxNQUNaQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLE1BQ2RDLGtCQUFrQjtBQUFBLE1BQ2xCQyxhQUFhO0FBQUEsTUFDYkMsZUFBZTtBQUFBLE1BQ2ZDLGlCQUFpQjtBQUFBLElBQ25CLENBQUM7QUFDRDlCLHdCQUFvQixNQUFNO0FBQzFCZ0IsY0FBVSxDQUFDLENBQUM7QUFDWmQsbUJBQWUsTUFBTTtBQUNyQkUsd0JBQW9CLE1BQU07QUFDMUJ3RCx1QkFBbUIsS0FBSztBQUFBLEVBQzFCO0FBRUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNFbkY7QUFBQUE7QUFBQUEsSUFDRCx1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDWjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1VLFlBQVlLO0FBQUFBLFVBQ2xCLFdBQVdMLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFBTUYsZUFBZSxDQUFDK0gsVUFBVSxFQUFFLEdBQUdBLE1BQU05SCxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFKMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSTRFO0FBQUEsTUFFMUUsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHVDQUNaO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG1DQUFrQyxzQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQVE7QUFBQSxZQUFJO0FBQUEsZUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxXQUFRLE9BQU0sMEJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNiVCx1Q0FBdUIsSUFBSTtBQUMzQnlMLG9DQUFvQjtBQUFBLGNBQ3RCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQUssV0FBVSxRQUFPLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSw0REFBMkQsK0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDNUosWUFDQyx1QkFBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsa0JBQWUsV0FBVyxNQUFNLE1BQUsseUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJELEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFDRUYsbUJBQW1CbUosU0FBUyxJQUM5QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTW5KO0FBQUFBLGNBQ04sU0FBU2dLO0FBQUFBLGNBQ1QsaUJBQWdCO0FBQUEsY0FDaEIsa0JBQWtCO0FBQUE7QUFBQSxZQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJOEMsSUFHOUMsdUJBQUMsU0FBSSxXQUFVLG1DQUFrQyw0Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUNBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVzVMO0FBQUFBLFVBQ1gsU0FBUyxNQUFNO0FBQ2JDLG1DQUF1QixLQUFLO0FBQzVCeUwsZ0NBQW9CO0FBQUEsVUFDdEI7QUFBQSxVQUNBLE9BQU07QUFBQSxVQUVOLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxzREFBcUQsa0RBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVWLHdCQUNwQztBQUFBLHFDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ2xELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPOUo7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDNEUsTUFBTTtBQUNmLDRCQUFNaUcsV0FBV2pHLEVBQUVwRCxPQUFPc0Q7QUFDMUI3RSxtQ0FBYTRLLFFBQVE7QUFDckJwSztBQUFBQSx3QkFDRW9LLGFBQWEsVUFBVWpMLFNBQVNFO0FBQUFBLHNCQUNsQztBQUNBb0Qsd0NBQWtCLENBQUNvRSxVQUFVO0FBQUEsd0JBQzNCLEdBQUdBO0FBQUFBLHdCQUNIbkUsVUFBVTtBQUFBLHdCQUNWRyxRQUFRO0FBQUEsc0JBQ1YsRUFBRTtBQUNGakQscUNBQWUsTUFBTTtBQUNyQkUsMENBQW9CLE1BQU07QUFDMUJnQixvQ0FBYztBQUFBLHdCQUNaQyxRQUFRO0FBQUEsd0JBQ1JDLFVBQVU7QUFBQSx3QkFDVkMsV0FBVztBQUFBLHdCQUNYQyxZQUFZO0FBQUEsd0JBQ1pDLFlBQVk7QUFBQSx3QkFDWkMsY0FBYztBQUFBLHdCQUNkQyxrQkFBa0I7QUFBQSx3QkFDbEJDLGFBQWE7QUFBQSx3QkFDYkMsZUFBZTtBQUFBLHdCQUNmQyxpQkFDRTRJLGFBQWEsYUFBYSxjQUFjO0FBQUEsc0JBQzVDLENBQUM7QUFDRGhILDZDQUF1QixFQUFFO0FBQ3pCMUQsMENBQW9CLE1BQU07QUFDMUJnQixnQ0FBVSxDQUFDLENBQUM7QUFBQSxvQkFDZDtBQUFBLG9CQUVBO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcsVUFBUSxNQUFDLGlDQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCO0FBQUEsc0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkF0Q25DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF1Q0E7QUFBQSxtQkEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0Q0E7QUFBQSxjQUVDbkIsYUFDQyx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUN0REEsY0FBYyxVQUFVLFVBQVU7QUFBQSxrQkFBWTtBQUFBLGtCQUN0RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsYUFBYSxVQUFVQSxTQUFTO0FBQUEsb0JBQ2hDO0FBQUEsb0JBQ0Esa0JBQWlCO0FBQUEsb0JBQ2pCLGNBQWMsQ0FBQzhLLE9BQU9DLFdBQ3BCekksT0FBT3lJLFFBQVFDLFFBQVEsR0FDbkJDLFlBQVksRUFDYjFCLFNBQVN1QixNQUFNRyxZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT2hJLGVBQWVFLFlBQVkrSDtBQUFBQSxvQkFDbEMsVUFBVSxDQUFDcEcsVUFBVTtBQUVuQjNELGdDQUFVLENBQUNtRyxVQUFVLEVBQUUsR0FBR0EsTUFBTW5FLFVBQVUsR0FBRyxFQUFFO0FBQy9DRCx3Q0FBa0IsQ0FBQ29FLFVBQVU7QUFBQSx3QkFDM0IsR0FBR0E7QUFBQUEsd0JBQ0huRSxVQUFVMkI7QUFBQUEsc0JBQ1osRUFBRTtBQUdGM0UsMENBQW9CLE1BQU07QUFDMUJvQixvQ0FBYztBQUFBLHdCQUNaQyxRQUFRO0FBQUEsd0JBQ1JDLFVBQVU7QUFBQSx3QkFDVkMsV0FBVztBQUFBLHdCQUNYQyxZQUFZO0FBQUEsd0JBQ1pDLFlBQVk7QUFBQSx3QkFDWkMsY0FBYztBQUFBLHdCQUNkQyxrQkFBa0I7QUFBQSx3QkFDbEJDLGFBQWE7QUFBQSx3QkFDYkMsZUFBZTtBQUFBLHdCQUNmQyxpQkFDRWpDLGNBQWMsYUFBYSxjQUFjO0FBQUEsc0JBQzdDLENBQUM7QUFDRDZELDZDQUF1QixFQUFFO0FBQUEsb0JBQzNCO0FBQUEsb0JBRUU3RCx5QkFBYyxVQUFVSixTQUFTRSxXQUFXK0g7QUFBQUEsc0JBQUksQ0FBQ3NELFdBQ2pELHVCQUFDLE9BQU8sUUFBUCxFQUErQixPQUFPQSxPQUFPbEQsS0FDM0NrRDtBQUFBQSwrQkFBT2hEO0FBQUFBLHdCQUFLO0FBQUEsd0JBQUlnRCxPQUFPQztBQUFBQSwyQkFETkQsT0FBT2xELEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBekNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkEwQ0E7QUFBQSxnQkFFQy9HLE9BQU9pQyxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmpDLGlCQUFPaUMsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBckRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdURBO0FBQUEsY0FJRix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUNwRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxNQUFNOUQsY0FBYyxPQUFPO0FBQUEsc0JBQ3BDLFdBQVcsd0JBQXdCRCxlQUFlLFVBQzlDLDZCQUNBLDJCQUEyQjtBQUFBLHNCQUMxQjtBQUFBO0FBQUEsb0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTUMsY0FBYyxRQUFRO0FBQUEsc0JBQ3JDLFdBQVcsd0JBQXdCRCxlQUFlLFdBQzlDLDZCQUNBLDJCQUEyQjtBQUFBLHNCQUMxQjtBQUFBO0FBQUEsb0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEscUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUJBO0FBQUEsbUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsY0FFQ0EsZUFBZSxVQUNkLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ3hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBTzZELGVBQWVJO0FBQUFBLG9CQUN0QixLQUFLakI7QUFBQUEsb0JBQ0wsVUFBVWtIO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNMEQ7QUFBQSxnQkFFekRwSSxPQUFPbUMsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qm5DLGlCQUFPbUMsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsbUJBYm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ3BELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT1IsZ0JBQWdCRTtBQUFBQSxzQkFDdkIsS0FBS0YsZ0JBQWdCRyxXQUFXWjtBQUFBQSxzQkFDaEMsVUFBVWtIO0FBQUFBLHNCQUNWLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNMEQ7QUFBQSxrQkFFekRwSSxPQUFPNkIsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCN0IsaUJBQU82QixhQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRDtBQUFBLHFCQWIvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLG9CQUN0RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLE9BQU9GLGdCQUFnQkc7QUFBQUEsc0JBQ3ZCLEtBQUtILGdCQUFnQkU7QUFBQUEsc0JBQ3JCLE1BQUssb0JBQUlaLEtBQUssR0FBRVEsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsc0JBQzFDLFVBQVUwRztBQUFBQSxzQkFDVixXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTzBEO0FBQUEsa0JBRXpEcEksT0FBTzhCLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjlCLGlCQUFPOEIsV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUQ7QUFBQSxxQkFkN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQkE7QUFBQSxtQkFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQ0E7QUFBQSxjQUdGLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNO0FBQ2Isd0JBQUk1RCxlQUFlLFNBQVM7QUFDMUJpSztBQUFBQSx3QkFDRXBHLGVBQWVFO0FBQUFBLHdCQUNmRixlQUFlSTtBQUFBQSx3QkFDZnJEO0FBQUFBLHdCQUNBO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRixPQUFPO0FBQ0xxSjtBQUFBQSx3QkFDRXBHLGVBQWVFO0FBQUFBLHdCQUNmLEVBQUUyQyxNQUFNakQsZ0JBQWdCRSxXQUFXZ0QsSUFBSWxELGdCQUFnQkcsUUFBUTtBQUFBLHdCQUMvRGhEO0FBQUFBLHdCQUNBO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRjtBQUFBLGtCQUNGO0FBQUEsa0JBQ0EsVUFDRSxDQUFDaUQsZUFBZUUsWUFDZi9ELGVBQWUsV0FBVyxDQUFDNkQsZUFBZUksaUJBQzFDakUsZUFBZSxhQUNiLENBQUN5RCxnQkFBZ0JFLGFBQWEsQ0FBQ0YsZ0JBQWdCRyxZQUNsRGxDO0FBQUFBLGtCQUVGLFdBQVU7QUFBQSxrQkFFVEEsMkNBQWlDLG1CQUFtQjtBQUFBO0FBQUEsZ0JBNUJ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E2QkEsS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErQkE7QUFBQSxjQUlDZ0QsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDRCQUNiLGlDQUFDLGtCQUFlLFdBQVcsTUFBTSxNQUFLLG9CQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRCxLQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FJRDlELGFBQWFzQixjQUFjLENBQUN3QyxtQkFDM0IsdUJBQUMsU0FBSSxXQUFVLFFBQ1p4QyxxQkFBV1MsY0FDVix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsMENBQXlDLDhCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUNULFdBQVdHLFlBQVlILFdBQVdFLFVBQ2pDLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0Msa0NBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHRix1QkFBQyxTQUFJLFdBQVUsd0NBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLHFCQUFvQiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU9GLFdBQVdVO0FBQUFBLHdCQUNsQjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHc0U7QUFBQSx1QkFQeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUscUJBQW9CLHdCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTyxJQUFJVixXQUFXRyxVQUFVMkY7QUFBQUEsMEJBQzlCO0FBQUEsd0JBQ0YsQ0FBQztBQUFBLHdCQUNEO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtzRTtBQUFBLHVCQVR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxxQkFBb0IsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPLElBQUk5RixXQUFXSyxZQUFZeUY7QUFBQUEsMEJBQ2hDO0FBQUEsd0JBQ0YsQ0FBQztBQUFBLHdCQUNEO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtzRTtBQUFBLHVCQVR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxxQkFBb0I7QUFBQTtBQUFBLHNCQUNyQjtBQUFBLHNCQUNiOUYsV0FBV1csb0JBQW9CLGNBQzVCLGNBQ0E7QUFBQSx5QkFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQSxPQUFPLElBQUlYLFdBQVdRLGlCQUFpQnNGO0FBQUFBLDBCQUNyQztBQUFBLDBCQUNBO0FBQUEsNEJBQ0VpRSx1QkFBdUI7QUFBQSw0QkFDdkJDLHVCQUF1QjtBQUFBLDBCQUN6QjtBQUFBLHdCQUNGLENBQUM7QUFBQSx3QkFDRCxXQUFVO0FBQUE7QUFBQSxzQkFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBU2lGO0FBQUEsdUJBaEJuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLHFCQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVEQTtBQUFBLG1CQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1FQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDYixpQ0FBQyxPQUFFLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxnQkFDakJ0TDtBQUFBQSxnQkFBVTtBQUFBLGdCQUFFO0FBQUEsZ0JBQ25Dc0IsV0FBV1csb0JBQW9CLGNBQzVCLGNBQ0E7QUFBQSxnQkFBYztBQUFBLGdCQUFJO0FBQUEsbUJBSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBLEtBL0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUZBO0FBQUEsY0FJRGpDLGFBQWFzQixXQUFXUyxlQUFlLENBQUMrQixtQkFDdkMsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDRDQUNYeEM7QUFBQUEsNkJBQVdXLG9CQUFvQixjQUM1QixjQUNBO0FBQUEsa0JBQWM7QUFBQSxrQkFBSTtBQUFBLHFCQUh4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsV0FBTSxXQUFVLDZCQUNmO0FBQUEseUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsK0JBQ1o7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsOEJBQTZCLG9CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQztBQUFBLG9CQUMvQyx1QkFBQyxRQUFHLFdBQVUsK0JBQThCLDBCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxXQUNFakM7QUFBQUEsa0NBQWMsV0FDYix1QkFBQyxRQUNDO0FBQUEsNkNBQUMsUUFBRyxXQUFVLG9CQUFtQixpQ0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSwrQkFBOEI7QUFBQTtBQUFBLHdCQUV6Q3NCLFdBQVdNLFlBQVl3RixlQUFlLFNBQVM7QUFBQSwwQkFDOUNpRSx1QkFBdUI7QUFBQSwwQkFDdkJDLHVCQUF1QjtBQUFBLHdCQUN6QixDQUFDO0FBQUEsMkJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFNQTtBQUFBLHlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBV0E7QUFBQSxvQkFFRix1QkFBQyxRQUNDO0FBQUEsNkNBQUMsUUFBRyxXQUFVLG9CQUNYdEwsd0JBQWMsVUFDWCxxQkFDQSx1Q0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUlBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsd0JBRXpDc0IsV0FBV08sY0FBY3VGLGVBQWUsU0FBUztBQUFBLDBCQUNoRGlFLHVCQUF1QjtBQUFBLDBCQUN2QkMsdUJBQXVCO0FBQUEsd0JBQ3pCLENBQUM7QUFBQSwyQkFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU1BO0FBQUEseUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFhQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSw4QkFDWjtBQUFBLDZDQUFDLFFBQUcsV0FBVSxvQkFBbUI7QUFBQTtBQUFBLHdCQUNqQjtBQUFBLHdCQUNiaEssV0FBV1csb0JBQW9CLGNBQzVCLGNBQ0E7QUFBQSwyQkFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDhDQUE2QztBQUFBO0FBQUEsd0JBRXhEWCxXQUFXUSxrQkFBa0JzRjtBQUFBQSwwQkFDNUI7QUFBQSwwQkFDQTtBQUFBLDRCQUNFaUUsdUJBQXVCO0FBQUEsNEJBQ3ZCQyx1QkFBdUI7QUFBQSwwQkFDekI7QUFBQSx3QkFDRjtBQUFBLDJCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBU0E7QUFBQSx5QkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSx1QkE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkErQ0E7QUFBQSxxQkF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5REE7QUFBQSxtQkFoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpRUE7QUFBQSxjQUdGLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3JJLGVBQWVHO0FBQUFBLG9CQUN0QixVQUFVa0c7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUNWLFVBQVUsQ0FBQ3RLO0FBQUFBO0FBQUFBLGtCQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNMkI7QUFBQSxnQkFFMUJrQyxPQUFPa0MsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZsQyxpQkFBT2tDLFlBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsaUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT2xEO0FBQUFBLG9CQUNQO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlvRjtBQUFBLG1CQVJ0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUM3Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLEtBQUs7QUFBQSxvQkFDTCxPQUFPK0MsZUFBZUs7QUFBQUEsb0JBQ3RCLFVBQVUsQ0FBQ3NCLE1BQU07QUFDZiw0QkFBTUUsUUFBUUYsRUFBRXBELE9BQU9zRDtBQUN2QjVCLHdDQUFrQixDQUFDb0UsVUFBVTtBQUFBLHdCQUMzQixHQUFHQTtBQUFBQSx3QkFDSGhFLFFBQVF3QjtBQUFBQSxzQkFDVixFQUFFO0FBQ0YzRCxnQ0FBVSxDQUFDbUcsVUFBVSxFQUFFLEdBQUdBLE1BQU1oRSxRQUFRLEdBQUcsRUFBRTtBQUFBLG9CQUMvQztBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUE7QUFBQSxrQkFkZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBY3FDO0FBQUEsZ0JBRXBDcEMsT0FBT29DLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnBDLGlCQUFPb0MsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxtQkFyQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsY0FFQ3RELGNBQWMsV0FBVzRELG9CQUFvQmlHLFNBQVMsS0FBSyxDQUFDakosYUFDM0QsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDRDQUEyQyxvREFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSw2Q0FDYixpQ0FBQyxXQUFNLFdBQVUsNkJBQ2Y7QUFBQSx5Q0FBQyxXQUNDLGlDQUFDLFFBQUcsV0FBVSwrQkFDWjtBQUFBLDJDQUFDLFFBQUcsV0FBVSw4QkFBNkIsd0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsOEJBQTZCLHFCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDhCQUE2QixxQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNDLHVCQUFDLFFBQUcsV0FBVSwrQkFBOEIsK0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUQ7QUFBQSxvQkFDQyx1QkFBQyxRQUFHLFdBQVUsK0JBQThCLHlDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVEO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUE4QixvQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLGtCQUNBLHVCQUFDLFdBQ0VnRCw4QkFBb0JpRTtBQUFBQSxvQkFBSSxDQUFDMEQsTUFBTXhELFVBQzlCLHVCQUFDLFFBQWUsV0FBVSxvQkFDeEI7QUFBQSw2Q0FBQyxRQUFHLFdBQVUsb0JBQ1h3RCxnQkFBTUMsU0FBU3hDLGFBQWEsT0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQkFDWHVDLGdCQUFNQyxTQUFTSixnQkFBZ0IsT0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQkFDWEcsZ0JBQU1FLFVBQVVDLGNBQWMsT0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNHLHVCQUFDLFFBQUcsV0FBVSxvQkFDZEgsZ0JBQU1FLFVBQVVFLGVBQWUsT0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFSDtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQkFDWEosZ0JBQU1FLFVBQVVHLGNBQWMsT0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSwrQkFDWEwsZUFBS00sb0JBQW9CLE9BRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkFuQk85RCxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBb0JBO0FBQUEsa0JBQ0QsS0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF3QkE7QUFBQSxxQkEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnREEsS0FqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrREE7QUFBQSxtQkF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1REE7QUFBQSxjQUVEL0gsY0FBYyxjQUFjNEQsb0JBQW9CaUcsU0FBUyxLQUFLLENBQUNqSixhQUM5RCx1QkFBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNENBQTJDLG1EQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDZDQUNiLGlDQUFDLFdBQU0sV0FBVSw2QkFDZjtBQUFBLHlDQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLCtCQUNaO0FBQUEsMkNBQUMsUUFBRyxXQUFVLDhCQUE2Qix3QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSw4QkFBNkIscUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsOEJBQTZCLHFCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUE4QiwrQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSwrQkFBOEIsd0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsK0JBQThCLG1DQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUJBLEtBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBcUJBO0FBQUEsa0JBQ0EsdUJBQUMsV0FDRWdELDhCQUFvQmlFO0FBQUFBLG9CQUFJLENBQUMwRCxNQUFNeEQsVUFDOUIsdUJBQUMsUUFBZSxXQUFVLG9CQUN4QjtBQUFBLDZDQUFDLFFBQUcsV0FBVSxvQkFDWHdELGdCQUFNQyxTQUFTeEMsYUFBYSxPQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9CQUNYdUMsZ0JBQU1DLFNBQVNKLGdCQUFnQixPQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9CQUNYRyxnQkFBTUUsVUFBVUMsY0FBYyxPQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUNYSCxnQkFBTUUsVUFBVUUsZUFBZSxPQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0MsdUJBQUMsUUFBRyxXQUFVLCtCQUNaSixnQkFBTUUsVUFBVUssY0FBYyxPQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVEO0FBQUEsc0JBQ0MsdUJBQUMsUUFBRyxXQUFVLCtCQUNaUCxnQkFBTVEsbUJBQW1CLE9BRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUQ7QUFBQSx5QkFsQk9oRSxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsa0JBQ0QsS0F0Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF1QkE7QUFBQSxxQkE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErQ0EsS0FoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpREE7QUFBQSxtQkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzREE7QUFBQSxjQUVGLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPOUUsZUFBZU07QUFBQUEsb0JBQ3RCLFVBQVUrRjtBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUI7QUFBQSxzQkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUEsc0JBQzVCdEssaUJBQ0MsbUNBQ0U7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkI7QUFBQSx3QkFDN0IsdUJBQUMsWUFBTyxPQUFNLGlCQUFnQiw2QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMkM7QUFBQSwyQkFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBO0FBQUE7QUFBQSxrQkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBY0E7QUFBQSxnQkFDQ2tDLE9BQU9xQyxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnJDLGlCQUFPcUMsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0JBO0FBQUEsY0FFQ04sZUFBZU0sYUFBYSxZQUMzQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9OLGVBQWVPO0FBQUFBLG9CQUN0QixVQUFVOEY7QUFBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNMEQ7QUFBQSxnQkFFekRwSSxPQUFPc0Msa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWdEMsaUJBQU9zQyxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUdGLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPUCxlQUFlUTtBQUFBQSxvQkFDdEIsVUFBVTZGO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBO0FBQUEsa0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1VO0FBQUEsZ0JBRVRwSSxPQUFPdUMsUUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCdkMsaUJBQU91QyxRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLG1CQWIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUFpQnpDLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLG1CQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNO0FBQ2JqQyw2Q0FBdUIsS0FBSztBQUM1QnlMLDBDQUFvQjtBQUFBLG9CQUN0QjtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFBNkU7QUFBQTtBQUFBLGtCQU56RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsVUFBVTVKLGFBQWFFO0FBQUFBLG9CQUN2QixXQUFVO0FBQUEsb0JBRVRGLHNCQUFZLGtCQUFrQjtBQUFBO0FBQUEsa0JBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLG1CQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtCQTtBQUFBLGlCQXZvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3b0JBO0FBQUEsZUE1b0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNm9CQTtBQUFBO0FBQUEsUUFycEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXNwQkE7QUFBQSxTQTdzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThzQkE7QUFBQSxPQWh0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWl0QkEsS0FsdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtdEJBO0FBRUo7QUFBRW5DLEdBOWhESUQsaUNBQStCO0FBQUEsVUFFTkYsYUFBYU8sZUFBZTtBQUFBO0FBQUFtTixLQUZyRHhOO0FBZ2lETixlQUFlQTtBQUFnQyxJQUFBd047QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIkFQSSIsIk1vZGFsIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsIlNlbGVjdCIsIlRvb2x0aXAiLCJub3RpZmljYXRpb24iLCJTZXR0aW5nU2lkZWJhciIsIlRhcmdldFBheU91dENvbW1pc3Npb25JbmNlbnRpdmUiLCJfcyIsInBheW1lbnRGb3IiLCJhcGkiLCJjb250ZXh0SG9sZGVyIiwidXNlTm90aWZpY2F0aW9uIiwic2hvd0NvbW1pc3Npb25Nb2RhbCIsInNldFNob3dDb21taXNzaW9uTW9kYWwiLCJtb2RpZnlQYXltZW50Iiwic2V0TW9kaWZ5UGF5bWVudCIsImFkbWluSWQiLCJzZXRBZG1pbklkIiwiZmlsdGVyTW9kZSIsInNldEZpbHRlck1vZGUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJub1JlbG9hZCIsInR5cGUiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJhZ2VudFR5cGUiLCJzZXRBZ2VudFR5cGUiLCJjYWxjdWxhdGVkQW1vdW50Iiwic2V0Q2FsY3VsYXRlZEFtb3VudCIsImFscmVhZHlQYWlkIiwic2V0QWxyZWFkeVBhaWQiLCJyZW1haW5pbmdQYXlhYmxlIiwic2V0UmVtYWluaW5nUGF5YWJsZSIsInNlbGVjdGVkVXNlckxpc3QiLCJzZXRTZWxlY3RlZFVzZXJMaXN0IiwiY29tbWlzc2lvblBheW1lbnRzIiwic2V0Q29tbWlzc2lvblBheW1lbnRzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiaXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uIiwic2V0SXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uIiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwicmVSZW5kZXIiLCJzZXRSZVJlbmRlciIsInRhcmdldERhdGEiLCJzZXRUYXJnZXREYXRhIiwidGFyZ2V0IiwiYWNoaWV2ZWQiLCJyZW1haW5pbmciLCJkaWZmZXJlbmNlIiwidXBUb1RhcmdldCIsImJleW9uZFRhcmdldCIsInRhcmdldENvbW1pc3Npb24iLCJpc1RhcmdldFNldCIsInRhcmdldERpc3BsYXkiLCJjYWxjdWxhdGlvblR5cGUiLCJ0b2RheSIsIkRhdGUiLCJjdXJyZW50TW9udGgiLCJnZXRGdWxsWWVhciIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJpbml0Rmlyc3REYXkiLCJpbml0TGFzdERheSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJjdXN0b21EYXRlUmFuZ2UiLCJzZXRDdXN0b21EYXRlUmFuZ2UiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwiY29tbWlzc2lvbkZvcm0iLCJzZXRDb21taXNzaW9uRm9ybSIsImFnZW50X2lkIiwicGF5X2RhdGUiLCJzZWxlY3RlZE1vbnRoIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsIm5vdGUiLCJwYXlfZm9yIiwiYWRtaW5fdHlwZSIsImNvbW1pc3Npb25CcmVha2Rvd24iLCJzZXRDb21taXNzaW9uQnJlYWtkb3duIiwiaXNUYXJnZXRMb2FkaW5nIiwic2V0SXNUYXJnZXRMb2FkaW5nIiwiZmV0Y2hBZ2VudHMiLCJyZXMiLCJnZXQiLCJhbGwiLCJkYXRhIiwiZmlsdGVyIiwiYSIsImFnZW50X3R5cGUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwic2V0U2VhcmNoVGV4dCIsInZhbHVlIiwic2V0Q3VycmVudFBhZ2UiLCJzZXRDdXJyZW50UGFnZVJlbGF0ZWQiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRlc3QiLCJkIiwiaXNOYU4iLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJnZXREYXRlIiwiZmV0Y2hUYXJnZXREZXRhaWxzIiwiYWdlbnRJZCIsInBlcmlvZCIsIm1vZGUiLCJmcm9tIiwidG8iLCJmaXJzdERheSIsImxhc3REYXkiLCJtb250aFN0ciIsInBhcnNlSW50IiwidGFyZ2V0UmVzIiwicGFyYW1zIiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwidGFyZ2V0Rm9yUGVyaW9kIiwic3RhdHVzIiwidG90YWxfdGFyZ2V0IiwiTnVtYmVyIiwiY29tbSIsImluY2VudGl2ZVN1bW1hcnkiLCJ0b3RhbF9ncm91cF92YWx1ZSIsImNvbW1pc3Npb25TdW1tYXJ5IiwicmVwbGFjZSIsInRvdGFsQ29tbWlzc2lvbiIsIk1hdGgiLCJtYXgiLCJ0b0xvY2FsZVN0cmluZyIsInRvRml4ZWQiLCJwcmV2IiwiYnJlYWtkb3duRGF0YSIsImluY2VudGl2ZURhdGEiLCJjb21taXNzaW9uRGF0YSIsImZldGNoQ29tbWlzc2lvblBheW1lbnRzIiwicmVzcG9uc2UiLCJyZXNwb25zZURhdGEiLCJtYXAiLCJwYXltZW50IiwiaW5kZXgiLCJpZCIsIl9pZCIsImFnZW50X25hbWUiLCJuYW1lIiwiY29tbWlzc2lvbl9mcm9tIiwiY29tbWlzc2lvbkNhbGN1bGF0aW9uRnJvbURhdGUiLCJjb21taXNzaW9uX3RvIiwiY29tbWlzc2lvbkNhbGN1bGF0aW9uVG9EYXRlIiwiZGlzYnVyc2VkX2J5IiwicmVjZWlwdF9ubyIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImZ1bGxfbmFtZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsImdldE1vbnRoUmFuZ2UiLCJjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uIiwiaGFuZGxlQ29tbWlzc2lvbkNoYW5nZSIsImluY2x1ZGVzIiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwicGFyc2VGbG9hdCIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJoYW5kbGVDb21taXNzaW9uU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicGF5bG9hZCIsInBvc3QiLCJvcGVuIiwiZGVzY3JpcHRpb24iLCJjbGFzc05hbWUiLCJzaG93UHJvZ3Jlc3MiLCJwYXVzZU9uSG92ZXIiLCJyZXNldENvbW1pc3Npb25Gb3JtIiwidmFsIiwiY29tbWlzc2lvbkNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJzZWxlY3RlZCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsInVuZGVmaW5lZCIsInBlcnNvbiIsInBob25lX251bWJlciIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsIml0ZW0iLCJ1c2VyX2lkIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiZ3JvdXBfdmFsdWUiLCJjb21taXNzaW9uIiwiY29tbWlzc2lvbl92YWx1ZSIsImluY2VudGl2ZXMiLCJpbmNlbnRpdmVfdmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYXJnZXRQYXlPdXRDb21taXNzaW9uSW5jZW50aXZlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5cclxuLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgVG9vbHRpcCwgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFNldHRpbmdTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2V0dGluZ1NpZGViYXJcIjtcclxuXHJcbmNvbnN0IFRhcmdldFBheU91dENvbW1pc3Npb25JbmNlbnRpdmUgPSAoKSA9PiB7XHJcbiAgY29uc3QgcGF5bWVudEZvciA9IFwiY29tbWlzc2lvblwiO1xyXG4gIGNvbnN0IFthcGksIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzaG93Q29tbWlzc2lvbk1vZGFsLCBzZXRTaG93Q29tbWlzc2lvbk1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kaWZ5UGF5bWVudCwgc2V0TW9kaWZ5UGF5bWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkbWluSWQsIHNldEFkbWluSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFtmaWx0ZXJNb2RlLCBzZXRGaWx0ZXJNb2RlXSA9IHVzZVN0YXRlKFwibW9udGhcIik7XHJcblxyXG5cclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIG5vUmVsb2FkOiBmYWxzZSxcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnRUeXBlLCBzZXRBZ2VudFR5cGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2NhbGN1bGF0ZWRBbW91bnQsIHNldENhbGN1bGF0ZWRBbW91bnRdID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG4gIGNvbnN0IFthbHJlYWR5UGFpZCwgc2V0QWxyZWFkeVBhaWRdID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG4gIGNvbnN0IFtyZW1haW5pbmdQYXlhYmxlLCBzZXRSZW1haW5pbmdQYXlhYmxlXSA9IHVzZVN0YXRlKFwiMC4wMFwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRVc2VyTGlzdCwgc2V0U2VsZWN0ZWRVc2VyTGlzdF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvbW1pc3Npb25QYXltZW50cywgc2V0Q29tbWlzc2lvblBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdDb21taXNzaW9uQ2FsY3VsYXRpb24sIHNldElzTG9hZGluZ0NvbW1pc3Npb25DYWxjdWxhdGlvbl0gPVxyXG4gICAgdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtyZVJlbmRlciwgc2V0UmVSZW5kZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3RhcmdldERhdGEsIHNldFRhcmdldERhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdGFyZ2V0OiAwLFxyXG4gICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICByZW1haW5pbmc6IDAsXHJcbiAgICBkaWZmZXJlbmNlOiAwLFxyXG4gICAgdXBUb1RhcmdldDogMCxcclxuICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgIHRhcmdldENvbW1pc3Npb246IDAsXHJcbiAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgIGNhbGN1bGF0aW9uVHlwZTogXCJjb21taXNzaW9uXCIsXHJcbiAgfSk7XHJcblxyXG5cclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgY3VycmVudE1vbnRoID0gYCR7dG9kYXkuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcoXHJcbiAgICB0b2RheS5nZXRNb250aCgpICsgMVxyXG4gICkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgY29uc3QgaW5pdEZpcnN0RGF5ID0gYCR7dG9kYXkuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcodG9kYXkuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKX0tMDFgO1xyXG4gIGNvbnN0IGluaXRMYXN0RGF5ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gIGNvbnN0IFtjdXN0b21EYXRlUmFuZ2UsIHNldEN1c3RvbURhdGVSYW5nZV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBmcm9tX2RhdGU6IGluaXRGaXJzdERheSxcclxuICAgIHRvX2RhdGU6IGluaXRMYXN0RGF5LFxyXG4gIH0pO1xyXG5cclxuXHJcbiAgY29uc3QgW2NvbW1pc3Npb25Gb3JtLCBzZXRDb21taXNzaW9uRm9ybV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBhZ2VudF9pZDogXCJcIixcclxuICAgIHBheV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgc2VsZWN0ZWRNb250aDogY3VycmVudE1vbnRoLFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gICAgcGF5X2ZvcjogcGF5bWVudEZvcixcclxuICAgIGFkbWluX3R5cGU6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG5cclxuXHJcbiAgY29uc3QgW2NvbW1pc3Npb25CcmVha2Rvd24sIHNldENvbW1pc3Npb25CcmVha2Rvd25dID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc1RhcmdldExvYWRpbmcsIHNldElzVGFyZ2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIik7XHJcbiAgICAgIGNvbnN0IGFsbCA9IHJlcy5kYXRhIHx8IFtdO1xyXG4gICAgICBzZXRBZ2VudHMoXHJcbiAgICAgICAgYWxsLmZpbHRlcigoYSkgPT4gYS5hZ2VudF90eXBlID09PSBcImFnZW50XCIgfHwgYS5hZ2VudF90eXBlID09PSBcImJvdGhcIilcclxuICAgICAgKTtcclxuICAgICAgc2V0RW1wbG95ZWVzKFxyXG4gICAgICAgIGFsbC5maWx0ZXIoXHJcbiAgICAgICAgICAoYSkgPT4gYS5hZ2VudF90eXBlID09PSBcImVtcGxveWVlXCIgfHwgYS5hZ2VudF90eXBlID09PSBcImJvdGhcIlxyXG4gICAgICAgIClcclxuICAgICAgKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiQWdlbnQgZmV0Y2ggZXJyb3JcIiwgZXJyKTtcclxuICAgIH1cclxuICB9O1xyXG4gY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgc2V0Q3VycmVudFBhZ2UoMSk7XHJcbiAgICBzZXRDdXJyZW50UGFnZVJlbGF0ZWQoMSk7XHJcbiAgfTtcclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IHtcclxuICAgIGlmICghZGF0ZSkgcmV0dXJuIFwiXCI7XHJcbiAgICBpZiAodHlwZW9mIGRhdGUgPT09IFwic3RyaW5nXCIgJiYgL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvLnRlc3QoZGF0ZSkpIHtcclxuICAgICAgcmV0dXJuIGRhdGU7XHJcbiAgICB9XHJcbiAgICBjb25zdCBkID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICBpZiAoaXNOYU4oZCkpIHJldHVybiBcIlwiO1xyXG4gICAgY29uc3QgeWVhciA9IGQuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGQuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIGNvbnN0IGRheSA9IFN0cmluZyhkLmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbiAgfTtcclxuXHJcbiAgLy8gY29uc3QgZmV0Y2hUYXJnZXREZXRhaWxzID0gYXN5bmMgKGFnZW50SWQsIG1vbnRoLCB0eXBlKSA9PiB7XHJcbiAgLy8gICBpZiAoIWFnZW50SWQgfHwgIW1vbnRoKSB7XHJcbiAgLy8gICAgIHNldFRhcmdldERhdGEoe1xyXG4gIC8vICAgICAgIHRhcmdldDogMCxcclxuICAvLyAgICAgICBhY2hpZXZlZDogMCxcclxuICAvLyAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgLy8gICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAvLyAgICAgICB1cFRvVGFyZ2V0OiAwLFxyXG4gIC8vICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAvLyAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gIC8vICAgICAgIGlzVGFyZ2V0U2V0OiBmYWxzZSxcclxuICAvLyAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAvLyAgICAgICBjYWxjdWxhdGlvblR5cGU6IHR5cGUgPT09IFwiZW1wbG95ZWVcIiA/IFwiaW5jZW50aXZlXCIgOiBcImNvbW1pc3Npb25cIixcclxuICAvLyAgICAgfSk7XHJcbiAgLy8gICAgIHJldHVybjtcclxuICAvLyAgIH1cclxuXHJcbiAgLy8gICBzZXRJc1RhcmdldExvYWRpbmcodHJ1ZSk7XHJcbiAgLy8gICB0cnkge1xyXG4gIC8vICAgICAvLyBDYWxjdWxhdGUgZmlyc3QgYW5kIGxhc3QgZGF5IG9mIHNlbGVjdGVkIG1vbnRoXHJcbiAgLy8gICAgIGNvbnN0IFt5ZWFyLCBtb250aFN0cl0gPSBtb250aC5zcGxpdChcIi1cIik7XHJcbiAgLy8gICAgIGNvbnN0IGZpcnN0RGF5ID0gYCR7eWVhcn0tJHttb250aFN0cn0tMDFgO1xyXG4gIC8vICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGhTdHIpLCAwKVxyXG4gIC8vICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgLy8gICAgICAgLnNwbGl0KFwiVFwiKVswXTtcclxuXHJcbiAgLy8gICAgIC8vIEZldGNoIHRhcmdldCBkZXRhaWxzIGZvciB0aGUgc2VsZWN0ZWQgYWdlbnRcclxuICAvLyAgICAgY29uc3QgdGFyZ2V0UmVzID0gYXdhaXQgQVBJLmdldChgL3RhcmdldC9hZ2VudC8ke2FnZW50SWR9YCwge1xyXG4gIC8vICAgICAgIHBhcmFtczogeyB5ZWFyIH0sXHJcbiAgLy8gICAgIH0pO1xyXG5cclxuICAvLyAgICAgLy8gTWFwIG1vbnRoIG51bWJlciB0byBtb250aCBuYW1lXHJcbiAgLy8gICAgIGNvbnN0IG1vbnRoTmFtZXMgPSBbXHJcbiAgLy8gICAgICAgXCJKYW51YXJ5XCIsXHJcbiAgLy8gICAgICAgXCJGZWJydWFyeVwiLFxyXG4gIC8vICAgICAgIFwiTWFyY2hcIixcclxuICAvLyAgICAgICBcIkFwcmlsXCIsXHJcbiAgLy8gICAgICAgXCJNYXlcIixcclxuICAvLyAgICAgICBcIkp1bmVcIixcclxuICAvLyAgICAgICBcIkp1bHlcIixcclxuICAvLyAgICAgICBcIkF1Z3VzdFwiLFxyXG4gIC8vICAgICAgIFwiU2VwdGVtYmVyXCIsXHJcbiAgLy8gICAgICAgXCJPY3RvYmVyXCIsXHJcbiAgLy8gICAgICAgXCJOb3ZlbWJlclwiLFxyXG4gIC8vICAgICAgIFwiRGVjZW1iZXJcIixcclxuICAvLyAgICAgXTtcclxuICAvLyAgICAgY29uc3QgbW9udGhOdW1iZXIgPSBwYXJzZUludChtb250aFN0ciwgMTApO1xyXG4gIC8vICAgICBjb25zdCBtb250aE5hbWUgPSBtb250aE5hbWVzW21vbnRoTnVtYmVyIC0gMV07XHJcblxyXG4gIC8vICAgICBsZXQgdGFyZ2V0Rm9yTW9udGggPSAwO1xyXG4gIC8vICAgICBpZiAodGFyZ2V0UmVzLmRhdGEgJiYgdGFyZ2V0UmVzLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gIC8vICAgICAgIGNvbnN0IG1vbnRoRGF0YSA9IHRhcmdldFJlcy5kYXRhWzBdLm1vbnRoRGF0YSB8fCB7fTtcclxuICAvLyAgICAgICB0YXJnZXRGb3JNb250aCA9IE51bWJlcihtb250aERhdGFbbW9udGhOYW1lXSB8fCAwKTtcclxuICAvLyAgICAgfVxyXG5cclxuICAvLyAgICAgLy8gRmV0Y2ggY29tbWlzc2lvbiBkYXRhIHRvIGdldCBhY2hpZXZlZCAtIENPUlJFQ1RFRDogUmVtb3ZlZCBleHRyYSAvYXBpIHByZWZpeFxyXG4gIC8vICAgICBjb25zdCBjb21tID0gYXdhaXQgQVBJLmdldChcIi9lbnJvbGwvZ2V0LWRldGFpbGVkLWNvbW1pc3Npb24tcGVyLW1vbnRoXCIsIHtcclxuICAvLyAgICAgICBwYXJhbXM6IHtcclxuICAvLyAgICAgICAgIGFnZW50X2lkOiBhZ2VudElkLFxyXG4gIC8vICAgICAgICAgZnJvbV9kYXRlOiBmb3JtYXREYXRlKGZpcnN0RGF5KSxcclxuICAvLyAgICAgICAgIHRvX2RhdGU6IGZvcm1hdERhdGUobGFzdERheSksXHJcbiAgLy8gICAgICAgfSxcclxuICAvLyAgICAgfSk7XHJcblxyXG4gIC8vICAgICBsZXQgYWNoaWV2ZWQgPSBjb21tPy5kYXRhPy5zdW1tYXJ5Py5hY3R1YWxfYnVzaW5lc3MgfHwgMDtcclxuICAvLyAgICAgaWYgKHR5cGVvZiBhY2hpZXZlZCA9PT0gXCJzdHJpbmdcIikge1xyXG4gIC8vICAgICAgIGFjaGlldmVkID0gTnVtYmVyKGFjaGlldmVkLnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKSk7XHJcbiAgLy8gICAgIH1cclxuXHJcbiAgLy8gICAgIGNvbnN0IHJlbWFpbmluZyA9IE1hdGgubWF4KHRhcmdldEZvck1vbnRoIC0gYWNoaWV2ZWQsIDApO1xyXG4gIC8vICAgICBjb25zdCBkaWZmZXJlbmNlID0gdGFyZ2V0Rm9yTW9udGggLSBhY2hpZXZlZDtcclxuXHJcbiAgLy8gICAgIC8vIENhbGN1bGF0ZSBjb21taXNzaW9uL2luY2VudGl2ZSBiYXNlZCBvbiBhZ2VudCB0eXBlXHJcbiAgLy8gICAgIGxldCB1cFRvVGFyZ2V0ID0gMDtcclxuICAvLyAgICAgbGV0IGJleW9uZFRhcmdldCA9IDA7XHJcbiAgLy8gICAgIGxldCB0b3RhbENvbW1pc3Npb24gPSAwO1xyXG5cclxuICAvLyAgICAgaWYgKHR5cGUgPT09IFwiYWdlbnRcIikge1xyXG4gIC8vICAgICAgIC8vIEZvciBhZ2VudHM6IDAuNSUgdXAgdG8gdGFyZ2V0LCAxJSBiZXlvbmQgdGFyZ2V0XHJcbiAgLy8gICAgICAgaWYgKGFjaGlldmVkIDw9IHRhcmdldEZvck1vbnRoKSB7XHJcbiAgLy8gICAgICAgICB1cFRvVGFyZ2V0ID0gYWNoaWV2ZWQgKiAwLjAwNTsgLy8gMC41JVxyXG4gIC8vICAgICAgIH0gZWxzZSB7XHJcbiAgLy8gICAgICAgICB1cFRvVGFyZ2V0ID0gdGFyZ2V0Rm9yTW9udGggKiAwLjAwNTtcclxuICAvLyAgICAgICAgIGJleW9uZFRhcmdldCA9IChhY2hpZXZlZCAtIHRhcmdldEZvck1vbnRoKSAqIDAuMDE7IC8vIDElXHJcbiAgLy8gICAgICAgfVxyXG4gIC8vICAgICAgIHRvdGFsQ29tbWlzc2lvbiA9IHVwVG9UYXJnZXQgKyBiZXlvbmRUYXJnZXQ7XHJcbiAgLy8gICAgIH0gZWxzZSB7XHJcbiAgLy8gICAgICAgLy8gRm9yIGVtcGxveWVlczogMSUgb25seSBvbiBhbW91bnQgYmV5b25kIHRhcmdldFxyXG4gIC8vICAgICAgIGlmIChhY2hpZXZlZCA+IHRhcmdldEZvck1vbnRoKSB7XHJcbiAgLy8gICAgICAgICBiZXlvbmRUYXJnZXQgPSAoYWNoaWV2ZWQgLSB0YXJnZXRGb3JNb250aCkgKiAwLjAxOyAvLyAxJVxyXG4gIC8vICAgICAgIH1cclxuICAvLyAgICAgICB0b3RhbENvbW1pc3Npb24gPSBiZXlvbmRUYXJnZXQ7XHJcbiAgLy8gICAgIH1cclxuXHJcbiAgLy8gICAgIC8vIEZvcm1hdCB0YXJnZXQgdmFsdWUgZm9yIGRpc3BsYXlcclxuICAvLyAgICAgY29uc3QgdGFyZ2V0RGlzcGxheSA9XHJcbiAgLy8gICAgICAgdGFyZ2V0Rm9yTW9udGggPiAwXHJcbiAgLy8gICAgICAgICA/IGDigrkke3RhcmdldEZvck1vbnRoLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YFxyXG4gIC8vICAgICAgICAgOiBcIk5vdCBTZXRcIjtcclxuXHJcbiAgLy8gICAgIHNldFRhcmdldERhdGEoe1xyXG4gIC8vICAgICAgIHRhcmdldDogdGFyZ2V0Rm9yTW9udGgsXHJcbiAgLy8gICAgICAgYWNoaWV2ZWQsXHJcbiAgLy8gICAgICAgcmVtYWluaW5nLFxyXG4gIC8vICAgICAgIGRpZmZlcmVuY2UsXHJcbiAgLy8gICAgICAgdXBUb1RhcmdldCxcclxuICAvLyAgICAgICBiZXlvbmRUYXJnZXQsXHJcbiAgLy8gICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogdG90YWxDb21taXNzaW9uLFxyXG4gIC8vICAgICAgIGlzVGFyZ2V0U2V0OiB0YXJnZXRGb3JNb250aCA+PSAwLFxyXG4gIC8vICAgICAgIHRhcmdldERpc3BsYXk6IHRhcmdldERpc3BsYXksXHJcbiAgLy8gICAgICAgY2FsY3VsYXRpb25UeXBlOiB0eXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgLy8gICAgIH0pO1xyXG5cclxuICAvLyAgICAgaWYgKHR5cGUgPT09IFwiYWdlbnRcIikge1xyXG4gIC8vICAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQodG90YWxDb21taXNzaW9uLnRvRml4ZWQoMikpO1xyXG4gIC8vICAgICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoe1xyXG4gIC8vICAgICAgICAgLi4ucHJldixcclxuICAvLyAgICAgICAgIGFtb3VudDogdG90YWxDb21taXNzaW9uLnRvRml4ZWQoMiksXHJcbiAgLy8gICAgICAgfSkpO1xyXG4gIC8vICAgICB9IGVsc2Uge1xyXG4gIC8vICAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQodG90YWxDb21taXNzaW9uLnRvRml4ZWQoMikpO1xyXG4gIC8vICAgICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoe1xyXG4gIC8vICAgICAgICAgLi4ucHJldixcclxuICAvLyAgICAgICAgIGFtb3VudDogdG90YWxDb21taXNzaW9uLnRvRml4ZWQoMiksXHJcbiAgLy8gICAgICAgfSkpO1xyXG4gIC8vICAgICB9XHJcblxyXG4gIC8vICAgICAvLyBTdG9yZSBjb21taXNzaW9uIGJyZWFrZG93biBmb3IgZGlzcGxheVxyXG4gIC8vICAgICBzZXRDb21taXNzaW9uQnJlYWtkb3duKGNvbW0/LmRhdGE/LmNvbW1pc3Npb25fZGF0YSB8fCBbXSk7XHJcbiAgLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhcmdldCBkZXRhaWxzXCIsIGVycm9yKTtcclxuICAvLyAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgLy8gICAgICAgdGFyZ2V0OiAwLFxyXG4gIC8vICAgICAgIGFjaGlldmVkOiAwLFxyXG4gIC8vICAgICAgIHJlbWFpbmluZzogMCxcclxuICAvLyAgICAgICBkaWZmZXJlbmNlOiAwLFxyXG4gIC8vICAgICAgIHVwVG9UYXJnZXQ6IDAsXHJcbiAgLy8gICAgICAgYmV5b25kVGFyZ2V0OiAwLFxyXG4gIC8vICAgICAgIHRhcmdldENvbW1pc3Npb246IDAsXHJcbiAgLy8gICAgICAgaXNUYXJnZXRTZXQ6IGZhbHNlLFxyXG4gIC8vICAgICAgIHRhcmdldERpc3BsYXk6IFwiTm90IFNldFwiLFxyXG4gIC8vICAgICAgIGNhbGN1bGF0aW9uVHlwZTogYWdlbnRUeXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgLy8gICAgIH0pO1xyXG4gIC8vICAgICBzZXRDb21taXNzaW9uQnJlYWtkb3duKFtdKTtcclxuICAvLyAgIH0gZmluYWxseSB7XHJcbiAgLy8gICAgIHNldElzVGFyZ2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgLy8gICB9XHJcbiAgLy8gfTtcclxuXHJcbiAgLy8gY29uc3QgZmV0Y2hUYXJnZXREZXRhaWxzID0gYXN5bmMgKGFnZW50SWQsIG1vbnRoLCB0eXBlKSA9PiB7XHJcbiAgLy8gICBpZiAoIWFnZW50SWQgfHwgIW1vbnRoKSB7XHJcbiAgLy8gICAgIHNldFRhcmdldERhdGEoe1xyXG4gIC8vICAgICAgIHRhcmdldDogMCxcclxuICAvLyAgICAgICBhY2hpZXZlZDogMCxcclxuICAvLyAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgLy8gICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAvLyAgICAgICB1cFRvVGFyZ2V0OiAwLFxyXG4gIC8vICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAvLyAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gIC8vICAgICAgIGlzVGFyZ2V0U2V0OiBmYWxzZSxcclxuICAvLyAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAvLyAgICAgICBjYWxjdWxhdGlvblR5cGU6IHR5cGUgPT09IFwiZW1wbG95ZWVcIiA/IFwiaW5jZW50aXZlXCIgOiBcImNvbW1pc3Npb25cIixcclxuICAvLyAgICAgfSk7XHJcbiAgLy8gICAgIHJldHVybjtcclxuICAvLyAgIH1cclxuXHJcbiAgLy8gICBzZXRJc1RhcmdldExvYWRpbmcodHJ1ZSk7XHJcbiAgLy8gICB0cnkge1xyXG4gIC8vICAgICAvLyBDYWxjdWxhdGUgZmlyc3QgYW5kIGxhc3QgZGF5IG9mIHNlbGVjdGVkIG1vbnRoXHJcbiAgLy8gICAgIGNvbnN0IFt5ZWFyLCBtb250aFN0cl0gPSBtb250aC5zcGxpdChcIi1cIik7XHJcbiAgLy8gICAgIGNvbnN0IGZpcnN0RGF5ID0gYCR7eWVhcn0tJHttb250aFN0cn0tMDFgO1xyXG4gIC8vICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGhTdHIpLCAwKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuXHJcbiAgLy8gICAgIC8vID09PSBTVEVQIDE6IEZldGNoIFRBUkdFVCAobW9udGhseSBzdHJ1Y3R1cmUpID09PVxyXG4gIC8vICAgICBjb25zdCB0YXJnZXRSZXMgPSBhd2FpdCBBUEkuZ2V0KGAvdGFyZ2V0L2FnZW50LyR7YWdlbnRJZH1gLCB7XHJcbiAgLy8gICAgICAgcGFyYW1zOiB7IHllYXIgfSxcclxuICAvLyAgICAgfSk7XHJcblxyXG4gIC8vICAgICBjb25zdCBtb250aE5hbWVzID0gW1xyXG4gIC8vICAgICAgIFwiSmFudWFyeVwiLCBcIkZlYnJ1YXJ5XCIsIFwiTWFyY2hcIiwgXCJBcHJpbFwiLCBcIk1heVwiLCBcIkp1bmVcIixcclxuICAvLyAgICAgICBcIkp1bHlcIiwgXCJBdWd1c3RcIiwgXCJTZXB0ZW1iZXJcIiwgXCJPY3RvYmVyXCIsIFwiTm92ZW1iZXJcIiwgXCJEZWNlbWJlclwiXHJcbiAgLy8gICAgIF07XHJcbiAgLy8gICAgIGNvbnN0IG1vbnRoTmFtZSA9IG1vbnRoTmFtZXNbcGFyc2VJbnQobW9udGhTdHIsIDEwKSAtIDFdO1xyXG4gIC8vICAgICBsZXQgdGFyZ2V0Rm9yTW9udGggPSAwO1xyXG4gIC8vICAgICBpZiAodGFyZ2V0UmVzLmRhdGEgJiYgdGFyZ2V0UmVzLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gIC8vICAgICAgIGNvbnN0IG1vbnRoRGF0YSA9IHRhcmdldFJlcy5kYXRhWzBdLm1vbnRoRGF0YSB8fCB7fTtcclxuICAvLyAgICAgICB0YXJnZXRGb3JNb250aCA9IE51bWJlcihtb250aERhdGFbbW9udGhOYW1lXSB8fCAwKTtcclxuICAvLyAgICAgfVxyXG5cclxuICAvLyAgICAgLy8gPT09IFNURVAgMjogRmV0Y2ggQUNISUVWRUQgQlVTSU5FU1MgJiBCUkVBS0RPV04gdXNpbmcgY29ycmVjdCByb3V0ZXMgPT09XHJcbiAgLy8gICAgIGxldCBjb21tO1xyXG4gIC8vICAgICBpZiAodHlwZSA9PT0gXCJlbXBsb3llZVwiKSB7XHJcbiAgLy8gICAgICAgY29tbSA9IGF3YWl0IEFQSS5nZXQoYC9lbnJvbGwvZW1wbG95ZWUvJHthZ2VudElkfS9pbmNlbnRpdmVgLCB7XHJcbiAgLy8gICAgICAgICBwYXJhbXM6IHsgc3RhcnRfZGF0ZTogZmlyc3REYXksIGVuZF9kYXRlOiBsYXN0RGF5IH0sXHJcbiAgLy8gICAgICAgfSk7XHJcbiAgLy8gICAgIH0gZWxzZSB7XHJcbiAgLy8gICAgICAgY29tbSA9IGF3YWl0IEFQSS5nZXQoYC9lbnJvbGwvYWdlbnQvJHthZ2VudElkfS9jb21taXNzaW9uYCwge1xyXG4gIC8vICAgICAgICAgcGFyYW1zOiB7IHN0YXJ0X2RhdGU6IGZpcnN0RGF5LCBlbmRfZGF0ZTogbGFzdERheSB9LFxyXG4gIC8vICAgICAgIH0pO1xyXG4gIC8vICAgICB9XHJcblxyXG4gIC8vICAgICAvLyBFeHRyYWN0IGFjaGlldmVkIGFtb3VudFxyXG4gIC8vICAgICBsZXQgYWNoaWV2ZWQgPSAwO1xyXG4gIC8vICAgICBpZiAodHlwZSA9PT0gXCJlbXBsb3llZVwiKSB7XHJcbiAgLy8gICAgICAgYWNoaWV2ZWQgPSBjb21tPy5kYXRhPy5pbmNlbnRpdmVTdW1tYXJ5Py50b3RhbF9ncm91cF92YWx1ZSB8fCAwO1xyXG4gIC8vICAgICB9IGVsc2Uge1xyXG4gIC8vICAgICAgIGFjaGlldmVkID0gY29tbT8uZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlIHx8IDA7XHJcbiAgLy8gICAgIH1cclxuICAvLyAgICAgaWYgKHR5cGVvZiBhY2hpZXZlZCA9PT0gXCJzdHJpbmdcIikge1xyXG4gIC8vICAgICAgIGFjaGlldmVkID0gTnVtYmVyKGFjaGlldmVkLnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKSk7XHJcbiAgLy8gICAgIH1cclxuXHJcbiAgLy8gICAgIC8vIENhbGN1bGF0ZSBjb21taXNzaW9uL2luY2VudGl2ZVxyXG4gIC8vICAgICBjb25zdCByZW1haW5pbmcgPSBNYXRoLm1heCh0YXJnZXRGb3JNb250aCAtIGFjaGlldmVkLCAwKTtcclxuICAvLyAgICAgY29uc3QgZGlmZmVyZW5jZSA9IGFjaGlldmVkIC0gdGFyZ2V0Rm9yTW9udGg7XHJcblxyXG4gIC8vICAgICBsZXQgdXBUb1RhcmdldCA9IDA7XHJcbiAgLy8gICAgIGxldCBiZXlvbmRUYXJnZXQgPSAwO1xyXG4gIC8vICAgICBsZXQgdG90YWxDb21taXNzaW9uID0gMDtcclxuXHJcbiAgLy8gICAgIGlmICh0eXBlID09PSBcImFnZW50XCIpIHtcclxuICAvLyAgICAgICBpZiAoYWNoaWV2ZWQgPD0gdGFyZ2V0Rm9yTW9udGgpIHtcclxuICAvLyAgICAgICAgIHVwVG9UYXJnZXQgPSBhY2hpZXZlZCAqIDAuMDA1OyAvLyAwLjUlXHJcbiAgLy8gICAgICAgfSBlbHNlIHtcclxuICAvLyAgICAgICAgIHVwVG9UYXJnZXQgPSB0YXJnZXRGb3JNb250aCAqIDAuMDA1O1xyXG4gIC8vICAgICAgICAgYmV5b25kVGFyZ2V0ID0gKGFjaGlldmVkIC0gdGFyZ2V0Rm9yTW9udGgpICogMC4wMTsgLy8gMSVcclxuICAvLyAgICAgICB9XHJcbiAgLy8gICAgICAgdG90YWxDb21taXNzaW9uID0gdXBUb1RhcmdldCArIGJleW9uZFRhcmdldDtcclxuICAvLyAgICAgfSBlbHNlIHtcclxuICAvLyAgICAgICBpZiAoYWNoaWV2ZWQgPiB0YXJnZXRGb3JNb250aCkge1xyXG4gIC8vICAgICAgICAgYmV5b25kVGFyZ2V0ID0gKGFjaGlldmVkIC0gdGFyZ2V0Rm9yTW9udGgpICogMC4wMTsgLy8gMSVcclxuICAvLyAgICAgICB9XHJcbiAgLy8gICAgICAgdG90YWxDb21taXNzaW9uID0gYmV5b25kVGFyZ2V0O1xyXG4gIC8vICAgICB9XHJcblxyXG4gIC8vICAgICAvLyBGb3JtYXQgdGFyZ2V0IHZhbHVlIGZvciBkaXNwbGF5XHJcbiAgLy8gICAgIGNvbnN0IHRhcmdldERpc3BsYXkgPVxyXG4gIC8vICAgICAgIHRhcmdldEZvck1vbnRoID4gMFxyXG4gIC8vICAgICAgICAgPyBg4oK5JHt0YXJnZXRGb3JNb250aC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWBcclxuICAvLyAgICAgICAgIDogXCJOb3QgU2V0XCI7XHJcblxyXG4gIC8vICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAvLyAgICAgICB0YXJnZXQ6IHRhcmdldEZvck1vbnRoLFxyXG4gIC8vICAgICAgIGFjaGlldmVkLFxyXG4gIC8vICAgICAgIHJlbWFpbmluZyxcclxuICAvLyAgICAgICBkaWZmZXJlbmNlLFxyXG4gIC8vICAgICAgIHVwVG9UYXJnZXQsXHJcbiAgLy8gICAgICAgYmV5b25kVGFyZ2V0LFxyXG4gIC8vICAgICAgIHRhcmdldENvbW1pc3Npb246IHRvdGFsQ29tbWlzc2lvbixcclxuICAvLyAgICAgICBpc1RhcmdldFNldDogdGFyZ2V0Rm9yTW9udGggPiAwLFxyXG4gIC8vICAgICAgIHRhcmdldERpc3BsYXksXHJcbiAgLy8gICAgICAgY2FsY3VsYXRpb25UeXBlOiB0eXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgLy8gICAgIH0pO1xyXG5cclxuICAvLyAgICAgc2V0Q2FsY3VsYXRlZEFtb3VudCh0b3RhbENvbW1pc3Npb24udG9GaXhlZCgyKSk7XHJcbiAgLy8gICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoe1xyXG4gIC8vICAgICAgIC4uLnByZXYsXHJcbiAgLy8gICAgICAgYW1vdW50OiB0b3RhbENvbW1pc3Npb24udG9GaXhlZCgyKSxcclxuICAvLyAgICAgfSkpO1xyXG5cclxuICAvLyAgICAgLy8gPT09IFNURVAgMzogU2V0IEJSRUFLRE9XTiBEQVRBID09PVxyXG4gIC8vICAgICBjb25zdCBicmVha2Rvd25EYXRhID0gdHlwZSA9PT0gXCJlbXBsb3llZVwiXHJcbiAgLy8gICAgICAgPyBjb21tPy5kYXRhPy5pbmNlbnRpdmVEYXRhIHx8IFtdXHJcbiAgLy8gICAgICAgOiBjb21tPy5kYXRhPy5jb21taXNzaW9uRGF0YSB8fCBbXTtcclxuXHJcbiAgLy8gICAgIHNldENvbW1pc3Npb25CcmVha2Rvd24oYnJlYWtkb3duRGF0YSk7XHJcblxyXG4gIC8vICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YXJnZXQgZGV0YWlsc1wiLCBlcnJvcik7XHJcbiAgLy8gICAgIHNldFRhcmdldERhdGEoe1xyXG4gIC8vICAgICAgIHRhcmdldDogMCxcclxuICAvLyAgICAgICBhY2hpZXZlZDogMCxcclxuICAvLyAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgLy8gICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAvLyAgICAgICB1cFRvVGFyZ2V0OiAwLFxyXG4gIC8vICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAvLyAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gIC8vICAgICAgIGlzVGFyZ2V0U2V0OiBmYWxzZSxcclxuICAvLyAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAvLyAgICAgICBjYWxjdWxhdGlvblR5cGU6IHR5cGUgPT09IFwiZW1wbG95ZWVcIiA/IFwiaW5jZW50aXZlXCIgOiBcImNvbW1pc3Npb25cIixcclxuICAvLyAgICAgfSk7XHJcbiAgLy8gICAgIHNldENvbW1pc3Npb25CcmVha2Rvd24oW10pO1xyXG4gIC8vICAgfSBmaW5hbGx5IHtcclxuICAvLyAgICAgc2V0SXNUYXJnZXRMb2FkaW5nKGZhbHNlKTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG5cclxuICBjb25zdCBmZXRjaFRhcmdldERldGFpbHMgPSBhc3luYyAoYWdlbnRJZCwgcGVyaW9kLCB0eXBlLCBtb2RlID0gXCJtb250aFwiKSA9PiB7XHJcbiAgICBpZiAoIWFnZW50SWQgfHwgKG1vZGUgPT09IFwiY3VzdG9tXCIgJiYgKCFwZXJpb2QuZnJvbSB8fCAhcGVyaW9kLnRvKSkpIHtcclxuICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICAgIGFjaGlldmVkOiAwLFxyXG4gICAgICAgIHJlbWFpbmluZzogMCxcclxuICAgICAgICBkaWZmZXJlbmNlOiAwLFxyXG4gICAgICAgIHVwVG9UYXJnZXQ6IDAsXHJcbiAgICAgICAgYmV5b25kVGFyZ2V0OiAwLFxyXG4gICAgICAgIHRhcmdldENvbW1pc3Npb246IDAsXHJcbiAgICAgICAgaXNUYXJnZXRTZXQ6IGZhbHNlLFxyXG4gICAgICAgIHRhcmdldERpc3BsYXk6IFwiTm90IFNldFwiLFxyXG4gICAgICAgIGNhbGN1bGF0aW9uVHlwZTogdHlwZSA9PT0gXCJlbXBsb3llZVwiID8gXCJpbmNlbnRpdmVcIiA6IFwiY29tbWlzc2lvblwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0Q29tbWlzc2lvbkJyZWFrZG93bihbXSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJc1RhcmdldExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgZmlyc3REYXksIGxhc3REYXk7XHJcbiAgICAgIGlmIChtb2RlID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgICBjb25zdCBbeWVhciwgbW9udGhTdHJdID0gcGVyaW9kLnNwbGl0KFwiLVwiKTtcclxuICAgICAgICBmaXJzdERheSA9IGAke3llYXJ9LSR7bW9udGhTdHJ9LTAxYDtcclxuICAgICAgICBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGhTdHIpLCAwKVxyXG4gICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgIC5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZmlyc3REYXkgPSBmb3JtYXREYXRlKHBlcmlvZC5mcm9tKTtcclxuICAgICAgICBsYXN0RGF5ID0gZm9ybWF0RGF0ZShwZXJpb2QudG8pO1xyXG4gICAgICB9XHJcblxyXG5cclxuICAgICAgbGV0IHRhcmdldFJlcztcclxuICAgICAgaWYgKHR5cGUgPT09IFwiZW1wbG95ZWVcIikge1xyXG4gICAgICAgIHRhcmdldFJlcyA9IGF3YWl0IEFQSS5nZXQoYC90YXJnZXQvZW1wbG95ZWVzLyR7YWdlbnRJZH1gLCB7XHJcbiAgICAgICAgICBwYXJhbXM6IHsgc3RhcnRfZGF0ZTogZmlyc3REYXksIGVuZF9kYXRlOiBsYXN0RGF5IH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGFyZ2V0UmVzID0gYXdhaXQgQVBJLmdldChgL3RhcmdldC9hZ2VudHMvJHthZ2VudElkfWAsIHtcclxuICAgICAgICAgIHBhcmFtczogeyBzdGFydF9kYXRlOiBmaXJzdERheSwgZW5kX2RhdGU6IGxhc3REYXkgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgdGFyZ2V0Rm9yUGVyaW9kID1cclxuICAgICAgICB0YXJnZXRSZXM/LmRhdGE/LnN0YXR1cyAmJiB0YXJnZXRSZXM/LmRhdGE/LnRvdGFsX3RhcmdldFxyXG4gICAgICAgICAgPyBOdW1iZXIodGFyZ2V0UmVzLmRhdGEudG90YWxfdGFyZ2V0KVxyXG4gICAgICAgICAgOiAwO1xyXG5cclxuXHJcbiAgICAgIGxldCBjb21tO1xyXG4gICAgICBpZiAodHlwZSA9PT0gXCJlbXBsb3llZVwiKSB7XHJcbiAgICAgICAgY29tbSA9IGF3YWl0IEFQSS5nZXQoYC9lbnJvbGwvZW1wbG95ZWUvJHthZ2VudElkfS9pbmNlbnRpdmVgLCB7XHJcbiAgICAgICAgICBwYXJhbXM6IHsgc3RhcnRfZGF0ZTogZmlyc3REYXksIGVuZF9kYXRlOiBsYXN0RGF5IH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29tbSA9IGF3YWl0IEFQSS5nZXQoYC9lbnJvbGwvYWdlbnQvJHthZ2VudElkfS9jb21taXNzaW9uYCwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7IHN0YXJ0X2RhdGU6IGZpcnN0RGF5LCBlbmRfZGF0ZTogbGFzdERheSB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBsZXQgYWNoaWV2ZWQgPVxyXG4gICAgICAgIHR5cGUgPT09IFwiZW1wbG95ZWVcIlxyXG4gICAgICAgICAgPyBjb21tPy5kYXRhPy5pbmNlbnRpdmVTdW1tYXJ5Py50b3RhbF9ncm91cF92YWx1ZSB8fCAwXHJcbiAgICAgICAgICA6IGNvbW0/LmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9ncm91cF92YWx1ZSB8fCAwO1xyXG4gICAgICBpZiAodHlwZW9mIGFjaGlldmVkID09PSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgYWNoaWV2ZWQgPSBOdW1iZXIoYWNoaWV2ZWQucmVwbGFjZSgvW14wLTkuLV0rL2csIFwiXCIpKTtcclxuICAgICAgfVxyXG5cclxuXHJcbiAgICAgIGxldCB1cFRvVGFyZ2V0ID0gMDtcclxuICAgICAgbGV0IGJleW9uZFRhcmdldCA9IDA7XHJcbiAgICAgIGxldCB0b3RhbENvbW1pc3Npb24gPSAwO1xyXG4gICAgICBjb25zdCByZW1haW5pbmcgPSBNYXRoLm1heCh0YXJnZXRGb3JQZXJpb2QgLSBhY2hpZXZlZCwgMCk7XHJcbiAgICAgIGNvbnN0IGRpZmZlcmVuY2UgPSBhY2hpZXZlZCAtIHRhcmdldEZvclBlcmlvZDtcclxuXHJcbiAgICAgIGlmICh0eXBlID09PSBcImFnZW50XCIpIHtcclxuICAgICAgICBpZiAoYWNoaWV2ZWQgPD0gdGFyZ2V0Rm9yUGVyaW9kKSB7XHJcbiAgICAgICAgICB1cFRvVGFyZ2V0ID0gYWNoaWV2ZWQgKiAwLjAwNTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdXBUb1RhcmdldCA9IHRhcmdldEZvclBlcmlvZCAqIDAuMDA1O1xyXG4gICAgICAgICAgYmV5b25kVGFyZ2V0ID0gKGFjaGlldmVkIC0gdGFyZ2V0Rm9yUGVyaW9kKSAqIDAuMDE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRvdGFsQ29tbWlzc2lvbiA9IHVwVG9UYXJnZXQgKyBiZXlvbmRUYXJnZXQ7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKGFjaGlldmVkID4gdGFyZ2V0Rm9yUGVyaW9kKSB7XHJcbiAgICAgICAgICBiZXlvbmRUYXJnZXQgPSAoYWNoaWV2ZWQgLSB0YXJnZXRGb3JQZXJpb2QpICogMC4wMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdG90YWxDb21taXNzaW9uID0gYmV5b25kVGFyZ2V0O1xyXG4gICAgICB9XHJcblxyXG5cclxuICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgdGFyZ2V0OiB0YXJnZXRGb3JQZXJpb2QsXHJcbiAgICAgICAgYWNoaWV2ZWQsXHJcbiAgICAgICAgcmVtYWluaW5nLFxyXG4gICAgICAgIGRpZmZlcmVuY2UsXHJcbiAgICAgICAgdXBUb1RhcmdldCxcclxuICAgICAgICBiZXlvbmRUYXJnZXQsXHJcbiAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogdG90YWxDb21taXNzaW9uLFxyXG4gICAgICAgIGlzVGFyZ2V0U2V0OiB0YXJnZXRGb3JQZXJpb2QgPiAwLFxyXG4gICAgICAgIHRhcmdldERpc3BsYXk6XHJcbiAgICAgICAgICB0YXJnZXRGb3JQZXJpb2QgPiAwXHJcbiAgICAgICAgICAgID8gYOKCuSR7dGFyZ2V0Rm9yUGVyaW9kLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YFxyXG4gICAgICAgICAgICA6IFwiTm90IFNldFwiLFxyXG4gICAgICAgIGNhbGN1bGF0aW9uVHlwZTogdHlwZSA9PT0gXCJlbXBsb3llZVwiID8gXCJpbmNlbnRpdmVcIiA6IFwiY29tbWlzc2lvblwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQodG90YWxDb21taXNzaW9uLnRvRml4ZWQoMikpO1xyXG4gICAgICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIGFtb3VudDogdG90YWxDb21taXNzaW9uLnRvRml4ZWQoMiksXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAgIGNvbnN0IGJyZWFrZG93bkRhdGEgPVxyXG4gICAgICAgIHR5cGUgPT09IFwiZW1wbG95ZWVcIlxyXG4gICAgICAgICAgPyBjb21tPy5kYXRhPy5pbmNlbnRpdmVEYXRhIHx8IFtdXHJcbiAgICAgICAgICA6IGNvbW0/LmRhdGE/LmNvbW1pc3Npb25EYXRhIHx8IFtdO1xyXG4gICAgICBzZXRDb21taXNzaW9uQnJlYWtkb3duKGJyZWFrZG93bkRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YXJnZXQgZGV0YWlsc1wiLCBlcnJvcik7XHJcbiAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICBhY2hpZXZlZDogMCxcclxuICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgICB1cFRvVGFyZ2V0OiAwLFxyXG4gICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gICAgICAgIGlzVGFyZ2V0U2V0OiBmYWxzZSxcclxuICAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgICAgICBjYWxjdWxhdGlvblR5cGU6IHR5cGUgPT09IFwiZW1wbG95ZWVcIiA/IFwiaW5jZW50aXZlXCIgOiBcImNvbW1pc3Npb25cIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldENvbW1pc3Npb25CcmVha2Rvd24oW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNUYXJnZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3QgZmV0Y2hDb21taXNzaW9uUGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvcGF5bWVudC1vdXQvZ2V0LWNvbW1pc3Npb24tcGF5bWVudHNcIik7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChwYXltZW50LCBpbmRleCkgPT4gKHtcclxuICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgIF9pZDogcGF5bWVudC5faWQsXHJcbiAgICAgICAgYWdlbnRfaWQ6IHBheW1lbnQuYWdlbnRfaWQsXHJcbiAgICAgICAgYWdlbnRfbmFtZTogcGF5bWVudC5hZ2VudF9pZD8ubmFtZSxcclxuICAgICAgICBwYXlfZGF0ZTogcGF5bWVudC5wYXlfZGF0ZSxcclxuICAgICAgICBhbW91bnQ6IHBheW1lbnQuYW1vdW50LFxyXG4gICAgICAgIHBheV90eXBlOiBwYXltZW50LnBheV90eXBlLFxyXG4gICAgICAgIGNvbW1pc3Npb25fZnJvbTpcclxuICAgICAgICAgIHBheW1lbnQuY29tbWlzc2lvbkNhbGN1bGF0aW9uRnJvbURhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuICAgICAgICBjb21taXNzaW9uX3RvOlxyXG4gICAgICAgICAgcGF5bWVudC5jb21taXNzaW9uQ2FsY3VsYXRpb25Ub0RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuICAgICAgICB0cmFuc2FjdGlvbl9pZDogcGF5bWVudC50cmFuc2FjdGlvbl9pZCxcclxuICAgICAgICBub3RlOiBwYXltZW50Lm5vdGUsXHJcbiAgICAgICAgcGF5X2ZvcjogcGF5bWVudC5wYXlfZm9yLFxyXG4gICAgICAgIGRpc2J1cnNlZF9ieTogcGF5bWVudC5hZG1pbl90eXBlPy5uYW1lLFxyXG4gICAgICAgIHJlY2VpcHRfbm86IHBheW1lbnQucmVjZWlwdF9ubyxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRDb21taXNzaW9uUGF5bWVudHMocmVzcG9uc2VEYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggQ29tbWlzc2lvbiBwYXltZW50c1wiLCBlcnJvcik7XHJcbiAgICAgIHNldENvbW1pc3Npb25QYXltZW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBzZXRBZG1pbklkKHVzZXJPYmo/Ll9pZCk7XHJcbiAgICBzZXRBZG1pbk5hbWUodXNlck9iaj8uZnVsbF9uYW1lIHx8IHVzZXJPYmo/Lm5hbWUgfHwgXCJcIik7XHJcbiAgICBpZiAodXNlck9iaj8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCkge1xyXG4gICAgICBzZXRNb2RpZnlQYXltZW50KFxyXG4gICAgICAgIHVzZXJPYmo/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09IFwidHJ1ZVwiXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gICAgZmV0Y2hDb21taXNzaW9uUGF5bWVudHMoKTtcclxuICB9LCBbcmVSZW5kZXJdKTtcclxuXHJcblxyXG4gIGNvbnN0IGdldE1vbnRoUmFuZ2UgPSAoc2VsZWN0ZWRNb250aCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZE1vbnRoKSByZXR1cm4geyBmaXJzdERheTogXCJcIiwgbGFzdERheTogXCJcIiB9O1xyXG4gICAgY29uc3QgW3llYXIsIG1vbnRoXSA9IHNlbGVjdGVkTW9udGguc3BsaXQoXCItXCIpO1xyXG4gICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbiAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgcmV0dXJuIHsgZmlyc3REYXksIGxhc3REYXkgfTtcclxuICB9O1xyXG5cclxuICAvLyBjb25zdCBjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uID0gYXN5bmMgKGFnZW50SWQsIG1vbnRoLCB0eXBlKSA9PiB7XHJcbiAgLy8gICBpZiAoIWFnZW50SWQgfHwgIW1vbnRoKSB7XHJcbiAgLy8gICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhbW91bnQ6IFwiXCIgfSkpO1xyXG4gIC8vICAgICByZXR1cm47XHJcbiAgLy8gICB9XHJcblxyXG4gIC8vICAgc2V0SXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uKHRydWUpO1xyXG4gIC8vICAgdHJ5IHtcclxuICAvLyAgICAgYXdhaXQgZmV0Y2hUYXJnZXREZXRhaWxzKGFnZW50SWQsIG1vbnRoLCB0eXBlKTtcclxuICAvLyAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgLy8gICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gY2FsY3VsYXRlIGFnZW50IGNvbW1pc3Npb246XCIsIGVycm9yKTtcclxuICAvLyAgICAgc2V0Q29tbWlzc2lvbkZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIGFtb3VudDogXCJcIiB9KSk7XHJcbiAgLy8gICB9IGZpbmFsbHkge1xyXG4gIC8vICAgICBzZXRJc0xvYWRpbmdDb21taXNzaW9uQ2FsY3VsYXRpb24oZmFsc2UpO1xyXG4gIC8vICAgfVxyXG4gIC8vIH07XHJcblxyXG4gIC8vIGNvbnN0IGhhbmRsZUNvbW1pc3Npb25DaGFuZ2UgPSAoZSkgPT4ge1xyXG4gIC8vICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgLy8gICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgLy8gICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcblxyXG4gIC8vICAgaWYgKG5hbWUgPT09IFwiYWdlbnRfaWRcIiB8fCBuYW1lID09PSBcInNlbGVjdGVkTW9udGhcIikge1xyXG4gIC8vICAgICBjb25zdCB1cGRhdGVkQWdlbnRJZCA9XHJcbiAgLy8gICAgICAgbmFtZSA9PT0gXCJhZ2VudF9pZFwiID8gdmFsdWUgOiBjb21taXNzaW9uRm9ybS5hZ2VudF9pZDtcclxuICAvLyAgICAgY29uc3QgdXBkYXRlZE1vbnRoID1cclxuICAvLyAgICAgICBuYW1lID09PSBcInNlbGVjdGVkTW9udGhcIiA/IHZhbHVlIDogY29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aDtcclxuICAvLyAgICAgaWYgKHVwZGF0ZWRBZ2VudElkICYmIHVwZGF0ZWRNb250aCAmJiBhZ2VudFR5cGUpIHtcclxuICAvLyAgICAgICBjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uKFxyXG4gIC8vICAgICAgICAgdXBkYXRlZEFnZW50SWQsXHJcbiAgLy8gICAgICAgICB1cGRhdGVkTW9udGgsXHJcbiAgLy8gICAgICAgICBhZ2VudFR5cGVcclxuICAvLyAgICAgICApO1xyXG4gIC8vICAgICB9IGVsc2Uge1xyXG4gIC8vICAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQoXCIwLjAwXCIpO1xyXG4gIC8vICAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gIC8vICAgICAgICAgdGFyZ2V0OiAwLFxyXG4gIC8vICAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgLy8gICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgLy8gICAgICAgICBkaWZmZXJlbmNlOiAwLFxyXG4gIC8vICAgICAgICAgdXBUb1RhcmdldDogMCxcclxuICAvLyAgICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAvLyAgICAgICAgIHRhcmdldENvbW1pc3Npb246IDAsXHJcbiAgLy8gICAgICAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgLy8gICAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAvLyAgICAgICAgIGNhbGN1bGF0aW9uVHlwZTpcclxuICAvLyAgICAgICAgICAgYWdlbnRUeXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgLy8gICAgICAgfSk7XHJcbiAgLy8gICAgICAgc2V0Q29tbWlzc2lvbkJyZWFrZG93bihbXSk7XHJcbiAgLy8gICAgIH1cclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG5cclxuICBjb25zdCBjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uID0gYXN5bmMgKGFnZW50SWQsIHBlcmlvZCwgdHlwZSwgbW9kZSA9IFwibW9udGhcIikgPT4ge1xyXG4gICAgaWYgKCFhZ2VudElkIHx8ICghcGVyaW9kICYmIG1vZGUgPT09IFwibW9udGhcIikgfHwgKG1vZGUgPT09IFwiY3VzdG9tXCIgJiYgKCFwZXJpb2QuZnJvbSB8fCAhcGVyaW9kLnRvKSkpIHtcclxuICAgICAgc2V0Q29tbWlzc2lvbkZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIGFtb3VudDogXCJcIiB9KSk7XHJcbiAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQoXCIwLjAwXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBzZXRJc0xvYWRpbmdDb21taXNzaW9uQ2FsY3VsYXRpb24odHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBmZXRjaFRhcmdldERldGFpbHMoYWdlbnRJZCwgcGVyaW9kLCB0eXBlLCBtb2RlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gY2FsY3VsYXRlIGNvbW1pc3Npb246XCIsIGVycm9yKTtcclxuICAgICAgc2V0Q29tbWlzc2lvbkZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIGFtb3VudDogXCJcIiB9KSk7XHJcbiAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQoXCIwLjAwXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb21taXNzaW9uQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG5cclxuICAgIFxyXG4gICAgaWYgKG5hbWUgPT09IFwiZnJvbV9kYXRlXCIgfHwgbmFtZSA9PT0gXCJ0b19kYXRlXCIpIHtcclxuICAgICAgc2V0Q3VzdG9tRGF0ZVJhbmdlKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcblxyXG4gXHJcbiAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQoXCIwLjAwXCIpO1xyXG4gICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICB0YXJnZXQ6IDAsXHJcbiAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICAgIGRpZmZlcmVuY2U6IDAsXHJcbiAgICAgICAgdXBUb1RhcmdldDogMCxcclxuICAgICAgICBiZXlvbmRUYXJnZXQ6IDAsXHJcbiAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuICAgICAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICAgICAgdGFyZ2V0RGlzcGxheTogXCJOb3QgU2V0XCIsXHJcbiAgICAgICAgY2FsY3VsYXRpb25UeXBlOlxyXG4gICAgICAgICAgYWdlbnRUeXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRDb21taXNzaW9uQnJlYWtkb3duKFtdKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcblxyXG4gICAgXHJcbiAgICBpZiAoW1wiYWdlbnRfaWRcIiwgXCJzZWxlY3RlZE1vbnRoXCJdLmluY2x1ZGVzKG5hbWUpKSB7XHJcbiAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQoXCIwLjAwXCIpO1xyXG4gICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICB0YXJnZXQ6IDAsXHJcbiAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICAgIGRpZmZlcmVuY2U6IDAsXHJcbiAgICAgICAgdXBUb1RhcmdldDogMCxcclxuICAgICAgICBiZXlvbmRUYXJnZXQ6IDAsXHJcbiAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuICAgICAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICAgICAgdGFyZ2V0RGlzcGxheTogXCJOb3QgU2V0XCIsXHJcbiAgICAgICAgY2FsY3VsYXRpb25UeXBlOlxyXG4gICAgICAgICAgYWdlbnRUeXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRDb21taXNzaW9uQnJlYWtkb3duKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghY29tbWlzc2lvbkZvcm0uYWdlbnRfaWQpIHtcclxuICAgICAgbmV3RXJyb3JzLmFnZW50X2lkID0gXCJQbGVhc2Ugc2VsZWN0IGFuIGFnZW50XCI7XHJcbiAgICB9XHJcbiAgICBpZiAoXHJcbiAgICAgICFjb21taXNzaW9uRm9ybS5hbW91bnQgfHxcclxuICAgICAgaXNOYU4oY29tbWlzc2lvbkZvcm0uYW1vdW50KSB8fFxyXG4gICAgICBwYXJzZUZsb2F0KGNvbW1pc3Npb25Gb3JtLmFtb3VudCkgPD0gMFxyXG4gICAgKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIGFtb3VudFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGZpbHRlck1vZGUgPT09IFwibW9udGhcIiAmJiAhY29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aCkge1xyXG4gICAgICBuZXdFcnJvcnMuc2VsZWN0ZWRNb250aCA9IFwiUGxlYXNlIHNlbGVjdCBhIG1vbnRoXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoZmlsdGVyTW9kZSA9PT0gXCJjdXN0b21cIikge1xyXG4gICAgICBpZiAoIWN1c3RvbURhdGVSYW5nZS5mcm9tX2RhdGUpIG5ld0Vycm9ycy5mcm9tX2RhdGUgPSBcIkZyb20gZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICBpZiAoIWN1c3RvbURhdGVSYW5nZS50b19kYXRlKSBuZXdFcnJvcnMudG9fZGF0ZSA9IFwiVG8gZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKFxyXG4gICAgICBjb21taXNzaW9uRm9ybS5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJlxyXG4gICAgICAhY29tbWlzc2lvbkZvcm0udHJhbnNhY3Rpb25faWRcclxuICAgICkge1xyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkIGZvciBvbmxpbmUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbW1pc3Npb25TdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgIGxldCBjb21taXNzaW9uQ2FsY3VsYXRpb25Gcm9tRGF0ZSwgY29tbWlzc2lvbkNhbGN1bGF0aW9uVG9EYXRlO1xyXG4gICAgICAgIGlmIChmaWx0ZXJNb2RlID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgICAgIGNvbnN0IHsgZmlyc3REYXksIGxhc3REYXkgfSA9IGdldE1vbnRoUmFuZ2UoY29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aCk7XHJcbiAgICAgICAgICBjb21taXNzaW9uQ2FsY3VsYXRpb25Gcm9tRGF0ZSA9IGZpcnN0RGF5O1xyXG4gICAgICAgICAgY29tbWlzc2lvbkNhbGN1bGF0aW9uVG9EYXRlID0gbGFzdERheTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29tbWlzc2lvbkNhbGN1bGF0aW9uRnJvbURhdGUgPSBjdXN0b21EYXRlUmFuZ2UuZnJvbV9kYXRlO1xyXG4gICAgICAgICAgY29tbWlzc2lvbkNhbGN1bGF0aW9uVG9EYXRlID0gY3VzdG9tRGF0ZVJhbmdlLnRvX2RhdGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgLi4uY29tbWlzc2lvbkZvcm0sXHJcbiAgICAgICAgICBhZG1pbl90eXBlOiBhZG1pbklkLFxyXG4gICAgICAgICAgY29tbWlzc2lvbkNhbGN1bGF0aW9uRnJvbURhdGUsXHJcbiAgICAgICAgICBjb21taXNzaW9uQ2FsY3VsYXRpb25Ub0RhdGUsXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgYXdhaXQgQVBJLnBvc3QoXCIvcGF5bWVudC1vdXQvYWRkLWNvbW1pc3Npb24tcGF5bWVudFwiLCBwYXlsb2FkKTtcclxuICAgICAgICBhcGkub3Blbih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkNvbW1pc3Npb24gUGF5T3V0IEFkZGVkXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJDb21taXNzaW9uIFBheW1lbnQgSGFzIEJlZW4gU3VjY2Vzc2Z1bGx5IEFkZGVkXCIsXHJcbiAgICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tNDAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgICBzaG93UHJvZ3Jlc3M6IHRydWUsXHJcbiAgICAgICAgICBwYXVzZU9uSG92ZXI6IGZhbHNlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHJlc2V0Q29tbWlzc2lvbkZvcm0oKTtcclxuICAgICAgICBzZXRSZVJlbmRlcigodmFsKSA9PiB2YWwgKyAxKTtcclxuICAgICAgICBmZXRjaENvbW1pc3Npb25QYXltZW50cygpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIjtcclxuICAgICAgICBhcGkub3Blbih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBBZGQgQ29tbWlzc2lvbiBQYXlvdXRcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBtZXNzYWdlLFxyXG4gICAgICAgICAgc2hvd1Byb2dyZXNzOiB0cnVlLFxyXG4gICAgICAgICAgcGF1c2VPbkhvdmVyOiBmYWxzZSxcclxuICAgICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtNDAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbW1pc3Npb25Db2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWdlbnRfbmFtZVwiLCBoZWFkZXI6IFwiQWdlbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnQgKOKCuSlcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbiAgICB7IGtleTogXCJjb21taXNzaW9uX2Zyb21cIiwgaGVhZGVyOiBcIkZyb20gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJjb21taXNzaW9uX3RvXCIsIGhlYWRlcjogXCJUbyBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbiAgICB7IGtleTogXCJkaXNidXJzZWRfYnlcIiwgaGVhZGVyOiBcIkRpc2J1cnNlZCBieVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgcmVzZXRDb21taXNzaW9uRm9ybSA9ICgpID0+IHtcclxuICAgIHNldEFnZW50VHlwZShcIlwiKTtcclxuICAgIHNldFNlbGVjdGVkVXNlckxpc3QoW10pO1xyXG4gICAgc2V0Q29tbWlzc2lvbkZvcm0oe1xyXG4gICAgICBhZ2VudF9pZDogXCJcIixcclxuICAgICAgcGF5X2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgIHNlbGVjdGVkTW9udGg6IGN1cnJlbnRNb250aCxcclxuICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICBub3RlOiBcIlwiLFxyXG4gICAgICBhZG1pbl90eXBlOiBhZG1pbklkLFxyXG4gICAgICBwYXlfZm9yOiBwYXltZW50Rm9yLFxyXG4gICAgfSk7XHJcbiAgICBzZXRDb21taXNzaW9uQnJlYWtkb3duKFtdKTtcclxuICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICB0YXJnZXQ6IDAsXHJcbiAgICAgIGFjaGlldmVkOiAwLFxyXG4gICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgIGRpZmZlcmVuY2U6IDAsXHJcbiAgICAgIHVwVG9UYXJnZXQ6IDAsXHJcbiAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuICAgICAgaXNUYXJnZXRTZXQ6IGZhbHNlLFxyXG4gICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgICAgY2FsY3VsYXRpb25UeXBlOiBcImNvbW1pc3Npb25cIixcclxuICAgIH0pO1xyXG4gICAgc2V0Q2FsY3VsYXRlZEFtb3VudChcIjAuMDBcIik7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgc2V0QWxyZWFkeVBhaWQoXCIwLjAwXCIpO1xyXG4gICAgc2V0UmVtYWluaW5nUGF5YWJsZShcIjAuMDBcIik7XHJcbiAgICBzZXRJc1RhcmdldExvYWRpbmcoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTQgbWQ6bWItMFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC1yZWQtNTAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICBDb21taXNzaW9uIC8gSW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgUGF5bWVudHMgT3V0XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIkFkZCBDb21taXNzaW9uIFBheW1lbnRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzZXRDb21taXNzaW9uRm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtOTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC02MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+Kzwvc3Bhbj4gQ29tbWlzc2lvbiAvIEluY2VudGl2ZSBQYXltZW50XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi00IHRleHQtdmlvbGV0LTgwMCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBDb21taXNzaW9uIC8gSW5jZW50aXZlIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSBkYXRhPVwiQ29tbWlzc2lvbiBQYXltZW50c1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogY29tbWlzc2lvblBheW1lbnRzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2NvbW1pc3Npb25QYXltZW50c31cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29tbWlzc2lvbkNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlBheU91dCBDb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YENvbW1pc3Npb24gUGF5bWVudHMuY3N2YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBObyBjb21taXNzaW9uIHBheW1lbnRzIGZvdW5kXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dDb21taXNzaW9uTW9kYWx9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTaG93Q29tbWlzc2lvbk1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICByZXNldENvbW1pc3Npb25Gb3JtKCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHdpZHRoPVwibWF4LXctbWRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgICAgQWRkIENvbW1pc3Npb24gLyBJbmNlbnRpdmUgUGF5bWVudFxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZUNvbW1pc3Npb25TdWJtaXR9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXthZ2VudFR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWdlbnRUeXBlKHNlbGVjdGVkKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkVXNlckxpc3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkID09PSBcImFnZW50XCIgPyBhZ2VudHMgOiBlbXBsb3llZXNcclxuICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEFscmVhZHlQYWlkKFwiMC4wMFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFJlbWFpbmluZ1BheWFibGUoXCIwLjAwXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbWFpbmluZzogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBUb1RhcmdldDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmV5b25kVGFyZ2V0OiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldERpc3BsYXk6IFwiTm90IFNldFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGlvblR5cGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWQgPT09IFwiZW1wbG95ZWVcIiA/IFwiaW5jZW50aXZlXCIgOiBcImNvbW1pc3Npb25cIixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Q29tbWlzc2lvbkJyZWFrZG93bihbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRDYWxjdWxhdGVkQW1vdW50KFwiMC4wMFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5cclxuICAgICAgICAgICAgICAgICAgICAgIC0tIFNlbGVjdCBUeXBlIC0tXHJcbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFnZW50XCI+QWdlbnQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW1wbG95ZWVcIj5FbXBsb3llZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHthZ2VudFR5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3Qge2FnZW50VHlwZSA9PT0gXCJhZ2VudFwiID8gXCJBZ2VudFwiIDogXCJFbXBsb3llZVwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2BTZWxlY3QgJHthZ2VudFR5cGV9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTdHJpbmcob3B0aW9uPy5jaGlsZHJlbilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS5hZ2VudF9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhZ2VudF9pZDogXCJcIiB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRfaWQ6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FsY3VsYXRlZEFtb3VudChcIjAuMDBcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhY2hpZXZlZDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cFRvVGFyZ2V0OiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzVGFyZ2V0U2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGlvblR5cGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZ2VudFR5cGUgPT09IFwiZW1wbG95ZWVcIiA/IFwiaW5jZW50aXZlXCIgOiBcImNvbW1pc3Npb25cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbW1pc3Npb25CcmVha2Rvd24oW10pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7KGFnZW50VHlwZSA9PT0gXCJhZ2VudFwiID8gYWdlbnRzIDogZW1wbG95ZWVzKS5tYXAoKHBlcnNvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3BlcnNvbi5faWR9IHZhbHVlPXtwZXJzb24uX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVyc29uLm5hbWV9IHwge3BlcnNvbi5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFnZW50X2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZ2VudF9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRmlsdGVyIEJ5IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlck1vZGUoXCJtb250aFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLWxnICR7ZmlsdGVyTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS0yMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIE1vbnRoXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXJNb2RlKFwiY3VzdG9tXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtbGcgJHtmaWx0ZXJNb2RlID09PSBcImN1c3RvbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS0yMDAgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbSBSYW5nZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtmaWx0ZXJNb2RlID09PSBcIm1vbnRoXCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE1vbnRoIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VsZWN0ZWRNb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICAgIG1heD17Y3VycmVudE1vbnRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnNlbGVjdGVkTW9udGggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuc2VsZWN0ZWRNb250aH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImZyb21fZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21EYXRlUmFuZ2UuZnJvbV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg9e2N1c3RvbURhdGVSYW5nZS50b19kYXRlIHx8IGN1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmZyb21fZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmZyb21fZGF0ZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVG8gRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0b19kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbURhdGVSYW5nZS50b19kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW49e2N1c3RvbURhdGVSYW5nZS5mcm9tX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heD17bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRvX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy50b19kYXRlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGZpbHRlck1vZGUgPT09IFwibW9udGhcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Gb3JtLmFnZW50X2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Gb3JtLnNlbGVjdGVkTW9udGgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRUeXBlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FsY3VsYXRlVG90YWxQYXlhYmxlQ29tbWlzc2lvbihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uRm9ybS5hZ2VudF9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7IGZyb206IGN1c3RvbURhdGVSYW5nZS5mcm9tX2RhdGUsIHRvOiBjdXN0b21EYXRlUmFuZ2UudG9fZGF0ZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFnZW50VHlwZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcImN1c3RvbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAhY29tbWlzc2lvbkZvcm0uYWdlbnRfaWQgfHxcclxuICAgICAgICAgICAgICAgICAgICAgIChmaWx0ZXJNb2RlID09PSBcIm1vbnRoXCIgJiYgIWNvbW1pc3Npb25Gb3JtLnNlbGVjdGVkTW9udGgpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAoZmlsdGVyTW9kZSA9PT0gXCJjdXN0b21cIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoIWN1c3RvbURhdGVSYW5nZS5mcm9tX2RhdGUgfHwgIWN1c3RvbURhdGVSYW5nZS50b19kYXRlKSkgfHxcclxuICAgICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZ0NvbW1pc3Npb25DYWxjdWxhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctZ3JlZW4tNzAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgaG92ZXI6YmctZ3JlZW4tODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmdDb21taXNzaW9uQ2FsY3VsYXRpb24gPyBcIkNhbGN1bGF0aW5nLi4uXCIgOiBcIkNhbGN1bGF0ZSBBbW91bnRcIn1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgIHtpc1RhcmdldExvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IGRhdGE9XCJUYXJnZXQgRGV0YWlsc1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcblxyXG4gICAgICAgICAgICAgICAge2FnZW50VHlwZSAmJiB0YXJnZXREYXRhICYmICFpc1RhcmdldExvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS5pc1RhcmdldFNldCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgcC00IHJvdW5kZWQtbGcgc2hhZG93IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQteWVsbG93LTgwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVGFyZ2V0IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmFjaGlldmVkID49IHRhcmdldERhdGEudGFyZ2V0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tODAwIGZvbnQtc2VtaWJvbGQgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg8J+OiSBUYXJnZXQgQWNoaWV2ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtZDpncmlkLWNvbHMtMyBnYXAtNCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYXJnZXQgU2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0YXJnZXREYXRhLnRhcmdldERpc3BsYXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgcm91bmRlZCB3LWZ1bGwgYmctZ3JheS01MCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY2hpZXZlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7dGFyZ2V0RGF0YS5hY2hpZXZlZD8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIHctZnVsbCBiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpZmZlcmVuY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Digrkke3RhcmdldERhdGEuZGlmZmVyZW5jZT8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIHctZnVsbCBiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYXlhYmxle1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS5jYWxjdWxhdGlvblR5cGUgPT09IFwiaW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiQ29tbWlzc2lvblwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7dGFyZ2V0RGF0YS50YXJnZXRDb21taXNzaW9uLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgcm91bmRlZCB3LWZ1bGwgYmctZ3JheS01MCB0ZXh0LWdyZWVuLTcwMCBmb250LWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmcteWVsbG93LTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci15ZWxsb3ctMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteWVsbG93LTgwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5vIHRhcmdldCBzZXQgZm9yIHRoaXMge2FnZW50VHlwZX0ue1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmNhbGN1bGF0aW9uVHlwZSA9PT0gXCJpbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiQ29tbWlzc2lvblwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB3aWxsIGJlIGNhbGN1bGF0ZWQgYmFzZWQgb24gc3RhbmRhcmQgcnVsZXMuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcblxyXG4gICAgICAgICAgICAgICAge2FnZW50VHlwZSAmJiB0YXJnZXREYXRhLmlzVGFyZ2V0U2V0ICYmICFpc1RhcmdldExvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgc2hhZG93IGJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItMyB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS5jYWxjdWxhdGlvblR5cGUgPT09IFwiaW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJDb21taXNzaW9uXCJ9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgQnJlYWtkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LXNtIGJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0XCI+UGFydDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50ICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudFR5cGUgPT09IFwiYWdlbnRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMC41JSB1cCB0byBUYXJnZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS51cFRvVGFyZ2V0Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnRUeXBlID09PSBcImFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIjElIGJleW9uZCBUYXJnZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiMSUgaW5jZW50aXZlIG9uIHRhcmdldCBkaWZmZXJlbmNlXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmJleW9uZFRhcmdldD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFBheWFibGV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS5jYWxjdWxhdGlvblR5cGUgPT09IFwiaW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJDb21taXNzaW9uXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiB0ZXh0LXJpZ2h0IHRleHQtZ3JlZW4tODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLnRhcmdldENvbW1pc3Npb24/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Gb3JtLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDb21taXNzaW9uQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW1vZGlmeVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgUGF5YWJsZSAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbGN1bGF0ZWRBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBiZy1ncmF5LTEwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRW50ZXIgQW1vdW50ICjigrkpIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1pbj17MX1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0uYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhbW91bnQ6IFwiXCIgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgaG93IG11Y2ggdG8gcGF5XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmFtb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7YWdlbnRUeXBlID09PSBcImFnZW50XCIgJiYgY29tbWlzc2lvbkJyZWFrZG93bi5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgYmctZ3JheS0xMDAgcC0zIHJvdW5kZWQtbGcgc2hhZG93LWlubmVyIGJvcmRlciBib3JkZXItZ3JheS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTMgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29tbWlzc2lvbiBCcmVha2Rvd24gKEN1c3RvbWVyLXdpc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLTYwIG92ZXJmbG93LXktYXV0byBjdXN0b20tc2Nyb2xsYmFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LXNtIGJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXZpb2xldC0xMDAgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgdmFsdWUgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uIFBlcmNlbnRhZ2UgKCUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uIHZhbHVlICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29tbWlzc2lvbkJyZWFrZG93bi5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZ3JvdXBfaWQ/LmNvbW1pc3Npb24gfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5jb21taXNzaW9uX3ZhbHVlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHthZ2VudFR5cGUgPT09IFwiZW1wbG95ZWVcIiAmJiBjb21taXNzaW9uQnJlYWtkb3duLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBiZy1ncmF5LTEwMCBwLTMgcm91bmRlZC1sZyBzaGFkb3ctaW5uZXIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItMyB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgQnJlYWtkb3duIChDdXN0b21lci13aXNlKVxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC02MCBvdmVyZmxvdy15LWF1dG8gY3VzdG9tLXNjcm9sbGJhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgdGV4dC1zbSBib3JkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaG9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIHZhbHVlICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5jZW50aXZlIHBlcmNlbnRhZ2UgKCUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5jZW50aXZlIHZhbHVlICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29tbWlzc2lvbkJyZWFrZG93bi5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5ncm91cF9pZD8uaW5jZW50aXZlcyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uaW5jZW50aXZlX3ZhbHVlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0ucGF5X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPk9ubGluZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHttb2RpZnlQYXltZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5DaGVxdWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJhbmtfdHJhbnNmZXJcIj5CYW5rIFRyYW5zZmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7Y29tbWlzc2lvbkZvcm0ucGF5X3R5cGUgPT09IFwib25saW5lXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSUQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDb21taXNzaW9uQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0cmFuc2FjdGlvbiBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTm90ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Gb3JtLm5vdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGRpdGlvbmFsIGRldGFpbHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICByb3dzPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubm90ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMubm90ZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy12aW9sZXQtNTAgcC0zIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRGlzYnVyc2VkIEJ5XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPnthZG1pbk5hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgc3BhY2UteC0zIHB0LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmVzZXRDb21taXNzaW9uRm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmcgfHwgaXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy12aW9sZXQtNzAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy12aW9sZXQtNjAwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IFwiUHJvY2Vzc2luZy4uLlwiIDogXCJTYXZlIFBheW1lbnRcIn1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVGFyZ2V0UGF5T3V0Q29tbWlzc2lvbkluY2VudGl2ZTtcclxuXHJcblxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVGFyZ2V0UGF5T3V0Q29tbWlzc2lvbkluY2VudGl2ZS5qc3gifQ==