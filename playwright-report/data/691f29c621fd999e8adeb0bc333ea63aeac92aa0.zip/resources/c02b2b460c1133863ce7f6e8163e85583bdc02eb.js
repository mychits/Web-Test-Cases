import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/InActiveUserReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomerReportPrint from "/src/components/printFormats/CustomerReportPrint.js";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FiSearch } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { IoMdDownload } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Fuse from "/node_modules/.vite/deps/fuse__js.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const InActiveUserReport = () => {
  _s();
  const [searchParams] = useSearchParams();
  const userId = searchParams.get("user_id");
  const [groups, setGroups] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [TableDaybook, setTableDaybook] = useState([]);
  const [TableAuctions, setTableAuctions] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(userId ? userId : "");
  const [group, setGroup] = useState([]);
  const [commission, setCommission] = useState("");
  const [TableEnrolls, setTableEnrolls] = useState([]);
  const [TableEnrollsDate, setTableEnrollsDate] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [groupPaid, setGroupPaid] = useState("");
  const [groupToBePaid, setGroupToBePaid] = useState("");
  const [customerTransactions, setCustomerTransactions] = useState(null);
  const [fromDate, setFromDate] = useState(() => {
    const today = /* @__PURE__ */ new Date();
    return today.toISOString().split("T")[0];
  });
  const [toDate, setToDate] = useState(() => {
    const today = /* @__PURE__ */ new Date();
    return today.toISOString().split("T")[0];
  });
  const [totalAmount, setTotalAmount] = useState(0);
  const [groupPaidDate, setGroupPaidDate] = useState("");
  const [groupToBePaidDate, setGroupToBePaidDate] = useState("");
  const [detailsLoading, setDetailLoading] = useState(false);
  const [basicLoading, setBasicLoading] = useState(false);
  const [dateLoading, setDateLoading] = useState(false);
  const [EnrollGroupId, setEnrollGroupId] = useState({
    groupId: "",
    ticket: ""
  });
  const [registrationFee, setRegistrationFee] = useState({
    amount: 0,
    createdAt: null
  });
  const [visibleRows, setVisibleRows] = useState({
    row1: false,
    row2: false,
    row3: false,
    row4: false,
    row5: false,
    row6: false,
    row7: false,
    row8: false,
    row9: false
  });
  const Input = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
    /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: label }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "text",
        placeholder: label,
        value: value || "",
        readOnly: true,
        className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
        lineNumber: 71,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
    lineNumber: 69,
    columnNumber: 3
  }, this);
  const [TotalToBepaid, setTotalToBePaid] = useState("");
  const [Totalpaid, setTotalPaid] = useState("");
  const [Totalprofit, setTotalProfit] = useState("");
  const [NetTotalprofit, setNetTotalProfit] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState(
    userId ? userId : ""
  );
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = /* @__PURE__ */ new Date();
    return today.toISOString().split("T")[0];
  });
  const [selectedPaymentMode, setSelectedPaymentMode] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState(
    userId ? userId : ""
  );
  const [payments, setPayments] = useState([]);
  const [availableTickets, setAvailableTickets] = useState([]);
  const [screenLoading, setScreenLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("groupDetails");
  const [searchText, setSearchText] = useState("");
  const [groupDetails, setGroupDetails] = useState(" ");
  const [loanCustomers, setLoanCustomers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [pigmeCustomerData, setPigmeCustomerData] = useState([]);
  const [pigmeId, setPigmeId] = useState("No");
  const [filteredPigmeData, setFilteredPigmeData] = useState([]);
  const [borrowersData, setBorrowersData] = useState([]);
  const [borrowerId, setBorrowerId] = useState("No");
  const [filteredBorrowerData, setFilteredBorrowerData] = useState([]);
  const [filteredDisbursement, setFilteredDisbursement] = useState([]);
  const [disbursementLoading, setDisbursementLoading] = useState(false);
  const [registrationAmount, setRegistrationAmount] = useState(null);
  const [registrationDate, setRegistrationDate] = useState(null);
  const [finalPaymentBalance, setFinalPaymentBalance] = useState(0);
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    ticket: "",
    receipt_no: "",
    pay_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: ""
  });
  const BasicLoanColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Payment Date" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment Type" },
    { key: "balance", header: "Balance" }
  ];
  const BasicPigmeColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Payment Date" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment Type" },
    { key: "balance", header: "Balance" }
  ];
  const DisbursementColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Disbursed Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "pay_type", header: "Payment Type" },
    { key: "disbursement_type", header: "Disbursement Type" },
    { key: "disbursed_by", header: "Disbursed By" },
    { key: "balance", header: "Balance" }
  ];
  useEffect(() => {
    const fetchRegistrationFee = async () => {
      if (activeTab === "basicReport" && selectedGroup && EnrollGroupId.groupId && EnrollGroupId.ticket && EnrollGroupId.groupId !== "Loan" && EnrollGroupId !== "Pigme") {
        try {
          setTableEnrolls([]);
          setGroupPaid("");
          setGroupToBePaid("");
          setRegistrationAmount(null);
          setRegistrationDate(null);
          setBasicLoading(true);
          setIsLoading(true);
          const response = await api.get(
            "/enroll/get-user-registration-fee-report",
            {
              params: {
                group_id: EnrollGroupId.groupId,
                ticket: EnrollGroupId.ticket,
                user_id: selectedGroup
              }
            }
          );
          const { payments: payments2 = [], registrationFees = [] } = response.data || {};
          setGroupPaid(payments2[0]?.groupPaidAmount || 0);
          setGroupToBePaid(payments2[0]?.totalToBePaidAmount || 0);
          let balance = 0;
          const formattedData = payments2.map((payment, index) => {
            balance += Number(payment.amount || 0);
            return {
              _id: payment._id,
              id: index + 1,
              date: formatPayDate(payment?.pay_date),
              amount: payment.amount,
              receipt: payment.receipt_no,
              old_receipt: payment.old_receipt_no,
              type: payment.pay_type,
              balance
            };
          });
          let totalRegAmount = 0;
          registrationFees.forEach((regFee, idx) => {
            formattedData.push({
              id: "-",
              date: regFee.createdAt ? new Date(regFee.createdAt).toLocaleDateString("en-GB") : "",
              amount: regFee.amount,
              receipt: regFee.receipt_no,
              old_receipt: "-",
              type: regFee.pay_for || "Reg Fee",
              balance: "-"
            });
            totalRegAmount += Number(regFee.amount || 0);
          });
          setRegistrationAmount(totalRegAmount);
          if (registrationFees.length > 0) {
            setRegistrationDate(
              registrationFees[0]?.createdAt ? new Date(registrationFees[0].createdAt).toLocaleDateString(
                "en-GB"
              ) : null
            );
          }
          if (formattedData.length > 0) {
            formattedData.push({
              id: "",
              date: "",
              amount: "",
              receipt: "",
              old_receipt: "",
              type: "TOTAL",
              balance
            });
            setFinalPaymentBalance(balance);
          } else {
            setFinalPaymentBalance(0);
          }
          setTableEnrolls(formattedData);
        } catch (error) {
          console.error("Error fetching registration fee and payments:", error);
          setTableEnrolls([]);
          setGroupPaid("");
          setGroupToBePaid("");
          setRegistrationAmount(null);
          setRegistrationDate(null);
        } finally {
          setBasicLoading(false);
          setIsLoading(false);
        }
      } else {
        setTableEnrolls([]);
        setGroupPaid("");
        setGroupToBePaid("");
        setRegistrationAmount(null);
        setRegistrationDate(null);
      }
    };
    fetchRegistrationFee();
  }, [activeTab, selectedGroup, EnrollGroupId.groupId, EnrollGroupId.ticket]);
  useEffect(() => {
    const fetchAllLoanPaymentsbyId = async () => {
      setBorrowersData([]);
      setBasicLoading(true);
      try {
        const selectedLoan = loanCustomers?.overall_loan?.find(
          (loan) => loan?.loan_details?.loan?._id === EnrollGroupId.ticket
        );
        const loanId = selectedLoan?.loan_details?.loan?._id || EnrollGroupId.ticket;
        const response = await api.get(
          `/loan-payment/get-all-loan-payments/${loanId}`
        );
        if (response.data?.length > 0) {
          let balance = 0;
          const formattedData = response.data.map((loanPayment, index) => {
            balance += Number(loanPayment.amount);
            return {
              _id: loanPayment._id,
              id: index + 1,
              pay_date: formatPayDate(loanPayment?.pay_date),
              amount: loanPayment.amount,
              receipt_no: loanPayment.receipt_no,
              pay_type: loanPayment.pay_type,
              balance
            };
          });
          formattedData.push({
            _id: "",
            id: "",
            pay_date: "",
            receipt_no: "",
            amount: "",
            pay_type: "",
            balance
          });
          setBorrowersData(formattedData);
        } else {
          setBorrowersData([]);
        }
      } catch (error) {
        console.error("Error fetching loan payment data:", error);
        setBorrowersData([]);
      } finally {
        setBasicLoading(false);
      }
    };
    if (EnrollGroupId.groupId === "Loan" && EnrollGroupId.ticket)
      fetchAllLoanPaymentsbyId();
  }, [EnrollGroupId.ticket]);
  useEffect(() => {
    const fetchAllPigmePaymentsbyId = async () => {
      setPigmeCustomerData([]);
      setBasicLoading(true);
      try {
        const response = await api.get(
          `/pigme-payment/get-all-pigme-payments-by-id/${EnrollGroupId.ticket}`
        );
        if (response.data && response.data.length > 0) {
          let balance = 0;
          const formattedData = response.data.map((pigmePayment, index) => {
            balance += Number(pigmePayment.amount);
            return {
              _id: pigmePayment._id,
              id: index + 1,
              pay_date: formatPayDate(pigmePayment?.pay_date),
              amount: pigmePayment.amount,
              receipt_no: pigmePayment.receipt_no,
              pay_type: pigmePayment.pay_type,
              balance
            };
          });
          formattedData.push({
            _id: "",
            id: "",
            pay_date: "",
            receipt_no: "",
            amount: "",
            pay_type: "",
            balance
          });
          setPigmeCustomerData(formattedData);
        } else {
          setPigmeCustomerData([]);
        }
      } catch (error) {
        console.error("Error fetching pigme payment data:", error);
        setPigmeCustomerData([]);
      } finally {
        setBasicLoading(false);
      }
    };
    if (EnrollGroupId.groupId === "Pigme") fetchAllPigmePaymentsbyId();
  }, [EnrollGroupId.ticket]);
  useEffect(() => {
    const fetchGroupById = async () => {
      try {
        const response = await api.get(
          `/group/get-by-id-group/${EnrollGroupId.groupId}`
        );
        if (response.status >= 400) throw new Error("API ERROR");
        setGroupDetails(response.data);
      } catch (err) {
        console.log("Failed to fetch group details by ID:", err.message);
      }
    };
    if (EnrollGroupId.groupId !== "Loan" && EnrollGroupId.groupId !== "Pigme")
      fetchGroupById();
  }, [EnrollGroupId?.ticket]);
  useEffect(() => {
    setScreenLoading(true);
    const fetchGroups = async () => {
      setDetailLoading(true);
      try {
        const response = await api.get("/user/get-user");
        setGroups(response.data);
        setScreenLoading(false);
        setDetailLoading(false);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setDetailLoading(false);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchBorrower = async () => {
      try {
        setLoanCustomers([]);
        const response = await api.get(`/payment/loan/user/${selectedGroup}`);
        if (response.data) {
          const filteredBorrowerData2 = response.data?.overall_loan?.map(
            (loan, index) => ({
              sl_no: index + 1,
              loan: loan?.loan_details?.loan?.loan_id,
              loan_amount: loan?.loan_value,
              tenure: loan?.loan_details?.loan?.tenure,
              service_charge: loan?.loan_details?.loan?.service_charges,
              total_paid_amount: loan?.total_paid_amount,
              balance: loan?.balance
            })
          );
          setFilteredBorrowerData(filteredBorrowerData2);
        }
        setLoanCustomers(response.data);
        if (response.status >= 400) throw new Error("Failed to send message");
      } catch (err) {
        console.log("failed to fetch loan customers", err.message);
        setFilteredBorrowerData([]);
      }
    };
    setBorrowersData([]);
    setBorrowerId("No");
    fetchBorrower();
  }, [selectedGroup]);
  useEffect(() => {
    const fetchPigme = async () => {
      try {
        setPigmeCustomers([]);
        const response = await api.get(`/payment/pigme/user/${selectedGroup}`);
        console.info(response.data, "pigme");
        if (response.data) {
          const filteredPigmeData2 = response.data?.overall_pigme?.map(
            (pigme, index) => ({
              sl_no: index + 1,
              pigme: pigme?.pigme_details?.pigme?.pigme_id,
              start_date: pigme?.pigme_details?.pigme?.start_date?.split("T")[0],
              duration: pigme?.pigme_details?.pigme?.duration,
              maturity_interest: pigme?.pigme_details?.pigme?.maturity_interest,
              total_deposited_amount: pigme?.total_deposited_amount
            })
          );
          setFilteredPigmeData(filteredPigmeData2);
        }
        setPigmeCustomers(response.data);
        if (response.status >= 400) throw new Error("Failed to send message");
      } catch (err) {
        console.log("failed to fetch Pigme customers", err.message);
        setFilteredPigmeData([]);
      }
    };
    setPigmeCustomerData([]);
    setPigmeId("No");
    fetchPigme();
  }, [selectedGroup]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get(`/user/get-user-by-id/${selectedGroup}`);
        setGroup(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [selectedGroup]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setFilteredUsers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchDisbursement = async () => {
      try {
        setDisbursementLoading(true);
        const response = await api.get(
          `/payment-out/get-payment-out-report-daybook`,
          {
            params: {
              userId: selectedGroup
            }
          }
        );
        if (response.data) {
          const formattedData = response.data.map((payment, index) => {
            let balance = 0;
            balance += Number(payment.amount);
            return {
              _id: payment._id,
              id: index + 1,
              disbursement_type: payment.disbursement_type,
              group_name: payment?.group_id?.group_name,
              pay_date: formatPayDate(payment?.pay_date),
              ticket: payment.ticket,
              transaction_date: formatPayDate(payment.createdAt),
              amount: payment.amount,
              receipt_no: payment.receipt_no,
              pay_type: payment.pay_type,
              disbursed_by: payment.admin_type?.name,
              balance
            };
          });
          setFilteredDisbursement(formattedData);
        } else {
          setFilteredDisbursement([]);
        }
      } catch (error) {
        console.error("Error fetching disbursement data", error, error.message);
        setFilteredDisbursement([]);
      } finally {
        setDisbursementLoading(false);
      }
    };
    if (selectedGroup) fetchDisbursement();
  }, [selectedGroup]);
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    setSelectedGroup(groupId);
    handleGroupAuctionChange(groupId);
  };
  useEffect(() => {
    if (userId) {
      handleGroupPayment(userId);
    }
  }, []);
  const handleEnrollGroup = (event) => {
    const value = event.target.value;
    if (value) {
      const [groupId, ticket] = value.split("|");
      setEnrollGroupId({ groupId, ticket });
    } else {
      setEnrollGroupId({ groupId: "", ticket: "" });
    }
    console.info(borrowersData, " information borroswers ADATA");
    console.info(EnrollGroupId.groupId, " information EnrollGroupId.groupId");
  };
  useEffect(() => {
    const fetchCustomerTransaction = async () => {
      try {
        if (!selectedAuctionGroupId) return;
        const response = await api.get(
          `/payment/users/${selectedAuctionGroupId}`
        );
        console.info(response.data.payments, "Fetched user transactions");
        setCustomerTransactions(response.data.payments);
      } catch (error) {
        console.error("Unable to fetch customer transaction details", error);
      }
    };
    fetchCustomerTransaction();
  }, [selectedAuctionGroupId]);
  useEffect(
    () => {
      const fetchPayments = async () => {
        try {
          const response = await api.get(`/payment/get-customer-history`, {
            params: {
              pay_date: selectedDate,
              groupId: selectedAuctionGroupId,
              userId: selectedCustomers,
              pay_type: selectedPaymentMode
            }
          });
          if (response.data && response.data.length > 0) {
            setFilteredAuction(response);
            const paymentData = response.data;
            const totalAmount2 = paymentData.reduce(
              (sum, payment) => sum + Number(payment.amount || 0),
              0
            );
            setPayments(totalAmount2);
            const formattedData = response.data.map((group2, index) => ({
              id: index + 1,
              group: group2.group_id.group_name,
              name: group2.user_id?.full_name,
              phone_number: group2.user_id.phone_number,
              ticket: group2.ticket,
              amount: group2.amount,
              mode: group2.pay_type
            }));
            setTableDaybook(formattedData);
          } else {
            setFilteredAuction([]);
          }
        } catch (error) {
          console.error("Error fetching payment data:", error);
          setFilteredAuction([]);
          setPayments(0);
        }
      };
      fetchPayments();
    },
    [
      selectedAuctionGroupId,
      selectedDate,
      selectedPaymentMode,
      selectedCustomers
    ]
  );
  const loanColumns = [
    { key: "sl_no", header: "SL. No" },
    { key: "loan", header: "Loan ID" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "service_charge", header: "Service Charge" },
    { key: "tenure", header: "Tenure" },
    { key: "total_paid_amount", header: "Total Paid Amount" },
    { key: "balance", header: "Balance" }
  ];
  const pigmeColumns = [
    { key: "sl_no", header: "SL. No" },
    { key: "pigme", header: "Pigme ID" },
    { key: "start_date", header: "Start Date" },
    { key: "duration", header: "duration" },
    { key: "maturity_interest", header: "Intrest" },
    { key: "total_deposited_amount", header: "Total Deposited Amount" }
  ];
  const handleGroupAuctionChange = async (groupId) => {
    setFilteredAuction([]);
    if (groupId) {
      try {
        const response = await api.post(
          `/enroll/get-inactive-report/${groupId}`
        );
        if (response.data && response.data.length > 0) {
          setFilteredAuction(response.data);
          const formattedData = response.data.map((group2, index) => {
            const groupName = group2?.enrollment?.group?.group_name || "";
            const tickets = group2?.enrollment?.tickets || "";
            const groupType = group2?.enrollment?.group?.group_type;
            const groupInstall = parseInt(group2?.enrollment?.group?.group_install) || 0;
            const auctionCount = parseInt(group2?.auction?.auctionCount) || 0;
            const totalPaidAmount2 = group2?.payments?.totalPaidAmount || 0;
            const totalProfit2 = group2?.profit?.totalProfit || 0;
            const totalPayable = group2?.payable?.totalPayable || 0;
            const firstDividentHead = group2?.firstAuction?.firstDividentHead || 0;
            if (!group2?.enrollment?.group) {
              return null;
            }
            return {
              id: index + 1,
              group: groupName,
              ticket: tickets,
              totalBePaid: groupType === "double" ? groupInstall * auctionCount + groupInstall : totalPayable + groupInstall + totalProfit2,
              profit: totalProfit2,
              toBePaidAmount: groupType === "double" ? groupInstall * auctionCount + groupInstall : totalPayable + groupInstall + firstDividentHead,
              paidAmount: totalPaidAmount2,
              balance: groupType === "double" ? groupInstall * auctionCount + groupInstall - totalPaidAmount2 : totalPayable + groupInstall + firstDividentHead - totalPaidAmount2,
              referred_type: group2?.enrollment?.referred_type || "N/A",
              referrer_name: group2?.enrollment?.referrer_name || "N/A",
              chit_asking_month: group2?.enrollment?.chit_asking_month || "N/A",
              customer_status: group2?.enrollment?.customer_status || "N/A",
              removal_reason: group2?.enrollment?.removal_reason || "N/A",
              isPrized: group2?.enrollment?.isPrized === true ? "Prized" : "Un Prized"
            };
          }).filter((item) => item !== null).filter((item) => item.customer_status === "In Active");
          setTableAuctions(formattedData);
          setCommission(0);
          const totalToBePaidAmount = formattedData.filter((summary) => summary.customer_status === "In Active").reduce((sum, group2) => {
            return sum + (group2?.totalBePaid || 0);
          }, 0);
          setTotalToBePaid(totalToBePaidAmount);
          const totalNetToBePaidAmount = formattedData.filter((summary) => summary.customer_status === "In Active").reduce((sum, group2) => {
            return sum + (group2?.toBePaidAmount || 0);
          }, 0);
          setNetTotalProfit(totalNetToBePaidAmount);
          const totalPaidAmount = formattedData.filter((summary) => summary.customer_status === "In Active").reduce((sum, group2) => sum + (group2?.paidAmount || 0), 0);
          setTotalPaid(totalPaidAmount);
          const totalProfit = formattedData.filter((summary) => summary.customer_status === "In Active").reduce((sum, group2) => sum + (group2?.profit || 0), 0);
          setTotalProfit(totalProfit);
        } else {
          setFilteredAuction([]);
          setCommission(0);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
        setCommission(0);
      }
    } else {
      setFilteredAuction([]);
      setCommission(0);
    }
  };
  useEffect(() => {
    if (userId) {
      handleGroupAuctionChange(userId);
    }
  }, []);
  const Auctioncolumns = [
    { key: "id", header: "SL. NO" },
    { key: "customer_status", header: "Customer Status" },
    { key: "removal_reason", header: "Removal Reason" },
    { key: "group", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "referred_type", header: "Referrer Type" },
    { key: "referrer_name", header: "Referred By" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "isPrized", header: "Is Prized" },
    { key: "totalBePaid", header: "Amount to be Paid" },
    { key: "profit", header: "Profit" },
    { key: "toBePaidAmount", header: "Net To be Paid" },
    { key: "paidAmount", header: "Amount Paid" },
    { key: "balance", header: "Balance" }
  ];
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    return date.toISOString().split("T")[0];
  };
  useEffect(() => {
    const fetchEnroll = async () => {
      setTableEnrolls([]);
      setBasicLoading(true);
      try {
        setIsLoading(true);
        const response = await api.get(
          `/enroll/get-user-payment?group_id=${EnrollGroupId.groupId}&ticket=${EnrollGroupId.ticket}&user_id=${selectedGroup}`
        );
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const Paid = response.data;
          setGroupPaid(Paid[0].groupPaidAmount);
          const toBePaid = response.data;
          setGroupToBePaid(toBePaid[0].totalToBePaidAmount);
          let balance = 0;
          const formattedData = response.data.map((group2, index) => {
            balance += Number(group2.amount);
            return {
              _id: group2._id,
              id: index + 1,
              date: formatPayDate(group2?.pay_date),
              amount: group2.amount,
              receipt: group2.receipt_no,
              old_receipt: group2.old_receipt_no,
              type: group2.pay_type,
              balance
            };
          });
          formattedData.push({
            id: "",
            date: "",
            amount: "",
            receipt: "",
            old_receipt: "",
            type: "",
            balance
          });
          setTableEnrolls(formattedData);
        } else {
          setFilteredUsers([]);
          setTableEnrolls([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
        setTableEnrolls([]);
      } finally {
        setBasicLoading(false);
        setIsLoading(false);
      }
    };
    if (EnrollGroupId.groupId !== "Loan" && EnrollGroupId.groupId !== "Pigme")
      fetchEnroll();
  }, [selectedGroup, EnrollGroupId.groupId, EnrollGroupId.ticket]);
  const Basiccolumns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "amount", header: "Amount" },
    { key: "receipt", header: "Receipt No" },
    { key: "old_receipt", header: "Old Receipt No" },
    { key: "type", header: "Payment Type" },
    { key: "balance", header: "Balance" }
  ];
  const formatDate = (dateString) => {
    const parts = dateString.split("-");
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
    return dateString;
  };
  const formattedFromDate = formatDate(fromDate);
  const formattedToDate = formatDate(toDate);
  useEffect(() => {
    const fetchEnroll = async () => {
      try {
        const response = await api.get(
          `/group-report/get-group-enroll-date/${selectedGroup}?fromDate=${formattedFromDate}&toDate=${formattedToDate}`
        );
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const Paid = response.data;
          setGroupPaidDate(Paid[0].groupPaidAmount || 0);
          const toBePaid = response.data;
          setGroupToBePaidDate(toBePaid[0].totalToBePaidAmount);
          const totalAmount2 = response.data.reduce(
            (sum, group2) => sum + parseInt(group2.amount),
            0
          );
          setTotalAmount(totalAmount2);
          const formattedData = response.data.map((group2, index) => ({
            id: index + 1,
            name: group2?.user?.full_name,
            phone_number: group2?.user?.phone_number,
            ticket: group2.ticket,
            amount_to_be_paid: parseInt(group2.group.group_install) + group2.totalToBePaidAmount,
            amount_paid: group2.totalPaidAmount,
            amount_balance: parseInt(group2.group.group_install) + group2.totalToBePaidAmount - group2.totalPaidAmount
          }));
          setTableEnrollsDate(formattedData);
        } else {
          setFilteredUsers([]);
          setTotalAmount(0);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
        setTotalAmount(0);
      }
    };
    fetchEnroll();
  }, [selectedGroup, formattedFromDate, formattedToDate]);
  const Datecolumns = [
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "ticket", header: "Ticket" },
    { key: "amount_to_be_paid", header: "Amount to be Paid" },
    { key: "amount_paid", header: "Amount Paid" },
    { key: "amount_balance", header: "Amount Balance" }
  ];
  useEffect(() => {
    if (groupInfo && formData.bid_amount) {
      const commission2 = groupInfo.group_value * 5 / 100 || 0;
      const win_amount = (groupInfo.group_value || 0) - (formData.bid_amount || 0);
      const divident = (formData.bid_amount || 0) - commission2;
      const divident_head = groupInfo.group_members ? divident / groupInfo.group_members : 0;
      const payable = (groupInfo.group_install || 0) - divident_head;
      setFormData((prevData) => ({
        ...prevData,
        group_id: groupInfo._id,
        commission: commission2,
        win_amount,
        divident,
        divident_head,
        payable
      }));
    }
  }, [groupInfo, formData.bid_amount]);
  useEffect(() => {
    if (selectedGroup) {
      api.post(`/enroll/get-next-tickets/${selectedGroup}`).then((response) => {
        setAvailableTickets(response.data.availableTickets || []);
      }).catch((error) => {
        console.error("Error fetching available tickets:", error);
      });
    } else {
      setAvailableTickets([]);
    }
  }, [selectedGroup]);
  if (screenLoading)
    return /* @__PURE__ */ jsxDEV("div", { className: "w-screen m-24", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
      lineNumber: 1031,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
      lineNumber: 1030,
      columnNumber: 5
    }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: " min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
        lineNumber: 1039,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center", children: "Reports - In Active Customer" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
        lineNumber: 1044,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center w-full gap-4 bg-violet-50    p-2 w-30 h-40  rounded-3xl  border   space-x-2  ", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block text-lg text-gray-500 text-center  font-semibold mb-2",
              htmlFor: "SS",
              children: "In Active Customer"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1051,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              id: "SS",
              value: selectedAuctionGroupId || void 0,
              onChange: handleGroupPayment,
              showSearch: true,
              popupMatchSelectWidth: false,
              placeholder: "Search or Select Customer",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              style: { height: "50px", width: "600px" },
              children: groups.map(
                (group2) => /* @__PURE__ */ jsxDEV("option", { value: group2._id, children: [
                  group2.full_name,
                  " - ",
                  group2.phone_number
                ] }, group2._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1071,
                  columnNumber: 23
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1056,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
          lineNumber: 1050,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
          lineNumber: 1049,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
          lineNumber: 1048,
          columnNumber: 15
        }, this),
        selectedGroup && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: `px-6 py-2 font-medium ${activeTab === "groupDetails" ? "border-b-2 border-violet-500 text-violet-500" : "text-gray-500"}`,
                onClick: () => handleTabChange("groupDetails"),
                children: "Customer Details"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1084,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: `px-6 py-2 font-medium ${activeTab === "basicReport" ? "border-b-2 border-violet-500 text-violet-500" : "text-gray-500"}`,
                onClick: () => handleTabChange("basicReport"),
                children: "Customer Ledger"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1092,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: `px-6 py-2 font-medium ${activeTab === "disbursement" ? "border-b-2 border-violet-500 text-violet-500" : "text-gray-500"}`,
                onClick: () => handleTabChange("disbursement"),
                children: "PayOut | Disbursement"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1101,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1083,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-3", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => CustomerReportPrint(
                group,
                TableAuctions,
                filteredBorrowerData,
                filteredDisbursement,
                {
                  TotalToBepaid,
                  Totalprofit,
                  NetTotalprofit,
                  Totalpaid
                },
                TableEnrolls,
                customerTransactions
              ),
              className: "flex items-center gap-2 px-6 py-2 bg-violet-500 text-white rounded shadow",
              children: [
                /* @__PURE__ */ jsxDEV(IoMdDownload, { size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1129,
                  columnNumber: 25
                }, this),
                "Download Full Report"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1111,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1110,
            columnNumber: 21
          }, this),
          activeTab === "groupDetails" && /* @__PURE__ */ jsxDEV(Fragment, { children: detailsLoading ? /* @__PURE__ */ jsxDEV("p", { children: "loading..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1137,
            columnNumber: 21
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-lg  ", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "absolute inset-y-0 left-4 flex items-center text-gray-400 ", children: /* @__PURE__ */ jsxDEV(FiSearch, { className: "text-xl" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1143,
                  columnNumber: 35
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1142,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "Search customer details...",
                    className: "w-full pl-12 pr-5 py-3.5 text-gray-800 bg-white border border-gray-200 rounded-full shadow-3xl \r\n                   placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-violet-400 focus:border-violet-400 \r\n                   transition-all duration-300 ease-in-out text-sm md:text-base",
                    value: searchText,
                    onChange: (e) => setSearchText(e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1145,
                    columnNumber: 33
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1141,
                columnNumber: 31
              }, this),
              searchText && (() => {
                const detailsArray = [
                  { key: "Name", value: group.full_name },
                  { key: "Email", value: group.email },
                  { key: "Phone", value: group.phone_number },
                  {
                    key: "Alternate Number",
                    value: group.alternate_number
                  },
                  { key: "Address", value: group.address },
                  { key: "Aadhaar", value: group.adhaar_no },
                  { key: "PAN", value: group.pan_no },
                  { key: "Pincode", value: group.pincode },
                  {
                    key: "Father Name",
                    value: group.father_name
                  },
                  {
                    key: "Nominee Name",
                    value: group.nominee_name
                  },
                  {
                    key: "Bank Name",
                    value: group.bank_name
                  },
                  {
                    key: "Bank Account",
                    value: group.bank_account_number
                  }
                ];
                const fuse = new Fuse(detailsArray, {
                  keys: ["key", "value"],
                  threshold: 0.3
                  // Fuzzy match
                });
                const results = fuse.search(searchText);
                return /* @__PURE__ */ jsxDEV("div", { className: "mt-2 bg-white border rounded shadow p-3 w-1/2", children: results.length > 0 ? results.map(
                  ({ item }) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "p-1 border-b",
                      children: [
                        /* @__PURE__ */ jsxDEV("strong", { children: item.key }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                          lineNumber: 1204,
                          columnNumber: 45
                        }, this),
                        " →",
                        " ",
                        item.value || "-"
                      ]
                    },
                    item.key,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1201,
                      columnNumber: 31
                    },
                    this
                  )
                ) : /* @__PURE__ */ jsxDEV("p", { children: "No matching details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1209,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1198,
                  columnNumber: 29
                }, this);
              })()
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1140,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setVisibleRows((prev) => ({
                      ...prev,
                      row1: !prev.row1
                    })),
                    className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row1 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-violet-700 to-violet-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                    children: visibleRows.row1 ? "✓ Hide Basic Info" : "Show Basic Info"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1219,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setVisibleRows((prev) => ({
                      ...prev,
                      row2: !prev.row2
                    })),
                    className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row2 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-violet-700 to-violet-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                    children: visibleRows.row2 ? "✓ Hide Address Info" : "Show Address Info"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1237,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setVisibleRows((prev) => ({
                      ...prev,
                      row3: !prev.row3
                    })),
                    className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row3 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-violet-700 to-violet-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                    children: visibleRows.row3 ? "✓ Hide Regional Info" : "Show Regional Info"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1255,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setVisibleRows((prev) => ({
                      ...prev,
                      row4: !prev.row4
                    })),
                    className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row4 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-violet-700 to-violet-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                    children: visibleRows.row4 ? "✓ Hide Referral, Nominee & Bank Details" : "Show Referral, Nominee & Bank Details"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1273,
                    columnNumber: 33
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1218,
                columnNumber: 31
              }, this),
              visibleRows.row1 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col w-full gap-4", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Name",
                      value: group.full_name
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1296,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(Input, { label: "Email", value: group.email }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1300,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1295,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Phone Number",
                      value: group.phone_number
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1303,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Adhaar Number",
                      value: group.adhaar_no
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1307,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1302,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "PAN Number",
                      value: group.pan_no
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1313,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Pincode",
                      value: group.pincode
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1317,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1312,
                  columnNumber: 35
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1294,
                columnNumber: 25
              }, this),
              visibleRows.row2 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Address",
                      value: group.address
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1329,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Gender",
                      value: group.gender
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1333,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1328,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Date of Birth",
                      value: group.dateofbirth ? new Date(group.dateofbirth).toISOString().split("T")[0] : ""
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1339,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Collection Area",
                      value: group?.collection_area?.route_name
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1349,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1338,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Marital Status",
                      value: group.marital_status
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1355,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Father Name",
                      value: group.father_name
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1359,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1354,
                  columnNumber: 35
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1327,
                columnNumber: 25
              }, this),
              visibleRows.row3 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Nationality",
                      value: group.nationality
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1371,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Village",
                      value: group.village
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1375,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1370,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(Input, { label: "Taluk", value: group.taluk }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1381,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "District",
                      value: group.district
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1382,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1380,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(Input, { label: "State", value: group.state }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1388,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Alternate Number",
                      value: group.alternate_number
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1389,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1387,
                  columnNumber: 35
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1369,
                columnNumber: 25
              }, this),
              visibleRows.row4 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Referral Name",
                      value: group.referral_name
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1401,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Nominee Name",
                      value: group.nominee_name
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1405,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Nominee DOB",
                      value: group.nominee_dateofbirth ? new Date(group.nominee_dateofbirth).toISOString().split("T")[0] : ""
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1409,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1400,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Nominee Phone Number",
                      value: group.nominee_phone_number
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1421,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Nominee Relationship",
                      value: group.nominee_relationship
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1425,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Bank Name",
                      value: group.bank_name
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1429,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1420,
                  columnNumber: 35
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Bank Branch Name",
                      value: group.bank_branch_name
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1435,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Bank Account Number",
                      value: group.bank_account_number
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1439,
                      columnNumber: 37
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      label: "Bank IFSC Code",
                      value: group.bank_IFSC_code
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1443,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1434,
                  columnNumber: 35
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1399,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1216,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4", children: "Enrolled Groups" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1453,
                columnNumber: 31
              }, this),
              TableAuctions && TableAuctions.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: [
                /* @__PURE__ */ jsxDEV(
                  DataTable,
                  {
                    data: filterOption(
                      TableAuctions,
                      // Use TableAuctions for display
                      searchText
                    ),
                    columns: Auctioncolumns,
                    exportedPdfName: `InActive Customer Details Report`,
                    printHeaderKeys: [
                      "Customer Name",
                      "Phone Number",
                      "Total Amount Payable",
                      "Total Profit",
                      "Total Net To be Paid",
                      "Total Balance"
                    ],
                    printHeaderValues: [
                      group.full_name,
                      group?.phone_number,
                      TotalToBepaid,
                      Totalprofit,
                      NetTotalprofit,
                      NetTotalprofit && Totalpaid ? NetTotalprofit - Totalpaid : ""
                    ],
                    exportedFileName: `InActive Customer Details Report-${TableAuctions.length > 0 ? TableAuctions[0].date + " to " + TableAuctions[TableAuctions.length - 1].date : "empty"}.csv`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1461,
                    columnNumber: 35
                  },
                  this
                ),
                filteredBorrowerData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4", children: "Loan Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1498,
                    columnNumber: 39
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    DataTable,
                    {
                      data: filteredBorrowerData,
                      columns: loanColumns,
                      exportedFileName: `Customer Loan Report.csv`,
                      exportedPdfName: "Customer Loan Report"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1501,
                      columnNumber: 39
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1497,
                  columnNumber: 27
                }, this),
                filteredPigmeData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4", children: "Pigme Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1512,
                    columnNumber: 39
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    DataTable,
                    {
                      data: filteredPigmeData,
                      columns: pigmeColumns,
                      exportedFileName: `Customer Pigme Details.csv`,
                      exportedPdfName: "Customer Pigme Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1515,
                      columnNumber: 39
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1511,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1460,
                columnNumber: 25
              }, this) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1525,
                columnNumber: 25
              }, this),
              !isLoading && TableAuctions.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-40 w-full flex justify-center items-center", children: "No Enrolled Group Data Found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1530,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1452,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mt-5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Amount to be Paid" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1537,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "-",
                    value: TotalToBepaid || "",
                    readOnly: true,
                    className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1540,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-green-700 pl-3`, children: numberToIndianWords(TotalToBepaid || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1547,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1536,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Profit" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1552,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "-",
                    value: Totalprofit || "",
                    readOnly: true,
                    className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1555,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-green-700 pl-3`, children: numberToIndianWords(Totalprofit || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1562,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1551,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Net To be Paid" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1567,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "-",
                    value: NetTotalprofit || "",
                    readOnly: true,
                    className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1570,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-green-700 pl-3`, children: numberToIndianWords(NetTotalprofit || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1577,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1566,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Amount Paid" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1582,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "-",
                    value: Totalpaid || "",
                    readOnly: true,
                    className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1585,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-green-700 pl-3`, children: numberToIndianWords(Totalpaid || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1592,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1581,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Balance" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1597,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "-",
                    value: NetTotalprofit && Totalpaid ? NetTotalprofit - Totalpaid : "",
                    readOnly: true,
                    className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1600,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-green-700 pl-3`, children: numberToIndianWords(NetTotalprofit && Totalpaid ? NetTotalprofit - Totalpaid : 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1611,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1596,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1535,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1139,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1135,
            columnNumber: 19
          }, this),
          activeTab === "basicReport" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Groups and Tickets" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1816,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: EnrollGroupId.groupId ? `${EnrollGroupId.groupId}|${EnrollGroupId.ticket}` : "",
                  onChange: handleEnrollGroup,
                  className: "border border-gray-300 rounded px-6 py-2 shadow-sm outline-none w-full max-w-md",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group | Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                      lineNumber: 1827,
                      columnNumber: 33
                    }, this),
                    filteredAuction.map((group2) => {
                      if (group2?.enrollment?.group && group2?.enrollment?.customer_status === "In Active") {
                        return /* @__PURE__ */ jsxDEV(
                          "option",
                          {
                            value: `${group2.enrollment.group._id}|${group2.enrollment.tickets}`,
                            children: [
                              group2.enrollment.group.group_name,
                              " |",
                              " ",
                              group2.enrollment.tickets
                            ]
                          },
                          group2.enrollment.group._id,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                            lineNumber: 1837,
                            columnNumber: 35
                          },
                          this
                        );
                      }
                      return null;
                    }),
                    Array.isArray(loanCustomers?.overall_loan) && loanCustomers.overall_loan.map(
                      (loan, index) => /* @__PURE__ */ jsxDEV(
                        "option",
                        {
                          value: `Loan|${loan?.loan_details?.loan?._id || index}`,
                          children: [
                            loan?.loan_details?.loan?.loan_id || "N/A",
                            " ",
                            "| ₹",
                            loan?.loan_value || 0
                          ]
                        },
                        loan?.loan_details?.loan?._id || index,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                          lineNumber: 1851,
                          columnNumber: 31
                        },
                        this
                      )
                    ),
                    Array.isArray(pigmeCustomers?.overall_pigme) && pigmeCustomers.overall_pigme.map(
                      (pigme, index) => /* @__PURE__ */ jsxDEV(
                        "option",
                        {
                          value: `Pigme|${pigme?.pigme_details?.pigme?._id || index}`,
                          children: [
                            pigme?.pigme_details?.pigme?.pigme_id || "N/A",
                            " ",
                            "| ₹",
                            pigme?.total_deposited_amount || 0
                          ]
                        },
                        pigme?.pigme_details?.pigme?._id || index,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                          lineNumber: 1867,
                          columnNumber: 31
                        },
                        this
                      )
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1819,
                  columnNumber: 31
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1815,
              columnNumber: 29
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1814,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-center gap-10 flex-wrap", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: `Registration Fee: ₹${registrationAmount || 0}`,
                    readOnly: true,
                    className: "px-4 py-2 border rounded font-semibold w-60 text-center bg-green-100 text-green-800 border-green-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1889,
                    columnNumber: 31
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-mono text-green-700 text-center w-60 break-words", children: numberToIndianWords(registrationAmount || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1895,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1888,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: `Payment Balance: ₹${finalPaymentBalance || 0}`,
                    readOnly: true,
                    className: "px-4 py-2 border rounded font-semibold w-60 text-center bg-violet-100 text-violet-800 border-violet-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1902,
                    columnNumber: 31
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-mono text-violet-700 text-center w-60 break-words", children: numberToIndianWords(finalPaymentBalance || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1908,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1901,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: `Total: ₹${Number(finalPaymentBalance || 0) + Number(registrationAmount || 0)}`,
                    readOnly: true,
                    className: "px-4 py-2 border rounded font-semibold w-60 text-center bg-purple-100 text-purple-800 border-purple-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                    lineNumber: 1915,
                    columnNumber: 31
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-mono text-purple-700 text-center w-60 break-words", children: numberToIndianWords(
                  Number(finalPaymentBalance || 0) + Number(registrationAmount || 0)
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                  lineNumber: 1923,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1914,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1885,
              columnNumber: 27
            }, this),
            (TableEnrolls?.length > 0 || borrowersData?.length > 0 || pigmeCustomerData?.length > 0) && !basicLoading ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                exportedPdfName: "Customer Ledger Report",
                exportedFileName: "Customer Ledger Report.csv",
                printHeaderKeys: [
                  "Customer Name",
                  "Customer Id",
                  "Phone Number",
                  "Ticket Number",
                  "Group Name"
                ],
                printHeaderValues: [
                  group.full_name,
                  group.customer_id,
                  group.phone_number,
                  EnrollGroupId.ticket,
                  groupDetails.group_name
                ],
                data: EnrollGroupId.groupId === "Loan" ? borrowersData : EnrollGroupId.groupId === "Pigme" ? pigmeCustomerData : TableEnrolls,
                columns: EnrollGroupId.groupId === "Loan" ? BasicLoanColumns : EnrollGroupId.groupId === "Pigme" ? BasicPigmeColumns : Basiccolumns
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1940,
                columnNumber: 31
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1939,
              columnNumber: 23
            }, this) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: basicLoading }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1974,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1813,
            columnNumber: 25
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1812,
            columnNumber: 19
          }, this),
          activeTab === "disbursement" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm  text-gray-700 font-bold", children: "Disbursement" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1982,
              columnNumber: 25
            }, this),
            disbursementLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1987,
              columnNumber: 21
            }, this) : filteredDisbursement?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: filteredDisbursement,
                columns: DisbursementColumns,
                exportedPdfName: `Customer Payout Report`,
                exportedFileName: `Customer Payout Report.csv`,
                printHeaderKeys: [
                  "Customer Name",
                  "Phone Number"
                ],
                printHeaderValues: [
                  group?.full_name,
                  group?.phone_number
                ]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
                lineNumber: 1990,
                columnNumber: 29
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 1989,
              columnNumber: 21
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-40  w-full flex justify-center items-center ", children: "No Disbursement Data Found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
              lineNumber: 2006,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
            lineNumber: 1981,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
          lineNumber: 1082,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
          lineNumber: 1081,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
        lineNumber: 1047,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
      lineNumber: 1043,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
    lineNumber: 1038,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
    lineNumber: 1037,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx",
    lineNumber: 1036,
    columnNumber: 5
  }, this);
};
_s(InActiveUserReport, "7DgmIS7SFFncmTI1O6uaoyR6/Ac=", false, function() {
  return [useSearchParams];
});
_c = InActiveUserReport;
export default InActiveUserReport;
var _c;
$RefreshReg$(_c, "InActiveUserReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/InActiveUserReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUVNLFNBeWlDZ0IsVUF6aUNoQjsyQkFyRU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx5QkFBeUI7QUFDaEMsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLDJCQUEyQjtBQUVwQyxNQUFNQyxxQkFBcUJBLE1BQU07QUFBQUMsS0FBQTtBQUMvQixRQUFNLENBQUNDLFlBQVksSUFBSVAsZ0JBQWdCO0FBQ3ZDLFFBQU1RLFNBQVNELGFBQWFFLElBQUksU0FBUztBQUN6QyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSW5CLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNvQixXQUFXQyxZQUFZLElBQUlyQixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDc0IsY0FBY0MsZUFBZSxJQUFJdkIsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3dCLGVBQWVDLGdCQUFnQixJQUFJekIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzBCLGVBQWVDLGdCQUFnQixJQUFJM0IsU0FBU2dCLFNBQVNBLFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUNZLE9BQU9DLFFBQVEsSUFBSTdCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUM4QixZQUFZQyxhQUFhLElBQUkvQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDZ0MsY0FBY0MsZUFBZSxJQUFJakMsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ2tDLGtCQUFrQkMsbUJBQW1CLElBQUluQyxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDb0MsZUFBZUMsZ0JBQWdCLElBQUlyQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDc0MsV0FBV0MsWUFBWSxJQUFJdkMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3dDLGVBQWVDLGdCQUFnQixJQUFJekMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzBDLHNCQUFzQkMsdUJBQXVCLElBQUkzQyxTQUFTLElBQUk7QUFDckUsUUFBTSxDQUFDNEMsVUFBVUMsV0FBVyxJQUFJN0MsU0FBUyxNQUFNO0FBQzdDLFVBQU04QyxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFdBQU9ELE1BQU1FLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3pDLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSW5ELFNBQVMsTUFBTTtBQUN6QyxVQUFNOEMsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixXQUFPRCxNQUFNRSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUN6QyxDQUFDO0FBQ0QsUUFBTSxDQUFDRyxhQUFhQyxjQUFjLElBQUlyRCxTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDc0QsZUFBZUMsZ0JBQWdCLElBQUl2RCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDd0QsbUJBQW1CQyxvQkFBb0IsSUFBSXpELFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUMwRCxnQkFBZ0JDLGdCQUFnQixJQUFJM0QsU0FBUyxLQUFLO0FBQ3pELFFBQU0sQ0FBQzRELGNBQWNDLGVBQWUsSUFBSTdELFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUM4RCxhQUFhQyxjQUFjLElBQUkvRCxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDZ0UsZUFBZUMsZ0JBQWdCLElBQUlqRSxTQUFTO0FBQUEsSUFDakRrRSxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSXJFLFNBQVM7QUFBQSxJQUNyRHNFLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsRUFDYixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUl6RSxTQUFTO0FBQUEsSUFDN0MwRSxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxFQUNSLENBQUM7QUFHRCxRQUFNQyxRQUFRQSxDQUFDLEVBQUVDLE9BQU9DLE1BQU0sTUFDNUIsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkJBQUMsV0FBTSxXQUFVLDBDQUEwQ0QsbUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUU7QUFBQSxJQUNqRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsYUFBYUE7QUFBQUEsUUFDYixPQUFPQyxTQUFTO0FBQUEsUUFDaEI7QUFBQSxRQUNBLFdBQVU7QUFBQTtBQUFBLE1BTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS29GO0FBQUEsT0FQdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBRUYsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSXZGLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN3RixXQUFXQyxZQUFZLElBQUl6RixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDMEYsYUFBYUMsY0FBYyxJQUFJM0YsU0FBUyxFQUFFO0FBRWpELFFBQU0sQ0FBQzRGLGdCQUFnQkMsaUJBQWlCLElBQUk3RixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDOEYsd0JBQXdCQyx5QkFBeUIsSUFBSS9GO0FBQUFBLElBQzFEZ0IsU0FBU0EsU0FBUztBQUFBLEVBQ3BCO0FBQ0EsUUFBTSxDQUFDZ0YsaUJBQWlCQyxrQkFBa0IsSUFBSWpHLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNrRyxXQUFXQyxZQUFZLElBQUluRyxTQUFTLENBQUMsQ0FBQztBQUU3QyxRQUFNLENBQUNvRyxjQUFjQyxlQUFlLElBQUlyRyxTQUFTLE1BQU07QUFDckQsVUFBTThDLFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsV0FBT0QsTUFBTUUsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDekMsQ0FBQztBQUNELFFBQU0sQ0FBQ3FELHFCQUFxQkMsc0JBQXNCLElBQUl2RyxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDd0csbUJBQW1CQyxvQkFBb0IsSUFBSXpHO0FBQUFBLElBQ2hEZ0IsU0FBU0EsU0FBUztBQUFBLEVBQ3BCO0FBQ0EsUUFBTSxDQUFDMEYsVUFBVUMsV0FBVyxJQUFJM0csU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQzRHLGtCQUFrQkMsbUJBQW1CLElBQUk3RyxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDOEcsZUFBZUMsZ0JBQWdCLElBQUkvRyxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDZ0gsV0FBV0MsWUFBWSxJQUFJakgsU0FBUyxjQUFjO0FBQ3pELFFBQU0sQ0FBQ2tILFlBQVlDLGFBQWEsSUFBSW5ILFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNvSCxjQUFjQyxlQUFlLElBQUlySCxTQUFTLEdBQUc7QUFDcEQsUUFBTSxDQUFDc0gsZUFBZUMsZ0JBQWdCLElBQUl2SCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDd0gsZ0JBQWdCQyxpQkFBaUIsSUFBSXpILFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUMwSCxtQkFBbUJDLG9CQUFvQixJQUFJM0gsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQzRILFNBQVNDLFVBQVUsSUFBSTdILFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUM4SCxtQkFBbUJDLG9CQUFvQixJQUFJL0gsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ2dJLGVBQWVDLGdCQUFnQixJQUFJakksU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2tJLFlBQVlDLGFBQWEsSUFBSW5JLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUNvSSxzQkFBc0JDLHVCQUF1QixJQUFJckksU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ3NJLHNCQUFzQkMsdUJBQXVCLElBQUl2SSxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDd0kscUJBQXFCQyxzQkFBc0IsSUFBSXpJLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUMwSSxvQkFBb0JDLHFCQUFxQixJQUFJM0ksU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQzRJLGtCQUFrQkMsbUJBQW1CLElBQUk3SSxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDOEkscUJBQXFCQyxzQkFBc0IsSUFBSS9JLFNBQVMsQ0FBQztBQUNoRSxRQUFNZ0osOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDOUIsa0JBQWM4QixFQUFFQyxPQUFPN0QsS0FBSztBQUFBLEVBQzlCO0FBQ0EsUUFBTThELGtCQUFrQkEsQ0FBQ0MsUUFBUTtBQUMvQm5DLGlCQUFhbUMsR0FBRztBQUFBLEVBQ2xCO0FBRUEsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUl0SixTQUFTO0FBQUEsSUFDdkN1SixVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RyRixRQUFRO0FBQUEsSUFDUnNGLFlBQVk7QUFBQSxJQUNaQyxVQUFVO0FBQUEsSUFDVnBGLFFBQVE7QUFBQSxJQUNScUYsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFFRCxRQUFNQyxtQkFBbUI7QUFBQSxJQUN2QixFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBRXZDLFFBQU1DLG9CQUFvQjtBQUFBLElBQ3hCLEVBQUVGLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLGVBQWU7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLGVBQWU7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFFdkMsUUFBTUUsc0JBQXNCO0FBQUEsSUFDMUIsRUFBRUgsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLFlBQVlDLFFBQVEsaUJBQWlCO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUVELEtBQUsscUJBQXFCQyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHdkNoSyxZQUFVLE1BQU07QUFDZCxVQUFNbUssdUJBQXVCLFlBQVk7QUFDdkMsVUFDRWxELGNBQWMsaUJBQ2R0RixpQkFDQXNDLGNBQWNFLFdBQ2RGLGNBQWNHLFVBQ2RILGNBQWNFLFlBQVksVUFDMUJGLGtCQUFrQixTQUNsQjtBQUNBLFlBQUk7QUFDRi9CLDBCQUFnQixFQUFFO0FBQ2xCTSx1QkFBYSxFQUFFO0FBQ2ZFLDJCQUFpQixFQUFFO0FBQ25Ca0csZ0NBQXNCLElBQUk7QUFDMUJFLDhCQUFvQixJQUFJO0FBQ3hCaEYsMEJBQWdCLElBQUk7QUFDcEJ4Qyx1QkFBYSxJQUFJO0FBRWpCLGdCQUFNOEksV0FBVyxNQUFNbEssSUFBSWdCO0FBQUFBLFlBQ3pCO0FBQUEsWUFDQTtBQUFBLGNBQ0VtSixRQUFRO0FBQUEsZ0JBQ05iLFVBQVV2RixjQUFjRTtBQUFBQSxnQkFDeEJDLFFBQVFILGNBQWNHO0FBQUFBLGdCQUN0QnFGLFNBQVM5SDtBQUFBQSxjQUNYO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFFQSxnQkFBTSxFQUFFZ0Ysc0JBQVcsSUFBSTJELG1CQUFtQixHQUFHLElBQUlGLFNBQVNHLFFBQVEsQ0FBQztBQUVuRS9ILHVCQUFhbUUsVUFBUyxDQUFDLEdBQUc2RCxtQkFBbUIsQ0FBQztBQUM5QzlILDJCQUFpQmlFLFVBQVMsQ0FBQyxHQUFHOEQsdUJBQXVCLENBQUM7QUFFdEQsY0FBSUMsVUFBVTtBQUNkLGdCQUFNQyxnQkFBZ0JoRSxVQUFTaUUsSUFBSSxDQUFDQyxTQUFTQyxVQUFVO0FBQ3JESix1QkFBV0ssT0FBT0YsUUFBUXRHLFVBQVUsQ0FBQztBQUNyQyxtQkFBTztBQUFBLGNBQ0x5RyxLQUFLSCxRQUFRRztBQUFBQSxjQUNiQyxJQUFJSCxRQUFRO0FBQUEsY0FDWkksTUFBTUMsY0FBY04sU0FBU2xCLFFBQVE7QUFBQSxjQUNyQ3BGLFFBQVFzRyxRQUFRdEc7QUFBQUEsY0FDaEI2RyxTQUFTUCxRQUFRbkI7QUFBQUEsY0FDakIyQixhQUFhUixRQUFRUztBQUFBQSxjQUNyQkMsTUFBTVYsUUFBUWpCO0FBQUFBLGNBQ2RjO0FBQUFBLFlBQ0Y7QUFBQSxVQUNGLENBQUM7QUFFRCxjQUFJYyxpQkFBaUI7QUFDckJsQiwyQkFBaUJtQixRQUFRLENBQUNDLFFBQVFDLFFBQVE7QUFDeENoQiwwQkFBY2lCLEtBQUs7QUFBQSxjQUNqQlgsSUFBSTtBQUFBLGNBQ0pDLE1BQU1RLE9BQU9sSCxZQUNULElBQUl4QixLQUFLMEksT0FBT2xILFNBQVMsRUFBRXFILG1CQUFtQixPQUFPLElBQ3JEO0FBQUEsY0FDSnRILFFBQVFtSCxPQUFPbkg7QUFBQUEsY0FDZjZHLFNBQVNNLE9BQU9oQztBQUFBQSxjQUNoQjJCLGFBQWE7QUFBQSxjQUNiRSxNQUFNRyxPQUFPSSxXQUFXO0FBQUEsY0FDeEJwQixTQUFTO0FBQUEsWUFDWCxDQUFDO0FBRURjLDhCQUFrQlQsT0FBT1csT0FBT25ILFVBQVUsQ0FBQztBQUFBLFVBQzdDLENBQUM7QUFFRHFFLGdDQUFzQjRDLGNBQWM7QUFFcEMsY0FBSWxCLGlCQUFpQnlCLFNBQVMsR0FBRztBQUMvQmpEO0FBQUFBLGNBQ0V3QixpQkFBaUIsQ0FBQyxHQUFHOUYsWUFDakIsSUFBSXhCLEtBQUtzSCxpQkFBaUIsQ0FBQyxFQUFFOUYsU0FBUyxFQUFFcUg7QUFBQUEsZ0JBQ3hDO0FBQUEsY0FDRixJQUNFO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFFQSxjQUFJbEIsY0FBY29CLFNBQVMsR0FBRztBQUM1QnBCLDBCQUFjaUIsS0FBSztBQUFBLGNBQ2pCWCxJQUFJO0FBQUEsY0FDSkMsTUFBTTtBQUFBLGNBQ04zRyxRQUFRO0FBQUEsY0FDUjZHLFNBQVM7QUFBQSxjQUNUQyxhQUFhO0FBQUEsY0FDYkUsTUFBTTtBQUFBLGNBQ05iO0FBQUFBLFlBQ0YsQ0FBQztBQUNEMUIsbUNBQXVCMEIsT0FBTztBQUFBLFVBQ2hDLE9BQU87QUFDTDFCLG1DQUF1QixDQUFDO0FBQUEsVUFDMUI7QUFFQTlHLDBCQUFnQnlJLGFBQWE7QUFBQSxRQUMvQixTQUFTcUIsT0FBTztBQUNkQyxrQkFBUUQsTUFBTSxpREFBaURBLEtBQUs7QUFDcEU5SiwwQkFBZ0IsRUFBRTtBQUNsQk0sdUJBQWEsRUFBRTtBQUNmRSwyQkFBaUIsRUFBRTtBQUNuQmtHLGdDQUFzQixJQUFJO0FBQzFCRSw4QkFBb0IsSUFBSTtBQUFBLFFBQzFCLFVBQUM7QUFDQ2hGLDBCQUFnQixLQUFLO0FBQ3JCeEMsdUJBQWEsS0FBSztBQUFBLFFBQ3BCO0FBQUEsTUFDRixPQUFPO0FBQ0xZLHdCQUFnQixFQUFFO0FBQ2xCTSxxQkFBYSxFQUFFO0FBQ2ZFLHlCQUFpQixFQUFFO0FBQ25Ca0csOEJBQXNCLElBQUk7QUFDMUJFLDRCQUFvQixJQUFJO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBRUFxQix5QkFBcUI7QUFBQSxFQUN2QixHQUFHLENBQUNsRCxXQUFXdEYsZUFBZXNDLGNBQWNFLFNBQVNGLGNBQWNHLE1BQU0sQ0FBQztBQWtEMUVwRSxZQUFVLE1BQU07QUFDZCxVQUFNa00sMkJBQTJCLFlBQVk7QUFDM0NoRSx1QkFBaUIsRUFBRTtBQUNuQnBFLHNCQUFnQixJQUFJO0FBRXBCLFVBQUk7QUFFRixjQUFNcUksZUFBZTVFLGVBQWU2RSxjQUFjQztBQUFBQSxVQUNoRCxDQUFDQyxTQUFTQSxNQUFNQyxjQUFjRCxNQUFNdEIsUUFBUS9HLGNBQWNHO0FBQUFBLFFBQzVEO0FBQ0EsY0FBTW9JLFNBQ0pMLGNBQWNJLGNBQWNELE1BQU10QixPQUFPL0csY0FBY0c7QUFFekQsY0FBTWdHLFdBQVcsTUFBTWxLLElBQUlnQjtBQUFBQSxVQUN6Qix1Q0FBdUNzTCxNQUFNO0FBQUEsUUFDL0M7QUFFQSxZQUFJcEMsU0FBU0csTUFBTXdCLFNBQVMsR0FBRztBQUM3QixjQUFJckIsVUFBVTtBQUNkLGdCQUFNQyxnQkFBZ0JQLFNBQVNHLEtBQUtLLElBQUksQ0FBQzZCLGFBQWEzQixVQUFVO0FBQzlESix1QkFBV0ssT0FBTzBCLFlBQVlsSSxNQUFNO0FBQ3BDLG1CQUFPO0FBQUEsY0FDTHlHLEtBQUt5QixZQUFZekI7QUFBQUEsY0FDakJDLElBQUlILFFBQVE7QUFBQSxjQUNabkIsVUFBVXdCLGNBQWNzQixhQUFhOUMsUUFBUTtBQUFBLGNBQzdDcEYsUUFBUWtJLFlBQVlsSTtBQUFBQSxjQUNwQm1GLFlBQVkrQyxZQUFZL0M7QUFBQUEsY0FDeEJFLFVBQVU2QyxZQUFZN0M7QUFBQUEsY0FDdEJjO0FBQUFBLFlBQ0Y7QUFBQSxVQUNGLENBQUM7QUFDREMsd0JBQWNpQixLQUFLO0FBQUEsWUFDakJaLEtBQUs7QUFBQSxZQUNMQyxJQUFJO0FBQUEsWUFDSnRCLFVBQVU7QUFBQSxZQUNWRCxZQUFZO0FBQUEsWUFDWm5GLFFBQVE7QUFBQSxZQUNScUYsVUFBVTtBQUFBLFlBQ1ZjO0FBQUFBLFVBQ0YsQ0FBQztBQUNEeEMsMkJBQWlCeUMsYUFBYTtBQUFBLFFBQ2hDLE9BQU87QUFDTHpDLDJCQUFpQixFQUFFO0FBQUEsUUFDckI7QUFBQSxNQUNGLFNBQVM4RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHFDQUFxQ0EsS0FBSztBQUN4RDlELHlCQUFpQixFQUFFO0FBQUEsTUFDckIsVUFBQztBQUNDcEUsd0JBQWdCLEtBQUs7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFFQSxRQUFJRyxjQUFjRSxZQUFZLFVBQVVGLGNBQWNHO0FBQ3BEOEgsK0JBQXlCO0FBQUEsRUFDN0IsR0FBRyxDQUFDakksY0FBY0csTUFBTSxDQUFDO0FBRXpCcEUsWUFBVSxNQUFNO0FBQ2QsVUFBTTBNLDRCQUE0QixZQUFZO0FBQzVDOUUsMkJBQXFCLEVBQUU7QUFDdkI5RCxzQkFBZ0IsSUFBSTtBQUVwQixVQUFJO0FBQ0YsY0FBTXNHLFdBQVcsTUFBTWxLLElBQUlnQjtBQUFBQSxVQUN6QiwrQ0FBK0MrQyxjQUFjRyxNQUFNO0FBQUEsUUFDckU7QUFFQSxZQUFJZ0csU0FBU0csUUFBUUgsU0FBU0csS0FBS3dCLFNBQVMsR0FBRztBQUM3QyxjQUFJckIsVUFBVTtBQUNkLGdCQUFNQyxnQkFBZ0JQLFNBQVNHLEtBQUtLLElBQUksQ0FBQytCLGNBQWM3QixVQUFVO0FBQy9ESix1QkFBV0ssT0FBTzRCLGFBQWFwSSxNQUFNO0FBQ3JDLG1CQUFPO0FBQUEsY0FDTHlHLEtBQUsyQixhQUFhM0I7QUFBQUEsY0FDbEJDLElBQUlILFFBQVE7QUFBQSxjQUNabkIsVUFBVXdCLGNBQWN3QixjQUFjaEQsUUFBUTtBQUFBLGNBQzlDcEYsUUFBUW9JLGFBQWFwSTtBQUFBQSxjQUNyQm1GLFlBQVlpRCxhQUFhakQ7QUFBQUEsY0FDekJFLFVBQVUrQyxhQUFhL0M7QUFBQUEsY0FDdkJjO0FBQUFBLFlBQ0Y7QUFBQSxVQUNGLENBQUM7QUFDREMsd0JBQWNpQixLQUFLO0FBQUEsWUFDakJaLEtBQUs7QUFBQSxZQUNMQyxJQUFJO0FBQUEsWUFDSnRCLFVBQVU7QUFBQSxZQUNWRCxZQUFZO0FBQUEsWUFDWm5GLFFBQVE7QUFBQSxZQUNScUYsVUFBVTtBQUFBLFlBQ1ZjO0FBQUFBLFVBQ0YsQ0FBQztBQUNEOUMsK0JBQXFCK0MsYUFBYTtBQUFBLFFBQ3BDLE9BQU87QUFDTC9DLCtCQUFxQixFQUFFO0FBQUEsUUFDekI7QUFBQSxNQUNGLFNBQVNvRSxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHNDQUFzQ0EsS0FBSztBQUN6RHBFLDZCQUFxQixFQUFFO0FBQUEsTUFDekIsVUFBQztBQUNDOUQsd0JBQWdCLEtBQUs7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFFQSxRQUFJRyxjQUFjRSxZQUFZLFFBQVN1SSwyQkFBMEI7QUFBQSxFQUNuRSxHQUFHLENBQUN6SSxjQUFjRyxNQUFNLENBQUM7QUFFekJwRSxZQUFVLE1BQU07QUFDZCxVQUFNNE0saUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGLGNBQU14QyxXQUFXLE1BQU1sSyxJQUFJZ0I7QUFBQUEsVUFDekIsMEJBQTBCK0MsY0FBY0UsT0FBTztBQUFBLFFBQ2pEO0FBQ0EsWUFBSWlHLFNBQVN5QyxVQUFVLElBQUssT0FBTSxJQUFJQyxNQUFNLFdBQVc7QUFDdkR4Rix3QkFBZ0I4QyxTQUFTRyxJQUFJO0FBQUEsTUFDL0IsU0FBU3dDLEtBQUs7QUFDWmQsZ0JBQVFlLElBQUksd0NBQXdDRCxJQUFJRSxPQUFPO0FBQUEsTUFDakU7QUFBQSxJQUNGO0FBQ0EsUUFBSWhKLGNBQWNFLFlBQVksVUFBVUYsY0FBY0UsWUFBWTtBQUNoRXlJLHFCQUFlO0FBQUEsRUFDbkIsR0FBRyxDQUFDM0ksZUFBZUcsTUFBTSxDQUFDO0FBRTFCcEUsWUFBVSxNQUFNO0FBQ2RnSCxxQkFBaUIsSUFBSTtBQUVyQixVQUFNa0csY0FBYyxZQUFZO0FBQzlCdEosdUJBQWlCLElBQUk7QUFDckIsVUFBSTtBQUNGLGNBQU13RyxXQUFXLE1BQU1sSyxJQUFJZ0IsSUFBSSxnQkFBZ0I7QUFDL0NFLGtCQUFVZ0osU0FBU0csSUFBSTtBQUN2QnZELHlCQUFpQixLQUFLO0FBQ3RCcEQseUJBQWlCLEtBQUs7QUFBQSxNQUN4QixTQUFTb0ksT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRCxVQUFDO0FBQ0NwSSx5QkFBaUIsS0FBSztBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUNBc0osZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMbE4sWUFBVSxNQUFNO0FBQ2QsVUFBTW1OLGdCQUFnQixZQUFZO0FBQ2hDLFVBQUk7QUFDRjNGLHlCQUFpQixFQUFFO0FBQ25CLGNBQU00QyxXQUFXLE1BQU1sSyxJQUFJZ0IsSUFBSSxzQkFBc0JTLGFBQWEsRUFBRTtBQUNwRSxZQUFJeUksU0FBU0csTUFBTTtBQUNqQixnQkFBTWxDLHdCQUF1QitCLFNBQVNHLE1BQU02QixjQUFjeEI7QUFBQUEsWUFDeEQsQ0FBQzBCLE1BQU14QixXQUFXO0FBQUEsY0FDaEJzQyxPQUFPdEMsUUFBUTtBQUFBLGNBQ2Z3QixNQUFNQSxNQUFNQyxjQUFjRCxNQUFNZTtBQUFBQSxjQUNoQ0MsYUFBYWhCLE1BQU1pQjtBQUFBQSxjQUNuQkMsUUFBUWxCLE1BQU1DLGNBQWNELE1BQU1rQjtBQUFBQSxjQUNsQ0MsZ0JBQWdCbkIsTUFBTUMsY0FBY0QsTUFBTW9CO0FBQUFBLGNBQzFDQyxtQkFBbUJyQixNQUFNcUI7QUFBQUEsY0FDekJqRCxTQUFTNEIsTUFBTTVCO0FBQUFBLFlBQ2pCO0FBQUEsVUFDRjtBQUNBcEMsa0NBQXdCRCxxQkFBb0I7QUFBQSxRQUM5QztBQUNBYix5QkFBaUI0QyxTQUFTRyxJQUFJO0FBRTlCLFlBQUlILFNBQVN5QyxVQUFVLElBQUssT0FBTSxJQUFJQyxNQUFNLHdCQUF3QjtBQUFBLE1BQ3RFLFNBQVNDLEtBQUs7QUFDWmQsZ0JBQVFlLElBQUksa0NBQWtDRCxJQUFJRSxPQUFPO0FBQ3pEM0UsZ0NBQXdCLEVBQUU7QUFBQSxNQUM1QjtBQUFBLElBQ0Y7QUFDQUoscUJBQWlCLEVBQUU7QUFDbkJFLGtCQUFjLElBQUk7QUFDbEIrRSxrQkFBYztBQUFBLEVBQ2hCLEdBQUcsQ0FBQ3hMLGFBQWEsQ0FBQztBQUVsQjNCLFlBQVUsTUFBTTtBQUNkLFVBQU00TixhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGbEcsMEJBQWtCLEVBQUU7QUFDcEIsY0FBTTBDLFdBQVcsTUFBTWxLLElBQUlnQixJQUFJLHVCQUF1QlMsYUFBYSxFQUFFO0FBQ3JFc0ssZ0JBQVE0QixLQUFLekQsU0FBU0csTUFBTSxPQUFPO0FBQ25DLFlBQUlILFNBQVNHLE1BQU07QUFDakIsZ0JBQU14QyxxQkFBb0JxQyxTQUFTRyxNQUFNdUQsZUFBZWxEO0FBQUFBLFlBQ3RELENBQUNtRCxPQUFPakQsV0FBVztBQUFBLGNBQ2pCc0MsT0FBT3RDLFFBQVE7QUFBQSxjQUNmaUQsT0FBT0EsT0FBT0MsZUFBZUQsT0FBT0U7QUFBQUEsY0FDcENDLFlBQ0VILE9BQU9DLGVBQWVELE9BQU9HLFlBQVloTCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsY0FDdkRpTCxVQUFVSixPQUFPQyxlQUFlRCxPQUFPSTtBQUFBQSxjQUN2Q0MsbUJBQW1CTCxPQUFPQyxlQUFlRCxPQUFPSztBQUFBQSxjQUNoREMsd0JBQXdCTixPQUFPTTtBQUFBQSxZQUNqQztBQUFBLFVBQ0Y7QUFDQXJHLCtCQUFxQkQsa0JBQWlCO0FBQUEsUUFDeEM7QUFDQUwsMEJBQWtCMEMsU0FBU0csSUFBSTtBQUUvQixZQUFJSCxTQUFTeUMsVUFBVSxJQUFLLE9BQU0sSUFBSUMsTUFBTSx3QkFBd0I7QUFBQSxNQUN0RSxTQUFTQyxLQUFLO0FBQ1pkLGdCQUFRZSxJQUFJLG1DQUFtQ0QsSUFBSUUsT0FBTztBQUMxRGpGLDZCQUFxQixFQUFFO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQ0FKLHlCQUFxQixFQUFFO0FBQ3ZCRSxlQUFXLElBQUk7QUFDZjhGLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQ2pNLGFBQWEsQ0FBQztBQUVsQjNCLFlBQVUsTUFBTTtBQUNkLFVBQU1rTixjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU05QyxXQUFXLE1BQU1sSyxJQUFJZ0IsSUFBSSx3QkFBd0JTLGFBQWEsRUFBRTtBQUN0RUcsaUJBQVNzSSxTQUFTRyxJQUFJO0FBQUEsTUFDeEIsU0FBU3lCLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FrQixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDdkwsYUFBYSxDQUFDO0FBRWxCM0IsWUFBVSxNQUFNO0FBQ2QsVUFBTWtOLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTTlDLFdBQVcsTUFBTWxLLElBQUlnQixJQUFJLGdCQUFnQjtBQUMvQ29CLHlCQUFpQjhILFNBQVNHLElBQUk7QUFBQSxNQUNoQyxTQUFTeUIsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQWtCLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFHTGxOLFlBQVUsTUFBTTtBQUNkLFVBQU1zTyxvQkFBb0IsWUFBWTtBQUNwQyxVQUFJO0FBQ0Y1RiwrQkFBdUIsSUFBSTtBQUMzQixjQUFNMEIsV0FBVyxNQUFNbEssSUFBSWdCO0FBQUFBLFVBQ3pCO0FBQUEsVUFDQTtBQUFBLFlBQ0VtSixRQUFRO0FBQUEsY0FDTnBKLFFBQVFVO0FBQUFBLFlBQ1Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUVBLFlBQUl5SSxTQUFTRyxNQUFNO0FBQ2pCLGdCQUFNSSxnQkFBZ0JQLFNBQVNHLEtBQUtLLElBQUksQ0FBQ0MsU0FBU0MsVUFBVTtBQUMxRCxnQkFBSUosVUFBVTtBQUVkQSx1QkFBV0ssT0FBT0YsUUFBUXRHLE1BQU07QUFDaEMsbUJBQU87QUFBQSxjQUNMeUcsS0FBS0gsUUFBUUc7QUFBQUEsY0FDYkMsSUFBSUgsUUFBUTtBQUFBLGNBQ1p5RCxtQkFBbUIxRCxRQUFRMEQ7QUFBQUEsY0FDM0JDLFlBQVkzRCxTQUFTckIsVUFBVWdGO0FBQUFBLGNBQy9CN0UsVUFBVXdCLGNBQWNOLFNBQVNsQixRQUFRO0FBQUEsY0FDekN2RixRQUFReUcsUUFBUXpHO0FBQUFBLGNBQ2hCcUssa0JBQWtCdEQsY0FBY04sUUFBUXJHLFNBQVM7QUFBQSxjQUNqREQsUUFBUXNHLFFBQVF0RztBQUFBQSxjQUNoQm1GLFlBQVltQixRQUFRbkI7QUFBQUEsY0FDcEJFLFVBQVVpQixRQUFRakI7QUFBQUEsY0FDbEI4RSxjQUFjN0QsUUFBUThELFlBQVlDO0FBQUFBLGNBQ2xDbEU7QUFBQUEsWUFDRjtBQUFBLFVBQ0YsQ0FBQztBQUVEbEMsa0NBQXdCbUMsYUFBYTtBQUFBLFFBQ3ZDLE9BQU87QUFDTG5DLGtDQUF3QixFQUFFO0FBQUEsUUFDNUI7QUFBQSxNQUNGLFNBQVN3RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG9DQUFvQ0EsT0FBT0EsTUFBTWlCLE9BQU87QUFDdEV6RSxnQ0FBd0IsRUFBRTtBQUFBLE1BQzVCLFVBQUM7QUFDQ0UsK0JBQXVCLEtBQUs7QUFBQSxNQUM5QjtBQUFBLElBQ0Y7QUFDQSxRQUFJL0csY0FBZTJNLG1CQUFrQjtBQUFBLEVBQ3ZDLEdBQUcsQ0FBQzNNLGFBQWEsQ0FBQztBQUVsQixRQUFNa04scUJBQXFCLE9BQU8xSyxZQUFZO0FBQzVDNkIsOEJBQTBCN0IsT0FBTztBQUNqQ3ZDLHFCQUFpQnVDLE9BQU87QUFDeEIySyw2QkFBeUIzSyxPQUFPO0FBQUEsRUFDbEM7QUFDQW5FLFlBQVUsTUFBTTtBQUNkLFFBQUlpQixRQUFRO0FBQ1Y0Tix5QkFBbUI1TixNQUFNO0FBQUEsSUFDM0I7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUNMLFFBQU04TixvQkFBb0JBLENBQUNDLFVBQVU7QUFDbkMsVUFBTTFKLFFBQVEwSixNQUFNN0YsT0FBTzdEO0FBRTNCLFFBQUlBLE9BQU87QUFDVCxZQUFNLENBQUNuQixTQUFTQyxNQUFNLElBQUlrQixNQUFNcEMsTUFBTSxHQUFHO0FBQ3pDZ0IsdUJBQWlCLEVBQUVDLFNBQVNDLE9BQU8sQ0FBQztBQUFBLElBQ3RDLE9BQU87QUFDTEYsdUJBQWlCLEVBQUVDLFNBQVMsSUFBSUMsUUFBUSxHQUFHLENBQUM7QUFBQSxJQUM5QztBQUNBNkgsWUFBUTRCLEtBQUs1RixlQUFlLCtCQUErQjtBQUMzRGdFLFlBQVE0QixLQUFLNUosY0FBY0UsU0FBUyxvQ0FBb0M7QUFBQSxFQUMxRTtBQUVBbkUsWUFBVSxNQUFNO0FBQ2QsVUFBTWlQLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixZQUFJLENBQUNsSix1QkFBd0I7QUFFN0IsY0FBTXFFLFdBQVcsTUFBTWxLLElBQUlnQjtBQUFBQSxVQUN6QixrQkFBa0I2RSxzQkFBc0I7QUFBQSxRQUMxQztBQUNBa0csZ0JBQVE0QixLQUFLekQsU0FBU0csS0FBSzVELFVBQVUsMkJBQTJCO0FBQ2hFL0QsZ0NBQXdCd0gsU0FBU0csS0FBSzVELFFBQVE7QUFBQSxNQUNoRCxTQUFTcUYsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxnREFBZ0RBLEtBQUs7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFDQWlELDZCQUF5QjtBQUFBLEVBQzNCLEdBQUcsQ0FBQ2xKLHNCQUFzQixDQUFDO0FBRTNCL0Y7QUFBQUEsSUFBVSxNQUFNO0FBQ2QsWUFBTWtQLGdCQUFnQixZQUFZO0FBQ2hDLFlBQUk7QUFDRixnQkFBTTlFLFdBQVcsTUFBTWxLLElBQUlnQixJQUFJLGlDQUFpQztBQUFBLFlBQzlEbUosUUFBUTtBQUFBLGNBQ05WLFVBQVV0RDtBQUFBQSxjQUNWbEMsU0FBUzRCO0FBQUFBLGNBQ1Q5RSxRQUFRd0Y7QUFBQUEsY0FDUm1ELFVBQVVyRDtBQUFBQSxZQUNaO0FBQUEsVUFDRixDQUFDO0FBRUQsY0FBSTZELFNBQVNHLFFBQVFILFNBQVNHLEtBQUt3QixTQUFTLEdBQUc7QUFDN0M3RiwrQkFBbUJrRSxRQUFRO0FBQzNCLGtCQUFNK0UsY0FBYy9FLFNBQVNHO0FBQzdCLGtCQUFNbEgsZUFBYzhMLFlBQVlDO0FBQUFBLGNBQzlCLENBQUNDLEtBQUt4RSxZQUFZd0UsTUFBTXRFLE9BQU9GLFFBQVF0RyxVQUFVLENBQUM7QUFBQSxjQUNsRDtBQUFBLFlBQ0Y7QUFDQXFDLHdCQUFZdkQsWUFBVztBQUN2QixrQkFBTXNILGdCQUFnQlAsU0FBU0csS0FBS0ssSUFBSSxDQUFDL0ksUUFBT2lKLFdBQVc7QUFBQSxjQUN6REcsSUFBSUgsUUFBUTtBQUFBLGNBQ1pqSixPQUFPQSxPQUFNMkgsU0FBU2dGO0FBQUFBLGNBQ3RCSSxNQUFNL00sT0FBTTRILFNBQVM2RjtBQUFBQSxjQUNyQkMsY0FBYzFOLE9BQU00SCxRQUFROEY7QUFBQUEsY0FDNUJuTCxRQUFRdkMsT0FBTXVDO0FBQUFBLGNBQ2RHLFFBQVExQyxPQUFNMEM7QUFBQUEsY0FDZGlMLE1BQU0zTixPQUFNK0g7QUFBQUEsWUFDZCxFQUFFO0FBQ0ZwSSw0QkFBZ0JtSixhQUFhO0FBQUEsVUFDL0IsT0FBTztBQUNMekUsK0JBQW1CLEVBQUU7QUFBQSxVQUN2QjtBQUFBLFFBQ0YsU0FBUzhGLE9BQU87QUFDZEMsa0JBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EOUYsNkJBQW1CLEVBQUU7QUFDckJVLHNCQUFZLENBQUM7QUFBQSxRQUNmO0FBQUEsTUFDRjtBQUVBc0ksb0JBQWM7QUFBQSxJQUNoQjtBQUFBLElBQUc7QUFBQSxNQUNEbko7QUFBQUEsTUFDQU07QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFBaUI7QUFBQSxFQUNsQjtBQUNELFFBQU1nSixjQUFjO0FBQUEsSUFDbEIsRUFBRTFGLEtBQUssU0FBU0MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLFVBQVU7QUFBQSxJQUNqQyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVELEtBQUssa0JBQWtCQyxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsb0JBQW9CO0FBQUEsSUFDeEQsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBR3ZDLFFBQU0wRixlQUFlO0FBQUEsSUFDbkIsRUFBRTNGLEtBQUssU0FBU0MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRUQsS0FBSyxTQUFTQyxRQUFRLFdBQVc7QUFBQSxJQUNuQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsVUFBVTtBQUFBLElBQzlDLEVBQUVELEtBQUssMEJBQTBCQyxRQUFRLHlCQUF5QjtBQUFBLEVBQUM7QUFHckUsUUFBTThFLDJCQUEyQixPQUFPM0ssWUFBWTtBQUNsRCtCLHVCQUFtQixFQUFFO0FBQ3JCLFFBQUkvQixTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU1pRyxXQUFXLE1BQU1sSyxJQUFJeVA7QUFBQUEsVUFDekIsK0JBQStCeEwsT0FBTztBQUFBLFFBQ3hDO0FBRUEsWUFBSWlHLFNBQVNHLFFBQVFILFNBQVNHLEtBQUt3QixTQUFTLEdBQUc7QUFDN0M3Riw2QkFBbUJrRSxTQUFTRyxJQUFJO0FBR2hDLGdCQUFNSSxnQkFBZ0JQLFNBQVNHLEtBQzVCSyxJQUFJLENBQUMvSSxRQUFPaUosVUFBVTtBQUNyQixrQkFBTThFLFlBQVkvTixRQUFPZ08sWUFBWWhPLE9BQU8yTSxjQUFjO0FBQzFELGtCQUFNc0IsVUFBVWpPLFFBQU9nTyxZQUFZQyxXQUFXO0FBQzlDLGtCQUFNQyxZQUFZbE8sUUFBT2dPLFlBQVloTyxPQUFPbU87QUFDNUMsa0JBQU1DLGVBQ0pDLFNBQVNyTyxRQUFPZ08sWUFBWWhPLE9BQU9zTyxhQUFhLEtBQUs7QUFDdkQsa0JBQU1DLGVBQWVGLFNBQVNyTyxRQUFPd08sU0FBU0QsWUFBWSxLQUFLO0FBQy9ELGtCQUFNRSxtQkFBa0J6TyxRQUFPOEUsVUFBVTJKLG1CQUFtQjtBQUM1RCxrQkFBTUMsZUFBYzFPLFFBQU8yTyxRQUFRRCxlQUFlO0FBQ2xELGtCQUFNRSxlQUFlNU8sUUFBTzZPLFNBQVNELGdCQUFnQjtBQUNyRCxrQkFBTUUsb0JBQ0o5TyxRQUFPK08sY0FBY0QscUJBQXFCO0FBRTVDLGdCQUFJLENBQUM5TyxRQUFPZ08sWUFBWWhPLE9BQU87QUFDN0IscUJBQU87QUFBQSxZQUNUO0FBRUEsbUJBQU87QUFBQSxjQUNMb0osSUFBSUgsUUFBUTtBQUFBLGNBQ1pqSixPQUFPK047QUFBQUEsY0FDUHhMLFFBQVEwTDtBQUFBQSxjQUVSZSxhQUNFZCxjQUFjLFdBQ1ZFLGVBQWVHLGVBQWVILGVBQzlCUSxlQUFlUixlQUFlTTtBQUFBQSxjQUVwQ0MsUUFBUUQ7QUFBQUEsY0FFUk8sZ0JBQ0VmLGNBQWMsV0FDVkUsZUFBZUcsZUFBZUgsZUFDOUJRLGVBQWVSLGVBQWVVO0FBQUFBLGNBRXBDSSxZQUFZVDtBQUFBQSxjQUVaNUYsU0FDRXFGLGNBQWMsV0FDVkUsZUFBZUcsZUFDakJILGVBQ0FLLG1CQUNFRyxlQUNGUixlQUNBVSxvQkFDQUw7QUFBQUEsY0FDSlUsZUFBZW5QLFFBQU9nTyxZQUFZbUIsaUJBQWlCO0FBQUEsY0FDbkRDLGVBQWVwUCxRQUFPZ08sWUFBWW9CLGlCQUFpQjtBQUFBLGNBQ25EQyxtQkFDRXJQLFFBQU9nTyxZQUFZcUIscUJBQXFCO0FBQUEsY0FDMUNDLGlCQUFpQnRQLFFBQU9nTyxZQUFZc0IsbUJBQW1CO0FBQUEsY0FDdkRDLGdCQUFnQnZQLFFBQU9nTyxZQUFZdUIsa0JBQWtCO0FBQUEsY0FDckRDLFVBQ0V4UCxRQUFPZ08sWUFBWXdCLGFBQWEsT0FDNUIsV0FDQTtBQUFBLFlBQ1I7QUFBQSxVQUNGLENBQUMsRUFDQUMsT0FBTyxDQUFDQyxTQUFTQSxTQUFTLElBQUksRUFDOUJELE9BQU8sQ0FBQ0MsU0FBU0EsS0FBS0osb0JBQW9CLFdBQVc7QUFDeER6UCwyQkFBaUJpSixhQUFhO0FBQzlCM0ksd0JBQWMsQ0FBQztBQUNmLGdCQUFNeUksc0JBQXNCRSxjQUN6QjJHLE9BQU8sQ0FBQ0UsWUFBWUEsUUFBUUwsb0JBQW9CLFdBQVcsRUFDM0QvQixPQUFPLENBQUNDLEtBQUt4TixXQUFVO0FBQ3RCLG1CQUFPd04sT0FBT3hOLFFBQU9nUCxlQUFlO0FBQUEsVUFDdEMsR0FBRyxDQUFDO0FBQ05yTCwyQkFBaUJpRixtQkFBbUI7QUFFcEMsZ0JBQU1nSCx5QkFBeUI5RyxjQUM1QjJHLE9BQU8sQ0FBQ0UsWUFBWUEsUUFBUUwsb0JBQW9CLFdBQVcsRUFDM0QvQixPQUFPLENBQUNDLEtBQUt4TixXQUFVO0FBQ3RCLG1CQUFPd04sT0FBT3hOLFFBQU9pUCxrQkFBa0I7QUFBQSxVQUN6QyxHQUFHLENBQUM7QUFDTmhMLDRCQUFrQjJMLHNCQUFzQjtBQUV4QyxnQkFBTW5CLGtCQUFrQjNGLGNBQ3JCMkcsT0FBTyxDQUFDRSxZQUFZQSxRQUFRTCxvQkFBb0IsV0FBVyxFQUMzRC9CLE9BQU8sQ0FBQ0MsS0FBS3hOLFdBQVV3TixPQUFPeE4sUUFBT2tQLGNBQWMsSUFBSSxDQUFDO0FBQzNEckwsdUJBQWE0SyxlQUFlO0FBRTVCLGdCQUFNQyxjQUFjNUYsY0FDakIyRyxPQUFPLENBQUNFLFlBQVlBLFFBQVFMLG9CQUFvQixXQUFXLEVBQzNEL0IsT0FBTyxDQUFDQyxLQUFLeE4sV0FBVXdOLE9BQU94TixRQUFPMk8sVUFBVSxJQUFJLENBQUM7QUFDdkQ1Syx5QkFBZTJLLFdBQVc7QUFBQSxRQUM1QixPQUFPO0FBQ0xySyw2QkFBbUIsRUFBRTtBQUNyQmxFLHdCQUFjLENBQUM7QUFBQSxRQUNqQjtBQUFBLE1BQ0YsU0FBU2dLLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REOUYsMkJBQW1CLEVBQUU7QUFDckJsRSxzQkFBYyxDQUFDO0FBQUEsTUFDakI7QUFBQSxJQUNGLE9BQU87QUFDTGtFLHlCQUFtQixFQUFFO0FBQ3JCbEUsb0JBQWMsQ0FBQztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUNBaEMsWUFBVSxNQUFNO0FBQ2QsUUFBSWlCLFFBQVE7QUFDVjZOLCtCQUF5QjdOLE1BQU07QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBQ0wsUUFBTXlRLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUUzSCxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVELEtBQUssa0JBQWtCQyxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVELEtBQUssU0FBU0MsUUFBUSxhQUFhO0FBQUEsSUFDckMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGlCQUFpQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLGlCQUFpQkMsUUFBUSxjQUFjO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsb0JBQW9CO0FBQUEsSUFDeEQsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLFlBQVk7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsb0JBQW9CO0FBQUEsSUFDbEQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsRUFBQztBQUd2QyxRQUFNbUIsZ0JBQWdCQSxDQUFDd0csZUFBZTtBQUNwQyxVQUFNekcsT0FBTyxJQUFJbEksS0FBSzJPLFVBQVU7QUFDaEMsV0FBT3pHLEtBQUtqSSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUN4QztBQUVBbEQsWUFBVSxNQUFNO0FBQ2QsVUFBTTRSLGNBQWMsWUFBWTtBQUM5QjFQLHNCQUFnQixFQUFFO0FBQ2xCNEIsc0JBQWdCLElBQUk7QUFFcEIsVUFBSTtBQUNGeEMscUJBQWEsSUFBSTtBQUNqQixjQUFNOEksV0FBVyxNQUFNbEssSUFBSWdCO0FBQUFBLFVBQ3pCLHFDQUFxQytDLGNBQWNFLE9BQU8sV0FBV0YsY0FBY0csTUFBTSxZQUFZekMsYUFBYTtBQUFBLFFBQ3BIO0FBRUEsWUFBSXlJLFNBQVNHLFFBQVFILFNBQVNHLEtBQUt3QixTQUFTLEdBQUc7QUFDN0N6SiwyQkFBaUI4SCxTQUFTRyxJQUFJO0FBRTlCLGdCQUFNc0gsT0FBT3pILFNBQVNHO0FBQ3RCL0gsdUJBQWFxUCxLQUFLLENBQUMsRUFBRXJILGVBQWU7QUFFcEMsZ0JBQU1zSCxXQUFXMUgsU0FBU0c7QUFDMUI3SCwyQkFBaUJvUCxTQUFTLENBQUMsRUFBRXJILG1CQUFtQjtBQUVoRCxjQUFJQyxVQUFVO0FBQ2QsZ0JBQU1DLGdCQUFnQlAsU0FBU0csS0FBS0ssSUFBSSxDQUFDL0ksUUFBT2lKLFVBQVU7QUFDeERKLHVCQUFXSyxPQUFPbEosT0FBTTBDLE1BQU07QUFDOUIsbUJBQU87QUFBQSxjQUNMeUcsS0FBS25KLE9BQU1tSjtBQUFBQSxjQUNYQyxJQUFJSCxRQUFRO0FBQUEsY0FDWkksTUFBTUMsY0FBY3RKLFFBQU84SCxRQUFRO0FBQUEsY0FDbkNwRixRQUFRMUMsT0FBTTBDO0FBQUFBLGNBQ2Q2RyxTQUFTdkosT0FBTTZIO0FBQUFBLGNBQ2YyQixhQUFheEosT0FBTXlKO0FBQUFBLGNBQ25CQyxNQUFNMUosT0FBTStIO0FBQUFBLGNBQ1pjO0FBQUFBLFlBQ0Y7QUFBQSxVQUNGLENBQUM7QUFDREMsd0JBQWNpQixLQUFLO0FBQUEsWUFDakJYLElBQUk7QUFBQSxZQUNKQyxNQUFNO0FBQUEsWUFDTjNHLFFBQVE7QUFBQSxZQUNSNkcsU0FBUztBQUFBLFlBQ1RDLGFBQWE7QUFBQSxZQUNiRSxNQUFNO0FBQUEsWUFDTmI7QUFBQUEsVUFDRixDQUFDO0FBRUR4SSwwQkFBZ0J5SSxhQUFhO0FBQUEsUUFDL0IsT0FBTztBQUNMckksMkJBQWlCLEVBQUU7QUFDbkJKLDBCQUFnQixFQUFFO0FBQUEsUUFDcEI7QUFBQSxNQUNGLFNBQVM4SixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RDFKLHlCQUFpQixFQUFFO0FBQ25CSix3QkFBZ0IsRUFBRTtBQUFBLE1BQ3BCLFVBQUM7QUFDQzRCLHdCQUFnQixLQUFLO0FBQ3JCeEMscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBLFFBQUkyQyxjQUFjRSxZQUFZLFVBQVVGLGNBQWNFLFlBQVk7QUFDaEV5TixrQkFBWTtBQUFBLEVBQ2hCLEdBQUcsQ0FBQ2pRLGVBQWVzQyxjQUFjRSxTQUFTRixjQUFjRyxNQUFNLENBQUM7QUFFL0QsUUFBTTJOLGVBQWU7QUFBQSxJQUNuQixFQUFFaEksS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLGFBQWE7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsaUJBQWlCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHdkMsUUFBTWdJLGFBQWFBLENBQUNMLGVBQWU7QUFDakMsVUFBTU0sUUFBUU4sV0FBV3pPLE1BQU0sR0FBRztBQUNsQyxRQUFJK08sTUFBTWxHLFdBQVcsR0FBRztBQUN0QixhQUFPLEdBQUdrRyxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQztBQUFBLElBQzVDO0FBQ0EsV0FBT047QUFBQUEsRUFDVDtBQUNBLFFBQU1PLG9CQUFvQkYsV0FBV25QLFFBQVE7QUFDN0MsUUFBTXNQLGtCQUFrQkgsV0FBVzdPLE1BQU07QUFFekNuRCxZQUFVLE1BQU07QUFDZCxVQUFNNFIsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNeEgsV0FBVyxNQUFNbEssSUFBSWdCO0FBQUFBLFVBQ3pCLHVDQUF1Q1MsYUFBYSxhQUFhdVEsaUJBQWlCLFdBQVdDLGVBQWU7QUFBQSxRQUM5RztBQUNBLFlBQUkvSCxTQUFTRyxRQUFRSCxTQUFTRyxLQUFLd0IsU0FBUyxHQUFHO0FBQzdDekosMkJBQWlCOEgsU0FBU0csSUFBSTtBQUU5QixnQkFBTXNILE9BQU96SCxTQUFTRztBQUN0Qi9HLDJCQUFpQnFPLEtBQUssQ0FBQyxFQUFFckgsbUJBQW1CLENBQUM7QUFFN0MsZ0JBQU1zSCxXQUFXMUgsU0FBU0c7QUFDMUI3RywrQkFBcUJvTyxTQUFTLENBQUMsRUFBRXJILG1CQUFtQjtBQUVwRCxnQkFBTXBILGVBQWMrRyxTQUFTRyxLQUFLNkU7QUFBQUEsWUFDaEMsQ0FBQ0MsS0FBS3hOLFdBQVV3TixNQUFNYSxTQUFTck8sT0FBTTBDLE1BQU07QUFBQSxZQUMzQztBQUFBLFVBQ0Y7QUFDQWpCLHlCQUFlRCxZQUFXO0FBQzFCLGdCQUFNc0gsZ0JBQWdCUCxTQUFTRyxLQUFLSyxJQUFJLENBQUMvSSxRQUFPaUosV0FBVztBQUFBLFlBQ3pERyxJQUFJSCxRQUFRO0FBQUEsWUFDWjhELE1BQU0vTSxRQUFPdVEsTUFBTTlDO0FBQUFBLFlBQ25CQyxjQUFjMU4sUUFBT3VRLE1BQU03QztBQUFBQSxZQUMzQm5MLFFBQVF2QyxPQUFNdUM7QUFBQUEsWUFDZGlPLG1CQUNFbkMsU0FBU3JPLE9BQU1BLE1BQU1zTyxhQUFhLElBQUl0TyxPQUFNNEk7QUFBQUEsWUFDOUM2SCxhQUFhelEsT0FBTXlPO0FBQUFBLFlBQ25CaUMsZ0JBQ0VyQyxTQUFTck8sT0FBTUEsTUFBTXNPLGFBQWEsSUFDbEN0TyxPQUFNNEksc0JBQ041SSxPQUFNeU87QUFBQUEsVUFDVixFQUFFO0FBQ0ZsTyw4QkFBb0J1SSxhQUFhO0FBQUEsUUFDbkMsT0FBTztBQUNMckksMkJBQWlCLEVBQUU7QUFDbkJnQix5QkFBZSxDQUFDO0FBQUEsUUFDbEI7QUFBQSxNQUNGLFNBQVMwSSxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RDFKLHlCQUFpQixFQUFFO0FBQ25CZ0IsdUJBQWUsQ0FBQztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUNBc08sZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ2pRLGVBQWV1USxtQkFBbUJDLGVBQWUsQ0FBQztBQUV0RCxRQUFNSyxjQUFjO0FBQUEsSUFDbEIsRUFBRXpJLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsb0JBQW9CO0FBQUEsSUFDeEQsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxpQkFBaUI7QUFBQSxFQUFDO0FBR3JEaEssWUFBVSxNQUFNO0FBQ2QsUUFBSW1HLGFBQWFtRCxTQUFTbUosWUFBWTtBQUNwQyxZQUFNMVEsY0FBY29FLFVBQVV1TSxjQUFjLElBQUssT0FBTztBQUN4RCxZQUFNQyxjQUNIeE0sVUFBVXVNLGVBQWUsTUFBTXBKLFNBQVNtSixjQUFjO0FBQ3pELFlBQU1HLFlBQVl0SixTQUFTbUosY0FBYyxLQUFLMVE7QUFDOUMsWUFBTThRLGdCQUFnQjFNLFVBQVUyTSxnQkFDNUJGLFdBQVd6TSxVQUFVMk0sZ0JBQ3JCO0FBQ0osWUFBTXBDLFdBQVd2SyxVQUFVZ0ssaUJBQWlCLEtBQUswQztBQUNqRHRKLGtCQUFZLENBQUN3SixjQUFjO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSHZKLFVBQVVyRCxVQUFVNkU7QUFBQUEsUUFDcEJqSjtBQUFBQSxRQUNBNFE7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQW5DO0FBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ3ZLLFdBQVdtRCxTQUFTbUosVUFBVSxDQUFDO0FBRW5DelMsWUFBVSxNQUFNO0FBQ2QsUUFBSTJCLGVBQWU7QUFDakJ6QixVQUNHeVAsS0FBSyw0QkFBNEJoTyxhQUFhLEVBQUUsRUFDaERxUixLQUFLLENBQUM1SSxhQUFhO0FBQ2xCdEQsNEJBQW9Cc0QsU0FBU0csS0FBSzFELG9CQUFvQixFQUFFO0FBQUEsTUFDMUQsQ0FBQyxFQUNBb00sTUFBTSxDQUFDakgsVUFBVTtBQUNoQkMsZ0JBQVFELE1BQU0scUNBQXFDQSxLQUFLO0FBQUEsTUFDMUQsQ0FBQztBQUFBLElBQ0wsT0FBTztBQUNMbEYsMEJBQW9CLEVBQUU7QUFBQSxJQUN4QjtBQUFBLEVBQ0YsR0FBRyxDQUFDbkYsYUFBYSxDQUFDO0FBQ2xCLE1BQUlvRjtBQUNGLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLGtCQUFlLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBR0osU0FDRSxtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxrQ0FBaUMsNENBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsa0hBQ2IsaUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUztBQUFBLGNBQU07QUFBQTtBQUFBLFlBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsT0FBT2hCLDBCQUEwQm1OO0FBQUFBLGNBQ2pDLFVBQVVyRTtBQUFBQSxjQUNWO0FBQUEsY0FDQSx1QkFBdUI7QUFBQSxjQUN2QixhQUFZO0FBQUEsY0FDWixjQUFjLENBQUNzRSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGNBRWpDLE9BQU8sRUFBRUUsUUFBUSxRQUFRQyxPQUFPLFFBQVE7QUFBQSxjQUN2Q3ZTLGlCQUFPeUo7QUFBQUEsZ0JBQUksQ0FBQy9JLFdBQ1gsdUJBQUMsWUFBdUIsT0FBT0EsT0FBTW1KLEtBQ2xDbko7QUFBQUEseUJBQU15TjtBQUFBQSxrQkFBVTtBQUFBLGtCQUFJek4sT0FBTTBOO0FBQUFBLHFCQURoQjFOLE9BQU1tSixLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4QkE7QUFBQSxRQUVDckosaUJBQ0MsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcseUJBQXlCc0YsY0FBYyxpQkFDOUMsaURBQ0EsZUFBZTtBQUFBLGdCQUVuQixTQUFTLE1BQU1tQyxnQkFBZ0IsY0FBYztBQUFBLGdCQUFHO0FBQUE7QUFBQSxjQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLHlCQUF5Qm5DLGNBQWMsZ0JBQzlDLGlEQUNBLGVBQWU7QUFBQSxnQkFFbkIsU0FBUyxNQUFNbUMsZ0JBQWdCLGFBQWE7QUFBQSxnQkFBRztBQUFBO0FBQUEsY0FMakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyx5QkFBeUJuQyxjQUFjLGlCQUM5QyxpREFDQSxlQUFlO0FBQUEsZ0JBRW5CLFNBQVMsTUFBTW1DLGdCQUFnQixjQUFjO0FBQUEsZ0JBQUc7QUFBQTtBQUFBLGNBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUNQL0k7QUFBQUEsZ0JBQ0V3QjtBQUFBQSxnQkFDQUo7QUFBQUEsZ0JBQ0E0RztBQUFBQSxnQkFDQUU7QUFBQUEsZ0JBQ0E7QUFBQSxrQkFDRWhEO0FBQUFBLGtCQUNBSTtBQUFBQSxrQkFDQUU7QUFBQUEsa0JBQ0FKO0FBQUFBLGdCQUNGO0FBQUEsZ0JBQ0F4RDtBQUFBQSxnQkFDQVU7QUFBQUEsY0FDRjtBQUFBLGNBRUYsV0FBVTtBQUFBLGNBQ1Y7QUFBQSx1Q0FBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVCO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFsQjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9CQSxLQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBRUNzRSxjQUFjLGtCQUNiLG1DQUNHdEQsMkJBQ0MsdUJBQUMsT0FBRSwwQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhLElBRWIsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4REFDZCxpQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBLG9CQUdWLE9BQU93RDtBQUFBQSxvQkFDUCxVQUFVLENBQUMrQixNQUNUOUIsY0FBYzhCLEVBQUVDLE9BQU83RCxLQUFLO0FBQUE7QUFBQSxrQkFSaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNHO0FBQUEsbUJBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBRUM2QixlQUNFLE1BQU07QUFDTCxzQkFBTXdNLGVBQWU7QUFBQSxrQkFDbkIsRUFBRTVKLEtBQUssUUFBUXpFLE9BQU96RCxNQUFNeU4sVUFBVTtBQUFBLGtCQUN0QyxFQUFFdkYsS0FBSyxTQUFTekUsT0FBT3pELE1BQU0rUixNQUFNO0FBQUEsa0JBQ25DLEVBQUU3SixLQUFLLFNBQVN6RSxPQUFPekQsTUFBTTBOLGFBQWE7QUFBQSxrQkFDMUM7QUFBQSxvQkFDRXhGLEtBQUs7QUFBQSxvQkFDTHpFLE9BQU96RCxNQUFNZ1M7QUFBQUEsa0JBQ2Y7QUFBQSxrQkFDQSxFQUFFOUosS0FBSyxXQUFXekUsT0FBT3pELE1BQU1pUyxRQUFRO0FBQUEsa0JBQ3ZDLEVBQUUvSixLQUFLLFdBQVd6RSxPQUFPekQsTUFBTWtTLFVBQVU7QUFBQSxrQkFDekMsRUFBRWhLLEtBQUssT0FBT3pFLE9BQU96RCxNQUFNbVMsT0FBTztBQUFBLGtCQUNsQyxFQUFFakssS0FBSyxXQUFXekUsT0FBT3pELE1BQU1vUyxRQUFRO0FBQUEsa0JBQ3ZDO0FBQUEsb0JBQ0VsSyxLQUFLO0FBQUEsb0JBQ0x6RSxPQUFPekQsTUFBTXFTO0FBQUFBLGtCQUNmO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRW5LLEtBQUs7QUFBQSxvQkFDTHpFLE9BQU96RCxNQUFNc1M7QUFBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLG9CQUNFcEssS0FBSztBQUFBLG9CQUNMekUsT0FBT3pELE1BQU11UztBQUFBQSxrQkFDZjtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VySyxLQUFLO0FBQUEsb0JBQ0x6RSxPQUFPekQsTUFBTXdTO0FBQUFBLGtCQUNmO0FBQUEsZ0JBQUM7QUFHSCxzQkFBTUMsT0FBTyxJQUFJMVQsS0FBSytTLGNBQWM7QUFBQSxrQkFDbENZLE1BQU0sQ0FBQyxPQUFPLE9BQU87QUFBQSxrQkFDckJDLFdBQVc7QUFBQTtBQUFBLGdCQUNiLENBQUM7QUFFRCxzQkFBTUMsVUFBVUgsS0FBS0ksT0FBT3ZOLFVBQVU7QUFFdEMsdUJBQ0UsdUJBQUMsU0FBSSxXQUFVLGlEQUNac04sa0JBQVExSSxTQUFTLElBQ2hCMEksUUFBUTdKO0FBQUFBLGtCQUFJLENBQUMsRUFBRTJHLEtBQUssTUFDbEI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsV0FBVTtBQUFBLHNCQUNWO0FBQUEsK0NBQUMsWUFBUUEsZUFBS3hILE9BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBa0I7QUFBQSx3QkFBUztBQUFBLHdCQUFHO0FBQUEsd0JBQzdCd0gsS0FBS2pNLFNBQVM7QUFBQTtBQUFBO0FBQUEsb0JBSFZpTSxLQUFLeEg7QUFBQUEsb0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGdCQUNELElBRUQsdUJBQUMsT0FBRSxtQ0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQixLQVgxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsY0FFSixHQUFHO0FBQUEsaUJBekVQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFDUHJGLGVBQWUsQ0FBQ2lRLFVBQVU7QUFBQSxzQkFDeEIsR0FBR0E7QUFBQUEsc0JBQ0hoUSxNQUFNLENBQUNnUSxLQUFLaFE7QUFBQUEsb0JBQ2QsRUFBRTtBQUFBLG9CQUVKLFdBQVc7QUFBQSxVQUNuQ0YsWUFBWUUsT0FDa0Isc0VBQ0EscUdBQXFHO0FBQUE7QUFBQSxvQkFHMUdGLHNCQUFZRSxPQUNULHNCQUNBO0FBQUE7QUFBQSxrQkFmTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZ0JBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUNQRCxlQUFlLENBQUNpUSxVQUFVO0FBQUEsc0JBQ3hCLEdBQUdBO0FBQUFBLHNCQUNIL1AsTUFBTSxDQUFDK1AsS0FBSy9QO0FBQUFBLG9CQUNkLEVBQUU7QUFBQSxvQkFFSixXQUFXO0FBQUEsVUFDbkNILFlBQVlHLE9BQ2tCLHNFQUNBLHFHQUFxRztBQUFBO0FBQUEsb0JBRzFHSCxzQkFBWUcsT0FDVCx3QkFDQTtBQUFBO0FBQUEsa0JBZk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWdCQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFDUEYsZUFBZSxDQUFDaVEsVUFBVTtBQUFBLHNCQUN4QixHQUFHQTtBQUFBQSxzQkFDSDlQLE1BQU0sQ0FBQzhQLEtBQUs5UDtBQUFBQSxvQkFDZCxFQUFFO0FBQUEsb0JBRUosV0FBVztBQUFBLFVBQ25DSixZQUFZSSxPQUNrQixzRUFDQSxxR0FBcUc7QUFBQTtBQUFBLG9CQUcxR0osc0JBQVlJLE9BQ1QseUJBQ0E7QUFBQTtBQUFBLGtCQWZOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFnQkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQ1BILGVBQWUsQ0FBQ2lRLFVBQVU7QUFBQSxzQkFDeEIsR0FBR0E7QUFBQUEsc0JBQ0g3UCxNQUFNLENBQUM2UCxLQUFLN1A7QUFBQUEsb0JBQ2QsRUFBRTtBQUFBLG9CQUVKLFdBQVc7QUFBQSxVQUNuQ0wsWUFBWUssT0FDa0Isc0VBQ0EscUdBQXFHO0FBQUE7QUFBQSxvQkFHMUdMLHNCQUFZSyxPQUNULDRDQUNBO0FBQUE7QUFBQSxrQkFmTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZ0JBO0FBQUEsbUJBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0VBO0FBQUEsY0FHQ0wsWUFBWUUsUUFDWCx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBTzlDLE1BQU15TjtBQUFBQTtBQUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRXlCO0FBQUEsa0JBRXpCLHVCQUFDLFNBQU0sT0FBTSxTQUFRLE9BQU96TixNQUFNK1IsU0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0M7QUFBQSxxQkFMMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPL1IsTUFBTTBOO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFNEI7QUFBQSxrQkFFNUI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU8xTixNQUFNa1M7QUFBQUE7QUFBQUEsb0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUV5QjtBQUFBLHFCQVAzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU9sUyxNQUFNbVM7QUFBQUE7QUFBQUEsb0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVzQjtBQUFBLGtCQUV0QjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBT25TLE1BQU1vUztBQUFBQTtBQUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRXVCO0FBQUEscUJBUHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0QkE7QUFBQSxjQUlEeFAsWUFBWUcsUUFDWCx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBTy9DLE1BQU1pUztBQUFBQTtBQUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRXVCO0FBQUEsa0JBRXZCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPalMsTUFBTStTO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFc0I7QUFBQSxxQkFQeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUNFL1MsTUFBTWdULGNBQ0YsSUFBSTdSLEtBQUtuQixNQUFNZ1QsV0FBVyxFQUN6QjVSLFlBQVksRUFDWkMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNiO0FBQUE7QUFBQSxvQkFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUc7QUFBQSxrQkFFSDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBT3JCLE9BQU9pVCxpQkFBaUJDO0FBQUFBO0FBQUFBLG9CQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRTRDO0FBQUEscUJBYjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBT2xULE1BQU1tVDtBQUFBQTtBQUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRThCO0FBQUEsa0JBRTlCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPblQsTUFBTXFTO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFMkI7QUFBQSxxQkFQN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFDQTtBQUFBLGNBSUR6UCxZQUFZSSxRQUNYLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPaEQsTUFBTW9UO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFMkI7QUFBQSxrQkFFM0I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU9wVCxNQUFNcVQ7QUFBQUE7QUFBQUEsb0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUV1QjtBQUFBLHFCQVB6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEseUNBQUMsU0FBTSxPQUFNLFNBQVEsT0FBT3JULE1BQU1zVCxTQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3QztBQUFBLGtCQUN4QztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBT3RULE1BQU11VDtBQUFBQTtBQUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRXdCO0FBQUEscUJBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSx5Q0FBQyxTQUFNLE9BQU0sU0FBUSxPQUFPdlQsTUFBTXdULFNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDO0FBQUEsa0JBQ3hDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPeFQsTUFBTWdTO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFZ0M7QUFBQSxxQkFKbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLG1CQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlCQTtBQUFBLGNBSURwUCxZQUFZSyxRQUNYLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPakQsTUFBTXlUO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFNkI7QUFBQSxrQkFFN0I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU96VCxNQUFNc1M7QUFBQUE7QUFBQUEsb0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUU0QjtBQUFBLGtCQUU1QjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FDRXRTLE1BQU0wVCxzQkFDRixJQUFJdlMsS0FBS25CLE1BQU0wVCxtQkFBbUIsRUFDakN0UyxZQUFZLEVBQ1pDLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDYjtBQUFBO0FBQUEsb0JBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVFHO0FBQUEscUJBakJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU9yQixNQUFNMlQ7QUFBQUE7QUFBQUEsb0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVvQztBQUFBLGtCQUVwQztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBTzNULE1BQU00VDtBQUFBQTtBQUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRW9DO0FBQUEsa0JBRXBDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPNVQsTUFBTXVTO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFeUI7QUFBQSxxQkFYM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPdlMsTUFBTTZUO0FBQUFBO0FBQUFBLG9CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFZ0M7QUFBQSxrQkFFaEM7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU83VCxNQUFNd1M7QUFBQUE7QUFBQUEsb0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVtQztBQUFBLGtCQUVuQztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sT0FBT3hTLE1BQU04VDtBQUFBQTtBQUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRThCO0FBQUEscUJBWGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxtQkFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpREE7QUFBQSxpQkF4T0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwT0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDRCQUEyQiwrQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUNsVSxpQkFDQ0EsY0FBY3NLLFNBQVMsS0FDdkIsQ0FBQzFLLFlBQ0QsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFNYjtBQUFBQSxzQkFDSmlCO0FBQUFBO0FBQUFBLHNCQUNBMEY7QUFBQUEsb0JBQ0Y7QUFBQSxvQkFDQSxTQUFTdUs7QUFBQUEsb0JBQ1QsaUJBQWlCO0FBQUEsb0JBQ2pCLGlCQUFpQjtBQUFBLHNCQUNmO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLG9CQUFlO0FBQUEsb0JBRWpCLG1CQUFtQjtBQUFBLHNCQUNqQjdQLE1BQU15TjtBQUFBQSxzQkFDTnpOLE9BQU8wTjtBQUFBQSxzQkFDUGhLO0FBQUFBLHNCQUNBSTtBQUFBQSxzQkFDQUU7QUFBQUEsc0JBQ0FBLGtCQUFrQkosWUFDZEksaUJBQWlCSixZQUNqQjtBQUFBLG9CQUFFO0FBQUEsb0JBRVQsa0JBQWtCLG9DQUFvQ2hFLGNBQWNzSyxTQUFTLElBQ3hFdEssY0FBYyxDQUFDLEVBQUV5SixPQUNuQixTQUNBekosY0FDRUEsY0FBY3NLLFNBQVMsQ0FBQyxFQUN4QmIsT0FDQSxPQUFPO0FBQUE7QUFBQSxrQkEvQmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWdDVztBQUFBLGdCQUdWN0MscUJBQXFCMEQsU0FBUyxLQUM3Qix1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSw0QkFBMkIsNEJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFNMUQ7QUFBQUEsc0JBQ04sU0FBU29IO0FBQUFBLHNCQUNULGtCQUFrQjtBQUFBLHNCQUNsQixpQkFBZ0I7QUFBQTtBQUFBLG9CQUpsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSXdDO0FBQUEscUJBUjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFHRDFILGtCQUFrQmdFLFNBQVMsS0FDMUIsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsNEJBQTJCLDZCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBTWhFO0FBQUFBLHNCQUNOLFNBQVMySDtBQUFBQSxzQkFDUCxrQkFBa0I7QUFBQSxzQkFDcEIsaUJBQWdCO0FBQUE7QUFBQSxvQkFKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUkwQztBQUFBLHFCQVI1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsbUJBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0RBLElBRUEsdUJBQUMsa0JBQWUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUl0QyxDQUFDck8sYUFBYUksY0FBY3NLLFdBQVcsS0FDdEMsdUJBQUMsU0FBSSxXQUFVLGdEQUErQyw0Q0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWhGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtGQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5Qyx1Q0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBT3hHLGlCQUFpQjtBQUFBLG9CQUN4QjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLb0Y7QUFBQSxnQkFFcEYsdUJBQUMsVUFBSyxXQUFXLHlDQUNkMUUsOEJBQW9CMEUsaUJBQWlCLENBQUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsNEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLE9BQU9JLGVBQWU7QUFBQSxvQkFDdEI7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS29GO0FBQUEsZ0JBRXBGLHVCQUFDLFVBQUssV0FBVyx5Q0FDZDlFLDhCQUFvQjhFLGVBQWUsQ0FBQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QyxvQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBT0Usa0JBQWtCO0FBQUEsb0JBQ3pCO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtvRjtBQUFBLGdCQUVwRix1QkFBQyxVQUFLLFdBQVcseUNBQ2RoRiw4QkFBb0JnRixrQkFBa0IsQ0FBQyxLQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QyxpQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBT0osYUFBYTtBQUFBLG9CQUNwQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLb0Y7QUFBQSxnQkFFcEYsdUJBQUMsVUFBSyxXQUFXLHlDQUNkNUUsOEJBQW9CNEUsYUFBYSxDQUFDLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsMENBQXlDLDZCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixPQUNFSSxrQkFBa0JKLFlBQ2RJLGlCQUFpQkosWUFDakI7QUFBQSxvQkFFTjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTb0Y7QUFBQSxnQkFFcEYsdUJBQUMsVUFBSyxXQUFXLHlDQUNkNUUsOEJBQW9CZ0Ysa0JBQWtCSixZQUNuQ0ksaUJBQWlCSixZQUNqQixDQUFDLEtBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGlCQWpGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtGQTtBQUFBLGVBOWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK2RBLEtBbmVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcWVBO0FBQUEsVUErTER3QixjQUFjLGlCQUNiLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMENBQXlDLGtDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUNFaEQsY0FBY0UsVUFDVixHQUFHRixjQUFjRSxPQUFPLElBQUlGLGNBQWNHLE1BQU0sS0FDaEQ7QUFBQSxrQkFFTixVQUFVMks7QUFBQUEsa0JBQ1YsV0FBVTtBQUFBLGtCQUNWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLElBQUcscUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNDO0FBQUEsb0JBR3JDOUksZ0JBQWdCMkUsSUFBSSxDQUFDL0ksV0FBVTtBQUM5QiwwQkFDRUEsUUFBT2dPLFlBQVloTyxTQUNuQkEsUUFBT2dPLFlBQVlzQixvQkFDbkIsYUFDQTtBQUNBLCtCQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUVDLE9BQU8sR0FBR3RQLE9BQU1nTyxXQUFXaE8sTUFBTW1KLEdBQUcsSUFBSW5KLE9BQU1nTyxXQUFXQyxPQUFPO0FBQUEsNEJBQy9Eak87QUFBQUEscUNBQU1nTyxXQUFXaE8sTUFBTTJNO0FBQUFBLDhCQUFXO0FBQUEsOEJBQUc7QUFBQSw4QkFDckMzTSxPQUFNZ08sV0FBV0M7QUFBQUE7QUFBQUE7QUFBQUEsMEJBSGJqTyxPQUFNZ08sV0FBV2hPLE1BQU1tSjtBQUFBQSwwQkFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQ0EsNkJBQU87QUFBQSxvQkFDVCxDQUFDO0FBQUEsb0JBRUE0SyxNQUFNQyxRQUFRdE8sZUFBZTZFLFlBQVksS0FDeEM3RSxjQUFjNkUsYUFBYXhCO0FBQUFBLHNCQUN6QixDQUFDMEIsTUFBTXhCLFVBQ0w7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBSUMsT0FBTyxRQUFRd0IsTUFBTUMsY0FBY0QsTUFBTXRCLE9BQU9GLEtBQUs7QUFBQSwwQkFFcER3QjtBQUFBQSxrQ0FBTUMsY0FBY0QsTUFBTWUsV0FDekI7QUFBQSw0QkFBTztBQUFBLDRCQUFJO0FBQUEsNEJBQ1RmLE1BQU1pQixjQUFjO0FBQUE7QUFBQTtBQUFBLHdCQU50QmpCLE1BQU1DLGNBQWNELE1BQU10QixPQUFPRjtBQUFBQSx3QkFGckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFTQTtBQUFBLG9CQUVKO0FBQUEsb0JBRUQ4SyxNQUFNQyxRQUFRcE8sZ0JBQWdCcUcsYUFBYSxLQUMxQ3JHLGVBQWVxRyxjQUFjbEQ7QUFBQUEsc0JBQzNCLENBQUNtRCxPQUFPakQsVUFDTjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFLQyxPQUFPLFNBQVNpRCxPQUFPQyxlQUFlRCxPQUFPL0MsT0FDM0NGLEtBQUs7QUFBQSwwQkFFTmlEO0FBQUFBLG1DQUFPQyxlQUFlRCxPQUNuQkUsWUFBWTtBQUFBLDRCQUFPO0FBQUEsNEJBQUk7QUFBQSw0QkFDdkJGLE9BQU9NLDBCQUEwQjtBQUFBO0FBQUE7QUFBQSx3QkFSbkNOLE9BQU9DLGVBQWVELE9BQU8vQyxPQUM3QkY7QUFBQUEsd0JBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFXQTtBQUFBLG9CQUVKO0FBQUE7QUFBQTtBQUFBLGdCQTdESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E4REE7QUFBQSxpQkFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtRUEsS0FwRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxRUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw2Q0FHYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPLHNCQUFzQm5DLHNCQUFzQixDQUFDO0FBQUEsb0JBQ3BEO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlrSDtBQUFBLGdCQUVsSCx1QkFBQyxPQUFFLFdBQVUsc0VBQ1Y5SCw4QkFBb0I4SCxzQkFBc0IsQ0FBQyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8scUJBQXFCSSx1QkFBdUIsQ0FBQztBQUFBLG9CQUNwRDtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJcUg7QUFBQSxnQkFFckgsdUJBQUMsT0FBRSxXQUFVLHVFQUNWbEksOEJBQW9Ca0ksdUJBQXVCLENBQUMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPLFdBQVdnQyxPQUFPaEMsdUJBQXVCLENBQUMsSUFDL0NnQyxPQUFPcEMsc0JBQXNCLENBQUMsQ0FBQztBQUFBLG9CQUVqQztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNcUg7QUFBQSxnQkFFckgsdUJBQUMsT0FBRSxXQUFVLHVFQUNWOUg7QUFBQUEsa0JBQ0NrSyxPQUFPaEMsdUJBQXVCLENBQUMsSUFDL0JnQyxPQUFPcEMsc0JBQXNCLENBQUM7QUFBQSxnQkFDaEMsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGlCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThDQTtBQUFBLGFBSUUxRyxjQUFjOEosU0FBUyxLQUN2QjlELGVBQWU4RCxTQUFTLEtBQ3hCcEUsbUJBQW1Cb0UsU0FBUyxNQUM1QixDQUFDbEksZUFDRCx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGlCQUFnQjtBQUFBLGdCQUNoQixrQkFBaUI7QUFBQSxnQkFDakIsaUJBQWlCO0FBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGdCQUFZO0FBQUEsZ0JBRWQsbUJBQW1CO0FBQUEsa0JBQ2pCaEMsTUFBTXlOO0FBQUFBLGtCQUNOek4sTUFBTWlVO0FBQUFBLGtCQUNOalUsTUFBTTBOO0FBQUFBLGtCQUNOdEwsY0FBY0c7QUFBQUEsa0JBQ2RpRCxhQUFhbUg7QUFBQUEsZ0JBQVU7QUFBQSxnQkFFekIsTUFDRXZLLGNBQWNFLFlBQVksU0FDdEI4RCxnQkFDQWhFLGNBQWNFLFlBQVksVUFDeEJ3RCxvQkFDQTFGO0FBQUFBLGdCQUVSLFNBQ0VnQyxjQUFjRSxZQUFZLFNBQ3RCMkYsbUJBQ0E3RixjQUFjRSxZQUFZLFVBQ3hCOEYsb0JBQ0E4SDtBQUFBQTtBQUFBQSxjQTdCVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE4QkcsS0EvQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0EsSUFFQSx1QkFBQyxrQkFBZSxXQUFXbE8sZ0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsZUFqSzVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUtBLEtBcEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUtBO0FBQUEsVUFHRG9ELGNBQWMsa0JBQ2IsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHlDQUF3Qyw0QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUN3QixzQkFDQyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlLElBQ2JGLHNCQUFzQndELFNBQVMsSUFDakMsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNeEQ7QUFBQUEsZ0JBQ04sU0FBUzJCO0FBQUFBLGdCQUNULGlCQUFpQjtBQUFBLGdCQUNqQixrQkFBa0I7QUFBQSxnQkFDbEIsaUJBQWlCO0FBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLGdCQUFjO0FBQUEsZ0JBRWhCLG1CQUFtQjtBQUFBLGtCQUNqQnJJLE9BQU95TjtBQUFBQSxrQkFDUHpOLE9BQU8wTjtBQUFBQSxnQkFBWTtBQUFBO0FBQUEsY0FYdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWUksS0FiTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtEQUFpRCwwQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsYUFoNkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrNkJBLEtBbjZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbzZCQTtBQUFBLFdBdDhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdzhCQTtBQUFBLFNBNThCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNjhCQTtBQUFBLE9BbDlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbTlCQSxLQXA5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXE5QkEsS0F0OUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1OUJBO0FBRUo7QUFBRXhPLEdBcDlESUQsb0JBQWtCO0FBQUEsVUFDQ0wsZUFBZTtBQUFBO0FBQUFzVixLQURsQ2pWO0FBczlETixlQUFlQTtBQUFtQixJQUFBaVY7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJDdXN0b21lclJlcG9ydFByaW50IiwiU2VsZWN0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwidXNlU2VhcmNoUGFyYW1zIiwiRmlTZWFyY2giLCJJb01kRG93bmxvYWQiLCJGdXNlIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkluQWN0aXZlVXNlclJlcG9ydCIsIl9zIiwic2VhcmNoUGFyYW1zIiwidXNlcklkIiwiZ2V0IiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiVGFibGVEYXlib29rIiwic2V0VGFibGVEYXlib29rIiwiVGFibGVBdWN0aW9ucyIsInNldFRhYmxlQXVjdGlvbnMiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsImdyb3VwIiwic2V0R3JvdXAiLCJjb21taXNzaW9uIiwic2V0Q29tbWlzc2lvbiIsIlRhYmxlRW5yb2xscyIsInNldFRhYmxlRW5yb2xscyIsIlRhYmxlRW5yb2xsc0RhdGUiLCJzZXRUYWJsZUVucm9sbHNEYXRlIiwiZmlsdGVyZWRVc2VycyIsInNldEZpbHRlcmVkVXNlcnMiLCJncm91cFBhaWQiLCJzZXRHcm91cFBhaWQiLCJncm91cFRvQmVQYWlkIiwic2V0R3JvdXBUb0JlUGFpZCIsImN1c3RvbWVyVHJhbnNhY3Rpb25zIiwic2V0Q3VzdG9tZXJUcmFuc2FjdGlvbnMiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9kYXkiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInRvRGF0ZSIsInNldFRvRGF0ZSIsInRvdGFsQW1vdW50Iiwic2V0VG90YWxBbW91bnQiLCJncm91cFBhaWREYXRlIiwic2V0R3JvdXBQYWlkRGF0ZSIsImdyb3VwVG9CZVBhaWREYXRlIiwic2V0R3JvdXBUb0JlUGFpZERhdGUiLCJkZXRhaWxzTG9hZGluZyIsInNldERldGFpbExvYWRpbmciLCJiYXNpY0xvYWRpbmciLCJzZXRCYXNpY0xvYWRpbmciLCJkYXRlTG9hZGluZyIsInNldERhdGVMb2FkaW5nIiwiRW5yb2xsR3JvdXBJZCIsInNldEVucm9sbEdyb3VwSWQiLCJncm91cElkIiwidGlja2V0IiwicmVnaXN0cmF0aW9uRmVlIiwic2V0UmVnaXN0cmF0aW9uRmVlIiwiYW1vdW50IiwiY3JlYXRlZEF0IiwidmlzaWJsZVJvd3MiLCJzZXRWaXNpYmxlUm93cyIsInJvdzEiLCJyb3cyIiwicm93MyIsInJvdzQiLCJyb3c1Iiwicm93NiIsInJvdzciLCJyb3c4Iiwicm93OSIsIklucHV0IiwibGFiZWwiLCJ2YWx1ZSIsIlRvdGFsVG9CZXBhaWQiLCJzZXRUb3RhbFRvQmVQYWlkIiwiVG90YWxwYWlkIiwic2V0VG90YWxQYWlkIiwiVG90YWxwcm9maXQiLCJzZXRUb3RhbFByb2ZpdCIsIk5ldFRvdGFscHJvZml0Iiwic2V0TmV0VG90YWxQcm9maXQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkQXVjdGlvbiIsInNldEZpbHRlcmVkQXVjdGlvbiIsImdyb3VwSW5mbyIsInNldEdyb3VwSW5mbyIsInNlbGVjdGVkRGF0ZSIsInNldFNlbGVjdGVkRGF0ZSIsInNlbGVjdGVkUGF5bWVudE1vZGUiLCJzZXRTZWxlY3RlZFBheW1lbnRNb2RlIiwic2VsZWN0ZWRDdXN0b21lcnMiLCJzZXRTZWxlY3RlZEN1c3RvbWVycyIsInBheW1lbnRzIiwic2V0UGF5bWVudHMiLCJhdmFpbGFibGVUaWNrZXRzIiwic2V0QXZhaWxhYmxlVGlja2V0cyIsInNjcmVlbkxvYWRpbmciLCJzZXRTY3JlZW5Mb2FkaW5nIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJncm91cERldGFpbHMiLCJzZXRHcm91cERldGFpbHMiLCJsb2FuQ3VzdG9tZXJzIiwic2V0TG9hbkN1c3RvbWVycyIsInBpZ21lQ3VzdG9tZXJzIiwic2V0UGlnbWVDdXN0b21lcnMiLCJwaWdtZUN1c3RvbWVyRGF0YSIsInNldFBpZ21lQ3VzdG9tZXJEYXRhIiwicGlnbWVJZCIsInNldFBpZ21lSWQiLCJmaWx0ZXJlZFBpZ21lRGF0YSIsInNldEZpbHRlcmVkUGlnbWVEYXRhIiwiYm9ycm93ZXJzRGF0YSIsInNldEJvcnJvd2Vyc0RhdGEiLCJib3Jyb3dlcklkIiwic2V0Qm9ycm93ZXJJZCIsImZpbHRlcmVkQm9ycm93ZXJEYXRhIiwic2V0RmlsdGVyZWRCb3Jyb3dlckRhdGEiLCJmaWx0ZXJlZERpc2J1cnNlbWVudCIsInNldEZpbHRlcmVkRGlzYnVyc2VtZW50IiwiZGlzYnVyc2VtZW50TG9hZGluZyIsInNldERpc2J1cnNlbWVudExvYWRpbmciLCJyZWdpc3RyYXRpb25BbW91bnQiLCJzZXRSZWdpc3RyYXRpb25BbW91bnQiLCJyZWdpc3RyYXRpb25EYXRlIiwic2V0UmVnaXN0cmF0aW9uRGF0ZSIsImZpbmFsUGF5bWVudEJhbGFuY2UiLCJzZXRGaW5hbFBheW1lbnRCYWxhbmNlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsImhhbmRsZVRhYkNoYW5nZSIsInRhYiIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9pZCIsInVzZXJfaWQiLCJyZWNlaXB0X25vIiwicGF5X2RhdGUiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwiQmFzaWNMb2FuQ29sdW1ucyIsImtleSIsImhlYWRlciIsIkJhc2ljUGlnbWVDb2x1bW5zIiwiRGlzYnVyc2VtZW50Q29sdW1ucyIsImZldGNoUmVnaXN0cmF0aW9uRmVlIiwicmVzcG9uc2UiLCJwYXJhbXMiLCJyZWdpc3RyYXRpb25GZWVzIiwiZGF0YSIsImdyb3VwUGFpZEFtb3VudCIsInRvdGFsVG9CZVBhaWRBbW91bnQiLCJiYWxhbmNlIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsInBheW1lbnQiLCJpbmRleCIsIk51bWJlciIsIl9pZCIsImlkIiwiZGF0ZSIsImZvcm1hdFBheURhdGUiLCJyZWNlaXB0Iiwib2xkX3JlY2VpcHQiLCJvbGRfcmVjZWlwdF9ubyIsInR5cGUiLCJ0b3RhbFJlZ0Ftb3VudCIsImZvckVhY2giLCJyZWdGZWUiLCJpZHgiLCJwdXNoIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwicGF5X2ZvciIsImxlbmd0aCIsImVycm9yIiwiY29uc29sZSIsImZldGNoQWxsTG9hblBheW1lbnRzYnlJZCIsInNlbGVjdGVkTG9hbiIsIm92ZXJhbGxfbG9hbiIsImZpbmQiLCJsb2FuIiwibG9hbl9kZXRhaWxzIiwibG9hbklkIiwibG9hblBheW1lbnQiLCJmZXRjaEFsbFBpZ21lUGF5bWVudHNieUlkIiwicGlnbWVQYXltZW50IiwiZmV0Y2hHcm91cEJ5SWQiLCJzdGF0dXMiLCJFcnJvciIsImVyciIsImxvZyIsIm1lc3NhZ2UiLCJmZXRjaEdyb3VwcyIsImZldGNoQm9ycm93ZXIiLCJzbF9ubyIsImxvYW5faWQiLCJsb2FuX2Ftb3VudCIsImxvYW5fdmFsdWUiLCJ0ZW51cmUiLCJzZXJ2aWNlX2NoYXJnZSIsInNlcnZpY2VfY2hhcmdlcyIsInRvdGFsX3BhaWRfYW1vdW50IiwiZmV0Y2hQaWdtZSIsImluZm8iLCJvdmVyYWxsX3BpZ21lIiwicGlnbWUiLCJwaWdtZV9kZXRhaWxzIiwicGlnbWVfaWQiLCJzdGFydF9kYXRlIiwiZHVyYXRpb24iLCJtYXR1cml0eV9pbnRlcmVzdCIsInRvdGFsX2RlcG9zaXRlZF9hbW91bnQiLCJmZXRjaERpc2J1cnNlbWVudCIsImRpc2J1cnNlbWVudF90eXBlIiwiZ3JvdXBfbmFtZSIsInRyYW5zYWN0aW9uX2RhdGUiLCJkaXNidXJzZWRfYnkiLCJhZG1pbl90eXBlIiwibmFtZSIsImhhbmRsZUdyb3VwUGF5bWVudCIsImhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSIsImhhbmRsZUVucm9sbEdyb3VwIiwiZXZlbnQiLCJmZXRjaEN1c3RvbWVyVHJhbnNhY3Rpb24iLCJmZXRjaFBheW1lbnRzIiwicGF5bWVudERhdGEiLCJyZWR1Y2UiLCJzdW0iLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJtb2RlIiwibG9hbkNvbHVtbnMiLCJwaWdtZUNvbHVtbnMiLCJwb3N0IiwiZ3JvdXBOYW1lIiwiZW5yb2xsbWVudCIsInRpY2tldHMiLCJncm91cFR5cGUiLCJncm91cF90eXBlIiwiZ3JvdXBJbnN0YWxsIiwicGFyc2VJbnQiLCJncm91cF9pbnN0YWxsIiwiYXVjdGlvbkNvdW50IiwiYXVjdGlvbiIsInRvdGFsUGFpZEFtb3VudCIsInRvdGFsUHJvZml0IiwicHJvZml0IiwidG90YWxQYXlhYmxlIiwicGF5YWJsZSIsImZpcnN0RGl2aWRlbnRIZWFkIiwiZmlyc3RBdWN0aW9uIiwidG90YWxCZVBhaWQiLCJ0b0JlUGFpZEFtb3VudCIsInBhaWRBbW91bnQiLCJyZWZlcnJlZF90eXBlIiwicmVmZXJyZXJfbmFtZSIsImNoaXRfYXNraW5nX21vbnRoIiwiY3VzdG9tZXJfc3RhdHVzIiwicmVtb3ZhbF9yZWFzb24iLCJpc1ByaXplZCIsImZpbHRlciIsIml0ZW0iLCJzdW1tYXJ5IiwidG90YWxOZXRUb0JlUGFpZEFtb3VudCIsIkF1Y3Rpb25jb2x1bW5zIiwiZGF0ZVN0cmluZyIsImZldGNoRW5yb2xsIiwiUGFpZCIsInRvQmVQYWlkIiwiQmFzaWNjb2x1bW5zIiwiZm9ybWF0RGF0ZSIsInBhcnRzIiwiZm9ybWF0dGVkRnJvbURhdGUiLCJmb3JtYXR0ZWRUb0RhdGUiLCJ1c2VyIiwiYW1vdW50X3RvX2JlX3BhaWQiLCJhbW91bnRfcGFpZCIsImFtb3VudF9iYWxhbmNlIiwiRGF0ZWNvbHVtbnMiLCJiaWRfYW1vdW50IiwiZ3JvdXBfdmFsdWUiLCJ3aW5fYW1vdW50IiwiZGl2aWRlbnQiLCJkaXZpZGVudF9oZWFkIiwiZ3JvdXBfbWVtYmVycyIsInByZXZEYXRhIiwidGhlbiIsImNhdGNoIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImhlaWdodCIsIndpZHRoIiwiZGV0YWlsc0FycmF5IiwiZW1haWwiLCJhbHRlcm5hdGVfbnVtYmVyIiwiYWRkcmVzcyIsImFkaGFhcl9ubyIsInBhbl9ubyIsInBpbmNvZGUiLCJmYXRoZXJfbmFtZSIsIm5vbWluZWVfbmFtZSIsImJhbmtfbmFtZSIsImJhbmtfYWNjb3VudF9udW1iZXIiLCJmdXNlIiwia2V5cyIsInRocmVzaG9sZCIsInJlc3VsdHMiLCJzZWFyY2giLCJwcmV2IiwiZ2VuZGVyIiwiZGF0ZW9mYmlydGgiLCJjb2xsZWN0aW9uX2FyZWEiLCJyb3V0ZV9uYW1lIiwibWFyaXRhbF9zdGF0dXMiLCJuYXRpb25hbGl0eSIsInZpbGxhZ2UiLCJ0YWx1ayIsImRpc3RyaWN0Iiwic3RhdGUiLCJyZWZlcnJhbF9uYW1lIiwibm9taW5lZV9kYXRlb2ZiaXJ0aCIsIm5vbWluZWVfcGhvbmVfbnVtYmVyIiwibm9taW5lZV9yZWxhdGlvbnNoaXAiLCJiYW5rX2JyYW5jaF9uYW1lIiwiYmFua19JRlNDX2NvZGUiLCJBcnJheSIsImlzQXJyYXkiLCJjdXN0b21lcl9pZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkluQWN0aXZlVXNlclJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IEN1c3RvbWVyUmVwb3J0UHJpbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvcHJpbnRGb3JtYXRzL0N1c3RvbWVyUmVwb3J0UHJpbnRcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaVNlYXJjaCB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5pbXBvcnQgeyBJb01kRG93bmxvYWQgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEZ1c2UgZnJvbSBcImZ1c2UuanNcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIlxyXG5cclxuY29uc3QgSW5BY3RpdmVVc2VyUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XHJcbiAgY29uc3QgdXNlcklkID0gc2VhcmNoUGFyYW1zLmdldChcInVzZXJfaWRcIik7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtUYWJsZURheWJvb2ssIHNldFRhYmxlRGF5Ym9va10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlQXVjdGlvbnMsIHNldFRhYmxlQXVjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKHVzZXJJZCA/IHVzZXJJZCA6IFwiXCIpO1xyXG4gIGNvbnN0IFtncm91cCwgc2V0R3JvdXBdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjb21taXNzaW9uLCBzZXRDb21taXNzaW9uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtUYWJsZUVucm9sbHMsIHNldFRhYmxlRW5yb2xsc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlRW5yb2xsc0RhdGUsIHNldFRhYmxlRW5yb2xsc0RhdGVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBQYWlkLCBzZXRHcm91cFBhaWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2dyb3VwVG9CZVBhaWQsIHNldEdyb3VwVG9CZVBhaWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2N1c3RvbWVyVHJhbnNhY3Rpb25zLCBzZXRDdXN0b21lclRyYW5zYWN0aW9uc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKCgpID0+IHtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIHJldHVybiB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICB9KTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoKCkgPT4ge1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgcmV0dXJuIHRvZGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gIH0pO1xyXG4gIGNvbnN0IFt0b3RhbEFtb3VudCwgc2V0VG90YWxBbW91bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2dyb3VwUGFpZERhdGUsIHNldEdyb3VwUGFpZERhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2dyb3VwVG9CZVBhaWREYXRlLCBzZXRHcm91cFRvQmVQYWlkRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGV0YWlsc0xvYWRpbmcsIHNldERldGFpbExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtiYXNpY0xvYWRpbmcsIHNldEJhc2ljTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2RhdGVMb2FkaW5nLCBzZXREYXRlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW0Vucm9sbEdyb3VwSWQsIHNldEVucm9sbEdyb3VwSWRdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBJZDogXCJcIixcclxuICAgIHRpY2tldDogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbcmVnaXN0cmF0aW9uRmVlLCBzZXRSZWdpc3RyYXRpb25GZWVdID0gdXNlU3RhdGUoe1xyXG4gICAgYW1vdW50OiAwLFxyXG4gICAgY3JlYXRlZEF0OiBudWxsLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt2aXNpYmxlUm93cywgc2V0VmlzaWJsZVJvd3NdID0gdXNlU3RhdGUoe1xyXG4gICAgcm93MTogZmFsc2UsXHJcbiAgICByb3cyOiBmYWxzZSxcclxuICAgIHJvdzM6IGZhbHNlLFxyXG4gICAgcm93NDogZmFsc2UsXHJcbiAgICByb3c1OiBmYWxzZSxcclxuICAgIHJvdzY6IGZhbHNlLFxyXG4gICAgcm93NzogZmFsc2UsXHJcbiAgICByb3c4OiBmYWxzZSxcclxuICAgIHJvdzk6IGZhbHNlLFxyXG4gIH0pO1xyXG5cclxuICAvLyBSZXVzYWJsZSBJbnB1dCBjb21wb25lbnRcclxuICBjb25zdCBJbnB1dCA9ICh7IGxhYmVsLCB2YWx1ZSB9KSA9PiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPntsYWJlbH08L2xhYmVsPlxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9e2xhYmVsfVxyXG4gICAgICAgIHZhbHVlPXt2YWx1ZSB8fCBcIlwifVxyXG4gICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG4gIGNvbnN0IFtUb3RhbFRvQmVwYWlkLCBzZXRUb3RhbFRvQmVQYWlkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtUb3RhbHBhaWQsIHNldFRvdGFsUGFpZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbVG90YWxwcm9maXQsIHNldFRvdGFsUHJvZml0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBbTmV0VG90YWxwcm9maXQsIHNldE5ldFRvdGFsUHJvZml0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFxyXG4gICAgdXNlcklkID8gdXNlcklkIDogXCJcIlxyXG4gICk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbiwgc2V0RmlsdGVyZWRBdWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoKCkgPT4ge1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgcmV0dXJuIHRvZGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gIH0pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBheW1lbnRNb2RlLCBzZXRTZWxlY3RlZFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVycywgc2V0U2VsZWN0ZWRDdXN0b21lcnNdID0gdXNlU3RhdGUoXHJcbiAgICB1c2VySWQgPyB1c2VySWQgOiBcIlwiXHJcbiAgKTtcclxuICBjb25zdCBbcGF5bWVudHMsIHNldFBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYXZhaWxhYmxlVGlja2V0cywgc2V0QXZhaWxhYmxlVGlja2V0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NjcmVlbkxvYWRpbmcsIHNldFNjcmVlbkxvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwiZ3JvdXBEZXRhaWxzXCIpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtncm91cERldGFpbHMsIHNldEdyb3VwRGV0YWlsc10gPSB1c2VTdGF0ZShcIiBcIik7XHJcbiAgY29uc3QgW2xvYW5DdXN0b21lcnMsIHNldExvYW5DdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUN1c3RvbWVycywgc2V0UGlnbWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUN1c3RvbWVyRGF0YSwgc2V0UGlnbWVDdXN0b21lckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUlkLCBzZXRQaWdtZUlkXSA9IHVzZVN0YXRlKFwiTm9cIik7XHJcbiAgY29uc3QgW2ZpbHRlcmVkUGlnbWVEYXRhLCBzZXRGaWx0ZXJlZFBpZ21lRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2JvcnJvd2Vyc0RhdGEsIHNldEJvcnJvd2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtib3Jyb3dlcklkLCBzZXRCb3Jyb3dlcklkXSA9IHVzZVN0YXRlKFwiTm9cIik7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQm9ycm93ZXJEYXRhLCBzZXRGaWx0ZXJlZEJvcnJvd2VyRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkRGlzYnVyc2VtZW50LCBzZXRGaWx0ZXJlZERpc2J1cnNlbWVudF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2Rpc2J1cnNlbWVudExvYWRpbmcsIHNldERpc2J1cnNlbWVudExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZWdpc3RyYXRpb25BbW91bnQsIHNldFJlZ2lzdHJhdGlvbkFtb3VudF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVnaXN0cmF0aW9uRGF0ZSwgc2V0UmVnaXN0cmF0aW9uRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZmluYWxQYXltZW50QmFsYW5jZSwgc2V0RmluYWxQYXltZW50QmFsYW5jZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVUYWJDaGFuZ2UgPSAodGFiKSA9PiB7XHJcbiAgICBzZXRBY3RpdmVUYWIodGFiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHRpY2tldDogXCJcIixcclxuICAgIHJlY2VpcHRfbm86IFwiXCIsXHJcbiAgICBwYXlfZGF0ZTogXCJcIixcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBCYXNpY0xvYW5Db2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IEJhc2ljUGlnbWVDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IERpc2J1cnNlbWVudENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInBheV9kYXRlXCIsIGhlYWRlcjogXCJEaXNidXJzZWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdF9ub1wiLCBoZWFkZXI6IFwiUmVjZWlwdCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImRpc2J1cnNlbWVudF90eXBlXCIsIGhlYWRlcjogXCJEaXNidXJzZW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJkaXNidXJzZWRfYnlcIiwgaGVhZGVyOiBcIkRpc2J1cnNlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hSZWdpc3RyYXRpb25GZWUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBhY3RpdmVUYWIgPT09IFwiYmFzaWNSZXBvcnRcIiAmJlxyXG4gICAgICAgIHNlbGVjdGVkR3JvdXAgJiZcclxuICAgICAgICBFbnJvbGxHcm91cElkLmdyb3VwSWQgJiZcclxuICAgICAgICBFbnJvbGxHcm91cElkLnRpY2tldCAmJlxyXG4gICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCAhPT0gXCJMb2FuXCIgJiZcclxuICAgICAgICBFbnJvbGxHcm91cElkICE9PSBcIlBpZ21lXCJcclxuICAgICAgKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIHNldFRhYmxlRW5yb2xscyhbXSk7XHJcbiAgICAgICAgICBzZXRHcm91cFBhaWQoXCJcIik7XHJcbiAgICAgICAgICBzZXRHcm91cFRvQmVQYWlkKFwiXCIpO1xyXG4gICAgICAgICAgc2V0UmVnaXN0cmF0aW9uQW1vdW50KG51bGwpO1xyXG4gICAgICAgICAgc2V0UmVnaXN0cmF0aW9uRGF0ZShudWxsKTtcclxuICAgICAgICAgIHNldEJhc2ljTG9hZGluZyh0cnVlKTtcclxuICAgICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICAgIFwiL2Vucm9sbC9nZXQtdXNlci1yZWdpc3RyYXRpb24tZmVlLXJlcG9ydFwiLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBncm91cF9pZDogRW5yb2xsR3JvdXBJZC5ncm91cElkLFxyXG4gICAgICAgICAgICAgICAgdGlja2V0OiBFbnJvbGxHcm91cElkLnRpY2tldCxcclxuICAgICAgICAgICAgICAgIHVzZXJfaWQ6IHNlbGVjdGVkR3JvdXAsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB7IHBheW1lbnRzID0gW10sIHJlZ2lzdHJhdGlvbkZlZXMgPSBbXSB9ID0gcmVzcG9uc2UuZGF0YSB8fCB7fTtcclxuXHJcbiAgICAgICAgICBzZXRHcm91cFBhaWQocGF5bWVudHNbMF0/Lmdyb3VwUGFpZEFtb3VudCB8fCAwKTtcclxuICAgICAgICAgIHNldEdyb3VwVG9CZVBhaWQocGF5bWVudHNbMF0/LnRvdGFsVG9CZVBhaWRBbW91bnQgfHwgMCk7XHJcblxyXG4gICAgICAgICAgbGV0IGJhbGFuY2UgPSAwO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHBheW1lbnRzLm1hcCgocGF5bWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgYmFsYW5jZSArPSBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIGRhdGU6IGZvcm1hdFBheURhdGUocGF5bWVudD8ucGF5X2RhdGUpLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogcGF5bWVudC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogcGF5bWVudC5yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIG9sZF9yZWNlaXB0OiBwYXltZW50Lm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIHR5cGU6IHBheW1lbnQucGF5X3R5cGUsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIGxldCB0b3RhbFJlZ0Ftb3VudCA9IDA7XHJcbiAgICAgICAgICByZWdpc3RyYXRpb25GZWVzLmZvckVhY2goKHJlZ0ZlZSwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgIGZvcm1hdHRlZERhdGEucHVzaCh7XHJcbiAgICAgICAgICAgICAgaWQ6IFwiLVwiLFxyXG4gICAgICAgICAgICAgIGRhdGU6IHJlZ0ZlZS5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICAgID8gbmV3IERhdGUocmVnRmVlLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgICAgICBhbW91bnQ6IHJlZ0ZlZS5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogcmVnRmVlLnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IFwiLVwiLFxyXG4gICAgICAgICAgICAgIHR5cGU6IHJlZ0ZlZS5wYXlfZm9yIHx8IFwiUmVnIEZlZVwiLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2U6IFwiLVwiLFxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHRvdGFsUmVnQW1vdW50ICs9IE51bWJlcihyZWdGZWUuYW1vdW50IHx8IDApO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgc2V0UmVnaXN0cmF0aW9uQW1vdW50KHRvdGFsUmVnQW1vdW50KTtcclxuXHJcbiAgICAgICAgICBpZiAocmVnaXN0cmF0aW9uRmVlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHNldFJlZ2lzdHJhdGlvbkRhdGUoXHJcbiAgICAgICAgICAgICAgcmVnaXN0cmF0aW9uRmVlc1swXT8uY3JlYXRlZEF0XHJcbiAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHJlZ2lzdHJhdGlvbkZlZXNbMF0uY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgIFwiZW4tR0JcIlxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgOiBudWxsXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGZvcm1hdHRlZERhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBmb3JtYXR0ZWREYXRhLnB1c2goe1xyXG4gICAgICAgICAgICAgIGlkOiBcIlwiLFxyXG4gICAgICAgICAgICAgIGRhdGU6IFwiXCIsXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgICAgIHJlY2VpcHQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgdHlwZTogXCJUT1RBTFwiLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzZXRGaW5hbFBheW1lbnRCYWxhbmNlKGJhbGFuY2UpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2V0RmluYWxQYXltZW50QmFsYW5jZSgwKTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBzZXRUYWJsZUVucm9sbHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZWdpc3RyYXRpb24gZmVlIGFuZCBwYXltZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgICAgIHNldEdyb3VwUGFpZChcIlwiKTtcclxuICAgICAgICAgIHNldEdyb3VwVG9CZVBhaWQoXCJcIik7XHJcbiAgICAgICAgICBzZXRSZWdpc3RyYXRpb25BbW91bnQobnVsbCk7XHJcbiAgICAgICAgICBzZXRSZWdpc3RyYXRpb25EYXRlKG51bGwpO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICBzZXRCYXNpY0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgICBzZXRHcm91cFBhaWQoXCJcIik7XHJcbiAgICAgICAgc2V0R3JvdXBUb0JlUGFpZChcIlwiKTtcclxuICAgICAgICBzZXRSZWdpc3RyYXRpb25BbW91bnQobnVsbCk7XHJcbiAgICAgICAgc2V0UmVnaXN0cmF0aW9uRGF0ZShudWxsKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFJlZ2lzdHJhdGlvbkZlZSgpO1xyXG4gIH0sIFthY3RpdmVUYWIsIHNlbGVjdGVkR3JvdXAsIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCwgRW5yb2xsR3JvdXBJZC50aWNrZXRdKTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGNvbnN0IGZldGNoQWxsTG9hblBheW1lbnRzYnlJZCA9IGFzeW5jICgpID0+IHtcclxuICAvLyAgICAgc2V0Qm9ycm93ZXJzRGF0YShbXSk7XHJcbiAgLy8gICAgIHNldEJhc2ljTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgLy8gICAgIHRyeSB7XHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gIC8vICAgICAgICAgYC9sb2FuLXBheW1lbnQvZ2V0LWFsbC1sb2FuLXBheW1lbnRzLyR7RW5yb2xsR3JvdXBJZC50aWNrZXR9YFxyXG4gIC8vICAgICAgICk7XHJcblxyXG4gIC8vICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gIC8vICAgICAgICAgbGV0IGJhbGFuY2UgPSAwO1xyXG4gIC8vICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChsb2FuUGF5bWVudCwgaW5kZXgpID0+IHtcclxuICAvLyAgICAgICAgICAgYmFsYW5jZSArPSBOdW1iZXIobG9hblBheW1lbnQuYW1vdW50KTtcclxuICAvLyAgICAgICAgICAgcmV0dXJuIHtcclxuICAvLyAgICAgICAgICAgICBfaWQ6IGxvYW5QYXltZW50Ll9pZCxcclxuICAvLyAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gIC8vICAgICAgICAgICAgIHBheV9kYXRlOiBmb3JtYXRQYXlEYXRlKGxvYW5QYXltZW50Py5wYXlfZGF0ZSksXHJcbiAgLy8gICAgICAgICAgICAgYW1vdW50OiBsb2FuUGF5bWVudC5hbW91bnQsXHJcbiAgLy8gICAgICAgICAgICAgcmVjZWlwdF9ubzogbG9hblBheW1lbnQucmVjZWlwdF9ubyxcclxuICAvLyAgICAgICAgICAgICBwYXlfdHlwZTogbG9hblBheW1lbnQucGF5X3R5cGUsXHJcbiAgLy8gICAgICAgICAgICAgYmFsYW5jZSxcclxuICAvLyAgICAgICAgICAgfTtcclxuICAvLyAgICAgICAgIH0pO1xyXG4gIC8vICAgICAgICAgZm9ybWF0dGVkRGF0YS5wdXNoKHtcclxuICAvLyAgICAgICAgICAgX2lkOiBcIlwiLFxyXG4gIC8vICAgICAgICAgICBpZDogXCJcIixcclxuICAvLyAgICAgICAgICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgLy8gICAgICAgICAgIHJlY2VpcHRfbm86IFwiXCIsXHJcbiAgLy8gICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAvLyAgICAgICAgICAgcGF5X3R5cGU6IFwiXCIsXHJcbiAgLy8gICAgICAgICAgIGJhbGFuY2UsXHJcbiAgLy8gICAgICAgICB9KTtcclxuICAvLyAgICAgICAgIHNldEJvcnJvd2Vyc0RhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgLy8gICAgICAgfSBlbHNlIHtcclxuICAvLyAgICAgICAgIHNldEJvcnJvd2Vyc0RhdGEoW10pO1xyXG4gIC8vICAgICAgIH1cclxuICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbG9hbiBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAvLyAgICAgICBzZXRCb3Jyb3dlcnNEYXRhKFtdKTtcclxuICAvLyAgICAgfSBmaW5hbGx5IHtcclxuICAvLyAgICAgICBzZXRCYXNpY0xvYWRpbmcoZmFsc2UpO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9O1xyXG5cclxuICAvLyAgIGlmIChFbnJvbGxHcm91cElkLmdyb3VwSWQgPT09IFwiTG9hblwiKSBmZXRjaEFsbExvYW5QYXltZW50c2J5SWQoKTtcclxuICAvLyB9LCBbRW5yb2xsR3JvdXBJZC50aWNrZXRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWxsTG9hblBheW1lbnRzYnlJZCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0Qm9ycm93ZXJzRGF0YShbXSk7XHJcbiAgICAgIHNldEJhc2ljTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgLy8gRmluZCBhY3R1YWwgbG9hbl9pZCBmcm9tIHNlbGVjdGVkIGxvYW5cclxuICAgICAgICBjb25zdCBzZWxlY3RlZExvYW4gPSBsb2FuQ3VzdG9tZXJzPy5vdmVyYWxsX2xvYW4/LmZpbmQoXHJcbiAgICAgICAgICAobG9hbikgPT4gbG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5faWQgPT09IEVucm9sbEdyb3VwSWQudGlja2V0XHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zdCBsb2FuSWQgPVxyXG4gICAgICAgICAgc2VsZWN0ZWRMb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/Ll9pZCB8fCBFbnJvbGxHcm91cElkLnRpY2tldDtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC9sb2FuLXBheW1lbnQvZ2V0LWFsbC1sb2FuLXBheW1lbnRzLyR7bG9hbklkfWBcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgbGV0IGJhbGFuY2UgPSAwO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChsb2FuUGF5bWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgYmFsYW5jZSArPSBOdW1iZXIobG9hblBheW1lbnQuYW1vdW50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IGxvYW5QYXltZW50Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIHBheV9kYXRlOiBmb3JtYXRQYXlEYXRlKGxvYW5QYXltZW50Py5wYXlfZGF0ZSksXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBsb2FuUGF5bWVudC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdF9ubzogbG9hblBheW1lbnQucmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgICBwYXlfdHlwZTogbG9hblBheW1lbnQucGF5X3R5cGUsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgZm9ybWF0dGVkRGF0YS5wdXNoKHtcclxuICAgICAgICAgICAgX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICBpZDogXCJcIixcclxuICAgICAgICAgICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgICAgICAgICAgIHJlY2VpcHRfbm86IFwiXCIsXHJcbiAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgcGF5X3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldEJvcnJvd2Vyc0RhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEJvcnJvd2Vyc0RhdGEoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbG9hbiBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRCb3Jyb3dlcnNEYXRhKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRCYXNpY0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChFbnJvbGxHcm91cElkLmdyb3VwSWQgPT09IFwiTG9hblwiICYmIEVucm9sbEdyb3VwSWQudGlja2V0KVxyXG4gICAgICBmZXRjaEFsbExvYW5QYXltZW50c2J5SWQoKTtcclxuICB9LCBbRW5yb2xsR3JvdXBJZC50aWNrZXRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWxsUGlnbWVQYXltZW50c2J5SWQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldFBpZ21lQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgc2V0QmFzaWNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL3BpZ21lLXBheW1lbnQvZ2V0LWFsbC1waWdtZS1wYXltZW50cy1ieS1pZC8ke0Vucm9sbEdyb3VwSWQudGlja2V0fWBcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGxldCBiYWxhbmNlID0gMDtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgocGlnbWVQYXltZW50LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBiYWxhbmNlICs9IE51bWJlcihwaWdtZVBheW1lbnQuYW1vdW50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IHBpZ21lUGF5bWVudC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBwYXlfZGF0ZTogZm9ybWF0UGF5RGF0ZShwaWdtZVBheW1lbnQ/LnBheV9kYXRlKSxcclxuICAgICAgICAgICAgICBhbW91bnQ6IHBpZ21lUGF5bWVudC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdF9ubzogcGlnbWVQYXltZW50LnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgcGF5X3R5cGU6IHBpZ21lUGF5bWVudC5wYXlfdHlwZSxcclxuICAgICAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBmb3JtYXR0ZWREYXRhLnB1c2goe1xyXG4gICAgICAgICAgICBfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGlkOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogXCJcIixcclxuICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0UGlnbWVDdXN0b21lckRhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldFBpZ21lQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBpZ21lIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRCYXNpY0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChFbnJvbGxHcm91cElkLmdyb3VwSWQgPT09IFwiUGlnbWVcIikgZmV0Y2hBbGxQaWdtZVBheW1lbnRzYnlJZCgpO1xyXG4gIH0sIFtFbnJvbGxHcm91cElkLnRpY2tldF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cEJ5SWQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtFbnJvbGxHcm91cElkLmdyb3VwSWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApIHRocm93IG5ldyBFcnJvcihcIkFQSSBFUlJPUlwiKTtcclxuICAgICAgICBzZXRHcm91cERldGFpbHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiRmFpbGVkIHRvIGZldGNoIGdyb3VwIGRldGFpbHMgYnkgSUQ6XCIsIGVyci5tZXNzYWdlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGlmIChFbnJvbGxHcm91cElkLmdyb3VwSWQgIT09IFwiTG9hblwiICYmIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCAhPT0gXCJQaWdtZVwiKVxyXG4gICAgICBmZXRjaEdyb3VwQnlJZCgpO1xyXG4gIH0sIFtFbnJvbGxHcm91cElkPy50aWNrZXRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFNjcmVlbkxvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldERldGFpbExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIHNldFNjcmVlbkxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIHNldERldGFpbExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0RGV0YWlsTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQm9ycm93ZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0TG9hbkN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9sb2FuL3VzZXIvJHtzZWxlY3RlZEdyb3VwfWApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBjb25zdCBmaWx0ZXJlZEJvcnJvd2VyRGF0YSA9IHJlc3BvbnNlLmRhdGE/Lm92ZXJhbGxfbG9hbj8ubWFwKFxyXG4gICAgICAgICAgICAobG9hbiwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBsb2FuOiBsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/LmxvYW5faWQsXHJcbiAgICAgICAgICAgICAgbG9hbl9hbW91bnQ6IGxvYW4/LmxvYW5fdmFsdWUsXHJcbiAgICAgICAgICAgICAgdGVudXJlOiBsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/LnRlbnVyZSxcclxuICAgICAgICAgICAgICBzZXJ2aWNlX2NoYXJnZTogbG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5zZXJ2aWNlX2NoYXJnZXMsXHJcbiAgICAgICAgICAgICAgdG90YWxfcGFpZF9hbW91bnQ6IGxvYW4/LnRvdGFsX3BhaWRfYW1vdW50LFxyXG4gICAgICAgICAgICAgIGJhbGFuY2U6IGxvYW4/LmJhbGFuY2UsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRCb3Jyb3dlckRhdGEoZmlsdGVyZWRCb3Jyb3dlckRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZXRMb2FuQ3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCkgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHNlbmQgbWVzc2FnZVwiKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJmYWlsZWQgdG8gZmV0Y2ggbG9hbiBjdXN0b21lcnNcIiwgZXJyLm1lc3NhZ2UpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQm9ycm93ZXJEYXRhKFtdKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIHNldEJvcnJvd2Vyc0RhdGEoW10pO1xyXG4gICAgc2V0Qm9ycm93ZXJJZChcIk5vXCIpO1xyXG4gICAgZmV0Y2hCb3Jyb3dlcigpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFBpZ21lID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50L3BpZ21lL3VzZXIvJHtzZWxlY3RlZEdyb3VwfWApO1xyXG4gICAgICAgIGNvbnNvbGUuaW5mbyhyZXNwb25zZS5kYXRhLCBcInBpZ21lXCIpO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBjb25zdCBmaWx0ZXJlZFBpZ21lRGF0YSA9IHJlc3BvbnNlLmRhdGE/Lm92ZXJhbGxfcGlnbWU/Lm1hcChcclxuICAgICAgICAgICAgKHBpZ21lLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIHBpZ21lOiBwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/LnBpZ21lX2lkLFxyXG4gICAgICAgICAgICAgIHN0YXJ0X2RhdGU6XHJcbiAgICAgICAgICAgICAgICBwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/LnN0YXJ0X2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgICBkdXJhdGlvbjogcGlnbWU/LnBpZ21lX2RldGFpbHM/LnBpZ21lPy5kdXJhdGlvbixcclxuICAgICAgICAgICAgICBtYXR1cml0eV9pbnRlcmVzdDogcGlnbWU/LnBpZ21lX2RldGFpbHM/LnBpZ21lPy5tYXR1cml0eV9pbnRlcmVzdCxcclxuICAgICAgICAgICAgICB0b3RhbF9kZXBvc2l0ZWRfYW1vdW50OiBwaWdtZT8udG90YWxfZGVwb3NpdGVkX2Ftb3VudCxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFBpZ21lRGF0YShmaWx0ZXJlZFBpZ21lRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCkgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHNlbmQgbWVzc2FnZVwiKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJmYWlsZWQgdG8gZmV0Y2ggUGlnbWUgY3VzdG9tZXJzXCIsIGVyci5tZXNzYWdlKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFBpZ21lRGF0YShbXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBzZXRQaWdtZUN1c3RvbWVyRGF0YShbXSk7XHJcbiAgICBzZXRQaWdtZUlkKFwiTm9cIik7XHJcbiAgICBmZXRjaFBpZ21lKCk7XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3VzZXIvZ2V0LXVzZXItYnktaWQvJHtzZWxlY3RlZEdyb3VwfWApO1xyXG4gICAgICAgIHNldEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuICAvLyBkaXNidXJzZW1lbnQgcmVwb3J0XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERpc2J1cnNlbWVudCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXREaXNidXJzZW1lbnRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvcGF5bWVudC1vdXQvZ2V0LXBheW1lbnQtb3V0LXJlcG9ydC1kYXlib29rYCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgdXNlcklkOiBzZWxlY3RlZEdyb3VwLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBiYWxhbmNlID0gMDtcclxuXHJcbiAgICAgICAgICAgIGJhbGFuY2UgKz0gTnVtYmVyKHBheW1lbnQuYW1vdW50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IHBheW1lbnQuX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgZGlzYnVyc2VtZW50X3R5cGU6IHBheW1lbnQuZGlzYnVyc2VtZW50X3R5cGUsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogcGF5bWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgcGF5X2RhdGU6IGZvcm1hdFBheURhdGUocGF5bWVudD8ucGF5X2RhdGUpLFxyXG4gICAgICAgICAgICAgIHRpY2tldDogcGF5bWVudC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogZm9ybWF0UGF5RGF0ZShwYXltZW50LmNyZWF0ZWRBdCksXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCxcclxuICAgICAgICAgICAgICByZWNlaXB0X25vOiBwYXltZW50LnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgcGF5X3R5cGU6IHBheW1lbnQucGF5X3R5cGUsXHJcbiAgICAgICAgICAgICAgZGlzYnVyc2VkX2J5OiBwYXltZW50LmFkbWluX3R5cGU/Lm5hbWUsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldEZpbHRlcmVkRGlzYnVyc2VtZW50KGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZERpc2J1cnNlbWVudChbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkaXNidXJzZW1lbnQgZGF0YVwiLCBlcnJvciwgZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWREaXNidXJzZW1lbnQoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldERpc2J1cnNlbWVudExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgaWYgKHNlbGVjdGVkR3JvdXApIGZldGNoRGlzYnVyc2VtZW50KCk7XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50ID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwKGdyb3VwSWQpO1xyXG4gICAgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlKGdyb3VwSWQpO1xyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICh1c2VySWQpIHtcclxuICAgICAgaGFuZGxlR3JvdXBQYXltZW50KHVzZXJJZCk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG4gIGNvbnN0IGhhbmRsZUVucm9sbEdyb3VwID0gKGV2ZW50KSA9PiB7XHJcbiAgICBjb25zdCB2YWx1ZSA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuXHJcbiAgICBpZiAodmFsdWUpIHtcclxuICAgICAgY29uc3QgW2dyb3VwSWQsIHRpY2tldF0gPSB2YWx1ZS5zcGxpdChcInxcIik7XHJcbiAgICAgIHNldEVucm9sbEdyb3VwSWQoeyBncm91cElkLCB0aWNrZXQgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRFbnJvbGxHcm91cElkKHsgZ3JvdXBJZDogXCJcIiwgdGlja2V0OiBcIlwiIH0pO1xyXG4gICAgfVxyXG4gICAgY29uc29sZS5pbmZvKGJvcnJvd2Vyc0RhdGEsIFwiIGluZm9ybWF0aW9uIGJvcnJvc3dlcnMgQURBVEFcIik7XHJcbiAgICBjb25zb2xlLmluZm8oRW5yb2xsR3JvdXBJZC5ncm91cElkLCBcIiBpbmZvcm1hdGlvbiBFbnJvbGxHcm91cElkLmdyb3VwSWRcIik7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJUcmFuc2FjdGlvbiA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBpZiAoIXNlbGVjdGVkQXVjdGlvbkdyb3VwSWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC9wYXltZW50L3VzZXJzLyR7c2VsZWN0ZWRBdWN0aW9uR3JvdXBJZH1gXHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zb2xlLmluZm8ocmVzcG9uc2UuZGF0YS5wYXltZW50cywgXCJGZXRjaGVkIHVzZXIgdHJhbnNhY3Rpb25zXCIpO1xyXG4gICAgICAgIHNldEN1c3RvbWVyVHJhbnNhY3Rpb25zKHJlc3BvbnNlLmRhdGEucGF5bWVudHMpOyAvLyA8LS0gc3RvcmUgaW4gc3RhdGVcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIGN1c3RvbWVyIHRyYW5zYWN0aW9uIGRldGFpbHNcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hDdXN0b21lclRyYW5zYWN0aW9uKCk7XHJcbiAgfSwgW3NlbGVjdGVkQXVjdGlvbkdyb3VwSWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtY3VzdG9tZXItaGlzdG9yeWAsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBwYXlfZGF0ZTogc2VsZWN0ZWREYXRlLFxyXG4gICAgICAgICAgICBncm91cElkOiBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgICAgICAgICB1c2VySWQ6IHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKHJlc3BvbnNlKTtcclxuICAgICAgICAgIGNvbnN0IHBheW1lbnREYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICAgIGNvbnN0IHRvdGFsQW1vdW50ID0gcGF5bWVudERhdGEucmVkdWNlKFxyXG4gICAgICAgICAgICAoc3VtLCBwYXltZW50KSA9PiBzdW0gKyBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgIDBcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBzZXRQYXltZW50cyh0b3RhbEFtb3VudCk7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgZ3JvdXA6IGdyb3VwLmdyb3VwX2lkLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgIG5hbWU6IGdyb3VwLnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cC51c2VyX2lkLnBob25lX251bWJlcixcclxuICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAgICAgICAgIGFtb3VudDogZ3JvdXAuYW1vdW50LFxyXG4gICAgICAgICAgICBtb2RlOiBncm91cC5wYXlfdHlwZSxcclxuICAgICAgICAgIH0pKTtcclxuICAgICAgICAgIHNldFRhYmxlRGF5Ym9vayhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgc2V0UGF5bWVudHMoMCk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hQYXltZW50cygpO1xyXG4gIH0sIFtcclxuICAgIHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQsXHJcbiAgICBzZWxlY3RlZERhdGUsXHJcbiAgICBzZWxlY3RlZFBheW1lbnRNb2RlLFxyXG4gICAgc2VsZWN0ZWRDdXN0b21lcnMsXHJcbiAgXSk7XHJcbiAgY29uc3QgbG9hbkNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5vXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5cIiwgaGVhZGVyOiBcIkxvYW4gSURcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9hbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInNlcnZpY2VfY2hhcmdlXCIsIGhlYWRlcjogXCJTZXJ2aWNlIENoYXJnZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0ZW51cmVcIiwgaGVhZGVyOiBcIlRlbnVyZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9wYWlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgcGlnbWVDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJwaWdtZVwiLCBoZWFkZXI6IFwiUGlnbWUgSURcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhcnRfZGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJkdXJhdGlvblwiLCBoZWFkZXI6IFwiZHVyYXRpb25cIiB9LFxyXG4gICAgeyBrZXk6IFwibWF0dXJpdHlfaW50ZXJlc3RcIiwgaGVhZGVyOiBcIkludHJlc3RcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfZGVwb3NpdGVkX2Ftb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgRGVwb3NpdGVkIEFtb3VudFwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICBgL2Vucm9sbC9nZXQtaW5hY3RpdmUtcmVwb3J0LyR7Z3JvdXBJZH1gXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24ocmVzcG9uc2UuZGF0YSk7XHJcblxyXG5cclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhXHJcbiAgICAgICAgICAgIC5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IGdyb3VwPy5lbnJvbGxtZW50Py5ncm91cD8uZ3JvdXBfbmFtZSB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHRpY2tldHMgPSBncm91cD8uZW5yb2xsbWVudD8udGlja2V0cyB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdyb3VwVHlwZSA9IGdyb3VwPy5lbnJvbGxtZW50Py5ncm91cD8uZ3JvdXBfdHlwZTtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cEluc3RhbGwgPVxyXG4gICAgICAgICAgICAgICAgcGFyc2VJbnQoZ3JvdXA/LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9pbnN0YWxsKSB8fCAwO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGF1Y3Rpb25Db3VudCA9IHBhcnNlSW50KGdyb3VwPy5hdWN0aW9uPy5hdWN0aW9uQ291bnQpIHx8IDA7XHJcbiAgICAgICAgICAgICAgY29uc3QgdG90YWxQYWlkQW1vdW50ID0gZ3JvdXA/LnBheW1lbnRzPy50b3RhbFBhaWRBbW91bnQgfHwgMDtcclxuICAgICAgICAgICAgICBjb25zdCB0b3RhbFByb2ZpdCA9IGdyb3VwPy5wcm9maXQ/LnRvdGFsUHJvZml0IHx8IDA7XHJcbiAgICAgICAgICAgICAgY29uc3QgdG90YWxQYXlhYmxlID0gZ3JvdXA/LnBheWFibGU/LnRvdGFsUGF5YWJsZSB8fCAwO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGZpcnN0RGl2aWRlbnRIZWFkID1cclxuICAgICAgICAgICAgICAgIGdyb3VwPy5maXJzdEF1Y3Rpb24/LmZpcnN0RGl2aWRlbnRIZWFkIHx8IDA7XHJcblxyXG4gICAgICAgICAgICAgIGlmICghZ3JvdXA/LmVucm9sbG1lbnQ/Lmdyb3VwKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXA6IGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgIHRpY2tldDogdGlja2V0cyxcclxuXHJcbiAgICAgICAgICAgICAgICB0b3RhbEJlUGFpZDpcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBUeXBlID09PSBcImRvdWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBncm91cEluc3RhbGwgKiBhdWN0aW9uQ291bnQgKyBncm91cEluc3RhbGxcclxuICAgICAgICAgICAgICAgICAgICA6IHRvdGFsUGF5YWJsZSArIGdyb3VwSW5zdGFsbCArIHRvdGFsUHJvZml0LFxyXG5cclxuICAgICAgICAgICAgICAgIHByb2ZpdDogdG90YWxQcm9maXQsXHJcblxyXG4gICAgICAgICAgICAgICAgdG9CZVBhaWRBbW91bnQ6XHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwVHlwZSA9PT0gXCJkb3VibGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gZ3JvdXBJbnN0YWxsICogYXVjdGlvbkNvdW50ICsgZ3JvdXBJbnN0YWxsXHJcbiAgICAgICAgICAgICAgICAgICAgOiB0b3RhbFBheWFibGUgKyBncm91cEluc3RhbGwgKyBmaXJzdERpdmlkZW50SGVhZCxcclxuXHJcbiAgICAgICAgICAgICAgICBwYWlkQW1vdW50OiB0b3RhbFBhaWRBbW91bnQsXHJcblxyXG4gICAgICAgICAgICAgICAgYmFsYW5jZTpcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBUeXBlID09PSBcImRvdWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBncm91cEluc3RhbGwgKiBhdWN0aW9uQ291bnQgK1xyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwSW5zdGFsbCAtXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWxQYWlkQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgOiB0b3RhbFBheWFibGUgK1xyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwSW5zdGFsbCArXHJcbiAgICAgICAgICAgICAgICAgICAgZmlyc3REaXZpZGVudEhlYWQgLVxyXG4gICAgICAgICAgICAgICAgICAgIHRvdGFsUGFpZEFtb3VudCxcclxuICAgICAgICAgICAgICAgIHJlZmVycmVkX3R5cGU6IGdyb3VwPy5lbnJvbGxtZW50Py5yZWZlcnJlZF90eXBlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICByZWZlcnJlcl9uYW1lOiBncm91cD8uZW5yb2xsbWVudD8ucmVmZXJyZXJfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6XHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwPy5lbnJvbGxtZW50Py5jaGl0X2Fza2luZ19tb250aCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJfc3RhdHVzOiBncm91cD8uZW5yb2xsbWVudD8uY3VzdG9tZXJfc3RhdHVzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICByZW1vdmFsX3JlYXNvbjogZ3JvdXA/LmVucm9sbG1lbnQ/LnJlbW92YWxfcmVhc29uIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICBpc1ByaXplZDpcclxuICAgICAgICAgICAgICAgICAgZ3JvdXA/LmVucm9sbG1lbnQ/LmlzUHJpemVkID09PSB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcIlByaXplZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIlVuIFByaXplZFwiIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmZpbHRlcigoaXRlbSkgPT4gaXRlbSAhPT0gbnVsbClcclxuICAgICAgICAgICAgLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5jdXN0b21lcl9zdGF0dXMgPT09IFwiSW4gQWN0aXZlXCIpO1xyXG4gICAgICAgICAgc2V0VGFibGVBdWN0aW9ucyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICAgIHNldENvbW1pc3Npb24oMCk7XHJcbiAgICAgICAgICBjb25zdCB0b3RhbFRvQmVQYWlkQW1vdW50ID0gZm9ybWF0dGVkRGF0YVxyXG4gICAgICAgICAgICAuZmlsdGVyKChzdW1tYXJ5KSA9PiBzdW1tYXJ5LmN1c3RvbWVyX3N0YXR1cyA9PT0gXCJJbiBBY3RpdmVcIilcclxuICAgICAgICAgICAgLnJlZHVjZSgoc3VtLCBncm91cCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiBzdW0gKyAoZ3JvdXA/LnRvdGFsQmVQYWlkIHx8IDApO1xyXG4gICAgICAgICAgICB9LCAwKTtcclxuICAgICAgICAgIHNldFRvdGFsVG9CZVBhaWQodG90YWxUb0JlUGFpZEFtb3VudCk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdG90YWxOZXRUb0JlUGFpZEFtb3VudCA9IGZvcm1hdHRlZERhdGFcclxuICAgICAgICAgICAgLmZpbHRlcigoc3VtbWFyeSkgPT4gc3VtbWFyeS5jdXN0b21lcl9zdGF0dXMgPT09IFwiSW4gQWN0aXZlXCIpXHJcbiAgICAgICAgICAgIC5yZWR1Y2UoKHN1bSwgZ3JvdXApID0+IHtcclxuICAgICAgICAgICAgICByZXR1cm4gc3VtICsgKGdyb3VwPy50b0JlUGFpZEFtb3VudCB8fCAwKTtcclxuICAgICAgICAgICAgfSwgMCk7XHJcbiAgICAgICAgICBzZXROZXRUb3RhbFByb2ZpdCh0b3RhbE5ldFRvQmVQYWlkQW1vdW50KTtcclxuXHJcbiAgICAgICAgICBjb25zdCB0b3RhbFBhaWRBbW91bnQgPSBmb3JtYXR0ZWREYXRhXHJcbiAgICAgICAgICAgIC5maWx0ZXIoKHN1bW1hcnkpID0+IHN1bW1hcnkuY3VzdG9tZXJfc3RhdHVzID09PSBcIkluIEFjdGl2ZVwiKVxyXG4gICAgICAgICAgICAucmVkdWNlKChzdW0sIGdyb3VwKSA9PiBzdW0gKyAoZ3JvdXA/LnBhaWRBbW91bnQgfHwgMCksIDApO1xyXG4gICAgICAgICAgc2V0VG90YWxQYWlkKHRvdGFsUGFpZEFtb3VudCk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdG90YWxQcm9maXQgPSBmb3JtYXR0ZWREYXRhXHJcbiAgICAgICAgICAgIC5maWx0ZXIoKHN1bW1hcnkpID0+IHN1bW1hcnkuY3VzdG9tZXJfc3RhdHVzID09PSBcIkluIEFjdGl2ZVwiKVxyXG4gICAgICAgICAgICAucmVkdWNlKChzdW0sIGdyb3VwKSA9PiBzdW0gKyAoZ3JvdXA/LnByb2ZpdCB8fCAwKSwgMCk7XHJcbiAgICAgICAgICBzZXRUb3RhbFByb2ZpdCh0b3RhbFByb2ZpdCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgICBzZXRDb21taXNzaW9uKDApO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICBzZXRDb21taXNzaW9uKDApO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICBzZXRDb21taXNzaW9uKDApO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICh1c2VySWQpIHtcclxuICAgICAgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlKHVzZXJJZCk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG4gIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9zdGF0dXNcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJyZW1vdmFsX3JlYXNvblwiLCBoZWFkZXI6IFwiUmVtb3ZhbCBSZWFzb25cIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZXIgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlcl9uYW1lXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJjaGl0X2Fza2luZ19tb250aFwiLCBoZWFkZXI6IFwiQ2hpdCBBc2tpbmcgTW9udGhcIiB9LFxyXG4gICAgeyBrZXk6IFwiaXNQcml6ZWRcIiwgaGVhZGVyOiBcIklzIFByaXplZFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbEJlUGFpZFwiLCBoZWFkZXI6IFwiQW1vdW50IHRvIGJlIFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicHJvZml0XCIsIGhlYWRlcjogXCJQcm9maXRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG9CZVBhaWRBbW91bnRcIiwgaGVhZGVyOiBcIk5ldCBUbyBiZSBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcInBhaWRBbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZvcm1hdFBheURhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgcmV0dXJuIGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRW5yb2xsID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRUYWJsZUVucm9sbHMoW10pO1xyXG4gICAgICBzZXRCYXNpY0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL2Vucm9sbC9nZXQtdXNlci1wYXltZW50P2dyb3VwX2lkPSR7RW5yb2xsR3JvdXBJZC5ncm91cElkfSZ0aWNrZXQ9JHtFbnJvbGxHcm91cElkLnRpY2tldH0mdXNlcl9pZD0ke3NlbGVjdGVkR3JvdXB9YFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuXHJcbiAgICAgICAgICBjb25zdCBQYWlkID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICAgIHNldEdyb3VwUGFpZChQYWlkWzBdLmdyb3VwUGFpZEFtb3VudCk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdG9CZVBhaWQgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgICAgc2V0R3JvdXBUb0JlUGFpZCh0b0JlUGFpZFswXS50b3RhbFRvQmVQYWlkQW1vdW50KTtcclxuXHJcbiAgICAgICAgICBsZXQgYmFsYW5jZSA9IDA7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBiYWxhbmNlICs9IE51bWJlcihncm91cC5hbW91bnQpO1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgZGF0ZTogZm9ybWF0UGF5RGF0ZShncm91cD8ucGF5X2RhdGUpLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogZ3JvdXAuYW1vdW50LFxyXG4gICAgICAgICAgICAgIHJlY2VpcHQ6IGdyb3VwLnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IGdyb3VwLm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIHR5cGU6IGdyb3VwLnBheV90eXBlLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGZvcm1hdHRlZERhdGEucHVzaCh7XHJcbiAgICAgICAgICAgIGlkOiBcIlwiLFxyXG4gICAgICAgICAgICBkYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHJlY2VpcHQ6IFwiXCIsXHJcbiAgICAgICAgICAgIG9sZF9yZWNlaXB0OiBcIlwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgc2V0VGFibGVFbnJvbGxzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICAgIHNldFRhYmxlRW5yb2xscyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICBzZXRUYWJsZUVucm9sbHMoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldEJhc2ljTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGlmIChFbnJvbGxHcm91cElkLmdyb3VwSWQgIT09IFwiTG9hblwiICYmIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCAhPT0gXCJQaWdtZVwiKVxyXG4gICAgICBmZXRjaEVucm9sbCgpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwLCBFbnJvbGxHcm91cElkLmdyb3VwSWQsIEVucm9sbEdyb3VwSWQudGlja2V0XSk7XHJcblxyXG4gIGNvbnN0IEJhc2ljY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0XCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0XCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJ0eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBwYXJ0cyA9IGRhdGVTdHJpbmcuc3BsaXQoXCItXCIpO1xyXG4gICAgaWYgKHBhcnRzLmxlbmd0aCA9PT0gMykge1xyXG4gICAgICByZXR1cm4gYCR7cGFydHNbMl19LSR7cGFydHNbMV19LSR7cGFydHNbMF19YDtcclxuICAgIH1cclxuICAgIHJldHVybiBkYXRlU3RyaW5nO1xyXG4gIH07XHJcbiAgY29uc3QgZm9ybWF0dGVkRnJvbURhdGUgPSBmb3JtYXREYXRlKGZyb21EYXRlKTtcclxuICBjb25zdCBmb3JtYXR0ZWRUb0RhdGUgPSBmb3JtYXREYXRlKHRvRGF0ZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVucm9sbCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL2dyb3VwLXJlcG9ydC9nZXQtZ3JvdXAtZW5yb2xsLWRhdGUvJHtzZWxlY3RlZEdyb3VwfT9mcm9tRGF0ZT0ke2Zvcm1hdHRlZEZyb21EYXRlfSZ0b0RhdGU9JHtmb3JtYXR0ZWRUb0RhdGV9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IFBhaWQgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgICAgc2V0R3JvdXBQYWlkRGF0ZShQYWlkWzBdLmdyb3VwUGFpZEFtb3VudCB8fCAwKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB0b0JlUGFpZCA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgICBzZXRHcm91cFRvQmVQYWlkRGF0ZSh0b0JlUGFpZFswXS50b3RhbFRvQmVQYWlkQW1vdW50KTtcclxuXHJcbiAgICAgICAgICBjb25zdCB0b3RhbEFtb3VudCA9IHJlc3BvbnNlLmRhdGEucmVkdWNlKFxyXG4gICAgICAgICAgICAoc3VtLCBncm91cCkgPT4gc3VtICsgcGFyc2VJbnQoZ3JvdXAuYW1vdW50KSxcclxuICAgICAgICAgICAgMFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHNldFRvdGFsQW1vdW50KHRvdGFsQW1vdW50KTtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcj8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgIHRpY2tldDogZ3JvdXAudGlja2V0LFxyXG4gICAgICAgICAgICBhbW91bnRfdG9fYmVfcGFpZDpcclxuICAgICAgICAgICAgICBwYXJzZUludChncm91cC5ncm91cC5ncm91cF9pbnN0YWxsKSArIGdyb3VwLnRvdGFsVG9CZVBhaWRBbW91bnQsXHJcbiAgICAgICAgICAgIGFtb3VudF9wYWlkOiBncm91cC50b3RhbFBhaWRBbW91bnQsXHJcbiAgICAgICAgICAgIGFtb3VudF9iYWxhbmNlOlxyXG4gICAgICAgICAgICAgIHBhcnNlSW50KGdyb3VwLmdyb3VwLmdyb3VwX2luc3RhbGwpICtcclxuICAgICAgICAgICAgICBncm91cC50b3RhbFRvQmVQYWlkQW1vdW50IC1cclxuICAgICAgICAgICAgICBncm91cC50b3RhbFBhaWRBbW91bnQsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICBzZXRUYWJsZUVucm9sbHNEYXRlKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICAgIHNldFRvdGFsQW1vdW50KDApO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgICAgc2V0VG90YWxBbW91bnQoMCk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEVucm9sbCgpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwLCBmb3JtYXR0ZWRGcm9tRGF0ZSwgZm9ybWF0dGVkVG9EYXRlXSk7XHJcblxyXG4gIGNvbnN0IERhdGVjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudF90b19iZV9wYWlkXCIsIGhlYWRlcjogXCJBbW91bnQgdG8gYmUgUGFpZFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRfcGFpZFwiLCBoZWFkZXI6IFwiQW1vdW50IFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50X2JhbGFuY2VcIiwgaGVhZGVyOiBcIkFtb3VudCBCYWxhbmNlXCIgfSxcclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGdyb3VwSW5mbyAmJiBmb3JtRGF0YS5iaWRfYW1vdW50KSB7XHJcbiAgICAgIGNvbnN0IGNvbW1pc3Npb24gPSAoZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlICogNSkgLyAxMDAgfHwgMDtcclxuICAgICAgY29uc3Qgd2luX2Ftb3VudCA9XHJcbiAgICAgICAgKGdyb3VwSW5mby5ncm91cF92YWx1ZSB8fCAwKSAtIChmb3JtRGF0YS5iaWRfYW1vdW50IHx8IDApO1xyXG4gICAgICBjb25zdCBkaXZpZGVudCA9IChmb3JtRGF0YS5iaWRfYW1vdW50IHx8IDApIC0gY29tbWlzc2lvbjtcclxuICAgICAgY29uc3QgZGl2aWRlbnRfaGVhZCA9IGdyb3VwSW5mby5ncm91cF9tZW1iZXJzXHJcbiAgICAgICAgPyBkaXZpZGVudCAvIGdyb3VwSW5mby5ncm91cF9tZW1iZXJzXHJcbiAgICAgICAgOiAwO1xyXG4gICAgICBjb25zdCBwYXlhYmxlID0gKGdyb3VwSW5mby5ncm91cF9pbnN0YWxsIHx8IDApIC0gZGl2aWRlbnRfaGVhZDtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIGdyb3VwX2lkOiBncm91cEluZm8uX2lkLFxyXG4gICAgICAgIGNvbW1pc3Npb24sXHJcbiAgICAgICAgd2luX2Ftb3VudCxcclxuICAgICAgICBkaXZpZGVudCxcclxuICAgICAgICBkaXZpZGVudF9oZWFkLFxyXG4gICAgICAgIHBheWFibGUsXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9LCBbZ3JvdXBJbmZvLCBmb3JtRGF0YS5iaWRfYW1vdW50XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRHcm91cCkge1xyXG4gICAgICBhcGlcclxuICAgICAgICAucG9zdChgL2Vucm9sbC9nZXQtbmV4dC10aWNrZXRzLyR7c2VsZWN0ZWRHcm91cH1gKVxyXG4gICAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgc2V0QXZhaWxhYmxlVGlja2V0cyhyZXNwb25zZS5kYXRhLmF2YWlsYWJsZVRpY2tldHMgfHwgW10pO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF2YWlsYWJsZSB0aWNrZXRzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRBdmFpbGFibGVUaWNrZXRzKFtdKTtcclxuICAgIH1cclxuICB9LCBbc2VsZWN0ZWRHcm91cF0pO1xyXG4gIGlmIChzY3JlZW5Mb2FkaW5nKVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlbiBtLTI0XCI+XHJcbiAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIiBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtdC0zMFwiPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIFJlcG9ydHMgLSBJbiBBY3RpdmUgQ3VzdG9tZXJcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdy1mdWxsIGdhcC00IGJnLXZpb2xldC01MCAgICBwLTIgdy0zMCBoLTQwICByb3VuZGVkLTN4bCAgYm9yZGVyICAgc3BhY2UteC0yICBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LWxnIHRleHQtZ3JheS01MDAgdGV4dC1jZW50ZXIgIGZvbnQtc2VtaWJvbGQgbWItMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPXtcIlNTXCJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgSW4gQWN0aXZlIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIlNTXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cFBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3IgU2VsZWN0IEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogXCI1MHB4XCIsIHdpZHRoOiBcIjYwMHB4XCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmZ1bGxfbmFtZX0gLSB7Z3JvdXAucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7c2VsZWN0ZWRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LXN0YXJ0IGJvcmRlci1iIGJvcmRlci1ncmF5LTMwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTYgcHktMiBmb250LW1lZGl1bSAke2FjdGl2ZVRhYiA9PT0gXCJncm91cERldGFpbHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItYi0yIGJvcmRlci12aW9sZXQtNTAwIHRleHQtdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUYWJDaGFuZ2UoXCJncm91cERldGFpbHNcIil9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNiBweS0yIGZvbnQtbWVkaXVtICR7YWN0aXZlVGFiID09PSBcImJhc2ljUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWItMiBib3JkZXItdmlvbGV0LTUwMCB0ZXh0LXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVGFiQ2hhbmdlKFwiYmFzaWNSZXBvcnRcIil9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBMZWRnZXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNiBweS0yIGZvbnQtbWVkaXVtICR7YWN0aXZlVGFiID09PSBcImRpc2J1cnNlbWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1iLTIgYm9yZGVyLXZpb2xldC01MDAgdGV4dC12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRhYkNoYW5nZShcImRpc2J1cnNlbWVudFwiKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBheU91dCB8IERpc2J1cnNlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lclJlcG9ydFByaW50KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYWJsZUF1Y3Rpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRCb3Jyb3dlckRhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJlZERpc2J1cnNlbWVudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWxUb0JlcGFpZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWxwcm9maXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5ldFRvdGFscHJvZml0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbHBhaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVFbnJvbGxzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJUcmFuc2FjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNiBweS0yIGJnLXZpb2xldC01MDAgdGV4dC13aGl0ZSByb3VuZGVkIHNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW9NZERvd25sb2FkIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBGdWxsIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiZ3JvdXBEZXRhaWxzXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2RldGFpbHNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwPmxvYWRpbmcuLi48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LWxnICBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC00IGZsZXggaXRlbXMtY2VudGVyIHRleHQtZ3JheS00MDAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlTZWFyY2ggY2xhc3NOYW1lPVwidGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggY3VzdG9tZXIgZGV0YWlscy4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTIgcHItNSBweS0zLjUgdGV4dC1ncmF5LTgwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBzaGFkb3ctM3hsIFxyXG4gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXItZ3JheS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC00MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC00MDAgXHJcbiAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgdGV4dC1zbSBtZDp0ZXh0LWJhc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VhcmNoVGV4dCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZXRhaWxzQXJyYXkgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiBcIk5hbWVcIiwgdmFsdWU6IGdyb3VwLmZ1bGxfbmFtZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJFbWFpbFwiLCB2YWx1ZTogZ3JvdXAuZW1haWwgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiUGhvbmVcIiwgdmFsdWU6IGdyb3VwLnBob25lX251bWJlciB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIkFsdGVybmF0ZSBOdW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZ3JvdXAuYWx0ZXJuYXRlX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiQWRkcmVzc1wiLCB2YWx1ZTogZ3JvdXAuYWRkcmVzcyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJBYWRoYWFyXCIsIHZhbHVlOiBncm91cC5hZGhhYXJfbm8gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiUEFOXCIsIHZhbHVlOiBncm91cC5wYW5fbm8gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiUGluY29kZVwiLCB2YWx1ZTogZ3JvdXAucGluY29kZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIkZhdGhlciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGdyb3VwLmZhdGhlcl9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIk5vbWluZWUgTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBncm91cC5ub21pbmVlX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiQmFuayBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGdyb3VwLmJhbmtfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJCYW5rIEFjY291bnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZ3JvdXAuYmFua19hY2NvdW50X251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZnVzZSA9IG5ldyBGdXNlKGRldGFpbHNBcnJheSwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXlzOiBbXCJrZXlcIiwgXCJ2YWx1ZVwiXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyZXNob2xkOiAwLjMsIC8vIEZ1enp5IG1hdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRzID0gZnVzZS5zZWFyY2goc2VhcmNoVGV4dCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGJnLXdoaXRlIGJvcmRlciByb3VuZGVkIHNoYWRvdyBwLTMgdy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0cy5tYXAoKHsgaXRlbSB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ua2V5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSBib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e2l0ZW0ua2V5fTwvc3Ryb25nPiDihpJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udmFsdWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+Tm8gbWF0Y2hpbmcgZGV0YWlsczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVG9nZ2xlIEJ1dHRvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZpc2libGVSb3dzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93MTogIXByZXYucm93MSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0XHJcbiAgICAgICAgJHt2aXNpYmxlUm93cy5yb3cxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MDAgdG8tZ3JlZW4tNzAwIHRleHQtd2hpdGUgc2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC03MDAgdG8tdmlvbGV0LTkwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTA1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlUm93cy5yb3cxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCLinJMgSGlkZSBCYXNpYyBJbmZvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNob3cgQmFzaWMgSW5mb1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWaXNpYmxlUm93cygocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzI6ICFwcmV2LnJvdzIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yIHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dFxyXG4gICAgICAgICR7dmlzaWJsZVJvd3Mucm93MlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNzAwIHRvLXZpb2xldC05MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNjYWxlLTEwNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93MlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwi4pyTIEhpZGUgQWRkcmVzcyBJbmZvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNob3cgQWRkcmVzcyBJbmZvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZpc2libGVSb3dzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93MzogIXByZXYucm93MyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0XHJcbiAgICAgICAgJHt2aXNpYmxlUm93cy5yb3czXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MDAgdG8tZ3JlZW4tNzAwIHRleHQtd2hpdGUgc2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC03MDAgdG8tdmlvbGV0LTkwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTA1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlUm93cy5yb3czXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCLinJMgSGlkZSBSZWdpb25hbCBJbmZvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNob3cgUmVnaW9uYWwgSW5mb1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWaXNpYmxlUm93cygocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzQ6ICFwcmV2LnJvdzQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yIHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dFxyXG4gICAgICAgICR7dmlzaWJsZVJvd3Mucm93NFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNzAwIHRvLXZpb2xldC05MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNjYWxlLTEwNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93NFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwi4pyTIEhpZGUgUmVmZXJyYWwsIE5vbWluZWUgJiBCYW5rIERldGFpbHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiU2hvdyBSZWZlcnJhbCwgTm9taW5lZSAmIEJhbmsgRGV0YWlsc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSb3cgMTogQmFzaWMgSW5mbyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVSb3dzLnJvdzEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtOCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgdy1mdWxsIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPVwiRW1haWxcIiB2YWx1ZT17Z3JvdXAuZW1haWx9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQWRoYWFyIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlBBTiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5wYW5fbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSb3cgMjogQWRkcmVzcyBJbmZvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93MiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC04IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJHZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5nZW5kZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJEYXRlIG9mIEJpcnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cC5kYXRlb2ZiaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGdyb3VwLmRhdGVvZmJpcnRoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ29sbGVjdGlvbiBBcmVhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXA/LmNvbGxlY3Rpb25fYXJlYT8ucm91dGVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIk1hcml0YWwgU3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAubWFyaXRhbF9zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRmF0aGVyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5mYXRoZXJfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJvdyAzOiBSZWdpb25hbCBJbmZvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93MyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC04IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJOYXRpb25hbGl0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLm5hdGlvbmFsaXR5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC52aWxsYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTQgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCBsYWJlbD1cIlRhbHVrXCIgdmFsdWU9e2dyb3VwLnRhbHVrfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRpc3RyaWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuZGlzdHJpY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPVwiU3RhdGVcIiB2YWx1ZT17Z3JvdXAuc3RhdGV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQWx0ZXJuYXRlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmFsdGVybmF0ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSb3cgNDogUmVmZXJyYWwsIE5vbWluZWUgJiBCYW5rIEluZm8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlUm93cy5yb3c0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTggbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlJlZmVycmFsIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5yZWZlcnJhbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIk5vbWluZWUgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLm5vbWluZWVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJOb21pbmVlIERPQlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXAubm9taW5lZV9kYXRlb2ZiaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGdyb3VwLm5vbWluZWVfZGF0ZW9mYmlydGgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIk5vbWluZWUgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAubm9taW5lZV9waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTm9taW5lZSBSZWxhdGlvbnNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5ub21pbmVlX3JlbGF0aW9uc2hpcH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIEJyYW5jaCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuYmFua19icmFuY2hfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIEFjY291bnQgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuYmFua19hY2NvdW50X251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIElGU0MgQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmJhbmtfSUZTQ19jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbnJvbGxlZCBHcm91cHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENoYW5nZWQgY29uZGl0aW9uYWwgdG8gY2hlY2sgVGFibGVBdWN0aW9ucyBkaXJlY3RseSwgYXMgaXQncyB0aGUgZm9ybWF0dGVkIGRhdGEgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtUYWJsZUF1Y3Rpb25zICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVBdWN0aW9ucy5sZW5ndGggPiAwICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhYmxlQXVjdGlvbnMsIC8vIFVzZSBUYWJsZUF1Y3Rpb25zIGZvciBkaXNwbGF5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoVGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgSW5BY3RpdmUgQ3VzdG9tZXIgRGV0YWlscyBSZXBvcnRgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgQW1vdW50IFBheWFibGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIFByb2ZpdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgTmV0IFRvIGJlIFBhaWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIEJhbGFuY2VcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cC5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbFRvQmVwYWlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFscHJvZml0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5ldFRvdGFscHJvZml0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5ldFRvdGFscHJvZml0ICYmIFRvdGFscGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBOZXRUb3RhbHByb2ZpdCAtIFRvdGFscGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BJbkFjdGl2ZSBDdXN0b21lciBEZXRhaWxzIFJlcG9ydC0ke1RhYmxlQXVjdGlvbnMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gVGFibGVBdWN0aW9uc1swXS5kYXRlICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIiB0byBcIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVBdWN0aW9uc1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhYmxlQXVjdGlvbnMubGVuZ3RoIC0gMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0uZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJlbXB0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiB5ZXMgeW91IGNhbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEJvcnJvd2VyRGF0YS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExvYW4gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRCb3Jyb3dlckRhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtsb2FuQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lciBMb2FuIFJlcG9ydC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ3VzdG9tZXIgTG9hbiBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRQaWdtZURhdGEubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaWdtZSBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFBpZ21lRGF0YX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e3BpZ21lQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEN1c3RvbWVyIFBpZ21lIERldGFpbHMuY3N2YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkN1c3RvbWVyIFBpZ21lIERldGFpbHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXtpc0xvYWRpbmd9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGlzcGxheSBcIk5vIERhdGFcIiBpZiBub3QgbG9hZGluZyBhbmQgVGFibGVBdWN0aW9ucyBpcyBlbXB0eSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0xvYWRpbmcgJiYgVGFibGVBdWN0aW9ucy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00MCB3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIEVucm9sbGVkIEdyb3VwIERhdGEgRm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG10LTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgQW1vdW50IHRvIGJlIFBhaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtUb3RhbFRvQmVwYWlkIHx8IFwiXCJ9IC8vIERlZmF1bHQgdG8gZW1wdHkgc3RyaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhUb3RhbFRvQmVwYWlkIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFByb2ZpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1RvdGFscHJvZml0IHx8IFwiXCJ9IC8vIERlZmF1bHQgdG8gZW1wdHkgc3RyaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhUb3RhbHByb2ZpdCB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBOZXQgVG8gYmUgUGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e05ldFRvdGFscHJvZml0IHx8IFwiXCJ9IC8vIERlZmF1bHQgdG8gZW1wdHkgc3RyaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhOZXRUb3RhbHByb2ZpdCB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBBbW91bnQgUGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1RvdGFscGFpZCB8fCBcIlwifSAvLyBEZWZhdWx0IHRvIGVtcHR5IHN0cmluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDAgcGwtM2B9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoVG90YWxwYWlkIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTmV0VG90YWxwcm9maXQgJiYgVG90YWxwYWlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBOZXRUb3RhbHByb2ZpdCAtIFRvdGFscGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSAvLyBDYWxjdWxhdGUgb25seSBpZiBib3RoIGFyZSBudW1iZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhOZXRUb3RhbHByb2ZpdCAmJiBUb3RhbHBhaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBOZXRUb3RhbHByb2ZpdCAtIFRvdGFscGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiB7YWN0aXZlVGFiID09PSBcImJhc2ljUmVwb3J0XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXBzIGFuZCBUaWNrZXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbnJvbGxHcm91cElkLmdyb3VwSWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgJHtFbnJvbGxHcm91cElkLmdyb3VwSWR9fCR7RW5yb2xsR3JvdXBJZC50aWNrZXR9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVucm9sbEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC02IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHcm91cCB8IFRpY2tldDwvb3B0aW9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRBdWN0aW9uLm1hcCgoZ3JvdXApID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChncm91cD8uZW5yb2xsbWVudD8uZ3JvdXApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2dyb3VwLmVucm9sbG1lbnQuZ3JvdXAuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake2dyb3VwLmVucm9sbG1lbnQuZ3JvdXAuX2lkfXwke2dyb3VwLmVucm9sbG1lbnQudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5lbnJvbGxtZW50Lmdyb3VwLmdyb3VwX25hbWV9IHx7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZW5yb2xsbWVudC50aWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBcnJheS5pc0FycmF5KGxvYW5DdXN0b21lcnMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGxvYW5DdXN0b21lcnMubWFwKChsb2FuKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsb2FuLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgTG9hbnwke2xvYW4uX2lkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake2xvYW4ubG9hbl9pZCB8fCBcIk4vQVwifSB8IOKCuSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYW4ubG9hbl9hbW91bnQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEFycmF5LmlzQXJyYXkobG9hbkN1c3RvbWVycz8ub3ZlcmFsbF9sb2FuKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBsb2FuQ3VzdG9tZXJzLm92ZXJhbGxfbG9hbi5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGxvYW4sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgTG9hbnwke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYW4/LmxvYW5fZGV0YWlscz8ubG9hbj8uX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/LmxvYW5faWQgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIk4vQVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gfCDigrkke2xvYW4/LmxvYW5fdmFsdWUgfHwgMH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7QXJyYXkuaXNBcnJheShwaWdtZUN1c3RvbWVycylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gcGlnbWVDdXN0b21lcnMubWFwKChwaWdtZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bG9hbi5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YFBpZ21lfCR7cGlnbWUuX2lkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake3BpZ21lLnBpZ21lX2lkIHx8IFwiTi9BXCJ9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEFycmF5LmlzQXJyYXkocGlnbWVDdXN0b21lcnM/Lm92ZXJhbGxfcGlnbWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHBpZ21lQ3VzdG9tZXJzLm92ZXJhbGxfcGlnbWUubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChwaWdtZSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BQaWdtZXwke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lPy5waWdtZV9kZXRhaWxzPy5waWdtZT8uX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/LnBpZ21lX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJOL0FcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IHwg4oK5JHtwaWdtZT8udG90YWxfZGVwb3NpdGVkX2Ftb3VudCB8fCAwfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVnaXN0cmF0aW9uRmVlLmFtb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBwLTQgYm9yZGVyIHJvdW5kZWQgYmctZ3JheS0xMDAgdy1maXQgdGV4dC1ncmF5LTgwMCBzaGFkb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWdpc3RyYXRpb24gRmVlIEluZm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkFtb3VudDo8L3N0cm9uZz4g4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWdpc3RyYXRpb25GZWUuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+RGF0ZTo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWdpc3RyYXRpb25GZWUuY3JlYXRlZEF0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVnaXN0cmF0aW9uRmVlLmNyZWF0ZWRBdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGp1c3RpZnktY2VudGVyIGdhcC04IGZsZXgtd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BSZWdpc3RyYXRpb24gRmVlOiDigrkke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVnaXN0cmF0aW9uQW1vdW50IHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZCBmb250LXNlbWlib2xkIHctNjAgdGV4dC1jZW50ZXIgYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIGJvcmRlci1ncmVlbi00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgUGF5bWVudCBCYWxhbmNlOiDigrkke2ZpbmFsUGF5bWVudEJhbGFuY2V9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZCBmb250LXNlbWlib2xkIHctNjAgdGV4dC1jZW50ZXIgYmctdmlvbGV0LTEwMCB0ZXh0LXZpb2xldC04MDAgYm9yZGVyLXZpb2xldC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgVG90YWw6IOKCuSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZmluYWxQYXltZW50QmFsYW5jZSkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKHJlZ2lzdHJhdGlvbkFtb3VudCB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciByb3VuZGVkIGZvbnQtc2VtaWJvbGQgdy02MCB0ZXh0LWNlbnRlciBiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTgwMCBib3JkZXItcHVycGxlLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhUYWJsZUVucm9sbHMgJiYgVGFibGVFbnJvbGxzLmxlbmd0aCA+IDApIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKGJvcnJvd2Vyc0RhdGEubGVuZ3RoID4gMCAmJiAhYmFzaWNMb2FkaW5nKSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkN1c3RvbWVyIExlZGdlciBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIElkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUaWNrZXQgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkdyb3VwIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU3RhcnQgRGF0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJFbmQgRGF0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwLmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXAucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW5yb2xsR3JvdXBJZC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cERldGFpbHMuZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cERldGFpbHMuc3RhcnRfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cERldGFpbHMuZW5kX2RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCA9PT0gXCJMb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBib3Jyb3dlcnNEYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogVGFibGVFbnJvbGxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW5yb2xsR3JvdXBJZC5ncm91cElkID09PSBcIkxvYW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IEJhc2ljTG9hbkNvbHVtbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBCYXNpY2NvbHVtbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17YmFzaWNMb2FkaW5nfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJiYXNpY1JlcG9ydFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwcyBhbmQgVGlja2V0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW5yb2xsR3JvdXBJZC5ncm91cElkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYCR7RW5yb2xsR3JvdXBJZC5ncm91cElkfXwke0Vucm9sbEdyb3VwSWQudGlja2V0fWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVFbnJvbGxHcm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNiBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LW1kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHcm91cCB8IFRpY2tldDwvb3B0aW9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pyFIENISVQgR3JvdXBzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEF1Y3Rpb24ubWFwKChncm91cCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cD8uZW5yb2xsbWVudD8uZ3JvdXAgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LmVucm9sbG1lbnQ/LmN1c3RvbWVyX3N0YXR1cyA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJJbiBBY3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtncm91cC5lbnJvbGxtZW50Lmdyb3VwLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtncm91cC5lbnJvbGxtZW50Lmdyb3VwLl9pZH18JHtncm91cC5lbnJvbGxtZW50LnRpY2tldHN9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZW5yb2xsbWVudC5ncm91cC5ncm91cF9uYW1lfSB8e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmVucm9sbG1lbnQudGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7QXJyYXkuaXNBcnJheShsb2FuQ3VzdG9tZXJzPy5vdmVyYWxsX2xvYW4pICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FuQ3VzdG9tZXJzLm92ZXJhbGxfbG9hbi5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChsb2FuLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYW4/LmxvYW5fZGV0YWlscz8ubG9hbj8uX2lkIHx8IGluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YExvYW58JHtsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/Ll9pZCB8fCBpbmRleFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5sb2FuX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiTi9BXCJ9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfCDigrl7bG9hbj8ubG9hbl92YWx1ZSB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7QXJyYXkuaXNBcnJheShwaWdtZUN1c3RvbWVycz8ub3ZlcmFsbF9waWdtZSkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXJzLm92ZXJhbGxfcGlnbWUubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocGlnbWUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWU/LnBpZ21lX2RldGFpbHM/LnBpZ21lPy5faWQgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgUGlnbWV8JHtwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/Ll9pZCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGlnbWU/LnBpZ21lX2RldGFpbHM/LnBpZ21lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ucGlnbWVfaWQgfHwgXCJOL0FcIn17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8IOKCuXtwaWdtZT8udG90YWxfZGVwb3NpdGVkX2Ftb3VudCB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMTAgZmxleC13cmFwXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJlZ2lzdHJhdGlvbiBGZWUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YFJlZ2lzdHJhdGlvbiBGZWU6IOKCuSR7cmVnaXN0cmF0aW9uQW1vdW50IHx8IDB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZCBmb250LXNlbWlib2xkIHctNjAgdGV4dC1jZW50ZXIgYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIGJvcmRlci1ncmVlbi00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIHRleHQtY2VudGVyIHctNjAgYnJlYWstd29yZHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhyZWdpc3RyYXRpb25BbW91bnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQYXltZW50IEJhbGFuY2UgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YFBheW1lbnQgQmFsYW5jZTog4oK5JHtmaW5hbFBheW1lbnRCYWxhbmNlIHx8IDB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZCBmb250LXNlbWlib2xkIHctNjAgdGV4dC1jZW50ZXIgYmctdmlvbGV0LTEwMCB0ZXh0LXZpb2xldC04MDAgYm9yZGVyLXZpb2xldC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgZm9udC1tb25vIHRleHQtdmlvbGV0LTcwMCB0ZXh0LWNlbnRlciB3LTYwIGJyZWFrLXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZmluYWxQYXltZW50QmFsYW5jZSB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BUb3RhbDog4oK5JHtOdW1iZXIoZmluYWxQYXltZW50QmFsYW5jZSB8fCAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIocmVnaXN0cmF0aW9uQW1vdW50IHx8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZCBmb250LXNlbWlib2xkIHctNjAgdGV4dC1jZW50ZXIgYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS04MDAgYm9yZGVyLXB1cnBsZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgZm9udC1tb25vIHRleHQtcHVycGxlLTcwMCB0ZXh0LWNlbnRlciB3LTYwIGJyZWFrLXdvcmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZmluYWxQYXltZW50QmFsYW5jZSB8fCAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIocmVnaXN0cmF0aW9uQW1vdW50IHx8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKchSBDb3JyZWN0ZWQgRGF0YSBEaXNwbGF5ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsoVGFibGVFbnJvbGxzPy5sZW5ndGggPiAwIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3Jyb3dlcnNEYXRhPy5sZW5ndGggPiAwIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdtZUN1c3RvbWVyRGF0YT8ubGVuZ3RoID4gMCkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICFiYXNpY0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBMZWRnZXIgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXIgTGVkZ2VyIFJlcG9ydC5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIElkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUaWNrZXQgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkdyb3VwIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cC5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwLnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQudGlja2V0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBEZXRhaWxzLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCA9PT0gXCJMb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBib3Jyb3dlcnNEYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogRW5yb2xsR3JvdXBJZC5ncm91cElkID09PSBcIlBpZ21lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHBpZ21lQ3VzdG9tZXJEYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBUYWJsZUVucm9sbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbnJvbGxHcm91cElkLmdyb3VwSWQgPT09IFwiTG9hblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gQmFzaWNMb2FuQ29sdW1uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEVucm9sbEdyb3VwSWQuZ3JvdXBJZCA9PT0gXCJQaWdtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBCYXNpY1BpZ21lQ29sdW1uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogQmFzaWNjb2x1bW5zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e2Jhc2ljTG9hZGluZ30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiZGlzYnVyc2VtZW50XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtICB0ZXh0LWdyYXktNzAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERpc2J1cnNlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Rpc2J1cnNlbWVudExvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBmaWx0ZXJlZERpc2J1cnNlbWVudD8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkRGlzYnVyc2VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtEaXNidXJzZW1lbnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BDdXN0b21lciBQYXlvdXQgUmVwb3J0YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEN1c3RvbWVyIFBheW91dCBSZXBvcnQuY3N2YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQaG9uZSBOdW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00MCAgdy1mdWxsIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gRGlzYnVyc2VtZW50IERhdGEgRm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSW5BY3RpdmVVc2VyUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvSW5BY3RpdmVVc2VyUmVwb3J0LmpzeCJ9