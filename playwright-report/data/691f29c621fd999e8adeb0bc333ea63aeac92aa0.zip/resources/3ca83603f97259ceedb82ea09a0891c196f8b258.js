import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Payroll.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Input, Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { fieldSize } from "/src/data/fieldSize.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { HiOutlinePlusCircle, HiOutlineTrash } from "/node_modules/.vite/deps/react-icons_hi.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const Payroll = () => {
  _s();
  const [TableEmployees, setTableEmployees] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [errors, setErrors] = useState({});
  const [searchText, setSearchText] = useState("");
  const [selectedManagerId, setSelectedManagerId] = useState("");
  const [selectedReportingManagerId, setSelectedReportingManagerId] = useState("");
  const [managers, setManagers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [selectedManagerTitle, setSelectedManagerTitle] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    // password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    agent_type: "employee",
    joining_date: "",
    status: "",
    dob: "",
    gender: "",
    alternate_number: "",
    salary: "",
    leaving_date: "",
    emergency_contact_person: "",
    emergency_contact_number: [""],
    total_allocated_leaves: "2",
    earnings: {
      basic: 0,
      hra: 0,
      travel_allowance: 0,
      medical_allowance: 0,
      basket_of_benifits: 0,
      performance_bonus: 0,
      other_allowances: 0,
      conveyance: 0
    },
    deductions: {
      income_tax: 0,
      esi: 0,
      epf: 0,
      professional_tax: 0
    },
    additional_salary: []
  });
  const [updateFormData, setUpdateFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    // password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    joining_date: "",
    status: "",
    dob: "",
    gender: "",
    alternate_number: "",
    salary: "",
    leaving_date: "",
    emergency_contact_person: "",
    emergency_contact_number: [""],
    total_allocated_leaves: "2",
    earnings: {
      basic: 0,
      hra: 0,
      travel_allowance: 0,
      medical_allowance: 0,
      basket_of_benifits: 0,
      performance_bonus: 0,
      other_allowances: 0,
      conveyance: 0
    },
    deductions: {
      income_tax: 0,
      esi: 0,
      epf: 0,
      professional_tax: 0
    },
    additional_salary: []
  });
  useEffect(() => {
    const fetchEmployeeProfile = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/employee");
        const employeeData = response.data?.employee || [];
        const formattedData = employeeData.map((group, index) => ({
          _id: group?._id,
          id: index + 1,
          name: group?.name || "N/A",
          employeeCode: group?.employeeCode || "N/A",
          phone_number: group?.phone_number || "N/A",
          // password: group?.password || "N/A",
          designation: group?.designation_id?.title || "N/A",
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 143,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 153,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 163,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 136,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 135,
            columnNumber: 11
          }, this)
        }));
        setTableEmployees(formattedData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchEmployeeProfile();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchManagers = async () => {
      try {
        const response = await api.get("/designation/get-designation");
        setManagers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchManagers();
  }, [reloadTrigger]);
  const handleAntDSelectManager = (managerId) => {
    setSelectedManagerId(managerId);
    const selected = managers.find((mgr) => mgr._id === managerId);
    const title = selected?.title || "";
    setSelectedManagerTitle(title);
    setFormData((prev) => ({
      ...prev,
      deductions: { ...prev.deductions },
      earnings: { ...prev.earnings },
      managerId,
      managerTitle: title
    }));
    setErrors((prev) => ({
      ...prev,
      managerId: "",
      managerTitle: ""
    }));
  };
  const handleAdditionalSalaryChange = (index, field, val, isUpdate = false) => {
    const setter = isUpdate ? setUpdateFormData : setFormData;
    setter((prev) => {
      const updatedList = [...prev.additional_salary];
      updatedList[index] = {
        ...updatedList[index],
        [field]: field === "value" ? val === "" ? 0 : Number(val) : val
      };
      return { ...prev, additional_salary: updatedList };
    });
  };
  const addAdditionalSalaryField = (isUpdate = false) => {
    const setter = isUpdate ? setUpdateFormData : setFormData;
    setter((prev) => ({
      ...prev,
      additional_salary: [...prev.additional_salary, { name: "", value: 0 }]
    }));
  };
  const removeAdditionalSalaryField = (index, isUpdate = false) => {
    const setter = isUpdate ? setUpdateFormData : setFormData;
    setter((prev) => ({
      ...prev,
      additional_salary: prev.additional_salary.filter((_, i) => i !== index)
    }));
  };
  const handleChange = (name, value, earnings = false, deductions = false) => {
    if (earnings) {
      setFormData((prevData) => ({
        ...prevData,
        earnings: { ...prevData.earnings, [name]: value }
      }));
    } else if (deductions) {
      setFormData((prevData) => ({
        ...prevData,
        deductions: { ...prevData.deductions, [name]: value }
      }));
    } else {
      if (name === "salary") {
        setFormData((prevData) => ({
          ...prevData,
          [name]: value
        }));
      } else {
        setFormData((prevData) => ({
          ...prevData,
          [name]: value
        }));
      }
      setErrors((prev) => ({
        ...prev,
        [name]: ""
      }));
    }
  };
  const handleAntDSelectReportingManager = (reportingId) => {
    setSelectedReportingManagerId(reportingId);
    setFormData((prev) => ({
      ...prev,
      reportingManagerId: reportingId
    }));
    setErrors((prev) => ({
      ...prev,
      reportingManagerId: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addEmployee" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      // password:
      //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{5,}$/,
      pincode: /^\d{6}$/,
      aadhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
      alternate_number: /^[6-9]\d{9}$/
    };
    if (!data.name || !data.name.trim()) {
      newErrors.name = "Full Name is required";
    }
    if (!data.email) {
      newErrors.email = "Email is required";
    } else if (!regex.email.test(data.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!data.phone_number) {
      newErrors.phone_number = "Phone number is required";
    } else if (!regex.phone.test(data.phone_number)) {
      newErrors.phone_number = "Invalid  phone number";
    }
    if (!data.alternate_number) {
      newErrors.alternate_number = "Alternate Phone number is required";
    } else if (!regex.alternate_number.test(data.alternate_number)) {
      newErrors.alternate_number = "Invalid Alternate  phone number";
    }
    if (!data.status) {
      newErrors.status = "Status is required";
    }
    if (!data.dob) {
      newErrors.dob = "Date of Birth is required";
    }
    if (!data.joining_date) {
      newErrors.joining_date = "Joining Date is required";
    }
    if (!data.gender) {
      newErrors.gender = "Please Select Gender";
    }
    if (!data.salary) {
      newErrors.salary = "Salary is required";
    }
    if (!data.pincode) {
      newErrors.pincode = "Pincode is required";
    } else if (!regex.pincode.test(data.pincode)) {
      newErrors.pincode = "Invalid pincode (6 digits required)";
    }
    if (!data.adhaar_no) {
      newErrors.adhaar_no = "Aadhaar number is required";
    } else if (!regex.aadhaar.test(data.adhaar_no)) {
      newErrors.adhaar_no = "Invalid Aadhaar number (12 digits required)";
    }
    if (!data.pan_no) {
      newErrors.pan_no = "PAN number is required";
    } else if (!regex.pan.test(data.pan_no.toUpperCase())) {
      newErrors.pan_no = "Invalid PAN format (e.g., ABCDE1234F)";
    }
    if (!data.address || !data.address.trim()) {
      newErrors.address = "Address is required";
    } else if (data.address.trim().length < 10) {
      newErrors.address = "Address should be at least 10 characters";
    }
    if (!data.emergency_contact_person) {
      newErrors.emergency_contact_person = "Contact Person Name is Required";
    }
    if (!data.total_allocated_leaves) {
      newErrors.total_allocated_leaves = "Please Provide Total Allocated Leaves";
    }
    if (!selectedManagerId) {
      newErrors.designation_id = "Please Enter Designation";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const addPhoneField = (formState, setFormState) => {
    const phones = [...formState.emergency_contact_number || []];
    const lastPhone = phones[phones.length - 1];
    if (phones.length > 0 && (!lastPhone || lastPhone.trim() === "")) {
      alert(
        "Please fill in the last emergency contact number before adding a new one."
      );
      return;
    }
    setFormState((prevState) => ({
      ...prevState,
      emergency_contact_number: [...phones, ""]
    }));
  };
  const handlePhoneChange = (formState, setFormState, index, e) => {
    const value = e.target.value;
    let phones = formState.emergency_contact_number && formState.emergency_contact_number.length > 0 ? [...formState.emergency_contact_number] : [""];
    while (phones.length <= index) {
      phones.push("");
    }
    phones[index] = value;
    const lastIndex = phones.reduceRight((lastNonEmpty, phone, i) => {
      return lastNonEmpty !== -1 ? lastNonEmpty : phone.trim() !== "" ? i : -1;
    }, -1);
    phones = lastIndex === -1 ? [""] : phones.slice(0, lastIndex + 1);
    setFormState({
      ...formState,
      emergency_contact_number: phones
    });
  };
  const removePhoneField = (formState, setFormState, index) => {
    const phones = Array.isArray(formState.emergency_contact_number) ? [...formState.emergency_contact_number] : [];
    const updatedPhones = phones.filter((_, i) => i !== index);
    setFormState({
      ...formState,
      emergency_contact_number: updatedPhones
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValidate = validateForm("addEmployee");
    try {
      const sanitizeNumber = (val) => val === "" || val == null ? 0 : Number(val);
      if (isValidate) {
        const dataToSend = {
          ...formData,
          salary: sanitizeNumber(formData.salary),
          earnings: {
            basic: sanitizeNumber(formData.earnings.basic),
            hra: sanitizeNumber(formData.earnings.hra),
            travel_allowance: sanitizeNumber(
              formData.earnings.travel_allowance
            ),
            medical_allowance: sanitizeNumber(
              formData.earnings.medical_allowance
            ),
            basket_of_benifits: sanitizeNumber(
              formData.earnings.basket_of_benifits
            ),
            performance_bonus: sanitizeNumber(
              formData.earnings.performance_bonus
            ),
            other_allowances: sanitizeNumber(
              formData.earnings.other_allowances
            ),
            conveyance: sanitizeNumber(formData.earnings.conveyance)
          },
          deductions: {
            income_tax: sanitizeNumber(formData.deductions.income_tax),
            esi: sanitizeNumber(formData.deductions.esi),
            epf: sanitizeNumber(formData.deductions.epf),
            professional_tax: sanitizeNumber(
              formData.deductions.professional_tax
            )
          },
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId
        };
        const response = await api.post("/employee/payroll", dataToSend, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        setShowModal(false);
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Employee Added Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error adding Employee:", error);
      if (error.response && error.response.data && error.response.data.message) {
        const errMsg = error.response.data.message.toLowerCase();
        if (errMsg.includes("phone number")) {
          setErrors((prevErrors) => ({
            ...prevErrors,
            phone_number: "Phone number already exists"
          }));
        } else {
          setAlertConfig({
            visibility: true,
            message: error.response.data.message,
            type: "error"
          });
        }
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Employee Name" },
    { key: "employeeCode", header: "Employee ID" },
    { key: "phone_number", header: "Employee Phone Number" },
    { key: "designation", header: "Designation" },
    // { key: "password", header: "Employee Password" },
    { key: "action", header: "Action" }
  ];
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/agent/get-additional-employee-info-by-id/${userId}`
      );
      setCurrentUser(response.data?.employee);
      setShowModalDelete(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(`/agent/get-employee-by-id/${userId}`);
      setCurrentUpdateUser(response.data?.employee);
      setUpdateFormData({
        name: response?.data?.employee?.name,
        email: response?.data?.employee?.email,
        phone_number: response?.data?.employee?.phone_number,
        // password: response?.data?.employee?.password,
        pincode: response?.data?.employee?.pincode,
        adhaar_no: response?.data?.employee?.adhaar_no,
        pan_no: response?.data?.employee?.pan_no,
        address: response?.data?.employee?.address,
        joining_date: response?.data?.employee?.joining_date?.split("T")[0],
        status: response?.data?.employee?.status,
        dob: response?.data?.employee?.dob?.split("T")[0],
        gender: response?.data?.employee?.gender,
        alternate_number: response?.data?.employee?.alternate_number,
        salary: response?.data?.employee?.salary,
        leaving_date: response?.data?.employee?.leaving_date?.split("T")[0],
        emergency_contact_number: response?.data?.employee?.emergency_contact_number || [""],
        emergency_contact_person: response?.data?.employee?.emergency_contact_person,
        total_allocated_leaves: response?.data?.employee?.total_allocated_leaves?.toString() || "2",
        earnings: {
          basic: response?.data?.employee?.earnings?.basic || 0,
          hra: response?.data?.employee?.earnings?.hra || 0,
          travel_allowance: response?.data?.employee?.earnings?.travel_allowance || 0,
          medical_allowance: response?.data?.employee?.earnings?.medical_allowance || 0,
          basket_of_benifits: response?.data?.employee?.earnings?.basket_of_benifits || 0,
          performance_bonus: response?.data?.employee?.earnings?.performance_bonus || 0,
          other_allowances: response?.data?.employee?.earnings?.other_allowances || 0,
          conveyance: response?.data?.employee?.earnings?.conveyance || 0
        },
        deductions: {
          income_tax: response?.data?.employee?.deductions?.income_tax || 0,
          esi: response?.data?.employee?.deductions?.esi || 0,
          epf: response?.data?.employee?.deductions?.epf || 0,
          professional_tax: response?.data?.employee?.deductions?.professional_tax || 0
        },
        additional_salary: response?.data?.employee?.additional_salary || []
      });
      setSelectedManagerId(response.data?.employee?.designation_id?._id || 0);
      setSelectedReportingManagerId(
        response.data?.employee?.reporting_manager_id || 0
      );
      setSelectedManagerTitle(response.data?.employee?.designation_id?.title);
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleInputChange = (name, value, earnings = false, deductions = false) => {
    if (earnings) {
      setUpdateFormData((prevData) => ({
        ...prevData,
        earnings: { ...prevData.earnings, [name]: value }
      }));
    } else if (deductions) {
      setUpdateFormData((prevData) => ({
        ...prevData,
        deductions: { ...prevData.deductions, [name]: value }
      }));
    } else {
      setUpdateFormData((prevData) => ({
        ...prevData,
        [name]: value
      }));
      setErrors((prev) => ({
        ...prev,
        [name]: ""
      }));
    }
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(
          `/agent/delete-additional-employee-info-by-id/${currentUser._id}`
        );
        setShowModalDelete(false);
        setCurrentUser(null);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        const dataToSend = {
          ...updateFormData,
          deductions: {
            ...updateFormData.deductions
          },
          earnings: {
            ...updateFormData.earnings
          },
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId
        };
        const response = await api.put(
          `/agent/update-additional-employee-info/${currentUpdateUser._id}`,
          dataToSend
        );
        setShowModalUpdate(false);
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Employee Details Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating agent:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error.response.data.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 720,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
        lineNumber: 724,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 725,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 734,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Payroll" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 737,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
                setErrors({});
              },
              className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
              children: "+ Add Employee"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 738,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 736,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 735,
          columnNumber: 13
        }, this),
        TableEmployees?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableEmployees, searchText),
            columns,
            exportedPdfName: "Employee Payroll",
            exportedFileName: `Employees Payroll.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 749,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableEmployees?.length <= 0,
            data: "Employee Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 757,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
        lineNumber: 733,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
      lineNumber: 719,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Employee" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
        lineNumber: 767,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "name",
              children: [
                "Full Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 775,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 772,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "name",
              value: formData.name,
              onChange: (e) => handleChange(e.target.name, e.target.value),
              id: "name",
              placeholder: "Enter the Full Name",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 777,
              columnNumber: 17
            },
            this
          ),
          errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 788,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 771,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "email",
                children: [
                  "Email ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 796,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 793,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "email",
                name: "email",
                value: formData.email,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "email",
                placeholder: "Enter Email",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 798,
                columnNumber: 19
              },
              this
            ),
            errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 811,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 792,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "phone_number",
                children: [
                  "Phone Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 818,
                    columnNumber: 34
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 815,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "tel",
                name: "phone_number",
                value: formData.phone_number,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "phone_number",
                placeholder: "Enter Phone Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 820,
                columnNumber: 19
              },
              this
            ),
            errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 833,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 814,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 791,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "adhaar_no",
                children: [
                  "Adhaar Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 894,
                    columnNumber: 35
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 891,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "adhaar_no",
                value: formData.adhaar_no,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "adhaar_no",
                placeholder: "Enter Adhaar Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 896,
                columnNumber: 19
              },
              this
            ),
            errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 909,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 890,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "pan_no",
                children: [
                  "Pan Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 918,
                    columnNumber: 32
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 915,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "pan_no",
                value: formData.pan_no,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "pan_no",
                placeholder: "Enter Pan Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 920,
                columnNumber: 19
              },
              this
            ),
            errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 933,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 914,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 889,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "address",
              children: [
                "Address ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 941,
                  columnNumber: 27
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 938,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "address",
              value: formData.address,
              onChange: (e) => handleChange(e.target.name, e.target.value),
              id: "address",
              placeholder: "Enter the Address",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 943,
              columnNumber: 17
            },
            this
          ),
          errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 954,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 937,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "designation_id",
                children: [
                  "Designation ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 962,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 959,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                id: "designation_id",
                name: "designation_id",
                value: selectedManagerId || void 0,
                onChange: handleAntDSelectManager,
                placeholder: "Select Designation",
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                showSearch: true,
                popupMatchSelectWidth: false,
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                children: managers.map(
                  (mgr) => /* @__PURE__ */ jsxDEV(Select.Option, { value: mgr._id, children: mgr.title }, mgr._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 979,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 964,
                columnNumber: 19
              },
              this
            ),
            errors.designation_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.designation_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 985,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 958,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "status",
                children: [
                  "Status ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 994,
                    columnNumber: 28
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 991,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                placeholder: "Select Status",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "status",
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                value: formData?.status || void 0,
                onChange: (value) => handleChange("status", value),
                children: ["Active", "Inactive", "Terminated"].map(
                  (stype) => /* @__PURE__ */ jsxDEV(Select.Option, { value: stype.toLowerCase(), children: stype }, stype, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1010,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 996,
                columnNumber: 19
              },
              this
            ),
            errors.status && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.status }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1016,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 990,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 957,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "joining_date",
                children: [
                  "Joining Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1025,
                    columnNumber: 34
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1022,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "joining_date",
                value: formData.joining_date,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "joining_date",
                placeholder: "Enter Employee Joining Date",
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1027,
                columnNumber: 19
              },
              this
            ),
            errors.joining_date && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.joining_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1039,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1021,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "leaving_date",
                children: "Leaving Date"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1045,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "leaving_date",
                value: formData.leaving_date,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "leaving_date",
                placeholder: "Enter Leaving Date",
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1050,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1044,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1020,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "dob",
                children: [
                  "Date of Birth ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1068,
                    columnNumber: 35
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1065,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "dob",
                value: formData.dob,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "dob",
                placeholder: "Enter Employee Date of Birth",
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1070,
                columnNumber: 19
              },
              this
            ),
            errors.dob && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.dob }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1082,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1064,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "gender",
                children: [
                  "Gender ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1089,
                    columnNumber: 28
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1086,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                placeholder: "Select Gender",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "gender",
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                value: formData?.gender || void 0,
                onChange: (value) => handleChange("gender", value),
                children: ["Male", "Female", "Others"].map(
                  (gender) => /* @__PURE__ */ jsxDEV(Select.Option, { value: gender.toLowerCase(), children: gender }, gender, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1105,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1091,
                columnNumber: 19
              },
              this
            ),
            errors.gender && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.gender }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1111,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1085,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1063,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "alternate_number",
                children: [
                  "Alternate Phone Number",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1121,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1117,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "tel",
                name: "alternate_number",
                value: formData.alternate_number,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "alternate_number",
                placeholder: "Enter Alternate Phone Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1123,
                columnNumber: 19
              },
              this
            ),
            errors.alternate_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.alternate_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1136,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1116,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "total_allocated_leaves",
                children: [
                  "Total Allocated Leaves",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1146,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1142,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                onWheel: (e) => e.target.blur(),
                name: "total_allocated_leaves",
                value: formData.total_allocated_leaves,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "total_allocated_leaves",
                placeholder: "Enter total allocated leaves",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1148,
                columnNumber: 19
              },
              this
            ),
            errors.total_allocated_leaves && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.total_allocated_leaves }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1162,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1141,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1115,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "emergency_contact_person",
                children: [
                  "Emergency Contact Person",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1174,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1170,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "emergency_contact_person",
                value: formData.emergency_contact_person,
                onChange: (e) => handleChange(e.target.name, e.target.value),
                id: "emergency_contact_person",
                placeholder: "Enter Emergency Contact Person Name",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1176,
                columnNumber: 19
              },
              this
            ),
            errors.emergency_contact_person && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.emergency_contact_person }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1189,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1169,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "emergency_contact_number",
                children: [
                  "Emergency Phone Number",
                  " "
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1195,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-2 gap-2", children: /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "tel",
                name: "emergency_contact_number",
                value: formData.emergency_contact_number?.[0] || "",
                onChange: (e) => handlePhoneChange(formData, setFormData, 0, e),
                id: "emergency_contact_number_0",
                placeholder: "Enter Default Emergency Phone Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1201,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1200,
              columnNumber: 19
            }, this),
            formData.emergency_contact_number?.slice(1).map(
              (phone, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-2 gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "tel",
                    name: `emergency_phone_${index + 1}`,
                    value: phone,
                    onChange: (e) => handlePhoneChange(
                      formData,
                      setFormData,
                      index + 1,
                      e
                    ),
                    id: `emergency_contact_number_${index + 1}`,
                    placeholder: "Enter Additional Emergency Phone Number",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1218,
                    columnNumber: 25
                  },
                  this
                ),
                index > 0 && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => removePhoneField(formData, setFormData, index + 1),
                    className: "text-red-600 text-sm",
                    children: "Remove"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1235,
                    columnNumber: 21
                  },
                  this
                )
              ] }, index, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1217,
                columnNumber: 19
              }, this)
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => addPhoneField(formData, setFormData),
                className: "mt-2 text-violet-600 text-sm",
                children: "+ Add Another"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1246,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1194,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1168,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block  text-sm font-medium text-gray-900",
              htmlFor: "salary",
              children: [
                "Fixed Salary ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1259,
                  columnNumber: 34
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1256,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "number",
              onWheel: (e) => e.target.blur(),
              name: "salary",
              value: formData.salary,
              onChange: (e) => handleChange(e.target.name, e.target.value),
              id: "salary",
              placeholder: "Enter Your Salary",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1261,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(formData.salary || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1274,
            columnNumber: 19
          }, this),
          errors.salary && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.salary }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1278,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1255,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1254,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 p-5 rounded-2xl border border-slate-200 mt-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-base font-bold text-slate-800", children: "Additional Salaries" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1285,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: "Add collection salary or more." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1288,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1284,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => addAdditionalSalaryField(false),
                className: "flex items-center gap-1.5 px-3 py-1.5 bg-violet-50 text-violet-700 rounded-lg text-sm font-semibold hover:bg-violet-100 transition-colors border border-violet-200",
                children: [
                  /* @__PURE__ */ jsxDEV(HiOutlinePlusCircle, { size: 18 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1297,
                    columnNumber: 21
                  }, this),
                  "Add Component"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1293,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1283,
            columnNumber: 17
          }, this),
          formData.additional_salary.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex px-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: "Component Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1306,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 ml-4", children: "Amount (₹)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1307,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-10" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1308,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1305,
              columnNumber: 21
            }, this),
            formData.additional_salary.map(
              (item, index) => /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "flex flex-row items-start space-x-4 animate-fadeIn",
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 group", children: /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        placeholder: "e.g. Collection",
                        value: item.name,
                        onChange: (e) => handleAdditionalSalaryChange(
                          index,
                          "name",
                          e.target.value
                        ),
                        className: `bg-white border-slate-200 ${fieldSize.height} rounded-xl focus:border-violet-500 hover:border-violet-400 shadow-sm w-full transition-all`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1317,
                        columnNumber: 27
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 1316,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "number",
                          placeholder: "0.00",
                          value: item.value || "",
                          onChange: (e) => handleAdditionalSalaryChange(
                            index,
                            "value",
                            e.target.value
                          ),
                          className: `bg-white border-slate-200 ${fieldSize.height} rounded-xl focus:border-violet-500 hover:border-violet-400 shadow-sm w-full transition-all`
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                          lineNumber: 1333,
                          columnNumber: 27
                        },
                        this
                      ),
                      item.value > 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-medium text-violet-500 mt-1.5 px-1 italic", children: [
                        numberToIndianWords(item.value),
                        " Only"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1347,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 1332,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => removeAdditionalSalaryField(index),
                        className: "p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all mt-1",
                        title: "Remove component",
                        children: /* @__PURE__ */ jsxDEV(HiOutlineTrash, { size: 20 }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                          lineNumber: 1359,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1354,
                        columnNumber: 25
                      },
                      this
                    )
                  ]
                },
                index,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1312,
                  columnNumber: 19
                },
                this
              )
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1303,
            columnNumber: 17
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-6 border-2 border-dashed border-slate-200 rounded-xl", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-400", children: "No additional salary components added." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1366,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1365,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1282,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-4 text-3xl font-bold text-gray-900",
              htmlFor: "earnings",
              children: "Earnings"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1374,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "basic",
                  children: "Fixed Basic Salary"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1382,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "basic",
                  value: formData.earnings?.basic === 0 ? "" : formData.earnings?.basic,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "basic",
                  placeholder: "Enter Fixed Employee Basic Salary",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5 `
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1387,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(formData.earnings?.basic || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1403,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1381,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "hra",
                  children: "Fixed House Rent Allowance"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1408,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "hra",
                  value: formData.earnings?.hra === 0 ? "" : formData.earnings?.hra,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "hra",
                  placeholder: "Enter Fixed House Rent Allowance",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1413,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(formData.earnings?.hra || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1429,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1407,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1380,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "travel_allowance",
                  children: "Fixed Travel Allowance"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1436,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "travel_allowance",
                  value: formData.earnings?.travel_allowance === 0 ? "" : formData.earnings?.travel_allowance,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "travel_allowance",
                  placeholder: "Enter Fixed Employee Travel Allowance",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1441,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                formData.earnings?.travel_allowance || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1457,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1435,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "medical_allowance",
                  children: "Fixed Medical Allowance"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1464,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "medical_allowance",
                  value: formData.earnings?.medical_allowance === 0 ? "" : formData.earnings?.medical_allowance,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "medical_allowance",
                  placeholder: "Enter Fixed Medical Allowance",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1469,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                formData.earnings?.medical_allowance || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1485,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1463,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1434,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "basket_of_benifits",
                  children: "Fixed Basket of Benifits"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1494,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "basket_of_benifits",
                  value: formData.earnings?.basket_of_benifits === 0 ? "" : formData.earnings?.basket_of_benifits,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "basket_of_benifits",
                  placeholder: "Enter Fixed Employee Basket of Benifits",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1499,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                formData.earnings?.basket_of_benifits || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1515,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1493,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "performance_bonus",
                  children: "Fixed Performance Bonus"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1522,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "performance_bonus",
                  value: formData.earnings?.performance_bonus === 0 ? "" : formData.earnings?.performance_bonus,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "performance_bonus",
                  placeholder: "Enter Fixed Performance Bonus",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1527,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                formData.earnings?.performance_bonus || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1543,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1521,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1492,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "other_allowances",
                  children: "Fixed Other Allowance"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1552,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "other_allowances",
                  value: formData.earnings?.other_allowances === 0 ? "" : formData.earnings?.other_allowances,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "other_allowances",
                  placeholder: "Enter Fixed Other Allowance",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1557,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                formData.earnings?.other_allowances || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1573,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1551,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "conveyance",
                  children: "Fixed Conveyance"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1580,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "conveyance",
                  value: formData.earnings?.conveyance === 0 ? "" : formData.earnings?.conveyance,
                  onChange: (e) => handleChange(e.target.name, e.target.value, true, false),
                  id: "conveyance",
                  placeholder: "Enter Fixed Conveyance",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1585,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(formData.earnings?.conveyance || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1601,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1579,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1550,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1373,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-4 text-2xl font-bold text-gray-900",
              htmlFor: "deductions",
              children: "Deductions"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1609,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "income_tax",
                  children: "Fixed Income Tax"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1616,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "income_tax",
                  value: formData.deductions?.income_tax === 0 ? "" : formData.deductions?.income_tax,
                  onChange: (e) => handleChange(e.target.name, e.target.value, false, true),
                  id: "income_tax",
                  placeholder: "Enter Fixed Employee Income Tax",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1621,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                formData.deductions?.income_tax || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1637,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1615,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "esi",
                  children: "Fixed Employees' State Insurance"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1644,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "esi",
                  value: formData.deductions?.esi === 0 ? "" : formData.deductions?.esi,
                  onChange: (e) => handleChange(e.target.name, e.target.value, false, true),
                  id: "esi",
                  placeholder: "Enter Fixed Employees' State Insurance",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1649,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(formData.deductions?.esi || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1665,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1643,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1614,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "epf",
                  children: "Fixed Employees' Provident Fund"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1672,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "epf",
                  value: formData.deductions?.epf === 0 ? "" : formData.deductions?.epf,
                  onChange: (e) => handleChange(e.target.name, e.target.value, false, true),
                  id: "epf",
                  placeholder: "Enter Fixed Employees' Provident Fund",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1677,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(formData.deductions?.epf || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1693,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1671,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "professional_tax",
                  children: "Fixed Professional Tax"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1698,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "professional_tax",
                  value: formData.deductions?.professional_tax === 0 ? "" : formData.deductions?.professional_tax,
                  onChange: (e) => handleChange(e.target.name, e.target.value, false, true),
                  id: "professional_tax",
                  placeholder: "Enter Fixed Employees' Professional Tax",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1703,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                formData.deductions?.professional_tax || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1719,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1697,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1670,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1608,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800\r\n            focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Employee"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1729,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1728,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
        lineNumber: 770,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
      lineNumber: 766,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
      lineNumber: 765,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1743,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "update_name",
                  children: [
                    "Full Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 1751,
                      columnNumber: 29
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1748,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "name",
                  value: updateFormData.name,
                  onChange: (e) => handleInputChange(e.target.name, e.target.value),
                  id: "update_name",
                  placeholder: "Enter the Full Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1753,
                  columnNumber: 17
                },
                this
              ),
              errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1766,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1747,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_email",
                    children: [
                      "Email ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1774,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1771,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "email",
                    name: "email",
                    value: updateFormData.email,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_email",
                    placeholder: "Enter Email",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1776,
                    columnNumber: 19
                  },
                  this
                ),
                errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1789,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1770,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_phone_number",
                    children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1796,
                        columnNumber: 34
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1793,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "tel",
                    name: "phone_number",
                    value: updateFormData.phone_number,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_phone_number",
                    placeholder: "Enter Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1798,
                    columnNumber: 19
                  },
                  this
                ),
                errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1811,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1792,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1769,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "update_pincode",
                  children: [
                    "Pincode ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 1846,
                      columnNumber: 29
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1843,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "pincode",
                  value: updateFormData.pincode,
                  onChange: (e) => handleInputChange(e.target.name, e.target.value),
                  id: "update_pincode",
                  placeholder: "Enter Pincode",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1848,
                  columnNumber: 19
                },
                this
              ),
              errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1861,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1842,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1817,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_adhaar_no",
                    children: [
                      "Adhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1872,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1869,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "adhaar_no",
                    value: updateFormData.adhaar_no,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_adhaar_no",
                    placeholder: "Enter Adhaar Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1874,
                    columnNumber: 19
                  },
                  this
                ),
                errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1887,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1868,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_pan_no",
                    children: [
                      "Pan Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1896,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1893,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "pan_no",
                    value: updateFormData.pan_no,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_pan_no",
                    placeholder: "Enter Pan Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1898,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1911,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1892,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1867,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "update_address",
                  children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 1919,
                      columnNumber: 27
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1916,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "address",
                  value: updateFormData.address,
                  onChange: (e) => handleInputChange(e.target.name, e.target.value),
                  id: "update_address",
                  placeholder: "Enter the Address",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1921,
                  columnNumber: 17
                },
                this
              ),
              errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1934,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1915,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_designation_id",
                    children: [
                      "Designation ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1942,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1939,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    id: "update_designation_id",
                    name: "designation_id",
                    value: selectedManagerId || void 0,
                    onChange: handleAntDSelectManager,
                    placeholder: "Select Designation",
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    showSearch: true,
                    popupMatchSelectWidth: false,
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    children: managers.map(
                      (manager) => /* @__PURE__ */ jsxDEV(Select.Option, { value: manager._id, children: manager.title }, manager._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1960,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1945,
                    columnNumber: 19
                  },
                  this
                ),
                errors.designation_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.designation_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1966,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1938,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_status",
                    children: [
                      "Status ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1975,
                        columnNumber: 28
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1972,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Status",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "status",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.status || void 0,
                    onChange: (value) => handleInputChange("status", value),
                    children: ["Active", "Inactive", "Terminated"].map(
                      (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status.toLowerCase(), children: status }, status, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 1991,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 1977,
                    columnNumber: 19
                  },
                  this
                ),
                errors.status && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.status }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 1997,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 1971,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 1937,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_joining_date",
                    children: [
                      "Joining Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2006,
                        columnNumber: 34
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2003,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "joining_date",
                    value: updateFormData.joining_date,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_joining_date",
                    placeholder: "Enter Employee Joining Date",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2008,
                    columnNumber: 19
                  },
                  this
                ),
                errors.joining_date && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.joining_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2020,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2002,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_leaving_date",
                    children: "Leaving Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2026,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "leaving_date",
                    value: updateFormData?.leaving_date ? new Date(updateFormData?.leaving_date || "").toISOString().split("T")[0] : "",
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_leaving_date",
                    placeholder: "Enter Leaving Date",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2031,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2025,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2001,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_dob",
                    children: [
                      "Date of Birth ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2055,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2052,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "dob",
                    value: updateFormData?.dob ? new Date(updateFormData?.dob || "").toISOString().split("T")[0] : "",
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_dob",
                    placeholder: "Enter Employee Date of Birth",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2057,
                    columnNumber: 19
                  },
                  this
                ),
                errors.dob && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.dob }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2075,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2051,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_gender",
                    children: [
                      "Gender ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2082,
                        columnNumber: 28
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2079,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Gender",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "gender",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.gender || void 0,
                    onChange: (value) => handleInputChange("gender", value),
                    children: ["Male", "Female", "Others"].map(
                      (gender) => /* @__PURE__ */ jsxDEV(Select.Option, { value: gender.toLowerCase(), children: gender }, gender, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2098,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2084,
                    columnNumber: 19
                  },
                  this
                ),
                errors.gender && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.gender }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2104,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2078,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2050,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_alternate_number",
                    children: [
                      "Alternate Phone Number",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2114,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2110,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "tel",
                    name: "alternate_number",
                    value: updateFormData.alternate_number,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_alternate_number",
                    placeholder: "Enter Alternate Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2116,
                    columnNumber: 19
                  },
                  this
                ),
                errors.alternate_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.alternate_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2130,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2109,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_total_allocated_leaves",
                    children: [
                      "Total No. of Leaves ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2139,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2136,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    onWheel: (e) => e.target.blur(),
                    name: "total_allocated_leaves",
                    value: updateFormData.total_allocated_leaves,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_total_allocated_leaves",
                    placeholder: "Enter total leaves",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2141,
                    columnNumber: 19
                  },
                  this
                ),
                errors.total_allocated_leaves && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.total_allocated_leaves }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2155,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2135,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2108,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_emergency_contact_person",
                    children: [
                      "Emergency Contact Person",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2167,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2163,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "emergency_contact_person",
                    value: updateFormData?.emergency_contact_person,
                    onChange: (e) => handleInputChange(e.target.name, e.target.value),
                    id: "update_emergency_contact_person",
                    placeholder: "Enter Emergency Contact Person Name",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2169,
                    columnNumber: 19
                  },
                  this
                ),
                errors.emergency_contact_person && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.emergency_contact_person }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2182,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2162,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "update_emergency_contact_number",
                    children: [
                      "Emergency Phone Number",
                      " "
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2188,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-2 gap-2", children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "tel",
                    name: "emergency_contact_number",
                    value: updateFormData.emergency_contact_number?.[0] || "",
                    onChange: (e) => handlePhoneChange(
                      updateFormData,
                      setUpdateFormData,
                      0,
                      e
                    ),
                    id: "update_emergency_contact_number_0",
                    placeholder: "Enter Default Emergency Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2194,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2193,
                  columnNumber: 19
                }, this),
                updateFormData.emergency_contact_number?.slice(1).map(
                  (phone, index) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "flex items-center mb-2 gap-2",
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            type: "tel",
                            name: `emergency_phone_${index + 1}`,
                            value: phone,
                            onChange: (e) => handlePhoneChange(
                              updateFormData,
                              setUpdateFormData,
                              index + 1,
                              e
                            ),
                            id: `update_emergency_contact_number_${index + 1}`,
                            placeholder: "Enter Additional Emergency Phone Number",
                            className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                            lineNumber: 2218,
                            columnNumber: 25
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "button",
                          {
                            type: "button",
                            onClick: () => removePhoneField(
                              updateFormData,
                              setUpdateFormData,
                              index + 1
                            ),
                            className: "text-red-600 text-sm",
                            children: "Remove"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                            lineNumber: 2234,
                            columnNumber: 25
                          },
                          this
                        )
                      ]
                    },
                    index + 1,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2215,
                      columnNumber: 19
                    },
                    this
                  )
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => addPhoneField(updateFormData, setUpdateFormData),
                    className: "mt-2 text-violet-600 text-sm",
                    children: "+ Add Another"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2248,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2187,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2161,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "update_salary",
                  children: [
                    "Fixed Salary ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2263,
                      columnNumber: 34
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2260,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  onWheel: (e) => e.target.blur(),
                  name: "salary",
                  value: updateFormData.salary,
                  onChange: (e) => handleInputChange(e.target.name, e.target.value),
                  id: "update_salary",
                  placeholder: "Enter Salary",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2265,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(updateFormData.salary || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2278,
                columnNumber: 19
              }, this),
              errors.salary && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.salary }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2282,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2259,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2258,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 p-5 rounded-2xl border border-slate-200 mt-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-base font-bold text-slate-800", children: "Additional Salaries" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2290,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: "Update Collection Salaries and more." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2293,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2289,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => addAdditionalSalaryField(true),
                    className: "flex items-center gap-1.5 px-3 py-1.5 bg-violet-50 text-violet-700 rounded-lg text-sm font-semibold hover:bg-violet-100 transition-colors border border-violet-200",
                    children: [
                      /* @__PURE__ */ jsxDEV(HiOutlinePlusCircle, { size: 18 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                        lineNumber: 2302,
                        columnNumber: 21
                      }, this),
                      "Add Component"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2298,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2288,
                columnNumber: 17
              }, this),
              updateFormData.additional_salary.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex px-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: "Component Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2311,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1 ml-4", children: "Amount (₹)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2312,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2313,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2310,
                  columnNumber: 21
                }, this),
                updateFormData.additional_salary.map(
                  (item, index) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "flex flex-row items-start space-x-4 animate-fadeIn",
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV(
                          Input,
                          {
                            placeholder: "eg: Collection",
                            value: item.name,
                            onChange: (e) => handleAdditionalSalaryChange(
                              index,
                              "name",
                              e.target.value,
                              true
                            ),
                            className: `bg-white border-slate-200 ${fieldSize.height} rounded-xl focus:border-violet-500 hover:border-violet-400 shadow-sm w-full transition-all`
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                            lineNumber: 2322,
                            columnNumber: 27
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                          lineNumber: 2321,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                          /* @__PURE__ */ jsxDEV(
                            Input,
                            {
                              type: "number",
                              placeholder: "0.00",
                              value: item.value || "",
                              onChange: (e) => handleAdditionalSalaryChange(
                                index,
                                "value",
                                e.target.value,
                                true
                              ),
                              className: `bg-white border-slate-200 ${fieldSize.height} rounded-xl focus:border-violet-500 hover:border-violet-400 shadow-sm w-full transition-all`
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                              lineNumber: 2339,
                              columnNumber: 27
                            },
                            this
                          ),
                          item.value > 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-medium text-violet-500 mt-1.5 px-1 italic", children: [
                            numberToIndianWords(item.value),
                            " Only"
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                            lineNumber: 2354,
                            columnNumber: 23
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                          lineNumber: 2338,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "button",
                          {
                            type: "button",
                            onClick: () => removeAdditionalSalaryField(index, true),
                            className: "p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all mt-1",
                            title: "Remove component",
                            children: /* @__PURE__ */ jsxDEV(HiOutlineTrash, { size: 20 }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                              lineNumber: 2368,
                              columnNumber: 27
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                            lineNumber: 2361,
                            columnNumber: 25
                          },
                          this
                        )
                      ]
                    },
                    index,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2317,
                      columnNumber: 19
                    },
                    this
                  )
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2308,
                columnNumber: 17
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-6 border-2 border-dashed border-slate-200 rounded-xl", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-400", children: "No additional components found for this employee." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2375,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2374,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2287,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-4 text-3xl font-bold text-gray-900",
                  htmlFor: "update_earnings",
                  children: "Earnings"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2382,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_basic",
                      children: "Fixed Basic Salary"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2390,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "basic",
                      value: updateFormData.earnings?.basic === 0 ? "" : updateFormData.earnings?.basic,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_basic",
                      placeholder: "Enter Employee Fixed Basic Salary",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2395,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(updateFormData.earnings?.basic || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2416,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2389,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_hra",
                      children: "Fixed House Rent Allowance"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2421,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "hra",
                      value: updateFormData.earnings?.hra === 0 ? "" : updateFormData.earnings?.hra,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_hra",
                      placeholder: "Enter Fixed House Rent Allowance",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2426,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(updateFormData.earnings?.hra || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2447,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2420,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2388,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_travel_allowance",
                      children: "Fixed Travel Allowance"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2454,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "travel_allowance",
                      value: updateFormData.earnings?.travel_allowance === 0 ? "" : updateFormData.earnings?.travel_allowance,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_travel_allowance",
                      placeholder: "Enter Fixed Employee Travel Allowance",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2459,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.earnings?.travel_allowance || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2480,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2453,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_medical_allowance",
                      children: "Fixed Medical Allowance"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2487,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "medical_allowance",
                      value: updateFormData.earnings?.medical_allowance === 0 ? "" : updateFormData.earnings?.medical_allowance,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_medical_allowance",
                      placeholder: "Enter Fixed Medical Allowance",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2492,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.earnings?.medical_allowance || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2513,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2486,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2452,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_basket_of_benifits",
                      children: "Fixed Basket of Benifits"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2522,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "basket_of_benifits",
                      value: updateFormData.earnings?.basket_of_benifits === 0 ? "" : updateFormData.earnings?.basket_of_benifits,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_basket_of_benifits",
                      placeholder: "Enter Fixed Employee Basket of Benifits",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2527,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.earnings?.basket_of_benifits || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2548,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2521,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_performance_bonus",
                      children: "Fixed Performance Bonus"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2555,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "performance_bonus",
                      value: updateFormData.earnings?.performance_bonus === 0 ? "" : updateFormData.earnings?.performance_bonus,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_performance_bonus",
                      placeholder: "Enter Fixed Performance Bonus",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2560,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.earnings?.performance_bonus || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2581,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2554,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2520,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_other_allowances",
                      children: "Fixed Other Allowance"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2590,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "other_allowances",
                      value: updateFormData.earnings?.other_allowances === 0 ? "" : updateFormData.earnings?.other_allowances,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_other_allowances",
                      placeholder: "Enter Fixed Other Allowance",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2595,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.earnings?.other_allowances || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2616,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2589,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_conveyance",
                      children: "Fixed Conveyance"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2623,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "conveyance",
                      value: updateFormData.earnings?.conveyance === 0 ? "" : updateFormData.earnings?.conveyance,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        true,
                        false
                      ),
                      id: "update_conveyance",
                      placeholder: "Enter Fixed Conveyance",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2628,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.earnings?.conveyance || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2649,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2622,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2588,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2381,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-4 text-3xl font-bold text-gray-900",
                  htmlFor: "update_deductions",
                  children: "Deductions"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2659,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_income_tax",
                      children: "Fixed Income Tax"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2666,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "income_tax",
                      value: updateFormData.deductions?.income_tax === 0 ? "" : updateFormData.deductions?.income_tax,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        false,
                        true
                      ),
                      id: "update_income_tax",
                      placeholder: "Enter Fixed Employee Income Tax",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2671,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.deductions?.income_tax || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2692,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2665,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_esi",
                      children: "Fixed Employees' State Insurance"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2699,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "esi",
                      value: updateFormData.deductions?.esi === 0 ? "" : updateFormData.deductions?.esi,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        false,
                        true
                      ),
                      id: "update_esi",
                      placeholder: "Enter Fixed Employees' State Insurance",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2704,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(updateFormData.deductions?.esi || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2725,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2698,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2664,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_epf",
                      children: "Fixed Employees' Provident Fund"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2732,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "epf",
                      value: updateFormData.deductions?.epf === 0 ? "" : updateFormData.deductions?.epf,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        false,
                        true
                      ),
                      id: "update_epf",
                      placeholder: "Enter Fixed Employees' Provident Fund",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2737,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(updateFormData.deductions?.epf || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2758,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2731,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "update_professional_tax",
                      children: "Fixed Professional Tax"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2763,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      onWheel: (e) => e.target.blur(),
                      name: "professional_tax",
                      value: updateFormData.deductions?.professional_tax === 0 ? "" : updateFormData.deductions?.professional_tax,
                      onChange: (e) => handleInputChange(
                        e.target.name,
                        e.target.value,
                        false,
                        true
                      ),
                      id: "update_professional_tax",
                      placeholder: "Enter Fixed Employees' Professional Tax",
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2768,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-medium font-mono text-violet-600", children: numberToIndianWords(
                    updateFormData.deductions?.professional_tax || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2789,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2762,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2730,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2658,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n            focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update Employee"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                lineNumber: 2799,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2798,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 1746,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 1742,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
        lineNumber: 1739,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
            lineNumber: 2816,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "delete_employee_name",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                          lineNumber: 2831,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                          lineNumber: 2835,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2827,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "delete_employee_name",
                      placeholder: "Enter the employee Full Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                      lineNumber: 2837,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                  lineNumber: 2826,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n        focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
                    lineNumber: 2845,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
              lineNumber: 2820,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
          lineNumber: 2815,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
        lineNumber: 2809,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
    lineNumber: 718,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx",
    lineNumber: 717,
    columnNumber: 5
  }, this);
};
_s(Payroll, "gbBWNFggWUVYU/6TQ8LaYDPA/e4=");
_c = Payroll;
export default Payroll;
var _c;
$RefreshReg$(_c, "Payroll");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Payroll.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEl3QixTQThqQnBCLFVBOWpCb0I7MkJBOUl4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxRQUFRQyxnQkFBZ0I7QUFDeEMsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLHFCQUFxQkMsc0JBQXNCO0FBQ3BELE9BQU9DLGdCQUFnQjtBQUN2QixNQUFNQyxVQUFVQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEIsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJckIsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3NCLFdBQVdDLFlBQVksSUFBSXZCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN3QixpQkFBaUJDLGtCQUFrQixJQUFJekIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzBCLGlCQUFpQkMsa0JBQWtCLElBQUkzQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNEIsYUFBYUMsY0FBYyxJQUFJN0IsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQzhCLG1CQUFtQkMsb0JBQW9CLElBQUkvQixTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDZ0MsUUFBUUMsU0FBUyxJQUFJakMsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDa0MsWUFBWUMsYUFBYSxJQUFJbkMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ29DLG1CQUFtQkMsb0JBQW9CLElBQUlyQyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDc0MsNEJBQTRCQyw2QkFBNkIsSUFDOUR2QyxTQUFTLEVBQUU7QUFDYixRQUFNLENBQUN3QyxVQUFVQyxXQUFXLElBQUl6QyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDMEMsV0FBV0MsWUFBWSxJQUFJM0MsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzRDLGVBQWVDLGdCQUFnQixJQUFJN0MsU0FBUyxDQUFDO0FBQ3BELFFBQU04Qyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCZCxrQkFBY2EsS0FBSztBQUFBLEVBQ3JCO0FBQ0EsUUFBTSxDQUFDRSxzQkFBc0JDLHVCQUF1QixJQUFJbkQsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ29ELGFBQWFDLGNBQWMsSUFBSXJELFNBQVM7QUFBQSxJQUM3Q3NELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJMUQsU0FBUztBQUFBLElBQ3ZDMkQsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUE7QUFBQSxJQUVkQyxTQUFTO0FBQUEsSUFDVEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxnQkFBZ0I7QUFBQSxJQUNoQkMsUUFBUTtBQUFBLElBQ1JDLFlBQVk7QUFBQSxJQUNaQyxjQUFjO0FBQUEsSUFDZEMsUUFBUTtBQUFBLElBQ1JDLEtBQUs7QUFBQSxJQUNMQyxRQUFRO0FBQUEsSUFDUkMsa0JBQWtCO0FBQUEsSUFDbEJDLFFBQVE7QUFBQSxJQUNSQyxjQUFjO0FBQUEsSUFDZEMsMEJBQTBCO0FBQUEsSUFDMUJDLDBCQUEwQixDQUFDLEVBQUU7QUFBQSxJQUM3QkMsd0JBQXdCO0FBQUEsSUFDeEJDLFVBQVU7QUFBQSxNQUNSQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLGtCQUFrQjtBQUFBLE1BQ2xCQyxtQkFBbUI7QUFBQSxNQUNuQkMsb0JBQW9CO0FBQUEsTUFDcEJDLG1CQUFtQjtBQUFBLE1BQ25CQyxrQkFBa0I7QUFBQSxNQUNsQkMsWUFBWTtBQUFBLElBQ2Q7QUFBQSxJQUNBQyxZQUFZO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLEtBQUs7QUFBQSxNQUNMQyxLQUFLO0FBQUEsTUFDTEMsa0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxJQUNBQyxtQkFBbUI7QUFBQSxFQUNyQixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJOUYsU0FBUztBQUFBLElBQ25EMkQsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUE7QUFBQSxJQUVkQyxTQUFTO0FBQUEsSUFDVEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxnQkFBZ0I7QUFBQSxJQUNoQkMsUUFBUTtBQUFBLElBQ1JFLGNBQWM7QUFBQSxJQUNkQyxRQUFRO0FBQUEsSUFDUkMsS0FBSztBQUFBLElBQ0xDLFFBQVE7QUFBQSxJQUNSQyxrQkFBa0I7QUFBQSxJQUNsQkMsUUFBUTtBQUFBLElBQ1JDLGNBQWM7QUFBQSxJQUNkQywwQkFBMEI7QUFBQSxJQUMxQkMsMEJBQTBCLENBQUMsRUFBRTtBQUFBLElBQzdCQyx3QkFBd0I7QUFBQSxJQUN4QkMsVUFBVTtBQUFBLE1BQ1JDLE9BQU87QUFBQSxNQUNQQyxLQUFLO0FBQUEsTUFDTEMsa0JBQWtCO0FBQUEsTUFDbEJDLG1CQUFtQjtBQUFBLE1BQ25CQyxvQkFBb0I7QUFBQSxNQUNwQkMsbUJBQW1CO0FBQUEsTUFDbkJDLGtCQUFrQjtBQUFBLE1BQ2xCQyxZQUFZO0FBQUEsSUFDZDtBQUFBLElBQ0FDLFlBQVk7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsS0FBSztBQUFBLE1BQ0xDLEtBQUs7QUFBQSxNQUNMQyxrQkFBa0I7QUFBQSxJQUNwQjtBQUFBLElBQ0FDLG1CQUFtQjtBQUFBLEVBQ3JCLENBQUM7QUFDRDdGLFlBQVUsTUFBTTtBQUNkLFVBQU1nRyx1QkFBdUIsWUFBWTtBQUN2QyxVQUFJO0FBQ0ZwRCxxQkFBYSxJQUFJO0FBQ2pCLGNBQU1xRCxXQUFXLE1BQU16RixJQUFJMEYsSUFBSSxXQUFXO0FBQzFDLGNBQU1DLGVBQWVGLFNBQVNHLE1BQU1DLFlBQVk7QUFFaEQsY0FBTUMsZ0JBQWdCSCxhQUFhSSxJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUN4REMsS0FBS0YsT0FBT0U7QUFBQUEsVUFDWkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1o3QyxNQUFNNEMsT0FBTzVDLFFBQVE7QUFBQSxVQUNyQmdELGNBQWNKLE9BQU9JLGdCQUFnQjtBQUFBLFVBQ3JDOUMsY0FBYzBDLE9BQU8xQyxnQkFBZ0I7QUFBQTtBQUFBLFVBRXJDK0MsYUFBYUwsT0FBT3RDLGdCQUFnQjRDLFNBQVM7QUFBQSxVQUM3Q0MsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsY0FDakIsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1DLHNCQUFzQlgsTUFBTUUsR0FBRztBQUFBLHdCQUFHO0FBQUE7QUFBQSxzQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFTyxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUUsc0JBQXNCWixNQUFNRSxHQUFHO0FBQUEsd0JBQUc7QUFBQTtBQUFBLHNCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSUE7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1YsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQSxZQTNCakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEJBO0FBQUEsUUFFSixFQUFFO0FBQ0ZwRiwwQkFBa0JnRixhQUFhO0FBQUEsTUFDakMsU0FBU2UsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFBQSxNQUNsRCxVQUFDO0FBQ0N6RSxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0FvRCx5QkFBcUI7QUFBQSxFQUN2QixHQUFHLENBQUNuRCxhQUFhLENBQUM7QUFDbEI3QyxZQUFVLE1BQU07QUFDZCxVQUFNdUgsZ0JBQWdCLFlBQVk7QUFDaEMsVUFBSTtBQUNGLGNBQU10QixXQUFXLE1BQU16RixJQUFJMEYsSUFBSSw4QkFBOEI7QUFDN0R4RCxvQkFBWXVELFNBQVNHLElBQUk7QUFBQSxNQUMzQixTQUFTaUIsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUUsa0JBQWM7QUFBQSxFQUNoQixHQUFHLENBQUMxRSxhQUFhLENBQUM7QUFFbEIsUUFBTTJFLDBCQUEwQkEsQ0FBQ0MsY0FBYztBQUM3Q25GLHlCQUFxQm1GLFNBQVM7QUFDOUIsVUFBTUMsV0FBV2pGLFNBQVNrRixLQUFLLENBQUNDLFFBQVFBLElBQUlsQixRQUFRZSxTQUFTO0FBQzdELFVBQU1YLFFBQVFZLFVBQVVaLFNBQVM7QUFDakMxRCw0QkFBd0IwRCxLQUFLO0FBQzdCbkQsZ0JBQVksQ0FBQ2tFLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIckMsWUFBWSxFQUFFLEdBQUdxQyxLQUFLckMsV0FBVztBQUFBLE1BQ2pDVCxVQUFVLEVBQUUsR0FBRzhDLEtBQUs5QyxTQUFTO0FBQUEsTUFDN0IwQztBQUFBQSxNQUNBSyxjQUFjaEI7QUFBQUEsSUFDaEIsRUFBRTtBQUNGNUUsY0FBVSxDQUFDMkYsVUFBVTtBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0hKLFdBQVc7QUFBQSxNQUNYSyxjQUFjO0FBQUEsSUFDaEIsRUFBRTtBQUFBLEVBQ0o7QUFDQSxRQUFNQywrQkFBK0JBLENBQ25DdEIsT0FDQXVCLE9BQ0FDLEtBQ0FDLFdBQVcsVUFDUjtBQUNILFVBQU1DLFNBQVNELFdBQVduQyxvQkFBb0JwQztBQUM5Q3dFLFdBQU8sQ0FBQ04sU0FBUztBQUNmLFlBQU1PLGNBQWMsQ0FBQyxHQUFHUCxLQUFLaEMsaUJBQWlCO0FBQzlDdUMsa0JBQVkzQixLQUFLLElBQUk7QUFBQSxRQUNuQixHQUFHMkIsWUFBWTNCLEtBQUs7QUFBQSxRQUNwQixDQUFDdUIsS0FBSyxHQUFHQSxVQUFVLFVBQVdDLFFBQVEsS0FBSyxJQUFJSSxPQUFPSixHQUFHLElBQUtBO0FBQUFBLE1BQ2hFO0FBQ0EsYUFBTyxFQUFFLEdBQUdKLE1BQU1oQyxtQkFBbUJ1QyxZQUFZO0FBQUEsSUFDbkQsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNRSwyQkFBMkJBLENBQUNKLFdBQVcsVUFBVTtBQUNyRCxVQUFNQyxTQUFTRCxXQUFXbkMsb0JBQW9CcEM7QUFDOUN3RSxXQUFPLENBQUNOLFVBQVU7QUFBQSxNQUNoQixHQUFHQTtBQUFBQSxNQUNIaEMsbUJBQW1CLENBQUMsR0FBR2dDLEtBQUtoQyxtQkFBbUIsRUFBRWpDLE1BQU0sSUFBSVgsT0FBTyxFQUFFLENBQUM7QUFBQSxJQUN2RSxFQUFFO0FBQUEsRUFDSjtBQUNBLFFBQU1zRiw4QkFBOEJBLENBQUM5QixPQUFPeUIsV0FBVyxVQUFVO0FBQy9ELFVBQU1DLFNBQVNELFdBQVduQyxvQkFBb0JwQztBQUM5Q3dFLFdBQU8sQ0FBQ04sVUFBVTtBQUFBLE1BQ2hCLEdBQUdBO0FBQUFBLE1BQ0hoQyxtQkFBbUJnQyxLQUFLaEMsa0JBQWtCMkMsT0FBTyxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNakMsS0FBSztBQUFBLElBQ3hFLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTWtDLGVBQWVBLENBQUMvRSxNQUFNWCxPQUFPOEIsV0FBVyxPQUFPUyxhQUFhLFVBQVU7QUFDMUUsUUFBSVQsVUFBVTtBQUNacEIsa0JBQVksQ0FBQ2lGLGNBQWM7QUFBQSxRQUN6QixHQUFHQTtBQUFBQSxRQUNIN0QsVUFBVSxFQUFFLEdBQUc2RCxTQUFTN0QsVUFBVSxDQUFDbkIsSUFBSSxHQUFHWCxNQUFNO0FBQUEsTUFDbEQsRUFBRTtBQUFBLElBQ0osV0FBV3VDLFlBQVk7QUFDckI3QixrQkFBWSxDQUFDaUYsY0FBYztBQUFBLFFBQ3pCLEdBQUdBO0FBQUFBLFFBQ0hwRCxZQUFZLEVBQUUsR0FBR29ELFNBQVNwRCxZQUFZLENBQUM1QixJQUFJLEdBQUdYLE1BQU07QUFBQSxNQUN0RCxFQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0wsVUFBSVcsU0FBUyxVQUFVO0FBQ3JCRCxvQkFBWSxDQUFDaUYsY0FBYztBQUFBLFVBQ3pCLEdBQUdBO0FBQUFBLFVBQ0gsQ0FBQ2hGLElBQUksR0FBR1g7QUFBQUEsUUFDVixFQUFFO0FBQUEsTUFDSixPQUFPO0FBQ0xVLG9CQUFZLENBQUNpRixjQUFjO0FBQUEsVUFDekIsR0FBR0E7QUFBQUEsVUFDSCxDQUFDaEYsSUFBSSxHQUFHWDtBQUFBQSxRQUNWLEVBQUU7QUFBQSxNQUNKO0FBRUFmLGdCQUFVLENBQUMyRixVQUFVO0FBQUEsUUFDbkIsR0FBR0E7QUFBQUEsUUFDSCxDQUFDakUsSUFBSSxHQUFHO0FBQUEsTUFDVixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxRQUFNaUYsbUNBQW1DQSxDQUFDQyxnQkFBZ0I7QUFDeER0RyxrQ0FBOEJzRyxXQUFXO0FBQ3pDbkYsZ0JBQVksQ0FBQ2tFLFVBQVU7QUFBQSxNQUNyQixHQUFHQTtBQUFBQSxNQUNIa0Isb0JBQW9CRDtBQUFBQSxJQUN0QixFQUFFO0FBQ0Y1RyxjQUFVLENBQUMyRixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSGtCLG9CQUFvQjtBQUFBLElBQ3RCLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTUMsZUFBZUEsQ0FBQ3ZGLFNBQVM7QUFDN0IsVUFBTXdGLFlBQVksQ0FBQztBQUNuQixVQUFNN0MsT0FBTzNDLFNBQVMsZ0JBQWdCQyxXQUFXb0M7QUFDakQsVUFBTW9ELFFBQVE7QUFBQSxNQUNackYsT0FBTztBQUFBLE1BQ1BzRixPQUFPO0FBQUE7QUFBQTtBQUFBLE1BR1BuRixTQUFTO0FBQUEsTUFDVG9GLFNBQVM7QUFBQSxNQUNUQyxLQUFLO0FBQUEsTUFDTDVFLGtCQUFrQjtBQUFBLElBQ3BCO0FBQ0EsUUFBSSxDQUFDMkIsS0FBS3hDLFFBQVEsQ0FBQ3dDLEtBQUt4QyxLQUFLMEYsS0FBSyxHQUFHO0FBQ25DTCxnQkFBVXJGLE9BQU87QUFBQSxJQUNuQjtBQUNBLFFBQUksQ0FBQ3dDLEtBQUt2QyxPQUFPO0FBQ2ZvRixnQkFBVXBGLFFBQVE7QUFBQSxJQUNwQixXQUFXLENBQUNxRixNQUFNckYsTUFBTTBGLEtBQUtuRCxLQUFLdkMsS0FBSyxHQUFHO0FBQ3hDb0YsZ0JBQVVwRixRQUFRO0FBQUEsSUFDcEI7QUFDQSxRQUFJLENBQUN1QyxLQUFLdEMsY0FBYztBQUN0Qm1GLGdCQUFVbkYsZUFBZTtBQUFBLElBQzNCLFdBQVcsQ0FBQ29GLE1BQU1DLE1BQU1JLEtBQUtuRCxLQUFLdEMsWUFBWSxHQUFHO0FBQy9DbUYsZ0JBQVVuRixlQUFlO0FBQUEsSUFDM0I7QUFDQSxRQUFJLENBQUNzQyxLQUFLM0Isa0JBQWtCO0FBQzFCd0UsZ0JBQVV4RSxtQkFBbUI7QUFBQSxJQUMvQixXQUFXLENBQUN5RSxNQUFNekUsaUJBQWlCOEUsS0FBS25ELEtBQUszQixnQkFBZ0IsR0FBRztBQUM5RHdFLGdCQUFVeEUsbUJBQW1CO0FBQUEsSUFDL0I7QUFPQSxRQUFJLENBQUMyQixLQUFLOUIsUUFBUTtBQUNoQjJFLGdCQUFVM0UsU0FBUztBQUFBLElBQ3JCO0FBQ0EsUUFBSSxDQUFDOEIsS0FBSzdCLEtBQUs7QUFDYjBFLGdCQUFVMUUsTUFBTTtBQUFBLElBQ2xCO0FBQ0EsUUFBSSxDQUFDNkIsS0FBSy9CLGNBQWM7QUFDdEI0RSxnQkFBVTVFLGVBQWU7QUFBQSxJQUMzQjtBQUNBLFFBQUksQ0FBQytCLEtBQUs1QixRQUFRO0FBQ2hCeUUsZ0JBQVV6RSxTQUFTO0FBQUEsSUFDckI7QUFDQSxRQUFJLENBQUM0QixLQUFLMUIsUUFBUTtBQUNoQnVFLGdCQUFVdkUsU0FBUztBQUFBLElBQ3JCO0FBQ0EsUUFBSSxDQUFDMEIsS0FBS3BDLFNBQVM7QUFDakJpRixnQkFBVWpGLFVBQVU7QUFBQSxJQUN0QixXQUFXLENBQUNrRixNQUFNbEYsUUFBUXVGLEtBQUtuRCxLQUFLcEMsT0FBTyxHQUFHO0FBQzVDaUYsZ0JBQVVqRixVQUFVO0FBQUEsSUFDdEI7QUFDQSxRQUFJLENBQUNvQyxLQUFLbkMsV0FBVztBQUNuQmdGLGdCQUFVaEYsWUFBWTtBQUFBLElBQ3hCLFdBQVcsQ0FBQ2lGLE1BQU1FLFFBQVFHLEtBQUtuRCxLQUFLbkMsU0FBUyxHQUFHO0FBQzlDZ0YsZ0JBQVVoRixZQUFZO0FBQUEsSUFDeEI7QUFFQSxRQUFJLENBQUNtQyxLQUFLakMsUUFBUTtBQUNoQjhFLGdCQUFVOUUsU0FBUztBQUFBLElBQ3JCLFdBQVcsQ0FBQytFLE1BQU1HLElBQUlFLEtBQUtuRCxLQUFLakMsT0FBT3FGLFlBQVksQ0FBQyxHQUFHO0FBQ3JEUCxnQkFBVTlFLFNBQVM7QUFBQSxJQUNyQjtBQUNBLFFBQUksQ0FBQ2lDLEtBQUtyQyxXQUFXLENBQUNxQyxLQUFLckMsUUFBUXVGLEtBQUssR0FBRztBQUN6Q0wsZ0JBQVVsRixVQUFVO0FBQUEsSUFDdEIsV0FBV3FDLEtBQUtyQyxRQUFRdUYsS0FBSyxFQUFFRyxTQUFTLElBQUk7QUFDMUNSLGdCQUFVbEYsVUFBVTtBQUFBLElBQ3RCO0FBQ0EsUUFBSSxDQUFDcUMsS0FBS3hCLDBCQUEwQjtBQUNsQ3FFLGdCQUFVckUsMkJBQTJCO0FBQUEsSUFDdkM7QUFDQSxRQUFJLENBQUN3QixLQUFLdEIsd0JBQXdCO0FBQ2hDbUUsZ0JBQVVuRSx5QkFDUjtBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUN6QyxtQkFBbUI7QUFDdEI0RyxnQkFBVS9FLGlCQUFpQjtBQUFBLElBQzdCO0FBRUFoQyxjQUFVK0csU0FBUztBQUNuQixXQUFPUyxPQUFPQyxLQUFLVixTQUFTLEVBQUVRLFdBQVc7QUFBQSxFQUMzQztBQUNBLFFBQU1HLGdCQUFnQkEsQ0FBQ0MsV0FBV0MsaUJBQWlCO0FBQ2pELFVBQU1DLFNBQVMsQ0FBQyxHQUFJRixVQUFVaEYsNEJBQTRCLEVBQUc7QUFDN0QsVUFBTW1GLFlBQVlELE9BQU9BLE9BQU9OLFNBQVMsQ0FBQztBQUMxQyxRQUFJTSxPQUFPTixTQUFTLE1BQU0sQ0FBQ08sYUFBYUEsVUFBVVYsS0FBSyxNQUFNLEtBQUs7QUFDaEVXO0FBQUFBLFFBQ0U7QUFBQSxNQUNGO0FBQ0E7QUFBQSxJQUNGO0FBQ0FILGlCQUFhLENBQUNJLGVBQWU7QUFBQSxNQUMzQixHQUFHQTtBQUFBQSxNQUNIckYsMEJBQTBCLENBQUMsR0FBR2tGLFFBQVEsRUFBRTtBQUFBLElBQzFDLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTUksb0JBQW9CQSxDQUFDTixXQUFXQyxjQUFjckQsT0FBT3pELE1BQU07QUFDL0QsVUFBTUMsUUFBUUQsRUFBRUUsT0FBT0Q7QUFDdkIsUUFBSThHLFNBQ0ZGLFVBQVVoRiw0QkFDVmdGLFVBQVVoRix5QkFBeUI0RSxTQUFTLElBQ3hDLENBQUMsR0FBR0ksVUFBVWhGLHdCQUF3QixJQUN0QyxDQUFDLEVBQUU7QUFDVCxXQUFPa0YsT0FBT04sVUFBVWhELE9BQU87QUFDN0JzRCxhQUFPSyxLQUFLLEVBQUU7QUFBQSxJQUNoQjtBQUNBTCxXQUFPdEQsS0FBSyxJQUFJeEQ7QUFDaEIsVUFBTW9ILFlBQVlOLE9BQU9PLFlBQVksQ0FBQ0MsY0FBY3BCLE9BQU9ULE1BQU07QUFDL0QsYUFBTzZCLGlCQUFpQixLQUFLQSxlQUFlcEIsTUFBTUcsS0FBSyxNQUFNLEtBQUtaLElBQUk7QUFBQSxJQUN4RSxHQUFHLEVBQUU7QUFDTHFCLGFBQVNNLGNBQWMsS0FBSyxDQUFDLEVBQUUsSUFBSU4sT0FBT1MsTUFBTSxHQUFHSCxZQUFZLENBQUM7QUFDaEVQLGlCQUFhO0FBQUEsTUFDWCxHQUFHRDtBQUFBQSxNQUNIaEYsMEJBQTBCa0Y7QUFBQUEsSUFDNUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNVSxtQkFBbUJBLENBQUNaLFdBQVdDLGNBQWNyRCxVQUFVO0FBQzNELFVBQU1zRCxTQUFTVyxNQUFNQyxRQUFRZCxVQUFVaEYsd0JBQXdCLElBQzNELENBQUMsR0FBR2dGLFVBQVVoRix3QkFBd0IsSUFDdEM7QUFDSixVQUFNK0YsZ0JBQWdCYixPQUFPdkIsT0FBTyxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNakMsS0FBSztBQUN6RHFELGlCQUFhO0FBQUEsTUFDWCxHQUFHRDtBQUFBQSxNQUNIaEYsMEJBQTBCK0Y7QUFBQUEsSUFDNUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNQyxlQUFlLE9BQU83SCxNQUFNO0FBQ2hDQSxNQUFFOEgsZUFBZTtBQUNqQixVQUFNQyxhQUFhL0IsYUFBYSxhQUFhO0FBQzdDLFFBQUk7QUFDRixZQUFNZ0MsaUJBQWlCQSxDQUFDL0MsUUFDdEJBLFFBQVEsTUFBTUEsT0FBTyxPQUFPLElBQUlJLE9BQU9KLEdBQUc7QUFDNUMsVUFBSThDLFlBQVk7QUFDZCxjQUFNRSxhQUFhO0FBQUEsVUFDakIsR0FBR3ZIO0FBQUFBLFVBQ0hnQixRQUFRc0csZUFBZXRILFNBQVNnQixNQUFNO0FBQUEsVUFDdENLLFVBQVU7QUFBQSxZQUNSQyxPQUFPZ0csZUFBZXRILFNBQVNxQixTQUFTQyxLQUFLO0FBQUEsWUFDN0NDLEtBQUsrRixlQUFldEgsU0FBU3FCLFNBQVNFLEdBQUc7QUFBQSxZQUN6Q0Msa0JBQWtCOEY7QUFBQUEsY0FDaEJ0SCxTQUFTcUIsU0FBU0c7QUFBQUEsWUFDcEI7QUFBQSxZQUNBQyxtQkFBbUI2RjtBQUFBQSxjQUNqQnRILFNBQVNxQixTQUFTSTtBQUFBQSxZQUNwQjtBQUFBLFlBQ0FDLG9CQUFvQjRGO0FBQUFBLGNBQ2xCdEgsU0FBU3FCLFNBQVNLO0FBQUFBLFlBQ3BCO0FBQUEsWUFDQUMsbUJBQW1CMkY7QUFBQUEsY0FDakJ0SCxTQUFTcUIsU0FBU007QUFBQUEsWUFDcEI7QUFBQSxZQUNBQyxrQkFBa0IwRjtBQUFBQSxjQUNoQnRILFNBQVNxQixTQUFTTztBQUFBQSxZQUNwQjtBQUFBLFlBQ0FDLFlBQVl5RixlQUFldEgsU0FBU3FCLFNBQVNRLFVBQVU7QUFBQSxVQUN6RDtBQUFBLFVBQ0FDLFlBQVk7QUFBQSxZQUNWQyxZQUFZdUYsZUFBZXRILFNBQVM4QixXQUFXQyxVQUFVO0FBQUEsWUFDekRDLEtBQUtzRixlQUFldEgsU0FBUzhCLFdBQVdFLEdBQUc7QUFBQSxZQUMzQ0MsS0FBS3FGLGVBQWV0SCxTQUFTOEIsV0FBV0csR0FBRztBQUFBLFlBQzNDQyxrQkFBa0JvRjtBQUFBQSxjQUNoQnRILFNBQVM4QixXQUFXSTtBQUFBQSxZQUN0QjtBQUFBLFVBQ0Y7QUFBQSxVQUNBMUIsZ0JBQWdCN0I7QUFBQUEsVUFDaEI2SSxzQkFBc0IzSTtBQUFBQSxRQUN4QjtBQUNBLGNBQU0wRCxXQUFXLE1BQU16RixJQUFJMkssS0FBSyxxQkFBcUJGLFlBQVk7QUFBQSxVQUMvREcsU0FBUztBQUFBLFlBQ1AsZ0JBQWdCO0FBQUEsVUFDbEI7QUFBQSxRQUNGLENBQUM7QUFDRDVKLHFCQUFhLEtBQUs7QUFzQ2xCYyw2QkFBcUIsRUFBRTtBQUN2QkUsc0NBQThCLEVBQUU7QUFDaENNLHlCQUFpQixDQUFDK0UsU0FBU0EsT0FBTyxDQUFDO0FBQ25DdkUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTNEQsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUM3QyxVQUNFQSxNQUFNcEIsWUFDTm9CLE1BQU1wQixTQUFTRyxRQUNmaUIsTUFBTXBCLFNBQVNHLEtBQUs1QyxTQUNwQjtBQUNBLGNBQU02SCxTQUFTaEUsTUFBTXBCLFNBQVNHLEtBQUs1QyxRQUFROEgsWUFBWTtBQUN2RCxZQUFJRCxPQUFPRSxTQUFTLGNBQWMsR0FBRztBQUNuQ3JKLG9CQUFVLENBQUNzSixnQkFBZ0I7QUFBQSxZQUN6QixHQUFHQTtBQUFBQSxZQUNIMUgsY0FBYztBQUFBLFVBQ2hCLEVBQUU7QUFBQSxRQUNKLE9BQU87QUFDTFIseUJBQWU7QUFBQSxZQUNiQyxZQUFZO0FBQUEsWUFDWkMsU0FBUzZELE1BQU1wQixTQUFTRyxLQUFLNUM7QUFBQUEsWUFDN0JDLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRixPQUFPO0FBQ0xILHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTWdJLFVBQVU7QUFBQSxJQUNkLEVBQUV4RSxLQUFLLE1BQU15RSxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFekUsS0FBSyxRQUFReUUsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFekUsS0FBSyxnQkFBZ0J5RSxRQUFRLGNBQWM7QUFBQSxJQUM3QyxFQUFFekUsS0FBSyxnQkFBZ0J5RSxRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUV6RSxLQUFLLGVBQWV5RSxRQUFRLGNBQWM7QUFBQTtBQUFBLElBRTVDLEVBQUV6RSxLQUFLLFVBQVV5RSxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU10RSx3QkFBd0IsT0FBT3VFLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU0xRixXQUFXLE1BQU16RixJQUFJMEY7QUFBQUEsUUFDekIsNkNBQTZDeUYsTUFBTTtBQUFBLE1BQ3JEO0FBQ0E3SixxQkFBZW1FLFNBQVNHLE1BQU1DLFFBQVE7QUFDdEMzRSx5QkFBbUIsSUFBSTtBQUN2QlEsZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZCxTQUFTbUYsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUNBLFFBQU1GLHdCQUF3QixPQUFPd0UsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTTFGLFdBQVcsTUFBTXpGLElBQUkwRixJQUFJLDZCQUE2QnlGLE1BQU0sRUFBRTtBQUNwRTNKLDJCQUFxQmlFLFNBQVNHLE1BQU1DLFFBQVE7QUFDNUNOLHdCQUFrQjtBQUFBLFFBQ2hCbkMsTUFBTXFDLFVBQVVHLE1BQU1DLFVBQVV6QztBQUFBQSxRQUNoQ0MsT0FBT29DLFVBQVVHLE1BQU1DLFVBQVV4QztBQUFBQSxRQUNqQ0MsY0FBY21DLFVBQVVHLE1BQU1DLFVBQVV2QztBQUFBQTtBQUFBQSxRQUV4Q0UsU0FBU2lDLFVBQVVHLE1BQU1DLFVBQVVyQztBQUFBQSxRQUNuQ0MsV0FBV2dDLFVBQVVHLE1BQU1DLFVBQVVwQztBQUFBQSxRQUNyQ0UsUUFBUThCLFVBQVVHLE1BQU1DLFVBQVVsQztBQUFBQSxRQUNsQ0osU0FBU2tDLFVBQVVHLE1BQU1DLFVBQVV0QztBQUFBQSxRQUNuQ00sY0FBYzRCLFVBQVVHLE1BQU1DLFVBQVVoQyxjQUFjdUgsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2xFdEgsUUFBUTJCLFVBQVVHLE1BQU1DLFVBQVUvQjtBQUFBQSxRQUNsQ0MsS0FBSzBCLFVBQVVHLE1BQU1DLFVBQVU5QixLQUFLcUgsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2hEcEgsUUFBUXlCLFVBQVVHLE1BQU1DLFVBQVU3QjtBQUFBQSxRQUNsQ0Msa0JBQWtCd0IsVUFBVUcsTUFBTUMsVUFBVTVCO0FBQUFBLFFBQzVDQyxRQUFRdUIsVUFBVUcsTUFBTUMsVUFBVTNCO0FBQUFBLFFBQ2xDQyxjQUFjc0IsVUFBVUcsTUFBTUMsVUFBVTFCLGNBQWNpSCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDbEUvRywwQkFBMEJvQixVQUFVRyxNQUFNQyxVQUN0Q3hCLDRCQUE0QixDQUFDLEVBQUU7QUFBQSxRQUNuQ0QsMEJBQ0VxQixVQUFVRyxNQUFNQyxVQUFVekI7QUFBQUEsUUFDNUJFLHdCQUNFbUIsVUFBVUcsTUFBTUMsVUFBVXZCLHdCQUF3QitHLFNBQVMsS0FBSztBQUFBLFFBQ2xFOUcsVUFBVTtBQUFBLFVBQ1JDLE9BQU9pQixVQUFVRyxNQUFNQyxVQUFVdEIsVUFBVUMsU0FBUztBQUFBLFVBQ3BEQyxLQUFLZ0IsVUFBVUcsTUFBTUMsVUFBVXRCLFVBQVVFLE9BQU87QUFBQSxVQUNoREMsa0JBQ0VlLFVBQVVHLE1BQU1DLFVBQVV0QixVQUFVRyxvQkFBb0I7QUFBQSxVQUMxREMsbUJBQ0VjLFVBQVVHLE1BQU1DLFVBQVV0QixVQUFVSSxxQkFBcUI7QUFBQSxVQUMzREMsb0JBQ0VhLFVBQVVHLE1BQU1DLFVBQVV0QixVQUFVSyxzQkFBc0I7QUFBQSxVQUM1REMsbUJBQ0VZLFVBQVVHLE1BQU1DLFVBQVV0QixVQUFVTSxxQkFBcUI7QUFBQSxVQUMzREMsa0JBQ0VXLFVBQVVHLE1BQU1DLFVBQVV0QixVQUFVTyxvQkFBb0I7QUFBQSxVQUMxREMsWUFBWVUsVUFBVUcsTUFBTUMsVUFBVXRCLFVBQVVRLGNBQWM7QUFBQSxRQUNoRTtBQUFBLFFBRUFDLFlBQVk7QUFBQSxVQUNWQyxZQUFZUSxVQUFVRyxNQUFNQyxVQUFVYixZQUFZQyxjQUFjO0FBQUEsVUFDaEVDLEtBQUtPLFVBQVVHLE1BQU1DLFVBQVViLFlBQVlFLE9BQU87QUFBQSxVQUNsREMsS0FBS00sVUFBVUcsTUFBTUMsVUFBVWIsWUFBWUcsT0FBTztBQUFBLFVBQ2xEQyxrQkFDRUssVUFBVUcsTUFBTUMsVUFBVWIsWUFBWUksb0JBQW9CO0FBQUEsUUFDOUQ7QUFBQSxRQUNBQyxtQkFBbUJJLFVBQVVHLE1BQU1DLFVBQVVSLHFCQUFxQjtBQUFBLE1BQ3BFLENBQUM7QUFDRHZELDJCQUFxQjJELFNBQVNHLE1BQU1DLFVBQVVuQyxnQkFBZ0J3QyxPQUFPLENBQUM7QUFDdEVsRTtBQUFBQSxRQUNFeUQsU0FBU0csTUFBTUMsVUFBVTZFLHdCQUF3QjtBQUFBLE1BQ25EO0FBQ0E5SCw4QkFBd0I2QyxTQUFTRyxNQUFNQyxVQUFVbkMsZ0JBQWdCNEMsS0FBSztBQUN0RWxGLHlCQUFtQixJQUFJO0FBQ3ZCTSxnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVNtRixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUEsUUFBTXlFLG9CQUFvQkEsQ0FDeEJsSSxNQUNBWCxPQUNBOEIsV0FBVyxPQUNYUyxhQUFhLFVBQ1Y7QUFDSCxRQUFJVCxVQUFVO0FBQ1pnQix3QkFBa0IsQ0FBQzZDLGNBQWM7QUFBQSxRQUMvQixHQUFHQTtBQUFBQSxRQUNIN0QsVUFBVSxFQUFFLEdBQUc2RCxTQUFTN0QsVUFBVSxDQUFDbkIsSUFBSSxHQUFHWCxNQUFNO0FBQUEsTUFDbEQsRUFBRTtBQUFBLElBQ0osV0FBV3VDLFlBQVk7QUFDckJPLHdCQUFrQixDQUFDNkMsY0FBYztBQUFBLFFBQy9CLEdBQUdBO0FBQUFBLFFBQ0hwRCxZQUFZLEVBQUUsR0FBR29ELFNBQVNwRCxZQUFZLENBQUM1QixJQUFJLEdBQUdYLE1BQU07QUFBQSxNQUN0RCxFQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0w4Qyx3QkFBa0IsQ0FBQzZDLGNBQWM7QUFBQSxRQUMvQixHQUFHQTtBQUFBQSxRQUNILENBQUNoRixJQUFJLEdBQUdYO0FBQUFBLE1BQ1YsRUFBRTtBQUNGZixnQkFBVSxDQUFDMkYsVUFBVTtBQUFBLFFBQ25CLEdBQUdBO0FBQUFBLFFBQ0gsQ0FBQ2pFLElBQUksR0FBRztBQUFBLE1BQ1YsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBQ0EsUUFBTW1JLG1CQUFtQixZQUFZO0FBQ25DLFFBQUlsSyxhQUFhO0FBQ2YsVUFBSTtBQUNGLGNBQU1yQixJQUFJd0w7QUFBQUEsVUFDUixnREFBZ0RuSyxZQUFZNkUsR0FBRztBQUFBLFFBQ2pFO0FBQ0FoRiwyQkFBbUIsS0FBSztBQUN4QkksdUJBQWUsSUFBSTtBQUNuQmdCLHlCQUFpQixDQUFDK0UsU0FBU0EsT0FBTyxDQUFDO0FBQ25DdkUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFNBQVM0RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLE1BQzdDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNNEUsZUFBZSxPQUFPakosTUFBTTtBQUNoQ0EsTUFBRThILGVBQWU7QUFDakIsVUFBTW9CLFVBQVVsRCxhQUFhO0FBQzdCLFFBQUk7QUFDRixVQUFJa0QsU0FBUztBQUNYLGNBQU1qQixhQUFhO0FBQUEsVUFDakIsR0FBR25GO0FBQUFBLFVBQ0hOLFlBQVk7QUFBQSxZQUNWLEdBQUdNLGVBQWVOO0FBQUFBLFVBQ3BCO0FBQUEsVUFDQVQsVUFBVTtBQUFBLFlBQ1IsR0FBR2UsZUFBZWY7QUFBQUEsVUFDcEI7QUFBQSxVQUNBYixnQkFBZ0I3QjtBQUFBQSxVQUNoQjZJLHNCQUFzQjNJO0FBQUFBLFFBQ3hCO0FBQ0EsY0FBTTBELFdBQVcsTUFBTXpGLElBQUkyTDtBQUFBQSxVQUN6QiwwQ0FBMENwSyxrQkFBa0IyRSxHQUFHO0FBQUEsVUFDL0R1RTtBQUFBQSxRQUNGO0FBQ0FySiwyQkFBbUIsS0FBSztBQUN4QlUsNkJBQXFCLEVBQUU7QUFDdkJFLHNDQUE4QixFQUFFO0FBQ2hDTSx5QkFBaUIsQ0FBQytFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3ZFLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBUzRELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUMsVUFDRUEsTUFBTXBCLFlBQ05vQixNQUFNcEIsU0FBU0csUUFDZmlCLE1BQU1wQixTQUFTRyxLQUFLNUMsU0FDcEI7QUFDQUYsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUyxHQUFHNkQsTUFBTXBCLFNBQVNHLEtBQUs1QyxPQUFPO0FBQUEsVUFDdkNDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTEgsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1KLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDdUUsVUFBVSxFQUFFLEdBQUdBLE1BQU10RSxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVILHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5Qix1QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2IvQiw2QkFBYSxJQUFJO0FBQ2pCVSwwQkFBVSxDQUFDLENBQUM7QUFBQSxjQUNkO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBd0c7QUFBQTtBQUFBLFlBTHBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUNDYixnQkFBZ0JvSSxTQUFTLEtBQUssQ0FBQzlHLFlBQzlCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxlQUFld0U7QUFBQUEsWUFDZixNQUFNeEcsYUFBYVUsZ0JBQWdCYyxVQUFVO0FBQUEsWUFDN0M7QUFBQSxZQUNFLGlCQUFnQjtBQUFBLFlBQ2xCLGtCQUFrQjtBQUFBO0FBQUEsVUFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSzRDLElBRzVDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsU0FBU2QsZ0JBQWdCb0ksVUFBVTtBQUFBLFlBQ25DLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3NCO0FBQUEsV0EzQjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxTQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkNBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLFdBQVdsSSxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVXFKLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU87QUFBQTtBQUFBLGdCQUNMLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQTtBQUFBO0FBQUEsWUFINUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPbkgsU0FBU0U7QUFBQUEsY0FDaEIsVUFBVSxDQUFDWixNQUFNMkYsYUFBYTNGLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxjQUMzRCxJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUWlLO0FBQUEsVUFFaEtuSyxPQUFPMkIsUUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCM0IsaUJBQU8yQixRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLGFBakIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBUTtBQUFBO0FBQUEsa0JBQ1YsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUh4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9GLFNBQVNHO0FBQUFBLGdCQUNoQixVQUFVLENBQUNiLE1BQ1QyRixhQUFhM0YsRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsS0FBSztBQUFBLGdCQUU1QyxJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsY0FWbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVWlLO0FBQUEsWUFFaEtuSyxPQUFPNEIsU0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCNUIsaUJBQU80QixTQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLGVBbkIzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQWU7QUFBQTtBQUFBLGtCQUNWLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPSCxTQUFTSTtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDZCxNQUNUMkYsYUFBYTNGLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFFNUMsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGNBVmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVpSztBQUFBLFlBRWhLbkssT0FBTzZCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsYUE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStDQTtBQUFBLFFBbURBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFZO0FBQUE7QUFBQSxrQkFDTix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQTtBQUFBLGNBSGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0osU0FBU087QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQ2pCLE1BQ1QyRixhQUFhM0YsRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsS0FBSztBQUFBLGdCQUU1QyxJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsY0FWbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVWlLO0FBQUEsWUFFaEtuSyxPQUFPZ0MsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZoQyxpQkFBT2dDLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBUztBQUFBO0FBQUEsa0JBQ04sdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUg3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9QLFNBQVNTO0FBQUFBLGdCQUNoQixVQUFVLENBQUNuQixNQUNUMkYsYUFBYTNGLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFFNUMsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGNBVmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVpSztBQUFBLFlBRWhLbkssT0FBT2tDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QmxDLGlCQUFPa0MsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxlQW5CNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0NBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFVO0FBQUE7QUFBQSxnQkFDVix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUE7QUFBQTtBQUFBLFlBSDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBT1QsU0FBU0s7QUFBQUEsY0FDaEIsVUFBVSxDQUFDZixNQUFNMkYsYUFBYTNGLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxjQUMzRCxJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUWlLO0FBQUEsVUFFaEtuSyxPQUFPOEIsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCOUIsaUJBQU84QixXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLGFBakI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBaUI7QUFBQTtBQUFBLGtCQUNiLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUE7QUFBQTtBQUFBLGNBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsT0FBTzFCLHFCQUFxQmdLO0FBQUFBLGdCQUM1QixVQUFVN0U7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQSxnQkFDVjtBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixjQUFjLENBQUM4RSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWkMsU0FBU2UsTUFBTWhCLFlBQVksQ0FBQztBQUFBLGdCQUVoQzdJLG1CQUFTOEQ7QUFBQUEsa0JBQUksQ0FBQ3FCLFFBQ2IsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUlsQixLQUNyQ2tCLGNBQUlkLFNBRGFjLElBQUlsQixLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW1CQTtBQUFBLFlBQ0N6RSxPQUFPaUMsa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWakMsaUJBQU9pQyxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUE3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFTO0FBQUE7QUFBQSxrQkFDVix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQTtBQUFBLGNBSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osdUJBQXVCO0FBQUEsZ0JBQ3ZCO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLGNBQWMsQ0FBQ29JLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKbEIsWUFBWSxFQUNaQyxTQUFTZSxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU81SCxVQUFVWSxVQUFVK0g7QUFBQUEsZ0JBQzNCLFVBQVUsQ0FBQ3BKLFVBQVUwRixhQUFhLFVBQVUxRixLQUFLO0FBQUEsZ0JBQ2hELFdBQUMsVUFBVSxZQUFZLFlBQVksRUFBRXNEO0FBQUFBLGtCQUFJLENBQUNrRyxVQUN6Qyx1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsTUFBTW5CLFlBQVksR0FDakRtQixtQkFEaUJBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBa0JBO0FBQUEsWUFDQ3hLLE9BQU9xQyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJyQyxpQkFBT3FDLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsZUExQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsYUE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThEQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQWU7QUFBQTtBQUFBLGtCQUNWLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPWixTQUFTVztBQUFBQSxnQkFDaEIsVUFBVSxDQUFDckIsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBRTVDLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsY0FUbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU2lLO0FBQUEsWUFFaEtuSyxPQUFPb0MsZ0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWcEMsaUJBQU9vQyxnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFlO0FBQUE7QUFBQSxjQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9YLFNBQVNpQjtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDM0IsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBRTVDLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsY0FUbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU2lLO0FBQUEsZUFmbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMENBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUhoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU8xSSxTQUFTYTtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDdkIsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBRTVDLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsY0FUbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU2lLO0FBQUEsWUFFaEtuSyxPQUFPc0MsT0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCdEMsaUJBQU9zQyxPQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLGVBbEJ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQVM7QUFBQTtBQUFBLGtCQUNWLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FIekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkI7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0wsY0FBYyxDQUFDK0gsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0psQixZQUFZLEVBQ1pDLFNBQVNlLE1BQU1oQixZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBTzVILFVBQVVjLFVBQVU2SDtBQUFBQSxnQkFDM0IsVUFBVSxDQUFDcEosVUFBVTBGLGFBQWEsVUFBVTFGLEtBQUs7QUFBQSxnQkFDaEQsV0FBQyxRQUFRLFVBQVUsUUFBUSxFQUFFc0Q7QUFBQUEsa0JBQUksQ0FBQy9CLFdBQ2pDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxPQUFPOEcsWUFBWSxHQUNuRDlHLG9CQURpQkEsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFrQkE7QUFBQSxZQUNDdkMsT0FBT3VDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnZDLGlCQUFPdUMsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxlQTFCNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxhQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbURBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBbUI7QUFBQTtBQUFBLGtCQUNKO0FBQUEsa0JBQ3ZCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPZCxTQUFTZTtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDekIsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBRTVDLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxjQVZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVaUs7QUFBQSxZQUVoS25LLE9BQU93QyxvQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4QyxpQkFBT3dDLG9CQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQXlCO0FBQUE7QUFBQSxrQkFDVjtBQUFBLGtCQUN2Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQTtBQUFBLGNBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLENBQUN6QixNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLGdCQUM5QixNQUFLO0FBQUEsZ0JBQ0wsT0FBT2hKLFNBQVNvQjtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDOUIsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBRTVDLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxjQVhsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXaUs7QUFBQSxZQUVoS25LLE9BQU82QywwQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y3QyxpQkFBTzZDLDBCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLGFBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvREE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUEyQjtBQUFBO0FBQUEsa0JBRW5DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPcEIsU0FBU2tCO0FBQUFBLGdCQUNoQixVQUFVLENBQUM1QixNQUNUMkYsYUFBYTNGLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxnQkFFNUMsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGNBVmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVpSztBQUFBLFlBRWhLbkssT0FBTzJDLDRCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjNDLGlCQUFPMkMsNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBMkI7QUFBQTtBQUFBLGtCQUNaO0FBQUE7QUFBQTtBQUFBLGNBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9sQixTQUFTbUIsMkJBQTJCLENBQUMsS0FBSztBQUFBLGdCQUNqRCxVQUFVLENBQUM3QixNQUNUbUgsa0JBQWtCekcsVUFBVUMsYUFBYSxHQUFHWCxDQUFDO0FBQUEsZ0JBRS9DLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3BDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxjQVZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVaUssS0FYbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBQ0MxSSxTQUFTbUIsMEJBQ04yRixNQUFNLENBQUMsRUFDUmpFO0FBQUFBLGNBQUksQ0FBQzRDLE9BQU8xQyxVQUNYLHVCQUFDLFNBQWdCLFdBQVUsZ0NBQ3pCO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQU0sbUJBQW1CQSxRQUFRLENBQUM7QUFBQSxvQkFDbEMsT0FBTzBDO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ25HLE1BQ1RtSDtBQUFBQSxzQkFDRXpHO0FBQUFBLHNCQUNBQztBQUFBQSxzQkFDQThDLFFBQVE7QUFBQSxzQkFDUnpEO0FBQUFBLG9CQUNGO0FBQUEsb0JBRUYsSUFBSSw0QkFBNEJ5RCxRQUFRLENBQUM7QUFBQSxvQkFDekMsYUFBWTtBQUFBLG9CQUNaLFdBQVcscUNBQXFDN0YsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBY2lLO0FBQUEsZ0JBRWhLM0YsUUFBUSxLQUNQO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQ1BnRSxpQkFBaUIvRyxVQUFVQyxhQUFhOEMsUUFBUSxDQUFDO0FBQUEsb0JBRW5ELFdBQVU7QUFBQSxvQkFBdUI7QUFBQTtBQUFBLGtCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxtQkF6Qk1BLE9BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEyQkE7QUFBQSxZQUNEO0FBQUEsWUFDSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1tRCxjQUFjbEcsVUFBVUMsV0FBVztBQUFBLGdCQUNsRCxXQUFVO0FBQUEsZ0JBQStCO0FBQUE7QUFBQSxjQUgzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMERBO0FBQUEsYUFwRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFGQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFTO0FBQUE7QUFBQSxnQkFDSix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUE7QUFBQTtBQUFBLFlBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxDQUFDWCxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLGNBQzlCLE1BQUs7QUFBQSxjQUNMLE9BQU9oSixTQUFTZ0I7QUFBQUEsY0FDaEIsVUFBVSxDQUFDMUIsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsY0FFNUMsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLFlBWGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdpSztBQUFBLFVBRWpLLHVCQUFDLFVBQUssV0FBVSw4Q0FDYnJMLDhCQUFvQjJDLFNBQVNnQixVQUFVLENBQUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0N6QyxPQUFPeUMsVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCekMsaUJBQU95QyxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBdkI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsc0NBQXFDLG1DQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLDhDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNNEQseUJBQXlCLEtBQUs7QUFBQSxnQkFDN0MsV0FBVTtBQUFBLGdCQUNWO0FBQUEseUNBQUMsdUJBQW9CLE1BQU0sTUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFBRztBQUFBO0FBQUE7QUFBQSxjQUpuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFFQzVFLFNBQVNtQyxrQkFBa0I0RCxTQUFTLElBQ25DLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFVBQVMsOEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUEsY0FDdEMsdUJBQUMsU0FBSSxXQUFVLGVBQWMsMEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsY0FDdkMsdUJBQUMsU0FBSSxXQUFVLFVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0I7QUFBQSxpQkFIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBRUMvRixTQUFTbUMsa0JBQWtCVTtBQUFBQSxjQUFJLENBQUNvRyxNQUFNbEcsVUFDckM7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLGFBQVk7QUFBQSx3QkFDWixPQUFPa0csS0FBSy9JO0FBQUFBLHdCQUNaLFVBQVUsQ0FBQ1osTUFDVCtFO0FBQUFBLDBCQUNFdEI7QUFBQUEsMEJBQ0E7QUFBQSwwQkFDQXpELEVBQUVFLE9BQU9EO0FBQUFBLHdCQUNYO0FBQUEsd0JBRUYsV0FBVyw2QkFBNkJyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsc0JBVjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFVd0osS0FYMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFhQTtBQUFBLG9CQUdBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLGFBQVk7QUFBQSwwQkFDWixPQUFPTyxLQUFLMUosU0FBUztBQUFBLDBCQUNyQixVQUFVLENBQUNELE1BQ1QrRTtBQUFBQSw0QkFDRXRCO0FBQUFBLDRCQUNBO0FBQUEsNEJBQ0F6RCxFQUFFRSxPQUFPRDtBQUFBQSwwQkFDWDtBQUFBLDBCQUVGLFdBQVcsNkJBQTZCckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLHdCQVgxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBV3dKO0FBQUEsc0JBRXZKTyxLQUFLMUosUUFBUSxLQUNaLHVCQUFDLE9BQUUsV0FBVSw4REFDVmxDO0FBQUFBLDRDQUFvQjRMLEtBQUsxSixLQUFLO0FBQUEsd0JBQUU7QUFBQSwyQkFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQW1CQTtBQUFBLG9CQUdBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTLE1BQU1zRiw0QkFBNEI5QixLQUFLO0FBQUEsd0JBQ2hELFdBQVU7QUFBQSx3QkFDVixPQUFNO0FBQUEsd0JBQ04saUNBQUMsa0JBQWUsTUFBTSxNQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF5QjtBQUFBO0FBQUEsc0JBTDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBO0FBQUE7QUFBQSxnQkEvQ0tBO0FBQUFBLGdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpREE7QUFBQSxZQUNEO0FBQUEsZUEzREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0REEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsdUVBQ2IsaUNBQUMsT0FBRSxXQUFVLDBCQUF5QixzREFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQXZGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUZBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFXO0FBQUE7QUFBQSxZQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFRO0FBQUE7QUFBQSxnQkFGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLENBQUN6RCxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLGtCQUM5QixNQUFLO0FBQUEsa0JBQ0wsT0FDRWhKLFNBQVNxQixVQUFVQyxVQUFVLElBQ3pCLEtBQ0F0QixTQUFTcUIsVUFBVUM7QUFBQUEsa0JBRXpCLFVBQVUsQ0FBQ2hDLE1BQ1QyRixhQUFhM0YsRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsT0FBTyxNQUFNLEtBQUs7QUFBQSxrQkFFekQsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxnQkFkbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY2tLO0FBQUEsY0FFbEssdUJBQUMsVUFBSyxXQUFVLDhDQUNickwsOEJBQW9CMkMsU0FBU3FCLFVBQVVDLFNBQVMsQ0FBQyxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU07QUFBQTtBQUFBLGdCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsQ0FBQ2hDLE1BQU1BLEVBQUVFLE9BQU93SixLQUFLO0FBQUEsa0JBQzlCLE1BQUs7QUFBQSxrQkFDTCxPQUNFaEosU0FBU3FCLFVBQVVFLFFBQVEsSUFDdkIsS0FDQXZCLFNBQVNxQixVQUFVRTtBQUFBQSxrQkFFekIsVUFBVSxDQUFDakMsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxPQUFPLE1BQU0sS0FBSztBQUFBLGtCQUV6RCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjaUs7QUFBQSxjQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTCw4QkFBb0IyQyxTQUFTcUIsVUFBVUUsT0FBTyxDQUFDLEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxlQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFEQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFtQjtBQUFBO0FBQUEsZ0JBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxDQUFDakMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxrQkFDOUIsTUFBSztBQUFBLGtCQUNMLE9BQ0VoSixTQUFTcUIsVUFBVUcscUJBQXFCLElBQ3BDLEtBQ0F4QixTQUFTcUIsVUFBVUc7QUFBQUEsa0JBRXpCLFVBQVUsQ0FBQ2xDLE1BQ1QyRixhQUFhM0YsRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsT0FBTyxNQUFNLEtBQUs7QUFBQSxrQkFFekQsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxnQkFkbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY2lLO0FBQUEsY0FFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickw7QUFBQUEsZ0JBQ0MyQyxTQUFTcUIsVUFBVUcsb0JBQW9CO0FBQUEsY0FDekMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQW9CO0FBQUE7QUFBQSxnQkFGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLENBQUNsQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLGtCQUM5QixNQUFLO0FBQUEsa0JBQ0wsT0FDRWhKLFNBQVNxQixVQUFVSSxzQkFBc0IsSUFDckMsS0FDQXpCLFNBQVNxQixVQUFVSTtBQUFBQSxrQkFFekIsVUFBVSxDQUFDbkMsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxPQUFPLE1BQU0sS0FBSztBQUFBLGtCQUV6RCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjaUs7QUFBQSxjQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTDtBQUFBQSxnQkFDQzJDLFNBQVNxQixVQUFVSSxxQkFBcUI7QUFBQSxjQUMxQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQkE7QUFBQSxlQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlEQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFxQjtBQUFBO0FBQUEsZ0JBRi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxDQUFDbkMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxrQkFDOUIsTUFBSztBQUFBLGtCQUNMLE9BQ0VoSixTQUFTcUIsVUFBVUssdUJBQXVCLElBQ3RDLEtBQ0ExQixTQUFTcUIsVUFBVUs7QUFBQUEsa0JBRXpCLFVBQVUsQ0FBQ3BDLE1BQ1QyRixhQUFhM0YsRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsT0FBTyxNQUFNLEtBQUs7QUFBQSxrQkFFekQsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxnQkFkbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY2lLO0FBQUEsY0FFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickw7QUFBQUEsZ0JBQ0MyQyxTQUFTcUIsVUFBVUssc0JBQXNCO0FBQUEsY0FDM0MsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQW9CO0FBQUE7QUFBQSxnQkFGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLENBQUNwQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLGtCQUM5QixNQUFLO0FBQUEsa0JBQ0wsT0FDRWhKLFNBQVNxQixVQUFVTSxzQkFBc0IsSUFDckMsS0FDQTNCLFNBQVNxQixVQUFVTTtBQUFBQSxrQkFFekIsVUFBVSxDQUFDckMsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxPQUFPLE1BQU0sS0FBSztBQUFBLGtCQUV6RCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjaUs7QUFBQSxjQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTDtBQUFBQSxnQkFDQzJDLFNBQVNxQixVQUFVTSxxQkFBcUI7QUFBQSxjQUMxQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQkE7QUFBQSxlQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlEQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFtQjtBQUFBO0FBQUEsZ0JBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxDQUFDckMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxrQkFDOUIsTUFBSztBQUFBLGtCQUNMLE9BQ0VoSixTQUFTcUIsVUFBVU8scUJBQXFCLElBQ3BDLEtBQ0E1QixTQUFTcUIsVUFBVU87QUFBQUEsa0JBRXpCLFVBQVUsQ0FBQ3RDLE1BQ1QyRixhQUFhM0YsRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsT0FBTyxNQUFNLEtBQUs7QUFBQSxrQkFFekQsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxnQkFkbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY2lLO0FBQUEsY0FFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickw7QUFBQUEsZ0JBQ0MyQyxTQUFTcUIsVUFBVU8sb0JBQW9CO0FBQUEsY0FDekMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWE7QUFBQTtBQUFBLGdCQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsQ0FBQ3RDLE1BQU1BLEVBQUVFLE9BQU93SixLQUFLO0FBQUEsa0JBQzlCLE1BQUs7QUFBQSxrQkFDTCxPQUNFaEosU0FBU3FCLFVBQVVRLGVBQWUsSUFDOUIsS0FDQTdCLFNBQVNxQixVQUFVUTtBQUFBQSxrQkFFekIsVUFBVSxDQUFDdkMsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxPQUFPLE1BQU0sS0FBSztBQUFBLGtCQUV6RCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjaUs7QUFBQSxjQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTCw4QkFBb0IyQyxTQUFTcUIsVUFBVVEsY0FBYyxDQUFDLEtBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxlQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLGFBeE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5T0E7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQWE7QUFBQTtBQUFBLFlBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWE7QUFBQTtBQUFBLGdCQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsQ0FBQ3ZDLE1BQU1BLEVBQUVFLE9BQU93SixLQUFLO0FBQUEsa0JBQzlCLE1BQUs7QUFBQSxrQkFDTCxPQUNFaEosU0FBUzhCLFlBQVlDLGVBQWUsSUFDaEMsS0FDQS9CLFNBQVM4QixZQUFZQztBQUFBQSxrQkFFM0IsVUFBVSxDQUFDekMsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxPQUFPLE9BQU8sSUFBSTtBQUFBLGtCQUV6RCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjaUs7QUFBQSxjQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTDtBQUFBQSxnQkFDQzJDLFNBQVM4QixZQUFZQyxjQUFjO0FBQUEsY0FDckMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU07QUFBQTtBQUFBLGdCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsQ0FBQ3pDLE1BQU1BLEVBQUVFLE9BQU93SixLQUFLO0FBQUEsa0JBQzlCLE1BQUs7QUFBQSxrQkFDTCxPQUNFaEosU0FBUzhCLFlBQVlFLFFBQVEsSUFDekIsS0FDQWhDLFNBQVM4QixZQUFZRTtBQUFBQSxrQkFFM0IsVUFBVSxDQUFDMUMsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxPQUFPLE9BQU8sSUFBSTtBQUFBLGtCQUV6RCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjaUs7QUFBQSxjQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTCw4QkFBb0IyQyxTQUFTOEIsWUFBWUUsT0FBTyxDQUFDLEtBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxlQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFNO0FBQUE7QUFBQSxnQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLENBQUMxQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLGtCQUM5QixNQUFLO0FBQUEsa0JBQ0wsT0FDRWhKLFNBQVM4QixZQUFZRyxRQUFRLElBQ3pCLEtBQ0FqQyxTQUFTOEIsWUFBWUc7QUFBQUEsa0JBRTNCLFVBQVUsQ0FBQzNDLE1BQ1QyRixhQUFhM0YsRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsT0FBTyxPQUFPLElBQUk7QUFBQSxrQkFFekQsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxnQkFkbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY2lLO0FBQUEsY0FFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickwsOEJBQW9CMkMsU0FBUzhCLFlBQVlHLE9BQU8sQ0FBQyxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQW1CO0FBQUE7QUFBQSxnQkFGN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLENBQUMzQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLGtCQUM5QixNQUFLO0FBQUEsa0JBQ0wsT0FDRWhKLFNBQVM4QixZQUFZSSxxQkFBcUIsSUFDdEMsS0FDQWxDLFNBQVM4QixZQUFZSTtBQUFBQSxrQkFFM0IsVUFBVSxDQUFDNUMsTUFDVDJGLGFBQWEzRixFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxPQUFPLE9BQU8sSUFBSTtBQUFBLGtCQUV6RCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQWRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjaUs7QUFBQSxjQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTDtBQUFBQSxnQkFDQzJDLFNBQVM4QixZQUFZSSxvQkFBb0I7QUFBQSxjQUMzQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQkE7QUFBQSxlQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLGFBckhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzSEE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ29IO0FBQUE7QUFBQSxVQUhoSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBcjhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBczhCQTtBQUFBLFNBMThCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMjhCQSxLQTU4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTY4QkE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXakU7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFDdkMsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QywrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVXFLLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFjO0FBQUE7QUFBQSxvQkFDWix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFIN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT25HLGVBQWVsQztBQUFBQSxrQkFDdEIsVUFBVSxDQUFDWixNQUNUOEksa0JBQWtCOUksRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsS0FBSztBQUFBLGtCQUVqRCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsZ0JBVmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVpSztBQUFBLGNBRWhLbkssT0FBTzJCLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjNCLGlCQUFPMkIsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxpQkFuQjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWU7QUFBQTtBQUFBLHNCQUNqQix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFIekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPa0MsZUFBZWpDO0FBQUFBLG9CQUN0QixVQUFVLENBQUNiLE1BQ1Q4SSxrQkFBa0I5SSxFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsb0JBRWpELElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxrQkFWbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVVpSztBQUFBLGdCQUVoS25LLE9BQU80QixTQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI1QixpQkFBTzRCLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsbUJBbkIzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFzQjtBQUFBO0FBQUEsc0JBQ2pCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUhoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9pQyxlQUFlaEM7QUFBQUEsb0JBQ3RCLFVBQVUsQ0FBQ2QsTUFDVDhJLGtCQUFrQjlJLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxvQkFFakQsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQVZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVWlLO0FBQUEsZ0JBRWhLbkssT0FBTzZCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQXlCYixpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWlCO0FBQUE7QUFBQSxvQkFDakIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9nQyxlQUFlOUI7QUFBQUEsa0JBQ3RCLFVBQVUsQ0FBQ2hCLE1BQ1Q4SSxrQkFBa0I5SSxFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsa0JBRWpELElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxnQkFWbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVWlLO0FBQUEsY0FFaEtuSyxPQUFPK0IsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YvQixpQkFBTytCLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQSxLQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlEQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFtQjtBQUFBO0FBQUEsc0JBQ2IsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBTzhCLGVBQWU3QjtBQUFBQSxvQkFDdEIsVUFBVSxDQUFDakIsTUFDVDhJLGtCQUFrQjlJLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxvQkFFakQsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQVZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVWlLO0FBQUEsZ0JBRWhLbkssT0FBT2dDLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEMsaUJBQU9nQyxhQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZ0I7QUFBQTtBQUFBLHNCQUNiLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUg5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU82QixlQUFlM0I7QUFBQUEsb0JBQ3RCLFVBQVUsQ0FBQ25CLE1BQ1Q4SSxrQkFBa0I5SSxFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsb0JBRWpELElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxrQkFWbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVVpSztBQUFBLGdCQUVoS25LLE9BQU9rQyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJsQyxpQkFBT2tDLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsbUJBbkI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWlCO0FBQUE7QUFBQSxvQkFDakIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU8yQixlQUFlL0I7QUFBQUEsa0JBQ3RCLFVBQVUsQ0FBQ2YsTUFDVDhJLGtCQUFrQjlJLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxrQkFFakQsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGdCQVZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVaUs7QUFBQSxjQUVoS25LLE9BQU84QixXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI5QixpQkFBTzhCLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBbkI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUF3QjtBQUFBO0FBQUEsc0JBQ3BCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUgvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsTUFBSztBQUFBLG9CQUNMLE9BQU8xQixxQkFBcUJnSztBQUFBQSxvQkFDNUIsVUFBVTdFO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixXQUFVO0FBQUEsb0JBQ1Y7QUFBQSxvQkFDQSx1QkFBdUI7QUFBQSxvQkFDdkIsY0FBYyxDQUFDOEUsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0psQixZQUFZLEVBQ1pDLFNBQVNlLE1BQU1oQixZQUFZLENBQUM7QUFBQSxvQkFFaEM3SSxtQkFBUzhEO0FBQUFBLHNCQUFJLENBQUNxRyxZQUNiLHVCQUFDLE9BQU8sUUFBUCxFQUFnQyxPQUFPQSxRQUFRbEcsS0FDN0NrRyxrQkFBUTlGLFNBRFM4RixRQUFRbEcsS0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQW1CQTtBQUFBLGdCQUNDekUsT0FBT2lDLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmpDLGlCQUFPaUMsa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdDQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFnQjtBQUFBO0FBQUEsc0JBQ2pCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQ29JLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKbEIsWUFBWSxFQUNaQyxTQUFTZSxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsb0JBRWpDLE9BQU94RixnQkFBZ0J4QixVQUFVK0g7QUFBQUEsb0JBQ2pDLFVBQVUsQ0FBQ3BKLFVBQVU2SSxrQkFBa0IsVUFBVTdJLEtBQUs7QUFBQSxvQkFDckQsV0FBQyxVQUFVLFlBQVksWUFBWSxFQUFFc0Q7QUFBQUEsc0JBQUksQ0FBQ2pDLFdBQ3pDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxPQUFPZ0gsWUFBWSxHQUNuRGhILG9CQURpQkEsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWtCQTtBQUFBLGdCQUNDckMsT0FBT3FDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnJDLGlCQUFPcUMsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxtQkExQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNEJBO0FBQUEsaUJBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0RBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQXNCO0FBQUE7QUFBQSxzQkFDakIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBO0FBQUE7QUFBQSxrQkFIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPd0IsZUFBZXpCO0FBQUFBLG9CQUN0QixVQUFVLENBQUNyQixNQUNUOEksa0JBQWtCOUksRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsS0FBSztBQUFBLG9CQUVqRCxJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQVRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU2lLO0FBQUEsZ0JBRWhLbkssT0FBT29DLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnBDLGlCQUFPb0MsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFzQjtBQUFBO0FBQUEsa0JBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FDRXlCLGdCQUFnQm5CLGVBQ1osSUFBSWtJLEtBQUsvRyxnQkFBZ0JuQixnQkFBZ0IsRUFBRSxFQUN4Q21JLFlBQVksRUFDWmxCLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDZjtBQUFBLG9CQUVOLFVBQVUsQ0FBQzVJLE1BQ1Q4SSxrQkFBa0I5SSxFQUFFRSxPQUFPVSxNQUFNWixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsb0JBRWpELElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsa0JBZmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFlaUs7QUFBQSxtQkFyQm5LO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0RBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWE7QUFBQTtBQUFBLHNCQUNQLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FDRXRHLGdCQUFnQnZCLE1BQ1osSUFBSXNJLEtBQUsvRyxnQkFBZ0J2QixPQUFPLEVBQUUsRUFDL0J1SSxZQUFZLEVBQ1psQixNQUFNLEdBQUcsRUFBRSxDQUFDLElBQ2Y7QUFBQSxvQkFFTixVQUFVLENBQUM1SSxNQUNUOEksa0JBQWtCOUksRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsS0FBSztBQUFBLG9CQUVqRCxJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQWZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZWlLO0FBQUEsZ0JBRWhLbkssT0FBT3NDLE9BQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnRDLGlCQUFPc0MsT0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQSxtQkF4QnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWdCO0FBQUE7QUFBQSxzQkFDakIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBO0FBQUE7QUFBQSxrQkFIekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsY0FBYyxDQUFDK0gsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0psQixZQUFZLEVBQ1pDLFNBQVNlLE1BQU1oQixZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT3hGLGdCQUFnQnRCLFVBQVU2SDtBQUFBQSxvQkFDakMsVUFBVSxDQUFDcEosVUFBVTZJLGtCQUFrQixVQUFVN0ksS0FBSztBQUFBLG9CQUNyRCxXQUFDLFFBQVEsVUFBVSxRQUFRLEVBQUVzRDtBQUFBQSxzQkFBSSxDQUFDL0IsV0FDakMsdUJBQUMsT0FBTyxRQUFQLEVBQTJCLE9BQU9BLE9BQU84RyxZQUFZLEdBQ25EOUcsb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBa0JBO0FBQUEsZ0JBQ0N2QyxPQUFPdUMsVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCdkMsaUJBQU91QyxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLG1CQTFCNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0QkE7QUFBQSxpQkF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5REE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBMEI7QUFBQTtBQUFBLHNCQUNYO0FBQUEsc0JBQ3ZCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3NCLGVBQWVyQjtBQUFBQSxvQkFDdEIsVUFBVSxDQUFDekIsTUFDVDhJLGtCQUFrQjlJLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxvQkFFakQsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQVZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVWlLO0FBQUEsZ0JBR2hLbkssT0FBT3dDLG9CQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhDLGlCQUFPd0Msb0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFnQztBQUFBO0FBQUEsc0JBQ3BCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLENBQUN6QixNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLG9CQUM5QixNQUFLO0FBQUEsb0JBQ0wsT0FBTzVHLGVBQWVoQjtBQUFBQSxvQkFDdEIsVUFBVSxDQUFDOUIsTUFDVDhJLGtCQUFrQjlJLEVBQUVFLE9BQU9VLE1BQU1aLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxvQkFFakQsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQVhsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBV2lLO0FBQUEsZ0JBRWhLbkssT0FBTzZDLDBCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdDLGlCQUFPNkMsMEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdCQTtBQUFBLGlCQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFrQztBQUFBO0FBQUEsc0JBQ2pCO0FBQUEsc0JBQ3pCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2dCLGdCQUFnQmxCO0FBQUFBLG9CQUN2QixVQUFVLENBQUM1QixNQUNUOEksa0JBQWtCOUksRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsS0FBSztBQUFBLG9CQUVqRCxJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsa0JBVmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFVaUs7QUFBQSxnQkFFaEtuSyxPQUFPMkMsNEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWM0MsaUJBQU8yQyw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWtDO0FBQUE7QUFBQSxzQkFDbkI7QUFBQTtBQUFBO0FBQUEsa0JBSHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9rQixlQUFlakIsMkJBQTJCLENBQUMsS0FBSztBQUFBLG9CQUN2RCxVQUFVLENBQUM3QixNQUNUbUg7QUFBQUEsc0JBQ0VyRTtBQUFBQSxzQkFDQUM7QUFBQUEsc0JBQ0E7QUFBQSxzQkFDQS9DO0FBQUFBLG9CQUNGO0FBQUEsb0JBRUYsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDcEMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLGtCQWZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZWlLLEtBaEJuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLGdCQUNDdEcsZUFBZWpCLDBCQUNaMkYsTUFBTSxDQUFDLEVBQ1JqRTtBQUFBQSxrQkFBSSxDQUFDNEMsT0FBTzFDLFVBQ1g7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsV0FBVTtBQUFBLHNCQUNWO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMLE1BQU0sbUJBQW1CQSxRQUFRLENBQUM7QUFBQSw0QkFDbEMsT0FBTzBDO0FBQUFBLDRCQUNQLFVBQVUsQ0FBQ25HLE1BQ1RtSDtBQUFBQSw4QkFDRXJFO0FBQUFBLDhCQUNBQztBQUFBQSw4QkFDQVUsUUFBUTtBQUFBLDhCQUNSekQ7QUFBQUEsNEJBQ0Y7QUFBQSw0QkFFRixJQUFJLG1DQUFtQ3lELFFBQVEsQ0FBQztBQUFBLDRCQUNoRCxhQUFZO0FBQUEsNEJBQ1osV0FBVyxxQ0FBcUM3RixVQUFVd0wsTUFBTTtBQUFBO0FBQUEsMEJBZGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFjaUs7QUFBQSx3QkFFaks7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMLFNBQVMsTUFDUDNCO0FBQUFBLDhCQUNFM0U7QUFBQUEsOEJBQ0FDO0FBQUFBLDhCQUNBVSxRQUFRO0FBQUEsNEJBQ1Y7QUFBQSw0QkFFRixXQUFVO0FBQUEsNEJBQXVCO0FBQUE7QUFBQSwwQkFUbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVdBO0FBQUE7QUFBQTtBQUFBLG9CQTdCS0EsUUFBUTtBQUFBLG9CQURmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBK0JBO0FBQUEsZ0JBQ0Q7QUFBQSxnQkFDSDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUNQbUQsY0FBYzlELGdCQUFnQkMsaUJBQWlCO0FBQUEsb0JBRWpELFdBQVU7QUFBQSxvQkFBK0I7QUFBQTtBQUFBLGtCQUwzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxtQkFwRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxRUE7QUFBQSxpQkEvRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYixpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWdCO0FBQUE7QUFBQSxvQkFDWCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUgvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsQ0FBQy9DLE1BQU1BLEVBQUVFLE9BQU93SixLQUFLO0FBQUEsa0JBQzlCLE1BQUs7QUFBQSxrQkFDTCxPQUFPNUcsZUFBZXBCO0FBQUFBLGtCQUN0QixVQUFVLENBQUMxQixNQUNUOEksa0JBQWtCOUksRUFBRUUsT0FBT1UsTUFBTVosRUFBRUUsT0FBT0QsS0FBSztBQUFBLGtCQUVqRCxJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsZ0JBWGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdpSztBQUFBLGNBRWpLLHVCQUFDLFVBQUssV0FBVSw4Q0FDYnJMLDhCQUFvQitFLGVBQWVwQixVQUFVLENBQUMsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0N6QyxPQUFPeUMsVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCekMsaUJBQU95QyxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGlCQXZCNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsc0NBQXFDLG1DQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QixvREFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNNEQseUJBQXlCLElBQUk7QUFBQSxvQkFDNUMsV0FBVTtBQUFBLG9CQUNWO0FBQUEsNkNBQUMsdUJBQW9CLE1BQU0sTUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBOEI7QUFBQSxzQkFBRztBQUFBO0FBQUE7QUFBQSxrQkFKbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FFQ3hDLGVBQWVELGtCQUFrQjRELFNBQVMsSUFDekMsdUJBQUMsU0FBSSxXQUFVLGFBRWI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkVBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsVUFBUyw4QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDdEMsdUJBQUMsU0FBSSxXQUFVLGVBQWMsMEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEsa0JBQ3ZDLHVCQUFDLFNBQUksV0FBVSxVQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNCO0FBQUEscUJBSHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFFQzNELGVBQWVELGtCQUFrQlU7QUFBQUEsa0JBQUksQ0FBQ29HLE1BQU1sRyxVQUMzQztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFQyxXQUFVO0FBQUEsc0JBRVY7QUFBQSwrQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxhQUFZO0FBQUEsNEJBQ1osT0FBT2tHLEtBQUsvSTtBQUFBQSw0QkFDWixVQUFVLENBQUNaLE1BQ1QrRTtBQUFBQSw4QkFDRXRCO0FBQUFBLDhCQUNBO0FBQUEsOEJBQ0F6RCxFQUFFRSxPQUFPRDtBQUFBQSw4QkFDVDtBQUFBLDRCQUNGO0FBQUEsNEJBRUYsV0FBVyw2QkFBNkJyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsMEJBWDFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFXd0osS0FaMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFjQTtBQUFBLHdCQUdBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMLGFBQVk7QUFBQSw4QkFDWixPQUFPTyxLQUFLMUosU0FBUztBQUFBLDhCQUNyQixVQUFVLENBQUNELE1BQ1QrRTtBQUFBQSxnQ0FDRXRCO0FBQUFBLGdDQUNBO0FBQUEsZ0NBQ0F6RCxFQUFFRSxPQUFPRDtBQUFBQSxnQ0FDVDtBQUFBLDhCQUNGO0FBQUEsOEJBRUYsV0FBVyw2QkFBNkJyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsNEJBWjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFZd0o7QUFBQSwwQkFFdkpPLEtBQUsxSixRQUFRLEtBQ1osdUJBQUMsT0FBRSxXQUFVLDhEQUNWbEM7QUFBQUEsZ0RBQW9CNEwsS0FBSzFKLEtBQUs7QUFBQSw0QkFBRTtBQUFBLCtCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsNkJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBb0JBO0FBQUEsd0JBR0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMLFNBQVMsTUFDUHNGLDRCQUE0QjlCLE9BQU8sSUFBSTtBQUFBLDRCQUV6QyxXQUFVO0FBQUEsNEJBQ1YsT0FBTTtBQUFBLDRCQUNOLGlDQUFDLGtCQUFlLE1BQU0sTUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBeUI7QUFBQTtBQUFBLDBCQVAzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUUE7QUFBQTtBQUFBO0FBQUEsb0JBbkRLQTtBQUFBQSxvQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXFEQTtBQUFBLGdCQUNEO0FBQUEsbUJBL0RIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0VBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLE9BQUUsV0FBVSwwQkFBeUIsaUVBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBM0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkZBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBa0I7QUFBQTtBQUFBLGdCQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFlO0FBQUE7QUFBQSxvQkFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsQ0FBQ3pELE1BQU1BLEVBQUVFLE9BQU93SixLQUFLO0FBQUEsc0JBQzlCLE1BQUs7QUFBQSxzQkFDTCxPQUNFNUcsZUFBZWYsVUFBVUMsVUFBVSxJQUMvQixLQUNBYyxlQUFlZixVQUFVQztBQUFBQSxzQkFFL0IsVUFBVSxDQUFDaEMsTUFDVDhJO0FBQUFBLHdCQUNFOUksRUFBRUUsT0FBT1U7QUFBQUEsd0JBQ1RaLEVBQUVFLE9BQU9EO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0E7QUFBQSxzQkFDRjtBQUFBLHNCQUVGLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsb0JBbkJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBbUJpSztBQUFBLGtCQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTCw4QkFBb0IrRSxlQUFlZixVQUFVQyxTQUFTLENBQUMsS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThCQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBYTtBQUFBO0FBQUEsb0JBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUNoQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLHNCQUM5QixNQUFLO0FBQUEsc0JBQ0wsT0FDRTVHLGVBQWVmLFVBQVVFLFFBQVEsSUFDN0IsS0FDQWEsZUFBZWYsVUFBVUU7QUFBQUEsc0JBRS9CLFVBQVUsQ0FBQ2pDLE1BQ1Q4STtBQUFBQSx3QkFDRTlJLEVBQUVFLE9BQU9VO0FBQUFBLHdCQUNUWixFQUFFRSxPQUFPRDtBQUFBQSx3QkFDVDtBQUFBLHdCQUNBO0FBQUEsc0JBQ0Y7QUFBQSxzQkFFRixJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLG9CQW5CbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW1CaUs7QUFBQSxrQkFFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickwsOEJBQW9CK0UsZUFBZWYsVUFBVUUsT0FBTyxDQUFDLEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4QkE7QUFBQSxtQkE5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErREE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBMEI7QUFBQTtBQUFBLG9CQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxDQUFDakMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxzQkFDOUIsTUFBSztBQUFBLHNCQUNMLE9BQ0U1RyxlQUFlZixVQUFVRyxxQkFBcUIsSUFDMUMsS0FDQVksZUFBZWYsVUFBVUc7QUFBQUEsc0JBRS9CLFVBQVUsQ0FBQ2xDLE1BQ1Q4STtBQUFBQSx3QkFDRTlJLEVBQUVFLE9BQU9VO0FBQUFBLHdCQUNUWixFQUFFRSxPQUFPRDtBQUFBQSx3QkFDVDtBQUFBLHdCQUNBO0FBQUEsc0JBQ0Y7QUFBQSxzQkFFRixJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLG9CQW5CbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW1CaUs7QUFBQSxrQkFFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickw7QUFBQUEsb0JBQ0MrRSxlQUFlZixVQUFVRyxvQkFBb0I7QUFBQSxrQkFDL0MsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0NBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUEyQjtBQUFBO0FBQUEsb0JBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUNsQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLHNCQUM5QixNQUFLO0FBQUEsc0JBQ0wsT0FDRTVHLGVBQWVmLFVBQVVJLHNCQUFzQixJQUMzQyxLQUNBVyxlQUFlZixVQUFVSTtBQUFBQSxzQkFFL0IsVUFBVSxDQUFDbkMsTUFDVDhJO0FBQUFBLHdCQUNFOUksRUFBRUUsT0FBT1U7QUFBQUEsd0JBQ1RaLEVBQUVFLE9BQU9EO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0E7QUFBQSxzQkFDRjtBQUFBLHNCQUVGLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsb0JBbkJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBbUJpSztBQUFBLGtCQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTDtBQUFBQSxvQkFDQytFLGVBQWVmLFVBQVVJLHFCQUFxQjtBQUFBLGtCQUNoRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQ0E7QUFBQSxtQkFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBNEI7QUFBQTtBQUFBLG9CQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxDQUFDbkMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxzQkFDOUIsTUFBSztBQUFBLHNCQUNMLE9BQ0U1RyxlQUFlZixVQUFVSyx1QkFBdUIsSUFDNUMsS0FDQVUsZUFBZWYsVUFBVUs7QUFBQUEsc0JBRS9CLFVBQVUsQ0FBQ3BDLE1BQ1Q4STtBQUFBQSx3QkFDRTlJLEVBQUVFLE9BQU9VO0FBQUFBLHdCQUNUWixFQUFFRSxPQUFPRDtBQUFBQSx3QkFDVDtBQUFBLHdCQUNBO0FBQUEsc0JBQ0Y7QUFBQSxzQkFFRixJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLG9CQW5CbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW1CaUs7QUFBQSxrQkFFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickw7QUFBQUEsb0JBQ0MrRSxlQUFlZixVQUFVSyxzQkFBc0I7QUFBQSxrQkFDakQsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0NBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUEyQjtBQUFBO0FBQUEsb0JBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUNwQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLHNCQUM5QixNQUFLO0FBQUEsc0JBQ0wsT0FDRTVHLGVBQWVmLFVBQVVNLHNCQUFzQixJQUMzQyxLQUNBUyxlQUFlZixVQUFVTTtBQUFBQSxzQkFFL0IsVUFBVSxDQUFDckMsTUFDVDhJO0FBQUFBLHdCQUNFOUksRUFBRUUsT0FBT1U7QUFBQUEsd0JBQ1RaLEVBQUVFLE9BQU9EO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0E7QUFBQSxzQkFDRjtBQUFBLHNCQUVGLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsb0JBbkJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBbUJpSztBQUFBLGtCQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTDtBQUFBQSxvQkFDQytFLGVBQWVmLFVBQVVNLHFCQUFxQjtBQUFBLGtCQUNoRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQ0E7QUFBQSxtQkFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBMEI7QUFBQTtBQUFBLG9CQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxDQUFDckMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxzQkFDOUIsTUFBSztBQUFBLHNCQUNMLE9BQ0U1RyxlQUFlZixVQUFVTyxxQkFBcUIsSUFDMUMsS0FDQVEsZUFBZWYsVUFBVU87QUFBQUEsc0JBRS9CLFVBQVUsQ0FBQ3RDLE1BQ1Q4STtBQUFBQSx3QkFDRTlJLEVBQUVFLE9BQU9VO0FBQUFBLHdCQUNUWixFQUFFRSxPQUFPRDtBQUFBQSx3QkFDVDtBQUFBLHdCQUNBO0FBQUEsc0JBQ0Y7QUFBQSxzQkFFRixJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLG9CQW5CbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW1CaUs7QUFBQSxrQkFFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickw7QUFBQUEsb0JBQ0MrRSxlQUFlZixVQUFVTyxvQkFBb0I7QUFBQSxrQkFDL0MsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0NBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFvQjtBQUFBO0FBQUEsb0JBRjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUN0QyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLHNCQUM5QixNQUFLO0FBQUEsc0JBQ0wsT0FDRTVHLGVBQWVmLFVBQVVRLGVBQWUsSUFDcEMsS0FDQU8sZUFBZWYsVUFBVVE7QUFBQUEsc0JBRS9CLFVBQVUsQ0FBQ3ZDLE1BQ1Q4STtBQUFBQSx3QkFDRTlJLEVBQUVFLE9BQU9VO0FBQUFBLHdCQUNUWixFQUFFRSxPQUFPRDtBQUFBQSx3QkFDVDtBQUFBLHdCQUNBO0FBQUEsc0JBQ0Y7QUFBQSxzQkFFRixJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaLFdBQVcscUNBQXFDckMsVUFBVXdMLE1BQU07QUFBQTtBQUFBLG9CQW5CbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW1CaUs7QUFBQSxrQkFFakssdUJBQUMsVUFBSyxXQUFVLDhDQUNickw7QUFBQUEsb0JBQ0MrRSxlQUFlZixVQUFVUSxjQUFjO0FBQUEsa0JBQ3pDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLHFCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdDQTtBQUFBLG1CQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1FQTtBQUFBLGlCQWxSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1SQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQW9CO0FBQUE7QUFBQSxnQkFGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBb0I7QUFBQTtBQUFBLG9CQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxDQUFDdkMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxzQkFDOUIsTUFBSztBQUFBLHNCQUNMLE9BQ0U1RyxlQUFlTixZQUFZQyxlQUFlLElBQ3RDLEtBQ0FLLGVBQWVOLFlBQVlDO0FBQUFBLHNCQUVqQyxVQUFVLENBQUN6QyxNQUNUOEk7QUFBQUEsd0JBQ0U5SSxFQUFFRSxPQUFPVTtBQUFBQSx3QkFDVFosRUFBRUUsT0FBT0Q7QUFBQUEsd0JBQ1Q7QUFBQSx3QkFDQTtBQUFBLHNCQUNGO0FBQUEsc0JBRUYsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxvQkFuQmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFtQmlLO0FBQUEsa0JBRWpLLHVCQUFDLFVBQUssV0FBVSw4Q0FDYnJMO0FBQUFBLG9CQUNDK0UsZUFBZU4sWUFBWUMsY0FBYztBQUFBLGtCQUMzQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQ0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQWE7QUFBQTtBQUFBLG9CQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxDQUFDekMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxzQkFDOUIsTUFBSztBQUFBLHNCQUNMLE9BQ0U1RyxlQUFlTixZQUFZRSxRQUFRLElBQy9CLEtBQ0FJLGVBQWVOLFlBQVlFO0FBQUFBLHNCQUVqQyxVQUFVLENBQUMxQyxNQUNUOEk7QUFBQUEsd0JBQ0U5SSxFQUFFRSxPQUFPVTtBQUFBQSx3QkFDVFosRUFBRUUsT0FBT0Q7QUFBQUEsd0JBQ1Q7QUFBQSx3QkFDQTtBQUFBLHNCQUNGO0FBQUEsc0JBRUYsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxvQkFuQmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFtQmlLO0FBQUEsa0JBRWpLLHVCQUFDLFVBQUssV0FBVSw4Q0FDYnJMLDhCQUFvQitFLGVBQWVOLFlBQVlFLE9BQU8sQ0FBQyxLQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOEJBO0FBQUEsbUJBaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQWE7QUFBQTtBQUFBLG9CQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxDQUFDMUMsTUFBTUEsRUFBRUUsT0FBT3dKLEtBQUs7QUFBQSxzQkFDOUIsTUFBSztBQUFBLHNCQUNMLE9BQ0U1RyxlQUFlTixZQUFZRyxRQUFRLElBQy9CLEtBQ0FHLGVBQWVOLFlBQVlHO0FBQUFBLHNCQUVqQyxVQUFVLENBQUMzQyxNQUNUOEk7QUFBQUEsd0JBQ0U5SSxFQUFFRSxPQUFPVTtBQUFBQSx3QkFDVFosRUFBRUUsT0FBT0Q7QUFBQUEsd0JBQ1Q7QUFBQSx3QkFDQTtBQUFBLHNCQUNGO0FBQUEsc0JBRUYsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWixXQUFXLHFDQUFxQ3JDLFVBQVV3TCxNQUFNO0FBQUE7QUFBQSxvQkFuQmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFtQmlLO0FBQUEsa0JBRWpLLHVCQUFDLFVBQUssV0FBVSw4Q0FDYnJMLDhCQUFvQitFLGVBQWVOLFlBQVlHLE9BQU8sQ0FBQyxLQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOEJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUEwQjtBQUFBO0FBQUEsb0JBRnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLENBQUMzQyxNQUFNQSxFQUFFRSxPQUFPd0osS0FBSztBQUFBLHNCQUM5QixNQUFLO0FBQUEsc0JBQ0wsT0FDRTVHLGVBQWVOLFlBQVlJLHFCQUFxQixJQUM1QyxLQUNBRSxlQUFlTixZQUFZSTtBQUFBQSxzQkFFakMsVUFBVSxDQUFDNUMsTUFDVDhJO0FBQUFBLHdCQUNFOUksRUFBRUUsT0FBT1U7QUFBQUEsd0JBQ1RaLEVBQUVFLE9BQU9EO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0E7QUFBQSxzQkFDRjtBQUFBLHNCQUVGLElBQUc7QUFBQSxzQkFDSCxhQUFZO0FBQUEsc0JBQ1osV0FBVyxxQ0FBcUNyQyxVQUFVd0wsTUFBTTtBQUFBO0FBQUEsb0JBbkJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBbUJpSztBQUFBLGtCQUVqSyx1QkFBQyxVQUFLLFdBQVUsOENBQ2JyTDtBQUFBQSxvQkFDQytFLGVBQWVOLFlBQVlJLG9CQUFvQjtBQUFBLGtCQUNqRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQ0E7QUFBQSxtQkFoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpRUE7QUFBQSxpQkF6SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwSUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQzhGO0FBQUE7QUFBQSxjQUgxRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQW5pQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvaUNBO0FBQUEsYUF4aUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5aUNBO0FBQUE7QUFBQSxNQTVpQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNmlDQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVduRTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkkseUJBQWUsSUFBSTtBQUFBLFFBQ3JCO0FBQUEsUUFDQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsZUFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDbUIsTUFBTTtBQUNmQSxrQkFBRThILGVBQWU7QUFDakJpQixpQ0FBaUI7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1Y7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBdUI7QUFBQTtBQUFBLHdCQUNsQjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYmxLLHNCQUFZK0IsUUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDaEQsVUFBVXdMLE1BQU07QUFBQTtBQUFBLG9CQUxsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS2lLO0FBQUEscUJBaEJuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQzBGO0FBQUE7QUFBQSxrQkFIdEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUE7QUFBQTtBQUFBLFlBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQStCQTtBQUFBLGFBcENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQ0E7QUFBQTtBQUFBLE1BNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTZDQTtBQUFBLE9BeGxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeWxFQSxLQTFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJsRUE7QUFFSjtBQUFFaEwsR0F6eEZJRCxTQUFPO0FBQUE0TCxLQUFQNUw7QUEweEZOLGVBQWVBO0FBQVEsSUFBQTRMO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJJb01kTW9yZSIsIklucHV0IiwiU2VsZWN0IiwiRHJvcGRvd24iLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsImZpZWxkU2l6ZSIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJudW1iZXJUb0luZGlhbldvcmRzIiwiSGlPdXRsaW5lUGx1c0NpcmNsZSIsIkhpT3V0bGluZVRyYXNoIiwiQnJlYWRjcnVtYiIsIlBheXJvbGwiLCJfcyIsIlRhYmxlRW1wbG95ZWVzIiwic2V0VGFibGVFbXBsb3llZXMiLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50VXNlciIsInNldEN1cnJlbnRVc2VyIiwiY3VycmVudFVwZGF0ZVVzZXIiLCJzZXRDdXJyZW50VXBkYXRlVXNlciIsImVycm9ycyIsInNldEVycm9ycyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwic2VsZWN0ZWRNYW5hZ2VySWQiLCJzZXRTZWxlY3RlZE1hbmFnZXJJZCIsInNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkIiwic2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQiLCJtYW5hZ2VycyIsInNldE1hbmFnZXJzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJzZWxlY3RlZE1hbmFnZXJUaXRsZSIsInNldFNlbGVjdGVkTWFuYWdlclRpdGxlIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJuYW1lIiwiZW1haWwiLCJwaG9uZV9udW1iZXIiLCJhZGRyZXNzIiwicGluY29kZSIsImFkaGFhcl9ubyIsImRlc2lnbmF0aW9uX2lkIiwicGFuX25vIiwiYWdlbnRfdHlwZSIsImpvaW5pbmdfZGF0ZSIsInN0YXR1cyIsImRvYiIsImdlbmRlciIsImFsdGVybmF0ZV9udW1iZXIiLCJzYWxhcnkiLCJsZWF2aW5nX2RhdGUiLCJlbWVyZ2VuY3lfY29udGFjdF9wZXJzb24iLCJlbWVyZ2VuY3lfY29udGFjdF9udW1iZXIiLCJ0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzIiwiZWFybmluZ3MiLCJiYXNpYyIsImhyYSIsInRyYXZlbF9hbGxvd2FuY2UiLCJtZWRpY2FsX2FsbG93YW5jZSIsImJhc2tldF9vZl9iZW5pZml0cyIsInBlcmZvcm1hbmNlX2JvbnVzIiwib3RoZXJfYWxsb3dhbmNlcyIsImNvbnZleWFuY2UiLCJkZWR1Y3Rpb25zIiwiaW5jb21lX3RheCIsImVzaSIsImVwZiIsInByb2Zlc3Npb25hbF90YXgiLCJhZGRpdGlvbmFsX3NhbGFyeSIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJmZXRjaEVtcGxveWVlUHJvZmlsZSIsInJlc3BvbnNlIiwiZ2V0IiwiZW1wbG95ZWVEYXRhIiwiZGF0YSIsImVtcGxveWVlIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJpZCIsImVtcGxveWVlQ29kZSIsImRlc2lnbmF0aW9uIiwidGl0bGUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hNYW5hZ2VycyIsImhhbmRsZUFudERTZWxlY3RNYW5hZ2VyIiwibWFuYWdlcklkIiwic2VsZWN0ZWQiLCJmaW5kIiwibWdyIiwicHJldiIsIm1hbmFnZXJUaXRsZSIsImhhbmRsZUFkZGl0aW9uYWxTYWxhcnlDaGFuZ2UiLCJmaWVsZCIsInZhbCIsImlzVXBkYXRlIiwic2V0dGVyIiwidXBkYXRlZExpc3QiLCJOdW1iZXIiLCJhZGRBZGRpdGlvbmFsU2FsYXJ5RmllbGQiLCJyZW1vdmVBZGRpdGlvbmFsU2FsYXJ5RmllbGQiLCJmaWx0ZXIiLCJfIiwiaSIsImhhbmRsZUNoYW5nZSIsInByZXZEYXRhIiwiaGFuZGxlQW50RFNlbGVjdFJlcG9ydGluZ01hbmFnZXIiLCJyZXBvcnRpbmdJZCIsInJlcG9ydGluZ01hbmFnZXJJZCIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsInJlZ2V4IiwicGhvbmUiLCJhYWRoYWFyIiwicGFuIiwidHJpbSIsInRlc3QiLCJ0b1VwcGVyQ2FzZSIsImxlbmd0aCIsIk9iamVjdCIsImtleXMiLCJhZGRQaG9uZUZpZWxkIiwiZm9ybVN0YXRlIiwic2V0Rm9ybVN0YXRlIiwicGhvbmVzIiwibGFzdFBob25lIiwiYWxlcnQiLCJwcmV2U3RhdGUiLCJoYW5kbGVQaG9uZUNoYW5nZSIsInB1c2giLCJsYXN0SW5kZXgiLCJyZWR1Y2VSaWdodCIsImxhc3ROb25FbXB0eSIsInNsaWNlIiwicmVtb3ZlUGhvbmVGaWVsZCIsIkFycmF5IiwiaXNBcnJheSIsInVwZGF0ZWRQaG9uZXMiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWRhdGUiLCJzYW5pdGl6ZU51bWJlciIsImRhdGFUb1NlbmQiLCJyZXBvcnRpbmdfbWFuYWdlcl9pZCIsInBvc3QiLCJoZWFkZXJzIiwiZXJyTXNnIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInByZXZFcnJvcnMiLCJjb2x1bW5zIiwiaGVhZGVyIiwidXNlcklkIiwic3BsaXQiLCJ0b1N0cmluZyIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlVXNlciIsImRlbGV0ZSIsImhhbmRsZVVwZGF0ZSIsImlzVmFsaWQiLCJwdXQiLCJoZWlnaHQiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwic3R5cGUiLCJibHVyIiwiaXRlbSIsIm1hbmFnZXIiLCJEYXRlIiwidG9JU09TdHJpbmciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYXlyb2xsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IHsgSGlPdXRsaW5lUGx1c0NpcmNsZSwgSGlPdXRsaW5lVHJhc2ggfSBmcm9tIFwicmVhY3QtaWNvbnMvaGlcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5jb25zdCBQYXlyb2xsID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtUYWJsZUVtcGxveWVlcywgc2V0VGFibGVFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVVc2VyLCBzZXRDdXJyZW50VXBkYXRlVXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJJZCwgc2V0U2VsZWN0ZWRNYW5hZ2VySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkLCBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZF0gPVxyXG4gICAgdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21hbmFnZXJzLCBzZXRNYW5hZ2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJUaXRsZSwgc2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIG5hbWU6IFwiXCIsXHJcbiAgICBlbWFpbDogXCJcIixcclxuICAgIHBob25lX251bWJlcjogXCJcIixcclxuICAgIC8vIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgYWRkcmVzczogXCJcIixcclxuICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICBhZGhhYXJfbm86IFwiXCIsXHJcbiAgICBkZXNpZ25hdGlvbl9pZDogXCJcIixcclxuICAgIHBhbl9ubzogXCJcIixcclxuICAgIGFnZW50X3R5cGU6IFwiZW1wbG95ZWVcIixcclxuICAgIGpvaW5pbmdfZGF0ZTogXCJcIixcclxuICAgIHN0YXR1czogXCJcIixcclxuICAgIGRvYjogXCJcIixcclxuICAgIGdlbmRlcjogXCJcIixcclxuICAgIGFsdGVybmF0ZV9udW1iZXI6IFwiXCIsXHJcbiAgICBzYWxhcnk6IFwiXCIsXHJcbiAgICBsZWF2aW5nX2RhdGU6IFwiXCIsXHJcbiAgICBlbWVyZ2VuY3lfY29udGFjdF9wZXJzb246IFwiXCIsXHJcbiAgICBlbWVyZ2VuY3lfY29udGFjdF9udW1iZXI6IFtcIlwiXSxcclxuICAgIHRvdGFsX2FsbG9jYXRlZF9sZWF2ZXM6IFwiMlwiLFxyXG4gICAgZWFybmluZ3M6IHtcclxuICAgICAgYmFzaWM6IDAsXHJcbiAgICAgIGhyYTogMCxcclxuICAgICAgdHJhdmVsX2FsbG93YW5jZTogMCxcclxuICAgICAgbWVkaWNhbF9hbGxvd2FuY2U6IDAsXHJcbiAgICAgIGJhc2tldF9vZl9iZW5pZml0czogMCxcclxuICAgICAgcGVyZm9ybWFuY2VfYm9udXM6IDAsXHJcbiAgICAgIG90aGVyX2FsbG93YW5jZXM6IDAsXHJcbiAgICAgIGNvbnZleWFuY2U6IDAsXHJcbiAgICB9LFxyXG4gICAgZGVkdWN0aW9uczoge1xyXG4gICAgICBpbmNvbWVfdGF4OiAwLFxyXG4gICAgICBlc2k6IDAsXHJcbiAgICAgIGVwZjogMCxcclxuICAgICAgcHJvZmVzc2lvbmFsX3RheDogMCxcclxuICAgIH0sXHJcbiAgICBhZGRpdGlvbmFsX3NhbGFyeTogW10sXHJcbiAgfSk7XHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBuYW1lOiBcIlwiLFxyXG4gICAgZW1haWw6IFwiXCIsXHJcbiAgICBwaG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICAvLyBwYXNzd29yZDogXCJcIixcclxuICAgIGFkZHJlc3M6IFwiXCIsXHJcbiAgICBwaW5jb2RlOiBcIlwiLFxyXG4gICAgYWRoYWFyX25vOiBcIlwiLFxyXG4gICAgZGVzaWduYXRpb25faWQ6IFwiXCIsXHJcbiAgICBwYW5fbm86IFwiXCIsXHJcbiAgICBqb2luaW5nX2RhdGU6IFwiXCIsXHJcbiAgICBzdGF0dXM6IFwiXCIsXHJcbiAgICBkb2I6IFwiXCIsXHJcbiAgICBnZW5kZXI6IFwiXCIsXHJcbiAgICBhbHRlcm5hdGVfbnVtYmVyOiBcIlwiLFxyXG4gICAgc2FsYXJ5OiBcIlwiLFxyXG4gICAgbGVhdmluZ19kYXRlOiBcIlwiLFxyXG4gICAgZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uOiBcIlwiLFxyXG4gICAgZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyOiBbXCJcIl0sXHJcbiAgICB0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzOiBcIjJcIixcclxuICAgIGVhcm5pbmdzOiB7XHJcbiAgICAgIGJhc2ljOiAwLFxyXG4gICAgICBocmE6IDAsXHJcbiAgICAgIHRyYXZlbF9hbGxvd2FuY2U6IDAsXHJcbiAgICAgIG1lZGljYWxfYWxsb3dhbmNlOiAwLFxyXG4gICAgICBiYXNrZXRfb2ZfYmVuaWZpdHM6IDAsXHJcbiAgICAgIHBlcmZvcm1hbmNlX2JvbnVzOiAwLFxyXG4gICAgICBvdGhlcl9hbGxvd2FuY2VzOiAwLFxyXG4gICAgICBjb252ZXlhbmNlOiAwLFxyXG4gICAgfSxcclxuICAgIGRlZHVjdGlvbnM6IHtcclxuICAgICAgaW5jb21lX3RheDogMCxcclxuICAgICAgZXNpOiAwLFxyXG4gICAgICBlcGY6IDAsXHJcbiAgICAgIHByb2Zlc3Npb25hbF90YXg6IDAsXHJcbiAgICB9LFxyXG4gICAgYWRkaXRpb25hbF9zYWxhcnk6IFtdLFxyXG4gIH0pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlUHJvZmlsZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgIGNvbnN0IGVtcGxveWVlRGF0YSA9IHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlIHx8IFtdO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gZW1wbG95ZWVEYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIG5hbWU6IGdyb3VwPy5uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBlbXBsb3llZUNvZGU6IGdyb3VwPy5lbXBsb3llZUNvZGUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgLy8gcGFzc3dvcmQ6IGdyb3VwPy5wYXNzd29yZCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IGdyb3VwPy5kZXNpZ25hdGlvbl9pZD8udGl0bGUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3Blbihncm91cC5faWQpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIj5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVFbXBsb3llZXMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEVtcGxveWVlUHJvZmlsZSgpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTWFuYWdlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Rlc2lnbmF0aW9uL2dldC1kZXNpZ25hdGlvblwiKTtcclxuICAgICAgICBzZXRNYW5hZ2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hNYW5hZ2VycygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3RNYW5hZ2VyID0gKG1hbmFnZXJJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRNYW5hZ2VySWQobWFuYWdlcklkKTtcclxuICAgIGNvbnN0IHNlbGVjdGVkID0gbWFuYWdlcnMuZmluZCgobWdyKSA9PiBtZ3IuX2lkID09PSBtYW5hZ2VySWQpO1xyXG4gICAgY29uc3QgdGl0bGUgPSBzZWxlY3RlZD8udGl0bGUgfHwgXCJcIjtcclxuICAgIHNldFNlbGVjdGVkTWFuYWdlclRpdGxlKHRpdGxlKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBkZWR1Y3Rpb25zOiB7IC4uLnByZXYuZGVkdWN0aW9ucyB9LFxyXG4gICAgICBlYXJuaW5nczogeyAuLi5wcmV2LmVhcm5pbmdzIH0sXHJcbiAgICAgIG1hbmFnZXJJZCxcclxuICAgICAgbWFuYWdlclRpdGxlOiB0aXRsZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgbWFuYWdlcklkOiBcIlwiLFxyXG4gICAgICBtYW5hZ2VyVGl0bGU6IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBZGRpdGlvbmFsU2FsYXJ5Q2hhbmdlID0gKFxyXG4gICAgaW5kZXgsXHJcbiAgICBmaWVsZCxcclxuICAgIHZhbCxcclxuICAgIGlzVXBkYXRlID0gZmFsc2VcclxuICApID0+IHtcclxuICAgIGNvbnN0IHNldHRlciA9IGlzVXBkYXRlID8gc2V0VXBkYXRlRm9ybURhdGEgOiBzZXRGb3JtRGF0YTtcclxuICAgIHNldHRlcigocHJldikgPT4ge1xyXG4gICAgICBjb25zdCB1cGRhdGVkTGlzdCA9IFsuLi5wcmV2LmFkZGl0aW9uYWxfc2FsYXJ5XTtcclxuICAgICAgdXBkYXRlZExpc3RbaW5kZXhdID0ge1xyXG4gICAgICAgIC4uLnVwZGF0ZWRMaXN0W2luZGV4XSxcclxuICAgICAgICBbZmllbGRdOiBmaWVsZCA9PT0gXCJ2YWx1ZVwiID8gKHZhbCA9PT0gXCJcIiA/IDAgOiBOdW1iZXIodmFsKSkgOiB2YWwsXHJcbiAgICAgIH07XHJcbiAgICAgIHJldHVybiB7IC4uLnByZXYsIGFkZGl0aW9uYWxfc2FsYXJ5OiB1cGRhdGVkTGlzdCB9O1xyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCBhZGRBZGRpdGlvbmFsU2FsYXJ5RmllbGQgPSAoaXNVcGRhdGUgPSBmYWxzZSkgPT4ge1xyXG4gICAgY29uc3Qgc2V0dGVyID0gaXNVcGRhdGUgPyBzZXRVcGRhdGVGb3JtRGF0YSA6IHNldEZvcm1EYXRhO1xyXG4gICAgc2V0dGVyKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBhZGRpdGlvbmFsX3NhbGFyeTogWy4uLnByZXYuYWRkaXRpb25hbF9zYWxhcnksIHsgbmFtZTogXCJcIiwgdmFsdWU6IDAgfV0sXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuICBjb25zdCByZW1vdmVBZGRpdGlvbmFsU2FsYXJ5RmllbGQgPSAoaW5kZXgsIGlzVXBkYXRlID0gZmFsc2UpID0+IHtcclxuICAgIGNvbnN0IHNldHRlciA9IGlzVXBkYXRlID8gc2V0VXBkYXRlRm9ybURhdGEgOiBzZXRGb3JtRGF0YTtcclxuICAgIHNldHRlcigocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgYWRkaXRpb25hbF9zYWxhcnk6IHByZXYuYWRkaXRpb25hbF9zYWxhcnkuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCksXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKG5hbWUsIHZhbHVlLCBlYXJuaW5ncyA9IGZhbHNlLCBkZWR1Y3Rpb25zID0gZmFsc2UpID0+IHtcclxuICAgIGlmIChlYXJuaW5ncykge1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgZWFybmluZ3M6IHsgLi4ucHJldkRhdGEuZWFybmluZ3MsIFtuYW1lXTogdmFsdWUgfSxcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIGlmIChkZWR1Y3Rpb25zKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBkZWR1Y3Rpb25zOiB7IC4uLnByZXZEYXRhLmRlZHVjdGlvbnMsIFtuYW1lXTogdmFsdWUgfSxcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKG5hbWUgPT09IFwic2FsYXJ5XCIpIHtcclxuICAgICAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIFtuYW1lXTogXCJcIixcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3RSZXBvcnRpbmdNYW5hZ2VyID0gKHJlcG9ydGluZ0lkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChyZXBvcnRpbmdJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcmVwb3J0aW5nTWFuYWdlcklkOiByZXBvcnRpbmdJZCxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcmVwb3J0aW5nTWFuYWdlcklkOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkRW1wbG95ZWVcIiA/IGZvcm1EYXRhIDogdXBkYXRlRm9ybURhdGE7XHJcbiAgICBjb25zdCByZWdleCA9IHtcclxuICAgICAgZW1haWw6IC9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLFxyXG4gICAgICBwaG9uZTogL15bNi05XVxcZHs5fSQvLFxyXG4gICAgICAvLyBwYXNzd29yZDpcclxuICAgICAgLy8gICAvXig/PS4qW2Etel0pKD89LipbQS1aXSkoPz0uKlxcZCkoPz0uKltAJCElKj8mXSlbQS1aYS16XFxkQCQhJSo/Jl17NSx9JC8sXHJcbiAgICAgIHBpbmNvZGU6IC9eXFxkezZ9JC8sXHJcbiAgICAgIGFhZGhhYXI6IC9eXFxkezEyfSQvLFxyXG4gICAgICBwYW46IC9eW0EtWl17NX1bMC05XXs0fVtBLVpdezF9JC8sXHJcbiAgICAgIGFsdGVybmF0ZV9udW1iZXI6IC9eWzYtOV1cXGR7OX0kLyxcclxuICAgIH07XHJcbiAgICBpZiAoIWRhdGEubmFtZSB8fCAhZGF0YS5uYW1lLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMubmFtZSA9IFwiRnVsbCBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEuZW1haWwpIHtcclxuICAgICAgbmV3RXJyb3JzLmVtYWlsID0gXCJFbWFpbCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXguZW1haWwudGVzdChkYXRhLmVtYWlsKSkge1xyXG4gICAgICBuZXdFcnJvcnMuZW1haWwgPSBcIkludmFsaWQgZW1haWwgZm9ybWF0XCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEucGhvbmVfbnVtYmVyKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5waG9uZV9udW1iZXIgPSBcIlBob25lIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGhvbmUudGVzdChkYXRhLnBob25lX251bWJlcikpIHtcclxuICAgICAgbmV3RXJyb3JzLnBob25lX251bWJlciA9IFwiSW52YWxpZCAgcGhvbmUgbnVtYmVyXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEuYWx0ZXJuYXRlX251bWJlcikge1xyXG4gICAgICBuZXdFcnJvcnMuYWx0ZXJuYXRlX251bWJlciA9IFwiQWx0ZXJuYXRlIFBob25lIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXguYWx0ZXJuYXRlX251bWJlci50ZXN0KGRhdGEuYWx0ZXJuYXRlX251bWJlcikpIHtcclxuICAgICAgbmV3RXJyb3JzLmFsdGVybmF0ZV9udW1iZXIgPSBcIkludmFsaWQgQWx0ZXJuYXRlICBwaG9uZSBudW1iZXJcIjtcclxuICAgIH1cclxuICAgIC8vIGlmICghZGF0YS5wYXNzd29yZCkge1xyXG4gICAgLy8gICBuZXdFcnJvcnMucGFzc3dvcmQgPSBcIlBhc3N3b3JkIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAvLyB9IGVsc2UgaWYgKCFyZWdleC5wYXNzd29yZC50ZXN0KGRhdGEucGFzc3dvcmQpKSB7XHJcbiAgICAvLyAgIG5ld0Vycm9ycy5wYXNzd29yZCA9XHJcbiAgICAvLyAgICAgXCJQYXNzd29yZCBtdXN0IGNvbnRhaW4gYXQgbGVhc3QgNSBjaGFyYWN0ZXJzLCBvbmUgdXBwZXJjYXNlLCBvbmUgbG93ZXJjYXNlLCBvbmUgbnVtYmVyLCBhbmQgb25lIHNwZWNpYWwgY2hhcmFjdGVyXCI7XHJcbiAgICAvLyB9XHJcbiAgICBpZiAoIWRhdGEuc3RhdHVzKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5zdGF0dXMgPSBcIlN0YXR1cyBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLmRvYikge1xyXG4gICAgICBuZXdFcnJvcnMuZG9iID0gXCJEYXRlIG9mIEJpcnRoIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEuam9pbmluZ19kYXRlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5qb2luaW5nX2RhdGUgPSBcIkpvaW5pbmcgRGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLmdlbmRlcikge1xyXG4gICAgICBuZXdFcnJvcnMuZ2VuZGVyID0gXCJQbGVhc2UgU2VsZWN0IEdlbmRlclwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLnNhbGFyeSkge1xyXG4gICAgICBuZXdFcnJvcnMuc2FsYXJ5ID0gXCJTYWxhcnkgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5waW5jb2RlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5waW5jb2RlID0gXCJQaW5jb2RlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5waW5jb2RlLnRlc3QoZGF0YS5waW5jb2RlKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGluY29kZSA9IFwiSW52YWxpZCBwaW5jb2RlICg2IGRpZ2l0cyByZXF1aXJlZClcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5hZGhhYXJfbm8pIHtcclxuICAgICAgbmV3RXJyb3JzLmFkaGFhcl9ubyA9IFwiQWFkaGFhciBudW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIXJlZ2V4LmFhZGhhYXIudGVzdChkYXRhLmFkaGFhcl9ubykpIHtcclxuICAgICAgbmV3RXJyb3JzLmFkaGFhcl9ubyA9IFwiSW52YWxpZCBBYWRoYWFyIG51bWJlciAoMTIgZGlnaXRzIHJlcXVpcmVkKVwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5wYW5fbm8pIHtcclxuICAgICAgbmV3RXJyb3JzLnBhbl9ubyA9IFwiUEFOIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGFuLnRlc3QoZGF0YS5wYW5fbm8udG9VcHBlckNhc2UoKSkpIHtcclxuICAgICAgbmV3RXJyb3JzLnBhbl9ubyA9IFwiSW52YWxpZCBQQU4gZm9ybWF0IChlLmcuLCBBQkNERTEyMzRGKVwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLmFkZHJlc3MgfHwgIWRhdGEuYWRkcmVzcy50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmFkZHJlc3MgPSBcIkFkZHJlc3MgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoZGF0YS5hZGRyZXNzLnRyaW0oKS5sZW5ndGggPCAxMCkge1xyXG4gICAgICBuZXdFcnJvcnMuYWRkcmVzcyA9IFwiQWRkcmVzcyBzaG91bGQgYmUgYXQgbGVhc3QgMTAgY2hhcmFjdGVyc1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLmVtZXJnZW5jeV9jb250YWN0X3BlcnNvbikge1xyXG4gICAgICBuZXdFcnJvcnMuZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uID0gXCJDb250YWN0IFBlcnNvbiBOYW1lIGlzIFJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEudG90YWxfYWxsb2NhdGVkX2xlYXZlcykge1xyXG4gICAgICBuZXdFcnJvcnMudG90YWxfYWxsb2NhdGVkX2xlYXZlcyA9XHJcbiAgICAgICAgXCJQbGVhc2UgUHJvdmlkZSBUb3RhbCBBbGxvY2F0ZWQgTGVhdmVzXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIXNlbGVjdGVkTWFuYWdlcklkKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5kZXNpZ25hdGlvbl9pZCA9IFwiUGxlYXNlIEVudGVyIERlc2lnbmF0aW9uXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuICBjb25zdCBhZGRQaG9uZUZpZWxkID0gKGZvcm1TdGF0ZSwgc2V0Rm9ybVN0YXRlKSA9PiB7XHJcbiAgICBjb25zdCBwaG9uZXMgPSBbLi4uKGZvcm1TdGF0ZS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXIgfHwgW10pXTtcclxuICAgIGNvbnN0IGxhc3RQaG9uZSA9IHBob25lc1twaG9uZXMubGVuZ3RoIC0gMV07XHJcbiAgICBpZiAocGhvbmVzLmxlbmd0aCA+IDAgJiYgKCFsYXN0UGhvbmUgfHwgbGFzdFBob25lLnRyaW0oKSA9PT0gXCJcIikpIHtcclxuICAgICAgYWxlcnQoXHJcbiAgICAgICAgXCJQbGVhc2UgZmlsbCBpbiB0aGUgbGFzdCBlbWVyZ2VuY3kgY29udGFjdCBudW1iZXIgYmVmb3JlIGFkZGluZyBhIG5ldyBvbmUuXCJcclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgc2V0Rm9ybVN0YXRlKChwcmV2U3RhdGUpID0+ICh7XHJcbiAgICAgIC4uLnByZXZTdGF0ZSxcclxuICAgICAgZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyOiBbLi4ucGhvbmVzLCBcIlwiXSxcclxuICAgIH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVBob25lQ2hhbmdlID0gKGZvcm1TdGF0ZSwgc2V0Rm9ybVN0YXRlLCBpbmRleCwgZSkgPT4ge1xyXG4gICAgY29uc3QgdmFsdWUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIGxldCBwaG9uZXMgPVxyXG4gICAgICBmb3JtU3RhdGUuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyICYmXHJcbiAgICAgIGZvcm1TdGF0ZS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXIubGVuZ3RoID4gMFxyXG4gICAgICAgID8gWy4uLmZvcm1TdGF0ZS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXJdXHJcbiAgICAgICAgOiBbXCJcIl07XHJcbiAgICB3aGlsZSAocGhvbmVzLmxlbmd0aCA8PSBpbmRleCkge1xyXG4gICAgICBwaG9uZXMucHVzaChcIlwiKTtcclxuICAgIH1cclxuICAgIHBob25lc1tpbmRleF0gPSB2YWx1ZTtcclxuICAgIGNvbnN0IGxhc3RJbmRleCA9IHBob25lcy5yZWR1Y2VSaWdodCgobGFzdE5vbkVtcHR5LCBwaG9uZSwgaSkgPT4ge1xyXG4gICAgICByZXR1cm4gbGFzdE5vbkVtcHR5ICE9PSAtMSA/IGxhc3ROb25FbXB0eSA6IHBob25lLnRyaW0oKSAhPT0gXCJcIiA/IGkgOiAtMTtcclxuICAgIH0sIC0xKTtcclxuICAgIHBob25lcyA9IGxhc3RJbmRleCA9PT0gLTEgPyBbXCJcIl0gOiBwaG9uZXMuc2xpY2UoMCwgbGFzdEluZGV4ICsgMSk7XHJcbiAgICBzZXRGb3JtU3RhdGUoe1xyXG4gICAgICAuLi5mb3JtU3RhdGUsXHJcbiAgICAgIGVtZXJnZW5jeV9jb250YWN0X251bWJlcjogcGhvbmVzLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCByZW1vdmVQaG9uZUZpZWxkID0gKGZvcm1TdGF0ZSwgc2V0Rm9ybVN0YXRlLCBpbmRleCkgPT4ge1xyXG4gICAgY29uc3QgcGhvbmVzID0gQXJyYXkuaXNBcnJheShmb3JtU3RhdGUuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyKVxyXG4gICAgICA/IFsuLi5mb3JtU3RhdGUuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyXVxyXG4gICAgICA6IFtdO1xyXG4gICAgY29uc3QgdXBkYXRlZFBob25lcyA9IHBob25lcy5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KTtcclxuICAgIHNldEZvcm1TdGF0ZSh7XHJcbiAgICAgIC4uLmZvcm1TdGF0ZSxcclxuICAgICAgZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyOiB1cGRhdGVkUGhvbmVzLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZGF0ZSA9IHZhbGlkYXRlRm9ybShcImFkZEVtcGxveWVlXCIpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc2FuaXRpemVOdW1iZXIgPSAodmFsKSA9PlxyXG4gICAgICAgIHZhbCA9PT0gXCJcIiB8fCB2YWwgPT0gbnVsbCA/IDAgOiBOdW1iZXIodmFsKTtcclxuICAgICAgaWYgKGlzVmFsaWRhdGUpIHtcclxuICAgICAgICBjb25zdCBkYXRhVG9TZW5kID0ge1xyXG4gICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICBzYWxhcnk6IHNhbml0aXplTnVtYmVyKGZvcm1EYXRhLnNhbGFyeSksXHJcbiAgICAgICAgICBlYXJuaW5nczoge1xyXG4gICAgICAgICAgICBiYXNpYzogc2FuaXRpemVOdW1iZXIoZm9ybURhdGEuZWFybmluZ3MuYmFzaWMpLFxyXG4gICAgICAgICAgICBocmE6IHNhbml0aXplTnVtYmVyKGZvcm1EYXRhLmVhcm5pbmdzLmhyYSksXHJcbiAgICAgICAgICAgIHRyYXZlbF9hbGxvd2FuY2U6IHNhbml0aXplTnVtYmVyKFxyXG4gICAgICAgICAgICAgIGZvcm1EYXRhLmVhcm5pbmdzLnRyYXZlbF9hbGxvd2FuY2VcclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgbWVkaWNhbF9hbGxvd2FuY2U6IHNhbml0aXplTnVtYmVyKFxyXG4gICAgICAgICAgICAgIGZvcm1EYXRhLmVhcm5pbmdzLm1lZGljYWxfYWxsb3dhbmNlXHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIGJhc2tldF9vZl9iZW5pZml0czogc2FuaXRpemVOdW1iZXIoXHJcbiAgICAgICAgICAgICAgZm9ybURhdGEuZWFybmluZ3MuYmFza2V0X29mX2JlbmlmaXRzXHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIHBlcmZvcm1hbmNlX2JvbnVzOiBzYW5pdGl6ZU51bWJlcihcclxuICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncy5wZXJmb3JtYW5jZV9ib251c1xyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgICBvdGhlcl9hbGxvd2FuY2VzOiBzYW5pdGl6ZU51bWJlcihcclxuICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncy5vdGhlcl9hbGxvd2FuY2VzXHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIGNvbnZleWFuY2U6IHNhbml0aXplTnVtYmVyKGZvcm1EYXRhLmVhcm5pbmdzLmNvbnZleWFuY2UpLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGRlZHVjdGlvbnM6IHtcclxuICAgICAgICAgICAgaW5jb21lX3RheDogc2FuaXRpemVOdW1iZXIoZm9ybURhdGEuZGVkdWN0aW9ucy5pbmNvbWVfdGF4KSxcclxuICAgICAgICAgICAgZXNpOiBzYW5pdGl6ZU51bWJlcihmb3JtRGF0YS5kZWR1Y3Rpb25zLmVzaSksXHJcbiAgICAgICAgICAgIGVwZjogc2FuaXRpemVOdW1iZXIoZm9ybURhdGEuZGVkdWN0aW9ucy5lcGYpLFxyXG4gICAgICAgICAgICBwcm9mZXNzaW9uYWxfdGF4OiBzYW5pdGl6ZU51bWJlcihcclxuICAgICAgICAgICAgICBmb3JtRGF0YS5kZWR1Y3Rpb25zLnByb2Zlc3Npb25hbF90YXhcclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbl9pZDogc2VsZWN0ZWRNYW5hZ2VySWQsXHJcbiAgICAgICAgICByZXBvcnRpbmdfbWFuYWdlcl9pZDogc2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL2VtcGxveWVlL3BheXJvbGxcIiwgZGF0YVRvU2VuZCwge1xyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAvLyBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgLy8gICBuYW1lOiBcIlwiLFxyXG4gICAgICAgIC8vICAgZW1haWw6IFwiXCIsXHJcbiAgICAgICAgLy8gICBwaG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgLy8gICBwYXNzd29yZDogXCJcIixcclxuICAgICAgICAvLyAgIGFkZHJlc3M6IFwiXCIsXHJcbiAgICAgICAgLy8gICBwaW5jb2RlOiBcIlwiLFxyXG4gICAgICAgIC8vICAgYWRoYWFyX25vOiBcIlwiLFxyXG4gICAgICAgIC8vICAgZGVzaWduYXRpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgLy8gICBwYW5fbm86IFwiXCIsXHJcbiAgICAgICAgLy8gICBqb2luaW5nX2RhdGU6IFwiXCIsXHJcbiAgICAgICAgLy8gICBzdGF0dXM6IFwiXCIsXHJcbiAgICAgICAgLy8gICBkb2I6IFwiXCIsXHJcbiAgICAgICAgLy8gICBnZW5kZXI6IFwiXCIsXHJcbiAgICAgICAgLy8gICBhbHRlcm5hdGVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgIC8vICAgc2FsYXJ5OiBcIlwiLFxyXG4gICAgICAgIC8vICAgbGVhdmluZ19kYXRlOiBcIlwiLFxyXG4gICAgICAgIC8vICAgZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uOiBcIlwiLFxyXG4gICAgICAgIC8vICAgZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyOiBbXCJcIl0sXHJcbiAgICAgICAgLy8gICB0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzOiBcIjJcIixcclxuICAgICAgICAvLyAgIGVhcm5pbmdzOiB7XHJcbiAgICAgICAgLy8gICAgIGJhc2ljOiAwLFxyXG4gICAgICAgIC8vICAgICBocmE6IDAsXHJcbiAgICAgICAgLy8gICAgIHRyYXZlbF9hbGxvd2FuY2U6IDAsXHJcbiAgICAgICAgLy8gICAgIG1lZGljYWxfYWxsb3dhbmNlOiAwLFxyXG4gICAgICAgIC8vICAgICBiYXNrZXRfb2ZfYmVuaWZpdHM6IDAsXHJcbiAgICAgICAgLy8gICAgIHBlcmZvcm1hbmNlX2JvbnVzOiAwLFxyXG4gICAgICAgIC8vICAgICBvdGhlcl9hbGxvd2FuY2VzOiAwLFxyXG4gICAgICAgIC8vICAgICBjb252ZXlhbmNlOiAwLFxyXG4gICAgICAgIC8vICAgfSxcclxuICAgICAgICAvLyAgIGRlZHVjdGlvbnM6IHtcclxuICAgICAgICAvLyAgICAgaW5jb21lX3RheDogMCxcclxuICAgICAgICAvLyAgICAgZXNpOiAwLFxyXG4gICAgICAgIC8vICAgICBlcGY6IDAsXHJcbiAgICAgICAgLy8gICAgIHByb2Zlc3Npb25hbF90YXg6IDAsXHJcbiAgICAgICAgLy8gICB9LFxyXG4gICAgICAgIC8vIH0pO1xyXG4gICAgICAgIHNldFNlbGVjdGVkTWFuYWdlcklkKFwiXCIpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkKFwiXCIpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJFbXBsb3llZSBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIEVtcGxveWVlOlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgY29uc3QgZXJyTXNnID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgaWYgKGVyck1zZy5pbmNsdWRlcyhcInBob25lIG51bWJlclwiKSkge1xyXG4gICAgICAgICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IFwiUGhvbmUgbnVtYmVyIGFscmVhZHkgZXhpc3RzXCIsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZUNvZGVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElEXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImRlc2lnbmF0aW9uXCIsIGhlYWRlcjogXCJEZXNpZ25hdGlvblwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJwYXNzd29yZFwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgUGFzc3dvcmRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2FnZW50L2dldC1hZGRpdGlvbmFsLWVtcGxveWVlLWluZm8tYnktaWQvJHt1c2VySWR9YFxyXG4gICAgICApO1xyXG4gICAgICBzZXRDdXJyZW50VXNlcihyZXNwb25zZS5kYXRhPy5lbXBsb3llZSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hZ2VudC9nZXQtZW1wbG95ZWUtYnktaWQvJHt1c2VySWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVVc2VyKHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIG5hbWU6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8ubmFtZSxcclxuICAgICAgICBlbWFpbDogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5lbWFpbCxcclxuICAgICAgICBwaG9uZV9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgIC8vIHBhc3N3b3JkOiByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LnBhc3N3b3JkLFxyXG4gICAgICAgIHBpbmNvZGU6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8ucGluY29kZSxcclxuICAgICAgICBhZGhhYXJfbm86IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uYWRoYWFyX25vLFxyXG4gICAgICAgIHBhbl9ubzogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5wYW5fbm8sXHJcbiAgICAgICAgYWRkcmVzczogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5hZGRyZXNzLFxyXG4gICAgICAgIGpvaW5pbmdfZGF0ZTogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5qb2luaW5nX2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICBzdGF0dXM6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uc3RhdHVzLFxyXG4gICAgICAgIGRvYjogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5kb2I/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICBnZW5kZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uZ2VuZGVyLFxyXG4gICAgICAgIGFsdGVybmF0ZV9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uYWx0ZXJuYXRlX251bWJlcixcclxuICAgICAgICBzYWxhcnk6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uc2FsYXJ5LFxyXG4gICAgICAgIGxlYXZpbmdfZGF0ZTogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5sZWF2aW5nX2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICBlbWVyZ2VuY3lfY29udGFjdF9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZVxyXG4gICAgICAgICAgPy5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXIgfHwgW1wiXCJdLFxyXG4gICAgICAgIGVtZXJnZW5jeV9jb250YWN0X3BlcnNvbjpcclxuICAgICAgICAgIHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uLFxyXG4gICAgICAgIHRvdGFsX2FsbG9jYXRlZF9sZWF2ZXM6XHJcbiAgICAgICAgICByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LnRvdGFsX2FsbG9jYXRlZF9sZWF2ZXM/LnRvU3RyaW5nKCkgfHwgXCIyXCIsXHJcbiAgICAgICAgZWFybmluZ3M6IHtcclxuICAgICAgICAgIGJhc2ljOiByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LmVhcm5pbmdzPy5iYXNpYyB8fCAwLFxyXG4gICAgICAgICAgaHJhOiByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LmVhcm5pbmdzPy5ocmEgfHwgMCxcclxuICAgICAgICAgIHRyYXZlbF9hbGxvd2FuY2U6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uZWFybmluZ3M/LnRyYXZlbF9hbGxvd2FuY2UgfHwgMCxcclxuICAgICAgICAgIG1lZGljYWxfYWxsb3dhbmNlOlxyXG4gICAgICAgICAgICByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LmVhcm5pbmdzPy5tZWRpY2FsX2FsbG93YW5jZSB8fCAwLFxyXG4gICAgICAgICAgYmFza2V0X29mX2JlbmlmaXRzOlxyXG4gICAgICAgICAgICByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LmVhcm5pbmdzPy5iYXNrZXRfb2ZfYmVuaWZpdHMgfHwgMCxcclxuICAgICAgICAgIHBlcmZvcm1hbmNlX2JvbnVzOlxyXG4gICAgICAgICAgICByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LmVhcm5pbmdzPy5wZXJmb3JtYW5jZV9ib251cyB8fCAwLFxyXG4gICAgICAgICAgb3RoZXJfYWxsb3dhbmNlczpcclxuICAgICAgICAgICAgcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5lYXJuaW5ncz8ub3RoZXJfYWxsb3dhbmNlcyB8fCAwLFxyXG4gICAgICAgICAgY29udmV5YW5jZTogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5lYXJuaW5ncz8uY29udmV5YW5jZSB8fCAwLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIGRlZHVjdGlvbnM6IHtcclxuICAgICAgICAgIGluY29tZV90YXg6IHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZT8uZGVkdWN0aW9ucz8uaW5jb21lX3RheCB8fCAwLFxyXG4gICAgICAgICAgZXNpOiByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LmRlZHVjdGlvbnM/LmVzaSB8fCAwLFxyXG4gICAgICAgICAgZXBmOiByZXNwb25zZT8uZGF0YT8uZW1wbG95ZWU/LmRlZHVjdGlvbnM/LmVwZiB8fCAwLFxyXG4gICAgICAgICAgcHJvZmVzc2lvbmFsX3RheDpcclxuICAgICAgICAgICAgcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5kZWR1Y3Rpb25zPy5wcm9mZXNzaW9uYWxfdGF4IHx8IDAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZGRpdGlvbmFsX3NhbGFyeTogcmVzcG9uc2U/LmRhdGE/LmVtcGxveWVlPy5hZGRpdGlvbmFsX3NhbGFyeSB8fCBbXSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNlbGVjdGVkTWFuYWdlcklkKHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlPy5kZXNpZ25hdGlvbl9pZD8uX2lkIHx8IDApO1xyXG4gICAgICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChcclxuICAgICAgICByZXNwb25zZS5kYXRhPy5lbXBsb3llZT8ucmVwb3J0aW5nX21hbmFnZXJfaWQgfHwgMFxyXG4gICAgICApO1xyXG4gICAgICBzZXRTZWxlY3RlZE1hbmFnZXJUaXRsZShyZXNwb25zZS5kYXRhPy5lbXBsb3llZT8uZGVzaWduYXRpb25faWQ/LnRpdGxlKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXI6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChcclxuICAgIG5hbWUsXHJcbiAgICB2YWx1ZSxcclxuICAgIGVhcm5pbmdzID0gZmFsc2UsXHJcbiAgICBkZWR1Y3Rpb25zID0gZmFsc2VcclxuICApID0+IHtcclxuICAgIGlmIChlYXJuaW5ncykge1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgZWFybmluZ3M6IHsgLi4ucHJldkRhdGEuZWFybmluZ3MsIFtuYW1lXTogdmFsdWUgfSxcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIGlmIChkZWR1Y3Rpb25zKSB7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBkZWR1Y3Rpb25zOiB7IC4uLnByZXZEYXRhLmRlZHVjdGlvbnMsIFtuYW1lXTogdmFsdWUgfSxcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVEZWxldGVVc2VyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRVc2VyKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShcclxuICAgICAgICAgIGAvYWdlbnQvZGVsZXRlLWFkZGl0aW9uYWwtZW1wbG95ZWUtaW5mby1ieS1pZC8ke2N1cnJlbnRVc2VyLl9pZH1gXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBZ2VudCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIHVzZXI6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YVRvU2VuZCA9IHtcclxuICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgZGVkdWN0aW9uczoge1xyXG4gICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5kZWR1Y3Rpb25zLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGVhcm5pbmdzOiB7XHJcbiAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmVhcm5pbmdzLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGRlc2lnbmF0aW9uX2lkOiBzZWxlY3RlZE1hbmFnZXJJZCxcclxuICAgICAgICAgIHJlcG9ydGluZ19tYW5hZ2VyX2lkOiBzZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChcclxuICAgICAgICAgIGAvYWdlbnQvdXBkYXRlLWFkZGl0aW9uYWwtZW1wbG95ZWUtaW5mby8ke2N1cnJlbnRVcGRhdGVVc2VyLl9pZH1gLFxyXG4gICAgICAgICAgZGF0YVRvU2VuZFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChcIlwiKTtcclxuICAgICAgICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChcIlwiKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRW1wbG95ZWUgRGV0YWlscyBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBhZ2VudDpcIiwgZXJyb3IpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8QnJlYWRjcnVtYi8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlBheXJvbGw8L2gxPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICsgQWRkIEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtUYWJsZUVtcGxveWVlcz8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUVtcGxveWVlcywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJFbXBsb3llZSBQYXlyb2xsXCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BFbXBsb3llZXMgUGF5cm9sbC5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlRW1wbG95ZWVzPy5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJFbXBsb3llZSBEYXRhXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBBZGQgRW1wbG95ZWVcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm5hbWVcIj5cclxuICAgICAgICAgICAgICAgICAgRnVsbCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBGdWxsIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtYWlsIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtYWlsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5lbWFpbH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaG9uZV9udW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwicGhvbmVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZV9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBhc3N3b3JkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGFzc3dvcmQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaW5jb2RlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGluY29kZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFkaGFhcl9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGhhYXJfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImFkaGFhcl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGhhYXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGFuX25vXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGFuIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhbl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwicGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhbiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFuX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5wYW5fbm99PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJhZGRyZXNzXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZHJlc3MgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5hZGRyZXNzfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkZXNpZ25hdGlvbl9pZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERlc2lnbmF0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJkZXNpZ25hdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRlc2lnbmF0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNYW5hZ2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVBbnREU2VsZWN0TWFuYWdlcn1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBEZXNpZ25hdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH0+XHJcbiAgICAgICAgICAgICAgICAgICAge21hbmFnZXJzLm1hcCgobWdyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e21nci5faWR9IHZhbHVlPXttZ3IuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge21nci50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic3RhdHVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhdHVzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5zdGF0dXMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUNoYW5nZShcInN0YXR1c1wiLCB2YWx1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJBY3RpdmVcIiwgXCJJbmFjdGl2ZVwiLCBcIlRlcm1pbmF0ZWRcIl0ubWFwKChzdHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtzdHlwZX0gdmFsdWU9e3N0eXBlLnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXR1cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuc3RhdHVzfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiam9pbmluZ19kYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgSm9pbmluZyBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiam9pbmluZ19kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuam9pbmluZ19kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJqb2luaW5nX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1wbG95ZWUgSm9pbmluZyBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5qb2luaW5nX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuam9pbmluZ19kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImxlYXZpbmdfZGF0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIExlYXZpbmcgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYXZpbmdfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmxlYXZpbmdfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibGVhdmluZ19kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIExlYXZpbmcgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRvYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERhdGUgb2YgQmlydGggPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkb2JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kb2J9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRvYlwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbXBsb3llZSBEYXRlIG9mIEJpcnRoXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5kb2IgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmRvYn08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJnZW5kZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBHZW5kZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmdlbmRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQ2hhbmdlKFwiZ2VuZGVyXCIsIHZhbHVlKX0+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcIk1hbGVcIiwgXCJGZW1hbGVcIiwgXCJPdGhlcnNcIl0ubWFwKChnZW5kZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z2VuZGVyfSB2YWx1ZT17Z2VuZGVyLnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z2VuZGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5nZW5kZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmdlbmRlcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFsdGVybmF0ZV9udW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBBbHRlcm5hdGUgUGhvbmUgTnVtYmVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhbHRlcm5hdGVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYWx0ZXJuYXRlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYWx0ZXJuYXRlX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBbHRlcm5hdGUgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFsdGVybmF0ZV9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWx0ZXJuYXRlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgQWxsb2NhdGVkIExlYXZlc3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0b3RhbF9hbGxvY2F0ZWRfbGVhdmVzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudG90YWxfYWxsb2NhdGVkX2xlYXZlc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidG90YWxfYWxsb2NhdGVkX2xlYXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0b3RhbCBhbGxvY2F0ZWQgbGVhdmVzXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRvdGFsX2FsbG9jYXRlZF9sZWF2ZXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudG90YWxfYWxsb2NhdGVkX2xlYXZlc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtZXJnZW5jeV9jb250YWN0X3BlcnNvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtZXJnZW5jeSBDb250YWN0IFBlcnNvblxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJlbWVyZ2VuY3lfY29udGFjdF9wZXJzb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1lcmdlbmN5IENvbnRhY3QgUGVyc29uIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtZXJnZW5jeV9jb250YWN0X3BlcnNvbn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWVyZ2VuY3lfY29udGFjdF9udW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbWVyZ2VuY3kgUGhvbmUgTnVtYmVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG1iLTIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtZXJnZW5jeV9jb250YWN0X251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyPy5bMF0gfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlUGhvbmVDaGFuZ2UoZm9ybURhdGEsIHNldEZvcm1EYXRhLCAwLCBlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJlbWVyZ2VuY3lfY29udGFjdF9udW1iZXJfMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIERlZmF1bHQgRW1lcmdlbmN5IFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICA/LnNsaWNlKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgocGhvbmUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG1iLTIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17YGVtZXJnZW5jeV9waG9uZV8ke2luZGV4ICsgMX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQaG9uZUNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2BlbWVyZ2VuY3lfY29udGFjdF9udW1iZXJfJHtpbmRleCArIDF9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkZGl0aW9uYWwgRW1lcmdlbmN5IFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpbmRleCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlUGhvbmVGaWVsZChmb3JtRGF0YSwgc2V0Rm9ybURhdGEsIGluZGV4ICsgMSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZW1vdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWRkUGhvbmVGaWVsZChmb3JtRGF0YSwgc2V0Rm9ybURhdGEpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgdGV4dC12aW9sZXQtNjAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICArIEFkZCBBbm90aGVyXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInNhbGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEZpeGVkIFNhbGFyeSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5zYWxhcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInNhbGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBZb3VyIFNhbGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuc2FsYXJ5IHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc2FsYXJ5ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5zYWxhcnl9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgbXQtOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIFNhbGFyaWVzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZGQgY29sbGVjdGlvbiBzYWxhcnkgb3IgbW9yZS5cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkZEFkZGl0aW9uYWxTYWxhcnlGaWVsZChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSBiZy12aW9sZXQtNTAgdGV4dC12aW9sZXQtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIGhvdmVyOmJnLXZpb2xldC0xMDAgdHJhbnNpdGlvbi1jb2xvcnMgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEhpT3V0bGluZVBsdXNDaXJjbGUgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgQWRkIENvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hZGRpdGlvbmFsX3NhbGFyeS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBUYWJsZS1saWtlIGhlYWRlcnMgZm9yIGJldHRlciBhbGlnbm1lbnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB4LTEgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5Db21wb25lbnQgTmFtZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWwtNFwiPkFtb3VudCAo4oK5KTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hZGRpdGlvbmFsX3NhbGFyeS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cgaXRlbXMtc3RhcnQgc3BhY2UteC00IGFuaW1hdGUtZmFkZUluXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDb21wb25lbnQgTmFtZSBJbnB1dCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBDb2xsZWN0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFkZGl0aW9uYWxTYWxhcnlDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJuYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgYm9yZGVyLXNsYXRlLTIwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHJvdW5kZWQteGwgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6Ym9yZGVyLXZpb2xldC00MDAgc2hhZG93LXNtIHctZnVsbCB0cmFuc2l0aW9uLWFsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQW1vdW50IElucHV0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0udmFsdWUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQWRkaXRpb25hbFNhbGFyeUNoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgYm9yZGVyLXNsYXRlLTIwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHJvdW5kZWQteGwgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6Ym9yZGVyLXZpb2xldC00MDAgc2hhZG93LXNtIHctZnVsbCB0cmFuc2l0aW9uLWFsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS52YWx1ZSA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tZWRpdW0gdGV4dC12aW9sZXQtNTAwIG10LTEuNSBweC0xIGl0YWxpY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhpdGVtLnZhbHVlKX0gT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIERlbGV0ZSBBY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZW1vdmVBZGRpdGlvbmFsU2FsYXJ5RmllbGQoaW5kZXgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJlZC02MDAgaG92ZXI6YmctcmVkLTUwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZW1vdmUgY29tcG9uZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEhpT3V0bGluZVRyYXNoIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktNiBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vIGFkZGl0aW9uYWwgc2FsYXJ5IGNvbXBvbmVudHMgYWRkZWQuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItNCB0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlYXJuaW5nc1wiPlxyXG4gICAgICAgICAgICAgICAgICBFYXJuaW5nc1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJiYXNpY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgQmFzaWMgU2FsYXJ5XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiYXNpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmVhcm5pbmdzPy5iYXNpYyA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZm9ybURhdGEuZWFybmluZ3M/LmJhc2ljXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSwgdHJ1ZSwgZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImJhc2ljXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRml4ZWQgRW1wbG95ZWUgQmFzaWMgU2FsYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjUgYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuZWFybmluZ3M/LmJhc2ljIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJocmFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIEhvdXNlIFJlbnQgQWxsb3dhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJocmFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncz8uaHJhID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmb3JtRGF0YS5lYXJuaW5ncz8uaHJhXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSwgdHJ1ZSwgZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImhyYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIEhvdXNlIFJlbnQgQWxsb3dhbmNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5lYXJuaW5ncz8uaHJhIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInRyYXZlbF9hbGxvd2FuY2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIFRyYXZlbCBBbGxvd2FuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYXZlbF9hbGxvd2FuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncz8udHJhdmVsX2FsbG93YW5jZSA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZm9ybURhdGEuZWFybmluZ3M/LnRyYXZlbF9hbGxvd2FuY2VcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlLCB0cnVlLCBmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidHJhdmVsX2FsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIEVtcGxveWVlIFRyYXZlbCBBbGxvd2FuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncz8udHJhdmVsX2FsbG93YW5jZSB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJtZWRpY2FsX2FsbG93YW5jZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgTWVkaWNhbCBBbGxvd2FuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1lZGljYWxfYWxsb3dhbmNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZWFybmluZ3M/Lm1lZGljYWxfYWxsb3dhbmNlID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmb3JtRGF0YS5lYXJuaW5ncz8ubWVkaWNhbF9hbGxvd2FuY2VcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlLCB0cnVlLCBmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibWVkaWNhbF9hbGxvd2FuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBNZWRpY2FsIEFsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmVhcm5pbmdzPy5tZWRpY2FsX2FsbG93YW5jZSB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImJhc2tldF9vZl9iZW5pZml0c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgQmFza2V0IG9mIEJlbmlmaXRzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiYXNrZXRfb2ZfYmVuaWZpdHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncz8uYmFza2V0X29mX2JlbmlmaXRzID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmb3JtRGF0YS5lYXJuaW5ncz8uYmFza2V0X29mX2JlbmlmaXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSwgdHJ1ZSwgZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImJhc2tldF9vZl9iZW5pZml0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIEVtcGxveWVlIEJhc2tldCBvZiBCZW5pZml0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmVhcm5pbmdzPy5iYXNrZXRfb2ZfYmVuaWZpdHMgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGVyZm9ybWFuY2VfYm9udXNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIFBlcmZvcm1hbmNlIEJvbnVzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwZXJmb3JtYW5jZV9ib251c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmVhcm5pbmdzPy5wZXJmb3JtYW5jZV9ib251cyA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZm9ybURhdGEuZWFybmluZ3M/LnBlcmZvcm1hbmNlX2JvbnVzXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSwgdHJ1ZSwgZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBlcmZvcm1hbmNlX2JvbnVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRml4ZWQgUGVyZm9ybWFuY2UgQm9udXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncz8ucGVyZm9ybWFuY2VfYm9udXMgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJvdGhlcl9hbGxvd2FuY2VzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGaXhlZCBPdGhlciBBbGxvd2FuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm90aGVyX2FsbG93YW5jZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncz8ub3RoZXJfYWxsb3dhbmNlcyA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZm9ybURhdGEuZWFybmluZ3M/Lm90aGVyX2FsbG93YW5jZXNcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlLCB0cnVlLCBmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwib3RoZXJfYWxsb3dhbmNlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIE90aGVyIEFsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmVhcm5pbmdzPy5vdGhlcl9hbGxvd2FuY2VzIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvbnZleWFuY2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIENvbnZleWFuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvbnZleWFuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5lYXJuaW5ncz8uY29udmV5YW5jZSA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZm9ybURhdGEuZWFybmluZ3M/LmNvbnZleWFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlLCB0cnVlLCBmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29udmV5YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIENvbnZleWFuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLmVhcm5pbmdzPy5jb252ZXlhbmNlIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi00IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRlZHVjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgRGVkdWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImluY29tZV90YXhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIEluY29tZSBUYXhcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImluY29tZV90YXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5kZWR1Y3Rpb25zPy5pbmNvbWVfdGF4ID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmb3JtRGF0YS5kZWR1Y3Rpb25zPy5pbmNvbWVfdGF4XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSwgZmFsc2UsIHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImluY29tZV90YXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBFbXBsb3llZSBJbmNvbWUgVGF4XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZGVkdWN0aW9ucz8uaW5jb21lX3RheCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlc2lcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIEVtcGxveWVlcycgU3RhdGUgSW5zdXJhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlc2lcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5kZWR1Y3Rpb25zPy5lc2kgPT09IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IGZvcm1EYXRhLmRlZHVjdGlvbnM/LmVzaVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUsIGZhbHNlLCB0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJlc2lcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBFbXBsb3llZXMnIFN0YXRlIEluc3VyYW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuZGVkdWN0aW9ucz8uZXNpIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVwZlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgRW1wbG95ZWVzJyBQcm92aWRlbnQgRnVuZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiBlLnRhcmdldC5ibHVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZXBmXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZGVkdWN0aW9ucz8uZXBmID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmb3JtRGF0YS5kZWR1Y3Rpb25zPy5lcGZcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlLCBmYWxzZSwgdHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZXBmXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRml4ZWQgRW1wbG95ZWVzJyBQcm92aWRlbnQgRnVuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGEuZGVkdWN0aW9ucz8uZXBmIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwcm9mZXNzaW9uYWxfdGF4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGaXhlZCBQcm9mZXNzaW9uYWwgVGF4XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwcm9mZXNzaW9uYWxfdGF4XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZGVkdWN0aW9ucz8ucHJvZmVzc2lvbmFsX3RheCA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZm9ybURhdGEuZGVkdWN0aW9ucz8ucHJvZmVzc2lvbmFsX3RheFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUsIGZhbHNlLCB0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwcm9mZXNzaW9uYWxfdGF4XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRml4ZWQgRW1wbG95ZWVzJyBQcm9mZXNzaW9uYWwgVGF4XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZGVkdWN0aW9ucz8ucHJvZmVzc2lvbmFsX3RheCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDBcclxuICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyIGJvcmRlci0yIGJvcmRlci1ibGFja1wiPlxyXG4gICAgICAgICAgICAgICAgICBTYXZlIEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgVXBkYXRlIEVtcGxveWVlXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfbmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICBGdWxsIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBGdWxsIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfZW1haWxcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbWFpbCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJbnB1dENoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ1cGRhdGVfZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmVtYWlsfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9waG9uZV9udW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX3Bob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfcGFzc3dvcmRcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXNzd29yZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9wYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX3BpbmNvZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICBQaW5jb2RlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9waW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2FkaGFhcl9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRoYWFyX25vXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9hZGhhYXJfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWRoYWFyIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGhhYXJfbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9wYW5fbm9cIj5cclxuICAgICAgICAgICAgICAgICAgICBQYW4gTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhbl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJbnB1dENoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ1cGRhdGVfcGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhbiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFuX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5wYW5fbm99PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfYWRkcmVzc1wiPlxyXG4gICAgICAgICAgICAgICAgICBBZGRyZXNzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmFkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVJbnB1dENoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmFkZHJlc3N9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9kZXNpZ25hdGlvbl9pZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERlc2lnbmF0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX2Rlc2lnbmF0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVzaWduYXRpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZE1hbmFnZXJJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUFudERTZWxlY3RNYW5hZ2VyfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IERlc2lnbmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfT5cclxuICAgICAgICAgICAgICAgICAgICB7bWFuYWdlcnMubWFwKChtYW5hZ2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e21hbmFnZXIuX2lkfSB2YWx1ZT17bWFuYWdlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bWFuYWdlci50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX3N0YXR1c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXR1cyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBTdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uc3RhdHVzIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcInN0YXR1c1wiLCB2YWx1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJBY3RpdmVcIiwgXCJJbmFjdGl2ZVwiLCBcIlRlcm1pbmF0ZWRcIl0ubWFwKChzdGF0dXMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3RhdHVzfSB2YWx1ZT17c3RhdHVzLnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGF0dXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnN0YXR1c308L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9qb2luaW5nX2RhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICBKb2luaW5nIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJqb2luaW5nX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5qb2luaW5nX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX2pvaW5pbmdfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbXBsb3llZSBKb2luaW5nIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmpvaW5pbmdfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5qb2luaW5nX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2xlYXZpbmdfZGF0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIExlYXZpbmcgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImxlYXZpbmdfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LmxlYXZpbmdfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHVwZGF0ZUZvcm1EYXRhPy5sZWF2aW5nX2RhdGUgfHwgXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJbnB1dENoYW5nZShlLnRhcmdldC5uYW1lLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ1cGRhdGVfbGVhdmluZ19kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIExlYXZpbmcgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9kb2JcIj5cclxuICAgICAgICAgICAgICAgICAgICBEYXRlIG9mIEJpcnRoIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZG9iXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YT8uZG9iXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUodXBkYXRlRm9ybURhdGE/LmRvYiB8fCBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9kb2JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1wbG95ZWUgRGF0ZSBvZiBCaXJ0aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZG9iICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5kb2J9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2dlbmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEdlbmRlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJnZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZ2VuZGVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVJbnB1dENoYW5nZShcImdlbmRlclwiLCB2YWx1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJNYWxlXCIsIFwiRmVtYWxlXCIsIFwiT3RoZXJzXCJdLm1hcCgoZ2VuZGVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dlbmRlcn0gdmFsdWU9e2dlbmRlci50b0xvd2VyQ2FzZSgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dlbmRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ2VuZGVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5nZW5kZXJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfYWx0ZXJuYXRlX251bWJlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEFsdGVybmF0ZSBQaG9uZSBOdW1iZXJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFsdGVybmF0ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5hbHRlcm5hdGVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9hbHRlcm5hdGVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFsdGVybmF0ZSBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFsdGVybmF0ZV9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWx0ZXJuYXRlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfdG90YWxfYWxsb2NhdGVkX2xlYXZlc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvdGFsIE5vLiBvZiBMZWF2ZXMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwidG90YWxfYWxsb2NhdGVkX2xlYXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnRvdGFsX2FsbG9jYXRlZF9sZWF2ZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX3RvdGFsX2FsbG9jYXRlZF9sZWF2ZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdG90YWwgbGVhdmVzXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRvdGFsX2FsbG9jYXRlZF9sZWF2ZXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudG90YWxfYWxsb2NhdGVkX2xlYXZlc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9lbWVyZ2VuY3lfY29udGFjdF9wZXJzb25cIj5cclxuICAgICAgICAgICAgICAgICAgICBFbWVyZ2VuY3kgQ29udGFjdCBQZXJzb257XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWVyZ2VuY3lfY29udGFjdF9wZXJzb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKGUudGFyZ2V0Lm5hbWUsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9lbWVyZ2VuY3lfY29udGFjdF9wZXJzb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1lcmdlbmN5IENvbnRhY3QgUGVyc29uIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1lcmdlbmN5X2NvbnRhY3RfcGVyc29uICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtZXJnZW5jeV9jb250YWN0X3BlcnNvbn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfZW1lcmdlbmN5X2NvbnRhY3RfbnVtYmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1lcmdlbmN5IFBob25lIE51bWJlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0yIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWVyZ2VuY3lfY29udGFjdF9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmVtZXJnZW5jeV9jb250YWN0X251bWJlcj8uWzBdIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVBob25lQ2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9lbWVyZ2VuY3lfY29udGFjdF9udW1iZXJfMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIERlZmF1bHQgRW1lcmdlbmN5IFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5lbWVyZ2VuY3lfY29udGFjdF9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICA/LnNsaWNlKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgocGhvbmUsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXggKyAxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0yIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2BlbWVyZ2VuY3lfcGhvbmVfJHtpbmRleCArIDF9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlUGhvbmVDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtgdXBkYXRlX2VtZXJnZW5jeV9jb250YWN0X251bWJlcl8ke2luZGV4ICsgMX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWRkaXRpb25hbCBFbWVyZ2VuY3kgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW1vdmVQaG9uZUZpZWxkKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4ICsgMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGFkZFBob25lRmllbGQodXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHRleHQtdmlvbGV0LTYwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgKyBBZGQgQW5vdGhlclxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX3NhbGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEZpeGVkIFNhbGFyeSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5zYWxhcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoZS50YXJnZXQubmFtZSwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX3NhbGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBTYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHVwZGF0ZUZvcm1EYXRhLnNhbGFyeSB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnNhbGFyeSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuc2FsYXJ5fTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsvKiBBZGRpdGlvbmFsIFNhbGFyeSBTZWN0aW9uIGZvciBVcGRhdGUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgbXQtOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIFNhbGFyaWVzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBVcGRhdGUgQ29sbGVjdGlvbiBTYWxhcmllcyBhbmQgbW9yZS5cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFkZEFkZGl0aW9uYWxTYWxhcnlGaWVsZCh0cnVlKX0gLy8gJ3RydWUnIGZvciBVcGRhdGUgbG9naWNcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IGJnLXZpb2xldC01MCB0ZXh0LXZpb2xldC03MDAgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctdmlvbGV0LTEwMCB0cmFuc2l0aW9uLWNvbG9ycyBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SGlPdXRsaW5lUGx1c0NpcmNsZSBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICAgICAgICBBZGQgQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFkZGl0aW9uYWxfc2FsYXJ5Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIENvbHVtbiBIZWFkZXJzICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBweC0xIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+Q29tcG9uZW50IE5hbWU8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1sLTRcIj5BbW91bnQgKOKCuSk8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWRkaXRpb25hbF9zYWxhcnkubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNwYWNlLXgtNCBhbmltYXRlLWZhZGVJblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQ29tcG9uZW50IE5hbWUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImVnOiBDb2xsZWN0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFkZGl0aW9uYWxTYWxhcnlDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJuYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSBib3JkZXItc2xhdGUtMjAwICR7ZmllbGRTaXplLmhlaWdodH0gcm91bmRlZC14bCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjpib3JkZXItdmlvbGV0LTQwMCBzaGFkb3ctc20gdy1mdWxsIHRyYW5zaXRpb24tYWxsYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBbW91bnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS52YWx1ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBZGRpdGlvbmFsU2FsYXJ5Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLXdoaXRlIGJvcmRlci1zbGF0ZS0yMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLXhsIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIGhvdmVyOmJvcmRlci12aW9sZXQtNDAwIHNoYWRvdy1zbSB3LWZ1bGwgdHJhbnNpdGlvbi1hbGxgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udmFsdWUgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbWVkaXVtIHRleHQtdmlvbGV0LTUwMCBtdC0xLjUgcHgtMSBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoaXRlbS52YWx1ZSl9IE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZW1vdmUgQnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92ZUFkZGl0aW9uYWxTYWxhcnlGaWVsZChpbmRleCwgdHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9IC8vICd0cnVlJyBmb3IgVXBkYXRlIGxvZ2ljXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcmVkLTYwMCBob3ZlcjpiZy1yZWQtNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBtdC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlbW92ZSBjb21wb25lbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SGlPdXRsaW5lVHJhc2ggc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS02IGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTm8gYWRkaXRpb25hbCBjb21wb25lbnRzIGZvdW5kIGZvciB0aGlzIGVtcGxveWVlLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItNCB0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfZWFybmluZ3NcIj5cclxuICAgICAgICAgICAgICAgICAgRWFybmluZ3NcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2Jhc2ljXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGaXhlZCBCYXNpYyBTYWxhcnlcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImJhc2ljXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/LmJhc2ljID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uYmFzaWNcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX2Jhc2ljXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1wbG95ZWUgRml4ZWQgQmFzaWMgU2FsYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uYmFzaWMgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9ocmFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIEhvdXNlIFJlbnQgQWxsb3dhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJocmFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uaHJhID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uaHJhXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9ocmFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBIb3VzZSBSZW50IEFsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModXBkYXRlRm9ybURhdGEuZWFybmluZ3M/LmhyYSB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfdHJhdmVsX2FsbG93YW5jZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgVHJhdmVsIEFsbG93YW5jZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiBlLnRhcmdldC5ibHVyKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHJhdmVsX2FsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmVhcm5pbmdzPy50cmF2ZWxfYWxsb3dhbmNlID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8udHJhdmVsX2FsbG93YW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJbnB1dENoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmFsc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ1cGRhdGVfdHJhdmVsX2FsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIEVtcGxveWVlIFRyYXZlbCBBbGxvd2FuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8udHJhdmVsX2FsbG93YW5jZSB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfbWVkaWNhbF9hbGxvd2FuY2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIE1lZGljYWwgQWxsb3dhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJtZWRpY2FsX2FsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmVhcm5pbmdzPy5tZWRpY2FsX2FsbG93YW5jZSA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/Lm1lZGljYWxfYWxsb3dhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9tZWRpY2FsX2FsbG93YW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIE1lZGljYWwgQWxsb3dhbmNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/Lm1lZGljYWxfYWxsb3dhbmNlIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2Jhc2tldF9vZl9iZW5pZml0c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgQmFza2V0IG9mIEJlbmlmaXRzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiYXNrZXRfb2ZfYmVuaWZpdHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uYmFza2V0X29mX2JlbmlmaXRzID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uYmFza2V0X29mX2JlbmlmaXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9iYXNrZXRfb2ZfYmVuaWZpdHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBFbXBsb3llZSBCYXNrZXQgb2YgQmVuaWZpdHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uYmFza2V0X29mX2JlbmlmaXRzIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9wZXJmb3JtYW5jZV9ib251c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgUGVyZm9ybWFuY2UgQm9udXNcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBlcmZvcm1hbmNlX2JvbnVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/LnBlcmZvcm1hbmNlX2JvbnVzID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8ucGVyZm9ybWFuY2VfYm9udXNcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX3BlcmZvcm1hbmNlX2JvbnVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRml4ZWQgUGVyZm9ybWFuY2UgQm9udXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbWVkaXVtIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8ucGVyZm9ybWFuY2VfYm9udXMgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfb3RoZXJfYWxsb3dhbmNlc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgT3RoZXIgQWxsb3dhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJvdGhlcl9hbGxvd2FuY2VzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/Lm90aGVyX2FsbG93YW5jZXMgPT09IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVwZGF0ZUZvcm1EYXRhLmVhcm5pbmdzPy5vdGhlcl9hbGxvd2FuY2VzXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9vdGhlcl9hbGxvd2FuY2VzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRml4ZWQgT3RoZXIgQWxsb3dhbmNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/Lm90aGVyX2FsbG93YW5jZXMgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2NvbnZleWFuY2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIENvbnZleWFuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvbnZleWFuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5lYXJuaW5ncz8uY29udmV5YW5jZSA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/LmNvbnZleWFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidXBkYXRlX2NvbnZleWFuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBDb252ZXlhbmNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZWFybmluZ3M/LmNvbnZleWFuY2UgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItNCB0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGRhdGVfZGVkdWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgICAgICBEZWR1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2luY29tZV90YXhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIEluY29tZSBUYXhcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImluY29tZV90YXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5kZWR1Y3Rpb25zPy5pbmNvbWVfdGF4ID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVGb3JtRGF0YS5kZWR1Y3Rpb25zPy5pbmNvbWVfdGF4XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9pbmNvbWVfdGF4XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRml4ZWQgRW1wbG95ZWUgSW5jb21lIFRheFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmRlZHVjdGlvbnM/LmluY29tZV90YXggfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXBkYXRlX2VzaVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQgRW1wbG95ZWVzJyBTdGF0ZSBJbnN1cmFuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVzaVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmRlZHVjdGlvbnM/LmVzaSA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogdXBkYXRlRm9ybURhdGEuZGVkdWN0aW9ucz8uZXNpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9lc2lcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBFbXBsb3llZXMnIFN0YXRlIEluc3VyYW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModXBkYXRlRm9ybURhdGEuZGVkdWN0aW9ucz8uZXNpIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9lcGZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpeGVkIEVtcGxveWVlcycgUHJvdmlkZW50IEZ1bmRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4gZS50YXJnZXQuYmx1cigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVwZlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmRlZHVjdGlvbnM/LmVwZiA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogdXBkYXRlRm9ybURhdGEuZGVkdWN0aW9ucz8uZXBmXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUlucHV0Q2hhbmdlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZV9lcGZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBGaXhlZCBFbXBsb3llZXMnIFByb3ZpZGVudCBGdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW1lZGl1bSBmb250LW1vbm8gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh1cGRhdGVGb3JtRGF0YS5kZWR1Y3Rpb25zPy5lcGYgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVwZGF0ZV9wcm9mZXNzaW9uYWxfdGF4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGaXhlZCBQcm9mZXNzaW9uYWwgVGF4XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25XaGVlbD17KGUpID0+IGUudGFyZ2V0LmJsdXIoKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwcm9mZXNzaW9uYWxfdGF4XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZGVkdWN0aW9ucz8ucHJvZmVzc2lvbmFsX3RheCA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogdXBkYXRlRm9ybURhdGEuZGVkdWN0aW9ucz8ucHJvZmVzc2lvbmFsX3RheFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVJbnB1dENoYW5nZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRydWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ1cGRhdGVfcHJvZmVzc2lvbmFsX3RheFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZpeGVkIEVtcGxveWVlcycgUHJvZmVzc2lvbmFsIFRheFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tZWRpdW0gZm9udC1tb25vIHRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmRlZHVjdGlvbnM/LnByb2Zlc3Npb25hbF90YXggfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsRGVsZXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50VXNlcihudWxsKTtcclxuICAgICAgICAgIH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIERlbGV0ZSBFbXBsb3llZVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICB7Y3VycmVudFVzZXIgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVVc2VyKCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRlbGV0ZV9lbXBsb3llZV9uYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRlbGV0ZV9lbXBsb3llZV9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBlbXBsb3llZSBGdWxsIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMFxyXG4gICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgUGF5cm9sbDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BheXJvbGwuanN4In0=