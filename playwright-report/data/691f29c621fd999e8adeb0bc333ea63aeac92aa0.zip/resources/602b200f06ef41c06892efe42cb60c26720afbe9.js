import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/BidRequestReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import {
  Form,
  Input,
  DatePicker,
  TimePicker,
  Button,
  Select,
  Popconfirm,
  Spin,
  message,
  Modal
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Tag, Tooltip, Empty, Modal as AntModal, Tabs, Space } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { FaGavel } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { IoMdRefresh } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import {
  FilterOutlined,
  EditOutlined,
  ShareAltOutlined,
  PrinterOutlined,
  DeleteOutlined,
  SearchOutlined,
  ClockCircleOutlined,
  CheckCircleOutlined,
  CloseOutlined,
  StopOutlined,
  TrophyOutlined,
  WhatsAppOutlined,
  ExclamationCircleOutlined,
  SaveOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import __vite__cjsImport13_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport13_dayjs.__esModule ? __vite__cjsImport13_dayjs.default : __vite__cjsImport13_dayjs;
import * as XLSX from "/node_modules/.vite/deps/xlsx.js?v=819e0a34";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import "/node_modules/.vite/deps/jspdf-autotable.js?v=819e0a34";
const { TabPane } = Tabs;
const { Option } = Select;
const SelectionCheckbox = ({
  itemKey,
  userName,
  userPhone,
  activeUserData,
  setActiveUserData
}) => {
  const isChecked = !!activeUserData?.[itemKey]?.info?.status;
  return /* @__PURE__ */ jsxDEV(
    "input",
    {
      type: "checkbox",
      checked: isChecked,
      onChange: (e) => {
        setActiveUserData((prev) => ({
          ...prev,
          [itemKey]: {
            info: {
              status: e.target.checked,
              userName,
              userPhone
            }
          }
        }));
      },
      className: "w-4 h-4 cursor-pointer accent-blue-600"
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
      lineNumber: 56,
      columnNumber: 5
    },
    this
  );
};
_c = SelectionCheckbox;
const BidRequestReport = () => {
  _s();
  const [allBidRequests, setAllBidRequests] = useState([]);
  const [bidRequests, setBidRequests] = useState([]);
  const [rawBidRequestsData, setRawBidRequestsData] = useState([]);
  const [groups, setGroups] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [openActionId, setOpenActionId] = useState(null);
  const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editForm] = Form.useForm();
  const [editGroups, setEditGroups] = useState([]);
  const [selectedEditGroupIndex, setSelectedEditGroupIndex] = useState(0);
  const [editingId, setEditingId] = useState(null);
  const [customerBalance, setCustomerBalance] = useState(null);
  const [loadingBalance, setLoadingBalance] = useState(false);
  const [editLoading, setEditLoading] = useState(false);
  const [users, setUsers] = useState([]);
  const [activeUserData, setActiveUserData] = useState({});
  const [selectAll, setSelectAll] = useState(false);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [bulkLoading, setBulkLoading] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const [overview, setOverview] = useState({
    totalRequests: 0,
    totalPaidAmount: 0,
    pendingRequests: 0,
    acceptRequests: 0,
    rejectRequests: 0,
    nextAuctionRequests: 0,
    prizedRequests: 0
  });
  const [filters, setFilters] = useState({
    groupId: "",
    userId: "",
    status: "",
    paymentStatus: "",
    startDate: "",
    endDate: "",
    viewType: "all"
  });
  const [tempGroupId, setTempGroupId] = useState("");
  const [tempStatus, setTempStatus] = useState("");
  const [tempPaymentStatus, setTempPaymentStatus] = useState("");
  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [showModalView, setShowModalView] = useState(false);
  const [currentBidRequest, setCurrentBidRequest] = useState(null);
  const [groupStats, setGroupStats] = useState([]);
  const [activeTab, setActiveTab] = useState("list");
  const selectedCount = useMemo(() => {
    return bidRequests.filter((item) => activeUserData[item.key]?.info?.status).length;
  }, [bidRequests, activeUserData]);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "bid_request_code", header: "Bid Request Code" },
    { key: "request_date", header: "Request Date" },
    { key: "auction_time", header: "Request Time" },
    { key: "user_name", header: "Subscriber Name" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket_number", header: "Ticket" },
    { key: "auction_date", header: "Auction Date" },
    { key: "amount_paid", header: "Amount Paid" },
    // { key: "instance_balance", header: "Instance Balance (At Request)" },
    { key: "balance", header: "Current Balance" },
    { key: "source", header: "Source" },
    { key: "checkBox", header: "Select" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action", width: 180 }
  ];
  const exportColumns = [
    { key: "id", header: "SL. NO" },
    { key: "bid_request_code", header: "Bid Request Code" },
    { key: "request_date", header: "Request Date" },
    { key: "auction_time", header: "Request Time" },
    { key: "user_name", header: "Subscriber Name" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket_number", header: "Ticket" },
    { key: "auction_date", header: "Auction Date" },
    { key: "amount_paid_raw", header: "Amount Paid" },
    // { key: "instance_balance_raw", header: "Instance Balance (At Request)" },
    { key: "balance_raw", header: "Current Balance" },
    { key: "source", header: "Source" },
    { key: "status_raw", header: "Status" }
  ];
  const displayBidRequests = useMemo(() => {
    return bidRequests.map((item) => ({
      ...item,
      checkBox: /* @__PURE__ */ jsxDEV(
        SelectionCheckbox,
        {
          itemKey: item.key,
          userName: item.user_name,
          userPhone: item.rawData?.mobileNumber || item.rawData?.subscriberId?.phone_number || "N/A",
          activeUserData,
          setActiveUserData
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 189,
          columnNumber: 7
        },
        this
      )
    }));
  }, [bidRequests, activeUserData]);
  const handleOpenVerifyModal = () => setIsVerifyModalOpen(true);
  const handleCloseVerifyModal = () => setIsVerifyModalOpen(false);
  const handleSendWhatsApp = async () => {
    setIsSending(true);
    try {
      const selectedItems = bidRequests.filter(
        (item) => activeUserData[item.key]?.info?.status
      );
      const receivers = {};
      selectedItems.forEach((item) => {
        const rawData = item.rawData;
        const userObj = typeof rawData?.subscriberId === "object" ? rawData.subscriberId : {};
        const groupObj = typeof rawData?.groupId === "object" ? rawData.groupId : {};
        const enrollmentId = rawData?.enrollmentId?._id || rawData?.enrollmentId;
        receivers[item.key] = {
          info: {
            status: true,
            subscriberName: item.user_name || userObj.full_name || "N/A",
            mobileNumber: rawData?.mobileNumber || userObj.phone_number || "N/A",
            groupName: item.group_name || groupObj.group_name || "N/A",
            ticketNumber: item.ticket_number || "N/A",
            bidRequestId: item.key,
            enrollmentId,
            groupId: groupObj._id || rawData?.groupId,
            subscriberId: userObj._id || rawData?.subscriberId
          }
        };
      });
      await api.post("/whatsapp/bid-request-balance-check", receivers);
      message.success("WhatsApp messages initiated successfully!");
      const newActiveData = { ...activeUserData };
      selectedItems.forEach((item) => delete newActiveData[item.key]);
      setActiveUserData(newActiveData);
      setIsVerifyModalOpen(false);
    } catch (err) {
      console.error(err);
      message.error(err.response?.data?.message || "Failed to send messages.");
    } finally {
      setIsSending(false);
    }
  };
  const handleBulkStatusUpdate = (newStatus) => {
    const selectedItems = bidRequests.filter(
      (item) => activeUserData[item.key]?.info?.status
    );
    if (selectedItems.length === 0) return;
    Modal.confirm({
      title: `Bulk Update Confirmation`,
      icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 263,
        columnNumber: 13
      }, this),
      content: `You are about to update status to "${newStatus}" for ${selectedItems.length} requests. Are you sure?`,
      okText: "Yes, Update",
      cancelText: "No",
      onOk: async () => {
        setBulkLoading(true);
        try {
          const promises = selectedItems.map((item) => {
            const rawData = item.rawData;
            const payload = {
              status: newStatus,
              enrollmentId: rawData?.enrollmentId?._id || rawData?.enrollmentId,
              groupId: rawData?.groupId?._id || rawData?.groupId
            };
            return api.put(`/bid-request/update/${item.key}`, payload);
          });
          await Promise.all(promises);
          message.success(
            `${selectedItems.length} requests updated to ${newStatus}`
          );
          setActiveUserData({});
          setSelectAll(false);
          fetchBidRequests();
        } catch (err) {
          message.error("Failed to update some requests.");
        } finally {
          setBulkLoading(false);
        }
      }
    });
  };
  const fetchUsers = async () => {
    try {
      const response = await api.get("/user/get-user");
      setUsers(response.data || []);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };
  const fetchCustomerBalance = async (enrollmentId) => {
    if (!enrollmentId) return;
    setLoadingBalance(true);
    try {
      const response = await api.get(
        `/bid-request/get-balance/${enrollmentId}`
      );
      if (response.data?.data?.length > 0) {
        setCustomerBalance(response.data.data[0].balance);
      } else {
        setCustomerBalance(0);
      }
    } catch (error) {
      setCustomerBalance(0);
    } finally {
      setLoadingBalance(false);
    }
  };
  const fetchAuctionCount = async (groupId) => {
    if (!groupId) return 0;
    try {
      const response = await api.get(`/auction/get-group-auction/${groupId}`);
      return response.data.length;
    } catch (error) {
      return 0;
    }
  };
  const fetchEditCustomerDetails = async (userId, selectedEnrollmentId = null) => {
    try {
      const response = await api.post(
        `/enroll/get-user-tickets-report/${userId}`
      );
      if (response.data && response.data.length > 0) {
        const groupsDataPromise = response.data.map(async (item) => {
          const enrollment = item?.enrollment;
          const groupData = enrollment?.group;
          const groupId = groupData?._id;
          const auctionsDone = await fetchAuctionCount(groupId);
          const referredBy = groupData?.agent?.name && groupData?.agent?.phone_number ? `${groupData.agent.name} | ${groupData.agent.phone_number}` : groupData?.referred_customer?.full_name && groupData?.referred_customer?.phone_number ? `${groupData.referred_customer.full_name} | ${groupData.referred_customer.phone_number}` : groupData?.referred_lead?.lead_name && groupData?.referred_lead?.agent_number ? `${groupData.referred_lead.lead_name} | ${groupData.referred_lead.agent_number}` : "N/A";
          return {
            id: groupId,
            bid_request_code: groupData?.bid_request_code,
            groupName: groupData?.group_name || "No Group Name",
            ticketNumber: enrollment?.tickets || enrollment?.ticket_number || "N/A",
            startDate: groupData?.start_date ? groupData.start_date.split("T")[0] : "N/A",
            endDate: groupData?.end_date ? groupData.end_date.split("T")[0] : "N/A",
            auctionsDone,
            fullEnrollment: enrollment,
            enrollmentId: enrollment?._id,
            referredBy
          };
        });
        const groupsData = await Promise.all(groupsDataPromise);
        setEditGroups(groupsData);
        if (groupsData.length > 0) {
          let defaultIndex = 0;
          if (selectedEnrollmentId) {
            const foundIndex = groupsData.findIndex(
              (g) => g.enrollmentId === selectedEnrollmentId
            );
            if (foundIndex !== -1) {
              defaultIndex = foundIndex;
            }
          }
          setSelectedEditGroupIndex(defaultIndex);
          const selectedGroup = groupsData[defaultIndex];
          editForm.setFieldsValue({
            groupName: selectedGroup.groupName,
            ticketNumber: selectedGroup.ticketNumber,
            selectedGroupIndex: defaultIndex,
            startDate: selectedGroup.startDate,
            endDate: selectedGroup.endDate,
            auctionsDone: selectedGroup.auctionsDone,
            referredBy: selectedGroup.referredBy
          });
        }
      } else {
        setEditGroups([]);
        editForm.setFieldsValue({
          groupName: "No Groups Found",
          ticketNumber: "N/A",
          selectedGroupIndex: void 0,
          referredBy: "N/A"
        });
      }
    } catch (error) {
      console.error("Error fetching customer details:", error);
      message.error("Failed to fetch customer group details.");
    }
  };
  const handleEditGroupSelect = async (index) => {
    setSelectedEditGroupIndex(index);
    const selectedGroup = editGroups[index];
    if (selectedGroup) {
      editForm.setFieldsValue({
        groupName: selectedGroup.groupName,
        ticketNumber: selectedGroup.ticketNumber,
        selectedGroupIndex: index,
        startDate: selectedGroup.startDate,
        endDate: selectedGroup.endDate,
        auctionsDone: selectedGroup.auctionsDone,
        requestDate: selectedGroup.request_date ? dayjs(selectedGroup.request_date) : dayjs(),
        referredBy: selectedGroup.referredBy
      });
      await fetchCustomerBalance(selectedGroup.enrollmentId);
    }
  };
  const handleOpenEditModal = async (item) => {
    setOpenActionId(null);
    setEditingId(item.key);
    setIsEditModalOpen(true);
    const rawData = item.rawData;
    const userObj = typeof rawData.subscriberId === "object" ? rawData.subscriberId : {};
    const userId = userObj._id || rawData.subscriberId;
    const nameToDisplay = rawData.subscriberName || userObj.full_name || item.user_name || "";
    const phoneToDisplay = rawData.mobileNumber || userObj.phone_number || "";
    const customerIdToDisplay = userObj.customer_id || "N/A";
    const adminObject = rawData.adminUserDetails || {};
    const adminName = adminObject.name || adminObject.full_name || rawData.adminName || "N/A";
    const referredByFromTable = rawData?.agent?.name && rawData?.agent?.phone_number ? `${rawData.agent.name} | ${rawData.agent.phone_number}` : rawData?.referred_customer?.full_name && rawData?.referred_customer?.phone_number ? `${rawData.referred_customer.full_name} | ${rawData.referred_customer.phone_number}` : rawData?.referred_lead?.lead_name && rawData?.referred_lead?.agent_number ? `${rawData.referred_lead.lead_name} | ${rawData.referred_lead.agent_number}` : rawData.referredBy || "N/A";
    editForm.setFieldsValue({
      subscriberId: userId,
      subscriberName: nameToDisplay,
      mobileNumber: phoneToDisplay,
      customerId: customerIdToDisplay,
      bid_request_code: rawData.bid_request_code || "-",
      adminName,
      auctionDate: rawData.auctionDate ? dayjs(rawData.auctionDate) : null,
      auctionTime: rawData.auction_time ? dayjs(rawData.auction_time, "HH:mm") : null,
      referredBy: referredByFromTable,
      requestDate: rawData.request_date ? dayjs(rawData.request_date) : dayjs(),
      groupName: item.group_name,
      ticketNumber: item.ticket_number,
      enrollmentId: rawData.enrollmentId,
      groupId: rawData.groupId?._id || rawData.groupId
    });
    setCustomerBalance(rawData.auctions?.balance || 0);
    if (users.length === 0) await fetchUsers();
    await fetchEditCustomerDetails(userId, rawData.enrollmentId);
    if (rawData.enrollmentId) {
      await fetchCustomerBalance(rawData.enrollmentId);
    }
  };
  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    editForm.resetFields();
    setEditGroups([]);
    setCustomerBalance(null);
    setEditingId(null);
  };
  const handleSaveChanges = async () => {
    try {
      const values = await editForm.validateFields();
      setEditLoading(true);
      const updateData = {
        auctionDate: values.auctionDate ? values.auctionDate.format("YYYY-MM-DD") : null,
        auction_time: values.auctionTime ? values.auctionTime.format("HH:mm") : null,
        request_date: values.requestDate ? values.requestDate.format("YYYY-MM-DD") : null
        // Update request_date
      };
      const response = await api.put(`/bid-request/update/${editingId}`, updateData);
      if (response.status === 200) {
        message.success("Updated successfully!");
        fetchBidRequests();
        setIsEditModalOpen(false);
      }
    } catch (error) {
      message.error("Update failed");
    } finally {
      setEditLoading(false);
    }
  };
  const updateStatus = async (newStatus) => {
    try {
      setEditLoading(true);
      const values = await editForm.validateFields();
      const groupIndex = values.selectedGroupIndex ?? selectedEditGroupIndex;
      const selectedGroup = editGroups[groupIndex];
      if (!selectedGroup) {
        message.error("Group details not found. Please select a valid group.");
        setEditLoading(false);
        return;
      }
      const auctionDate = values.auctionDate?.format("YYYY-MM-DD");
      const auctionTime = values.auctionTime?.format("HH:mm");
      const requestDate = values.requestDate?.format("YYYY-MM-DD");
      const payload = {
        subscriberId: values.subscriberId,
        subscriberName: values.subscriberName,
        mobileNumber: values.mobileNumber,
        customerId: values.customerId,
        groupName: selectedGroup.groupName,
        ticketNumber: selectedGroup.ticketNumber,
        auctionDate,
        auction_time: auctionTime,
        auctionTime,
        referredBy: values.referredBy,
        referred_by: values.referredBy,
        groupId: selectedGroup.id,
        enrollmentId: selectedGroup.enrollmentId,
        status: newStatus,
        requestDate
      };
      await api.put(`/bid-request/update/${editingId}`, payload);
      const statusMessages = {
        Pending: "Bid Request moved to Pending successfully",
        Accept: "Bid Request accepted successfully",
        Reject: "Bid Request rejected successfully",
        NextAuction: "Post to Next Auction successfully",
        Prized: "Bid Request marked as Prized successfully"
      };
      message.success(
        statusMessages[newStatus] || `Status updated to ${newStatus}`
      );
      handleCloseEditModal();
      fetchBidRequests();
    } catch (error) {
      console.error("Update Error:", error);
      let errorMessage = "Failed to update status.";
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.errors) {
        errorMessage = Object.values(error.response.data.errors).flat().join(", ");
      } else if (error.errorFields) {
        errorMessage = error.errorFields.map((f) => `${f.name.join(".")}: ${f.errors.join(", ")}`).join("; ");
      }
      message.error(errorMessage);
    } finally {
      setEditLoading(false);
    }
  };
  const handleSetPending = async () => {
    await updateStatus("Pending");
  };
  const handleSetAccept = async () => {
    await updateStatus("Accept");
  };
  const handleSetReject = async () => {
    await updateStatus("Reject");
  };
  const handleSetNextAuction = async () => {
    await updateStatus("NextAuction");
  };
  const handleSetPrized = async () => {
    await updateStatus("Prized");
  };
  const fetchInitialData = async () => {
    try {
      const groupRes = await api.get("/group/get-group-admin");
      setGroups(groupRes.data || []);
    } catch (error) {
      console.error("Error fetching initial data", error);
    }
  };
  const handleEdit = (item) => {
    handleOpenEditModal(item);
  };
  const handleShare = (item) => {
    setOpenActionId(null);
    const frontendUrl = window.location.origin;
    const fullUrl = `${frontendUrl}/bid-request/share/${item.key}`;
    window.open(fullUrl, "_blank");
  };
  const handlePrint = (item) => {
    setOpenActionId(null);
    const printWindow = window.open("", "_blank");
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Bid Request Details</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          table { border-collapse: collapse; width: 100%; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f2f2f2; }
        </style>
      </head>
      <body>
        <h1>Bid Request Details</h1>
        <table>
          <tr><th>Field</th><th>Value</th></tr>
          <tr><td>Bid Request Code</td><td>${item.bid_request_code}</td></tr>
          <tr><td>Subscriber Name</td><td>${item.user_name}</td></tr>
          <tr><td>Group Name</td><td>${item.group_name}</td></tr>
          <tr><td>Ticket Number</td><td>${item.ticket_number}</td></tr>
          <tr><td>Auction Date</td><td>${item.auction_date}</td></tr>
          <tr><td>Instance Balance (At Request)</td><td>${item.instance_balance}</td></tr>
          <tr><td>Current Balance</td><td>${item.balance}</td></tr>
          <tr><td>Status</td><td>${typeof item.status === "object" ? item.status.props.children : item.status}</td></tr>
         </table>
      </body>
      </html>
    `;
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
  };
  const confirmDelete = (id) => {
    setOpenActionId(null);
    AntModal.confirm({
      title: "Are you sure you want to delete this bid request?",
      content: "This action cannot be undone.",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handleDelete = async (id) => {
    try {
      await api.delete(`/bid-request/delete/${id}`);
      message.success("Bid request deleted successfully");
      fetchBidRequests();
    } catch (error) {
      message.error("Failed to delete bid request");
    }
  };
  const handleToggleAction = useCallback((e, id) => {
    e.stopPropagation();
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    setOpenActionId((prevId) => {
      if (prevId === id) {
        return null;
      } else {
        setDropdownPos({
          top: rect.bottom + window.scrollY + 5,
          left: rect.right - 160
        });
        return id;
      }
    });
  }, []);
  const fetchBidRequests = async () => {
    setIsLoading(true);
    try {
      const params = {};
      if (filters.viewType) params.type = filters.viewType;
      if (filters.groupId) params.groupId = filters.groupId;
      if (filters.userId) params.userId = filters.userId;
      if (filters.status) params.status = filters.status;
      if (filters.paymentStatus) params.paymentStatus = filters.paymentStatus;
      if (filters.startDate) params.startDate = filters.startDate;
      if (filters.endDate) params.endDate = filters.endDate;
      const response = await api.get("/bid-request/get-all", { params });
      if (response.data && response.data.data) {
        setRawBidRequestsData(response.data.data);
        const formattedData = response.data.data.map((item, index) => {
          const userObject = item?.subscriberId || {};
          const groupObject = item?.groupId || {};
          const currentBalance = item?.auctions?.balance || 0;
          const instanceBalance = item?.instanceBalance || 0;
          const requestSource = item?.source || "Chit-Admin";
          const amountPaid = item?.auctions?.amount_paid || item?.amount_paid || 0;
          const getStatusTag = (status) => {
            const mappedStatus = status === "Decline" ? "Reject" : status;
            const statusColors = {
              Pending: "orange",
              Accept: "green",
              Reject: "red",
              Decline: "red",
              // Add this line
              NextAuction: "blue",
              Prized: "purple"
            };
            return /* @__PURE__ */ jsxDEV(Tag, { color: statusColors[mappedStatus] || "default", children: mappedStatus === "Reject" ? "Reject" : status || "Pending" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 755,
              columnNumber: 15
            }, this);
          };
          return {
            key: item._id,
            id: index + 1,
            bid_request_code: item.bid_request_code || `BR-${index + 1}`,
            request_date: item?.request_date ? dayjs(item.request_date).format("DD-MM-YYYY") : "N/A",
            request_date_raw: item.request_date,
            user_name: item.subscriberName || (typeof userObject === "object" ? userObject.full_name : "N/A"),
            group_name: item.groupName || (typeof groupObject === "object" ? groupObject.group_name : "N/A"),
            ticket_number: item.ticketNumber || "-",
            auction_date: item.auctionDate ? dayjs(item.auctionDate).format("DD-MM-YYYY") : "N/A",
            auction_time: item.auction_time ? dayjs(item.auction_time, "HH:mm").format("h:mm A") : "-",
            source: requestSource,
            source_raw: requestSource,
            instance_balance: /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: instanceBalance <= 0 ? "text-green-600 font-semibold" : "text-red-600 font-semibold",
                children: [
                  "₹ ",
                  instanceBalance.toLocaleString("en-IN")
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 788,
                columnNumber: 13
              },
              this
            ),
            instance_balance_raw: instanceBalance,
            balance: /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: currentBalance <= 0 ? "text-green-600 font-semibold" : "text-red-600 font-semibold",
                children: [
                  "₹ ",
                  currentBalance.toLocaleString("en-IN")
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 801,
                columnNumber: 13
              },
              this
            ),
            balance_raw: currentBalance,
            amount_paid: /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600 font-semibold", children: [
              "₹ ",
              amountPaid.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 814,
              columnNumber: 13
            }, this),
            amount_paid_raw: amountPaid,
            status: getStatusTag(item.status),
            status_raw: item.status || "Pending",
            referred_by: item.referred_by || "N/A",
            next_auction_date: item.latest_auction?.next_date ? dayjs(item.latest_auction.next_date).format("DD-MM-YYYY") : "N/A",
            rawData: item,
            action: /* @__PURE__ */ jsxDEV("div", { className: "relative text-center dropdown-trigger", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: (e) => handleToggleAction(e, item._id),
                className: "p-2 rounded-full hover:bg-gray-200 transition-colors duration-200",
                "aria-label": "Actions",
                children: "⋮"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 829,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 828,
              columnNumber: 13
            }, this)
          };
        });
        setAllBidRequests(formattedData);
        setBidRequests(formattedData);
        calculateOverview(response.data.data);
        calculateGroupStats(response.data.data);
      }
    } catch (error) {
      setAllBidRequests([]);
      setBidRequests([]);
      setRawBidRequestsData([]);
      setAlertConfig({
        visibility: true,
        message: "Error fetching bid requests",
        type: "error"
      });
      setTimeout(
        () => setAlertConfig((prev) => ({ ...prev, visibility: false })),
        3e3
      );
      console.error("Error fetching bid requests:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (openActionId && !event.target.closest(".dropdown-trigger") && !event.target.closest(".dropdown-menu")) {
        setOpenActionId(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [openActionId]);
  useEffect(() => {
    const allChecked = bidRequests.length > 0 && bidRequests.every((item) => activeUserData[item.key]?.info?.status);
    setSelectAll(allChecked);
  }, [bidRequests, activeUserData]);
  const handleApplyFilters = () => {
    setFilters({
      groupId: tempGroupId,
      userId: filters.userId,
      status: tempStatus,
      paymentStatus: tempPaymentStatus,
      startDate: tempFromDate ? tempFromDate.format("YYYY-MM-DD") : "",
      endDate: tempToDate ? tempToDate.format("YYYY-MM-DD") : "",
      viewType: filters.viewType
    });
    setActiveUserData({});
    setSelectAll(false);
    message.success("Filters applied");
  };
  const handleClearFilters = () => {
    setTempGroupId("");
    setTempStatus("");
    setTempPaymentStatus("");
    setTempFromDate(null);
    setTempToDate(null);
    setFilters({
      groupId: "",
      userId: "",
      status: "",
      paymentStatus: "",
      startDate: "",
      endDate: "",
      viewType: "all"
    });
    setActiveUserData({});
    setSelectAll(false);
    message.success("Filters cleared");
  };
  const calculateOverviewFromData = (data) => {
    const totalRequests = data?.length || 0;
    const pendingRequests = data?.filter((item) => item?.status_raw === "Pending")?.length || 0;
    const acceptRequests = data?.filter((item) => item?.status_raw === "Accept")?.length || 0;
    const rejectRequests = data?.filter((item) => item?.status_raw === "Reject")?.length || 0;
    const nextAuctionRequests = data?.filter((item) => item?.status_raw === "NextAuction")?.length || 0;
    const prizedRequests = data?.filter((item) => item?.status_raw === "Prized")?.length || 0;
    const totalPaidAmount = data?.reduce((sum, item) => sum + (item?.balance_raw || 0), 0) || 0;
    setOverview({
      totalRequests,
      totalPaidAmount,
      pendingRequests,
      acceptRequests,
      rejectRequests,
      nextAuctionRequests,
      prizedRequests
    });
  };
  const calculateGroupStatsFromData = (data) => {
    const statsMap = /* @__PURE__ */ new Map();
    data.forEach((item) => {
      const groupName = item.group_name;
      if (!groupName || groupName === "N/A") return;
      if (!statsMap.has(groupName)) {
        statsMap.set(groupName, {
          groupName,
          total: 0,
          pending: 0,
          accept: 0,
          reject: 0,
          nextAuction: 0,
          prized: 0,
          totalBalance: 0
        });
      }
      const stats = statsMap.get(groupName);
      stats.total++;
      stats.totalBalance += item.balance_raw || 0;
      switch (item.status_raw) {
        case "Pending":
          stats.pending++;
          break;
        case "Accept":
          stats.accept++;
          break;
        case "Reject":
          stats.reject++;
          break;
        case "NextAuction":
          stats.nextAuction++;
          break;
        case "Prized":
          stats.prized++;
          break;
        default:
          break;
      }
    });
    setGroupStats(Array.from(statsMap.values()));
  };
  const calculateOverview = (data) => {
    const totalRequests = data?.length || 0;
    const pendingRequests = data?.filter((item) => item?.status === "Pending")?.length || 0;
    const acceptRequests = data?.filter((item) => item?.status === "Accept")?.length || 0;
    const rejectRequests = data?.filter((item) => item?.status === "reject")?.length || 0;
    const nextAuctionRequests = data?.filter((item) => item?.status === "NextAuction")?.length || 0;
    const prizedRequests = data?.filter((item) => item?.status === "Prized")?.length || 0;
    const totalPaidAmount = data?.reduce(
      (sum, item) => sum + (item?.payments?.totalPaidAmount || 0),
      0
    ) || 0;
    const totalAmountPaid = data?.reduce(
      (sum, item) => sum + (item?.auctions?.amount_paid || item?.amount_paid || 0),
      0
    ) || 0;
    setOverview({
      totalRequests,
      totalPaidAmount,
      totalAmountPaid,
      pendingRequests,
      acceptRequests,
      rejectRequests,
      nextAuctionRequests,
      prizedRequests
    });
  };
  const calculateGroupStats = (data) => {
    const statsMap = /* @__PURE__ */ new Map();
    data.forEach((item) => {
      const groupObject = item?.groupId || {};
      const groupName = item?.groupName || (typeof groupObject === "object" ? groupObject?.group_name : "Unknown");
      if (!groupName) return;
      if (!statsMap.has(groupName)) {
        statsMap.set(groupName, {
          groupName,
          total: 0,
          pending: 0,
          accept: 0,
          reject: 0,
          nextAuction: 0,
          prized: 0,
          totalBalance: 0,
          nextAuctionDate: "N/A"
        });
      }
      const stats = statsMap.get(groupName);
      stats.total++;
      stats.totalBalance += item.auctions?.balance || 0;
      switch (item.status) {
        case "Pending":
          stats.pending++;
          break;
        case "Accept":
          stats.accept++;
          break;
        case "Reject":
          stats.reject++;
          break;
        case "NextAuction":
          stats.nextAuction++;
          break;
        case "Prized":
          stats.prized++;
          break;
        default:
          break;
      }
      const nextDate = item.latest_auction?.next_date;
      if (nextDate && stats.nextAuctionDate === "N/A") {
        const nextDateObj = dayjs(nextDate);
        if (nextDateObj.isValid()) {
          stats.nextAuctionDate = nextDateObj.format("DD-MM-YYYY");
        }
      }
    });
    setGroupStats(Array.from(statsMap.values()));
  };
  useEffect(() => {
    fetchInitialData();
  }, []);
  useEffect(() => {
    fetchBidRequests();
  }, []);
  useEffect(() => {
    if (allBidRequests.length > 0) {
      let filtered = [...allBidRequests];
      if (filters.groupId) {
        const selectedGroup = groups.find((g) => g._id === filters.groupId);
        if (selectedGroup) {
          filtered = filtered.filter(
            (item) => item.group_name === selectedGroup.group_name
          );
        }
      }
      if (filters.status) {
        filtered = filtered.filter(
          (item) => item.status_raw === filters.status
        );
      }
      if (filters.paymentStatus) {
        filtered = filtered.filter((item) => {
          const balance = item.balance_raw;
          if (filters.paymentStatus === "pending") return balance > 0;
          if (filters.paymentStatus === "uptodate") return balance <= 0;
          return true;
        });
      }
      if (filters.startDate || filters.endDate) {
        filtered = filtered.filter((item) => {
          if (!item.request_date_raw) return false;
          const itemDate = dayjs(item.request_date_raw);
          if (filters.startDate) {
            const startDate = dayjs(filters.startDate);
            if (itemDate.isBefore(startDate, "day")) return false;
          }
          if (filters.endDate) {
            const endDate = dayjs(filters.endDate);
            if (itemDate.isAfter(endDate, "day")) return false;
          }
          return true;
        });
      }
      setBidRequests(filtered);
      calculateOverviewFromData(filtered);
      calculateGroupStatsFromData(filtered);
    } else if (allBidRequests.length === 0 && !isLoading) {
      setBidRequests([]);
      calculateOverviewFromData([]);
      calculateGroupStatsFromData([]);
    }
  }, [filters, allBidRequests, groups]);
  const exportToExcel = () => {
    const exportData = bidRequests.map((item) => ({
      "SL No": item.id,
      "Bid Request Code": item.bid_request_code,
      "Request Date": item.request_date,
      "Subscriber Name": item.user_name,
      "Group Name": item.group_name,
      "Ticket Number": item.ticket_number,
      "Auction Date": item.auction_date,
      Source: item.source,
      "Auction Time": item.auction_time,
      "Instance Balance (At Request)": item.instance_balance,
      "Current Balance": item.balance,
      Status: typeof item.status === "object" ? item.status.props.children : item.status
    }));
    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Bid Requests");
    XLSX.writeFile(
      wb,
      `Bid_Requests_Report_${dayjs().format("YYYY-MM-DD")}.xlsx`
    );
    message.success("Excel file downloaded successfully");
  };
  const exportToPDF = () => {
    const doc = new jsPDF("landscape");
    doc.setFontSize(16);
    doc.text("Bid Requests Report", 14, 15);
    doc.setFontSize(10);
    doc.text(`Generated on: ${dayjs().format("DD-MM-YYYY HH:mm:ss")}`, 14, 22);
    const tableData = bidRequests.map(
      (item) => [
        item.id,
        item.bid_request_code,
        item.request_date,
        item.user_name,
        item.group_name,
        item.ticket_number,
        item.auction_date,
        item.instance_balance,
        item.balance,
        typeof item.status === "object" ? item.status.props.children : item.status
      ]
    );
    doc.autoTable({
      head: [
        [
          "SL No",
          "Bid Code",
          "Req Date",
          "Source",
          "Subscriber",
          "Group",
          "Ticket",
          "Auction Date",
          "Inst. Balance",
          "Curr. Balance",
          "Status"
        ]
      ],
      body: tableData,
      startY: 30,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [41, 128, 185] }
    });
    doc.save(`Bid_Requests_Report_${dayjs().format("YYYY-MM-DD")}.pdf`);
    message.success("PDF file downloaded successfully");
  };
  const printReport = () => {
    const printWindow = window.open("", "_blank");
    const summaryHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Bid Requests Report</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1, h2 { text-align: center; }
          table { border-collapse: collapse; width: 100%; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f2f2f2; }
          .summary-card { margin: 20px 0; }
        </style>
      </head>
      <body>
        <h1>Bid Requests Report</h1>
        <p style="text-align: center;">Generated on: ${dayjs().format("DD-MM-YYYY HH:mm:ss")}</p>
        
        <div class="summary-card">
          <h2>Summary Statistics</h2>
          <table>
            <tr><th>Metric</th><th>Value</th></tr>
            <tr><td>Total Requests</td><td>${overview.totalRequests}</td></tr>
            <tr><td>Pending Requests</td><td>${overview.pendingRequests}</td></tr>
            <tr><td>Accept Requests</td><td>${overview.acceptRequests}</td></tr>
            <tr><td>Reject Requests</td><td>${overview.rejectRequests}</td></tr>
            <tr><td>Prized Requests</td><td>${overview.prizedRequests}</td></tr>
            <tr><td>Next Auctions</td><td>${overview.nextAuctionRequests}</td></tr>
            <tr><td>Total Current Due</td><td>₹${overview.totalPaidAmount.toLocaleString("en-IN")}</td></tr>
          </table>
        </div>
        
        <h2>Bid Requests Details</h2>
        <table>
          <thead>
            <tr>
              <th>SL No</th>
              <th>Bid Code</th>
              <th>Request Date</th>
              <th>Subscriber</th>
              <th>Group</th>
              <th>Ticket</th>
              <th>Auction Date</th>
              <th>Inst. Balance</th> 
              <th>Curr. Balance</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${bidRequests.map(
      (item) => `
              <tr>
                <td>${item.id}</td>
                <td>${item.bid_request_code}</td>
                <td>${item.request_date}</td>
                <td>${item.user_name}</td>
                <td>${item.group_name}</td>
                <td>${item.ticket_number}</td>
                <td>${item.auction_date}</td>
                <td>${item.instance_balance}</td> 
                <td>${item.balance}</td>
                <td>${typeof item.status === "object" ? item.status.props.children : item.status}</td>
              </tr>
            `
    ).join("")}
          </tbody>
        </table>
      </body>
      </html>
    `;
    printWindow.document.write(summaryHTML);
    printWindow.document.close();
    printWindow.print();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1318,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 bg-gray-50 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(FaGavel, { className: "text-blue-900" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1327,
            columnNumber: 13
          }, this),
          " All Bid Request Report"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1326,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Space, { children: /* @__PURE__ */ jsxDEV(Button, { icon: /* @__PURE__ */ jsxDEV(IoMdRefresh, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1330,
          columnNumber: 27
        }, this), onClick: fetchBidRequests, children: "Refresh" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1330,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1329,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1325,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-sm mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxDEV(FilterOutlined, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1338,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 m-0", children: "Filter Options" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1339,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1337,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-500 uppercase mb-1", children: "DATE RANGE" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1346,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                DatePicker,
                {
                  style: { width: "100%" },
                  value: tempFromDate,
                  onChange: setTempFromDate,
                  format: "DD-MM-YYYY",
                  placeholder: "From Date",
                  size: "large"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1350,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                DatePicker,
                {
                  style: { width: "100%" },
                  value: tempToDate,
                  onChange: setTempToDate,
                  format: "DD-MM-YYYY",
                  placeholder: "To Date",
                  size: "large"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1358,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1349,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1345,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[150px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-500 uppercase mb-1", children: "Filter by Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1370,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "All Groups",
                className: "w-full",
                allowClear: true,
                value: tempGroupId || void 0,
                onChange: (val) => setTempGroupId(val || ""),
                size: "large",
                children: groups.map(
                  (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g._id, children: g.group_name }, g._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1382,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1373,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1369,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[150px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-500 uppercase mb-1", children: "Request Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1390,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "All Status",
                className: "w-full",
                allowClear: true,
                value: tempStatus || void 0,
                onChange: (val) => setTempStatus(val || ""),
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "Pending", children: "Pending" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1401,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "Accept", children: "Accept" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1402,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "Reject", children: "Reject" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1403,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "NextAuction", children: "Next Auction" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1404,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "Prized", children: "Prized" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1405,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1393,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1389,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[150px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-500 uppercase mb-1", children: "Payment Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1410,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "All Payments",
                className: "w-full",
                allowClear: true,
                value: tempPaymentStatus || void 0,
                onChange: (val) => setTempPaymentStatus(val || ""),
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "pending", children: "Payment Pending" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1421,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "uptodate", children: "Up to Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1422,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1413,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1409,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 min-w-[100px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-500 uppercase mb-1 text-center", children: "SELECT ALL" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1427,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-10", children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                className: "w-5 h-5 cursor-pointer accent-blue-600",
                checked: selectAll,
                onChange: (e) => {
                  const checked = e.target.checked;
                  setSelectAll(checked);
                  const updated = { ...activeUserData };
                  bidRequests.forEach((item) => {
                    updated[item.key] = {
                      info: {
                        status: checked,
                        userName: item.user_name,
                        userPhone: item.rawData?.mobileNumber || item.rawData?.subscriberId?.phone_number || "N/A"
                      }
                    };
                  });
                  setActiveUserData(updated);
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1431,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1430,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1426,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 flex gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(SearchOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1460,
                  columnNumber: 23
                }, this),
                onClick: handleApplyFilters,
                size: "large",
                children: "Apply"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1458,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Button, { onClick: handleClearFilters, size: "large", children: "Clear" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1466,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1457,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1344,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1336,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl p-5 shadow-md", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90", children: "Total Requests" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1475,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: overview.totalRequests }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1476,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1474,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-yellow-500 to-orange-500 text-white rounded-xl p-5 shadow-md", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90", children: "Pending Requests" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1482,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: overview.pendingRequests }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1483,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1481,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl p-5 shadow-md", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90", children: "Accept Requests" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1489,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: overview.acceptRequests }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1490,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1488,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-red-500 to-rose-600 text-white rounded-xl p-5 shadow-md", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90", children: "Reject Requests" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1496,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: overview.rejectRequests }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1497,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1495,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-xl p-5 shadow-md", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90", children: "Prized Requests" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1503,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: overview.prizedRequests }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1504,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1502,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-slate-800 to-slate-600 text-white rounded-xl p-5 shadow-md", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90", children: "Next Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1510,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: overview.nextAuctionRequests }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1511,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1509,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1473,
        columnNumber: 9
      }, this),
      selectedCount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg shadow p-4 mb-6 transition-all duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-600 text-white rounded-full h-10 w-10 flex items-center justify-center font-bold text-lg shadow-md", children: selectedCount }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1521,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-lg", children: "Items Selected" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1524,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1520,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3 justify-center", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              icon: /* @__PURE__ */ jsxDEV(WhatsAppOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1531,
                columnNumber: 23
              }, this),
              size: "large",
              className: "bg-green-600 hover:bg-green-700 border-green-600",
              onClick: handleOpenVerifyModal,
              loading: isSending,
              children: "Send WhatsApp"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1529,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "large",
              className: "bg-green-100 text-green-700 border-green-200 hover:bg-green-200 font-semibold",
              onClick: () => handleBulkStatusUpdate("Accept"),
              loading: bulkLoading,
              children: "Accept All"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1539,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "large",
              className: "bg-purple-100 text-purple-700 border-purple-200 hover:bg-purple-200 font-semibold",
              icon: /* @__PURE__ */ jsxDEV(TrophyOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1550,
                columnNumber: 23
              }, this),
              onClick: () => handleBulkStatusUpdate("Prized"),
              loading: bulkLoading,
              children: "Mark as Prized"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1547,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "large",
              className: "bg-red-100 text-red-700 border-red-200 hover:bg-red-200 font-semibold",
              onClick: () => handleBulkStatusUpdate("Reject"),
              loading: bulkLoading,
              children: "Reject All"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1556,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "large",
              className: "bg-yellow-100 text-yellow-700 border-yellow-200 hover:bg-yellow-200 font-semibold",
              onClick: () => handleBulkStatusUpdate("Pending"),
              loading: bulkLoading,
              children: "Mark Pending"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1564,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "large",
              className: "bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 font-semibold",
              onClick: () => handleBulkStatusUpdate("NextAuction"),
              loading: bulkLoading,
              children: "Post to Next Auction"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1572,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1528,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1519,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1518,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Tabs, { activeKey: activeTab, onChange: setActiveTab, className: "mb-6", children: /* @__PURE__ */ jsxDEV(TabPane, { tab: "Bid Requests List", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Bid Requests" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1588,
        columnNumber: 13
      }, this) : bidRequests.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Bid Request Data Found" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1590,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: displayBidRequests,
          columns,
          exportCols: exportColumns,
          exportedPdfName: "Bid Request Report",
          exportedFileName: "Bid_Request_Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1592,
          columnNumber: 13
        },
        this
      ) }, "list", false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1586,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1585,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
      lineNumber: 1324,
      columnNumber: 7
    }, this),
    openActionId && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "dropdown-menu dropdown-menu-fixed bg-white border rounded-lg shadow-lg w-40",
        style: {
          position: "absolute",
          zIndex: 9999,
          top: `${dropdownPos.top}px`,
          left: `${dropdownPos.left}px`
        },
        onClick: (e) => e.stopPropagation(),
        children: (() => {
          const item = allBidRequests.find((req) => req.key === openActionId);
          if (!item) return null;
          return /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  handleEdit(item);
                },
                className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-blue-600",
                children: [
                  /* @__PURE__ */ jsxDEV(EditOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1627,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Edit" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1628,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1620,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  handleShare(item);
                },
                className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-orange-600",
                children: [
                  /* @__PURE__ */ jsxDEV(ShareAltOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1637,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Share" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1638,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1630,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  handlePrint(item);
                },
                className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-green-600",
                children: [
                  /* @__PURE__ */ jsxDEV(PrinterOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1647,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Print" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1648,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1640,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  confirmDelete(item.key);
                },
                className: "flex items-center gap-2 w-full px-4 py-2 hover:bg-gray-100 text-red-600 border-t border-gray-100",
                children: [
                  /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1657,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1658,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1650,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1619,
            columnNumber: 13
          }, this);
        })()
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1605,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold border-b pb-2", children: "Bid Request Details" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1668,
          columnNumber: 9
        }, this),
        open: showModalView,
        onCancel: () => setShowModalView(false),
        footer: null,
        width: 700,
        children: currentBidRequest && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-y-4 py-4", children: [
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Bid Request Code",
              value: currentBidRequest.bid_request_code
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1679,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Subscriber Name",
              value: currentBidRequest.user_name
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1683,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Mobile Number",
              value: currentBidRequest.mobileNumber || "N/A"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1687,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Group Name",
              value: currentBidRequest.group_name
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1691,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Ticket Number",
              value: currentBidRequest.ticket_number
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1695,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Request Date",
              value: currentBidRequest.request_date
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1699,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Auction Date",
              value: currentBidRequest.auction_date
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1703,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Auction Time",
              value: currentBidRequest.auction_time
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1707,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Instance Balance (At Request)",
              value: currentBidRequest.instance_balance
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1711,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Current Balance",
              value: currentBidRequest.balance
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1715,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Next Auction Date",
              value: currentBidRequest.next_auction_date
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1719,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Referred By",
              value: currentBidRequest.referred_by
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1723,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Status", value: currentBidRequest.status }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1727,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1678,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1666,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "border-b-2 border-blue-900 pb-3", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-blue-900 uppercase tracking-wider text-center", children: "Edit Bid Request" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1735,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1734,
          columnNumber: 9
        }, this),
        open: isEditModalOpen,
        onCancel: handleCloseEditModal,
        footer: null,
        width: 900,
        destroyOnClose: true,
        children: /* @__PURE__ */ jsxDEV(Form, { form: editForm, layout: "vertical", className: "mt-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-3 border-b pb-1", children: "Subscriber Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1748,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 bg-gray-50 p-4 rounded-lg border border-gray-200 mb-4", children: [
              /* @__PURE__ */ jsxDEV(Form.Item, { name: "subscriberId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1753,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1752,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Bid Request Code" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1756,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "bid_request_code", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    readOnly: true,
                    className: "bg-gray-100 border-gray-300 font-semibold"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1760,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1759,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1755,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Created By (Admin)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1767,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "adminName", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    readOnly: true,
                    className: "bg-gray-100 border-gray-300 font-semibold"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1771,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1770,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1766,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Subscriber Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1778,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "subscriberName", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    readOnly: true,
                    className: "bg-gray-100 border-gray-300 font-semibold"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1782,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1781,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1777,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Mobile Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1789,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "mobileNumber", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    readOnly: true,
                    className: "bg-gray-100 border-gray-300 font-semibold"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1793,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1792,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1788,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Customer ID" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1800,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "customerId", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    readOnly: true,
                    className: "bg-gray-100 border-gray-300 font-semibold"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1804,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1803,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1799,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1751,
              columnNumber: 13
            }, this),
            editGroups.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700", children: [
                "Select Group for Bid Request",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1816,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1814,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "selectedGroupIndex",
                  rules: [{ required: true, message: "Required!" }],
                  className: "mb-3",
                  children: /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      placeholder: "Choose which group...",
                      onChange: handleEditGroupSelect,
                      value: selectedEditGroupIndex,
                      className: "w-full",
                      size: "large",
                      children: editGroups.map(
                        (group, index) => /* @__PURE__ */ jsxDEV(Option, { value: index, children: [
                          group.groupName,
                          " (Ticket: ",
                          group.ticketNumber,
                          ")"
                        ] }, group.id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                          lineNumber: 1831,
                          columnNumber: 19
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 1823,
                      columnNumber: 19
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1818,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Group Start Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1839,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: "startDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      readOnly: true,
                      className: "bg-blue-50 border-blue-200 text-blue-900 font-semibold h-10"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 1843,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1842,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1838,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Group End Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1850,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: "endDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      readOnly: true,
                      className: "bg-blue-50 border-blue-200 text-blue-900 font-semibold h-10"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 1854,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1853,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1849,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Auctions Done" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1861,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: "auctionsDone", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      readOnly: true,
                      className: "bg-green-50 border-green-200 text-green-900 font-bold text-center h-10"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 1865,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1864,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1860,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Ticket Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1872,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: "ticketNumber", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      readOnly: true,
                      className: "bg-gray-100 border-gray-300 font-semibold h-10"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 1876,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1875,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1871,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1837,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Group Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1884,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "groupName", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    readOnly: true,
                    className: "bg-gray-100 border-gray-300 font-semibold h-10"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1888,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1887,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1883,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1813,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 flex justify-center items-center", children: /* @__PURE__ */ jsxDEV(Spin, { size: "large", tip: "Loading group details..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1897,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1896,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1747,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-3 border-b pb-1", children: "Auction Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1903,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                  "Auction Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1909,
                    columnNumber: 32
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1908,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Form.Item,
                  {
                    name: "auctionDate",
                    rules: [{ required: true, message: "Required!" }],
                    className: "mb-0",
                    children: /* @__PURE__ */ jsxDEV(
                      DatePicker,
                      {
                        style: { width: "100%" },
                        className: "border-gray-400 h-10",
                        format: "DD-MM-YYYY"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 1916,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1911,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1907,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                  "Auction Time ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1925,
                    columnNumber: 32
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1924,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Form.Item,
                  {
                    name: "auctionTime",
                    rules: [{ required: true, message: "Required!" }],
                    className: "mb-0",
                    children: /* @__PURE__ */ jsxDEV(
                      TimePicker,
                      {
                        style: { width: "100%" },
                        className: "border-gray-400 h-10",
                        format: "h:mm A",
                        use12Hours: true
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 1932,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1927,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1923,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Request Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1941,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "requestDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                  DatePicker,
                  {
                    style: { width: "100%" },
                    className: "border-gray-400 h-10",
                    format: "DD-MM-YYYY"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                    lineNumber: 1945,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1944,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1940,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1906,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1902,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 border rounded-lg flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-700 text-lg", children: "Current Due Balance:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1957,
              columnNumber: 15
            }, this),
            loadingBalance ? /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1961,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: `font-bold text-2xl ${customerBalance <= 0 ? "text-green-600" : "text-red-600"}`,
                children: customerBalance !== null ? `₹ ${customerBalance.toLocaleString("en-IN")}` : "N/A"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 1963,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1956,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1955,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Form.Item, { name: "enrollmentId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1975,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1974,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Form.Item, { name: "groupId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1978,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1977,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-3 border-b pb-1", children: "Update Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1982,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-6 gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                Popconfirm,
                {
                  title: "Set to Pending?",
                  onConfirm: handleSetPending,
                  okText: "Yes",
                  cancelText: "No",
                  children: /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "default",
                      loading: editLoading,
                      className: "h-14 font-bold border-yellow-500 text-yellow-600 hover:bg-yellow-50",
                      icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 1996,
                        columnNumber: 25
                      }, this),
                      disabled: editGroups.length === 0,
                      block: true,
                      children: "Pending"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 1992,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 1986,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Popconfirm,
                {
                  title: "Approve Request?",
                  onConfirm: handleSetAccept,
                  okText: "Yes",
                  cancelText: "No",
                  children: /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "primary",
                      loading: editLoading,
                      disabled: editGroups.length === 0,
                      className: "h-14 font-bold bg-green-600 hover:bg-green-700 border-green-600",
                      icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 2014,
                        columnNumber: 25
                      }, this),
                      block: true,
                      children: "Accept"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 2009,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 2003,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Popconfirm,
                {
                  title: "Mark as Prized?",
                  onConfirm: handleSetPrized,
                  okText: "Yes",
                  cancelText: "No",
                  children: /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "primary",
                      loading: editLoading,
                      disabled: editGroups.length === 0,
                      className: "h-14 font-bold bg-purple-600 hover:bg-purple-700 border-purple-600",
                      icon: /* @__PURE__ */ jsxDEV(TrophyOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 2031,
                        columnNumber: 25
                      }, this),
                      block: true,
                      children: "Prized"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 2026,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 2020,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Popconfirm,
                {
                  title: "Reject Request?",
                  onConfirm: handleSetReject,
                  okText: "Yes",
                  cancelText: "No",
                  children: /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "primary",
                      danger: true,
                      loading: editLoading,
                      className: "h-14 font-bold",
                      icon: /* @__PURE__ */ jsxDEV(CloseOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 2048,
                        columnNumber: 25
                      }, this),
                      disabled: editGroups.length === 0,
                      block: true,
                      children: "Reject"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 2043,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 2037,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Popconfirm,
                {
                  title: "Post to next auction?",
                  onConfirm: handleSetNextAuction,
                  okText: "Yes",
                  cancelText: "No",
                  children: /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "primary",
                      danger: true,
                      loading: editLoading,
                      className: "h-14 font-bold bg-orange-600 hover:bg-orange-700 border-orange-600",
                      icon: /* @__PURE__ */ jsxDEV(StopOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 2066,
                        columnNumber: 25
                      }, this),
                      disabled: editGroups.length === 0,
                      block: true,
                      children: [
                        "Next",
                        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                          lineNumber: 2071,
                          columnNumber: 19
                        }, this),
                        "Auction"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 2061,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 2055,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: handleCloseEditModal,
                  className: "h-14 font-semibold border-gray-400",
                  block: true,
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 2075,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Popconfirm,
                {
                  title: "Save Changes?",
                  description: "Are you sure you want to save the changes to auction date/time?",
                  onConfirm: handleSaveChanges,
                  okText: "Yes",
                  cancelText: "No",
                  children: /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "primary",
                      loading: editLoading,
                      className: "h-14 font-bold bg-blue-600 hover:bg-blue-700 border-blue-600",
                      icon: /* @__PURE__ */ jsxDEV(SaveOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                        lineNumber: 2094,
                        columnNumber: 25
                      }, this),
                      disabled: editGroups.length === 0,
                      block: true,
                      children: "Save Changes"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                      lineNumber: 2090,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                  lineNumber: 2083,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 1985,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 1981,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 1746,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 1732,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: isVerifyModalOpen,
        onCancel: handleCloseVerifyModal,
        footer: null,
        centered: true,
        width: 500,
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 text-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-full p-4", children: /* @__PURE__ */ jsxDEV(WhatsAppOutlined, { className: "text-4xl text-green-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 2116,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 2115,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 2114,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800 mb-2", children: "Are You Sure?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 2119,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mb-6", children: [
            "You are about to send WhatsApp messages to",
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-600", children: [
              selectedCount,
              " contacts"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 2124,
              columnNumber: 13
            }, this),
            ".",
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
              lineNumber: 2128,
              columnNumber: 13
            }, this),
            "This action cannot be undone once initiated."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 2122,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                onClick: handleCloseVerifyModal,
                className: "w-32",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 2132,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "large",
                loading: isSending,
                onClick: handleSendWhatsApp,
                className: "w-32 bg-green-600 hover:bg-green-700 border-green-600",
                children: "Yes, Send"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
                lineNumber: 2139,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
            lineNumber: 2131,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
          lineNumber: 2113,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
        lineNumber: 2106,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
    lineNumber: 1317,
    columnNumber: 5
  }, this);
};
_s(BidRequestReport, "yjJpkj7u29tge89WbUEH87uj2kE=", false, function() {
  return [Form.useForm];
});
_c2 = BidRequestReport;
const DetailItem = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col border-b border-gray-50 pb-2 mr-4", children: [
  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-gray-400 uppercase tracking-wider", children: label }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
    lineNumber: 2157,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: value || "N/A" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
    lineNumber: 2160,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx",
  lineNumber: 2156,
  columnNumber: 1
}, this);
_c3 = DetailItem;
export default BidRequestReport;
var _c, _c2, _c3;
$RefreshReg$(_c, "SelectionCheckbox");
$RefreshReg$(_c2, "BidRequestReport");
$RefreshReg$(_c3, "DetailItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidRequestReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURJLFNBMmhEVSxVQTNoRFY7MkJBdkRKO0FBQW9CQSxvQkFBcUIsT0FBRUMsc0JBQXNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2pFO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLEtBQUtDLFNBQVNDLE9BQU9QLFNBQVNRLFVBQVVDLE1BQU1DLGFBQWE7QUFDcEUsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxtQkFBbUI7QUFDNUI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsV0FBVztBQUNsQixZQUFZQyxVQUFVO0FBQ3RCLE9BQU9DLFdBQVc7QUFDbEIsT0FBTztBQUVQLE1BQU0sRUFBRUMsUUFBUSxJQUFJckI7QUFDcEIsTUFBTSxFQUFFc0IsT0FBTyxJQUFJbkM7QUFHbkIsTUFBTW9DLG9CQUFvQkEsQ0FBQztBQUFBLEVBQ3pCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFDSixRQUFNQyxZQUFZLENBQUMsQ0FBQ0YsaUJBQWlCSCxPQUFPLEdBQUdNLE1BQU1DO0FBRXJELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLFNBQVNGO0FBQUFBLE1BQ1QsVUFBVSxDQUFDRyxNQUFNO0FBQ2ZKLDBCQUFrQixDQUFDSyxVQUFVO0FBQUEsVUFDM0IsR0FBR0E7QUFBQUEsVUFDSCxDQUFDVCxPQUFPLEdBQUc7QUFBQSxZQUNUTSxNQUFNO0FBQUEsY0FDSkMsUUFBUUMsRUFBRUUsT0FBT0M7QUFBQUEsY0FDakJWO0FBQUFBLGNBQ0FDO0FBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRixFQUFFO0FBQUEsTUFDSjtBQUFBLE1BQ0EsV0FBVTtBQUFBO0FBQUEsSUFmWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFlb0Q7QUFHeEQ7QUFDQVUsS0E3Qk1iO0FBK0JOLE1BQU1jLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBRTdCLFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSTVELFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUM2RCxhQUFhQyxjQUFjLElBQUk5RCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDK0Qsb0JBQW9CQyxxQkFBcUIsSUFBSWhFLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUNpRSxRQUFRQyxTQUFTLElBQUlsRSxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDbUUsV0FBV0MsWUFBWSxJQUFJcEUsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3FFLGNBQWNDLGVBQWUsSUFBSXRFLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUN1RSxhQUFhQyxjQUFjLElBQUl4RSxTQUFTLEVBQUV5RSxLQUFLLEdBQUdDLE1BQU0sRUFBRSxDQUFDO0FBR2xFLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSTVFLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM2RSxRQUFRLElBQUkzRSxLQUFLNEUsUUFBUTtBQUNoQyxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWhGLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNpRix3QkFBd0JDLHlCQUF5QixJQUFJbEYsU0FBUyxDQUFDO0FBQ3RFLFFBQU0sQ0FBQ21GLFdBQVdDLFlBQVksSUFBSXBGLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUNxRixpQkFBaUJDLGtCQUFrQixJQUFJdEYsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ3VGLGdCQUFnQkMsaUJBQWlCLElBQUl4RixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDeUYsYUFBYUMsY0FBYyxJQUFJMUYsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQzJGLE9BQU9DLFFBQVEsSUFBSTVGLFNBQVMsRUFBRTtBQUdyQyxRQUFNLENBQUMrQyxnQkFBZ0JDLGlCQUFpQixJQUFJaEQsU0FBUyxDQUFDLENBQUM7QUFDdkQsUUFBTSxDQUFDNkYsV0FBV0MsWUFBWSxJQUFJOUYsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQytGLG1CQUFtQkMsb0JBQW9CLElBQUloRyxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDaUcsV0FBV0MsWUFBWSxJQUFJbEcsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ21HLGFBQWFDLGNBQWMsSUFBSXBHLFNBQVMsS0FBSztBQUdwRCxRQUFNLENBQUNxRyxhQUFhQyxjQUFjLElBQUl0RyxTQUFTO0FBQUEsSUFDN0N1RyxZQUFZO0FBQUEsSUFDWjdGLFNBQVM7QUFBQSxJQUNUOEYsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJMUcsU0FBUztBQUFBLElBQ3ZDMkcsZUFBZTtBQUFBLElBQ2ZDLGlCQUFpQjtBQUFBLElBQ2pCQyxpQkFBaUI7QUFBQSxJQUNqQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGdCQUFnQjtBQUFBLElBQ2hCQyxxQkFBcUI7QUFBQSxJQUNyQkMsZ0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJbkgsU0FBUztBQUFBLElBQ3JDb0gsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxJQUNSbEUsUUFBUTtBQUFBLElBQ1JtRSxlQUFlO0FBQUEsSUFDZkMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBR0QsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUkzSCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDNEgsWUFBWUMsYUFBYSxJQUFJN0gsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzhILG1CQUFtQkMsb0JBQW9CLElBQUkvSCxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDZ0ksY0FBY0MsZUFBZSxJQUFJakksU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ2tJLFlBQVlDLGFBQWEsSUFBSW5JLFNBQVMsSUFBSTtBQUVqRCxRQUFNLENBQUNvSSxlQUFlQyxnQkFBZ0IsSUFBSXJJLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNzSSxtQkFBbUJDLG9CQUFvQixJQUFJdkksU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ3dJLFlBQVlDLGFBQWEsSUFBSXpJLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMwSSxXQUFXQyxZQUFZLElBQUkzSSxTQUFTLE1BQU07QUFHakQsUUFBTTRJLGdCQUFnQjNJLFFBQVEsTUFBTTtBQUNsQyxXQUFPNEQsWUFBWWdGLE9BQU8sQ0FBQ0MsU0FBUy9GLGVBQWUrRixLQUFLQyxHQUFHLEdBQUc3RixNQUFNQyxNQUFNLEVBQ3ZFNkY7QUFBQUEsRUFDTCxHQUFHLENBQUNuRixhQUFhZCxjQUFjLENBQUM7QUFHaEMsUUFBTWtHLFVBQVU7QUFBQSxJQUNkLEVBQUVGLEtBQUssTUFBTUcsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUgsS0FBSyxvQkFBb0JHLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRUgsS0FBSyxnQkFBZ0JHLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVILEtBQUssZ0JBQWdCRyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFSCxLQUFLLGFBQWFHLFFBQVEsa0JBQWtCO0FBQUEsSUFDOUMsRUFBRUgsS0FBSyxjQUFjRyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFSCxLQUFLLGlCQUFpQkcsUUFBUSxTQUFTO0FBQUEsSUFDekMsRUFBRUgsS0FBSyxnQkFBZ0JHLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVILEtBQUssZUFBZUcsUUFBUSxjQUFjO0FBQUE7QUFBQSxJQUU1QyxFQUFFSCxLQUFLLFdBQVdHLFFBQVEsa0JBQWtCO0FBQUEsSUFDNUMsRUFBRUgsS0FBSyxVQUFVRyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFSCxLQUFLLFlBQVlHLFFBQVEsU0FBUztBQUFBLElBQ3BDLEVBQUVILEtBQUssVUFBVUcsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUgsS0FBSyxVQUFVRyxRQUFRLFVBQVVDLE9BQU8sSUFBSTtBQUFBLEVBQUM7QUFHakQsUUFBTUMsZ0JBQWdCO0FBQUEsSUFDcEIsRUFBRUwsS0FBSyxNQUFNRyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFSCxLQUFLLG9CQUFvQkcsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFSCxLQUFLLGdCQUFnQkcsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUgsS0FBSyxnQkFBZ0JHLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVILEtBQUssYUFBYUcsUUFBUSxrQkFBa0I7QUFBQSxJQUM5QyxFQUFFSCxLQUFLLGNBQWNHLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVILEtBQUssaUJBQWlCRyxRQUFRLFNBQVM7QUFBQSxJQUN6QyxFQUFFSCxLQUFLLGdCQUFnQkcsUUFBUSxlQUFlO0FBQUEsSUFDN0MsRUFBRUgsS0FBSyxtQkFBbUJHLFFBQVEsY0FBYztBQUFBO0FBQUEsSUFFakQsRUFBRUgsS0FBSyxlQUFlRyxRQUFRLGtCQUFrQjtBQUFBLElBQ2hELEVBQUVILEtBQUssVUFBVUcsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUgsS0FBSyxjQUFjRyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3pDLFFBQU1HLHFCQUFxQnBKLFFBQVEsTUFBTTtBQUN2QyxXQUFPNEQsWUFBWXlGLElBQUksQ0FBQ1IsVUFBVTtBQUFBLE1BQ2hDLEdBQUdBO0FBQUFBLE1BQ0hTLFVBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNULEtBQUtDO0FBQUFBLFVBQ2QsVUFBVUQsS0FBS1U7QUFBQUEsVUFDZixXQUNFVixLQUFLVyxTQUFTQyxnQkFDZFosS0FBS1csU0FBU0UsY0FBY0MsZ0JBQzVCO0FBQUEsVUFFRjtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU3VDO0FBQUEsSUFHM0MsRUFBRTtBQUFBLEVBQ0osR0FBRyxDQUFDL0YsYUFBYWQsY0FBYyxDQUFDO0FBRWhDLFFBQU04Ryx3QkFBd0JBLE1BQU03RCxxQkFBcUIsSUFBSTtBQUM3RCxRQUFNOEQseUJBQXlCQSxNQUFNOUQscUJBQXFCLEtBQUs7QUFFL0QsUUFBTStELHFCQUFxQixZQUFZO0FBQ3JDN0QsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTThELGdCQUFnQm5HLFlBQVlnRjtBQUFBQSxRQUNoQyxDQUFDQyxTQUFTL0YsZUFBZStGLEtBQUtDLEdBQUcsR0FBRzdGLE1BQU1DO0FBQUFBLE1BQzVDO0FBQ0EsWUFBTThHLFlBQVksQ0FBQztBQUVuQkQsb0JBQWNFLFFBQVEsQ0FBQ3BCLFNBQVM7QUFDOUIsY0FBTVcsVUFBVVgsS0FBS1c7QUFDckIsY0FBTVUsVUFDSixPQUFPVixTQUFTRSxpQkFBaUIsV0FBV0YsUUFBUUUsZUFBZSxDQUFDO0FBQ3RFLGNBQU1TLFdBQ0osT0FBT1gsU0FBU3JDLFlBQVksV0FBV3FDLFFBQVFyQyxVQUFVLENBQUM7QUFDNUQsY0FBTWlELGVBQ0paLFNBQVNZLGNBQWNDLE9BQU9iLFNBQVNZO0FBRXpDSixrQkFBVW5CLEtBQUtDLEdBQUcsSUFBSTtBQUFBLFVBQ3BCN0YsTUFBTTtBQUFBLFlBQ0pDLFFBQVE7QUFBQSxZQUNSb0gsZ0JBQWdCekIsS0FBS1UsYUFBYVcsUUFBUUssYUFBYTtBQUFBLFlBQ3ZEZCxjQUNFRCxTQUFTQyxnQkFBZ0JTLFFBQVFQLGdCQUFnQjtBQUFBLFlBQ25EYSxXQUFXM0IsS0FBSzRCLGNBQWNOLFNBQVNNLGNBQWM7QUFBQSxZQUNyREMsY0FBYzdCLEtBQUs4QixpQkFBaUI7QUFBQSxZQUNwQ0MsY0FBYy9CLEtBQUtDO0FBQUFBLFlBQ25Cc0I7QUFBQUEsWUFDQWpELFNBQVNnRCxTQUFTRSxPQUFPYixTQUFTckM7QUFBQUEsWUFDbEN1QyxjQUFjUSxRQUFRRyxPQUFPYixTQUFTRTtBQUFBQSxVQUN4QztBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNL0ksSUFBSWtLLEtBQUssdUNBQXVDYixTQUFTO0FBQy9EdkosY0FBUXFLLFFBQVEsMkNBQTJDO0FBRTNELFlBQU1DLGdCQUFnQixFQUFFLEdBQUdqSSxlQUFlO0FBQzFDaUgsb0JBQWNFLFFBQVEsQ0FBQ3BCLFNBQVMsT0FBT2tDLGNBQWNsQyxLQUFLQyxHQUFHLENBQUM7QUFDOUQvRix3QkFBa0JnSSxhQUFhO0FBQy9CaEYsMkJBQXFCLEtBQUs7QUFBQSxJQUM1QixTQUFTaUYsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQ2pCdkssY0FBUXlLLE1BQU1GLElBQUlHLFVBQVVDLE1BQU0zSyxXQUFXLDBCQUEwQjtBQUFBLElBQ3pFLFVBQUM7QUFDQ3dGLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0YseUJBQXlCQSxDQUFDQyxjQUFjO0FBQzVDLFVBQU12QixnQkFBZ0JuRyxZQUFZZ0Y7QUFBQUEsTUFDaEMsQ0FBQ0MsU0FBUy9GLGVBQWUrRixLQUFLQyxHQUFHLEdBQUc3RixNQUFNQztBQUFBQSxJQUM1QztBQUNBLFFBQUk2RyxjQUFjaEIsV0FBVyxFQUFHO0FBRWhDckksVUFBTTZLLFFBQVE7QUFBQSxNQUNaQyxPQUFPO0FBQUEsTUFDUEMsTUFBTSx1QkFBQywrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsTUFDaENDLFNBQVMsc0NBQXNDSixTQUFTLFNBQVN2QixjQUFjaEIsTUFBTTtBQUFBLE1BQ3JGNEMsUUFBUTtBQUFBLE1BQ1JDLFlBQVk7QUFBQSxNQUNaQyxNQUFNLFlBQVk7QUFDaEIxRix1QkFBZSxJQUFJO0FBQ25CLFlBQUk7QUFDRixnQkFBTTJGLFdBQVcvQixjQUFjVixJQUFJLENBQUNSLFNBQVM7QUFDM0Msa0JBQU1XLFVBQVVYLEtBQUtXO0FBQ3JCLGtCQUFNdUMsVUFBVTtBQUFBLGNBQ2Q3SSxRQUFRb0k7QUFBQUEsY0FDUmxCLGNBQWNaLFNBQVNZLGNBQWNDLE9BQU9iLFNBQVNZO0FBQUFBLGNBQ3JEakQsU0FBU3FDLFNBQVNyQyxTQUFTa0QsT0FBT2IsU0FBU3JDO0FBQUFBLFlBQzdDO0FBQ0EsbUJBQU94RyxJQUFJcUwsSUFBSSx1QkFBdUJuRCxLQUFLQyxHQUFHLElBQUlpRCxPQUFPO0FBQUEsVUFDM0QsQ0FBQztBQUNELGdCQUFNRSxRQUFRQyxJQUFJSixRQUFRO0FBQzFCckwsa0JBQVFxSztBQUFBQSxZQUNOLEdBQUdmLGNBQWNoQixNQUFNLHdCQUF3QnVDLFNBQVM7QUFBQSxVQUMxRDtBQUNBdkksNEJBQWtCLENBQUMsQ0FBQztBQUNwQjhDLHVCQUFhLEtBQUs7QUFDbEJzRywyQkFBaUI7QUFBQSxRQUNuQixTQUFTbkIsS0FBSztBQUNadkssa0JBQVF5SyxNQUFNLGlDQUFpQztBQUFBLFFBQ2pELFVBQUM7QUFDQy9FLHlCQUFlLEtBQUs7QUFBQSxRQUN0QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTWlHLGFBQWEsWUFBWTtBQUM3QixRQUFJO0FBQ0YsWUFBTWpCLFdBQVcsTUFBTXhLLElBQUkwTCxJQUFJLGdCQUFnQjtBQUMvQzFHLGVBQVN3RixTQUFTQyxRQUFRLEVBQUU7QUFBQSxJQUM5QixTQUFTRixPQUFPO0FBQ2RELGNBQVFDLE1BQU0seUJBQXlCQSxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTW9CLHVCQUF1QixPQUFPbEMsaUJBQWlCO0FBQ25ELFFBQUksQ0FBQ0EsYUFBYztBQUNuQjdFLHNCQUFrQixJQUFJO0FBQ3RCLFFBQUk7QUFDRixZQUFNNEYsV0FBVyxNQUFNeEssSUFBSTBMO0FBQUFBLFFBQ3pCLDRCQUE0QmpDLFlBQVk7QUFBQSxNQUMxQztBQUNBLFVBQUllLFNBQVNDLE1BQU1BLE1BQU1yQyxTQUFTLEdBQUc7QUFDbkMxRCwyQkFBbUI4RixTQUFTQyxLQUFLQSxLQUFLLENBQUMsRUFBRW1CLE9BQU87QUFBQSxNQUNsRCxPQUFPO0FBQ0xsSCwyQkFBbUIsQ0FBQztBQUFBLE1BQ3RCO0FBQUEsSUFDRixTQUFTNkYsT0FBTztBQUNkN0YseUJBQW1CLENBQUM7QUFBQSxJQUN0QixVQUFDO0FBQ0NFLHdCQUFrQixLQUFLO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBRUEsUUFBTWlILG9CQUFvQixPQUFPckYsWUFBWTtBQUMzQyxRQUFJLENBQUNBLFFBQVMsUUFBTztBQUNyQixRQUFJO0FBQ0YsWUFBTWdFLFdBQVcsTUFBTXhLLElBQUkwTCxJQUFJLDhCQUE4QmxGLE9BQU8sRUFBRTtBQUN0RSxhQUFPZ0UsU0FBU0MsS0FBS3JDO0FBQUFBLElBQ3ZCLFNBQVNtQyxPQUFPO0FBQ2QsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTXVCLDJCQUEyQixPQUMvQnJGLFFBQ0FzRix1QkFBdUIsU0FDcEI7QUFDSCxRQUFJO0FBQ0YsWUFBTXZCLFdBQVcsTUFBTXhLLElBQUlrSztBQUFBQSxRQUN6QixtQ0FBbUN6RCxNQUFNO0FBQUEsTUFDM0M7QUFDQSxVQUFJK0QsU0FBU0MsUUFBUUQsU0FBU0MsS0FBS3JDLFNBQVMsR0FBRztBQUM3QyxjQUFNNEQsb0JBQW9CeEIsU0FBU0MsS0FBSy9CLElBQUksT0FBT1IsU0FBUztBQUMxRCxnQkFBTStELGFBQWEvRCxNQUFNK0Q7QUFDekIsZ0JBQU1DLFlBQVlELFlBQVlFO0FBQzlCLGdCQUFNM0YsVUFBVTBGLFdBQVd4QztBQUMzQixnQkFBTTBDLGVBQWUsTUFBTVAsa0JBQWtCckYsT0FBTztBQUNwRCxnQkFBTTZGLGFBQ0pILFdBQVdJLE9BQU9DLFFBQVFMLFdBQVdJLE9BQU90RCxlQUN4QyxHQUFHa0QsVUFBVUksTUFBTUMsSUFBSSxNQUFNTCxVQUFVSSxNQUFNdEQsWUFBWSxLQUN6RGtELFdBQVdNLG1CQUFtQjVDLGFBQzVCc0MsV0FBV00sbUJBQW1CeEQsZUFDOUIsR0FBR2tELFVBQVVNLGtCQUFrQjVDLFNBQVMsTUFBTXNDLFVBQVVNLGtCQUFrQnhELFlBQVksS0FDdEZrRCxXQUFXTyxlQUFlQyxhQUN4QlIsV0FBV08sZUFBZUUsZUFDMUIsR0FBR1QsVUFBVU8sY0FBY0MsU0FBUyxNQUFNUixVQUFVTyxjQUFjRSxZQUFZLEtBQzlFO0FBRVYsaUJBQU87QUFBQSxZQUNMQyxJQUFJcEc7QUFBQUEsWUFDSnFHLGtCQUFrQlgsV0FBV1c7QUFBQUEsWUFDN0JoRCxXQUFXcUMsV0FBV3BDLGNBQWM7QUFBQSxZQUNwQ0MsY0FDRWtDLFlBQVlhLFdBQVdiLFlBQVlqQyxpQkFBaUI7QUFBQSxZQUN0RHJELFdBQVd1RixXQUFXYSxhQUNsQmIsVUFBVWEsV0FBV0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNqQztBQUFBLFlBQ0pwRyxTQUFTc0YsV0FBV2UsV0FDaEJmLFVBQVVlLFNBQVNELE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDL0I7QUFBQSxZQUNKWjtBQUFBQSxZQUNBYyxnQkFBZ0JqQjtBQUFBQSxZQUNoQnhDLGNBQWN3QyxZQUFZdkM7QUFBQUEsWUFDMUIyQztBQUFBQSxVQUNGO0FBQUEsUUFDRixDQUFDO0FBRUQsY0FBTWMsYUFBYSxNQUFNN0IsUUFBUUMsSUFBSVMsaUJBQWlCO0FBQ3RENUgsc0JBQWMrSSxVQUFVO0FBRXhCLFlBQUlBLFdBQVcvRSxTQUFTLEdBQUc7QUFDekIsY0FBSWdGLGVBQWU7QUFDbkIsY0FBSXJCLHNCQUFzQjtBQUN4QixrQkFBTXNCLGFBQWFGLFdBQVdHO0FBQUFBLGNBQzVCLENBQUNDLE1BQU1BLEVBQUU5RCxpQkFBaUJzQztBQUFBQSxZQUM1QjtBQUNBLGdCQUFJc0IsZUFBZSxJQUFJO0FBQ3JCRCw2QkFBZUM7QUFBQUEsWUFDakI7QUFBQSxVQUNGO0FBQ0EvSSxvQ0FBMEI4SSxZQUFZO0FBQ3RDLGdCQUFNSSxnQkFBZ0JMLFdBQVdDLFlBQVk7QUFDN0NuSixtQkFBU3dKLGVBQWU7QUFBQSxZQUN0QjVELFdBQVcyRCxjQUFjM0Q7QUFBQUEsWUFDekJFLGNBQWN5RCxjQUFjekQ7QUFBQUEsWUFDNUIyRCxvQkFBb0JOO0FBQUFBLFlBQ3BCekcsV0FBVzZHLGNBQWM3RztBQUFBQSxZQUN6QkMsU0FBUzRHLGNBQWM1RztBQUFBQSxZQUN2QndGLGNBQWNvQixjQUFjcEI7QUFBQUEsWUFDNUJDLFlBQVltQixjQUFjbkI7QUFBQUEsVUFDNUIsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGLE9BQU87QUFDTGpJLHNCQUFjLEVBQUU7QUFDaEJILGlCQUFTd0osZUFBZTtBQUFBLFVBQ3RCNUQsV0FBVztBQUFBLFVBQ1hFLGNBQWM7QUFBQSxVQUNkMkQsb0JBQW9CQztBQUFBQSxVQUNwQnRCLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTOUIsT0FBTztBQUNkRCxjQUFRQyxNQUFNLG9DQUFvQ0EsS0FBSztBQUN2RHpLLGNBQVF5SyxNQUFNLHlDQUF5QztBQUFBLElBQ3pEO0FBQUEsRUFDRjtBQUVBLFFBQU1xRCx3QkFBd0IsT0FBT0MsVUFBVTtBQUM3Q3ZKLDhCQUEwQnVKLEtBQUs7QUFDL0IsVUFBTUwsZ0JBQWdCckosV0FBVzBKLEtBQUs7QUFDdEMsUUFBSUwsZUFBZTtBQUNqQnZKLGVBQVN3SixlQUFlO0FBQUEsUUFDdEI1RCxXQUFXMkQsY0FBYzNEO0FBQUFBLFFBQ3pCRSxjQUFjeUQsY0FBY3pEO0FBQUFBLFFBQzVCMkQsb0JBQW9CRztBQUFBQSxRQUNwQmxILFdBQVc2RyxjQUFjN0c7QUFBQUEsUUFDekJDLFNBQVM0RyxjQUFjNUc7QUFBQUEsUUFDdkJ3RixjQUFjb0IsY0FBY3BCO0FBQUFBLFFBQzVCMEIsYUFBYU4sY0FBY08sZUFDdkJyTSxNQUFNOEwsY0FBY08sWUFBWSxJQUNoQ3JNLE1BQU07QUFBQSxRQUNWMkssWUFBWW1CLGNBQWNuQjtBQUFBQSxNQUM1QixDQUFDO0FBQ0QsWUFBTVYscUJBQXFCNkIsY0FBYy9ELFlBQVk7QUFBQSxJQUN2RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUUsc0JBQXNCLE9BQU85RixTQUFTO0FBQzFDeEUsb0JBQWdCLElBQUk7QUFDcEJjLGlCQUFhMEQsS0FBS0MsR0FBRztBQUNyQm5FLHVCQUFtQixJQUFJO0FBRXZCLFVBQU02RSxVQUFVWCxLQUFLVztBQUNyQixVQUFNVSxVQUNKLE9BQU9WLFFBQVFFLGlCQUFpQixXQUFXRixRQUFRRSxlQUFlLENBQUM7QUFDckUsVUFBTXRDLFNBQVM4QyxRQUFRRyxPQUFPYixRQUFRRTtBQUN0QyxVQUFNa0YsZ0JBQ0pwRixRQUFRYyxrQkFBa0JKLFFBQVFLLGFBQWExQixLQUFLVSxhQUFhO0FBQ25FLFVBQU1zRixpQkFBaUJyRixRQUFRQyxnQkFBZ0JTLFFBQVFQLGdCQUFnQjtBQUN2RSxVQUFNbUYsc0JBQXNCNUUsUUFBUTZFLGVBQWU7QUFFbkQsVUFBTUMsY0FBY3hGLFFBQVF5RixvQkFBb0IsQ0FBQztBQUNqRCxVQUFNQyxZQUNKRixZQUFZOUIsUUFBUThCLFlBQVl6RSxhQUFhZixRQUFRMEYsYUFBYTtBQUVwRSxVQUFNQyxzQkFDSjNGLFNBQVN5RCxPQUFPQyxRQUFRMUQsU0FBU3lELE9BQU90RCxlQUNwQyxHQUFHSCxRQUFReUQsTUFBTUMsSUFBSSxNQUFNMUQsUUFBUXlELE1BQU10RCxZQUFZLEtBQ3JESCxTQUFTMkQsbUJBQW1CNUMsYUFDMUJmLFNBQVMyRCxtQkFBbUJ4RCxlQUM1QixHQUFHSCxRQUFRMkQsa0JBQWtCNUMsU0FBUyxNQUFNZixRQUFRMkQsa0JBQWtCeEQsWUFBWSxLQUNsRkgsU0FBUzRELGVBQWVDLGFBQ3RCN0QsU0FBUzRELGVBQWVFLGVBQ3hCLEdBQUc5RCxRQUFRNEQsY0FBY0MsU0FBUyxNQUFNN0QsUUFBUTRELGNBQWNFLFlBQVksS0FDMUU5RCxRQUFRd0QsY0FBYztBQUVoQ3BJLGFBQVN3SixlQUFlO0FBQUEsTUFDdEIxRSxjQUFjdEM7QUFBQUEsTUFDZGtELGdCQUFnQnNFO0FBQUFBLE1BQ2hCbkYsY0FBY29GO0FBQUFBLE1BQ2RPLFlBQVlOO0FBQUFBLE1BQ1p0QixrQkFBa0JoRSxRQUFRZ0Usb0JBQW9CO0FBQUEsTUFDOUMwQjtBQUFBQSxNQUNBRyxhQUFhN0YsUUFBUTZGLGNBQWNoTixNQUFNbUgsUUFBUTZGLFdBQVcsSUFBSTtBQUFBLE1BQ2hFQyxhQUFhOUYsUUFBUStGLGVBQ2pCbE4sTUFBTW1ILFFBQVErRixjQUFjLE9BQU8sSUFDbkM7QUFBQSxNQUNKdkMsWUFBWW1DO0FBQUFBLE1BQ1hWLGFBQWFqRixRQUFRa0YsZUFBZXJNLE1BQU1tSCxRQUFRa0YsWUFBWSxJQUFJck0sTUFBTTtBQUFBLE1BQ3pFbUksV0FBVzNCLEtBQUs0QjtBQUFBQSxNQUNoQkMsY0FBYzdCLEtBQUs4QjtBQUFBQSxNQUNuQlAsY0FBY1osUUFBUVk7QUFBQUEsTUFDdEJqRCxTQUFTcUMsUUFBUXJDLFNBQVNrRCxPQUFPYixRQUFRckM7QUFBQUEsSUFDM0MsQ0FBQztBQUVEOUIsdUJBQW1CbUUsUUFBUWdHLFVBQVVqRCxXQUFXLENBQUM7QUFFakQsUUFBSTdHLE1BQU1xRCxXQUFXLEVBQUcsT0FBTXFELFdBQVc7QUFDekMsVUFBTUsseUJBQXlCckYsUUFBUW9DLFFBQVFZLFlBQVk7QUFFM0QsUUFBSVosUUFBUVksY0FBYztBQUN4QixZQUFNa0MscUJBQXFCOUMsUUFBUVksWUFBWTtBQUFBLElBQ2pEO0FBQUEsRUFDRjtBQUVBLFFBQU1xRix1QkFBdUJBLE1BQU07QUFDakM5Syx1QkFBbUIsS0FBSztBQUN4QkMsYUFBUzhLLFlBQVk7QUFDckIzSyxrQkFBYyxFQUFFO0FBQ2hCTSx1QkFBbUIsSUFBSTtBQUN2QkYsaUJBQWEsSUFBSTtBQUFBLEVBQ25CO0FBRUEsUUFBTXdLLG9CQUFvQixZQUFZO0FBQ3RDLFFBQUk7QUFDRixZQUFNQyxTQUFTLE1BQU1oTCxTQUFTaUwsZUFBZTtBQUM3Q3BLLHFCQUFlLElBQUk7QUFFbkIsWUFBTXFLLGFBQWE7QUFBQSxRQUNqQlQsYUFBYU8sT0FBT1AsY0FBY08sT0FBT1AsWUFBWVUsT0FBTyxZQUFZLElBQUk7QUFBQSxRQUM1RVIsY0FBY0ssT0FBT04sY0FBY00sT0FBT04sWUFBWVMsT0FBTyxPQUFPLElBQUk7QUFBQSxRQUN4RXJCLGNBQWNrQixPQUFPbkIsY0FBY21CLE9BQU9uQixZQUFZc0IsT0FBTyxZQUFZLElBQUk7QUFBQTtBQUFBLE1BQy9FO0FBRUEsWUFBTTVFLFdBQVcsTUFBTXhLLElBQUlxTCxJQUFJLHVCQUF1QjlHLFNBQVMsSUFBSTRLLFVBQVU7QUFFN0UsVUFBSTNFLFNBQVNqSSxXQUFXLEtBQUs7QUFDM0J6QyxnQkFBUXFLLFFBQVEsdUJBQXVCO0FBQ3ZDcUIseUJBQWlCO0FBQ2pCeEgsMkJBQW1CLEtBQUs7QUFBQSxNQUMxQjtBQUFBLElBQ0YsU0FBU3VHLE9BQU87QUFDZHpLLGNBQVF5SyxNQUFNLGVBQWU7QUFBQSxJQUMvQixVQUFDO0FBQ0N6RixxQkFBZSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUUsUUFBTXVLLGVBQWUsT0FBTzFFLGNBQWM7QUFDeEMsUUFBSTtBQUNGN0YscUJBQWUsSUFBSTtBQUNuQixZQUFNbUssU0FBUyxNQUFNaEwsU0FBU2lMLGVBQWU7QUFDN0MsWUFBTUksYUFBYUwsT0FBT3ZCLHNCQUFzQnJKO0FBQ2hELFlBQU1tSixnQkFBZ0JySixXQUFXbUwsVUFBVTtBQUUzQyxVQUFJLENBQUM5QixlQUFlO0FBQ2xCMU4sZ0JBQVF5SyxNQUFNLHVEQUF1RDtBQUNyRXpGLHVCQUFlLEtBQUs7QUFDcEI7QUFBQSxNQUNGO0FBRUEsWUFBTTRKLGNBQWNPLE9BQU9QLGFBQWFVLE9BQU8sWUFBWTtBQUMzRCxZQUFNVCxjQUFjTSxPQUFPTixhQUFhUyxPQUFPLE9BQU87QUFDdEQsWUFBTXRCLGNBQWNtQixPQUFPbkIsYUFBYXNCLE9BQU8sWUFBWTtBQUUzRCxZQUFNaEUsVUFBVTtBQUFBLFFBQ2RyQyxjQUFja0csT0FBT2xHO0FBQUFBLFFBQ3JCWSxnQkFBZ0JzRixPQUFPdEY7QUFBQUEsUUFDdkJiLGNBQWNtRyxPQUFPbkc7QUFBQUEsUUFDckIyRixZQUFZUSxPQUFPUjtBQUFBQSxRQUNuQjVFLFdBQVcyRCxjQUFjM0Q7QUFBQUEsUUFDekJFLGNBQWN5RCxjQUFjekQ7QUFBQUEsUUFDNUIyRTtBQUFBQSxRQUNBRSxjQUFjRDtBQUFBQSxRQUNkQTtBQUFBQSxRQUNBdEMsWUFBWTRDLE9BQU81QztBQUFBQSxRQUNuQmtELGFBQWFOLE9BQU81QztBQUFBQSxRQUNwQjdGLFNBQVNnSCxjQUFjWjtBQUFBQSxRQUN2Qm5ELGNBQWMrRCxjQUFjL0Q7QUFBQUEsUUFDNUJsSCxRQUFRb0k7QUFBQUEsUUFDUm1EO0FBQUFBLE1BQ0Y7QUFFQSxZQUFNOU4sSUFBSXFMLElBQUksdUJBQXVCOUcsU0FBUyxJQUFJNkcsT0FBTztBQUV6RCxZQUFNb0UsaUJBQWlCO0FBQUEsUUFDckJDLFNBQVM7QUFBQSxRQUNUQyxRQUFRO0FBQUEsUUFDUkMsUUFBUTtBQUFBLFFBQ1JDLGFBQWE7QUFBQSxRQUNiQyxRQUFRO0FBQUEsTUFDVjtBQUVBL1AsY0FBUXFLO0FBQUFBLFFBQ05xRixlQUFlN0UsU0FBUyxLQUFLLHFCQUFxQkEsU0FBUztBQUFBLE1BQzdEO0FBRUFtRSwyQkFBcUI7QUFDckJ0RCx1QkFBaUI7QUFBQSxJQUNuQixTQUFTakIsT0FBTztBQUNkRCxjQUFRQyxNQUFNLGlCQUFpQkEsS0FBSztBQUNwQyxVQUFJdUYsZUFBZTtBQUNuQixVQUFJdkYsTUFBTUMsVUFBVUMsTUFBTTNLLFNBQVM7QUFDakNnUSx1QkFBZXZGLE1BQU1DLFNBQVNDLEtBQUszSztBQUFBQSxNQUNyQyxXQUFXeUssTUFBTUMsVUFBVUMsTUFBTXNGLFFBQVE7QUFDdkNELHVCQUFlRSxPQUFPZixPQUFPMUUsTUFBTUMsU0FBU0MsS0FBS3NGLE1BQU0sRUFDcERFLEtBQUssRUFDTEMsS0FBSyxJQUFJO0FBQUEsTUFDZCxXQUFXM0YsTUFBTTRGLGFBQWE7QUFDNUJMLHVCQUFldkYsTUFBTTRGLFlBQ2xCekgsSUFBSSxDQUFDMEgsTUFBTSxHQUFHQSxFQUFFN0QsS0FBSzJELEtBQUssR0FBRyxDQUFDLEtBQUtFLEVBQUVMLE9BQU9HLEtBQUssSUFBSSxDQUFDLEVBQUUsRUFDeERBLEtBQUssSUFBSTtBQUFBLE1BQ2Q7QUFDQXBRLGNBQVF5SyxNQUFNdUYsWUFBWTtBQUFBLElBQzVCLFVBQUM7QUFDQ2hMLHFCQUFlLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUwsbUJBQW1CLFlBQVk7QUFDbkMsVUFBTWhCLGFBQWEsU0FBUztBQUFBLEVBQzlCO0FBQ0EsUUFBTWlCLGtCQUFrQixZQUFZO0FBQ2xDLFVBQU1qQixhQUFhLFFBQVE7QUFBQSxFQUM3QjtBQUNBLFFBQU1rQixrQkFBa0IsWUFBWTtBQUNsQyxVQUFNbEIsYUFBYSxRQUFRO0FBQUEsRUFDN0I7QUFDQSxRQUFNbUIsdUJBQXVCLFlBQVk7QUFDdkMsVUFBTW5CLGFBQWEsYUFBYTtBQUFBLEVBQ2xDO0FBQ0EsUUFBTW9CLGtCQUFrQixZQUFZO0FBQ2xDLFVBQU1wQixhQUFhLFFBQVE7QUFBQSxFQUM3QjtBQUVBLFFBQU1xQixtQkFBbUIsWUFBWTtBQUNuQyxRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNM1EsSUFBSTBMLElBQUksd0JBQXdCO0FBQ3ZEcEksZ0JBQVVxTixTQUFTbEcsUUFBUSxFQUFFO0FBQUEsSUFDL0IsU0FBU0YsT0FBTztBQUNkRCxjQUFRQyxNQUFNLCtCQUErQkEsS0FBSztBQUFBLElBQ3BEO0FBQUEsRUFDRjtBQUVBLFFBQU1xRyxhQUFhQSxDQUFDMUksU0FBUztBQUMzQjhGLHdCQUFvQjlGLElBQUk7QUFBQSxFQUMxQjtBQUVBLFFBQU0ySSxjQUFjQSxDQUFDM0ksU0FBUztBQUM1QnhFLG9CQUFnQixJQUFJO0FBQ3BCLFVBQU1vTixjQUFjQyxPQUFPQyxTQUFTQztBQUNwQyxVQUFNQyxVQUFVLEdBQUdKLFdBQVcsc0JBQXNCNUksS0FBS0MsR0FBRztBQUM1RDRJLFdBQU9JLEtBQUtELFNBQVMsUUFBUTtBQUFBLEVBQy9CO0FBRUEsUUFBTUUsY0FBY0EsQ0FBQ2xKLFNBQVM7QUFDNUJ4RSxvQkFBZ0IsSUFBSTtBQUNwQixVQUFNMk4sY0FBY04sT0FBT0ksS0FBSyxJQUFJLFFBQVE7QUFDNUMsVUFBTUcsZUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQWdCb0JwSixLQUFLMkUsZ0JBQWdCO0FBQUEsNENBQ3RCM0UsS0FBS1UsU0FBUztBQUFBLHVDQUNuQlYsS0FBSzRCLFVBQVU7QUFBQSwwQ0FDWjVCLEtBQUs4QixhQUFhO0FBQUEseUNBQ25COUIsS0FBS3FKLFlBQVk7QUFBQSwwREFDQXJKLEtBQUtzSixnQkFBZ0I7QUFBQSw0Q0FDbkN0SixLQUFLMEQsT0FBTztBQUFBLG1DQUNyQixPQUFPMUQsS0FBSzNGLFdBQVcsV0FBVzJGLEtBQUszRixPQUFPa1AsTUFBTUMsV0FBV3hKLEtBQUszRixNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLekc4TyxnQkFBWU0sU0FBU0MsTUFBTU4sWUFBWTtBQUN2Q0QsZ0JBQVlNLFNBQVNFLE1BQU07QUFDM0JSLGdCQUFZUyxNQUFNO0FBQUEsRUFDcEI7QUFFQSxRQUFNQyxnQkFBZ0JBLENBQUNuRixPQUFPO0FBQzVCbEosb0JBQWdCLElBQUk7QUFDcEJuRCxhQUFTcUssUUFBUTtBQUFBLE1BQ2ZDLE9BQU87QUFBQSxNQUNQRSxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JnSCxRQUFRO0FBQUEsTUFDUi9HLFlBQVk7QUFBQSxNQUNaQyxPQUFPO0FBQ0wrRyxxQkFBYXJGLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNcUYsZUFBZSxPQUFPckYsT0FBTztBQUNqQyxRQUFJO0FBQ0YsWUFBTTVNLElBQUlrUyxPQUFPLHVCQUF1QnRGLEVBQUUsRUFBRTtBQUM1QzlNLGNBQVFxSyxRQUFRLGtDQUFrQztBQUNsRHFCLHVCQUFpQjtBQUFBLElBQ25CLFNBQVNqQixPQUFPO0FBQ2R6SyxjQUFReUssTUFBTSw4QkFBOEI7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNNEgscUJBQXFCQyxZQUFZLENBQUM1UCxHQUFHb0ssT0FBTztBQUNoRHBLLE1BQUU2UCxnQkFBZ0I7QUFDbEI3UCxNQUFFOFAsZUFBZTtBQUVqQixVQUFNQyxPQUFPL1AsRUFBRWdRLGNBQWNDLHNCQUFzQjtBQUVuRC9PLG9CQUFnQixDQUFDZ1AsV0FBVztBQUMxQixVQUFJQSxXQUFXOUYsSUFBSTtBQUNqQixlQUFPO0FBQUEsTUFDVCxPQUFPO0FBQ0xoSix1QkFBZTtBQUFBLFVBQ2JDLEtBQUswTyxLQUFLSSxTQUFTNUIsT0FBTzZCLFVBQVU7QUFBQSxVQUNwQzlPLE1BQU15TyxLQUFLTSxRQUFRO0FBQUEsUUFDckIsQ0FBQztBQUNELGVBQU9qRztBQUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUU7QUFFTCxRQUFNcEIsbUJBQW1CLFlBQVk7QUFDbkNoSSxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNc1AsU0FBUyxDQUFDO0FBQ2hCLFVBQUl4TSxRQUFRTyxTQUFVaU0sUUFBT2xOLE9BQU9VLFFBQVFPO0FBQzVDLFVBQUlQLFFBQVFFLFFBQVNzTSxRQUFPdE0sVUFBVUYsUUFBUUU7QUFDOUMsVUFBSUYsUUFBUUcsT0FBUXFNLFFBQU9yTSxTQUFTSCxRQUFRRztBQUM1QyxVQUFJSCxRQUFRL0QsT0FBUXVRLFFBQU92USxTQUFTK0QsUUFBUS9EO0FBQzVDLFVBQUkrRCxRQUFRSSxjQUFlb00sUUFBT3BNLGdCQUFnQkosUUFBUUk7QUFDMUQsVUFBSUosUUFBUUssVUFBV21NLFFBQU9uTSxZQUFZTCxRQUFRSztBQUNsRCxVQUFJTCxRQUFRTSxRQUFTa00sUUFBT2xNLFVBQVVOLFFBQVFNO0FBRTlDLFlBQU00RCxXQUFXLE1BQU14SyxJQUFJMEwsSUFBSSx3QkFBd0IsRUFBRW9ILE9BQU8sQ0FBQztBQUlqRSxVQUFJdEksU0FBU0MsUUFBUUQsU0FBU0MsS0FBS0EsTUFBTTtBQUN2Q3JILDhCQUFzQm9ILFNBQVNDLEtBQUtBLElBQUk7QUFFeEMsY0FBTXNJLGdCQUFnQnZJLFNBQVNDLEtBQUtBLEtBQUsvQixJQUFJLENBQUNSLE1BQU0yRixVQUFVO0FBQzVELGdCQUFNbUYsYUFBYTlLLE1BQU1hLGdCQUFnQixDQUFDO0FBQzFDLGdCQUFNa0ssY0FBYy9LLE1BQU0xQixXQUFXLENBQUM7QUFFdEMsZ0JBQU0wTSxpQkFBaUJoTCxNQUFNMkcsVUFBVWpELFdBQVc7QUFDbEQsZ0JBQU11SCxrQkFBa0JqTCxNQUFNaUwsbUJBQW1CO0FBQ2pELGdCQUFNQyxnQkFBZ0JsTCxNQUFNbUwsVUFBVTtBQUVyQyxnQkFBTUMsYUFBYXBMLE1BQU0yRyxVQUFVMEUsZUFBZXJMLE1BQU1xTCxlQUFlO0FBQ3hFLGdCQUFNQyxlQUFlQSxDQUFDalIsV0FBVztBQUUvQixrQkFBTWtSLGVBQWVsUixXQUFXLFlBQVksV0FBV0E7QUFFdkQsa0JBQU1tUixlQUFlO0FBQUEsY0FDbkJqRSxTQUFTO0FBQUEsY0FDVEMsUUFBUTtBQUFBLGNBQ1JDLFFBQVE7QUFBQSxjQUNSZ0UsU0FBUztBQUFBO0FBQUEsY0FDVC9ELGFBQWE7QUFBQSxjQUNiQyxRQUFRO0FBQUEsWUFDVjtBQUNBLG1CQUNFLHVCQUFDLE9BQUksT0FBTzZELGFBQWFELFlBQVksS0FBSyxXQUN2Q0EsMkJBQWlCLFdBQVcsV0FBV2xSLFVBQVUsYUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBRUo7QUFFQSxpQkFBTztBQUFBLFlBQ0w0RixLQUFLRCxLQUFLd0I7QUFBQUEsWUFDVmtELElBQUlpQixRQUFRO0FBQUEsWUFDWmhCLGtCQUFrQjNFLEtBQUsyRSxvQkFBb0IsTUFBTWdCLFFBQVEsQ0FBQztBQUFBLFlBQzFERSxjQUFjN0YsTUFBTTZGLGVBQ2xCck0sTUFBTXdHLEtBQUs2RixZQUFZLEVBQUVxQixPQUFPLFlBQVksSUFDNUM7QUFBQSxZQUNGd0Usa0JBQWtCMUwsS0FBSzZGO0FBQUFBLFlBQ3ZCbkYsV0FDRVYsS0FBS3lCLG1CQUNKLE9BQU9xSixlQUFlLFdBQVdBLFdBQVdwSixZQUFZO0FBQUEsWUFDM0RFLFlBQ0U1QixLQUFLMkIsY0FDSixPQUFPb0osZ0JBQWdCLFdBQ3BCQSxZQUFZbkosYUFDWjtBQUFBLFlBQ05FLGVBQWU5QixLQUFLNkIsZ0JBQWdCO0FBQUEsWUFDcEN3SCxjQUFjckosS0FBS3dHLGNBQ2ZoTixNQUFNd0csS0FBS3dHLFdBQVcsRUFBRVUsT0FBTyxZQUFZLElBQzNDO0FBQUEsWUFDSlIsY0FBYzFHLEtBQUswRyxlQUNmbE4sTUFBTXdHLEtBQUswRyxjQUFjLE9BQU8sRUFBRVEsT0FBTyxRQUFRLElBQ2pEO0FBQUEsWUFFSmlFLFFBQVFEO0FBQUFBLFlBQ1JTLFlBQVlUO0FBQUFBLFlBQ1o1QixrQkFDRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQ0UyQixtQkFBbUIsSUFDZixpQ0FDQTtBQUFBLGdCQUNMO0FBQUE7QUFBQSxrQkFFRUEsZ0JBQWdCVyxlQUFlLE9BQU87QUFBQTtBQUFBO0FBQUEsY0FQM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxZQUVGQyxzQkFBc0JaO0FBQUFBLFlBRXRCdkgsU0FDRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQ0VzSCxrQkFBa0IsSUFDZCxpQ0FDQTtBQUFBLGdCQUNMO0FBQUE7QUFBQSxrQkFFRUEsZUFBZVksZUFBZSxPQUFPO0FBQUE7QUFBQTtBQUFBLGNBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsWUFFRkUsYUFBYWQ7QUFBQUEsWUFFYkssYUFDQSx1QkFBQyxVQUFLLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxjQUN6Q0QsV0FBV1EsZUFBZSxPQUFPO0FBQUEsaUJBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVGRyxpQkFBaUJYO0FBQUFBLFlBRWYvUSxRQUFRaVIsYUFBYXRMLEtBQUszRixNQUFNO0FBQUEsWUFDaEMyUixZQUFZaE0sS0FBSzNGLFVBQVU7QUFBQSxZQUMzQmdOLGFBQWFySCxLQUFLcUgsZUFBZTtBQUFBLFlBQ2pDNEUsbUJBQW1Cak0sS0FBS2tNLGdCQUFnQkMsWUFDcEMzUyxNQUFNd0csS0FBS2tNLGVBQWVDLFNBQVMsRUFBRWpGLE9BQU8sWUFBWSxJQUN4RDtBQUFBLFlBQ0p2RyxTQUFTWDtBQUFBQSxZQUNUb00sUUFDRSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLENBQUM5UixNQUFNMlAsbUJBQW1CM1AsR0FBRzBGLEtBQUt3QixHQUFHO0FBQUEsZ0JBQzlDLFdBQVU7QUFBQSxnQkFDVixjQUFXO0FBQUEsZ0JBQVM7QUFBQTtBQUFBLGNBSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFVBRUo7QUFBQSxRQUNGLENBQUM7QUFFRDFHLDBCQUFrQitQLGFBQWE7QUFDL0I3UCx1QkFBZTZQLGFBQWE7QUFFNUJ3QiwwQkFBa0IvSixTQUFTQyxLQUFLQSxJQUFJO0FBQ3BDK0osNEJBQW9CaEssU0FBU0MsS0FBS0EsSUFBSTtBQUFBLE1BQ3hDO0FBQUEsSUFDRixTQUFTRixPQUFPO0FBQ2R2SCx3QkFBa0IsRUFBRTtBQUNwQkUscUJBQWUsRUFBRTtBQUNqQkUsNEJBQXNCLEVBQUU7QUFDeEJzQyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaN0YsU0FBUztBQUFBLFFBQ1Q4RixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0Q2TztBQUFBQSxRQUNFLE1BQU0vTyxlQUFlLENBQUNqRCxVQUFVLEVBQUUsR0FBR0EsTUFBTWtELFlBQVksTUFBTSxFQUFFO0FBQUEsUUFDL0Q7QUFBQSxNQUNGO0FBQ0EyRSxjQUFRQyxNQUFNLGdDQUFnQ0EsS0FBSztBQUFBLElBQ3JELFVBQUM7QUFDQy9HLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQWtSLFlBQVUsTUFBTTtBQUNkLFVBQU1DLHFCQUFxQkEsQ0FBQ0MsVUFBVTtBQUNwQyxVQUNFblIsZ0JBQ0EsQ0FBQ21SLE1BQU1sUyxPQUFPbVMsUUFBUSxtQkFBbUIsS0FDekMsQ0FBQ0QsTUFBTWxTLE9BQU9tUyxRQUFRLGdCQUFnQixHQUN0QztBQUNBblIsd0JBQWdCLElBQUk7QUFBQSxNQUN0QjtBQUFBLElBQ0Y7QUFDQWlPLGFBQVNtRCxpQkFBaUIsYUFBYUgsa0JBQWtCO0FBQ3pELFdBQU8sTUFBTWhELFNBQVNvRCxvQkFBb0IsYUFBYUosa0JBQWtCO0FBQUEsRUFDM0UsR0FBRyxDQUFDbFIsWUFBWSxDQUFDO0FBRWpCaVIsWUFBVSxNQUFNO0FBQ2QsVUFBTU0sYUFDSi9SLFlBQVltRixTQUFTLEtBQ3JCbkYsWUFBWWdTLE1BQU0sQ0FBQy9NLFNBQVMvRixlQUFlK0YsS0FBS0MsR0FBRyxHQUFHN0YsTUFBTUMsTUFBTTtBQUNwRTJDLGlCQUFhOFAsVUFBVTtBQUFBLEVBQ3pCLEdBQUcsQ0FBQy9SLGFBQWFkLGNBQWMsQ0FBQztBQUVoQyxRQUFNK1MscUJBQXFCQSxNQUFNO0FBQy9CM08sZUFBVztBQUFBLE1BQ1RDLFNBQVNNO0FBQUFBLE1BQ1RMLFFBQVFILFFBQVFHO0FBQUFBLE1BQ2hCbEUsUUFBUXlFO0FBQUFBLE1BQ1JOLGVBQWVRO0FBQUFBLE1BQ2ZQLFdBQVdTLGVBQWVBLGFBQWFnSSxPQUFPLFlBQVksSUFBSTtBQUFBLE1BQzlEeEksU0FBU1UsYUFBYUEsV0FBVzhILE9BQU8sWUFBWSxJQUFJO0FBQUEsTUFDeER2SSxVQUFVUCxRQUFRTztBQUFBQSxJQUNwQixDQUFDO0FBQ0R6RSxzQkFBa0IsQ0FBQyxDQUFDO0FBQ3BCOEMsaUJBQWEsS0FBSztBQUNsQnBGLFlBQVFxSyxRQUFRLGlCQUFpQjtBQUFBLEVBQ25DO0FBRUEsUUFBTWdMLHFCQUFxQkEsTUFBTTtBQUMvQnBPLG1CQUFlLEVBQUU7QUFDakJFLGtCQUFjLEVBQUU7QUFDaEJFLHlCQUFxQixFQUFFO0FBQ3ZCRSxvQkFBZ0IsSUFBSTtBQUNwQkUsa0JBQWMsSUFBSTtBQUNsQmhCLGVBQVc7QUFBQSxNQUNUQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JsRSxRQUFRO0FBQUEsTUFDUm1FLGVBQWU7QUFBQSxNQUNmQyxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RDLFVBQVU7QUFBQSxJQUNaLENBQUM7QUFDRHpFLHNCQUFrQixDQUFDLENBQUM7QUFDcEI4QyxpQkFBYSxLQUFLO0FBQ2xCcEYsWUFBUXFLLFFBQVEsaUJBQWlCO0FBQUEsRUFDbkM7QUFFQSxRQUFNaUwsNEJBQTRCQSxDQUFDM0ssU0FBUztBQUMxQyxVQUFNMUUsZ0JBQWdCMEUsTUFBTXJDLFVBQVU7QUFDdEMsVUFBTW5DLGtCQUNKd0UsTUFBTXhDLE9BQU8sQ0FBQ0MsU0FBU0EsTUFBTWdNLGVBQWUsU0FBUyxHQUFHOUwsVUFBVTtBQUNwRSxVQUFNbEMsaUJBQ0p1RSxNQUFNeEMsT0FBTyxDQUFDQyxTQUFTQSxNQUFNZ00sZUFBZSxRQUFRLEdBQUc5TCxVQUFVO0FBQ25FLFVBQU1qQyxpQkFDSnNFLE1BQU14QyxPQUFPLENBQUNDLFNBQVNBLE1BQU1nTSxlQUFlLFFBQVEsR0FBRzlMLFVBQVU7QUFDbkUsVUFBTWhDLHNCQUNKcUUsTUFBTXhDLE9BQU8sQ0FBQ0MsU0FBU0EsTUFBTWdNLGVBQWUsYUFBYSxHQUFHOUwsVUFBVTtBQUN4RSxVQUFNL0IsaUJBQ0pvRSxNQUFNeEMsT0FBTyxDQUFDQyxTQUFTQSxNQUFNZ00sZUFBZSxRQUFRLEdBQUc5TCxVQUFVO0FBRW5FLFVBQU1wQyxrQkFDSnlFLE1BQU00SyxPQUFPLENBQUNDLEtBQUtwTixTQUFTb04sT0FBT3BOLE1BQU04TCxlQUFlLElBQUksQ0FBQyxLQUFLO0FBRXBFbE8sZ0JBQVk7QUFBQSxNQUNWQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTWtQLDhCQUE4QkEsQ0FBQzlLLFNBQVM7QUFDNUMsVUFBTStLLFdBQVcsb0JBQUlDLElBQUk7QUFFekJoTCxTQUFLbkIsUUFBUSxDQUFDcEIsU0FBUztBQUNyQixZQUFNMkIsWUFBWTNCLEtBQUs0QjtBQUN2QixVQUFJLENBQUNELGFBQWFBLGNBQWMsTUFBTztBQUV2QyxVQUFJLENBQUMyTCxTQUFTRSxJQUFJN0wsU0FBUyxHQUFHO0FBQzVCMkwsaUJBQVNHLElBQUk5TCxXQUFXO0FBQUEsVUFDdEJBO0FBQUFBLFVBQ0ErTCxPQUFPO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RDLFFBQVE7QUFBQSxVQUNSQyxRQUFRO0FBQUEsVUFDUkMsYUFBYTtBQUFBLFVBQ2JDLFFBQVE7QUFBQSxVQUNSQyxjQUFjO0FBQUEsUUFDaEIsQ0FBQztBQUFBLE1BQ0g7QUFFQSxZQUFNQyxRQUFRWCxTQUFTOUosSUFBSTdCLFNBQVM7QUFDcENzTSxZQUFNUDtBQUNOTyxZQUFNRCxnQkFBZ0JoTyxLQUFLOEwsZUFBZTtBQUUxQyxjQUFROUwsS0FBS2dNLFlBQVU7QUFBQSxRQUNyQixLQUFLO0FBQ0hpQyxnQkFBTU47QUFDTjtBQUFBLFFBQ0YsS0FBSztBQUNITSxnQkFBTUw7QUFDTjtBQUFBLFFBQ0YsS0FBSztBQUNISyxnQkFBTUo7QUFDTjtBQUFBLFFBQ0YsS0FBSztBQUNISSxnQkFBTUg7QUFDTjtBQUFBLFFBQ0YsS0FBSztBQUNIRyxnQkFBTUY7QUFDTjtBQUFBLFFBQ0Y7QUFDRTtBQUFBLE1BQ0o7QUFBQSxJQUNGLENBQUM7QUFFRHBPLGtCQUFjdU8sTUFBTUMsS0FBS2IsU0FBU3ZHLE9BQU8sQ0FBQyxDQUFDO0FBQUEsRUFDN0M7QUFFQSxRQUFNc0Ysb0JBQW9CQSxDQUFDOUosU0FBUztBQUNsQyxVQUFNMUUsZ0JBQWdCMEUsTUFBTXJDLFVBQVU7QUFDdEMsVUFBTW5DLGtCQUNKd0UsTUFBTXhDLE9BQU8sQ0FBQ0MsU0FBU0EsTUFBTTNGLFdBQVcsU0FBUyxHQUFHNkYsVUFBVTtBQUNoRSxVQUFNbEMsaUJBQ0p1RSxNQUFNeEMsT0FBTyxDQUFDQyxTQUFTQSxNQUFNM0YsV0FBVyxRQUFRLEdBQUc2RixVQUFVO0FBQy9ELFVBQU1qQyxpQkFDSnNFLE1BQU14QyxPQUFPLENBQUNDLFNBQVNBLE1BQU0zRixXQUFXLFFBQVEsR0FBRzZGLFVBQVU7QUFDL0QsVUFBTWhDLHNCQUNKcUUsTUFBTXhDLE9BQU8sQ0FBQ0MsU0FBU0EsTUFBTTNGLFdBQVcsYUFBYSxHQUFHNkYsVUFBVTtBQUNwRSxVQUFNL0IsaUJBQ0pvRSxNQUFNeEMsT0FBTyxDQUFDQyxTQUFTQSxNQUFNM0YsV0FBVyxRQUFRLEdBQUc2RixVQUFVO0FBRS9ELFVBQU1wQyxrQkFDSnlFLE1BQU00SztBQUFBQSxNQUNKLENBQUNDLEtBQUtwTixTQUFTb04sT0FBT3BOLE1BQU1vTyxVQUFVdFEsbUJBQW1CO0FBQUEsTUFDekQ7QUFBQSxJQUNGLEtBQUs7QUFFSixVQUFNdVEsa0JBQWtCOUwsTUFBTTRLO0FBQUFBLE1BQ2pDLENBQUNDLEtBQUtwTixTQUFTb04sT0FBT3BOLE1BQU0yRyxVQUFVMEUsZUFBZXJMLE1BQU1xTCxlQUFlO0FBQUEsTUFDMUU7QUFBQSxJQUNGLEtBQUs7QUFFSHpOLGdCQUFZO0FBQUEsTUFDVkM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQ3VRO0FBQUFBLE1BQ0R0UTtBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTW1PLHNCQUFzQkEsQ0FBQy9KLFNBQVM7QUFDcEMsVUFBTStLLFdBQVcsb0JBQUlDLElBQUk7QUFFekJoTCxTQUFLbkIsUUFBUSxDQUFDcEIsU0FBUztBQUNyQixZQUFNK0ssY0FBYy9LLE1BQU0xQixXQUFXLENBQUM7QUFDdEMsWUFBTXFELFlBQ0ozQixNQUFNMkIsY0FDTCxPQUFPb0osZ0JBQWdCLFdBQVdBLGFBQWFuSixhQUFhO0FBQy9ELFVBQUksQ0FBQ0QsVUFBVztBQUVoQixVQUFJLENBQUMyTCxTQUFTRSxJQUFJN0wsU0FBUyxHQUFHO0FBQzVCMkwsaUJBQVNHLElBQUk5TCxXQUFXO0FBQUEsVUFDdEJBO0FBQUFBLFVBQ0ErTCxPQUFPO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RDLFFBQVE7QUFBQSxVQUNSQyxRQUFRO0FBQUEsVUFDUkMsYUFBYTtBQUFBLFVBQ2JDLFFBQVE7QUFBQSxVQUNSQyxjQUFjO0FBQUEsVUFDZE0saUJBQWlCO0FBQUEsUUFDbkIsQ0FBQztBQUFBLE1BQ0g7QUFFQSxZQUFNTCxRQUFRWCxTQUFTOUosSUFBSTdCLFNBQVM7QUFDcENzTSxZQUFNUDtBQUNOTyxZQUFNRCxnQkFBZ0JoTyxLQUFLMkcsVUFBVWpELFdBQVc7QUFFaEQsY0FBUTFELEtBQUszRixRQUFNO0FBQUEsUUFDakIsS0FBSztBQUNINFQsZ0JBQU1OO0FBQ047QUFBQSxRQUNGLEtBQUs7QUFDSE0sZ0JBQU1MO0FBQ047QUFBQSxRQUNGLEtBQUs7QUFDSEssZ0JBQU1KO0FBQ047QUFBQSxRQUNGLEtBQUs7QUFDSEksZ0JBQU1IO0FBQ047QUFBQSxRQUNGLEtBQUs7QUFDSEcsZ0JBQU1GO0FBQ047QUFBQSxRQUNGO0FBQ0U7QUFBQSxNQUNKO0FBRUEsWUFBTVEsV0FBV3ZPLEtBQUtrTSxnQkFBZ0JDO0FBQ3RDLFVBQUlvQyxZQUFZTixNQUFNSyxvQkFBb0IsT0FBTztBQUMvQyxjQUFNRSxjQUFjaFYsTUFBTStVLFFBQVE7QUFDbEMsWUFBSUMsWUFBWUMsUUFBUSxHQUFHO0FBQ3pCUixnQkFBTUssa0JBQWtCRSxZQUFZdEgsT0FBTyxZQUFZO0FBQUEsUUFDekQ7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBRUR2SCxrQkFBY3VPLE1BQU1DLEtBQUtiLFNBQVN2RyxPQUFPLENBQUMsQ0FBQztBQUFBLEVBQzdDO0FBRUF5RixZQUFVLE1BQU07QUFDZGhFLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMZ0UsWUFBVSxNQUFNO0FBQ2RsSixxQkFBaUI7QUFBQSxFQUNuQixHQUFHLEVBQUU7QUFFTGtKLFlBQVUsTUFBTTtBQUNkLFFBQUkzUixlQUFlcUYsU0FBUyxHQUFHO0FBQzdCLFVBQUl3TyxXQUFXLENBQUMsR0FBRzdULGNBQWM7QUFFakMsVUFBSXVELFFBQVFFLFNBQVM7QUFDbkIsY0FBTWdILGdCQUFnQm5LLE9BQU93VCxLQUFLLENBQUN0SixNQUFNQSxFQUFFN0QsUUFBUXBELFFBQVFFLE9BQU87QUFDbEUsWUFBSWdILGVBQWU7QUFDakJvSixxQkFBV0EsU0FBUzNPO0FBQUFBLFlBQ2xCLENBQUNDLFNBQVNBLEtBQUs0QixlQUFlMEQsY0FBYzFEO0FBQUFBLFVBQzlDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxVQUFJeEQsUUFBUS9ELFFBQVE7QUFDbEJxVSxtQkFBV0EsU0FBUzNPO0FBQUFBLFVBQ2xCLENBQUNDLFNBQVNBLEtBQUtnTSxlQUFlNU4sUUFBUS9EO0FBQUFBLFFBQ3hDO0FBQUEsTUFDRjtBQUVBLFVBQUkrRCxRQUFRSSxlQUFlO0FBQ3pCa1EsbUJBQVdBLFNBQVMzTyxPQUFPLENBQUNDLFNBQVM7QUFDbkMsZ0JBQU0wRCxVQUFVMUQsS0FBSzhMO0FBQ3JCLGNBQUkxTixRQUFRSSxrQkFBa0IsVUFBVyxRQUFPa0YsVUFBVTtBQUMxRCxjQUFJdEYsUUFBUUksa0JBQWtCLFdBQVksUUFBT2tGLFdBQVc7QUFDNUQsaUJBQU87QUFBQSxRQUNULENBQUM7QUFBQSxNQUNIO0FBRUEsVUFBSXRGLFFBQVFLLGFBQWFMLFFBQVFNLFNBQVM7QUFDeENnUSxtQkFBV0EsU0FBUzNPLE9BQU8sQ0FBQ0MsU0FBUztBQUNuQyxjQUFJLENBQUNBLEtBQUswTCxpQkFBa0IsUUFBTztBQUNuQyxnQkFBTWtELFdBQVdwVixNQUFNd0csS0FBSzBMLGdCQUFnQjtBQUU1QyxjQUFJdE4sUUFBUUssV0FBVztBQUNyQixrQkFBTUEsWUFBWWpGLE1BQU00RSxRQUFRSyxTQUFTO0FBQ3pDLGdCQUFJbVEsU0FBU0MsU0FBU3BRLFdBQVcsS0FBSyxFQUFHLFFBQU87QUFBQSxVQUNsRDtBQUVBLGNBQUlMLFFBQVFNLFNBQVM7QUFDbkIsa0JBQU1BLFVBQVVsRixNQUFNNEUsUUFBUU0sT0FBTztBQUNyQyxnQkFBSWtRLFNBQVNFLFFBQVFwUSxTQUFTLEtBQUssRUFBRyxRQUFPO0FBQUEsVUFDL0M7QUFFQSxpQkFBTztBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0g7QUFFQTFELHFCQUFlMFQsUUFBUTtBQUN2QnhCLGdDQUEwQndCLFFBQVE7QUFDbENyQixrQ0FBNEJxQixRQUFRO0FBQUEsSUFDdEMsV0FBVzdULGVBQWVxRixXQUFXLEtBQUssQ0FBQzdFLFdBQVc7QUFDcERMLHFCQUFlLEVBQUU7QUFDakJrUyxnQ0FBMEIsRUFBRTtBQUM1Qkcsa0NBQTRCLEVBQUU7QUFBQSxJQUNoQztBQUFBLEVBQ0YsR0FBRyxDQUFDalAsU0FBU3ZELGdCQUFnQk0sTUFBTSxDQUFDO0FBRXBDLFFBQU00VCxnQkFBZ0JBLE1BQU07QUFDMUIsVUFBTUMsYUFBYWpVLFlBQVl5RixJQUFJLENBQUNSLFVBQVU7QUFBQSxNQUM1QyxTQUFTQSxLQUFLMEU7QUFBQUEsTUFDZCxvQkFBb0IxRSxLQUFLMkU7QUFBQUEsTUFDekIsZ0JBQWdCM0UsS0FBSzZGO0FBQUFBLE1BQ3JCLG1CQUFtQjdGLEtBQUtVO0FBQUFBLE1BQ3hCLGNBQWNWLEtBQUs0QjtBQUFBQSxNQUNuQixpQkFBaUI1QixLQUFLOEI7QUFBQUEsTUFDdEIsZ0JBQWdCOUIsS0FBS3FKO0FBQUFBLE1BQ3JCNEYsUUFBUWpQLEtBQUttTDtBQUFBQSxNQUNiLGdCQUFnQm5MLEtBQUswRztBQUFBQSxNQUNyQixpQ0FBaUMxRyxLQUFLc0o7QUFBQUEsTUFDdEMsbUJBQW1CdEosS0FBSzBEO0FBQUFBLE1BQ3hCd0wsUUFDRSxPQUFPbFAsS0FBSzNGLFdBQVcsV0FDbkIyRixLQUFLM0YsT0FBT2tQLE1BQU1DLFdBQ2xCeEosS0FBSzNGO0FBQUFBLElBQ2IsRUFBRTtBQUVGLFVBQU04VSxLQUFLMVYsS0FBSzJWLE1BQU1DLGNBQWNMLFVBQVU7QUFDOUMsVUFBTU0sS0FBSzdWLEtBQUsyVixNQUFNRyxTQUFTO0FBQy9COVYsU0FBSzJWLE1BQU1JLGtCQUFrQkYsSUFBSUgsSUFBSSxjQUFjO0FBQ25EMVYsU0FBS2dXO0FBQUFBLE1BQ0hIO0FBQUFBLE1BQ0EsdUJBQXVCOVYsTUFBTSxFQUFFME4sT0FBTyxZQUFZLENBQUM7QUFBQSxJQUNyRDtBQUNBdFAsWUFBUXFLLFFBQVEsb0NBQW9DO0FBQUEsRUFDdEQ7QUFFQSxRQUFNeU4sY0FBY0EsTUFBTTtBQUN4QixVQUFNQyxNQUFNLElBQUlqVyxNQUFNLFdBQVc7QUFFakNpVyxRQUFJQyxZQUFZLEVBQUU7QUFDbEJELFFBQUlFLEtBQUssdUJBQXVCLElBQUksRUFBRTtBQUN0Q0YsUUFBSUMsWUFBWSxFQUFFO0FBQ2xCRCxRQUFJRSxLQUFLLGlCQUFpQnJXLE1BQU0sRUFBRTBOLE9BQU8scUJBQXFCLENBQUMsSUFBSSxJQUFJLEVBQUU7QUFFekUsVUFBTTRJLFlBQVkvVSxZQUFZeUY7QUFBQUEsTUFBSSxDQUFDUixTQUFTO0FBQUEsUUFDMUNBLEtBQUswRTtBQUFBQSxRQUNMMUUsS0FBSzJFO0FBQUFBLFFBQ0wzRSxLQUFLNkY7QUFBQUEsUUFDTDdGLEtBQUtVO0FBQUFBLFFBQ0xWLEtBQUs0QjtBQUFBQSxRQUNMNUIsS0FBSzhCO0FBQUFBLFFBQ0w5QixLQUFLcUo7QUFBQUEsUUFDTHJKLEtBQUtzSjtBQUFBQSxRQUNMdEosS0FBSzBEO0FBQUFBLFFBQ0wsT0FBTzFELEtBQUszRixXQUFXLFdBQ25CMkYsS0FBSzNGLE9BQU9rUCxNQUFNQyxXQUNsQnhKLEtBQUszRjtBQUFBQSxNQUFNO0FBQUEsSUFDaEI7QUFFRHNWLFFBQUlJLFVBQVU7QUFBQSxNQUNaQyxNQUFNO0FBQUEsUUFDSjtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFBUTtBQUFBLE1BQ1Q7QUFBQSxNQUVIQyxNQUFNSDtBQUFBQSxNQUNOSSxRQUFRO0FBQUEsTUFDUkMsUUFBUSxFQUFFQyxVQUFVLEVBQUU7QUFBQSxNQUN0QkMsWUFBWSxFQUFFQyxXQUFXLENBQUMsSUFBSSxLQUFLLEdBQUcsRUFBRTtBQUFBLElBQzFDLENBQUM7QUFFRFgsUUFBSVksS0FBSyx1QkFBdUIvVyxNQUFNLEVBQUUwTixPQUFPLFlBQVksQ0FBQyxNQUFNO0FBQ2xFdFAsWUFBUXFLLFFBQVEsa0NBQWtDO0FBQUEsRUFDcEQ7QUFFQSxRQUFNdU8sY0FBY0EsTUFBTTtBQUN4QixVQUFNckgsY0FBY04sT0FBT0ksS0FBSyxJQUFJLFFBQVE7QUFDNUMsVUFBTXdILGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1REFnQitCalgsTUFBTSxFQUFFME4sT0FBTyxxQkFBcUIsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FNL0N2SixTQUFTRSxhQUFhO0FBQUEsK0NBQ3BCRixTQUFTSSxlQUFlO0FBQUEsOENBQ3pCSixTQUFTSyxjQUFjO0FBQUEsOENBQ3ZCTCxTQUFTTSxjQUFjO0FBQUEsOENBQ3ZCTixTQUFTUSxjQUFjO0FBQUEsNENBQ3pCUixTQUFTTyxtQkFBbUI7QUFBQSxpREFDdkJQLFNBQVNHLGdCQUFnQjhOLGVBQWUsT0FBTyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBcUJuRjdRLFlBQ0N5RjtBQUFBQSxNQUNDLENBQUNSLFNBQVM7QUFBQTtBQUFBLHNCQUVKQSxLQUFLMEUsRUFBRTtBQUFBLHNCQUNQMUUsS0FBSzJFLGdCQUFnQjtBQUFBLHNCQUNyQjNFLEtBQUs2RixZQUFZO0FBQUEsc0JBQ2pCN0YsS0FBS1UsU0FBUztBQUFBLHNCQUNkVixLQUFLNEIsVUFBVTtBQUFBLHNCQUNmNUIsS0FBSzhCLGFBQWE7QUFBQSxzQkFDbEI5QixLQUFLcUosWUFBWTtBQUFBLHNCQUNqQnJKLEtBQUtzSixnQkFBZ0I7QUFBQSxzQkFDckJ0SixLQUFLMEQsT0FBTztBQUFBLHNCQUNaLE9BQU8xRCxLQUFLM0YsV0FBVyxXQUFXMkYsS0FBSzNGLE9BQU9rUCxNQUFNQyxXQUFXeEosS0FBSzNGLE1BQU07QUFBQTtBQUFBO0FBQUEsSUFHbEYsRUFDQzJOLEtBQUssRUFBRSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU9uQm1CLGdCQUFZTSxTQUFTQyxNQUFNK0csV0FBVztBQUN0Q3RILGdCQUFZTSxTQUFTRSxNQUFNO0FBQzNCUixnQkFBWVMsTUFBTTtBQUFBLEVBQ3BCO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNck0sWUFBWUc7QUFBQUEsUUFDbEIsV0FBV0gsWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWTNGO0FBQUFBO0FBQUFBLE1BSHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUcrQjtBQUFBLElBRy9CLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSw4Q0FDWjtBQUFBLGlDQUFDLFdBQVEsV0FBVSxtQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0M7QUFBQSxVQUFHO0FBQUEsYUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNDLGlDQUFDLFVBQU8sTUFBTSx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVksR0FBSyxTQUFTMEwsa0JBQWtCLHVCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsaUNBQUMsa0JBQWUsV0FBVSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUN6Qyx1QkFBQyxRQUFHLFdBQVUsMkNBQTBDLDhCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSx3REFBdUQsMEJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTyxFQUFFakQsT0FBTyxPQUFPO0FBQUEsa0JBQ3ZCLE9BQU9uQjtBQUFBQSxrQkFDUCxVQUFVQztBQUFBQSxrQkFDVixRQUFPO0FBQUEsa0JBQ1AsYUFBWTtBQUFBLGtCQUNaLE1BQUs7QUFBQTtBQUFBLGdCQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1jO0FBQUEsY0FFZDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPLEVBQUVrQixPQUFPLE9BQU87QUFBQSxrQkFDdkIsT0FBT2pCO0FBQUFBLGtCQUNQLFVBQVVDO0FBQUFBLGtCQUNWLFFBQU87QUFBQSxrQkFDUCxhQUFZO0FBQUEsa0JBQ1osTUFBSztBQUFBO0FBQUEsZ0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTWM7QUFBQSxpQkFmaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHdEQUF1RCwrQkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsT0FBT1QsZUFBZTZHO0FBQUFBLGdCQUN0QixVQUFVLENBQUNpTCxRQUFRN1IsZUFBZTZSLE9BQU8sRUFBRTtBQUFBLGdCQUMzQyxNQUFLO0FBQUEsZ0JBRUp2VixpQkFBT3FGO0FBQUFBLGtCQUFJLENBQUM2RSxNQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxFQUFFN0QsS0FDakM2RCxZQUFFekQsY0FEZXlELEVBQUU3RCxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHdEQUF1RCw4QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsT0FBTzFDLGNBQWMyRztBQUFBQSxnQkFDckIsVUFBVSxDQUFDaUwsUUFBUTNSLGNBQWMyUixPQUFPLEVBQUU7QUFBQSxnQkFDMUMsTUFBSztBQUFBLGdCQUVMO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxXQUFVLHVCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUN0Qyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQ3BDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUyxzQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQSxrQkFDcEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxlQUFjLDRCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQztBQUFBLGtCQUMvQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUE7QUFBQTtBQUFBLGNBWnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSx3REFBdUQsOEJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQSxnQkFDVjtBQUFBLGdCQUNBLE9BQU8xUixxQkFBcUJ5RztBQUFBQSxnQkFDNUIsVUFBVSxDQUFDaUwsUUFBUXpSLHFCQUFxQnlSLE9BQU8sRUFBRTtBQUFBLGdCQUNqRCxNQUFLO0FBQUEsZ0JBRUw7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFdBQVUsK0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDO0FBQUEsa0JBQzlDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sWUFBVywwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEM7QUFBQTtBQUFBO0FBQUEsY0FUNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxvRUFBbUUsMEJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBUzNUO0FBQUFBLGdCQUNULFVBQVUsQ0FBQ3pDLE1BQU07QUFDZix3QkFBTUcsVUFBVUgsRUFBRUUsT0FBT0M7QUFDekJ1QywrQkFBYXZDLE9BQU87QUFDcEIsd0JBQU1rVyxVQUFVLEVBQUUsR0FBRzFXLGVBQWU7QUFDcENjLDhCQUFZcUcsUUFBUSxDQUFDcEIsU0FBUztBQUM1QjJRLDRCQUFRM1EsS0FBS0MsR0FBRyxJQUFJO0FBQUEsc0JBQ2xCN0YsTUFBTTtBQUFBLHdCQUNKQyxRQUFRSTtBQUFBQSx3QkFDUlYsVUFBVWlHLEtBQUtVO0FBQUFBLHdCQUNmMUcsV0FDRWdHLEtBQUtXLFNBQVNDLGdCQUNkWixLQUFLVyxTQUFTRSxjQUFjQyxnQkFDNUI7QUFBQSxzQkFDSjtBQUFBLG9CQUNGO0FBQUEsa0JBQ0YsQ0FBQztBQUNENUcsb0NBQWtCeVcsT0FBTztBQUFBLGdCQUMzQjtBQUFBO0FBQUEsY0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcUJJLEtBdEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUNyQixTQUFTM0Q7QUFBQUEsZ0JBQ1QsTUFBSztBQUFBLGdCQUFPO0FBQUE7QUFBQSxjQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFDQSx1QkFBQyxVQUFPLFNBQVNDLG9CQUFvQixNQUFLLFNBQVEscUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQTdIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEhBO0FBQUEsV0F0SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVJQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtGQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHNCQUFxQiw4QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRCx1QkFBQyxRQUFHLFdBQVUsMkJBQ1h0UCxtQkFBU0UsaUJBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsc0ZBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsc0JBQXFCLGdDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xELHVCQUFDLFFBQUcsV0FBVSwyQkFDWEYsbUJBQVNJLG1CQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHNGQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHNCQUFxQiwrQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxRQUFHLFdBQVUsMkJBQ1hKLG1CQUFTSyxrQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpRkFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSxzQkFBcUIsK0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsUUFBRyxXQUFVLDJCQUNYTCxtQkFBU00sa0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsc0ZBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsc0JBQXFCLCtCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2pELHVCQUFDLFFBQUcsV0FBVSwyQkFDWE4sbUJBQVNRLGtCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLG9GQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHNCQUFxQiw0QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxRQUFHLFdBQVUsMkJBQ1hSLG1CQUFTTyx1QkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMENBO0FBQUEsTUFFQzRCLGdCQUFnQixLQUNmLHVCQUFDLFNBQUksV0FBVSw0SEFDYixpQ0FBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsOEdBQ1pBLDJCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0MsOEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQU0sdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQSxjQUN2QixNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixTQUFTaUI7QUFBQUEsY0FDVCxTQUFTNUQ7QUFBQUEsY0FBVTtBQUFBO0FBQUEsWUFOckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU1xRix1QkFBdUIsUUFBUTtBQUFBLGNBQzlDLFNBQVNuRjtBQUFBQSxjQUFZO0FBQUE7QUFBQSxZQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZTtBQUFBLGNBQ3JCLFNBQVMsTUFBTW1GLHVCQUF1QixRQUFRO0FBQUEsY0FDOUMsU0FBU25GO0FBQUFBLGNBQVk7QUFBQTtBQUFBLFlBTHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNbUYsdUJBQXVCLFFBQVE7QUFBQSxjQUM5QyxTQUFTbkY7QUFBQUEsY0FBWTtBQUFBO0FBQUEsWUFKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU1tRix1QkFBdUIsU0FBUztBQUFBLGNBQy9DLFNBQVNuRjtBQUFBQSxjQUFZO0FBQUE7QUFBQSxZQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTW1GLHVCQUF1QixhQUFhO0FBQUEsY0FDbkQsU0FBU25GO0FBQUFBLGNBQVk7QUFBQTtBQUFBLFlBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9EQTtBQUFBLFdBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4REEsS0EvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdFQTtBQUFBLE1BR0YsdUJBQUMsUUFBSyxXQUFXdUMsV0FBVyxVQUFVQyxjQUFjLFdBQVUsUUFDNUQsaUNBQUMsV0FBUSxLQUFJLHFCQUNWeEUsc0JBQ0MsdUJBQUMsa0JBQWUsV0FBVyxNQUFNLE1BQUssa0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0QsSUFDbEROLFlBQVltRixVQUFVLElBQ3hCLHVCQUFDLFNBQU0sYUFBWSwrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QyxJQUU5QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTUs7QUFBQUEsVUFDTjtBQUFBLFVBQ0EsWUFBWUQ7QUFBQUEsVUFDWixpQkFBZ0I7QUFBQSxVQUNoQixrQkFBaUI7QUFBQTtBQUFBLFFBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUsyQyxLQVhWLFFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXJSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc1JBO0FBQUEsSUFFQy9FLGdCQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixPQUFPO0FBQUEsVUFDTHFWLFVBQVU7QUFBQSxVQUNWQyxRQUFRO0FBQUEsVUFDUmxWLEtBQUssR0FBR0YsWUFBWUUsR0FBRztBQUFBLFVBQ3ZCQyxNQUFNLEdBQUdILFlBQVlHLElBQUk7QUFBQSxRQUMzQjtBQUFBLFFBQ0EsU0FBUyxDQUFDdEIsTUFBTUEsRUFBRTZQLGdCQUFnQjtBQUFBLFFBRWhDLGlCQUFNO0FBQ04sZ0JBQU1uSyxPQUFPbkYsZUFBZThULEtBQUssQ0FBQ21DLFFBQVFBLElBQUk3USxRQUFRMUUsWUFBWTtBQUNsRSxjQUFJLENBQUN5RSxLQUFNLFFBQU87QUFDbEIsaUJBQ0UsbUNBQ0U7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsQ0FBQzFGLE1BQU07QUFDZEEsb0JBQUU2UCxnQkFBZ0I7QUFDbEJ6Qiw2QkFBVzFJLElBQUk7QUFBQSxnQkFDakI7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFhO0FBQUEsa0JBQ2IsdUJBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFVO0FBQUE7QUFBQTtBQUFBLGNBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxDQUFDMUYsTUFBTTtBQUNkQSxvQkFBRTZQLGdCQUFnQjtBQUNsQnhCLDhCQUFZM0ksSUFBSTtBQUFBLGdCQUNsQjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlCO0FBQUEsa0JBQ2pCLHVCQUFDLFVBQUsscUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBVztBQUFBO0FBQUE7QUFBQSxjQVJiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsQ0FBQzFGLE1BQU07QUFDZEEsb0JBQUU2UCxnQkFBZ0I7QUFDbEJqQiw4QkFBWWxKLElBQUk7QUFBQSxnQkFDbEI7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQjtBQUFBLGtCQUNoQix1QkFBQyxVQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVc7QUFBQTtBQUFBO0FBQUEsY0FSYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLENBQUMxRixNQUFNO0FBQ2RBLG9CQUFFNlAsZ0JBQWdCO0FBQ2xCTixnQ0FBYzdKLEtBQUtDLEdBQUc7QUFBQSxnQkFDeEI7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUEsa0JBQ2YsdUJBQUMsVUFBSyxzQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFZO0FBQUE7QUFBQTtBQUFBLGNBUmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlDQTtBQUFBLFFBRUosR0FBRztBQUFBO0FBQUEsTUF6REw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMERBO0FBQUEsSUFHRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLG1DQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGLE1BQU1YO0FBQUFBLFFBQ04sVUFBVSxNQUFNQyxpQkFBaUIsS0FBSztBQUFBLFFBQ3RDLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUVOQywrQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT0Esa0JBQWtCbUY7QUFBQUE7QUFBQUEsWUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRTRDO0FBQUEsVUFFNUM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU9uRixrQkFBa0JrQjtBQUFBQTtBQUFBQSxZQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFcUM7QUFBQSxVQUVyQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT2xCLGtCQUFrQm9CLGdCQUFnQjtBQUFBO0FBQUEsWUFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRWlEO0FBQUEsVUFFakQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU9wQixrQkFBa0JvQztBQUFBQTtBQUFBQSxZQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFc0M7QUFBQSxVQUV0QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT3BDLGtCQUFrQnNDO0FBQUFBO0FBQUFBLFlBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUV5QztBQUFBLFVBRXpDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPdEMsa0JBQWtCcUc7QUFBQUE7QUFBQUEsWUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRXdDO0FBQUEsVUFFeEM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU9yRyxrQkFBa0I2SjtBQUFBQTtBQUFBQSxZQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFd0M7QUFBQSxVQUV4QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBTzdKLGtCQUFrQmtIO0FBQUFBO0FBQUFBLFlBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUV3QztBQUFBLFVBRXhDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPbEgsa0JBQWtCOEo7QUFBQUE7QUFBQUEsWUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRTRDO0FBQUEsVUFFNUM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU85SixrQkFBa0JrRTtBQUFBQTtBQUFBQSxZQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFbUM7QUFBQSxVQUVuQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT2xFLGtCQUFrQnlNO0FBQUFBO0FBQUFBLFlBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUU2QztBQUFBLFVBRTdDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPek0sa0JBQWtCNkg7QUFBQUE7QUFBQUEsWUFGM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRXVDO0FBQUEsVUFFdkMsdUJBQUMsY0FBVyxPQUFNLFVBQVMsT0FBTzdILGtCQUFrQm5GLFVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsYUFqRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrREE7QUFBQTtBQUFBLE1BOURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWdFQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLG1DQUNiLGlDQUFDLFFBQUcsV0FBVSx3RUFBdUUsZ0NBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUYsTUFBTXdCO0FBQUFBLFFBQ04sVUFBVStLO0FBQUFBLFFBQ1YsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsZ0JBQWM7QUFBQSxRQUVkLGlDQUFDLFFBQUssTUFBTTdLLFVBQVUsUUFBTyxZQUFXLFdBQVUsUUFDaEQ7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw4Q0FBNkMsa0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwrRkFDYjtBQUFBLHFDQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssZ0JBQWUsUUFBTSxNQUNuQyxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQU0sS0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QyxnQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssb0JBQW1CLFdBQVUsUUFDM0M7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0M7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRXVELEtBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QyxrQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssYUFBWSxXQUFVLFFBQ3BDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUV1RCxLQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsK0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGtCQUFpQixXQUFVLFFBQ3pDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUV1RCxLQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsNkJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGdCQUFlLFdBQVUsUUFDdkM7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0M7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRXVELEtBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QywyQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssY0FBYSxXQUFVLFFBQ3JDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUV1RCxLQUh6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGlCQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJEQTtBQUFBLFlBRUNFLFdBQVdpRSxTQUFTLElBQ25CLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsZ0JBQ3RCO0FBQUEsZ0JBQzdCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQyxLQUFLO0FBQUEsZ0JBQUw7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBTyxDQUFDLEVBQUU2USxVQUFVLE1BQU1uWixTQUFTLFlBQVksQ0FBQztBQUFBLGtCQUNoRCxXQUFVO0FBQUEsa0JBRVY7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsYUFBWTtBQUFBLHNCQUNaLFVBQVU4TjtBQUFBQSxzQkFDVixPQUFPdko7QUFBQUEsc0JBQ1AsV0FBVTtBQUFBLHNCQUNWLE1BQUs7QUFBQSxzQkFFSkYscUJBQVd1RTtBQUFBQSx3QkFBSSxDQUFDeUQsT0FBTzBCLFVBQ3RCLHVCQUFDLFVBQXNCLE9BQU9BLE9BQzNCMUI7QUFBQUEsZ0NBQU10QztBQUFBQSwwQkFBVTtBQUFBLDBCQUFXc0MsTUFBTXBDO0FBQUFBLDBCQUFhO0FBQUEsNkJBRHBDb0MsTUFBTVMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUE7QUFBQSxvQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBWUE7QUFBQTtBQUFBLGdCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FrQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMENBQXlDLGdDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxhQUFZLFdBQVUsUUFDcEM7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0M7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRXlFLEtBSDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsOEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLFdBQVUsV0FBVSxRQUNsQztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQztBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFeUUsS0FIM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBDQUF5Qyw2QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssZ0JBQWUsV0FBVSxRQUN2QztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQztBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFb0YsS0FIdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBDQUF5Qyw2QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssZ0JBQWUsV0FBVSxRQUN2QztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQztBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFNEQsS0FIOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxtQkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2Q0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QywwQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssYUFBWSxXQUFVLFFBQ3BDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUU0RCxLQUg5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGlCQWhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlGQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxREFDYixpQ0FBQyxRQUFLLE1BQUssU0FBUSxLQUFJLDhCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF2Sko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5SkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDhDQUE2QywrQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSwwQ0FBeUM7QUFBQTtBQUFBLGtCQUMzQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDLEtBQUs7QUFBQSxrQkFBTDtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPLENBQUMsRUFBRXFNLFVBQVUsTUFBTW5aLFNBQVMsWUFBWSxDQUFDO0FBQUEsb0JBQ2hELFdBQVU7QUFBQSxvQkFFVjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPLEVBQUV5SSxPQUFPLE9BQU87QUFBQSx3QkFDdkIsV0FBVTtBQUFBLHdCQUNWLFFBQU87QUFBQTtBQUFBLHNCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHcUI7QUFBQTtBQUFBLGtCQVJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxtQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QztBQUFBO0FBQUEsa0JBQzNDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUMsS0FBSztBQUFBLGtCQUFMO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8sQ0FBQyxFQUFFMFEsVUFBVSxNQUFNblosU0FBUyxZQUFZLENBQUM7QUFBQSxvQkFDaEQsV0FBVTtBQUFBLG9CQUVWO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU8sRUFBRXlJLE9BQU8sT0FBTztBQUFBLHdCQUN2QixXQUFVO0FBQUEsd0JBQ1YsUUFBTztBQUFBLHdCQUNQLFlBQVU7QUFBQTtBQUFBLHNCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJWTtBQUFBO0FBQUEsa0JBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVdBO0FBQUEsbUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsMENBQXlDLDRCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxlQUFjLFdBQVUsUUFDdEM7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTyxFQUFFQSxPQUFPLE9BQU87QUFBQSxvQkFDdkIsV0FBVTtBQUFBLG9CQUNWLFFBQU87QUFBQTtBQUFBLGtCQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHcUIsS0FKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4Q0E7QUFBQSxlQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1EQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHVDQUFzQyxvQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0M1RCxpQkFDQyx1QkFBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQixJQUVsQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsc0JBQXNCRixtQkFBbUIsSUFBSSxtQkFBbUIsY0FBYztBQUFBLGdCQUV4RkEsOEJBQW9CLE9BQ2pCLEtBQUtBLGdCQUFnQnFQLGVBQWUsT0FBTyxDQUFDLEtBQzVDO0FBQUE7QUFBQSxjQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFFQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGdCQUFlLFFBQU0sTUFDbkMsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFNLEtBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxXQUFVLFFBQU0sTUFDOUIsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFNLEtBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsOENBQTZDLDZCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sV0FBV3pEO0FBQUFBLGtCQUNYLFFBQU87QUFBQSxrQkFDUCxZQUFXO0FBQUEsa0JBRVg7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVN4TDtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBQ1YsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQjtBQUFBLHNCQUMxQixVQUFVVixXQUFXaUUsV0FBVztBQUFBLHNCQUNoQyxPQUFLO0FBQUE7QUFBQTtBQUFBLG9CQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBO0FBQUEsZ0JBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZ0JBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sV0FBV2tJO0FBQUFBLGtCQUNYLFFBQU87QUFBQSxrQkFDUCxZQUFXO0FBQUEsa0JBRVg7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVN6TDtBQUFBQSxzQkFDVCxVQUFVVixXQUFXaUUsV0FBVztBQUFBLHNCQUNoQyxXQUFVO0FBQUEsc0JBQ1YsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQjtBQUFBLHNCQUMxQixPQUFLO0FBQUE7QUFBQTtBQUFBLG9CQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBO0FBQUEsZ0JBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZ0JBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sV0FBV3FJO0FBQUFBLGtCQUNYLFFBQU87QUFBQSxrQkFDUCxZQUFXO0FBQUEsa0JBRVg7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVM1TDtBQUFBQSxzQkFDVCxVQUFVVixXQUFXaUUsV0FBVztBQUFBLHNCQUNoQyxXQUFVO0FBQUEsc0JBQ1YsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFlO0FBQUEsc0JBQ3JCLE9BQUs7QUFBQTtBQUFBO0FBQUEsb0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUE7QUFBQSxnQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FnQkE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixXQUFXbUk7QUFBQUEsa0JBQ1gsUUFBTztBQUFBLGtCQUNQLFlBQVc7QUFBQSxrQkFFWDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0w7QUFBQSxzQkFDQSxTQUFTMUw7QUFBQUEsc0JBQ1QsV0FBVTtBQUFBLHNCQUNWLE1BQU0sdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBYztBQUFBLHNCQUNwQixVQUFVVixXQUFXaUUsV0FBVztBQUFBLHNCQUNoQyxPQUFLO0FBQUE7QUFBQTtBQUFBLG9CQVBQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVQTtBQUFBO0FBQUEsZ0JBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLFdBQVdvSTtBQUFBQSxrQkFDWCxRQUFPO0FBQUEsa0JBQ1AsWUFBVztBQUFBLGtCQUVYO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTDtBQUFBLHNCQUNBLFNBQVMzTDtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBQ1YsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFhO0FBQUEsc0JBQ25CLFVBQVVWLFdBQVdpRSxXQUFXO0FBQUEsc0JBQ2hDLE9BQUs7QUFBQTtBQUFBO0FBQUEsd0JBR0wsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFHO0FBQUEsd0JBQUc7QUFBQTtBQUFBO0FBQUEsb0JBVlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVlBO0FBQUE7QUFBQSxnQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTMEc7QUFBQUEsa0JBQ1QsV0FBVTtBQUFBLGtCQUNWLE9BQUs7QUFBQTtBQUFBO0FBQUEsZ0JBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixhQUFZO0FBQUEsa0JBQ1osV0FBV0U7QUFBQUEsa0JBQ1gsUUFBTztBQUFBLGtCQUNQLFlBQVc7QUFBQSxrQkFFWDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBU25LO0FBQUFBLHNCQUNULFdBQVU7QUFBQSxzQkFDVixNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWE7QUFBQSxzQkFDbkIsVUFBVVYsV0FBV2lFLFdBQVc7QUFBQSxzQkFDaEMsT0FBSztBQUFBO0FBQUE7QUFBQSxvQkFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQTtBQUFBLGdCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQSxpQkFuSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvSEE7QUFBQSxlQXhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlIQTtBQUFBLGFBcFdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxV0E7QUFBQTtBQUFBLE1BblhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9YQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1qRDtBQUFBQSxRQUNOLFVBQVUrRDtBQUFBQSxRQUNWLFFBQVE7QUFBQSxRQUNSO0FBQUEsUUFDQSxPQUFPO0FBQUEsUUFFUCxpQ0FBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsU0FBSSxXQUFVLGlDQUNiLGlDQUFDLG9CQUFpQixXQUFVLDZCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRCxLQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLHlDQUF3Qyw2QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQjtBQUFBO0FBQUEsWUFDVztBQUFBLFlBQzNDLHVCQUFDLFVBQUssV0FBVSwyQkFDYmxCO0FBQUFBO0FBQUFBLGNBQWM7QUFBQSxpQkFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQU87QUFBQSxZQUVQLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBRztBQUFBLFlBQUc7QUFBQSxlQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNrQjtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGNBSGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsU0FBUzdEO0FBQUFBLGdCQUNULFNBQVM4RDtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQXVEO0FBQUE7QUFBQSxjQUxuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsYUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9DQTtBQUFBO0FBQUEsTUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNENBO0FBQUEsT0FqMEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrMEJBO0FBRUo7QUFBRXJHLEdBNWhFSUQsa0JBQWdCO0FBQUEsVUFZRHZELEtBQUs0RSxPQUFPO0FBQUE7QUFBQWdWLE1BWjNCclc7QUE4aEVOLE1BQU1zVyxhQUFhQSxDQUFDLEVBQUVDLE9BQU9DLE1BQU0sTUFDakMsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEseUJBQUMsVUFBSyxXQUFVLGdFQUNiRCxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFBQSxFQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FDYkMsbUJBQVMsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFBQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FPQTtBQUNBQyxNQVRJSDtBQVdOLGVBQWV0VztBQUFpQixJQUFBRCxJQUFBc1csS0FBQUk7QUFBQUMsYUFBQTNXLElBQUE7QUFBQTJXLGFBQUFMLEtBQUE7QUFBQUssYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTWVtbyIsIkZvcm0iLCJJbnB1dCIsIkRhdGVQaWNrZXIiLCJUaW1lUGlja2VyIiwiQnV0dG9uIiwiU2VsZWN0IiwiUG9wY29uZmlybSIsIlNwaW4iLCJtZXNzYWdlIiwiTW9kYWwiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiVGFnIiwiVG9vbHRpcCIsIkVtcHR5IiwiQW50TW9kYWwiLCJUYWJzIiwiU3BhY2UiLCJGYUdhdmVsIiwiSW9NZFJlZnJlc2giLCJGaWx0ZXJPdXRsaW5lZCIsIkVkaXRPdXRsaW5lZCIsIlNoYXJlQWx0T3V0bGluZWQiLCJQcmludGVyT3V0bGluZWQiLCJEZWxldGVPdXRsaW5lZCIsIlNlYXJjaE91dGxpbmVkIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkNoZWNrQ2lyY2xlT3V0bGluZWQiLCJDbG9zZU91dGxpbmVkIiwiU3RvcE91dGxpbmVkIiwiVHJvcGh5T3V0bGluZWQiLCJXaGF0c0FwcE91dGxpbmVkIiwiRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCIsIlNhdmVPdXRsaW5lZCIsImRheWpzIiwiWExTWCIsImpzUERGIiwiVGFiUGFuZSIsIk9wdGlvbiIsIlNlbGVjdGlvbkNoZWNrYm94IiwiaXRlbUtleSIsInVzZXJOYW1lIiwidXNlclBob25lIiwiYWN0aXZlVXNlckRhdGEiLCJzZXRBY3RpdmVVc2VyRGF0YSIsImlzQ2hlY2tlZCIsImluZm8iLCJzdGF0dXMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJfYyIsIkJpZFJlcXVlc3RSZXBvcnQiLCJfcyIsImFsbEJpZFJlcXVlc3RzIiwic2V0QWxsQmlkUmVxdWVzdHMiLCJiaWRSZXF1ZXN0cyIsInNldEJpZFJlcXVlc3RzIiwicmF3QmlkUmVxdWVzdHNEYXRhIiwic2V0UmF3QmlkUmVxdWVzdHNEYXRhIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwib3BlbkFjdGlvbklkIiwic2V0T3BlbkFjdGlvbklkIiwiZHJvcGRvd25Qb3MiLCJzZXREcm9wZG93blBvcyIsInRvcCIsImxlZnQiLCJpc0VkaXRNb2RhbE9wZW4iLCJzZXRJc0VkaXRNb2RhbE9wZW4iLCJlZGl0Rm9ybSIsInVzZUZvcm0iLCJlZGl0R3JvdXBzIiwic2V0RWRpdEdyb3VwcyIsInNlbGVjdGVkRWRpdEdyb3VwSW5kZXgiLCJzZXRTZWxlY3RlZEVkaXRHcm91cEluZGV4IiwiZWRpdGluZ0lkIiwic2V0RWRpdGluZ0lkIiwiY3VzdG9tZXJCYWxhbmNlIiwic2V0Q3VzdG9tZXJCYWxhbmNlIiwibG9hZGluZ0JhbGFuY2UiLCJzZXRMb2FkaW5nQmFsYW5jZSIsImVkaXRMb2FkaW5nIiwic2V0RWRpdExvYWRpbmciLCJ1c2VycyIsInNldFVzZXJzIiwic2VsZWN0QWxsIiwic2V0U2VsZWN0QWxsIiwiaXNWZXJpZnlNb2RhbE9wZW4iLCJzZXRJc1ZlcmlmeU1vZGFsT3BlbiIsImlzU2VuZGluZyIsInNldElzU2VuZGluZyIsImJ1bGtMb2FkaW5nIiwic2V0QnVsa0xvYWRpbmciLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsInR5cGUiLCJvdmVydmlldyIsInNldE92ZXJ2aWV3IiwidG90YWxSZXF1ZXN0cyIsInRvdGFsUGFpZEFtb3VudCIsInBlbmRpbmdSZXF1ZXN0cyIsImFjY2VwdFJlcXVlc3RzIiwicmVqZWN0UmVxdWVzdHMiLCJuZXh0QXVjdGlvblJlcXVlc3RzIiwicHJpemVkUmVxdWVzdHMiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsImdyb3VwSWQiLCJ1c2VySWQiLCJwYXltZW50U3RhdHVzIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsInZpZXdUeXBlIiwidGVtcEdyb3VwSWQiLCJzZXRUZW1wR3JvdXBJZCIsInRlbXBTdGF0dXMiLCJzZXRUZW1wU3RhdHVzIiwidGVtcFBheW1lbnRTdGF0dXMiLCJzZXRUZW1wUGF5bWVudFN0YXR1cyIsInRlbXBGcm9tRGF0ZSIsInNldFRlbXBGcm9tRGF0ZSIsInRlbXBUb0RhdGUiLCJzZXRUZW1wVG9EYXRlIiwic2hvd01vZGFsVmlldyIsInNldFNob3dNb2RhbFZpZXciLCJjdXJyZW50QmlkUmVxdWVzdCIsInNldEN1cnJlbnRCaWRSZXF1ZXN0IiwiZ3JvdXBTdGF0cyIsInNldEdyb3VwU3RhdHMiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJzZWxlY3RlZENvdW50IiwiZmlsdGVyIiwiaXRlbSIsImtleSIsImxlbmd0aCIsImNvbHVtbnMiLCJoZWFkZXIiLCJ3aWR0aCIsImV4cG9ydENvbHVtbnMiLCJkaXNwbGF5QmlkUmVxdWVzdHMiLCJtYXAiLCJjaGVja0JveCIsInVzZXJfbmFtZSIsInJhd0RhdGEiLCJtb2JpbGVOdW1iZXIiLCJzdWJzY3JpYmVySWQiLCJwaG9uZV9udW1iZXIiLCJoYW5kbGVPcGVuVmVyaWZ5TW9kYWwiLCJoYW5kbGVDbG9zZVZlcmlmeU1vZGFsIiwiaGFuZGxlU2VuZFdoYXRzQXBwIiwic2VsZWN0ZWRJdGVtcyIsInJlY2VpdmVycyIsImZvckVhY2giLCJ1c2VyT2JqIiwiZ3JvdXBPYmoiLCJlbnJvbGxtZW50SWQiLCJfaWQiLCJzdWJzY3JpYmVyTmFtZSIsImZ1bGxfbmFtZSIsImdyb3VwTmFtZSIsImdyb3VwX25hbWUiLCJ0aWNrZXROdW1iZXIiLCJ0aWNrZXRfbnVtYmVyIiwiYmlkUmVxdWVzdElkIiwicG9zdCIsInN1Y2Nlc3MiLCJuZXdBY3RpdmVEYXRhIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwicmVzcG9uc2UiLCJkYXRhIiwiaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZSIsIm5ld1N0YXR1cyIsImNvbmZpcm0iLCJ0aXRsZSIsImljb24iLCJjb250ZW50Iiwib2tUZXh0IiwiY2FuY2VsVGV4dCIsIm9uT2siLCJwcm9taXNlcyIsInBheWxvYWQiLCJwdXQiLCJQcm9taXNlIiwiYWxsIiwiZmV0Y2hCaWRSZXF1ZXN0cyIsImZldGNoVXNlcnMiLCJnZXQiLCJmZXRjaEN1c3RvbWVyQmFsYW5jZSIsImJhbGFuY2UiLCJmZXRjaEF1Y3Rpb25Db3VudCIsImZldGNoRWRpdEN1c3RvbWVyRGV0YWlscyIsInNlbGVjdGVkRW5yb2xsbWVudElkIiwiZ3JvdXBzRGF0YVByb21pc2UiLCJlbnJvbGxtZW50IiwiZ3JvdXBEYXRhIiwiZ3JvdXAiLCJhdWN0aW9uc0RvbmUiLCJyZWZlcnJlZEJ5IiwiYWdlbnQiLCJuYW1lIiwicmVmZXJyZWRfY3VzdG9tZXIiLCJyZWZlcnJlZF9sZWFkIiwibGVhZF9uYW1lIiwiYWdlbnRfbnVtYmVyIiwiaWQiLCJiaWRfcmVxdWVzdF9jb2RlIiwidGlja2V0cyIsInN0YXJ0X2RhdGUiLCJzcGxpdCIsImVuZF9kYXRlIiwiZnVsbEVucm9sbG1lbnQiLCJncm91cHNEYXRhIiwiZGVmYXVsdEluZGV4IiwiZm91bmRJbmRleCIsImZpbmRJbmRleCIsImciLCJzZWxlY3RlZEdyb3VwIiwic2V0RmllbGRzVmFsdWUiLCJzZWxlY3RlZEdyb3VwSW5kZXgiLCJ1bmRlZmluZWQiLCJoYW5kbGVFZGl0R3JvdXBTZWxlY3QiLCJpbmRleCIsInJlcXVlc3REYXRlIiwicmVxdWVzdF9kYXRlIiwiaGFuZGxlT3BlbkVkaXRNb2RhbCIsIm5hbWVUb0Rpc3BsYXkiLCJwaG9uZVRvRGlzcGxheSIsImN1c3RvbWVySWRUb0Rpc3BsYXkiLCJjdXN0b21lcl9pZCIsImFkbWluT2JqZWN0IiwiYWRtaW5Vc2VyRGV0YWlscyIsImFkbWluTmFtZSIsInJlZmVycmVkQnlGcm9tVGFibGUiLCJjdXN0b21lcklkIiwiYXVjdGlvbkRhdGUiLCJhdWN0aW9uVGltZSIsImF1Y3Rpb25fdGltZSIsImF1Y3Rpb25zIiwiaGFuZGxlQ2xvc2VFZGl0TW9kYWwiLCJyZXNldEZpZWxkcyIsImhhbmRsZVNhdmVDaGFuZ2VzIiwidmFsdWVzIiwidmFsaWRhdGVGaWVsZHMiLCJ1cGRhdGVEYXRhIiwiZm9ybWF0IiwidXBkYXRlU3RhdHVzIiwiZ3JvdXBJbmRleCIsInJlZmVycmVkX2J5Iiwic3RhdHVzTWVzc2FnZXMiLCJQZW5kaW5nIiwiQWNjZXB0IiwiUmVqZWN0IiwiTmV4dEF1Y3Rpb24iLCJQcml6ZWQiLCJlcnJvck1lc3NhZ2UiLCJlcnJvcnMiLCJPYmplY3QiLCJmbGF0Iiwiam9pbiIsImVycm9yRmllbGRzIiwiZiIsImhhbmRsZVNldFBlbmRpbmciLCJoYW5kbGVTZXRBY2NlcHQiLCJoYW5kbGVTZXRSZWplY3QiLCJoYW5kbGVTZXROZXh0QXVjdGlvbiIsImhhbmRsZVNldFByaXplZCIsImZldGNoSW5pdGlhbERhdGEiLCJncm91cFJlcyIsImhhbmRsZUVkaXQiLCJoYW5kbGVTaGFyZSIsImZyb250ZW5kVXJsIiwid2luZG93IiwibG9jYXRpb24iLCJvcmlnaW4iLCJmdWxsVXJsIiwib3BlbiIsImhhbmRsZVByaW50IiwicHJpbnRXaW5kb3ciLCJwcmludENvbnRlbnQiLCJhdWN0aW9uX2RhdGUiLCJpbnN0YW5jZV9iYWxhbmNlIiwicHJvcHMiLCJjaGlsZHJlbiIsImRvY3VtZW50Iiwid3JpdGUiLCJjbG9zZSIsInByaW50IiwiY29uZmlybURlbGV0ZSIsIm9rVHlwZSIsImhhbmRsZURlbGV0ZSIsImRlbGV0ZSIsImhhbmRsZVRvZ2dsZUFjdGlvbiIsInVzZUNhbGxiYWNrIiwic3RvcFByb3BhZ2F0aW9uIiwicHJldmVudERlZmF1bHQiLCJyZWN0IiwiY3VycmVudFRhcmdldCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsInByZXZJZCIsImJvdHRvbSIsInNjcm9sbFkiLCJyaWdodCIsInBhcmFtcyIsImZvcm1hdHRlZERhdGEiLCJ1c2VyT2JqZWN0IiwiZ3JvdXBPYmplY3QiLCJjdXJyZW50QmFsYW5jZSIsImluc3RhbmNlQmFsYW5jZSIsInJlcXVlc3RTb3VyY2UiLCJzb3VyY2UiLCJhbW91bnRQYWlkIiwiYW1vdW50X3BhaWQiLCJnZXRTdGF0dXNUYWciLCJtYXBwZWRTdGF0dXMiLCJzdGF0dXNDb2xvcnMiLCJEZWNsaW5lIiwicmVxdWVzdF9kYXRlX3JhdyIsInNvdXJjZV9yYXciLCJ0b0xvY2FsZVN0cmluZyIsImluc3RhbmNlX2JhbGFuY2VfcmF3IiwiYmFsYW5jZV9yYXciLCJhbW91bnRfcGFpZF9yYXciLCJzdGF0dXNfcmF3IiwibmV4dF9hdWN0aW9uX2RhdGUiLCJsYXRlc3RfYXVjdGlvbiIsIm5leHRfZGF0ZSIsImFjdGlvbiIsImNhbGN1bGF0ZU92ZXJ2aWV3IiwiY2FsY3VsYXRlR3JvdXBTdGF0cyIsInNldFRpbWVvdXQiLCJ1c2VFZmZlY3QiLCJoYW5kbGVDbGlja091dHNpZGUiLCJldmVudCIsImNsb3Nlc3QiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImFsbENoZWNrZWQiLCJldmVyeSIsImhhbmRsZUFwcGx5RmlsdGVycyIsImhhbmRsZUNsZWFyRmlsdGVycyIsImNhbGN1bGF0ZU92ZXJ2aWV3RnJvbURhdGEiLCJyZWR1Y2UiLCJzdW0iLCJjYWxjdWxhdGVHcm91cFN0YXRzRnJvbURhdGEiLCJzdGF0c01hcCIsIk1hcCIsImhhcyIsInNldCIsInRvdGFsIiwicGVuZGluZyIsImFjY2VwdCIsInJlamVjdCIsIm5leHRBdWN0aW9uIiwicHJpemVkIiwidG90YWxCYWxhbmNlIiwic3RhdHMiLCJBcnJheSIsImZyb20iLCJwYXltZW50cyIsInRvdGFsQW1vdW50UGFpZCIsIm5leHRBdWN0aW9uRGF0ZSIsIm5leHREYXRlIiwibmV4dERhdGVPYmoiLCJpc1ZhbGlkIiwiZmlsdGVyZWQiLCJmaW5kIiwiaXRlbURhdGUiLCJpc0JlZm9yZSIsImlzQWZ0ZXIiLCJleHBvcnRUb0V4Y2VsIiwiZXhwb3J0RGF0YSIsIlNvdXJjZSIsIlN0YXR1cyIsIndzIiwidXRpbHMiLCJqc29uX3RvX3NoZWV0Iiwid2IiLCJib29rX25ldyIsImJvb2tfYXBwZW5kX3NoZWV0Iiwid3JpdGVGaWxlIiwiZXhwb3J0VG9QREYiLCJkb2MiLCJzZXRGb250U2l6ZSIsInRleHQiLCJ0YWJsZURhdGEiLCJhdXRvVGFibGUiLCJoZWFkIiwiYm9keSIsInN0YXJ0WSIsInN0eWxlcyIsImZvbnRTaXplIiwiaGVhZFN0eWxlcyIsImZpbGxDb2xvciIsInNhdmUiLCJwcmludFJlcG9ydCIsInN1bW1hcnlIVE1MIiwidmFsIiwidXBkYXRlZCIsInBvc2l0aW9uIiwiekluZGV4IiwicmVxIiwicmVxdWlyZWQiLCJfYzIiLCJEZXRhaWxJdGVtIiwibGFiZWwiLCJ2YWx1ZSIsIl9jMyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCaWRSZXF1ZXN0UmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIEZvcm0sXHJcbiAgSW5wdXQsXHJcbiAgRGF0ZVBpY2tlcixcclxuICBUaW1lUGlja2VyLFxyXG4gIEJ1dHRvbixcclxuICBTZWxlY3QsXHJcbiAgUG9wY29uZmlybSxcclxuICBTcGluLFxyXG4gIG1lc3NhZ2UsXHJcbiAgTW9kYWwsXHJcbn0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgVGFnLCBUb29sdGlwLCBFbXB0eSwgTW9kYWwgYXMgQW50TW9kYWwsIFRhYnMsIFNwYWNlIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgRmFHYXZlbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBJb01kUmVmcmVzaCB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlck91dGxpbmVkLFxyXG4gIEVkaXRPdXRsaW5lZCxcclxuICBTaGFyZUFsdE91dGxpbmVkLFxyXG4gIFByaW50ZXJPdXRsaW5lZCxcclxuICBEZWxldGVPdXRsaW5lZCxcclxuICBTZWFyY2hPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIENoZWNrQ2lyY2xlT3V0bGluZWQsXHJcbiAgQ2xvc2VPdXRsaW5lZCxcclxuICBTdG9wT3V0bGluZWQsXHJcbiAgVHJvcGh5T3V0bGluZWQsXHJcbiAgV2hhdHNBcHBPdXRsaW5lZCxcclxuICBFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkLFxyXG4gIFNhdmVPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgKiBhcyBYTFNYIGZyb20gXCJ4bHN4XCI7XHJcbmltcG9ydCBqc1BERiBmcm9tIFwianNwZGZcIjtcclxuaW1wb3J0IFwianNwZGYtYXV0b3RhYmxlXCI7XHJcblxyXG5jb25zdCB7IFRhYlBhbmUgfSA9IFRhYnM7XHJcbmNvbnN0IHsgT3B0aW9uIH0gPSBTZWxlY3Q7XHJcblxyXG4vLyA9PT09PT09PT09IFNlbGVjdGlvbiBDaGVja2JveCBDb21wb25lbnQgPT09PT09PT09PVxyXG5jb25zdCBTZWxlY3Rpb25DaGVja2JveCA9ICh7XHJcbiAgaXRlbUtleSxcclxuICB1c2VyTmFtZSxcclxuICB1c2VyUGhvbmUsXHJcbiAgYWN0aXZlVXNlckRhdGEsXHJcbiAgc2V0QWN0aXZlVXNlckRhdGEsXHJcbn0pID0+IHtcclxuICBjb25zdCBpc0NoZWNrZWQgPSAhIWFjdGl2ZVVzZXJEYXRhPy5baXRlbUtleV0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxpbnB1dFxyXG4gICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICBjaGVja2VkPXtpc0NoZWNrZWR9XHJcbiAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIFtpdGVtS2V5XToge1xyXG4gICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgc3RhdHVzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyTmFtZSxcclxuICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXJQaG9uZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9fVxyXG4gICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGN1cnNvci1wb2ludGVyIGFjY2VudC1ibHVlLTYwMFwiXHJcbiAgICAvPlxyXG4gICk7XHJcbn07XHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5jb25zdCBCaWRSZXF1ZXN0UmVwb3J0ID0gKCkgPT4ge1xyXG4gIC8vIFNlcGFyYXRlIHN0YXRlIGZvciBhbGwgZGF0YSB2cyBmaWx0ZXJlZCBkYXRhXHJcbiAgY29uc3QgW2FsbEJpZFJlcXVlc3RzLCBzZXRBbGxCaWRSZXF1ZXN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2JpZFJlcXVlc3RzLCBzZXRCaWRSZXF1ZXN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3Jhd0JpZFJlcXVlc3RzRGF0YSwgc2V0UmF3QmlkUmVxdWVzdHNEYXRhXSA9IHVzZVN0YXRlKFtdKTsgLy8gU3RvcmUgcmF3IGRhdGEgZm9yIGVkaXRpbmdcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW29wZW5BY3Rpb25JZCwgc2V0T3BlbkFjdGlvbklkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtkcm9wZG93blBvcywgc2V0RHJvcGRvd25Qb3NdID0gdXNlU3RhdGUoeyB0b3A6IDAsIGxlZnQ6IDAgfSk7XHJcblxyXG4gIC8vIEVkaXQgTW9kYWwgU3RhdGVzXHJcbiAgY29uc3QgW2lzRWRpdE1vZGFsT3Blbiwgc2V0SXNFZGl0TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdEZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW2VkaXRHcm91cHMsIHNldEVkaXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVkaXRHcm91cEluZGV4LCBzZXRTZWxlY3RlZEVkaXRHcm91cEluZGV4XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtlZGl0aW5nSWQsIHNldEVkaXRpbmdJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VzdG9tZXJCYWxhbmNlLCBzZXRDdXN0b21lckJhbGFuY2VdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xvYWRpbmdCYWxhbmNlLCBzZXRMb2FkaW5nQmFsYW5jZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRMb2FkaW5nLCBzZXRFZGl0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIC8vID09PT09PT09PT0gQ2hlY2tib3ggU2VsZWN0aW9uIFN0YXRlcyA9PT09PT09PT09XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNWZXJpZnlNb2RhbE9wZW4sIHNldElzVmVyaWZ5TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTZW5kaW5nLCBzZXRJc1NlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtidWxrTG9hZGluZywgc2V0QnVsa0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbb3ZlcnZpZXcsIHNldE92ZXJ2aWV3XSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsUmVxdWVzdHM6IDAsXHJcbiAgICB0b3RhbFBhaWRBbW91bnQ6IDAsXHJcbiAgICBwZW5kaW5nUmVxdWVzdHM6IDAsXHJcbiAgICBhY2NlcHRSZXF1ZXN0czogMCxcclxuICAgIHJlamVjdFJlcXVlc3RzOiAwLFxyXG4gICAgbmV4dEF1Y3Rpb25SZXF1ZXN0czogMCxcclxuICAgIHByaXplZFJlcXVlc3RzOiAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cElkOiBcIlwiLFxyXG4gICAgdXNlcklkOiBcIlwiLFxyXG4gICAgc3RhdHVzOiBcIlwiLFxyXG4gICAgcGF5bWVudFN0YXR1czogXCJcIixcclxuICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgICB2aWV3VHlwZTogXCJhbGxcIixcclxuICB9KTtcclxuXHJcbiAgLy8gVGVtcG9yYXJ5IHN0YXRlcyBmb3IgZmlsdGVyc1xyXG4gIGNvbnN0IFt0ZW1wR3JvdXBJZCwgc2V0VGVtcEdyb3VwSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RlbXBTdGF0dXMsIHNldFRlbXBTdGF0dXNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RlbXBQYXltZW50U3RhdHVzLCBzZXRUZW1wUGF5bWVudFN0YXR1c10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdGVtcEZyb21EYXRlLCBzZXRUZW1wRnJvbURhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RlbXBUb0RhdGUsIHNldFRlbXBUb0RhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtzaG93TW9kYWxWaWV3LCBzZXRTaG93TW9kYWxWaWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEJpZFJlcXVlc3QsIHNldEN1cnJlbnRCaWRSZXF1ZXN0XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtncm91cFN0YXRzLCBzZXRHcm91cFN0YXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoXCJsaXN0XCIpO1xyXG5cclxuICAvLyA9PT09PT09PT09IFNlbGVjdGVkIENvdW50IENhbGN1bGF0aW9uID09PT09PT09PT1cclxuICBjb25zdCBzZWxlY3RlZENvdW50ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gYmlkUmVxdWVzdHMuZmlsdGVyKChpdGVtKSA9PiBhY3RpdmVVc2VyRGF0YVtpdGVtLmtleV0/LmluZm8/LnN0YXR1cylcclxuICAgICAgLmxlbmd0aDtcclxuICB9LCBbYmlkUmVxdWVzdHMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJiaWRfcmVxdWVzdF9jb2RlXCIsIGhlYWRlcjogXCJCaWQgUmVxdWVzdCBDb2RlXCIgfSxcclxuICAgIHsga2V5OiBcInJlcXVlc3RfZGF0ZVwiLCBoZWFkZXI6IFwiUmVxdWVzdCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fdGltZVwiLCBoZWFkZXI6IFwiUmVxdWVzdCBUaW1lXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfbmFtZVwiLCBoZWFkZXI6IFwiU3Vic2NyaWJlciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0X251bWJlclwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudF9wYWlkXCIsIGhlYWRlcjogXCJBbW91bnQgUGFpZFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJpbnN0YW5jZV9iYWxhbmNlXCIsIGhlYWRlcjogXCJJbnN0YW5jZSBCYWxhbmNlIChBdCBSZXF1ZXN0KVwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJDdXJyZW50IEJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwic291cmNlXCIsIGhlYWRlcjogXCJTb3VyY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hcIiwgaGVhZGVyOiBcIlNlbGVjdFwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiLCB3aWR0aDogMTgwIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZXhwb3J0Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX3JlcXVlc3RfY29kZVwiLCBoZWFkZXI6IFwiQmlkIFJlcXVlc3QgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZXF1ZXN0X2RhdGVcIiwgaGVhZGVyOiBcIlJlcXVlc3QgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX3RpbWVcIiwgaGVhZGVyOiBcIlJlcXVlc3QgVGltZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyX25hbWVcIiwgaGVhZGVyOiBcIlN1YnNjcmliZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldF9udW1iZXJcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgICAgeyBrZXk6IFwiYW1vdW50X3BhaWRfcmF3XCIsIGhlYWRlcjogXCJBbW91bnQgUGFpZFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJpbnN0YW5jZV9iYWxhbmNlX3Jhd1wiLCBoZWFkZXI6IFwiSW5zdGFuY2UgQmFsYW5jZSAoQXQgUmVxdWVzdClcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZV9yYXdcIiwgaGVhZGVyOiBcIkN1cnJlbnQgQmFsYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCJzb3VyY2VcIiwgaGVhZGVyOiBcIlNvdXJjZVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNfcmF3XCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGRpc3BsYXlCaWRSZXF1ZXN0cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGJpZFJlcXVlc3RzLm1hcCgoaXRlbSkgPT4gKHtcclxuICAgICAgLi4uaXRlbSxcclxuICAgICAgY2hlY2tCb3g6IChcclxuICAgICAgICA8U2VsZWN0aW9uQ2hlY2tib3hcclxuICAgICAgICAgIGl0ZW1LZXk9e2l0ZW0ua2V5fVxyXG4gICAgICAgICAgdXNlck5hbWU9e2l0ZW0udXNlcl9uYW1lfVxyXG4gICAgICAgICAgdXNlclBob25lPXtcclxuICAgICAgICAgICAgaXRlbS5yYXdEYXRhPy5tb2JpbGVOdW1iZXIgfHxcclxuICAgICAgICAgICAgaXRlbS5yYXdEYXRhPy5zdWJzY3JpYmVySWQ/LnBob25lX251bWJlciB8fFxyXG4gICAgICAgICAgICBcIk4vQVwiXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBhY3RpdmVVc2VyRGF0YT17YWN0aXZlVXNlckRhdGF9XHJcbiAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YT17c2V0QWN0aXZlVXNlckRhdGF9XHJcbiAgICAgICAgLz5cclxuICAgICAgKSxcclxuICAgIH0pKTtcclxuICB9LCBbYmlkUmVxdWVzdHMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9wZW5WZXJpZnlNb2RhbCA9ICgpID0+IHNldElzVmVyaWZ5TW9kYWxPcGVuKHRydWUpO1xyXG4gIGNvbnN0IGhhbmRsZUNsb3NlVmVyaWZ5TW9kYWwgPSAoKSA9PiBzZXRJc1ZlcmlmeU1vZGFsT3BlbihmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbmRXaGF0c0FwcCA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzU2VuZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkSXRlbXMgPSBiaWRSZXF1ZXN0cy5maWx0ZXIoXHJcbiAgICAgICAgKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0ua2V5XT8uaW5mbz8uc3RhdHVzLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCByZWNlaXZlcnMgPSB7fTtcclxuXHJcbiAgICAgIHNlbGVjdGVkSXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJhd0RhdGEgPSBpdGVtLnJhd0RhdGE7XHJcbiAgICAgICAgY29uc3QgdXNlck9iaiA9XHJcbiAgICAgICAgICB0eXBlb2YgcmF3RGF0YT8uc3Vic2NyaWJlcklkID09PSBcIm9iamVjdFwiID8gcmF3RGF0YS5zdWJzY3JpYmVySWQgOiB7fTtcclxuICAgICAgICBjb25zdCBncm91cE9iaiA9XHJcbiAgICAgICAgICB0eXBlb2YgcmF3RGF0YT8uZ3JvdXBJZCA9PT0gXCJvYmplY3RcIiA/IHJhd0RhdGEuZ3JvdXBJZCA6IHt9O1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnRJZCA9XHJcbiAgICAgICAgICByYXdEYXRhPy5lbnJvbGxtZW50SWQ/Ll9pZCB8fCByYXdEYXRhPy5lbnJvbGxtZW50SWQ7XHJcblxyXG4gICAgICAgIHJlY2VpdmVyc1tpdGVtLmtleV0gPSB7XHJcbiAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgIHN0YXR1czogdHJ1ZSxcclxuICAgICAgICAgICAgc3Vic2NyaWJlck5hbWU6IGl0ZW0udXNlcl9uYW1lIHx8IHVzZXJPYmouZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIG1vYmlsZU51bWJlcjpcclxuICAgICAgICAgICAgICByYXdEYXRhPy5tb2JpbGVOdW1iZXIgfHwgdXNlck9iai5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgZ3JvdXBOYW1lOiBpdGVtLmdyb3VwX25hbWUgfHwgZ3JvdXBPYmouZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICB0aWNrZXROdW1iZXI6IGl0ZW0udGlja2V0X251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBiaWRSZXF1ZXN0SWQ6IGl0ZW0ua2V5LFxyXG4gICAgICAgICAgICBlbnJvbGxtZW50SWQ6IGVucm9sbG1lbnRJZCxcclxuICAgICAgICAgICAgZ3JvdXBJZDogZ3JvdXBPYmouX2lkIHx8IHJhd0RhdGE/Lmdyb3VwSWQsXHJcbiAgICAgICAgICAgIHN1YnNjcmliZXJJZDogdXNlck9iai5faWQgfHwgcmF3RGF0YT8uc3Vic2NyaWJlcklkLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3doYXRzYXBwL2JpZC1yZXF1ZXN0LWJhbGFuY2UtY2hlY2tcIiwgcmVjZWl2ZXJzKTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiV2hhdHNBcHAgbWVzc2FnZXMgaW5pdGlhdGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcblxyXG4gICAgICBjb25zdCBuZXdBY3RpdmVEYXRhID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgICBzZWxlY3RlZEl0ZW1zLmZvckVhY2goKGl0ZW0pID0+IGRlbGV0ZSBuZXdBY3RpdmVEYXRhW2l0ZW0ua2V5XSk7XHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKG5ld0FjdGl2ZURhdGEpO1xyXG4gICAgICBzZXRJc1ZlcmlmeU1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBzZW5kIG1lc3NhZ2VzLlwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU2VuZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZSA9IChuZXdTdGF0dXMpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkSXRlbXMgPSBiaWRSZXF1ZXN0cy5maWx0ZXIoXHJcbiAgICAgIChpdGVtKSA9PiBhY3RpdmVVc2VyRGF0YVtpdGVtLmtleV0/LmluZm8/LnN0YXR1cyxcclxuICAgICk7XHJcbiAgICBpZiAoc2VsZWN0ZWRJdGVtcy5sZW5ndGggPT09IDApIHJldHVybjtcclxuXHJcbiAgICBNb2RhbC5jb25maXJtKHtcclxuICAgICAgdGl0bGU6IGBCdWxrIFVwZGF0ZSBDb25maXJtYXRpb25gLFxyXG4gICAgICBpY29uOiA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgY29udGVudDogYFlvdSBhcmUgYWJvdXQgdG8gdXBkYXRlIHN0YXR1cyB0byBcIiR7bmV3U3RhdHVzfVwiIGZvciAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSByZXF1ZXN0cy4gQXJlIHlvdSBzdXJlP2AsXHJcbiAgICAgIG9rVGV4dDogXCJZZXMsIFVwZGF0ZVwiLFxyXG4gICAgICBjYW5jZWxUZXh0OiBcIk5vXCIsXHJcbiAgICAgIG9uT2s6IGFzeW5jICgpID0+IHtcclxuICAgICAgICBzZXRCdWxrTG9hZGluZyh0cnVlKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgcHJvbWlzZXMgPSBzZWxlY3RlZEl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCByYXdEYXRhID0gaXRlbS5yYXdEYXRhO1xyXG4gICAgICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAgIHN0YXR1czogbmV3U3RhdHVzLFxyXG4gICAgICAgICAgICAgIGVucm9sbG1lbnRJZDogcmF3RGF0YT8uZW5yb2xsbWVudElkPy5faWQgfHwgcmF3RGF0YT8uZW5yb2xsbWVudElkLFxyXG4gICAgICAgICAgICAgIGdyb3VwSWQ6IHJhd0RhdGE/Lmdyb3VwSWQ/Ll9pZCB8fCByYXdEYXRhPy5ncm91cElkLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICByZXR1cm4gYXBpLnB1dChgL2JpZC1yZXF1ZXN0L3VwZGF0ZS8ke2l0ZW0ua2V5fWAsIHBheWxvYWQpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChwcm9taXNlcyk7XHJcbiAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXHJcbiAgICAgICAgICAgIGAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSByZXF1ZXN0cyB1cGRhdGVkIHRvICR7bmV3U3RhdHVzfWAsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEoe30pO1xyXG4gICAgICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgICAgICAgIGZldGNoQmlkUmVxdWVzdHMoKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHNvbWUgcmVxdWVzdHMuXCIpO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICBzZXRCdWxrTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyczpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJCYWxhbmNlID0gYXN5bmMgKGVucm9sbG1lbnRJZCkgPT4ge1xyXG4gICAgaWYgKCFlbnJvbGxtZW50SWQpIHJldHVybjtcclxuICAgIHNldExvYWRpbmdCYWxhbmNlKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvYmlkLXJlcXVlc3QvZ2V0LWJhbGFuY2UvJHtlbnJvbGxtZW50SWR9YCxcclxuICAgICAgKTtcclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LmRhdGE/Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICBzZXRDdXN0b21lckJhbGFuY2UocmVzcG9uc2UuZGF0YS5kYXRhWzBdLmJhbGFuY2UpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEN1c3RvbWVyQmFsYW5jZSgwKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0Q3VzdG9tZXJCYWxhbmNlKDApO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZ0JhbGFuY2UoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQXVjdGlvbkNvdW50ID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIGlmICghZ3JvdXBJZCkgcmV0dXJuIDA7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hdWN0aW9uL2dldC1ncm91cC1hdWN0aW9uLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEubGVuZ3RoO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFZGl0Q3VzdG9tZXJEZXRhaWxzID0gYXN5bmMgKFxyXG4gICAgdXNlcklkLFxyXG4gICAgc2VsZWN0ZWRFbnJvbGxtZW50SWQgPSBudWxsLFxyXG4gICkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICBgL2Vucm9sbC9nZXQtdXNlci10aWNrZXRzLXJlcG9ydC8ke3VzZXJJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCBncm91cHNEYXRhUHJvbWlzZSA9IHJlc3BvbnNlLmRhdGEubWFwKGFzeW5jIChpdGVtKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBlbnJvbGxtZW50ID0gaXRlbT8uZW5yb2xsbWVudDtcclxuICAgICAgICAgIGNvbnN0IGdyb3VwRGF0YSA9IGVucm9sbG1lbnQ/Lmdyb3VwO1xyXG4gICAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGdyb3VwRGF0YT8uX2lkO1xyXG4gICAgICAgICAgY29uc3QgYXVjdGlvbnNEb25lID0gYXdhaXQgZmV0Y2hBdWN0aW9uQ291bnQoZ3JvdXBJZCk7XHJcbiAgICAgICAgICBjb25zdCByZWZlcnJlZEJ5ID1cclxuICAgICAgICAgICAgZ3JvdXBEYXRhPy5hZ2VudD8ubmFtZSAmJiBncm91cERhdGE/LmFnZW50Py5waG9uZV9udW1iZXJcclxuICAgICAgICAgICAgICA/IGAke2dyb3VwRGF0YS5hZ2VudC5uYW1lfSB8ICR7Z3JvdXBEYXRhLmFnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgOiBncm91cERhdGE/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBEYXRhPy5yZWZlcnJlZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICA/IGAke2dyb3VwRGF0YS5yZWZlcnJlZF9jdXN0b21lci5mdWxsX25hbWV9IHwgJHtncm91cERhdGEucmVmZXJyZWRfY3VzdG9tZXIucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgICAgICAgIDogZ3JvdXBEYXRhPy5yZWZlcnJlZF9sZWFkPy5sZWFkX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICBncm91cERhdGE/LnJlZmVycmVkX2xlYWQ/LmFnZW50X251bWJlclxyXG4gICAgICAgICAgICAgICAgICA/IGAke2dyb3VwRGF0YS5yZWZlcnJlZF9sZWFkLmxlYWRfbmFtZX0gfCAke2dyb3VwRGF0YS5yZWZlcnJlZF9sZWFkLmFnZW50X251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgIDogXCJOL0FcIjtcclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBpZDogZ3JvdXBJZCxcclxuICAgICAgICAgICAgYmlkX3JlcXVlc3RfY29kZTogZ3JvdXBEYXRhPy5iaWRfcmVxdWVzdF9jb2RlLFxyXG4gICAgICAgICAgICBncm91cE5hbWU6IGdyb3VwRGF0YT8uZ3JvdXBfbmFtZSB8fCBcIk5vIEdyb3VwIE5hbWVcIixcclxuICAgICAgICAgICAgdGlja2V0TnVtYmVyOlxyXG4gICAgICAgICAgICAgIGVucm9sbG1lbnQ/LnRpY2tldHMgfHwgZW5yb2xsbWVudD8udGlja2V0X251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBzdGFydERhdGU6IGdyb3VwRGF0YT8uc3RhcnRfZGF0ZVxyXG4gICAgICAgICAgICAgID8gZ3JvdXBEYXRhLnN0YXJ0X2RhdGUuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICBlbmREYXRlOiBncm91cERhdGE/LmVuZF9kYXRlXHJcbiAgICAgICAgICAgICAgPyBncm91cERhdGEuZW5kX2RhdGUuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uc0RvbmU6IGF1Y3Rpb25zRG9uZSxcclxuICAgICAgICAgICAgZnVsbEVucm9sbG1lbnQ6IGVucm9sbG1lbnQsXHJcbiAgICAgICAgICAgIGVucm9sbG1lbnRJZDogZW5yb2xsbWVudD8uX2lkLFxyXG4gICAgICAgICAgICByZWZlcnJlZEJ5OiByZWZlcnJlZEJ5LFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZ3JvdXBzRGF0YSA9IGF3YWl0IFByb21pc2UuYWxsKGdyb3Vwc0RhdGFQcm9taXNlKTtcclxuICAgICAgICBzZXRFZGl0R3JvdXBzKGdyb3Vwc0RhdGEpO1xyXG5cclxuICAgICAgICBpZiAoZ3JvdXBzRGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBsZXQgZGVmYXVsdEluZGV4ID0gMDtcclxuICAgICAgICAgIGlmIChzZWxlY3RlZEVucm9sbG1lbnRJZCkge1xyXG4gICAgICAgICAgICBjb25zdCBmb3VuZEluZGV4ID0gZ3JvdXBzRGF0YS5maW5kSW5kZXgoXHJcbiAgICAgICAgICAgICAgKGcpID0+IGcuZW5yb2xsbWVudElkID09PSBzZWxlY3RlZEVucm9sbG1lbnRJZCxcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgaWYgKGZvdW5kSW5kZXggIT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgZGVmYXVsdEluZGV4ID0gZm91bmRJbmRleDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc2V0U2VsZWN0ZWRFZGl0R3JvdXBJbmRleChkZWZhdWx0SW5kZXgpO1xyXG4gICAgICAgICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGdyb3Vwc0RhdGFbZGVmYXVsdEluZGV4XTtcclxuICAgICAgICAgIGVkaXRGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICAgICAgZ3JvdXBOYW1lOiBzZWxlY3RlZEdyb3VwLmdyb3VwTmFtZSxcclxuICAgICAgICAgICAgdGlja2V0TnVtYmVyOiBzZWxlY3RlZEdyb3VwLnRpY2tldE51bWJlcixcclxuICAgICAgICAgICAgc2VsZWN0ZWRHcm91cEluZGV4OiBkZWZhdWx0SW5kZXgsXHJcbiAgICAgICAgICAgIHN0YXJ0RGF0ZTogc2VsZWN0ZWRHcm91cC5zdGFydERhdGUsXHJcbiAgICAgICAgICAgIGVuZERhdGU6IHNlbGVjdGVkR3JvdXAuZW5kRGF0ZSxcclxuICAgICAgICAgICAgYXVjdGlvbnNEb25lOiBzZWxlY3RlZEdyb3VwLmF1Y3Rpb25zRG9uZSxcclxuICAgICAgICAgICAgcmVmZXJyZWRCeTogc2VsZWN0ZWRHcm91cC5yZWZlcnJlZEJ5LFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVkaXRHcm91cHMoW10pO1xyXG4gICAgICAgIGVkaXRGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICAgIGdyb3VwTmFtZTogXCJObyBHcm91cHMgRm91bmRcIixcclxuICAgICAgICAgIHRpY2tldE51bWJlcjogXCJOL0FcIixcclxuICAgICAgICAgIHNlbGVjdGVkR3JvdXBJbmRleDogdW5kZWZpbmVkLFxyXG4gICAgICAgICAgcmVmZXJyZWRCeTogXCJOL0FcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGN1c3RvbWVyIGRldGFpbHM6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBjdXN0b21lciBncm91cCBkZXRhaWxzLlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0R3JvdXBTZWxlY3QgPSBhc3luYyAoaW5kZXgpID0+IHtcclxuICAgIHNldFNlbGVjdGVkRWRpdEdyb3VwSW5kZXgoaW5kZXgpO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGVkaXRHcm91cHNbaW5kZXhdO1xyXG4gICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgZWRpdEZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgIGdyb3VwTmFtZTogc2VsZWN0ZWRHcm91cC5ncm91cE5hbWUsXHJcbiAgICAgICAgdGlja2V0TnVtYmVyOiBzZWxlY3RlZEdyb3VwLnRpY2tldE51bWJlcixcclxuICAgICAgICBzZWxlY3RlZEdyb3VwSW5kZXg6IGluZGV4LFxyXG4gICAgICAgIHN0YXJ0RGF0ZTogc2VsZWN0ZWRHcm91cC5zdGFydERhdGUsXHJcbiAgICAgICAgZW5kRGF0ZTogc2VsZWN0ZWRHcm91cC5lbmREYXRlLFxyXG4gICAgICAgIGF1Y3Rpb25zRG9uZTogc2VsZWN0ZWRHcm91cC5hdWN0aW9uc0RvbmUsXHJcbiAgICAgICAgcmVxdWVzdERhdGU6IHNlbGVjdGVkR3JvdXAucmVxdWVzdF9kYXRlXHJcbiAgICAgICAgICA/IGRheWpzKHNlbGVjdGVkR3JvdXAucmVxdWVzdF9kYXRlKVxyXG4gICAgICAgICAgOiBkYXlqcygpLFxyXG4gICAgICAgIHJlZmVycmVkQnk6IHNlbGVjdGVkR3JvdXAucmVmZXJyZWRCeSxcclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGZldGNoQ3VzdG9tZXJCYWxhbmNlKHNlbGVjdGVkR3JvdXAuZW5yb2xsbWVudElkKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuRWRpdE1vZGFsID0gYXN5bmMgKGl0ZW0pID0+IHtcclxuICAgIHNldE9wZW5BY3Rpb25JZChudWxsKTtcclxuICAgIHNldEVkaXRpbmdJZChpdGVtLmtleSk7XHJcbiAgICBzZXRJc0VkaXRNb2RhbE9wZW4odHJ1ZSk7XHJcblxyXG4gICAgY29uc3QgcmF3RGF0YSA9IGl0ZW0ucmF3RGF0YTtcclxuICAgIGNvbnN0IHVzZXJPYmogPVxyXG4gICAgICB0eXBlb2YgcmF3RGF0YS5zdWJzY3JpYmVySWQgPT09IFwib2JqZWN0XCIgPyByYXdEYXRhLnN1YnNjcmliZXJJZCA6IHt9O1xyXG4gICAgY29uc3QgdXNlcklkID0gdXNlck9iai5faWQgfHwgcmF3RGF0YS5zdWJzY3JpYmVySWQ7XHJcbiAgICBjb25zdCBuYW1lVG9EaXNwbGF5ID1cclxuICAgICAgcmF3RGF0YS5zdWJzY3JpYmVyTmFtZSB8fCB1c2VyT2JqLmZ1bGxfbmFtZSB8fCBpdGVtLnVzZXJfbmFtZSB8fCBcIlwiO1xyXG4gICAgY29uc3QgcGhvbmVUb0Rpc3BsYXkgPSByYXdEYXRhLm1vYmlsZU51bWJlciB8fCB1c2VyT2JqLnBob25lX251bWJlciB8fCBcIlwiO1xyXG4gICAgY29uc3QgY3VzdG9tZXJJZFRvRGlzcGxheSA9IHVzZXJPYmouY3VzdG9tZXJfaWQgfHwgXCJOL0FcIjtcclxuXHJcbiAgICBjb25zdCBhZG1pbk9iamVjdCA9IHJhd0RhdGEuYWRtaW5Vc2VyRGV0YWlscyB8fCB7fTtcclxuICAgIGNvbnN0IGFkbWluTmFtZSA9XHJcbiAgICAgIGFkbWluT2JqZWN0Lm5hbWUgfHwgYWRtaW5PYmplY3QuZnVsbF9uYW1lIHx8IHJhd0RhdGEuYWRtaW5OYW1lIHx8IFwiTi9BXCI7XHJcblxyXG4gICAgY29uc3QgcmVmZXJyZWRCeUZyb21UYWJsZSA9XHJcbiAgICAgIHJhd0RhdGE/LmFnZW50Py5uYW1lICYmIHJhd0RhdGE/LmFnZW50Py5waG9uZV9udW1iZXJcclxuICAgICAgICA/IGAke3Jhd0RhdGEuYWdlbnQubmFtZX0gfCAke3Jhd0RhdGEuYWdlbnQucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICA6IHJhd0RhdGE/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgcmF3RGF0YT8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlclxyXG4gICAgICAgICAgPyBgJHtyYXdEYXRhLnJlZmVycmVkX2N1c3RvbWVyLmZ1bGxfbmFtZX0gfCAke3Jhd0RhdGEucmVmZXJyZWRfY3VzdG9tZXIucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgIDogcmF3RGF0YT8ucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lICYmXHJcbiAgICAgICAgICAgICAgcmF3RGF0YT8ucmVmZXJyZWRfbGVhZD8uYWdlbnRfbnVtYmVyXHJcbiAgICAgICAgICAgID8gYCR7cmF3RGF0YS5yZWZlcnJlZF9sZWFkLmxlYWRfbmFtZX0gfCAke3Jhd0RhdGEucmVmZXJyZWRfbGVhZC5hZ2VudF9udW1iZXJ9YFxyXG4gICAgICAgICAgICA6IHJhd0RhdGEucmVmZXJyZWRCeSB8fCBcIk4vQVwiO1xyXG5cclxuICAgIGVkaXRGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgc3Vic2NyaWJlcklkOiB1c2VySWQsXHJcbiAgICAgIHN1YnNjcmliZXJOYW1lOiBuYW1lVG9EaXNwbGF5LFxyXG4gICAgICBtb2JpbGVOdW1iZXI6IHBob25lVG9EaXNwbGF5LFxyXG4gICAgICBjdXN0b21lcklkOiBjdXN0b21lcklkVG9EaXNwbGF5LFxyXG4gICAgICBiaWRfcmVxdWVzdF9jb2RlOiByYXdEYXRhLmJpZF9yZXF1ZXN0X2NvZGUgfHwgXCItXCIsXHJcbiAgICAgIGFkbWluTmFtZTogYWRtaW5OYW1lLFxyXG4gICAgICBhdWN0aW9uRGF0ZTogcmF3RGF0YS5hdWN0aW9uRGF0ZSA/IGRheWpzKHJhd0RhdGEuYXVjdGlvbkRhdGUpIDogbnVsbCxcclxuICAgICAgYXVjdGlvblRpbWU6IHJhd0RhdGEuYXVjdGlvbl90aW1lXHJcbiAgICAgICAgPyBkYXlqcyhyYXdEYXRhLmF1Y3Rpb25fdGltZSwgXCJISDptbVwiKVxyXG4gICAgICAgIDogbnVsbCxcclxuICAgICAgcmVmZXJyZWRCeTogcmVmZXJyZWRCeUZyb21UYWJsZSxcclxuICAgICAgIHJlcXVlc3REYXRlOiByYXdEYXRhLnJlcXVlc3RfZGF0ZSA/IGRheWpzKHJhd0RhdGEucmVxdWVzdF9kYXRlKSA6IGRheWpzKCksXHJcbiAgICAgIGdyb3VwTmFtZTogaXRlbS5ncm91cF9uYW1lLFxyXG4gICAgICB0aWNrZXROdW1iZXI6IGl0ZW0udGlja2V0X251bWJlcixcclxuICAgICAgZW5yb2xsbWVudElkOiByYXdEYXRhLmVucm9sbG1lbnRJZCxcclxuICAgICAgZ3JvdXBJZDogcmF3RGF0YS5ncm91cElkPy5faWQgfHwgcmF3RGF0YS5ncm91cElkLFxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0Q3VzdG9tZXJCYWxhbmNlKHJhd0RhdGEuYXVjdGlvbnM/LmJhbGFuY2UgfHwgMCk7XHJcblxyXG4gICAgaWYgKHVzZXJzLmxlbmd0aCA9PT0gMCkgYXdhaXQgZmV0Y2hVc2VycygpO1xyXG4gICAgYXdhaXQgZmV0Y2hFZGl0Q3VzdG9tZXJEZXRhaWxzKHVzZXJJZCwgcmF3RGF0YS5lbnJvbGxtZW50SWQpO1xyXG5cclxuICAgIGlmIChyYXdEYXRhLmVucm9sbG1lbnRJZCkge1xyXG4gICAgICBhd2FpdCBmZXRjaEN1c3RvbWVyQmFsYW5jZShyYXdEYXRhLmVucm9sbG1lbnRJZCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xvc2VFZGl0TW9kYWwgPSAoKSA9PiB7XHJcbiAgICBzZXRJc0VkaXRNb2RhbE9wZW4oZmFsc2UpO1xyXG4gICAgZWRpdEZvcm0ucmVzZXRGaWVsZHMoKTtcclxuICAgIHNldEVkaXRHcm91cHMoW10pO1xyXG4gICAgc2V0Q3VzdG9tZXJCYWxhbmNlKG51bGwpO1xyXG4gICAgc2V0RWRpdGluZ0lkKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNhdmVDaGFuZ2VzID0gYXN5bmMgKCkgPT4ge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB2YWx1ZXMgPSBhd2FpdCBlZGl0Rm9ybS52YWxpZGF0ZUZpZWxkcygpO1xyXG4gICAgc2V0RWRpdExvYWRpbmcodHJ1ZSk7XHJcbiAgICBcclxuICAgIGNvbnN0IHVwZGF0ZURhdGEgPSB7XHJcbiAgICAgIGF1Y3Rpb25EYXRlOiB2YWx1ZXMuYXVjdGlvbkRhdGUgPyB2YWx1ZXMuYXVjdGlvbkRhdGUuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSA6IG51bGwsXHJcbiAgICAgIGF1Y3Rpb25fdGltZTogdmFsdWVzLmF1Y3Rpb25UaW1lID8gdmFsdWVzLmF1Y3Rpb25UaW1lLmZvcm1hdChcIkhIOm1tXCIpIDogbnVsbCxcclxuICAgICAgcmVxdWVzdF9kYXRlOiB2YWx1ZXMucmVxdWVzdERhdGUgPyB2YWx1ZXMucmVxdWVzdERhdGUuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSA6IG51bGwsIC8vIFVwZGF0ZSByZXF1ZXN0X2RhdGVcclxuICAgIH07XHJcbiAgICBcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChgL2JpZC1yZXF1ZXN0L3VwZGF0ZS8ke2VkaXRpbmdJZH1gLCB1cGRhdGVEYXRhKTtcclxuICAgIFxyXG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgICAgZmV0Y2hCaWRSZXF1ZXN0cygpOyAvLyBSZWZyZXNoIHRhYmxlXHJcbiAgICAgIHNldElzRWRpdE1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIG1lc3NhZ2UuZXJyb3IoXCJVcGRhdGUgZmFpbGVkXCIpO1xyXG4gIH0gZmluYWxseSB7XHJcbiAgICBzZXRFZGl0TG9hZGluZyhmYWxzZSk7XHJcbiAgfVxyXG59O1xyXG5cclxuICBjb25zdCB1cGRhdGVTdGF0dXMgPSBhc3luYyAobmV3U3RhdHVzKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRFZGl0TG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgdmFsdWVzID0gYXdhaXQgZWRpdEZvcm0udmFsaWRhdGVGaWVsZHMoKTtcclxuICAgICAgY29uc3QgZ3JvdXBJbmRleCA9IHZhbHVlcy5zZWxlY3RlZEdyb3VwSW5kZXggPz8gc2VsZWN0ZWRFZGl0R3JvdXBJbmRleDtcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGVkaXRHcm91cHNbZ3JvdXBJbmRleF07XHJcblxyXG4gICAgICBpZiAoIXNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICBtZXNzYWdlLmVycm9yKFwiR3JvdXAgZGV0YWlscyBub3QgZm91bmQuIFBsZWFzZSBzZWxlY3QgYSB2YWxpZCBncm91cC5cIik7XHJcbiAgICAgICAgc2V0RWRpdExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgYXVjdGlvbkRhdGUgPSB2YWx1ZXMuYXVjdGlvbkRhdGU/LmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcbiAgICAgIGNvbnN0IGF1Y3Rpb25UaW1lID0gdmFsdWVzLmF1Y3Rpb25UaW1lPy5mb3JtYXQoXCJISDptbVwiKTtcclxuICAgICAgY29uc3QgcmVxdWVzdERhdGUgPSB2YWx1ZXMucmVxdWVzdERhdGU/LmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcblxyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIHN1YnNjcmliZXJJZDogdmFsdWVzLnN1YnNjcmliZXJJZCxcclxuICAgICAgICBzdWJzY3JpYmVyTmFtZTogdmFsdWVzLnN1YnNjcmliZXJOYW1lLFxyXG4gICAgICAgIG1vYmlsZU51bWJlcjogdmFsdWVzLm1vYmlsZU51bWJlcixcclxuICAgICAgICBjdXN0b21lcklkOiB2YWx1ZXMuY3VzdG9tZXJJZCxcclxuICAgICAgICBncm91cE5hbWU6IHNlbGVjdGVkR3JvdXAuZ3JvdXBOYW1lLFxyXG4gICAgICAgIHRpY2tldE51bWJlcjogc2VsZWN0ZWRHcm91cC50aWNrZXROdW1iZXIsXHJcbiAgICAgICAgYXVjdGlvbkRhdGU6IGF1Y3Rpb25EYXRlLFxyXG4gICAgICAgIGF1Y3Rpb25fdGltZTogYXVjdGlvblRpbWUsXHJcbiAgICAgICAgYXVjdGlvblRpbWU6IGF1Y3Rpb25UaW1lLFxyXG4gICAgICAgIHJlZmVycmVkQnk6IHZhbHVlcy5yZWZlcnJlZEJ5LFxyXG4gICAgICAgIHJlZmVycmVkX2J5OiB2YWx1ZXMucmVmZXJyZWRCeSxcclxuICAgICAgICBncm91cElkOiBzZWxlY3RlZEdyb3VwLmlkLFxyXG4gICAgICAgIGVucm9sbG1lbnRJZDogc2VsZWN0ZWRHcm91cC5lbnJvbGxtZW50SWQsXHJcbiAgICAgICAgc3RhdHVzOiBuZXdTdGF0dXMsXHJcbiAgICAgICAgcmVxdWVzdERhdGU6IHJlcXVlc3REYXRlLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXdhaXQgYXBpLnB1dChgL2JpZC1yZXF1ZXN0L3VwZGF0ZS8ke2VkaXRpbmdJZH1gLCBwYXlsb2FkKTtcclxuXHJcbiAgICAgIGNvbnN0IHN0YXR1c01lc3NhZ2VzID0ge1xyXG4gICAgICAgIFBlbmRpbmc6IFwiQmlkIFJlcXVlc3QgbW92ZWQgdG8gUGVuZGluZyBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICBBY2NlcHQ6IFwiQmlkIFJlcXVlc3QgYWNjZXB0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgUmVqZWN0OiBcIkJpZCBSZXF1ZXN0IHJlamVjdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIE5leHRBdWN0aW9uOiBcIlBvc3QgdG8gTmV4dCBBdWN0aW9uIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIFByaXplZDogXCJCaWQgUmVxdWVzdCBtYXJrZWQgYXMgUHJpemVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFxyXG4gICAgICAgIHN0YXR1c01lc3NhZ2VzW25ld1N0YXR1c10gfHwgYFN0YXR1cyB1cGRhdGVkIHRvICR7bmV3U3RhdHVzfWAsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBoYW5kbGVDbG9zZUVkaXRNb2RhbCgpO1xyXG4gICAgICBmZXRjaEJpZFJlcXVlc3RzKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiVXBkYXRlIEVycm9yOlwiLCBlcnJvcik7XHJcbiAgICAgIGxldCBlcnJvck1lc3NhZ2UgPSBcIkZhaWxlZCB0byB1cGRhdGUgc3RhdHVzLlwiO1xyXG4gICAgICBpZiAoZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UpIHtcclxuICAgICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2U7XHJcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3IucmVzcG9uc2U/LmRhdGE/LmVycm9ycykge1xyXG4gICAgICAgIGVycm9yTWVzc2FnZSA9IE9iamVjdC52YWx1ZXMoZXJyb3IucmVzcG9uc2UuZGF0YS5lcnJvcnMpXHJcbiAgICAgICAgICAuZmxhdCgpXHJcbiAgICAgICAgICAuam9pbihcIiwgXCIpO1xyXG4gICAgICB9IGVsc2UgaWYgKGVycm9yLmVycm9yRmllbGRzKSB7XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IuZXJyb3JGaWVsZHNcclxuICAgICAgICAgIC5tYXAoKGYpID0+IGAke2YubmFtZS5qb2luKFwiLlwiKX06ICR7Zi5lcnJvcnMuam9pbihcIiwgXCIpfWApXHJcbiAgICAgICAgICAuam9pbihcIjsgXCIpO1xyXG4gICAgICB9XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoZXJyb3JNZXNzYWdlKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldEVkaXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZXRQZW5kaW5nID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgYXdhaXQgdXBkYXRlU3RhdHVzKFwiUGVuZGluZ1wiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNldEFjY2VwdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IHVwZGF0ZVN0YXR1cyhcIkFjY2VwdFwiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNldFJlamVjdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IHVwZGF0ZVN0YXR1cyhcIlJlamVjdFwiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNldE5leHRBdWN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgYXdhaXQgdXBkYXRlU3RhdHVzKFwiTmV4dEF1Y3Rpb25cIik7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVTZXRQcml6ZWQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCB1cGRhdGVTdGF0dXMoXCJQcml6ZWRcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hJbml0aWFsRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGdyb3VwUmVzID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgIHNldEdyb3Vwcyhncm91cFJlcy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBpbml0aWFsIGRhdGFcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUVkaXQgPSAoaXRlbSkgPT4ge1xyXG4gICAgaGFuZGxlT3BlbkVkaXRNb2RhbChpdGVtKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTaGFyZSA9IChpdGVtKSA9PiB7XHJcbiAgICBzZXRPcGVuQWN0aW9uSWQobnVsbCk7XHJcbiAgICBjb25zdCBmcm9udGVuZFVybCA9IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW47XHJcbiAgICBjb25zdCBmdWxsVXJsID0gYCR7ZnJvbnRlbmRVcmx9L2JpZC1yZXF1ZXN0L3NoYXJlLyR7aXRlbS5rZXl9YDtcclxuICAgIHdpbmRvdy5vcGVuKGZ1bGxVcmwsIFwiX2JsYW5rXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVByaW50ID0gKGl0ZW0pID0+IHtcclxuICAgIHNldE9wZW5BY3Rpb25JZChudWxsKTtcclxuICAgIGNvbnN0IHByaW50V2luZG93ID0gd2luZG93Lm9wZW4oXCJcIiwgXCJfYmxhbmtcIik7XHJcbiAgICBjb25zdCBwcmludENvbnRlbnQgPSBgXHJcbiAgICAgIDwhRE9DVFlQRSBodG1sPlxyXG4gICAgICA8aHRtbD5cclxuICAgICAgPGhlYWQ+XHJcbiAgICAgICAgPHRpdGxlPkJpZCBSZXF1ZXN0IERldGFpbHM8L3RpdGxlPlxyXG4gICAgICAgIDxzdHlsZT5cclxuICAgICAgICAgIGJvZHkgeyBmb250LWZhbWlseTogQXJpYWwsIHNhbnMtc2VyaWY7IHBhZGRpbmc6IDIwcHg7IH1cclxuICAgICAgICAgIHRhYmxlIHsgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTsgd2lkdGg6IDEwMCU7IG1hcmdpbi10b3A6IDIwcHg7IH1cclxuICAgICAgICAgIHRoLCB0ZCB7IGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7IHBhZGRpbmc6IDhweDsgdGV4dC1hbGlnbjogbGVmdDsgfVxyXG4gICAgICAgICAgdGggeyBiYWNrZ3JvdW5kLWNvbG9yOiAjZjJmMmYyOyB9XHJcbiAgICAgICAgPC9zdHlsZT5cclxuICAgICAgPC9oZWFkPlxyXG4gICAgICA8Ym9keT5cclxuICAgICAgICA8aDE+QmlkIFJlcXVlc3QgRGV0YWlsczwvaDE+XHJcbiAgICAgICAgPHRhYmxlPlxyXG4gICAgICAgICAgPHRyPjx0aD5GaWVsZDwvdGg+PHRoPlZhbHVlPC90aD48L3RyPlxyXG4gICAgICAgICAgPHRyPjx0ZD5CaWQgUmVxdWVzdCBDb2RlPC90ZD48dGQ+JHtpdGVtLmJpZF9yZXF1ZXN0X2NvZGV9PC90ZD48L3RyPlxyXG4gICAgICAgICAgPHRyPjx0ZD5TdWJzY3JpYmVyIE5hbWU8L3RkPjx0ZD4ke2l0ZW0udXNlcl9uYW1lfTwvdGQ+PC90cj5cclxuICAgICAgICAgIDx0cj48dGQ+R3JvdXAgTmFtZTwvdGQ+PHRkPiR7aXRlbS5ncm91cF9uYW1lfTwvdGQ+PC90cj5cclxuICAgICAgICAgIDx0cj48dGQ+VGlja2V0IE51bWJlcjwvdGQ+PHRkPiR7aXRlbS50aWNrZXRfbnVtYmVyfTwvdGQ+PC90cj5cclxuICAgICAgICAgIDx0cj48dGQ+QXVjdGlvbiBEYXRlPC90ZD48dGQ+JHtpdGVtLmF1Y3Rpb25fZGF0ZX08L3RkPjwvdHI+XHJcbiAgICAgICAgICA8dHI+PHRkPkluc3RhbmNlIEJhbGFuY2UgKEF0IFJlcXVlc3QpPC90ZD48dGQ+JHtpdGVtLmluc3RhbmNlX2JhbGFuY2V9PC90ZD48L3RyPlxyXG4gICAgICAgICAgPHRyPjx0ZD5DdXJyZW50IEJhbGFuY2U8L3RkPjx0ZD4ke2l0ZW0uYmFsYW5jZX08L3RkPjwvdHI+XHJcbiAgICAgICAgICA8dHI+PHRkPlN0YXR1czwvdGQ+PHRkPiR7dHlwZW9mIGl0ZW0uc3RhdHVzID09PSBcIm9iamVjdFwiID8gaXRlbS5zdGF0dXMucHJvcHMuY2hpbGRyZW4gOiBpdGVtLnN0YXR1c308L3RkPjwvdHI+XHJcbiAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgIDwvYm9keT5cclxuICAgICAgPC9odG1sPlxyXG4gICAgYDtcclxuICAgIHByaW50V2luZG93LmRvY3VtZW50LndyaXRlKHByaW50Q29udGVudCk7XHJcbiAgICBwcmludFdpbmRvdy5kb2N1bWVudC5jbG9zZSgpO1xyXG4gICAgcHJpbnRXaW5kb3cucHJpbnQoKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb25maXJtRGVsZXRlID0gKGlkKSA9PiB7XHJcbiAgICBzZXRPcGVuQWN0aW9uSWQobnVsbCk7XHJcbiAgICBBbnRNb2RhbC5jb25maXJtKHtcclxuICAgICAgdGl0bGU6IFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGJpZCByZXF1ZXN0P1wiLFxyXG4gICAgICBjb250ZW50OiBcIlRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuXCIsXHJcbiAgICAgIG9rVGV4dDogXCJZZXNcIixcclxuICAgICAgb2tUeXBlOiBcImRhbmdlclwiLFxyXG4gICAgICBjYW5jZWxUZXh0OiBcIk5vXCIsXHJcbiAgICAgIG9uT2soKSB7XHJcbiAgICAgICAgaGFuZGxlRGVsZXRlKGlkKTtcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2JpZC1yZXF1ZXN0L2RlbGV0ZS8ke2lkfWApO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJCaWQgcmVxdWVzdCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgZmV0Y2hCaWRSZXF1ZXN0cygpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBkZWxldGUgYmlkIHJlcXVlc3RcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVG9nZ2xlQWN0aW9uID0gdXNlQ2FsbGJhY2soKGUsIGlkKSA9PiB7XHJcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IHJlY3QgPSBlLmN1cnJlbnRUYXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcblxyXG4gICAgc2V0T3BlbkFjdGlvbklkKChwcmV2SWQpID0+IHtcclxuICAgICAgaWYgKHByZXZJZCA9PT0gaWQpIHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXREcm9wZG93blBvcyh7XHJcbiAgICAgICAgICB0b3A6IHJlY3QuYm90dG9tICsgd2luZG93LnNjcm9sbFkgKyA1LFxyXG4gICAgICAgICAgbGVmdDogcmVjdC5yaWdodCAtIDE2MCxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hCaWRSZXF1ZXN0cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xyXG4gICAgICBpZiAoZmlsdGVycy52aWV3VHlwZSkgcGFyYW1zLnR5cGUgPSBmaWx0ZXJzLnZpZXdUeXBlO1xyXG4gICAgICBpZiAoZmlsdGVycy5ncm91cElkKSBwYXJhbXMuZ3JvdXBJZCA9IGZpbHRlcnMuZ3JvdXBJZDtcclxuICAgICAgaWYgKGZpbHRlcnMudXNlcklkKSBwYXJhbXMudXNlcklkID0gZmlsdGVycy51c2VySWQ7XHJcbiAgICAgIGlmIChmaWx0ZXJzLnN0YXR1cykgcGFyYW1zLnN0YXR1cyA9IGZpbHRlcnMuc3RhdHVzO1xyXG4gICAgICBpZiAoZmlsdGVycy5wYXltZW50U3RhdHVzKSBwYXJhbXMucGF5bWVudFN0YXR1cyA9IGZpbHRlcnMucGF5bWVudFN0YXR1cztcclxuICAgICAgaWYgKGZpbHRlcnMuc3RhcnREYXRlKSBwYXJhbXMuc3RhcnREYXRlID0gZmlsdGVycy5zdGFydERhdGU7XHJcbiAgICAgIGlmIChmaWx0ZXJzLmVuZERhdGUpIHBhcmFtcy5lbmREYXRlID0gZmlsdGVycy5lbmREYXRlO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2JpZC1yZXF1ZXN0L2dldC1hbGxcIiwgeyBwYXJhbXMgfSk7XHJcblxyXG4gICAgICBcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuZGF0YSkge1xyXG4gICAgICAgIHNldFJhd0JpZFJlcXVlc3RzRGF0YShyZXNwb25zZS5kYXRhLmRhdGEpO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHVzZXJPYmplY3QgPSBpdGVtPy5zdWJzY3JpYmVySWQgfHwge307XHJcbiAgICAgICAgICBjb25zdCBncm91cE9iamVjdCA9IGl0ZW0/Lmdyb3VwSWQgfHwge307XHJcblxyXG4gICAgICAgICAgY29uc3QgY3VycmVudEJhbGFuY2UgPSBpdGVtPy5hdWN0aW9ucz8uYmFsYW5jZSB8fCAwO1xyXG4gICAgICAgICAgY29uc3QgaW5zdGFuY2VCYWxhbmNlID0gaXRlbT8uaW5zdGFuY2VCYWxhbmNlIHx8IDA7XHJcbiAgICAgICAgICBjb25zdCByZXF1ZXN0U291cmNlID0gaXRlbT8uc291cmNlIHx8IFwiQ2hpdC1BZG1pblwiO1xyXG5cclxuICAgICAgICAgICBjb25zdCBhbW91bnRQYWlkID0gaXRlbT8uYXVjdGlvbnM/LmFtb3VudF9wYWlkIHx8IGl0ZW0/LmFtb3VudF9wYWlkIHx8IDA7XHJcbiAgICAgICAgICBjb25zdCBnZXRTdGF0dXNUYWcgPSAoc3RhdHVzKSA9PiB7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBtYXBwZWRTdGF0dXMgPSBzdGF0dXMgPT09IFwiRGVjbGluZVwiID8gXCJSZWplY3RcIiA6IHN0YXR1cztcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGNvbnN0IHN0YXR1c0NvbG9ycyA9IHtcclxuICAgICAgICAgICAgICBQZW5kaW5nOiBcIm9yYW5nZVwiLFxyXG4gICAgICAgICAgICAgIEFjY2VwdDogXCJncmVlblwiLFxyXG4gICAgICAgICAgICAgIFJlamVjdDogXCJyZWRcIixcclxuICAgICAgICAgICAgICBEZWNsaW5lOiBcInJlZFwiLCAgLy8gQWRkIHRoaXMgbGluZVxyXG4gICAgICAgICAgICAgIE5leHRBdWN0aW9uOiBcImJsdWVcIixcclxuICAgICAgICAgICAgICBQcml6ZWQ6IFwicHVycGxlXCIsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPFRhZyBjb2xvcj17c3RhdHVzQ29sb3JzW21hcHBlZFN0YXR1c10gfHwgXCJkZWZhdWx0XCJ9PlxyXG4gICAgICAgICAgICAgICAge21hcHBlZFN0YXR1cyA9PT0gXCJSZWplY3RcIiA/IFwiUmVqZWN0XCIgOiBzdGF0dXMgfHwgXCJQZW5kaW5nXCJ9XHJcbiAgICAgICAgICAgICAgPC9UYWc+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGtleTogaXRlbS5faWQsXHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIGJpZF9yZXF1ZXN0X2NvZGU6IGl0ZW0uYmlkX3JlcXVlc3RfY29kZSB8fCBgQlItJHtpbmRleCArIDF9YCxcclxuICAgICAgICAgICAgcmVxdWVzdF9kYXRlOiBpdGVtPy5yZXF1ZXN0X2RhdGVcclxuICAgICAgICAgICAgPyBkYXlqcyhpdGVtLnJlcXVlc3RfZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKVxyXG4gICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHJlcXVlc3RfZGF0ZV9yYXc6IGl0ZW0ucmVxdWVzdF9kYXRlLFxyXG4gICAgICAgICAgICB1c2VyX25hbWU6XHJcbiAgICAgICAgICAgICAgaXRlbS5zdWJzY3JpYmVyTmFtZSB8fFxyXG4gICAgICAgICAgICAgICh0eXBlb2YgdXNlck9iamVjdCA9PT0gXCJvYmplY3RcIiA/IHVzZXJPYmplY3QuZnVsbF9uYW1lIDogXCJOL0FcIiksXHJcbiAgICAgICAgICAgIGdyb3VwX25hbWU6XHJcbiAgICAgICAgICAgICAgaXRlbS5ncm91cE5hbWUgfHxcclxuICAgICAgICAgICAgICAodHlwZW9mIGdyb3VwT2JqZWN0ID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgICAgICAgICA/IGdyb3VwT2JqZWN0Lmdyb3VwX25hbWVcclxuICAgICAgICAgICAgICAgIDogXCJOL0FcIiksXHJcbiAgICAgICAgICAgIHRpY2tldF9udW1iZXI6IGl0ZW0udGlja2V0TnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGU6IGl0ZW0uYXVjdGlvbkRhdGVcclxuICAgICAgICAgICAgICA/IGRheWpzKGl0ZW0uYXVjdGlvbkRhdGUpLmZvcm1hdChcIkRELU1NLVlZWVlcIilcclxuICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fdGltZTogaXRlbS5hdWN0aW9uX3RpbWVcclxuICAgICAgICAgICAgICA/IGRheWpzKGl0ZW0uYXVjdGlvbl90aW1lLCBcIkhIOm1tXCIpLmZvcm1hdChcImg6bW0gQVwiKVxyXG4gICAgICAgICAgICAgIDogXCItXCIsXHJcblxyXG4gICAgICAgICAgICBzb3VyY2U6IHJlcXVlc3RTb3VyY2UsXHJcbiAgICAgICAgICAgIHNvdXJjZV9yYXc6IHJlcXVlc3RTb3VyY2UsXHJcbiAgICAgICAgICAgIGluc3RhbmNlX2JhbGFuY2U6IChcclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgaW5zdGFuY2VCYWxhbmNlIDw9IDBcclxuICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtcmVkLTYwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICDigrkge2luc3RhbmNlQmFsYW5jZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgaW5zdGFuY2VfYmFsYW5jZV9yYXc6IGluc3RhbmNlQmFsYW5jZSxcclxuXHJcbiAgICAgICAgICAgIGJhbGFuY2U6IChcclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgY3VycmVudEJhbGFuY2UgPD0gMFxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LWdyZWVuLTYwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIOKCuSB7Y3VycmVudEJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIGJhbGFuY2VfcmF3OiBjdXJyZW50QmFsYW5jZSxcclxuXHJcbiAgICAgICAgICAgIGFtb3VudF9wYWlkOiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgIOKCuSB7YW1vdW50UGFpZC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgYW1vdW50X3BhaWRfcmF3OiBhbW91bnRQYWlkLFxyXG5cclxuICAgICAgICAgICAgc3RhdHVzOiBnZXRTdGF0dXNUYWcoaXRlbS5zdGF0dXMpLFxyXG4gICAgICAgICAgICBzdGF0dXNfcmF3OiBpdGVtLnN0YXR1cyB8fCBcIlBlbmRpbmdcIixcclxuICAgICAgICAgICAgcmVmZXJyZWRfYnk6IGl0ZW0ucmVmZXJyZWRfYnkgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgbmV4dF9hdWN0aW9uX2RhdGU6IGl0ZW0ubGF0ZXN0X2F1Y3Rpb24/Lm5leHRfZGF0ZVxyXG4gICAgICAgICAgICAgID8gZGF5anMoaXRlbS5sYXRlc3RfYXVjdGlvbi5uZXh0X2RhdGUpLmZvcm1hdChcIkRELU1NLVlZWVlcIilcclxuICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHJhd0RhdGE6IGl0ZW0sXHJcbiAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdGV4dC1jZW50ZXIgZHJvcGRvd24tdHJpZ2dlclwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlVG9nZ2xlQWN0aW9uKGUsIGl0ZW0uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1ncmF5LTIwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQWN0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIOKLrlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRBbGxCaWRSZXF1ZXN0cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICBzZXRCaWRSZXF1ZXN0cyhmb3JtYXR0ZWREYXRhKTtcclxuXHJcbiAgICAgICAgY2FsY3VsYXRlT3ZlcnZpZXcocmVzcG9uc2UuZGF0YS5kYXRhKTtcclxuICAgICAgICBjYWxjdWxhdGVHcm91cFN0YXRzKHJlc3BvbnNlLmRhdGEuZGF0YSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFsbEJpZFJlcXVlc3RzKFtdKTtcclxuICAgICAgc2V0QmlkUmVxdWVzdHMoW10pO1xyXG4gICAgICBzZXRSYXdCaWRSZXF1ZXN0c0RhdGEoW10pO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yIGZldGNoaW5nIGJpZCByZXF1ZXN0c1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFRpbWVvdXQoXHJcbiAgICAgICAgKCkgPT4gc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKSxcclxuICAgICAgICAzMDAwLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYmlkIHJlcXVlc3RzOlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBoYW5kbGVDbGlja091dHNpZGUgPSAoZXZlbnQpID0+IHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgIG9wZW5BY3Rpb25JZCAmJlxyXG4gICAgICAgICFldmVudC50YXJnZXQuY2xvc2VzdChcIi5kcm9wZG93bi10cmlnZ2VyXCIpICYmXHJcbiAgICAgICAgIWV2ZW50LnRhcmdldC5jbG9zZXN0KFwiLmRyb3Bkb3duLW1lbnVcIilcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0T3BlbkFjdGlvbklkKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZWRvd25cIiwgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcclxuICB9LCBbb3BlbkFjdGlvbklkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhbGxDaGVja2VkID1cclxuICAgICAgYmlkUmVxdWVzdHMubGVuZ3RoID4gMCAmJlxyXG4gICAgICBiaWRSZXF1ZXN0cy5ldmVyeSgoaXRlbSkgPT4gYWN0aXZlVXNlckRhdGFbaXRlbS5rZXldPy5pbmZvPy5zdGF0dXMpO1xyXG4gICAgc2V0U2VsZWN0QWxsKGFsbENoZWNrZWQpO1xyXG4gIH0sIFtiaWRSZXF1ZXN0cywgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQXBwbHlGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0RmlsdGVycyh7XHJcbiAgICAgIGdyb3VwSWQ6IHRlbXBHcm91cElkLFxyXG4gICAgICB1c2VySWQ6IGZpbHRlcnMudXNlcklkLFxyXG4gICAgICBzdGF0dXM6IHRlbXBTdGF0dXMsXHJcbiAgICAgIHBheW1lbnRTdGF0dXM6IHRlbXBQYXltZW50U3RhdHVzLFxyXG4gICAgICBzdGFydERhdGU6IHRlbXBGcm9tRGF0ZSA/IHRlbXBGcm9tRGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogXCJcIixcclxuICAgICAgZW5kRGF0ZTogdGVtcFRvRGF0ZSA/IHRlbXBUb0RhdGUuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSA6IFwiXCIsXHJcbiAgICAgIHZpZXdUeXBlOiBmaWx0ZXJzLnZpZXdUeXBlLFxyXG4gICAgfSk7XHJcbiAgICBzZXRBY3RpdmVVc2VyRGF0YSh7fSk7XHJcbiAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgbWVzc2FnZS5zdWNjZXNzKFwiRmlsdGVycyBhcHBsaWVkXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsZWFyRmlsdGVycyA9ICgpID0+IHtcclxuICAgIHNldFRlbXBHcm91cElkKFwiXCIpO1xyXG4gICAgc2V0VGVtcFN0YXR1cyhcIlwiKTtcclxuICAgIHNldFRlbXBQYXltZW50U3RhdHVzKFwiXCIpO1xyXG4gICAgc2V0VGVtcEZyb21EYXRlKG51bGwpO1xyXG4gICAgc2V0VGVtcFRvRGF0ZShudWxsKTtcclxuICAgIHNldEZpbHRlcnMoe1xyXG4gICAgICBncm91cElkOiBcIlwiLFxyXG4gICAgICB1c2VySWQ6IFwiXCIsXHJcbiAgICAgIHN0YXR1czogXCJcIixcclxuICAgICAgcGF5bWVudFN0YXR1czogXCJcIixcclxuICAgICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgICB2aWV3VHlwZTogXCJhbGxcIixcclxuICAgIH0pO1xyXG4gICAgc2V0QWN0aXZlVXNlckRhdGEoe30pO1xyXG4gICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIkZpbHRlcnMgY2xlYXJlZFwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjYWxjdWxhdGVPdmVydmlld0Zyb21EYXRhID0gKGRhdGEpID0+IHtcclxuICAgIGNvbnN0IHRvdGFsUmVxdWVzdHMgPSBkYXRhPy5sZW5ndGggfHwgMDtcclxuICAgIGNvbnN0IHBlbmRpbmdSZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGE/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzX3JhdyA9PT0gXCJQZW5kaW5nXCIpPy5sZW5ndGggfHwgMDtcclxuICAgIGNvbnN0IGFjY2VwdFJlcXVlc3RzID1cclxuICAgICAgZGF0YT8uZmlsdGVyKChpdGVtKSA9PiBpdGVtPy5zdGF0dXNfcmF3ID09PSBcIkFjY2VwdFwiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCByZWplY3RSZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGE/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzX3JhdyA9PT0gXCJSZWplY3RcIik/Lmxlbmd0aCB8fCAwO1xyXG4gICAgY29uc3QgbmV4dEF1Y3Rpb25SZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGE/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzX3JhdyA9PT0gXCJOZXh0QXVjdGlvblwiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCBwcml6ZWRSZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGE/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzX3JhdyA9PT0gXCJQcml6ZWRcIik/Lmxlbmd0aCB8fCAwO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsUGFpZEFtb3VudCA9XHJcbiAgICAgIGRhdGE/LnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyAoaXRlbT8uYmFsYW5jZV9yYXcgfHwgMCksIDApIHx8IDA7XHJcblxyXG4gICAgc2V0T3ZlcnZpZXcoe1xyXG4gICAgICB0b3RhbFJlcXVlc3RzLFxyXG4gICAgICB0b3RhbFBhaWRBbW91bnQsXHJcbiAgICAgIHBlbmRpbmdSZXF1ZXN0cyxcclxuICAgICAgYWNjZXB0UmVxdWVzdHMsXHJcbiAgICAgIHJlamVjdFJlcXVlc3RzLFxyXG4gICAgICBuZXh0QXVjdGlvblJlcXVlc3RzLFxyXG4gICAgICBwcml6ZWRSZXF1ZXN0cyxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNhbGN1bGF0ZUdyb3VwU3RhdHNGcm9tRGF0YSA9IChkYXRhKSA9PiB7XHJcbiAgICBjb25zdCBzdGF0c01hcCA9IG5ldyBNYXAoKTtcclxuXHJcbiAgICBkYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgY29uc3QgZ3JvdXBOYW1lID0gaXRlbS5ncm91cF9uYW1lO1xyXG4gICAgICBpZiAoIWdyb3VwTmFtZSB8fCBncm91cE5hbWUgPT09IFwiTi9BXCIpIHJldHVybjtcclxuXHJcbiAgICAgIGlmICghc3RhdHNNYXAuaGFzKGdyb3VwTmFtZSkpIHtcclxuICAgICAgICBzdGF0c01hcC5zZXQoZ3JvdXBOYW1lLCB7XHJcbiAgICAgICAgICBncm91cE5hbWUsXHJcbiAgICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICAgIHBlbmRpbmc6IDAsXHJcbiAgICAgICAgICBhY2NlcHQ6IDAsXHJcbiAgICAgICAgICByZWplY3Q6IDAsXHJcbiAgICAgICAgICBuZXh0QXVjdGlvbjogMCxcclxuICAgICAgICAgIHByaXplZDogMCxcclxuICAgICAgICAgIHRvdGFsQmFsYW5jZTogMCxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3Qgc3RhdHMgPSBzdGF0c01hcC5nZXQoZ3JvdXBOYW1lKTtcclxuICAgICAgc3RhdHMudG90YWwrKztcclxuICAgICAgc3RhdHMudG90YWxCYWxhbmNlICs9IGl0ZW0uYmFsYW5jZV9yYXcgfHwgMDtcclxuXHJcbiAgICAgIHN3aXRjaCAoaXRlbS5zdGF0dXNfcmF3KSB7XHJcbiAgICAgICAgY2FzZSBcIlBlbmRpbmdcIjpcclxuICAgICAgICAgIHN0YXRzLnBlbmRpbmcrKztcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJBY2NlcHRcIjpcclxuICAgICAgICAgIHN0YXRzLmFjY2VwdCsrO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcIlJlamVjdFwiOlxyXG4gICAgICAgICAgc3RhdHMucmVqZWN0Kys7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiTmV4dEF1Y3Rpb25cIjpcclxuICAgICAgICAgIHN0YXRzLm5leHRBdWN0aW9uKys7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiUHJpemVkXCI6XHJcbiAgICAgICAgICBzdGF0cy5wcml6ZWQrKztcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0R3JvdXBTdGF0cyhBcnJheS5mcm9tKHN0YXRzTWFwLnZhbHVlcygpKSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FsY3VsYXRlT3ZlcnZpZXcgPSAoZGF0YSkgPT4ge1xyXG4gICAgY29uc3QgdG90YWxSZXF1ZXN0cyA9IGRhdGE/Lmxlbmd0aCB8fCAwO1xyXG4gICAgY29uc3QgcGVuZGluZ1JlcXVlc3RzID1cclxuICAgICAgZGF0YT8uZmlsdGVyKChpdGVtKSA9PiBpdGVtPy5zdGF0dXMgPT09IFwiUGVuZGluZ1wiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCBhY2NlcHRSZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGE/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzID09PSBcIkFjY2VwdFwiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCByZWplY3RSZXF1ZXN0cyA9XHJcbiAgICAgIGRhdGE/LmZpbHRlcigoaXRlbSkgPT4gaXRlbT8uc3RhdHVzID09PSBcInJlamVjdFwiKT8ubGVuZ3RoIHx8IDA7XHJcbiAgICBjb25zdCBuZXh0QXVjdGlvblJlcXVlc3RzID1cclxuICAgICAgZGF0YT8uZmlsdGVyKChpdGVtKSA9PiBpdGVtPy5zdGF0dXMgPT09IFwiTmV4dEF1Y3Rpb25cIik/Lmxlbmd0aCB8fCAwO1xyXG4gICAgY29uc3QgcHJpemVkUmVxdWVzdHMgPVxyXG4gICAgICBkYXRhPy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0/LnN0YXR1cyA9PT0gXCJQcml6ZWRcIik/Lmxlbmd0aCB8fCAwO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsUGFpZEFtb3VudCA9XHJcbiAgICAgIGRhdGE/LnJlZHVjZShcclxuICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyAoaXRlbT8ucGF5bWVudHM/LnRvdGFsUGFpZEFtb3VudCB8fCAwKSxcclxuICAgICAgICAwLFxyXG4gICAgICApIHx8IDA7XHJcbiAgICAgICBcclxuICAgICAgIGNvbnN0IHRvdGFsQW1vdW50UGFpZCA9IGRhdGE/LnJlZHVjZShcclxuICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChpdGVtPy5hdWN0aW9ucz8uYW1vdW50X3BhaWQgfHwgaXRlbT8uYW1vdW50X3BhaWQgfHwgMCksXHJcbiAgICAwLFxyXG4gICkgfHwgMDtcclxuXHJcbiAgICBzZXRPdmVydmlldyh7XHJcbiAgICAgIHRvdGFsUmVxdWVzdHMsXHJcbiAgICAgIHRvdGFsUGFpZEFtb3VudCxcclxuICAgICAgIHRvdGFsQW1vdW50UGFpZCxcclxuICAgICAgcGVuZGluZ1JlcXVlc3RzLFxyXG4gICAgICBhY2NlcHRSZXF1ZXN0cyxcclxuICAgICAgcmVqZWN0UmVxdWVzdHMsXHJcbiAgICAgIG5leHRBdWN0aW9uUmVxdWVzdHMsXHJcbiAgICAgIHByaXplZFJlcXVlc3RzLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FsY3VsYXRlR3JvdXBTdGF0cyA9IChkYXRhKSA9PiB7XHJcbiAgICBjb25zdCBzdGF0c01hcCA9IG5ldyBNYXAoKTtcclxuXHJcbiAgICBkYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgY29uc3QgZ3JvdXBPYmplY3QgPSBpdGVtPy5ncm91cElkIHx8IHt9O1xyXG4gICAgICBjb25zdCBncm91cE5hbWUgPVxyXG4gICAgICAgIGl0ZW0/Lmdyb3VwTmFtZSB8fFxyXG4gICAgICAgICh0eXBlb2YgZ3JvdXBPYmplY3QgPT09IFwib2JqZWN0XCIgPyBncm91cE9iamVjdD8uZ3JvdXBfbmFtZSA6IFwiVW5rbm93blwiKTtcclxuICAgICAgaWYgKCFncm91cE5hbWUpIHJldHVybjtcclxuXHJcbiAgICAgIGlmICghc3RhdHNNYXAuaGFzKGdyb3VwTmFtZSkpIHtcclxuICAgICAgICBzdGF0c01hcC5zZXQoZ3JvdXBOYW1lLCB7XHJcbiAgICAgICAgICBncm91cE5hbWUsXHJcbiAgICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICAgIHBlbmRpbmc6IDAsXHJcbiAgICAgICAgICBhY2NlcHQ6IDAsXHJcbiAgICAgICAgICByZWplY3Q6IDAsXHJcbiAgICAgICAgICBuZXh0QXVjdGlvbjogMCxcclxuICAgICAgICAgIHByaXplZDogMCxcclxuICAgICAgICAgIHRvdGFsQmFsYW5jZTogMCxcclxuICAgICAgICAgIG5leHRBdWN0aW9uRGF0ZTogXCJOL0FcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3Qgc3RhdHMgPSBzdGF0c01hcC5nZXQoZ3JvdXBOYW1lKTtcclxuICAgICAgc3RhdHMudG90YWwrKztcclxuICAgICAgc3RhdHMudG90YWxCYWxhbmNlICs9IGl0ZW0uYXVjdGlvbnM/LmJhbGFuY2UgfHwgMDtcclxuXHJcbiAgICAgIHN3aXRjaCAoaXRlbS5zdGF0dXMpIHtcclxuICAgICAgICBjYXNlIFwiUGVuZGluZ1wiOlxyXG4gICAgICAgICAgc3RhdHMucGVuZGluZysrO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcIkFjY2VwdFwiOlxyXG4gICAgICAgICAgc3RhdHMuYWNjZXB0Kys7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwiUmVqZWN0XCI6XHJcbiAgICAgICAgICBzdGF0cy5yZWplY3QrKztcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJOZXh0QXVjdGlvblwiOlxyXG4gICAgICAgICAgc3RhdHMubmV4dEF1Y3Rpb24rKztcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJQcml6ZWRcIjpcclxuICAgICAgICAgIHN0YXRzLnByaXplZCsrO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBuZXh0RGF0ZSA9IGl0ZW0ubGF0ZXN0X2F1Y3Rpb24/Lm5leHRfZGF0ZTtcclxuICAgICAgaWYgKG5leHREYXRlICYmIHN0YXRzLm5leHRBdWN0aW9uRGF0ZSA9PT0gXCJOL0FcIikge1xyXG4gICAgICAgIGNvbnN0IG5leHREYXRlT2JqID0gZGF5anMobmV4dERhdGUpO1xyXG4gICAgICAgIGlmIChuZXh0RGF0ZU9iai5pc1ZhbGlkKCkpIHtcclxuICAgICAgICAgIHN0YXRzLm5leHRBdWN0aW9uRGF0ZSA9IG5leHREYXRlT2JqLmZvcm1hdChcIkRELU1NLVlZWVlcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRHcm91cFN0YXRzKEFycmF5LmZyb20oc3RhdHNNYXAudmFsdWVzKCkpKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hJbml0aWFsRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQmlkUmVxdWVzdHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWxsQmlkUmVxdWVzdHMubGVuZ3RoID4gMCkge1xyXG4gICAgICBsZXQgZmlsdGVyZWQgPSBbLi4uYWxsQmlkUmVxdWVzdHNdO1xyXG5cclxuICAgICAgaWYgKGZpbHRlcnMuZ3JvdXBJZCkge1xyXG4gICAgICAgIGNvbnN0IHNlbGVjdGVkR3JvdXAgPSBncm91cHMuZmluZCgoZykgPT4gZy5faWQgPT09IGZpbHRlcnMuZ3JvdXBJZCk7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgICAgIGZpbHRlcmVkID0gZmlsdGVyZWQuZmlsdGVyKFxyXG4gICAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5ncm91cF9uYW1lID09PSBzZWxlY3RlZEdyb3VwLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGZpbHRlcnMuc3RhdHVzKSB7XHJcbiAgICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIoXHJcbiAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5zdGF0dXNfcmF3ID09PSBmaWx0ZXJzLnN0YXR1cyxcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoZmlsdGVycy5wYXltZW50U3RhdHVzKSB7XHJcbiAgICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGNvbnN0IGJhbGFuY2UgPSBpdGVtLmJhbGFuY2VfcmF3O1xyXG4gICAgICAgICAgaWYgKGZpbHRlcnMucGF5bWVudFN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHJldHVybiBiYWxhbmNlID4gMDtcclxuICAgICAgICAgIGlmIChmaWx0ZXJzLnBheW1lbnRTdGF0dXMgPT09IFwidXB0b2RhdGVcIikgcmV0dXJuIGJhbGFuY2UgPD0gMDtcclxuICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoZmlsdGVycy5zdGFydERhdGUgfHwgZmlsdGVycy5lbmREYXRlKSB7XHJcbiAgICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGlmICghaXRlbS5yZXF1ZXN0X2RhdGVfcmF3KSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICBjb25zdCBpdGVtRGF0ZSA9IGRheWpzKGl0ZW0ucmVxdWVzdF9kYXRlX3Jhdyk7XHJcblxyXG4gICAgICAgICAgaWYgKGZpbHRlcnMuc3RhcnREYXRlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHN0YXJ0RGF0ZSA9IGRheWpzKGZpbHRlcnMuc3RhcnREYXRlKTtcclxuICAgICAgICAgICAgaWYgKGl0ZW1EYXRlLmlzQmVmb3JlKHN0YXJ0RGF0ZSwgXCJkYXlcIikpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZmlsdGVycy5lbmREYXRlKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGVuZERhdGUgPSBkYXlqcyhmaWx0ZXJzLmVuZERhdGUpO1xyXG4gICAgICAgICAgICBpZiAoaXRlbURhdGUuaXNBZnRlcihlbmREYXRlLCBcImRheVwiKSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRCaWRSZXF1ZXN0cyhmaWx0ZXJlZCk7XHJcbiAgICAgIGNhbGN1bGF0ZU92ZXJ2aWV3RnJvbURhdGEoZmlsdGVyZWQpO1xyXG4gICAgICBjYWxjdWxhdGVHcm91cFN0YXRzRnJvbURhdGEoZmlsdGVyZWQpO1xyXG4gICAgfSBlbHNlIGlmIChhbGxCaWRSZXF1ZXN0cy5sZW5ndGggPT09IDAgJiYgIWlzTG9hZGluZykge1xyXG4gICAgICBzZXRCaWRSZXF1ZXN0cyhbXSk7XHJcbiAgICAgIGNhbGN1bGF0ZU92ZXJ2aWV3RnJvbURhdGEoW10pO1xyXG4gICAgICBjYWxjdWxhdGVHcm91cFN0YXRzRnJvbURhdGEoW10pO1xyXG4gICAgfVxyXG4gIH0sIFtmaWx0ZXJzLCBhbGxCaWRSZXF1ZXN0cywgZ3JvdXBzXSk7XHJcblxyXG4gIGNvbnN0IGV4cG9ydFRvRXhjZWwgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBleHBvcnREYXRhID0gYmlkUmVxdWVzdHMubWFwKChpdGVtKSA9PiAoe1xyXG4gICAgICBcIlNMIE5vXCI6IGl0ZW0uaWQsXHJcbiAgICAgIFwiQmlkIFJlcXVlc3QgQ29kZVwiOiBpdGVtLmJpZF9yZXF1ZXN0X2NvZGUsXHJcbiAgICAgIFwiUmVxdWVzdCBEYXRlXCI6IGl0ZW0ucmVxdWVzdF9kYXRlLFxyXG4gICAgICBcIlN1YnNjcmliZXIgTmFtZVwiOiBpdGVtLnVzZXJfbmFtZSxcclxuICAgICAgXCJHcm91cCBOYW1lXCI6IGl0ZW0uZ3JvdXBfbmFtZSxcclxuICAgICAgXCJUaWNrZXQgTnVtYmVyXCI6IGl0ZW0udGlja2V0X251bWJlcixcclxuICAgICAgXCJBdWN0aW9uIERhdGVcIjogaXRlbS5hdWN0aW9uX2RhdGUsXHJcbiAgICAgIFNvdXJjZTogaXRlbS5zb3VyY2UsXHJcbiAgICAgIFwiQXVjdGlvbiBUaW1lXCI6IGl0ZW0uYXVjdGlvbl90aW1lLFxyXG4gICAgICBcIkluc3RhbmNlIEJhbGFuY2UgKEF0IFJlcXVlc3QpXCI6IGl0ZW0uaW5zdGFuY2VfYmFsYW5jZSxcclxuICAgICAgXCJDdXJyZW50IEJhbGFuY2VcIjogaXRlbS5iYWxhbmNlLFxyXG4gICAgICBTdGF0dXM6XHJcbiAgICAgICAgdHlwZW9mIGl0ZW0uc3RhdHVzID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgICA/IGl0ZW0uc3RhdHVzLnByb3BzLmNoaWxkcmVuXHJcbiAgICAgICAgICA6IGl0ZW0uc3RhdHVzLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIGNvbnN0IHdzID0gWExTWC51dGlscy5qc29uX3RvX3NoZWV0KGV4cG9ydERhdGEpO1xyXG4gICAgY29uc3Qgd2IgPSBYTFNYLnV0aWxzLmJvb2tfbmV3KCk7XHJcbiAgICBYTFNYLnV0aWxzLmJvb2tfYXBwZW5kX3NoZWV0KHdiLCB3cywgXCJCaWQgUmVxdWVzdHNcIik7XHJcbiAgICBYTFNYLndyaXRlRmlsZShcclxuICAgICAgd2IsXHJcbiAgICAgIGBCaWRfUmVxdWVzdHNfUmVwb3J0XyR7ZGF5anMoKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpfS54bHN4YCxcclxuICAgICk7XHJcbiAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJFeGNlbCBmaWxlIGRvd25sb2FkZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGV4cG9ydFRvUERGID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZG9jID0gbmV3IGpzUERGKFwibGFuZHNjYXBlXCIpO1xyXG5cclxuICAgIGRvYy5zZXRGb250U2l6ZSgxNik7XHJcbiAgICBkb2MudGV4dChcIkJpZCBSZXF1ZXN0cyBSZXBvcnRcIiwgMTQsIDE1KTtcclxuICAgIGRvYy5zZXRGb250U2l6ZSgxMCk7XHJcbiAgICBkb2MudGV4dChgR2VuZXJhdGVkIG9uOiAke2RheWpzKCkuZm9ybWF0KFwiREQtTU0tWVlZWSBISDptbTpzc1wiKX1gLCAxNCwgMjIpO1xyXG5cclxuICAgIGNvbnN0IHRhYmxlRGF0YSA9IGJpZFJlcXVlc3RzLm1hcCgoaXRlbSkgPT4gW1xyXG4gICAgICBpdGVtLmlkLFxyXG4gICAgICBpdGVtLmJpZF9yZXF1ZXN0X2NvZGUsXHJcbiAgICAgIGl0ZW0ucmVxdWVzdF9kYXRlLFxyXG4gICAgICBpdGVtLnVzZXJfbmFtZSxcclxuICAgICAgaXRlbS5ncm91cF9uYW1lLFxyXG4gICAgICBpdGVtLnRpY2tldF9udW1iZXIsXHJcbiAgICAgIGl0ZW0uYXVjdGlvbl9kYXRlLFxyXG4gICAgICBpdGVtLmluc3RhbmNlX2JhbGFuY2UsXHJcbiAgICAgIGl0ZW0uYmFsYW5jZSxcclxuICAgICAgdHlwZW9mIGl0ZW0uc3RhdHVzID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgPyBpdGVtLnN0YXR1cy5wcm9wcy5jaGlsZHJlblxyXG4gICAgICAgIDogaXRlbS5zdGF0dXMsXHJcbiAgICBdKTtcclxuXHJcbiAgICBkb2MuYXV0b1RhYmxlKHtcclxuICAgICAgaGVhZDogW1xyXG4gICAgICAgIFtcclxuICAgICAgICAgIFwiU0wgTm9cIixcclxuICAgICAgICAgIFwiQmlkIENvZGVcIixcclxuICAgICAgICAgIFwiUmVxIERhdGVcIixcclxuICAgICAgICAgIFwiU291cmNlXCIsXHJcbiAgICAgICAgICBcIlN1YnNjcmliZXJcIixcclxuICAgICAgICAgIFwiR3JvdXBcIixcclxuICAgICAgICAgIFwiVGlja2V0XCIsXHJcbiAgICAgICAgICBcIkF1Y3Rpb24gRGF0ZVwiLFxyXG4gICAgICAgICAgXCJJbnN0LiBCYWxhbmNlXCIsXHJcbiAgICAgICAgICBcIkN1cnIuIEJhbGFuY2VcIixcclxuICAgICAgICAgIFwiU3RhdHVzXCIsXHJcbiAgICAgICAgXSxcclxuICAgICAgXSxcclxuICAgICAgYm9keTogdGFibGVEYXRhLFxyXG4gICAgICBzdGFydFk6IDMwLFxyXG4gICAgICBzdHlsZXM6IHsgZm9udFNpemU6IDggfSxcclxuICAgICAgaGVhZFN0eWxlczogeyBmaWxsQ29sb3I6IFs0MSwgMTI4LCAxODVdIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICBkb2Muc2F2ZShgQmlkX1JlcXVlc3RzX1JlcG9ydF8ke2RheWpzKCkuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKX0ucGRmYCk7XHJcbiAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJQREYgZmlsZSBkb3dubG9hZGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBwcmludFJlcG9ydCA9ICgpID0+IHtcclxuICAgIGNvbnN0IHByaW50V2luZG93ID0gd2luZG93Lm9wZW4oXCJcIiwgXCJfYmxhbmtcIik7XHJcbiAgICBjb25zdCBzdW1tYXJ5SFRNTCA9IGBcclxuICAgICAgPCFET0NUWVBFIGh0bWw+XHJcbiAgICAgIDxodG1sPlxyXG4gICAgICA8aGVhZD5cclxuICAgICAgICA8dGl0bGU+QmlkIFJlcXVlc3RzIFJlcG9ydDwvdGl0bGU+XHJcbiAgICAgICAgPHN0eWxlPlxyXG4gICAgICAgICAgYm9keSB7IGZvbnQtZmFtaWx5OiBBcmlhbCwgc2Fucy1zZXJpZjsgcGFkZGluZzogMjBweDsgfVxyXG4gICAgICAgICAgaDEsIGgyIHsgdGV4dC1hbGlnbjogY2VudGVyOyB9XHJcbiAgICAgICAgICB0YWJsZSB7IGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7IHdpZHRoOiAxMDAlOyBtYXJnaW4tdG9wOiAyMHB4OyB9XHJcbiAgICAgICAgICB0aCwgdGQgeyBib3JkZXI6IDFweCBzb2xpZCAjZGRkOyBwYWRkaW5nOiA4cHg7IHRleHQtYWxpZ246IGxlZnQ7IH1cclxuICAgICAgICAgIHRoIHsgYmFja2dyb3VuZC1jb2xvcjogI2YyZjJmMjsgfVxyXG4gICAgICAgICAgLnN1bW1hcnktY2FyZCB7IG1hcmdpbjogMjBweCAwOyB9XHJcbiAgICAgICAgPC9zdHlsZT5cclxuICAgICAgPC9oZWFkPlxyXG4gICAgICA8Ym9keT5cclxuICAgICAgICA8aDE+QmlkIFJlcXVlc3RzIFJlcG9ydDwvaDE+XHJcbiAgICAgICAgPHAgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7XCI+R2VuZXJhdGVkIG9uOiAke2RheWpzKCkuZm9ybWF0KFwiREQtTU0tWVlZWSBISDptbTpzc1wiKX08L3A+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInN1bW1hcnktY2FyZFwiPlxyXG4gICAgICAgICAgPGgyPlN1bW1hcnkgU3RhdGlzdGljczwvaDI+XHJcbiAgICAgICAgICA8dGFibGU+XHJcbiAgICAgICAgICAgIDx0cj48dGg+TWV0cmljPC90aD48dGg+VmFsdWU8L3RoPjwvdHI+XHJcbiAgICAgICAgICAgIDx0cj48dGQ+VG90YWwgUmVxdWVzdHM8L3RkPjx0ZD4ke292ZXJ2aWV3LnRvdGFsUmVxdWVzdHN9PC90ZD48L3RyPlxyXG4gICAgICAgICAgICA8dHI+PHRkPlBlbmRpbmcgUmVxdWVzdHM8L3RkPjx0ZD4ke292ZXJ2aWV3LnBlbmRpbmdSZXF1ZXN0c308L3RkPjwvdHI+XHJcbiAgICAgICAgICAgIDx0cj48dGQ+QWNjZXB0IFJlcXVlc3RzPC90ZD48dGQ+JHtvdmVydmlldy5hY2NlcHRSZXF1ZXN0c308L3RkPjwvdHI+XHJcbiAgICAgICAgICAgIDx0cj48dGQ+UmVqZWN0IFJlcXVlc3RzPC90ZD48dGQ+JHtvdmVydmlldy5yZWplY3RSZXF1ZXN0c308L3RkPjwvdHI+XHJcbiAgICAgICAgICAgIDx0cj48dGQ+UHJpemVkIFJlcXVlc3RzPC90ZD48dGQ+JHtvdmVydmlldy5wcml6ZWRSZXF1ZXN0c308L3RkPjwvdHI+XHJcbiAgICAgICAgICAgIDx0cj48dGQ+TmV4dCBBdWN0aW9uczwvdGQ+PHRkPiR7b3ZlcnZpZXcubmV4dEF1Y3Rpb25SZXF1ZXN0c308L3RkPjwvdHI+XHJcbiAgICAgICAgICAgIDx0cj48dGQ+VG90YWwgQ3VycmVudCBEdWU8L3RkPjx0ZD7igrkke292ZXJ2aWV3LnRvdGFsUGFpZEFtb3VudC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfTwvdGQ+PC90cj5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGgyPkJpZCBSZXF1ZXN0cyBEZXRhaWxzPC9oMj5cclxuICAgICAgICA8dGFibGU+XHJcbiAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICA8dGg+U0wgTm88L3RoPlxyXG4gICAgICAgICAgICAgIDx0aD5CaWQgQ29kZTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPlJlcXVlc3QgRGF0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPlN1YnNjcmliZXI8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aD5Hcm91cDwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPlRpY2tldDwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPkF1Y3Rpb24gRGF0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPkluc3QuIEJhbGFuY2U8L3RoPiBcclxuICAgICAgICAgICAgICA8dGg+Q3Vyci4gQmFsYW5jZTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAke2JpZFJlcXVlc3RzXHJcbiAgICAgICAgICAgICAgLm1hcChcclxuICAgICAgICAgICAgICAgIChpdGVtKSA9PiBgXHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS5pZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS5iaWRfcmVxdWVzdF9jb2RlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLnJlcXVlc3RfZGF0ZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS51c2VyX25hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZD4ke2l0ZW0uZ3JvdXBfbmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS50aWNrZXRfbnVtYmVyfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLmF1Y3Rpb25fZGF0ZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS5pbnN0YW5jZV9iYWxhbmNlfTwvdGQ+IFxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS5iYWxhbmNlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+JHt0eXBlb2YgaXRlbS5zdGF0dXMgPT09IFwib2JqZWN0XCIgPyBpdGVtLnN0YXR1cy5wcm9wcy5jaGlsZHJlbiA6IGl0ZW0uc3RhdHVzfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgYCxcclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgLmpvaW4oXCJcIil9XHJcbiAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgIDwvdGFibGU+XHJcbiAgICAgIDwvYm9keT5cclxuICAgICAgPC9odG1sPlxyXG4gICAgYDtcclxuXHJcbiAgICBwcmludFdpbmRvdy5kb2N1bWVudC53cml0ZShzdW1tYXJ5SFRNTCk7XHJcbiAgICBwcmludFdpbmRvdy5kb2N1bWVudC5jbG9zZSgpO1xyXG4gICAgcHJpbnRXaW5kb3cucHJpbnQoKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgPEN1c3RvbUFsZXJ0XHJcbiAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBiZy1ncmF5LTUwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEZhR2F2ZWwgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMFwiIC8+IEFsbCBCaWQgUmVxdWVzdCBSZXBvcnRcclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICA8U3BhY2U+XHJcbiAgICAgICAgICAgIDxCdXR0b24gaWNvbj17PElvTWRSZWZyZXNoIC8+fSBvbkNsaWNrPXtmZXRjaEJpZFJlcXVlc3RzfT5cclxuICAgICAgICAgICAgICBSZWZyZXNoXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9TcGFjZT5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctc20gbWItOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTRcIj5cclxuICAgICAgICAgICAgPEZpbHRlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbS0wXCI+XHJcbiAgICAgICAgICAgICAgRmlsdGVyIE9wdGlvbnNcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsyMDBweF1cIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgREFURSBSQU5HRVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBGcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFRlbXBGcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiREQtTU0tWVlZWVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRnJvbSBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBUb0RhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRUZW1wVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICBmb3JtYXQ9XCJERC1NTS1ZWVlZXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUbyBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctWzE1MHB4XVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBGaWx0ZXIgYnkgR3JvdXBcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWxsIEdyb3Vwc1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBHcm91cElkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRUZW1wR3JvdXBJZCh2YWwgfHwgXCJcIil9XHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChnKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Zy5faWR9IHZhbHVlPXtnLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2cuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctWzE1MHB4XVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBSZXF1ZXN0IFN0YXR1c1xyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgU3RhdHVzXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFN0YXR1cyB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0VGVtcFN0YXR1cyh2YWwgfHwgXCJcIil9XHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiUGVuZGluZ1wiPlBlbmRpbmc8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFjY2VwdFwiPkFjY2VwdDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiUmVqZWN0XCI+UmVqZWN0PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJOZXh0QXVjdGlvblwiPk5leHQgQXVjdGlvbjwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiUHJpemVkXCI+UHJpemVkPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsxNTBweF1cIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgUGF5bWVudCBTdGF0dXNcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWxsIFBheW1lbnRzXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFBheW1lbnRTdGF0dXMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldFRlbXBQYXltZW50U3RhdHVzKHZhbCB8fCBcIlwiKX1cclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJwZW5kaW5nXCI+UGF5bWVudCBQZW5kaW5nPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJ1cHRvZGF0ZVwiPlVwIHRvIERhdGU8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIG1pbi13LVsxMDBweF1cIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItMSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgU0VMRUNUIEFMTFxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLTEwXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSBjdXJzb3ItcG9pbnRlciBhY2NlbnQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgICAgICAgICAgICAgICAgIGJpZFJlcXVlc3RzLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRbaXRlbS5rZXldID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiBpdGVtLnVzZXJfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnJhd0RhdGE/Lm1vYmlsZU51bWJlciB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5yYXdEYXRhPy5zdWJzY3JpYmVySWQ/LnBob25lX251bWJlciB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEodXBkYXRlZCk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PFNlYXJjaE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwbHlGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBBcHBseVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlQ2xlYXJGaWx0ZXJzfSBzaXplPVwibGFyZ2VcIj5cclxuICAgICAgICAgICAgICAgIENsZWFyXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNSBtYi04XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgcC01IHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIG9wYWNpdHktOTBcIj5Ub3RhbCBSZXF1ZXN0czwvcD5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAge292ZXJ2aWV3LnRvdGFsUmVxdWVzdHN9XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS15ZWxsb3ctNTAwIHRvLW9yYW5nZS01MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHAtNSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBvcGFjaXR5LTkwXCI+UGVuZGluZyBSZXF1ZXN0czwvcD5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAge292ZXJ2aWV3LnBlbmRpbmdSZXF1ZXN0c31cclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTUwMCB0by1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgcC01IHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIG9wYWNpdHktOTBcIj5BY2NlcHQgUmVxdWVzdHM8L3A+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIHtvdmVydmlldy5hY2NlcHRSZXF1ZXN0c31cclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXJlZC01MDAgdG8tcm9zZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHAtNSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBvcGFjaXR5LTkwXCI+UmVqZWN0IFJlcXVlc3RzPC9wPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG10LTFcIj5cclxuICAgICAgICAgICAgICB7b3ZlcnZpZXcucmVqZWN0UmVxdWVzdHN9XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNTAwIHRvLWluZGlnby02MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHAtNSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBvcGFjaXR5LTkwXCI+UHJpemVkIFJlcXVlc3RzPC9wPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG10LTFcIj5cclxuICAgICAgICAgICAgICB7b3ZlcnZpZXcucHJpemVkUmVxdWVzdHN9XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1zbGF0ZS04MDAgdG8tc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBwLTUgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gb3BhY2l0eS05MFwiPk5leHQgQXVjdGlvbjwvcD5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAge292ZXJ2aWV3Lm5leHRBdWN0aW9uUmVxdWVzdHN9XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge3NlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcm91bmRlZC1sZyBzaGFkb3cgcC00IG1iLTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtZnVsbCBoLTEwIHctMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQtbGcgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZENvdW50fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICBJdGVtcyBTZWxlY3RlZFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTMganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8V2hhdHNBcHBPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMCBib3JkZXItZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlT3BlblZlcmlmeU1vZGFsfVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtpc1NlbmRpbmd9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNlbmQgV2hhdHNBcHBcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAgYm9yZGVyLWdyZWVuLTIwMCBob3ZlcjpiZy1ncmVlbi0yMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJ1bGtTdGF0dXNVcGRhdGUoXCJBY2NlcHRcIil9XHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2J1bGtMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBY2NlcHQgQWxsXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS03MDAgYm9yZGVyLXB1cnBsZS0yMDAgaG92ZXI6YmctcHVycGxlLTIwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PFRyb3BoeU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdWxrU3RhdHVzVXBkYXRlKFwiUHJpemVkXCIpfVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtidWxrTG9hZGluZ31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgTWFyayBhcyBQcml6ZWRcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBib3JkZXItcmVkLTIwMCBob3ZlcjpiZy1yZWQtMjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdWxrU3RhdHVzVXBkYXRlKFwiUmVqZWN0XCIpfVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtidWxrTG9hZGluZ31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUmVqZWN0IEFsbFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctNzAwIGJvcmRlci15ZWxsb3ctMjAwIGhvdmVyOmJnLXllbGxvdy0yMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJ1bGtTdGF0dXNVcGRhdGUoXCJQZW5kaW5nXCIpfVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtidWxrTG9hZGluZ31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgTWFyayBQZW5kaW5nXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTEwMCB0ZXh0LW9yYW5nZS03MDAgYm9yZGVyLW9yYW5nZS0yMDAgaG92ZXI6Ymctb3JhbmdlLTIwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZShcIk5leHRBdWN0aW9uXCIpfVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtidWxrTG9hZGluZ31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUG9zdCB0byBOZXh0IEF1Y3Rpb25cclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIDxUYWJzIGFjdGl2ZUtleT17YWN0aXZlVGFifSBvbkNoYW5nZT17c2V0QWN0aXZlVGFifSBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICA8VGFiUGFuZSB0YWI9XCJCaWQgUmVxdWVzdHMgTGlzdFwiIGtleT1cImxpc3RcIj5cclxuICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSBkYXRhPVwiQmlkIFJlcXVlc3RzXCIgLz5cclxuICAgICAgICAgICAgKSA6IGJpZFJlcXVlc3RzLmxlbmd0aCA8PSAwID8gKFxyXG4gICAgICAgICAgICAgIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIEJpZCBSZXF1ZXN0IERhdGEgRm91bmRcIiAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGRhdGE9e2Rpc3BsYXlCaWRSZXF1ZXN0c31cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRDb2xzPXtleHBvcnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQmlkIFJlcXVlc3QgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJCaWRfUmVxdWVzdF9SZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9UYWJQYW5lPlxyXG4gICAgICAgIDwvVGFicz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7b3BlbkFjdGlvbklkICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJkcm9wZG93bi1tZW51IGRyb3Bkb3duLW1lbnUtZml4ZWQgYmctd2hpdGUgYm9yZGVyIHJvdW5kZWQtbGcgc2hhZG93LWxnIHctNDBcIlxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcclxuICAgICAgICAgICAgekluZGV4OiA5OTk5LFxyXG4gICAgICAgICAgICB0b3A6IGAke2Ryb3Bkb3duUG9zLnRvcH1weGAsXHJcbiAgICAgICAgICAgIGxlZnQ6IGAke2Ryb3Bkb3duUG9zLmxlZnR9cHhgLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHsoKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBpdGVtID0gYWxsQmlkUmVxdWVzdHMuZmluZCgocmVxKSA9PiByZXEua2V5ID09PSBvcGVuQWN0aW9uSWQpO1xyXG4gICAgICAgICAgICBpZiAoIWl0ZW0pIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVFZGl0KGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8RWRpdE91dGxpbmVkIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkVkaXQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVNoYXJlKGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtb3JhbmdlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTaGFyZUFsdE91dGxpbmVkIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPlNoYXJlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVQcmludChpdGVtKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHB4LTQgcHktMiBob3ZlcjpiZy1ncmF5LTEwMCB0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxQcmludGVyT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+UHJpbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpcm1EZWxldGUoaXRlbS5rZXkpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgcHgtNCBweS0yIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtcmVkLTYwMCBib3JkZXItdCBib3JkZXItZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8RGVsZXRlT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+RGVsZXRlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9KSgpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgIEJpZCBSZXF1ZXN0IERldGFpbHNcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXtzaG93TW9kYWxWaWV3fVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTaG93TW9kYWxWaWV3KGZhbHNlKX1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgd2lkdGg9ezcwMH1cclxuICAgICAgPlxyXG4gICAgICAgIHtjdXJyZW50QmlkUmVxdWVzdCAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXktNCBweS00XCI+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJCaWQgUmVxdWVzdCBDb2RlXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEJpZFJlcXVlc3QuYmlkX3JlcXVlc3RfY29kZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW1cclxuICAgICAgICAgICAgICBsYWJlbD1cIlN1YnNjcmliZXIgTmFtZVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRCaWRSZXF1ZXN0LnVzZXJfbmFtZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW1cclxuICAgICAgICAgICAgICBsYWJlbD1cIk1vYmlsZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QmlkUmVxdWVzdC5tb2JpbGVOdW1iZXIgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW1cclxuICAgICAgICAgICAgICBsYWJlbD1cIkdyb3VwIE5hbWVcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QmlkUmVxdWVzdC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8RGV0YWlsSXRlbVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiVGlja2V0IE51bWJlclwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRCaWRSZXF1ZXN0LnRpY2tldF9udW1iZXJ9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJSZXF1ZXN0IERhdGVcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QmlkUmVxdWVzdC5yZXF1ZXN0X2RhdGV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJBdWN0aW9uIERhdGVcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QmlkUmVxdWVzdC5hdWN0aW9uX2RhdGV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJBdWN0aW9uIFRpbWVcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QmlkUmVxdWVzdC5hdWN0aW9uX3RpbWV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJJbnN0YW5jZSBCYWxhbmNlIChBdCBSZXF1ZXN0KVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRCaWRSZXF1ZXN0Lmluc3RhbmNlX2JhbGFuY2V9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJDdXJyZW50IEJhbGFuY2VcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QmlkUmVxdWVzdC5iYWxhbmNlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8RGV0YWlsSXRlbVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiTmV4dCBBdWN0aW9uIERhdGVcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QmlkUmVxdWVzdC5uZXh0X2F1Y3Rpb25fZGF0ZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW1cclxuICAgICAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIEJ5XCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEJpZFJlcXVlc3QucmVmZXJyZWRfYnl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiU3RhdHVzXCIgdmFsdWU9e2N1cnJlbnRCaWRSZXF1ZXN0LnN0YXR1c30gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQW50TW9kYWw+XHJcblxyXG4gICAgICA8QW50TW9kYWxcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iLTIgYm9yZGVyLWJsdWUtOTAwIHBiLTNcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtYmx1ZS05MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgRWRpdCBCaWQgUmVxdWVzdFxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9wZW49e2lzRWRpdE1vZGFsT3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17aGFuZGxlQ2xvc2VFZGl0TW9kYWx9XHJcbiAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4gICAgICAgIHdpZHRoPXs5MDB9XHJcbiAgICAgICAgZGVzdHJveU9uQ2xvc2VcclxuICAgICAgPlxyXG4gICAgICAgIDxGb3JtIGZvcm09e2VkaXRGb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS05MDAgbWItMyBib3JkZXItYiBwYi0xXCI+XHJcbiAgICAgICAgICAgICAgU3Vic2NyaWJlciBEZXRhaWxzXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBiZy1ncmF5LTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cInN1YnNjcmliZXJJZFwiIGhpZGRlbj5cclxuICAgICAgICAgICAgICAgIDxJbnB1dCAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgQmlkIFJlcXVlc3QgQ29kZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImJpZF9yZXF1ZXN0X2NvZGVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBDcmVhdGVkIEJ5IChBZG1pbilcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhZG1pbk5hbWVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBTdWJzY3JpYmVyIE5hbWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJzdWJzY3JpYmVyTmFtZVwiIGNsYXNzTmFtZT1cIm1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXItZ3JheS0zMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIE1vYmlsZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJtb2JpbGVOdW1iZXJcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciBJRFxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImN1c3RvbWVySWRcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge2VkaXRHcm91cHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgR3JvdXAgZm9yIEJpZCBSZXF1ZXN0e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInNlbGVjdGVkR3JvdXBJbmRleFwiXHJcbiAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJSZXF1aXJlZCFcIiB9XX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNob29zZSB3aGljaCBncm91cC4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVkaXRHcm91cFNlbGVjdH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFZGl0R3JvdXBJbmRleH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7ZWRpdEdyb3Vwcy5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e2dyb3VwLmlkfSB2YWx1ZT17aW5kZXh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBOYW1lfSAoVGlja2V0OiB7Z3JvdXAudGlja2V0TnVtYmVyfSlcclxuICAgICAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIFN0YXJ0IERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cInN0YXJ0RGF0ZVwiIGNsYXNzTmFtZT1cIm1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIGJvcmRlci1ibHVlLTIwMCB0ZXh0LWJsdWUtOTAwIGZvbnQtc2VtaWJvbGQgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIEVuZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJlbmREYXRlXCIgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgYm9yZGVyLWJsdWUtMjAwIHRleHQtYmx1ZS05MDAgZm9udC1zZW1pYm9sZCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbnMgRG9uZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiYXVjdGlvbnNEb25lXCIgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwIGJvcmRlci1ncmVlbi0yMDAgdGV4dC1ncmVlbi05MDAgZm9udC1ib2xkIHRleHQtY2VudGVyIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUaWNrZXQgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJ0aWNrZXROdW1iZXJcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGQgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIE5hbWVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZ3JvdXBOYW1lXCIgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGJvcmRlci1ncmF5LTMwMCBmb250LXNlbWlib2xkIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04IGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8U3BpbiBzaXplPVwibGFyZ2VcIiB0aXA9XCJMb2FkaW5nIGdyb3VwIGRldGFpbHMuLi5cIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTkwMCBtYi0zIGJvcmRlci1iIHBiLTFcIj5cclxuICAgICAgICAgICAgICBBdWN0aW9uIERldGFpbHNcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBBdWN0aW9uIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJSZXF1aXJlZCFcIiB9XX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWdyYXktNDAwIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkRELU1NLVlZWVlcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBBdWN0aW9uIFRpbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uVGltZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJSZXF1aXJlZCFcIiB9XX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxUaW1lUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWdyYXktNDAwIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cImg6bW0gQVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlMTJIb3Vyc1xyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBSZXF1ZXN0IERhdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJyZXF1ZXN0RGF0ZVwiIGNsYXNzTmFtZT1cIm1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItZ3JheS00MDAgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiREQtTU0tWVlZWVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZ3JheS01MCBib3JkZXIgcm91bmRlZC1sZyBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgQ3VycmVudCBEdWUgQmFsYW5jZTpcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAge2xvYWRpbmdCYWxhbmNlID8gKFxyXG4gICAgICAgICAgICAgICAgPFNwaW4gc2l6ZT1cInNtYWxsXCIgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9udC1ib2xkIHRleHQtMnhsICR7Y3VzdG9tZXJCYWxhbmNlIDw9IDAgPyBcInRleHQtZ3JlZW4tNjAwXCIgOiBcInRleHQtcmVkLTYwMFwifWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtjdXN0b21lckJhbGFuY2UgIT09IG51bGxcclxuICAgICAgICAgICAgICAgICAgICA/IGDigrkgJHtjdXN0b21lckJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZW5yb2xsbWVudElkXCIgaGlkZGVuPlxyXG4gICAgICAgICAgICA8SW5wdXQgLz5cclxuICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZ3JvdXBJZFwiIGhpZGRlbj5cclxuICAgICAgICAgICAgPElucHV0IC8+XHJcbiAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIG1iLTMgYm9yZGVyLWIgcGItMVwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSBTdGF0dXNcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy02IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiU2V0IHRvIFBlbmRpbmc/XCJcclxuICAgICAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlU2V0UGVuZGluZ31cclxuICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRlZmF1bHRcIlxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtlZGl0TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCBmb250LWJvbGQgYm9yZGVyLXllbGxvdy01MDAgdGV4dC15ZWxsb3ctNjAwIGhvdmVyOmJnLXllbGxvdy01MFwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249ezxDbG9ja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZWRpdEdyb3Vwcy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFBlbmRpbmdcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJBcHByb3ZlIFJlcXVlc3Q/XCJcclxuICAgICAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlU2V0QWNjZXB0fVxyXG4gICAgICAgICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2VkaXRMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZWRpdEdyb3Vwcy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgZm9udC1ib2xkIGJnLWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi03MDAgYm9yZGVyLWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249ezxDaGVja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBY2NlcHRcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJNYXJrIGFzIFByaXplZD9cIlxyXG4gICAgICAgICAgICAgICAgb25Db25maXJtPXtoYW5kbGVTZXRQcml6ZWR9XHJcbiAgICAgICAgICAgICAgICBva1RleHQ9XCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgY2FuY2VsVGV4dD1cIk5vXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgbG9hZGluZz17ZWRpdExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0R3JvdXBzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCBmb250LWJvbGQgYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNzAwIGJvcmRlci1wdXJwbGUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PFRyb3BoeU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBQcml6ZWRcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJSZWplY3QgUmVxdWVzdD9cIlxyXG4gICAgICAgICAgICAgICAgb25Db25maXJtPXtoYW5kbGVTZXRSZWplY3R9XHJcbiAgICAgICAgICAgICAgICBva1RleHQ9XCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgY2FuY2VsVGV4dD1cIk5vXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgZGFuZ2VyXHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2VkaXRMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTE0IGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249ezxDbG9zZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZWRpdEdyb3Vwcy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFJlamVjdFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4gICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlBvc3QgdG8gbmV4dCBhdWN0aW9uP1wiXHJcbiAgICAgICAgICAgICAgICBvbkNvbmZpcm09e2hhbmRsZVNldE5leHRBdWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtlZGl0TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCBmb250LWJvbGQgYmctb3JhbmdlLTYwMCBob3ZlcjpiZy1vcmFuZ2UtNzAwIGJvcmRlci1vcmFuZ2UtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PFN0b3BPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2VkaXRHcm91cHMubGVuZ3RoID09PSAwfVxyXG4gICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBOZXh0XHJcbiAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2VFZGl0TW9kYWx9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTE0IGZvbnQtc2VtaWJvbGQgYm9yZGVyLWdyYXktNDAwXCJcclxuICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlNhdmUgQ2hhbmdlcz9cIlxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gc2F2ZSB0aGUgY2hhbmdlcyB0byBhdWN0aW9uIGRhdGUvdGltZT9cIlxyXG4gICAgICAgICAgICAgICAgb25Db25maXJtPXtoYW5kbGVTYXZlQ2hhbmdlc31cclxuICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXtlZGl0TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xNCBmb250LWJvbGQgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgYm9yZGVyLWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PFNhdmVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2VkaXRHcm91cHMubGVuZ3RoID09PSAwfVxyXG4gICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTYXZlIENoYW5nZXNcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0Zvcm0+XHJcbiAgICAgIDwvQW50TW9kYWw+XHJcblxyXG4gICAgICA8QW50TW9kYWxcclxuICAgICAgICBvcGVuPXtpc1ZlcmlmeU1vZGFsT3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17aGFuZGxlQ2xvc2VWZXJpZnlNb2RhbH1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgY2VudGVyZWRcclxuICAgICAgICB3aWR0aD17NTAwfVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHJvdW5kZWQtZnVsbCBwLTRcIj5cclxuICAgICAgICAgICAgICA8V2hhdHNBcHBPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCB0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItMlwiPlxyXG4gICAgICAgICAgICBBcmUgWW91IFN1cmU/XHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtYi02XCI+XHJcbiAgICAgICAgICAgIFlvdSBhcmUgYWJvdXQgdG8gc2VuZCBXaGF0c0FwcCBtZXNzYWdlcyB0b3tcIiBcIn1cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICB7c2VsZWN0ZWRDb3VudH0gY29udGFjdHNcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAuXHJcbiAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lIG9uY2UgaW5pdGlhdGVkLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlVmVyaWZ5TW9kYWx9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zMlwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXtpc1NlbmRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2VuZFdoYXRzQXBwfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMzIgYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMCBib3JkZXItZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFllcywgU2VuZFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0FudE1vZGFsPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IERldGFpbEl0ZW0gPSAoeyBsYWJlbCwgdmFsdWUgfSkgPT4gKFxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBib3JkZXItYiBib3JkZXItZ3JheS01MCBwYi0yIG1yLTRcIj5cclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICB7bGFiZWx9XHJcbiAgICA8L3NwYW4+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICB7dmFsdWUgfHwgXCJOL0FcIn1cclxuICAgIDwvc3Bhbj5cclxuICA8L2Rpdj5cclxuKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJpZFJlcXVlc3RSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9CaWRSZXF1ZXN0UmVwb3J0LmpzeCJ9