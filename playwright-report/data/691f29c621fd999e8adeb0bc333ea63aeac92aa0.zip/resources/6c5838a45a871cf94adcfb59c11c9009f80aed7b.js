import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Agent.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Input, Select, Dropdown, Modal as madal } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const { confirm } = madal;
const Agent = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableAgents, setTableAgents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [errors, setErrors] = useState({});
  const [searchText, setSearchText] = useState("");
  const [selectedManagerId, setSelectedManagerId] = useState("");
  const [selectedReportingManagerId, setSelectedReportingManagerId] = useState("");
  const [managers, setManagers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [selectedManagerTitle, setSelectedManagerTitle] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    // password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    agent_type: "agent",
    isVerified: "true"
  });
  const [updateFormData, setUpdateFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    // password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    isVerified: "false"
  });
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/agent/get");
        setUsers(response?.data?.agent);
        const formattedData = response.data?.agent?.map((group, index) => ({
          _id: group?._id,
          id: index + 1,
          name: group?.name,
          employeeCode: group?.employeeCode || "N/A",
          phone_number: group?.phone_number,
          // password: group?.password,
          designation: group?.designation_id?.title,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center  gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 104,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-blue-600 cursor-pointer",
                        onClick: () => handleVerifyAgent(group._id),
                        children: "Un Verify"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 115,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 126,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 138,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 97,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 90,
            columnNumber: 11
          }, this)
        }));
        setTableAgents(formattedData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAgents();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchManagers = async () => {
      try {
        const response = await api.get("/designation/get-designation");
        setManagers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchManagers();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addEmployee" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      // password:
      //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{5,}$/,
      pincode: /^\d{6}$/,
      aadhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
    };
    if (!data.name.trim()) {
      newErrors.name = "Full Name is required";
    }
    if (!data.email) {
      newErrors.email = "Email is required";
    } else if (!regex.email.test(data.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!data.phone_number) {
      newErrors.phone_number = "Phone number is required";
    } else if (!regex.phone.test(data.phone_number)) {
      newErrors.phone_number = "Invalid  phone number";
    }
    if (!data.pincode) {
      newErrors.pincode = "Pincode is required";
    } else if (!regex.pincode.test(data.pincode)) {
      newErrors.pincode = "Invalid pincode (6 digits required)";
    }
    if (!data.adhaar_no) {
      newErrors.adhaar_no = "Aadhaar number is required";
    } else if (!regex.aadhaar.test(data.adhaar_no)) {
      newErrors.adhaar_no = "Invalid Aadhaar number (12 digits required)";
    }
    if (!selectedManagerId) {
      newErrors.reporting_manager = "Reporting Manager is required";
    }
    if (!data.pan_no) {
      newErrors.pan_no = "PAN number is required";
    } else if (!regex.pan.test(data.pan_no.toUpperCase())) {
      newErrors.pan_no = "Invalid PAN format (e.g., ABCDE1234F)";
    }
    if (!data.address.trim()) {
      newErrors.address = "Address is required";
    } else if (data.address.trim().length < 10) {
      newErrors.address = "Address should be at least 10 characters";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleAntDSelectManager = (managerId) => {
    setSelectedManagerId(managerId);
    const selected = managers.find((mgr) => mgr._id === managerId);
    const title = selected?.title || "";
    setSelectedManagerTitle(title);
    setFormData((prev) => ({
      ...prev,
      managerId,
      managerTitle: title
    }));
    setErrors((prev) => ({
      ...prev,
      managerId: "",
      managerTitle: ""
    }));
  };
  const handleAntInputDSelectManager = (managerId) => {
    setSelectedManagerId(managerId);
    const selected = managers.find((mgr) => mgr._id === managerId);
    const title = selected?.title || "";
    setSelectedManagerTitle(title);
    setUpdateFormData((prev) => ({
      ...prev,
      managerId,
      managerTitle: title
    }));
    setErrors((prev) => ({
      ...prev,
      managerId: "",
      managerTitle: ""
    }));
  };
  const handleAntDSelectReportingManager = (reportingId) => {
    setSelectedReportingManagerId(reportingId);
    setUpdateFormData((prev) => ({
      ...prev,
      reportingManagerId: reportingId
    }));
    setErrors((prev) => ({
      ...prev,
      reportingManagerId: ""
    }));
  };
  const handleReportingManager = (value) => {
    setSelectedReportingManagerId(value);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValidate = validateForm("addEmployee");
    try {
      if (isValidate) {
        const dataToSend = {
          ...formData,
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId
        };
        const response = await api.post("/agent/add", dataToSend, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        setShowModal(false);
        setFormData({
          name: "",
          email: "",
          phone_number: "",
          // password: "",
          address: "",
          pincode: "",
          adhaar_no: "",
          pan_no: ""
        });
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent Added Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error adding agent:", error);
      if (error.response && error.response.data && error.response.data.message) {
        const errMsg = error.response.data.message.toLowerCase();
        if (errMsg.includes("phone number")) {
          setErrors((prevErrors) => ({
            ...prevErrors,
            phone_number: "Phone number already exists"
          }));
        } else {
          setAlertConfig({
            visibility: true,
            message: error.response.data.message,
            type: "error"
          });
        }
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const handleVerifyAgent = (userId) => {
    confirm({
      title: "Are you sure you want to Un-Verify this agent?",
      content: "This action will mark the agent as Un-Verified.",
      okText: "Yes, Verify",
      cancelText: "Cancel",
      async onOk() {
        try {
          await api.put(`/agent/update/${userId}`, {
            isVerified: false
          });
          setReloadTrigger((prev) => prev + 1);
          setAlertConfig({
            visibility: true,
            message: "Agent Un-Verified Successfully",
            type: "success"
          });
        } catch (error) {
          setAlertConfig({
            visibility: true,
            message: error?.response?.data?.message || "Failed to verify agent",
            type: "error"
          });
        }
      }
    });
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Agent Name" },
    { key: "employeeCode", header: "Employee ID" },
    { key: "phone_number", header: "Agent Phone Number" },
    { key: "designation", header: "Designation" },
    // { key: "password", header: "Agent Password" },
    { key: "action", header: "Action" }
  ];
  const filteredUsers = users.filter(
    (user) => user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(`/agent/get-by-id/${userId}`);
      setCurrentUser(response.data?.agent);
      setShowModalDelete(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(`/agent/get-by-id/${userId}`);
      setCurrentUpdateUser(response.data?.agent);
      setUpdateFormData({
        name: response?.data?.agent?.name,
        email: response?.data?.agent?.email,
        phone_number: response?.data?.agent?.phone_number,
        // password: response?.data?.agent?.password,
        pincode: response?.data?.agent?.pincode,
        adhaar_no: response?.data?.agent?.adhaar_no,
        pan_no: response?.data?.agent?.pan_no,
        address: response?.data?.agent?.address
      });
      setSelectedManagerId(response.data?.agent?.designation_id?._id || "");
      setSelectedReportingManagerId(response.data?.agent?.reporting_manager_id || "");
      setSelectedManagerTitle(response.data?.agent?.designation_id?.title);
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(`/agent/delete/${currentUser._id}`);
        setShowModalDelete(false);
        setCurrentUser(null);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        const dataToSend = {
          ...updateFormData,
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId
        };
        const response = await api.put(
          `/agent/update/${currentUpdateUser._id}`,
          dataToSend
        );
        setShowModalUpdate(false);
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating agent:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error.response.data.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const handleManager = async (event) => {
    const groupId = event.target.value;
    setSelectedManagerId(groupId);
    const selected = managers.find((mgr) => mgr._id === groupId);
    setSelectedManagerTitle(selected?.title || "");
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
        lineNumber: 550,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 551,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 555,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 w-8 ", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 569,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Agents" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 571,
              columnNumber: 7
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowModal(true);
                  setErrors({});
                },
                className: "ml-4 bg-violet-600 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+ Add Agent"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 572,
                columnNumber: 7
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 570,
            columnNumber: 5
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 568,
          columnNumber: 3
        }, this),
        TableAgents?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableAgents, searchText),
            columns,
            selectionColor: "custom-violet",
            exportedFileName: `Employees-${TableAgents.length > 0 ? TableAgents[0].name + " to " + TableAgents[TableAgents.length - 1].name : "empty"}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 585,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableAgents.length <= 0,
            data: "Agent Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 599,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
        lineNumber: 566,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
      lineNumber: 549,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Agent" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
        lineNumber: 613,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Full Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 622,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 618,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "name",
              value: formData.name,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Full Name",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 624,
              columnNumber: 17
            },
            this
          ),
          errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 635,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 617,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Email  ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 644,
                    columnNumber: 28
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 640,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "email",
                name: "email",
                value: formData.email,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Email",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 646,
                columnNumber: 19
              },
              this
            ),
            errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 657,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 639,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Phone Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 665,
                    columnNumber: 34
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 661,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "phone_number",
                value: formData.phone_number,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Phone Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 667,
                columnNumber: 19
              },
              this
            ),
            errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 678,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 660,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 638,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "date",
              children: [
                "Pincode ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 713,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 709,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "number",
              name: "pincode",
              value: formData.pincode,
              onChange: handleChange,
              id: "text",
              placeholder: "Enter Pincode",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 715,
              columnNumber: 19
            },
            this
          ),
          errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 726,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 708,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 684,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Adhaar Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 738,
                    columnNumber: 35
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 734,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "adhaar_no",
                value: formData.adhaar_no,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Adhaar Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 740,
                columnNumber: 19
              },
              this
            ),
            errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 751,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 733,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Pan Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 761,
                    columnNumber: 32
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 757,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "pan_no",
                value: formData.pan_no,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Pan Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 763,
                columnNumber: 19
              },
              this
            ),
            errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 774,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 756,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 732,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Address ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 783,
                  columnNumber: 27
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 779,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "address",
              value: formData.address,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Address",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 785,
              columnNumber: 17
            },
            this
          ),
          errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 796,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 778,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "category",
              children: [
                "Designation ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 804,
                  columnNumber: 31
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 800,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              id: "manager-select",
              name: "managerId",
              value: selectedManagerId || void 0,
              onChange: handleAntDSelectManager,
              placeholder: "Select Designation",
              className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
              showSearch: true,
              popupMatchSelectWidth: false,
              filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
              children: managers.map(
                (mgr) => /* @__PURE__ */ jsxDEV(Select.Option, { value: mgr._id, children: mgr.title }, mgr._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 834,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 820,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 799,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Agent"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 843,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 842,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
        lineNumber: 616,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
      lineNumber: 612,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
      lineNumber: 611,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Agent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 860,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Full Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 869,
                      columnNumber: 29
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 865,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "name",
                  value: updateFormData.name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Full Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 871,
                  columnNumber: 17
                },
                this
              ),
              errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 882,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 864,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Email ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 891,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 887,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "email",
                    name: "email",
                    value: updateFormData.email,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Email",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 893,
                    columnNumber: 19
                  },
                  this
                ),
                errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 904,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 886,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 912,
                        columnNumber: 34
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 908,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "phone_number",
                    value: updateFormData.phone_number,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 914,
                    columnNumber: 19
                  },
                  this
                ),
                errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 925,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 907,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 885,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "date",
                  children: [
                    "Pincode ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 960,
                      columnNumber: 29
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 956,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "pincode",
                  value: updateFormData.pincode,
                  onChange: handleInputChange,
                  id: "text",
                  placeholder: "Enter Pincode",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 962,
                  columnNumber: 19
                },
                this
              ),
              errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 973,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 955,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 931,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Adhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 985,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 981,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "adhaar_no",
                    value: updateFormData.adhaar_no,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Adhaar Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 987,
                    columnNumber: 19
                  },
                  this
                ),
                errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 998,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 980,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Pan Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 1008,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 1004,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "pan_no",
                    value: updateFormData.pan_no,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Pan Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 1010,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1021,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 1003,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 979,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 1030,
                      columnNumber: 27
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1026,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "address",
                  value: updateFormData.address,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Address",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1032,
                  columnNumber: 17
                },
                this
              ),
              errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 1043,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 1025,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Designation ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 1051,
                      columnNumber: 31
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1047,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  id: "selectedManagerId",
                  name: "selectedManagerId",
                  value: selectedManagerId || void 0,
                  onChange: handleAntInputDSelectManager,
                  placeholder: "Select Designation",
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  children: managers.map(
                    (manager) => /* @__PURE__ */ jsxDEV(Select.Option, { value: manager._id, children: manager.title }, manager._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 1081,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1067,
                  columnNumber: 17
                },
                this
              ),
              errors.designation_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.designation_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 1088,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 1046,
              columnNumber: 15
            }, this),
            (selectedManagerTitle === "Sales Excecutive" || selectedManagerTitle === "Business Agent" || selectedManagerTitle === "Office Executive") && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Reporting Manager"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1096,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: selectedReportingManagerId || void 0,
                  id: "selectedReportingManagerId",
                  onChange: handleReportingManager,
                  placeholder: "Select Reporting Manager",
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "", hidden: true, children: "Select Reporting Manager" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 1114,
                      columnNumber: 23
                    }, this),
                    users.map(
                      (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: [
                        group.name,
                        " - ",
                        group?.designation_id?.title
                      ] }, group._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                        lineNumber: 1118,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1102,
                  columnNumber: 21
                },
                this
              ),
              errors.reporting_manager && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.reporting_manager }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 1124,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 1095,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update Agent"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                lineNumber: 1129,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 1128,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 863,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 859,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
        lineNumber: 855,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Agent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
            lineNumber: 1149,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                          lineNumber: 1166,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion. ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                          lineNumber: 1169,
                          columnNumber: 42
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 1161,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the employee Full Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                      lineNumber: 1171,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                  lineNumber: 1160,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
                    lineNumber: 1179,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
              lineNumber: 1153,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
          lineNumber: 1148,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
        lineNumber: 1141,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
    lineNumber: 548,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx",
    lineNumber: 547,
    columnNumber: 5
  }, this);
};
_s(Agent, "Aq2pkt+5n1+IMaTZkHgX9ZxnJ2I=");
_c = Agent;
export default Agent;
var _c;
$RefreshReg$(_c, "Agent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Agent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUd3QixTQTJicEIsVUEzYm9COzJCQXZHeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBU0MsU0FBU0MsYUFBYTtBQUN2RCxPQUFPRCxXQUFXO0FBQ2xCLE9BQU9FLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE1BQU0sRUFBRUMsUUFBUSxJQUFJVjtBQUNwQixNQUFNVyxRQUFRQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUl2QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDd0IsYUFBYUMsY0FBYyxJQUFJekIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzBCLFlBQVlDLGFBQWEsSUFBSTNCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM0QixXQUFXQyxZQUFZLElBQUk3QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDOEIsaUJBQWlCQyxrQkFBa0IsSUFBSS9CLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNnQyxpQkFBaUJDLGtCQUFrQixJQUFJakMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ2tDLGFBQWFDLGNBQWMsSUFBSW5DLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNvQyxtQkFBbUJDLG9CQUFvQixJQUFJckMsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ3NDLFFBQVFDLFNBQVMsSUFBSXZDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3dDLFlBQVlDLGFBQWEsSUFBSXpDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMwQyxtQkFBbUJDLG9CQUFvQixJQUFJM0MsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQzRDLDRCQUE0QkMsNkJBQTZCLElBQUk3QyxTQUFTLEVBQUU7QUFDL0UsUUFBTSxDQUFDOEMsVUFBVUMsV0FBVyxJQUFJL0MsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2dELFdBQVdDLFlBQVksSUFBSWpELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNrRCxlQUFlQyxnQkFBZ0IsSUFBSW5ELFNBQVMsQ0FBQztBQUNwRCxRQUFNb0QsNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQmQsa0JBQWNhLEtBQUs7QUFBQSxFQUNyQjtBQUNBLFFBQU0sQ0FBQ0Usc0JBQXNCQyx1QkFBdUIsSUFBSXpELFNBQVMsRUFBRTtBQUVuRSxRQUFNLENBQUMwRCxhQUFhQyxjQUFjLElBQUkzRCxTQUFTO0FBQUEsSUFDN0M0RCxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSWhFLFNBQVM7QUFBQSxJQUN2Q2lFLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsY0FBYztBQUFBO0FBQUEsSUFFZEMsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxJQUNSQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSTVFLFNBQVM7QUFBQSxJQUNuRGlFLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsY0FBYztBQUFBO0FBQUEsSUFFZEMsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxJQUNQRSxZQUFZO0FBQUEsRUFDZixDQUFDO0FBR0QzRSxZQUFVLE1BQU07QUFDZCxVQUFNOEUsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRjVCLHFCQUFhLElBQUk7QUFDakIsY0FBTTZCLFdBQVcsTUFBTXBFLElBQUlxRSxJQUFJLFlBQVk7QUFDM0N4RCxpQkFBU3VELFVBQVVFLE1BQU1DLEtBQUs7QUFDOUIsY0FBTUMsZ0JBQWdCSixTQUFTRSxNQUFNQyxPQUFPRSxJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUNqRUMsS0FBS0YsT0FBT0U7QUFBQUEsVUFDWkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1pwQixNQUFNbUIsT0FBT25CO0FBQUFBLFVBQ2J1QixjQUFjSixPQUFPSSxnQkFBZ0I7QUFBQSxVQUNyQ3JCLGNBQWNpQixPQUFPakI7QUFBQUE7QUFBQUEsVUFFckJzQixhQUFhTCxPQUFPYixnQkFBZ0JtQjtBQUFBQSxVQUNwQ0MsUUFDRSx1QkFBQyxTQUFJLFdBQVUsOEJBT2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsY0FDakIsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1DLHNCQUFzQlgsTUFBTUUsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQztBQUFBLG9CQUNHTyxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUUsa0JBQWtCWixNQUFNRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGtCQUNGO0FBQUEsb0JBQ0VPLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNRyxzQkFBc0JiLE1BQU1FLEdBQUc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsZ0JBQUM7QUFBQSxjQUVMO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQTtBQUFBLFlBekNqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUEwQ0EsS0FqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrREE7QUFBQSxRQUVKLEVBQUU7QUFDRjdELHVCQUFleUQsYUFBYTtBQUFBLE1BQzlCLFNBQVNnQixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xELFVBQUM7QUFDQ2pELHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQTRCLGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUMzQixhQUFhLENBQUM7QUFFbEJuRCxZQUFVLE1BQU07QUFDZCxVQUFNcUcsZ0JBQWdCLFlBQVk7QUFDaEMsVUFBSTtBQUNGLGNBQU10QixXQUFXLE1BQU1wRSxJQUFJcUUsSUFBSSw4QkFBOEI7QUFDN0RoQyxvQkFBWStCLFNBQVNFLElBQUk7QUFBQSxNQUMzQixTQUFTa0IsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUUsa0JBQWM7QUFBQSxFQUNoQixHQUFHLENBQUNsRCxhQUFhLENBQUM7QUFFbEIsUUFBTW1ELGVBQWVBLENBQUNoRCxNQUFNO0FBQzFCLFVBQU0sRUFBRVksTUFBTVgsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQlMsZ0JBQVksQ0FBQ3NDLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNyQyxJQUFJLEdBQUdYO0FBQUFBLElBQ1YsRUFBRTtBQUNGZixjQUFVLENBQUMrRCxjQUFjO0FBQUEsTUFDdkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDckMsSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1zQyxlQUFlQSxDQUFDekMsU0FBUztBQUM3QixVQUFNMEMsWUFBWSxDQUFDO0FBQ25CLFVBQU14QixPQUFPbEIsU0FBUyxnQkFBZ0JDLFdBQVdZO0FBQ2pELFVBQU04QixRQUFRO0FBQUEsTUFDWnZDLE9BQU87QUFBQSxNQUNQd0MsT0FBTztBQUFBO0FBQUE7QUFBQSxNQUdQckMsU0FBUztBQUFBLE1BQ1RzQyxTQUFTO0FBQUEsTUFDVEMsS0FBSztBQUFBLElBQ1A7QUFFQSxRQUFJLENBQUM1QixLQUFLZixLQUFLNEMsS0FBSyxHQUFHO0FBQ3JCTCxnQkFBVXZDLE9BQU87QUFBQSxJQUNuQjtBQUVBLFFBQUksQ0FBQ2UsS0FBS2QsT0FBTztBQUNmc0MsZ0JBQVV0QyxRQUFRO0FBQUEsSUFDcEIsV0FBVyxDQUFDdUMsTUFBTXZDLE1BQU00QyxLQUFLOUIsS0FBS2QsS0FBSyxHQUFHO0FBQ3hDc0MsZ0JBQVV0QyxRQUFRO0FBQUEsSUFDcEI7QUFFQSxRQUFJLENBQUNjLEtBQUtiLGNBQWM7QUFDdEJxQyxnQkFBVXJDLGVBQWU7QUFBQSxJQUMzQixXQUFXLENBQUNzQyxNQUFNQyxNQUFNSSxLQUFLOUIsS0FBS2IsWUFBWSxHQUFHO0FBQy9DcUMsZ0JBQVVyQyxlQUFlO0FBQUEsSUFDM0I7QUFTQSxRQUFJLENBQUNhLEtBQUtYLFNBQVM7QUFDakJtQyxnQkFBVW5DLFVBQVU7QUFBQSxJQUN0QixXQUFXLENBQUNvQyxNQUFNcEMsUUFBUXlDLEtBQUs5QixLQUFLWCxPQUFPLEdBQUc7QUFDNUNtQyxnQkFBVW5DLFVBQVU7QUFBQSxJQUN0QjtBQUVBLFFBQUksQ0FBQ1csS0FBS1YsV0FBVztBQUNuQmtDLGdCQUFVbEMsWUFBWTtBQUFBLElBQ3hCLFdBQVcsQ0FBQ21DLE1BQU1FLFFBQVFHLEtBQUs5QixLQUFLVixTQUFTLEdBQUc7QUFDOUNrQyxnQkFBVWxDLFlBQVk7QUFBQSxJQUN4QjtBQUNBLFFBQUksQ0FBQzVCLG1CQUFtQjtBQUN0QjhELGdCQUFVTyxvQkFBb0I7QUFBQSxJQUNoQztBQUNBLFFBQUksQ0FBQy9CLEtBQUtSLFFBQVE7QUFDaEJnQyxnQkFBVWhDLFNBQVM7QUFBQSxJQUNyQixXQUFXLENBQUNpQyxNQUFNRyxJQUFJRSxLQUFLOUIsS0FBS1IsT0FBT3dDLFlBQVksQ0FBQyxHQUFHO0FBQ3JEUixnQkFBVWhDLFNBQVM7QUFBQSxJQUNyQjtBQUVBLFFBQUksQ0FBQ1EsS0FBS1osUUFBUXlDLEtBQUssR0FBRztBQUN4QkwsZ0JBQVVwQyxVQUFVO0FBQUEsSUFDdEIsV0FBV1ksS0FBS1osUUFBUXlDLEtBQUssRUFBRUksU0FBUyxJQUFJO0FBQzFDVCxnQkFBVXBDLFVBQVU7QUFBQSxJQUN0QjtBQUVBN0IsY0FBVWlFLFNBQVM7QUFDbkIsV0FBT1UsT0FBT0MsS0FBS1gsU0FBUyxFQUFFUyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNRywwQkFBMEJBLENBQUNDLGNBQWM7QUFDN0MxRSx5QkFBcUIwRSxTQUFTO0FBRTlCLFVBQU1DLFdBQVd4RSxTQUFTeUUsS0FBSyxDQUFDQyxRQUFRQSxJQUFJbEMsUUFBUStCLFNBQVM7QUFDN0QsVUFBTTNCLFFBQVE0QixVQUFVNUIsU0FBUztBQUVqQ2pDLDRCQUF3QmlDLEtBQUs7QUFHN0IxQixnQkFBWSxDQUFDeUQsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0hKO0FBQUFBLE1BQ0FLLGNBQWNoQztBQUFBQSxJQUNoQixFQUFFO0FBRUZuRCxjQUFVLENBQUNrRixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSEosV0FBVztBQUFBLE1BQ1hLLGNBQWM7QUFBQSxJQUNoQixFQUFFO0FBQUEsRUFDSjtBQUNBLFFBQU1DLCtCQUErQkEsQ0FBQ04sY0FBYztBQUNsRDFFLHlCQUFxQjBFLFNBQVM7QUFFOUIsVUFBTUMsV0FBV3hFLFNBQVN5RSxLQUFLLENBQUNDLFFBQVFBLElBQUlsQyxRQUFRK0IsU0FBUztBQUM3RCxVQUFNM0IsUUFBUTRCLFVBQVU1QixTQUFTO0FBRWpDakMsNEJBQXdCaUMsS0FBSztBQUc3QmQsc0JBQWtCLENBQUM2QyxVQUFVO0FBQUEsTUFDM0IsR0FBR0E7QUFBQUEsTUFDSEo7QUFBQUEsTUFDQUssY0FBY2hDO0FBQUFBLElBQ2hCLEVBQUU7QUFFRm5ELGNBQVUsQ0FBQ2tGLFVBQVU7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNISixXQUFXO0FBQUEsTUFDWEssY0FBYztBQUFBLElBQ2hCLEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTUUsbUNBQW1DQSxDQUFDQyxnQkFBZ0I7QUFDeERoRixrQ0FBOEJnRixXQUFXO0FBR3pDakQsc0JBQWtCLENBQUM2QyxVQUFVO0FBQUEsTUFDM0IsR0FBR0E7QUFBQUEsTUFDSEssb0JBQW9CRDtBQUFBQSxJQUN0QixFQUFFO0FBR0Z0RixjQUFVLENBQUNrRixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSEssb0JBQW9CO0FBQUEsSUFDdEIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNQyx5QkFBeUJBLENBQUN6RSxVQUFVO0FBQ3hDVCxrQ0FBOEJTLEtBQUs7QUFBQSxFQUNyQztBQUVBLFFBQU0wRSxlQUFlLE9BQU8zRSxNQUFNO0FBQ2hDQSxNQUFFNEUsZUFBZTtBQUNqQixVQUFNQyxhQUFhM0IsYUFBYSxhQUFhO0FBRTdDLFFBQUk7QUFDRixVQUFJMkIsWUFBWTtBQUNkLGNBQU1DLGFBQWE7QUFBQSxVQUNqQixHQUFHcEU7QUFBQUEsVUFDSFEsZ0JBQWdCN0I7QUFBQUEsVUFDaEIwRixzQkFBc0J4RjtBQUFBQSxRQUN4QjtBQUVBLGNBQU1rQyxXQUFXLE1BQU1wRSxJQUFJMkgsS0FBSyxjQUFjRixZQUFZO0FBQUEsVUFDeERHLFNBQVM7QUFBQSxZQUNQLGdCQUFnQjtBQUFBLFVBQ2xCO0FBQUEsUUFDRixDQUFDO0FBRUR6RyxxQkFBYSxLQUFLO0FBQ2xCbUMsb0JBQVk7QUFBQSxVQUNWQyxNQUFNO0FBQUEsVUFDTkMsT0FBTztBQUFBLFVBQ1BDLGNBQWM7QUFBQTtBQUFBLFVBRWRDLFNBQVM7QUFBQSxVQUNUQyxTQUFTO0FBQUEsVUFDVEMsV0FBVztBQUFBLFVBQ1hFLFFBQVE7QUFBQSxRQUNWLENBQUM7QUFDRDdCLDZCQUFxQixFQUFFO0FBQ3ZCRSxzQ0FBOEIsRUFBRTtBQUNoQ00seUJBQWlCLENBQUNzRSxTQUFTQSxPQUFPLENBQUM7QUFDbkM5RCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNvQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sdUJBQXVCQSxLQUFLO0FBQzFDLFVBQ0VBLE1BQU1wQixZQUNOb0IsTUFBTXBCLFNBQVNFLFFBQ2ZrQixNQUFNcEIsU0FBU0UsS0FBS25CLFNBQ3BCO0FBQ0EsY0FBTTBFLFNBQVNyQyxNQUFNcEIsU0FBU0UsS0FBS25CLFFBQVEyRSxZQUFZO0FBRXZELFlBQUlELE9BQU9FLFNBQVMsY0FBYyxHQUFHO0FBQ25DbEcsb0JBQVUsQ0FBQ21HLGdCQUFnQjtBQUFBLFlBQ3pCLEdBQUdBO0FBQUFBLFlBQ0h2RSxjQUFjO0FBQUEsVUFDaEIsRUFBRTtBQUFBLFFBQ0osT0FBTztBQUNMUix5QkFBZTtBQUFBLFlBQ2JDLFlBQVk7QUFBQSxZQUNaQyxTQUFTcUMsTUFBTXBCLFNBQVNFLEtBQUtuQjtBQUFBQSxZQUM3QkMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGLE9BQU87QUFDTEgsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFRixRQUFNa0Msb0JBQW9CQSxDQUFDMkMsV0FBVztBQUVwQ3hILFlBQVE7QUFBQSxNQUNOdUUsT0FBTztBQUFBLE1BQ1BrRCxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFlBQVk7QUFBQSxNQUVaLE1BQU1DLE9BQU87QUFDWCxZQUFJO0FBQ0YsZ0JBQU1ySSxJQUFJc0ksSUFBSSxpQkFBaUJMLE1BQU0sSUFBSTtBQUFBLFlBQ3ZDakUsWUFBWTtBQUFBLFVBQ2QsQ0FBQztBQUVEdkIsMkJBQWlCLENBQUNzRSxTQUFTQSxPQUFPLENBQUM7QUFFbkM5RCx5QkFBZTtBQUFBLFlBQ2JDLFlBQVk7QUFBQSxZQUNaQyxTQUFTO0FBQUEsWUFDVEMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBRUgsU0FBU29DLE9BQU87QUFFZHZDLHlCQUFlO0FBQUEsWUFDYkMsWUFBWTtBQUFBLFlBQ1pDLFNBQ0VxQyxPQUFPcEIsVUFBVUUsTUFBTW5CLFdBQVc7QUFBQSxZQUNwQ0MsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVFLFFBQU1tRixVQUFVO0FBQUEsSUFDZCxFQUFFcEQsS0FBSyxNQUFNcUQsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRXJELEtBQUssUUFBUXFELFFBQVEsYUFBYTtBQUFBLElBQ3BDLEVBQUVyRCxLQUFLLGdCQUFnQnFELFFBQVEsY0FBYztBQUFBLElBQzdDLEVBQUVyRCxLQUFLLGdCQUFnQnFELFFBQVEscUJBQXFCO0FBQUEsSUFDcEQsRUFBRXJELEtBQUssZUFBZXFELFFBQVEsY0FBYztBQUFBO0FBQUEsSUFFNUMsRUFBRXJELEtBQUssVUFBVXFELFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUMsZ0JBQWdCN0gsTUFBTThIO0FBQUFBLElBQU8sQ0FBQ0MsU0FDbENBLEtBQUtwRixLQUFLdUUsWUFBWSxFQUFFQyxTQUFTL0csV0FBVzhHLFlBQVksQ0FBQztBQUFBLEVBQzNEO0FBRUEsUUFBTXZDLHdCQUF3QixPQUFPMEMsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTTdELFdBQVcsTUFBTXBFLElBQUlxRSxJQUFJLG9CQUFvQjRELE1BQU0sRUFBRTtBQUMzRHhHLHFCQUFlMkMsU0FBU0UsTUFBTUMsS0FBSztBQUNuQ2xELHlCQUFtQixJQUFJO0FBQ3ZCUSxnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVMyRCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUEsUUFBTUgsd0JBQXdCLE9BQU80QyxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNN0QsV0FBVyxNQUFNcEUsSUFBSXFFLElBQUksb0JBQW9CNEQsTUFBTSxFQUFFO0FBQzNEdEcsMkJBQXFCeUMsU0FBU0UsTUFBTUMsS0FBSztBQUN6Q0wsd0JBQWtCO0FBQUEsUUFDaEJYLE1BQU1hLFVBQVVFLE1BQU1DLE9BQU9oQjtBQUFBQSxRQUM3QkMsT0FBT1ksVUFBVUUsTUFBTUMsT0FBT2Y7QUFBQUEsUUFDOUJDLGNBQWNXLFVBQVVFLE1BQU1DLE9BQU9kO0FBQUFBO0FBQUFBLFFBRXJDRSxTQUFTUyxVQUFVRSxNQUFNQyxPQUFPWjtBQUFBQSxRQUNoQ0MsV0FBV1EsVUFBVUUsTUFBTUMsT0FBT1g7QUFBQUEsUUFDbENFLFFBQVFNLFVBQVVFLE1BQU1DLE9BQU9UO0FBQUFBLFFBQy9CSixTQUFTVSxVQUFVRSxNQUFNQyxPQUFPYjtBQUFBQSxNQUNsQyxDQUFDO0FBQ0R6QiwyQkFBcUJtQyxTQUFTRSxNQUFNQyxPQUFPVixnQkFBZ0JlLE9BQU8sRUFBRTtBQUNwRXpDLG9DQUE4QmlDLFNBQVNFLE1BQU1DLE9BQU9tRCx3QkFBd0IsRUFBRTtBQUM5RTNFLDhCQUF3QnFCLFNBQVNFLE1BQU1DLE9BQU9WLGdCQUFnQm1CLEtBQUs7QUFDbkV6RCx5QkFBbUIsSUFBSTtBQUN2Qk0sZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZCxTQUFTMkQsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUVBLFFBQU1vRCxvQkFBb0JBLENBQUNqRyxNQUFNO0FBQy9CLFVBQU0sRUFBRVksTUFBTVgsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQnFCLHNCQUFrQixDQUFDMEIsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ3JDLElBQUksR0FBR1g7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1pRyxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJckgsYUFBYTtBQUNmLFVBQUk7QUFDRixjQUFNeEIsSUFBSThJLE9BQU8saUJBQWlCdEgsWUFBWW9ELEdBQUcsRUFBRTtBQUNuRHZELDJCQUFtQixLQUFLO0FBQ3hCSSx1QkFBZSxJQUFJO0FBQ25CZ0IseUJBQWlCLENBQUNzRSxTQUFTQSxPQUFPLENBQUM7QUFDbkM5RCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0gsU0FBU29DLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU11RCxlQUFlLE9BQU9wRyxNQUFNO0FBQ2hDQSxNQUFFNEUsZUFBZTtBQUNqQixVQUFNeUIsVUFBVW5ELGFBQWE7QUFDN0IsUUFBSTtBQUNGLFVBQUltRCxTQUFTO0FBQ1gsY0FBTXZCLGFBQWE7QUFBQSxVQUNqQixHQUFHeEQ7QUFBQUEsVUFDSEosZ0JBQWdCN0I7QUFBQUEsVUFDaEIwRixzQkFBc0J4RjtBQUFBQSxRQUN4QjtBQUNBLGNBQU1rQyxXQUFXLE1BQU1wRSxJQUFJc0k7QUFBQUEsVUFDekIsaUJBQWlCNUcsa0JBQWtCa0QsR0FBRztBQUFBLFVBQ3RDNkM7QUFBQUEsUUFDRjtBQUNBbEcsMkJBQW1CLEtBQUs7QUFDeEJVLDZCQUFxQixFQUFFO0FBQ3ZCRSxzQ0FBOEIsRUFBRTtBQUNoQ00seUJBQWlCLENBQUNzRSxTQUFTQSxPQUFPLENBQUM7QUFDbkM5RCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNvQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDLFVBQ0VBLE1BQU1wQixZQUNOb0IsTUFBTXBCLFNBQVNFLFFBQ2ZrQixNQUFNcEIsU0FBU0UsS0FBS25CLFNBQ3BCO0FBQ0FGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVMsR0FBR3FDLE1BQU1wQixTQUFTRSxLQUFLbkIsT0FBTztBQUFBLFVBQ3ZDQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xILHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBSUEsUUFBTTZGLGdCQUFnQixPQUFPQyxVQUFVO0FBQ3JDLFVBQU1DLFVBQVVELE1BQU1yRyxPQUFPRDtBQUM3QlgseUJBQXFCa0gsT0FBTztBQUM1QixVQUFNdkMsV0FBV3hFLFNBQVN5RSxLQUFLLENBQUNDLFFBQVFBLElBQUlsQyxRQUFRdUUsT0FBTztBQUMzRHBHLDRCQUF3QjZELFVBQVU1QixTQUFTLEVBQUU7QUFBQSxFQUMvQztBQU9BLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDSjtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNSO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyw2QkFBNkJ0QztBQUFBQSxVQUM3QixZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNTSxZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQzhELFVBQVUsRUFBRSxHQUFHQSxNQUFNN0QsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLFFBTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1HO0FBQUEsTUFLUCx1QkFBQyxTQUFJLFdBQVUsc0JBRW5CO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ1A7QUFBQSxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDakIsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBCQUF5QixzQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3QztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiL0IsK0JBQWEsSUFBSTtBQUNqQlUsNEJBQVUsQ0FBQyxDQUFDO0FBQUEsZ0JBQ2Q7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQXVHO0FBQUE7QUFBQSxjQUxuSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQ2YsYUFBYXlGLFNBQVMsS0FBSyxDQUFDakUsWUFDM0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLGVBQWUrQztBQUFBQSxZQUNmLE1BQU1qRixhQUFhVSxhQUFhZ0IsVUFBVTtBQUFBLFlBQzFDO0FBQUEsWUFDQSxnQkFBZTtBQUFBLFlBQ2Ysa0JBQWtCLGFBQ2hCaEIsWUFBWXlGLFNBQVMsSUFDakJ6RixZQUFZLENBQUMsRUFBRXlDLE9BQU8sU0FBU3pDLFlBQVlBLFlBQVl5RixTQUFTLENBQUMsRUFBRWhELE9BQ25FLE9BQU87QUFBQTtBQUFBLFVBVGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVVMsSUFJVDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVN6QyxZQUFZeUYsVUFBVTtBQUFBLFlBQy9CLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR21CO0FBQUEsV0FwQ2pCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1Q047QUFBQSxTQXhERztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNERLO0FBQUEsSUFFQSx1QkFBQyxTQUFNLFdBQVdyRixXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMseUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVW1HLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQU87QUFBQTtBQUFBLGdCQUVMLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQTtBQUFBO0FBQUEsWUFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPakUsU0FBU0U7QUFBQUEsY0FDaEIsVUFBVW9DO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLFdBQVcscUNBQXFDcEYsVUFBVTZJLE1BQU07QUFBQTtBQUFBLFlBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFpSztBQUFBLFVBRWhLeEgsT0FBTzJCLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjNCLGlCQUFPMkIsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxhQWxCMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVQLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPRixTQUFTRztBQUFBQSxnQkFDaEIsVUFBVW1DO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3BGLFVBQVU2SSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRaUs7QUFBQSxZQUVoS3hILE9BQU80QixTQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI1QixpQkFBTzRCLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsZUFsQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9ILFNBQVNJO0FBQUFBLGdCQUNoQixVQUFVa0M7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDcEYsVUFBVTZJLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFpSztBQUFBLFlBRWhLeEgsT0FBTzZCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsYUE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQXdCYixpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBTTtBQUFBO0FBQUEsZ0JBRU4sdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBO0FBQUE7QUFBQSxZQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9KLFNBQVNNO0FBQUFBLGNBQ2hCLFVBQVVnQztBQUFBQSxjQUNWLElBQUc7QUFBQSxjQUNILGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxXQUFXLHFDQUFxQ3BGLFVBQVU2SSxNQUFNO0FBQUE7QUFBQSxZQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRaUs7QUFBQSxVQUVoS3hILE9BQU8rQixXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVi9CLGlCQUFPK0IsV0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQSxLQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0NBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUEsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9OLFNBQVNPO0FBQUFBLGdCQUNoQixVQUFVK0I7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDcEYsVUFBVTZJLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFpSztBQUFBLFlBRWhLeEgsT0FBT2dDLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEMsaUJBQU9nQyxhQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVILHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPUCxTQUFTUztBQUFBQSxnQkFDaEIsVUFBVTZCO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3BGLFVBQVU2SSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRaUs7QUFBQSxZQUVoS3hILE9BQU9rQyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJsQyxpQkFBT2tDLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsZUFsQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsYUE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBTztBQUFBO0FBQUEsZ0JBRVAsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBO0FBQUE7QUFBQSxZQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9ULFNBQVNLO0FBQUFBLGNBQ2hCLFVBQVVpQztBQUFBQSxjQUNWLElBQUc7QUFBQSxjQUNILGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxXQUFXLHFDQUFxQ3BGLFVBQVU2SSxNQUFNO0FBQUE7QUFBQSxZQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRaUs7QUFBQSxVQUVoS3hILE9BQU84QixXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI5QixpQkFBTzhCLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsYUFsQjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFVO0FBQUE7QUFBQSxnQkFFTix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBO0FBQUE7QUFBQSxZQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBZUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU8xQixxQkFBcUJxSDtBQUFBQSxjQUM1QixVQUFVM0M7QUFBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsdUJBQXVCO0FBQUEsY0FDdkIsY0FBYyxDQUFDNEMsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVMxQixZQUFZLEVBQUVDLFNBQVN1QixNQUFNeEIsWUFBWSxDQUFDO0FBQUEsY0FHM0QxRixtQkFBU3FDO0FBQUFBLGdCQUFJLENBQUNxQyxRQUNiLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxJQUFJbEMsS0FDckNrQyxjQUFJOUIsU0FEYThCLElBQUlsQyxLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0JBO0FBQUEsYUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlDQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDcUg7QUFBQTtBQUFBLFVBSGpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0ExT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJPQTtBQUFBLFNBL09GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnUEEsS0FqUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtQQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd0RDtBQUFBQSxRQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUV2QyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVd0gsY0FBYyxZQUFVLE1BQzVEO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVMLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPOUUsZUFBZVY7QUFBQUEsa0JBQ3RCLFVBQVVxRjtBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVyxxQ0FBcUNySSxVQUFVNkksTUFBTTtBQUFBO0FBQUEsZ0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFpSztBQUFBLGNBRWhLeEgsT0FBTzJCLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjNCLGlCQUFPMkIsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxpQkFsQjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVSLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9VLGVBQWVUO0FBQUFBLG9CQUN0QixVQUFVb0Y7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDckksVUFBVTZJLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUWlLO0FBQUEsZ0JBRWhLeEgsT0FBTzRCLFNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjVCLGlCQUFPNEIsU0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxtQkFsQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9TLGVBQWVSO0FBQUFBLG9CQUN0QixVQUFVbUY7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDckksVUFBVTZJLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUWlLO0FBQUEsZ0JBRWhLeEgsT0FBTzZCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQXdCYixpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU07QUFBQTtBQUFBLG9CQUVOLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPUSxlQUFlTjtBQUFBQSxrQkFDdEIsVUFBVWlGO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3JJLFVBQVU2SSxNQUFNO0FBQUE7QUFBQSxnQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUWlLO0FBQUEsY0FFaEt4SCxPQUFPK0IsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YvQixpQkFBTytCLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQSxLQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFQSx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPTSxlQUFlTDtBQUFBQSxvQkFDdEIsVUFBVWdGO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3JJLFVBQVU2SSxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFpSztBQUFBLGdCQUVoS3hILE9BQU9nQyxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmhDLGlCQUFPZ0MsYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVILHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9LLGVBQWVIO0FBQUFBLG9CQUN0QixVQUFVOEU7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDckksVUFBVTZJLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUWlLO0FBQUEsZ0JBRWhLeEgsT0FBT2tDLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QmxDLGlCQUFPa0MsVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxtQkFsQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsaUJBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkNBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTztBQUFBO0FBQUEsb0JBRVAsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9HLGVBQWVQO0FBQUFBLGtCQUN0QixVQUFVa0Y7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDckksVUFBVTZJLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRaUs7QUFBQSxjQUVoS3hILE9BQU84QixXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI5QixpQkFBTzhCLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBbEI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxvQkFFTix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQWVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLElBQUc7QUFBQSxrQkFDSCxNQUFLO0FBQUEsa0JBQ0wsT0FBTzFCLHFCQUFxQnFIO0FBQUFBLGtCQUM1QixVQUFVcEM7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVjtBQUFBLGtCQUNBLHVCQUF1QjtBQUFBLGtCQUN2QixjQUFjLENBQUNxQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBUzFCLFlBQVksRUFBRUMsU0FBU3VCLE1BQU14QixZQUFZLENBQUM7QUFBQSxrQkFHM0QxRixtQkFBU3FDO0FBQUFBLG9CQUFJLENBQUNnRixZQUNiLHVCQUFDLE9BQU8sUUFBUCxFQUFnQyxPQUFPQSxRQUFRN0UsS0FDN0M2RSxrQkFBUXpFLFNBRFN5RSxRQUFRN0UsS0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBa0JBO0FBQUEsY0FFQ2hELE9BQU9pQyxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCakMsaUJBQU9pQyxrQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxpQkExQ3BFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNENBO0FBQUEsYUFDRWYseUJBQXlCLHNCQUN6QkEseUJBQXlCLG9CQUN6QkEseUJBQXlCLHVCQUV2Qix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLGdCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT1osOEJBQThCbUg7QUFBQUEsa0JBQ3JDLElBQUc7QUFBQSxrQkFDSCxVQUFVaEM7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVjtBQUFBLGtCQUNBLHVCQUF1QjtBQUFBLGtCQUN2QixjQUFjLENBQUNpQyxPQUFPQyxXQUNwQkEsUUFBUUMsVUFBVUUsU0FBUyxFQUFFNUIsWUFBWSxFQUFFQyxTQUFTdUIsTUFBTXhCLFlBQVksQ0FBQztBQUFBLGtCQUd6RTtBQUFBLDJDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxRQUFNLE1BQUMsd0NBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQ2xILE1BQU02RDtBQUFBQSxzQkFBSSxDQUFDQyxVQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNRSxLQUN6Q0Y7QUFBQUEsOEJBQU1uQjtBQUFBQSx3QkFBSztBQUFBLHdCQUFJbUIsT0FBT2IsZ0JBQWdCbUI7QUFBQUEsMkJBRHJCTixNQUFNRSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBO0FBQUEsZ0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9CQTtBQUFBLGNBQ0NoRCxPQUFPeUUscUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnpFLGlCQUFPeUUscUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1FO0FBQUEsaUJBN0J2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStCQTtBQUFBLFlBRUosdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDK0Y7QUFBQTtBQUFBLGNBSDNHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBalJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa1JBO0FBQUEsYUF0UkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVSQTtBQUFBO0FBQUEsTUEzUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNFJBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV2pGO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSSx5QkFBZSxJQUFJO0FBQUEsUUFDckI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCxlQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUNtQixNQUFNO0FBQ2ZBLGtCQUFFNEUsZUFBZTtBQUNqQnNCLGlDQUFpQjtBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYnJILHNCQUFZK0IsUUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVJ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDaEQsVUFBVTZJLE1BQU07QUFBQTtBQUFBLG9CQUxsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS2lLO0FBQUEscUJBaEJuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQzJGO0FBQUE7QUFBQSxrQkFIdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWlDQTtBQUFBLGFBdENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3Q0E7QUFBQTtBQUFBLE1BL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWdEQTtBQUFBLE9Bam9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa29CQSxLQW5vQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9vQkE7QUFFSjtBQUFFekksR0F0cENJRCxPQUFLO0FBQUFpSixLQUFMako7QUF3cENOLGVBQWVBO0FBQU0sSUFBQWlKO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJNZERlbGV0ZSIsIkNpRWRpdCIsIklvTWRNb3JlIiwiSW5wdXQiLCJTZWxlY3QiLCJEcm9wZG93biIsIk1vZGFsIiwibWFkYWwiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJmaWVsZFNpemUiLCJCcmVhZGNydW1iIiwiY29uZmlybSIsIkFnZW50IiwiX3MiLCJ1c2VycyIsInNldFVzZXJzIiwiVGFibGVBZ2VudHMiLCJzZXRUYWJsZUFnZW50cyIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFVzZXIiLCJzZXRDdXJyZW50VXNlciIsImN1cnJlbnRVcGRhdGVVc2VyIiwic2V0Q3VycmVudFVwZGF0ZVVzZXIiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInNlbGVjdGVkTWFuYWdlcklkIiwic2V0U2VsZWN0ZWRNYW5hZ2VySWQiLCJzZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZCIsInNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkIiwibWFuYWdlcnMiLCJzZXRNYW5hZ2VycyIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsInNlbGVjdGVkTWFuYWdlclRpdGxlIiwic2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsIm5hbWUiLCJlbWFpbCIsInBob25lX251bWJlciIsImFkZHJlc3MiLCJwaW5jb2RlIiwiYWRoYWFyX25vIiwiZGVzaWduYXRpb25faWQiLCJwYW5fbm8iLCJhZ2VudF90eXBlIiwiaXNWZXJpZmllZCIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJmZXRjaEFnZW50cyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImFnZW50IiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJpZCIsImVtcGxveWVlQ29kZSIsImRlc2lnbmF0aW9uIiwidGl0bGUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlVmVyaWZ5QWdlbnQiLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaE1hbmFnZXJzIiwiaGFuZGxlQ2hhbmdlIiwicHJldkRhdGEiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJyZWdleCIsInBob25lIiwiYWFkaGFhciIsInBhbiIsInRyaW0iLCJ0ZXN0IiwicmVwb3J0aW5nX21hbmFnZXIiLCJ0b1VwcGVyQ2FzZSIsImxlbmd0aCIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVBbnREU2VsZWN0TWFuYWdlciIsIm1hbmFnZXJJZCIsInNlbGVjdGVkIiwiZmluZCIsIm1nciIsInByZXYiLCJtYW5hZ2VyVGl0bGUiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3RNYW5hZ2VyIiwiaGFuZGxlQW50RFNlbGVjdFJlcG9ydGluZ01hbmFnZXIiLCJyZXBvcnRpbmdJZCIsInJlcG9ydGluZ01hbmFnZXJJZCIsImhhbmRsZVJlcG9ydGluZ01hbmFnZXIiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWRhdGUiLCJkYXRhVG9TZW5kIiwicmVwb3J0aW5nX21hbmFnZXJfaWQiLCJwb3N0IiwiaGVhZGVycyIsImVyck1zZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJwcmV2RXJyb3JzIiwidXNlcklkIiwiY29udGVudCIsIm9rVGV4dCIsImNhbmNlbFRleHQiLCJvbk9rIiwicHV0IiwiY29sdW1ucyIsImhlYWRlciIsImZpbHRlcmVkVXNlcnMiLCJmaWx0ZXIiLCJ1c2VyIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVEZWxldGVVc2VyIiwiZGVsZXRlIiwiaGFuZGxlVXBkYXRlIiwiaXNWYWxpZCIsImhhbmRsZU1hbmFnZXIiLCJldmVudCIsImdyb3VwSWQiLCJoZWlnaHQiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwibWFuYWdlciIsInRvU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWdlbnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IE1kRGVsZXRlIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IENpRWRpdCB9IGZyb20gXCJyZWFjdC1pY29ucy9jaVwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93bixNb2RhbCBhcyBtYWRhbCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcbmNvbnN0IHsgY29uZmlybSB9ID0gbWFkYWw7XHJcbmNvbnN0IEFnZW50ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUFnZW50cywgc2V0VGFibGVBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVVc2VyLCBzZXRDdXJyZW50VXBkYXRlVXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJJZCwgc2V0U2VsZWN0ZWRNYW5hZ2VySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkLCBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbWFuYWdlcnMsIHNldE1hbmFnZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJUaXRsZSwgc2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogXCJcIixcclxuICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgLy8gcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgcGluY29kZTogXCJcIixcclxuICAgIGFkaGFhcl9ubzogXCJcIixcclxuICAgIGRlc2lnbmF0aW9uX2lkOiBcIlwiLFxyXG4gICAgcGFuX25vOiBcIlwiLFxyXG4gICAgYWdlbnRfdHlwZTogXCJhZ2VudFwiLFxyXG4gICAgaXNWZXJpZmllZDogXCJ0cnVlXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogXCJcIixcclxuICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgLy8gcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgcGluY29kZTogXCJcIixcclxuICAgIGFkaGFhcl9ubzogXCJcIixcclxuICAgIGRlc2lnbmF0aW9uX2lkOiBcIlwiLFxyXG4gICAgcGFuX25vOiBcIlwiLFxyXG4gICAgIGlzVmVyaWZpZWQ6IFwiZmFsc2VcIixcclxuICB9KTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZT8uZGF0YT8uYWdlbnQpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhPy5hZ2VudD8ubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXA/Lm5hbWUsXHJcbiAgICAgICAgICBlbXBsb3llZUNvZGU6IGdyb3VwPy5lbXBsb3llZUNvZGUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnBob25lX251bWJlcixcclxuICAgICAgICAgIC8vIHBhc3N3b3JkOiBncm91cD8ucGFzc3dvcmQsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbjogZ3JvdXA/LmRlc2lnbmF0aW9uX2lkPy50aXRsZSxcclxuICAgICAgICAgIGFjdGlvbjogIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyICBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIHsvKiA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JlZW4tNDAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbWQgc2hhZG93IGhvdmVyOmJvcmRlci1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxDaUVkaXQgY29sb3I9XCJncmVlblwiIC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+ICovfVxyXG4gICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgdHJpZ2dlcj17WydjbGljayddfVxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmVyaWZ5QWdlbnQoZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIFVuIFZlcmlmeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRUYWJsZUFnZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQWdlbnRzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTWFuYWdlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Rlc2lnbmF0aW9uL2dldC1kZXNpZ25hdGlvblwiKTtcclxuICAgICAgICBzZXRNYW5hZ2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hNYW5hZ2VycygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZEVtcGxveWVlXCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG4gICAgY29uc3QgcmVnZXggPSB7XHJcbiAgICAgIGVtYWlsOiAvXlteXFxzQF0rQFteXFxzQF0rXFwuW15cXHNAXSskLyxcclxuICAgICAgcGhvbmU6IC9eWzYtOV1cXGR7OX0kLyxcclxuICAgICAgLy8gcGFzc3dvcmQ6XHJcbiAgICAgIC8vICAgL14oPz0uKlthLXpdKSg/PS4qW0EtWl0pKD89LipcXGQpKD89LipbQCQhJSo/Jl0pW0EtWmEtelxcZEAkISUqPyZdezUsfSQvLFxyXG4gICAgICBwaW5jb2RlOiAvXlxcZHs2fSQvLFxyXG4gICAgICBhYWRoYWFyOiAvXlxcZHsxMn0kLyxcclxuICAgICAgcGFuOiAvXltBLVpdezV9WzAtOV17NH1bQS1aXXsxfSQvLFxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIWRhdGEubmFtZS50cmltKCkpIHtcclxuICAgICAgbmV3RXJyb3JzLm5hbWUgPSBcIkZ1bGwgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5lbWFpbCkge1xyXG4gICAgICBuZXdFcnJvcnMuZW1haWwgPSBcIkVtYWlsIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5lbWFpbC50ZXN0KGRhdGEuZW1haWwpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5lbWFpbCA9IFwiSW52YWxpZCBlbWFpbCBmb3JtYXRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGhvbmVfbnVtYmVyKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5waG9uZV9udW1iZXIgPSBcIlBob25lIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGhvbmUudGVzdChkYXRhLnBob25lX251bWJlcikpIHtcclxuICAgICAgbmV3RXJyb3JzLnBob25lX251bWJlciA9IFwiSW52YWxpZCAgcGhvbmUgbnVtYmVyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gaWYgKCFkYXRhLnBhc3N3b3JkKSB7XHJcbiAgICAvLyAgIG5ld0Vycm9ycy5wYXNzd29yZCA9IFwiUGFzc3dvcmQgaXMgcmVxdWlyZWRcIjtcclxuICAgIC8vIH0gZWxzZSBpZiAoIXJlZ2V4LnBhc3N3b3JkLnRlc3QoZGF0YS5wYXNzd29yZCkpIHtcclxuICAgIC8vICAgbmV3RXJyb3JzLnBhc3N3b3JkID1cclxuICAgIC8vICAgICBcIlBhc3N3b3JkIG11c3QgY29udGFpbiBhdCBsZWFzdCA1IGNoYXJhY3RlcnMsIG9uZSB1cHBlcmNhc2UsIG9uZSBsb3dlcmNhc2UsIG9uZSBudW1iZXIsIGFuZCBvbmUgc3BlY2lhbCBjaGFyYWN0ZXJcIjtcclxuICAgIC8vIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGluY29kZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGluY29kZSA9IFwiUGluY29kZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGluY29kZS50ZXN0KGRhdGEucGluY29kZSkpIHtcclxuICAgICAgbmV3RXJyb3JzLnBpbmNvZGUgPSBcIkludmFsaWQgcGluY29kZSAoNiBkaWdpdHMgcmVxdWlyZWQpXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmFkaGFhcl9ubykge1xyXG4gICAgICBuZXdFcnJvcnMuYWRoYWFyX25vID0gXCJBYWRoYWFyIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXguYWFkaGFhci50ZXN0KGRhdGEuYWRoYWFyX25vKSkge1xyXG4gICAgICBuZXdFcnJvcnMuYWRoYWFyX25vID0gXCJJbnZhbGlkIEFhZGhhYXIgbnVtYmVyICgxMiBkaWdpdHMgcmVxdWlyZWQpXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIXNlbGVjdGVkTWFuYWdlcklkKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5yZXBvcnRpbmdfbWFuYWdlciA9IFwiUmVwb3J0aW5nIE1hbmFnZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5wYW5fbm8pIHtcclxuICAgICAgbmV3RXJyb3JzLnBhbl9ubyA9IFwiUEFOIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGFuLnRlc3QoZGF0YS5wYW5fbm8udG9VcHBlckNhc2UoKSkpIHtcclxuICAgICAgbmV3RXJyb3JzLnBhbl9ubyA9IFwiSW52YWxpZCBQQU4gZm9ybWF0IChlLmcuLCBBQkNERTEyMzRGKVwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5hZGRyZXNzLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuYWRkcmVzcyA9IFwiQWRkcmVzcyBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChkYXRhLmFkZHJlc3MudHJpbSgpLmxlbmd0aCA8IDEwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGRyZXNzID0gXCJBZGRyZXNzIHNob3VsZCBiZSBhdCBsZWFzdCAxMCBjaGFyYWN0ZXJzXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdE1hbmFnZXIgPSAobWFuYWdlcklkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChtYW5hZ2VySWQpO1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdGVkID0gbWFuYWdlcnMuZmluZCgobWdyKSA9PiBtZ3IuX2lkID09PSBtYW5hZ2VySWQpO1xyXG4gICAgY29uc3QgdGl0bGUgPSBzZWxlY3RlZD8udGl0bGUgfHwgXCJcIjtcclxuXHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJUaXRsZSh0aXRsZSk7XHJcblxyXG5cclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBtYW5hZ2VySWQsXHJcbiAgICAgIG1hbmFnZXJUaXRsZTogdGl0bGUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBtYW5hZ2VySWQ6IFwiXCIsXHJcbiAgICAgIG1hbmFnZXJUaXRsZTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZUFudElucHV0RFNlbGVjdE1hbmFnZXIgPSAobWFuYWdlcklkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChtYW5hZ2VySWQpO1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdGVkID0gbWFuYWdlcnMuZmluZCgobWdyKSA9PiBtZ3IuX2lkID09PSBtYW5hZ2VySWQpO1xyXG4gICAgY29uc3QgdGl0bGUgPSBzZWxlY3RlZD8udGl0bGUgfHwgXCJcIjtcclxuXHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJUaXRsZSh0aXRsZSk7XHJcblxyXG5cclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBtYW5hZ2VySWQsXHJcbiAgICAgIG1hbmFnZXJUaXRsZTogdGl0bGUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBtYW5hZ2VySWQ6IFwiXCIsXHJcbiAgICAgIG1hbmFnZXJUaXRsZTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdFJlcG9ydGluZ01hbmFnZXIgPSAocmVwb3J0aW5nSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkKHJlcG9ydGluZ0lkKTtcclxuXHJcblxyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIHJlcG9ydGluZ01hbmFnZXJJZDogcmVwb3J0aW5nSWQsXHJcbiAgICB9KSk7XHJcblxyXG5cclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcmVwb3J0aW5nTWFuYWdlcklkOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlcG9ydGluZ01hbmFnZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkKHZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZGF0ZSA9IHZhbGlkYXRlRm9ybShcImFkZEVtcGxveWVlXCIpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkYXRlKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YVRvU2VuZCA9IHtcclxuICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgZGVzaWduYXRpb25faWQ6IHNlbGVjdGVkTWFuYWdlcklkLFxyXG4gICAgICAgICAgcmVwb3J0aW5nX21hbmFnZXJfaWQ6IHNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9hZ2VudC9hZGRcIiwgZGF0YVRvU2VuZCwge1xyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgbmFtZTogXCJcIixcclxuICAgICAgICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgICAgLy8gcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICAgICAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgICAgICAgcGluY29kZTogXCJcIixcclxuICAgICAgICAgIGFkaGFhcl9ubzogXCJcIixcclxuICAgICAgICAgIHBhbl9ubzogXCJcIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChcIlwiKTtcclxuICAgICAgICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChcIlwiKVxyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBZ2VudCBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIGFnZW50OlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgY29uc3QgZXJyTXNnID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICAgIGlmIChlcnJNc2cuaW5jbHVkZXMoXCJwaG9uZSBudW1iZXJcIikpIHtcclxuICAgICAgICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldkVycm9ycyxcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBcIlBob25lIG51bWJlciBhbHJlYWR5IGV4aXN0c1wiLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZSxcclxuICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuY29uc3QgaGFuZGxlVmVyaWZ5QWdlbnQgPSAodXNlcklkKSA9PiB7XHJcblxyXG4gIGNvbmZpcm0oe1xyXG4gICAgdGl0bGU6IFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIFVuLVZlcmlmeSB0aGlzIGFnZW50P1wiLFxyXG4gICAgY29udGVudDogXCJUaGlzIGFjdGlvbiB3aWxsIG1hcmsgdGhlIGFnZW50IGFzIFVuLVZlcmlmaWVkLlwiLFxyXG4gICAgb2tUZXh0OiBcIlllcywgVmVyaWZ5XCIsXHJcbiAgICBjYW5jZWxUZXh0OiBcIkNhbmNlbFwiLFxyXG5cclxuICAgIGFzeW5jIG9uT2soKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnB1dChgL2FnZW50L3VwZGF0ZS8ke3VzZXJJZH1gLCB7XHJcbiAgICAgICAgICBpc1ZlcmlmaWVkOiBmYWxzZSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG5cclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBZ2VudCBVbi1WZXJpZmllZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuXHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6XHJcbiAgICAgICAgICAgIGVycm9yPy5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byB2ZXJpZnkgYWdlbnRcIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSxcclxuICB9KTtcclxufTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQWdlbnQgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZUNvZGVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElEXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQWdlbnQgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImRlc2lnbmF0aW9uXCIsIGhlYWRlcjogXCJEZXNpZ25hdGlvblwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJwYXNzd29yZFwiLCBoZWFkZXI6IFwiQWdlbnQgUGFzc3dvcmRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVXNlcnMgPSB1c2Vycy5maWx0ZXIoKHVzZXIpID0+XHJcbiAgICB1c2VyLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYWdlbnQvZ2V0LWJ5LWlkLyR7dXNlcklkfWApO1xyXG4gICAgICBzZXRDdXJyZW50VXNlcihyZXNwb25zZS5kYXRhPy5hZ2VudCk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYWdlbnQvZ2V0LWJ5LWlkLyR7dXNlcklkfWApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlVXNlcihyZXNwb25zZS5kYXRhPy5hZ2VudCk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBuYW1lOiByZXNwb25zZT8uZGF0YT8uYWdlbnQ/Lm5hbWUsXHJcbiAgICAgICAgZW1haWw6IHJlc3BvbnNlPy5kYXRhPy5hZ2VudD8uZW1haWwsXHJcbiAgICAgICAgcGhvbmVfbnVtYmVyOiByZXNwb25zZT8uZGF0YT8uYWdlbnQ/LnBob25lX251bWJlcixcclxuICAgICAgICAvLyBwYXNzd29yZDogcmVzcG9uc2U/LmRhdGE/LmFnZW50Py5wYXNzd29yZCxcclxuICAgICAgICBwaW5jb2RlOiByZXNwb25zZT8uZGF0YT8uYWdlbnQ/LnBpbmNvZGUsXHJcbiAgICAgICAgYWRoYWFyX25vOiByZXNwb25zZT8uZGF0YT8uYWdlbnQ/LmFkaGFhcl9ubyxcclxuICAgICAgICBwYW5fbm86IHJlc3BvbnNlPy5kYXRhPy5hZ2VudD8ucGFuX25vLFxyXG4gICAgICAgIGFkZHJlc3M6IHJlc3BvbnNlPy5kYXRhPy5hZ2VudD8uYWRkcmVzcyxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNlbGVjdGVkTWFuYWdlcklkKHJlc3BvbnNlLmRhdGE/LmFnZW50Py5kZXNpZ25hdGlvbl9pZD8uX2lkIHx8IFwiXCIpO1xyXG4gICAgICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChyZXNwb25zZS5kYXRhPy5hZ2VudD8ucmVwb3J0aW5nX21hbmFnZXJfaWQgfHwgXCJcIik7XHJcbiAgICAgIHNldFNlbGVjdGVkTWFuYWdlclRpdGxlKHJlc3BvbnNlLmRhdGE/LmFnZW50Py5kZXNpZ25hdGlvbl9pZD8udGl0bGUpXHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVVzZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudFVzZXIpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvYWdlbnQvZGVsZXRlLyR7Y3VycmVudFVzZXIuX2lkfWApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFnZW50IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YVRvU2VuZCA9IHtcclxuICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgZGVzaWduYXRpb25faWQ6IHNlbGVjdGVkTWFuYWdlcklkLFxyXG4gICAgICAgICAgcmVwb3J0aW5nX21hbmFnZXJfaWQ6IHNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL2FnZW50L3VwZGF0ZS8ke2N1cnJlbnRVcGRhdGVVc2VyLl9pZH1gLFxyXG4gICAgICAgICAgZGF0YVRvU2VuZFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRTZWxlY3RlZE1hbmFnZXJJZChcIlwiKTtcclxuICAgICAgICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChcIlwiKVxyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBZ2VudCBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBhZ2VudDpcIiwgZXJyb3IpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVNYW5hZ2VyID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBjb25zdCBncm91cElkID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0U2VsZWN0ZWRNYW5hZ2VySWQoZ3JvdXBJZCk7XHJcbiAgICBjb25zdCBzZWxlY3RlZCA9IG1hbmFnZXJzLmZpbmQoKG1ncikgPT4gbWdyLl9pZCA9PT0gZ3JvdXBJZCk7XHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJUaXRsZShzZWxlY3RlZD8udGl0bGUgfHwgXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgLy8gY29uc3QgaGFuZGxlUmVwb3J0aW5nTWFuYWdlciA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gIC8vICAgY29uc3QgcmVwb3J0aW5nSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgLy8gICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChyZXBvcnRpbmdJZCk7XHJcbiAgLy8gfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiID5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgIFxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IHctOCBcIj5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5BZ2VudHM8L2gxPlxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICB9fVxyXG4gICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgPlxyXG4gICAgICAgICsgQWRkIEFnZW50XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG4gIHtUYWJsZUFnZW50cz8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgPERhdGFUYWJsZVxyXG4gICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICBkYXRhPXtmaWx0ZXJPcHRpb24oVGFibGVBZ2VudHMsIHNlYXJjaFRleHQpfVxyXG4gICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICBzZWxlY3Rpb25Db2xvcj1cImN1c3RvbS12aW9sZXRcIlxyXG4gICAgICBleHBvcnRlZEZpbGVOYW1lPXtgRW1wbG95ZWVzLSR7XHJcbiAgICAgICAgVGFibGVBZ2VudHMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgPyBUYWJsZUFnZW50c1swXS5uYW1lICsgXCIgdG8gXCIgKyBUYWJsZUFnZW50c1tUYWJsZUFnZW50cy5sZW5ndGggLSAxXS5uYW1lXHJcbiAgICAgICAgICA6IFwiZW1wdHlcIlxyXG4gICAgICB9LmNzdmB9XHJcbiAgICBcclxuICAgIC8+XHJcbiAgKSA6IChcclxuICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgZmFpbHVyZT17VGFibGVBZ2VudHMubGVuZ3RoIDw9IDB9XHJcbiAgICAgIGRhdGE9XCJBZ2VudCBEYXRhXCJcclxuICAgIC8+XHJcbiAgKX1cclxuPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQWRkIEFnZW50XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEZ1bGwgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEZ1bGwgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLm5hbWV9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1haWwgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmVtYWlsfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQYXNzd29yZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGluY29kZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFkaGFhcl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGhhYXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQYW4gTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFuX25vfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhbiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFuX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5wYW5fbm99PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEFkZHJlc3MgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuYWRkcmVzc308L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZXNpZ25hdGlvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNYW5hZ2VySWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVNYW5hZ2VyfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBoaWRkZW4+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0IERlc2lnbmF0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7bWFuYWdlcnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3VwLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJtYW5hZ2VyLXNlbGVjdFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJtYW5hZ2VySWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNYW5hZ2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQW50RFNlbGVjdE1hbmFnZXJ9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IERlc2lnbmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge21hbmFnZXJzLm1hcCgobWdyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXttZ3IuX2lkfSB2YWx1ZT17bWdyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bWdyLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyIGJvcmRlci0yIGJvcmRlci1ibGFja1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNhdmUgQWdlbnRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgVXBkYXRlIEFnZW50XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEZ1bGwgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEZ1bGwgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLm5hbWV9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1haWwgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZW1haWx9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQYXNzd29yZCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwZGF0ZS1wYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGluY29kZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBZGhhYXIgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFkaGFhcl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkaGFhciBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBhbiBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGFuX25vfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFuIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYW5fbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnBhbl9ub308L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5hZGRyZXNzfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERlc2lnbmF0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZE1hbmFnZXJJZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZU1hbmFnZXJ9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCIgaGlkZGVuPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBEZXNpZ25hdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge21hbmFnZXJzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cC50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwic2VsZWN0ZWRNYW5hZ2VySWRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwic2VsZWN0ZWRNYW5hZ2VySWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNYW5hZ2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQW50SW5wdXREU2VsZWN0TWFuYWdlcn1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGVzaWduYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7bWFuYWdlcnMubWFwKChtYW5hZ2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXttYW5hZ2VyLl9pZH0gdmFsdWU9e21hbmFnZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHttYW5hZ2VyLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmRlc2lnbmF0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZGVzaWduYXRpb25faWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7KHNlbGVjdGVkTWFuYWdlclRpdGxlID09PSBcIlNhbGVzIEV4Y2VjdXRpdmVcIiB8fFxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRNYW5hZ2VyVGl0bGUgPT09IFwiQnVzaW5lc3MgQWdlbnRcIiB8fFxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRNYW5hZ2VyVGl0bGUgPT09IFwiT2ZmaWNlIEV4ZWN1dGl2ZVwiKVxyXG4gICAgICAgICAgICAgICAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZXBvcnRpbmcgTWFuYWdlclxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwic2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVJlcG9ydGluZ01hbmFnZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZXBvcnRpbmcgTWFuYWdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCIgaGlkZGVuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVwb3J0aW5nIE1hbmFnZXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAubmFtZX0gLSB7Z3JvdXA/LmRlc2lnbmF0aW9uX2lkPy50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5yZXBvcnRpbmdfbWFuYWdlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5yZXBvcnRpbmdfbWFuYWdlcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZSBBZ2VudFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgRGVsZXRlIEFnZW50XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50VXNlciAmJiAoXHJcbiAgICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZVVzZXIoKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFVzZXIubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHRvIGNvbmZpcm0gZGVsZXRpb24uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIGVtcGxveWVlIEZ1bGwgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFnZW50O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQWdlbnQuanN4In0=