import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AddGroupForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select, Collapse, Tag, Button, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { PlusOutlined, DeleteOutlined, EditOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import ReConfirmModal from "/src/components/modals/ReConfirmModal.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
const { Panel } = Collapse;
const AddGroupForm = ({
  mode = "add",
  initialData = null,
  fieldSize = { height: "h-12" }
}) => {
  _s();
  const [formData, setFormData] = useState({
    group_name: "",
    group_type: "",
    group_value: "",
    group_install: "",
    group_members: "",
    group_duration: "",
    start_date_type: "fixed",
    start_date: "",
    end_date: "",
    minimum_bid: "",
    maximum_bid: "",
    commission: "1",
    group_commission: "5",
    incentives: "1",
    reg_fee: "",
    monthly_installment: "",
    weekly_installment: "",
    daily_installment: "",
    relationship_manager: "",
    app_display_vacany_seat: null,
    auction_processing_type: "SYSTEM",
    auction_mode: "ONLINE"
  });
  const [prefixedAuctionEntries, setPrefixedAuctionEntries] = useState([]);
  const [currentAuctionEntry, setCurrentAuctionEntry] = useState({
    auction_time: "10:00 AM",
    next_auction_time: "11:00 AM",
    bid_percentage: "",
    bid_amount: "",
    commission: "",
    win_amount: "",
    divident: "",
    divident_head: "",
    payable: "",
    auction_date: "",
    next_date: "",
    auction_type: "NORMAL",
    auction_stage_type: "COMMENCEMENT",
    auction_number: 1
  });
  const [editingIndex, setEditingIndex] = useState(null);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [employees, setEmployees] = useState([]);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const location = useLocation();
  const [isEditMode, setIsEditMode] = useState(false);
  const [groupId, setGroupId] = useState(null);
  const [loadingFetch, setLoadingFetch] = useState(false);
  const getAuctionEntriesOnly = (entries) => entries.filter((e) => e.auction_stage_type === "AUCTION");
  const renumberAuctionEntries = (entries) => {
    let auctionCounter = 1;
    return entries.map((entry) => {
      if (entry.auction_stage_type === "AUCTION" || entry.auction_stage_type === "COMMENCEMENT") {
        return {
          ...entry,
          auction_number: auctionCounter++
        };
      }
      return entry;
    });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    let newValue = value;
    const stringNumericFields = [
      "group_value",
      "group_install",
      "group_members",
      "group_duration",
      "reg_fee",
      "daily_installment",
      "weekly_installment",
      "monthly_installment",
      "minimum_bid",
      "maximum_bid",
      "commission",
      "group_commission",
      "incentives"
    ];
    const numberFields = ["app_display_vacany_seat"];
    if (stringNumericFields.includes(name)) {
      if (value === "") {
        newValue = "";
      } else {
        let num = Number(value);
        if (!isNaN(num) && num >= 0) {
          newValue = num.toString();
        } else if (num < 0) {
          newValue = "0";
        } else if (isNaN(num)) {
          newValue = "";
        }
      }
    }
    if (numberFields.includes(name)) {
      if (value === "") {
        newValue = null;
      } else {
        let num = Number(value);
        if (!isNaN(num) && num >= 0) {
          newValue = num;
        } else if (num < 0) {
          newValue = 0;
        } else if (isNaN(num)) {
          newValue = null;
        }
      }
    }
    setFormData((prevData) => ({
      ...prevData,
      [name]: newValue
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAuctionInputChange = (field, value) => {
    setCurrentAuctionEntry((prev) => ({
      ...prev,
      [field]: value
    }));
  };
  const handleAddAuctionEntry = () => {
    if (!currentAuctionEntry.auction_date || !currentAuctionEntry.auction_time) {
      alert("Please fill in at least the Date and Time.");
      return;
    }
    const newEntry = { ...currentAuctionEntry };
    ["bid_percentage", "bid_amount", "commission", "win_amount", "divident", "payable", "auction_number"].forEach((field) => {
      if (newEntry[field]) newEntry[field] = newEntry[field];
    });
    setPrefixedAuctionEntries([...prefixedAuctionEntries, newEntry]);
    setCurrentAuctionEntry({
      ...currentAuctionEntry,
      bid_percentage: "",
      bid_amount: "",
      commission: "",
      win_amount: "",
      divident: "",
      payable: "",
      auction_date: "",
      auction_number: prefixedAuctionEntries.length + 2,
      auction_stage_type: "AUCTION"
    });
  };
  const handleRemoveEntry = (index) => {
    const entryToRemove = prefixedAuctionEntries[index];
    if (entryToRemove.auction_stage_type === "COMMENCEMENT") {
      message.warning("Commencement entry is mandatory and cannot be deleted.");
      return;
    }
    const updatedList = prefixedAuctionEntries.filter((_, i) => i !== index);
    const renumberedList = renumberAuctionEntries(updatedList);
    setPrefixedAuctionEntries(renumberedList);
    if (editingIndex === index) {
      setEditingIndex(null);
      resetAuctionEntryForm();
    } else if (editingIndex !== null && editingIndex > index) {
      setEditingIndex(editingIndex - 1);
    }
  };
  const handleReconfirmation = (e) => {
    e.preventDefault();
    const isValid = validateForm("addGroup");
    if (!isValid) {
      message.warning("Please fill all the required fields");
      return;
    }
    setShowConfirm(true);
  };
  const fetchGroupForEdit = async (id) => {
    setLoadingFetch(true);
    try {
      const response = await api.get(`/v1/admin/groups/${id}`);
      const group = response.data?.data;
      const formattedStartDate = group.start_date?.split("T")[0];
      const formattedEndDate = group.end_date?.split("T")[0];
      setFormData({
        group_name: group.group_name || "",
        group_type: group.group_type || "",
        group_value: group.group_value || "",
        group_install: group.group_install || "",
        group_members: group.group_members || "",
        group_duration: group.group_duration || "",
        start_date_type: group.start_date_type || "fixed",
        start_date: formattedStartDate || "",
        end_date: formattedEndDate || "",
        minimum_bid: group.minimum_bid || "",
        maximum_bid: group.maximum_bid || "",
        commission: group.commission || "1",
        group_commission: group.group_commission || "5",
        incentives: group.incentives || "1",
        reg_fee: group.reg_fee || "",
        monthly_installment: group.monthly_installment || "",
        weekly_installment: group.weekly_installment || "",
        daily_installment: group.daily_installment || "",
        relationship_manager: typeof group.relationship_manager === "object" ? group.relationship_manager?._id : group.relationship_manager || "",
        app_display_vacany_seat: group.app_display_vacany_seat || null,
        auction_processing_type: group.auction_processing_type || "",
        auction_mode: group.auction_mode || ""
      });
      if (group.prefixed_auction_entries && Array.isArray(group.prefixed_auction_entries)) {
        const sorted = [...group.prefixed_auction_entries].sort((a, b) => {
          if (a.auction_stage_type === "COMMENCEMENT") return -1;
          if (b.auction_stage_type === "COMMENCEMENT") return 1;
          return 0;
        });
        const renumbered = renumberAuctionEntries(sorted);
        setPrefixedAuctionEntries(renumbered);
      } else {
        setPrefixedAuctionEntries([]);
      }
    } catch (error) {
      console.error("Error fetching group for edit:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to load group data for editing",
        type: "error"
      });
    } finally {
      setLoadingFetch(false);
    }
  };
  useEffect(
    () => {
      const groupValue = parseFloat(formData.group_value) || 0;
      const groupCommissionPct = parseFloat(formData.group_commission) || 0;
      const groupMembers = parseFloat(formData.group_members) || 0;
      const groupInstall = parseFloat(formData.group_install) || 0;
      let bidAmount = parseFloat(currentAuctionEntry.bid_amount) || 0;
      let bidPercent = parseFloat(currentAuctionEntry.bid_percentage) || 0;
      if (bidAmount === 0 && bidPercent === 0) {
        if (currentAuctionEntry.commission !== "") {
          setCurrentAuctionEntry((prev) => ({
            ...prev,
            commission: "",
            win_amount: "",
            divident: "",
            divident_head: "",
            payable: ""
          }));
        }
        return;
      }
      if (groupValue === 0) return;
      let finalBidAmount = bidAmount;
      let finalBidPercent = bidPercent;
      if (bidAmount > 0 && bidPercent === 0) {
        finalBidPercent = bidAmount / groupValue * 100;
      } else if (bidPercent > 0 && bidAmount === 0) {
        finalBidAmount = bidPercent / 100 * groupValue;
      } else {
        finalBidPercent = bidAmount / groupValue * 100;
      }
      if (bidPercent > 0 && bidAmount === 0) {
        bidAmount = bidPercent / 100 * groupValue;
        setCurrentAuctionEntry((prev) => ({
          ...prev,
          bid_amount: bidAmount.toFixed(2)
        }));
        return;
      }
      const commission = groupValue * groupCommissionPct / 100;
      const winAmount = groupValue - bidAmount;
      const divident = bidAmount - commission;
      const dividentHead = groupMembers > 0 ? divident / groupMembers : 0;
      const payable = groupInstall - dividentHead;
      setCurrentAuctionEntry((prev) => ({
        ...prev,
        commission: commission.toFixed(2),
        win_amount: winAmount.toFixed(2),
        divident: divident.toFixed(2),
        bid_percentage: finalBidPercent.toFixed(2),
        divident_head: dividentHead.toFixed(2),
        payable: payable.toFixed(2)
      }));
    },
    [
      currentAuctionEntry.bid_amount,
      currentAuctionEntry.bid_percentage,
      formData.group_value,
      formData.group_commission,
      formData.group_members,
      formData.group_install
    ]
  );
  useEffect(() => {
    if (currentAuctionEntry.auction_date) {
      const date = new Date(currentAuctionEntry.auction_date);
      if (!isNaN(date.getTime())) {
        date.setDate(date.getDate() + 10);
        const nextDate = date.toISOString().split("T")[0];
        setCurrentAuctionEntry((prev) => ({
          ...prev,
          next_date: nextDate
        }));
      }
    }
  }, [currentAuctionEntry.auction_date]);
  useEffect(() => {
    if (currentAuctionEntry.auction_time) {
      setCurrentAuctionEntry((prev) => ({
        ...prev,
        next_auction_time: prev.auction_time
      }));
    }
  }, [currentAuctionEntry.auction_time]);
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const editParam = params.get("edit");
    const idParam = params.get("groupId");
    if (editParam === "true" && idParam) {
      setIsEditMode(true);
      setGroupId(idParam);
      fetchGroupForEdit(idParam);
      resetAuctionEntryForm();
    }
  }, [location.search]);
  useEffect(() => {
    async function getEmployees() {
      try {
        const response = await api.get("/employee");
        const responseData = response.data?.employee;
        setEmployees(responseData ? responseData : []);
      } catch (error) {
        setEmployees([]);
        console.log("Error Fetching Employees");
      }
    }
    getEmployees();
  }, []);
  const validateForm = (type) => {
    const newErrors = {};
    const data = formData;
    if (!data.group_name?.trim()) newErrors.group_name = "Group Name is required";
    if (!data.group_type) newErrors.group_type = "Group Type is required";
    if (!data.group_value) newErrors.group_value = "Group Value is required";
    if (!data.group_install) newErrors.group_install = "Group Installment Amount is required";
    if (!data.group_members) newErrors.group_members = "Group Members is required";
    if (!data.relationship_manager) newErrors.relationship_manager = "Relationship Manager is required";
    if (!data.monthly_installment) newErrors.monthly_installment = "Monthly Installment is required";
    if (!data.weekly_installment) newErrors.weekly_installment = "Weekly Installment is required";
    if (!data.daily_installment) newErrors.daily_installment = "Daily Installment is required";
    if (!data.group_duration) newErrors.group_duration = "Group Duration is required";
    if (!data.reg_fee) newErrors.reg_fee = "Registration Fee is required";
    if (!data.start_date) newErrors.start_date = "Start Date is required";
    if (!data.end_date) newErrors.end_date = "End Date is required";
    if (!data.app_display_vacany_seat) newErrors.app_display_vacany_seat = "Please Enter Display Vacant Seat";
    if (!data.start_date_type) newErrors.start_date_type = "Please select the Start date Type";
    if (formData.end_date && !data.end_date) newErrors.end_date = "End Date is required";
    else if (formData.end_date && new Date(data.end_date) < new Date(data.start_date))
      newErrors.end_date = "End Date cannot be earlier than Start Date";
    if (!data.minimum_bid) newErrors.minimum_bid = "Minimum Bid is required";
    if (!data.maximum_bid) newErrors.maximum_bid = "Maximum Bid is required";
    else if (parseFloat(data.maximum_bid) < parseFloat(data.minimum_bid))
      newErrors.maximum_bid = "Maximum Bid must be greater than or equal to Minimum Bid";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const resetAuctionEntryForm = () => {
    const maxNumber = prefixedAuctionEntries.length > 0 ? Math.max(...prefixedAuctionEntries.map((e) => Number(e.auction_number) || 0)) : 0;
    setCurrentAuctionEntry({
      auction_time: "10:00 AM",
      next_auction_time: "11:00 AM",
      bid_percentage: "",
      bid_amount: "",
      commission: "",
      win_amount: "",
      divident: "",
      divident_head: "",
      payable: "",
      auction_date: "",
      next_date: "",
      auction_type: "NORMAL",
      auction_stage_type: "AUCTION",
      auction_number: maxNumber + 1
    });
  };
  const handleAddOrUpdateAuctionEntry = () => {
    if (!currentAuctionEntry.auction_date || !currentAuctionEntry.auction_time) {
      message.warning("Please fill at least the Date and Time.");
      return;
    }
    const existingCommencement = prefixedAuctionEntries.some(
      (entry) => entry.auction_stage_type === "COMMENCEMENT"
    );
    if (currentAuctionEntry.auction_stage_type === "COMMENCEMENT" && existingCommencement && editingIndex === null) {
      message.warning("Only one Commencement entry is allowed per group.");
      return;
    }
    const newEntry = { ...currentAuctionEntry };
    if (editingIndex !== null) {
      const updatedList = [...prefixedAuctionEntries];
      updatedList[editingIndex] = {
        ...newEntry,
        auction_number: newEntry.auction_stage_type === "COMMENCEMENT" ? prefixedAuctionEntries[editingIndex].auction_number : newEntry.auction_number
      };
      setPrefixedAuctionEntries(updatedList);
      setEditingIndex(null);
      message.success("Entry updated successfully");
    } else {
      const nextNumber = prefixedAuctionEntries.length + 1;
      const finalEntry = {
        ...newEntry,
        auction_number: nextNumber
      };
      setPrefixedAuctionEntries(
        [
          ...prefixedAuctionEntries,
          finalEntry
        ]
      );
      message.success("Entry added successfully");
    }
    const nextNumberAfterAdd = prefixedAuctionEntries.length + 2;
    setCurrentAuctionEntry({
      auction_time: "10:00",
      next_auction_time: "11:00",
      bid_percentage: "",
      bid_amount: "",
      commission: "",
      win_amount: "",
      divident: "",
      divident_head: "",
      payable: "",
      auction_date: "",
      next_date: "",
      auction_type: "NORMAL",
      auction_stage_type: "AUCTION",
      auction_number: nextNumberAfterAdd
    });
  };
  const handleSubmit = async () => {
    try {
      setLoading(true);
      let response;
      if (isEditMode && groupId) {
        const updatePayload = {
          ...formData,
          prefixed_auction_entries: prefixedAuctionEntries
        };
        response = await api.put(`/v1/admin/groups/${groupId}`, updatePayload, {
          headers: { "Content-Type": "application/json" }
        });
        setAlertConfig({
          visibility: true,
          message: "Group updated successfully",
          type: "success"
        });
      } else {
        const payload = {
          ...formData,
          prefixed_auction_entries: prefixedAuctionEntries
        };
        response = await api.post("/v1/admin/groups/", payload, {
          headers: { "Content-Type": "application/json" }
        });
        setAlertConfig({
          visibility: true,
          message: "Group Added Successfully",
          type: "success"
        });
      }
      setShowConfirm(false);
      setReloadTrigger((prev) => prev + 1);
      if (window.opener && window.opener.refreshGroups) {
        window.opener.refreshGroups();
      }
      if (!isEditMode) {
        setFormData({
          group_name: "",
          group_type: "",
          group_value: "",
          group_install: "",
          group_members: "",
          group_duration: "",
          start_date_type: "fixed",
          start_date: "",
          end_date: "",
          minimum_bid: "",
          maximum_bid: "",
          commission: "",
          incentives: "",
          relationship_manager: "",
          monthly_installment: "",
          weekly_installment: "",
          daily_installment: "",
          reg_fee: "",
          app_display_vacany_seat: "",
          auction_processing_type: "",
          auction_mode: "",
          group_commission: "5"
        });
        setPrefixedAuctionEntries([]);
      }
      setTimeout(() => {
        if (isEditMode) {
          window.close();
        } else {
          window.close();
        }
      }, 2e3);
    } catch (error) {
      console.error("Error saving group:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || (isEditMode ? "Failed to update group" : "Failed to add group"),
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };
  const confirmData = {
    ...formData,
    // Provide a summary of auction entries instead of the full array
    auction_entries_count: prefixedAuctionEntries.length,
    auction_entries_summary: prefixedAuctionEntries.map(
      (e) => `#${e.auction_number} (${e.auction_date || "no date"})`
    ).join(", ")
  };
  const sanitizedConfirmData = Object.entries(confirmData).reduce((acc, [key, value]) => {
    if (value === null || typeof value !== "object") {
      acc[key] = value;
    }
    return acc;
  }, {});
  const handleEditEntry = (index) => {
    const entry = prefixedAuctionEntries[index];
    setCurrentAuctionEntry(entry);
    setEditingIndex(index);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex justify-center p-5", children: [
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
        lineNumber: 690,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("form", { className: "relative w-full max-w-4xl bg-white rounded shadow-lg overflow-hidden", onSubmit: handleReconfirmation, noValidate: true, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "border-b-2 border-blue-900 p-6 mb-6 flex justify-between items-center bg-gray-50", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-blue-900 uppercase tracking-wider", children: "Add Group" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
        lineNumber: 698,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
        lineNumber: 697,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6", children: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Group Name ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 707,
              columnNumber: 104
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 707,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", name: "group_name", value: formData?.group_name, onChange: handleChange, placeholder: "Enter the Group Name", className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 708,
            columnNumber: 29
          }, this),
          errors.group_name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors?.group_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 709,
            columnNumber: 51
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 706,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 705,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Group Type ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 715,
                columnNumber: 104
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 715,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { className: "bg-gray-50 border h-12 border-gray-300 text-gray-900 text-sm rounded-lg w-full", placeholder: "Select Group Type", value: formData?.group_type || void 0, onChange: (value) => handleAntDSelect("group_type", value), children: ["Divident", "Double", "Fixed-Divident", "Fixed-Double"].map((gType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: gType.toLowerCase(), children: gType }, gType, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 717,
              columnNumber: 106
            }, this)) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 716,
              columnNumber: 29
            }, this),
            errors.group_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_type }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 719,
              columnNumber: 51
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 714,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Relationship Manager ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 722,
                columnNumber: 114
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 722,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-12 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                placeholder: "Select RM",
                showSearch: true,
                value: formData?.relationship_manager || void 0,
                onChange: (value) => handleAntDSelect("relationship_manager", value),
                optionFilterProp: "children",
                children: (Array.isArray(employees) ? employees : []).map(
                  (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee?._id, children: [
                    employee?.name,
                    " | ",
                    employee?.phone_number
                  ] }, employee?._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 728,
                    columnNumber: 17
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 723,
                columnNumber: 29
              },
              this
            ),
            errors.relationship_manager && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.relationship_manager }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 733,
              columnNumber: 61
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 721,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 713,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "App Display Vacancy Seat ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 739,
                columnNumber: 118
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 739,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "app_display_vacany_seat", placeholder: "Enter App Display Vacancy Seat", value: formData?.app_display_vacany_seat, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 740,
              columnNumber: 29
            }, this),
            errors.app_display_vacany_seat && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors?.app_display_vacany_seat }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 741,
              columnNumber: 64
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 738,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Group Value ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 744,
                columnNumber: 105
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 744,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "group_value", placeholder: "Enter Group Value", value: formData?.group_value, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 745,
              columnNumber: 29
            }, this),
            errors.group_value && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors?.group_value }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 746,
              columnNumber: 52
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 743,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 737,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Group Installment ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 752,
                columnNumber: 111
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 752,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "group_install", placeholder: "Enter Group Installment", value: formData?.group_install, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 753,
              columnNumber: 29
            }, this),
            errors.group_install && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors?.group_install }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 754,
              columnNumber: 54
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 751,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Group Members ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 757,
                columnNumber: 107
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 757,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "group_members", placeholder: "Enter Group Members", value: formData?.group_members, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 758,
              columnNumber: 29
            }, this),
            errors.group_members && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors?.group_members }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 759,
              columnNumber: 54
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 756,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 750,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Daily Installment ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 763,
                columnNumber: 112
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 763,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "daily_installment", placeholder: "Enter Daily Installment", value: formData?.daily_installment, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 764,
              columnNumber: 29
            }, this),
            errors.daily_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.daily_installment }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 765,
              columnNumber: 58
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 763,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Weekly Installment ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 767,
                columnNumber: 113
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 767,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "weekly_installment", placeholder: "Enter Weekly Installment", value: formData?.weekly_installment, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 767,
              columnNumber: 160
            }, this),
            errors.weekly_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.weekly_installment }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 768,
              columnNumber: 59
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 767,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Monthly Installment ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 770,
                columnNumber: 114
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 770,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "monthly_installment", placeholder: "Enter Monthly Installment", value: formData?.monthly_installment, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 770,
              columnNumber: 161
            }, this),
            errors.monthly_installment && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.monthly_installment }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 771,
              columnNumber: 60
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 770,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 762,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Group Duration ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 777,
                columnNumber: 108
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 777,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "group_duration", placeholder: "Enter Group Duration", value: formData?.group_duration, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 778,
              columnNumber: 29
            }, this),
            errors.group_duration && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_duration }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 779,
              columnNumber: 55
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 776,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Registration Fee ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 782,
                columnNumber: 110
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 782,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", name: "reg_fee", placeholder: "Enter Registration Fee", value: formData?.reg_fee, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 783,
              columnNumber: 29
            }, this),
            errors.reg_fee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.reg_fee }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 784,
              columnNumber: 48
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 781,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 775,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Start date Type ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 791,
              columnNumber: 105
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 791,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-6 mt-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "flex items-center space-x-2 cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV("input", { type: "radio", name: "start_date_type", value: "expected", checked: formData?.start_date_type === "expected", onChange: handleChange, className: "w-4 h-4 text-blue-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 793,
                columnNumber: 91
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: "Expected" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 793,
                columnNumber: 262
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 793,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("label", { className: "flex items-center space-x-2 cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV("input", { type: "radio", name: "start_date_type", value: "fixed", checked: formData?.start_date_type === "fixed", onChange: handleChange, className: "w-4 h-4 text-blue-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 794,
                columnNumber: 91
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: "Fixed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 794,
                columnNumber: 256
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 794,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 792,
            columnNumber: 25
          }, this),
          errors.start_date_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date_type }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 796,
            columnNumber: 52
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 790,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Start Date ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 800,
                columnNumber: 105
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 800,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", name: "start_date", value: formData?.start_date, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 800,
              columnNumber: 152
            }, this),
            errors.start_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 801,
              columnNumber: 51
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 800,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "End Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 803,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", name: "end_date", value: formData?.end_date, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 803,
              columnNumber: 110
            }, this),
            errors.end_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.end_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 804,
              columnNumber: 49
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 803,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 799,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Minimum Bid % ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 809,
                columnNumber: 108
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 809,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", placeholder: "Enter Minimum Bid %", name: "minimum_bid", value: formData?.minimum_bid, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 809,
              columnNumber: 155
            }, this),
            errors.minimum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.minimum_bid }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 810,
              columnNumber: 52
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 809,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Maximum Bid % ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 812,
                columnNumber: 108
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 812,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", min: "0", placeholder: "Enter Maximum Bid %", name: "maximum_bid", value: formData?.maximum_bid, onChange: handleChange, className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 812,
              columnNumber: 155
            }, this),
            errors.maximum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.maximum_bid }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 813,
              columnNumber: 52
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 812,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 808,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Agent Commission %" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 818,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                placeholder: "Enter Agent Commission %",
                name: "commission",
                value: formData?.commission,
                onChange: handleChange,
                className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 818,
                columnNumber: 120
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 818,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Company Commission %" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 820,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                name: "group_commission",
                placeholder: "Enter Company Commission %",
                value: formData?.group_commission,
                onChange: handleChange,
                className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 820,
                columnNumber: 122
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 820,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Employee Incentives %" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 822,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                placeholder: "Enter Employee Incentives %",
                name: "incentives",
                value: formData?.incentives,
                onChange: handleChange,
                className: "bg-gray-50 border border-gray-300 h-12 text-gray-900 text-sm rounded-lg w-full p-2.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 822,
                columnNumber: 123
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 822,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 817,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Collapse, { defaultActiveKey: ["1", "2"], className: "bg-white rounded-xl shadow-md border border-gray-200", expandIconPosition: "end", children: [
          /* @__PURE__ */ jsxDEV(Panel, { header: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800 uppercase", children: "Auction Configuration" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 827,
            columnNumber: 40
          }, this), children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Processing Type" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 830,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(Select, { className: "w-full h-12", placeholder: "Select Type", value: formData?.auction_processing_type || void 0, onChange: (val) => handleAntDSelect("auction_processing_type", val), children: ["SYSTEM", "MANUAL"].map((s) => /* @__PURE__ */ jsxDEV(Select.Option, { value: s, children: s }, s, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 832,
                columnNumber: 74
              }, this)) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 831,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 829,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Mode" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 836,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(Select, { className: "w-full h-12", placeholder: "Select Mode", value: formData?.auction_mode || void 0, onChange: (val) => handleAntDSelect("auction_mode", val), children: ["ONLINE", "OFFLINE"].map((s) => /* @__PURE__ */ jsxDEV(Select.Option, { value: s, children: s }, s, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 838,
                columnNumber: 75
              }, this)) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 837,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 835,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 828,
            columnNumber: 29
          }, this) }, "1", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
            lineNumber: 827,
            columnNumber: 25
          }, this),
          formData?.group_type === "fixed-double" || formData?.group_type === "fixed-divident" ? /* @__PURE__ */ jsxDEV(
            Panel,
            {
              header: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full pr-4", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-blue-900 uppercase", children: "Pre‑scheduled Auction Entries" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                  lineNumber: 847,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(Tag, { color: "blue", children: [
                  prefixedAuctionEntries.length,
                  " Added"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                  lineNumber: 848,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                lineNumber: 846,
                columnNumber: 15
              }, this),
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 border border-blue-100 rounded-lg p-6 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-blue-800 mb-4 uppercase tracking-wide", children: editingIndex !== null ? "Edit Entry" : "Add New Auction Entry" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 854,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: `grid grid-cols-1 md:grid-cols-${currentAuctionEntry.auction_stage_type === "AUCTION" ? 3 : 2} gap-4 mb-4`, children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Auction No." }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 860,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "number",
                          value: editingIndex !== null ? currentAuctionEntry.auction_number : prefixedAuctionEntries.length + 1,
                          onChange: (e) => handleAuctionInputChange("auction_number", e.target.value),
                          className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm font-bold text-blue-900"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 861,
                          columnNumber: 45
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 859,
                      columnNumber: 41
                    }, this),
                    currentAuctionEntry.auction_stage_type === "AUCTION" && /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 875,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: "w-full h-10",
                          value: currentAuctionEntry.auction_type,
                          onChange: (val) => handleAuctionInputChange("auction_type", val),
                          children: [
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "FREE", children: "Free" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                              lineNumber: 881,
                              columnNumber: 53
                            }, this),
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "NORMAL", children: "Normal" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                              lineNumber: 882,
                              columnNumber: 53
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 876,
                          columnNumber: 49
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 874,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Stage" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 887,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: "w-full h-10",
                          value: currentAuctionEntry.auction_stage_type,
                          onChange: (val) => handleAuctionInputChange("auction_stage_type", val),
                          children: [
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "COMMENCEMENT", children: "Commencement" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                              lineNumber: 894,
                              columnNumber: 49
                            }, this),
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "AUCTION", children: "Auction" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                              lineNumber: 895,
                              columnNumber: 49
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 888,
                          columnNumber: 45
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 886,
                      columnNumber: 41
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 858,
                    columnNumber: 37
                  }, this),
                  currentAuctionEntry.auction_stage_type === "AUCTION" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Bid Amount" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 904,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            placeholder: "0.00",
                            min: "0",
                            value: currentAuctionEntry.bid_amount,
                            onChange: (e) => handleAuctionInputChange("bid_amount", e.target.value),
                            className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 905,
                            columnNumber: 53
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 903,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Bid %" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 915,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            placeholder: "0.00",
                            min: "0",
                            disabled: true,
                            value: currentAuctionEntry.bid_percentage,
                            onChange: (e) => handleAuctionInputChange("bid_percentage", e.target.value),
                            className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 916,
                            columnNumber: 53
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 914,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Commission" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 928,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            placeholder: "0.00",
                            min: "0",
                            disabled: true,
                            value: currentAuctionEntry.commission,
                            onChange: (e) => handleAuctionInputChange("commission", e.target.value),
                            className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 929,
                            columnNumber: 53
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 927,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Win Amount" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 940,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            placeholder: "0.00",
                            disabled: true,
                            min: "0",
                            value: currentAuctionEntry.win_amount,
                            onChange: (e) => handleAuctionInputChange("win_amount", e.target.value),
                            className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 941,
                            columnNumber: 53
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 939,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 902,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Dividend" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 955,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            placeholder: "0.00",
                            min: "0",
                            disabled: true,
                            value: currentAuctionEntry.divident,
                            onChange: (e) => handleAuctionInputChange("divident", e.target.value),
                            className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 956,
                            columnNumber: 53
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 954,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Dividend Per Head" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 967,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "text",
                            placeholder: "0.00",
                            disabled: true,
                            value: currentAuctionEntry.divident_head,
                            onChange: (e) => handleAuctionInputChange("divident_head", e.target.value),
                            className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 968,
                            columnNumber: 53
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 966,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Payable" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 978,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            placeholder: "0.00",
                            min: "0",
                            disabled: true,
                            value: currentAuctionEntry.payable,
                            onChange: (e) => handleAuctionInputChange("payable", e.target.value),
                            className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 979,
                            columnNumber: 53
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 977,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 953,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 901,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 mt-5", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Auction Date" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 995,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "date",
                          value: currentAuctionEntry.auction_date,
                          onChange: (e) => handleAuctionInputChange("auction_date", e.target.value),
                          className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 996,
                          columnNumber: 45
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 994,
                      columnNumber: 41
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Next Auction Date" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 1004,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "date",
                          value: currentAuctionEntry.next_date,
                          onChange: (e) => handleAuctionInputChange("next_date", e.target.value),
                          className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 1005,
                          columnNumber: 45
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 1003,
                      columnNumber: 41
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 993,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Auction Time" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 1016,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "time",
                          value: currentAuctionEntry.auction_time,
                          onChange: (e) => handleAuctionInputChange("auction_time", e.target.value),
                          className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 1017,
                          columnNumber: 45
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 1015,
                      columnNumber: 41
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 mb-1", children: "Next Auction Time" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 1025,
                        columnNumber: 45
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "time",
                          value: currentAuctionEntry.next_auction_time,
                          onChange: (e) => handleAuctionInputChange("next_auction_time", e.target.value),
                          className: "w-full bg-white border border-gray-300 h-10 rounded px-3 text-sm"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 1026,
                          columnNumber: 45
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 1024,
                      columnNumber: 41
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 1014,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-end gap-3", children: [
                    editingIndex !== null && /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        onClick: () => {
                          setEditingIndex(null);
                          resetAuctionEntryForm();
                        },
                        className: "h-10 px-6 rounded font-medium",
                        children: "Cancel Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 1037,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        type: "primary",
                        icon: editingIndex !== null ? /* @__PURE__ */ jsxDEV(EditOutlined, {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 1049,
                          columnNumber: 51
                        }, this) : /* @__PURE__ */ jsxDEV(PlusOutlined, {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 1049,
                          columnNumber: 70
                        }, this),
                        onClick: handleAddOrUpdateAuctionEntry,
                        className: "bg-blue-600 hover:bg-blue-700 h-10 px-6 rounded font-medium",
                        children: editingIndex !== null ? "Update Entry" : "Add Entry"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 1047,
                        columnNumber: 41
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 1035,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                  lineNumber: 853,
                  columnNumber: 33
                }, this),
                prefixedAuctionEntries.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-semibold text-gray-500 uppercase mb-3", children: [
                    "Added Entries (",
                    prefixedAuctionEntries.length,
                    ")"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 1060,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "max-h-60 overflow-y-auto space-y-2 pr-1 custom-scrollbar", children: prefixedAuctionEntries.map(
                    (entry, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between bg-white border border-gray-200 p-3 rounded shadow-sm hover:shadow-md transition-shadow group", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 text-blue-800 w-8 h-8 rounded flex items-center justify-center font-bold text-sm", children: [
                          "#",
                          entry.auction_number
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 1065,
                          columnNumber: 57
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-800", children: [
                            entry.auction_date || "No Date",
                            " ",
                            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 font-normal ml-2", children: entry.auction_time }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                              lineNumber: 1069,
                              columnNumber: 142
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 1069,
                            columnNumber: 61
                          }, this),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                            entry.auction_stage_type,
                            " | Payable: ₹",
                            entry.payable || 0
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 1070,
                            columnNumber: 61
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                          lineNumber: 1068,
                          columnNumber: 57
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 1064,
                        columnNumber: 53
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                        /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            type: "text",
                            icon: /* @__PURE__ */ jsxDEV(EditOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                              lineNumber: 1076,
                              columnNumber: 31
                            }, this),
                            onClick: () => handleEditEntry(idx),
                            className: "opacity-0 group-hover:opacity-100 transition-opacity text-blue-600",
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 1074,
                            columnNumber: 57
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Button,
                          {
                            danger: true,
                            type: "text",
                            icon: /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                              lineNumber: 1085,
                              columnNumber: 31
                            }, this),
                            onClick: () => handleRemoveEntry(idx),
                            className: "opacity-0 group-hover:opacity-100 transition-opacity",
                            disabled: entry.auction_stage_type === "COMMENCEMENT",
                            style: entry.auction_stage_type === "COMMENCEMENT" ? { opacity: 0, cursor: "not-allowed" } : {}
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                            lineNumber: 1082,
                            columnNumber: 57
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                        lineNumber: 1073,
                        columnNumber: 53
                      }, this)
                    ] }, idx, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                      lineNumber: 1063,
                      columnNumber: 19
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                    lineNumber: 1061,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
                  lineNumber: 1059,
                  columnNumber: 15
                }, this)
              ]
            },
            "2",
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
              lineNumber: 844,
              columnNumber: 13
            },
            this
          ) : null
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
          lineNumber: 826,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
        lineNumber: 703,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-center p-6 bg-gray-50 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV("button", { type: "submit", disabled: loading, className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-8 py-3 text-center shadow-lg transition-transform transform hover:scale-105 disabled:opacity-50", children: loading ? "Saving..." : isEditMode ? "Update Group" : "Save Group" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
        lineNumber: 1103,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
        lineNumber: 1102,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
      lineNumber: 696,
      columnNumber: 13
    }, this),
    showConfirm && /* @__PURE__ */ jsxDEV(
      ReConfirmModal,
      {
        isOpen: showConfirm,
        title: "Confirm Group Details",
        data: sanitizedConfirmData,
        onCancel: () => setShowConfirm(false),
        onConfirm: handleSubmit
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
        lineNumber: 1110,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx",
    lineNumber: 689,
    columnNumber: 5
  }, this);
};
_s(AddGroupForm, "lcKLz3o4Wf+QL5fDSuQN2RYxmNo=", false, function() {
  return [useLocation];
});
_c = AddGroupForm;
export default AddGroupForm;
var _c;
$RefreshReg$(_c, "AddGroupForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AddGroupForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaXJCWSxTQW1ONEIsVUFuTjVCOzJCQWpyQlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsUUFBUUMsVUFBVUMsS0FBS0MsUUFBUUMsZUFBZTtBQUN2RCxTQUFTQyxjQUFjQyxnQkFBZ0JDLG9CQUFvQjtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxpQkFBaUI7QUFDeEIsU0FBU0MsbUJBQW1CO0FBRTVCLE1BQU0sRUFBRUMsTUFBTSxJQUFJWDtBQUVsQixNQUFNWSxlQUFlQSxDQUFDO0FBQUEsRUFDbEJDLE9BQU87QUFBQSxFQUNQQyxjQUFjO0FBQUEsRUFDZEMsWUFBWSxFQUFFQyxRQUFRLE9BQU87QUFDakMsTUFBTTtBQUFBQyxLQUFBO0FBQ0YsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlyQixTQUFTO0FBQUEsSUFDckNzQixZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxlQUFlO0FBQUEsSUFDZkMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxpQkFBaUI7QUFBQSxJQUNqQkMsWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxhQUFhO0FBQUEsSUFDYkMsYUFBYTtBQUFBLElBQ2JDLFlBQVk7QUFBQSxJQUNaQyxrQkFBa0I7QUFBQSxJQUNsQkMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxxQkFBcUI7QUFBQSxJQUNyQkMsb0JBQW9CO0FBQUEsSUFDcEJDLG1CQUFtQjtBQUFBLElBQ25CQyxzQkFBc0I7QUFBQSxJQUN0QkMseUJBQXlCO0FBQUEsSUFDekJDLHlCQUF5QjtBQUFBLElBQ3pCQyxjQUFjO0FBQUEsRUFDbEIsQ0FBQztBQUVELFFBQU0sQ0FBQ0Msd0JBQXdCQyx5QkFBeUIsSUFBSTdDLFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUM4QyxxQkFBcUJDLHNCQUFzQixJQUFJL0MsU0FBUztBQUFBLElBQzNEZ0QsY0FBYztBQUFBLElBQ2RDLG1CQUFtQjtBQUFBLElBQ25CQyxnQkFBZ0I7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1psQixZQUFZO0FBQUEsSUFDWm1CLFlBQVk7QUFBQSxJQUNaQyxVQUFVO0FBQUEsSUFDVkMsZUFBZTtBQUFBLElBQ2ZDLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsSUFDZEMsV0FBVztBQUFBLElBQ1hDLGNBQWM7QUFBQSxJQUNkQyxvQkFBb0I7QUFBQSxJQUNwQkMsZ0JBQWdCO0FBQUEsRUFDcEIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJOUQsU0FBUyxJQUFJO0FBRXJELFFBQU0sQ0FBQytELGFBQWFDLGNBQWMsSUFBSWhFLFNBQVM7QUFBQSxJQUMzQ2lFLFlBQVk7QUFBQSxJQUNaNUQsU0FBUztBQUFBLElBQ1Q2RCxNQUFNO0FBQUEsRUFDVixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlwRSxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNxRSxXQUFXQyxZQUFZLElBQUl0RSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDdUUsZUFBZUMsZ0JBQWdCLElBQUl4RSxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDeUUsU0FBU0MsVUFBVSxJQUFJMUUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQzJFLGFBQWFDLGNBQWMsSUFBSTVFLFNBQVMsS0FBSztBQUNwRCxRQUFNNkUsV0FBV2pFLFlBQVk7QUFDN0IsUUFBTSxDQUFDa0UsWUFBWUMsYUFBYSxJQUFJL0UsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ2dGLFNBQVNDLFVBQVUsSUFBSWpGLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNrRixjQUFjQyxlQUFlLElBQUluRixTQUFTLEtBQUs7QUFFdEQsUUFBTW9GLHdCQUF3QkEsQ0FBQ0MsWUFBWUEsUUFBUUMsT0FBTyxDQUFBQyxNQUFLQSxFQUFFNUIsdUJBQXVCLFNBQVM7QUFHakcsUUFBTTZCLHlCQUF5QkEsQ0FBQ0gsWUFBWTtBQUN4QyxRQUFJSSxpQkFBaUI7QUFDckIsV0FBT0osUUFBUUssSUFBSSxDQUFBQyxVQUFTO0FBQ3hCLFVBQ0lBLE1BQU1oQyx1QkFBdUIsYUFDN0JnQyxNQUFNaEMsdUJBQXVCLGdCQUMvQjtBQUNFLGVBQU87QUFBQSxVQUNILEdBQUdnQztBQUFBQSxVQUNIL0IsZ0JBQWdCNkI7QUFBQUEsUUFDcEI7QUFBQSxNQUNKO0FBQ0EsYUFBT0U7QUFBQUEsSUFDWCxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1DLGVBQWVBLENBQUNMLE1BQU07QUFDeEIsVUFBTSxFQUFFTSxNQUFNQyxNQUFNLElBQUlQLEVBQUVRO0FBQzFCLFFBQUlDLFdBQVdGO0FBR2YsVUFBTUcsc0JBQXNCO0FBQUEsTUFDeEI7QUFBQSxNQUFlO0FBQUEsTUFBaUI7QUFBQSxNQUFpQjtBQUFBLE1BQ2pEO0FBQUEsTUFBVztBQUFBLE1BQXFCO0FBQUEsTUFBc0I7QUFBQSxNQUN0RDtBQUFBLE1BQWU7QUFBQSxNQUFlO0FBQUEsTUFBYztBQUFBLE1BQW9CO0FBQUEsSUFBWTtBQUloRixVQUFNQyxlQUFlLENBQUMseUJBQXlCO0FBRy9DLFFBQUlELG9CQUFvQkUsU0FBU04sSUFBSSxHQUFHO0FBQ3BDLFVBQUlDLFVBQVUsSUFBSTtBQUNkRSxtQkFBVztBQUFBLE1BQ2YsT0FBTztBQUNILFlBQUlJLE1BQU1DLE9BQU9QLEtBQUs7QUFDdEIsWUFBSSxDQUFDUSxNQUFNRixHQUFHLEtBQUtBLE9BQU8sR0FBRztBQUN6QkoscUJBQVdJLElBQUlHLFNBQVM7QUFBQSxRQUM1QixXQUFXSCxNQUFNLEdBQUc7QUFDaEJKLHFCQUFXO0FBQUEsUUFDZixXQUFXTSxNQUFNRixHQUFHLEdBQUc7QUFDbkJKLHFCQUFXO0FBQUEsUUFDZjtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBQ0EsUUFBSUUsYUFBYUMsU0FBU04sSUFBSSxHQUFHO0FBQzdCLFVBQUlDLFVBQVUsSUFBSTtBQUNkRSxtQkFBVztBQUFBLE1BQ2YsT0FBTztBQUNILFlBQUlJLE1BQU1DLE9BQU9QLEtBQUs7QUFDdEIsWUFBSSxDQUFDUSxNQUFNRixHQUFHLEtBQUtBLE9BQU8sR0FBRztBQUN6QkoscUJBQVdJO0FBQUFBLFFBQ2YsV0FBV0EsTUFBTSxHQUFHO0FBQ2hCSixxQkFBVztBQUFBLFFBQ2YsV0FBV00sTUFBTUYsR0FBRyxHQUFHO0FBQ25CSixxQkFBVztBQUFBLFFBQ2Y7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUVBM0UsZ0JBQVksQ0FBQ21GLGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUNYLElBQUksR0FBR0c7QUFBQUEsSUFDWixFQUFFO0FBQ0Y1QixjQUFVLENBQUNvQyxjQUFjO0FBQUEsTUFDckIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDWCxJQUFJLEdBQUc7QUFBQSxJQUNaLEVBQUU7QUFBQSxFQUNOO0FBRUEsUUFBTVksbUJBQW1CQSxDQUFDQyxPQUFPWixVQUFVO0FBQ3ZDekUsZ0JBQVksQ0FBQ21GLGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUNFLEtBQUssR0FBR1o7QUFBQUEsSUFDYixFQUFFO0FBQ0YxQixjQUFVLENBQUN1QyxnQkFBZ0I7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUNELEtBQUssR0FBRztBQUFBLElBQ2IsRUFBRTtBQUFBLEVBQ047QUFFQSxRQUFNRSwyQkFBMkJBLENBQUNGLE9BQU9aLFVBQVU7QUFDL0MvQywyQkFBdUIsQ0FBQzhELFVBQVU7QUFBQSxNQUM5QixHQUFHQTtBQUFBQSxNQUNILENBQUNILEtBQUssR0FBR1o7QUFBQUEsSUFDYixFQUFFO0FBQUEsRUFDTjtBQUVBLFFBQU1nQix3QkFBd0JBLE1BQU07QUFDaEMsUUFBSSxDQUFDaEUsb0JBQW9CVSxnQkFBZ0IsQ0FBQ1Ysb0JBQW9CRSxjQUFjO0FBQ3hFK0QsWUFBTSw0Q0FBNEM7QUFDbEQ7QUFBQSxJQUNKO0FBRUEsVUFBTUMsV0FBVyxFQUFFLEdBQUdsRSxvQkFBb0I7QUFDMUMsS0FBQyxrQkFBa0IsY0FBYyxjQUFjLGNBQWMsWUFBWSxXQUFXLGdCQUFnQixFQUFFbUUsUUFBUSxDQUFBUCxVQUFTO0FBQ25ILFVBQUlNLFNBQVNOLEtBQUssRUFBR00sVUFBU04sS0FBSyxJQUFLTSxTQUFTTixLQUFLO0FBQUEsSUFDMUQsQ0FBQztBQUVEN0QsOEJBQTBCLENBQUMsR0FBR0Qsd0JBQXdCb0UsUUFBUSxDQUFDO0FBRS9EakUsMkJBQXVCO0FBQUEsTUFDbkIsR0FBR0Q7QUFBQUEsTUFDSEksZ0JBQWdCO0FBQUEsTUFDaEJDLFlBQVk7QUFBQSxNQUNabEIsWUFBWTtBQUFBLE1BQ1ptQixZQUFZO0FBQUEsTUFDWkMsVUFBVTtBQUFBLE1BQ1ZFLFNBQVM7QUFBQSxNQUNUQyxjQUFjO0FBQUEsTUFDZEksZ0JBQWdCaEIsdUJBQXVCc0UsU0FBUztBQUFBLE1BQ2hEdkQsb0JBQW9CO0FBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNd0Qsb0JBQW9CQSxDQUFDQyxVQUFVO0FBQ2pDLFVBQU1DLGdCQUFnQnpFLHVCQUF1QndFLEtBQUs7QUFDbEQsUUFBSUMsY0FBYzFELHVCQUF1QixnQkFBZ0I7QUFDckR0RCxjQUFRaUgsUUFBUSx3REFBd0Q7QUFDeEU7QUFBQSxJQUNKO0FBQ0EsVUFBTUMsY0FBYzNFLHVCQUF1QjBDLE9BQU8sQ0FBQ2tDLEdBQUdDLE1BQU1BLE1BQU1MLEtBQUs7QUFHdkUsVUFBTU0saUJBQWlCbEMsdUJBQXVCK0IsV0FBVztBQUN6RDFFLDhCQUEwQjZFLGNBQWM7QUFHeEMsUUFBSTdELGlCQUFpQnVELE9BQU87QUFDeEJ0RCxzQkFBZ0IsSUFBSTtBQUNwQjZELDRCQUFzQjtBQUFBLElBQzFCLFdBQVc5RCxpQkFBaUIsUUFBUUEsZUFBZXVELE9BQU87QUFFdER0RCxzQkFBZ0JELGVBQWUsQ0FBQztBQUFBLElBQ3BDO0FBQUEsRUFDSjtBQUVBLFFBQU0rRCx1QkFBdUJBLENBQUNyQyxNQUFNO0FBQ2hDQSxNQUFFc0MsZUFBZTtBQUNqQixVQUFNQyxVQUFVQyxhQUFhLFVBQVU7QUFDdkMsUUFBSSxDQUFDRCxTQUFTO0FBQ1Z6SCxjQUFRaUgsUUFBUSxxQ0FBcUM7QUFDckQ7QUFBQSxJQUNKO0FBQ0ExQyxtQkFBZSxJQUFJO0FBQUEsRUFDdkI7QUFFQSxRQUFNb0Qsb0JBQW9CLE9BQU9DLE9BQU87QUFDcEM5QyxvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0EsWUFBTStDLFdBQVcsTUFBTXpILElBQUkwSCxJQUFJLG9CQUFvQkYsRUFBRSxFQUFFO0FBQ3ZELFlBQU1HLFFBQVFGLFNBQVNHLE1BQU1BO0FBRzdCLFlBQU1DLHFCQUFxQkYsTUFBTXZHLFlBQVkwRyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3pELFlBQU1DLG1CQUFtQkosTUFBTXRHLFVBQVV5RyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRXJEbEgsa0JBQVk7QUFBQSxRQUNSQyxZQUFZOEcsTUFBTTlHLGNBQWM7QUFBQSxRQUNoQ0MsWUFBWTZHLE1BQU03RyxjQUFjO0FBQUEsUUFDaENDLGFBQWE0RyxNQUFNNUcsZUFBZTtBQUFBLFFBQ2xDQyxlQUFlMkcsTUFBTTNHLGlCQUFpQjtBQUFBLFFBQ3RDQyxlQUFlMEcsTUFBTTFHLGlCQUFpQjtBQUFBLFFBQ3RDQyxnQkFBZ0J5RyxNQUFNekcsa0JBQWtCO0FBQUEsUUFDeENDLGlCQUFpQndHLE1BQU14RyxtQkFBbUI7QUFBQSxRQUMxQ0MsWUFBWXlHLHNCQUFzQjtBQUFBLFFBQ2xDeEcsVUFBVTBHLG9CQUFvQjtBQUFBLFFBQzlCekcsYUFBYXFHLE1BQU1yRyxlQUFlO0FBQUEsUUFDbENDLGFBQWFvRyxNQUFNcEcsZUFBZTtBQUFBLFFBQ2xDQyxZQUFZbUcsTUFBTW5HLGNBQWM7QUFBQSxRQUNoQ0Msa0JBQWtCa0csTUFBTWxHLG9CQUFvQjtBQUFBLFFBQzVDQyxZQUFZaUcsTUFBTWpHLGNBQWM7QUFBQSxRQUNoQ0MsU0FBU2dHLE1BQU1oRyxXQUFXO0FBQUEsUUFDMUJDLHFCQUFxQitGLE1BQU0vRix1QkFBdUI7QUFBQSxRQUNsREMsb0JBQW9COEYsTUFBTTlGLHNCQUFzQjtBQUFBLFFBQ2hEQyxtQkFBbUI2RixNQUFNN0YscUJBQXFCO0FBQUEsUUFDOUNDLHNCQUFzQixPQUFPNEYsTUFBTTVGLHlCQUF5QixXQUN0RDRGLE1BQU01RixzQkFBc0JpRyxNQUM1QkwsTUFBTTVGLHdCQUF3QjtBQUFBLFFBQ3BDQyx5QkFBeUIyRixNQUFNM0YsMkJBQTJCO0FBQUEsUUFDMURDLHlCQUF5QjBGLE1BQU0xRiwyQkFBMkI7QUFBQSxRQUMxREMsY0FBY3lGLE1BQU16RixnQkFBZ0I7QUFBQSxNQUN4QyxDQUFDO0FBR0QsVUFBSXlGLE1BQU1NLDRCQUE0QkMsTUFBTUMsUUFBUVIsTUFBTU0sd0JBQXdCLEdBQUc7QUFFakYsY0FBTUcsU0FBUyxDQUFDLEdBQUdULE1BQU1NLHdCQUF3QixFQUFFSSxLQUFLLENBQUNDLEdBQUdDLE1BQU07QUFDOUQsY0FBSUQsRUFBRXBGLHVCQUF1QixlQUFnQixRQUFPO0FBQ3BELGNBQUlxRixFQUFFckYsdUJBQXVCLGVBQWdCLFFBQU87QUFDcEQsaUJBQU87QUFBQSxRQUNYLENBQUM7QUFDRCxjQUFNc0YsYUFBYXpELHVCQUF1QnFELE1BQU07QUFDaERoRyxrQ0FBMEJvRyxVQUFVO0FBQUEsTUFDeEMsT0FBTztBQUNIcEcsa0NBQTBCLEVBQUU7QUFBQSxNQUNoQztBQUFBLElBQ0osU0FBU3FHLE9BQU87QUFDWkMsY0FBUUQsTUFBTSxrQ0FBa0NBLEtBQUs7QUFDckRsRixxQkFBZTtBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaNUQsU0FBUztBQUFBLFFBQ1Q2RCxNQUFNO0FBQUEsTUFDVixDQUFDO0FBQUEsSUFDTCxVQUFDO0FBQ0dpQixzQkFBZ0IsS0FBSztBQUFBLElBQ3pCO0FBQUEsRUFDSjtBQUdBcEY7QUFBQUEsSUFBVSxNQUFNO0FBQ1osWUFBTXFKLGFBQWFDLFdBQVdqSSxTQUFTSSxXQUFXLEtBQUs7QUFDdkQsWUFBTThILHFCQUFxQkQsV0FBV2pJLFNBQVNjLGdCQUFnQixLQUFLO0FBQ3BFLFlBQU1xSCxlQUFlRixXQUFXakksU0FBU00sYUFBYSxLQUFLO0FBQzNELFlBQU04SCxlQUFlSCxXQUFXakksU0FBU0ssYUFBYSxLQUFLO0FBRzNELFVBQUlnSSxZQUFZSixXQUFXdkcsb0JBQW9CSyxVQUFVLEtBQUs7QUFDOUQsVUFBSXVHLGFBQWFMLFdBQVd2RyxvQkFBb0JJLGNBQWMsS0FBSztBQUVuRSxVQUFJdUcsY0FBYyxLQUFLQyxlQUFlLEdBQUc7QUFDckMsWUFBSTVHLG9CQUFvQmIsZUFBZSxJQUFJO0FBQ3ZDYyxpQ0FBdUIsQ0FBQThELFVBQVM7QUFBQSxZQUM1QixHQUFHQTtBQUFBQSxZQUNINUUsWUFBWTtBQUFBLFlBQ1ptQixZQUFZO0FBQUEsWUFDWkMsVUFBVTtBQUFBLFlBQ1ZDLGVBQWU7QUFBQSxZQUNmQyxTQUFTO0FBQUEsVUFDYixFQUFFO0FBQUEsUUFDTjtBQUNBO0FBQUEsTUFDSjtBQUVBLFVBQUk2RixlQUFlLEVBQUc7QUFDdEIsVUFBSU8saUJBQWlCRjtBQUNyQixVQUFJRyxrQkFBa0JGO0FBQ3RCLFVBQUlELFlBQVksS0FBS0MsZUFBZSxHQUFHO0FBQ25DRSwwQkFBbUJILFlBQVlMLGFBQWM7QUFBQSxNQUNqRCxXQUFXTSxhQUFhLEtBQUtELGNBQWMsR0FBRztBQUMxQ0UseUJBQWtCRCxhQUFhLE1BQU9OO0FBQUFBLE1BQzFDLE9BQU87QUFFSFEsMEJBQW1CSCxZQUFZTCxhQUFjO0FBQUEsTUFDakQ7QUFDQSxVQUFJTSxhQUFhLEtBQUtELGNBQWMsR0FBRztBQUNuQ0Esb0JBQWFDLGFBQWEsTUFBT047QUFDakNyRywrQkFBdUIsQ0FBQThELFVBQVM7QUFBQSxVQUM1QixHQUFHQTtBQUFBQSxVQUNIMUQsWUFBWXNHLFVBQVVJLFFBQVEsQ0FBQztBQUFBLFFBQ25DLEVBQUU7QUFDRjtBQUFBLE1BQ0o7QUFDQSxZQUFNNUgsYUFBY21ILGFBQWFFLHFCQUFzQjtBQUN2RCxZQUFNUSxZQUFZVixhQUFhSztBQUMvQixZQUFNcEcsV0FBV29HLFlBQVl4SDtBQUM3QixZQUFNOEgsZUFBZVIsZUFBZSxJQUFJbEcsV0FBV2tHLGVBQWU7QUFDbEUsWUFBTWhHLFVBQVVpRyxlQUFlTztBQUUvQmhILDZCQUF1QixDQUFBOEQsVUFBUztBQUFBLFFBQzVCLEdBQUdBO0FBQUFBLFFBQ0g1RSxZQUFZQSxXQUFXNEgsUUFBUSxDQUFDO0FBQUEsUUFDaEN6RyxZQUFZMEcsVUFBVUQsUUFBUSxDQUFDO0FBQUEsUUFDL0J4RyxVQUFVQSxTQUFTd0csUUFBUSxDQUFDO0FBQUEsUUFDNUIzRyxnQkFBZ0IwRyxnQkFBZ0JDLFFBQVEsQ0FBQztBQUFBLFFBQ3pDdkcsZUFBZXlHLGFBQWFGLFFBQVEsQ0FBQztBQUFBLFFBQ3JDdEcsU0FBU0EsUUFBUXNHLFFBQVEsQ0FBQztBQUFBLE1BQzlCLEVBQUU7QUFBQSxJQUNOO0FBQUEsSUFBRztBQUFBLE1BQ0MvRyxvQkFBb0JLO0FBQUFBLE1BQ3BCTCxvQkFBb0JJO0FBQUFBLE1BQ3BCOUIsU0FBU0k7QUFBQUEsTUFDVEosU0FBU2M7QUFBQUEsTUFDVGQsU0FBU007QUFBQUEsTUFDVE4sU0FBU0s7QUFBQUEsSUFBYTtBQUFBLEVBQ3pCO0FBR0QxQixZQUFVLE1BQU07QUFDWixRQUFJK0Msb0JBQW9CVSxjQUFjO0FBQ2xDLFlBQU13RyxPQUFPLElBQUlDLEtBQUtuSCxvQkFBb0JVLFlBQVk7QUFDdEQsVUFBSSxDQUFDOEMsTUFBTTBELEtBQUtFLFFBQVEsQ0FBQyxHQUFHO0FBQ3hCRixhQUFLRyxRQUFRSCxLQUFLSSxRQUFRLElBQUksRUFBRTtBQUNoQyxjQUFNQyxXQUFXTCxLQUFLTSxZQUFZLEVBQUUvQixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ2hEeEYsK0JBQXVCLENBQUE4RCxVQUFTO0FBQUEsVUFDNUIsR0FBR0E7QUFBQUEsVUFDSHBELFdBQVc0RztBQUFBQSxRQUNmLEVBQUU7QUFBQSxNQUNOO0FBQUEsSUFDSjtBQUFBLEVBQ0osR0FBRyxDQUFDdkgsb0JBQW9CVSxZQUFZLENBQUM7QUFHckN6RCxZQUFVLE1BQU07QUFDWixRQUFJK0Msb0JBQW9CRSxjQUFjO0FBQ2xDRCw2QkFBdUIsQ0FBQThELFVBQVM7QUFBQSxRQUM1QixHQUFHQTtBQUFBQSxRQUNINUQsbUJBQW1CNEQsS0FBSzdEO0FBQUFBLE1BQzVCLEVBQUU7QUFBQSxJQUNOO0FBQUEsRUFDSixHQUFHLENBQUNGLG9CQUFvQkUsWUFBWSxDQUFDO0FBRXJDakQsWUFBVSxNQUFNO0FBQ1osVUFBTXdLLFNBQVMsSUFBSUMsZ0JBQWdCM0YsU0FBUzRGLE1BQU07QUFDbEQsVUFBTUMsWUFBWUgsT0FBT3BDLElBQUksTUFBTTtBQUNuQyxVQUFNd0MsVUFBVUosT0FBT3BDLElBQUksU0FBUztBQUVwQyxRQUFJdUMsY0FBYyxVQUFVQyxTQUFTO0FBQ2pDNUYsb0JBQWMsSUFBSTtBQUNsQkUsaUJBQVcwRixPQUFPO0FBQ2xCM0Msd0JBQWtCMkMsT0FBTztBQUN6QmhELDRCQUFzQjtBQUFBLElBQzFCO0FBQUEsRUFDSixHQUFHLENBQUM5QyxTQUFTNEYsTUFBTSxDQUFDO0FBRXBCMUssWUFBVSxNQUFNO0FBQ1osbUJBQWU2SyxlQUFlO0FBQzFCLFVBQUk7QUFDQSxjQUFNMUMsV0FBVyxNQUFNekgsSUFBSTBILElBQUksV0FBVztBQUMxQyxjQUFNMEMsZUFBZTNDLFNBQVNHLE1BQU15QztBQUNwQ3hHLHFCQUFhdUcsZUFBZUEsZUFBZSxFQUFFO0FBQUEsTUFDakQsU0FBUzNCLE9BQU87QUFDWjVFLHFCQUFhLEVBQUU7QUFDZjZFLGdCQUFRNEIsSUFBSSwwQkFBMEI7QUFBQSxNQUMxQztBQUFBLElBQ0o7QUFDQUgsaUJBQWE7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNN0MsZUFBZUEsQ0FBQzdELFNBQVM7QUFDM0IsVUFBTThHLFlBQVksQ0FBQztBQUNuQixVQUFNM0MsT0FBT2pIO0FBRWIsUUFBSSxDQUFDaUgsS0FBSy9HLFlBQVkySixLQUFLLEVBQUdELFdBQVUxSixhQUFhO0FBQ3JELFFBQUksQ0FBQytHLEtBQUs5RyxXQUFZeUosV0FBVXpKLGFBQWE7QUFDN0MsUUFBSSxDQUFDOEcsS0FBSzdHLFlBQWF3SixXQUFVeEosY0FBYztBQUMvQyxRQUFJLENBQUM2RyxLQUFLNUcsY0FBZXVKLFdBQVV2SixnQkFBZ0I7QUFDbkQsUUFBSSxDQUFDNEcsS0FBSzNHLGNBQWVzSixXQUFVdEosZ0JBQWdCO0FBQ25ELFFBQUksQ0FBQzJHLEtBQUs3RixxQkFBc0J3SSxXQUFVeEksdUJBQXVCO0FBQ2pFLFFBQUksQ0FBQzZGLEtBQUtoRyxvQkFBcUIySSxXQUFVM0ksc0JBQXNCO0FBQy9ELFFBQUksQ0FBQ2dHLEtBQUsvRixtQkFBb0IwSSxXQUFVMUkscUJBQXFCO0FBQzdELFFBQUksQ0FBQytGLEtBQUs5RixrQkFBbUJ5SSxXQUFVekksb0JBQW9CO0FBQzNELFFBQUksQ0FBQzhGLEtBQUsxRyxlQUFnQnFKLFdBQVVySixpQkFBaUI7QUFDckQsUUFBSSxDQUFDMEcsS0FBS2pHLFFBQVM0SSxXQUFVNUksVUFBVTtBQUN2QyxRQUFJLENBQUNpRyxLQUFLeEcsV0FBWW1KLFdBQVVuSixhQUFhO0FBQzdDLFFBQUksQ0FBQ3dHLEtBQUt2RyxTQUFVa0osV0FBVWxKLFdBQVc7QUFDekMsUUFBSSxDQUFDdUcsS0FBSzVGLHdCQUF5QnVJLFdBQVV2SSwwQkFBMEI7QUFDdkUsUUFBSSxDQUFDNEYsS0FBS3pHLGdCQUFpQm9KLFdBQVVwSixrQkFBa0I7QUFDdkQsUUFBSVIsU0FBU1UsWUFBWSxDQUFDdUcsS0FBS3ZHLFNBQVVrSixXQUFVbEosV0FBVztBQUFBLGFBQ3JEVixTQUFTVSxZQUFZLElBQUltSSxLQUFLNUIsS0FBS3ZHLFFBQVEsSUFBSSxJQUFJbUksS0FBSzVCLEtBQUt4RyxVQUFVO0FBQzVFbUosZ0JBQVVsSixXQUFXO0FBQ3pCLFFBQUksQ0FBQ3VHLEtBQUt0RyxZQUFhaUosV0FBVWpKLGNBQWM7QUFDL0MsUUFBSSxDQUFDc0csS0FBS3JHLFlBQWFnSixXQUFVaEosY0FBYztBQUFBLGFBQ3RDcUgsV0FBV2hCLEtBQUtyRyxXQUFXLElBQUlxSCxXQUFXaEIsS0FBS3RHLFdBQVc7QUFDL0RpSixnQkFBVWhKLGNBQWM7QUFFNUJvQyxjQUFVNEcsU0FBUztBQUNuQixXQUFPRSxPQUFPQyxLQUFLSCxTQUFTLEVBQUU5RCxXQUFXO0FBQUEsRUFDN0M7QUFnREEsUUFBTVMsd0JBQXdCQSxNQUFNO0FBQ2hDLFVBQU15RCxZQUFZeEksdUJBQXVCc0UsU0FBUyxJQUM1Q21FLEtBQUtDLElBQUksR0FBRzFJLHVCQUF1QjhDLElBQUksQ0FBQUgsTUFBS2MsT0FBT2QsRUFBRTNCLGNBQWMsS0FBSyxDQUFDLENBQUMsSUFDMUU7QUFDTmIsMkJBQXVCO0FBQUEsTUFDbkJDLGNBQWM7QUFBQSxNQUNkQyxtQkFBbUI7QUFBQSxNQUNuQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLFlBQVk7QUFBQSxNQUNabEIsWUFBWTtBQUFBLE1BQ1ptQixZQUFZO0FBQUEsTUFDWkMsVUFBVTtBQUFBLE1BQ1ZDLGVBQWU7QUFBQSxNQUNmQyxTQUFTO0FBQUEsTUFDVEMsY0FBYztBQUFBLE1BQ2RDLFdBQVc7QUFBQSxNQUNYQyxjQUFjO0FBQUEsTUFDZEMsb0JBQW9CO0FBQUEsTUFDcEJDLGdCQUFnQndILFlBQVk7QUFBQSxJQUNoQyxDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1HLGdDQUFnQ0EsTUFBTTtBQUN4QyxRQUNJLENBQUN6SSxvQkFBb0JVLGdCQUNyQixDQUFDVixvQkFBb0JFLGNBQ3ZCO0FBQ0UzQyxjQUFRaUgsUUFBUSx5Q0FBeUM7QUFDekQ7QUFBQSxJQUNKO0FBRUEsVUFBTWtFLHVCQUF1QjVJLHVCQUF1QjZJO0FBQUFBLE1BQ2hELENBQUM5RixVQUFVQSxNQUFNaEMsdUJBQXVCO0FBQUEsSUFDNUM7QUFFQSxRQUNJYixvQkFBb0JhLHVCQUF1QixrQkFDM0M2SCx3QkFDQTNILGlCQUFpQixNQUNuQjtBQUNFeEQsY0FBUWlILFFBQVEsbURBQW1EO0FBQ25FO0FBQUEsSUFDSjtBQUVBLFVBQU1OLFdBQVcsRUFBRSxHQUFHbEUsb0JBQW9CO0FBRzFDLFFBQUllLGlCQUFpQixNQUFNO0FBQ3ZCLFlBQU0wRCxjQUFjLENBQUMsR0FBRzNFLHNCQUFzQjtBQUU5QzJFLGtCQUFZMUQsWUFBWSxJQUFJO0FBQUEsUUFDeEIsR0FBR21EO0FBQUFBLFFBQ0hwRCxnQkFDSW9ELFNBQVNyRCx1QkFBdUIsaUJBQzFCZix1QkFBdUJpQixZQUFZLEVBQUVELGlCQUNyQ29ELFNBQVNwRDtBQUFBQSxNQUN2QjtBQUVBZixnQ0FBMEIwRSxXQUFXO0FBQ3JDekQsc0JBQWdCLElBQUk7QUFFcEJ6RCxjQUFRcUwsUUFBUSw0QkFBNEI7QUFBQSxJQUNoRCxPQUdLO0FBQ0QsWUFBTUMsYUFBYS9JLHVCQUF1QnNFLFNBQVM7QUFFbkQsWUFBTTBFLGFBQWE7QUFBQSxRQUNmLEdBQUc1RTtBQUFBQSxRQUNIcEQsZ0JBQWdCK0g7QUFBQUEsTUFDcEI7QUFFQTlJO0FBQUFBLFFBQTBCO0FBQUEsVUFDdEIsR0FBR0Q7QUFBQUEsVUFDSGdKO0FBQUFBLFFBQVU7QUFBQSxNQUNiO0FBRUR2TCxjQUFRcUwsUUFBUSwwQkFBMEI7QUFBQSxJQUM5QztBQUdBLFVBQU1HLHFCQUFxQmpKLHVCQUF1QnNFLFNBQVM7QUFFM0RuRSwyQkFBdUI7QUFBQSxNQUNuQkMsY0FBYztBQUFBLE1BQ2RDLG1CQUFtQjtBQUFBLE1BQ25CQyxnQkFBZ0I7QUFBQSxNQUNoQkMsWUFBWTtBQUFBLE1BQ1psQixZQUFZO0FBQUEsTUFDWm1CLFlBQVk7QUFBQSxNQUNaQyxVQUFVO0FBQUEsTUFDVkMsZUFBZTtBQUFBLE1BQ2ZDLFNBQVM7QUFBQSxNQUNUQyxjQUFjO0FBQUEsTUFDZEMsV0FBVztBQUFBLE1BQ1hDLGNBQWM7QUFBQSxNQUNkQyxvQkFBb0I7QUFBQSxNQUNwQkMsZ0JBQWdCaUk7QUFBQUEsSUFDcEIsQ0FBQztBQUFBLEVBQ0w7QUFHQSxRQUFNQyxlQUFlLFlBQVk7QUFDN0IsUUFBSTtBQUNBcEgsaUJBQVcsSUFBSTtBQUNmLFVBQUl3RDtBQUNKLFVBQUlwRCxjQUFjRSxTQUFTO0FBRXZCLGNBQU0rRyxnQkFBZ0I7QUFBQSxVQUNsQixHQUFHM0s7QUFBQUEsVUFDSHNILDBCQUEwQjlGO0FBQUFBLFFBQzlCO0FBQ0FzRixtQkFBVyxNQUFNekgsSUFBSXVMLElBQUksb0JBQW9CaEgsT0FBTyxJQUFJK0csZUFBZTtBQUFBLFVBQ25FRSxTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtBQUFBLFFBQ2xELENBQUM7QUFDRGpJLHVCQUFlO0FBQUEsVUFDWEMsWUFBWTtBQUFBLFVBQ1o1RCxTQUFTO0FBQUEsVUFDVDZELE1BQU07QUFBQSxRQUNWLENBQUM7QUFBQSxNQUNMLE9BQU87QUFFSCxjQUFNZ0ksVUFBVTtBQUFBLFVBQ1osR0FBRzlLO0FBQUFBLFVBQ0hzSCwwQkFBMEI5RjtBQUFBQSxRQUM5QjtBQUNBc0YsbUJBQVcsTUFBTXpILElBQUkwTCxLQUFLLHFCQUFxQkQsU0FBUztBQUFBLFVBQ3BERCxTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtBQUFBLFFBQ2xELENBQUM7QUFDRGpJLHVCQUFlO0FBQUEsVUFDWEMsWUFBWTtBQUFBLFVBQ1o1RCxTQUFTO0FBQUEsVUFDVDZELE1BQU07QUFBQSxRQUNWLENBQUM7QUFBQSxNQUNMO0FBRUFVLHFCQUFlLEtBQUs7QUFDcEJKLHVCQUFpQixDQUFDcUMsU0FBU0EsT0FBTyxDQUFDO0FBR25DLFVBQUl1RixPQUFPQyxVQUFVRCxPQUFPQyxPQUFPQyxlQUFlO0FBQzlDRixlQUFPQyxPQUFPQyxjQUFjO0FBQUEsTUFDaEM7QUFHQSxVQUFJLENBQUN4SCxZQUFZO0FBQ2J6RCxvQkFBWTtBQUFBLFVBQ1JDLFlBQVk7QUFBQSxVQUFJQyxZQUFZO0FBQUEsVUFBSUMsYUFBYTtBQUFBLFVBQUlDLGVBQWU7QUFBQSxVQUNoRUMsZUFBZTtBQUFBLFVBQUlDLGdCQUFnQjtBQUFBLFVBQUlDLGlCQUFpQjtBQUFBLFVBQ3hEQyxZQUFZO0FBQUEsVUFBSUMsVUFBVTtBQUFBLFVBQUlDLGFBQWE7QUFBQSxVQUFJQyxhQUFhO0FBQUEsVUFDNURDLFlBQVk7QUFBQSxVQUFJRSxZQUFZO0FBQUEsVUFBSUssc0JBQXNCO0FBQUEsVUFDdERILHFCQUFxQjtBQUFBLFVBQUlDLG9CQUFvQjtBQUFBLFVBQUlDLG1CQUFtQjtBQUFBLFVBQ3BFSCxTQUFTO0FBQUEsVUFBSUsseUJBQXlCO0FBQUEsVUFBSUMseUJBQXlCO0FBQUEsVUFDbkVDLGNBQWM7QUFBQSxVQUFJVCxrQkFBa0I7QUFBQSxRQUN4QyxDQUFDO0FBQ0RXLGtDQUEwQixFQUFFO0FBQUEsTUFDaEM7QUFFQTBKLGlCQUFXLE1BQU07QUFDYixZQUFJekgsWUFBWTtBQUNac0gsaUJBQU9JLE1BQU07QUFBQSxRQUNqQixPQUFPO0FBQ0hKLGlCQUFPSSxNQUFNO0FBQUEsUUFDakI7QUFBQSxNQUNKLEdBQUcsR0FBSTtBQUFBLElBQ1gsU0FBU3RELE9BQU87QUFDWkMsY0FBUUQsTUFBTSx1QkFBdUJBLEtBQUs7QUFDMUNsRixxQkFBZTtBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaNUQsU0FBUzZJLE1BQU1oQixVQUFVRyxNQUFNaEksWUFBWXlFLGFBQWEsMkJBQTJCO0FBQUEsUUFDbkZaLE1BQU07QUFBQSxNQUNWLENBQUM7QUFBQSxJQUNMLFVBQUM7QUFDR1EsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUlBLFFBQU0rSCxjQUFjO0FBQUEsSUFDaEIsR0FBR3JMO0FBQUFBO0FBQUFBLElBRUhzTCx1QkFBdUI5Six1QkFBdUJzRTtBQUFBQSxJQUM5Q3lGLHlCQUF5Qi9KLHVCQUF1QjhDO0FBQUFBLE1BQUksQ0FBQUgsTUFDaEQsSUFBSUEsRUFBRTNCLGNBQWMsS0FBSzJCLEVBQUUvQixnQkFBZ0IsU0FBUztBQUFBLElBQ3hELEVBQUVvSixLQUFLLElBQUk7QUFBQSxFQUNmO0FBR0EsUUFBTUMsdUJBQXVCM0IsT0FBTzdGLFFBQVFvSCxXQUFXLEVBQUVLLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxLQUFLbEgsS0FBSyxNQUFNO0FBQ25GLFFBQUlBLFVBQVUsUUFBUSxPQUFPQSxVQUFVLFVBQVU7QUFDN0NpSCxVQUFJQyxHQUFHLElBQUlsSDtBQUFBQSxJQUNmO0FBQ0EsV0FBT2lIO0FBQUFBLEVBQ1gsR0FBRyxDQUFDLENBQUM7QUFFTCxRQUFNRSxrQkFBa0JBLENBQUM3RixVQUFVO0FBQy9CLFVBQU16QixRQUFRL0MsdUJBQXVCd0UsS0FBSztBQUMxQ3JFLDJCQUF1QjRDLEtBQUs7QUFDNUI3QixvQkFBZ0JzRCxLQUFLO0FBQUEsRUFDekI7QUFFQSxTQUNJLHVCQUFDLFNBQUksV0FBVSxrQ0FDWDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxNQUFNckQsWUFBWUc7QUFBQUEsUUFDbEIsV0FBV0gsWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWTFEO0FBQUFBLFFBQ3JCLFNBQVMsTUFBTTJELGVBQWUsQ0FBQTZDLFVBQVMsRUFBRSxHQUFHQSxNQUFNNUMsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLE1BSjFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUk0RTtBQUFBLElBRTVFLHVCQUFDLFVBQUssV0FBVSx3RUFBdUUsVUFBVTJELHNCQUFzQixZQUFVLE1BQzdIO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9GQUNYLGlDQUFDLFFBQUcsV0FBVSw2REFBNEQseUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUVYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUNYLGlDQUFDLFNBQ0c7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxZQUFXLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrSDtBQUFBLFVBQ2xILHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssY0FBYSxPQUFPeEcsVUFBVUUsWUFBWSxVQUFVc0UsY0FBYyxhQUFZLHdCQUF1QixXQUFXLHFDQUFxQzNFLFVBQVVDLE1BQU0sOEZBQTdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdSO0FBQUEsVUFDdlJpRCxPQUFPN0MsY0FBYyx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCNkMsa0JBQVE3QyxjQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLGFBSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsaUNBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGNBQVcsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSDtBQUFBLFlBQ2xILHVCQUFDLFVBQU8sV0FBVSxrRkFBaUYsYUFBWSxxQkFBb0IsT0FBT0YsVUFBVUcsY0FBYzJMLFFBQVcsVUFBVSxDQUFDcEgsVUFBVVcsaUJBQWlCLGNBQWNYLEtBQUssR0FDak8sV0FBQyxZQUFZLFVBQVUsa0JBQWtCLGNBQWMsRUFBRUosSUFBSSxDQUFDeUgsVUFBVyx1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsTUFBTUMsWUFBWSxHQUFJRCxtQkFBcENBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThELENBQWlCLEtBRDdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDaEosT0FBTzVDLGNBQWMsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjRDLGlCQUFPNUMsY0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxlQUx0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FBcUIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0SDtBQUFBLFlBQzVIO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQU8sV0FBVTtBQUFBLGdCQUNkLGFBQVk7QUFBQSxnQkFBWSxZQUFVO0FBQUEsZ0JBQUMsT0FBT0gsVUFBVW9CLHdCQUF3QjBLO0FBQUFBLGdCQUM1RSxVQUFVLENBQUNwSCxVQUFVVyxpQkFBaUIsd0JBQXdCWCxLQUFLO0FBQUEsZ0JBQ25FLGtCQUFpQjtBQUFBLGdCQUNmNkMsaUJBQU1DLFFBQVF2RSxTQUFTLElBQUlBLFlBQVksSUFBSXFCO0FBQUFBLGtCQUFJLENBQUNvRixhQUM5Qyx1QkFBQyxPQUFPLFFBQVAsRUFBa0MsT0FBT0EsVUFBVXJDLEtBQy9DcUM7QUFBQUEsOEJBQVVqRjtBQUFBQSxvQkFBSztBQUFBLG9CQUFJaUYsVUFBVXVDO0FBQUFBLHVCQURkdkMsVUFBVXJDLEtBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDSDtBQUFBO0FBQUEsY0FSTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFlBQ0N0RSxPQUFPM0Isd0JBQXdCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkIyQixpQkFBTzNCLHdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLGVBWjFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSxpQ0FBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FBeUIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnSTtBQUFBLFlBQ2hJLHVCQUFDLFdBQU0sTUFBSyxVQUFTLEtBQUksS0FBSSxNQUFLLDJCQUEwQixhQUFZLGtDQUFpQyxPQUFPcEIsVUFBVXFCLHlCQUF5QixVQUFVbUQsY0FBYyxXQUFVLDBGQUFyTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyUTtBQUFBLFlBQzFRekIsT0FBTzFCLDJCQUEyQix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCMEIsa0JBQVExQiwyQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxlQUhqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FBWSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1IO0FBQUEsWUFDbkgsdUJBQUMsV0FBTSxNQUFLLFVBQVMsS0FBSSxLQUFJLE1BQUssZUFBYyxhQUFZLHFCQUFvQixPQUFPckIsVUFBVUksYUFBYSxVQUFVb0UsY0FBYyxXQUFVLDBGQUFoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzTztBQUFBLFlBQ3JPekIsT0FBTzNDLGVBQWUsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjJDLGtCQUFRM0MsZUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUh6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLGlDQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxjQUFrQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlIO0FBQUEsWUFDekgsdUJBQUMsV0FBTSxNQUFLLFVBQVMsS0FBSSxLQUFJLE1BQUssaUJBQWdCLGFBQVksMkJBQTBCLE9BQU9KLFVBQVVLLGVBQWUsVUFBVW1FLGNBQWMsV0FBVSwwRkFBMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ1A7QUFBQSxZQUMvT3pCLE9BQU8xQyxpQkFBaUIsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjBDLGtCQUFRMUMsaUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsZUFIN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGNBQWMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSDtBQUFBLFlBQ3JILHVCQUFDLFdBQU0sTUFBSyxVQUFTLEtBQUksS0FBSSxNQUFLLGlCQUFnQixhQUFZLHVCQUFzQixPQUFPTCxVQUFVTSxlQUFlLFVBQVVrRSxjQUFjLFdBQVUsMEZBQXRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRPO0FBQUEsWUFDM096QixPQUFPekMsaUJBQWlCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ5QyxrQkFBUXpDLGlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLGVBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsaUNBQUMsU0FBSTtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGNBQWtCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUg7QUFBQSxZQUMxSCx1QkFBQyxXQUFNLE1BQUssVUFBUyxLQUFJLEtBQUksTUFBSyxxQkFBb0IsYUFBWSwyQkFBMEIsT0FBT04sVUFBVW1CLG1CQUFtQixVQUFVcUQsY0FBYyxXQUFVLDBGQUFsSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3UDtBQUFBLFlBQ3ZQekIsT0FBTzVCLHFCQUFxQix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCNEIsaUJBQU81QixxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxlQUZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FBbUIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSDtBQUFBLFlBQVEsdUJBQUMsV0FBTSxNQUFLLFVBQVMsS0FBSSxLQUFJLE1BQUssc0JBQXFCLGFBQVksNEJBQTJCLE9BQU9uQixVQUFVa0Isb0JBQW9CLFVBQVVzRCxjQUFjLFdBQVUsMEZBQXJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJQO0FBQUEsWUFDN1h6QixPQUFPN0Isc0JBQXNCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI2QixpQkFBTzdCLHNCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLGVBRHRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxjQUFvQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJIO0FBQUEsWUFBUSx1QkFBQyxXQUFNLE1BQUssVUFBUyxLQUFJLEtBQUksTUFBSyx1QkFBc0IsYUFBWSw2QkFBNEIsT0FBT2xCLFVBQVVpQixxQkFBcUIsVUFBVXVELGNBQWMsV0FBVSwwRkFBeEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOFA7QUFBQSxZQUNqWXpCLE9BQU85Qix1QkFBdUIsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjhCLGlCQUFPOUIsdUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsZUFEeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSxpQ0FBQyxTQUNHO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FBZSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNIO0FBQUEsWUFDdEgsdUJBQUMsV0FBTSxNQUFLLFVBQVMsS0FBSSxLQUFJLE1BQUssa0JBQWlCLGFBQVksd0JBQXVCLE9BQU9qQixVQUFVTyxnQkFBZ0IsVUFBVWlFLGNBQWMsV0FBVSwwRkFBeko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK087QUFBQSxZQUM5T3pCLE9BQU94QyxrQkFBa0IsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QndDLGlCQUFPeEMsa0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsZUFIOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGNBQWlCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0g7QUFBQSxZQUN4SCx1QkFBQyxXQUFNLE1BQUssVUFBUyxLQUFJLEtBQUksTUFBSyxXQUFVLGFBQVksMEJBQXlCLE9BQU9QLFVBQVVnQixTQUFTLFVBQVV3RCxjQUFjLFdBQVUsMEZBQTdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1PO0FBQUEsWUFDbE96QixPQUFPL0IsV0FBVyx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCK0IsaUJBQU8vQixXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLGVBSGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBSUEsdUJBQUMsU0FDRztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLFlBQWdCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1SDtBQUFBLFVBQ3ZILHVCQUFDLFNBQUksV0FBVSxvQ0FDWDtBQUFBLG1DQUFDLFdBQU0sV0FBVSw4Q0FBNkM7QUFBQSxxQ0FBQyxXQUFNLE1BQUssU0FBUSxNQUFLLG1CQUFrQixPQUFNLFlBQVcsU0FBU2hCLFVBQVVRLG9CQUFvQixZQUFZLFVBQVVnRSxjQUFjLFdBQVUsMkJBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdLO0FBQUEsY0FBRyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHdCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLGlCQUF6UjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnUztBQUFBLFlBQ2hTLHVCQUFDLFdBQU0sV0FBVSw4Q0FBNkM7QUFBQSxxQ0FBQyxXQUFNLE1BQUssU0FBUSxNQUFLLG1CQUFrQixPQUFNLFNBQVEsU0FBU3hFLFVBQVVRLG9CQUFvQixTQUFTLFVBQVVnRSxjQUFjLFdBQVUsMkJBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtLO0FBQUEsY0FBRyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHFCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBLGlCQUFoUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1UjtBQUFBLGVBRjNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNDekIsT0FBT3ZDLG1CQUFtQix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCdUMsaUJBQU92QyxtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxhQU5oRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLGlDQUFDLFNBQUk7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxjQUFXLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0g7QUFBQSxZQUFRLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssY0FBYSxPQUFPUixVQUFVUyxZQUFZLFVBQVUrRCxjQUFjLFdBQVUsMEZBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBMO0FBQUEsWUFDcFR6QixPQUFPdEMsY0FBYyx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCc0MsaUJBQU90QyxjQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RDtBQUFBLGVBRHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQVEsdUJBQUMsV0FBTSxNQUFLLFFBQU8sTUFBSyxZQUFXLE9BQU9ULFVBQVVVLFVBQVUsVUFBVThELGNBQWMsV0FBVSwwRkFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0w7QUFBQSxZQUN0UXpCLE9BQU9yQyxZQUFZLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJxQyxpQkFBT3JDLFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsZUFEbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSxpQ0FBQyxTQUFJO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUFnRDtBQUFBO0FBQUEsY0FBYyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNIO0FBQUEsWUFBUSx1QkFBQyxXQUFNLE1BQUssVUFBUyxLQUFJLEtBQUksYUFBWSx1QkFBc0IsTUFBSyxlQUFjLE9BQU9WLFVBQVVXLGFBQWEsVUFBVTZELGNBQWMsV0FBVSwwRkFBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd087QUFBQSxZQUN0V3pCLE9BQU9wQyxlQUFlLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJvQyxpQkFBT3BDLGVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsZUFEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBZ0Q7QUFBQTtBQUFBLGNBQWMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzSDtBQUFBLFlBQVEsdUJBQUMsV0FBTSxNQUFLLFVBQVMsS0FBSSxLQUFJLGFBQVksdUJBQXNCLE1BQUssZUFBYyxPQUFPWCxVQUFVWSxhQUFhLFVBQVU0RCxjQUFjLFdBQVUsMEZBQWxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdPO0FBQUEsWUFDdFd6QixPQUFPbkMsZUFBZSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCbUMsaUJBQU9uQyxlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLGVBRHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsaUNBQUMsU0FBSTtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0Msa0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtGO0FBQUEsWUFBUTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUFNLE1BQUs7QUFBQSxnQkFBUyxLQUFJO0FBQUEsZ0JBQ3BILGFBQVk7QUFBQSxnQkFBMkIsTUFBSztBQUFBLGdCQUFhLE9BQU9aLFVBQVVhO0FBQUFBLGdCQUFZLFVBQVUyRDtBQUFBQSxnQkFBYyxXQUFVO0FBQUE7QUFBQSxjQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDbUg7QUFBQSxlQURsTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUNxTjtBQUFBLFVBQ3JOLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRjtBQUFBLFlBQVE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTSxNQUFLO0FBQUEsZ0JBQVMsS0FBSTtBQUFBLGdCQUFJLE1BQUs7QUFBQSxnQkFDL0gsYUFBWTtBQUFBLGdCQUE2QixPQUFPeEUsVUFBVWM7QUFBQUEsZ0JBQWtCLFVBQVUwRDtBQUFBQSxnQkFBYyxXQUFVO0FBQUE7QUFBQSxjQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFDdUc7QUFBQSxlQUR4TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUMyTTtBQUFBLFVBQzNNLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRjtBQUFBLFlBQVE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFBTSxNQUFLO0FBQUEsZ0JBQVMsS0FBSTtBQUFBLGdCQUN2SCxhQUFZO0FBQUEsZ0JBQThCLE1BQUs7QUFBQSxnQkFBYSxPQUFPeEUsVUFBVWU7QUFBQUEsZ0JBQVksVUFBVXlEO0FBQUFBLGdCQUFjLFdBQVU7QUFBQTtBQUFBLGNBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUNtSDtBQUFBLGVBRHJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQ3dOO0FBQUEsYUFONU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxZQUFTLGtCQUFrQixDQUFDLEtBQUssR0FBRyxHQUFHLFdBQVUsd0RBQXVELG9CQUFtQixPQUN4SDtBQUFBLGlDQUFDLFNBQU0sUUFBUSx1QkFBQyxVQUFLLFdBQVUsNkNBQTRDLHFDQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRixHQUM1RixpQ0FBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSxtQ0FBQyxTQUNHO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyx1Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUY7QUFBQSxjQUN2Rix1QkFBQyxVQUFPLFdBQVUsZUFBYyxhQUFZLGVBQWMsT0FBT3hFLFVBQVVzQiwyQkFBMkJ3SyxRQUFXLFVBQVUsQ0FBQ0ksUUFBUTdHLGlCQUFpQiwyQkFBMkI2RyxHQUFHLEdBQzlLLFdBQUMsVUFBVSxRQUFRLEVBQUU1SCxJQUFJLENBQUM2SCxNQUFNLHVCQUFDLE9BQU8sUUFBUCxFQUFzQixPQUFPQSxHQUFJQSxlQUFkQSxHQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQyxDQUFnQixLQUR6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFO0FBQUEsY0FDNUUsdUJBQUMsVUFBTyxXQUFVLGVBQWMsYUFBWSxlQUFjLE9BQU9uTSxVQUFVdUIsZ0JBQWdCdUssUUFBVyxVQUFVLENBQUNJLFFBQVE3RyxpQkFBaUIsZ0JBQWdCNkcsR0FBRyxHQUN4SixXQUFDLFVBQVUsU0FBUyxFQUFFNUgsSUFBSSxDQUFDNkgsTUFBTSx1QkFBQyxPQUFPLFFBQVAsRUFBc0IsT0FBT0EsR0FBSUEsZUFBZEEsR0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0MsQ0FBZ0IsS0FEMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUEsS0FkeUcsS0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0NuTSxVQUFVRyxlQUFlLGtCQUFrQkgsVUFBVUcsZUFBZSxtQkFDakU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFFBQ0ksdUJBQUMsU0FBSSxXQUFVLGlEQUNYO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDZDQUE0Qyw2Q0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUY7QUFBQSxnQkFDekYsdUJBQUMsT0FBSSxPQUFNLFFBQVFxQjtBQUFBQSx5Q0FBdUJzRTtBQUFBQSxrQkFBTztBQUFBLHFCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLG1CQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FJSjtBQUFBLHVDQUFDLFNBQUksV0FBVSx5REFDWDtBQUFBLHlDQUFDLFFBQUcsV0FBVSxvRUFDVHJELDJCQUFpQixPQUFPLGVBQWUsMkJBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVcsaUNBQWlDZixvQkFBb0JhLHVCQUF1QixZQUFZLElBQUksQ0FBQyxlQUN6RztBQUFBLDJDQUFDLFNBQ0c7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyRTtBQUFBLHNCQUMzRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxNQUFLO0FBQUEsMEJBQ0wsT0FDSUUsaUJBQWlCLE9BQ1hmLG9CQUFvQmMsaUJBQ3BCaEIsdUJBQXVCc0UsU0FBUztBQUFBLDBCQUcxQyxVQUFVLENBQUMzQixNQUFNcUIseUJBQXlCLGtCQUFrQnJCLEVBQUVRLE9BQU9ELEtBQUs7QUFBQSwwQkFDMUUsV0FBVTtBQUFBO0FBQUEsd0JBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVN3RztBQUFBLHlCQVg1RztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWFBO0FBQUEsb0JBQ0NoRCxvQkFBb0JhLHVCQUF1QixhQUN4Qyx1QkFBQyxTQUNHO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0U7QUFBQSxzQkFDcEU7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0csV0FBVTtBQUFBLDBCQUNWLE9BQU9iLG9CQUFvQlk7QUFBQUEsMEJBQzNCLFVBQVUsQ0FBQzRKLFFBQVExRyx5QkFBeUIsZ0JBQWdCMEcsR0FBRztBQUFBLDBCQUUvRDtBQUFBLG1EQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFBTyxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBZ0M7QUFBQSw0QkFDaEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFvQztBQUFBO0FBQUE7QUFBQSx3QkFOeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU9BO0FBQUEseUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLG9CQUVKLHVCQUFDLFNBQ0c7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxRTtBQUFBLHNCQUNyRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxXQUFVO0FBQUEsMEJBQ1YsT0FDSXhLLG9CQUFvQmE7QUFBQUEsMEJBQ3hCLFVBQVUsQ0FBQzJKLFFBQVExRyx5QkFBeUIsc0JBQXNCMEcsR0FBRztBQUFBLDBCQUVyRTtBQUFBLG1EQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sZ0JBQWUsNEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWdEO0FBQUEsNEJBQ2hELHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sV0FBVSx1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBc0M7QUFBQTtBQUFBO0FBQUEsd0JBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRQTtBQUFBLHlCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBV0E7QUFBQSx1QkF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF3Q0E7QUFBQSxrQkFFQ3hLLG9CQUFvQmEsdUJBQXVCLGFBQ3hDLG1DQUNJO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDhDQUNYO0FBQUEsNkNBQUMsU0FDRztBQUFBLCtDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTBFO0FBQUEsd0JBQzFFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNHLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUEsNEJBQ1osS0FBSTtBQUFBLDRCQUNKLE9BQU9iLG9CQUFvQks7QUFBQUEsNEJBQzNCLFVBQVUsQ0FBQ29DLE1BQU1xQix5QkFBeUIsY0FBY3JCLEVBQUVRLE9BQU9ELEtBQUs7QUFBQSw0QkFDdEUsV0FBVTtBQUFBO0FBQUEsMEJBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU1nRjtBQUFBLDJCQVJwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FDRztBQUFBLCtDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXFFO0FBQUEsd0JBQ3JFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNHLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUEsNEJBQ1osS0FBSTtBQUFBLDRCQUNKO0FBQUEsNEJBQ0EsT0FBT2hELG9CQUFvQkk7QUFBQUEsNEJBQzNCLFVBQVUsQ0FBQ3FDLE1BQU1xQix5QkFBeUIsa0JBQWtCckIsRUFBRVEsT0FBT0QsS0FBSztBQUFBLDRCQUMxRSxXQUFVO0FBQUE7QUFBQSwwQkFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT2dGO0FBQUEsMkJBVHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBV0E7QUFBQSxzQkFFQSx1QkFBQyxTQUNHO0FBQUEsK0NBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMEU7QUFBQSx3QkFDMUU7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0csTUFBSztBQUFBLDRCQUNMLGFBQVk7QUFBQSw0QkFDWixLQUFJO0FBQUEsNEJBQ0o7QUFBQSw0QkFDQSxPQUFPaEQsb0JBQW9CYjtBQUFBQSw0QkFDM0IsVUFBVSxDQUFDc0QsTUFBTXFCLHlCQUF5QixjQUFjckIsRUFBRVEsT0FBT0QsS0FBSztBQUFBLDRCQUN0RSxXQUFVO0FBQUE7QUFBQSwwQkFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT2dGO0FBQUEsMkJBVHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBV0E7QUFBQSxzQkFDQSx1QkFBQyxTQUNHO0FBQUEsK0NBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMEU7QUFBQSx3QkFDMUU7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0csTUFBSztBQUFBLDRCQUNMLGFBQVk7QUFBQSw0QkFDWjtBQUFBLDRCQUNBLEtBQUk7QUFBQSw0QkFDSixPQUFPaEQsb0JBQW9CTTtBQUFBQSw0QkFDM0IsVUFBVSxDQUFDbUMsTUFBTXFCLHlCQUF5QixjQUFjckIsRUFBRVEsT0FBT0QsS0FBSztBQUFBLDRCQUN0RSxXQUFVO0FBQUE7QUFBQSwwQkFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT2dGO0FBQUEsMkJBVHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBV0E7QUFBQSx5QkFoREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpREE7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsOENBQ1g7QUFBQSw2Q0FBQyxTQUNHO0FBQUEsK0NBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBd0U7QUFBQSx3QkFDeEU7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0csTUFBSztBQUFBLDRCQUNMLGFBQVk7QUFBQSw0QkFDWixLQUFJO0FBQUEsNEJBQ0o7QUFBQSw0QkFDQSxPQUFPaEQsb0JBQW9CTztBQUFBQSw0QkFDM0IsVUFBVSxDQUFDa0MsTUFBTXFCLHlCQUF5QixZQUFZckIsRUFBRVEsT0FBT0QsS0FBSztBQUFBLDRCQUNwRSxXQUFVO0FBQUE7QUFBQSwwQkFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT2dGO0FBQUEsMkJBVHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBV0E7QUFBQSxzQkFDQSx1QkFBQyxTQUNHO0FBQUEsK0NBQUMsV0FBTSxXQUFVLGdEQUErQyxpQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUY7QUFBQSx3QkFDakY7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0csTUFBSztBQUFBLDRCQUNMLGFBQVk7QUFBQSw0QkFDWjtBQUFBLDRCQUNBLE9BQU9oRCxvQkFBb0JRO0FBQUFBLDRCQUMzQixVQUFVLENBQUNpQyxNQUFNcUIseUJBQXlCLGlCQUFpQnJCLEVBQUVRLE9BQU9ELEtBQUs7QUFBQSw0QkFDekUsV0FBVTtBQUFBO0FBQUEsMEJBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU1nRjtBQUFBLDJCQVJwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FDRztBQUFBLCtDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXVFO0FBQUEsd0JBQ3ZFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNHLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUEsNEJBQ1osS0FBSTtBQUFBLDRCQUNKO0FBQUEsNEJBQ0EsT0FBT2hELG9CQUFvQlM7QUFBQUEsNEJBQzNCLFVBQVUsQ0FBQ2dDLE1BQU1xQix5QkFBeUIsV0FBV3JCLEVBQUVRLE9BQU9ELEtBQUs7QUFBQSw0QkFDbkUsV0FBVTtBQUFBO0FBQUEsMEJBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU9nRjtBQUFBLDJCQVRwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVdBO0FBQUEseUJBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBb0NBO0FBQUEsdUJBeEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUZBO0FBQUEsa0JBR0osdUJBQUMsU0FBSSxXQUFVLG1EQUNYO0FBQUEsMkNBQUMsU0FDRztBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRFO0FBQUEsc0JBQzVFO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNHLE1BQUs7QUFBQSwwQkFDTCxPQUFPaEQsb0JBQW9CVTtBQUFBQSwwQkFDM0IsVUFBVSxDQUFDK0IsTUFBTXFCLHlCQUF5QixnQkFBZ0JyQixFQUFFUSxPQUFPRCxLQUFLO0FBQUEsMEJBQ3hFLFdBQVU7QUFBQTtBQUFBLHdCQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFJZ0Y7QUFBQSx5QkFOcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0c7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRjtBQUFBLHNCQUNqRjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxNQUFLO0FBQUEsMEJBQ0wsT0FBT2hELG9CQUFvQlc7QUFBQUEsMEJBQzNCLFVBQVUsQ0FBQzhCLE1BQU1xQix5QkFBeUIsYUFBYXJCLEVBQUVRLE9BQU9ELEtBQUs7QUFBQSwwQkFDckUsV0FBVTtBQUFBO0FBQUEsd0JBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUlnRjtBQUFBLHlCQU5wRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVFBO0FBQUEsdUJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUJBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLDhDQUNYO0FBQUEsMkNBQUMsU0FDRztBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRFO0FBQUEsc0JBQzVFO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNHLE1BQUs7QUFBQSwwQkFDTCxPQUFPaEQsb0JBQW9CRTtBQUFBQSwwQkFDM0IsVUFBVSxDQUFDdUMsTUFBTXFCLHlCQUF5QixnQkFBZ0JyQixFQUFFUSxPQUFPRCxLQUFLO0FBQUEsMEJBQ3hFLFdBQVU7QUFBQTtBQUFBLHdCQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFJZ0Y7QUFBQSx5QkFOcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0c7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRjtBQUFBLHNCQUNqRjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxNQUFLO0FBQUEsMEJBQ0wsT0FBT2hELG9CQUFvQkc7QUFBQUEsMEJBQzNCLFVBQVUsQ0FBQ3NDLE1BQU1xQix5QkFBeUIscUJBQXFCckIsRUFBRVEsT0FBT0QsS0FBSztBQUFBLDBCQUM3RSxXQUFVO0FBQUE7QUFBQSx3QkFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSWdGO0FBQUEseUJBTnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUUE7QUFBQSx1QkFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ1ZqQztBQUFBQSxxQ0FBaUIsUUFDZDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxTQUFTLE1BQU07QUFDWEMsMENBQWdCLElBQUk7QUFDcEI2RCxnREFBc0I7QUFBQSx3QkFDMUI7QUFBQSx3QkFDQSxXQUFVO0FBQUEsd0JBQStCO0FBQUE7QUFBQSxzQkFMN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVFBO0FBQUEsb0JBRUo7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csTUFBSztBQUFBLHdCQUNMLE1BQU05RCxpQkFBaUIsT0FBTyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFhLElBQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBYTtBQUFBLHdCQUM5RCxTQUFTMEg7QUFBQUEsd0JBQ1QsV0FBVTtBQUFBLHdCQUVUMUgsMkJBQWlCLE9BQU8saUJBQWlCO0FBQUE7QUFBQSxzQkFOOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsdUJBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBb0JBO0FBQUEscUJBMU1KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMk1BO0FBQUEsZ0JBRUNqQix1QkFBdUJzRSxTQUFTLEtBQzdCLHVCQUFDLFNBQ0c7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsc0RBQXFEO0FBQUE7QUFBQSxvQkFBZ0J0RSx1QkFBdUJzRTtBQUFBQSxvQkFBTztBQUFBLHVCQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrSDtBQUFBLGtCQUNsSCx1QkFBQyxTQUFJLFdBQVUsNERBQ1Z0RSxpQ0FBdUI4QztBQUFBQSxvQkFBSSxDQUFDQyxPQUFPNkgsUUFDaEMsdUJBQUMsU0FBYyxXQUFVLG1JQUNyQjtBQUFBLDZDQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLCtDQUFDLFNBQUksV0FBVSxnR0FBK0Y7QUFBQTtBQUFBLDBCQUN4RzdILE1BQU0vQjtBQUFBQSw2QkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0EsdUJBQUMsU0FDRztBQUFBLGlEQUFDLE9BQUUsV0FBVSxtQ0FBbUMrQjtBQUFBQSxrQ0FBTW5DLGdCQUFnQjtBQUFBLDRCQUFVO0FBQUEsNEJBQUMsdUJBQUMsVUFBSyxXQUFVLGtDQUFrQ21DLGdCQUFNM0MsZ0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQXFFO0FBQUEsK0JBQXRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTZKO0FBQUEsMEJBQzdKLHVCQUFDLE9BQUUsV0FBVSx5QkFBeUIyQztBQUFBQSxrQ0FBTWhDO0FBQUFBLDRCQUFtQjtBQUFBLDRCQUFjZ0MsTUFBTXBDLFdBQVc7QUFBQSwrQkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZ0c7QUFBQSw2QkFGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFHQTtBQUFBLDJCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBUUE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNHLE1BQUs7QUFBQSw0QkFDTCxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWE7QUFBQSw0QkFDbkIsU0FBUyxNQUFNMEosZ0JBQWdCTyxHQUFHO0FBQUEsNEJBQ2xDLFdBQVU7QUFBQSw0QkFBb0U7QUFBQTtBQUFBLDBCQUpsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT0E7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDRztBQUFBLDRCQUNBLE1BQUs7QUFBQSw0QkFDTCxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWU7QUFBQSw0QkFDckIsU0FBUyxNQUFNckcsa0JBQWtCcUcsR0FBRztBQUFBLDRCQUNwQyxXQUFVO0FBQUEsNEJBQ1YsVUFBVTdILE1BQU1oQyx1QkFBdUI7QUFBQSw0QkFDdkMsT0FBT2dDLE1BQU1oQyx1QkFBdUIsaUJBQWlCLEVBQUU4SixTQUFTLEdBQUdDLFFBQVEsY0FBYyxJQUFJLENBQUM7QUFBQTtBQUFBLDBCQVBsRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT29HO0FBQUEsMkJBaEJ4RztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWtCQTtBQUFBLHlCQTVCTUYsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQTZCQTtBQUFBLGtCQUNILEtBaENMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUNBO0FBQUEscUJBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0NBO0FBQUE7QUFBQTtBQUFBLFlBcFBBO0FBQUEsWUFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNlBBLElBQ0E7QUFBQSxhQWhSUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaVJBO0FBQUEsV0E1WUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZZQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHNFQUNYLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFVBQVUvSSxTQUFTLFdBQVUsa09BQzlDQSxvQkFBVSxjQUFlSyxhQUFhLGlCQUFpQixnQkFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0ExWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJaQTtBQUFBLElBRUNILGVBQ0c7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLFFBQVFBO0FBQUFBLFFBQ1IsT0FBTTtBQUFBLFFBQ04sTUFBTWtJO0FBQUFBLFFBQ04sVUFBVSxNQUFNakksZUFBZSxLQUFLO0FBQUEsUUFDcEMsV0FBV2tIO0FBQUFBO0FBQUFBLE1BTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSzRCO0FBQUEsT0ExYXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2YUE7QUFFUjtBQUFFM0ssR0FwbENJTCxjQUFZO0FBQUEsVUEyREdGLFdBQVc7QUFBQTtBQUFBK00sS0EzRDFCN007QUFzbENOLGVBQWVBO0FBQWEsSUFBQTZNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNlbGVjdCIsIkNvbGxhcHNlIiwiVGFnIiwiQnV0dG9uIiwibWVzc2FnZSIsIlBsdXNPdXRsaW5lZCIsIkRlbGV0ZU91dGxpbmVkIiwiRWRpdE91dGxpbmVkIiwiYXBpIiwiUmVDb25maXJtTW9kYWwiLCJDdXN0b21BbGVydCIsInVzZUxvY2F0aW9uIiwiUGFuZWwiLCJBZGRHcm91cEZvcm0iLCJtb2RlIiwiaW5pdGlhbERhdGEiLCJmaWVsZFNpemUiLCJoZWlnaHQiLCJfcyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9uYW1lIiwiZ3JvdXBfdHlwZSIsImdyb3VwX3ZhbHVlIiwiZ3JvdXBfaW5zdGFsbCIsImdyb3VwX21lbWJlcnMiLCJncm91cF9kdXJhdGlvbiIsInN0YXJ0X2RhdGVfdHlwZSIsInN0YXJ0X2RhdGUiLCJlbmRfZGF0ZSIsIm1pbmltdW1fYmlkIiwibWF4aW11bV9iaWQiLCJjb21taXNzaW9uIiwiZ3JvdXBfY29tbWlzc2lvbiIsImluY2VudGl2ZXMiLCJyZWdfZmVlIiwibW9udGhseV9pbnN0YWxsbWVudCIsIndlZWtseV9pbnN0YWxsbWVudCIsImRhaWx5X2luc3RhbGxtZW50IiwicmVsYXRpb25zaGlwX21hbmFnZXIiLCJhcHBfZGlzcGxheV92YWNhbnlfc2VhdCIsImF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlIiwiYXVjdGlvbl9tb2RlIiwicHJlZml4ZWRBdWN0aW9uRW50cmllcyIsInNldFByZWZpeGVkQXVjdGlvbkVudHJpZXMiLCJjdXJyZW50QXVjdGlvbkVudHJ5Iiwic2V0Q3VycmVudEF1Y3Rpb25FbnRyeSIsImF1Y3Rpb25fdGltZSIsIm5leHRfYXVjdGlvbl90aW1lIiwiYmlkX3BlcmNlbnRhZ2UiLCJiaWRfYW1vdW50Iiwid2luX2Ftb3VudCIsImRpdmlkZW50IiwiZGl2aWRlbnRfaGVhZCIsInBheWFibGUiLCJhdWN0aW9uX2RhdGUiLCJuZXh0X2RhdGUiLCJhdWN0aW9uX3R5cGUiLCJhdWN0aW9uX3N0YWdlX3R5cGUiLCJhdWN0aW9uX251bWJlciIsImVkaXRpbmdJbmRleCIsInNldEVkaXRpbmdJbmRleCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwidHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzaG93Q29uZmlybSIsInNldFNob3dDb25maXJtIiwibG9jYXRpb24iLCJpc0VkaXRNb2RlIiwic2V0SXNFZGl0TW9kZSIsImdyb3VwSWQiLCJzZXRHcm91cElkIiwibG9hZGluZ0ZldGNoIiwic2V0TG9hZGluZ0ZldGNoIiwiZ2V0QXVjdGlvbkVudHJpZXNPbmx5IiwiZW50cmllcyIsImZpbHRlciIsImUiLCJyZW51bWJlckF1Y3Rpb25FbnRyaWVzIiwiYXVjdGlvbkNvdW50ZXIiLCJtYXAiLCJlbnRyeSIsImhhbmRsZUNoYW5nZSIsIm5hbWUiLCJ2YWx1ZSIsInRhcmdldCIsIm5ld1ZhbHVlIiwic3RyaW5nTnVtZXJpY0ZpZWxkcyIsIm51bWJlckZpZWxkcyIsImluY2x1ZGVzIiwibnVtIiwiTnVtYmVyIiwiaXNOYU4iLCJ0b1N0cmluZyIsInByZXZEYXRhIiwiaGFuZGxlQW50RFNlbGVjdCIsImZpZWxkIiwicHJldkVycm9ycyIsImhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZSIsInByZXYiLCJoYW5kbGVBZGRBdWN0aW9uRW50cnkiLCJhbGVydCIsIm5ld0VudHJ5IiwiZm9yRWFjaCIsImxlbmd0aCIsImhhbmRsZVJlbW92ZUVudHJ5IiwiaW5kZXgiLCJlbnRyeVRvUmVtb3ZlIiwid2FybmluZyIsInVwZGF0ZWRMaXN0IiwiXyIsImkiLCJyZW51bWJlcmVkTGlzdCIsInJlc2V0QXVjdGlvbkVudHJ5Rm9ybSIsImhhbmRsZVJlY29uZmlybWF0aW9uIiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwidmFsaWRhdGVGb3JtIiwiZmV0Y2hHcm91cEZvckVkaXQiLCJpZCIsInJlc3BvbnNlIiwiZ2V0IiwiZ3JvdXAiLCJkYXRhIiwiZm9ybWF0dGVkU3RhcnREYXRlIiwic3BsaXQiLCJmb3JtYXR0ZWRFbmREYXRlIiwiX2lkIiwicHJlZml4ZWRfYXVjdGlvbl9lbnRyaWVzIiwiQXJyYXkiLCJpc0FycmF5Iiwic29ydGVkIiwic29ydCIsImEiLCJiIiwicmVudW1iZXJlZCIsImVycm9yIiwiY29uc29sZSIsImdyb3VwVmFsdWUiLCJwYXJzZUZsb2F0IiwiZ3JvdXBDb21taXNzaW9uUGN0IiwiZ3JvdXBNZW1iZXJzIiwiZ3JvdXBJbnN0YWxsIiwiYmlkQW1vdW50IiwiYmlkUGVyY2VudCIsImZpbmFsQmlkQW1vdW50IiwiZmluYWxCaWRQZXJjZW50IiwidG9GaXhlZCIsIndpbkFtb3VudCIsImRpdmlkZW50SGVhZCIsImRhdGUiLCJEYXRlIiwiZ2V0VGltZSIsInNldERhdGUiLCJnZXREYXRlIiwibmV4dERhdGUiLCJ0b0lTT1N0cmluZyIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInNlYXJjaCIsImVkaXRQYXJhbSIsImlkUGFyYW0iLCJnZXRFbXBsb3llZXMiLCJyZXNwb25zZURhdGEiLCJlbXBsb3llZSIsImxvZyIsIm5ld0Vycm9ycyIsInRyaW0iLCJPYmplY3QiLCJrZXlzIiwibWF4TnVtYmVyIiwiTWF0aCIsIm1heCIsImhhbmRsZUFkZE9yVXBkYXRlQXVjdGlvbkVudHJ5IiwiZXhpc3RpbmdDb21tZW5jZW1lbnQiLCJzb21lIiwic3VjY2VzcyIsIm5leHROdW1iZXIiLCJmaW5hbEVudHJ5IiwibmV4dE51bWJlckFmdGVyQWRkIiwiaGFuZGxlU3VibWl0IiwidXBkYXRlUGF5bG9hZCIsInB1dCIsImhlYWRlcnMiLCJwYXlsb2FkIiwicG9zdCIsIndpbmRvdyIsIm9wZW5lciIsInJlZnJlc2hHcm91cHMiLCJzZXRUaW1lb3V0IiwiY2xvc2UiLCJjb25maXJtRGF0YSIsImF1Y3Rpb25fZW50cmllc19jb3VudCIsImF1Y3Rpb25fZW50cmllc19zdW1tYXJ5Iiwiam9pbiIsInNhbml0aXplZENvbmZpcm1EYXRhIiwicmVkdWNlIiwiYWNjIiwia2V5IiwiaGFuZGxlRWRpdEVudHJ5IiwidW5kZWZpbmVkIiwiZ1R5cGUiLCJ0b0xvd2VyQ2FzZSIsInBob25lX251bWJlciIsInZhbCIsInMiLCJpZHgiLCJvcGFjaXR5IiwiY3Vyc29yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWRkR3JvdXBGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBDb2xsYXBzZSwgVGFnLCBCdXR0b24sIG1lc3NhZ2UgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBQbHVzT3V0bGluZWQsIERlbGV0ZU91dGxpbmVkLCBFZGl0T3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgUmVDb25maXJtTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL1JlQ29uZmlybU1vZGFsXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuY29uc3QgeyBQYW5lbCB9ID0gQ29sbGFwc2U7XHJcblxyXG5jb25zdCBBZGRHcm91cEZvcm0gPSAoe1xyXG4gICAgbW9kZSA9IFwiYWRkXCIsXHJcbiAgICBpbml0aWFsRGF0YSA9IG51bGwsXHJcbiAgICBmaWVsZFNpemUgPSB7IGhlaWdodDogXCJoLTEyXCIgfSxcclxufSkgPT4ge1xyXG4gICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgZ3JvdXBfbmFtZTogXCJcIixcclxuICAgICAgICBncm91cF90eXBlOiBcIlwiLFxyXG4gICAgICAgIGdyb3VwX3ZhbHVlOiBcIlwiLFxyXG4gICAgICAgIGdyb3VwX2luc3RhbGw6IFwiXCIsXHJcbiAgICAgICAgZ3JvdXBfbWVtYmVyczogXCJcIixcclxuICAgICAgICBncm91cF9kdXJhdGlvbjogXCJcIixcclxuICAgICAgICBzdGFydF9kYXRlX3R5cGU6IFwiZml4ZWRcIixcclxuICAgICAgICBzdGFydF9kYXRlOiBcIlwiLFxyXG4gICAgICAgIGVuZF9kYXRlOiBcIlwiLFxyXG4gICAgICAgIG1pbmltdW1fYmlkOiBcIlwiLFxyXG4gICAgICAgIG1heGltdW1fYmlkOiBcIlwiLFxyXG4gICAgICAgIGNvbW1pc3Npb246IFwiMVwiLFxyXG4gICAgICAgIGdyb3VwX2NvbW1pc3Npb246IFwiNVwiLFxyXG4gICAgICAgIGluY2VudGl2ZXM6IFwiMVwiLFxyXG4gICAgICAgIHJlZ19mZWU6IFwiXCIsXHJcbiAgICAgICAgbW9udGhseV9pbnN0YWxsbWVudDogXCJcIixcclxuICAgICAgICB3ZWVrbHlfaW5zdGFsbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgZGFpbHlfaW5zdGFsbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgcmVsYXRpb25zaGlwX21hbmFnZXI6IFwiXCIsXHJcbiAgICAgICAgYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQ6IG51bGwsXHJcbiAgICAgICAgYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGU6IFwiU1lTVEVNXCIsXHJcbiAgICAgICAgYXVjdGlvbl9tb2RlOiBcIk9OTElORVwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgW3ByZWZpeGVkQXVjdGlvbkVudHJpZXMsIHNldFByZWZpeGVkQXVjdGlvbkVudHJpZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2N1cnJlbnRBdWN0aW9uRW50cnksIHNldEN1cnJlbnRBdWN0aW9uRW50cnldID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIGF1Y3Rpb25fdGltZTogXCIxMDowMCBBTVwiLFxyXG4gICAgICAgIG5leHRfYXVjdGlvbl90aW1lOiBcIjExOjAwIEFNXCIsXHJcbiAgICAgICAgYmlkX3BlcmNlbnRhZ2U6IFwiXCIsXHJcbiAgICAgICAgYmlkX2Ftb3VudDogXCJcIixcclxuICAgICAgICBjb21taXNzaW9uOiBcIlwiLFxyXG4gICAgICAgIHdpbl9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgZGl2aWRlbnQ6IFwiXCIsXHJcbiAgICAgICAgZGl2aWRlbnRfaGVhZDogXCJcIixcclxuICAgICAgICBwYXlhYmxlOiBcIlwiLFxyXG4gICAgICAgIGF1Y3Rpb25fZGF0ZTogXCJcIixcclxuICAgICAgICBuZXh0X2RhdGU6IFwiXCIsXHJcbiAgICAgICAgYXVjdGlvbl90eXBlOiBcIk5PUk1BTFwiLFxyXG4gICAgICAgIGF1Y3Rpb25fc3RhZ2VfdHlwZTogXCJDT01NRU5DRU1FTlRcIixcclxuICAgICAgICBhdWN0aW9uX251bWJlcjogMSxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgW2VkaXRpbmdJbmRleCwgc2V0RWRpdGluZ0luZGV4XSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICAgIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICAgICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc2hvd0NvbmZpcm0sIHNldFNob3dDb25maXJtXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICAgIGNvbnN0IFtpc0VkaXRNb2RlLCBzZXRJc0VkaXRNb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtncm91cElkLCBzZXRHcm91cElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2xvYWRpbmdGZXRjaCwgc2V0TG9hZGluZ0ZldGNoXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCBnZXRBdWN0aW9uRW50cmllc09ubHkgPSAoZW50cmllcykgPT4gZW50cmllcy5maWx0ZXIoZSA9PiBlLmF1Y3Rpb25fc3RhZ2VfdHlwZSA9PT0gXCJBVUNUSU9OXCIpO1xyXG5cclxuICAgIC8vIFJlbnVtYmVyIEFVQ1RJT04gZW50cmllcyBzZXF1ZW50aWFsbHkgc3RhcnRpbmcgZnJvbSAxXHJcbiAgICBjb25zdCByZW51bWJlckF1Y3Rpb25FbnRyaWVzID0gKGVudHJpZXMpID0+IHtcclxuICAgICAgICBsZXQgYXVjdGlvbkNvdW50ZXIgPSAxO1xyXG4gICAgICAgIHJldHVybiBlbnRyaWVzLm1hcChlbnRyeSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIGVudHJ5LmF1Y3Rpb25fc3RhZ2VfdHlwZSA9PT0gXCJBVUNUSU9OXCIgfHxcclxuICAgICAgICAgICAgICAgIGVudHJ5LmF1Y3Rpb25fc3RhZ2VfdHlwZSA9PT0gXCJDT01NRU5DRU1FTlRcIlxyXG4gICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLi4uZW50cnksXHJcbiAgICAgICAgICAgICAgICAgICAgYXVjdGlvbl9udW1iZXI6IGF1Y3Rpb25Db3VudGVyKyssXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBlbnRyeTsgLy8gQ09NTUVOQ0VNRU5UIGVudHJpZXMga2VlcCB0aGVpciBvcmlnaW5hbCBudW1iZXJcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgICAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgICAgICBsZXQgbmV3VmFsdWUgPSB2YWx1ZTtcclxuXHJcbiAgICAgICAgLy8gRmllbGRzIHRoYXQgc2hvdWxkIGJlIHN0b3JlZCBhcyBzdHJpbmdzIChiYWNrZW5kIGV4cGVjdHMgc3RyaW5nKVxyXG4gICAgICAgIGNvbnN0IHN0cmluZ051bWVyaWNGaWVsZHMgPSBbXHJcbiAgICAgICAgICAgICdncm91cF92YWx1ZScsICdncm91cF9pbnN0YWxsJywgJ2dyb3VwX21lbWJlcnMnLCAnZ3JvdXBfZHVyYXRpb24nLFxyXG4gICAgICAgICAgICAncmVnX2ZlZScsICdkYWlseV9pbnN0YWxsbWVudCcsICd3ZWVrbHlfaW5zdGFsbG1lbnQnLCAnbW9udGhseV9pbnN0YWxsbWVudCcsXHJcbiAgICAgICAgICAgICdtaW5pbXVtX2JpZCcsICdtYXhpbXVtX2JpZCcsICdjb21taXNzaW9uJywgJ2dyb3VwX2NvbW1pc3Npb24nLCAnaW5jZW50aXZlcydcclxuICAgICAgICBdO1xyXG5cclxuICAgICAgICAvLyBGaWVsZHMgdGhhdCBzaG91bGQgYmUgc3RvcmVkIGFzIG51bWJlcnMgb3IgbnVsbFxyXG4gICAgICAgIGNvbnN0IG51bWJlckZpZWxkcyA9IFsnYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQnXTtcclxuXHJcbiAgICAgICAgLy8gSGFuZGxlIHN0cmluZyBudW1lcmljIGZpZWxkcyAoc3RvcmUgYXMgc3RyaW5nKVxyXG4gICAgICAgIGlmIChzdHJpbmdOdW1lcmljRmllbGRzLmluY2x1ZGVzKG5hbWUpKSB7XHJcbiAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gJycpIHtcclxuICAgICAgICAgICAgICAgIG5ld1ZhbHVlID0gJyc7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgbnVtID0gTnVtYmVyKHZhbHVlKTtcclxuICAgICAgICAgICAgICAgIGlmICghaXNOYU4obnVtKSAmJiBudW0gPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld1ZhbHVlID0gbnVtLnRvU3RyaW5nKCk7IC8vIHN0b3JlIGFzIHN0cmluZ1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChudW0gPCAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3VmFsdWUgPSAnMCc7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGlzTmFOKG51bSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChudW1iZXJGaWVsZHMuaW5jbHVkZXMobmFtZSkpIHtcclxuICAgICAgICAgICAgaWYgKHZhbHVlID09PSAnJykge1xyXG4gICAgICAgICAgICAgICAgbmV3VmFsdWUgPSBudWxsO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbGV0IG51bSA9IE51bWJlcih2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWlzTmFOKG51bSkgJiYgbnVtID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9IG51bTsgLy8gc3RvcmUgYXMgbnVtYmVyXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKG51bSA8IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9IDA7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGlzTmFOKG51bSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgICAgIFtuYW1lXTogbmV3VmFsdWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgICAgICBbbmFtZV06IFwiXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgICAgICAgICAgIFtmaWVsZF06IFwiXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBdWN0aW9uSW5wdXRDaGFuZ2UgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICAgICAgc2V0Q3VycmVudEF1Y3Rpb25FbnRyeSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBZGRBdWN0aW9uRW50cnkgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFjdXJyZW50QXVjdGlvbkVudHJ5LmF1Y3Rpb25fZGF0ZSB8fCAhY3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX3RpbWUpIHtcclxuICAgICAgICAgICAgYWxlcnQoXCJQbGVhc2UgZmlsbCBpbiBhdCBsZWFzdCB0aGUgRGF0ZSBhbmQgVGltZS5cIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IG5ld0VudHJ5ID0geyAuLi5jdXJyZW50QXVjdGlvbkVudHJ5IH07XHJcbiAgICAgICAgWydiaWRfcGVyY2VudGFnZScsICdiaWRfYW1vdW50JywgJ2NvbW1pc3Npb24nLCAnd2luX2Ftb3VudCcsICdkaXZpZGVudCcsICdwYXlhYmxlJywgJ2F1Y3Rpb25fbnVtYmVyJ10uZm9yRWFjaChmaWVsZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChuZXdFbnRyeVtmaWVsZF0pIG5ld0VudHJ5W2ZpZWxkXSA9IChuZXdFbnRyeVtmaWVsZF0pO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRQcmVmaXhlZEF1Y3Rpb25FbnRyaWVzKFsuLi5wcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLCBuZXdFbnRyeV0pO1xyXG5cclxuICAgICAgICBzZXRDdXJyZW50QXVjdGlvbkVudHJ5KHtcclxuICAgICAgICAgICAgLi4uY3VycmVudEF1Y3Rpb25FbnRyeSxcclxuICAgICAgICAgICAgYmlkX3BlcmNlbnRhZ2U6IFwiXCIsXHJcbiAgICAgICAgICAgIGJpZF9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICAgICAgICAgIHdpbl9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGRpdmlkZW50OiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlhYmxlOiBcIlwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGU6IFwiXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fbnVtYmVyOiBwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLmxlbmd0aCArIDIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fc3RhZ2VfdHlwZTogXCJBVUNUSU9OXCJcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlRW50cnkgPSAoaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBlbnRyeVRvUmVtb3ZlID0gcHJlZml4ZWRBdWN0aW9uRW50cmllc1tpbmRleF07XHJcbiAgICAgICAgaWYgKGVudHJ5VG9SZW1vdmUuYXVjdGlvbl9zdGFnZV90eXBlID09PSBcIkNPTU1FTkNFTUVOVFwiKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2Uud2FybmluZyhcIkNvbW1lbmNlbWVudCBlbnRyeSBpcyBtYW5kYXRvcnkgYW5kIGNhbm5vdCBiZSBkZWxldGVkLlwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCB1cGRhdGVkTGlzdCA9IHByZWZpeGVkQXVjdGlvbkVudHJpZXMuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCk7XHJcblxyXG4gICAgICAgIC8vIFJlbnVtYmVyIHJlbWFpbmluZyBhdWN0aW9uIGVudHJpZXNcclxuICAgICAgICBjb25zdCByZW51bWJlcmVkTGlzdCA9IHJlbnVtYmVyQXVjdGlvbkVudHJpZXModXBkYXRlZExpc3QpO1xyXG4gICAgICAgIHNldFByZWZpeGVkQXVjdGlvbkVudHJpZXMocmVudW1iZXJlZExpc3QpO1xyXG5cclxuICAgICAgICAvLyBJZiB3ZSB3ZXJlIGVkaXRpbmcgdGhlIGRlbGV0ZWQgZW50cnksIHJlc2V0IGVkaXQgbW9kZVxyXG4gICAgICAgIGlmIChlZGl0aW5nSW5kZXggPT09IGluZGV4KSB7XHJcbiAgICAgICAgICAgIHNldEVkaXRpbmdJbmRleChudWxsKTtcclxuICAgICAgICAgICAgcmVzZXRBdWN0aW9uRW50cnlGb3JtKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChlZGl0aW5nSW5kZXggIT09IG51bGwgJiYgZWRpdGluZ0luZGV4ID4gaW5kZXgpIHtcclxuICAgICAgICAgICAgLy8gQWRqdXN0IGVkaXRpbmcgaW5kZXggaWYgaXQgd2FzIGFmdGVyIHRoZSByZW1vdmVkIG9uZVxyXG4gICAgICAgICAgICBzZXRFZGl0aW5nSW5kZXgoZWRpdGluZ0luZGV4IC0gMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZWNvbmZpcm1hdGlvbiA9IChlKSA9PiB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRHcm91cFwiKTtcclxuICAgICAgICBpZiAoIWlzVmFsaWQpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIGZpbGwgYWxsIHRoZSByZXF1aXJlZCBmaWVsZHNcIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0U2hvd0NvbmZpcm0odHJ1ZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGZldGNoR3JvdXBGb3JFZGl0ID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICAgICAgc2V0TG9hZGluZ0ZldGNoKHRydWUpO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL2dyb3Vwcy8ke2lkfWApO1xyXG4gICAgICAgICAgICBjb25zdCBncm91cCA9IHJlc3BvbnNlLmRhdGE/LmRhdGE7XHJcblxyXG4gICAgICAgICAgICAvLyBGb3JtYXQgZGF0ZXMgZm9yIGlucHV0IGZpZWxkc1xyXG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWRTdGFydERhdGUgPSBncm91cC5zdGFydF9kYXRlPy5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZEVuZERhdGUgPSBncm91cC5lbmRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZ3JvdXAuZ3JvdXBfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBfdHlwZTogZ3JvdXAuZ3JvdXBfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBfdmFsdWU6IGdyb3VwLmdyb3VwX3ZhbHVlIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBncm91cF9pbnN0YWxsOiBncm91cC5ncm91cF9pbnN0YWxsIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBncm91cF9tZW1iZXJzOiBncm91cC5ncm91cF9tZW1iZXJzIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBncm91cF9kdXJhdGlvbjogZ3JvdXAuZ3JvdXBfZHVyYXRpb24gfHwgXCJcIixcclxuICAgICAgICAgICAgICAgIHN0YXJ0X2RhdGVfdHlwZTogZ3JvdXAuc3RhcnRfZGF0ZV90eXBlIHx8IFwiZml4ZWRcIixcclxuICAgICAgICAgICAgICAgIHN0YXJ0X2RhdGU6IGZvcm1hdHRlZFN0YXJ0RGF0ZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgZW5kX2RhdGU6IGZvcm1hdHRlZEVuZERhdGUgfHwgXCJcIixcclxuICAgICAgICAgICAgICAgIG1pbmltdW1fYmlkOiBncm91cC5taW5pbXVtX2JpZCB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgbWF4aW11bV9iaWQ6IGdyb3VwLm1heGltdW1fYmlkIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBjb21taXNzaW9uOiBncm91cC5jb21taXNzaW9uIHx8IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBfY29tbWlzc2lvbjogZ3JvdXAuZ3JvdXBfY29tbWlzc2lvbiB8fCBcIjVcIixcclxuICAgICAgICAgICAgICAgIGluY2VudGl2ZXM6IGdyb3VwLmluY2VudGl2ZXMgfHwgXCIxXCIsXHJcbiAgICAgICAgICAgICAgICByZWdfZmVlOiBncm91cC5yZWdfZmVlIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBtb250aGx5X2luc3RhbGxtZW50OiBncm91cC5tb250aGx5X2luc3RhbGxtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICB3ZWVrbHlfaW5zdGFsbG1lbnQ6IGdyb3VwLndlZWtseV9pbnN0YWxsbWVudCB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgZGFpbHlfaW5zdGFsbG1lbnQ6IGdyb3VwLmRhaWx5X2luc3RhbGxtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICByZWxhdGlvbnNoaXBfbWFuYWdlcjogdHlwZW9mIGdyb3VwLnJlbGF0aW9uc2hpcF9tYW5hZ2VyID09PSAnb2JqZWN0J1xyXG4gICAgICAgICAgICAgICAgICAgID8gZ3JvdXAucmVsYXRpb25zaGlwX21hbmFnZXI/Ll9pZFxyXG4gICAgICAgICAgICAgICAgICAgIDogZ3JvdXAucmVsYXRpb25zaGlwX21hbmFnZXIgfHwgXCJcIixcclxuICAgICAgICAgICAgICAgIGFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0OiBncm91cC5hcHBfZGlzcGxheV92YWNhbnlfc2VhdCB8fCBudWxsLFxyXG4gICAgICAgICAgICAgICAgYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGU6IGdyb3VwLmF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBhdWN0aW9uX21vZGU6IGdyb3VwLmF1Y3Rpb25fbW9kZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIC8vIFByZWZpbGwgcHJlZml4ZWQgYXVjdGlvbiBlbnRyaWVzIGlmIHRoZXkgZXhpc3RcclxuICAgICAgICAgICAgaWYgKGdyb3VwLnByZWZpeGVkX2F1Y3Rpb25fZW50cmllcyAmJiBBcnJheS5pc0FycmF5KGdyb3VwLnByZWZpeGVkX2F1Y3Rpb25fZW50cmllcykpIHtcclxuICAgICAgICAgICAgICAgIC8vIEVuc3VyZSBjb21tZW5jZW1lbnQgaXMgZmlyc3QgKG9wdGlvbmFsIGJ1dCBnb29kKVxyXG4gICAgICAgICAgICAgICAgY29uc3Qgc29ydGVkID0gWy4uLmdyb3VwLnByZWZpeGVkX2F1Y3Rpb25fZW50cmllc10uc29ydCgoYSwgYikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhLmF1Y3Rpb25fc3RhZ2VfdHlwZSA9PT0gXCJDT01NRU5DRU1FTlRcIikgcmV0dXJuIC0xO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChiLmF1Y3Rpb25fc3RhZ2VfdHlwZSA9PT0gXCJDT01NRU5DRU1FTlRcIikgcmV0dXJuIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDA7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlbnVtYmVyZWQgPSByZW51bWJlckF1Y3Rpb25FbnRyaWVzKHNvcnRlZCk7XHJcbiAgICAgICAgICAgICAgICBzZXRQcmVmaXhlZEF1Y3Rpb25FbnRyaWVzKHJlbnVtYmVyZWQpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgc2V0UHJlZml4ZWRBdWN0aW9uRW50cmllcyhbXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZm9yIGVkaXQ6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgZ3JvdXAgZGF0YSBmb3IgZWRpdGluZ1wiLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nRmV0Y2goZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gQXV0by1jYWxjdWxhdGUgYXVjdGlvbiBmaWVsZHMgd2hlbiBiaWRfYW1vdW50IG9yIGJpZF9wZXJjZW50YWdlIGNoYW5nZXNcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBWYWx1ZSA9IHBhcnNlRmxvYXQoZm9ybURhdGEuZ3JvdXBfdmFsdWUpIHx8IDA7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBDb21taXNzaW9uUGN0ID0gcGFyc2VGbG9hdChmb3JtRGF0YS5ncm91cF9jb21taXNzaW9uKSB8fCAwO1xyXG4gICAgICAgIGNvbnN0IGdyb3VwTWVtYmVycyA9IHBhcnNlRmxvYXQoZm9ybURhdGEuZ3JvdXBfbWVtYmVycykgfHwgMDtcclxuICAgICAgICBjb25zdCBncm91cEluc3RhbGwgPSBwYXJzZUZsb2F0KGZvcm1EYXRhLmdyb3VwX2luc3RhbGwpIHx8IDA7XHJcblxyXG4gICAgICAgIC8vIEdldCBjdXJyZW50IGJpZCB2YWx1ZXNcclxuICAgICAgICBsZXQgYmlkQW1vdW50ID0gcGFyc2VGbG9hdChjdXJyZW50QXVjdGlvbkVudHJ5LmJpZF9hbW91bnQpIHx8IDA7XHJcbiAgICAgICAgbGV0IGJpZFBlcmNlbnQgPSBwYXJzZUZsb2F0KGN1cnJlbnRBdWN0aW9uRW50cnkuYmlkX3BlcmNlbnRhZ2UpIHx8IDA7XHJcblxyXG4gICAgICAgIGlmIChiaWRBbW91bnQgPT09IDAgJiYgYmlkUGVyY2VudCA9PT0gMCkge1xyXG4gICAgICAgICAgICBpZiAoY3VycmVudEF1Y3Rpb25FbnRyeS5jb21taXNzaW9uICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICBzZXRDdXJyZW50QXVjdGlvbkVudHJ5KHByZXYgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgd2luX2Ftb3VudDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICBkaXZpZGVudDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICBkaXZpZGVudF9oZWFkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHBheWFibGU6IFwiXCJcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZ3JvdXBWYWx1ZSA9PT0gMCkgcmV0dXJuO1xyXG4gICAgICAgIGxldCBmaW5hbEJpZEFtb3VudCA9IGJpZEFtb3VudDtcclxuICAgICAgICBsZXQgZmluYWxCaWRQZXJjZW50ID0gYmlkUGVyY2VudDtcclxuICAgICAgICBpZiAoYmlkQW1vdW50ID4gMCAmJiBiaWRQZXJjZW50ID09PSAwKSB7XHJcbiAgICAgICAgICAgIGZpbmFsQmlkUGVyY2VudCA9IChiaWRBbW91bnQgLyBncm91cFZhbHVlKSAqIDEwMDtcclxuICAgICAgICB9IGVsc2UgaWYgKGJpZFBlcmNlbnQgPiAwICYmIGJpZEFtb3VudCA9PT0gMCkge1xyXG4gICAgICAgICAgICBmaW5hbEJpZEFtb3VudCA9IChiaWRQZXJjZW50IC8gMTAwKSAqIGdyb3VwVmFsdWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gQm90aCBub24temVybzoga2VlcCBhbW91bnQgYXMgbWFzdGVyLCByZWNhbGMgcGVyY2VudGFnZVxyXG4gICAgICAgICAgICBmaW5hbEJpZFBlcmNlbnQgPSAoYmlkQW1vdW50IC8gZ3JvdXBWYWx1ZSkgKiAxMDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChiaWRQZXJjZW50ID4gMCAmJiBiaWRBbW91bnQgPT09IDApIHtcclxuICAgICAgICAgICAgYmlkQW1vdW50ID0gKGJpZFBlcmNlbnQgLyAxMDApICogZ3JvdXBWYWx1ZTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEF1Y3Rpb25FbnRyeShwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgYmlkX2Ftb3VudDogYmlkQW1vdW50LnRvRml4ZWQoMilcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGNvbW1pc3Npb24gPSAoZ3JvdXBWYWx1ZSAqIGdyb3VwQ29tbWlzc2lvblBjdCkgLyAxMDA7XHJcbiAgICAgICAgY29uc3Qgd2luQW1vdW50ID0gZ3JvdXBWYWx1ZSAtIGJpZEFtb3VudDtcclxuICAgICAgICBjb25zdCBkaXZpZGVudCA9IGJpZEFtb3VudCAtIGNvbW1pc3Npb247XHJcbiAgICAgICAgY29uc3QgZGl2aWRlbnRIZWFkID0gZ3JvdXBNZW1iZXJzID4gMCA/IGRpdmlkZW50IC8gZ3JvdXBNZW1iZXJzIDogMDtcclxuICAgICAgICBjb25zdCBwYXlhYmxlID0gZ3JvdXBJbnN0YWxsIC0gZGl2aWRlbnRIZWFkO1xyXG5cclxuICAgICAgICBzZXRDdXJyZW50QXVjdGlvbkVudHJ5KHByZXYgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgY29tbWlzc2lvbjogY29tbWlzc2lvbi50b0ZpeGVkKDIpLFxyXG4gICAgICAgICAgICB3aW5fYW1vdW50OiB3aW5BbW91bnQudG9GaXhlZCgyKSxcclxuICAgICAgICAgICAgZGl2aWRlbnQ6IGRpdmlkZW50LnRvRml4ZWQoMiksXHJcbiAgICAgICAgICAgIGJpZF9wZXJjZW50YWdlOiBmaW5hbEJpZFBlcmNlbnQudG9GaXhlZCgyKSxcclxuICAgICAgICAgICAgZGl2aWRlbnRfaGVhZDogZGl2aWRlbnRIZWFkLnRvRml4ZWQoMiksXHJcbiAgICAgICAgICAgIHBheWFibGU6IHBheWFibGUudG9GaXhlZCgyKVxyXG4gICAgICAgIH0pKTtcclxuICAgIH0sIFtcclxuICAgICAgICBjdXJyZW50QXVjdGlvbkVudHJ5LmJpZF9hbW91bnQsXHJcbiAgICAgICAgY3VycmVudEF1Y3Rpb25FbnRyeS5iaWRfcGVyY2VudGFnZSxcclxuICAgICAgICBmb3JtRGF0YS5ncm91cF92YWx1ZSxcclxuICAgICAgICBmb3JtRGF0YS5ncm91cF9jb21taXNzaW9uLFxyXG4gICAgICAgIGZvcm1EYXRhLmdyb3VwX21lbWJlcnMsXHJcbiAgICAgICAgZm9ybURhdGEuZ3JvdXBfaW5zdGFsbFxyXG4gICAgXSk7XHJcblxyXG4gICAgLy8gQXV0by1zZXQgbmV4dF9kYXRlID0gYXVjdGlvbl9kYXRlICsgMTAgZGF5c1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoY3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX2RhdGUpIHtcclxuICAgICAgICAgICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGN1cnJlbnRBdWN0aW9uRW50cnkuYXVjdGlvbl9kYXRlKTtcclxuICAgICAgICAgICAgaWYgKCFpc05hTihkYXRlLmdldFRpbWUoKSkpIHtcclxuICAgICAgICAgICAgICAgIGRhdGUuc2V0RGF0ZShkYXRlLmdldERhdGUoKSArIDEwKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG5leHREYXRlID0gZGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF07XHJcbiAgICAgICAgICAgICAgICBzZXRDdXJyZW50QXVjdGlvbkVudHJ5KHByZXYgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgIG5leHRfZGF0ZTogbmV4dERhdGVcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sIFtjdXJyZW50QXVjdGlvbkVudHJ5LmF1Y3Rpb25fZGF0ZV0pO1xyXG5cclxuICAgIC8vIEF1dG8tc2V0IG5leHRfYXVjdGlvbl90aW1lID0gYXVjdGlvbl90aW1lICh1c2VyIGNhbiBzdGlsbCBlZGl0IG1hbnVhbGx5KVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoY3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX3RpbWUpIHtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEF1Y3Rpb25FbnRyeShwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgbmV4dF9hdWN0aW9uX3RpbWU6IHByZXYuYXVjdGlvbl90aW1lXHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbY3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX3RpbWVdKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKTtcclxuICAgICAgICBjb25zdCBlZGl0UGFyYW0gPSBwYXJhbXMuZ2V0KFwiZWRpdFwiKTtcclxuICAgICAgICBjb25zdCBpZFBhcmFtID0gcGFyYW1zLmdldChcImdyb3VwSWRcIik7XHJcblxyXG4gICAgICAgIGlmIChlZGl0UGFyYW0gPT09IFwidHJ1ZVwiICYmIGlkUGFyYW0pIHtcclxuICAgICAgICAgICAgc2V0SXNFZGl0TW9kZSh0cnVlKTtcclxuICAgICAgICAgICAgc2V0R3JvdXBJZChpZFBhcmFtKTtcclxuICAgICAgICAgICAgZmV0Y2hHcm91cEZvckVkaXQoaWRQYXJhbSk7XHJcbiAgICAgICAgICAgIHJlc2V0QXVjdGlvbkVudHJ5Rm9ybSgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sIFtsb2NhdGlvbi5zZWFyY2hdKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGFzeW5jIGZ1bmN0aW9uIGdldEVtcGxveWVlcygpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlLmRhdGE/LmVtcGxveWVlO1xyXG4gICAgICAgICAgICAgICAgc2V0RW1wbG95ZWVzKHJlc3BvbnNlRGF0YSA/IHJlc3BvbnNlRGF0YSA6IFtdKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIHNldEVtcGxveWVlcyhbXSk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIEZldGNoaW5nIEVtcGxveWVlc1wiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBnZXRFbXBsb3llZXMoKTtcclxuICAgIH0sIFtdKTtcclxuXHJcbiAgICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAodHlwZSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBmb3JtRGF0YTtcclxuXHJcbiAgICAgICAgaWYgKCFkYXRhLmdyb3VwX25hbWU/LnRyaW0oKSkgbmV3RXJyb3JzLmdyb3VwX25hbWUgPSBcIkdyb3VwIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICBpZiAoIWRhdGEuZ3JvdXBfdHlwZSkgbmV3RXJyb3JzLmdyb3VwX3R5cGUgPSBcIkdyb3VwIFR5cGUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICBpZiAoIWRhdGEuZ3JvdXBfdmFsdWUpIG5ld0Vycm9ycy5ncm91cF92YWx1ZSA9IFwiR3JvdXAgVmFsdWUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICBpZiAoIWRhdGEuZ3JvdXBfaW5zdGFsbCkgbmV3RXJyb3JzLmdyb3VwX2luc3RhbGwgPSBcIkdyb3VwIEluc3RhbGxtZW50IEFtb3VudCBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5ncm91cF9tZW1iZXJzKSBuZXdFcnJvcnMuZ3JvdXBfbWVtYmVycyA9IFwiR3JvdXAgTWVtYmVycyBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5yZWxhdGlvbnNoaXBfbWFuYWdlcikgbmV3RXJyb3JzLnJlbGF0aW9uc2hpcF9tYW5hZ2VyID0gXCJSZWxhdGlvbnNoaXAgTWFuYWdlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5tb250aGx5X2luc3RhbGxtZW50KSBuZXdFcnJvcnMubW9udGhseV9pbnN0YWxsbWVudCA9IFwiTW9udGhseSBJbnN0YWxsbWVudCBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS53ZWVrbHlfaW5zdGFsbG1lbnQpIG5ld0Vycm9ycy53ZWVrbHlfaW5zdGFsbG1lbnQgPSBcIldlZWtseSBJbnN0YWxsbWVudCBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5kYWlseV9pbnN0YWxsbWVudCkgbmV3RXJyb3JzLmRhaWx5X2luc3RhbGxtZW50ID0gXCJEYWlseSBJbnN0YWxsbWVudCBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5ncm91cF9kdXJhdGlvbikgbmV3RXJyb3JzLmdyb3VwX2R1cmF0aW9uID0gXCJHcm91cCBEdXJhdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5yZWdfZmVlKSBuZXdFcnJvcnMucmVnX2ZlZSA9IFwiUmVnaXN0cmF0aW9uIEZlZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5zdGFydF9kYXRlKSBuZXdFcnJvcnMuc3RhcnRfZGF0ZSA9IFwiU3RhcnQgRGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5lbmRfZGF0ZSkgbmV3RXJyb3JzLmVuZF9kYXRlID0gXCJFbmQgRGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5hcHBfZGlzcGxheV92YWNhbnlfc2VhdCkgbmV3RXJyb3JzLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0ID0gXCJQbGVhc2UgRW50ZXIgRGlzcGxheSBWYWNhbnQgU2VhdFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5zdGFydF9kYXRlX3R5cGUpIG5ld0Vycm9ycy5zdGFydF9kYXRlX3R5cGUgPSBcIlBsZWFzZSBzZWxlY3QgdGhlIFN0YXJ0IGRhdGUgVHlwZVwiO1xyXG4gICAgICAgIGlmIChmb3JtRGF0YS5lbmRfZGF0ZSAmJiAhZGF0YS5lbmRfZGF0ZSkgbmV3RXJyb3JzLmVuZF9kYXRlID0gXCJFbmQgRGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGVsc2UgaWYgKGZvcm1EYXRhLmVuZF9kYXRlICYmIG5ldyBEYXRlKGRhdGEuZW5kX2RhdGUpIDwgbmV3IERhdGUoZGF0YS5zdGFydF9kYXRlKSlcclxuICAgICAgICAgICAgbmV3RXJyb3JzLmVuZF9kYXRlID0gXCJFbmQgRGF0ZSBjYW5ub3QgYmUgZWFybGllciB0aGFuIFN0YXJ0IERhdGVcIjtcclxuICAgICAgICBpZiAoIWRhdGEubWluaW11bV9iaWQpIG5ld0Vycm9ycy5taW5pbXVtX2JpZCA9IFwiTWluaW11bSBCaWQgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICBpZiAoIWRhdGEubWF4aW11bV9iaWQpIG5ld0Vycm9ycy5tYXhpbXVtX2JpZCA9IFwiTWF4aW11bSBCaWQgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICBlbHNlIGlmIChwYXJzZUZsb2F0KGRhdGEubWF4aW11bV9iaWQpIDwgcGFyc2VGbG9hdChkYXRhLm1pbmltdW1fYmlkKSlcclxuICAgICAgICAgICAgbmV3RXJyb3JzLm1heGltdW1fYmlkID0gXCJNYXhpbXVtIEJpZCBtdXN0IGJlIGdyZWF0ZXIgdGhhbiBvciBlcXVhbCB0byBNaW5pbXVtIEJpZFwiO1xyXG5cclxuICAgICAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgICB9O1xyXG5cclxuXHJcblxyXG4gICAgLy8gY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgLy8gICAgIHRyeSB7XHJcbiAgICAvLyAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAvLyAgICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAvLyAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgIC8vICAgICAgICAgICAgIHByZWZpeGVkX2F1Y3Rpb25fZW50cmllczogcHJlZml4ZWRBdWN0aW9uRW50cmllc1xyXG4gICAgLy8gICAgICAgICB9O1xyXG4gICAgLy8gICAgICAgICBhd2FpdCBhcGkucG9zdChcIi92MS9hZG1pbi9ncm91cHMvXCIsIHBheWxvYWQsIHtcclxuICAgIC8vICAgICAgICAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcclxuICAgIC8vICAgICAgICAgfSk7XHJcbiAgICAvLyAgICAgICAgIHNldFNob3dDb25maXJtKGZhbHNlKTtcclxuICAgIC8vICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG5cclxuICAgIC8vICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgLy8gICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgIC8vICAgICAgICAgICAgIG1lc3NhZ2U6IFwiR3JvdXAgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAvLyAgICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgIC8vICAgICAgICAgfSk7XHJcblxyXG4gICAgLy8gICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAvLyAgICAgICAgICAgICBncm91cF9uYW1lOiBcIlwiLCBncm91cF90eXBlOiBcIlwiLCBncm91cF92YWx1ZTogXCJcIiwgZ3JvdXBfaW5zdGFsbDogXCJcIixcclxuICAgIC8vICAgICAgICAgICAgIGdyb3VwX21lbWJlcnM6IFwiXCIsIGdyb3VwX2R1cmF0aW9uOiBcIlwiLCBzdGFydF9kYXRlX3R5cGU6IFwiZml4ZWRcIixcclxuICAgIC8vICAgICAgICAgICAgIHN0YXJ0X2RhdGU6IFwiXCIsIGVuZF9kYXRlOiBcIlwiLCBtaW5pbXVtX2JpZDogXCJcIiwgbWF4aW11bV9iaWQ6IFwiXCIsXHJcbiAgICAvLyAgICAgICAgICAgICBjb21taXNzaW9uOiBcIlwiLCBpbmNlbnRpdmVzOiBcIlwiLCByZWxhdGlvbnNoaXBfbWFuYWdlcjogXCJcIixcclxuICAgIC8vICAgICAgICAgICAgIG1vbnRobHlfaW5zdGFsbG1lbnQ6IFwiXCIsIHdlZWtseV9pbnN0YWxsbWVudDogXCJcIiwgZGFpbHlfaW5zdGFsbG1lbnQ6IFwiXCIsXHJcbiAgICAvLyAgICAgICAgICAgICByZWdfZmVlOiBcIlwiLCBhcHBfZGlzcGxheV92YWNhbnlfc2VhdDogXCJcIiwgYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGU6IFwiXCIsXHJcbiAgICAvLyAgICAgICAgICAgICBhdWN0aW9uX21vZGU6IFwiXCIsIGdyb3VwX2NvbW1pc3Npb246IFwiNVwiLFxyXG4gICAgLy8gICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAgc2V0UHJlZml4ZWRBdWN0aW9uRW50cmllcyhbXSk7XHJcblxyXG4gICAgLy8gICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIHdpbmRvdy5jbG9zZSgpO1xyXG4gICAgLy8gICAgICAgICB9LCAyMDAwKTtcclxuICAgIC8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICAvLyAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgIC8vICAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAvLyAgICAgICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBhZGQgZ3JvdXBcIixcclxuICAgIC8vICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgIC8vICAgICAgICAgfSk7XHJcbiAgICAvLyAgICAgfSBmaW5hbGx5IHtcclxuICAgIC8vICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gfTtcclxuICAgIGNvbnN0IHJlc2V0QXVjdGlvbkVudHJ5Rm9ybSA9ICgpID0+IHtcclxuICAgICAgICBjb25zdCBtYXhOdW1iZXIgPSBwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgPyBNYXRoLm1heCguLi5wcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLm1hcChlID0+IE51bWJlcihlLmF1Y3Rpb25fbnVtYmVyKSB8fCAwKSlcclxuICAgICAgICAgICAgOiAwO1xyXG4gICAgICAgIHNldEN1cnJlbnRBdWN0aW9uRW50cnkoe1xyXG4gICAgICAgICAgICBhdWN0aW9uX3RpbWU6IFwiMTA6MDAgQU1cIixcclxuICAgICAgICAgICAgbmV4dF9hdWN0aW9uX3RpbWU6IFwiMTE6MDAgQU1cIixcclxuICAgICAgICAgICAgYmlkX3BlcmNlbnRhZ2U6IFwiXCIsXHJcbiAgICAgICAgICAgIGJpZF9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICAgICAgICAgIHdpbl9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGRpdmlkZW50OiBcIlwiLFxyXG4gICAgICAgICAgICBkaXZpZGVudF9oZWFkOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlhYmxlOiBcIlwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGU6IFwiXCIsXHJcbiAgICAgICAgICAgIG5leHRfZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgYXVjdGlvbl90eXBlOiBcIk5PUk1BTFwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX3N0YWdlX3R5cGU6IFwiQVVDVElPTlwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX251bWJlcjogbWF4TnVtYmVyICsgMSxcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQWRkT3JVcGRhdGVBdWN0aW9uRW50cnkgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAhY3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX2RhdGUgfHxcclxuICAgICAgICAgICAgIWN1cnJlbnRBdWN0aW9uRW50cnkuYXVjdGlvbl90aW1lXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBmaWxsIGF0IGxlYXN0IHRoZSBEYXRlIGFuZCBUaW1lLlwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgZXhpc3RpbmdDb21tZW5jZW1lbnQgPSBwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLnNvbWUoXHJcbiAgICAgICAgICAgIChlbnRyeSkgPT4gZW50cnkuYXVjdGlvbl9zdGFnZV90eXBlID09PSBcIkNPTU1FTkNFTUVOVFwiXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICBjdXJyZW50QXVjdGlvbkVudHJ5LmF1Y3Rpb25fc3RhZ2VfdHlwZSA9PT0gXCJDT01NRU5DRU1FTlRcIiAmJlxyXG4gICAgICAgICAgICBleGlzdGluZ0NvbW1lbmNlbWVudCAmJlxyXG4gICAgICAgICAgICBlZGl0aW5nSW5kZXggPT09IG51bGxcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiT25seSBvbmUgQ29tbWVuY2VtZW50IGVudHJ5IGlzIGFsbG93ZWQgcGVyIGdyb3VwLlwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgbmV3RW50cnkgPSB7IC4uLmN1cnJlbnRBdWN0aW9uRW50cnkgfTtcclxuXHJcbiAgICAgICAgLy8gRURJVFxyXG4gICAgICAgIGlmIChlZGl0aW5nSW5kZXggIT09IG51bGwpIHtcclxuICAgICAgICAgICAgY29uc3QgdXBkYXRlZExpc3QgPSBbLi4ucHJlZml4ZWRBdWN0aW9uRW50cmllc107XHJcblxyXG4gICAgICAgICAgICB1cGRhdGVkTGlzdFtlZGl0aW5nSW5kZXhdID0ge1xyXG4gICAgICAgICAgICAgICAgLi4ubmV3RW50cnksXHJcbiAgICAgICAgICAgICAgICBhdWN0aW9uX251bWJlcjpcclxuICAgICAgICAgICAgICAgICAgICBuZXdFbnRyeS5hdWN0aW9uX3N0YWdlX3R5cGUgPT09IFwiQ09NTUVOQ0VNRU5UXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzW2VkaXRpbmdJbmRleF0uYXVjdGlvbl9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBuZXdFbnRyeS5hdWN0aW9uX251bWJlcixcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHNldFByZWZpeGVkQXVjdGlvbkVudHJpZXModXBkYXRlZExpc3QpO1xyXG4gICAgICAgICAgICBzZXRFZGl0aW5nSW5kZXgobnVsbCk7XHJcblxyXG4gICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJFbnRyeSB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIEFERFxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zdCBuZXh0TnVtYmVyID0gcHJlZml4ZWRBdWN0aW9uRW50cmllcy5sZW5ndGggKyAxO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgZmluYWxFbnRyeSA9IHtcclxuICAgICAgICAgICAgICAgIC4uLm5ld0VudHJ5LFxyXG4gICAgICAgICAgICAgICAgYXVjdGlvbl9udW1iZXI6IG5leHROdW1iZXIsXHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBzZXRQcmVmaXhlZEF1Y3Rpb25FbnRyaWVzKFtcclxuICAgICAgICAgICAgICAgIC4uLnByZWZpeGVkQXVjdGlvbkVudHJpZXMsXHJcbiAgICAgICAgICAgICAgICBmaW5hbEVudHJ5LFxyXG4gICAgICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIkVudHJ5IGFkZGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIFJlc2V0IGZvcm1cclxuICAgICAgICBjb25zdCBuZXh0TnVtYmVyQWZ0ZXJBZGQgPSBwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLmxlbmd0aCArIDI7XHJcblxyXG4gICAgICAgIHNldEN1cnJlbnRBdWN0aW9uRW50cnkoe1xyXG4gICAgICAgICAgICBhdWN0aW9uX3RpbWU6IFwiMTA6MDBcIixcclxuICAgICAgICAgICAgbmV4dF9hdWN0aW9uX3RpbWU6IFwiMTE6MDBcIixcclxuICAgICAgICAgICAgYmlkX3BlcmNlbnRhZ2U6IFwiXCIsXHJcbiAgICAgICAgICAgIGJpZF9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICAgICAgICAgIHdpbl9hbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGRpdmlkZW50OiBcIlwiLFxyXG4gICAgICAgICAgICBkaXZpZGVudF9oZWFkOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlhYmxlOiBcIlwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGU6IFwiXCIsXHJcbiAgICAgICAgICAgIG5leHRfZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgYXVjdGlvbl90eXBlOiBcIk5PUk1BTFwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX3N0YWdlX3R5cGU6IFwiQVVDVElPTlwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX251bWJlcjogbmV4dE51bWJlckFmdGVyQWRkLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcblxyXG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgICAgIGxldCByZXNwb25zZTtcclxuICAgICAgICAgICAgaWYgKGlzRWRpdE1vZGUgJiYgZ3JvdXBJZCkge1xyXG4gICAgICAgICAgICAgICAgLy8gVXBkYXRlIGV4aXN0aW5nIGdyb3VwXHJcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVQYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgIHByZWZpeGVkX2F1Y3Rpb25fZW50cmllczogcHJlZml4ZWRBdWN0aW9uRW50cmllcyxcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoYC92MS9hZG1pbi9ncm91cHMvJHtncm91cElkfWAsIHVwZGF0ZVBheWxvYWQsIHtcclxuICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiR3JvdXAgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8gQWRkIG5ldyBncm91cFxyXG4gICAgICAgICAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICBwcmVmaXhlZF9hdWN0aW9uX2VudHJpZXM6IHByZWZpeGVkQXVjdGlvbkVudHJpZXMsXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi92MS9hZG1pbi9ncm91cHMvXCIsIHBheWxvYWQsIHtcclxuICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiR3JvdXAgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgc2V0U2hvd0NvbmZpcm0oZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcblxyXG4gICAgICAgICAgICAvLyDinIUgUmVmcmVzaCB0aGUgcGFyZW50IEdyb3VwcyB0YWJsZVxyXG4gICAgICAgICAgICBpZiAod2luZG93Lm9wZW5lciAmJiB3aW5kb3cub3BlbmVyLnJlZnJlc2hHcm91cHMpIHtcclxuICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuZXIucmVmcmVzaEdyb3VwcygpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBSZXNldCBmb3JtIGlmIGFkZCBtb2RlLCBvdGhlcndpc2UgY2xvc2UgdGFiIGFmdGVyIGRlbGF5XHJcbiAgICAgICAgICAgIGlmICghaXNFZGl0TW9kZSkge1xyXG4gICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwX25hbWU6IFwiXCIsIGdyb3VwX3R5cGU6IFwiXCIsIGdyb3VwX3ZhbHVlOiBcIlwiLCBncm91cF9pbnN0YWxsOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwX21lbWJlcnM6IFwiXCIsIGdyb3VwX2R1cmF0aW9uOiBcIlwiLCBzdGFydF9kYXRlX3R5cGU6IFwiZml4ZWRcIixcclxuICAgICAgICAgICAgICAgICAgICBzdGFydF9kYXRlOiBcIlwiLCBlbmRfZGF0ZTogXCJcIiwgbWluaW11bV9iaWQ6IFwiXCIsIG1heGltdW1fYmlkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb246IFwiXCIsIGluY2VudGl2ZXM6IFwiXCIsIHJlbGF0aW9uc2hpcF9tYW5hZ2VyOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIG1vbnRobHlfaW5zdGFsbG1lbnQ6IFwiXCIsIHdlZWtseV9pbnN0YWxsbWVudDogXCJcIiwgZGFpbHlfaW5zdGFsbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcmVnX2ZlZTogXCJcIiwgYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQ6IFwiXCIsIGF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGF1Y3Rpb25fbW9kZTogXCJcIiwgZ3JvdXBfY29tbWlzc2lvbjogXCI1XCIsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHNldFByZWZpeGVkQXVjdGlvbkVudHJpZXMoW10pO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChpc0VkaXRNb2RlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2luZG93LmNsb3NlKCk7IC8vIE9wdGlvbmFsOiBjbG9zZSB0YWIgYWZ0ZXIgdXBkYXRlXHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5jbG9zZSgpOyAvLyBvciBrZWVwIG9wZW4gZm9yIGFub3RoZXIgZW50cnlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgMjAwMCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNhdmluZyBncm91cDpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgKGlzRWRpdE1vZGUgPyBcIkZhaWxlZCB0byB1cGRhdGUgZ3JvdXBcIiA6IFwiRmFpbGVkIHRvIGFkZCBncm91cFwiKSxcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcblxyXG4gICAgLy8g4pyFIFByZXBhcmUgc2FmZSBkYXRhIGZvciBjb25maXJtYXRpb24gbW9kYWwgKG5vIG5lc3RlZCBvYmplY3RzL2FycmF5cylcclxuICAgIGNvbnN0IGNvbmZpcm1EYXRhID0ge1xyXG4gICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgIC8vIFByb3ZpZGUgYSBzdW1tYXJ5IG9mIGF1Y3Rpb24gZW50cmllcyBpbnN0ZWFkIG9mIHRoZSBmdWxsIGFycmF5XHJcbiAgICAgICAgYXVjdGlvbl9lbnRyaWVzX2NvdW50OiBwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLmxlbmd0aCxcclxuICAgICAgICBhdWN0aW9uX2VudHJpZXNfc3VtbWFyeTogcHJlZml4ZWRBdWN0aW9uRW50cmllcy5tYXAoZSA9PlxyXG4gICAgICAgICAgICBgIyR7ZS5hdWN0aW9uX251bWJlcn0gKCR7ZS5hdWN0aW9uX2RhdGUgfHwgXCJubyBkYXRlXCJ9KWBcclxuICAgICAgICApLmpvaW4oXCIsIFwiKVxyXG4gICAgfTtcclxuICAgIC8vIFJlbW92ZSBhbnkgbGVmdG92ZXIgbm9uLXByaW1pdGl2ZSB2YWx1ZXMgKHRob3VnaCB3ZSBhbHJlYWR5IHJlbW92ZWQgcmVsYXRpb25zaGlwX21hbmFnZXJfc2VsZWN0KVxyXG4gICAgLy8gRW5zdXJlIGFsbCB2YWx1ZXMgYXJlIHByaW1pdGl2ZXNcclxuICAgIGNvbnN0IHNhbml0aXplZENvbmZpcm1EYXRhID0gT2JqZWN0LmVudHJpZXMoY29uZmlybURhdGEpLnJlZHVjZSgoYWNjLCBba2V5LCB2YWx1ZV0pID0+IHtcclxuICAgICAgICBpZiAodmFsdWUgPT09IG51bGwgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICBhY2Nba2V5XSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gYWNjO1xyXG4gICAgfSwge30pO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUVkaXRFbnRyeSA9IChpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGVudHJ5ID0gcHJlZml4ZWRBdWN0aW9uRW50cmllc1tpbmRleF07XHJcbiAgICAgICAgc2V0Q3VycmVudEF1Y3Rpb25FbnRyeShlbnRyeSk7XHJcbiAgICAgICAgc2V0RWRpdGluZ0luZGV4KGluZGV4KTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGp1c3RpZnktY2VudGVyIHAtNVwiPlxyXG4gICAgICAgICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWxlcnRDb25maWcocHJldiA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy00eGwgYmctd2hpdGUgcm91bmRlZCBzaGFkb3ctbGcgb3ZlcmZsb3ctaGlkZGVuXCIgb25TdWJtaXQ9e2hhbmRsZVJlY29uZmlybWF0aW9ufSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYi0yIGJvcmRlci1ibHVlLTkwMCBwLTYgbWItNiBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ibHVlLTkwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBHcm91cCBOYW1lICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+R3JvdXAgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwiZ3JvdXBfbmFtZVwiIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfbmFtZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgR3JvdXAgTmFtZVwiIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX25hbWUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnM/Lmdyb3VwX25hbWV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+R3JvdXAgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIFR5cGVcIiB2YWx1ZT17Zm9ybURhdGE/Lmdyb3VwX3R5cGUgfHwgdW5kZWZpbmVkfSBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZ3JvdXBfdHlwZVwiLCB2YWx1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJEaXZpZGVudFwiLCBcIkRvdWJsZVwiLCBcIkZpeGVkLURpdmlkZW50XCIsIFwiRml4ZWQtRG91YmxlXCJdLm1hcCgoZ1R5cGUpID0+ICg8U2VsZWN0Lk9wdGlvbiBrZXk9e2dUeXBlfSB2YWx1ZT17Z1R5cGUudG9Mb3dlckNhc2UoKX0+e2dUeXBlfTwvU2VsZWN0Lk9wdGlvbj4pKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF90eXBlICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzLmdyb3VwX3R5cGV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5SZWxhdGlvbnNoaXAgTWFuYWdlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUk1cIiBzaG93U2VhcmNoIHZhbHVlPXtmb3JtRGF0YT8ucmVsYXRpb25zaGlwX21hbmFnZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJyZWxhdGlvbnNoaXBfbWFuYWdlclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhBcnJheS5pc0FycmF5KGVtcGxveWVlcykgPyBlbXBsb3llZXMgOiBbXSkubWFwKChlbXBsb3llZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcGxveWVlPy5faWR9IHZhbHVlPXtlbXBsb3llZT8uX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZT8ubmFtZX0gfCB7ZW1wbG95ZWU/LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlbGF0aW9uc2hpcF9tYW5hZ2VyICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzLnJlbGF0aW9uc2hpcF9tYW5hZ2VyfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkFwcCBEaXNwbGF5IFZhY2FuY3kgU2VhdCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBuYW1lPVwiYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXRcIiBwbGFjZWhvbGRlcj1cIkVudGVyIEFwcCBEaXNwbGF5IFZhY2FuY3kgU2VhdFwiIHZhbHVlPXtmb3JtRGF0YT8uYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXR9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEyIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0ICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzPy5hcHBfZGlzcGxheV92YWNhbnlfc2VhdH08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkdyb3VwIFZhbHVlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMFwiIG5hbWU9XCJncm91cF92YWx1ZVwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgVmFsdWVcIiB2YWx1ZT17Zm9ybURhdGE/Lmdyb3VwX3ZhbHVlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMiB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF92YWx1ZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycz8uZ3JvdXBfdmFsdWV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+R3JvdXAgSW5zdGFsbG1lbnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwXCIgbmFtZT1cImdyb3VwX2luc3RhbGxcIiBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIEluc3RhbGxtZW50XCIgdmFsdWU9e2Zvcm1EYXRhPy5ncm91cF9pbnN0YWxsfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMiB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9pbnN0YWxsICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzPy5ncm91cF9pbnN0YWxsfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+R3JvdXAgTWVtYmVycyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBuYW1lPVwiZ3JvdXBfbWVtYmVyc1wiIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgTWVtYmVyc1wiIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfbWVtYmVyc30gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTIgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfbWVtYmVycyAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycz8uZ3JvdXBfbWVtYmVyc308L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5EYWlseSBJbnN0YWxsbWVudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBuYW1lPVwiZGFpbHlfaW5zdGFsbG1lbnRcIiBwbGFjZWhvbGRlcj1cIkVudGVyIERhaWx5IEluc3RhbGxtZW50XCIgdmFsdWU9e2Zvcm1EYXRhPy5kYWlseV9pbnN0YWxsbWVudH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTIgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGFpbHlfaW5zdGFsbG1lbnQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMuZGFpbHlfaW5zdGFsbG1lbnR9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+V2Vla2x5IEluc3RhbGxtZW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD48aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBuYW1lPVwid2Vla2x5X2luc3RhbGxtZW50XCIgcGxhY2Vob2xkZXI9XCJFbnRlciBXZWVrbHkgSW5zdGFsbG1lbnRcIiB2YWx1ZT17Zm9ybURhdGE/LndlZWtseV9pbnN0YWxsbWVudH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTIgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMud2Vla2x5X2luc3RhbGxtZW50ICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzLndlZWtseV9pbnN0YWxsbWVudH08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5Nb250aGx5IEluc3RhbGxtZW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD48aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBuYW1lPVwibW9udGhseV9pbnN0YWxsbWVudFwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgTW9udGhseSBJbnN0YWxsbWVudFwiIHZhbHVlPXtmb3JtRGF0YT8ubW9udGhseV9pbnN0YWxsbWVudH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTIgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubW9udGhseV9pbnN0YWxsbWVudCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5tb250aGx5X2luc3RhbGxtZW50fTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkdyb3VwIER1cmF0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMFwiIG5hbWU9XCJncm91cF9kdXJhdGlvblwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgRHVyYXRpb25cIiB2YWx1ZT17Zm9ybURhdGE/Lmdyb3VwX2R1cmF0aW9ufSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMiB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9kdXJhdGlvbiAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5ncm91cF9kdXJhdGlvbn08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlJlZ2lzdHJhdGlvbiBGZWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwXCIgbmFtZT1cInJlZ19mZWVcIiBwbGFjZWhvbGRlcj1cIkVudGVyIFJlZ2lzdHJhdGlvbiBGZWVcIiB2YWx1ZT17Zm9ybURhdGE/LnJlZ19mZWV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEyIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlZ19mZWUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMucmVnX2ZlZX08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5TdGFydCBkYXRlIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNiBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIGN1cnNvci1wb2ludGVyXCI+PGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJzdGFydF9kYXRlX3R5cGVcIiB2YWx1ZT1cImV4cGVjdGVkXCIgY2hlY2tlZD17Zm9ybURhdGE/LnN0YXJ0X2RhdGVfdHlwZSA9PT0gXCJleHBlY3RlZFwifSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS02MDBcIiAvPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMFwiPkV4cGVjdGVkPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIGN1cnNvci1wb2ludGVyXCI+PGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJzdGFydF9kYXRlX3R5cGVcIiB2YWx1ZT1cImZpeGVkXCIgY2hlY2tlZD17Zm9ybURhdGE/LnN0YXJ0X2RhdGVfdHlwZSA9PT0gXCJmaXhlZFwifSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS02MDBcIiAvPjxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMFwiPkZpeGVkPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXJ0X2RhdGVfdHlwZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5zdGFydF9kYXRlX3R5cGV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+U3RhcnQgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+PGlucHV0IHR5cGU9XCJkYXRlXCIgbmFtZT1cInN0YXJ0X2RhdGVcIiB2YWx1ZT17Zm9ybURhdGE/LnN0YXJ0X2RhdGV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEyIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXJ0X2RhdGUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMuc3RhcnRfZGF0ZX08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5FbmQgRGF0ZTwvbGFiZWw+PGlucHV0IHR5cGU9XCJkYXRlXCIgbmFtZT1cImVuZF9kYXRlXCIgdmFsdWU9e2Zvcm1EYXRhPy5lbmRfZGF0ZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTIgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5kX2RhdGUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMuZW5kX2RhdGV9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PjxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiID5NaW5pbXVtIEJpZCAlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD48aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIiBwbGFjZWhvbGRlcj1cIkVudGVyIE1pbmltdW0gQmlkICVcIiBuYW1lPVwibWluaW11bV9iaWRcIiB2YWx1ZT17Zm9ybURhdGE/Lm1pbmltdW1fYmlkfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMiB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5taW5pbXVtX2JpZH08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj48bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIiA+TWF4aW11bSBCaWQgJSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+PGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwXCIgcGxhY2Vob2xkZXI9XCJFbnRlciBNYXhpbXVtIEJpZCAlXCIgbmFtZT1cIm1heGltdW1fYmlkXCIgdmFsdWU9e2Zvcm1EYXRhPy5tYXhpbXVtX2JpZH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTIgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubWF4aW11bV9iaWQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMubWF4aW11bV9iaWR9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PjxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkFnZW50IENvbW1pc3Npb24gJTwvbGFiZWw+PGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWdlbnQgQ29tbWlzc2lvbiAlXCIgbmFtZT1cImNvbW1pc3Npb25cIiB2YWx1ZT17Zm9ybURhdGE/LmNvbW1pc3Npb259IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEyIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiIC8+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+Q29tcGFueSBDb21taXNzaW9uICU8L2xhYmVsPjxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMFwiIG5hbWU9XCJncm91cF9jb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQ29tcGFueSBDb21taXNzaW9uICVcIiB2YWx1ZT17Zm9ybURhdGE/Lmdyb3VwX2NvbW1pc3Npb259IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEyIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiIC8+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+PGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+RW1wbG95ZWUgSW5jZW50aXZlcyAlPC9sYWJlbD48aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbXBsb3llZSBJbmNlbnRpdmVzICVcIiBuYW1lPVwiaW5jZW50aXZlc1wiIHZhbHVlPXtmb3JtRGF0YT8uaW5jZW50aXZlc30gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTIgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCIgLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPENvbGxhcHNlIGRlZmF1bHRBY3RpdmVLZXk9e1tcIjFcIiwgXCIyXCJdfSBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCIgZXhwYW5kSWNvblBvc2l0aW9uPVwiZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQYW5lbCBoZWFkZXI9ezxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS04MDAgdXBwZXJjYXNlXCI+QXVjdGlvbiBDb25maWd1cmF0aW9uPC9zcGFuPn0ga2V5PVwiMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+QXVjdGlvbiBQcm9jZXNzaW5nIFR5cGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCIgcGxhY2Vob2xkZXI9XCJTZWxlY3QgVHlwZVwiIHZhbHVlPXtmb3JtRGF0YT8uYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGUgfHwgdW5kZWZpbmVkfSBvbkNoYW5nZT17KHZhbCkgPT4gaGFuZGxlQW50RFNlbGVjdChcImF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlXCIsIHZhbCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcIlNZU1RFTVwiLCBcIk1BTlVBTFwiXS5tYXAoKHMpID0+IDxTZWxlY3QuT3B0aW9uIGtleT17c30gdmFsdWU9e3N9PntzfTwvU2VsZWN0Lk9wdGlvbj4pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5BdWN0aW9uIE1vZGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCIgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTW9kZVwiIHZhbHVlPXtmb3JtRGF0YT8uYXVjdGlvbl9tb2RlIHx8IHVuZGVmaW5lZH0gb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUFudERTZWxlY3QoXCJhdWN0aW9uX21vZGVcIiwgdmFsKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiT05MSU5FXCIsIFwiT0ZGTElORVwiXS5tYXAoKHMpID0+IDxTZWxlY3QuT3B0aW9uIGtleT17c30gdmFsdWU9e3N9PntzfTwvU2VsZWN0Lk9wdGlvbj4pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGE/Lmdyb3VwX3R5cGUgPT09IFwiZml4ZWQtZG91YmxlXCIgfHwgZm9ybURhdGE/Lmdyb3VwX3R5cGUgPT09IFwiZml4ZWQtZGl2aWRlbnRcIiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQYW5lbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcj17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbCBwci00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIHVwcGVyY2FzZVwiPlByZeKAkXNjaGVkdWxlZCBBdWN0aW9uIEVudHJpZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFnIGNvbG9yPVwiYmx1ZVwiPntwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLmxlbmd0aH0gQWRkZWQ8L1RhZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMTAwIHJvdW5kZWQtbGcgcC02IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtODAwIG1iLTQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlZGl0aW5nSW5kZXggIT09IG51bGwgPyBcIkVkaXQgRW50cnlcIiA6IFwiQWRkIE5ldyBBdWN0aW9uIEVudHJ5XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLSR7Y3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX3N0YWdlX3R5cGUgPT09IFwiQVVDVElPTlwiID8gMyA6IDJ9IGdhcC00IG1iLTRgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+QXVjdGlvbiBOby48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdGluZ0luZGV4ICE9PSBudWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBjdXJyZW50QXVjdGlvbkVudHJ5LmF1Y3Rpb25fbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBwcmVmaXhlZEF1Y3Rpb25FbnRyaWVzLmxlbmd0aCArIDFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB9ICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRBdWN0aW9uRW50cnkuYXVjdGlvbl9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQXVjdGlvbklucHV0Q2hhbmdlKFwiYXVjdGlvbl9udW1iZXJcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEwIHJvdW5kZWQgcHgtMyB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX3N0YWdlX3R5cGUgPT09IFwiQVVDVElPTlwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIG1iLTFcIj5UeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRBdWN0aW9uRW50cnkuYXVjdGlvbl90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZShcImF1Y3Rpb25fdHlwZVwiLCB2YWwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkZSRUVcIj5GcmVlPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJOT1JNQUxcIj5Ob3JtYWw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+U3RhZ2U8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50QXVjdGlvbkVudHJ5LmF1Y3Rpb25fc3RhZ2VfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZShcImF1Y3Rpb25fc3RhZ2VfdHlwZVwiLCB2YWwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJDT01NRU5DRU1FTlRcIj5Db21tZW5jZW1lbnQ8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQVVDVElPTlwiPkF1Y3Rpb248L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEF1Y3Rpb25FbnRyeS5hdWN0aW9uX3N0YWdlX3R5cGUgPT09IFwiQVVDVElPTlwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPkJpZCBBbW91bnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwLjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEF1Y3Rpb25FbnRyeS5iaWRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQXVjdGlvbklucHV0Q2hhbmdlKFwiYmlkX2Ftb3VudFwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMCByb3VuZGVkIHB4LTMgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPkJpZCAlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEF1Y3Rpb25FbnRyeS5iaWRfcGVyY2VudGFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZShcImJpZF9wZXJjZW50YWdlXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEwIHJvdW5kZWQgcHgtMyB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPkNvbW1pc3Npb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwLjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QXVjdGlvbkVudHJ5LmNvbW1pc3Npb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVBdWN0aW9uSW5wdXRDaGFuZ2UoXCJjb21taXNzaW9uXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEwIHJvdW5kZWQgcHgtMyB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+V2luIEFtb3VudDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRBdWN0aW9uRW50cnkud2luX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZShcIndpbl9hbW91bnRcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTAgcm91bmRlZCBweC0zIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIG1iLTFcIj5EaXZpZGVuZDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRBdWN0aW9uRW50cnkuZGl2aWRlbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVBdWN0aW9uSW5wdXRDaGFuZ2UoXCJkaXZpZGVudFwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMCByb3VuZGVkIHB4LTMgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPkRpdmlkZW5kIFBlciBIZWFkPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRBdWN0aW9uRW50cnkuZGl2aWRlbnRfaGVhZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZShcImRpdmlkZW50X2hlYWRcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTAgcm91bmRlZCBweC0zIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIG1iLTFcIj5QYXlhYmxlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEF1Y3Rpb25FbnRyeS5wYXlhYmxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQXVjdGlvbklucHV0Q2hhbmdlKFwicGF5YWJsZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMCByb3VuZGVkIHB4LTMgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00IG1iLTQgbXQtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIG1iLTFcIj5BdWN0aW9uIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QXVjdGlvbkVudHJ5LmF1Y3Rpb25fZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVBdWN0aW9uSW5wdXRDaGFuZ2UoXCJhdWN0aW9uX2RhdGVcIiwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTEwIHJvdW5kZWQgcHgtMyB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPk5leHQgQXVjdGlvbiBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEF1Y3Rpb25FbnRyeS5uZXh0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQXVjdGlvbklucHV0Q2hhbmdlKFwibmV4dF9kYXRlXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMCByb3VuZGVkIHB4LTMgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMVwiPkF1Y3Rpb24gVGltZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0aW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRBdWN0aW9uRW50cnkuYXVjdGlvbl90aW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZShcImF1Y3Rpb25fdGltZVwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTAgcm91bmRlZCBweC0zIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0xXCI+TmV4dCBBdWN0aW9uIFRpbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGltZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QXVjdGlvbkVudHJ5Lm5leHRfYXVjdGlvbl90aW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUF1Y3Rpb25JbnB1dENoYW5nZShcIm5leHRfYXVjdGlvbl90aW1lXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xMCByb3VuZGVkIHB4LTMgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZWRpdGluZ0luZGV4ICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmdJbmRleChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0QXVjdGlvbkVudHJ5Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEwIHB4LTYgcm91bmRlZCBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDYW5jZWwgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17ZWRpdGluZ0luZGV4ICE9PSBudWxsID8gPEVkaXRPdXRsaW5lZCAvPiA6IDxQbHVzT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkT3JVcGRhdGVBdWN0aW9uRW50cnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgaC0xMCBweC02IHJvdW5kZWQgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlZGl0aW5nSW5kZXggIT09IG51bGwgPyBcIlVwZGF0ZSBFbnRyeVwiIDogXCJBZGQgRW50cnlcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ByZWZpeGVkQXVjdGlvbkVudHJpZXMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTNcIj5BZGRlZCBFbnRyaWVzICh7cHJlZml4ZWRBdWN0aW9uRW50cmllcy5sZW5ndGh9KTwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLTYwIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTIgcHItMSBjdXN0b20tc2Nyb2xsYmFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ByZWZpeGVkQXVjdGlvbkVudHJpZXMubWFwKChlbnRyeSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtMyByb3VuZGVkIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1zaGFkb3cgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDAgdy04IGgtOCByb3VuZGVkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICN7ZW50cnkuYXVjdGlvbl9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntlbnRyeS5hdWN0aW9uX2RhdGUgfHwgXCJObyBEYXRlXCJ9IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgZm9udC1ub3JtYWwgbWwtMlwiPntlbnRyeS5hdWN0aW9uX3RpbWV9PC9zcGFuPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+e2VudHJ5LmF1Y3Rpb25fc3RhZ2VfdHlwZX0gfCBQYXlhYmxlOiDigrl7ZW50cnkucGF5YWJsZSB8fCAwfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxFZGl0T3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVkaXRFbnRyeShpZHgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IHRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PERlbGV0ZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVFbnRyeShpZHgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2VudHJ5LmF1Y3Rpb25fc3RhZ2VfdHlwZSA9PT0gXCJDT01NRU5DRU1FTlRcIn0gIC8vIGRpc2FibGUgZm9yIGNvbW1lbmNlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17ZW50cnkuYXVjdGlvbl9zdGFnZV90eXBlID09PSBcIkNPTU1FTkNFTUVOVFwiID8geyBvcGFjaXR5OiAwLCBjdXJzb3I6ICdub3QtYWxsb3dlZCcgfSA6IHt9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUGFuZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sbGFwc2U+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIHAtNiBiZy1ncmF5LTUwIGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtsb2FkaW5nfSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtOCBweS0zIHRleHQtY2VudGVyIHNoYWRvdy1sZyB0cmFuc2l0aW9uLXRyYW5zZm9ybSB0cmFuc2Zvcm0gaG92ZXI6c2NhbGUtMTA1IGRpc2FibGVkOm9wYWNpdHktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyBcIlNhdmluZy4uLlwiIDogKGlzRWRpdE1vZGUgPyBcIlVwZGF0ZSBHcm91cFwiIDogXCJTYXZlIEdyb3VwXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuXHJcbiAgICAgICAgICAgIHtzaG93Q29uZmlybSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8UmVDb25maXJtTW9kYWxcclxuICAgICAgICAgICAgICAgICAgICBpc09wZW49e3Nob3dDb25maXJtfVxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29uZmlybSBHcm91cCBEZXRhaWxzXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhPXtzYW5pdGl6ZWRDb25maXJtRGF0YX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd0NvbmZpcm0oZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17aGFuZGxlU3VibWl0fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBZGRHcm91cEZvcm07Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0FkZEdyb3VwRm9ybS5qc3gifQ==