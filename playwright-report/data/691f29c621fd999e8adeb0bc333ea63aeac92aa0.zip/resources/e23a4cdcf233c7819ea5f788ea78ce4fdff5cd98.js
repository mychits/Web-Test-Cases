import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LeadSettings.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Card } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { BsPersonCheck } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import { IoPeopleOutline } from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import { RiAdminLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import { MdAppSettingsAlt } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { GoGraph } from "/node_modules/.vite/deps/react-icons_go.js?v=819e0a34";
import { FiArrowRight } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
const data = [
  {
    title: "Designation",
    description: "Manage employee designations and roles",
    path: "/designation",
    icon: /* @__PURE__ */ jsxDEV(IoPeopleOutline, { size: 28 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    gradient: "from-violet-500 to-violet-600"
  },
  {
    title: "Administrative Privileges",
    description: "Configure admin access levels",
    path: "/administrative-privileges",
    icon: /* @__PURE__ */ jsxDEV(RiAdminLine, { size: 28 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
      lineNumber: 23,
      columnNumber: 9
    }, this),
    gradient: "from-purple-500 to-purple-600"
  },
  {
    title: "Admin Access Rights",
    description: "Control system access permissions",
    path: "/admin-access-rights",
    icon: /* @__PURE__ */ jsxDEV(BsPersonCheck, { size: 28 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    gradient: "from-indigo-500 to-indigo-600"
  },
  {
    title: "Mobile Access",
    description: "Manage mobile application settings",
    path: "app-settings/groups/mobile-access",
    icon: /* @__PURE__ */ jsxDEV(MdAppSettingsAlt, { size: 24 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
      lineNumber: 37,
      columnNumber: 9
    }, this),
    gradient: "from-violet-500 to-violet-600"
  }
  // {
  //   title: "Agent Targets",
  //   description: "Set and monitor performance targets",
  //   path: "/target",
  //   icon: <GoGraph size={28} />,
  //   gradient: "from-pink-500 to-pink-600",
  // },
];
const LeadSettings = () => {
  _s();
  const navigate = useNavigate();
  const [onload, setOnload] = useState(true);
  const [hoveredIndex, setHoveredIndex] = useState(null);
  useEffect(() => {
    const timer = setTimeout(() => {
      setOnload(false);
    }, 300);
    return () => {
      clearTimeout(timer);
    };
  }, []);
  const handleCardClick = (path) => {
    navigate(path);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8 bg-gradient-to-br from-violet-50 to-white min-h-screen", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-violet-600 to-purple-600 mb-2", children: "Settings Dashboard" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: "Manage your system settings and configurations" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
        lineNumber: 74,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 w-full", children: data.map(
      (item, index) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => handleCardClick(item.path),
          onMouseEnter: () => setHoveredIndex(index),
          onMouseLeave: () => setHoveredIndex(null),
          className: `
          relative cursor-pointer rounded-2xl overflow-hidden
          transform transition-all duration-500 ease-in-out
          ${onload ? "translate-y-10 opacity-0" : "translate-y-0 opacity-100"}
          ${hoveredIndex === index ? "scale-105 shadow-2xl" : "shadow-lg"}
        `,
          style: {
            transitionDelay: `${index * 100}ms`
          },
          children: /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-white", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `h-2 bg-gradient-to-r ${item.gradient}` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
              lineNumber: 95,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `w-14 h-14 rounded-xl flex items-center justify-center bg-gradient-to-r ${item.gradient} text-white mb-4 shadow-md`,
                  children: item.icon
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
                  lineNumber: 97,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-2", children: item.title }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
                lineNumber: 102,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 mb-4", children: item.description }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
                lineNumber: 105,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center text-violet-600 font-medium text-sm", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Configure" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
                  lineNumber: 109,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  FiArrowRight,
                  {
                    className: `ml-2 transition-transform duration-300 ${hoveredIndex === index ? "translate-x-1" : ""}`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
                    lineNumber: 110,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
                lineNumber: 108,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
              lineNumber: 96,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
            lineNumber: 94,
            columnNumber: 13
          }, this)
        },
        index,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
          lineNumber: 79,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx",
    lineNumber: 69,
    columnNumber: 5
  }, this);
};
_s(LeadSettings, "bXnMCO1dL7SKNdaLibNnnzOUJyA=", false, function() {
  return [useNavigate];
});
_c = LeadSettings;
export default LeadSettings;
var _c;
$RefreshReg$(_c, "LeadSettings");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadSettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVU7MkJBZlY7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG9CQUFvQjtBQUU3QixNQUFNQyxPQUFPO0FBQUEsRUFDWDtBQUFBLElBQ0VDLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsTUFBTTtBQUFBLElBQ05DLE1BQU0sdUJBQUMsbUJBQWdCLE1BQU0sTUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQ2hDQyxVQUFVO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxJQUNFSixPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLE1BQU07QUFBQSxJQUNOQyxNQUFNLHVCQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNCO0FBQUEsSUFDNUJDLFVBQVU7QUFBQSxFQUNaO0FBQUEsRUFDQTtBQUFBLElBQ0VKLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsTUFBTTtBQUFBLElBQ05DLE1BQU0sdUJBQUMsaUJBQWMsTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdCO0FBQUEsSUFDOUJDLFVBQVU7QUFBQSxFQUNaO0FBQUEsRUFDQTtBQUFBLElBQ0VKLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsTUFBTTtBQUFBLElBQ05DLE1BQU0sdUJBQUMsb0JBQWlCLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLElBQ2pDQyxVQUFVO0FBQUEsRUFDWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBT0E7QUFHRixNQUFNQyxlQUFlQSxNQUFNO0FBQUFDLEtBQUE7QUFDekIsUUFBTUMsV0FBV2YsWUFBWTtBQUM3QixRQUFNLENBQUNnQixRQUFRQyxTQUFTLElBQUluQixTQUFTLElBQUk7QUFDekMsUUFBTSxDQUFDb0IsY0FBY0MsZUFBZSxJQUFJckIsU0FBUyxJQUFJO0FBRXJEc0IsWUFBVSxNQUFNO0FBQ2QsVUFBTUMsUUFBUUMsV0FBVyxNQUFNO0FBQzdCTCxnQkFBVSxLQUFLO0FBQUEsSUFDakIsR0FBRyxHQUFHO0FBRU4sV0FBTyxNQUFNO0FBQ1hNLG1CQUFhRixLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1HLGtCQUFrQkEsQ0FBQ2QsU0FBUztBQUNoQ0ssYUFBU0wsSUFBSTtBQUFBLEVBQ2Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdHQUF1RyxrQ0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLDhEQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsU0FKN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ1pILGVBQUtrQjtBQUFBQSxNQUFJLENBQUNDLE1BQU1DLFVBQ2Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFNBQVMsTUFBTUgsZ0JBQWdCRSxLQUFLaEIsSUFBSTtBQUFBLFVBQ3hDLGNBQWMsTUFBTVMsZ0JBQWdCUSxLQUFLO0FBQUEsVUFDekMsY0FBYyxNQUFNUixnQkFBZ0IsSUFBSTtBQUFBLFVBQ3hDLFdBQVc7QUFBQTtBQUFBO0FBQUEsWUFHWEgsU0FBUyw2QkFBNkIsMkJBQTJCO0FBQUEsWUFDakVFLGlCQUFpQlMsUUFBUSx5QkFBeUIsV0FBVztBQUFBO0FBQUEsVUFFN0QsT0FBTztBQUFBLFlBQ0xDLGlCQUFpQixHQUFHRCxRQUFRLEdBQUc7QUFBQSxVQUNqQztBQUFBLFVBRUEsaUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFXLHdCQUF3QkQsS0FBS2QsUUFBUSxNQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pELHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVywwRUFBMEVjLEtBQUtkLFFBQVE7QUFBQSxrQkFFakdjLGVBQUtmO0FBQUFBO0FBQUFBLGdCQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsNENBQ1hlLGVBQUtsQixTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDVmtCLGVBQUtqQixlQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLHVDQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUNmO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsMENBQTBDUyxpQkFBaUJTLFFBQVEsa0JBQWtCLEVBQUU7QUFBQTtBQUFBLGtCQURwRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ3VHO0FBQUEsbUJBSHpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBO0FBQUEsUUFuQ0tBO0FBQUFBLFFBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXFDQTtBQUFBLElBQ0QsS0F4Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlDQTtBQUFBLE9BakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrREE7QUFFSjtBQUFFYixHQXhFSUQsY0FBWTtBQUFBLFVBQ0NiLFdBQVc7QUFBQTtBQUFBNkIsS0FEeEJoQjtBQTBFTixlQUFlQTtBQUFhLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDYXJkIiwidXNlTmF2aWdhdGUiLCJCc1BlcnNvbkNoZWNrIiwiSW9QZW9wbGVPdXRsaW5lIiwiUmlBZG1pbkxpbmUiLCJNZEFwcFNldHRpbmdzQWx0IiwiR29HcmFwaCIsIkZpQXJyb3dSaWdodCIsImRhdGEiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwicGF0aCIsImljb24iLCJncmFkaWVudCIsIkxlYWRTZXR0aW5ncyIsIl9zIiwibmF2aWdhdGUiLCJvbmxvYWQiLCJzZXRPbmxvYWQiLCJob3ZlcmVkSW5kZXgiLCJzZXRIb3ZlcmVkSW5kZXgiLCJ1c2VFZmZlY3QiLCJ0aW1lciIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJoYW5kbGVDYXJkQ2xpY2siLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJ0cmFuc2l0aW9uRGVsYXkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMZWFkU2V0dGluZ3MuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgQnNQZXJzb25DaGVjayB9IGZyb20gXCJyZWFjdC1pY29ucy9ic1wiO1xyXG5pbXBvcnQgeyBJb1Blb3BsZU91dGxpbmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW81XCI7XHJcbmltcG9ydCB7IFJpQWRtaW5MaW5lIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCB7IE1kQXBwU2V0dGluZ3NBbHQgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgR29HcmFwaCB9IGZyb20gXCJyZWFjdC1pY29ucy9nb1wiO1xyXG5pbXBvcnQgeyBGaUFycm93UmlnaHQgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuXHJcbmNvbnN0IGRhdGEgPSBbXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiRGVzaWduYXRpb25cIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBlbXBsb3llZSBkZXNpZ25hdGlvbnMgYW5kIHJvbGVzXCIsXHJcbiAgICBwYXRoOiBcIi9kZXNpZ25hdGlvblwiLFxyXG4gICAgaWNvbjogPElvUGVvcGxlT3V0bGluZSBzaXplPXsyOH0gLz4sXHJcbiAgICBncmFkaWVudDogXCJmcm9tLXZpb2xldC01MDAgdG8tdmlvbGV0LTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiQWRtaW5pc3RyYXRpdmUgUHJpdmlsZWdlc1wiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiQ29uZmlndXJlIGFkbWluIGFjY2VzcyBsZXZlbHNcIixcclxuICAgIHBhdGg6IFwiL2FkbWluaXN0cmF0aXZlLXByaXZpbGVnZXNcIixcclxuICAgIGljb246IDxSaUFkbWluTGluZSBzaXplPXsyOH0gLz4sXHJcbiAgICBncmFkaWVudDogXCJmcm9tLXB1cnBsZS01MDAgdG8tcHVycGxlLTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiQWRtaW4gQWNjZXNzIFJpZ2h0c1wiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiQ29udHJvbCBzeXN0ZW0gYWNjZXNzIHBlcm1pc3Npb25zXCIsXHJcbiAgICBwYXRoOiBcIi9hZG1pbi1hY2Nlc3MtcmlnaHRzXCIsXHJcbiAgICBpY29uOiA8QnNQZXJzb25DaGVjayBzaXplPXsyOH0gLz4sXHJcbiAgICBncmFkaWVudDogXCJmcm9tLWluZGlnby01MDAgdG8taW5kaWdvLTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiTW9iaWxlIEFjY2Vzc1wiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIG1vYmlsZSBhcHBsaWNhdGlvbiBzZXR0aW5nc1wiLFxyXG4gICAgcGF0aDogXCJhcHAtc2V0dGluZ3MvZ3JvdXBzL21vYmlsZS1hY2Nlc3NcIixcclxuICAgIGljb246IDxNZEFwcFNldHRpbmdzQWx0IHNpemU9ezI0fSAvPixcclxuICAgIGdyYWRpZW50OiBcImZyb20tdmlvbGV0LTUwMCB0by12aW9sZXQtNjAwXCIsXHJcbiAgfSxcclxuICAvLyB7XHJcbiAgLy8gICB0aXRsZTogXCJBZ2VudCBUYXJnZXRzXCIsXHJcbiAgLy8gICBkZXNjcmlwdGlvbjogXCJTZXQgYW5kIG1vbml0b3IgcGVyZm9ybWFuY2UgdGFyZ2V0c1wiLFxyXG4gIC8vICAgcGF0aDogXCIvdGFyZ2V0XCIsXHJcbiAgLy8gICBpY29uOiA8R29HcmFwaCBzaXplPXsyOH0gLz4sXHJcbiAgLy8gICBncmFkaWVudDogXCJmcm9tLXBpbmstNTAwIHRvLXBpbmstNjAwXCIsXHJcbiAgLy8gfSxcclxuXTtcclxuXHJcbmNvbnN0IExlYWRTZXR0aW5ncyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW29ubG9hZCwgc2V0T25sb2FkXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtob3ZlcmVkSW5kZXgsIHNldEhvdmVyZWRJbmRleF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHNldE9ubG9hZChmYWxzZSk7XHJcbiAgICB9LCAzMDApO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2FyZENsaWNrID0gKHBhdGgpID0+IHtcclxuICAgIG5hdmlnYXRlKHBhdGgpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8td2hpdGUgbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC10cmFuc3BhcmVudCBiZy1jbGlwLXRleHQgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tcHVycGxlLTYwMCBtYi0yXCI+XHJcbiAgICAgICAgICBTZXR0aW5ncyBEYXNoYm9hcmRcclxuICAgICAgICA8L2gxPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5NYW5hZ2UgeW91ciBzeXN0ZW0gc2V0dGluZ3MgYW5kIGNvbmZpZ3VyYXRpb25zPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNiB3LWZ1bGxcIj5cclxuICAgICAgICB7ZGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhcmRDbGljayhpdGVtLnBhdGgpfVxyXG4gICAgICAgICAgICBvbk1vdXNlRW50ZXI9eygpID0+IHNldEhvdmVyZWRJbmRleChpbmRleCl9XHJcbiAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17KCkgPT4gc2V0SG92ZXJlZEluZGV4KG51bGwpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BcclxuICAgICAgICAgIHJlbGF0aXZlIGN1cnNvci1wb2ludGVyIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlblxyXG4gICAgICAgICAgdHJhbnNmb3JtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCBlYXNlLWluLW91dFxyXG4gICAgICAgICAgJHtvbmxvYWQgPyBcInRyYW5zbGF0ZS15LTEwIG9wYWNpdHktMFwiIDogXCJ0cmFuc2xhdGUteS0wIG9wYWNpdHktMTAwXCJ9XHJcbiAgICAgICAgICAke2hvdmVyZWRJbmRleCA9PT0gaW5kZXggPyBcInNjYWxlLTEwNSBzaGFkb3ctMnhsXCIgOiBcInNoYWRvdy1sZ1wifVxyXG4gICAgICAgIGB9XHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbkRlbGF5OiBgJHtpbmRleCAqIDEwMH1tc2AsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BoLTIgYmctZ3JhZGllbnQtdG8tciAke2l0ZW0uZ3JhZGllbnR9YH0+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xNCBoLTE0IHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctZ3JhZGllbnQtdG8tciAke2l0ZW0uZ3JhZGllbnR9IHRleHQtd2hpdGUgbWItNCBzaGFkb3ctbWRgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS5pY29ufVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC12aW9sZXQtNjAwIGZvbnQtbWVkaXVtIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+Q29uZmlndXJlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8RmlBcnJvd1JpZ2h0IFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1sLTIgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwICR7aG92ZXJlZEluZGV4ID09PSBpbmRleCA/IFwidHJhbnNsYXRlLXgtMVwiIDogXCJcIn1gfSBcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMZWFkU2V0dGluZ3M7ICAiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvTGVhZFNldHRpbmdzLmpzeCJ9