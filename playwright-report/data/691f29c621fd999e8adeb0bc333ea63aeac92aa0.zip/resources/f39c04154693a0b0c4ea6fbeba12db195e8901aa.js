import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DueLoanWhatsappMessage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaWhatsapp, FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const CustomerDueLoanWhatsAppMessage = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [selectAll, setSelectAll] = useState(false);
  const [notifier, contextHolder] = notification.useNotification();
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const res = await api.get("/payment/customers/due-loan-report");
      const list = res.data.loanReports || [];
      const mapped = list.filter((loan) => Number(loan.outstanding) > 0).map((loan) => ({
        _id: loan._id,
        customerName: loan.borrower?.full_name || "-",
        customerPhone: loan.borrower?.phone_number || "-",
        loanID: loan.loan_id || loan._id,
        outstanding: loan.outstanding,
        balance: loan.outstanding,
        userName: loan.borrower?.full_name || "-",
        userPhone: loan.borrower?.phone_number || "-",
        loanAmount: loan.loan_amount,
        dailyAmount: loan.daily_payment_amount,
        amountToBePaid: loan.amount_payable,
        amountPaid: loan.total_paid_amount,
        dueDays: loan.duedaysCount,
        lastPay: loan.last_payment_amount,
        secondLastPay: loan.second_last_payment_amount,
        thirdLastPay: loan.third_last_payment_amount,
        referredBy: loan.referredBy || "N/A"
      }));
      const tempActive = {};
      mapped.forEach((row) => {
        tempActive[row._id] = {
          info: {
            status: false,
            customerName: row.customerName,
            customerPhone: row.customerPhone,
            loanID: row.loanID,
            outstanding: row.outstanding,
            amountPaid: row.amountPaid
          }
        };
      });
      setUsersData(mapped);
      setActiveUserData(tempActive);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const filterOption = (data, text) => {
    if (!text) return data;
    const search = text.toLowerCase();
    return data.filter(
      (row) => Object.values(row).some(
        (val) => String(val).toLowerCase().includes(search)
      )
    );
  };
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(usersData, searchText);
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    // ✅ backend required fields
                    customerName: user.customerName,
                    customerPhone: user.customerPhone,
                    loanID: user.loanID,
                    outstanding: user.outstanding,
                    amountPaid: user.amountPaid
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
            lineNumber: 101,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, searchText, activeUserData]);
  useEffect(() => {
    setSelectAll(
      filteredUsers.length > 0 && filteredUsers.every((u) => u.isSelected)
    );
  }, [filteredUsers]);
  const visibleSelectedCount = useMemo(
    () => filteredUsers.filter((u) => u.isSelected).length,
    [filteredUsers]
  );
  const sendWhatsapp = async () => {
    const key = "wa";
    try {
      notifier.open({
        key,
        message: "Sending WhatsApp Messages...",
        duration: 2
      });
      const payload = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          payload[user._id] = activeUserData[user._id];
        }
      });
      if (!Object.keys(payload).length) {
        notifier.error({ message: "No users selected" });
        return;
      }
      const res = await api.post(
        "/whatsapp/loan-due-message",
        payload
      );
      notifier.success({
        key,
        message: `Sent: ${res.data.successCount} | Failed: ${res.data.errorCount}`
      });
      fetchData();
    } catch (err) {
      notifier.error({
        key,
        message: "WhatsApp send failed",
        description: err.message
      });
    }
  };
  const columns = [
    { key: "sl_no", header: "SL NO" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone" },
    { key: "loanAmount", header: "Loan Amount" },
    { key: "dailyAmount", header: "Daily Pay" },
    { key: "amountToBePaid", header: "Expected Payable" },
    { key: "amountPaid", header: "Paid" },
    { key: "balance", header: "Outstanding" },
    { key: "dueDays", header: "Due Days" },
    // { key: "lastPay", header: "Last Pay" },
    // { key: "secondLastPay", header: "2nd Pay" },
    // { key: "thirdLastPay", header: "3rd Pay" },
    { key: "referredBy", header: "Referred By" },
    { key: "checkBoxs", header: "Select" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "w-screen", children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
          lineNumber: 210,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
        lineNumber: 214,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 mt-2", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
          lineNumber: 217,
          columnNumber: 14
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center", children: "OutStanding Loan WhatsApp Messages" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
          lineNumber: 218,
          columnNumber: 11
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
          lineNumber: 223,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 p-6 rounded-xl shadow flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { children: "Total Due Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                  lineNumber: 230,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                  lineNumber: 231,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                lineNumber: 229,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { size: 36 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                lineNumber: 235,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
              lineNumber: 228,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-6 rounded-xl shadow flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { children: "Selected" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                  lineNumber: 240,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                  lineNumber: 241,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                lineNumber: 239,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { size: 36 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                lineNumber: 245,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
              lineNumber: 238,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
            lineNumber: 227,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    setActiveUserData((prev) => {
                      const updated = { ...prev };
                      filteredUsers.forEach((user) => {
                        updated[user._id] = {
                          info: {
                            status: checked,
                            balance: user.balance,
                            userPhone: user.userPhone,
                            userName: user.userName,
                            amountPaid: user.amountPaid
                            //dueDays: user.dueDays,
                          }
                        };
                      });
                      return updated;
                    });
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                  lineNumber: 252,
                  columnNumber: 19
                },
                this
              ),
              " ",
              "Select All"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
              lineNumber: 251,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: sendWhatsapp,
                className: "relative bg-green-600 text-white px-4 py-2 rounded flex items-center",
                children: [
                  visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute -top-2 -right-2 bg-red-500 text-xs px-2 rounded-full", children: visibleSelectedCount }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                    lineNumber: 285,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                    lineNumber: 289,
                    columnNumber: 19
                  }, this),
                  "WhatsApp"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
                lineNumber: 280,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
            lineNumber: 250,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns,
              catcher: "_id",
              exportedPdfName: "Loan Outstanding Whatsapp Report",
              exportedFileName: "Loan Outstanding Whatsapp Report.csv"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
              lineNumber: 295,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
          lineNumber: 225,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
        lineNumber: 216,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
      lineNumber: 209,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx",
    lineNumber: 206,
    columnNumber: 5
  }, this);
};
_s(CustomerDueLoanWhatsAppMessage, "62reMGAJrHpldXRkCBB7YVHwhKY=", false, function() {
  return [notification.useNotification];
});
_c = CustomerDueLoanWhatsAppMessage;
export default CustomerDueLoanWhatsAppMessage;
var _c;
$RefreshReg$(_c, "CustomerDueLoanWhatsAppMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueLoanWhatsappMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0dVLFNBNEhFLFVBNUhGOzJCQXBHVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsWUFBWUMsU0FBU0MscUJBQXFCO0FBQ25ELE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLGdCQUFnQjtBQUV2QixNQUFNQyxpQ0FBaUNBLE1BQU07QUFBQUMsS0FBQTtBQUMzQyxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWYsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2dCLFdBQVdDLFlBQVksSUFBSWpCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNrQixnQkFBZ0JDLGlCQUFpQixJQUFJbkIsU0FBUyxDQUFDLENBQUM7QUFDdkQsUUFBTSxDQUFDb0IsV0FBV0MsWUFBWSxJQUFJckIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3NCLFdBQVdDLFlBQVksSUFBSXZCLFNBQVMsS0FBSztBQUVoRCxRQUFNLENBQUN3QixVQUFVQyxhQUFhLElBQUl2QixhQUFhd0IsZ0JBQWdCO0FBRy9ELFFBQU1DLFlBQVksWUFBWTtBQUM1QixRQUFJO0FBQ0ZOLG1CQUFhLElBQUk7QUFFakIsWUFBTU8sTUFBTSxNQUFNekIsSUFBSTBCLElBQUksb0NBQW9DO0FBQzlELFlBQU1DLE9BQU9GLElBQUlHLEtBQUtDLGVBQWU7QUFFckMsWUFBTUMsU0FBU0gsS0FDWkksT0FBTyxDQUFDQyxTQUFTQyxPQUFPRCxLQUFLRSxXQUFXLElBQUksQ0FBQyxFQUM3Q0MsSUFBSSxDQUFDSCxVQUFVO0FBQUEsUUFDZEksS0FBS0osS0FBS0k7QUFBQUEsUUFDVkMsY0FBY0wsS0FBS00sVUFBVUMsYUFBYTtBQUFBLFFBQzFDQyxlQUFlUixLQUFLTSxVQUFVRyxnQkFBZ0I7QUFBQSxRQUM5Q0MsUUFBUVYsS0FBS1csV0FBV1gsS0FBS0k7QUFBQUEsUUFDN0JGLGFBQWFGLEtBQUtFO0FBQUFBLFFBQ2xCVSxTQUFTWixLQUFLRTtBQUFBQSxRQUNkVyxVQUFVYixLQUFLTSxVQUFVQyxhQUFhO0FBQUEsUUFDdENPLFdBQVdkLEtBQUtNLFVBQVVHLGdCQUFnQjtBQUFBLFFBQzFDTSxZQUFZZixLQUFLZ0I7QUFBQUEsUUFDakJDLGFBQWFqQixLQUFLa0I7QUFBQUEsUUFDbEJDLGdCQUFnQm5CLEtBQUtvQjtBQUFBQSxRQUNyQkMsWUFBWXJCLEtBQUtzQjtBQUFBQSxRQUNqQkMsU0FBU3ZCLEtBQUt3QjtBQUFBQSxRQUNkQyxTQUFTekIsS0FBSzBCO0FBQUFBLFFBQ2RDLGVBQWUzQixLQUFLNEI7QUFBQUEsUUFDcEJDLGNBQWM3QixLQUFLOEI7QUFBQUEsUUFDbkJDLFlBQVkvQixLQUFLK0IsY0FBYztBQUFBLE1BQ2pDLEVBQUU7QUFFSixZQUFNQyxhQUFhLENBQUM7QUFDcEJsQyxhQUFPbUMsUUFBUSxDQUFDQyxRQUFRO0FBQ3RCRixtQkFBV0UsSUFBSTlCLEdBQUcsSUFBSTtBQUFBLFVBQ3BCK0IsTUFBTTtBQUFBLFlBQ0pDLFFBQVE7QUFBQSxZQUNSL0IsY0FBYzZCLElBQUk3QjtBQUFBQSxZQUNsQkcsZUFBZTBCLElBQUkxQjtBQUFBQSxZQUNuQkUsUUFBUXdCLElBQUl4QjtBQUFBQSxZQUNaUixhQUFhZ0MsSUFBSWhDO0FBQUFBLFlBQ2pCbUIsWUFBWWEsSUFBSWI7QUFBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBRUR2QyxtQkFBYWdCLE1BQU07QUFDbkJkLHdCQUFrQmdELFVBQVU7QUFBQSxJQUU5QixTQUFTSyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUNuQixVQUFDO0FBQ0NuRCxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUF0QixZQUFVLE1BQU07QUFDZDRCLGNBQVU7QUFBQSxFQUNaLEdBQUcsRUFBRTtBQUdMLFFBQU1nRCxlQUFlQSxDQUFDNUMsTUFBTTZDLFNBQVM7QUFDbkMsUUFBSSxDQUFDQSxLQUFNLFFBQU83QztBQUNsQixVQUFNOEMsU0FBU0QsS0FBS0UsWUFBWTtBQUVoQyxXQUFPL0MsS0FBS0c7QUFBQUEsTUFBTyxDQUFDbUMsUUFDbEJVLE9BQU9DLE9BQU9YLEdBQUcsRUFBRVk7QUFBQUEsUUFBSyxDQUFDQyxRQUN2QkMsT0FBT0QsR0FBRyxFQUFFSixZQUFZLEVBQUVNLFNBQVNQLE1BQU07QUFBQSxNQUMzQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBR0EsUUFBTVEsZ0JBQWdCcEYsUUFBUSxNQUFNO0FBQ2xDLFVBQU1xRixXQUFXWCxhQUFhM0QsV0FBV0YsVUFBVTtBQUVuRCxXQUFPd0UsU0FBU2hELElBQUksQ0FBQ2lELE1BQU1DLFVBQVU7QUFDbkMsWUFBTUMsYUFBYSxDQUFDLENBQUN2RSxlQUFlcUUsS0FBS2hELEdBQUcsR0FBRytCLE1BQU1DO0FBRXJELGFBQU87QUFBQSxRQUNMLEdBQUdnQjtBQUFBQSxRQUNIRyxPQUFPRixRQUFRO0FBQUEsUUFDZkcsV0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU0Y7QUFBQUEsWUFDVCxVQUFVLENBQUNHLE1BQU07QUFDZnpFLGdDQUFrQixDQUFDMEUsVUFBVTtBQUFBLGdCQUMzQixHQUFHQTtBQUFBQSxnQkFDSCxDQUFDTixLQUFLaEQsR0FBRyxHQUFHO0FBQUEsa0JBQ1YrQixNQUFNO0FBQUEsb0JBQ0pDLFFBQVFxQixFQUFFRSxPQUFPQztBQUFBQTtBQUFBQSxvQkFHakJ2RCxjQUFjK0MsS0FBSy9DO0FBQUFBLG9CQUNuQkcsZUFBZTRDLEtBQUs1QztBQUFBQSxvQkFDcEJFLFFBQVEwQyxLQUFLMUM7QUFBQUEsb0JBQ2JSLGFBQWFrRCxLQUFLbEQ7QUFBQUEsb0JBQ2xCbUIsWUFBWStCLEtBQUsvQjtBQUFBQSxrQkFDbkI7QUFBQSxnQkFDRjtBQUFBLGNBQ0YsRUFBRTtBQUFBLFlBQ0o7QUFBQTtBQUFBLFVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1CSTtBQUFBLFFBR05pQztBQUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUN6RSxXQUFXRixZQUFZSSxjQUFjLENBQUM7QUFHMUNuQixZQUFVLE1BQU07QUFDZHdCO0FBQUFBLE1BQ0U4RCxjQUFjVyxTQUFTLEtBQ3JCWCxjQUFjWSxNQUFNLENBQUNDLE1BQU1BLEVBQUVULFVBQVU7QUFBQSxJQUMzQztBQUFBLEVBQ0YsR0FBRyxDQUFDSixhQUFhLENBQUM7QUFFbEIsUUFBTWMsdUJBQXVCbEc7QUFBQUEsSUFDM0IsTUFBTW9GLGNBQWNuRCxPQUFPLENBQUNnRSxNQUFNQSxFQUFFVCxVQUFVLEVBQUVPO0FBQUFBLElBQ2hELENBQUNYLGFBQWE7QUFBQSxFQUNoQjtBQUdBLFFBQU1lLGVBQWUsWUFBWTtBQUMvQixVQUFNQyxNQUFNO0FBRVosUUFBSTtBQUNGN0UsZUFBUzhFLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUVELFlBQU1DLFVBQVUsQ0FBQztBQUVqQnBCLG9CQUFjakIsUUFBUSxDQUFDbUIsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxZQUFZO0FBQ25CZ0Isa0JBQVFsQixLQUFLaEQsR0FBRyxJQUFJckIsZUFBZXFFLEtBQUtoRCxHQUFHO0FBQUEsUUFDN0M7QUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJLENBQUN3QyxPQUFPMkIsS0FBS0QsT0FBTyxFQUFFVCxRQUFRO0FBQ2hDeEUsaUJBQVNrRCxNQUFNLEVBQUU2QixTQUFTLG9CQUFvQixDQUFDO0FBQy9DO0FBQUEsTUFDRjtBQUVBLFlBQU0zRSxNQUFNLE1BQU16QixJQUFJd0c7QUFBQUEsUUFDcEI7QUFBQSxRQUNBRjtBQUFBQSxNQUNGO0FBRUFqRixlQUFTb0YsUUFBUTtBQUFBLFFBQ2ZQO0FBQUFBLFFBQ0FFLFNBQVMsU0FBUzNFLElBQUlHLEtBQUs4RSxZQUFZLGNBQWNqRixJQUFJRyxLQUFLK0UsVUFBVTtBQUFBLE1BQzFFLENBQUM7QUFFRG5GLGdCQUFVO0FBQUEsSUFFWixTQUFTNkMsS0FBSztBQUNaaEQsZUFBU2tELE1BQU07QUFBQSxRQUNiMkI7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RRLGFBQWF2QyxJQUFJK0I7QUFBQUEsTUFDbkIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBS0EsUUFBTVMsVUFBVTtBQUFBLElBQ2QsRUFBRVgsS0FBSyxTQUFTWSxRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFWixLQUFLLFlBQVlZLFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRVosS0FBSyxhQUFhWSxRQUFRLFFBQVE7QUFBQSxJQUNwQyxFQUFFWixLQUFLLGNBQWNZLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVaLEtBQUssZUFBZVksUUFBUSxZQUFZO0FBQUEsSUFDMUMsRUFBRVosS0FBSyxrQkFBa0JZLFFBQVEsbUJBQW1CO0FBQUEsSUFDcEQsRUFBRVosS0FBSyxjQUFjWSxRQUFRLE9BQU87QUFBQSxJQUNwQyxFQUFFWixLQUFLLFdBQVdZLFFBQVEsY0FBYztBQUFBLElBQ3hDLEVBQUVaLEtBQUssV0FBV1ksUUFBUSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJckMsRUFBRVosS0FBSyxjQUFjWSxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFWixLQUFLLGFBQWFZLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFFeEMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsWUFDWnhGO0FBQUFBO0FBQUFBLElBRUQsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCLENBQUNtRSxNQUFNN0UsY0FBYzZFLEVBQUVFLE9BQU9vQixLQUFLO0FBQUEsVUFDaEUsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BRVIsdUJBQUMsU0FBSSxXQUFVLHNCQUNWO0FBQUEsK0JBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDZCx1QkFBQyxRQUFHLFdBQVUsa0NBQWlDLGtEQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVDOUYsWUFDQyx1QkFBQyxrQkFBZSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDLElBRXRDLG1DQUVFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLE9BQUUsbUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0I7QUFBQSxnQkFDdEIsdUJBQUMsT0FBRSxXQUFVLHNCQUNWaUUsd0JBQWNXLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxXQUFRLE1BQU0sTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQjtBQUFBLGlCQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSx3QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFXO0FBQUEsZ0JBQ1gsdUJBQUMsT0FBRSxXQUFVLHNCQUNWRyxrQ0FESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsaUJBQWMsTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBLGlCQVAxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUzdFO0FBQUFBLGtCQUNULFVBQVUsQ0FBQ3NFLE1BQU07QUFDZiwwQkFBTUcsVUFBVUgsRUFBRUUsT0FBT0M7QUFDekJ4RSxpQ0FBYXdFLE9BQU87QUFFcEI1RSxzQ0FBa0IsQ0FBQzBFLFNBQVM7QUFDMUIsNEJBQU1zQixVQUFVLEVBQUUsR0FBR3RCLEtBQUs7QUFDMUJSLG9DQUFjakIsUUFBUSxDQUFDbUIsU0FBUztBQUM5QjRCLGdDQUFRNUIsS0FBS2hELEdBQUcsSUFBSTtBQUFBLDBCQUNsQitCLE1BQU07QUFBQSw0QkFDSkMsUUFBUXdCO0FBQUFBLDRCQUNSaEQsU0FBU3dDLEtBQUt4QztBQUFBQSw0QkFDZEUsV0FBV3NDLEtBQUt0QztBQUFBQSw0QkFDaEJELFVBQVV1QyxLQUFLdkM7QUFBQUEsNEJBQ2ZRLFlBQVkrQixLQUFLL0I7QUFBQUE7QUFBQUEsMEJBRW5CO0FBQUEsd0JBQ0Y7QUFBQSxzQkFDRixDQUFDO0FBQ0QsNkJBQU8yRDtBQUFBQSxvQkFDVCxDQUFDO0FBQUEsa0JBQ0g7QUFBQTtBQUFBLGdCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F1Qkk7QUFBQSxjQUNEO0FBQUEsY0FBSTtBQUFBLGlCQXpCVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTZjtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBRVREO0FBQUFBLHlDQUF1QixLQUN0Qix1QkFBQyxVQUFLLFdBQVUsaUVBQ2JBLGtDQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFRix1QkFBQyxjQUFXLFdBQVUsVUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEI7QUFBQSxrQkFBRztBQUFBO0FBQUE7QUFBQSxjQVRqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLGVBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMENBO0FBQUEsVUFHQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTWQ7QUFBQUEsY0FDTjtBQUFBLGNBQ0EsU0FBUTtBQUFBLGNBQ1AsaUJBQWdCO0FBQUEsY0FDakIsa0JBQWlCO0FBQUE7QUFBQSxZQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLeUQ7QUFBQSxhQTNFM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZFQTtBQUFBLFdBdEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3RkE7QUFBQSxTQS9GRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0dBO0FBQUEsT0FuR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9HQTtBQUVKO0FBQUV4RSxHQXpTSUQsZ0NBQThCO0FBQUEsVUFPQVYsYUFBYXdCLGVBQWU7QUFBQTtBQUFBMEYsS0FQMUR4RztBQTJTTixlQUFlQTtBQUErQixJQUFBd0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsIm5vdGlmaWNhdGlvbiIsImFwaSIsIk5hdmJhciIsIlNpZGViYXIiLCJGYVdoYXRzYXBwIiwiRmFVc2VycyIsIkZhQ2hlY2tDaXJjbGUiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIkJyZWFkY3J1bWIiLCJDdXN0b21lckR1ZUxvYW5XaGF0c0FwcE1lc3NhZ2UiLCJfcyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwidXNlcnNEYXRhIiwic2V0VXNlcnNEYXRhIiwiYWN0aXZlVXNlckRhdGEiLCJzZXRBY3RpdmVVc2VyRGF0YSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsImZldGNoRGF0YSIsInJlcyIsImdldCIsImxpc3QiLCJkYXRhIiwibG9hblJlcG9ydHMiLCJtYXBwZWQiLCJmaWx0ZXIiLCJsb2FuIiwiTnVtYmVyIiwib3V0c3RhbmRpbmciLCJtYXAiLCJfaWQiLCJjdXN0b21lck5hbWUiLCJib3Jyb3dlciIsImZ1bGxfbmFtZSIsImN1c3RvbWVyUGhvbmUiLCJwaG9uZV9udW1iZXIiLCJsb2FuSUQiLCJsb2FuX2lkIiwiYmFsYW5jZSIsInVzZXJOYW1lIiwidXNlclBob25lIiwibG9hbkFtb3VudCIsImxvYW5fYW1vdW50IiwiZGFpbHlBbW91bnQiLCJkYWlseV9wYXltZW50X2Ftb3VudCIsImFtb3VudFRvQmVQYWlkIiwiYW1vdW50X3BheWFibGUiLCJhbW91bnRQYWlkIiwidG90YWxfcGFpZF9hbW91bnQiLCJkdWVEYXlzIiwiZHVlZGF5c0NvdW50IiwibGFzdFBheSIsImxhc3RfcGF5bWVudF9hbW91bnQiLCJzZWNvbmRMYXN0UGF5Iiwic2Vjb25kX2xhc3RfcGF5bWVudF9hbW91bnQiLCJ0aGlyZExhc3RQYXkiLCJ0aGlyZF9sYXN0X3BheW1lbnRfYW1vdW50IiwicmVmZXJyZWRCeSIsInRlbXBBY3RpdmUiLCJmb3JFYWNoIiwicm93IiwiaW5mbyIsInN0YXR1cyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZpbHRlck9wdGlvbiIsInRleHQiLCJzZWFyY2giLCJ0b0xvd2VyQ2FzZSIsIk9iamVjdCIsInZhbHVlcyIsInNvbWUiLCJ2YWwiLCJTdHJpbmciLCJpbmNsdWRlcyIsImZpbHRlcmVkVXNlcnMiLCJmaWx0ZXJlZCIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJzbF9ubyIsImNoZWNrQm94cyIsImUiLCJwcmV2IiwidGFyZ2V0IiwiY2hlY2tlZCIsImxlbmd0aCIsImV2ZXJ5IiwidSIsInZpc2libGVTZWxlY3RlZENvdW50Iiwic2VuZFdoYXRzYXBwIiwia2V5Iiwib3BlbiIsIm1lc3NhZ2UiLCJkdXJhdGlvbiIsInBheWxvYWQiLCJrZXlzIiwicG9zdCIsInN1Y2Nlc3MiLCJzdWNjZXNzQ291bnQiLCJlcnJvckNvdW50IiwiZGVzY3JpcHRpb24iLCJjb2x1bW5zIiwiaGVhZGVyIiwidmFsdWUiLCJ1cGRhdGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRHVlTG9hbldoYXRzYXBwTWVzc2FnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IGFwaSBmcm9tICcuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlJztcclxuaW1wb3J0IE5hdmJhciBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyJztcclxuaW1wb3J0IFNpZGViYXIgZnJvbSAnLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXInO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwLCBGYVVzZXJzLCBGYUNoZWNrQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSAnLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZSc7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tICcuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXInO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tICcuLi9oZWxwZXJzL0JyZWFkY3J1bWInO1xyXG5cclxuY29uc3QgQ3VzdG9tZXJEdWVMb2FuV2hhdHNBcHBNZXNzYWdlID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt1c2Vyc0RhdGEsIHNldFVzZXJzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG5cclxuXHJcbiAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9wYXltZW50L2N1c3RvbWVycy9kdWUtbG9hbi1yZXBvcnRcIik7XHJcbiAgICAgIGNvbnN0IGxpc3QgPSByZXMuZGF0YS5sb2FuUmVwb3J0cyB8fCBbXTtcclxuXHJcbiAgICAgIGNvbnN0IG1hcHBlZCA9IGxpc3RcclxuICAgICAgICAuZmlsdGVyKChsb2FuKSA9PiBOdW1iZXIobG9hbi5vdXRzdGFuZGluZykgPiAwKVxyXG4gICAgICAgIC5tYXAoKGxvYW4pID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGxvYW4uX2lkLCAgICAgICBcclxuICAgICAgICAgIGN1c3RvbWVyTmFtZTogbG9hbi5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJQaG9uZTogbG9hbi5ib3Jyb3dlcj8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgbG9hbklEOiBsb2FuLmxvYW5faWQgfHwgbG9hbi5faWQsXHJcbiAgICAgICAgICBvdXRzdGFuZGluZzogbG9hbi5vdXRzdGFuZGluZyxcclxuICAgICAgICAgIGJhbGFuY2U6IGxvYW4ub3V0c3RhbmRpbmcsICAgICAgXHJcbiAgICAgICAgICB1c2VyTmFtZTogbG9hbi5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgdXNlclBob25lOiBsb2FuLmJvcnJvd2VyPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICBsb2FuQW1vdW50OiBsb2FuLmxvYW5fYW1vdW50LFxyXG4gICAgICAgICAgZGFpbHlBbW91bnQ6IGxvYW4uZGFpbHlfcGF5bWVudF9hbW91bnQsXHJcbiAgICAgICAgICBhbW91bnRUb0JlUGFpZDogbG9hbi5hbW91bnRfcGF5YWJsZSxcclxuICAgICAgICAgIGFtb3VudFBhaWQ6IGxvYW4udG90YWxfcGFpZF9hbW91bnQsXHJcbiAgICAgICAgICBkdWVEYXlzOiBsb2FuLmR1ZWRheXNDb3VudCxcclxuICAgICAgICAgIGxhc3RQYXk6IGxvYW4ubGFzdF9wYXltZW50X2Ftb3VudCxcclxuICAgICAgICAgIHNlY29uZExhc3RQYXk6IGxvYW4uc2Vjb25kX2xhc3RfcGF5bWVudF9hbW91bnQsXHJcbiAgICAgICAgICB0aGlyZExhc3RQYXk6IGxvYW4udGhpcmRfbGFzdF9wYXltZW50X2Ftb3VudCxcclxuICAgICAgICAgIHJlZmVycmVkQnk6IGxvYW4ucmVmZXJyZWRCeSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuICAgICAgbWFwcGVkLmZvckVhY2goKHJvdykgPT4ge1xyXG4gICAgICAgIHRlbXBBY3RpdmVbcm93Ll9pZF0gPSB7XHJcbiAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgICAgIGN1c3RvbWVyTmFtZTogcm93LmN1c3RvbWVyTmFtZSxcclxuICAgICAgICAgICAgY3VzdG9tZXJQaG9uZTogcm93LmN1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgICAgIGxvYW5JRDogcm93LmxvYW5JRCxcclxuICAgICAgICAgICAgb3V0c3RhbmRpbmc6IHJvdy5vdXRzdGFuZGluZyxcclxuICAgICAgICAgICAgYW1vdW50UGFpZDogcm93LmFtb3VudFBhaWQsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0VXNlcnNEYXRhKG1hcHBlZCk7XHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHRlbXBBY3RpdmUpO1xyXG5cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaERhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG5cclxuICBjb25zdCBmaWx0ZXJPcHRpb24gPSAoZGF0YSwgdGV4dCkgPT4ge1xyXG4gICAgaWYgKCF0ZXh0KSByZXR1cm4gZGF0YTtcclxuICAgIGNvbnN0IHNlYXJjaCA9IHRleHQudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5maWx0ZXIoKHJvdykgPT5cclxuICAgICAgT2JqZWN0LnZhbHVlcyhyb3cpLnNvbWUoKHZhbCkgPT5cclxuICAgICAgICBTdHJpbmcodmFsKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaClcclxuICAgICAgKVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBmaWx0ZXJPcHRpb24odXNlcnNEYXRhLCBzZWFyY2hUZXh0KTtcclxuXHJcbiAgICByZXR1cm4gZmlsdGVyZWQubWFwKCh1c2VyLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4udXNlcixcclxuICAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gICAgICAgIGNoZWNrQm94czogKFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgIFt1c2VyLl9pZF06IHtcclxuICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8g4pyFIGJhY2tlbmQgcmVxdWlyZWQgZmllbGRzXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJOYW1lOiB1c2VyLmN1c3RvbWVyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21lclBob25lOiB1c2VyLmN1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgbG9hbklEOiB1c2VyLmxvYW5JRCxcclxuICAgICAgICAgICAgICAgICAgICBvdXRzdGFuZGluZzogdXNlci5vdXRzdGFuZGluZyxcclxuICAgICAgICAgICAgICAgICAgICBhbW91bnRQYWlkOiB1c2VyLmFtb3VudFBhaWQsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSxcclxuICAgICAgICBpc1NlbGVjdGVkLFxyXG4gICAgICB9O1xyXG4gICAgfSk7XHJcbiAgfSwgW3VzZXJzRGF0YSwgc2VhcmNoVGV4dCwgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RBbGwoXHJcbiAgICAgIGZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgIGZpbHRlcmVkVXNlcnMuZXZlcnkoKHUpID0+IHUuaXNTZWxlY3RlZClcclxuICAgICk7XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnNdKTtcclxuXHJcbiAgY29uc3QgdmlzaWJsZVNlbGVjdGVkQ291bnQgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHUpID0+IHUuaXNTZWxlY3RlZCkubGVuZ3RoLFxyXG4gICAgW2ZpbHRlcmVkVXNlcnNdXHJcbiAgKTtcclxuXHJcblxyXG4gIGNvbnN0IHNlbmRXaGF0c2FwcCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGtleSA9IFwid2FcIjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJTZW5kaW5nIFdoYXRzQXBwIE1lc3NhZ2VzLi4uXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHt9O1xyXG5cclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkge1xyXG4gICAgICAgICAgcGF5bG9hZFt1c2VyLl9pZF0gPSBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmICghT2JqZWN0LmtleXMocGF5bG9hZCkubGVuZ3RoKSB7XHJcbiAgICAgICAgbm90aWZpZXIuZXJyb3IoeyBtZXNzYWdlOiBcIk5vIHVzZXJzIHNlbGVjdGVkXCIgfSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICBcIi93aGF0c2FwcC9sb2FuLWR1ZS1tZXNzYWdlXCIsXHJcbiAgICAgICAgcGF5bG9hZFxyXG4gICAgICApO1xyXG5cclxuICAgICAgbm90aWZpZXIuc3VjY2Vzcyh7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IGBTZW50OiAke3Jlcy5kYXRhLnN1Y2Nlc3NDb3VudH0gfCBGYWlsZWQ6ICR7cmVzLmRhdGEuZXJyb3JDb3VudH1gLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGZldGNoRGF0YSgpOyAvLyByZWZyZXNoXHJcblxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIG5vdGlmaWVyLmVycm9yKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0c0FwcCBzZW5kIGZhaWxlZFwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBlcnIubWVzc2FnZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIFRBQkxFIENPTFVNTlNcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTCBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5BbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImRhaWx5QW1vdW50XCIsIGhlYWRlcjogXCJEYWlseSBQYXlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50VG9CZVBhaWRcIiwgaGVhZGVyOiBcIkV4cGVjdGVkIFBheWFibGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50UGFpZFwiLCBoZWFkZXI6IFwiUGFpZFwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJPdXRzdGFuZGluZ1wiIH0sXHJcbiAgICB7IGtleTogXCJkdWVEYXlzXCIsIGhlYWRlcjogXCJEdWUgRGF5c1wiIH0sXHJcbiAgICAvLyB7IGtleTogXCJsYXN0UGF5XCIsIGhlYWRlcjogXCJMYXN0IFBheVwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJzZWNvbmRMYXN0UGF5XCIsIGhlYWRlcjogXCIybmQgUGF5XCIgfSxcclxuICAgIC8vIHsga2V5OiBcInRoaXJkTGFzdFBheVwiLCBoZWFkZXI6IFwiM3JkIFBheVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZEJ5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdFwiIH0sXHJcbiAgXTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlblwiPlxyXG4gICAgICB7Y29udGV4dEhvbGRlcn1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBtdC0yXCI+XHJcbiAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICBPdXRTdGFuZGluZyBMb2FuIFdoYXRzQXBwIE1lc3NhZ2VzXHJcbiAgICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgey8qIFNVTU1BUlkgQ0FSRFMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC02IG10LTggbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHAtNiByb3VuZGVkLXhsIHNoYWRvdyBmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIER1ZSBDdXN0b21lcnM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPEZhVXNlcnMgc2l6ZT17MzZ9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBwLTYgcm91bmRlZC14bCBzaGFkb3cgZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cD5TZWxlY3RlZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8RmFDaGVja0NpcmNsZSBzaXplPXszNn0gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQUNUSU9OIEJBUiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RBbGwoY2hlY2tlZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEoKHByZXYpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4ucHJldiB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkW3VzZXIuX2lkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWxhbmNlOiB1c2VyLmJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci51c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnRQYWlkOiB1c2VyLmFtb3VudFBhaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vZHVlRGF5czogdXNlci5kdWVEYXlzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEFsbFxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIGZsZXggaXRlbXMtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0yIC1yaWdodC0yIGJnLXJlZC01MDAgdGV4dC14cyBweC0yIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFRBQkxFICovfVxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiTG9hbiBPdXRzdGFuZGluZyBXaGF0c2FwcCBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkxvYW4gT3V0c3RhbmRpbmcgV2hhdHNhcHAgUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDdXN0b21lckR1ZUxvYW5XaGF0c0FwcE1lc3NhZ2U7XHJcblxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRHVlTG9hbldoYXRzYXBwTWVzc2FnZS5qc3gifQ==