import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/SettingSidebar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const Fragment2 = __vite__cjsImport3_react["Fragment"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { NavLink, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import {
  BadgeCheck,
  BriefcaseBusiness,
  ChevronLeft,
  ChevronRight,
  CircleUserRound,
  Gift,
  HelpCircle,
  LayoutDashboard,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  UserRoundCog,
  UsersRound,
  Wrench
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const settingsSidebarAccentClasses = [
  "bg-blue-50 text-blue-700 border-blue-100/80",
  "bg-indigo-50 text-indigo-700 border-indigo-100/80",
  "bg-emerald-50 text-emerald-700 border-emerald-100/80",
  "bg-amber-50 text-amber-700 border-amber-100/80",
  "bg-sky-50 text-sky-700 border-sky-100/80",
  "bg-violet-50 text-violet-700 border-violet-100/80",
  "bg-rose-50 text-rose-700 border-rose-100/80",
  "bg-teal-50 text-teal-700 border-teal-100/80",
  "bg-slate-100 text-slate-700 border-slate-200/80"
];
const getSettingsSidebarAccentClass = (key = "") => {
  const text = String(key);
  const hash = [...text].reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return settingsSidebarAccentClasses[hash % settingsSidebarAccentClasses.length];
};
const settingMenu = [
  { id: 1, title: "Dashboard", icon: LayoutDashboard, link: "/dashboard" },
  // { id: 2, title: "Analytics", icon: SiGoogleanalytics, link: "/analytics" },
  {
    id: 3,
    title: "App Settings",
    icon: Wrench,
    submenu: true,
    submenuItems: [
      {
        id: "3-1",
        title: "Groups",
        icon: UsersRound,
        submenu: true,
        submenuItems: [
          {
            id: "3-1-1",
            title: "Mobile Access",
            icon: SlidersHorizontal,
            link: "/lead-setting/app-settings/groups/mobile-access"
          },
          {
            id: "3-1-2",
            title: "Dream Asset",
            icon: Sparkles,
            link: "/lead-setting/app-settings/groups/asset"
          },
          {
            id: "3-1-3",
            title: "Become Agent",
            icon: BriefcaseBusiness,
            link: "/lead-setting/app-settings/groups/become-agent"
          }
        ]
      }
    ]
  },
  {
    title: "Insurance",
    icon: UserRoundCog,
    link: "/insurance"
  },
  {
    title: "Reward",
    icon: Gift,
    link: "/gift-received"
  },
  { id: 4, title: "Designations", icon: UserRoundCog, link: "/designation" },
  {
    id: 5,
    title: "Administrative Privileges",
    icon: ShieldCheck,
    link: "/administrative-privileges"
  },
  {
    title: "Admin Access Rights",
    icon: BadgeCheck,
    link: "/admin-access-rights"
  },
  // {
  //   id: 6,
  //   title: "Target Management",
  //   icon: LuTarget,
  //   submenu: true,
  //   submenuItems: [
  //     {
  //       id: "6-1",
  //       title: "Target",
  //       icon: TbTargetArrow,
  //       link: "/target",
  //     },
  //     {
  //       id: "6-2",
  //       title: "Reports",
  //       icon: BsFileBarGraph,
  //       submenu: true,
  //       submenuItems: [
  //         {
  //           id: "6-2-1",
  //           title: "Commission Report",
  //           icon: TbGraph,
  //           link: "/target-commission",
  //         },
  //         {
  //           id: "6-2-2",
  //           title: "Incentive Report",
  //           icon: TbGraphFilled,
  //           link: "/target-incentive",
  //         },
  //       ],
  //     },
  //     {
  //       id: "6-3",
  //       title: "Accounts",
  //       icon: MdAccountBalanceWallet,
  //       submenu: true,
  //       submenuItems: [
  //         {
  //           id: "6-3-1",
  //           title: "PayOut Menu",
  //           icon: RiMoneyRupeeCircleFill,
  //           link: "/target-payout-menu",
  //         },
  //       ],
  //     },
  //   ],
  // },
  //       {
  //   title: "Penalty Management",
  //   icon: RiMoneyRupeeCircleFill,
  //   submenu: true,
  //   submenuItems: [
  //     { title: "Penalty Settings", icon: Wrench, link: "/penalty-settings" },
  //     { title: "Penalty Monitor", icon: TbGraph, link: "/penalty-monitor" },
  //   ],
  // },
  { id: 7, title: "Profile", icon: CircleUserRound, link: "/profile" },
  { id: 8, title: "Help & Support", icon: HelpCircle, link: "/help" }
];
const SettingSidebar = ({ showMobileSidebar = false, setShowMobileSidebar = () => {
} }) => {
  _s();
  const [open, setOpen] = useState(true);
  const [submenuOpenIndex, setSubmenuOpenIndex] = useState(null);
  const [nestedSubmenuOpenIndex, setNestedSubmenuOpenIndex] = useState({});
  const location = useLocation();
  const toggleSubMenu = (index) => {
    setSubmenuOpenIndex(submenuOpenIndex === index ? null : index);
  };
  const toggleNestedSubMenu = (submenuIndex, subIndex) => {
    setNestedSubmenuOpenIndex((prevState) => ({
      ...prevState,
      [submenuIndex]: prevState[submenuIndex] === subIndex ? null : subIndex
    }));
  };
  const isRouteActive = useCallback((link) => {
    if (!link || link === "#") return false;
    const normalizedLink = link.endsWith("/") && link.length > 1 ? link.slice(0, -1) : link;
    const normalizedPath = location.pathname.endsWith("/") && location.pathname.length > 1 ? location.pathname.slice(0, -1) : location.pathname;
    return normalizedPath === normalizedLink || normalizedPath.startsWith(`${normalizedLink}/`);
  }, [location.pathname]);
  const isMenuActive = useCallback((menu) => {
    if (isRouteActive(menu.link)) return true;
    return menu.submenuItems?.some((submenuItem) => {
      if (isRouteActive(submenuItem.link)) return true;
      return submenuItem.submenuItems?.some((subSubItem) => isRouteActive(subSubItem.link));
    });
  }, [isRouteActive]);
  useEffect(() => {
    const activeMenuIndex = settingMenu.findIndex(isMenuActive);
    if (activeMenuIndex === -1) return;
    const activeMenu = settingMenu[activeMenuIndex];
    if (activeMenu?.submenu) {
      setSubmenuOpenIndex(activeMenuIndex);
    }
    const activeSubmenuIndex = activeMenu?.submenuItems?.findIndex((submenuItem) => {
      if (isRouteActive(submenuItem.link)) return true;
      return submenuItem.submenuItems?.some((subSubItem) => isRouteActive(subSubItem.link));
    });
    if (activeSubmenuIndex >= 0 && activeMenu?.submenuItems?.[activeSubmenuIndex]?.submenu) {
      setNestedSubmenuOpenIndex((prevState) => ({
        ...prevState,
        [activeMenuIndex]: activeSubmenuIndex
      }));
    }
  }, [isMenuActive, isRouteActive, location.pathname]);
  const renderIcon = (Icon, className = "") => {
    if (!Icon) return null;
    const IconComponent = Icon;
    return /* @__PURE__ */ jsxDEV(IconComponent, { className, strokeWidth: 1.8 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
      lineNumber: 227,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: `hidden shrink-0 transition-all duration-300 md:block ${open ? "w-64" : "w-20"}` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
      lineNumber: 232,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `sidebar-scrollbar fixed left-0 top-[68px] z-40 h-[calc(100vh-68px)] shrink-0 overflow-y-auto overflow-x-hidden border-r border-slate-200/70 bg-white/80 shadow-[1px_0_18px_rgba(15,23,42,0.05)] backdrop-blur-2xl transition-all duration-300 ${open ? "w-64" : "w-20"} ${showMobileSidebar ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`,
        children: /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 px-3 pb-5 pt-3", children: settingMenu.map((menu, index) => {
          const isOpen = submenuOpenIndex === index;
          const menuIsActive = isMenuActive(menu);
          const menuLinkIsActive = isRouteActive(menu.link);
          return /* @__PURE__ */ jsxDEV(Fragment2, { children: [
            /* @__PURE__ */ jsxDEV(
              NavLink,
              {
                to: menu.link || "#",
                end: true,
                onClick: (e) => {
                  if (menu.submenu) {
                    e.preventDefault();
                    toggleSubMenu(index);
                  }
                },
                className: ({ isActive }) => `group relative flex items-center rounded-xl border py-2 transition-all duration-200 ${open ? "gap-x-3 px-3" : "justify-center px-0"} ${isActive && !menu.submenu || menuIsActive ? "border-indigo-100/80 bg-indigo-50/80 text-indigo-700 font-semibold shadow-sm shadow-indigo-900/[0.03]" : "border-transparent text-slate-600 hover:border-slate-200/70 hover:bg-white/70 hover:text-slate-950"}`,
                children: [
                  (menuLinkIsActive && !menu.submenu || menuIsActive) && open && /* @__PURE__ */ jsxDEV("span", { className: "absolute left-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-r-full bg-[#0071e3]/70" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                    lineNumber: 262,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: `grid h-9 w-9 shrink-0 place-items-center rounded-xl border transition duration-200 ${getSettingsSidebarAccentClass(menu.title)} ${menuLinkIsActive && !menu.submenu || menuIsActive ? "ring-2 ring-[#0071e3]/15" : "group-hover:scale-[1.03]"}`, children: renderIcon(menu.icon, "h-[18px] w-[18px]") }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                    lineNumber: 264,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: `flex-1 truncate text-sm font-semibold ${!open && "hidden"}`, children: menu.title }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                    lineNumber: 267,
                    columnNumber: 19
                  }, this),
                  menu.submenu && open && /* @__PURE__ */ jsxDEV(
                    ChevronRight,
                    {
                      className: `ml-auto h-4 w-4 shrink-0 text-slate-400 transition-transform duration-200 ${isOpen ? "rotate-90 text-[#0071e3]" : ""}`,
                      strokeWidth: 1.8
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                      lineNumber: 271,
                      columnNumber: 19
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                lineNumber: 245,
                columnNumber: 17
              },
              this
            ),
            menu.submenu && isOpen && open && /* @__PURE__ */ jsxDEV("ul", { className: "ml-3 mt-1 space-y-1 border-l border-slate-200/70 pl-3 font-medium", children: menu.submenuItems.map((submenuItem, subIndex) => {
              const isNestedOpen = nestedSubmenuOpenIndex[index] === subIndex;
              const submenuIsActive = isRouteActive(submenuItem.link) || submenuItem.submenuItems?.some((subSubItem) => isRouteActive(subSubItem.link));
              return /* @__PURE__ */ jsxDEV(Fragment2, { children: [
                /* @__PURE__ */ jsxDEV(
                  NavLink,
                  {
                    to: submenuItem.link || "#",
                    end: true,
                    onClick: (e) => {
                      if (submenuItem.submenu) {
                        e.preventDefault();
                        toggleNestedSubMenu(index, subIndex);
                      }
                    },
                    className: ({ isActive }) => `flex items-center rounded-lg px-3 py-2.5 text-sm transition-all duration-200 ${isActive || submenuIsActive ? "border border-indigo-100/80 bg-indigo-50/80 text-indigo-700 font-semibold shadow-sm shadow-indigo-900/[0.03]" : "border border-transparent text-slate-600 hover:border-slate-200/70 hover:bg-white/70 hover:text-slate-950"}`,
                    children: [
                      submenuItem.icon && /* @__PURE__ */ jsxDEV("span", { className: `mr-2 grid h-8 w-8 shrink-0 place-items-center rounded-lg border ${getSettingsSidebarAccentClass(submenuItem.title)}`, children: renderIcon(submenuItem.icon, "h-4 w-4") }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                        lineNumber: 303,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "flex-1 truncate", children: submenuItem.title }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                        lineNumber: 307,
                        columnNumber: 29
                      }, this),
                      submenuItem.submenu && /* @__PURE__ */ jsxDEV(
                        ChevronRight,
                        {
                          className: `ml-auto h-3.5 w-3.5 shrink-0 text-slate-400 transition-transform duration-200 ${isNestedOpen ? "rotate-90 text-[#0071e3]" : ""}`,
                          strokeWidth: 1.8
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                          lineNumber: 309,
                          columnNumber: 27
                        },
                        this
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                    lineNumber: 286,
                    columnNumber: 27
                  },
                  this
                ),
                submenuItem.submenu && isNestedOpen && /* @__PURE__ */ jsxDEV("ul", { className: "ml-4 mt-1 space-y-1 border-l border-slate-200/70 pl-3", children: submenuItem.submenuItems.map(
                  (subSubItem) => /* @__PURE__ */ jsxDEV(
                    NavLink,
                    {
                      to: subSubItem.link,
                      end: true,
                      className: ({ isActive }) => `flex items-center rounded-lg px-3 py-2 text-sm transition-all duration-200 ${isActive ? "border border-indigo-100/80 bg-indigo-50/80 text-indigo-700 font-semibold shadow-sm shadow-indigo-900/[0.03]" : "border border-transparent text-slate-600 hover:border-slate-200/70 hover:bg-white/70 hover:text-slate-950"}`,
                      children: [
                        subSubItem.icon && /* @__PURE__ */ jsxDEV("span", { className: `mr-2 grid h-7 w-7 shrink-0 place-items-center rounded-lg border ${getSettingsSidebarAccentClass(subSubItem.title)}`, children: renderIcon(subSubItem.icon, "h-3.5 w-3.5") }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                          lineNumber: 331,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: subSubItem.title }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                          lineNumber: 335,
                          columnNumber: 35
                        }, this)
                      ]
                    },
                    subSubItem.id || subSubItem.title,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                      lineNumber: 319,
                      columnNumber: 27
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                  lineNumber: 317,
                  columnNumber: 25
                }, this)
              ] }, submenuItem.id || submenuItem.title, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
                lineNumber: 285,
                columnNumber: 23
              }, this);
            }) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
              lineNumber: 279,
              columnNumber: 17
            }, this)
          ] }, menu.id || menu.title, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
            lineNumber: 244,
            columnNumber: 15
          }, this);
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
          lineNumber: 237,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
        lineNumber: 234,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => setOpen(!open),
        className: `fixed top-20 z-50 hidden h-9 w-9 items-center justify-center rounded-full border border-slate-200/70 bg-white/85 text-slate-600 shadow-lg shadow-slate-900/10 backdrop-blur-xl transition-all duration-200 hover:bg-white hover:text-[#0071e3] focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 md:flex ${open ? "left-60" : "left-16 rotate-180"}`,
        "aria-label": open ? "Collapse settings sidebar" : "Expand settings sidebar",
        children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "h-5 w-5", strokeWidth: 1.8 }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
          lineNumber: 357,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
        lineNumber: 351,
        columnNumber: 7
      },
      this
    ),
    showMobileSidebar && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "fixed inset-0 z-30 bg-slate-900/20 backdrop-blur-[2px] md:hidden",
        onClick: () => setShowMobileSidebar(false)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
        lineNumber: 361,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx",
    lineNumber: 231,
    columnNumber: 5
  }, this);
};
_s(SettingSidebar, "biNSze2jNtnM8mhmd5fQjH5bD4o=", false, function() {
  return [useLocation];
});
_c = SettingSidebar;
export default SettingSidebar;
var _c;
$RefreshReg$(_c, "SettingSidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/SettingSidebar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa09XLFNBSVAsVUFKTzsyQkFsT1g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSx1QkFBVUMsYUFBYUMsV0FBV0MsZ0JBQWdCO0FBQzNELFNBQVNDLFNBQVNDLG1CQUFtQjtBQUNyQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQywrQkFBK0I7QUFBQSxFQUNuQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQWlEO0FBR25ELE1BQU1DLGdDQUFnQ0EsQ0FBQ0MsTUFBTSxPQUFPO0FBQ2xELFFBQU1DLE9BQU9DLE9BQU9GLEdBQUc7QUFDdkIsUUFBTUcsT0FBTyxDQUFDLEdBQUdGLElBQUksRUFBRUcsT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxNQUFNQyxLQUFLQyxXQUFXLENBQUMsR0FBRyxDQUFDO0FBQ3hFLFNBQU9ULDZCQUE2QkssT0FBT0wsNkJBQTZCVSxNQUFNO0FBQ2hGO0FBQ0EsTUFBTUMsY0FBYztBQUFBLEVBQ2xCLEVBQUVDLElBQUksR0FBR0MsT0FBTyxhQUFhQyxNQUFNckIsaUJBQWlCc0IsTUFBTSxhQUFhO0FBQUE7QUFBQSxFQUV2RTtBQUFBLElBQ0VILElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTWY7QUFBQUEsSUFDTmlCLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsTUFDWjtBQUFBLFFBQ0VMLElBQUk7QUFBQSxRQUNKQyxPQUFPO0FBQUEsUUFDUEMsTUFBTWhCO0FBQUFBLFFBQ05rQixTQUFTO0FBQUEsUUFDVEMsY0FBYztBQUFBLFVBQ1o7QUFBQSxZQUNFTCxJQUFJO0FBQUEsWUFDSkMsT0FBTztBQUFBLFlBQ1BDLE1BQU1uQjtBQUFBQSxZQUNOb0IsTUFBTTtBQUFBLFVBQ1I7QUFBQSxVQUNBO0FBQUEsWUFDRUgsSUFBSTtBQUFBLFlBQ0pDLE9BQU87QUFBQSxZQUNQQyxNQUFNbEI7QUFBQUEsWUFDTm1CLE1BQU07QUFBQSxVQUNSO0FBQUEsVUFDQTtBQUFBLFlBQ0VILElBQUk7QUFBQSxZQUNKQyxPQUFPO0FBQUEsWUFDUEMsTUFBTTNCO0FBQUFBLFlBQ040QixNQUFNO0FBQUEsVUFDUjtBQUFBLFFBQUM7QUFBQSxNQUVMO0FBQUEsSUFBQztBQUFBLEVBRUw7QUFBQSxFQUVFO0FBQUEsSUFDQUYsT0FBTztBQUFBLElBQ1BDLE1BQU1qQjtBQUFBQSxJQUNOa0IsTUFBTztBQUFBLEVBRVQ7QUFBQSxFQUNBO0FBQUEsSUFDRUYsT0FBTztBQUFBLElBQ1BDLE1BQU12QjtBQUFBQSxJQUNOd0IsTUFBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLEVBQUVILElBQUksR0FBR0MsT0FBTyxnQkFBZ0JDLE1BQU1qQixjQUFja0IsTUFBTSxlQUFlO0FBQUEsRUFDekU7QUFBQSxJQUNFSCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU1wQjtBQUFBQSxJQUNOcUIsTUFBTTtBQUFBLEVBQ1I7QUFBQSxFQUNBO0FBQUEsSUFDRUYsT0FBTztBQUFBLElBQ1BDLE1BQU01QjtBQUFBQSxJQUNONkIsTUFBTTtBQUFBLEVBQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTREQSxFQUFFSCxJQUFJLEdBQUdDLE9BQU8sV0FBV0MsTUFBTXhCLGlCQUFpQnlCLE1BQU0sV0FBVztBQUFBLEVBQ25FLEVBQUVILElBQUksR0FBR0MsT0FBTyxrQkFBa0JDLE1BQU10QixZQUFZdUIsTUFBTSxRQUFRO0FBQUM7QUFHckUsTUFBTUcsaUJBQWlCQSxDQUFDLEVBQUVDLG9CQUFvQixPQUFPQyx1QkFBdUJBLE1BQU07QUFBQyxFQUFFLE1BQU07QUFBQUMsS0FBQTtBQUN6RixRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSXhDLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUN5QyxrQkFBa0JDLG1CQUFtQixJQUFJMUMsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQzJDLHdCQUF3QkMseUJBQXlCLElBQUk1QyxTQUFTLENBQUMsQ0FBQztBQUN2RSxRQUFNNkMsV0FBVzNDLFlBQVk7QUFFN0IsUUFBTTRDLGdCQUFnQkEsQ0FBQ0MsVUFBVTtBQUMvQkwsd0JBQW9CRCxxQkFBcUJNLFFBQVEsT0FBT0EsS0FBSztBQUFBLEVBQy9EO0FBRUEsUUFBTUMsc0JBQXNCQSxDQUFDQyxjQUFjQyxhQUFhO0FBQ3RETiw4QkFBMEIsQ0FBQ08sZUFBZTtBQUFBLE1BQ3hDLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsWUFBWSxHQUFHRSxVQUFVRixZQUFZLE1BQU1DLFdBQVcsT0FBT0E7QUFBQUEsSUFDaEUsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRSxnQkFBZ0J0RCxZQUFZLENBQUNrQyxTQUFTO0FBQzFDLFFBQUksQ0FBQ0EsUUFBUUEsU0FBUyxJQUFLLFFBQU87QUFFbEMsVUFBTXFCLGlCQUFpQnJCLEtBQUtzQixTQUFTLEdBQUcsS0FBS3RCLEtBQUtMLFNBQVMsSUFBSUssS0FBS3VCLE1BQU0sR0FBRyxFQUFFLElBQUl2QjtBQUNuRixVQUFNd0IsaUJBQWlCWCxTQUFTWSxTQUFTSCxTQUFTLEdBQUcsS0FBS1QsU0FBU1ksU0FBUzlCLFNBQVMsSUFDakZrQixTQUFTWSxTQUFTRixNQUFNLEdBQUcsRUFBRSxJQUM3QlYsU0FBU1k7QUFFYixXQUFPRCxtQkFBbUJILGtCQUFrQkcsZUFBZUUsV0FBVyxHQUFHTCxjQUFjLEdBQUc7QUFBQSxFQUM1RixHQUFHLENBQUNSLFNBQVNZLFFBQVEsQ0FBQztBQUV0QixRQUFNRSxlQUFlN0QsWUFBWSxDQUFDOEQsU0FBUztBQUN6QyxRQUFJUixjQUFjUSxLQUFLNUIsSUFBSSxFQUFHLFFBQU87QUFFckMsV0FBTzRCLEtBQUsxQixjQUFjMkIsS0FBSyxDQUFDQyxnQkFBZ0I7QUFDOUMsVUFBSVYsY0FBY1UsWUFBWTlCLElBQUksRUFBRyxRQUFPO0FBQzVDLGFBQU84QixZQUFZNUIsY0FBYzJCLEtBQUssQ0FBQ0UsZUFBZVgsY0FBY1csV0FBVy9CLElBQUksQ0FBQztBQUFBLElBQ3RGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ29CLGFBQWEsQ0FBQztBQUVsQnJELFlBQVUsTUFBTTtBQUNkLFVBQU1pRSxrQkFBa0JwQyxZQUFZcUMsVUFBVU4sWUFBWTtBQUUxRCxRQUFJSyxvQkFBb0IsR0FBSTtBQUU1QixVQUFNRSxhQUFhdEMsWUFBWW9DLGVBQWU7QUFFOUMsUUFBSUUsWUFBWWpDLFNBQVM7QUFDdkJTLDBCQUFvQnNCLGVBQWU7QUFBQSxJQUNyQztBQUVBLFVBQU1HLHFCQUFxQkQsWUFBWWhDLGNBQWMrQixVQUFVLENBQUNILGdCQUFnQjtBQUM5RSxVQUFJVixjQUFjVSxZQUFZOUIsSUFBSSxFQUFHLFFBQU87QUFDNUMsYUFBTzhCLFlBQVk1QixjQUFjMkIsS0FBSyxDQUFDRSxlQUFlWCxjQUFjVyxXQUFXL0IsSUFBSSxDQUFDO0FBQUEsSUFDdEYsQ0FBQztBQUVELFFBQUltQyxzQkFBc0IsS0FBS0QsWUFBWWhDLGVBQWVpQyxrQkFBa0IsR0FBR2xDLFNBQVM7QUFDdEZXLGdDQUEwQixDQUFDTyxlQUFlO0FBQUEsUUFDeEMsR0FBR0E7QUFBQUEsUUFDSCxDQUFDYSxlQUFlLEdBQUdHO0FBQUFBLE1BQ3JCLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRixHQUFHLENBQUNSLGNBQWNQLGVBQWVQLFNBQVNZLFFBQVEsQ0FBQztBQUVuRCxRQUFNVyxhQUFhQSxDQUFDQyxNQUFNQyxZQUFZLE9BQU87QUFDM0MsUUFBSSxDQUFDRCxLQUFNLFFBQU87QUFFbEIsVUFBTUUsZ0JBQWdCRjtBQUN0QixXQUFPLHVCQUFDLGlCQUFjLFdBQXNCLGFBQWEsT0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLEVBQy9EO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVyx3REFBd0Q5QixPQUFPLFNBQVMsTUFBTSxNQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlHO0FBQUEsSUFFakc7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVcsaVBBQWlQQSxPQUFPLFNBQVMsTUFBTSxJQUFJSCxvQkFBb0Isa0JBQWtCLG9DQUFvQztBQUFBLFFBRWhXLGlDQUFDLFFBQUcsV0FBVSw0QkFDWFIsc0JBQVk0QyxJQUFJLENBQUNaLE1BQU1iLFVBQVU7QUFDaEMsZ0JBQU0wQixTQUFTaEMscUJBQXFCTTtBQUNwQyxnQkFBTTJCLGVBQWVmLGFBQWFDLElBQUk7QUFDdEMsZ0JBQU1lLG1CQUFtQnZCLGNBQWNRLEtBQUs1QixJQUFJO0FBRWhELGlCQUNFLHVCQUFDbkMsV0FBQSxFQUNDO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFJK0QsS0FBSzVCLFFBQVE7QUFBQSxnQkFDakI7QUFBQSxnQkFDQSxTQUFTLENBQUM0QyxNQUFNO0FBQ2Qsc0JBQUloQixLQUFLM0IsU0FBUztBQUNoQjJDLHNCQUFFQyxlQUFlO0FBQ2pCL0Isa0NBQWNDLEtBQUs7QUFBQSxrQkFDckI7QUFBQSxnQkFDRjtBQUFBLGdCQUNBLFdBQVcsQ0FBQyxFQUFFK0IsU0FBUyxNQUNyQix1RkFBdUZ2QyxPQUFPLGlCQUFpQixxQkFBcUIsSUFBS3VDLFlBQVksQ0FBQ2xCLEtBQUszQixXQUFZeUMsZUFDbkssMEdBQ0Esb0dBQW9HO0FBQUEsZ0JBSXZHQztBQUFBQSx1Q0FBb0IsQ0FBQ2YsS0FBSzNCLFdBQVl5QyxpQkFBaUJuQyxRQUN4RCx1QkFBQyxVQUFLLFdBQVUscUZBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlHO0FBQUEsa0JBRW5HLHVCQUFDLFVBQUssV0FBVyxzRkFBc0ZyQiw4QkFBOEIwQyxLQUFLOUIsS0FBSyxDQUFDLElBQU02QyxvQkFBb0IsQ0FBQ2YsS0FBSzNCLFdBQVl5QyxlQUFnQiw2QkFBNkIsMEJBQTBCLElBQ2hRTixxQkFBV1IsS0FBSzdCLE1BQU0sbUJBQW1CLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVcseUNBQXlDLENBQUNRLFFBQVEsUUFBUSxJQUN4RXFCLGVBQUs5QixTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQzhCLEtBQUszQixXQUFXTSxRQUNmO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcsNkVBQTZFa0MsU0FBUyw2QkFBNkIsRUFBRTtBQUFBLHNCQUNoSSxhQUFhO0FBQUE7QUFBQSxvQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRW1CO0FBQUE7QUFBQTtBQUFBLGNBNUJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUErQkE7QUFBQSxZQUVDYixLQUFLM0IsV0FBV3dDLFVBQVVsQyxRQUN6Qix1QkFBQyxRQUFHLFdBQVUscUVBQ1hxQixlQUFLMUIsYUFBYXNDLElBQUksQ0FBQ1YsYUFBYVosYUFBYTtBQUNoRCxvQkFBTTZCLGVBQWVwQyx1QkFBdUJJLEtBQUssTUFBTUc7QUFDdkQsb0JBQU04QixrQkFBa0I1QixjQUFjVSxZQUFZOUIsSUFBSSxLQUFLOEIsWUFBWTVCLGNBQWMyQixLQUFLLENBQUNFLGVBQWVYLGNBQWNXLFdBQVcvQixJQUFJLENBQUM7QUFFeEkscUJBQ0UsdUJBQUNuQyxXQUFBLEVBQ0M7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFJaUUsWUFBWTlCLFFBQVE7QUFBQSxvQkFDeEI7QUFBQSxvQkFDQSxTQUFTLENBQUM0QyxNQUFNO0FBQ2QsMEJBQUlkLFlBQVk3QixTQUFTO0FBQ3ZCMkMsMEJBQUVDLGVBQWU7QUFDakI3Qiw0Q0FBb0JELE9BQU9HLFFBQVE7QUFBQSxzQkFDckM7QUFBQSxvQkFDRjtBQUFBLG9CQUNBLFdBQVcsQ0FBQyxFQUFFNEIsU0FBUyxNQUNyQixnRkFBZ0ZBLFlBQVlFLGtCQUN4RixpSEFDQSwyR0FBMkc7QUFBQSxvQkFJaEhsQjtBQUFBQSxrQ0FBWS9CLFFBQ1gsdUJBQUMsVUFBSyxXQUFXLG1FQUFtRWIsOEJBQThCNEMsWUFBWWhDLEtBQUssQ0FBQyxJQUNqSXNDLHFCQUFXTixZQUFZL0IsTUFBTSxTQUFTLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFFRix1QkFBQyxVQUFLLFdBQVUsbUJBQW1CK0Isc0JBQVloQyxTQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxRDtBQUFBLHNCQUNwRGdDLFlBQVk3QixXQUNYO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVcsaUZBQWlGOEMsZUFBZSw2QkFBNkIsRUFBRTtBQUFBLDBCQUMxSSxhQUFhO0FBQUE7QUFBQSx3QkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRW1CO0FBQUE7QUFBQTtBQUFBLGtCQXpCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTRCQTtBQUFBLGdCQUVDakIsWUFBWTdCLFdBQVc4QyxnQkFDdEIsdUJBQUMsUUFBRyxXQUFVLHlEQUNYakIsc0JBQVk1QixhQUFhc0M7QUFBQUEsa0JBQUksQ0FBQ1QsZUFDN0I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsSUFBSUEsV0FBVy9CO0FBQUFBLHNCQUNmO0FBQUEsc0JBQ0EsV0FBVyxDQUFDLEVBQUU4QyxTQUFTLE1BQ3JCLDhFQUE4RUEsV0FDMUUsaUhBQ0EsMkdBQTJHO0FBQUEsc0JBSWhIZjtBQUFBQSxtQ0FBV2hDLFFBQ1YsdUJBQUMsVUFBSyxXQUFXLG1FQUFtRWIsOEJBQThCNkMsV0FBV2pDLEtBQUssQ0FBQyxJQUNoSXNDLHFCQUFXTCxXQUFXaEMsTUFBTSxhQUFhLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFFRix1QkFBQyxVQUFLLFdBQVUsWUFBWWdDLHFCQUFXakMsU0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkM7QUFBQTtBQUFBO0FBQUEsb0JBZnhDaUMsV0FBV2xDLE1BQU1rQyxXQUFXakM7QUFBQUEsb0JBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBaUJBO0FBQUEsZ0JBQ0QsS0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQkE7QUFBQSxtQkFyRFdnQyxZQUFZakMsTUFBTWlDLFlBQVloQyxPQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVEQTtBQUFBLFlBRUosQ0FBQyxLQS9ESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdFQTtBQUFBLGVBbkdXOEIsS0FBSy9CLE1BQU0rQixLQUFLOUIsT0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxR0E7QUFBQSxRQUVKLENBQUMsS0E5R0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStHQTtBQUFBO0FBQUEsTUFsSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbUhBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FBUyxNQUFNVSxRQUFRLENBQUNELElBQUk7QUFBQSxRQUM1QixXQUFXLGtUQUFrVEEsT0FBTyxZQUFZLG9CQUFvQjtBQUFBLFFBQ3BXLGNBQVlBLE9BQU8sOEJBQThCO0FBQUEsUUFFakQsaUNBQUMsZUFBWSxXQUFVLFdBQVUsYUFBYSxPQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUE7QUFBQSxNQU5wRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLElBRUNILHFCQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixTQUFTLE1BQU1DLHFCQUFxQixLQUFLO0FBQUE7QUFBQSxNQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFNkM7QUFBQSxPQXBJakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVJQTtBQUVKO0FBQUVDLEdBOU1JSCxnQkFBYztBQUFBLFVBSURqQyxXQUFXO0FBQUE7QUFBQStFLEtBSnhCOUM7QUFnTk4sZUFBZUE7QUFBZSxJQUFBOEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkZyYWdtZW50IiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIk5hdkxpbmsiLCJ1c2VMb2NhdGlvbiIsIkJhZGdlQ2hlY2siLCJCcmllZmNhc2VCdXNpbmVzcyIsIkNoZXZyb25MZWZ0IiwiQ2hldnJvblJpZ2h0IiwiQ2lyY2xlVXNlclJvdW5kIiwiR2lmdCIsIkhlbHBDaXJjbGUiLCJMYXlvdXREYXNoYm9hcmQiLCJTaGllbGRDaGVjayIsIlNsaWRlcnNIb3Jpem9udGFsIiwiU3BhcmtsZXMiLCJVc2VyUm91bmRDb2ciLCJVc2Vyc1JvdW5kIiwiV3JlbmNoIiwic2V0dGluZ3NTaWRlYmFyQWNjZW50Q2xhc3NlcyIsImdldFNldHRpbmdzU2lkZWJhckFjY2VudENsYXNzIiwia2V5IiwidGV4dCIsIlN0cmluZyIsImhhc2giLCJyZWR1Y2UiLCJzdW0iLCJjaGFyIiwiY2hhckNvZGVBdCIsImxlbmd0aCIsInNldHRpbmdNZW51IiwiaWQiLCJ0aXRsZSIsImljb24iLCJsaW5rIiwic3VibWVudSIsInN1Ym1lbnVJdGVtcyIsIlNldHRpbmdTaWRlYmFyIiwic2hvd01vYmlsZVNpZGViYXIiLCJzZXRTaG93TW9iaWxlU2lkZWJhciIsIl9zIiwib3BlbiIsInNldE9wZW4iLCJzdWJtZW51T3BlbkluZGV4Iiwic2V0U3VibWVudU9wZW5JbmRleCIsIm5lc3RlZFN1Ym1lbnVPcGVuSW5kZXgiLCJzZXROZXN0ZWRTdWJtZW51T3BlbkluZGV4IiwibG9jYXRpb24iLCJ0b2dnbGVTdWJNZW51IiwiaW5kZXgiLCJ0b2dnbGVOZXN0ZWRTdWJNZW51Iiwic3VibWVudUluZGV4Iiwic3ViSW5kZXgiLCJwcmV2U3RhdGUiLCJpc1JvdXRlQWN0aXZlIiwibm9ybWFsaXplZExpbmsiLCJlbmRzV2l0aCIsInNsaWNlIiwibm9ybWFsaXplZFBhdGgiLCJwYXRobmFtZSIsInN0YXJ0c1dpdGgiLCJpc01lbnVBY3RpdmUiLCJtZW51Iiwic29tZSIsInN1Ym1lbnVJdGVtIiwic3ViU3ViSXRlbSIsImFjdGl2ZU1lbnVJbmRleCIsImZpbmRJbmRleCIsImFjdGl2ZU1lbnUiLCJhY3RpdmVTdWJtZW51SW5kZXgiLCJyZW5kZXJJY29uIiwiSWNvbiIsImNsYXNzTmFtZSIsIkljb25Db21wb25lbnQiLCJtYXAiLCJpc09wZW4iLCJtZW51SXNBY3RpdmUiLCJtZW51TGlua0lzQWN0aXZlIiwiZSIsInByZXZlbnREZWZhdWx0IiwiaXNBY3RpdmUiLCJpc05lc3RlZE9wZW4iLCJzdWJtZW51SXNBY3RpdmUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXR0aW5nU2lkZWJhci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgcmVhY3QvcHJvcC10eXBlcyAqL1xyXG5pbXBvcnQgeyBGcmFnbWVudCwgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTmF2TGluaywgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEJhZGdlQ2hlY2ssXHJcbiAgQnJpZWZjYXNlQnVzaW5lc3MsXHJcbiAgQ2hldnJvbkxlZnQsXHJcbiAgQ2hldnJvblJpZ2h0LFxyXG4gIENpcmNsZVVzZXJSb3VuZCxcclxuICBHaWZ0LFxyXG4gIEhlbHBDaXJjbGUsXHJcbiAgTGF5b3V0RGFzaGJvYXJkLFxyXG4gIFNoaWVsZENoZWNrLFxyXG4gIFNsaWRlcnNIb3Jpem9udGFsLFxyXG4gIFNwYXJrbGVzLFxyXG4gIFVzZXJSb3VuZENvZyxcclxuICBVc2Vyc1JvdW5kLFxyXG4gIFdyZW5jaCxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcblxyXG5jb25zdCBzZXR0aW5nc1NpZGViYXJBY2NlbnRDbGFzc2VzID0gW1xyXG4gIFwiYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIGJvcmRlci1ibHVlLTEwMC84MFwiLFxyXG4gIFwiYmctaW5kaWdvLTUwIHRleHQtaW5kaWdvLTcwMCBib3JkZXItaW5kaWdvLTEwMC84MFwiLFxyXG4gIFwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlci1lbWVyYWxkLTEwMC84MFwiLFxyXG4gIFwiYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgYm9yZGVyLWFtYmVyLTEwMC84MFwiLFxyXG4gIFwiYmctc2t5LTUwIHRleHQtc2t5LTcwMCBib3JkZXItc2t5LTEwMC84MFwiLFxyXG4gIFwiYmctdmlvbGV0LTUwIHRleHQtdmlvbGV0LTcwMCBib3JkZXItdmlvbGV0LTEwMC84MFwiLFxyXG4gIFwiYmctcm9zZS01MCB0ZXh0LXJvc2UtNzAwIGJvcmRlci1yb3NlLTEwMC84MFwiLFxyXG4gIFwiYmctdGVhbC01MCB0ZXh0LXRlYWwtNzAwIGJvcmRlci10ZWFsLTEwMC84MFwiLFxyXG4gIFwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGJvcmRlci1zbGF0ZS0yMDAvODBcIixcclxuXTtcclxuXHJcbmNvbnN0IGdldFNldHRpbmdzU2lkZWJhckFjY2VudENsYXNzID0gKGtleSA9IFwiXCIpID0+IHtcclxuICBjb25zdCB0ZXh0ID0gU3RyaW5nKGtleSk7XHJcbiAgY29uc3QgaGFzaCA9IFsuLi50ZXh0XS5yZWR1Y2UoKHN1bSwgY2hhcikgPT4gc3VtICsgY2hhci5jaGFyQ29kZUF0KDApLCAwKTtcclxuICByZXR1cm4gc2V0dGluZ3NTaWRlYmFyQWNjZW50Q2xhc3Nlc1toYXNoICUgc2V0dGluZ3NTaWRlYmFyQWNjZW50Q2xhc3Nlcy5sZW5ndGhdO1xyXG59O1xyXG5jb25zdCBzZXR0aW5nTWVudSA9IFtcclxuICB7IGlkOiAxLCB0aXRsZTogXCJEYXNoYm9hcmRcIiwgaWNvbjogTGF5b3V0RGFzaGJvYXJkLCBsaW5rOiBcIi9kYXNoYm9hcmRcIiB9LFxyXG4gIC8vIHsgaWQ6IDIsIHRpdGxlOiBcIkFuYWx5dGljc1wiLCBpY29uOiBTaUdvb2dsZWFuYWx5dGljcywgbGluazogXCIvYW5hbHl0aWNzXCIgfSxcclxuICB7XHJcbiAgICBpZDogMyxcclxuICAgIHRpdGxlOiBcIkFwcCBTZXR0aW5nc1wiLFxyXG4gICAgaWNvbjogV3JlbmNoLFxyXG4gICAgc3VibWVudTogdHJ1ZSxcclxuICAgIHN1Ym1lbnVJdGVtczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IFwiMy0xXCIsXHJcbiAgICAgICAgdGl0bGU6IFwiR3JvdXBzXCIsXHJcbiAgICAgICAgaWNvbjogVXNlcnNSb3VuZCxcclxuICAgICAgICBzdWJtZW51OiB0cnVlLFxyXG4gICAgICAgIHN1Ym1lbnVJdGVtczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogXCIzLTEtMVwiLFxyXG4gICAgICAgICAgICB0aXRsZTogXCJNb2JpbGUgQWNjZXNzXCIsXHJcbiAgICAgICAgICAgIGljb246IFNsaWRlcnNIb3Jpem9udGFsLFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9sZWFkLXNldHRpbmcvYXBwLXNldHRpbmdzL2dyb3Vwcy9tb2JpbGUtYWNjZXNzXCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogXCIzLTEtMlwiLFxyXG4gICAgICAgICAgICB0aXRsZTogXCJEcmVhbSBBc3NldFwiLFxyXG4gICAgICAgICAgICBpY29uOiBTcGFya2xlcyxcclxuICAgICAgICAgICAgbGluazogXCIvbGVhZC1zZXR0aW5nL2FwcC1zZXR0aW5ncy9ncm91cHMvYXNzZXRcIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiBcIjMtMS0zXCIsXHJcbiAgICAgICAgICAgIHRpdGxlOiBcIkJlY29tZSBBZ2VudFwiLFxyXG4gICAgICAgICAgICBpY29uOiBCcmllZmNhc2VCdXNpbmVzcyxcclxuICAgICAgICAgICAgbGluazogXCIvbGVhZC1zZXR0aW5nL2FwcC1zZXR0aW5ncy9ncm91cHMvYmVjb21lLWFnZW50XCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH0sXHJcblxyXG4gICAge1xyXG4gICAgdGl0bGU6IFwiSW5zdXJhbmNlXCIsXHJcbiAgICBpY29uOiBVc2VyUm91bmRDb2csXHJcbiAgICBsaW5rIDogXCIvaW5zdXJhbmNlXCJcclxuXHJcbiAgfSxcclxuICB7XHJcbiAgICB0aXRsZTogXCJSZXdhcmRcIixcclxuICAgIGljb246IEdpZnQsXHJcbiAgICBsaW5rIDogXCIvZ2lmdC1yZWNlaXZlZFwiXHJcbiAgfSxcclxuICB7IGlkOiA0LCB0aXRsZTogXCJEZXNpZ25hdGlvbnNcIiwgaWNvbjogVXNlclJvdW5kQ29nLCBsaW5rOiBcIi9kZXNpZ25hdGlvblwiIH0sXHJcbiAge1xyXG4gICAgaWQ6IDUsXHJcbiAgICB0aXRsZTogXCJBZG1pbmlzdHJhdGl2ZSBQcml2aWxlZ2VzXCIsXHJcbiAgICBpY29uOiBTaGllbGRDaGVjayxcclxuICAgIGxpbms6IFwiL2FkbWluaXN0cmF0aXZlLXByaXZpbGVnZXNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIHRpdGxlOiBcIkFkbWluIEFjY2VzcyBSaWdodHNcIixcclxuICAgIGljb246IEJhZGdlQ2hlY2ssXHJcbiAgICBsaW5rOiBcIi9hZG1pbi1hY2Nlc3MtcmlnaHRzXCIsXHJcbiAgfSxcclxuICAvLyB7XHJcbiAgLy8gICBpZDogNixcclxuICAvLyAgIHRpdGxlOiBcIlRhcmdldCBNYW5hZ2VtZW50XCIsXHJcbiAgLy8gICBpY29uOiBMdVRhcmdldCxcclxuICAvLyAgIHN1Ym1lbnU6IHRydWUsXHJcbiAgLy8gICBzdWJtZW51SXRlbXM6IFtcclxuICAvLyAgICAge1xyXG4gIC8vICAgICAgIGlkOiBcIjYtMVwiLFxyXG4gIC8vICAgICAgIHRpdGxlOiBcIlRhcmdldFwiLFxyXG4gIC8vICAgICAgIGljb246IFRiVGFyZ2V0QXJyb3csXHJcbiAgLy8gICAgICAgbGluazogXCIvdGFyZ2V0XCIsXHJcbiAgLy8gICAgIH0sXHJcbiAgLy8gICAgIHtcclxuICAvLyAgICAgICBpZDogXCI2LTJcIixcclxuICAvLyAgICAgICB0aXRsZTogXCJSZXBvcnRzXCIsXHJcbiAgLy8gICAgICAgaWNvbjogQnNGaWxlQmFyR3JhcGgsXHJcbiAgLy8gICAgICAgc3VibWVudTogdHJ1ZSxcclxuICAvLyAgICAgICBzdWJtZW51SXRlbXM6IFtcclxuICAvLyAgICAgICAgIHtcclxuICAvLyAgICAgICAgICAgaWQ6IFwiNi0yLTFcIixcclxuICAvLyAgICAgICAgICAgdGl0bGU6IFwiQ29tbWlzc2lvbiBSZXBvcnRcIixcclxuICAvLyAgICAgICAgICAgaWNvbjogVGJHcmFwaCxcclxuICAvLyAgICAgICAgICAgbGluazogXCIvdGFyZ2V0LWNvbW1pc3Npb25cIixcclxuICAvLyAgICAgICAgIH0sXHJcbiAgLy8gICAgICAgICB7XHJcbiAgLy8gICAgICAgICAgIGlkOiBcIjYtMi0yXCIsXHJcbiAgLy8gICAgICAgICAgIHRpdGxlOiBcIkluY2VudGl2ZSBSZXBvcnRcIixcclxuICAvLyAgICAgICAgICAgaWNvbjogVGJHcmFwaEZpbGxlZCxcclxuICAvLyAgICAgICAgICAgbGluazogXCIvdGFyZ2V0LWluY2VudGl2ZVwiLFxyXG4gIC8vICAgICAgICAgfSxcclxuICAvLyAgICAgICBdLFxyXG4gIC8vICAgICB9LFxyXG4gIC8vICAgICB7XHJcbiAgLy8gICAgICAgaWQ6IFwiNi0zXCIsXHJcbiAgLy8gICAgICAgdGl0bGU6IFwiQWNjb3VudHNcIixcclxuICAvLyAgICAgICBpY29uOiBNZEFjY291bnRCYWxhbmNlV2FsbGV0LFxyXG4gIC8vICAgICAgIHN1Ym1lbnU6IHRydWUsXHJcbiAgLy8gICAgICAgc3VibWVudUl0ZW1zOiBbXHJcbiAgLy8gICAgICAgICB7XHJcbiAgLy8gICAgICAgICAgIGlkOiBcIjYtMy0xXCIsXHJcbiAgLy8gICAgICAgICAgIHRpdGxlOiBcIlBheU91dCBNZW51XCIsXHJcbiAgLy8gICAgICAgICAgIGljb246IFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwsXHJcbiAgLy8gICAgICAgICAgIGxpbms6IFwiL3RhcmdldC1wYXlvdXQtbWVudVwiLFxyXG4gIC8vICAgICAgICAgfSxcclxuICAvLyAgICAgICBdLFxyXG4gIC8vICAgICB9LFxyXG4gIC8vICAgXSxcclxuICAvLyB9LFxyXG5cclxuLy8gICAgICAge1xyXG4vLyAgIHRpdGxlOiBcIlBlbmFsdHkgTWFuYWdlbWVudFwiLFxyXG4vLyAgIGljb246IFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwsXHJcbi8vICAgc3VibWVudTogdHJ1ZSxcclxuLy8gICBzdWJtZW51SXRlbXM6IFtcclxuLy8gICAgIHsgdGl0bGU6IFwiUGVuYWx0eSBTZXR0aW5nc1wiLCBpY29uOiBXcmVuY2gsIGxpbms6IFwiL3BlbmFsdHktc2V0dGluZ3NcIiB9LFxyXG4vLyAgICAgeyB0aXRsZTogXCJQZW5hbHR5IE1vbml0b3JcIiwgaWNvbjogVGJHcmFwaCwgbGluazogXCIvcGVuYWx0eS1tb25pdG9yXCIgfSxcclxuLy8gICBdLFxyXG4vLyB9LFxyXG5cclxuICB7IGlkOiA3LCB0aXRsZTogXCJQcm9maWxlXCIsIGljb246IENpcmNsZVVzZXJSb3VuZCwgbGluazogXCIvcHJvZmlsZVwiIH0sXHJcbiAgeyBpZDogOCwgdGl0bGU6IFwiSGVscCAmIFN1cHBvcnRcIiwgaWNvbjogSGVscENpcmNsZSwgbGluazogXCIvaGVscFwiIH0sXHJcbl07XHJcblxyXG5jb25zdCBTZXR0aW5nU2lkZWJhciA9ICh7IHNob3dNb2JpbGVTaWRlYmFyID0gZmFsc2UsIHNldFNob3dNb2JpbGVTaWRlYmFyID0gKCkgPT4ge30gfSkgPT4ge1xyXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtzdWJtZW51T3BlbkluZGV4LCBzZXRTdWJtZW51T3BlbkluZGV4XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtuZXN0ZWRTdWJtZW51T3BlbkluZGV4LCBzZXROZXN0ZWRTdWJtZW51T3BlbkluZGV4XSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVN1Yk1lbnUgPSAoaW5kZXgpID0+IHtcclxuICAgIHNldFN1Ym1lbnVPcGVuSW5kZXgoc3VibWVudU9wZW5JbmRleCA9PT0gaW5kZXggPyBudWxsIDogaW5kZXgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvZ2dsZU5lc3RlZFN1Yk1lbnUgPSAoc3VibWVudUluZGV4LCBzdWJJbmRleCkgPT4ge1xyXG4gICAgc2V0TmVzdGVkU3VibWVudU9wZW5JbmRleCgocHJldlN0YXRlKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2U3RhdGUsXHJcbiAgICAgIFtzdWJtZW51SW5kZXhdOiBwcmV2U3RhdGVbc3VibWVudUluZGV4XSA9PT0gc3ViSW5kZXggPyBudWxsIDogc3ViSW5kZXgsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaXNSb3V0ZUFjdGl2ZSA9IHVzZUNhbGxiYWNrKChsaW5rKSA9PiB7XHJcbiAgICBpZiAoIWxpbmsgfHwgbGluayA9PT0gXCIjXCIpIHJldHVybiBmYWxzZTtcclxuXHJcbiAgICBjb25zdCBub3JtYWxpemVkTGluayA9IGxpbmsuZW5kc1dpdGgoXCIvXCIpICYmIGxpbmsubGVuZ3RoID4gMSA/IGxpbmsuc2xpY2UoMCwgLTEpIDogbGluaztcclxuICAgIGNvbnN0IG5vcm1hbGl6ZWRQYXRoID0gbG9jYXRpb24ucGF0aG5hbWUuZW5kc1dpdGgoXCIvXCIpICYmIGxvY2F0aW9uLnBhdGhuYW1lLmxlbmd0aCA+IDFcclxuICAgICAgPyBsb2NhdGlvbi5wYXRobmFtZS5zbGljZSgwLCAtMSlcclxuICAgICAgOiBsb2NhdGlvbi5wYXRobmFtZTtcclxuXHJcbiAgICByZXR1cm4gbm9ybWFsaXplZFBhdGggPT09IG5vcm1hbGl6ZWRMaW5rIHx8IG5vcm1hbGl6ZWRQYXRoLnN0YXJ0c1dpdGgoYCR7bm9ybWFsaXplZExpbmt9L2ApO1xyXG4gIH0sIFtsb2NhdGlvbi5wYXRobmFtZV0pO1xyXG5cclxuICBjb25zdCBpc01lbnVBY3RpdmUgPSB1c2VDYWxsYmFjaygobWVudSkgPT4ge1xyXG4gICAgaWYgKGlzUm91dGVBY3RpdmUobWVudS5saW5rKSkgcmV0dXJuIHRydWU7XHJcblxyXG4gICAgcmV0dXJuIG1lbnUuc3VibWVudUl0ZW1zPy5zb21lKChzdWJtZW51SXRlbSkgPT4ge1xyXG4gICAgICBpZiAoaXNSb3V0ZUFjdGl2ZShzdWJtZW51SXRlbS5saW5rKSkgcmV0dXJuIHRydWU7XHJcbiAgICAgIHJldHVybiBzdWJtZW51SXRlbS5zdWJtZW51SXRlbXM/LnNvbWUoKHN1YlN1Ykl0ZW0pID0+IGlzUm91dGVBY3RpdmUoc3ViU3ViSXRlbS5saW5rKSk7XHJcbiAgICB9KTtcclxuICB9LCBbaXNSb3V0ZUFjdGl2ZV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgYWN0aXZlTWVudUluZGV4ID0gc2V0dGluZ01lbnUuZmluZEluZGV4KGlzTWVudUFjdGl2ZSk7XHJcblxyXG4gICAgaWYgKGFjdGl2ZU1lbnVJbmRleCA9PT0gLTEpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBhY3RpdmVNZW51ID0gc2V0dGluZ01lbnVbYWN0aXZlTWVudUluZGV4XTtcclxuXHJcbiAgICBpZiAoYWN0aXZlTWVudT8uc3VibWVudSkge1xyXG4gICAgICBzZXRTdWJtZW51T3BlbkluZGV4KGFjdGl2ZU1lbnVJbmRleCk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYWN0aXZlU3VibWVudUluZGV4ID0gYWN0aXZlTWVudT8uc3VibWVudUl0ZW1zPy5maW5kSW5kZXgoKHN1Ym1lbnVJdGVtKSA9PiB7XHJcbiAgICAgIGlmIChpc1JvdXRlQWN0aXZlKHN1Ym1lbnVJdGVtLmxpbmspKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgcmV0dXJuIHN1Ym1lbnVJdGVtLnN1Ym1lbnVJdGVtcz8uc29tZSgoc3ViU3ViSXRlbSkgPT4gaXNSb3V0ZUFjdGl2ZShzdWJTdWJJdGVtLmxpbmspKTtcclxuICAgIH0pO1xyXG5cclxuICAgIGlmIChhY3RpdmVTdWJtZW51SW5kZXggPj0gMCAmJiBhY3RpdmVNZW51Py5zdWJtZW51SXRlbXM/LlthY3RpdmVTdWJtZW51SW5kZXhdPy5zdWJtZW51KSB7XHJcbiAgICAgIHNldE5lc3RlZFN1Ym1lbnVPcGVuSW5kZXgoKHByZXZTdGF0ZSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2U3RhdGUsXHJcbiAgICAgICAgW2FjdGl2ZU1lbnVJbmRleF06IGFjdGl2ZVN1Ym1lbnVJbmRleCxcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtpc01lbnVBY3RpdmUsIGlzUm91dGVBY3RpdmUsIGxvY2F0aW9uLnBhdGhuYW1lXSk7XHJcblxyXG4gIGNvbnN0IHJlbmRlckljb24gPSAoSWNvbiwgY2xhc3NOYW1lID0gXCJcIikgPT4ge1xyXG4gICAgaWYgKCFJY29uKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgICBjb25zdCBJY29uQ29tcG9uZW50ID0gSWNvbjtcclxuICAgIHJldHVybiA8SWNvbkNvbXBvbmVudCBjbGFzc05hbWU9e2NsYXNzTmFtZX0gc3Ryb2tlV2lkdGg9ezEuOH0gLz47XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgaGlkZGVuIHNocmluay0wIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBtZDpibG9jayAke29wZW4gPyBcInctNjRcIiA6IFwidy0yMFwifWB9IC8+XHJcblxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgc2lkZWJhci1zY3JvbGxiYXIgZml4ZWQgbGVmdC0wIHRvcC1bNjhweF0gei00MCBoLVtjYWxjKDEwMHZoLTY4cHgpXSBzaHJpbmstMCBvdmVyZmxvdy15LWF1dG8gb3ZlcmZsb3cteC1oaWRkZW4gYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS84MCBzaGFkb3ctWzFweF8wXzE4cHhfcmdiYSgxNSwyMyw0MiwwLjA1KV0gYmFja2Ryb3AtYmx1ci0yeGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwICR7b3BlbiA/IFwidy02NFwiIDogXCJ3LTIwXCJ9ICR7c2hvd01vYmlsZVNpZGViYXIgPyBcInRyYW5zbGF0ZS14LTBcIiA6IFwiLXRyYW5zbGF0ZS14LWZ1bGwgbWQ6dHJhbnNsYXRlLXgtMFwifWB9XHJcbiAgICAgID5cclxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yIHB4LTMgcGItNSBwdC0zXCI+XHJcbiAgICAgICAgICB7c2V0dGluZ01lbnUubWFwKChtZW51LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBpc09wZW4gPSBzdWJtZW51T3BlbkluZGV4ID09PSBpbmRleDtcclxuICAgICAgICAgICAgY29uc3QgbWVudUlzQWN0aXZlID0gaXNNZW51QWN0aXZlKG1lbnUpO1xyXG4gICAgICAgICAgICBjb25zdCBtZW51TGlua0lzQWN0aXZlID0gaXNSb3V0ZUFjdGl2ZShtZW51LmxpbmspO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICA8RnJhZ21lbnQga2V5PXttZW51LmlkIHx8IG1lbnUudGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgICAgICAgdG89e21lbnUubGluayB8fCBcIiNcIn1cclxuICAgICAgICAgICAgICAgICAgZW5kXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1lbnUuc3VibWVudSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgdG9nZ2xlU3ViTWVudShpbmRleCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgYGdyb3VwIHJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIHB5LTIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7b3BlbiA/IFwiZ2FwLXgtMyBweC0zXCIgOiBcImp1c3RpZnktY2VudGVyIHB4LTBcIn0gJHsoaXNBY3RpdmUgJiYgIW1lbnUuc3VibWVudSkgfHwgbWVudUlzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWluZGlnby0xMDAvODAgYmctaW5kaWdvLTUwLzgwIHRleHQtaW5kaWdvLTcwMCBmb250LXNlbWlib2xkIHNoYWRvdy1zbSBzaGFkb3ctaW5kaWdvLTkwMC9bMC4wM11cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTYwMCBob3Zlcjpib3JkZXItc2xhdGUtMjAwLzcwIGhvdmVyOmJnLXdoaXRlLzcwIGhvdmVyOnRleHQtc2xhdGUtOTUwXCJcclxuICAgICAgICAgICAgICAgICAgICB9YFxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHsoKG1lbnVMaW5rSXNBY3RpdmUgJiYgIW1lbnUuc3VibWVudSkgfHwgbWVudUlzQWN0aXZlKSAmJiBvcGVuICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTAgdG9wLTEvMiBoLTYgdy0xIC10cmFuc2xhdGUteS0xLzIgcm91bmRlZC1yLWZ1bGwgYmctWyMwMDcxZTNdLzcwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZ3JpZCBoLTkgdy05IHNocmluay0wIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCAke2dldFNldHRpbmdzU2lkZWJhckFjY2VudENsYXNzKG1lbnUudGl0bGUpfSAkeygobWVudUxpbmtJc0FjdGl2ZSAmJiAhbWVudS5zdWJtZW51KSB8fCBtZW51SXNBY3RpdmUpID8gXCJyaW5nLTIgcmluZy1bIzAwNzFlM10vMTVcIiA6IFwiZ3JvdXAtaG92ZXI6c2NhbGUtWzEuMDNdXCJ9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge3JlbmRlckljb24obWVudS5pY29uLCBcImgtWzE4cHhdIHctWzE4cHhdXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGZsZXgtMSB0cnVuY2F0ZSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgJHshb3BlbiAmJiBcImhpZGRlblwifWB9PlxyXG4gICAgICAgICAgICAgICAgICAgIHttZW51LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHttZW51LnN1Ym1lbnUgJiYgb3BlbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbWwtYXV0byBoLTQgdy00IHNocmluay0wIHRleHQtc2xhdGUtNDAwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMCAke2lzT3BlbiA/IFwicm90YXRlLTkwIHRleHQtWyMwMDcxZTNdXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17MS44fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcblxyXG4gICAgICAgICAgICAgICAge21lbnUuc3VibWVudSAmJiBpc09wZW4gJiYgb3BlbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtbC0zIG10LTEgc3BhY2UteS0xIGJvcmRlci1sIGJvcmRlci1zbGF0ZS0yMDAvNzAgcGwtMyBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHttZW51LnN1Ym1lbnVJdGVtcy5tYXAoKHN1Ym1lbnVJdGVtLCBzdWJJbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNOZXN0ZWRPcGVuID0gbmVzdGVkU3VibWVudU9wZW5JbmRleFtpbmRleF0gPT09IHN1YkluZGV4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3VibWVudUlzQWN0aXZlID0gaXNSb3V0ZUFjdGl2ZShzdWJtZW51SXRlbS5saW5rKSB8fCBzdWJtZW51SXRlbS5zdWJtZW51SXRlbXM/LnNvbWUoKHN1YlN1Ykl0ZW0pID0+IGlzUm91dGVBY3RpdmUoc3ViU3ViSXRlbS5saW5rKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZyYWdtZW50IGtleT17c3VibWVudUl0ZW0uaWQgfHwgc3VibWVudUl0ZW0udGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17c3VibWVudUl0ZW0ubGluayB8fCBcIiNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHN1Ym1lbnVJdGVtLnN1Ym1lbnUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9nZ2xlTmVzdGVkU3ViTWVudShpbmRleCwgc3ViSW5kZXgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1sZyBweC0zIHB5LTIuNSB0ZXh0LXNtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke2lzQWN0aXZlIHx8IHN1Ym1lbnVJc0FjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXIgYm9yZGVyLWluZGlnby0xMDAvODAgYmctaW5kaWdvLTUwLzgwIHRleHQtaW5kaWdvLTcwMCBmb250LXNlbWlib2xkIHNoYWRvdy1zbSBzaGFkb3ctaW5kaWdvLTkwMC9bMC4wM11cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNjAwIGhvdmVyOmJvcmRlci1zbGF0ZS0yMDAvNzAgaG92ZXI6Ymctd2hpdGUvNzAgaG92ZXI6dGV4dC1zbGF0ZS05NTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdWJtZW51SXRlbS5pY29uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbXItMiBncmlkIGgtOCB3LTggc2hyaW5rLTAgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtbGcgYm9yZGVyICR7Z2V0U2V0dGluZ3NTaWRlYmFyQWNjZW50Q2xhc3Moc3VibWVudUl0ZW0udGl0bGUpfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZW5kZXJJY29uKHN1Ym1lbnVJdGVtLmljb24sIFwiaC00IHctNFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSB0cnVuY2F0ZVwiPntzdWJtZW51SXRlbS50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VibWVudUl0ZW0uc3VibWVudSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtbC1hdXRvIGgtMy41IHctMy41IHNocmluay0wIHRleHQtc2xhdGUtNDAwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMCAke2lzTmVzdGVkT3BlbiA/IFwicm90YXRlLTkwIHRleHQtWyMwMDcxZTNdXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezEuOH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VibWVudUl0ZW0uc3VibWVudSAmJiBpc05lc3RlZE9wZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm1sLTQgbXQtMSBzcGFjZS15LTEgYm9yZGVyLWwgYm9yZGVyLXNsYXRlLTIwMC83MCBwbC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdWJtZW51SXRlbS5zdWJtZW51SXRlbXMubWFwKChzdWJTdWJJdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17c3ViU3ViSXRlbS5pZCB8fCBzdWJTdWJJdGVtLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3N1YlN1Ykl0ZW0ubGlua31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtpc0FjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXIgYm9yZGVyLWluZGlnby0xMDAvODAgYmctaW5kaWdvLTUwLzgwIHRleHQtaW5kaWdvLTcwMCBmb250LXNlbWlib2xkIHNoYWRvdy1zbSBzaGFkb3ctaW5kaWdvLTkwMC9bMC4wM11cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNjAwIGhvdmVyOmJvcmRlci1zbGF0ZS0yMDAvNzAgaG92ZXI6Ymctd2hpdGUvNzAgaG92ZXI6dGV4dC1zbGF0ZS05NTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdWJTdWJJdGVtLmljb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Btci0yIGdyaWQgaC03IHctNyBzaHJpbmstMCBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgJHtnZXRTZXR0aW5nc1NpZGViYXJBY2NlbnRDbGFzcyhzdWJTdWJJdGVtLnRpdGxlKX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVuZGVySWNvbihzdWJTdWJJdGVtLmljb24sIFwiaC0zLjUgdy0zLjVcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntzdWJTdWJJdGVtLnRpdGxlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ZyYWdtZW50PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9GcmFnbWVudD5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvdWw+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oIW9wZW4pfVxyXG4gICAgICAgIGNsYXNzTmFtZT17YGZpeGVkIHRvcC0yMCB6LTUwIGhpZGRlbiBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNzAgYmctd2hpdGUvODUgdGV4dC1zbGF0ZS02MDAgc2hhZG93LWxnIHNoYWRvdy1zbGF0ZS05MDAvMTAgYmFja2Ryb3AtYmx1ci14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6Ymctd2hpdGUgaG92ZXI6dGV4dC1bIzAwNzFlM10gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yNSBtZDpmbGV4ICR7b3BlbiA/IFwibGVmdC02MFwiIDogXCJsZWZ0LTE2IHJvdGF0ZS0xODBcIn1gfVxyXG4gICAgICAgIGFyaWEtbGFiZWw9e29wZW4gPyBcIkNvbGxhcHNlIHNldHRpbmdzIHNpZGViYXJcIiA6IFwiRXhwYW5kIHNldHRpbmdzIHNpZGViYXJcIn1cclxuICAgICAgPlxyXG4gICAgICAgIDxDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJoLTUgdy01XCIgc3Ryb2tlV2lkdGg9ezEuOH0gLz5cclxuICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICB7c2hvd01vYmlsZVNpZGViYXIgJiYgKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei0zMCBiZy1zbGF0ZS05MDAvMjAgYmFja2Ryb3AtYmx1ci1bMnB4XSBtZDpoaWRkZW5cIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vYmlsZVNpZGViYXIoZmFsc2UpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2V0dGluZ1NpZGViYXI7XHJcblxyXG5cclxuXHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9jb21wb25lbnRzL2xheW91dHMvU2V0dGluZ1NpZGViYXIuanN4In0=