import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OverDueEmail.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { MdMarkEmailRead } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
const OverDueEmail = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const groupOptions = [...new Set(usersData.map((u) => u.groupName))];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    balance: user.balance,
                    userPhone: user.userPhone,
                    paymentsTicket: user.paymentsTicket,
                    groupName: user.groupName,
                    userName: user.userName,
                    groupId: user.groupId,
                    userId: user.userId,
                    amountPaid: user.amountPaid,
                    amountToBePaid: user.totalToBePaid,
                    userEmail: user.userEmail,
                    latestPaymentDate: user.latestPaymentDate,
                    // ✅ added
                    latestPaymentAmount: user.latestPaymentAmount,
                    // ✅ added
                    paymentType: user.payment_type
                    // ✅ added
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
            lineNumber: 46,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendEmail = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Emails..",
        description: "Processing...",
        className: "bg-violet-300 rounded-lg font-bold",
        duration: 2
      });
      const selectedUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          selectedUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/email/over-due-email", selectedUsers);
      const updatedActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete updatedActiveUserData[user._id];
        }
      });
      setActiveUserData(updatedActiveUserData);
      notifier.open({
        key,
        message: "Emails Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Emails",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/user/get-overdue-payments");
      const usersList = [];
      const tempActive = {};
      reportResponse.data.forEach((usrData) => {
        if (usrData?.data) {
          usrData.data.forEach((data) => {
            if (data?.enrollment?.group) {
              const groupInstall = parseInt(
                data.enrollment.group.group_install
              );
              const groupId = data.enrollment.group._id;
              const groupType = data.enrollment.group.group_type;
              const totalPaidAmount = data.payments.totalPaidAmount;
              const auctionCount = parseInt(data?.auction?.auctionCount);
              const totalPayable = data.payable.totalPayable;
              const totalProfit = data.profit.totalProfit;
              const firstDividentHead = data.firstAuction.firstDividentHead;
              const id = data?.enrollment?._id;
              const userPhone = usrData.phone_number;
              const userEmail = usrData.email;
              const paymentsTicket = data.payments.ticket;
              const groupName = data.enrollment.group.group_name;
              const totalToBePaid = groupType === "double" ? groupInstall * auctionCount + groupInstall : totalPayable + groupInstall + totalProfit;
              const amountToBePaid = totalToBePaid;
              const balance = groupType === "double" ? totalToBePaid - totalPaidAmount : totalPayable + groupInstall + firstDividentHead - totalPaidAmount;
              if (balance <= 0) return;
              const userName = usrData.userName;
              const latestPaymentAmount = data.latestPaymentAmount || 0;
              const latestPaymentDate = data.latestPaymentDate || "";
              tempActive[id] = {
                info: {
                  status: false,
                  balance
                }
              };
              const tempUsr = {
                _id: id,
                userName,
                userPhone,
                userEmail,
                customerId: usrData.customer_id,
                amountPaid: totalPaidAmount,
                paymentsTicket,
                amountToBePaid,
                groupName,
                payment_type: data?.enrollment?.payment_type,
                totalToBePaid,
                balance,
                groupId,
                userId: usrData?._id,
                latestPaymentAmount,
                // ⬅ New field
                latestPaymentDate
                // ⬅ New field
              };
              console.info("tempUsr", tempUsr);
              usersList.push(tempUsr);
            }
          });
        }
      });
      setUsersData(usersList);
      setActiveUserData(tempActive);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "userEmail", header: "Email" },
    { key: "payment_type", header: "Payment Type" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "totalToBePaid", header: "Amount to be Paid" },
    { key: "amountPaid", header: "Paid Amount" },
    { key: "latestPaymentAmount", header: "Last Payment Amount" },
    // ✅ NEW
    {
      key: "latestPaymentDate",
      header: "Last Payment Date",
      render: (value) => value ? new Date(value).toLocaleDateString("en-IN") : "N/A"
      // ✅ NEW
    },
    { key: "balance", header: "Balance" },
    { key: "checkBoxs", header: "Select User" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "w-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-30", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
        lineNumber: 252,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center", children: "Outstanding Email [Over]" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
        lineNumber: 258,
        columnNumber: 13
      }, this),
      contextHolder,
      isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
        lineNumber: 264,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
        lineNumber: 263,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
          lineNumber: 268,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Group Filter" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
              lineNumber: 272,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: 200 },
                allowClear: true,
                placeholder: "--All groups--",
                onChange: (value) => setGroupFilter(value),
                value: groupFilter || void 0,
                children: groupOptions.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
                    lineNumber: 283,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
                lineNumber: 275,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
            lineNumber: 271,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
            lineNumber: 270,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendEmail,
              className: "relative bg-violet-600 text-white px-4 py-2 rounded shadow-md hover:bg-violet-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
                      lineNumber: 300,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
                    lineNumber: 296,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(MdMarkEmailRead, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
                  lineNumber: 303,
                  columnNumber: 21
                }, this),
                "Email"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
              lineNumber: 291,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
            lineNumber: 290,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Over  Email",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Overdue Email.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
              lineNumber: 307,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
          lineNumber: 269,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
        lineNumber: 267,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
      lineNumber: 257,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
    lineNumber: 251,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx",
    lineNumber: 250,
    columnNumber: 5
  }, this);
};
_s(OverDueEmail, "s7XK8nFGNcWMPxK2A58pkJWZq2g=", false, function() {
  return [notification.useNotification];
});
_c = OverDueEmail;
export default OverDueEmail;
var _c;
$RefreshReg$(_c, "OverDueEmail");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OverDueEmail.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNVOzJCQTdDVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyx1QkFBdUI7QUFFaEMsTUFBTUMsZUFBZUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3pCLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJZCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDZSxXQUFXQyxZQUFZLElBQUloQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDaUIsYUFBYUMsY0FBYyxJQUFJbEIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ21CLFVBQVVDLFdBQVcsSUFBSXBCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNxQixRQUFRQyxTQUFTLElBQUl0QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDdUIsZ0JBQWdCQyxpQkFBaUIsSUFBSXhCLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQixZQUFZQyxhQUFhLElBQUk1QixTQUFTLENBQUM7QUFDOUMsUUFBTSxDQUFDNkIsVUFBVUMsYUFBYSxJQUFJckIsYUFBYXNCLGdCQUFnQjtBQUUvRCxRQUFNQyxlQUFlLENBQUMsR0FBRyxJQUFJQyxJQUFJbEIsVUFBVW1CLElBQUksQ0FBQ0MsTUFBTUEsRUFBRUMsU0FBUyxDQUFDLENBQUM7QUFFbkUsUUFBTUMsZ0JBQWdCcEMsUUFBUSxNQUFNO0FBQ2xDLFVBQU1xQyxXQUFXL0I7QUFBQUEsTUFDZlEsVUFBVXdCLE9BQU8sQ0FBQ0osTUFBTTtBQUN0QixjQUFNSyxhQUFhdkIsY0FBY2tCLEVBQUVDLGNBQWNuQixjQUFjO0FBQy9ELGNBQU13QixpQkFBaUIsSUFBSUMsS0FBS1AsRUFBRU0sY0FBYztBQUNoRCxjQUFNRSxnQkFBZ0J4QixXQUNsQnNCLGtCQUFrQixJQUFJQyxLQUFLdkIsUUFBUSxJQUNuQztBQUNKLGNBQU15QixjQUFjdkIsU0FBU29CLGtCQUFrQixJQUFJQyxLQUFLckIsTUFBTSxJQUFJO0FBQ2xFLGVBQU9tQixjQUFjRyxpQkFBaUJDO0FBQUFBLE1BQ3hDLENBQUM7QUFBQSxNQUNEL0I7QUFBQUEsSUFDRjtBQUVBLFdBQU95QixTQUFTSixJQUFJLENBQUNXLE1BQU1DLFVBQVU7QUFDbkMsWUFBTUMsYUFBYSxDQUFDLENBQUN4QixlQUFlc0IsS0FBS0csR0FBRyxHQUFHQyxNQUFNQztBQUVyRCxhQUFPO0FBQUEsUUFDTCxHQUFHTDtBQUFBQSxRQUNITSxPQUFPTCxRQUFRO0FBQUEsUUFDZk0sV0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU0w7QUFBQUEsWUFDVCxVQUFVLENBQUNNLE1BQU07QUFDZjdCLGdDQUFrQixDQUFDOEIsVUFBVTtBQUFBLGdCQUMzQixHQUFHQTtBQUFBQSxnQkFDSCxDQUFDVCxLQUFLRyxHQUFHLEdBQUc7QUFBQSxrQkFDVkMsTUFBTTtBQUFBLG9CQUNKQyxRQUFRRyxFQUFFRSxPQUFPQztBQUFBQSxvQkFDakJDLFNBQVNaLEtBQUtZO0FBQUFBLG9CQUNkQyxXQUFXYixLQUFLYTtBQUFBQSxvQkFDaEJDLGdCQUFnQmQsS0FBS2M7QUFBQUEsb0JBQ3JCdkIsV0FBV1MsS0FBS1Q7QUFBQUEsb0JBQ2hCd0IsVUFBVWYsS0FBS2U7QUFBQUEsb0JBQ2ZDLFNBQVNoQixLQUFLZ0I7QUFBQUEsb0JBQ2RDLFFBQVFqQixLQUFLaUI7QUFBQUEsb0JBQ2JDLFlBQVlsQixLQUFLa0I7QUFBQUEsb0JBQ2pCQyxnQkFBZ0JuQixLQUFLb0I7QUFBQUEsb0JBQ3JCQyxXQUFXckIsS0FBS3FCO0FBQUFBLG9CQUNoQkMsbUJBQW1CdEIsS0FBS3NCO0FBQUFBO0FBQUFBLG9CQUN4QkMscUJBQXFCdkIsS0FBS3VCO0FBQUFBO0FBQUFBLG9CQUMxQkMsYUFBYXhCLEtBQUt5QjtBQUFBQTtBQUFBQSxrQkFDcEI7QUFBQSxnQkFDRjtBQUFBLGNBQ0YsRUFBRTtBQUFBLFlBQ0o7QUFBQTtBQUFBLFVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXlCSTtBQUFBLFFBR052QjtBQUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNoQyxXQUFXRSxhQUFhRSxVQUFVRSxRQUFRUixZQUFZVSxjQUFjLENBQUM7QUFFekUsUUFBTWdELHVCQUF1QnRFLFFBQVEsTUFBTTtBQUN6QyxXQUFPb0MsY0FBY0UsT0FBTyxDQUFDTSxTQUFTQSxLQUFLRSxVQUFVLEVBQUV5QjtBQUFBQSxFQUN6RCxHQUFHLENBQUNuQyxhQUFhLENBQUM7QUFFbkIsUUFBTW9DLFlBQVksWUFBWTtBQUM3QixVQUFNQyxNQUFNO0FBQ1osUUFBSTtBQUNGN0MsZUFBUzhDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBR0QsWUFBTUMsZ0JBQWdCLENBQUM7QUFDdkIzQyxvQkFBYzRDLFFBQVEsQ0FBQ3BDLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsY0FBY3hCLGVBQWVzQixLQUFLRyxHQUFHLEdBQUc7QUFDL0NnQyx3QkFBY25DLEtBQUtHLEdBQUcsSUFBSXpCLGVBQWVzQixLQUFLRyxHQUFHO0FBQUEsUUFDbkQ7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNOUMsSUFBSWdGLEtBQUsseUJBQXlCRixhQUFhO0FBR3JELFlBQU1HLHdCQUF3QixFQUFFLEdBQUc1RCxlQUFlO0FBQ2xEYyxvQkFBYzRDLFFBQVEsQ0FBQ3BDLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsWUFBWTtBQUNuQixpQkFBT29DLHNCQUFzQnRDLEtBQUtHLEdBQUc7QUFBQSxRQUN2QztBQUFBLE1BQ0YsQ0FBQztBQUNEeEIsd0JBQWtCMkQscUJBQXFCO0FBRXZDdEQsZUFBUzhDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSCxTQUFTSyxLQUFLO0FBQ1p2RCxlQUFTOEMsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhTyxJQUFJUixXQUFXO0FBQUEsUUFDNUJFLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFRSxRQUFNTSxZQUFZLFlBQVk7QUFDNUIsUUFBSTtBQUNGM0QsbUJBQWEsSUFBSTtBQUNqQixZQUFNNEQsaUJBQWlCLE1BQU1wRixJQUFJcUYsSUFBSSw0QkFBNEI7QUFDakUsWUFBTUMsWUFBWTtBQUNsQixZQUFNQyxhQUFhLENBQUM7QUFFcEJILHFCQUFlSSxLQUFLVCxRQUFRLENBQUNVLFlBQVk7QUFDdkMsWUFBSUEsU0FBU0QsTUFBTTtBQUNqQkMsa0JBQVFELEtBQUtULFFBQVEsQ0FBQ1MsU0FBUztBQUM3QixnQkFBSUEsTUFBTUUsWUFBWUMsT0FBTztBQUMzQixvQkFBTUMsZUFBZUM7QUFBQUEsZ0JBQ25CTCxLQUFLRSxXQUFXQyxNQUFNRztBQUFBQSxjQUN4QjtBQUNBLG9CQUFNbkMsVUFBVTZCLEtBQUtFLFdBQVdDLE1BQU03QztBQUN0QyxvQkFBTWlELFlBQVlQLEtBQUtFLFdBQVdDLE1BQU1LO0FBQ3hDLG9CQUFNQyxrQkFBa0JULEtBQUtVLFNBQVNEO0FBQ3RDLG9CQUFNRSxlQUFlTixTQUFTTCxNQUFNWSxTQUFTRCxZQUFZO0FBQ3pELG9CQUFNRSxlQUFlYixLQUFLYyxRQUFRRDtBQUNsQyxvQkFBTUUsY0FBY2YsS0FBS2dCLE9BQU9EO0FBQ2hDLG9CQUFNRSxvQkFBb0JqQixLQUFLa0IsYUFBYUQ7QUFDNUMsb0JBQU1FLEtBQUtuQixNQUFNRSxZQUFZNUM7QUFDN0Isb0JBQU1VLFlBQVlpQyxRQUFRbUI7QUFDMUIsb0JBQU01QyxZQUFZeUIsUUFBUW9CO0FBQzFCLG9CQUFNcEQsaUJBQWlCK0IsS0FBS1UsU0FBU1k7QUFDckMsb0JBQU01RSxZQUFZc0QsS0FBS0UsV0FBV0MsTUFBTW9CO0FBR3hDLG9CQUFNaEQsZ0JBQ0pnQyxjQUFjLFdBQ1ZILGVBQWVPLGVBQWVQLGVBQzlCUyxlQUFlVCxlQUFlVztBQUNwQyxvQkFBTXpDLGlCQUFpQkM7QUFFdkIsb0JBQU1SLFVBQ0p3QyxjQUFjLFdBQ1ZoQyxnQkFBZ0JrQyxrQkFDaEJJLGVBQ0FULGVBQ0FhLG9CQUNBUjtBQUVOLGtCQUFJMUMsV0FBVyxFQUFHO0FBRWxCLG9CQUFNRyxXQUFXK0IsUUFBUS9CO0FBR3pCLG9CQUFNUSxzQkFBc0JzQixLQUFLdEIsdUJBQXVCO0FBQ3hELG9CQUFNRCxvQkFBb0J1QixLQUFLdkIscUJBQXFCO0FBRXBEc0IseUJBQVdvQixFQUFFLElBQUk7QUFBQSxnQkFDZjVELE1BQU07QUFBQSxrQkFDSkMsUUFBUTtBQUFBLGtCQUNSTztBQUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFFQSxvQkFBTXlELFVBQVU7QUFBQSxnQkFDZGxFLEtBQUs2RDtBQUFBQSxnQkFDTGpEO0FBQUFBLGdCQUNBRjtBQUFBQSxnQkFDQVE7QUFBQUEsZ0JBQ0FpRCxZQUFZeEIsUUFBUXlCO0FBQUFBLGdCQUNwQnJELFlBQVlvQztBQUFBQSxnQkFDWnhDO0FBQUFBLGdCQUNBSztBQUFBQSxnQkFDQTVCO0FBQUFBLGdCQUNBa0MsY0FBY29CLE1BQU1FLFlBQVl0QjtBQUFBQSxnQkFDaENMO0FBQUFBLGdCQUNBUjtBQUFBQSxnQkFDQUk7QUFBQUEsZ0JBQ0FDLFFBQVE2QixTQUFTM0M7QUFBQUEsZ0JBQ2pCb0I7QUFBQUE7QUFBQUEsZ0JBQ0FEO0FBQUFBO0FBQUFBLGNBQ0Y7QUFDQWtELHNCQUFRcEUsS0FBSyxXQUFXaUUsT0FBTztBQUMvQjFCLHdCQUFVOEIsS0FBS0osT0FBTztBQUFBLFlBQ3hCO0FBQUEsVUFDRixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0YsQ0FBQztBQUVEbEcsbUJBQWF3RSxTQUFTO0FBQ3RCaEUsd0JBQWtCaUUsVUFBVTtBQUM1QjdELG9CQUFjNEQsVUFBVWhCLE1BQU07QUFBQSxJQUNoQyxTQUFTK0MsT0FBTztBQUNkRixjQUFRRSxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDLFVBQUM7QUFDQzdGLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQTNCLFlBQVUsTUFBTTtBQUNkc0YsY0FBVTtBQUFBLEVBQ1osR0FBRyxFQUFFO0FBRUwsUUFBTW1DLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUU5QyxLQUFLLFNBQVMrQyxRQUFRLFNBQVM7QUFBQSxJQUNqQyxFQUFFL0MsS0FBSyxZQUFZK0MsUUFBUSxnQkFBZ0I7QUFBQSxJQUMzQyxFQUFFL0MsS0FBSyxhQUFhK0MsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRS9DLEtBQUssY0FBYytDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUUvQyxLQUFLLGFBQWErQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFDL0MsS0FBSyxhQUFhK0MsUUFBUSxRQUFPO0FBQUEsSUFDbEMsRUFBRS9DLEtBQUssZ0JBQWdCK0MsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRS9DLEtBQUssa0JBQWtCK0MsUUFBUSxTQUFTO0FBQUEsSUFDMUMsRUFBRS9DLEtBQUssaUJBQWlCK0MsUUFBUSxvQkFBb0I7QUFBQSxJQUNwRCxFQUFFL0MsS0FBSyxjQUFjK0MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRS9DLEtBQUssdUJBQXVCK0MsUUFBUSxzQkFBc0I7QUFBQTtBQUFBLElBQzVEO0FBQUEsTUFDRS9DLEtBQUs7QUFBQSxNQUNMK0MsUUFBUTtBQUFBLE1BQ1JDLFFBQVFBLENBQUNDLFVBQ1BBLFFBQVEsSUFBSWpGLEtBQUtpRixLQUFLLEVBQUVDLG1CQUFtQixPQUFPLElBQUk7QUFBQTtBQUFBLElBQzFEO0FBQUEsSUFDQSxFQUFFbEQsS0FBSyxXQUFXK0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRS9DLEtBQUssYUFBYStDLFFBQVEsY0FBYztBQUFBLEVBQUM7QUFHN0MsU0FDRSx1QkFBQyxTQUFJLFdBQVUsWUFDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkIsQ0FBQ3BFLE1BQU12QyxjQUFjdUMsRUFBRUUsT0FBT29FLEtBQUs7QUFBQSxRQUNoRSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBR2pCLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxrQ0FBaUMsd0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0M3RjtBQUFBQSxNQUNDTCxZQUNKLHVCQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLGtCQUFlLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUUsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQ2xFLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8sRUFBRW9HLE9BQU8sSUFBSTtBQUFBLGdCQUNwQjtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixVQUFVLENBQUNGLFVBQVV6RyxlQUFleUcsS0FBSztBQUFBLGdCQUN6QyxPQUFPMUcsZUFBZTZHO0FBQUFBLGdCQUVyQjlGLHVCQUFhRTtBQUFBQSxrQkFBSSxDQUFDMkQsVUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE9BQy9CQSxtQkFEaUJBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNwQjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVURjtBQUFBQSx1Q0FBdUIsS0FDdEI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU8saUNBQWlDQSxvQkFBb0I7QUFBQSxvQkFFNUQsaUNBQUMsVUFBTUEsa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNEI7QUFBQTtBQUFBLGtCQUo5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFFRix1QkFBQyxtQkFBZ0IsV0FBVSxRQUFPLE1BQU0sTUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQVpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTWxDO0FBQUFBLGNBQ04sU0FBU21GO0FBQUFBLGNBQ1QsU0FBUTtBQUFBLGNBQ1IsaUJBQWdCO0FBQUEsY0FDaEIsaUJBQWlCLENBQUMsWUFBWTtBQUFBLGNBQzlCLG1CQUFtQixDQUFDdkcsV0FBVztBQUFBLGNBQy9CLGtCQUFrQjtBQUFBO0FBQUEsWUFQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT3dDO0FBQUEsYUE3QzFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQ0E7QUFBQSxXQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0RBO0FBQUEsU0E1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThEQTtBQUFBLE9BcEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzRUEsS0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdFQTtBQUVKO0FBQUVMLEdBeFRJRCxjQUFZO0FBQUEsVUFTa0JGLGFBQWFzQixlQUFlO0FBQUE7QUFBQWdHLEtBVDFEcEg7QUF5VE4sZUFBZUE7QUFBYSxJQUFBb0g7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFXaGF0c2FwcCIsIm5vdGlmaWNhdGlvbiIsIk1kTWFya0VtYWlsUmVhZCIsIk92ZXJEdWVFbWFpbCIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsImdyb3VwT3B0aW9ucyIsIlNldCIsIm1hcCIsInUiLCJncm91cE5hbWUiLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWQiLCJmaWx0ZXIiLCJtYXRjaEdyb3VwIiwiZW5yb2xsbWVudERhdGUiLCJEYXRlIiwibWF0Y2hGcm9tRGF0ZSIsIm1hdGNoVG9EYXRlIiwidXNlciIsImluZGV4IiwiaXNTZWxlY3RlZCIsIl9pZCIsImluZm8iLCJzdGF0dXMiLCJzbF9ubyIsImNoZWNrQm94cyIsImUiLCJwcmV2IiwidGFyZ2V0IiwiY2hlY2tlZCIsImJhbGFuY2UiLCJ1c2VyUGhvbmUiLCJwYXltZW50c1RpY2tldCIsInVzZXJOYW1lIiwiZ3JvdXBJZCIsInVzZXJJZCIsImFtb3VudFBhaWQiLCJhbW91bnRUb0JlUGFpZCIsInRvdGFsVG9CZVBhaWQiLCJ1c2VyRW1haWwiLCJsYXRlc3RQYXltZW50RGF0ZSIsImxhdGVzdFBheW1lbnRBbW91bnQiLCJwYXltZW50VHlwZSIsInBheW1lbnRfdHlwZSIsInZpc2libGVTZWxlY3RlZENvdW50IiwibGVuZ3RoIiwic2VuZEVtYWlsIiwia2V5Iiwib3BlbiIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsImNsYXNzTmFtZSIsImR1cmF0aW9uIiwic2VsZWN0ZWRVc2VycyIsImZvckVhY2giLCJwb3N0IiwidXBkYXRlZEFjdGl2ZVVzZXJEYXRhIiwiZXJyIiwiZmV0Y2hEYXRhIiwicmVwb3J0UmVzcG9uc2UiLCJnZXQiLCJ1c2Vyc0xpc3QiLCJ0ZW1wQWN0aXZlIiwiZGF0YSIsInVzckRhdGEiLCJlbnJvbGxtZW50IiwiZ3JvdXAiLCJncm91cEluc3RhbGwiLCJwYXJzZUludCIsImdyb3VwX2luc3RhbGwiLCJncm91cFR5cGUiLCJncm91cF90eXBlIiwidG90YWxQYWlkQW1vdW50IiwicGF5bWVudHMiLCJhdWN0aW9uQ291bnQiLCJhdWN0aW9uIiwidG90YWxQYXlhYmxlIiwicGF5YWJsZSIsInRvdGFsUHJvZml0IiwicHJvZml0IiwiZmlyc3REaXZpZGVudEhlYWQiLCJmaXJzdEF1Y3Rpb24iLCJpZCIsInBob25lX251bWJlciIsImVtYWlsIiwidGlja2V0IiwiZ3JvdXBfbmFtZSIsInRlbXBVc3IiLCJjdXN0b21lcklkIiwiY3VzdG9tZXJfaWQiLCJjb25zb2xlIiwicHVzaCIsImVycm9yIiwiQXVjdGlvbmNvbHVtbnMiLCJoZWFkZXIiLCJyZW5kZXIiLCJ2YWx1ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIndpZHRoIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT3ZlckR1ZUVtYWlsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IE1kTWFya0VtYWlsUmVhZCB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5cclxuY29uc3QgT3ZlckR1ZUVtYWlsID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt1c2Vyc0RhdGEsIHNldFVzZXJzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3VwRmlsdGVyLCBzZXRHcm91cEZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWN0aXZlVXNlckRhdGEsIHNldEFjdGl2ZVVzZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0b3RhbFVzZXJzLCBzZXRUb3RhbFVzZXJzXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtub3RpZmllciwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcblxyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFsuLi5uZXcgU2V0KHVzZXJzRGF0YS5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKSldO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGZpbHRlck9wdGlvbihcclxuICAgICAgdXNlcnNEYXRhLmZpbHRlcigodSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoR3JvdXAgPSBncm91cEZpbHRlciA/IHUuZ3JvdXBOYW1lID09PSBncm91cEZpbHRlciA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmVucm9sbG1lbnREYXRlKTtcclxuICAgICAgICBjb25zdCBtYXRjaEZyb21EYXRlID0gZnJvbURhdGVcclxuICAgICAgICAgID8gZW5yb2xsbWVudERhdGUgPj0gbmV3IERhdGUoZnJvbURhdGUpXHJcbiAgICAgICAgICA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hUb0RhdGUgPSB0b0RhdGUgPyBlbnJvbGxtZW50RGF0ZSA8PSBuZXcgRGF0ZSh0b0RhdGUpIDogdHJ1ZTtcclxuICAgICAgICByZXR1cm4gbWF0Y2hHcm91cCAmJiBtYXRjaEZyb21EYXRlICYmIG1hdGNoVG9EYXRlO1xyXG4gICAgICB9KSxcclxuICAgICAgc2VhcmNoVGV4dFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZmlsdGVyZWQubWFwKCh1c2VyLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4udXNlcixcclxuICAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gICAgICAgIGNoZWNrQm94czogKFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgIFt1c2VyLl9pZF06IHtcclxuICAgICAgICAgICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICBiYWxhbmNlOiB1c2VyLmJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICBwYXltZW50c1RpY2tldDogdXNlci5wYXltZW50c1RpY2tldCxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwSWQ6IHVzZXIuZ3JvdXBJZCxcclxuICAgICAgICAgICAgICAgICAgICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4gICAgICAgICAgICAgICAgICAgIGFtb3VudFBhaWQ6IHVzZXIuYW1vdW50UGFpZCxcclxuICAgICAgICAgICAgICAgICAgICBhbW91bnRUb0JlUGFpZDogdXNlci50b3RhbFRvQmVQYWlkLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJFbWFpbDogdXNlci51c2VyRW1haWwsXHJcbiAgICAgICAgICAgICAgICAgICAgbGF0ZXN0UGF5bWVudERhdGU6IHVzZXIubGF0ZXN0UGF5bWVudERhdGUsIC8vIOKchSBhZGRlZFxyXG4gICAgICAgICAgICAgICAgICAgIGxhdGVzdFBheW1lbnRBbW91bnQ6IHVzZXIubGF0ZXN0UGF5bWVudEFtb3VudCwgLy8g4pyFIGFkZGVkXHJcbiAgICAgICAgICAgICAgICAgICAgcGF5bWVudFR5cGU6IHVzZXIucGF5bWVudF90eXBlLCAvLyDinIUgYWRkZWRcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApLFxyXG4gICAgICAgIGlzU2VsZWN0ZWQsXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbdXNlcnNEYXRhLCBncm91cEZpbHRlciwgZnJvbURhdGUsIHRvRGF0ZSwgc2VhcmNoVGV4dCwgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgY29uc3QgdmlzaWJsZVNlbGVjdGVkQ291bnQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBmaWx0ZXJlZFVzZXJzLmZpbHRlcigodXNlcikgPT4gdXNlci5pc1NlbGVjdGVkKS5sZW5ndGg7XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnNdKTtcclxuXHJcbiBjb25zdCBzZW5kRW1haWwgPSBhc3luYyAoKSA9PiB7XHJcbiAgY29uc3Qga2V5ID0gXCJ1cGRhdGFibGVcIjtcclxuICB0cnkge1xyXG4gICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgIGtleSxcclxuICAgICAgbWVzc2FnZTogXCJTZW5kaW5nIEVtYWlscy4uXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuICAgICAgY2xhc3NOYW1lOiBcImJnLXZpb2xldC0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgZHVyYXRpb246IDIsXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBQcmVwYXJlIHNlbGVjdGVkIHVzZXJzXHJcbiAgICBjb25zdCBzZWxlY3RlZFVzZXJzID0ge307XHJcbiAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCAmJiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0pIHtcclxuICAgICAgICBzZWxlY3RlZFVzZXJzW3VzZXIuX2lkXSA9IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgYXdhaXQgYXBpLnBvc3QoXCIvZW1haWwvb3Zlci1kdWUtZW1haWxcIiwgc2VsZWN0ZWRVc2Vycyk7XHJcblxyXG4gICAgLy8gQ2xlYW51cCBhZnRlciBzZW5kaW5nXHJcbiAgICBjb25zdCB1cGRhdGVkQWN0aXZlVXNlckRhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbiAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkge1xyXG4gICAgICAgIGRlbGV0ZSB1cGRhdGVkQWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHNldEFjdGl2ZVVzZXJEYXRhKHVwZGF0ZWRBY3RpdmVVc2VyRGF0YSk7XHJcblxyXG4gICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgIGtleSxcclxuICAgICAgbWVzc2FnZTogXCJFbWFpbHMgU2VudCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiU3VjY2Vzc1wiLFxyXG4gICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAga2V5LFxyXG4gICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBTZW5kIEVtYWlsc1wiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogZXJyLm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICBkdXJhdGlvbjogMixcclxuICAgIH0pO1xyXG4gIH1cclxufTtcclxuXHJcbiAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXBvcnRSZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtb3ZlcmR1ZS1wYXltZW50c1wiKTtcclxuICAgICAgY29uc3QgdXNlcnNMaXN0ID0gW107XHJcbiAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuXHJcbiAgICAgIHJlcG9ydFJlc3BvbnNlLmRhdGEuZm9yRWFjaCgodXNyRGF0YSkgPT4ge1xyXG4gICAgICAgIGlmICh1c3JEYXRhPy5kYXRhKSB7XHJcbiAgICAgICAgICB1c3JEYXRhLmRhdGEuZm9yRWFjaCgoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZGF0YT8uZW5yb2xsbWVudD8uZ3JvdXApIHtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cEluc3RhbGwgPSBwYXJzZUludChcclxuICAgICAgICAgICAgICAgIGRhdGEuZW5yb2xsbWVudC5ncm91cC5ncm91cF9pbnN0YWxsXHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gZGF0YS5lbnJvbGxtZW50Lmdyb3VwLl9pZDtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cFR5cGUgPSBkYXRhLmVucm9sbG1lbnQuZ3JvdXAuZ3JvdXBfdHlwZTtcclxuICAgICAgICAgICAgICBjb25zdCB0b3RhbFBhaWRBbW91bnQgPSBkYXRhLnBheW1lbnRzLnRvdGFsUGFpZEFtb3VudDtcclxuICAgICAgICAgICAgICBjb25zdCBhdWN0aW9uQ291bnQgPSBwYXJzZUludChkYXRhPy5hdWN0aW9uPy5hdWN0aW9uQ291bnQpO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHRvdGFsUGF5YWJsZSA9IGRhdGEucGF5YWJsZS50b3RhbFBheWFibGU7XHJcbiAgICAgICAgICAgICAgY29uc3QgdG90YWxQcm9maXQgPSBkYXRhLnByb2ZpdC50b3RhbFByb2ZpdDtcclxuICAgICAgICAgICAgICBjb25zdCBmaXJzdERpdmlkZW50SGVhZCA9IGRhdGEuZmlyc3RBdWN0aW9uLmZpcnN0RGl2aWRlbnRIZWFkO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGlkID0gZGF0YT8uZW5yb2xsbWVudD8uX2lkO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHVzZXJQaG9uZSA9IHVzckRhdGEucGhvbmVfbnVtYmVyO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHVzZXJFbWFpbCA9IHVzckRhdGEuZW1haWw7XHJcbiAgICAgICAgICAgICAgY29uc3QgcGF5bWVudHNUaWNrZXQgPSBkYXRhLnBheW1lbnRzLnRpY2tldDtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cE5hbWUgPSBkYXRhLmVucm9sbG1lbnQuZ3JvdXAuZ3JvdXBfbmFtZTtcclxuXHJcbiAgICAgICAgICAgICAgLy8g8J+foSBDSEFOR0UgMTogSGFuZGxlIGFtb3VudFRvQmVQYWlkIGFuZCB0b3RhbFRvQmVQYWlkIGNvbnNpc3RlbnRseVxyXG4gICAgICAgICAgICAgIGNvbnN0IHRvdGFsVG9CZVBhaWQgPVxyXG4gICAgICAgICAgICAgICAgZ3JvdXBUeXBlID09PSBcImRvdWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgID8gZ3JvdXBJbnN0YWxsICogYXVjdGlvbkNvdW50ICsgZ3JvdXBJbnN0YWxsXHJcbiAgICAgICAgICAgICAgICAgIDogdG90YWxQYXlhYmxlICsgZ3JvdXBJbnN0YWxsICsgdG90YWxQcm9maXQ7XHJcbiAgICAgICAgICAgICAgY29uc3QgYW1vdW50VG9CZVBhaWQgPSB0b3RhbFRvQmVQYWlkO1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCBiYWxhbmNlID1cclxuICAgICAgICAgICAgICAgIGdyb3VwVHlwZSA9PT0gXCJkb3VibGVcIlxyXG4gICAgICAgICAgICAgICAgICA/IHRvdGFsVG9CZVBhaWQgLSB0b3RhbFBhaWRBbW91bnRcclxuICAgICAgICAgICAgICAgICAgOiB0b3RhbFBheWFibGUgK1xyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwSW5zdGFsbCArXHJcbiAgICAgICAgICAgICAgICAgICAgZmlyc3REaXZpZGVudEhlYWQgLVxyXG4gICAgICAgICAgICAgICAgICAgIHRvdGFsUGFpZEFtb3VudDtcclxuXHJcbiAgICAgICAgICAgICAgaWYgKGJhbGFuY2UgPD0gMCkgcmV0dXJuO1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9IHVzckRhdGEudXNlck5hbWU7XHJcblxyXG4gICAgICAgICAgICAgIC8vIPCfn6EgQ0hBTkdFIDI6IE5ldyBmaWVsZHMgZnJvbSBsYXRlc3RQYXltZW50IGluZm9cclxuICAgICAgICAgICAgICBjb25zdCBsYXRlc3RQYXltZW50QW1vdW50ID0gZGF0YS5sYXRlc3RQYXltZW50QW1vdW50IHx8IDA7IC8vIOKshSBBZGRlZCBmb3IgY2xhcml0eVxyXG4gICAgICAgICAgICAgIGNvbnN0IGxhdGVzdFBheW1lbnREYXRlID0gZGF0YS5sYXRlc3RQYXltZW50RGF0ZSB8fCBcIlwiOyAvLyDirIUgQWRkZWQgZm9yIGNsYXJpdHlcclxuXHJcbiAgICAgICAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7XHJcbiAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgIGNvbnN0IHRlbXBVc3IgPSB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGlkLFxyXG4gICAgICAgICAgICAgICAgdXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICB1c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICB1c2VyRW1haWwsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21lcklkOiB1c3JEYXRhLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgYW1vdW50UGFpZDogdG90YWxQYWlkQW1vdW50LFxyXG4gICAgICAgICAgICAgICAgcGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgICAgICAgICBhbW91bnRUb0JlUGFpZCxcclxuICAgICAgICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgIHBheW1lbnRfdHlwZTogZGF0YT8uZW5yb2xsbWVudD8ucGF5bWVudF90eXBlLFxyXG4gICAgICAgICAgICAgICAgdG90YWxUb0JlUGFpZCxcclxuICAgICAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICBncm91cElkOiBncm91cElkLFxyXG4gICAgICAgICAgICAgICAgdXNlcklkOiB1c3JEYXRhPy5faWQsXHJcbiAgICAgICAgICAgICAgICBsYXRlc3RQYXltZW50QW1vdW50LCAvLyDirIUgTmV3IGZpZWxkXHJcbiAgICAgICAgICAgICAgICBsYXRlc3RQYXltZW50RGF0ZSwgLy8g4qyFIE5ldyBmaWVsZFxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgY29uc29sZS5pbmZvKFwidGVtcFVzclwiLCB0ZW1wVXNyKTtcclxuICAgICAgICAgICAgICB1c2Vyc0xpc3QucHVzaCh0ZW1wVXNyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFVzZXJzRGF0YSh1c2Vyc0xpc3QpO1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YSh0ZW1wQWN0aXZlKTsgLy8g4pyFIE1hdGNoIHN0cnVjdHVyZSBmcm9tIHNlY29uZCBzbmlwcGV0XHJcbiAgICAgIHNldFRvdGFsVXNlcnModXNlcnNMaXN0Lmxlbmd0aCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBBdWN0aW9uY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHtrZXk6IFwidXNlckVtYWlsXCIsIGhlYWRlcjogXCJFbWFpbFwifSxcclxuICAgIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxUb0JlUGFpZFwiLCBoZWFkZXI6IFwiQW1vdW50IHRvIGJlIFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50UGFpZFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibGF0ZXN0UGF5bWVudEFtb3VudFwiLCBoZWFkZXI6IFwiTGFzdCBQYXltZW50IEFtb3VudFwiIH0sIC8vIOKchSBORVdcclxuICAgIHtcclxuICAgICAga2V5OiBcImxhdGVzdFBheW1lbnREYXRlXCIsXHJcbiAgICAgIGhlYWRlcjogXCJMYXN0IFBheW1lbnQgRGF0ZVwiLFxyXG4gICAgICByZW5kZXI6ICh2YWx1ZSkgPT5cclxuICAgICAgICB2YWx1ZSA/IG5ldyBEYXRlKHZhbHVlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiKSA6IFwiTi9BXCIsIC8vIOKchSBORVdcclxuICAgIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImNoZWNrQm94c1wiLCBoZWFkZXI6IFwiU2VsZWN0IFVzZXJcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctc2NyZWVuXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0zMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICBPdXRzdGFuZGluZyBFbWFpbCBbT3Zlcl1cclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIEZpbHRlclxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZEVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctdmlvbGV0LTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPE1kTWFya0VtYWlsUmVhZCBjbGFzc05hbWU9XCJtci0yXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRVc2Vyc31cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17QXVjdGlvbmNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJPdmVyICBFbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tncm91cEZpbHRlcl19XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BPdmVyZHVlIEVtYWlsLmNzdmB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IE92ZXJEdWVFbWFpbDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL092ZXJEdWVFbWFpbC5qc3gifQ==