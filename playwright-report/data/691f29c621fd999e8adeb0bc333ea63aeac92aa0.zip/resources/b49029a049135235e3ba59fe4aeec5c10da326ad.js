import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/authentication/SuperAdminRoute.jsx");import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/authentication/SuperAdminRoute.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"];
import { message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const SuperAdminRoute = ({ children }) => {
  _s();
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const userRole = user?.admin_access_right_id?.title;
  const canAccessSalary = userRole === "Super Administrator" || userRole === "Branch Manager";
  const messageShown = useRef(false);
  useEffect(() => {
    if (!canAccessSalary && !messageShown.current) {
      messageShown.current = true;
      message.error({
        content: "You don't have access to view this page. Only Super Administrator or Branch Manager can access it.",
        duration: 4
      });
    }
  }, [canAccessSalary]);
  if (!canAccessSalary) {
    return null;
  }
  return children;
};
_s(SuperAdminRoute, "wK+krbA5w1t5QmPxHUeL1g3sAs0=");
_c = SuperAdminRoute;
export default SuperAdminRoute;
var _c;
$RefreshReg$(_c, "SuperAdminRoute");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/authentication/SuperAdminRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/authentication/SuperAdminRoute.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjJCQUFBO0FBQW9CQSxNQUFNLGNBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekMsU0FBU0MsZUFBZTtBQUd4QixNQUFNQyxrQkFBa0JBLENBQUMsRUFBRUMsU0FBUyxNQUFNO0FBQUFDLEtBQUE7QUFDeEMsUUFBTUMsT0FBT0MsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxNQUFNLEtBQUssSUFBSTtBQUU1RCxRQUFNQyxXQUFXTCxNQUFNTSx1QkFBdUJDO0FBRzlDLFFBQU1DLGtCQUNKSCxhQUFhLHlCQUNiQSxhQUFhO0FBRWYsUUFBTUksZUFBZWQsT0FBTyxLQUFLO0FBRWpDZSxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNGLG1CQUFtQixDQUFDQyxhQUFhRSxTQUFTO0FBQzdDRixtQkFBYUUsVUFBVTtBQUV2QmYsY0FBUWdCLE1BQU07QUFBQSxRQUNaQyxTQUNFO0FBQUEsUUFDRkMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ04sZUFBZSxDQUFDO0FBSXBCLE1BQUksQ0FBQ0EsaUJBQWlCO0FBQ3BCLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FBT1Y7QUFDVDtBQUFFQyxHQS9CSUYsaUJBQWU7QUFBQWtCLEtBQWZsQjtBQWlDTixlQUFlQTtBQUFnQixJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVJlZiIsIm1lc3NhZ2UiLCJTdXBlckFkbWluUm91dGUiLCJjaGlsZHJlbiIsIl9zIiwidXNlciIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyUm9sZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsInRpdGxlIiwiY2FuQWNjZXNzU2FsYXJ5IiwibWVzc2FnZVNob3duIiwidXNlRWZmZWN0IiwiY3VycmVudCIsImVycm9yIiwiY29udGVudCIsImR1cmF0aW9uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3VwZXJBZG1pblJvdXRlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBtZXNzYWdlIH0gZnJvbSBcImFudGRcIjtcclxuXHJcblxyXG5jb25zdCBTdXBlckFkbWluUm91dGUgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpIHx8IFwie31cIik7XHJcblxyXG4gIGNvbnN0IHVzZXJSb2xlID0gdXNlcj8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy50aXRsZTtcclxuXHJcbiAgLy8gUm9sZXMgYWxsb3dlZCB0byBhY2Nlc3MgU2FsYXJ5IE1hbmFnZW1lbnRcclxuICBjb25zdCBjYW5BY2Nlc3NTYWxhcnkgPVxyXG4gICAgdXNlclJvbGUgPT09IFwiU3VwZXIgQWRtaW5pc3RyYXRvclwiIHx8XHJcbiAgICB1c2VyUm9sZSA9PT0gXCJCcmFuY2ggTWFuYWdlclwiO1xyXG5cclxuICBjb25zdCBtZXNzYWdlU2hvd24gPSB1c2VSZWYoZmFsc2UpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFjYW5BY2Nlc3NTYWxhcnkgJiYgIW1lc3NhZ2VTaG93bi5jdXJyZW50KSB7XHJcbiAgICAgIG1lc3NhZ2VTaG93bi5jdXJyZW50ID0gdHJ1ZTtcclxuXHJcbiAgICAgIG1lc3NhZ2UuZXJyb3Ioe1xyXG4gICAgICAgIGNvbnRlbnQ6XHJcbiAgICAgICAgICBcIllvdSBkb24ndCBoYXZlIGFjY2VzcyB0byB2aWV3IHRoaXMgcGFnZS4gT25seSBTdXBlciBBZG1pbmlzdHJhdG9yIG9yIEJyYW5jaCBNYW5hZ2VyIGNhbiBhY2Nlc3MgaXQuXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDQsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0sIFtjYW5BY2Nlc3NTYWxhcnldKTtcclxuXHJcbiAgLy8gU3RheSBvbiB0aGUgc2FtZSBVUkwuXHJcbiAgLy8gRG8gbm90IGRpc3BsYXkgdGhlIHByb3RlY3RlZCBwYWdlLlxyXG4gIGlmICghY2FuQWNjZXNzU2FsYXJ5KSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIHJldHVybiBjaGlsZHJlbjtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN1cGVyQWRtaW5Sb3V0ZTsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvY29tcG9uZW50cy9hdXRoZW50aWNhdGlvbi9TdXBlckFkbWluUm91dGUuanN4In0=