import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LinkedGuarantor.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import handleGuarantorPrint from "/src/components/printFormats/GuarantorPrint.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const LinkedGuarantor = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableGuarantor, setTableGuarantor] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentGuarantor, setCurrentGuarantor] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [isEnrollmentLoading, setIsEnrollmentLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    user_id: "",
    user_guarantor: []
  });
  const [updateFormData, setUpdateFormData] = useState({
    user_id: "",
    user_guarantor: []
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchLinkedGuarantor = async () => {
      try {
        setIsLoading(true);
        const response = await api.get(
          "/v1/admin/users/linked-guarantors"
          // 👈 verify the exact path
        );
        const records = Array.isArray(response?.data?.data) ? response.data.data : [];
        console.log("reee", records);
        const rows = [];
        let counter = 0;
        records.forEach((record) => {
          const customer = record?.user_id || {};
          const guarantors = Array.isArray(record?.guarantorList) ? record.guarantorList : [];
          if (guarantors.length === 0) {
            counter += 1;
            rows.push({
              _id: record?._id,
              customer_user_id: customer?._id,
              id: counter,
              user_id: customer.full_name || "N/A",
              guarantor_code: "N/A",
              guarantor_referred_type: "Customer",
              guarantor_name: "N/A",
              guarantor_phone_number: "N/A",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(record?.user_id?._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                            lineNumber: 108,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(record?._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                            lineNumber: 119,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "3",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            onClick: () => handleGuarantorPrint(record?._id),
                            className: "text-violet-600",
                            children: "Print"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                            lineNumber: 130,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                    lineNumber: 142,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 101,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 100,
                columnNumber: 15
              }, this)
            });
            return;
          }
          guarantors.forEach((g) => {
            counter += 1;
            const guarantorUser = g?.user_id || {};
            rows.push({
              _id: record?._id,
              id: counter,
              user_id: customer.full_name || "N/A",
              customer_user_id: customer?._id,
              // Guarantor Code column → the guarantor's customer_id
              guarantor_code: guarantorUser.customer_id || "N/A",
              guarantor_referred_type: "Customer",
              guarantor_name: guarantorUser.full_name || "N/A",
              guarantor_phone_number: guarantorUser.phone_number || "N/A",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(record?.user_id?._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                            lineNumber: 173,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(record?._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                            lineNumber: 184,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "3",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            onClick: () => handleGuarantorPrint(record?._id),
                            className: "text-violet-600",
                            children: "Print"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                            lineNumber: 195,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                    lineNumber: 207,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 166,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 165,
                columnNumber: 15
              }, this)
            });
          });
        });
        setTableGuarantor(rows);
      } catch (error) {
        console.error("Error fetching linked guarantors:", error?.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchLinkedGuarantor();
  }, [reloadTrigger]);
  const fetchLinkedGuarantors = async (customerUserId, setter = setFormData) => {
    if (!customerUserId) return;
    setIsEnrollmentLoading(true);
    try {
      const response = await api.get(
        `/v1/admin/users/${customerUserId}/linked-guarantor`
      );
      const list = response?.data?.data?.guarantorList || response?.data?.guarantorList || response?.data?.data?.guarantors || response?.data?.guarantors || [];
      const linkedIds = list.map(
        (item) => typeof item?.user_id === "string" ? item.user_id : item?.user_id?._id || item?._id
      ).filter(Boolean);
      setter((prev) => ({ ...prev, user_guarantor: linkedIds }));
    } catch (error) {
      console.warn("No linked guarantors / fetch failed:", error?.message);
      setter((prev) => ({ ...prev, user_guarantor: [] }));
    } finally {
      setIsEnrollmentLoading(false);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!formData.user_id) newErrors.user_id = "Customer is required";
    if (!formData.user_guarantor?.length)
      newErrors.user_guarantor = "Select at least one customer to link";
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    try {
      const payload = {
        guarantorList: formData.user_guarantor.map((id) => ({ user_id: id }))
      };
      await api.post(
        `/v1/admin/users/${formData.user_id}/linked-guarantor`,
        payload
      );
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Guarantor linked successfully",
        visibility: true
      });
      setShowModal(false);
      setFormData({ user_id: "", user_guarantor: [] });
    } catch (error) {
      console.error("Error linking guarantor:", error);
      setAlertConfig({
        type: "error",
        message: error?.response?.data?.message || "An unexpected error occurred.",
        visibility: true
      });
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!updateFormData.user_id) newErrors.user_id = "Customer is required";
    if (!updateFormData.user_guarantor?.length)
      newErrors.user_guarantor = "Select at least one customer to link";
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    try {
      const payload = {
        guarantorList: updateFormData.user_guarantor.map((id) => ({
          user_id: id
        }))
      };
      await api.post(
        `/v1/admin/users/${updateFormData.user_id}/linked-guarantor`,
        payload
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Guarantor Updated Successfully",
        visibility: true
      });
    } catch (error) {
      console.error("Error updating Guarantor:", error);
      setAlertConfig({
        type: "error",
        message: error?.response?.data?.message || "Update failed",
        visibility: true
      });
    }
  };
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/guarantor/get-guarantor-info-by-id/${userId}`
      );
      setCurrentGuarantor(response.data?.guarantor);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Guarantor:", error);
    }
  };
  const handleDeleteGuarantor = async () => {
    if (!currentGuarantor) return;
    try {
      await api.delete(
        `/guarantor/delete-guarantor-info-by-id/${currentGuarantor._id}`
      );
      setAlertConfig({
        visibility: true,
        message: "guarantor deleted successfully",
        type: "success"
      });
      setReloadTrigger((prev) => prev + 1);
      setShowModalDelete(false);
      setCurrentGuarantor(null);
    } catch (error) {
      console.error("Error deleting Guarantor:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      setUpdateFormData({
        user_id: userId,
        user_guarantor: []
      });
      setShowModalUpdate(true);
      setErrors({});
      await fetchLinkedGuarantors(userId, setUpdateFormData);
    } catch (error) {
      console.error("Error fetching Guarantor:", error);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "user_id", header: "Customer Name" },
    { key: "guarantor_code", header: "Guarantor Code" },
    { key: "guarantor_referred_type", header: "Referred Type" },
    { key: "guarantor_name", header: "Guarantor Name" },
    { key: "guarantor_phone_number", header: "Guarantor Phone Number" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
        lineNumber: 404,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
          lineNumber: 405,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
          lineNumber: 409,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 420,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Linked Guarantor" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 422,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowModal(true);
                  setErrors({});
                  setFormData({ user_id: "", user_guarantor: [] });
                },
                className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+ Link Guarantor"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 424,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 421,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
          lineNumber: 419,
          columnNumber: 13
        }, this),
        TableGuarantor?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableGuarantor, searchText),
            columns,
            exportedPdfName: "Guarantor",
            exportedFileName: `Guarantor.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 438,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableGuarantor.length <= 0,
            data: "Guarantor Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 447,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
        lineNumber: 418,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
      lineNumber: 403,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setShowModal(false);
          setFormData({ user_id: "", user_guarantor: [] });
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Link Guarantor" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 466,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Customer ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 472,
                  columnNumber: 35
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 471,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  showSearch: true,
                  value: formData.user_id || void 0,
                  onChange: (value) => {
                    setFormData((prev) => ({
                      ...prev,
                      user_id: value,
                      user_guarantor: []
                    }));
                    fetchLinkedGuarantors(value);
                  },
                  filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                      lineNumber: 492,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 474,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 498,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 470,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Customer to Link",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 505,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 503,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  maxTagCount: "responsive",
                  allowClear: true,
                  showSearch: true,
                  placeholder: !formData.user_id ? "Select a customer first" : isEnrollmentLoading ? "Loading linked guarantors..." : "Select customers to link",
                  disabled: !formData.user_id || isEnrollmentLoading,
                  loading: isEnrollmentLoading,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  value: formData.user_guarantor || [],
                  onChange: (selectedIds) => setFormData((prev) => ({
                    ...prev,
                    user_guarantor: selectedIds
                  })),
                  filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
                  optionFilterProp: "children",
                  children: users.filter((u) => u._id !== formData.user_id).map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                      lineNumber: 537,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 507,
                  columnNumber: 17
                },
                this
              ),
              errors.user_guarantor && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_guarantor }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 543,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 502,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Link Guarantor"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 550,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 549,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 469,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
          lineNumber: 465,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
        lineNumber: 457,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => {
          setShowModalUpdate(false);
          setUpdateFormData({ user_id: "", user_guarantor: [] });
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Linked Guarantor" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 572,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Customer ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 578,
                  columnNumber: 35
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 577,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  showSearch: true,
                  value: updateFormData.user_id || void 0,
                  onChange: (value) => {
                    setUpdateFormData((prev) => ({
                      ...prev,
                      user_id: value,
                      user_guarantor: []
                    }));
                    fetchLinkedGuarantors(value, setUpdateFormData);
                  },
                  filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                      lineNumber: 598,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 580,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 604,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 576,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Customer to Link",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 611,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 609,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  maxTagCount: "responsive",
                  allowClear: true,
                  showSearch: true,
                  placeholder: !updateFormData.user_id ? "Select a customer first" : isEnrollmentLoading ? "Loading linked guarantors..." : "Select customers to link",
                  disabled: !updateFormData.user_id || isEnrollmentLoading,
                  loading: isEnrollmentLoading,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  value: updateFormData.user_guarantor || [],
                  onChange: (selectedIds) => setUpdateFormData((prev) => ({
                    ...prev,
                    user_guarantor: selectedIds
                  })),
                  filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
                  optionFilterProp: "children",
                  children: users.filter((u) => u._id !== updateFormData.user_id).map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                      lineNumber: 643,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 613,
                  columnNumber: 17
                },
                this
              ),
              errors.user_guarantor && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_guarantor }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 649,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 608,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                lineNumber: 656,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 655,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 575,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
          lineNumber: 571,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
        lineNumber: 563,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGuarantor(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Guarantor" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
            lineNumber: 677,
            columnNumber: 13
          }, this),
          currentGuarantor && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteGuarantor();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentGuarantor.guarantor_name || currentGuarantor?.user_id?.full_name || "N/A" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                          lineNumber: 694,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                          lineNumber: 700,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                      lineNumber: 689,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the Guarantor Name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                      lineNumber: 702,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                  lineNumber: 688,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
                    lineNumber: 710,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
              lineNumber: 681,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
          lineNumber: 676,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
        lineNumber: 669,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
    lineNumber: 402,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx",
    lineNumber: 401,
    columnNumber: 5
  }, this);
};
_s(LinkedGuarantor, "IjEqpm2Wy/zCcz/bRRWZCEl8c4s=");
_c = LinkedGuarantor;
export default LinkedGuarantor;
var _c;
$RefreshReg$(_c, "LinkedGuarantor");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LinkedGuarantor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkc0QixTQXFTeEIsVUFyU3dCOzJCQTNHNUI7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCO0FBQ3hDLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJbkIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ29CLGdCQUFnQkMsaUJBQWlCLElBQUlyQixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDc0IsV0FBV0MsWUFBWSxJQUFJdkIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3dCLGlCQUFpQkMsa0JBQWtCLElBQUl6QixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDMEIsaUJBQWlCQyxrQkFBa0IsSUFBSTNCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM0QixrQkFBa0JDLG1CQUFtQixJQUFJN0IsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQzhCLFdBQVdDLFlBQVksSUFBSS9CLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNnQyxlQUFlQyxnQkFBZ0IsSUFBSWpDLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUNrQyxxQkFBcUJDLHNCQUFzQixJQUFJbkMsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQ29DLFFBQVFDLFNBQVMsSUFBSXJDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ3NDLGFBQWFDLGNBQWMsSUFBSXZDLFNBQVM7QUFBQSxJQUM3Q3dDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJNUMsU0FBUztBQUFBLElBQ3ZDNkMsU0FBUztBQUFBLElBQ1RDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFFRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUloRCxTQUFTO0FBQUEsSUFDbkQ2QyxTQUFTO0FBQUEsSUFDVEMsZ0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUVELFFBQU0sQ0FBQ0csWUFBWUMsYUFBYSxJQUFJbEQsU0FBUyxFQUFFO0FBQy9DLFFBQU1tRCw0QkFBNEJBLENBQUNDLE1BQU07QUFDdkNGLGtCQUFjRSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFHQUMsWUFBVSxNQUFNO0FBQ2QsVUFBTUMsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU10RCxJQUFJdUQsSUFBSSxnQkFBZ0I7QUFDL0N2QyxpQkFBU3NDLFNBQVNFLElBQUk7QUFBQSxNQUN4QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBSixlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFHTEQsWUFBVSxNQUFNO0FBQ2QsVUFBTU8sdUJBQXVCLFlBQVk7QUFDdkMsVUFBSTtBQUNGL0IscUJBQWEsSUFBSTtBQUVqQixjQUFNMEIsV0FBVyxNQUFNdEQsSUFBSXVEO0FBQUFBLFVBQ3pCO0FBQUE7QUFBQSxRQUNGO0FBR0EsY0FBTUssVUFBVUMsTUFBTUMsUUFBUVIsVUFBVUUsTUFBTUEsSUFBSSxJQUM5Q0YsU0FBU0UsS0FBS0EsT0FDZDtBQUNKRSxnQkFBUUssSUFBSSxRQUFRSCxPQUFPO0FBSTNCLGNBQU1JLE9BQU87QUFDYixZQUFJQyxVQUFVO0FBRWRMLGdCQUFRTSxRQUFRLENBQUNDLFdBQVc7QUFDMUIsZ0JBQU1DLFdBQVdELFFBQVF6QixXQUFXLENBQUM7QUFDckMsZ0JBQU0yQixhQUFhUixNQUFNQyxRQUFRSyxRQUFRRyxhQUFhLElBQ2xESCxPQUFPRyxnQkFDUDtBQUVKLGNBQUlELFdBQVdFLFdBQVcsR0FBRztBQUMzQk4sdUJBQVc7QUFDWEQsaUJBQUtRLEtBQUs7QUFBQSxjQUNSQyxLQUFLTixRQUFRTTtBQUFBQSxjQUNiQyxrQkFBa0JOLFVBQVVLO0FBQUFBLGNBQzVCRSxJQUFJVjtBQUFBQSxjQUNKdkIsU0FBUzBCLFNBQVNRLGFBQWE7QUFBQSxjQUMvQkMsZ0JBQWdCO0FBQUEsY0FDaEJDLHlCQUF5QjtBQUFBLGNBQ3pCQyxnQkFBZ0I7QUFBQSxjQUNoQkMsd0JBQXdCO0FBQUEsY0FDeEJDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsa0JBQ2pCLE1BQU07QUFBQSxvQkFDSkMsT0FBTztBQUFBLHNCQUNMO0FBQUEsd0JBQ0VDLEtBQUs7QUFBQSx3QkFDTEMsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxNQUFNQyxzQkFBc0JsQixRQUFRekIsU0FBUytCLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRVUsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU1FLHNCQUFzQm5CLFFBQVFNLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRVUsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFNBQVMsTUFBTTNFLHFCQUFxQjBELFFBQVFNLEdBQUc7QUFBQSw0QkFDL0MsV0FBVTtBQUFBLDRCQUFpQjtBQUFBO0FBQUEsMEJBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQXpDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNENBO0FBQUEsWUFFSixDQUFDO0FBQ0Q7QUFBQSxVQUNGO0FBRUFKLHFCQUFXSCxRQUFRLENBQUNxQixNQUFNO0FBQ3hCdEIsdUJBQVc7QUFDWCxrQkFBTXVCLGdCQUFnQkQsR0FBRzdDLFdBQVcsQ0FBQztBQUVyQ3NCLGlCQUFLUSxLQUFLO0FBQUEsY0FDUkMsS0FBS04sUUFBUU07QUFBQUEsY0FDYkUsSUFBSVY7QUFBQUEsY0FDSnZCLFNBQVMwQixTQUFTUSxhQUFhO0FBQUEsY0FDL0JGLGtCQUFrQk4sVUFBVUs7QUFBQUE7QUFBQUEsY0FFNUJJLGdCQUFnQlcsY0FBY0MsZUFBZTtBQUFBLGNBQzdDWCx5QkFBeUI7QUFBQSxjQUN6QkMsZ0JBQWdCUyxjQUFjWixhQUFhO0FBQUEsY0FDM0NJLHdCQUF3QlEsY0FBY0UsZ0JBQWdCO0FBQUEsY0FDdERULFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsa0JBQ2pCLE1BQU07QUFBQSxvQkFDSkMsT0FBTztBQUFBLHNCQUNMO0FBQUEsd0JBQ0VDLEtBQUs7QUFBQSx3QkFDTEMsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxNQUFNQyxzQkFBc0JsQixRQUFRekIsU0FBUytCLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRVUsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU1FLHNCQUFzQm5CLFFBQVFNLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRVUsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFNBQVMsTUFBTTNFLHFCQUFxQjBELFFBQVFNLEdBQUc7QUFBQSw0QkFDL0MsV0FBVTtBQUFBLDRCQUFpQjtBQUFBO0FBQUEsMEJBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQXpDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNENBO0FBQUEsWUFFSixDQUFDO0FBQUEsVUFDSCxDQUFDO0FBQUEsUUFDSCxDQUFDO0FBRUR2RCwwQkFBa0I4QyxJQUFJO0FBQUEsTUFDeEIsU0FBU1AsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxxQ0FBcUNBLE9BQU9uQixPQUFPO0FBQUEsTUFDbkUsVUFBQztBQUNDVixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBRUErQix5QkFBcUI7QUFBQSxFQUN2QixHQUFHLENBQUM5QixhQUFhLENBQUM7QUFHbEIsUUFBTThELHdCQUF3QixPQUFPQyxnQkFBZ0JDLFNBQVNwRCxnQkFBZ0I7QUFDNUUsUUFBSSxDQUFDbUQsZUFBZ0I7QUFDckI1RCwyQkFBdUIsSUFBSTtBQUMzQixRQUFJO0FBQ0YsWUFBTXNCLFdBQVcsTUFBTXRELElBQUl1RDtBQUFBQSxRQUN6QixtQkFBbUJxQyxjQUFjO0FBQUEsTUFDbkM7QUFFQSxZQUFNRSxPQUNKeEMsVUFBVUUsTUFBTUEsTUFBTWMsaUJBQ3RCaEIsVUFBVUUsTUFBTWMsaUJBQ2hCaEIsVUFBVUUsTUFBTUEsTUFBTWEsY0FDdEJmLFVBQVVFLE1BQU1hLGNBQ2hCO0FBRUYsWUFBTTBCLFlBQVlELEtBQ2ZFO0FBQUFBLFFBQUksQ0FBQ0MsU0FDSixPQUFPQSxNQUFNdkQsWUFBWSxXQUNyQnVELEtBQUt2RCxVQUNMdUQsTUFBTXZELFNBQVMrQixPQUFPd0IsTUFBTXhCO0FBQUFBLE1BQ2xDLEVBQ0N5QixPQUFPQyxPQUFPO0FBRWpCTixhQUFPLENBQUNPLFVBQVUsRUFBRSxHQUFHQSxNQUFNekQsZ0JBQWdCb0QsVUFBVSxFQUFFO0FBQUEsSUFDM0QsU0FBU3RDLE9BQU87QUFDZEMsY0FBUTJDLEtBQUssd0NBQXdDNUMsT0FBT25CLE9BQU87QUFDbkV1RCxhQUFPLENBQUNPLFVBQVUsRUFBRSxHQUFHQSxNQUFNekQsZ0JBQWdCLEdBQUcsRUFBRTtBQUFBLElBQ3BELFVBQUM7QUFDQ1gsNkJBQXVCLEtBQUs7QUFBQSxJQUM5QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNc0UsZUFBZSxPQUFPckQsTUFBTTtBQUNoQ0EsTUFBRXNELGVBQWU7QUFFakIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQ2hFLFNBQVNFLFFBQVM4RCxXQUFVOUQsVUFBVTtBQUMzQyxRQUFJLENBQUNGLFNBQVNHLGdCQUFnQjRCO0FBQzVCaUMsZ0JBQVU3RCxpQkFBaUI7QUFFN0IsUUFBSThELE9BQU9DLEtBQUtGLFNBQVMsRUFBRWpDLFNBQVMsR0FBRztBQUNyQ3JDLGdCQUFVc0UsU0FBUztBQUNuQjtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTUcsVUFBVTtBQUFBLFFBQ2RyQyxlQUFlOUIsU0FBU0csZUFBZXFELElBQUksQ0FBQ3JCLFFBQVEsRUFBRWpDLFNBQVNpQyxHQUFHLEVBQUU7QUFBQSxNQUN0RTtBQUNBLFlBQU0zRSxJQUFJNEc7QUFBQUEsUUFDUixtQkFBbUJwRSxTQUFTRSxPQUFPO0FBQUEsUUFDbkNpRTtBQUFBQSxNQUNGO0FBRUE3RSx1QkFBaUIsQ0FBQ3NFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ2hFLHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVM7QUFBQSxRQUNURCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQ0RqQixtQkFBYSxLQUFLO0FBQ2xCcUIsa0JBQVksRUFBRUMsU0FBUyxJQUFJQyxnQkFBZ0IsR0FBRyxDQUFDO0FBQUEsSUFDakQsU0FBU2MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRCQUE0QkEsS0FBSztBQUMvQ3JCLHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVNtQixPQUFPSCxVQUFVRSxNQUFNbEIsV0FBVztBQUFBLFFBQzNDRCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFHQSxRQUFNd0UsZUFBZSxPQUFPNUQsTUFBTTtBQUNoQ0EsTUFBRXNELGVBQWU7QUFFakIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQzVELGVBQWVGLFFBQVM4RCxXQUFVOUQsVUFBVTtBQUNqRCxRQUFJLENBQUNFLGVBQWVELGdCQUFnQjRCO0FBQ2xDaUMsZ0JBQVU3RCxpQkFBaUI7QUFFN0IsUUFBSThELE9BQU9DLEtBQUtGLFNBQVMsRUFBRWpDLFNBQVMsR0FBRztBQUNyQ3JDLGdCQUFVc0UsU0FBUztBQUNuQjtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTUcsVUFBVTtBQUFBLFFBQ2RyQyxlQUFlMUIsZUFBZUQsZUFBZXFELElBQUksQ0FBQ3JCLFFBQVE7QUFBQSxVQUN4RGpDLFNBQVNpQztBQUFBQSxRQUNYLEVBQUU7QUFBQSxNQUNKO0FBQ0EsWUFBTTNFLElBQUk0RztBQUFBQSxRQUNSLG1CQUFtQmhFLGVBQWVGLE9BQU87QUFBQSxRQUN6Q2lFO0FBQUFBLE1BQ0Y7QUFFQW5GLHlCQUFtQixLQUFLO0FBQ3hCTSx1QkFBaUIsQ0FBQ3NFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ2hFLHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVM7QUFBQSxRQUNURCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSCxTQUFTb0IsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUNoRHJCLHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVNtQixPQUFPSCxVQUFVRSxNQUFNbEIsV0FBVztBQUFBLFFBQzNDRCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFHQSxRQUFNaUQsd0JBQXdCLE9BQU93QixXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNeEQsV0FBVyxNQUFNdEQsSUFBSXVEO0FBQUFBLFFBQ3pCLHVDQUF1Q3VELE1BQU07QUFBQSxNQUMvQztBQUNBcEYsMEJBQW9CNEIsU0FBU0UsTUFBTXVELFNBQVM7QUFDNUN6Rix5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNtQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBRUEsUUFBTXVELHdCQUF3QixZQUFZO0FBQ3hDLFFBQUksQ0FBQ3ZGLGlCQUFrQjtBQUN2QixRQUFJO0FBQ0YsWUFBTXpCLElBQUlpSDtBQUFBQSxRQUNSLDBDQUEwQ3hGLGlCQUFpQmdELEdBQUc7QUFBQSxNQUNoRTtBQUNBckMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRFQsdUJBQWlCLENBQUNzRSxTQUFTQSxPQUFPLENBQUM7QUFDbkM5RSx5QkFBbUIsS0FBSztBQUN4QkksMEJBQW9CLElBQUk7QUFBQSxJQUMxQixTQUFTK0IsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUdBLFFBQU00Qix3QkFBd0IsT0FBT3lCLFdBQVc7QUFDOUMsUUFBSTtBQUNGakUsd0JBQWtCO0FBQUEsUUFDaEJILFNBQVNvRTtBQUFBQSxRQUNUbkUsZ0JBQWdCO0FBQUEsTUFDbEIsQ0FBQztBQUNEbkIseUJBQW1CLElBQUk7QUFDdkJVLGdCQUFVLENBQUMsQ0FBQztBQUVaLFlBQU15RCxzQkFBc0JtQixRQUFRakUsaUJBQWlCO0FBQUEsSUFDdkQsU0FBU1ksT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUVBLFFBQU15RCxVQUFVO0FBQUEsSUFDZCxFQUFFL0IsS0FBSyxNQUFNZ0MsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRWhDLEtBQUssV0FBV2dDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDMUMsRUFBRWhDLEtBQUssa0JBQWtCZ0MsUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFaEMsS0FBSywyQkFBMkJnQyxRQUFRLGdCQUFnQjtBQUFBLElBQzFELEVBQUVoQyxLQUFLLGtCQUFrQmdDLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRWhDLEtBQUssMEJBQTBCZ0MsUUFBUSx5QkFBeUI7QUFBQSxJQUNsRSxFQUFFaEMsS0FBSyxVQUFVZ0MsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxTQUNFLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCbkU7QUFBQUEsVUFDN0IsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWIsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNnRSxVQUFVLEVBQUUsR0FBR0EsTUFBTS9ELFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BR0gsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDWCx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLGdDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBRXZEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2JqQiwrQkFBYSxJQUFJO0FBQ2pCYyw0QkFBVSxDQUFDLENBQUM7QUFDWk8sOEJBQVksRUFBRUMsU0FBUyxJQUFJQyxnQkFBZ0IsR0FBRyxDQUFDO0FBQUEsZ0JBQ2pEO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUF1RztBQUFBO0FBQUEsY0FObkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVDMUIsZ0JBQWdCc0QsU0FBUyxLQUFLLENBQUM1QyxZQUM5QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsZUFBZTBEO0FBQUFBLFlBQ2YsTUFBTTlFLGFBQWFVLGdCQUFnQjZCLFVBQVU7QUFBQSxZQUM3QztBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxVQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNb0MsSUFHcEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTN0IsZUFBZXNELFVBQVU7QUFBQSxZQUNsQyxNQUFLO0FBQUE7QUFBQSxVQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUd1QjtBQUFBLFdBaEMzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUNBO0FBQUEsU0FsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1EQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdwRDtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyx1QkFBYSxLQUFLO0FBQ2xCcUIsc0JBQVksRUFBRUMsU0FBUyxJQUFJQyxnQkFBZ0IsR0FBRyxDQUFDO0FBQy9DVCxvQkFBVSxDQUFDLENBQUM7QUFBQSxRQUNkO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDhCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVb0UsY0FBYyxZQUFVLE1BQzVEO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUM5Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcscUNBQXFDM0YsVUFBVXlHLE1BQU07QUFBQSxrQkFDaEUsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsT0FBTzVFLFNBQVNFLFdBQVcyRTtBQUFBQSxrQkFDM0IsVUFBVSxDQUFDbEUsVUFBVTtBQUNuQlYsZ0NBQVksQ0FBQzJELFVBQVU7QUFBQSxzQkFDckIsR0FBR0E7QUFBQUEsc0JBQ0gxRCxTQUFTUztBQUFBQSxzQkFDVFIsZ0JBQWdCO0FBQUEsb0JBQ2xCLEVBQUU7QUFDRmdELDBDQUFzQnhDLEtBQUs7QUFBQSxrQkFDN0I7QUFBQSxrQkFDQSxjQUFjLENBQUNtRSxPQUFPQyxXQUNwQkEsUUFBUUMsVUFBVUMsWUFBWSxFQUFFQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxrQkFHN0QxRyxnQkFBTWlGO0FBQUFBLG9CQUFJLENBQUMyQixTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLbEQsS0FDdkNrRCxlQUFLL0MsYUFEWStDLEtBQUtsRCxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FzQkE7QUFBQSxjQUNDeEMsT0FBT1MsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCVCxpQkFBT1MsV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxpQkE1QjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUN0QztBQUFBLGdCQUN4Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQTtBQUFBLGtCQUNBLGFBQ0UsQ0FBQ0YsU0FBU0UsVUFDTiw0QkFDQVgsc0JBQ0UsaUNBQ0E7QUFBQSxrQkFFUixVQUFVLENBQUNTLFNBQVNFLFdBQVdYO0FBQUFBLGtCQUMvQixTQUFTQTtBQUFBQSxrQkFDVCxXQUFXLHFDQUFxQ3BCLFVBQVV5RyxNQUFNO0FBQUEsa0JBQ2hFLE9BQU81RSxTQUFTRyxrQkFBa0I7QUFBQSxrQkFDbEMsVUFBVSxDQUFDaUYsZ0JBQ1RuRixZQUFZLENBQUMyRCxVQUFVO0FBQUEsb0JBQ3JCLEdBQUdBO0FBQUFBLG9CQUNIekQsZ0JBQWdCaUY7QUFBQUEsa0JBQ2xCLEVBQUU7QUFBQSxrQkFFSixjQUFjLENBQUNOLE9BQU9DLFdBQ3BCQSxRQUFRQyxVQUFVQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGtCQUU5RCxrQkFBaUI7QUFBQSxrQkFFaEIxRyxnQkFDRW1GLE9BQU8sQ0FBQzJCLE1BQU1BLEVBQUVwRCxRQUFRakMsU0FBU0UsT0FBTyxFQUN4Q3NEO0FBQUFBLG9CQUFJLENBQUMyQixTQUNKLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLbEQsS0FDdkNrRCxlQUFLL0MsYUFEWStDLEtBQUtsRCxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWpDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FrQ0E7QUFBQSxjQUNDeEMsT0FBT1Usa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVixpQkFBT1Usa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDbUc7QUFBQTtBQUFBLGNBSC9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBeEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUZBO0FBQUEsYUE3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThGQTtBQUFBO0FBQUEsTUF0R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBdUdBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3BCO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCcUIsNEJBQWtCLEVBQUVILFNBQVMsSUFBSUMsZ0JBQWdCLEdBQUcsQ0FBQztBQUNyRFQsb0JBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDZDtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1Qyx1Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVTJFLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDOUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ2xHLFVBQVV5RyxNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLE9BQU94RSxlQUFlRixXQUFXMkU7QUFBQUEsa0JBQ2pDLFVBQVUsQ0FBQ2xFLFVBQVU7QUFDbkJOLHNDQUFrQixDQUFDdUQsVUFBVTtBQUFBLHNCQUMzQixHQUFHQTtBQUFBQSxzQkFDSDFELFNBQVNTO0FBQUFBLHNCQUNUUixnQkFBZ0I7QUFBQSxvQkFDbEIsRUFBRTtBQUNGZ0QsMENBQXNCeEMsT0FBT04saUJBQWlCO0FBQUEsa0JBQ2hEO0FBQUEsa0JBQ0EsY0FBYyxDQUFDeUUsT0FBT0MsV0FDcEJBLFFBQVFDLFVBQVVDLFlBQVksRUFBRUMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsa0JBRzdEMUcsZ0JBQU1pRjtBQUFBQSxvQkFBSSxDQUFDMkIsU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS2xELEtBQ3ZDa0QsZUFBSy9DLGFBRFkrQyxLQUFLbEQsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBc0JBO0FBQUEsY0FDQ3hDLE9BQU9TLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QlQsaUJBQU9TLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBNUI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDdEM7QUFBQSxnQkFDeEIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQSxhQUNFLENBQUNFLGVBQWVGLFVBQ1osNEJBQ0FYLHNCQUNFLGlDQUNBO0FBQUEsa0JBRVIsVUFBVSxDQUFDYSxlQUFlRixXQUFXWDtBQUFBQSxrQkFDckMsU0FBU0E7QUFBQUEsa0JBQ1QsV0FBVyxxQ0FBcUNwQixVQUFVeUcsTUFBTTtBQUFBLGtCQUNoRSxPQUFPeEUsZUFBZUQsa0JBQWtCO0FBQUEsa0JBQ3hDLFVBQVUsQ0FBQ2lGLGdCQUNUL0Usa0JBQWtCLENBQUN1RCxVQUFVO0FBQUEsb0JBQzNCLEdBQUdBO0FBQUFBLG9CQUNIekQsZ0JBQWdCaUY7QUFBQUEsa0JBQ2xCLEVBQUU7QUFBQSxrQkFFSixjQUFjLENBQUNOLE9BQU9DLFdBQ3BCQSxRQUFRQyxVQUFVQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGtCQUU5RCxrQkFBaUI7QUFBQSxrQkFFaEIxRyxnQkFDRW1GLE9BQU8sQ0FBQzJCLE1BQU1BLEVBQUVwRCxRQUFRN0IsZUFBZUYsT0FBTyxFQUM5Q3NEO0FBQUFBLG9CQUFJLENBQUMyQixTQUNKLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLbEQsS0FDdkNrRCxlQUFLL0MsYUFEWStDLEtBQUtsRCxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWpDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FrQ0E7QUFBQSxjQUNDeEMsT0FBT1Usa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVixpQkFBT1Usa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDbUc7QUFBQTtBQUFBLGNBSC9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBeEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUZBO0FBQUEsYUE3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThGQTtBQUFBO0FBQUEsTUF0R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBdUdBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3RCO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSSw4QkFBb0IsSUFBSTtBQUFBLFFBQzFCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLGdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0Qsb0JBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ3dCLE1BQU07QUFDZkEsa0JBQUVzRCxlQUFlO0FBQ2pCUyxzQ0FBc0I7QUFBQSxjQUN4QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVztBQUFBO0FBQUEsd0JBRU47QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2J2RiwyQkFBaUJzRCxrQkFDaEJ0RCxrQkFBa0JpQixTQUFTa0MsYUFDM0IsU0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0M7QUFBQTtBQUFBO0FBQUEsb0JBWGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFZQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUsySTtBQUFBLHFCQW5CN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQkE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNtRztBQUFBO0FBQUEsa0JBSC9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBO0FBQUE7QUFBQSxZQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQ0E7QUFBQSxhQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkNBO0FBQUE7QUFBQSxNQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtREE7QUFBQSxPQTlURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK1RBLEtBaFVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpVUE7QUFFSjtBQUFFOUQsR0Fwc0JJRCxpQkFBZTtBQUFBaUgsS0FBZmpIO0FBc3NCTixlQUFlQTtBQUFnQixJQUFBaUg7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiSW5wdXQiLCJTZWxlY3QiLCJEcm9wZG93biIsIklvTWRNb3JlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJoYW5kbGVHdWFyYW50b3JQcmludCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiZmllbGRTaXplIiwiQnJlYWRjcnVtYiIsIkxpbmtlZEd1YXJhbnRvciIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsIlRhYmxlR3VhcmFudG9yIiwic2V0VGFibGVHdWFyYW50b3IiLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50R3VhcmFudG9yIiwic2V0Q3VycmVudEd1YXJhbnRvciIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiaXNFbnJvbGxtZW50TG9hZGluZyIsInNldElzRW5yb2xsbWVudExvYWRpbmciLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXJfaWQiLCJ1c2VyX2d1YXJhbnRvciIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJ1c2VFZmZlY3QiLCJmZXRjaFVzZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hMaW5rZWRHdWFyYW50b3IiLCJyZWNvcmRzIiwiQXJyYXkiLCJpc0FycmF5IiwibG9nIiwicm93cyIsImNvdW50ZXIiLCJmb3JFYWNoIiwicmVjb3JkIiwiY3VzdG9tZXIiLCJndWFyYW50b3JzIiwiZ3VhcmFudG9yTGlzdCIsImxlbmd0aCIsInB1c2giLCJfaWQiLCJjdXN0b21lcl91c2VyX2lkIiwiaWQiLCJmdWxsX25hbWUiLCJndWFyYW50b3JfY29kZSIsImd1YXJhbnRvcl9yZWZlcnJlZF90eXBlIiwiZ3VhcmFudG9yX25hbWUiLCJndWFyYW50b3JfcGhvbmVfbnVtYmVyIiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJsYWJlbCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImciLCJndWFyYW50b3JVc2VyIiwiY3VzdG9tZXJfaWQiLCJwaG9uZV9udW1iZXIiLCJmZXRjaExpbmtlZEd1YXJhbnRvcnMiLCJjdXN0b21lclVzZXJJZCIsInNldHRlciIsImxpc3QiLCJsaW5rZWRJZHMiLCJtYXAiLCJpdGVtIiwiZmlsdGVyIiwiQm9vbGVhbiIsInByZXYiLCJ3YXJuIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJuZXdFcnJvcnMiLCJPYmplY3QiLCJrZXlzIiwicGF5bG9hZCIsInBvc3QiLCJoYW5kbGVVcGRhdGUiLCJ1c2VySWQiLCJndWFyYW50b3IiLCJoYW5kbGVEZWxldGVHdWFyYW50b3IiLCJkZWxldGUiLCJjb2x1bW5zIiwiaGVhZGVyIiwiaGVpZ2h0IiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1c2VyIiwic2VsZWN0ZWRJZHMiLCJ1IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGlua2VkR3VhcmFudG9yLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IGhhbmRsZUd1YXJhbnRvclByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9HdWFyYW50b3JQcmludFwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCBMaW5rZWRHdWFyYW50b3IgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlR3VhcmFudG9yLCBzZXRUYWJsZUd1YXJhbnRvcl0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRHdWFyYW50b3IsIHNldEN1cnJlbnRHdWFyYW50b3JdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbaXNFbnJvbGxtZW50TG9hZGluZywgc2V0SXNFbnJvbGxtZW50TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICB1c2VyX2d1YXJhbnRvcjogW10sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHVzZXJfZ3VhcmFudG9yOiBbXSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEZldGNoIHVzZXJzIC0tLS0tLS0tLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEZldGNoIGxpbmtlZC1ndWFyYW50b3IgdGFibGUgZGF0YSAtLS0tLS0tLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTGlua2VkR3VhcmFudG9yID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgXCIvdjEvYWRtaW4vdXNlcnMvbGlua2VkLWd1YXJhbnRvcnNcIiAvLyDwn5GIIHZlcmlmeSB0aGUgZXhhY3QgcGF0aFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIHJlc3BvbnNlIHNoYXBlOiB7IHN1Y2Nlc3MsIHN0YXR1c0NvZGUsIG1lc3NhZ2UsIGRhdGE6IFsuLi5dIH1cclxuICAgICAgICBjb25zdCByZWNvcmRzID0gQXJyYXkuaXNBcnJheShyZXNwb25zZT8uZGF0YT8uZGF0YSlcclxuICAgICAgICAgID8gcmVzcG9uc2UuZGF0YS5kYXRhXHJcbiAgICAgICAgICA6IFtdO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdyZWVlJywgcmVjb3Jkcyk7XHJcblxyXG5cclxuICAgICAgICAvLyBGbGF0dGVuOiBvbmUgcm93IHBlciAoY3VzdG9tZXIg4oaSIGd1YXJhbnRvcikgbGlua1xyXG4gICAgICAgIGNvbnN0IHJvd3MgPSBbXTtcclxuICAgICAgICBsZXQgY291bnRlciA9IDA7XHJcblxyXG4gICAgICAgIHJlY29yZHMuZm9yRWFjaCgocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBjdXN0b21lciA9IHJlY29yZD8udXNlcl9pZCB8fCB7fTtcclxuICAgICAgICAgIGNvbnN0IGd1YXJhbnRvcnMgPSBBcnJheS5pc0FycmF5KHJlY29yZD8uZ3VhcmFudG9yTGlzdClcclxuICAgICAgICAgICAgPyByZWNvcmQuZ3VhcmFudG9yTGlzdFxyXG4gICAgICAgICAgICA6IFtdO1xyXG5cclxuICAgICAgICAgIGlmIChndWFyYW50b3JzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICBjb3VudGVyICs9IDE7XHJcbiAgICAgICAgICAgIHJvd3MucHVzaCh7XHJcbiAgICAgICAgICAgICAgX2lkOiByZWNvcmQ/Ll9pZCxcclxuICAgICAgICAgICAgICBjdXN0b21lcl91c2VyX2lkOiBjdXN0b21lcj8uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBjb3VudGVyLFxyXG4gICAgICAgICAgICAgIHVzZXJfaWQ6IGN1c3RvbWVyLmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgIGd1YXJhbnRvcl9jb2RlOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgIGd1YXJhbnRvcl9yZWZlcnJlZF90eXBlOiBcIkN1c3RvbWVyXCIsXHJcbiAgICAgICAgICAgICAgZ3VhcmFudG9yX25hbWU6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgZ3VhcmFudG9yX3Bob25lX251bWJlcjogXCJOL0FcIixcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihyZWNvcmQ/LnVzZXJfaWQ/Ll9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3BlbihyZWNvcmQ/Ll9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlR3VhcmFudG9yUHJpbnQocmVjb3JkPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBndWFyYW50b3JzLmZvckVhY2goKGcpID0+IHtcclxuICAgICAgICAgICAgY291bnRlciArPSAxO1xyXG4gICAgICAgICAgICBjb25zdCBndWFyYW50b3JVc2VyID0gZz8udXNlcl9pZCB8fCB7fTtcclxuXHJcbiAgICAgICAgICAgIHJvd3MucHVzaCh7XHJcbiAgICAgICAgICAgICAgX2lkOiByZWNvcmQ/Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogY291bnRlcixcclxuICAgICAgICAgICAgICB1c2VyX2lkOiBjdXN0b21lci5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBjdXN0b21lcl91c2VyX2lkOiBjdXN0b21lcj8uX2lkLFxyXG4gICAgICAgICAgICAgIC8vIEd1YXJhbnRvciBDb2RlIGNvbHVtbiDihpIgdGhlIGd1YXJhbnRvcidzIGN1c3RvbWVyX2lkXHJcbiAgICAgICAgICAgICAgZ3VhcmFudG9yX2NvZGU6IGd1YXJhbnRvclVzZXIuY3VzdG9tZXJfaWQgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBndWFyYW50b3JfcmVmZXJyZWRfdHlwZTogXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgIGd1YXJhbnRvcl9uYW1lOiBndWFyYW50b3JVc2VyLmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgIGd1YXJhbnRvcl9waG9uZV9udW1iZXI6IGd1YXJhbnRvclVzZXIucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4ocmVjb3JkPy51c2VyX2lkPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4ocmVjb3JkPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUd1YXJhbnRvclByaW50KHJlY29yZD8uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldFRhYmxlR3VhcmFudG9yKHJvd3MpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsaW5rZWQgZ3VhcmFudG9yczpcIiwgZXJyb3I/Lm1lc3NhZ2UpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hMaW5rZWRHdWFyYW50b3IoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEZldGNoIGxpbmtlZCBndWFyYW50b3JzIGZvciBhIGN1c3RvbWVyIC0tLS0tLS0tLS1cclxuICBjb25zdCBmZXRjaExpbmtlZEd1YXJhbnRvcnMgPSBhc3luYyAoY3VzdG9tZXJVc2VySWQsIHNldHRlciA9IHNldEZvcm1EYXRhKSA9PiB7XHJcbiAgICBpZiAoIWN1c3RvbWVyVXNlcklkKSByZXR1cm47XHJcbiAgICBzZXRJc0Vucm9sbG1lbnRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvdjEvYWRtaW4vdXNlcnMvJHtjdXN0b21lclVzZXJJZH0vbGlua2VkLWd1YXJhbnRvcmBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IGxpc3QgPVxyXG4gICAgICAgIHJlc3BvbnNlPy5kYXRhPy5kYXRhPy5ndWFyYW50b3JMaXN0IHx8XHJcbiAgICAgICAgcmVzcG9uc2U/LmRhdGE/Lmd1YXJhbnRvckxpc3QgfHxcclxuICAgICAgICByZXNwb25zZT8uZGF0YT8uZGF0YT8uZ3VhcmFudG9ycyB8fFxyXG4gICAgICAgIHJlc3BvbnNlPy5kYXRhPy5ndWFyYW50b3JzIHx8XHJcbiAgICAgICAgW107XHJcblxyXG4gICAgICBjb25zdCBsaW5rZWRJZHMgPSBsaXN0XHJcbiAgICAgICAgLm1hcCgoaXRlbSkgPT5cclxuICAgICAgICAgIHR5cGVvZiBpdGVtPy51c2VyX2lkID09PSBcInN0cmluZ1wiXHJcbiAgICAgICAgICAgID8gaXRlbS51c2VyX2lkXHJcbiAgICAgICAgICAgIDogaXRlbT8udXNlcl9pZD8uX2lkIHx8IGl0ZW0/Ll9pZFxyXG4gICAgICAgIClcclxuICAgICAgICAuZmlsdGVyKEJvb2xlYW4pO1xyXG5cclxuICAgICAgc2V0dGVyKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB1c2VyX2d1YXJhbnRvcjogbGlua2VkSWRzIH0pKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUud2FybihcIk5vIGxpbmtlZCBndWFyYW50b3JzIC8gZmV0Y2ggZmFpbGVkOlwiLCBlcnJvcj8ubWVzc2FnZSk7XHJcbiAgICAgIHNldHRlcigocHJldikgPT4gKHsgLi4ucHJldiwgdXNlcl9ndWFyYW50b3I6IFtdIH0pKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzRW5yb2xsbWVudExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gQWRkIC0tLS0tLS0tLS1cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgaWYgKCFmb3JtRGF0YS51c2VyX2lkKSBuZXdFcnJvcnMudXNlcl9pZCA9IFwiQ3VzdG9tZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZm9ybURhdGEudXNlcl9ndWFyYW50b3I/Lmxlbmd0aClcclxuICAgICAgbmV3RXJyb3JzLnVzZXJfZ3VhcmFudG9yID0gXCJTZWxlY3QgYXQgbGVhc3Qgb25lIGN1c3RvbWVyIHRvIGxpbmtcIjtcclxuXHJcbiAgICBpZiAoT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICBndWFyYW50b3JMaXN0OiBmb3JtRGF0YS51c2VyX2d1YXJhbnRvci5tYXAoKGlkKSA9PiAoeyB1c2VyX2lkOiBpZCB9KSksXHJcbiAgICAgIH07XHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgIGAvdjEvYWRtaW4vdXNlcnMvJHtmb3JtRGF0YS51c2VyX2lkfS9saW5rZWQtZ3VhcmFudG9yYCxcclxuICAgICAgICBwYXlsb2FkXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICBtZXNzYWdlOiBcIkd1YXJhbnRvciBsaW5rZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldEZvcm1EYXRhKHsgdXNlcl9pZDogXCJcIiwgdXNlcl9ndWFyYW50b3I6IFtdIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGxpbmtpbmcgZ3VhcmFudG9yOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC5cIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIFVwZGF0ZSAtLS0tLS0tLS0tXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghdXBkYXRlRm9ybURhdGEudXNlcl9pZCkgbmV3RXJyb3JzLnVzZXJfaWQgPSBcIkN1c3RvbWVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIXVwZGF0ZUZvcm1EYXRhLnVzZXJfZ3VhcmFudG9yPy5sZW5ndGgpXHJcbiAgICAgIG5ld0Vycm9ycy51c2VyX2d1YXJhbnRvciA9IFwiU2VsZWN0IGF0IGxlYXN0IG9uZSBjdXN0b21lciB0byBsaW5rXCI7XHJcblxyXG4gICAgaWYgKE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID4gMCkge1xyXG4gICAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgZ3VhcmFudG9yTGlzdDogdXBkYXRlRm9ybURhdGEudXNlcl9ndWFyYW50b3IubWFwKChpZCkgPT4gKHtcclxuICAgICAgICAgIHVzZXJfaWQ6IGlkLFxyXG4gICAgICAgIH0pKSxcclxuICAgICAgfTtcclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgYC92MS9hZG1pbi91c2Vycy8ke3VwZGF0ZUZvcm1EYXRhLnVzZXJfaWR9L2xpbmtlZC1ndWFyYW50b3JgLFxyXG4gICAgICAgIHBheWxvYWRcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiR3VhcmFudG9yIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgR3VhcmFudG9yOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiVXBkYXRlIGZhaWxlZFwiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gRGVsZXRlIC0tLS0tLS0tLS1cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9ndWFyYW50b3IvZ2V0LWd1YXJhbnRvci1pbmZvLWJ5LWlkLyR7dXNlcklkfWBcclxuICAgICAgKTtcclxuICAgICAgc2V0Q3VycmVudEd1YXJhbnRvcihyZXNwb25zZS5kYXRhPy5ndWFyYW50b3IpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgR3VhcmFudG9yOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlR3VhcmFudG9yID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFjdXJyZW50R3VhcmFudG9yKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkuZGVsZXRlKFxyXG4gICAgICAgIGAvZ3VhcmFudG9yL2RlbGV0ZS1ndWFyYW50b3ItaW5mby1ieS1pZC8ke2N1cnJlbnRHdWFyYW50b3IuX2lkfWBcclxuICAgICAgKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJndWFyYW50b3IgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgc2V0Q3VycmVudEd1YXJhbnRvcihudWxsKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBHdWFyYW50b3I6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIE9wZW4gVXBkYXRlIG1vZGFsIC0tLS0tLS0tLS1cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgdXNlcl9pZDogdXNlcklkLFxyXG4gICAgICAgIHVzZXJfZ3VhcmFudG9yOiBbXSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuXHJcbiAgICAgIGF3YWl0IGZldGNoTGlua2VkR3VhcmFudG9ycyh1c2VySWQsIHNldFVwZGF0ZUZvcm1EYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBHdWFyYW50b3I6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyX2lkXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImd1YXJhbnRvcl9jb2RlXCIsIGhlYWRlcjogXCJHdWFyYW50b3IgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJndWFyYW50b3JfcmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJndWFyYW50b3JfbmFtZVwiLCBoZWFkZXI6IFwiR3VhcmFudG9yIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3VhcmFudG9yX3Bob25lX251bWJlclwiLCBoZWFkZXI6IFwiR3VhcmFudG9yIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+TGlua2VkIEd1YXJhbnRvcjwvaDE+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyB1c2VyX2lkOiBcIlwiLCB1c2VyX2d1YXJhbnRvcjogW10gfSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgKyBMaW5rIEd1YXJhbnRvclxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge1RhYmxlR3VhcmFudG9yPy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24oVGFibGVHdWFyYW50b3IsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkd1YXJhbnRvclwiXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgR3VhcmFudG9yLmNzdmB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgZmFpbHVyZT17VGFibGVHdWFyYW50b3IubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPVwiR3VhcmFudG9yIERhdGFcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PSBBREQgTU9EQUwgPT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWx9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgdXNlcl9pZDogXCJcIiwgdXNlcl9ndWFyYW50b3I6IFtdIH0pO1xyXG4gICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgTGluayBHdWFyYW50b3JcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnVzZXJfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlcl9pZDogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICB1c2VyX2d1YXJhbnRvcjogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZldGNoTGlua2VkR3VhcmFudG9ycyh2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlbj8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEN1c3RvbWVyIHRvIExpbmt7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICBtYXhUYWdDb3VudD1cInJlc3BvbnNpdmVcIlxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xyXG4gICAgICAgICAgICAgICAgICAgICFmb3JtRGF0YS51c2VyX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiU2VsZWN0IGEgY3VzdG9tZXIgZmlyc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBpc0Vucm9sbG1lbnRMb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJMb2FkaW5nIGxpbmtlZCBndWFyYW50b3JzLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNlbGVjdCBjdXN0b21lcnMgdG8gbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFmb3JtRGF0YS51c2VyX2lkIHx8IGlzRW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2lzRW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudXNlcl9ndWFyYW50b3IgfHwgW119XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoc2VsZWN0ZWRJZHMpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlcl9ndWFyYW50b3I6IHNlbGVjdGVkSWRzLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlbj8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vyc1xyXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKHUpID0+IHUuX2lkICE9PSBmb3JtRGF0YS51c2VyX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgIC5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy51c2VyX2d1YXJhbnRvciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnVzZXJfZ3VhcmFudG9yfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgTGluayBHdWFyYW50b3JcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09IFVQREFURSBNT0RBTCA9PT09PT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoeyB1c2VyX2lkOiBcIlwiLCB1c2VyX2d1YXJhbnRvcjogW10gfSk7XHJcbiAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBVcGRhdGUgTGlua2VkIEd1YXJhbnRvclxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudXNlcl9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICB1c2VyX2lkOiB2YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgIHVzZXJfZ3VhcmFudG9yOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hMaW5rZWRHdWFyYW50b3JzKHZhbHVlLCBzZXRVcGRhdGVGb3JtRGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlbj8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEN1c3RvbWVyIHRvIExpbmt7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICBtYXhUYWdDb3VudD1cInJlc3BvbnNpdmVcIlxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xyXG4gICAgICAgICAgICAgICAgICAgICF1cGRhdGVGb3JtRGF0YS51c2VyX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiU2VsZWN0IGEgY3VzdG9tZXIgZmlyc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBpc0Vucm9sbG1lbnRMb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJMb2FkaW5nIGxpbmtlZCBndWFyYW50b3JzLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNlbGVjdCBjdXN0b21lcnMgdG8gbGlua1wiXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF1cGRhdGVGb3JtRGF0YS51c2VyX2lkIHx8IGlzRW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2lzRW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudXNlcl9ndWFyYW50b3IgfHwgW119XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoc2VsZWN0ZWRJZHMpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlcl9ndWFyYW50b3I6IHNlbGVjdGVkSWRzLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlbj8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vyc1xyXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKHUpID0+IHUuX2lkICE9PSB1cGRhdGVGb3JtRGF0YS51c2VyX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgIC5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy51c2VyX2d1YXJhbnRvciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnVzZXJfZ3VhcmFudG9yfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PSBERUxFVEUgTU9EQUwgPT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRHdWFyYW50b3IobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgR3VhcmFudG9yXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50R3VhcmFudG9yICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlR3VhcmFudG9yKCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQbGVhc2UgZW50ZXJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRHdWFyYW50b3IuZ3VhcmFudG9yX25hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudEd1YXJhbnRvcj8udXNlcl9pZD8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEd1YXJhbnRvciBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGlua2VkR3VhcmFudG9yOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9MaW5rZWRHdWFyYW50b3IuanN4In0=