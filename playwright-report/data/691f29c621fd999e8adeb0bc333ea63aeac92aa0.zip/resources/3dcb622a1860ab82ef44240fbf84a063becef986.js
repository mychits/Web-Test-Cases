import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RegistrationFees.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Modal as AntModal, Drawer, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import dataPaymentsFor from "/src/data/paymentsFor.js";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaReceipt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const RegistrationFee = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [userName, setUserName] = useState("");
  const [viewLoader, setViewLoader] = useState(false);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentUpdateAmount, setCurrentUpdateAmount] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [receiptNo, setReceiptNo] = useState("");
  const whatsappEnable = true;
  const [paymentMode, setPaymentMode] = useState("cash");
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [paymentFor, setPaymentFor] = useState(dataPaymentsFor.typeChit);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [borrowers, setBorrowers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [enableGroupColumn, setEnableGroupColumn] = useState(true);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [render, setRerender] = useState(0);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [openAntDDrawer, setOpenAntDDrawer] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [lastThreePayments, setLastThreePayments] = useState([]);
  const dropDownItems = (group) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(Link, { to: `/reg-fee-print/${group._id}`, className: "text-violet-600 ", children: "Print" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
          lineNumber: 67,
          columnNumber: 7
        }, this)
      },
      //   {
      //     key: "2",
      //     label: (
      //       <div
      //         className="text-red-600 "
      //         onClick={() => handleDeleteModalOpen(group._id)}
      //       >
      //         Delete
      //       </div>
      //     ),
      //   },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600 ",
            onClick: () => handleViewModalOpen(group._id),
            children: "View"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 86,
            columnNumber: 7
          },
          this
        )
      }
    ];
    if (modifyPayment) {
      dropDownItemList.push({
        key: "4",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-violet-600 ",
            onClick: () => handleUpdateModalOpen(group._id),
            children: "Update Amount"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 99,
            columnNumber: 9
          },
          this
        )
      });
    }
    return dropDownItemList;
  };
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    user_id: "",
    receipt_no: "",
    pay_date: today,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    payment_group_tickets: [],
    account_type: "",
    pay_for: "",
    note: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    amount: "",
    pay_date: ""
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const handleUploadModalClose = () => {
    setShowUploadModal(false);
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setModifyPayment(isModify);
    }
  }, []);
  useEffect(() => {
    const usr = localStorage.getItem("user");
    let admin_type = null;
    try {
      if (usr) {
        admin_type = JSON.parse(usr);
      }
    } catch (e) {
      console.error("Failed to parse user from localStorage:", e);
    }
    const fetchTodaysPayments = async () => {
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get("/registration-fee/get-reg-fee-by-dates", {
          params: {
            from_date: today,
            to_date: today
          }
        });
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              //   group_name: group?.group_id?.group_name ? `${group?.group_id?.group_name}`:
              //     group?.group_id?.group_name ? `${group?.group_id?.group_name}`: "N/A",
              group_name: group?.group_id?.group_name || group?.pay_for || "N/A",
              ticket: group.ticket,
              receipt: group.receipt_no,
              old_receipt: group.old_receipt_no,
              amount: group.amount,
              date: formatPayDate(group.pay_date),
              pay_for: group?.pay_for,
              transaction_date: formatPayDate(group.createdAt),
              note: group?.note,
              collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                    lineNumber: 217,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 210,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 209,
                columnNumber: 15
              }, this)
            };
          });
          setTablePayments(formattedData);
          setEnableGroupColumn(true);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setFilteredAuction([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchTodaysPayments();
  }, [render]);
  useEffect(() => {
    setBorrowers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/loans/get-borrower-by-user-id/${selectedGroupId}`
        );
        if (response.status >= 400)
          throw new Error("fetching loan borrowers Failed");
        setBorrowers(response.data);
      } catch (err) {
        console.log("Error Occurred");
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedGroupId]);
  useEffect(() => {
    setPigmeCustomers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/pigme/get-pigme-customer-by-user-id/${selectedGroupId}`
        );
        if (response.status >= 400)
          throw new Error("fetching pigme customers Failed");
        setPigmeCustomers(response.data);
      } catch (err) {
        console.log(
          "Error Occurred while fetching pigme customers,",
          err.message
        );
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedGroupId]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [alertConfig]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [alertConfig]);
  useEffect(() => {
    const fetchReceipt = async () => {
      try {
        const response = await api.get("/registration-fee/get-fee-latest-receipt");
        console.info("testing", response.data);
        setReceiptNo(response.data);
      } catch (error) {
        console.error("Error fetching receipt data:", error);
      }
    };
    fetchReceipt();
  }, [alertConfig]);
  useEffect(() => {
    if (receiptNo) {
      setFormData((prevData) => ({
        ...prevData,
        receipt_no: receiptNo.receipt_no
      }));
    }
  }, [receiptNo]);
  const validateForm = () => {
    const newErrors = {};
    if (!selectedGroupId) {
      newErrors.customer = "Please select a customer";
    }
    if (!formData.payment_group_tickets) {
      newErrors.payment_group_tickets = "Please select a group and ticket";
    }
    if (!formData.pay_date) {
      newErrors.pay_date = "Payment date is required";
    }
    if (!formData.pay_for) {
      newErrors.pay_for = "Registration Type is required";
    }
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    if (paymentMode === "online" && !formData.transaction_id?.trim()) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({ ...prevData, [name]: "" }));
  };
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/enroll/get-group-enroll/${groupId}`);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const onChoosePaymentFor = (e) => {
    setPaymentFor(e.target.value);
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  if (enableGroupColumn) {
    columns.push({ key: "group_name", header: "Group Name" });
  }
  columns.push(
    { key: "ticket", header: "Ticket Number" },
    { key: "old_receipt", header: "Old Receipt" },
    { key: "receipt", header: "Receipt" },
    { key: "amount", header: "Amount" },
    { key: "pay_for", header: "Registration Type" },
    { key: "note", header: "Remarks" },
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  );
  const handleGroup = async (event) => {
    const groupId = event.target.value;
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: groupId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    handleGroupChange(groupId);
    handleGroupAuctionChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleCustomer = async (groupId) => {
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: groupId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    setPaymentGroupTickets([]);
    handleGroupChange(groupId);
    handleGroupAuctionChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    handleGroupPaymentChange(groupId);
  };
  const formatPayDate = (dateString) => {
    return dateString?.split("T")[0];
  };
  const handleGroupPaymentChange = async (groupId) => {
    setSelectedAuctionGroup(groupId);
    if (groupId) {
      let url;
      if (groupId === "today") {
        url = `/registration-fee/get-reg-fee-by-dates?from_date=${today}&to_date=${today}`;
        setEnableGroupColumn(true);
      } else {
        url = `/registration-fee/get-registration-group-fee-by-id/${groupId}`;
        setEnableGroupColumn(false);
      }
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              pay_for: group?.pay_for,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              receipt: group.receipt_no,
              old_receipt: group.old_receipt_no,
              amount: group.amount,
              date: group?.pay_date.split("T")[0],
              note: group?.note,
              transaction_date: group?.createdAt?.split("T")[0],
              collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                    lineNumber: 547,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 540,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 539,
                columnNumber: 15
              }, this)
            };
          });
          setTablePayments(formattedData);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setFilteredAuction([]);
      } finally {
        setIsLoading(false);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prevData.transaction_id : ""
    }));
  };
  const handlePaymentFor = (e) => {
    const selectedMode = e.target.value;
    setFormData((prevData) => ({
      ...prevData,
      pay_for: selectedMode
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        setDisabled(true);
        setAlertConfig((prev) => ({
          ...prev,
          visibility: false
        }));
        setShowModal(false);
        let payload;
        const usr = localStorage.getItem("user");
        let admin_type = null;
        try {
          if (usr) {
            admin_type = JSON.parse(usr);
          }
        } catch (e2) {
          console.error("Failed to parse user from localStorage:", e2);
        }
        formData.payment_group_tickets = paymentGroupTickets;
        formData.admin_type = admin_type?._id;
        setOpenBackdropLoader(true);
        const response = await api.post(
          "/registration-fee/add-multiple-registration-fee",
          formData
        );
        if (response.status === 201) {
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            // receipt_no: "",
            pay_date: today,
            amount: "",
            pay_type: "cash",
            transaction_id: "",
            payment_group_tickets: [],
            account_type: "",
            pay_for: "",
            note: ""
          });
          setAlertConfig({
            visibility: true,
            noReload: true,
            message: "registration fee Added Successfully",
            type: "success"
          });
        }
        if (response.status >= 400) {
          setShowModal(false);
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            // receipt_no: "",
            pay_date: today,
            amount: "",
            pay_type: "cash",
            transaction_id: "",
            payment_group_tickets: [],
            account_type: "",
            pay_for: "",
            note: ""
          });
          setAlertConfig({
            visibility: true,
            noReload: true,
            message: "registration fee Added Failed",
            type: "error"
          });
        }
      }
    } catch (error) {
      setShowModal(false);
      setSelectedGroupId("");
      setFormData({
        user_id: "",
        receipt_no: "",
        pay_date: "",
        amount: "",
        pay_type: "cash",
        transaction_id: "",
        payment_group_tickets: [],
        account_type: "",
        pay_for: "",
        note: ""
      });
      setAlertConfig({
        visibility: true,
        noReload: true,
        message: `Error submitting registration fee data`,
        type: "error"
      });
      setDisabled(false);
      console.error("Error submitting registration fee data:", error);
    } finally {
      setOpenBackdropLoader(false);
      setRerender((prev) => prev + 1);
    }
  };
  const handleViewModalOpen = async (groupId) => {
    try {
      setLoading(true);
      setShowModalView(true);
      setCurrentGroupId(groupId);
      setViewLoader(true);
      const response = await api.get(
        `/registration-fee/get-registration-fee-by-id/${groupId}`
      );
      console.info("registration testing", response.data);
      setCurrentViewGroup(response.data);
    } catch (error) {
      console.error("Error viewing registration-fee:", error);
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(
        `/registration-fee/get-registration-fee-by-id/${groupId}`
      );
      setCurrentUpdateAmount(response.data);
      setUpdateFormData({
        amount: response?.data?.amount,
        pay_date: response?.data?.pay_date.split("T")[0]
      });
      setShowUpdateModal(true);
    } catch (error) {
      console.error("Error fetching Payment Amount data:", error);
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        `/payment/update-payment-amount/${currentUpdateAmount._id}`,
        updateFormData
      );
      setShowUpdateModal(false);
      setAlertConfig({
        visibility: true,
        message: "Payment Amount Updated Successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error updating Payment Amount:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error?.response?.data?.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const handleGroupAuctionChange = async (groupId) => {
    if (groupId) {
      try {
        const response = await api.post(
          `/enroll/get-user-tickets-report/${groupId}`
        );
        if (response.data && response.data.length > 0) {
          const validAuctions = response.data.filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setFilteredAuction(validAuctions);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "payment Data processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
    lineNumber: 882,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 886,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
      lineNumber: 890,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        noReload: alertConfig.noReload
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 891,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 898,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Registration Fee" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 899,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6  mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-bold ", children: "Search or Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 902,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full mt-4", children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Today's Registration Fee",
                popupMatchSelectWidth: false,
                showSearch: true,
                className: "w-full  h-14 max-w-md",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: selectedAuctionGroupId || void 0,
                onChange: handleGroupPayment,
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "today", children: "Today's Payments" }, "#1", false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                    lineNumber: 918,
                    columnNumber: 23
                  }, this),
                  actualGroups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 922,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 904,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setShowModal(true),
                  className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                  children: "+ Add Registration Fees"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 928,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setShowUploadModal(true),
                  className: "ml-4 bg-yellow-300 text-black px-4 py-2 rounded shadow-md hover:bg-yellow-400 transition duration-200",
                  children: "Upload Excel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 934,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 927,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 903,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
          lineNumber: 901,
          columnNumber: 17
        }, this),
        TablePayments && TablePayments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: TablePayments.filter(
              (item) => Object.values(item).some(
                (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
              )
            ),
            columns,
            exportedPdfName: "Registration Fees",
            exportedFileName: `Registration Fees.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 955,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Payments Data",
            failure: TablePayments.length <= 0 && selectedAuctionGroupId
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 969,
            columnNumber: 21
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
          lineNumber: 968,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 900,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
      lineNumber: 897,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setSelectedGroupId("");
          setShowModal(false);
          setErrors({});
          setPaymentGroupTickets([]);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Registration Fees" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 991,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Customer ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1065,
                      columnNumber: 32
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1061,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full ${fieldSize.height}`,
                  placeholder: "Select Or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: selectedGroupId || void 0,
                  onChange: handleCustomer,
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: `${group.full_name} | ${group.phone_number}` }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1083,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1068,
                  columnNumber: 21
                },
                this
              ),
              errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1090,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1060,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pay",
                  children: "Registration Fee"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1097,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "pay",
                  id: "pay_for",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                  onChange: handlePaymentFor,
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Registration Fee Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1109,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Reg|Chit", children: "Chit Registration Fee " }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1110,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Reg|Pigme", children: "Pigme Registration Fee" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1111,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Reg|Loan", children: "Loan Registration Fee" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1112,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1103,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1096,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Group & Ticket ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1121,
                      columnNumber: 38
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1117,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  name: "group_id",
                  placeholder: "Select Group | Ticket",
                  onChange: handlePaymentAntSelect,
                  value: paymentGroupTickets,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5 ",
                  children: [
                    formData.pay_for === "Reg|Chit" && /* @__PURE__ */ jsxDEV(Fragment, { children: filteredAuction.map((entry, index) => {
                      const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                      const groupId = entry?.enrollment?.group?._id || `missing-${index}`;
                      const ticket = entry?.enrollment?.tickets || "Unknown";
                      return /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `chit-${groupId}|${ticket}`,
                          children: [
                            groupName,
                            " | ",
                            ticket
                          ]
                        },
                        `chit-${groupId}|${ticket}`,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                          lineNumber: 1144,
                          columnNumber: 27
                        },
                        this
                      );
                    }) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1132,
                      columnNumber: 21
                    }, this),
                    formData.pay_for === "Reg|Pigme" && /* @__PURE__ */ jsxDEV(Fragment, { children: pigmeCustomers?.map((pigme) => {
                      return /* @__PURE__ */ jsxDEV(Select.Option, { value: `pigme-${pigme._id}`, children: `${pigme.pigme_id} | ₹ ${pigme.payable_amount}` }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                        lineNumber: 1158,
                        columnNumber: 27
                      }, this);
                    }) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1155,
                      columnNumber: 21
                    }, this),
                    formData.pay_for === "Reg|Loan" && /* @__PURE__ */ jsxDEV(Fragment, { children: borrowers?.map((borrower) => {
                      return /* @__PURE__ */ jsxDEV(Select.Option, { value: `loan-${borrower._id}`, children: `loan-${borrower.loan_id} | ₹ ${borrower.loan_amount}` }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                        lineNumber: 1169,
                        columnNumber: 27
                      }, this);
                    }) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1166,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1123,
                  columnNumber: 21
                },
                this
              ),
              errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.payment_group_tickets }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1178,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1116,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "group_install",
                  children: "Payment Date"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1186,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  disabled: !modifyPayment,
                  type: "date",
                  name: "pay_date",
                  value: formData.pay_date,
                  id: "pay_date",
                  onChange: handleChange,
                  placeholder: "",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1192,
                  columnNumber: 23
                },
                this
              ),
              errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1204,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1185,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1184,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: [
                      "Amount ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                        lineNumber: 1217,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                    lineNumber: 1213,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "amount",
                    value: formData.amount,
                    id: "amount",
                    onChange: handleChange,
                    placeholder: "Enter Amount",
                    required: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                    lineNumber: 1220,
                    columnNumber: 25
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1219,
                  columnNumber: 23
                }, this),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1233,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1212,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "pay_mode",
                    children: "Payment Mode"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                    lineNumber: 1239,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "pay_mode",
                    id: "pay_mode",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                    onChange: handlePaymentModeChange,
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                        lineNumber: 1251,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                        lineNumber: 1252,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Credit Note", children: "Credit Note" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                        lineNumber: 1253,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Transfer", children: "Transfer" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                        lineNumber: 1254,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                    lineNumber: 1245,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1238,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1211,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "note",
                  children: "Note"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1260,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  id: "note",
                  name: "note",
                  rows: 2,
                  value: formData?.note,
                  onChange: handleChange,
                  placeholder: "Enter note",
                  className: "w-full rounded-lg border border-gray-300 bg-white px-3 py-2.5 text-sm\r\n                       text-gray-900 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200 resize-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1266,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1259,
              columnNumber: 19
            }, this),
            formData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pay_mode",
                  children: "Individual Ticket Amount"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1279,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg hover:cursor-not-allowed w-full p-2.5",
                  placeholder: "totalAmount",
                  value: Number(formData.amount) / paymentGroupTickets.length,
                  disabled: true
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1286,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1278,
              columnNumber: 17
            }, this),
            paymentMode === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "transaction_id",
                  children: [
                    "Transaction ID ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                      lineNumber: 1303,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1299,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "transaction_id",
                  id: "transaction_id",
                  value: formData.transaction_id,
                  onChange: handleChange,
                  placeholder: "Enter Transaction ID",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1305,
                  columnNumber: 23
                },
                this
              ),
              errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1315,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1298,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Save Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1322,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1321,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 994,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
          lineNumber: 990,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 981,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: showModalView,
        onCancel: () => setShowModalView(false),
        onClose: () => setShowModalView(false),
        onOk: () => setShowModalView(false),
        onReload: () => handleViewModalOpen(currentGroupId),
        footer: /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
          lineNumber: 1342,
          columnNumber: 21
        }, this),
        loading: viewLoader,
        children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Payment Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 1345,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group: " }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1350,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1349,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Value:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1354,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1353,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Installment:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1358,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_install
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1357,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "User:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1362,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.user_id?.full_name,
              " ",
              "| Ticket: ",
              currentViewGroup?.ticket
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1361,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Bid Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1366,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount ? currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount : ""
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1365,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Commission:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1374,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.commission
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1373,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Winning Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1377,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.win_amount
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1376,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1381,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1380,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident per Head:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1384,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident_head
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1383,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Payable:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1388,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.payable
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1387,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Auction Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1391,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.auction_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1390,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1395,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.next_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1394,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Created At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1398,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.createdAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1397,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Updated At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                lineNumber: 1402,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.updatedAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1401,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 1348,
            columnNumber: 15
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 1336,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Sure want to delete this Payment ?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
            lineNumber: 1417,
            columnNumber: 17
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteAuction();
              },
              className: "space-y-6",
              children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-full text-white bg-red-700 hover:bg-red-800\r\n                    focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                  children: "Delete"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
                  lineNumber: 1428,
                  columnNumber: 21
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
              lineNumber: 1421,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
          lineNumber: 1416,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
        lineNumber: 1409,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
    lineNumber: 885,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
    lineNumber: 884,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx",
    lineNumber: 880,
    columnNumber: 5
  }, this);
};
_s(RegistrationFee, "DTXVj4kWq1927ZJl/SrhWaEJqhk=");
_c = RegistrationFee;
export default RegistrationFee;
var _c;
$RefreshReg$(_c, "RegistrationFee");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFees.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VVLFNBeWlDYyxVQXppQ2Q7MkJBbEVWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyx3QkFBd0I7QUFDakMsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxVQUFVUCxTQUFTUSxVQUFVQyxRQUFRQyxlQUFlO0FBQ3JFLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZO0FBQ3JCLE9BQU9DLHFCQUFxQjtBQUM1QixPQUFPQyx3QkFBd0I7QUFDL0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyxnQkFBZ0I7QUFDdkIsTUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFDNUIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl4QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDeUIsY0FBY0MsZUFBZSxJQUFJMUIsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQzJCLGVBQWVDLGdCQUFnQixJQUFJNUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzZCLGVBQWVDLGdCQUFnQixJQUFJOUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQytCLHNCQUFzQkMsdUJBQXVCLElBQUloQyxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDaUMsaUJBQWlCQyxrQkFBa0IsSUFBSWxDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNtQyx3QkFBd0JDLHlCQUF5QixJQUFJcEMsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQ3FDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3VDLFVBQVVDLFdBQVcsSUFBSXhDLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN5QyxZQUFZQyxhQUFhLElBQUkxQyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDMkMsaUJBQWlCQyxrQkFBa0IsSUFBSTVDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUM2QyxXQUFXQyxZQUFZLElBQUk5QyxTQUFTLENBQUMsQ0FBQztBQUM3QyxRQUFNLENBQUMrQyxXQUFXQyxZQUFZLElBQUloRCxTQUFTLEtBQUs7QUFFaEQsUUFBTSxDQUFDaUQsaUJBQWlCQyxrQkFBa0IsSUFBSWxELFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNtRCxxQkFBcUJDLHNCQUFzQixJQUFJcEQsU0FBUyxLQUFLO0FBRXBFLFFBQU0sQ0FBQ3FELGNBQWNDLGVBQWUsSUFBSXRELFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUN1RCxlQUFlQyxnQkFBZ0IsSUFBSXhELFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUN5RCxrQkFBa0JDLG1CQUFtQixJQUFJMUQsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQzJELGlCQUFpQkMsa0JBQWtCLElBQUk1RCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNkQsV0FBV0MsWUFBWSxJQUFJOUQsU0FBUyxFQUFFO0FBQzdDLFFBQU0rRCxpQkFBaUI7QUFDdkIsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlqRSxTQUFTLE1BQU07QUFDckQsUUFBTWtFLFNBQVEsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ25ELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJdkUsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3dFLFNBQVNDLFVBQVUsSUFBSXpFLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUMwRSxVQUFVQyxXQUFXLElBQUkzRSxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDNEUsWUFBWUMsYUFBYSxJQUFJN0UsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzhFLFlBQVlDLGFBQWEsSUFBSS9FLFNBQVNnQixnQkFBZ0JnRSxRQUFRO0FBQ3JFLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSWxGLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNtRixXQUFXQyxZQUFZLElBQUlwRixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDcUYsZ0JBQWdCQyxpQkFBaUIsSUFBSXRGLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUN1RixtQkFBbUJDLG9CQUFvQixJQUFJeEYsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ3lGLHFCQUFxQkMsc0JBQXNCLElBQUkxRixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDMkYsUUFBUUMsV0FBVyxJQUFJNUYsU0FBUyxDQUFDO0FBQ3hDLFFBQU0sQ0FBQzZGLG9CQUFvQkMscUJBQXFCLElBQUk5RixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDK0YsZ0JBQWdCQyxpQkFBaUIsSUFBSWhHLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNpRyxnQkFBZ0JDLGlCQUFpQixJQUFJbEcsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ21HLFlBQVlDLGFBQWEsSUFBSXBHLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNxRyxtQkFBbUJDLG9CQUFvQixJQUFJdEcsU0FBUyxFQUFFO0FBRTdELFFBQU11RyxnQkFBZ0JBLENBQUNDLFVBQVU7QUFDL0IsVUFBTUMsbUJBQW1CO0FBQUEsTUFDdkI7QUFBQSxRQUNFQyxLQUFLO0FBQUEsUUFDTEMsT0FDRSx1QkFBQyxRQUFLLElBQUksa0JBQWtCSCxNQUFNSSxHQUFHLElBQUksV0FBVSxvQkFBbUIscUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQTtBQUFBLFFBQ0VGLEtBQUs7QUFBQSxRQUNMQyxPQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1FLG9CQUFvQkwsTUFBTUksR0FBRztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsTUFFSjtBQUFBLElBQUM7QUFFSCxRQUFJRSxlQUFlO0FBQ2pCTCx1QkFBaUJNLEtBQUs7QUFBQSxRQUNwQkwsS0FBSztBQUFBLFFBQ0xDLE9BQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTUssc0JBQXNCUixNQUFNSSxHQUFHO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxNQUVKLENBQUM7QUFBQSxJQUNIO0FBQ0EsV0FBT0g7QUFBQUEsRUFDVDtBQUNBLFFBQU1RLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJ2QyxrQkFBY3NDLEtBQUs7QUFBQSxFQUNyQjtBQUNBLFFBQU0sQ0FBQ0UsYUFBYUMsY0FBYyxJQUFJdEgsU0FBUztBQUFBLElBQzdDdUgsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJNUgsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDNkgsVUFBVUMsV0FBVyxJQUFJOUgsU0FBUztBQUFBLElBQ3ZDK0gsU0FBUztBQUFBLElBQ1RDLFlBQVk7QUFBQSxJQUNaQyxVQUFVL0Q7QUFBQUEsSUFDVmdFLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxjQUFjO0FBQUEsSUFDZEMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUkxSSxTQUFTO0FBQUEsSUFDbkRrSSxRQUFRO0FBQUEsSUFDUkQsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUVELFFBQU0sQ0FBQ25CLGVBQWU2QixnQkFBZ0IsSUFBSTNJLFNBQVMsS0FBSztBQUV4RCxRQUFNNEkseUJBQXlCQSxNQUFNO0FBQ25DaEYsdUJBQW1CLEtBQUs7QUFBQSxFQUMxQjtBQUVBN0QsWUFBVSxNQUFNO0FBQ2QsVUFBTThJLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBRS9CLFFBQ0VHLFdBQ0FBLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxjQUNuRDtBQUNBLFlBQU1DLFdBQ0pOLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxpQkFDakQsU0FDRSxPQUNBO0FBQ05WLHVCQUFpQlcsUUFBUTtBQUFBLElBQzNCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFDTHZKLFlBQVUsTUFBTTtBQUNkLFVBQU13SixNQUFNVCxhQUFhQyxRQUFRLE1BQU07QUFDdkMsUUFBSVMsYUFBYTtBQUVqQixRQUFJO0FBQ0YsVUFBSUQsS0FBSztBQUNQQyxxQkFBYVAsS0FBS0MsTUFBTUssR0FBRztBQUFBLE1BQzdCO0FBQUEsSUFDRixTQUFTckMsR0FBRztBQUNWdUMsY0FBUUMsTUFBTSwyQ0FBMkN4QyxDQUFDO0FBQUEsSUFDNUQ7QUFFQSxVQUFNeUMsc0JBQXNCLFlBQVk7QUFDdEMsVUFBSTtBQUNGN0gseUJBQWlCLEVBQUU7QUFDbkJ5QyxxQkFBYSxJQUFJO0FBQ2pCLGNBQU1xRixXQUFXLE1BQU0xSixJQUFJMkosSUFBSSwwQ0FBMEM7QUFBQSxVQUN2RUMsUUFBUTtBQUFBLFlBQ05DLFdBQVc3RjtBQUFBQSxZQUNYOEYsU0FBUzlGO0FBQUFBLFVBQ1g7QUFBQSxRQUNGLENBQUM7QUFFRCxZQUFJMEYsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNQyxnQkFBZ0JQLFNBQVNLLEtBQUtHLElBQUksQ0FBQzVELE9BQU82RCxVQUFVO0FBR3hELG1CQUFPO0FBQUEsY0FDTHpELEtBQUtKLE1BQU1JO0FBQUFBLGNBQ1gwRCxJQUFJRCxRQUFRO0FBQUEsY0FDWkUsTUFBTS9ELE9BQU91QixTQUFTeUM7QUFBQUEsY0FDdEJDLGNBQWNqRSxPQUFPdUIsU0FBUzBDO0FBQUFBO0FBQUFBO0FBQUFBLGNBRzlCQyxZQUFZbEUsT0FBT21FLFVBQVVELGNBQWNsRSxPQUFPK0IsV0FBVztBQUFBLGNBQzdEcUMsUUFBUXBFLE1BQU1vRTtBQUFBQSxjQUNkQyxTQUFTckUsTUFBTXdCO0FBQUFBLGNBQ2Y4QyxhQUFhdEUsTUFBTXVFO0FBQUFBLGNBQ25CN0MsUUFBUTFCLE1BQU0wQjtBQUFBQSxjQUNkOEMsTUFBTUMsY0FBY3pFLE1BQU15QixRQUFRO0FBQUEsY0FDbENNLFNBQVMvQixPQUFPK0I7QUFBQUEsY0FDaEIyQyxrQkFBa0JELGNBQWN6RSxNQUFNMkUsU0FBUztBQUFBLGNBQy9DM0MsTUFBTWhDLE9BQU9nQztBQUFBQSxjQUNiNEMsY0FDRTVFLE9BQU80RSxjQUFjYixRQUNyQi9ELE9BQU9nRCxZQUFZNkIsY0FDbkI7QUFBQSxjQUNGQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGtCQUNqQixNQUFNO0FBQUEsb0JBQ0pDLE9BQU9oRixjQUFjQyxLQUFLO0FBQUEsa0JBQzVCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLFlBRUo7QUFBQSxVQUNGLENBQUM7QUFDRDFFLDJCQUFpQnFJLGFBQWE7QUFDOUIzRSwrQkFBcUIsSUFBSTtBQUFBLFFBQzNCLE9BQU87QUFDTDVDLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVM4RyxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRDlHLDJCQUFtQixFQUFFO0FBQUEsTUFDdkIsVUFBQztBQUNDMkIscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUVBb0Ysd0JBQW9CO0FBQUEsRUFDdEIsR0FBRyxDQUFDaEUsTUFBTSxDQUFDO0FBNEJYNUYsWUFBVSxNQUFNO0FBQ2RxRixpQkFBYSxFQUFFO0FBQ2YsVUFBTW9HLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNNUIsV0FBVyxNQUFNMUosSUFBSTJKO0FBQUFBLFVBQ3pCLGtDQUFrQzVILGVBQWU7QUFBQSxRQUNuRDtBQUNBLFlBQUkySCxTQUFTNkIsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLGdDQUFnQztBQUNsRHRHLHFCQUFhd0UsU0FBU0ssSUFBSTtBQUFBLE1BQzVCLFNBQVMwQixLQUFLO0FBQ1psQyxnQkFBUW1DLElBQUksZ0JBQWdCO0FBQUEsTUFDOUI7QUFBQSxJQUNGO0FBRUFKLDZCQUF5QjtBQUFBLEVBQzNCLEdBQUcsQ0FBQ3ZKLGVBQWUsQ0FBQztBQUVwQmxDLFlBQVUsTUFBTTtBQUNkdUYsc0JBQWtCLEVBQUU7QUFDcEIsVUFBTWtHLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNNUIsV0FBVyxNQUFNMUosSUFBSTJKO0FBQUFBLFVBQ3pCLHdDQUF3QzVILGVBQWU7QUFBQSxRQUN6RDtBQUNBLFlBQUkySCxTQUFTNkIsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLGlDQUFpQztBQUNuRHBHLDBCQUFrQnNFLFNBQVNLLElBQUk7QUFBQSxNQUNqQyxTQUFTMEIsS0FBSztBQUNabEMsZ0JBQVFtQztBQUFBQSxVQUNOO0FBQUEsVUFDQUQsSUFBSW5FO0FBQUFBLFFBQ047QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBZ0UsNkJBQXlCO0FBQUEsRUFDM0IsR0FBRyxDQUFDdkosZUFBZSxDQUFDO0FBRXBCbEMsWUFBVSxNQUFNO0FBQ2QsVUFBTThMLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTWpDLFdBQVcsTUFBTTFKLElBQUkySixJQUFJLGdCQUFnQjtBQUMvQ3JJLGtCQUFVb0ksU0FBU0ssSUFBSTtBQUFBLE1BQ3pCLFNBQVNQLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FtQyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDeEUsV0FBVyxDQUFDO0FBRWhCdEgsWUFBVSxNQUFNO0FBQ2QsVUFBTThMLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTWpDLFdBQVcsTUFBTTFKLElBQUkySixJQUFJLHdCQUF3QjtBQUN2RG5JLHdCQUFnQmtJLFNBQVNLLElBQUk7QUFBQSxNQUMvQixTQUFTUCxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBbUMsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ3hFLFdBQVcsQ0FBQztBQUVoQnRILFlBQVUsTUFBTTtBQUNkLFVBQU0rTCxlQUFlLFlBQVk7QUFDL0IsVUFBSTtBQUNGLGNBQU1sQyxXQUFXLE1BQU0xSixJQUFJMkosSUFBSSwwQ0FBMEM7QUFDekVKLGdCQUFRc0MsS0FBSyxXQUFXbkMsU0FBU0ssSUFBSTtBQUNyQ25HLHFCQUFhOEYsU0FBU0ssSUFBSTtBQUFBLE1BQzVCLFNBQVNQLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sZ0NBQWdDQSxLQUFLO0FBQUEsTUFDckQ7QUFBQSxJQUNGO0FBQ0FvQyxpQkFBYTtBQUFBLEVBQ2YsR0FBRyxDQUFDekUsV0FBVyxDQUFDO0FBRWhCdEgsWUFBVSxNQUFNO0FBQ2QsUUFBSThELFdBQVc7QUFDYmlFLGtCQUFZLENBQUNrRSxjQUFjO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSGhFLFlBQVluRSxVQUFVbUU7QUFBQUEsTUFDeEIsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ25FLFNBQVMsQ0FBQztBQUVkLFFBQU1vSSxlQUFlQSxNQUFNO0FBQ3pCLFVBQU1DLFlBQVksQ0FBQztBQUVuQixRQUFJLENBQUNqSyxpQkFBaUI7QUFDcEJpSyxnQkFBVUMsV0FBVztBQUFBLElBQ3ZCO0FBRUEsUUFBSSxDQUFDdEUsU0FBU1EsdUJBQXVCO0FBQ25DNkQsZ0JBQVU3RCx3QkFBd0I7QUFBQSxJQUNwQztBQUVBLFFBQUksQ0FBQ1IsU0FBU0ksVUFBVTtBQUN0QmlFLGdCQUFVakUsV0FBVztBQUFBLElBQ3ZCO0FBQ0EsUUFBSSxDQUFDSixTQUFTVSxTQUFTO0FBQ3JCMkQsZ0JBQVUzRCxVQUFVO0FBQUEsSUFDdEI7QUFFQSxVQUFNTCxTQUFTa0UsV0FBV3ZFLFNBQVNLLE1BQU07QUFDekMsUUFBSW1FLE1BQU1uRSxNQUFNLEtBQUtBLFVBQVUsR0FBRztBQUNoQ2dFLGdCQUFVaEUsU0FBUztBQUFBLElBQ3JCO0FBRUEsUUFBSWxFLGdCQUFnQixZQUFZLENBQUM2RCxTQUFTTyxnQkFBZ0JrRSxLQUFLLEdBQUc7QUFDaEVKLGdCQUFVOUQsaUJBQ1I7QUFBQSxJQUNKO0FBRUFSLGNBQVVzRSxTQUFTO0FBQ25CLFdBQU9LLE9BQU9DLEtBQUtOLFNBQVMsRUFBRWhDLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU11QyxlQUFlQSxDQUFDdkYsTUFBTTtBQUMxQixVQUFNLEVBQUVxRCxNQUFNcEQsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQlUsZ0JBQVksQ0FBQ2tFLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUN6QixJQUFJLEdBQUdwRDtBQUFBQSxJQUNWLEVBQUU7QUFDRlMsY0FBVSxDQUFDb0UsY0FBYyxFQUFFLEdBQUdBLFVBQVUsQ0FBQ3pCLElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUN2RDtBQUNBLFFBQU1tQyx5QkFBeUJBLENBQUNDLFdBQVc7QUFDekNqSCwyQkFBdUJpSCxNQUFNO0FBQUEsRUFDL0I7QUFFQSxRQUFNQyxvQkFBb0IsT0FBT0MsWUFBWTtBQUMzQ2pMLHFCQUFpQmlMLE9BQU87QUFFeEIsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNakQsV0FBVyxNQUFNMUosSUFBSTJKLElBQUksNEJBQTRCZ0QsT0FBTyxFQUFFO0FBQ3BFLFlBQUlqRCxTQUFTSyxRQUFRTCxTQUFTSyxLQUFLQyxTQUFTLEdBQUc7QUFDN0M1SCwyQkFBaUJzSCxTQUFTSyxJQUFJO0FBQUEsUUFDaEMsT0FBTztBQUNMM0gsMkJBQWlCLEVBQUU7QUFBQSxRQUNyQjtBQUFBLE1BQ0YsU0FBU29ILE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REcEgseUJBQWlCLEVBQUU7QUFBQSxNQUNyQjtBQUFBLElBQ0YsT0FBTztBQUNMQSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU13SyxxQkFBcUJBLENBQUM1RixNQUFNO0FBQ2hDbkMsa0JBQWNtQyxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsRUFDOUI7QUFFQSxRQUFNNEYsVUFBVTtBQUFBLElBQ2QsRUFBRXJHLEtBQUssTUFBTXNHLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUV0RyxLQUFLLFFBQVFzRyxRQUFRLFlBQVk7QUFBQSxJQUNuQyxFQUFFdEcsS0FBSyxvQkFBb0JzRyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUV0RyxLQUFLLFFBQVFzRyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUV0RyxLQUFLLGdCQUFnQnNHLFFBQVEsd0JBQXdCO0FBQUEsRUFBQztBQUUxRCxNQUFJekgsbUJBQW1CO0FBQ3JCd0gsWUFBUWhHLEtBQUssRUFBRUwsS0FBSyxjQUFjc0csUUFBUSxhQUFhLENBQUM7QUFBQSxFQUMxRDtBQUNBRCxVQUFRaEc7QUFBQUEsSUFDTixFQUFFTCxLQUFLLFVBQVVzRyxRQUFRLGdCQUFnQjtBQUFBLElBQ3pDLEVBQUV0RyxLQUFLLGVBQWVzRyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFdEcsS0FBSyxXQUFXc0csUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRXRHLEtBQUssVUFBVXNHLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUV0RyxLQUFLLFdBQVdzRyxRQUFRLG9CQUFvQjtBQUFBLElBQzlDLEVBQUV0RyxLQUFLLFFBQVFzRyxRQUFRLFVBQVU7QUFBQSxJQUNqQyxFQUFFdEcsS0FBSyxnQkFBZ0JzRyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFdEcsS0FBSyxVQUFVc0csUUFBUSxTQUFTO0FBQUEsRUFDcEM7QUFDQSxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkMsVUFBTUwsVUFBVUssTUFBTTlGLE9BQU9EO0FBQzdCakYsdUJBQW1CMkssT0FBTztBQUMxQi9FLGdCQUFZLENBQUNxRixrQkFBa0I7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNIcEYsU0FBUzhFO0FBQUFBLElBQ1gsRUFBRTtBQUNGakYsY0FBVSxDQUFDb0UsY0FBYyxFQUFFLEdBQUdBLFVBQVVHLFVBQVUsR0FBRyxFQUFFO0FBRXZEUyxzQkFBa0JDLE9BQU87QUFDekJPLDZCQUF5QlAsT0FBTztBQUVoQyxRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU1qRCxXQUFXLE1BQU0xSixJQUFJMkosSUFBSSwwQkFBMEJnRCxPQUFPLEVBQUU7QUFDbEUvSixxQkFBYThHLFNBQVNLLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDbEMsU0FBU1AsT0FBTztBQUNkNUcscUJBQWEsQ0FBQyxDQUFDO0FBQUEsTUFDakI7QUFBQSxJQUNGLE9BQU87QUFDTEEsbUJBQWEsQ0FBQyxDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTXVLLG9CQUFvQkEsQ0FBQ25HLE1BQU07QUFDL0IsVUFBTSxFQUFFcUQsTUFBTXBELE1BQU0sSUFBSUQsRUFBRUU7QUFDMUJzQixzQkFBa0IsQ0FBQ3NELGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUN6QixJQUFJLEdBQUdwRDtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTW1HLGlCQUFpQixPQUFPVCxZQUFZO0FBQ3hDM0ssdUJBQW1CMkssT0FBTztBQUMxQi9FLGdCQUFZLENBQUNxRixrQkFBa0I7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNIcEYsU0FBUzhFO0FBQUFBLElBQ1gsRUFBRTtBQUNGakYsY0FBVSxDQUFDb0UsY0FBYyxFQUFFLEdBQUdBLFVBQVVHLFVBQVUsR0FBRyxFQUFFO0FBQ3ZEekcsMkJBQXVCLEVBQUU7QUFDekJrSCxzQkFBa0JDLE9BQU87QUFDekJPLDZCQUF5QlAsT0FBTztBQUVoQyxRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU1qRCxXQUFXLE1BQU0xSixJQUFJMkosSUFBSSwwQkFBMEJnRCxPQUFPLEVBQUU7QUFDbEUvSixxQkFBYThHLFNBQVNLLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDbEMsU0FBU1AsT0FBTztBQUNkNUcscUJBQWEsQ0FBQyxDQUFDO0FBQUEsTUFDakI7QUFBQSxJQUNGLE9BQU87QUFDTEEsbUJBQWEsQ0FBQyxDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBQ0EsUUFBTXlLLHFCQUFxQixPQUFPVixZQUFZO0FBQzVDekssOEJBQTBCeUssT0FBTztBQUNqQ1csNkJBQXlCWCxPQUFPO0FBQUEsRUFDbEM7QUFFQSxRQUFNNUIsZ0JBQWdCQSxDQUFDd0MsZUFBZTtBQUNwQyxXQUFPQSxZQUFZcEosTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ2pDO0FBRUEsUUFBTW1KLDJCQUEyQixPQUFPWCxZQUFZO0FBQ2xEN0ssNEJBQXdCNkssT0FBTztBQUMvQixRQUFJQSxTQUFTO0FBQ1gsVUFBSWE7QUFDSixVQUFJYixZQUFZLFNBQVM7QUFDdkJhLGNBQU0sb0RBQW9EeEosS0FBSyxZQUFZQSxLQUFLO0FBQ2hGc0IsNkJBQXFCLElBQUk7QUFBQSxNQUMzQixPQUFPO0FBQ0xrSSxjQUFNLHNEQUFzRGIsT0FBTztBQUNuRXJILDZCQUFxQixLQUFLO0FBQUEsTUFDNUI7QUFDQSxVQUFJO0FBQ0YxRCx5QkFBaUIsRUFBRTtBQUNuQnlDLHFCQUFhLElBQUk7QUFDakIsY0FBTXFGLFdBQVcsTUFBTTFKLElBQUkySixJQUFJNkQsR0FBRztBQUVsQyxZQUFJOUQsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNQyxnQkFBZ0JQLFNBQVNLLEtBQUtHLElBQUksQ0FBQzVELE9BQU82RCxVQUFVO0FBQ3hELGdCQUFJLENBQUM3RCxPQUFPbUUsVUFBVUQsV0FBWSxRQUFPLENBQUM7QUFDMUMsbUJBQU87QUFBQSxjQUNMOUQsS0FBS0osTUFBTUk7QUFBQUEsY0FDWDBELElBQUlELFFBQVE7QUFBQSxjQUNaRSxNQUFNL0QsT0FBT3VCLFNBQVN5QztBQUFBQSxjQUN0QmpDLFNBQVMvQixPQUFPK0I7QUFBQUEsY0FDaEJrQyxjQUFjakUsT0FBT3VCLFNBQVMwQztBQUFBQSxjQUM5QkMsWUFBWWxFLE9BQU9tRSxVQUFVRDtBQUFBQSxjQUM3QkUsUUFBUXBFLE1BQU1vRTtBQUFBQSxjQUNkQyxTQUFTckUsTUFBTXdCO0FBQUFBLGNBQ2Y4QyxhQUFhdEUsTUFBTXVFO0FBQUFBLGNBQ25CN0MsUUFBUTFCLE1BQU0wQjtBQUFBQSxjQUNkOEMsTUFBTXhFLE9BQU95QixTQUFTNUQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGNBQ2xDbUUsTUFBTWhDLE9BQU9nQztBQUFBQSxjQUNiMEMsa0JBQWtCMUUsT0FBTzJFLFdBQVc5RyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsY0FDaEQrRyxjQUNFNUUsT0FBTzRFLGNBQWNiLFFBQ3JCL0QsT0FBT2dELFlBQVk2QixjQUNuQjtBQUFBLGNBQ0ZDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsa0JBQ2pCLE1BQU07QUFBQSxvQkFDSkMsT0FBT2hGLGNBQWNDLEtBQUs7QUFBQSxrQkFDNUI7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUE7QUFBQSxnQkFQakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsWUFFSjtBQUFBLFVBQ0YsQ0FBQztBQUNEMUUsMkJBQWlCcUksYUFBYTtBQUFBLFFBQ2hDLE9BQU87QUFDTHZILDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVM4RyxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRDlHLDJCQUFtQixFQUFFO0FBQUEsTUFDdkIsVUFBQztBQUNDMkIscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRixPQUFPO0FBQ0wzQix5QkFBbUIsRUFBRTtBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU0rSywwQkFBMEJBLENBQUN6RyxNQUFNO0FBQ3JDLFVBQU0wRyxlQUFlMUcsRUFBRUUsT0FBT0Q7QUFDOUJsRCxtQkFBZTJKLFlBQVk7QUFDM0I5RixnQkFBWSxDQUFDa0UsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0g3RCxVQUFVeUY7QUFBQUEsTUFFVnhGLGdCQUFnQndGLGlCQUFpQixXQUFXNUIsU0FBUzVELGlCQUFpQjtBQUFBLElBQ3hFLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTXlGLG1CQUFtQkEsQ0FBQzNHLE1BQU07QUFDOUIsVUFBTTBHLGVBQWUxRyxFQUFFRSxPQUFPRDtBQUM5QlcsZ0JBQVksQ0FBQ2tFLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNIekQsU0FBU3FGO0FBQUFBLElBQ1gsRUFBRTtBQUFBLEVBQ0o7QUFzREEsUUFBTUUsZUFBZSxPQUFPNUcsTUFBTTtBQUNoQ0EsTUFBRTZHLGVBQWU7QUFDakIsVUFBTUMsVUFBVS9CLGFBQWE7QUFDN0IsUUFBSTtBQUNGLFVBQUkrQixTQUFTO0FBQ1hySixvQkFBWSxJQUFJO0FBQ2hCMkMsdUJBQWUsQ0FBQzJHLFVBQVU7QUFBQSxVQUN4QixHQUFHQTtBQUFBQSxVQUNIMUcsWUFBWTtBQUFBLFFBQ2QsRUFBRTtBQUNGdkUscUJBQWEsS0FBSztBQUNsQixZQUFJa0w7QUFDSixjQUFNM0UsTUFBTVQsYUFBYUMsUUFBUSxNQUFNO0FBQ3ZDLFlBQUlTLGFBQWE7QUFDakIsWUFBSTtBQUNGLGNBQUlELEtBQUs7QUFDUEMseUJBQWFQLEtBQUtDLE1BQU1LLEdBQUc7QUFBQSxVQUM3QjtBQUFBLFFBQ0YsU0FBU3JDLElBQUc7QUFDVnVDLGtCQUFRQyxNQUFNLDJDQUEyQ3hDLEVBQUM7QUFBQSxRQUM1RDtBQUVBVyxpQkFBU1Esd0JBQXdCNUM7QUFDakNvQyxpQkFBUzJCLGFBQWFBLFlBQVk1QztBQUNsQ2QsOEJBQXNCLElBQUk7QUFDMUIsY0FBTThELFdBQVcsTUFBTTFKLElBQUlpTztBQUFBQSxVQUN6QjtBQUFBLFVBQ0F0RztBQUFBQSxRQUNGO0FBQ0EsWUFBSStCLFNBQVM2QixXQUFXLEtBQUs7QUFDM0J2Siw2QkFBbUIsRUFBRTtBQUNyQndELGlDQUF1QixFQUFFO0FBQ3pCZixzQkFBWSxLQUFLO0FBQ2pCbUQsc0JBQVk7QUFBQSxZQUNWQyxTQUFTO0FBQUE7QUFBQSxZQUVURSxVQUFVL0Q7QUFBQUEsWUFDVmdFLFFBQVE7QUFBQSxZQUNSQyxVQUFVO0FBQUEsWUFDVkMsZ0JBQWdCO0FBQUEsWUFDaEJDLHVCQUF1QjtBQUFBLFlBQ3ZCQyxjQUFjO0FBQUEsWUFDZEMsU0FBUztBQUFBLFlBQ1RDLE1BQU07QUFBQSxVQUNSLENBQUM7QUFDRGxCLHlCQUFlO0FBQUEsWUFDYkMsWUFBWTtBQUFBLFlBQ1pFLFVBQVU7QUFBQSxZQUNWRCxTQUFTO0FBQUEsWUFDVEUsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFFQSxZQUFJa0MsU0FBUzZCLFVBQVUsS0FBSztBQUMxQnpJLHVCQUFhLEtBQUs7QUFDbEJkLDZCQUFtQixFQUFFO0FBQ3JCd0QsaUNBQXVCLEVBQUU7QUFDekJmLHNCQUFZLEtBQUs7QUFDakJtRCxzQkFBWTtBQUFBLFlBQ1ZDLFNBQVM7QUFBQTtBQUFBLFlBRVRFLFVBQVUvRDtBQUFBQSxZQUNWZ0UsUUFBUTtBQUFBLFlBQ1JDLFVBQVU7QUFBQSxZQUNWQyxnQkFBZ0I7QUFBQSxZQUNoQkMsdUJBQXVCO0FBQUEsWUFDdkJDLGNBQWM7QUFBQSxZQUNkQyxTQUFTO0FBQUEsWUFDVEMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUNEbEIseUJBQWU7QUFBQSxZQUNiQyxZQUFZO0FBQUEsWUFDWkUsVUFBVTtBQUFBLFlBQ1ZELFNBQVM7QUFBQSxZQUNURSxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFNBQVNnQyxPQUFPO0FBQ2QxRyxtQkFBYSxLQUFLO0FBQ2xCZCx5QkFBbUIsRUFBRTtBQUNyQjRGLGtCQUFZO0FBQUEsUUFDVkMsU0FBUztBQUFBLFFBQ1RDLFlBQVk7QUFBQSxRQUNaQyxVQUFVO0FBQUEsUUFDVkMsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxnQkFBZ0I7QUFBQSxRQUNoQkMsdUJBQXVCO0FBQUEsUUFDdkJDLGNBQWM7QUFBQSxRQUNkQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEbEIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkUsVUFBVTtBQUFBLFFBQ1ZELFNBQVM7QUFBQSxRQUNURSxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QvQyxrQkFBWSxLQUFLO0FBQ2pCOEUsY0FBUUMsTUFBTSwyQ0FBMkNBLEtBQUs7QUFBQSxJQUNoRSxVQUFDO0FBQ0M1RCw0QkFBc0IsS0FBSztBQUMzQkYsa0JBQVksQ0FBQ3FJLFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQXlDQSxRQUFNcEgsc0JBQXNCLE9BQU9nRyxZQUFZO0FBQzdDLFFBQUk7QUFDRnBJLGlCQUFXLElBQUk7QUFDZmpCLHVCQUFpQixJQUFJO0FBQ3JCd0Msd0JBQWtCNkcsT0FBTztBQUN6Qm5LLG9CQUFjLElBQUk7QUFDbEIsWUFBTWtILFdBQVcsTUFBTTFKLElBQUkySjtBQUFBQSxRQUN6QixnREFBZ0RnRCxPQUFPO0FBQUEsTUFDekQ7QUFDQXBELGNBQVFzQyxLQUFLLHdCQUF3Qm5DLFNBQVNLLElBQUk7QUFDbER2RywwQkFBb0JrRyxTQUFTSyxJQUFJO0FBQUEsSUFDbkMsU0FBU1AsT0FBTztBQUNkRCxjQUFRQyxNQUFNLG1DQUFtQ0EsS0FBSztBQUFBLElBQ3hELFVBQUM7QUFDQ2pGLGlCQUFXLEtBQUs7QUFDaEIvQixvQkFBYyxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTXNFLHdCQUF3QixPQUFPNkYsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTWpELFdBQVcsTUFBTTFKLElBQUkySjtBQUFBQSxRQUN6QixnREFBZ0RnRCxPQUFPO0FBQUEsTUFDekQ7QUFDQXpKLDZCQUF1QndHLFNBQVNLLElBQUk7QUFDcEN2Qix3QkFBa0I7QUFBQSxRQUNoQlIsUUFBUTBCLFVBQVVLLE1BQU0vQjtBQUFBQSxRQUN4QkQsVUFBVTJCLFVBQVVLLE1BQU1oQyxTQUFTNUQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2pELENBQUM7QUFDRGEseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTd0UsT0FBTztBQUNkRCxjQUFRQyxNQUFNLHVDQUF1Q0EsS0FBSztBQUFBLElBQzVEO0FBQUEsRUFDRjtBQUNBLFFBQU0wRSxlQUFlLE9BQU9sSCxNQUFNO0FBQ2hDQSxNQUFFNkcsZUFBZTtBQUNqQixRQUFJO0FBQ0YsWUFBTTdOLElBQUltTztBQUFBQSxRQUNSLGtDQUFrQ2xMLG9CQUFvQnlELEdBQUc7QUFBQSxRQUN6RDZCO0FBQUFBLE1BQ0Y7QUFDQXZELHlCQUFtQixLQUFLO0FBRXhCb0MscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RFLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFNBQVNnQyxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JELFVBQ0VBLE1BQU1FLFlBQ05GLE1BQU1FLFNBQVNLLFFBQ2ZQLE1BQU1FLFNBQVNLLEtBQUt6QyxTQUNwQjtBQUNBRix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTLEdBQUdrQyxPQUFPRSxVQUFVSyxNQUFNekMsT0FBTztBQUFBLFVBQzFDRSxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xKLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNURSxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBSUEsUUFBTTBGLDJCQUEyQixPQUFPUCxZQUFZO0FBQ2xELFFBQUlBLFNBQVM7QUFDWCxVQUFJO0FBQ0YsY0FBTWpELFdBQVcsTUFBTTFKLElBQUlpTztBQUFBQSxVQUN6QixtQ0FBbUN0QixPQUFPO0FBQUEsUUFDNUM7QUFDQSxZQUFJakQsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNb0UsZ0JBQWdCMUUsU0FBU0ssS0FBS3NFO0FBQUFBLFlBQ2xDLENBQUNDLFlBQVlBLFFBQVFDLGNBQWNELFFBQVFDLFdBQVdqSTtBQUFBQSxVQUN4RDtBQUNBNUQsNkJBQW1CMEwsYUFBYTtBQUFBLFFBQ2xDLE9BQU87QUFDTDFMLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVM4RyxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RDlHLDJCQUFtQixFQUFFO0FBQUEsTUFDdkI7QUFBQSxJQUNGLE9BQU87QUFDTEEseUJBQW1CLEVBQUU7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNHaUQsK0JBQ0MsdUJBQUMsc0JBQW1CLE9BQU8saUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUQsSUFFekQsdUJBQUMsU0FDQyxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU13QixZQUFZSztBQUFBQSxRQUNsQixXQUFXTCxZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixVQUFVSCxZQUFZSTtBQUFBQTtBQUFBQSxNQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJaUM7QUFBQSxJQUVqQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNYLHVCQUFDLFFBQUcsV0FBVSwwQkFBeUIsZ0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxNQUN2RCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQWEsc0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osdUJBQXVCO0FBQUEsZ0JBQ3ZCO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLGNBQWMsQ0FBQ2lILE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU8zTSwwQkFBMEI2TTtBQUFBQSxnQkFDakMsVUFBVXpCO0FBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQXlCLE9BQU8sU0FBUyxnQ0FBdEIsTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDOUwsYUFBYTJJO0FBQUFBLG9CQUFJLENBQUM1RCxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUksS0FDekNKLGdCQUFNa0UsY0FEV2xFLE1BQU1JLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFzQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU01RCxhQUFhLElBQUk7QUFBQSxrQkFDaEMsV0FBVTtBQUFBLGtCQUF1RztBQUFBO0FBQUEsZ0JBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU1ZLG1CQUFtQixJQUFJO0FBQUEsa0JBQ3RDLFdBQVU7QUFBQSxrQkFBdUc7QUFBQTtBQUFBLGdCQUZuSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxlQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNDQTtBQUFBLGFBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQSxRQVlDL0IsaUJBQWlCQSxjQUFjcUksU0FBUyxJQUN2QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTXJJLGNBQWMwTTtBQUFBQSxjQUFPLENBQUNVLFNBQzFCMUMsT0FBT0ksT0FBT3NDLElBQUksRUFBRUM7QUFBQUEsZ0JBQUssQ0FBQy9ILFVBQ3hCZ0ksT0FBT2hJLEtBQUssRUFDVDJILFlBQVksRUFDWkMsU0FBU25LLFdBQVdrSyxZQUFZLENBQUM7QUFBQSxjQUN0QztBQUFBLFlBQ0Y7QUFBQSxZQUNBO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBa0I7QUFBQTtBQUFBLFVBVnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVU0QyxJQUc1Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxTQUNFak4sY0FBY3FJLFVBQVUsS0FBSy9IO0FBQUFBO0FBQUFBLFVBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtHLEtBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0E1RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThFQTtBQUFBLFNBakZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrRkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXWTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiYiw2QkFBbUIsRUFBRTtBQUNyQmMsdUJBQWEsS0FBSztBQUNsQjRFLG9CQUFVLENBQUMsQ0FBQztBQUNabEMsaUNBQXVCLEVBQUU7QUFBQSxRQUMzQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxxQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVW9JLGNBQWMsWUFBVSxNQWtFNUQ7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyw2RUFBNkUzTSxVQUFVaU8sTUFBTTtBQUFBLGtCQUN4RyxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsY0FBYyxDQUFDVixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPN00sbUJBQW1CK007QUFBQUEsa0JBQzFCLFVBQVUxQjtBQUFBQSxrQkFFVC9MLGlCQUFPNkk7QUFBQUEsb0JBQUksQ0FBQzVELFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1JLEtBQ3pDLGFBQUdKLE1BQU1nRSxTQUFTLE1BQU1oRSxNQUFNaUUsWUFBWSxNQUR6QmpFLE1BQU1JLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW1CQTtBQUFBLGNBRUNlLE9BQU93RSxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhFLGlCQUFPd0UsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0NBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQUs7QUFBQTtBQUFBLGdCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsSUFBRztBQUFBLGtCQUNILFdBQVU7QUFBQSxrQkFDVixVQUFVMEI7QUFBQUEsa0JBRVY7QUFBQSwyQ0FBQyxZQUFPLE9BQU0sSUFBRyw0Q0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkM7QUFBQSxvQkFDN0MsdUJBQUMsWUFBTyxPQUFNLFlBQVcsc0NBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStDO0FBQUEsb0JBQy9DLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHNDQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLG9CQUNoRCx1QkFBQyxZQUFPLE9BQU0sWUFBVyxxQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEM7QUFBQTtBQUFBO0FBQUEsZ0JBVGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVILHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osVUFBVW5CO0FBQUFBLGtCQUNWLE9BQU9qSDtBQUFBQSxrQkFDUCxXQUFVO0FBQUEsa0JBRVRvQztBQUFBQSw2QkFBU1UsWUFBWSxjQUNwQixtQ0FDRzVGLDBCQUFnQnlILElBQUksQ0FBQ2lGLE9BQU9oRixVQUFVO0FBQ3JDLDRCQUFNaUYsWUFDSkQsT0FBT1osWUFBWWpJLE9BQU9rRSxjQUMxQjtBQUNGLDRCQUFNbUMsVUFDSndDLE9BQU9aLFlBQVlqSSxPQUFPSSxPQUMxQixXQUFXeUQsS0FBSztBQUNsQiw0QkFBTU8sU0FDSnlFLE9BQU9aLFlBQVljLFdBQVc7QUFFaEMsNkJBQ0U7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFQyxPQUFPLFFBQVExQyxPQUFPLElBQUlqQyxNQUFNO0FBQUEsMEJBRS9CMEU7QUFBQUE7QUFBQUEsNEJBQVU7QUFBQSw0QkFBSTFFO0FBQUFBO0FBQUFBO0FBQUFBLHdCQUhWLFFBQVFpQyxPQUFPLElBQUlqQyxNQUFNO0FBQUEsd0JBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSixDQUFDLEtBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBb0JBO0FBQUEsb0JBRUQvQyxTQUFTVSxZQUFZLGVBQ3BCLG1DQUNHbEQsMEJBQWdCK0UsSUFBSSxDQUFDb0YsVUFBVTtBQUM5Qiw2QkFDRSx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFPLFNBQVNBLE1BQU01SSxHQUFHLElBQ3JDLGFBQUc0SSxNQUFNQyxRQUFRLFFBQVFELE1BQU1FLGNBQWMsTUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUVKLENBQUMsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVFBO0FBQUEsb0JBRUQ3SCxTQUFTVSxZQUFZLGNBQ3BCLG1DQUNHcEQscUJBQVdpRixJQUFJLENBQUN1RixhQUFhO0FBQzVCLDZCQUNFLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU8sUUFBUUEsU0FBUy9JLEdBQUcsSUFDdkMsa0JBQVErSSxTQUFTQyxPQUFPLFFBQVFELFNBQVNFLFdBQVcsTUFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUVKLENBQUMsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVFBO0FBQUE7QUFBQTtBQUFBLGdCQW5ESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FxREE7QUFBQSxjQUNDbEksT0FBT1UseUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVixpQkFBT1UseUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWhFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtFQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBZTtBQUFBO0FBQUEsZ0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxVQUFVLENBQUN2QjtBQUFBQSxrQkFDWCxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9lLFNBQVNJO0FBQUFBLGtCQUNoQixJQUFHO0FBQUEsa0JBQ0gsVUFBVXdFO0FBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRMkk7QUFBQSxjQUcxSTlFLE9BQU9NLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWTixpQkFBT00sWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWE7QUFBQTtBQUFBLHNCQUVkLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9KLFNBQVNLO0FBQUFBLG9CQUNoQixJQUFHO0FBQUEsb0JBQ0gsVUFBVXVFO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRMkksS0FUN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUVDOUUsT0FBT08sVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZQLGlCQUFPTyxVQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5QkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBVTtBQUFBO0FBQUEsa0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxJQUFHO0FBQUEsb0JBQ0gsV0FBVTtBQUFBLG9CQUNWLFVBQVV5RjtBQUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QjtBQUFBLHNCQUN6Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSxzQkFDN0IsdUJBQUMsWUFBTyxPQUFNLGVBQWMsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVDO0FBQUEsc0JBQ3ZDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFUbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVVBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsaUJBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU07QUFBQTtBQUFBLGdCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILE1BQUs7QUFBQSxrQkFDTCxNQUFNO0FBQUEsa0JBQ04sT0FBTzlGLFVBQVVXO0FBQUFBLGtCQUNqQixVQUFVaUU7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVE0RztBQUFBLGlCQWY5RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBQ0M1RSxTQUFTSyxVQUFVekMsb0JBQW9CeUUsU0FBUyxLQUMvQyx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsZ0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixPQUNFNEYsT0FBT2pJLFNBQVNLLE1BQU0sSUFBSXpDLG9CQUFvQnlFO0FBQUFBLGtCQUVoRCxVQUFRO0FBQUE7QUFBQSxnQkFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPVTtBQUFBLGlCQWZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFRGxHLGdCQUFnQixZQUNmLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBZ0I7QUFBQTtBQUFBLG9CQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxJQUFHO0FBQUEsa0JBQ0gsT0FBTzZELFNBQVNPO0FBQUFBLGtCQUNoQixVQUFVcUU7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU8ySTtBQUFBLGNBRTFJOUUsT0FBT1Msa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVCxpQkFBT1Msa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBRUYsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDMkc7QUFBQTtBQUFBLGNBSHZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBL1VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ1ZBO0FBQUEsYUFwVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFWQTtBQUFBO0FBQUEsTUE5VkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBK1ZBO0FBQUEsSUFJQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTTdFO0FBQUFBLFFBQ04sVUFBVSxNQUFNQyxpQkFBaUIsS0FBSztBQUFBLFFBQ3RDLFNBQVMsTUFBTUEsaUJBQWlCLEtBQUs7QUFBQSxRQUNyQyxNQUFNLE1BQU1BLGlCQUFpQixLQUFLO0FBQUEsUUFDbEMsVUFBVSxNQUFNcUQsb0JBQW9CZCxjQUFjO0FBQUEsUUFDbEQsUUFBUSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBSztBQUFBLFFBQ2IsU0FBU3REO0FBQUFBLFFBRVQ7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxjQUFVO0FBQUEsY0FDeEJnQixrQkFBa0JrSCxVQUFVRDtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyw0QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBLGNBQVU7QUFBQSxjQUM3QmpILGtCQUFrQmtILFVBQVVvRjtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyxrQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQVU7QUFBQSxjQUNuQ3RNLGtCQUFrQmtILFVBQVVxRjtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyxxQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsY0FBUztBQUFBLGNBQUV2TSxrQkFBa0JzRSxTQUFTeUM7QUFBQUEsY0FBVztBQUFBLGNBQUk7QUFBQSxjQUN2RC9HLGtCQUFrQm1IO0FBQUFBLGlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FBVTtBQUFBLGNBQzVCbkgsa0JBQWtCa0gsVUFBVW9GLGNBQzNCdE0sa0JBQWtCd00sYUFDaEJ4TSxrQkFBa0JrSCxVQUFVb0YsY0FDOUJ0TSxrQkFBa0J3TSxhQUNoQjtBQUFBLGlCQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sMkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFTO0FBQUEsY0FBRXhNLGtCQUFrQnlNO0FBQUFBLGlCQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLCtCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVCO0FBQUEsY0FBVTtBQUFBLGNBQ2hDek0sa0JBQWtCd007QUFBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8seUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQSxjQUFTO0FBQUEsY0FBRXhNLGtCQUFrQjBNO0FBQUFBLGlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLGtDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsY0FBVTtBQUFBLGNBQ25DMU0sa0JBQWtCMk07QUFBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sNkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUI7QUFBQSxjQUFTO0FBQUEsY0FBRTNNLGtCQUFrQjRNO0FBQUFBLGlCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDZCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCO0FBQUEsY0FBVTtBQUFBLGNBQzlCNU0sa0JBQWtCNk07QUFBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sMEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxjQUFTO0FBQUEsY0FBRTdNLGtCQUFrQjhNO0FBQUFBLGlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FBVTtBQUFBLGNBQzVCOU0sa0JBQWtCMEgsV0FBVzlHLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxpQkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQVU7QUFBQSxjQUM1Qlosa0JBQWtCK00sV0FBV25NLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxpQkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeURBO0FBQUE7QUFBQTtBQUFBLE1BckVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXNFQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdwQjtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkksMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxrREFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELGdCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUM2RCxNQUFNO0FBQ2ZBLGtCQUFFNkcsZUFBZTtBQUNqQjBDLG9DQUFvQjtBQUFBLGNBQ3RCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNpRztBQUFBO0FBQUEsZ0JBSDdHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUE7QUFBQSxZQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBO0FBQUEsYUFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBO0FBQUEsTUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNkJBO0FBQUEsT0F6aUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwaUJBLEtBM2lCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNGlCQSxLQWhqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtqQkE7QUFFSjtBQUFFblAsR0FqNUNJRCxpQkFBZTtBQUFBcVAsS0FBZnJQO0FBbTVDTixlQUFlQTtBQUFnQixJQUFBcVA7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsImFwaSIsIk1vZGFsIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJDaXJjdWxhckxvYWRlciIsIkZhV2hhdHNhcHBTcXVhcmUiLCJOYXZiYXIiLCJTZWxlY3QiLCJEcm9wZG93biIsIkFudE1vZGFsIiwiRHJhd2VyIiwiVG9vbHRpcCIsIklvTWRNb3JlIiwiTGluayIsImRhdGFQYXltZW50c0ZvciIsIkJhY2tkcm9wQmx1ckxvYWRlciIsIkZhUmVjZWlwdCIsImZpZWxkU2l6ZSIsIkJyZWFkY3J1bWIiLCJSZWdpc3RyYXRpb25GZWUiLCJfcyIsImdyb3VwcyIsInNldEdyb3VwcyIsImFjdHVhbEdyb3VwcyIsInNldEFjdHVhbEdyb3VwcyIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwiVGFibGVQYXltZW50cyIsInNldFRhYmxlUGF5bWVudHMiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cCIsInNldFNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2VsZWN0ZWRHcm91cElkIiwic2V0U2VsZWN0ZWRHcm91cElkIiwic2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsInNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQiLCJmaWx0ZXJlZFVzZXJzIiwic2V0RmlsdGVyZWRVc2VycyIsInVzZXJOYW1lIiwic2V0VXNlck5hbWUiLCJ2aWV3TG9hZGVyIiwic2V0Vmlld0xvYWRlciIsImZpbHRlcmVkQXVjdGlvbiIsInNldEZpbHRlcmVkQXVjdGlvbiIsImdyb3VwSW5mbyIsInNldEdyb3VwSW5mbyIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsImN1cnJlbnRVcGRhdGVBbW91bnQiLCJzZXRDdXJyZW50VXBkYXRlQW1vdW50IiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwic2hvd01vZGFsVmlldyIsInNldFNob3dNb2RhbFZpZXciLCJjdXJyZW50Vmlld0dyb3VwIiwic2V0Q3VycmVudFZpZXdHcm91cCIsInNob3dVcGxvYWRNb2RhbCIsInNldFNob3dVcGxvYWRNb2RhbCIsInJlY2VpcHRObyIsInNldFJlY2VpcHRObyIsIndoYXRzYXBwRW5hYmxlIiwicGF5bWVudE1vZGUiLCJzZXRQYXltZW50TW9kZSIsInRvZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImRpc2FibGVkIiwic2V0RGlzYWJsZWQiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInBheW1lbnRGb3IiLCJzZXRQYXltZW50Rm9yIiwidHlwZUNoaXQiLCJzaG93VXBkYXRlTW9kYWwiLCJzZXRTaG93VXBkYXRlTW9kYWwiLCJib3Jyb3dlcnMiLCJzZXRCb3Jyb3dlcnMiLCJwaWdtZUN1c3RvbWVycyIsInNldFBpZ21lQ3VzdG9tZXJzIiwiZW5hYmxlR3JvdXBDb2x1bW4iLCJzZXRFbmFibGVHcm91cENvbHVtbiIsInBheW1lbnRHcm91cFRpY2tldHMiLCJzZXRQYXltZW50R3JvdXBUaWNrZXRzIiwicmVuZGVyIiwic2V0UmVyZW5kZXIiLCJvcGVuQmFja2Ryb3BMb2FkZXIiLCJzZXRPcGVuQmFja2Ryb3BMb2FkZXIiLCJjdXJyZW50R3JvdXBJZCIsInNldEN1cnJlbnRHcm91cElkIiwib3BlbkFudEREcmF3ZXIiLCJzZXRPcGVuQW50RERyYXdlciIsInNob3dMb2FkZXIiLCJzZXRTaG93TG9hZGVyIiwibGFzdFRocmVlUGF5bWVudHMiLCJzZXRMYXN0VGhyZWVQYXltZW50cyIsImRyb3BEb3duSXRlbXMiLCJncm91cCIsImRyb3BEb3duSXRlbUxpc3QiLCJrZXkiLCJsYWJlbCIsIl9pZCIsImhhbmRsZVZpZXdNb2RhbE9wZW4iLCJtb2RpZnlQYXltZW50IiwicHVzaCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsIm5vUmVsb2FkIiwidHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ1c2VyX2lkIiwicmVjZWlwdF9ubyIsInBheV9kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsInBheW1lbnRfZ3JvdXBfdGlja2V0cyIsImFjY291bnRfdHlwZSIsInBheV9mb3IiLCJub3RlIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsInNldE1vZGlmeVBheW1lbnQiLCJoYW5kbGVVcGxvYWRNb2RhbENsb3NlIiwidXNlciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyT2JqIiwiSlNPTiIsInBhcnNlIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiaXNNb2RpZnkiLCJ1c3IiLCJhZG1pbl90eXBlIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hUb2RheXNQYXltZW50cyIsInJlc3BvbnNlIiwiZ2V0IiwicGFyYW1zIiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsImRhdGEiLCJsZW5ndGgiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiaW5kZXgiLCJpZCIsIm5hbWUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF9uYW1lIiwiZ3JvdXBfaWQiLCJ0aWNrZXQiLCJyZWNlaXB0Iiwib2xkX3JlY2VpcHQiLCJvbGRfcmVjZWlwdF9ubyIsImRhdGUiLCJmb3JtYXRQYXlEYXRlIiwidHJhbnNhY3Rpb25fZGF0ZSIsImNyZWF0ZWRBdCIsImNvbGxlY3RlZF9ieSIsImFkbWluX25hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscyIsInN0YXR1cyIsIkVycm9yIiwiZXJyIiwibG9nIiwiZmV0Y2hHcm91cHMiLCJmZXRjaFJlY2VpcHQiLCJpbmZvIiwicHJldkRhdGEiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJjdXN0b21lciIsInBhcnNlRmxvYXQiLCJpc05hTiIsInRyaW0iLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlQ2hhbmdlIiwiaGFuZGxlUGF5bWVudEFudFNlbGVjdCIsInZhbHVlcyIsImhhbmRsZUdyb3VwQ2hhbmdlIiwiZ3JvdXBJZCIsIm9uQ2hvb3NlUGF5bWVudEZvciIsImNvbHVtbnMiLCJoZWFkZXIiLCJoYW5kbGVHcm91cCIsImV2ZW50IiwicHJldkZvcm1EYXRhIiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVDdXN0b21lciIsImhhbmRsZUdyb3VwUGF5bWVudCIsImhhbmRsZUdyb3VwUGF5bWVudENoYW5nZSIsImRhdGVTdHJpbmciLCJ1cmwiLCJoYW5kbGVQYXltZW50TW9kZUNoYW5nZSIsInNlbGVjdGVkTW9kZSIsImhhbmRsZVBheW1lbnRGb3IiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWQiLCJwcmV2IiwicGF5bG9hZCIsInBvc3QiLCJoYW5kbGVVcGRhdGUiLCJwdXQiLCJ2YWxpZEF1Y3Rpb25zIiwiZmlsdGVyIiwiYXVjdGlvbiIsImVucm9sbG1lbnQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwiaXRlbSIsInNvbWUiLCJTdHJpbmciLCJoZWlnaHQiLCJlbnRyeSIsImdyb3VwTmFtZSIsInRpY2tldHMiLCJwaWdtZSIsInBpZ21lX2lkIiwicGF5YWJsZV9hbW91bnQiLCJib3Jyb3dlciIsImxvYW5faWQiLCJsb2FuX2Ftb3VudCIsIk51bWJlciIsImdyb3VwX3ZhbHVlIiwiZ3JvdXBfaW5zdGFsbCIsIndpbl9hbW91bnQiLCJjb21taXNzaW9uIiwiZGl2aWRlbnQiLCJkaXZpZGVudF9oZWFkIiwicGF5YWJsZSIsImF1Y3Rpb25fZGF0ZSIsIm5leHRfZGF0ZSIsInVwZGF0ZWRBdCIsImhhbmRsZURlbGV0ZUF1Y3Rpb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZWdpc3RyYXRpb25GZWVzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHBTcXVhcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERyb3Bkb3duLCBNb2RhbCBhcyBBbnRNb2RhbCwgRHJhd2VyLCBUb29sdGlwIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBkYXRhUGF5bWVudHNGb3IgZnJvbSBcIi4uL2RhdGEvcGF5bWVudHNGb3JcIjtcclxuaW1wb3J0IEJhY2tkcm9wQmx1ckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0JhY2tkcm9wQmx1ckxvYWRlclwiO1xyXG5pbXBvcnQgeyBGYVJlY2VpcHQgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuY29uc3QgUmVnaXN0cmF0aW9uRmVlID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FjdHVhbEdyb3Vwcywgc2V0QWN0dWFsR3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbVGFibGVQYXltZW50cywgc2V0VGFibGVQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkQXVjdGlvbkdyb3VwLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cElkLCBzZXRTZWxlY3RlZEdyb3VwSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQXVjdGlvbkdyb3VwSWQsIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1c2VyTmFtZSwgc2V0VXNlck5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3ZpZXdMb2FkZXIsIHNldFZpZXdMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZEF1Y3Rpb24sIHNldEZpbHRlcmVkQXVjdGlvbl0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3VwSW5mbywgc2V0R3JvdXBJbmZvXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlQW1vdW50LCBzZXRDdXJyZW50VXBkYXRlQW1vdW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAvL2NvbnN0IFtzaG93TW9kYWxWaWV3LCBzZXRTaG93TW9kZWxWaWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFZpZXcsIHNldFNob3dNb2RhbFZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Vmlld0dyb3VwLCBzZXRDdXJyZW50Vmlld0dyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93VXBsb2FkTW9kYWwsIHNldFNob3dVcGxvYWRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlY2VpcHRObywgc2V0UmVjZWlwdE5vXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IHdoYXRzYXBwRW5hYmxlID0gdHJ1ZTtcclxuICBjb25zdCBbcGF5bWVudE1vZGUsIHNldFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlKFwiY2FzaFwiKTtcclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Rpc2FibGVkLCBzZXREaXNhYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3BheW1lbnRGb3IsIHNldFBheW1lbnRGb3JdID0gdXNlU3RhdGUoZGF0YVBheW1lbnRzRm9yLnR5cGVDaGl0KTtcclxuICBjb25zdCBbc2hvd1VwZGF0ZU1vZGFsLCBzZXRTaG93VXBkYXRlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtib3Jyb3dlcnMsIHNldEJvcnJvd2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BpZ21lQ3VzdG9tZXJzLCBzZXRQaWdtZUN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VuYWJsZUdyb3VwQ29sdW1uLCBzZXRFbmFibGVHcm91cENvbHVtbl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbcGF5bWVudEdyb3VwVGlja2V0cywgc2V0UGF5bWVudEdyb3VwVGlja2V0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3JlbmRlciwgc2V0UmVyZW5kZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW29wZW5CYWNrZHJvcExvYWRlciwgc2V0T3BlbkJhY2tkcm9wTG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwSWQsIHNldEN1cnJlbnRHcm91cElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtvcGVuQW50RERyYXdlciwgc2V0T3BlbkFudEREcmF3ZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TG9hZGVyLCBzZXRTaG93TG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbGFzdFRocmVlUGF5bWVudHMsIHNldExhc3RUaHJlZVBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3QgZHJvcERvd25JdGVtcyA9IChncm91cCkgPT4ge1xyXG4gICAgY29uc3QgZHJvcERvd25JdGVtTGlzdCA9IFtcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIDxMaW5rIHRvPXtgL3JlZy1mZWUtcHJpbnQvJHtncm91cC5faWR9YH0gY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIFwiPlxyXG4gICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICksXHJcbiAgICAgIH0sXHJcbiAgICAgIC8vICAge1xyXG4gICAgICAvLyAgICAga2V5OiBcIjJcIixcclxuICAgICAgLy8gICAgIGxhYmVsOiAoXHJcbiAgICAgIC8vICAgICAgIDxkaXZcclxuICAgICAgLy8gICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgXCJcclxuICAgICAgLy8gICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgLy8gICAgICAgPlxyXG4gICAgICAvLyAgICAgICAgIERlbGV0ZVxyXG4gICAgICAvLyAgICAgICA8L2Rpdj5cclxuICAgICAgLy8gICAgICksXHJcbiAgICAgIC8vICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmlld01vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuICAgIGlmIChtb2RpZnlQYXltZW50KSB7XHJcbiAgICAgIGRyb3BEb3duSXRlbUxpc3QucHVzaCh7XHJcbiAgICAgICAga2V5OiBcIjRcIixcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFVwZGF0ZSBBbW91bnRcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGRyb3BEb3duSXRlbUxpc3Q7XHJcbiAgfTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgbm9SZWxvYWQ6IGZhbHNlLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgIHBheV9kYXRlOiB0b2RheSxcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgIGFjY291bnRfdHlwZTogXCJcIixcclxuICAgIHBheV9mb3I6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgLy8gY29uc3QgW3Nob3dQcmludE1vZGFsLCBzZXRTaG93UHJpbnRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW21vZGlmeVBheW1lbnQsIHNldE1vZGlmeVBheW1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGxvYWRNb2RhbENsb3NlID0gKCkgPT4ge1xyXG4gICAgc2V0U2hvd1VwbG9hZE1vZGFsKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgdXNlck9iaiAmJlxyXG4gICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnRcclxuICAgICkge1xyXG4gICAgICBjb25zdCBpc01vZGlmeSA9XHJcbiAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PVxyXG4gICAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0TW9kaWZ5UGF5bWVudChpc01vZGlmeSk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c3IgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgYWRtaW5fdHlwZSA9IG51bGw7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKHVzcikge1xyXG4gICAgICAgIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSB1c2VyIGZyb20gbG9jYWxTdG9yYWdlOlwiLCBlKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBmZXRjaFRvZGF5c1BheW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldFRhYmxlUGF5bWVudHMoW10pO1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvcmVnaXN0cmF0aW9uLWZlZS9nZXQtcmVnLWZlZS1ieS1kYXRlc1wiLCB7XHJcbiAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgZnJvbV9kYXRlOiB0b2RheSxcclxuICAgICAgICAgICAgdG9fZGF0ZTogdG9kYXksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIC8vaWYgKCFncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUpIHJldHVybiB7fTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAvLyAgIGdyb3VwX25hbWU6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSA/IGAke2dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZX1gOlxyXG4gICAgICAgICAgICAgIC8vICAgICBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgPyBgJHtncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9YDogXCJOL0FcIixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgZ3JvdXA/LnBheV9mb3IgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICB0aWNrZXQ6IGdyb3VwLnRpY2tldCxcclxuICAgICAgICAgICAgICByZWNlaXB0OiBncm91cC5yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIG9sZF9yZWNlaXB0OiBncm91cC5vbGRfcmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgICBhbW91bnQ6IGdyb3VwLmFtb3VudCxcclxuICAgICAgICAgICAgICBkYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLnBheV9kYXRlKSxcclxuICAgICAgICAgICAgICBwYXlfZm9yOiBncm91cD8ucGF5X2ZvcixcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLmNyZWF0ZWRBdCksXHJcbiAgICAgICAgICAgICAgbm90ZTogZ3JvdXA/Lm5vdGUsXHJcbiAgICAgICAgICAgICAgY29sbGVjdGVkX2J5OlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmNvbGxlY3RlZF9ieT8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHxcclxuICAgICAgICAgICAgICAgIFwiU3VwZXIgQWRtaW5cIixcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZHJvcERvd25JdGVtcyhncm91cCksXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICAgIHNldEVuYWJsZUdyb3VwQ29sdW1uKHRydWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoVG9kYXlzUGF5bWVudHMoKTtcclxuICB9LCBbcmVuZGVyXSk7XHJcblxyXG4gIC8vICAgY29uc3QgZmV0Y2hMYXN0VGhyZWVUcmFuc2FjdGlvbnMgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAvLyAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAvLyAgICAgc2V0T3BlbkFudEREcmF3ZXIodHJ1ZSk7XHJcbiAgLy8gICAgIGlmIChmb3JtRGF0YS51c2VyX2lkICYmIGZvcm1EYXRhLnBheW1lbnRfZ3JvdXBfdGlja2V0cykge1xyXG4gIC8vICAgICAgIHRyeSB7XHJcbiAgLy8gICAgICAgICBzZXRTaG93TG9hZGVyKHRydWUpO1xyXG4gIC8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwicGF5bWVudC9nZXQtbGFzdC1uLXRyYW5zYWN0aW9uXCIsIHtcclxuICAvLyAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgLy8gICAgICAgICAgICAgdXNlcl9pZDogZm9ybURhdGEudXNlcl9pZCxcclxuICAvLyAgICAgICAgICAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IHBheW1lbnRHcm91cFRpY2tldHMsXHJcbiAgLy8gICAgICAgICAgICAgbGltaXQ6IDMsXHJcbiAgLy8gICAgICAgICAgIH0sXHJcbiAgLy8gICAgICAgICB9KTtcclxuICAvLyAgICAgICAgIGlmIChyZXNwb25zZT8uZGF0YSkge1xyXG4gIC8vICAgICAgICAgICBzZXRMYXN0VGhyZWVQYXltZW50cyhyZXNwb25zZS5kYXRhKTtcclxuICAvLyAgICAgICAgIH0gZWxzZSB7XHJcbiAgLy8gICAgICAgICAgIHNldExhc3RUaHJlZVBheW1lbnRzKFtdKTtcclxuICAvLyAgICAgICAgIH1cclxuICAvLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICAgICAgc2V0TGFzdFRocmVlUGF5bWVudHMoW10pO1xyXG4gIC8vICAgICAgIH0gZmluYWxseSB7XHJcbiAgLy8gICAgICAgICBzZXRTaG93TG9hZGVyKGZhbHNlKTtcclxuICAvLyAgICAgICB9XHJcbiAgLy8gICAgIH1cclxuICAvLyAgIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRCb3Jyb3dlcnMoW10pO1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvbG9hbnMvZ2V0LWJvcnJvd2VyLWJ5LXVzZXItaWQvJHtzZWxlY3RlZEdyb3VwSWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApXHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJmZXRjaGluZyBsb2FuIGJvcnJvd2VycyBGYWlsZWRcIik7XHJcbiAgICAgICAgc2V0Qm9ycm93ZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIE9jY3VycmVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscygpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwSWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL3BpZ21lL2dldC1waWdtZS1jdXN0b21lci1ieS11c2VyLWlkLyR7c2VsZWN0ZWRHcm91cElkfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKVxyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiZmV0Y2hpbmcgcGlnbWUgY3VzdG9tZXJzIEZhaWxlZFwiKTtcclxuICAgICAgICBzZXRQaWdtZUN1c3RvbWVycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXHJcbiAgICAgICAgICBcIkVycm9yIE9jY3VycmVkIHdoaWxlIGZldGNoaW5nIHBpZ21lIGN1c3RvbWVycyxcIixcclxuICAgICAgICAgIGVyci5tZXNzYWdlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRHcm91cElkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW2FsZXJ0Q29uZmlnXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICAgIHNldEFjdHVhbEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbYWxlcnRDb25maWddKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUmVjZWlwdCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvcmVnaXN0cmF0aW9uLWZlZS9nZXQtZmVlLWxhdGVzdC1yZWNlaXB0XCIpO1xyXG4gICAgICAgIGNvbnNvbGUuaW5mbyhcInRlc3RpbmdcIiwgcmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgc2V0UmVjZWlwdE5vKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZWNlaXB0IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoUmVjZWlwdCgpO1xyXG4gIH0sIFthbGVydENvbmZpZ10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHJlY2VpcHRObykge1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgcmVjZWlwdF9ubzogcmVjZWlwdE5vLnJlY2VpcHRfbm8sXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9LCBbcmVjZWlwdE5vXSk7XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG5cclxuICAgIGlmICghc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5jdXN0b21lciA9IFwiUGxlYXNlIHNlbGVjdCBhIGN1c3RvbWVyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXltZW50X2dyb3VwX3RpY2tldHMpIHtcclxuICAgICAgbmV3RXJyb3JzLnBheW1lbnRfZ3JvdXBfdGlja2V0cyA9IFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwIGFuZCB0aWNrZXRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWZvcm1EYXRhLnBheV9kYXRlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYXlfZGF0ZSA9IFwiUGF5bWVudCBkYXRlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWZvcm1EYXRhLnBheV9mb3IpIHtcclxuICAgICAgbmV3RXJyb3JzLnBheV9mb3IgPSBcIlJlZ2lzdHJhdGlvbiBUeXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYW1vdW50ID0gcGFyc2VGbG9hdChmb3JtRGF0YS5hbW91bnQpO1xyXG4gICAgaWYgKGlzTmFOKGFtb3VudCkgfHwgYW1vdW50IDw9IDApIHtcclxuICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgcG9zaXRpdmUgYW1vdW50XCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHBheW1lbnRNb2RlID09PSBcIm9ubGluZVwiICYmICFmb3JtRGF0YS50cmFuc2FjdGlvbl9pZD8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy50cmFuc2FjdGlvbl9pZCA9XHJcbiAgICAgICAgXCJUcmFuc2FjdGlvbiBJRCBpcyByZXF1aXJlZCBmb3Igb25saW5lIHBheW1lbnRzXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudEFudFNlbGVjdCA9ICh2YWx1ZXMpID0+IHtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHModmFsdWVzKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwKGdyb3VwSWQpO1xyXG5cclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2dldC1ncm91cC1lbnJvbGwvJHtncm91cElkfWApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25DaG9vc2VQYXltZW50Rm9yID0gKGUpID0+IHtcclxuICAgIHNldFBheW1lbnRGb3IoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gIF07XHJcbiAgaWYgKGVuYWJsZUdyb3VwQ29sdW1uKSB7XHJcbiAgICBjb2x1bW5zLnB1c2goeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0pO1xyXG4gIH1cclxuICBjb2x1bW5zLnB1c2goXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwib2xkX3JlY2VpcHRcIiwgaGVhZGVyOiBcIk9sZCBSZWNlaXB0XCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRcIiwgaGVhZGVyOiBcIlJlY2VpcHRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X2ZvclwiLCBoZWFkZXI6IFwiUmVnaXN0cmF0aW9uIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiUmVtYXJrc1wiIH0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0ZWRfYnlcIiwgaGVhZGVyOiBcIkNvbGxlY3RlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH1cclxuICApO1xyXG4gIGNvbnN0IGhhbmRsZUdyb3VwID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBjb25zdCBncm91cElkID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZGb3JtRGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkZvcm1EYXRhLFxyXG4gICAgICB1c2VyX2lkOiBncm91cElkLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RGF0YSkgPT4gKHsgLi4ucHJldkRhdGEsIGN1c3RvbWVyOiBcIlwiIH0pKTtcclxuXHJcbiAgICBoYW5kbGVHcm91cENoYW5nZShncm91cElkKTtcclxuICAgIGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZShncm91cElkKTtcclxuXHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2dyb3VwL2dldC1ieS1pZC1ncm91cC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgICAgc2V0R3JvdXBJbmZvKHJlc3BvbnNlLmRhdGEgfHwge30pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldEdyb3VwSW5mbyh7fSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEdyb3VwSW5mbyh7fSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUN1c3RvbWVyID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBJZChncm91cElkKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2Rm9ybURhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZGb3JtRGF0YSxcclxuICAgICAgdXNlcl9pZDogZ3JvdXBJZCxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBjdXN0b21lcjogXCJcIiB9KSk7XHJcbiAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgIGhhbmRsZUdyb3VwQ2hhbmdlKGdyb3VwSWQpO1xyXG4gICAgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlKGdyb3VwSWQpO1xyXG5cclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgICBzZXRHcm91cEluZm8ocmVzcG9uc2UuZGF0YSB8fCB7fSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgc2V0R3JvdXBJbmZvKHt9KTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0R3JvdXBJbmZvKHt9KTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZUdyb3VwUGF5bWVudCA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkKGdyb3VwSWQpO1xyXG4gICAgaGFuZGxlR3JvdXBQYXltZW50Q2hhbmdlKGdyb3VwSWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdFBheURhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgcmV0dXJuIGRhdGVTdHJpbmc/LnNwbGl0KFwiVFwiKVswXTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cFBheW1lbnRDaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXAoZ3JvdXBJZCk7XHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICBsZXQgdXJsO1xyXG4gICAgICBpZiAoZ3JvdXBJZCA9PT0gXCJ0b2RheVwiKSB7XHJcbiAgICAgICAgdXJsID0gYC9yZWdpc3RyYXRpb24tZmVlL2dldC1yZWctZmVlLWJ5LWRhdGVzP2Zyb21fZGF0ZT0ke3RvZGF5fSZ0b19kYXRlPSR7dG9kYXl9YDtcclxuICAgICAgICBzZXRFbmFibGVHcm91cENvbHVtbih0cnVlKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB1cmwgPSBgL3JlZ2lzdHJhdGlvbi1mZWUvZ2V0LXJlZ2lzdHJhdGlvbi1ncm91cC1mZWUtYnktaWQvJHtncm91cElkfWA7XHJcbiAgICAgICAgc2V0RW5hYmxlR3JvdXBDb2x1bW4oZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0VGFibGVQYXltZW50cyhbXSk7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBheV9mb3I6IGdyb3VwPy5wYXlfZm9yLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogZ3JvdXAucmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgICBvbGRfcmVjZWlwdDogZ3JvdXAub2xkX3JlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBncm91cC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgZGF0ZTogZ3JvdXA/LnBheV9kYXRlLnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgICBub3RlOiBncm91cD8ubm90ZSxcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBncm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICAgICAgY29sbGVjdGVkX2J5OlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmNvbGxlY3RlZF9ieT8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHxcclxuICAgICAgICAgICAgICAgIFwiU3VwZXIgQWRtaW5cIixcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZHJvcERvd25JdGVtcyhncm91cCksXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vZGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFBheW1lbnRNb2RlKHNlbGVjdGVkTW9kZSk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBwYXlfdHlwZTogc2VsZWN0ZWRNb2RlLFxyXG5cclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IHNlbGVjdGVkTW9kZSA9PT0gXCJvbmxpbmVcIiA/IHByZXZEYXRhLnRyYW5zYWN0aW9uX2lkIDogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRGb3IgPSAoZSkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRNb2RlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBwYXlfZm9yOiBzZWxlY3RlZE1vZGUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuICAvLyAgIGNvbnN0IGNyZWF0ZVJlY2VpcHQgPSBhc3luYyAoZm9ybURhdGEpID0+IHtcclxuICAvLyAgICAgdHJ5IHtcclxuICAvLyAgICAgICBjb25zdCB7XHJcbiAgLy8gICAgICAgICBncm91cF9pZCxcclxuICAvLyAgICAgICAgIHVzZXJfaWQsXHJcbiAgLy8gICAgICAgICB0aWNrZXQsXHJcbiAgLy8gICAgICAgICByZWNlaXB0X25vLFxyXG4gIC8vICAgICAgICAgcGF5X2RhdGUsXHJcbiAgLy8gICAgICAgICBhbW91bnQsXHJcbiAgLy8gICAgICAgICBwYXlfdHlwZSxcclxuICAvLyAgICAgICAgIHRyYW5zYWN0aW9uX2lkLFxyXG4gIC8vICAgICAgIH0gPSBmb3JtRGF0YTtcclxuXHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2VVc2VyID0gYXdhaXQgYXBpLmdldChgdXNlci9nZXQtdXNlci1ieS1pZC8ke3VzZXJfaWR9YCk7XHJcblxyXG4gIC8vICAgICAgIGNvbnN0IHJlc3BvbnNlR3JvdXAgPSBhd2FpdCBhcGkuZ2V0KGBncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtncm91cF9pZH1gKTtcclxuXHJcbiAgLy8gICAgICAgaWYgKHJlc3BvbnNlVXNlci5zdGF0dXMgPT09IDIwMCAmJiByZXNwb25zZUdyb3VwLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgLy8gICAgICAgICBjb25zdCBjdXN0b21lck5hbWUgPSByZXNwb25zZVVzZXI/LmRhdGE/LmZ1bGxfbmFtZTtcclxuICAvLyAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IHJlc3BvbnNlR3JvdXA/LmRhdGE/Lmdyb3VwX25hbWU7XHJcbiAgLy8gICAgICAgICBpZiAoY3VzdG9tZXJOYW1lICYmIGdyb3VwTmFtZSkge1xyXG4gIC8vICAgICAgICAgICBzZXRQcmludERldGFpbHMoKHByZXYpID0+ICh7XHJcbiAgLy8gICAgICAgICAgICAgLi4ucHJldixcclxuICAvLyAgICAgICAgICAgICBjdXN0b21lck5hbWUsXHJcbiAgLy8gICAgICAgICAgICAgZ3JvdXBOYW1lLFxyXG4gIC8vICAgICAgICAgICAgIHRpY2tldE51bWJlcjogdGlja2V0LFxyXG4gIC8vICAgICAgICAgICAgIHJlY2VpcHROdW1iZXI6IHJlY2VpcHRfbm8sXHJcbiAgLy8gICAgICAgICAgICAgcGF5bWVudERhdGU6IHBheV9kYXRlLFxyXG4gIC8vICAgICAgICAgICAgIHBheW1lbnRNb2RlOiBwYXlfdHlwZSxcclxuICAvLyAgICAgICAgICAgICB0cmFuc2FjdGlvbklkOiBwYXlfdHlwZSA9PT0gXCJjYXNoXCIgPyBcIlwiIDogdHJhbnNhY3Rpb25faWQsXHJcbiAgLy8gICAgICAgICAgICAgYW1vdW50LFxyXG4gIC8vICAgICAgICAgICB9KSk7XHJcbiAgLy8gICAgICAgICAgIC8vIHNldFNob3dQcmludE1vZGFsKHRydWUpO1xyXG4gIC8vICAgICAgICAgfVxyXG4gIC8vICAgICAgIH1cclxuICAvLyAgICAgICBpZiAocmVzcG9uc2VVc2VyLnN0YXR1cyA+PSA0MDAgfHwgcmVzcG9uc2VHcm91cC5zdGF0dXMgPj0gNDAwKSB7XHJcbiAgLy8gICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgLy8gICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgLy8gICAgICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gIC8vICAgICAgICAgICBtZXNzYWdlOiBgRXJyb3IgQ3JlYXRpbmcgUmVjZWlwdGAsXHJcbiAgLy8gICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAvLyAgICAgICAgIH0pO1xyXG4gIC8vICAgICAgIH1cclxuICAvLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgLy8gICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gIC8vICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAvLyAgICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gIC8vICAgICAgICAgbWVzc2FnZTogYEVycm9yIENyZWF0aW5nIFJlY2VpcHRgLFxyXG4gIC8vICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gIC8vICAgICAgIH0pO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgICBzZXREaXNhYmxlZCh0cnVlKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBsZXQgcGF5bG9hZDtcclxuICAgICAgICBjb25zdCB1c3IgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgICAgbGV0IGFkbWluX3R5cGUgPSBudWxsO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBpZiAodXNyKSB7XHJcbiAgICAgICAgICAgIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSB1c2VyIGZyb20gbG9jYWxTdG9yYWdlOlwiLCBlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvcm1EYXRhLnBheW1lbnRfZ3JvdXBfdGlja2V0cyA9IHBheW1lbnRHcm91cFRpY2tldHM7XHJcbiAgICAgICAgZm9ybURhdGEuYWRtaW5fdHlwZSA9IGFkbWluX3R5cGU/Ll9pZDtcclxuICAgICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgIFwiL3JlZ2lzdHJhdGlvbi1mZWUvYWRkLW11bHRpcGxlLXJlZ2lzdHJhdGlvbi1mZWVcIixcclxuICAgICAgICAgIGZvcm1EYXRhXHJcbiAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDEpIHtcclxuICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAvLyByZWNlaXB0X25vOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICAgICAgYWNjb3VudF90eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZm9yOiBcIlwiLFxyXG4gICAgICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcInJlZ2lzdHJhdGlvbiBmZWUgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCkge1xyXG4gICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAvLyByZWNlaXB0X25vOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICAgICAgYWNjb3VudF90eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZm9yOiBcIlwiLFxyXG4gICAgICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcInJlZ2lzdHJhdGlvbiBmZWUgQWRkZWQgRmFpbGVkXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKFwiXCIpO1xyXG4gICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICByZWNlaXB0X25vOiBcIlwiLFxyXG4gICAgICAgIHBheV9kYXRlOiBcIlwiLFxyXG4gICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICBhY2NvdW50X3R5cGU6IFwiXCIsXHJcbiAgICAgICAgcGF5X2ZvcjogXCJcIixcclxuICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogYEVycm9yIHN1Ym1pdHRpbmcgcmVnaXN0cmF0aW9uIGZlZSBkYXRhYCxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXREaXNhYmxlZChmYWxzZSk7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzdWJtaXR0aW5nIHJlZ2lzdHJhdGlvbiBmZWUgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKGZhbHNlKTtcclxuICAgICAgc2V0UmVyZW5kZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyAgIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgLy8gICAgIHRyeSB7XHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtcGF5bWVudC1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgLy8gICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gIC8vICAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsOlwiLCBlcnJvcik7XHJcbiAgLy8gICAgIH1cclxuICAvLyAgIH07XHJcblxyXG4gIC8vIGNvbnN0IGhhbmRsZVZpZXdNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gIC8vICAgdHJ5IHtcclxuICAvLyAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtcGF5bWVudC1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgLy8gICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAvLyAgICAgc2V0U2hvd01vZGVsVmlldyh0cnVlKTtcclxuXHJcbiAgLy8gICB9Y2F0Y2ggKGVycm9yKSB7XHJcbiAgLy8gICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB2aWV3IFBheW1lbnQgRGV0YWlsczpcIiwgZXJyb3IpO1xyXG4gIC8vIH1cclxuXHJcbiAgLy8gICBjb25zdCBoYW5kbGVEZWxldGVBdWN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gIC8vICAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgLy8gICAgICAgdHJ5IHtcclxuICAvLyAgICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9wYXltZW50L2RlbGV0ZS1wYXltZW50LyR7Y3VycmVudEdyb3VwLl9pZH1gKTtcclxuXHJcbiAgLy8gICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gIC8vICAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gIC8vICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gIC8vICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gIC8vICAgICAgICAgICBtZXNzYWdlOiBcIlBheW1lbnQgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAvLyAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgLy8gICAgICAgICB9KTtcclxuICAvLyAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcclxuICAvLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gIC8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGF1Y3Rpb246XCIsIGVycm9yKTtcclxuICAvLyAgICAgICB9XHJcbiAgLy8gICAgIH1cclxuICAvLyAgIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVZpZXdNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0U2hvd01vZGFsVmlldyh0cnVlKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICAgIHNldFZpZXdMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3JlZ2lzdHJhdGlvbi1mZWUvZ2V0LXJlZ2lzdHJhdGlvbi1mZWUtYnktaWQvJHtncm91cElkfWBcclxuICAgICAgKTtcclxuICAgICAgY29uc29sZS5pbmZvKFwicmVnaXN0cmF0aW9uIHRlc3RpbmdcIiwgcmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldEN1cnJlbnRWaWV3R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igdmlld2luZyByZWdpc3RyYXRpb24tZmVlOlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0Vmlld0xvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3JlZ2lzdHJhdGlvbi1mZWUvZ2V0LXJlZ2lzdHJhdGlvbi1mZWUtYnktaWQvJHtncm91cElkfWBcclxuICAgICAgKTtcclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZUFtb3VudChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIGFtb3VudDogcmVzcG9uc2U/LmRhdGE/LmFtb3VudCxcclxuICAgICAgICBwYXlfZGF0ZTogcmVzcG9uc2U/LmRhdGE/LnBheV9kYXRlLnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dVcGRhdGVNb2RhbCh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBQYXltZW50IEFtb3VudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnB1dChcclxuICAgICAgICBgL3BheW1lbnQvdXBkYXRlLXBheW1lbnQtYW1vdW50LyR7Y3VycmVudFVwZGF0ZUFtb3VudC5faWR9YCxcclxuICAgICAgICB1cGRhdGVGb3JtRGF0YVxyXG4gICAgICApO1xyXG4gICAgICBzZXRTaG93VXBkYXRlTW9kYWwoZmFsc2UpO1xyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQYXltZW50IEFtb3VudCBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBQYXltZW50IEFtb3VudDpcIiwgZXJyb3IpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgICAgYC9lbnJvbGwvZ2V0LXVzZXItdGlja2V0cy1yZXBvcnQvJHtncm91cElkfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3QgdmFsaWRBdWN0aW9ucyA9IHJlc3BvbnNlLmRhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgICAoYXVjdGlvbikgPT4gYXVjdGlvbi5lbnJvbGxtZW50ICYmIGF1Y3Rpb24uZW5yb2xsbWVudC5ncm91cFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbih2YWxpZEF1Y3Rpb25zKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtvcGVuQmFja2Ryb3BMb2FkZXIgPyAoXHJcbiAgICAgICAgPEJhY2tkcm9wQmx1ckxvYWRlciB0aXRsZT17XCJwYXltZW50IERhdGEgcHJvY2Vzc2luZy4uLi5cIn0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgIG5vUmVsb2FkPXthbGVydENvbmZpZy5ub1JlbG9hZH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlJlZ2lzdHJhdGlvbiBGZWU8L2gxPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiAgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1ib2xkIFwiPlNlYXJjaCBvciBTZWxlY3QgR3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGwgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVG9kYXkncyBSZWdpc3RyYXRpb24gRmVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgIGgtMTQgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e1wiIzFcIn0gdmFsdWU9e1widG9kYXlcIn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRvZGF5J3MgUGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHthY3R1YWxHcm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbCh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy12aW9sZXQtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIEFkZCBSZWdpc3RyYXRpb24gRmVlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dVcGxvYWRNb2RhbCh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy15ZWxsb3ctMzAwIHRleHQtYmxhY2sgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXllbGxvdy00MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBVcGxvYWQgRXhjZWxcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgey8qIDxVcGxvYWRNb2RhbFxyXG4gICAgICAgICAgICAgICAgc2hvdz17c2hvd1VwbG9hZE1vZGFsfVxyXG4gICAgICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlVXBsb2FkTW9kYWxDbG9zZX1cclxuICAgICAgICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVGaWxlU3VibWl0fVxyXG4gICAgICAgICAgICAgICAgZ3JvdXBzPXtncm91cHN9XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZEdyb3VwSWQ9e3NlbGVjdGVkR3JvdXBJZH1cclxuICAgICAgICAgICAgICAgIGhhbmRsZUdyb3VwPXtoYW5kbGVHcm91cH1cclxuICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZVVzZXI9e2hhbmRsZUNoYW5nZVVzZXJ9XHJcbiAgICAgICAgICAgICAgICBmb3JtRGF0YT17Zm9ybURhdGF9XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJlZEF1Y3Rpb249e2ZpbHRlcmVkQXVjdGlvbn1cclxuICAgICAgICAgICAgICAvPiAqL31cclxuICAgICAgICAgICAgICAgIHtUYWJsZVBheW1lbnRzICYmIFRhYmxlUGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e1RhYmxlUGF5bWVudHMuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LnZhbHVlcyhpdGVtKS5zb21lKCh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiUmVnaXN0cmF0aW9uIEZlZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BSZWdpc3RyYXRpb24gRmVlcy5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGE9XCJQYXltZW50cyBEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBUYWJsZVBheW1lbnRzLmxlbmd0aCA8PSAwICYmIHNlbGVjdGVkQXVjdGlvbkdyb3VwSWRcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWx9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQWRkIFJlZ2lzdHJhdGlvbiBGZWVzXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICAgICAgey8qIDxEcmF3ZXJcclxuICAgICAgICAgICAgICAgICAgICBjbG9zYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGRlc3Ryb3lPbkhpZGRlblxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXs8cD5MYXN0IFRocmVlIFRyYW5zYWN0aW9uczwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9wZW49e29wZW5BbnRERHJhd2VyfVxyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e3Nob3dMb2FkZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0T3BlbkFudEREcmF3ZXIoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2xhc3RUaHJlZVBheW1lbnRzPy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWNlbnRlciB0ZXh0LXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5vIFRyYW5zYWN0aW9uIEZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bGFzdFRocmVlUGF5bWVudHMubWFwKChwYXltZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLXdoaXRlIHNoYWRvdy1tZCByb3VuZGVkLWxnIHAtNCBzcGFjZS15LTIgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IERhdGU6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQ/LnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC5ncm91cF9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC5ncm91cF9pZD8uZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQudGlja2V0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0OntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50Py50aWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50OntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwYXltZW50Py5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IFR5cGU6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudD8ucGF5X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOYW1lOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQudXNlcl9pZD8uZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L0RyYXdlcj4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgJHtmaWVsZFNpemUuaGVpZ2h0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake2dyb3VwLmZ1bGxfbmFtZX0gfCAke2dyb3VwLnBob25lX251bWJlcn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVnaXN0cmF0aW9uIEZlZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9mb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRGb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBSZWdpc3RyYXRpb24gRmVlIFR5cGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSZWd8Q2hpdFwiPkNoaXQgUmVnaXN0cmF0aW9uIEZlZSA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSZWd8UGlnbWVcIj5QaWdtZSBSZWdpc3RyYXRpb24gRmVlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUmVnfExvYW5cIj5Mb2FuIFJlZ2lzdHJhdGlvbiBGZWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHcm91cCAmIFRpY2tldCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIG1vZGU9XCJtdWx0aXBsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXAgfCBUaWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRBbnRTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEdyb3VwVGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41IFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBheV9mb3IgPT09IFwiUmVnfENoaXRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkQXVjdGlvbi5tYXAoKGVudHJ5LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBOYW1lID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVW5uYW1lZCBHcm91cFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBJZCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5Py5lbnJvbGxtZW50Py5ncm91cD8uX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBtaXNzaW5nLSR7aW5kZXh9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpY2tldCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5Py5lbnJvbGxtZW50Py50aWNrZXRzIHx8IFwiVW5rbm93blwiO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BjaGl0LSR7Z3JvdXBJZH18JHt0aWNrZXR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cE5hbWV9IHwge3RpY2tldH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBheV9mb3IgPT09IFwiUmVnfFBpZ21lXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZUN1c3RvbWVycz8ubWFwKChwaWdtZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9e2BwaWdtZS0ke3BpZ21lLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YCR7cGlnbWUucGlnbWVfaWR9IHwg4oK5ICR7cGlnbWUucGF5YWJsZV9hbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBheV9mb3IgPT09IFwiUmVnfExvYW5cIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2JvcnJvd2Vycz8ubWFwKChib3Jyb3dlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9e2Bsb2FuLSR7Ym9ycm93ZXIuX2lkfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgbG9hbi0ke2JvcnJvd2VyLmxvYW5faWR9IHwg4oK5ICR7Ym9ycm93ZXIubG9hbl9hbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW1vZGlmeVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50TW9kZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmVcIj5PbmxpbmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNyZWRpdCBOb3RlXCI+Q3JlZGl0IE5vdGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRyYW5zZmVyXCI+VHJhbnNmZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOb3RlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgbm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTMgcHktMi41IHRleHQtc21cclxuICAgICAgICAgICAgICAgICAgICAgICB0ZXh0LWdyYXktOTAwIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTIwMCByZXNpemUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hbW91bnQgJiYgcGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGggPiAxICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgSW5kaXZpZHVhbCBUaWNrZXQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBob3ZlcjpjdXJzb3Itbm90LWFsbG93ZWQgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ0b3RhbEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZm9ybURhdGEuYW1vdW50KSAvIHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIHtwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSUQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBUcmFuc2FjdGlvbiBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNhdmUgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9Nb2RhbD5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgICAgICAgb3Blbj17c2hvd01vZGFsVmlld31cclxuICAgICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgb25Paz17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgb25SZWxvYWQ9eygpID0+IGhhbmRsZVZpZXdNb2RhbE9wZW4oY3VycmVudEdyb3VwSWQpfVxyXG4gICAgICAgICAgICAgIGZvb3Rlcj17PGRpdj48L2Rpdj59XHJcbiAgICAgICAgICAgICAgbG9hZGluZz17dmlld0xvYWRlcn1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkdyb3VwOiA8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkdyb3VwIFZhbHVlOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkdyb3VwIEluc3RhbGxtZW50Ojwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9pbnN0YWxsfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VXNlcjo8L3N0cm9uZz4ge2N1cnJlbnRWaWV3R3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHwgVGlja2V0OiB7Y3VycmVudFZpZXdHcm91cD8udGlja2V0fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+QmlkIEFtb3VudDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgLVxyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRWaWV3R3JvdXA/Lndpbl9hbW91bnRcclxuICAgICAgICAgICAgICAgICAgICA/IGN1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSAtXHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudFZpZXdHcm91cD8ud2luX2Ftb3VudFxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJcIn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkNvbW1pc3Npb246PC9zdHJvbmc+IHtjdXJyZW50Vmlld0dyb3VwPy5jb21taXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+V2lubmluZyBBbW91bnQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8ud2luX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkRpdmlkZW50Ojwvc3Ryb25nPiB7Y3VycmVudFZpZXdHcm91cD8uZGl2aWRlbnR9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5EaXZpZGVudCBwZXIgSGVhZDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5kaXZpZGVudF9oZWFkfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+TmV4dCBQYXlhYmxlOjwvc3Ryb25nPiB7Y3VycmVudFZpZXdHcm91cD8ucGF5YWJsZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkF1Y3Rpb24gRGF0ZTo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5hdWN0aW9uX2RhdGV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5OZXh0IERhdGU6PC9zdHJvbmc+IHtjdXJyZW50Vmlld0dyb3VwPy5uZXh0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5DcmVhdGVkIEF0Ojwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VXBkYXRlZCBBdDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy51cGRhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0FudE1vZGFsPlxyXG4gICAgICAgICAgICB7LyogPC9QYXltZW50TW9kYWw+ICovfVxyXG5cclxuICAgICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU3VyZSB3YW50IHRvIGRlbGV0ZSB0aGlzIFBheW1lbnQgP1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlQXVjdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlZ2lzdHJhdGlvbkZlZTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1JlZ2lzdHJhdGlvbkZlZXMuanN4In0=