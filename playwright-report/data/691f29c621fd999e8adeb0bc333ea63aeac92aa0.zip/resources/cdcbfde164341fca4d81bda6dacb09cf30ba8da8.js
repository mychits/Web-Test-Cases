import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MobileAppEnroll.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import { FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"]; const useCallback = __vite__cjsImport5_react["useCallback"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import {
  MdGridView,
  MdViewList,
  MdOutlineTableRows,
  MdAssignmentInd
} from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import handleEnrollmentRequestPrint from "/src/components/printFormats/enrollmentRequestPrint.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import __vite__cjsImport19_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport19_dayjs.__esModule ? __vite__cjsImport19_dayjs.default : __vite__cjsImport19_dayjs;
import { SearchOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import {
  Select,
  Dropdown,
  notification,
  Input,
  Button,
  DatePicker,
  Modal as AntModal,
  Table,
  Card,
  Row,
  Col,
  Checkbox
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const MOBILE_ENROLL_STATUS_CONFIG = [
  {
    key: "Contacted",
    label: "Contacted",
    color: "from-indigo-500 to-indigo-600",
    bgLight: "bg-indigo-50",
    textColor: "text-indigo-700",
    iconColor: "text-indigo-500",
    ringColor: "ring-indigo-100",
    icon: /* @__PURE__ */ jsxDEV(
      "svg",
      {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4415,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 4409,
        columnNumber: 3
      },
      this
    )
  },
  {
    key: "Interested",
    label: "Interested",
    color: "from-blue-500 to-blue-600",
    bgLight: "bg-blue-50",
    textColor: "text-blue-700",
    iconColor: "text-blue-500",
    ringColor: "ring-blue-100",
    icon: /* @__PURE__ */ jsxDEV(
      "svg",
      {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            d: "M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4439,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 4433,
        columnNumber: 3
      },
      this
    )
  },
  {
    key: "Follow Up",
    label: "Follow Up",
    color: "from-purple-500 to-purple-600",
    bgLight: "bg-purple-50",
    textColor: "text-purple-700",
    iconColor: "text-purple-500",
    ringColor: "ring-purple-100",
    icon: /* @__PURE__ */ jsxDEV(
      "svg",
      {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4463,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 4457,
        columnNumber: 3
      },
      this
    )
  },
  {
    key: "Converted",
    label: "Converted",
    color: "from-emerald-500 to-green-600",
    bgLight: "bg-emerald-50",
    textColor: "text-emerald-700",
    iconColor: "text-emerald-500",
    ringColor: "ring-emerald-100",
    icon: /* @__PURE__ */ jsxDEV(
      "svg",
      {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4487,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 4481,
        columnNumber: 3
      },
      this
    )
  },
  {
    key: "Rejected",
    label: "Rejected",
    color: "from-red-500 to-red-600",
    bgLight: "bg-red-50",
    textColor: "text-red-700",
    iconColor: "text-red-500",
    ringColor: "ring-red-100",
    icon: /* @__PURE__ */ jsxDEV(
      "svg",
      {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            d: "M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4511,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 4505,
        columnNumber: 3
      },
      this
    )
  }
];
const STATUS_OPTIONS = [
  "Not Contacted",
  "Contacted",
  "Interested",
  "Follow Up",
  "Converted",
  "Rejected"
];
const MobileAppEnroll = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [TableEnrolls, setTableEnrolls] = useState([]);
  const [filteredEnrolls, setFilteredEnrolls] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [availableTickets, setAvailableTickets] = useState([]);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [availableTicketsAdd, setAvailableTicketsAdd] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isDataTableLoading, setIsDataTableLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [allEnrollUrl, setAllEnrollUrl] = useState(true);
  const [leads, setLeads] = useState([]);
  const [agents, setAgents] = useState([]);
  const [whatsappEnable, setWhatsappEnable] = useState(true);
  const [enrollmentStep, setEnrollmentStep] = useState("verify");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [isExistingEnrollment, setIsExistingEnrollment] = useState(false);
  const [admin, setAdmin] = useState("");
  const [activeTab, setActiveTab] = useState("pending");
  const [viewMode, setViewMode] = useState("grid");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(9);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEnrollments, setSelectedEnrollments] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [showStatusUpdateModal, setShowStatusUpdateModal] = useState(false);
  const [statusUpdateData, setStatusUpdateData] = useState({
    _id: "",
    status: "",
    remark: "",
    follow_up_date: "",
    isBulk: false,
    selectedIds: []
  });
  const [isStatusUpdating, setIsStatusUpdating] = useState(false);
  const [summaryStats, setSummaryStats] = useState({
    totalEnrollments: 0,
    totalTickets: 0,
    uniqueCustomers: 0,
    uniqueGroups: 0
  });
  const today = /* @__PURE__ */ new Date();
  const currentYear = today.getFullYear();
  const currentMonth = String(today.getMonth() + 1).padStart(2, "0");
  const currentYearMonth = `${currentYear}-${currentMonth}`;
  function formatDate(date) {
    const year = date.getFullYear();
    const month = `0${date.getMonth() + 1}`.slice(-2);
    const day = `0${date.getDate()}`.slice(-2);
    return `${year}-${month}-${day}`;
  }
  const parseDate = (dateString) => {
    const [year, month] = dateString.split("-");
    return {
      year,
      month: String(parseInt(month)).padStart(2, "0"),
      monthName: monthNames[parseInt(month) - 1]
    };
  };
  const formatToYearMonth = (year, month) => {
    return `${year}-${String(month).padStart(2, "0")}`;
  };
  const getMonthDateRange = (dateString) => {
    const { year, month } = parseDate(dateString);
    const startDate = new Date(year, parseInt(month) - 1, 1);
    const endDate = new Date(year, parseInt(month), 0);
    return {
      from_date: formatDate(startDate),
      to_date: formatDate(endDate)
    };
  };
  const [selectedDate, setSelectedDate] = useState("");
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    no_of_tickets: "",
    referred_type: "",
    payment_type: "",
    referred_customer: "",
    agent: "",
    referred_lead: "",
    chit_asking_month: ""
  });
  const [isVerified, setIsVerified] = useState(false);
  const [updateFormData, setUpdateFormData] = useState({
    group_id: "",
    user_id: "",
    tickets: "",
    payment_type: "",
    referred_type: "",
    referred_customer: "",
    agent: "",
    referred_lead: "",
    chit_asking_month: ""
  });
  const [searchText, setSearchText] = useState("");
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    const adminId = userObj?._id;
    if (adminId) {
      setAdmin(userObj._id);
    } else {
      setAdmin("");
    }
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const getStatusCounts = () => {
    const contacted = filteredEnrolls.filter(
      (u) => u.status && u.status !== "Not Contacted"
    );
    return {
      total: contacted.length,
      Contacted: contacted.filter((u) => u.status === "Contacted").length,
      Interested: contacted.filter((u) => u.status === "Interested").length,
      "Follow Up": contacted.filter((u) => u.status === "Follow Up").length,
      Converted: contacted.filter((u) => u.status === "Converted").length,
      Rejected: contacted.filter((u) => u.status === "Rejected").length
    };
  };
  const getStatusColor = (status) => {
    switch (status) {
      case "Approved":
        return "bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-600/20";
      case "Pending":
        return "bg-amber-50 text-amber-700 ring-1 ring-inset ring-amber-600/20";
      case "Interested":
        return "bg-blue-50 text-blue-700 ring-1 ring-inset ring-blue-600/20";
      case "Not Interested":
        return "bg-gray-50 text-gray-600 ring-1 ring-inset ring-gray-500/20";
      case "Contacted":
        return "bg-indigo-50 text-indigo-700 ring-1 ring-inset ring-indigo-600/20";
      case "Follow Up":
        return "bg-purple-50 text-purple-700 ring-1 ring-inset ring-purple-600/20";
      case "Converted":
        return "bg-green-50 text-green-700 ring-1 ring-inset ring-green-600/20";
      case "Rejected":
        return "bg-red-50 text-red-700 ring-1 ring-inset ring-red-600/20";
      default:
        return "bg-gray-50 text-gray-600 ring-1 ring-inset ring-gray-500/20";
    }
  };
  const getStatusIcon = (status) => {
    switch (status) {
      case "Contacted":
        return /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 4750,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4744,
            columnNumber: 11
          },
          this
        );
      case "Interested":
        return /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 4766,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4760,
            columnNumber: 11
          },
          this
        );
      case "Follow Up":
        return /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 4782,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4776,
            columnNumber: 11
          },
          this
        );
      case "Converted":
        return /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 4798,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4792,
            columnNumber: 11
          },
          this
        );
      case "Rejected":
        return /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-4 h-4",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 4814,
                columnNumber: 13
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4808,
            columnNumber: 11
          },
          this
        );
      default:
        return null;
    }
  };
  const getTabFilteredEnrolls = () => {
    if (activeTab === "pending") {
      return filteredEnrolls.filter(
        (enroll) => enroll.status === "Not Contacted" || !enroll.status
      );
    } else {
      return filteredEnrolls.filter(
        (enroll) => enroll.status && enroll.status !== "Not Contacted"
      );
    }
  };
  const handleSelectEnrollment = (id) => {
    setSelectedEnrollments((prev) => {
      if (prev.includes(id)) {
        return prev.filter((item) => item !== id);
      }
      return [...prev, id];
    });
    setSelectAll(false);
  };
  const handleSelectAll = () => {
    const tabFiltered = getTabFilteredEnrolls();
    const currentIds = tabFiltered.map((item) => item._id);
    if (selectAll) {
      setSelectedEnrollments([]);
    } else {
      setSelectedEnrollments(currentIds);
    }
    setSelectAll(!selectAll);
  };
  const handleBulkStatusUpdate = () => {
    if (selectedEnrollments.length === 0) {
      setAlertConfig({
        visibility: true,
        message: "Please select at least one enrollment.",
        type: "warning"
      });
      return;
    }
    setStatusUpdateData({
      _id: "",
      status: "",
      remark: "",
      follow_up_date: "",
      isBulk: true,
      selectedIds: [...selectedEnrollments]
    });
    setShowStatusUpdateModal(true);
  };
  const fetchAllEnrollmentData = useCallback(async () => {
    try {
      setIsDataTableLoading(true);
      const res = await api.get("/mobile-app-enroll/get-mobile-app-enroll");
      const rawData = res.data;
      const totalEnrollments = rawData.length;
      const totalTickets = rawData.reduce(
        (sum, item) => sum + (item.no_of_tickets || 0),
        0
      );
      const uniqueCustomers = new Set(
        rawData.map((item) => item.user_id?._id).filter(Boolean)
      ).size;
      const uniqueGroups = new Set(
        rawData.map((item) => item.group_id?.group_name).filter(Boolean)
      ).size;
      setSummaryStats({
        totalEnrollments,
        totalTickets,
        uniqueCustomers,
        uniqueGroups
      });
      const data = rawData.map((item, index) => ({
        _id: item._id,
        id: index + 1,
        mobile_enroll_code: item.mobile_enroll_code,
        name: item.user_id?.full_name || "-",
        phone_number: item.user_id?.phone_number || "-",
        group_name: item.group_id?.group_name || "-",
        no_of_tickets: item.no_of_tickets,
        payment_type: item.payment_type,
        chit_asking_month: item.chit_asking_month,
        referred_type: item.referred_type,
        status: item.status || "Not Contacted",
        remark: item.remark || "",
        follow_up_date: item.follow_up_date || "",
        user_id: item.user_id,
        group_id: item.group_id,
        referred_customer: item.referred_customer,
        referred_lead: item.referred_lead,
        agent: item.agent,
        enrollment_date: item.createdAt?.split("T")[0],
        referred_by: item?.user_id?.referred_employee ? `${item?.user_id?.referred_employee?.name || "-"} | ${item?.user_id?.referred_employee?.phone_number || "-"}` : "Self",
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: [
                {
                  key: "status",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-blue-600 font-medium cursor-pointer px-2 py-1 flex items-center gap-2",
                      onClick: () => openStatusUpdateModal(item),
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          "svg",
                          {
                            className: "w-4 h-4",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /* @__PURE__ */ jsxDEV(
                              "path",
                              {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "2",
                                d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                                lineNumber: 4953,
                                columnNumber: 27
                              },
                              this
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                            lineNumber: 4947,
                            columnNumber: 25
                          },
                          this
                        ),
                        "Update Status"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 4943,
                      columnNumber: 17
                    },
                    this
                  )
                },
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-green-600",
                      onClick: () => handleUpdateModalOpen(item._id),
                      children: "Edit"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 4967,
                      columnNumber: 17
                    },
                    this
                  )
                },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-red-600",
                      onClick: () => handleDeleteModalOpen(item._id),
                      children: "Delete"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 4978,
                      columnNumber: 17
                    },
                    this
                  )
                },
                {
                  key: "3",
                  label: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "text-blue-600",
                      onClick: () => handleEnrollClick(item),
                      children: "Approve"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 4989,
                      columnNumber: 17
                    },
                    this
                  )
                }
              ]
            },
            placement: "bottomLeft",
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5001,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 4936,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 4935,
          columnNumber: 9
        }, this)
      }));
      setTableEnrolls(data);
      setFilteredEnrolls(data);
    } catch (err) {
      console.error("Failed to fetch enrollment data", err);
    } finally {
      setIsDataTableLoading(false);
    }
  }, []);
  useEffect(() => {
    fetchAllEnrollmentData();
  }, [fetchAllEnrollmentData]);
  useEffect(() => {
    if (searchTerm) {
      const filtered = TableEnrolls.filter(
        (enroll) => enroll.name.toLowerCase().includes(searchTerm.toLowerCase()) || enroll.phone_number.toString().includes(searchTerm) || enroll.group_name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredEnrolls(filtered);
    } else {
      setFilteredEnrolls(TableEnrolls);
    }
  }, [searchTerm, TableEnrolls]);
  const ContactSummaryDashboard = () => {
    const counts = getStatusCounts();
    const pendingCount = filteredEnrolls.filter(
      (u) => u.status === "Not Contacted" || !u.status
    ).length;
    const conversionRate = counts.total > 0 ? (counts.Converted / counts.total * 100).toFixed(1) : "0.0";
    const rejectionRate = counts.total > 0 ? (counts.Rejected / counts.total * 100).toFixed(1) : "0.0";
    return /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl text-white shadow-md shadow-blue-200", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-5 h-5",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5060,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5054,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5053,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900", children: "Contact Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5069,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: "Overview of mobile enrollment follow-up work" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5072,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5068,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5052,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          parseFloat(conversionRate) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 rounded-full px-3 py-1.5", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "w-3.5 h-3.5 text-emerald-600",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                    d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5087,
                    columnNumber: 19
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5081,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-emerald-700", children: [
              conversionRate,
              "% conversion"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5094,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5080,
            columnNumber: 13
          }, this),
          parseFloat(rejectionRate) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-red-50 border border-red-200 rounded-full px-3 py-1.5", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "w-3.5 h-3.5 text-red-500",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                    d: "M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5107,
                    columnNumber: 19
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5101,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-red-600", children: [
              rejectionRate,
              "% rejection"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5114,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5100,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5078,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5051,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-5", children: MOBILE_ENROLL_STATUS_CONFIG.map((cfg) => {
        const count = counts[cfg.key];
        const percentage = counts.total > 0 ? (count / counts.total * 100).toFixed(0) : 0;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `relative overflow-hidden rounded-xl border border-gray-100 p-4 hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 group cursor-default ${count === 0 ? "opacity-50" : ""}`,
            children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `absolute top-0 right-0 w-20 h-20 rounded-full bg-gradient-to-br ${cfg.color} opacity-[0.07] -translate-y-1/2 translate-x-1/2 group-hover:opacity-[0.12] transition-opacity`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5132,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `w-9 h-9 rounded-lg ${cfg.bgLight} ${cfg.iconColor} flex items-center justify-center mb-3 ring-1 ${cfg.ringColor}`,
                    children: cfg.icon
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5136,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-extrabold text-gray-900 leading-none mb-1", children: count }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5141,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500 mb-2", children: cfg.label }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5144,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full h-1.5 bg-gray-100 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `h-full rounded-full bg-gradient-to-r ${cfg.color} transition-all duration-700 ease-out`,
                    style: { width: `${percentage}%` }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5148,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5147,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 mt-1 text-right", children: [
                  percentage,
                  "%"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5153,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5135,
                columnNumber: 17
              }, this)
            ]
          },
          cfg.key,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5128,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 pt-4 border-t border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 bg-slate-50 rounded-xl px-4 py-2.5 border border-slate-200/60", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-lg bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-white shadow-sm", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5171,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5165,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5164,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-gray-900 leading-none", children: counts.total }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5180,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 font-medium", children: "Total Processed" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5183,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5179,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5163,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 bg-amber-50 rounded-xl px-4 py-2.5 border border-amber-200/60", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-sm", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5197,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5191,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5190,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-amber-700 leading-none", children: pendingCount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5206,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-amber-600 font-medium", children: "Still Pending" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5209,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5205,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5189,
          columnNumber: 11
        }, this),
        counts["Follow Up"] > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 bg-purple-50 rounded-xl px-4 py-2.5 border border-purple-200/60", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center text-white shadow-sm", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5224,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5218,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5217,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-purple-700 leading-none", children: counts["Follow Up"] }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5233,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-purple-600 font-medium", children: "Follow Ups Due" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5236,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5232,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5216,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 ml-auto", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-gray-900 leading-none", children: [
              filteredEnrolls.length > 0 ? (counts.total / filteredEnrolls.length * 100).toFixed(1) : "0.0",
              "%"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5245,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 font-medium", children: "Process Rate" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5251,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5244,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-12 h-12 -rotate-90", viewBox: "0 0 36 36", children: [
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831",
                fill: "none",
                stroke: "#f1f5f9",
                strokeWidth: "3"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5257,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831",
                fill: "none",
                stroke: "url(#progressGradient)",
                strokeWidth: "3",
                strokeDasharray: `${filteredEnrolls.length > 0 ? counts.total / filteredEnrolls.length * 100 : 0}, 100`,
                strokeLinecap: "round"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5263,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV(
              "linearGradient",
              {
                id: "progressGradient",
                x1: "0%",
                y1: "0%",
                x2: "100%",
                y2: "0%",
                children: [
                  /* @__PURE__ */ jsxDEV("stop", { offset: "0%", stopColor: "#6366f1" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5279,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("stop", { offset: "100%", stopColor: "#3b82f6" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5280,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5272,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5271,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5256,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5255,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5243,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5162,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
      lineNumber: 5050,
      columnNumber: 7
    }, this);
  };
  const openStatusUpdateModal = (enroll) => {
    setStatusUpdateData({
      _id: enroll._id,
      status: enroll.status || "",
      remark: enroll.remark || "",
      follow_up_date: enroll.follow_up_date || "",
      isBulk: false,
      selectedIds: [enroll._id]
    });
    setShowStatusUpdateModal(true);
  };
  const handleStatusUpdateSubmit = async () => {
    const { _id, status, remark, follow_up_date, isBulk, selectedIds } = statusUpdateData;
    if (!status) {
      setAlertConfig({
        visibility: true,
        message: "Please select a status.",
        type: "warning"
      });
      return;
    }
    if (status === "Follow Up" && !follow_up_date) {
      setAlertConfig({
        visibility: true,
        message: "Please select a follow-up date.",
        type: "warning"
      });
      return;
    }
    setIsStatusUpdating(true);
    try {
      const idsToUpdate = isBulk ? selectedIds : [_id];
      const updatePromises = idsToUpdate.map(
        (id) => api.put(`/mobile-app-enroll/verify-enroll/${id}`, {
          status,
          remark: remark || "",
          follow_up_date: status === "Follow Up" ? follow_up_date : ""
        })
      );
      await Promise.all(updatePromises);
      setAlertConfig({
        visibility: true,
        message: isBulk ? `${idsToUpdate.length} enrollments updated successfully!` : "Status updated successfully!",
        type: "success"
      });
      setShowStatusUpdateModal(false);
      setSelectedEnrollments([]);
      setSelectAll(false);
      fetchAllEnrollmentData();
    } catch (error) {
      console.error("Update error:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to update status.",
        type: "error"
      });
    } finally {
      setIsStatusUpdating(false);
    }
  };
  const ActionDropdown = ({ enroll }) => {
    console.log("=== ActionDropdown enroll data ===", enroll);
    console.log("user_id:", enroll.user_id);
    console.log("group_id:", enroll.group_id);
    console.log("_id:", enroll._id);
    const handleEnrollClickWrapper = () => {
      console.log("=== Approve button clicked for enrollment ===", enroll);
      handleEnrollClick(enroll);
    };
    return /* @__PURE__ */ jsxDEV(
      Dropdown,
      {
        trigger: ["click"],
        menu: {
          items: [
            {
              key: "status",
              label: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "text-blue-600 font-medium cursor-pointer px-2 py-1 flex items-center gap-2",
                  onClick: () => openStatusUpdateModal(enroll),
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "svg",
                      {
                        className: "w-4 h-4",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /* @__PURE__ */ jsxDEV(
                          "path",
                          {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: "2",
                            d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                            lineNumber: 5397,
                            columnNumber: 21
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                        lineNumber: 5391,
                        columnNumber: 19
                      },
                      this
                    ),
                    "Update Status"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5387,
                  columnNumber: 13
                },
                this
              )
            },
            {
              key: "1",
              label: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "text-green-600 font-medium cursor-pointer px-2 py-1",
                  onClick: () => handleUpdateModalOpen(enroll._id),
                  children: "Edit"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5411,
                  columnNumber: 13
                },
                this
              )
            },
            {
              key: "2",
              label: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "text-red-600 font-medium cursor-pointer px-2 py-1",
                  onClick: () => handleDeleteModalOpen(enroll._id),
                  children: "Delete"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5422,
                  columnNumber: 13
                },
                this
              )
            },
            {
              key: "3",
              label: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "text-blue-600 font-medium cursor-pointer px-2 py-1",
                  onClick: handleEnrollClickWrapper,
                  children: "Approve"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5433,
                  columnNumber: 13
                },
                this
              )
            }
          ]
        },
        placement: "bottomLeft",
        children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer text-xl" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5445,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5380,
        columnNumber: 7
      },
      this
    );
  };
  const renderEnrollmentCard = (enroll) => {
    const isPending = enroll.status === "Not Contacted" || !enroll.status;
    if (activeTab === "pending" && !isPending) return null;
    if (activeTab === "contacted" && isPending) return null;
    const isSelected = selectedEnrollments.includes(enroll._id);
    if (activeTab === "contacted") {
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `group relative bg-white rounded-2xl border shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ${isSelected ? "border-violet-400 ring-2 ring-violet-100 shadow-lg" : "border-blue-200"}`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 w-full h-1.5 rounded-t-2xl bg-gradient-to-r from-blue-500 to-indigo-500 opacity-90" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5468,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-5 pt-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV(
                    Checkbox,
                    {
                      checked: isSelected,
                      onChange: () => handleSelectEnrollment(enroll._id),
                      className: "flex-shrink-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5472,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm flex-shrink-0", children: enroll.name?.charAt(0)?.toUpperCase() }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5477,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-gray-900 truncate text-lg", children: enroll.name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5481,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: enroll.mobile_enroll_code }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5484,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5480,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5471,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: /* @__PURE__ */ jsxDEV(ActionDropdown, { enroll }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5490,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5489,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5470,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5496,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5", children: enroll.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5499,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5495,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5504,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5 truncate", children: enroll.group_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5507,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5503,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5494,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-slate-50 to-blue-50/50 rounded-xl border border-slate-200/80 p-4 space-y-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
                  /* @__PURE__ */ jsxDEV(
                    "svg",
                    {
                      className: "w-3.5 h-3.5",
                      fill: "none",
                      stroke: "currentColor",
                      viewBox: "0 0 24 24",
                      children: /* @__PURE__ */ jsxDEV(
                        "path",
                        {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: "2",
                          d: "M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                          lineNumber: 5521,
                          columnNumber: 19
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5515,
                      columnNumber: 17
                    },
                    this
                  ),
                  "Work Status"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5514,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold ${getStatusColor(enroll.status)}`,
                      children: [
                        getStatusIcon(enroll.status),
                        enroll.status
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5532,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-600/20", children: [
                    enroll.no_of_tickets,
                    " tickets"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5538,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5531,
                  columnNumber: 15
                }, this),
                enroll.remark && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg border border-slate-200 p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1", children: "Remark" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5545,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700 leading-relaxed", children: enroll.remark }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5548,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5544,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
                  enroll.referred_by && enroll.referred_by !== "N/A" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg border border-slate-200 p-2.5", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5", children: "Referred By" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5557,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-indigo-700 truncate", children: enroll.referred_by }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5560,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5556,
                    columnNumber: 17
                  }, this),
                  enroll.follow_up_date && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg border border-purple-200 p-2.5", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-purple-400 uppercase tracking-wider mb-0.5", children: "Follow Up Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5567,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV(
                        "svg",
                        {
                          className: "w-4 h-4 text-purple-500",
                          fill: "none",
                          stroke: "currentColor",
                          viewBox: "0 0 24 24",
                          children: /* @__PURE__ */ jsxDEV(
                            "path",
                            {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: "2",
                              d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                              lineNumber: 5577,
                              columnNumber: 25
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                          lineNumber: 5571,
                          columnNumber: 23
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-purple-700", children: enroll.follow_up_date }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                        lineNumber: 5584,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5570,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5566,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5554,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-400 text-right", children: [
                  "Enrolled: ",
                  enroll.enrollment_date
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5592,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5513,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5469,
              columnNumber: 11
            }, this)
          ]
        },
        enroll._id,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5460,
          columnNumber: 9
        },
        this
      );
    }
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `group relative bg-white rounded-2xl border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 ${isSelected ? "border-violet-400 ring-2 ring-violet-100 shadow-lg" : "border-gray-200"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 w-full h-1.5 rounded-t-2xl bg-gradient-to-r from-amber-400 to-orange-500 opacity-80" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5611,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-5 pt-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
                /* @__PURE__ */ jsxDEV(
                  Checkbox,
                  {
                    checked: isSelected,
                    onChange: () => handleSelectEnrollment(enroll._id),
                    className: "flex-shrink-0"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5615,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-bold text-sm flex-shrink-0", children: enroll.name?.charAt(0)?.toUpperCase() }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5620,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-gray-900 truncate text-lg", children: enroll.name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5624,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: enroll.mobile_enroll_code }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5627,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5623,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5614,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(ActionDropdown, { enroll }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5632,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5613,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "Phone" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5637,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5", children: enroll.phone_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5640,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5636,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "Group" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5645,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5 truncate", children: enroll.group_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5648,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5644,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5635,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-xs text-gray-500 border-t border-gray-100 pt-3 mt-1", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full font-medium bg-amber-50 text-amber-700 ring-1 ring-inset ring-amber-600/20", children: "Not Contacted" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5655,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "svg",
                  {
                    className: "w-3.5 h-3.5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /* @__PURE__ */ jsxDEV(
                      "path",
                      {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "2",
                        d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                        lineNumber: 5665,
                        columnNumber: 17
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5659,
                    columnNumber: 15
                  },
                  this
                ),
                enroll.enrollment_date
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5658,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5654,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5612,
            columnNumber: 9
          }, this)
        ]
      },
      enroll._id,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5603,
        columnNumber: 7
      },
      this
    );
  };
  const EnrollRow = ({ enroll }) => {
    const isPending = enroll.status === "Not Contacted" || !enroll.status;
    if (activeTab === "pending" && !isPending) return null;
    if (activeTab === "contacted" && isPending) return null;
    const isSelected = selectedEnrollments.includes(enroll._id);
    if (activeTab === "contacted") {
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `group bg-white rounded-xl border shadow-sm hover:shadow-lg hover:border-blue-300 transition-all duration-300 overflow-hidden ${isSelected ? "border-violet-400 ring-2 ring-violet-100" : "border-blue-200"}`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 w-full sm:w-auto", children: [
                /* @__PURE__ */ jsxDEV(
                  Checkbox,
                  {
                    checked: isSelected,
                    onChange: () => handleSelectEnrollment(enroll._id),
                    className: "flex-shrink-0"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5699,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm flex-shrink-0", children: enroll.name?.charAt(0)?.toUpperCase() }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5704,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1 flex-wrap", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-900 truncate", children: enroll.name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5709,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${getStatusColor(enroll.status)}`,
                        children: [
                          getStatusIcon(enroll.status),
                          enroll.status
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                        lineNumber: 5712,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-600/20", children: [
                      enroll.no_of_tickets,
                      " tickets"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 5718,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5708,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 truncate", children: enroll.group_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5722,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5707,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5698,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 ml-0 sm:ml-auto w-full sm:w-auto", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 px-3 py-1.5 rounded-lg text-center min-w-[100px]", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-violet-500 font-medium", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5730,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-violet-900", children: enroll.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5731,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5729,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ActionDropdown, { enroll }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5736,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5735,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5728,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5697,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-slate-50 to-blue-50/40 border-t border-slate-200 px-4 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 text-xs", children: [
              enroll.remark && /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2 flex-1 min-w-[200px]", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-400 uppercase tracking-wider flex-shrink-0 mt-0.5", children: "Remark:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5745,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 leading-relaxed", children: enroll.remark }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5748,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5744,
                columnNumber: 15
              }, this),
              enroll.referred_by && enroll.referred_by !== "N/A" && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-indigo-100", children: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-indigo-700", children: [
                "Referred: ",
                enroll.referred_by
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5755,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5754,
                columnNumber: 15
              }, this),
              enroll.follow_up_date && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-purple-100", children: [
                /* @__PURE__ */ jsxDEV(
                  "svg",
                  {
                    className: "w-3.5 h-3.5 text-purple-500",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /* @__PURE__ */ jsxDEV(
                      "path",
                      {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: "2",
                        d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                        lineNumber: 5768,
                        columnNumber: 21
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 5762,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-purple-700", children: enroll.follow_up_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5775,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5761,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-slate-400 ml-auto", children: [
                "Enrolled: ",
                enroll.enrollment_date
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5780,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5742,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5741,
              columnNumber: 11
            }, this)
          ]
        },
        enroll._id,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5689,
          columnNumber: 9
        },
        this
      );
    }
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `group bg-white rounded-xl border shadow-sm hover:shadow-lg hover:border-gray-300 transition-all duration-300 overflow-hidden ${isSelected ? "border-violet-400 ring-2 ring-violet-100" : "border-gray-100"}`,
        children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 w-full sm:w-auto", children: [
            /* @__PURE__ */ jsxDEV(
              Checkbox,
              {
                checked: isSelected,
                onChange: () => handleSelectEnrollment(enroll._id),
                className: "flex-shrink-0"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5800,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-bold text-sm flex-shrink-0", children: enroll.name?.charAt(0)?.toUpperCase() }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5805,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-900 truncate", children: enroll.name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5810,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 ring-1 ring-inset ring-amber-600/20", children: "Pending" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5813,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5809,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 truncate", children: enroll.group_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5817,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5808,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5799,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 ml-0 sm:ml-auto w-full sm:w-auto", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-amber-50 px-3 py-1.5 rounded-lg text-center min-w-[100px]", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-amber-500 font-medium", children: "Phone" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5825,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-amber-900", children: enroll.phone_number }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5826,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5824,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-3 py-1.5 rounded-lg text-center min-w-[90px] border border-gray-100", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Enrolled" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5831,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: enroll.enrollment_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5832,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5830,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ActionDropdown, { enroll }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5837,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5836,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5823,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5798,
          columnNumber: 9
        }, this)
      },
      enroll._id,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5790,
        columnNumber: 7
      },
      this
    );
  };
  const SimplePagination = ({ currentPage: currentPage2, totalPages, onPageChange }) => {
    if (totalPages <= 1) return null;
    const pages = [];
    const max = 5;
    pages.push(1);
    if (totalPages > max) {
      if (currentPage2 > 3) pages.push("...");
      for (let i = Math.max(2, currentPage2 - 1); i <= Math.min(totalPages - 1, currentPage2 + 1); i++) {
        if (i !== 1 && i !== totalPages) pages.push(i);
      }
      if (currentPage2 < totalPages - 2) pages.push("...");
    } else {
      for (let i = 2; i <= totalPages; i++) pages.push(i);
    }
    if (totalPages > 1) pages.push(totalPages);
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-1.5 mt-8", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onPageChange(currentPage2 - 1),
          disabled: currentPage2 === 1,
          className: "px-3.5 py-2 text-sm font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 hover:shadow-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all",
          children: "Prev"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5868,
          columnNumber: 9
        },
        this
      ),
      pages.map(
        (page, i) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => typeof page === "number" && onPageChange(page),
            disabled: typeof page !== "number",
            className: `w-10 h-10 text-sm font-medium rounded-lg transition-all ${page === currentPage2 ? "bg-violet-600 text-white shadow-md shadow-violet-200" : typeof page === "number" ? "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:shadow-sm" : "bg-white text-gray-400 border border-gray-200 cursor-default"}`,
            children: page
          },
          i,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5876,
            columnNumber: 9
          },
          this
        )
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onPageChange(currentPage2 + 1),
          disabled: currentPage2 === totalPages,
          className: "px-3.5 py-2 text-sm font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 hover:shadow-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all",
          children: "Next"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5885,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
      lineNumber: 5867,
      columnNumber: 7
    }, this);
  };
  const renderEnrolls = () => {
    if (isDataTableLoading) {
      return /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: isDataTableLoading,
          failure: false,
          data: "Enrollment Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5900,
          columnNumber: 9
        },
        this
      );
    }
    const tabFilteredEnrolls = getTabFilteredEnrolls();
    const tabIndexOfLastItem = currentPage * itemsPerPage;
    const tabIndexOfFirstItem = tabIndexOfLastItem - itemsPerPage;
    const tabCurrentItems = tabFilteredEnrolls.slice(
      tabIndexOfFirstItem,
      tabIndexOfLastItem
    );
    const tabTotalPages = Math.ceil(tabFilteredEnrolls.length / itemsPerPage);
    if (!tabFilteredEnrolls.length) {
      return /* @__PURE__ */ jsxDEV("div", { className: "col-span-full py-20 bg-white rounded-2xl shadow-sm text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-300 mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "w-16 h-16 mx-auto",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "1.5",
                d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 11a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 5927,
                columnNumber: 15
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5921,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5920,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-600", children: activeTab === "pending" ? "No pending enrollments found" : "No contacted enrollments found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5935,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-1", children: activeTab === "pending" ? "All enrollments have been contacted" : "Try switching to the Pending tab or adjust your search" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5940,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5919,
        columnNumber: 9
      }, this);
    }
    const SelectionHeader = () => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4 px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          Checkbox,
          {
            checked: selectAll,
            onChange: handleSelectAll,
            indeterminate: selectedEnrollments.length > 0 && selectedEnrollments.length < tabFilteredEnrolls.length
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 5953,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500", children: selectedEnrollments.length > 0 ? `${selectedEnrollments.length} selected` : "Select All" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5961,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5952,
        columnNumber: 9
      }, this),
      selectedEnrollments.length > 0 && /* @__PURE__ */ jsxDEV(
        Button,
        {
          type: "primary",
          size: "small",
          icon: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 5978,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 5972,
              columnNumber: 9
            },
            this
          ),
          onClick: handleBulkStatusUpdate,
          className: "bg-violet-600 hover:bg-violet-700 border-violet-600",
          children: [
            "Bulk Update (",
            selectedEnrollments.length,
            ")"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5968,
          columnNumber: 7
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
      lineNumber: 5951,
      columnNumber: 5
    }, this);
    if (viewMode === "grid") {
      return /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(SelectionHeader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5998,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6", children: tabCurrentItems.map(renderEnrollmentCard) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 5999,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 5997,
        columnNumber: 9
      }, this);
    }
    if (viewMode === "list") {
      return /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(SelectionHeader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6009,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: tabCurrentItems.map(
          (e) => /* @__PURE__ */ jsxDEV(EnrollRow, { enroll: e }, e.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6012,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6010,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 6008,
        columnNumber: 9
      }, this);
    }
    const tableColumns = [
      {
        key: "selection",
        header: /* @__PURE__ */ jsxDEV(
          Checkbox,
          {
            checked: selectAll,
            onChange: handleSelectAll,
            indeterminate: selectedEnrollments.length > 0 && selectedEnrollments.length < getTabFilteredEnrolls().length
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6024,
            columnNumber: 7
          },
          this
        ),
        render: (record) => /* @__PURE__ */ jsxDEV(
          Checkbox,
          {
            checked: selectedEnrollments.includes(record._id),
            onChange: () => handleSelectEnrollment(record._id)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6034,
            columnNumber: 7
          },
          this
        )
      },
      ...columns
    ];
    return /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-hidden rounded-2xl border border-gray-200 shadow-sm bg-white", children: /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        catcher: "_id",
        data: TableEnrolls.filter(
          (e) => activeTab === "contacted" ? e.status && e.status !== "Not Contacted" : !e.status || e.status === "Not Contacted"
        ),
        columns,
        exportedPdfName: "MobileAppEnrollments",
        exportedFileName: "MobileAppEnrollments.csv"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 6045,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
      lineNumber: 6044,
      columnNumber: 7
    }, this);
  };
  const handleEnrollClick = (item) => {
    console.log("=== handleEnrollClick called with item ===", item);
    setCurrentGroup(item);
    const userId = item.user_id?._id || "";
    const groupId = item.group_id?._id || item.group_id?.id || "";
    const referredCustomerId = item.referred_customer?._id || "";
    const referredLeadId = item.referred_lead?._id || "";
    const agentId = item.agent?._id || "";
    setFormData({
      user_id: userId,
      group_id: groupId,
      payment_type: item.payment_type || "",
      referred_type: item.referred_type || "",
      chit_asking_month: item.chit_asking_month || "",
      referred_customer: referredCustomerId,
      referred_lead: referredLeadId,
      agent: agentId,
      no_of_tickets: item.no_of_tickets || 1
    });
    setEnrollmentStep("verify");
    setShowModal(true);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const {
      no_of_tickets,
      group_id,
      user_id,
      payment_type,
      referred_customer,
      referred_type,
      agent,
      referred_lead,
      chit_asking_month
    } = formData;
    const ticketsCount = parseInt(no_of_tickets || 1, 10);
    const ticketEntries = availableTicketsAdd.slice(0, ticketsCount).map((ticketNumber) => ({
      group_id,
      user_id,
      payment_type,
      referred_type,
      chit_asking_month: formData.chit_asking_month,
      referred_customer,
      referred_lead,
      agent,
      no_of_tickets: ticketsCount,
      tickets: ticketNumber
    }));
    try {
      setLoading(true);
      for (const ticketEntry of ticketEntries) {
        await api.post("/enroll/add-enroll", ticketEntry, {
          headers: { "Content-Type": "application/json" }
        });
      }
      if (currentGroup?._id) {
        await api.delete(
          `/mobile-app-enroll/delete-mobile-app-enroll/${currentGroup._id}`,
          {
            data: { deleted_by: admin, deleted_at: /* @__PURE__ */ new Date() }
          }
        );
      }
      setAlertConfig({
        visibility: true,
        message: "User Enrolled Successfully",
        type: "success"
      });
      setShowModal(false);
      setFormData({
        group_id: "",
        user_id: "",
        no_of_tickets: "",
        referred_type: "",
        payment_type: "",
        referred_customer: "",
        agent: "",
        referred_lead: "",
        chit_asking_month: ""
      });
      fetchAllEnrollmentData();
    } catch (error) {
      console.error("Error enrolling user:", error);
      setAlertConfig({
        visibility: true,
        message: "Enrollment failed",
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get-agent");
        setAgents(response.data);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const fetchLeads = async () => {
      try {
        const response = await api.get("/lead/get-lead");
        setLeads(response.data);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchLeads();
  }, []);
  const handleVerify = async () => {
    const {
      user_id,
      group_id,
      agent,
      referred_customer,
      referred_lead,
      referred_type
    } = formData;
    if (!user_id || !group_id) {
      notification.warning({
        message: "Please select both Group and Customer before verifying."
      });
      return;
    }
    try {
      const response = await api.get(`/enroll/get-enroll-check`, {
        params: { user_id, group_id }
      });
      const selectedUser = users.find((u) => u._id === user_id);
      const selectedGroup2 = groups.find((g) => g._id === group_id);
      const selectedAgent = agents.find((a) => a._id === agent);
      const selectedReferredCustomer = users.find(
        (u) => u._id === referred_customer
      );
      const selectedReferredLead = leads?.find?.(
        (l) => l._id === referred_lead
      );
      if (response?.data) {
        const agentName = typeof response.data.agent === "object" ? response.data.agent?.name : null;
        const referredCustomerName = typeof response.data.referred_customer === "object" ? response.data.referred_customer?.full_name : null;
        const referredLeadName = typeof response.data.referred_lead === "object" ? response.data.referred_lead?.lead_name : null;
        const referredInfoParts = [];
        if (agentName)
          referredInfoParts.push(
            ` Already referred by Agent Name: ${agentName}`
          );
        if (referredCustomerName)
          referredInfoParts.push(
            ` Already referred by Customer Name: ${referredCustomerName}`
          );
        if (referredLeadName)
          referredInfoParts.push(
            ` Already referred by Lead Name: ${referredLeadName}`
          );
        if (referredInfoParts.length === 0)
          referredInfoParts.push("Enrollment exists with no referral info.");
        setFormData((prev) => ({
          ...prev,
          no_of_tickets: response?.data?.no_of_tickets ?? prev.no_of_tickets,
          payment_type: response?.data?.payment_type ?? prev.payment_type,
          referred_customer: response?.data?.referred_customer ?? prev.referred_customer,
          referred_lead: response?.data?.referred_lead ?? prev.referred_lead,
          referred_type: prev.referred_type || response?.data?.referred_type || (response.data?.agent ? "Agent" : response.data?.referred_customer ? "Customer" : response.data?.referred_lead ? "Leads" : "")
        }));
        let selectedBy = "Unknown";
        if (referred_type === "Agent")
          selectedBy = selectedAgent?.name || "Unknown Agent";
        else if (referred_type === "Customer")
          selectedBy = selectedReferredCustomer?.full_name || "Unknown Customer";
        else if (referred_type === "Leads")
          selectedBy = selectedReferredLead?.lead_name || "Unknown Lead";
        setIsExistingEnrollment(true);
        setEnrollmentStep("continue");
        notification.warning({
          message: /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                fontWeight: "bold",
                fontSize: "1.25rem",
                marginBottom: "10px"
              },
              children: [
                'Customer Name: "',
                selectedUser?.full_name,
                '"',
                /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6307,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("hr", { style: { margin: "10px 0", borderTop: "1px solid #ccc" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6308,
                  columnNumber: 15
                }, this),
                'Group Name: "',
                selectedGroup2?.group_name,
                '"',
                /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6310,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("hr", { style: { margin: "10px 0", borderTop: "1px solid #ccc" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6311,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6299,
              columnNumber: 11
            },
            this
          ),
          description: /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: "bold", fontSize: "1.25rem" }, children: referredInfoParts.map(
            (part, index) => /* @__PURE__ */ jsxDEV("span", { children: [
              part,
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6319,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "hr",
                {
                  style: { margin: "10px 0", borderTop: "1px solid #ccc" }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6320,
                  columnNumber: 19
                },
                this
              )
            ] }, index, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6317,
              columnNumber: 13
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6315,
            columnNumber: 11
          }, this),
          duration: 30
        });
        setIsExistingEnrollment(true);
        setIsVerified(true);
        setEnrollmentStep("continue");
      } else {
        setIsExistingEnrollment(false);
        setIsVerified(true);
        setEnrollmentStep("continue");
        notification.success({
          message: `Eligible for Enrollment`,
          description: `User "${selectedUser?.full_name}" can be enrolled in "${selectedGroup2?.group_name}".`,
          duration: 6
        });
      }
    } catch (err) {
      console.error("Verification error:", err);
      notification.error({
        message: "Error checking enrollment",
        description: err.response?.data?.message || "Something went wrong"
      });
    }
  };
  const handleMultiStep = async (e) => {
    e.preventDefault();
    if (enrollmentStep === "verify") {
      await handleVerify();
    } else if (enrollmentStep === "continue") {
      setEnrollmentStep("submit");
    } else if (enrollmentStep === "submit") {
      handleSubmit(e);
    }
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  useEffect(() => {
    if (formData.group_id) {
      const fetchTickets = async () => {
        try {
          const response = await api.post(
            `/enroll/get-next-tickets/${formData.group_id}`
          );
          setAvailableTicketsAdd(response.data.availableTickets || []);
        } catch (error) {
          console.error("Error fetching next tickets:", error);
          setAvailableTicketsAdd([]);
        }
      };
      fetchTickets();
    } else {
      setAvailableTicketsAdd([]);
    }
  }, [formData.group_id]);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "mobile_enroll_code", header: "Mobile Enroll Code" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  if (allEnrollUrl) {
    columns.push({ key: "group_name", header: "Enrolled Group" });
  }
  columns.push(
    { key: "referred_type", header: "Referred Type" },
    { key: "payment_type", header: "Payment Type" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "referred_by", header: "Referred By" },
    { key: "status", header: "Contact Status" },
    { key: "follow_up_date", header: "Follow Up Date" },
    { key: "remark", header: "Remark" },
    { key: "action", header: "Action" }
  );
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };
  const validate = (type) => {
    const newErrors = {};
    const data = type === "addEnrollment" ? formData : updateFormData;
    const noOfTickets = type === "addEnrollment" ? "no_of_tickets" : "tickets";
    if (!data.group_id.trim()) {
      newErrors.group_id = "Please select a group";
    }
    if (!data.user_id) {
      newErrors.user_id = "Please select a customer";
    }
    if (availableTicketsAdd.length > 0) {
      if (!data[noOfTickets] || data[noOfTickets] <= 0 || isNaN(data[noOfTickets])) {
        newErrors[noOfTickets] = "Please enter number of tickets";
      } else if (data[noOfTickets] > availableTicketsAdd.length) {
        newErrors[noOfTickets] = `Maximum ${availableTicketsAdd.length} tickets allowed`;
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };
  const handleUpdateModalOpen = async (enrollId) => {
    try {
      const response = await api.get(
        `/mobile-app-enroll/get-mobile-app-enroll-by-id/${enrollId}`
      );
      setCurrentUpdateGroup(response.data);
      console.info(response.data?.agent?._id, "test customer");
      setUpdateFormData({
        group_id: response.data?.group_id?._id,
        user_id: response.data?.user_id?._id,
        tickets: response.data?.tickets,
        payment_type: response.data?.payment_type,
        referred_customer: response.data?.referred_customer?._id,
        agent: response.data?.agent?._id,
        referred_lead: response.data?.referred_lead?._id,
        referred_type: response.data?.referred_type,
        chit_asking_month: response.data?.chit_asking_month || ""
      });
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching enrollment:", error);
    }
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(
        `/mobile-app-enroll/get-mobile-app-enroll-by-id/${groupId}`
      );
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteGroup = async () => {
    if (currentGroup) {
      try {
        await api.delete(
          `/mobile-app-enroll/delete-mobile-app-enroll/${currentGroup._id}`,
          {
            data: { deleted_by: admin, deleted_at: /* @__PURE__ */ new Date() }
          }
        );
        setShowModalDelete(false);
        setCurrentGroup(null);
        setAlertConfig({
          visibility: true,
          message: "Enroll deleted successfully",
          type: "success"
        });
        fetchAllEnrollmentData();
      } catch (error) {
        console.error("Error deleting group:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        `/mobile-app-enroll/update-mobile-app-enroll/${currentUpdateGroup._id}`,
        updateFormData
      );
      setShowModalUpdate(false);
      setAlertConfig({
        visibility: true,
        message: "Enrollment Updated Successfully",
        type: "success"
      });
      fetchAllEnrollmentData();
    } catch (error) {
      console.error("Error updating enroll:", error);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6553,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 6557,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((p) => ({ ...p, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6558,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 bg-slate-50 min-h-screen", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6565,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-900 tracking-tight", children: "Mobile App Enrollments" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6571,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Manage and track mobile enrollment requests" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6574,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6570,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3 w-full lg:w-auto", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex bg-slate-100 rounded-xl p-1 gap-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setActiveTab("pending");
                      setSelectedEnrollments([]);
                      setSelectAll(false);
                    },
                    className: `px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === "pending" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: [
                      "Pending (",
                      filteredEnrolls.filter(
                        (e) => e.status === "Not Contacted" || !e.status
                      ).length,
                      ")"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 6581,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setActiveTab("contacted");
                      setSelectedEnrollments([]);
                      setSelectAll(false);
                    },
                    className: `px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === "contacted" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: [
                      "Contacted (",
                      filteredEnrolls.filter(
                        (e) => e.status && e.status !== "Not Contacted"
                      ).length,
                      ")"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 6597,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6580,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 bg-slate-100 rounded-xl p-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setViewMode("grid");
                      setSelectedEnrollments([]);
                      setSelectAll(false);
                    },
                    className: `p-2 rounded-lg transition-all ${viewMode === "grid" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: /* @__PURE__ */ jsxDEV(MdGridView, { className: "text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6624,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 6616,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setViewMode("list");
                      setSelectedEnrollments([]);
                      setSelectAll(false);
                    },
                    className: `p-2 rounded-lg transition-all ${viewMode === "list" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: /* @__PURE__ */ jsxDEV(MdViewList, { className: "text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6634,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 6626,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setViewMode("table");
                      setSelectedEnrollments([]);
                      setSelectAll(false);
                    },
                    className: `p-2 rounded-lg transition-all ${viewMode === "table" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: /* @__PURE__ */ jsxDEV(MdOutlineTableRows, { className: "text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6644,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 6636,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6615,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6579,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6569,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-5", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                placeholder: "Search by name, phone or group",
                value: searchQuery,
                allowClear: true,
                onChange: (e) => {
                  const val = e.target.value;
                  setSearchQuery(val);
                  if (val === "") {
                    setSearchTerm("");
                  }
                },
                onPressEnter: () => setSearchTerm(searchQuery),
                className: "h-10 w-80 rounded-lg border-gray-300 focus:border-violet-500 focus:ring-2 focus:ring-violet-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6652,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(SearchOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6668,
                  columnNumber: 25
                }, this),
                onClick: () => setSearchTerm(searchQuery),
                className: "h-10 bg-violet-600 hover:bg-violet-700 border-violet-600 flex items-center justify-center",
                children: "Search"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6666,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6651,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6568,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border-l-4 border-blue-500 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500 font-medium", children: "Total Enrollments" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6680,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-gray-800", children: summaryStats.totalEnrollments }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6683,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6679,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border-l-4 border-green-500 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500 font-medium", children: "Total Tickets" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6688,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-gray-800", children: summaryStats.totalTickets }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6691,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6687,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border-l-4 border-purple-500 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500 font-medium", children: "Unique Customers" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6696,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-gray-800", children: summaryStats.uniqueCustomers }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6699,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6695,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border-l-4 border-orange-500 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500 font-medium", children: "Unique Groups" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6704,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-gray-800", children: summaryStats.uniqueGroups }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6707,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6703,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6678,
          columnNumber: 13
        }, this),
        activeTab === "contacted" && !isDataTableLoading && /* @__PURE__ */ jsxDEV(ContactSummaryDashboard, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6715,
          columnNumber: 13
        }, this),
        renderEnrolls(),
        viewMode !== "table" && getTabFilteredEnrolls().length > itemsPerPage && /* @__PURE__ */ jsxDEV(
          SimplePagination,
          {
            currentPage,
            totalPages: Math.ceil(
              getTabFilteredEnrolls().length / itemsPerPage
            ),
            onPageChange: setCurrentPage
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6722,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 6564,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
      lineNumber: 6552,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setShowModal(false);
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6742,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Group ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6752,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6748,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Group",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "group_id",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.group_id || void 0,
                  onChange: (value) => handleAntDSelect("group_id", value),
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6770,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6754,
                  columnNumber: 17
                },
                this
              ),
              errors.group_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors.group_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6776,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6747,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Customer ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6784,
                      columnNumber: 28
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6780,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "user_id",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.user_id || void 0,
                  onChange: (value) => handleAntDSelect("user_id", value),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                      user.full_name,
                      " |",
                      " ",
                      user.phone_number ? user.phone_number : "No Number"
                    ] }, user._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6802,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6786,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6809,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6779,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "payment_type",
                  children: [
                    "Select Payment Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6817,
                      columnNumber: 39
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6813,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Payment Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "payment_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.payment_type || void 0,
                  onChange: (value) => handleAntDSelect("payment_type", value),
                  children: ["Daily", "Weekly", "Monthly"].map(
                    (pType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: pType, children: pType }, pType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6832,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6819,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6812,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: "Chit Asking Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 6840,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "p-2 border rounded w-full",
                  value: selectedDate,
                  onChange: (e) => {
                    setSelectedDate(e.target.value);
                    setFormData((prev) => ({
                      ...prev,
                      chit_asking_month: e.target.value
                    }));
                  },
                  min: formatToYearMonth(currentYear, currentMonth)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6843,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6839,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Select Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6863,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6859,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Referred Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.referred_type || void 0,
                  onChange: (value) => handleAntDSelect("referred_type", value),
                  children: [
                    "Self Joining",
                    "Customer",
                    "Employee",
                    "Leads",
                    "Others"
                  ].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6884,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6865,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6858,
              columnNumber: 15
            }, this),
            formData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Select Referred Customer",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6898,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6893,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Referred Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_customer",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.referred_customer || void 0,
                  onChange: (value) => handleAntDSelect("referred_customer", value),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                      user.full_name,
                      " |",
                      " ",
                      user.phone_number ? user.phone_number : "No Number"
                    ] }, user._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6918,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6900,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6892,
              columnNumber: 15
            }, this),
            formData.referred_type === "Leads" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Select Referred Leads",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6933,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6928,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Referred Leads",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_lead",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.referred_lead || void 0,
                  onChange: (value) => handleAntDSelect("referred_lead", value),
                  children: leads.map(
                    (lead) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lead._id, children: [
                      lead.lead_name,
                      " | ",
                      lead.lead_phone
                    ] }, lead._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6953,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6935,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6927,
              columnNumber: 15
            }, this),
            formData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Select Referred Employee",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6967,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6962,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`,
                  placeholder: "Select Or Search Referred Employee",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "agent",
                  filterOption: (input, option) => {
                    if (!option || !option.children) return false;
                    return option.children.toString().toLowerCase().includes(input.toLowerCase());
                  },
                  value: formData?.agent || void 0,
                  onChange: (value) => handleAntDSelect("agent", value),
                  children: agents.map(
                    (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                      agent.name,
                      " | ",
                      agent.phone_number
                    ] }, agent._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 6986,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6969,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6961,
              columnNumber: 15
            }, this),
            formData.group_id ? availableTicketsAdd.length > 0 ? /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Number of Tickets ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7e3,
                      columnNumber: 41
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 6996,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "no_of_tickets",
                  value: formData?.no_of_tickets,
                  id: "name",
                  onChange: (e) => {
                    handleChange(e);
                  },
                  placeholder: "Enter the Number of Tickets",
                  required: true,
                  max: availableTicketsAdd.length,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7002,
                  columnNumber: 21
                },
                this
              ),
              errors.no_of_tickets && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors.no_of_tickets }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7016,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "mt-10 flex items-center justify-center text-sm text-blue-900", children: [
                "Only ",
                availableTicketsAdd.length,
                " tickets left"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7020,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 6995,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-center text-red-600", children: "Group is Full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7025,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-center text-red-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7028,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center p-4 max-w-full bg-white rounded-lg shadow-sm space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
                /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { color: "green", className: "w-10 h-10" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7033,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: "WhatsApp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7034,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7032,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: whatsappEnable,
                    className: "text-green-500 checked:ring-2 checked:ring-green-700 rounded-full w-4 h-4"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                    lineNumber: 7039,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: "Send Via Whatsapp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7044,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7038,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7031,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                disabled: loading || enrollmentStep === "submit" && (!isVerified || availableTicketsAdd.length === 0),
                onClick: handleMultiStep,
                className: `w-1/4 text-white font-medium rounded-lg text-sm px-5 py-2.5 text-center ${loading ? "bg-gray-400 cursor-not-allowed" : enrollmentStep === "verify" ? "bg-gray-600 hover:bg-gray-700" : enrollmentStep === "continue" ? "bg-green-600 hover:bg-green-700" : "bg-blue-700 hover:bg-blue-800"}`,
                children: loading ? "Processing..." : enrollmentStep === "verify" ? "Verify" : enrollmentStep === "continue" ? "Continue" : "Submit"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7048,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7047,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 6745,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 6741,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 6734,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => {
          setShowModalUpdate(false);
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7080,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "group_id",
                  children: [
                    "Group ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7089,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7085,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "group_id",
                  id: "group_id",
                  value: updateFormData.group_id,
                  onChange: handleInputChange,
                  required: true,
                  disabled: true,
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7100,
                      columnNumber: 19
                    }, this),
                    groups.map(
                      (group) => /* @__PURE__ */ jsxDEV("option", { value: group._id, children: group.group_name }, group._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                        lineNumber: 7102,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7091,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7084,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "user_id",
                  children: [
                    "Customer ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7114,
                      columnNumber: 28
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7110,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "user_id",
                  id: "user_id",
                  value: updateFormData.user_id,
                  onChange: handleInputChange,
                  required: true,
                  disabled: true,
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7125,
                      columnNumber: 19
                    }, this),
                    users.map(
                      (user) => /* @__PURE__ */ jsxDEV("option", { value: user._id, children: user.full_name }, user._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                        lineNumber: 7127,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7116,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7133,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7109,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "payment_type",
                  children: [
                    "Select Payment Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7141,
                      columnNumber: 39
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7137,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Payment Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "payment_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.payment_type || void 0,
                  onChange: (value) => handleAntInputDSelect("payment_type", value),
                  children: ["Daily", "Weekly", "Monthly"].map(
                    (pType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: pType, children: pType }, pType.toLowerCase(), false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7158,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7143,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7136,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Chit Asking Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7165,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "p-2 border rounded w-full",
                  value: updateFormData.chit_asking_month,
                  onChange: (e) => setUpdateFormData((prev) => ({
                    ...prev,
                    chit_asking_month: e.target.value
                  }))
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7168,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7164,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Select Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7186,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7182,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Referred Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.referred_type || void 0,
                  onChange: (value) => handleAntInputDSelect("referred_type", value),
                  children: [
                    "Self Joining",
                    "Customer",
                    "Employee",
                    "Leads",
                    "Others"
                  ].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7209,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7188,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7181,
              columnNumber: 15
            }, this),
            updateFormData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Select Referred Customer",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7223,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7218,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Or Search Referred Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_customer",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.referred_customer || void 0,
                  onChange: (value) => handleAntInputDSelect("referred_customer", value),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7243,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7225,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7217,
              columnNumber: 15
            }, this),
            updateFormData.referred_type === "Leads" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Select Referred Leads",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7257,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7252,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Or Search Referred Lead",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_lead",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.referred_lead || void 0,
                  onChange: (value) => handleAntInputDSelect("referred_lead", value),
                  children: leads.map(
                    (lead) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lead._id, children: lead.lead_name }, lead._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7277,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7259,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7251,
              columnNumber: 15
            }, this),
            updateFormData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Select Referred Employee",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7291,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7286,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select Or Search Referred Employee",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "agent",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.agent || void 0,
                  onChange: (value) => handleAntInputDSelect("agent", value),
                  children: agents.map(
                    (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: agent.name }, agent._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                      lineNumber: 7309,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7293,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7285,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7317,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7083,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 7079,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 7072,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Sure want to remove this Enrollment ?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7336,
            columnNumber: 13
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteGroup();
              },
              className: "space-y-6",
              children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                  children: "Remove"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7347,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7340,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 7335,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 7328,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-xl text-blue-600", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-5 h-5",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7369,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7363,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7362,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: statusUpdateData.isBulk ? `Bulk Update (${statusUpdateData.selectedIds?.length || 0} enrollments)` : "Update Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7378,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: statusUpdateData.isBulk ? `Update status for ${statusUpdateData.selectedIds?.length || 0} selected enrollments` : "Change the contact status and remark for this enrollment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7383,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7377,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
          lineNumber: 7361,
          columnNumber: 11
        }, this),
        open: showStatusUpdateModal,
        onCancel: () => {
          setShowStatusUpdateModal(false);
          setStatusUpdateData({
            _id: "",
            status: "",
            remark: "",
            follow_up_date: "",
            isBulk: false,
            selectedIds: []
          });
        },
        footer: null,
        width: 700,
        className: "rounded-2xl",
        children: [
          /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], className: "mt-4", children: /* @__PURE__ */ jsxDEV(Col, { span: 24, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border border-gray-100 rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
                "Status ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7413,
                  columnNumber: 30
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7412,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Select Status",
                  value: statusUpdateData.status || void 0,
                  onChange: (value) => setStatusUpdateData((prev) => ({
                    ...prev,
                    status: value
                  })),
                  className: "w-full h-11",
                  options: STATUS_OPTIONS.map((opt) => ({
                    label: opt,
                    value: opt
                  }))
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7415,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7411,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider", children: "Remark" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7433,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input.TextArea,
                {
                  rows: 3,
                  placeholder: "Add a remark...",
                  value: statusUpdateData.remark,
                  onChange: (e) => setStatusUpdateData((prev) => ({
                    ...prev,
                    remark: e.target.value
                  })),
                  className: "w-full resize-none rounded-lg border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7436,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7432,
              columnNumber: 19
            }, this),
            statusUpdateData.status === "Follow Up" && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-purple-600 uppercase tracking-wider", children: [
                "Follow Up Date ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7453,
                  columnNumber: 40
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7452,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                DatePicker,
                {
                  value: statusUpdateData.follow_up_date ? dayjs(statusUpdateData.follow_up_date) : null,
                  onChange: (_, dateString) => setStatusUpdateData((prev) => ({
                    ...prev,
                    follow_up_date: dateString
                  })),
                  className: "w-full h-11 rounded-lg border-purple-300 hover:border-purple-400 focus:border-purple-500",
                  format: "YYYY-MM-DD",
                  placeholder: "Select follow-up date",
                  disabledDate: (current) => current && current < dayjs().startOf("day")
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                  lineNumber: 7455,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-purple-500 mt-1", children: "Select a future date for the follow-up" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7474,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
              lineNumber: 7451,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7410,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7409,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7408,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7407,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-6 pt-4 border-t border-slate-200", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "default",
                onClick: () => {
                  setShowStatusUpdateModal(false);
                  setStatusUpdateData({
                    _id: "",
                    status: "",
                    remark: "",
                    follow_up_date: "",
                    isBulk: false,
                    selectedIds: []
                  });
                },
                className: "h-11 px-6 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-xl font-medium",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7485,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                loading: isStatusUpdating,
                onClick: handleStatusUpdateSubmit,
                className: "h-11 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold rounded-xl shadow-md shadow-blue-200 transition-all",
                children: statusUpdateData.isBulk ? `Update ${statusUpdateData.selectedIds?.length || 0} Enrollments` : "Update Status"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
                lineNumber: 7502,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
            lineNumber: 7484,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
        lineNumber: 7359,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
    lineNumber: 6551,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx",
    lineNumber: 6550,
    columnNumber: 5
  }, this);
};
_s(MobileAppEnroll, "CZ7XdkUQMT6tRSSg9PAymZ70HNc=");
_c = MobileAppEnroll;
export default MobileAppEnroll;
var _c;
$RefreshReg$(_c, "MobileAppEnroll");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/MobileAppEnroll.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOHpJUSxTQThpREEsVUE5aURBOzJCQTl6SVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFPQSxPQUFPQSxpQkFBaUI7QUFDeEIsU0FBU0Msd0JBQXdCO0FBKzVDakMsU0FBU0MsV0FBV0MsVUFBVUMsbUJBQW1CO0FBQ2pELE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFFdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxrQ0FBa0M7QUFDekMsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxzQkFBc0I7QUFFL0I7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBdEIsU0FBU3VCO0FBQUFBLEVBQ1RDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFtMkZQLE1BQU1DLDhCQUE4QjtBQUFBLEVBQ2xDO0FBQUEsSUFDRUMsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsSUFDUEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLE1BQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLE1BQUs7QUFBQSxRQUNMLFFBQU87QUFBQSxRQUNQLFNBQVE7QUFBQSxRQUVSO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxlQUFjO0FBQUEsWUFDZCxnQkFBZTtBQUFBLFlBQ2YsYUFBWTtBQUFBLFlBQ1osR0FBRTtBQUFBO0FBQUEsVUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJMk47QUFBQTtBQUFBLE1BVjdOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFUCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsTUFDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsTUFBSztBQUFBLFFBQ0wsUUFBTztBQUFBLFFBQ1AsU0FBUTtBQUFBLFFBRVI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGVBQWM7QUFBQSxZQUNkLGdCQUFlO0FBQUEsWUFDZixhQUFZO0FBQUEsWUFDWixHQUFFO0FBQUE7QUFBQSxVQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk2VztBQUFBO0FBQUEsTUFWL1c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUE7QUFBQSxFQUVKO0FBQUEsRUFDQTtBQUFBLElBQ0VQLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLElBQ1BDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxNQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixNQUFLO0FBQUEsUUFDTCxRQUFPO0FBQUEsUUFDUCxTQUFRO0FBQUEsUUFFUjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsZUFBYztBQUFBLFlBQ2QsZ0JBQWU7QUFBQSxZQUNmLGFBQVk7QUFBQSxZQUNaLEdBQUU7QUFBQTtBQUFBLFVBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWlEO0FBQUE7QUFBQSxNQVZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZQTtBQUFBLEVBRUo7QUFBQSxFQUNBO0FBQUEsSUFDRVAsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsSUFDUEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLE1BQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLE1BQUs7QUFBQSxRQUNMLFFBQU87QUFBQSxRQUNQLFNBQVE7QUFBQSxRQUVSO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxlQUFjO0FBQUEsWUFDZCxnQkFBZTtBQUFBLFlBQ2YsYUFBWTtBQUFBLFlBQ1osR0FBRTtBQUFBO0FBQUEsVUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJbUQ7QUFBQTtBQUFBLE1BVnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFUCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsTUFDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsTUFBSztBQUFBLFFBQ0wsUUFBTztBQUFBLFFBQ1AsU0FBUTtBQUFBLFFBRVI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGVBQWM7QUFBQSxZQUNkLGdCQUFlO0FBQUEsWUFDZixhQUFZO0FBQUEsWUFDWixHQUFFO0FBQUE7QUFBQSxVQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkwRTtBQUFBO0FBQUEsTUFWNUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUE7QUFBQSxFQUVKO0FBQUM7QUFHSCxNQUFNQyxpQkFBaUI7QUFBQSxFQUNyQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQVU7QUFHWixNQUFNQyxrQkFBa0JBLE1BQU07QUFBQUMsS0FBQTtBQUM1QixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTdDLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUM4QyxPQUFPQyxRQUFRLElBQUkvQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0QsY0FBY0MsZUFBZSxJQUFJakQsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ2tELGlCQUFpQkMsa0JBQWtCLElBQUluRCxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDb0QsZUFBZUMsZ0JBQWdCLElBQUlyRCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDc0QsV0FBV0MsWUFBWSxJQUFJdkQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3dELGlCQUFpQkMsa0JBQWtCLElBQUl6RCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDMEQsb0JBQW9CQyxxQkFBcUIsSUFBSTNELFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUM0RCxrQkFBa0JDLG1CQUFtQixJQUFJN0QsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzhELGlCQUFpQkMsa0JBQWtCLElBQUkvRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDZ0UsY0FBY0MsZUFBZSxJQUFJakUsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ2tFLHFCQUFxQkMsc0JBQXNCLElBQUluRSxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDb0UsU0FBU0MsVUFBVSxJQUFJckUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3NFLG9CQUFvQkMscUJBQXFCLElBQUl2RSxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDd0UsUUFBUUMsU0FBUyxJQUFJekUsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDMEUsY0FBY0MsZUFBZSxJQUFJM0UsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzRFLE9BQU9DLFFBQVEsSUFBSTdFLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUM4RSxRQUFRQyxTQUFTLElBQUkvRSxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDZ0YsZ0JBQWdCQyxpQkFBaUIsSUFBSWpGLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNrRixnQkFBZ0JDLGlCQUFpQixJQUFJbkYsU0FBUyxRQUFRO0FBQzdELFFBQU0sQ0FBQ29GLGFBQWFDLGNBQWMsSUFBSXJGLFNBQVM7QUFBQSxJQUM3Q3NGLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0Msc0JBQXNCQyx1QkFBdUIsSUFBSTFGLFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUMyRixPQUFPQyxRQUFRLElBQUk1RixTQUFTLEVBQUU7QUFHckMsUUFBTSxDQUFDNkYsV0FBV0MsWUFBWSxJQUFJOUYsU0FBUyxTQUFTO0FBQ3BELFFBQU0sQ0FBQytGLFVBQVVDLFdBQVcsSUFBSWhHLFNBQVMsTUFBTTtBQUMvQyxRQUFNLENBQUNpRyxhQUFhQyxjQUFjLElBQUlsRyxTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDbUcsWUFBWSxJQUFJbkcsU0FBUyxDQUFDO0FBQ2pDLFFBQU0sQ0FBQ29HLFlBQVlDLGFBQWEsSUFBSXJHLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNzRyxhQUFhQyxjQUFjLElBQUl2RyxTQUFTLEVBQUU7QUFHakQsUUFBTSxDQUFDd0cscUJBQXFCQyxzQkFBc0IsSUFBSXpHLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUMwRyxXQUFXQyxZQUFZLElBQUkzRyxTQUFTLEtBQUs7QUFHaEQsUUFBTSxDQUFDNEcsdUJBQXVCQyx3QkFBd0IsSUFBSTdHLFNBQVMsS0FBSztBQUN4RSxRQUFNLENBQUM4RyxrQkFBa0JDLG1CQUFtQixJQUFJL0csU0FBUztBQUFBLElBQ3ZEZ0gsS0FBSztBQUFBLElBQ0xDLFFBQVE7QUFBQSxJQUNSQyxRQUFRO0FBQUEsSUFDUkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsRUFDZixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJdkgsU0FBUyxLQUFLO0FBRzlELFFBQU0sQ0FBQ3dILGNBQWNDLGVBQWUsSUFBSXpILFNBQVM7QUFBQSxJQUMvQzBILGtCQUFrQjtBQUFBLElBQ2xCQyxjQUFjO0FBQUEsSUFDZEMsaUJBQWlCO0FBQUEsSUFDakJDLGNBQWM7QUFBQSxFQUNoQixDQUFDO0FBRUQsUUFBTUMsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxjQUFjRixNQUFNRyxZQUFZO0FBQ3RDLFFBQU1DLGVBQWVDLE9BQU9MLE1BQU1NLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ2pFLFFBQU1DLG1CQUFtQixHQUFHTixXQUFXLElBQUlFLFlBQVk7QUFFdkQsV0FBU0ssV0FBV0MsTUFBTTtBQUN4QixVQUFNQyxPQUFPRCxLQUFLUCxZQUFZO0FBQzlCLFVBQU1TLFFBQVEsSUFBSUYsS0FBS0osU0FBUyxJQUFJLENBQUMsR0FBR08sTUFBTSxFQUFFO0FBQ2hELFVBQU1DLE1BQU0sSUFBSUosS0FBS0ssUUFBUSxDQUFDLEdBQUdGLE1BQU0sRUFBRTtBQUN6QyxXQUFPLEdBQUdGLElBQUksSUFBSUMsS0FBSyxJQUFJRSxHQUFHO0FBQUEsRUFDaEM7QUFFQSxRQUFNRSxZQUFZQSxDQUFDQyxlQUFlO0FBQ2hDLFVBQU0sQ0FBQ04sTUFBTUMsS0FBSyxJQUFJSyxXQUFXQyxNQUFNLEdBQUc7QUFDMUMsV0FBTztBQUFBLE1BQ0xQO0FBQUFBLE1BQ0FDLE9BQU9QLE9BQU9jLFNBQVNQLEtBQUssQ0FBQyxFQUFFTCxTQUFTLEdBQUcsR0FBRztBQUFBLE1BQzlDYSxXQUFXQyxXQUFXRixTQUFTUCxLQUFLLElBQUksQ0FBQztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBLFFBQU1VLG9CQUFvQkEsQ0FBQ1gsTUFBTUMsVUFBVTtBQUN6QyxXQUFPLEdBQUdELElBQUksSUFBSU4sT0FBT08sS0FBSyxFQUFFTCxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDbEQ7QUFFQSxRQUFNZ0Isb0JBQW9CQSxDQUFDTixlQUFlO0FBQ3hDLFVBQU0sRUFBRU4sTUFBTUMsTUFBTSxJQUFJSSxVQUFVQyxVQUFVO0FBQzVDLFVBQU1PLFlBQVksSUFBSXZCLEtBQUtVLE1BQU1RLFNBQVNQLEtBQUssSUFBSSxHQUFHLENBQUM7QUFDdkQsVUFBTWEsVUFBVSxJQUFJeEIsS0FBS1UsTUFBTVEsU0FBU1AsS0FBSyxHQUFHLENBQUM7QUFFakQsV0FBTztBQUFBLE1BQ0xjLFdBQVdqQixXQUFXZSxTQUFTO0FBQUEsTUFDL0JHLFNBQVNsQixXQUFXZ0IsT0FBTztBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUVBLFFBQU0sQ0FBQ0csY0FBY0MsZUFBZSxJQUFJM0osU0FBUyxFQUFFO0FBRW5ELFFBQU1tSixhQUFhO0FBQUEsSUFDakI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQVU7QUFHWixRQUFNLENBQUNTLFVBQVVDLFdBQVcsSUFBSTdKLFNBQVM7QUFBQSxJQUN2QzhKLFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLGVBQWU7QUFBQSxJQUNmQyxjQUFjO0FBQUEsSUFDZEMsbUJBQW1CO0FBQUEsSUFDbkJDLE9BQU87QUFBQSxJQUNQQyxlQUFlO0FBQUEsSUFDZkMsbUJBQW1CO0FBQUEsRUFDckIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJeEssU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ3lLLGdCQUFnQkMsaUJBQWlCLElBQUkxSyxTQUFTO0FBQUEsSUFDbkQ4SixVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RZLFNBQVM7QUFBQSxJQUNUVCxjQUFjO0FBQUEsSUFDZEQsZUFBZTtBQUFBLElBQ2ZFLG1CQUFtQjtBQUFBLElBQ25CQyxPQUFPO0FBQUEsSUFDUEMsZUFBZTtBQUFBLElBQ2ZDLG1CQUFtQjtBQUFBLEVBQ3JCLENBQUM7QUFFRCxRQUFNLENBQUNNLFlBQVlDLGFBQWEsSUFBSTdLLFNBQVMsRUFBRTtBQUUvQyxRQUFNOEssOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQkosa0JBQWNHLEtBQUs7QUFBQSxFQUNyQjtBQUVBakwsWUFBVSxNQUFNO0FBQ2QsVUFBTW1MLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBQy9CLFVBQU1NLFVBQVVILFNBQVNyRTtBQUN6QixRQUFJd0UsU0FBUztBQUNYNUYsZUFBU3lGLFFBQVFyRSxHQUFHO0FBQUEsSUFDdEIsT0FBTztBQUNMcEIsZUFBUyxFQUFFO0FBQUEsSUFDYjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUw3RixZQUFVLE1BQU07QUFDZCxVQUFNMEwsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU10TCxJQUFJdUwsSUFBSSx3QkFBd0I7QUFDdkQ5SSxrQkFBVTZJLFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBSixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBR0wsUUFBTU0sa0JBQWtCQSxNQUFNO0FBQzVCLFVBQU1DLFlBQVk5SSxnQkFBZ0IrSTtBQUFBQSxNQUNoQyxDQUFDQyxNQUFNQSxFQUFFakYsVUFBVWlGLEVBQUVqRixXQUFXO0FBQUEsSUFDbEM7QUFDQSxXQUFPO0FBQUEsTUFDTGtGLE9BQU9ILFVBQVVJO0FBQUFBLE1BQ2pCQyxXQUFXTCxVQUFVQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVqRixXQUFXLFdBQVcsRUFBRW1GO0FBQUFBLE1BQzdERSxZQUFZTixVQUFVQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVqRixXQUFXLFlBQVksRUFBRW1GO0FBQUFBLE1BQy9ELGFBQWFKLFVBQVVDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWpGLFdBQVcsV0FBVyxFQUFFbUY7QUFBQUEsTUFDL0RHLFdBQVdQLFVBQVVDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWpGLFdBQVcsV0FBVyxFQUFFbUY7QUFBQUEsTUFDN0RJLFVBQVVSLFVBQVVDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWpGLFdBQVcsVUFBVSxFQUFFbUY7QUFBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBR0EsUUFBTUssaUJBQWlCQSxDQUFDeEYsV0FBVztBQUNqQyxZQUFRQSxRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNUO0FBQ0UsZUFBTztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBR0EsUUFBTXlGLGdCQUFnQkEsQ0FBQ3pGLFdBQVc7QUFDaEMsWUFBUUEsUUFBTTtBQUFBLE1BQ1osS0FBSztBQUNILGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLFNBQVE7QUFBQSxZQUVSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsYUFBWTtBQUFBLGdCQUNaLEdBQUU7QUFBQTtBQUFBLGNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTJOO0FBQUE7QUFBQSxVQVY3TjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BRUosS0FBSztBQUNILGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLFNBQVE7QUFBQSxZQUVSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsYUFBWTtBQUFBLGdCQUNaLEdBQUU7QUFBQTtBQUFBLGNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTZXO0FBQUE7QUFBQSxVQVYvVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BRUosS0FBSztBQUNILGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLFNBQVE7QUFBQSxZQUVSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsYUFBWTtBQUFBLGdCQUNaLEdBQUU7QUFBQTtBQUFBLGNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWlEO0FBQUE7QUFBQSxVQVZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BRUosS0FBSztBQUNILGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLFNBQVE7QUFBQSxZQUVSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsYUFBWTtBQUFBLGdCQUNaLEdBQUU7QUFBQTtBQUFBLGNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSW1EO0FBQUE7QUFBQSxVQVZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BRUosS0FBSztBQUNILGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLFNBQVE7QUFBQSxZQUVSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsYUFBWTtBQUFBLGdCQUNaLEdBQUU7QUFBQTtBQUFBLGNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSTBFO0FBQUE7QUFBQSxVQVY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLE1BRUo7QUFDRSxlQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFHQSxRQUFNMEYsd0JBQXdCQSxNQUFNO0FBQ2xDLFFBQUk5RyxjQUFjLFdBQVc7QUFDM0IsYUFBTzNDLGdCQUFnQitJO0FBQUFBLFFBQ3JCLENBQUNXLFdBQVdBLE9BQU8zRixXQUFXLG1CQUFtQixDQUFDMkYsT0FBTzNGO0FBQUFBLE1BQzNEO0FBQUEsSUFDRixPQUFPO0FBQ0wsYUFBTy9ELGdCQUFnQitJO0FBQUFBLFFBQ3JCLENBQUNXLFdBQVdBLE9BQU8zRixVQUFVMkYsT0FBTzNGLFdBQVc7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBR0EsUUFBTTRGLHlCQUF5QkEsQ0FBQ0MsT0FBTztBQUNyQ3JHLDJCQUF1QixDQUFDc0csU0FBUztBQUMvQixVQUFJQSxLQUFLQyxTQUFTRixFQUFFLEdBQUc7QUFDckIsZUFBT0MsS0FBS2QsT0FBTyxDQUFDZ0IsU0FBU0EsU0FBU0gsRUFBRTtBQUFBLE1BQzFDO0FBQ0EsYUFBTyxDQUFDLEdBQUdDLE1BQU1ELEVBQUU7QUFBQSxJQUNyQixDQUFDO0FBQ0RuRyxpQkFBYSxLQUFLO0FBQUEsRUFDcEI7QUFFQSxRQUFNdUcsa0JBQWtCQSxNQUFNO0FBQzVCLFVBQU1DLGNBQWNSLHNCQUFzQjtBQUMxQyxVQUFNUyxhQUFhRCxZQUFZRSxJQUFJLENBQUNKLFNBQVNBLEtBQUtqRyxHQUFHO0FBQ3JELFFBQUlOLFdBQVc7QUFDYkQsNkJBQXVCLEVBQUU7QUFBQSxJQUMzQixPQUFPO0FBQ0xBLDZCQUF1QjJHLFVBQVU7QUFBQSxJQUNuQztBQUNBekcsaUJBQWEsQ0FBQ0QsU0FBUztBQUFBLEVBQ3pCO0FBR0EsUUFBTTRHLHlCQUF5QkEsTUFBTTtBQUNuQyxRQUFJOUcsb0JBQW9CNEYsV0FBVyxHQUFHO0FBQ3BDL0cscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFDQXVCLHdCQUFvQjtBQUFBLE1BQ2xCQyxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLE1BQ1JDLFFBQVE7QUFBQSxNQUNSQyxnQkFBZ0I7QUFBQSxNQUNoQkMsUUFBUTtBQUFBLE1BQ1JDLGFBQWEsQ0FBQyxHQUFHYixtQkFBbUI7QUFBQSxJQUN0QyxDQUFDO0FBQ0RLLDZCQUF5QixJQUFJO0FBQUEsRUFDL0I7QUFFQSxRQUFNMEcseUJBQXlCdE4sWUFBWSxZQUFZO0FBQ3JELFFBQUk7QUFDRnNFLDRCQUFzQixJQUFJO0FBQzFCLFlBQU1pSixNQUFNLE1BQU1wTixJQUFJdUwsSUFBSSwwQ0FBMEM7QUFDcEUsWUFBTThCLFVBQVVELElBQUk1QjtBQUVwQixZQUFNbEUsbUJBQW1CK0YsUUFBUXJCO0FBQ2pDLFlBQU16RSxlQUFlOEYsUUFBUUM7QUFBQUEsUUFDM0IsQ0FBQ0MsS0FBS1YsU0FBU1UsT0FBT1YsS0FBS2pELGlCQUFpQjtBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUNBLFlBQU1wQyxrQkFBa0IsSUFBSWdHO0FBQUFBLFFBQzFCSCxRQUFRSixJQUFJLENBQUNKLFNBQVNBLEtBQUtsRCxTQUFTL0MsR0FBRyxFQUFFaUYsT0FBTzRCLE9BQU87QUFBQSxNQUN6RCxFQUFFQztBQUNGLFlBQU1qRyxlQUFlLElBQUkrRjtBQUFBQSxRQUN2QkgsUUFBUUosSUFBSSxDQUFDSixTQUFTQSxLQUFLbkQsVUFBVWlFLFVBQVUsRUFBRTlCLE9BQU80QixPQUFPO0FBQUEsTUFDakUsRUFBRUM7QUFFRnJHLHNCQUFnQjtBQUFBLFFBQ2RDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU0rRCxPQUFPNkIsUUFBUUosSUFBSSxDQUFDSixNQUFNZSxXQUFXO0FBQUEsUUFDekNoSCxLQUFLaUcsS0FBS2pHO0FBQUFBLFFBQ1Y4RixJQUFJa0IsUUFBUTtBQUFBLFFBQ1pDLG9CQUFvQmhCLEtBQUtnQjtBQUFBQSxRQUN6QkMsTUFBTWpCLEtBQUtsRCxTQUFTb0UsYUFBYTtBQUFBLFFBQ2pDQyxjQUFjbkIsS0FBS2xELFNBQVNxRSxnQkFBZ0I7QUFBQSxRQUM1Q0wsWUFBWWQsS0FBS25ELFVBQVVpRSxjQUFjO0FBQUEsUUFDekMvRCxlQUFlaUQsS0FBS2pEO0FBQUFBLFFBQ3BCRSxjQUFjK0MsS0FBSy9DO0FBQUFBLFFBQ25CSSxtQkFBbUIyQyxLQUFLM0M7QUFBQUEsUUFDeEJMLGVBQWVnRCxLQUFLaEQ7QUFBQUEsUUFDcEJoRCxRQUFRZ0csS0FBS2hHLFVBQVU7QUFBQSxRQUN2QkMsUUFBUStGLEtBQUsvRixVQUFVO0FBQUEsUUFDdkJDLGdCQUFnQjhGLEtBQUs5RixrQkFBa0I7QUFBQSxRQUN2QzRDLFNBQVNrRCxLQUFLbEQ7QUFBQUEsUUFDZEQsVUFBVW1ELEtBQUtuRDtBQUFBQSxRQUNmSyxtQkFBbUI4QyxLQUFLOUM7QUFBQUEsUUFDeEJFLGVBQWU0QyxLQUFLNUM7QUFBQUEsUUFDcEJELE9BQU82QyxLQUFLN0M7QUFBQUEsUUFDWmlFLGlCQUFpQnBCLEtBQUtxQixXQUFXdEYsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQzdDdUYsYUFBYXRCLE1BQU1sRCxTQUFTeUUsb0JBQ2hDLEdBQUd2QixNQUFNbEQsU0FBU3lFLG1CQUFtQk4sUUFBUSxHQUFHLE1BQzlDakIsTUFBTWxELFNBQVN5RSxtQkFBbUJKLGdCQUFnQixHQUFHLEtBRXZEO0FBQUEsUUFFSUssUUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsWUFDakIsTUFBTTtBQUFBLGNBQ0pDLE9BQU87QUFBQSxnQkFDTDtBQUFBLGtCQUNFek0sS0FBSztBQUFBLGtCQUNMQyxPQUNFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFTLE1BQU15TSxzQkFBc0IxQixJQUFJO0FBQUEsc0JBRXpDO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLE1BQUs7QUFBQSw0QkFDTCxRQUFPO0FBQUEsNEJBQ1AsU0FBUTtBQUFBLDRCQUVSO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLGVBQWM7QUFBQSxnQ0FDZCxnQkFBZTtBQUFBLGdDQUNmLGFBQVk7QUFBQSxnQ0FDWixHQUFFO0FBQUE7QUFBQSw4QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBSTRIO0FBQUE7QUFBQSwwQkFWOUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVlBO0FBQUEsd0JBQU07QUFBQTtBQUFBO0FBQUEsb0JBaEJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFrQkE7QUFBQSxnQkFFSjtBQUFBLGdCQUNBO0FBQUEsa0JBQ0VoTCxLQUFLO0FBQUEsa0JBQ0xDLE9BQ0U7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVMsTUFBTTBNLHNCQUFzQjNCLEtBQUtqRyxHQUFHO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxnQkFFSjtBQUFBLGdCQUNBO0FBQUEsa0JBQ0UvRSxLQUFLO0FBQUEsa0JBQ0xDLE9BQ0U7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVMsTUFBTTJNLHNCQUFzQjVCLEtBQUtqRyxHQUFHO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxnQkFFSjtBQUFBLGdCQUNBO0FBQUEsa0JBQ0UvRSxLQUFLO0FBQUEsa0JBQ0xDLE9BQ0U7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVMsTUFBTTRNLGtCQUFrQjdCLElBQUk7QUFBQSxzQkFBRTtBQUFBO0FBQUEsb0JBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGdCQUVKO0FBQUEsY0FBQztBQUFBLFlBRUw7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFlBQVMsV0FBVSw4QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQTtBQUFBLFVBakVoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrRUEsS0FuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9FQTtBQUFBLE1BRUosRUFBRTtBQUNGaEssc0JBQWdCMkksSUFBSTtBQUNwQnpJLHlCQUFtQnlJLElBQUk7QUFBQSxJQUN6QixTQUFTbUQsS0FBSztBQUNaakQsY0FBUUQsTUFBTSxtQ0FBbUNrRCxHQUFHO0FBQUEsSUFDdEQsVUFBQztBQUNDeEssNEJBQXNCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUx4RSxZQUFVLE1BQU07QUFDZHdOLDJCQUF1QjtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ0Esc0JBQXNCLENBQUM7QUFHM0J4TixZQUFVLE1BQU07QUFDZCxRQUFJcUcsWUFBWTtBQUNkLFlBQU00SSxXQUFXaE0sYUFBYWlKO0FBQUFBLFFBQzVCLENBQUNXLFdBQ0NBLE9BQU9zQixLQUFLZSxZQUFZLEVBQUVqQyxTQUFTNUcsV0FBVzZJLFlBQVksQ0FBQyxLQUMzRHJDLE9BQU93QixhQUFhYyxTQUFTLEVBQUVsQyxTQUFTNUcsVUFBVSxLQUNsRHdHLE9BQU9tQixXQUFXa0IsWUFBWSxFQUFFakMsU0FBUzVHLFdBQVc2SSxZQUFZLENBQUM7QUFBQSxNQUNyRTtBQUNBOUwseUJBQW1CNkwsUUFBUTtBQUFBLElBQzdCLE9BQU87QUFDTDdMLHlCQUFtQkgsWUFBWTtBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLENBQUNvRCxZQUFZcEQsWUFBWSxDQUFDO0FBRzdCLFFBQU1tTSwwQkFBMEJBLE1BQU07QUFDcEMsVUFBTUMsU0FBU3JELGdCQUFnQjtBQUMvQixVQUFNc0QsZUFBZW5NLGdCQUFnQitJO0FBQUFBLE1BQ25DLENBQUNDLE1BQU1BLEVBQUVqRixXQUFXLG1CQUFtQixDQUFDaUYsRUFBRWpGO0FBQUFBLElBQzVDLEVBQUVtRjtBQUNGLFVBQU1rRCxpQkFDSkYsT0FBT2pELFFBQVEsS0FDVGlELE9BQU83QyxZQUFZNkMsT0FBT2pELFFBQVMsS0FBS29ELFFBQVEsQ0FBQyxJQUNuRDtBQUNOLFVBQU1DLGdCQUNKSixPQUFPakQsUUFBUSxLQUNUaUQsT0FBTzVDLFdBQVc0QyxPQUFPakQsUUFBUyxLQUFLb0QsUUFBUSxDQUFDLElBQ2xEO0FBRU4sV0FDRSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUdBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFNBQVE7QUFBQSxjQUVSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQWM7QUFBQSxrQkFDZCxnQkFBZTtBQUFBLGtCQUNmLGFBQVk7QUFBQSxrQkFDWixHQUFFO0FBQUE7QUFBQSxnQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJME07QUFBQTtBQUFBLFlBVjVNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxxQ0FBb0MsK0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsNERBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pFO0FBQUFBLHFCQUFXSCxjQUFjLElBQUksS0FDNUIsdUJBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUNMLFFBQU87QUFBQSxnQkFDUCxTQUFRO0FBQUEsZ0JBRVI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsZUFBYztBQUFBLG9CQUNkLGdCQUFlO0FBQUEsb0JBQ2YsYUFBWTtBQUFBLG9CQUNaLEdBQUU7QUFBQTtBQUFBLGtCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJb0M7QUFBQTtBQUFBLGNBVnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsc0NBQ2JBO0FBQUFBO0FBQUFBLGNBQWU7QUFBQSxpQkFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFFREcsV0FBV0QsYUFBYSxJQUFJLEtBQzNCLHVCQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsU0FBUTtBQUFBLGdCQUVSO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGVBQWM7QUFBQSxvQkFDZCxnQkFBZTtBQUFBLG9CQUNmLGFBQVk7QUFBQSxvQkFDWixHQUFFO0FBQUE7QUFBQSxrQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSXFDO0FBQUE7QUFBQSxjQVZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGtDQUNiQTtBQUFBQTtBQUFBQSxjQUFjO0FBQUEsaUJBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQSxXQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ1p4TixzQ0FBNEJxTCxJQUFJLENBQUNxQyxRQUFRO0FBQ3hDLGNBQU1DLFFBQVFQLE9BQU9NLElBQUl6TixHQUFHO0FBQzVCLGNBQU0yTixhQUNKUixPQUFPakQsUUFBUSxLQUFNd0QsUUFBUVAsT0FBT2pELFFBQVMsS0FBS29ELFFBQVEsQ0FBQyxJQUFJO0FBQ2pFLGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVcsMEpBQTBKSSxVQUFVLElBQUksZUFBZSxFQUFFO0FBQUEsWUFFcE07QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLG1FQUFtRUQsSUFBSXZOLEtBQUs7QUFBQTtBQUFBLGdCQUR6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDMEw7QUFBQSxjQUUxTCx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsc0JBQXNCdU4sSUFBSXROLE9BQU8sSUFBSXNOLElBQUlwTixTQUFTLGlEQUFpRG9OLElBQUluTixTQUFTO0FBQUEsb0JBRTFIbU4sY0FBSWxOO0FBQUFBO0FBQUFBLGtCQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSwyREFDVm1OLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsMENBQ1ZELGNBQUl4TixTQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyx3Q0FBd0N3TixJQUFJdk4sS0FBSztBQUFBLG9CQUM1RCxPQUFPLEVBQUUwTixPQUFPLEdBQUdELFVBQVUsSUFBSTtBQUFBO0FBQUEsa0JBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFFcUMsS0FIdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSwyREFDVkE7QUFBQUE7QUFBQUEsa0JBQVc7QUFBQSxxQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUE7QUFBQTtBQUFBLFVBM0JLRixJQUFJek47QUFBQUEsVUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBNkJBO0FBQUEsTUFFSixDQUFDLEtBckNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyRkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwSEFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsUUFBTztBQUFBLGNBQ1AsU0FBUTtBQUFBLGNBRVI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsZUFBYztBQUFBLGtCQUNkLGdCQUFlO0FBQUEsa0JBQ2YsYUFBWTtBQUFBLGtCQUNaLEdBQUU7QUFBQTtBQUFBLGdCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlnTjtBQUFBO0FBQUEsWUFWbE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHFEQUNWbU4saUJBQU9qRCxTQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FBd0MsK0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkZBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkhBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFNBQVE7QUFBQSxjQUVSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQWM7QUFBQSxrQkFDZCxnQkFBZTtBQUFBLGtCQUNmLGFBQVk7QUFBQSxrQkFDWixHQUFFO0FBQUE7QUFBQSxnQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJaUQ7QUFBQTtBQUFBLFlBVm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLE9BQUUsV0FBVSxzREFDVmtELDBCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSwwQ0FBeUMsNkJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQ0QsT0FBTyxXQUFXLElBQUksS0FDckIsdUJBQUMsU0FBSSxXQUFVLDZGQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRIQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxRQUFPO0FBQUEsY0FDUCxTQUFRO0FBQUEsY0FFUjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxlQUFjO0FBQUEsa0JBQ2QsZ0JBQWU7QUFBQSxrQkFDZixhQUFZO0FBQUEsa0JBQ1osR0FBRTtBQUFBO0FBQUEsZ0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSW1NO0FBQUE7QUFBQSxZQVZyTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsdURBQ1ZBLGlCQUFPLFdBQVcsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDJDQUEwQyw4QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHFEQUNWbE07QUFBQUEsOEJBQWdCa0osU0FBUyxLQUNwQmdELE9BQU9qRCxRQUFRakosZ0JBQWdCa0osU0FBVSxLQUFLbUQsUUFBUSxDQUFDLElBQ3pEO0FBQUEsY0FBTTtBQUFBLGlCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FBd0MsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxzQkFDYixpQ0FBQyxTQUFJLFdBQVUsd0JBQXVCLFNBQVEsYUFDNUM7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEdBQUU7QUFBQSxnQkFDRixNQUFLO0FBQUEsZ0JBQ0wsUUFBTztBQUFBLGdCQUNQLGFBQVk7QUFBQTtBQUFBLGNBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWlCO0FBQUEsWUFFakI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxHQUFFO0FBQUEsZ0JBQ0YsTUFBSztBQUFBLGdCQUNMLFFBQU87QUFBQSxnQkFDUCxhQUFZO0FBQUEsZ0JBQ1osaUJBQWlCLEdBQUdyTSxnQkFBZ0JrSixTQUFTLElBQUtnRCxPQUFPakQsUUFBUWpKLGdCQUFnQmtKLFNBQVUsTUFBTSxDQUFDO0FBQUEsZ0JBQ2xHLGVBQWM7QUFBQTtBQUFBLGNBTmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU11QjtBQUFBLFlBRXZCLHVCQUFDLFVBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFHO0FBQUEsZ0JBQ0gsSUFBRztBQUFBLGdCQUNILElBQUc7QUFBQSxnQkFDSCxJQUFHO0FBQUEsZ0JBQ0gsSUFBRztBQUFBLGdCQUVIO0FBQUEseUNBQUMsVUFBSyxRQUFPLE1BQUssV0FBVSxhQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQztBQUFBLGtCQUNyQyx1QkFBQyxVQUFLLFFBQU8sUUFBTyxXQUFVLGFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUE7QUFBQTtBQUFBLGNBUnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsYUF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBDQTtBQUFBLFdBM0hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0SEE7QUFBQSxTQTVPRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNk9BO0FBQUEsRUFFSjtBQUdBLFFBQU11Qyx3QkFBd0JBLENBQUMvQixXQUFXO0FBQ3hDN0Ysd0JBQW9CO0FBQUEsTUFDbEJDLEtBQUs0RixPQUFPNUY7QUFBQUEsTUFDWkMsUUFBUTJGLE9BQU8zRixVQUFVO0FBQUEsTUFDekJDLFFBQVEwRixPQUFPMUYsVUFBVTtBQUFBLE1BQ3pCQyxnQkFBZ0J5RixPQUFPekYsa0JBQWtCO0FBQUEsTUFDekNDLFFBQVE7QUFBQSxNQUNSQyxhQUFhLENBQUN1RixPQUFPNUYsR0FBRztBQUFBLElBQzFCLENBQUM7QUFDREgsNkJBQXlCLElBQUk7QUFBQSxFQUMvQjtBQUdBLFFBQU1pSiwyQkFBMkIsWUFBWTtBQUMzQyxVQUFNLEVBQUU5SSxLQUFLQyxRQUFRQyxRQUFRQyxnQkFBZ0JDLFFBQVFDLFlBQVksSUFDL0RQO0FBRUYsUUFBSSxDQUFDRyxRQUFRO0FBQ1g1QixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUNBLFFBQUl5QixXQUFXLGVBQWUsQ0FBQ0UsZ0JBQWdCO0FBQzdDOUIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQStCLHdCQUFvQixJQUFJO0FBQ3hCLFFBQUk7QUFFRixZQUFNd0ksY0FBYzNJLFNBQVNDLGNBQWMsQ0FBQ0wsR0FBRztBQUcvQyxZQUFNZ0osaUJBQWlCRCxZQUFZMUM7QUFBQUEsUUFBSSxDQUFDUCxPQUN0QzFNLElBQUk2UCxJQUFJLG9DQUFvQ25ELEVBQUUsSUFBSTtBQUFBLFVBQ2hEN0Y7QUFBQUEsVUFDQUMsUUFBUUEsVUFBVTtBQUFBLFVBQ2xCQyxnQkFBZ0JGLFdBQVcsY0FBY0UsaUJBQWlCO0FBQUEsUUFDNUQsQ0FBQztBQUFBLE1BQ0g7QUFHQSxZQUFNK0ksUUFBUUMsSUFBSUgsY0FBYztBQUVoQzNLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM2QixTQUNMLEdBQUcySSxZQUFZM0QsTUFBTSx1Q0FDckI7QUFBQSxRQUNKNUcsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUVEcUIsK0JBQXlCLEtBQUs7QUFFOUJKLDZCQUF1QixFQUFFO0FBQ3pCRSxtQkFBYSxLQUFLO0FBQ2xCNEcsNkJBQXVCO0FBQUEsSUFDekIsU0FBUzFCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxpQkFBaUJBLEtBQUs7QUFDcEN4RyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTc0csTUFBTUgsVUFBVUUsTUFBTXJHLFdBQVc7QUFBQSxRQUMxQ0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDK0IsMEJBQW9CLEtBQUs7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkksaUJBQWlCQSxDQUFDLEVBQUV4RCxPQUFPLE1BQU07QUFDckNkLFlBQVF1RSxJQUFJLHNDQUFzQ3pELE1BQU07QUFDeERkLFlBQVF1RSxJQUFJLFlBQVl6RCxPQUFPN0MsT0FBTztBQUN0QytCLFlBQVF1RSxJQUFJLGFBQWF6RCxPQUFPOUMsUUFBUTtBQUN4Q2dDLFlBQVF1RSxJQUFJLFFBQVF6RCxPQUFPNUYsR0FBRztBQUU5QixVQUFNc0osMkJBQTJCQSxNQUFNO0FBQ3JDeEUsY0FBUXVFLElBQUksaURBQWlEekQsTUFBTTtBQUNuRWtDLHdCQUFrQmxDLE1BQU07QUFBQSxJQUMxQjtBQUVBLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsUUFDakIsTUFBTTtBQUFBLFVBQ0o4QixPQUFPO0FBQUEsWUFDTDtBQUFBLGNBQ0V6TSxLQUFLO0FBQUEsY0FDTEMsT0FDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNeU0sc0JBQXNCL0IsTUFBTTtBQUFBLGtCQUUzQztBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixNQUFLO0FBQUEsd0JBQ0wsUUFBTztBQUFBLHdCQUNQLFNBQVE7QUFBQSx3QkFFUjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxlQUFjO0FBQUEsNEJBQ2QsZ0JBQWU7QUFBQSw0QkFDZixhQUFZO0FBQUEsNEJBQ1osR0FBRTtBQUFBO0FBQUEsMEJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUk0SDtBQUFBO0FBQUEsc0JBVjlIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFZQTtBQUFBLG9CQUFNO0FBQUE7QUFBQTtBQUFBLGdCQWhCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FrQkE7QUFBQSxZQUVKO0FBQUEsWUFDQTtBQUFBLGNBQ0UzSyxLQUFLO0FBQUEsY0FDTEMsT0FDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNME0sc0JBQXNCaEMsT0FBTzVGLEdBQUc7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsWUFFSjtBQUFBLFlBQ0E7QUFBQSxjQUNFL0UsS0FBSztBQUFBLGNBQ0xDLE9BQ0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVMsTUFBTTJNLHNCQUFzQmpDLE9BQU81RixHQUFHO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLFlBRUo7QUFBQSxZQUNBO0FBQUEsY0FDRS9FLEtBQUs7QUFBQSxjQUNMQyxPQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFTb087QUFBQUEsa0JBQXlCO0FBQUE7QUFBQSxnQkFGcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxZQUVKO0FBQUEsVUFBQztBQUFBLFFBRUw7QUFBQSxRQUNBLFdBQVU7QUFBQSxRQUVWLGlDQUFDLFlBQVMsV0FBVSxzQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBO0FBQUEsTUFqRXhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtFQTtBQUFBLEVBRUo7QUFHQSxRQUFNQyx1QkFBdUJBLENBQUMzRCxXQUFXO0FBQ3ZDLFVBQU00RCxZQUFZNUQsT0FBTzNGLFdBQVcsbUJBQW1CLENBQUMyRixPQUFPM0Y7QUFDL0QsUUFBSXBCLGNBQWMsYUFBYSxDQUFDMkssVUFBVyxRQUFPO0FBQ2xELFFBQUkzSyxjQUFjLGVBQWUySyxVQUFXLFFBQU87QUFDbkQsVUFBTUMsYUFBYWpLLG9CQUFvQndHLFNBQVNKLE9BQU81RixHQUFHO0FBRzFELFFBQUluQixjQUFjLGFBQWE7QUFDN0IsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsV0FBVyx5SEFDVDRLLGFBQ0ksdURBQ0EsaUJBQWlCO0FBQUEsVUFHdkI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUg7QUFBQSxZQUN6SCx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVNBO0FBQUFBLHNCQUNULFVBQVUsTUFBTTVELHVCQUF1QkQsT0FBTzVGLEdBQUc7QUFBQSxzQkFDakQsV0FBVTtBQUFBO0FBQUEsb0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUcyQjtBQUFBLGtCQUUzQix1QkFBQyxTQUFJLFdBQVUseUhBQ1o0RixpQkFBT3NCLE1BQU13QyxPQUFPLENBQUMsR0FBR0MsWUFBWSxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsNENBQ1gvRCxpQkFBT3NCLFFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVnRCLGlCQUFPcUIsc0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxxQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2IsaUNBQUMsa0JBQWUsVUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0IsS0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLG9FQUFtRSxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSw4Q0FDVnJCLGlCQUFPd0IsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsb0VBQW1FLHFCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHVEQUNWeEIsaUJBQU9tQixjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUscUdBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUZBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsTUFBSztBQUFBLHNCQUNMLFFBQU87QUFBQSxzQkFDUCxTQUFRO0FBQUEsc0JBRVI7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsZUFBYztBQUFBLDBCQUNkLGdCQUFlO0FBQUEsMEJBQ2YsYUFBWTtBQUFBLDBCQUNaLEdBQUU7QUFBQTtBQUFBLHdCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFJb0k7QUFBQTtBQUFBLG9CQVZ0STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBWUE7QUFBQSxrQkFBTTtBQUFBLHFCQWJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLCtFQUErRXRCLGVBQWVHLE9BQU8zRixNQUFNLENBQUM7QUFBQSxzQkFFdEh5RjtBQUFBQSxzQ0FBY0UsT0FBTzNGLE1BQU07QUFBQSx3QkFDM0IyRixPQUFPM0Y7QUFBQUE7QUFBQUE7QUFBQUEsb0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLG9KQUNiMkY7QUFBQUEsMkJBQU81QztBQUFBQSxvQkFBYztBQUFBLHVCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUVDNEMsT0FBTzFGLFVBQ04sdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHNFQUFxRSxzQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FDVjBGLGlCQUFPMUYsVUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUdGLHVCQUFDLFNBQUksV0FBVSwwQkFDWjBGO0FBQUFBLHlCQUFPMkIsZUFBZTNCLE9BQU8yQixnQkFBZ0IsU0FDNUMsdUJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHdFQUF1RSwyQkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxrREFDVjNCLGlCQUFPMkIsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUVEM0IsT0FBT3pGLGtCQUNOLHVCQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSx5RUFBd0UsOEJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsTUFBSztBQUFBLDBCQUNMLFFBQU87QUFBQSwwQkFDUCxTQUFRO0FBQUEsMEJBRVI7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsZUFBYztBQUFBLDhCQUNkLGdCQUFlO0FBQUEsOEJBQ2YsYUFBWTtBQUFBLDhCQUNaLEdBQUU7QUFBQTtBQUFBLDRCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFJNEY7QUFBQTtBQUFBLHdCQVY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBWUE7QUFBQSxzQkFDQSx1QkFBQyxPQUFFLFdBQVUscUNBQ1Z5RixpQkFBT3pGLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSx1QkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFzQkE7QUFBQSxxQkFsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQ0E7QUFBQSxnQkFFQSx1QkFBQyxPQUFFLFdBQVUseUNBQXdDO0FBQUE7QUFBQSxrQkFDeEN5RixPQUFPeUI7QUFBQUEscUJBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrRkE7QUFBQSxpQkE5SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErSEE7QUFBQTtBQUFBO0FBQUEsUUF2SUt6QixPQUFPNUY7QUFBQUEsUUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BeUlBO0FBQUEsSUFFSjtBQUdBLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUVDLFdBQVcseUhBQ1R5SixhQUNJLHVEQUNBLGlCQUFpQjtBQUFBLFFBR3ZCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBIO0FBQUEsVUFDMUgsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTQTtBQUFBQSxvQkFDVCxVQUFVLE1BQU01RCx1QkFBdUJELE9BQU81RixHQUFHO0FBQUEsb0JBQ2pELFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHMkI7QUFBQSxnQkFFM0IsdUJBQUMsU0FBSSxXQUFVLHVIQUNaNEYsaUJBQU9zQixNQUFNd0MsT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDRDQUNYL0QsaUJBQU9zQixRQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1Z0QixpQkFBT3FCLHNCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FDQSx1QkFBQyxrQkFBZSxVQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGlCQW5CakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSxvRUFBbUUscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsOENBQ1ZyQixpQkFBT3dCLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsb0VBQW1FLHFCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHVEQUNWeEIsaUJBQU9tQixjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsZ0lBQStILDZCQUEvSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLFFBQU87QUFBQSxvQkFDUCxTQUFRO0FBQUEsb0JBRVI7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsZUFBYztBQUFBLHdCQUNkLGdCQUFlO0FBQUEsd0JBQ2YsYUFBWTtBQUFBLHdCQUNaLEdBQUU7QUFBQTtBQUFBLHNCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJNEY7QUFBQTtBQUFBLGtCQVY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWUE7QUFBQSxnQkFDQ25CLE9BQU95QjtBQUFBQSxtQkFkVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsZUE5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErREE7QUFBQTtBQUFBO0FBQUEsTUF2RUt6QixPQUFPNUY7QUFBQUEsTUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBeUVBO0FBQUEsRUFFSjtBQUdBLFFBQU00SixZQUFZQSxDQUFDLEVBQUVoRSxPQUFPLE1BQU07QUFDaEMsVUFBTTRELFlBQVk1RCxPQUFPM0YsV0FBVyxtQkFBbUIsQ0FBQzJGLE9BQU8zRjtBQUMvRCxRQUFJcEIsY0FBYyxhQUFhLENBQUMySyxVQUFXLFFBQU87QUFDbEQsUUFBSTNLLGNBQWMsZUFBZTJLLFVBQVcsUUFBTztBQUNuRCxVQUFNQyxhQUFhakssb0JBQW9Cd0csU0FBU0osT0FBTzVGLEdBQUc7QUFFMUQsUUFBSW5CLGNBQWMsYUFBYTtBQUM3QixhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFXLGdJQUNUNEssYUFDSSw2Q0FDQSxpQkFBaUI7QUFBQSxVQUd2QjtBQUFBLG1DQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVNBO0FBQUFBLG9CQUNULFVBQVUsTUFBTTVELHVCQUF1QkQsT0FBTzVGLEdBQUc7QUFBQSxvQkFDakQsV0FBVTtBQUFBO0FBQUEsa0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUcyQjtBQUFBLGdCQUUzQix1QkFBQyxTQUFJLFdBQVUseUhBQ1o0RixpQkFBT3NCLE1BQU13QyxPQUFPLENBQUMsR0FBR0MsWUFBWSxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLGtEQUNYL0QsaUJBQU9zQixRQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLHFGQUFxRnpCLGVBQWVHLE9BQU8zRixNQUFNLENBQUM7QUFBQSx3QkFFNUh5RjtBQUFBQSx3Q0FBY0UsT0FBTzNGLE1BQU07QUFBQSwwQkFDM0IyRixPQUFPM0Y7QUFBQUE7QUFBQUE7QUFBQUEsc0JBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLG9KQUNiMkY7QUFBQUEsNkJBQU81QztBQUFBQSxzQkFBYztBQUFBLHlCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVjRDLGlCQUFPbUIsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsbUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNEJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsdUNBQXNDLHFCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUN4RCx1QkFBQyxPQUFFLFdBQVUscUNBQ1ZuQixpQkFBT3dCLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLGtCQUFlLFVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCLEtBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsaUJBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMENBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsb0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLDZDQUNaeEI7QUFBQUEscUJBQU8xRixVQUNOLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSwwRUFBeUUsdUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsaUNBQ2IwRixpQkFBTzFGLFVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUVEMEYsT0FBTzJCLGVBQWUzQixPQUFPMkIsZ0JBQWdCLFNBQzVDLHVCQUFDLFNBQUksV0FBVSx3RkFDYixpQ0FBQyxVQUFLLFdBQVUsaUNBQWdDO0FBQUE7QUFBQSxnQkFDbkMzQixPQUFPMkI7QUFBQUEsbUJBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FFRDNCLE9BQU96RixrQkFDTix1QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLFFBQU87QUFBQSxvQkFDUCxTQUFRO0FBQUEsb0JBRVI7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsZUFBYztBQUFBLHdCQUNkLGdCQUFlO0FBQUEsd0JBQ2YsYUFBWTtBQUFBLHdCQUNaLEdBQUU7QUFBQTtBQUFBLHNCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJNEY7QUFBQTtBQUFBLGtCQVY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsaUNBQ2J5RixpQkFBT3pGLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUVGLHVCQUFDLFVBQUssV0FBVSwwQkFBeUI7QUFBQTtBQUFBLGdCQUM1QnlGLE9BQU95QjtBQUFBQSxtQkFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlDQSxLQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJDQTtBQUFBO0FBQUE7QUFBQSxRQTlGS3pCLE9BQU81RjtBQUFBQSxRQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnR0E7QUFBQSxJQUVKO0FBRUEsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBRUMsV0FBVyxnSUFDVHlKLGFBQ0ksNkNBQ0EsaUJBQWlCO0FBQUEsUUFHdkIsaUNBQUMsU0FBSSxXQUFVLG1FQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTQTtBQUFBQSxnQkFDVCxVQUFVLE1BQU01RCx1QkFBdUJELE9BQU81RixHQUFHO0FBQUEsZ0JBQ2pELFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRzJCO0FBQUEsWUFFM0IsdUJBQUMsU0FBSSxXQUFVLHVIQUNaNEYsaUJBQU9zQixNQUFNd0MsT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGtEQUNYL0QsaUJBQU9zQixRQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsOElBQTZJLHVCQUE3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUNWdEIsaUJBQU9tQixjQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxnRUFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxzQ0FBcUMscUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsY0FDdkQsdUJBQUMsT0FBRSxXQUFVLG9DQUNWbkIsaUJBQU93QixnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFGQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLHFDQUFvQyx3QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxjQUN6RCx1QkFBQyxPQUFFLFdBQVUsbUNBQ1Z4QixpQkFBT3lCLG1CQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsa0JBQWUsVUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0IsS0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMENBO0FBQUE7QUFBQSxNQWpES3pCLE9BQU81RjtBQUFBQSxNQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtREE7QUFBQSxFQUVKO0FBR0EsUUFBTTZKLG1CQUFtQkEsQ0FBQyxFQUFFNUssMkJBQWE2SyxZQUFZQyxhQUFhLE1BQU07QUFDdEUsUUFBSUQsY0FBYyxFQUFHLFFBQU87QUFDNUIsVUFBTUUsUUFBUTtBQUNkLFVBQU1DLE1BQU07QUFDWkQsVUFBTUUsS0FBSyxDQUFDO0FBQ1osUUFBSUosYUFBYUcsS0FBSztBQUNwQixVQUFJaEwsZUFBYyxFQUFHK0ssT0FBTUUsS0FBSyxLQUFLO0FBQ3JDLGVBQ01DLElBQUlDLEtBQUtILElBQUksR0FBR2hMLGVBQWMsQ0FBQyxHQUNuQ2tMLEtBQUtDLEtBQUtDLElBQUlQLGFBQWEsR0FBRzdLLGVBQWMsQ0FBQyxHQUM3Q2tMLEtBQ0E7QUFDQSxZQUFJQSxNQUFNLEtBQUtBLE1BQU1MLFdBQVlFLE9BQU1FLEtBQUtDLENBQUM7QUFBQSxNQUMvQztBQUNBLFVBQUlsTCxlQUFjNkssYUFBYSxFQUFHRSxPQUFNRSxLQUFLLEtBQUs7QUFBQSxJQUNwRCxPQUFPO0FBQ0wsZUFBU0MsSUFBSSxHQUFHQSxLQUFLTCxZQUFZSyxJQUFLSCxPQUFNRSxLQUFLQyxDQUFDO0FBQUEsSUFDcEQ7QUFDQSxRQUFJTCxhQUFhLEVBQUdFLE9BQU1FLEtBQUtKLFVBQVU7QUFFekMsV0FDRSx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNQyxhQUFhOUssZUFBYyxDQUFDO0FBQUEsVUFDM0MsVUFBVUEsaUJBQWdCO0FBQUEsVUFDMUIsV0FBVTtBQUFBLFVBQTBMO0FBQUE7QUFBQSxRQUh0TTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BQ0MrSyxNQUFNM0Q7QUFBQUEsUUFBSSxDQUFDaUUsTUFBTUgsTUFDaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFNBQVMsTUFBTSxPQUFPRyxTQUFTLFlBQVlQLGFBQWFPLElBQUk7QUFBQSxZQUM1RCxVQUFVLE9BQU9BLFNBQVM7QUFBQSxZQUMxQixXQUFXLDJEQUEyREEsU0FBU3JMLGVBQWMseURBQXlELE9BQU9xTCxTQUFTLFdBQVcsbUZBQW1GLDhEQUE4RDtBQUFBLFlBRWpVQTtBQUFBQTtBQUFBQSxVQUxJSDtBQUFBQSxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLE1BQ0Q7QUFBQSxNQUNEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1KLGFBQWE5SyxlQUFjLENBQUM7QUFBQSxVQUMzQyxVQUFVQSxpQkFBZ0I2SztBQUFBQSxVQUMxQixXQUFVO0FBQUEsVUFBMEw7QUFBQTtBQUFBLFFBSHRNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLEVBRUo7QUFHQSxRQUFNUyxnQkFBZ0JBLE1BQU07QUFDMUIsUUFBSWpOLG9CQUFvQjtBQUN0QixhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXQTtBQUFBQSxVQUNYLFNBQVM7QUFBQSxVQUNULE1BQUs7QUFBQTtBQUFBLFFBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3dCO0FBQUEsSUFHNUI7QUFFQSxVQUFNa04scUJBQXFCN0Usc0JBQXNCO0FBQ2pELFVBQU04RSxxQkFBcUJ4TCxjQUFjRTtBQUN6QyxVQUFNdUwsc0JBQXNCRCxxQkFBcUJ0TDtBQUNqRCxVQUFNd0wsa0JBQWtCSCxtQkFBbUI3STtBQUFBQSxNQUN6QytJO0FBQUFBLE1BQ0FEO0FBQUFBLElBQ0Y7QUFDQSxVQUFNRyxnQkFBZ0JSLEtBQUtTLEtBQUtMLG1CQUFtQnBGLFNBQVNqRyxZQUFZO0FBRXhFLFFBQUksQ0FBQ3FMLG1CQUFtQnBGLFFBQVE7QUFDOUIsYUFDRSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLFNBQVE7QUFBQSxZQUVSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBYztBQUFBLGdCQUNkLGdCQUFlO0FBQUEsZ0JBQ2YsYUFBWTtBQUFBLGdCQUNaLEdBQUU7QUFBQTtBQUFBLGNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWdQO0FBQUE7QUFBQSxVQVZsUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLHVDQUNWdkcsd0JBQWMsWUFDWCxpQ0FDQSxvQ0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDVkEsd0JBQWMsWUFDWCx3Q0FDQSw0REFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsSUFFSjtBQUdBLFVBQU1pTSxrQkFBa0JBLE1BQ3RCLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTcEw7QUFBQUEsWUFDVCxVQUFVd0c7QUFBQUEsWUFDVixlQUNFMUcsb0JBQW9CNEYsU0FBUyxLQUM3QjVGLG9CQUFvQjRGLFNBQVNvRixtQkFBbUJwRjtBQUFBQTtBQUFBQSxVQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNRztBQUFBLFFBRUgsdUJBQUMsVUFBSyxXQUFVLHlCQUNiNUYsOEJBQW9CNEYsU0FBUyxJQUMxQixHQUFHNUYsb0JBQW9CNEYsTUFBTSxjQUM3QixnQkFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BQ0M1RixvQkFBb0I0RixTQUFTLEtBQzVCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxNQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxRQUFPO0FBQUEsY0FDUCxTQUFRO0FBQUEsY0FFUjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxlQUFjO0FBQUEsa0JBQ2QsZ0JBQWU7QUFBQSxrQkFDZixhQUFZO0FBQUEsa0JBQ1osR0FBRTtBQUFBO0FBQUEsZ0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTRIO0FBQUE7QUFBQSxZQVY5SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQTtBQUFBLFVBRUYsU0FBU2tCO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBQXFEO0FBQUE7QUFBQSxZQUVqRDlHLG9CQUFvQjRGO0FBQUFBLFlBQU87QUFBQTtBQUFBO0FBQUEsUUFyQjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXNCQTtBQUFBLFNBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5Q0E7QUFHRixRQUFJckcsYUFBYSxRQUFRO0FBQ3ZCLGFBQ0UsbUNBQ0U7QUFBQSwrQkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCO0FBQUEsUUFDaEIsdUJBQUMsU0FBSSxXQUFVLHdEQUNaNEwsMEJBQWdCdEUsSUFBSWtELG9CQUFvQixLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLElBRUo7QUFFQSxRQUFJeEssYUFBYSxRQUFRO0FBQ3ZCLGFBQ0UsbUNBQ0U7QUFBQSwrQkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCO0FBQUEsUUFDaEIsdUJBQUMsU0FBSSxXQUFVLGFBQ1o0TCwwQkFBZ0J0RTtBQUFBQSxVQUFJLENBQUN0QyxNQUNwQix1QkFBQyxhQUFxQixRQUFRQSxLQUFkQSxFQUFFK0IsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxRQUNqQyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsSUFFSjtBQUdBLFVBQU1pRixlQUFlO0FBQUEsTUFDbkI7QUFBQSxRQUNFOVAsS0FBSztBQUFBLFFBQ0wrUCxRQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTdEw7QUFBQUEsWUFDVCxVQUFVd0c7QUFBQUEsWUFDVixlQUNFMUcsb0JBQW9CNEYsU0FBUyxLQUM3QjVGLG9CQUFvQjRGLFNBQVNPLHNCQUFzQixFQUFFUDtBQUFBQTtBQUFBQSxVQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNRztBQUFBLFFBR0w2RixRQUFRQSxDQUFDQyxXQUNQO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTMUwsb0JBQW9Cd0csU0FBU2tGLE9BQU9sTCxHQUFHO0FBQUEsWUFDaEQsVUFBVSxNQUFNNkYsdUJBQXVCcUYsT0FBT2xMLEdBQUc7QUFBQTtBQUFBLFVBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVxRDtBQUFBLE1BR3pEO0FBQUEsTUFDQSxHQUFHbUw7QUFBQUEsSUFBTztBQUdaLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFNblAsYUFBYWlKO0FBQUFBLFVBQU8sQ0FBQ2xCLE1BQ3pCbEYsY0FBYyxjQUNWa0YsRUFBRTlELFVBQVU4RCxFQUFFOUQsV0FBVyxrQkFDekIsQ0FBQzhELEVBQUU5RCxVQUFVOEQsRUFBRTlELFdBQVc7QUFBQSxRQUNoQztBQUFBLFFBQ0E7QUFBQSxRQUNBLGlCQUFnQjtBQUFBLFFBQ2hCLGtCQUFpQjtBQUFBO0FBQUEsTUFUbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUzZDLEtBVi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLEVBRUo7QUFFQSxRQUFNNkgsb0JBQW9CQSxDQUFDN0IsU0FBUztBQUNsQ25CLFlBQVF1RSxJQUFJLDhDQUE4Q3BELElBQUk7QUFFOURoSixvQkFBZ0JnSixJQUFJO0FBRXBCLFVBQU1tRixTQUFTbkYsS0FBS2xELFNBQVMvQyxPQUFPO0FBQ3BDLFVBQU1xTCxVQUFVcEYsS0FBS25ELFVBQVU5QyxPQUFPaUcsS0FBS25ELFVBQVVnRCxNQUFNO0FBQzNELFVBQU13RixxQkFBcUJyRixLQUFLOUMsbUJBQW1CbkQsT0FBTztBQUMxRCxVQUFNdUwsaUJBQWlCdEYsS0FBSzVDLGVBQWVyRCxPQUFPO0FBQ2xELFVBQU13TCxVQUFVdkYsS0FBSzdDLE9BQU9wRCxPQUFPO0FBRW5DNkMsZ0JBQVk7QUFBQSxNQUNWRSxTQUFTcUk7QUFBQUEsTUFDVHRJLFVBQVV1STtBQUFBQSxNQUNWbkksY0FBYytDLEtBQUsvQyxnQkFBZ0I7QUFBQSxNQUNuQ0QsZUFBZWdELEtBQUtoRCxpQkFBaUI7QUFBQSxNQUNyQ0ssbUJBQW1CMkMsS0FBSzNDLHFCQUFxQjtBQUFBLE1BQzdDSCxtQkFBbUJtSTtBQUFBQSxNQUNuQmpJLGVBQWVrSTtBQUFBQSxNQUNmbkksT0FBT29JO0FBQUFBLE1BQ1B4SSxlQUFlaUQsS0FBS2pELGlCQUFpQjtBQUFBLElBQ3ZDLENBQUM7QUFFRDdFLHNCQUFrQixRQUFRO0FBQzFCNUIsaUJBQWEsSUFBSTtBQUFBLEVBQ25CO0FBRUEsUUFBTWtQLGVBQWUsT0FBTzFILE1BQU07QUFDaENBLE1BQUUySCxlQUFlO0FBRWpCLFVBQU07QUFBQSxNQUNKMUk7QUFBQUEsTUFDQUY7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUY7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsSUFDRixJQUFJVjtBQUVKLFVBQU0rSSxlQUFlMUosU0FBU2UsaUJBQWlCLEdBQUcsRUFBRTtBQUNwRCxVQUFNNEksZ0JBQWdCMU8sb0JBQ25CeUUsTUFBTSxHQUFHZ0ssWUFBWSxFQUNyQnRGLElBQUksQ0FBQ3dGLGtCQUFrQjtBQUFBLE1BQ3RCL0k7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQUQ7QUFBQUEsTUFDQUssbUJBQW1CVixTQUFTVTtBQUFBQSxNQUM1Qkg7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUQ7QUFBQUEsTUFDQUosZUFBZTJJO0FBQUFBLE1BQ2ZoSSxTQUFTa0k7QUFBQUEsSUFDWCxFQUFFO0FBRUosUUFBSTtBQUNGeE8saUJBQVcsSUFBSTtBQUNmLGlCQUFXeU8sZUFBZUYsZUFBZTtBQUN2QyxjQUFNeFMsSUFBSTJTLEtBQUssc0JBQXNCRCxhQUFhO0FBQUEsVUFDaERFLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsUUFDaEQsQ0FBQztBQUFBLE1BQ0g7QUFFQSxVQUFJaFAsY0FBY2dELEtBQUs7QUFDckIsY0FBTTVHLElBQUk2UztBQUFBQSxVQUNSLCtDQUErQ2pQLGFBQWFnRCxHQUFHO0FBQUEsVUFDL0Q7QUFBQSxZQUNFNEUsTUFBTSxFQUFFc0gsWUFBWXZOLE9BQU93TixZQUFZLG9CQUFJcEwsS0FBSyxFQUFFO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBMUMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFFRGpDLG1CQUFhLEtBQUs7QUFDbEJzRyxrQkFBWTtBQUFBLFFBQ1ZDLFVBQVU7QUFBQSxRQUNWQyxTQUFTO0FBQUEsUUFDVEMsZUFBZTtBQUFBLFFBQ2ZDLGVBQWU7QUFBQSxRQUNmQyxjQUFjO0FBQUEsUUFDZEMsbUJBQW1CO0FBQUEsUUFDbkJDLE9BQU87QUFBQSxRQUNQQyxlQUFlO0FBQUEsUUFDZkMsbUJBQW1CO0FBQUEsTUFDckIsQ0FBQztBQUVEaUQsNkJBQXVCO0FBQUEsSUFDekIsU0FBUzFCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUN4RyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDbkIsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBdEUsWUFBVSxNQUFNO0FBQ2QsVUFBTXFULGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTTFILFdBQVcsTUFBTXRMLElBQUl1TCxJQUFJLGdCQUFnQjtBQUMvQzVJLGlCQUFTMkksU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQ0F1SCxlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFFTHJULFlBQVUsTUFBTTtBQUNkLFVBQU1zVCxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU0zSCxXQUFXLE1BQU10TCxJQUFJdUwsSUFBSSxrQkFBa0I7QUFDakQ1RyxrQkFBVTJHLFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTbUQsS0FBSztBQUNaakQsZ0JBQVFELE1BQU0seUJBQXlCa0QsR0FBRztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUNBc0UsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMdFQsWUFBVSxNQUFNO0FBQ2QsVUFBTXVULGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTTVILFdBQVcsTUFBTXRMLElBQUl1TCxJQUFJLGdCQUFnQjtBQUMvQzlHLGlCQUFTNkcsU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVNtRCxLQUFLO0FBQ1pqRCxnQkFBUUQsTUFBTSx5QkFBeUJrRCxHQUFHO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQ0F1RSxlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFFTCxRQUFNQyxlQUFlLFlBQVk7QUFDL0IsVUFBTTtBQUFBLE1BQ0p4SjtBQUFBQSxNQUNBRDtBQUFBQSxNQUNBTTtBQUFBQSxNQUNBRDtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBSjtBQUFBQSxJQUNGLElBQUlMO0FBRUosUUFBSSxDQUFDRyxXQUFXLENBQUNELFVBQVU7QUFDekJ4SSxtQkFBYWtTLFFBQVE7QUFBQSxRQUNuQmpPLFNBQVM7QUFBQSxNQUNYLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTW1HLFdBQVcsTUFBTXRMLElBQUl1TCxJQUFJLDRCQUE0QjtBQUFBLFFBQ3pEOEgsUUFBUSxFQUFFMUosU0FBU0QsU0FBUztBQUFBLE1BQzlCLENBQUM7QUFFRCxZQUFNNEosZUFBZTVRLE1BQU02USxLQUFLLENBQUN6SCxNQUFNQSxFQUFFbEYsUUFBUStDLE9BQU87QUFDeEQsWUFBTTNHLGlCQUFnQlIsT0FBTytRLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRTVNLFFBQVE4QyxRQUFRO0FBQzNELFlBQU0rSixnQkFBZ0IvTyxPQUFPNk8sS0FBSyxDQUFDRyxNQUFNQSxFQUFFOU0sUUFBUW9ELEtBQUs7QUFDeEQsWUFBTTJKLDJCQUEyQmpSLE1BQU02UTtBQUFBQSxRQUNyQyxDQUFDekgsTUFBTUEsRUFBRWxGLFFBQVFtRDtBQUFBQSxNQUNuQjtBQUNBLFlBQU02Six1QkFBdUJwUCxPQUFPK087QUFBQUEsUUFDbEMsQ0FBQ00sTUFBTUEsRUFBRWpOLFFBQVFxRDtBQUFBQSxNQUNuQjtBQUVBLFVBQUlxQixVQUFVRSxNQUFNO0FBQ2xCLGNBQU1zSSxZQUNKLE9BQU94SSxTQUFTRSxLQUFLeEIsVUFBVSxXQUMzQnNCLFNBQVNFLEtBQUt4QixPQUFPOEQsT0FDckI7QUFDTixjQUFNaUcsdUJBQ0osT0FBT3pJLFNBQVNFLEtBQUt6QixzQkFBc0IsV0FDdkN1QixTQUFTRSxLQUFLekIsbUJBQW1CZ0UsWUFDakM7QUFDTixjQUFNaUcsbUJBQ0osT0FBTzFJLFNBQVNFLEtBQUt2QixrQkFBa0IsV0FDbkNxQixTQUFTRSxLQUFLdkIsZUFBZWdLLFlBQzdCO0FBRU4sY0FBTUMsb0JBQW9CO0FBRTFCLFlBQUlKO0FBQ0ZJLDRCQUFrQnBEO0FBQUFBLFlBQ2hCLG9DQUFvQ2dELFNBQVM7QUFBQSxVQUMvQztBQUNGLFlBQUlDO0FBQ0ZHLDRCQUFrQnBEO0FBQUFBLFlBQ2hCLHVDQUF1Q2lELG9CQUFvQjtBQUFBLFVBQzdEO0FBQ0YsWUFBSUM7QUFDRkUsNEJBQWtCcEQ7QUFBQUEsWUFDaEIsbUNBQW1Da0QsZ0JBQWdCO0FBQUEsVUFDckQ7QUFDRixZQUFJRSxrQkFBa0JsSSxXQUFXO0FBQy9Ca0ksNEJBQWtCcEQsS0FBSywwQ0FBMEM7QUFFbkVySCxvQkFBWSxDQUFDa0QsVUFBVTtBQUFBLFVBQ3JCLEdBQUdBO0FBQUFBLFVBQ0gvQyxlQUFlMEIsVUFBVUUsTUFBTTVCLGlCQUFpQitDLEtBQUsvQztBQUFBQSxVQUNyREUsY0FBY3dCLFVBQVVFLE1BQU0xQixnQkFBZ0I2QyxLQUFLN0M7QUFBQUEsVUFDbkRDLG1CQUNFdUIsVUFBVUUsTUFBTXpCLHFCQUFxQjRDLEtBQUs1QztBQUFBQSxVQUM1Q0UsZUFBZXFCLFVBQVVFLE1BQU12QixpQkFBaUIwQyxLQUFLMUM7QUFBQUEsVUFDckRKLGVBQ0U4QyxLQUFLOUMsaUJBQ0x5QixVQUFVRSxNQUFNM0Isa0JBQ2Z5QixTQUFTRSxNQUFNeEIsUUFDWixVQUNBc0IsU0FBU0UsTUFBTXpCLG9CQUNiLGFBQ0F1QixTQUFTRSxNQUFNdkIsZ0JBQ2IsVUFDQTtBQUFBLFFBQ1osRUFBRTtBQUVGLFlBQUlrSyxhQUFhO0FBQ2pCLFlBQUl0SyxrQkFBa0I7QUFDcEJzSyx1QkFBYVYsZUFBZTNGLFFBQVE7QUFBQSxpQkFDN0JqRSxrQkFBa0I7QUFDekJzSyx1QkFDRVIsMEJBQTBCNUYsYUFBYTtBQUFBLGlCQUNsQ2xFLGtCQUFrQjtBQUN6QnNLLHVCQUFhUCxzQkFBc0JLLGFBQWE7QUFFbEQzTyxnQ0FBd0IsSUFBSTtBQUM1QlAsMEJBQWtCLFVBQVU7QUFFNUI3RCxxQkFBYWtTLFFBQVE7QUFBQSxVQUNuQmpPLFNBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU87QUFBQSxnQkFDTGlQLFlBQVk7QUFBQSxnQkFDWkMsVUFBVTtBQUFBLGdCQUNWQyxjQUFjO0FBQUEsY0FDaEI7QUFBQSxjQUFFO0FBQUE7QUFBQSxnQkFFZWhCLGNBQWN2RjtBQUFBQSxnQkFBVTtBQUFBLGdCQUN6Qyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQUc7QUFBQSxnQkFDSCx1QkFBQyxRQUFHLE9BQU8sRUFBRXdHLFFBQVEsVUFBVUMsV0FBVyxpQkFBaUIsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkQ7QUFBQSxnQkFBRztBQUFBLGdCQUNsRHhSLGdCQUFlMks7QUFBQUEsZ0JBQVc7QUFBQSxnQkFDeEMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFHO0FBQUEsZ0JBQ0gsdUJBQUMsUUFBRyxPQUFPLEVBQUU0RyxRQUFRLFVBQVVDLFdBQVcsaUJBQWlCLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUE7QUFBQTtBQUFBLFlBWi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsVUFFRkMsYUFDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUwsWUFBWSxRQUFRQyxVQUFVLFVBQVUsR0FDbkRILDRCQUFrQmpIO0FBQUFBLFlBQUksQ0FBQ3lILE1BQU05RyxVQUM1Qix1QkFBQyxVQUNFOEc7QUFBQUE7QUFBQUEsY0FDRCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQUc7QUFBQSxjQUNIO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU8sRUFBRUgsUUFBUSxVQUFVQyxXQUFXLGlCQUFpQjtBQUFBO0FBQUEsZ0JBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUMyRDtBQUFBLGlCQUpsRDVHLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFVBQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFFRitHLFVBQVU7QUFBQSxRQUNaLENBQUM7QUFDRHJQLGdDQUF3QixJQUFJO0FBQzVCOEUsc0JBQWMsSUFBSTtBQUNsQnJGLDBCQUFrQixVQUFVO0FBQUEsTUFDOUIsT0FBTztBQUNMTyxnQ0FBd0IsS0FBSztBQUM3QjhFLHNCQUFjLElBQUk7QUFDbEJyRiwwQkFBa0IsVUFBVTtBQUU1QjdELHFCQUFhMFQsUUFBUTtBQUFBLFVBQ25CelAsU0FBUztBQUFBLFVBQ1RzUCxhQUFhLFNBQVNuQixjQUFjdkYsU0FBUyx5QkFBeUIvSyxnQkFBZTJLLFVBQVU7QUFBQSxVQUMvRmdILFVBQVU7QUFBQSxRQUNaLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTaEcsS0FBSztBQUNaakQsY0FBUUQsTUFBTSx1QkFBdUJrRCxHQUFHO0FBQ3hDek4sbUJBQWF1SyxNQUFNO0FBQUEsUUFDakJ0RyxTQUFTO0FBQUEsUUFDVHNQLGFBQWE5RixJQUFJckQsVUFBVUUsTUFBTXJHLFdBQVc7QUFBQSxNQUM5QyxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMFAsa0JBQWtCLE9BQU9sSyxNQUFNO0FBQ25DQSxNQUFFMkgsZUFBZTtBQUVqQixRQUFJeE4sbUJBQW1CLFVBQVU7QUFDL0IsWUFBTXFPLGFBQWE7QUFBQSxJQUNyQixXQUFXck8sbUJBQW1CLFlBQVk7QUFDeENDLHdCQUFrQixRQUFRO0FBQUEsSUFDNUIsV0FBV0QsbUJBQW1CLFVBQVU7QUFDdEN1TixtQkFBYTFILENBQUM7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUssbUJBQW1CQSxDQUFDQyxPQUFPbkssVUFBVTtBQUN6Q25CLGdCQUFZLENBQUN1TCxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUduSztBQUFBQSxJQUNYLEVBQUU7QUFFRnZHLGNBQVUsQ0FBQzRRLGdCQUFnQjtBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHO0FBQUEsSUFDWCxFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1HLHdCQUF3QkEsQ0FBQ0gsT0FBT25LLFVBQVU7QUFDOUNOLHNCQUFrQixDQUFDMEssY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsS0FBSyxHQUFHbks7QUFBQUEsSUFDWCxFQUFFO0FBRUZ2RyxjQUFVLEVBQUUsR0FBR0QsUUFBUSxDQUFDMlEsS0FBSyxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBRUFwVixZQUFVLE1BQU07QUFDZCxRQUFJNkosU0FBU0UsVUFBVTtBQUNyQixZQUFNeUwsZUFBZSxZQUFZO0FBQy9CLFlBQUk7QUFDRixnQkFBTTdKLFdBQVcsTUFBTXRMLElBQUkyUztBQUFBQSxZQUN6Qiw0QkFBNEJuSixTQUFTRSxRQUFRO0FBQUEsVUFDL0M7QUFDQTNGLGlDQUF1QnVILFNBQVNFLEtBQUtoSSxvQkFBb0IsRUFBRTtBQUFBLFFBQzdELFNBQVNpSSxPQUFPO0FBQ2RDLGtCQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRDFILGlDQUF1QixFQUFFO0FBQUEsUUFDM0I7QUFBQSxNQUNGO0FBQ0FvUixtQkFBYTtBQUFBLElBQ2YsT0FBTztBQUNMcFIsNkJBQXVCLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDeUYsU0FBU0UsUUFBUSxDQUFDO0FBRXRCLFFBQU1xSSxVQUFVO0FBQUEsSUFDZCxFQUFFbFEsS0FBSyxNQUFNK1AsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRS9QLEtBQUssc0JBQXNCK1AsUUFBUSxxQkFBcUI7QUFBQSxJQUMxRCxFQUFFL1AsS0FBSyxRQUFRK1AsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFL1AsS0FBSyxnQkFBZ0IrUCxRQUFRLHdCQUF3QjtBQUFBLEVBQUM7QUFFMUQsTUFBSXROLGNBQWM7QUFDaEJ5TixZQUFRakIsS0FBSyxFQUFFalAsS0FBSyxjQUFjK1AsUUFBUSxpQkFBaUIsQ0FBQztBQUFBLEVBQzlEO0FBQ0FHLFVBQVFqQjtBQUFBQSxJQUNOLEVBQUVqUCxLQUFLLGlCQUFpQitQLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRS9QLEtBQUssZ0JBQWdCK1AsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRS9QLEtBQUssbUJBQW1CK1AsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFL1AsS0FBSyxxQkFBcUIrUCxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUUvUCxLQUFLLGVBQWUrUCxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFDL1AsS0FBSyxVQUFVK1AsUUFBUSxpQkFBZ0I7QUFBQSxJQUN4QyxFQUFDL1AsS0FBSyxrQkFBa0IrUCxRQUFRLGlCQUFnQjtBQUFBLElBQ2hELEVBQUMvUCxLQUFLLFVBQVUrUCxRQUFRLFNBQVE7QUFBQSxJQUNoQyxFQUFFL1AsS0FBSyxVQUFVK1AsUUFBUSxTQUFTO0FBQUEsRUFDcEM7QUFFQSxRQUFNd0QsZUFBZUEsQ0FBQ3pLLE1BQU07QUFDMUIsVUFBTSxFQUFFbUQsTUFBTWxELE1BQU0sSUFBSUQsRUFBRUU7QUFDMUJwQixnQkFBWSxDQUFDdUwsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2xILElBQUksR0FBR2xEO0FBQUFBLElBQ1YsRUFBRTtBQUNGdkcsY0FBVSxDQUFDNFEsZ0JBQWdCLEVBQUUsR0FBR0EsWUFBWSxDQUFDbkgsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQzNEO0FBRUEsUUFBTXVILFdBQVdBLENBQUNqUSxTQUFTO0FBQ3pCLFVBQU1rUSxZQUFZLENBQUM7QUFDbkIsVUFBTTlKLE9BQU9wRyxTQUFTLGtCQUFrQm9FLFdBQVdhO0FBQ25ELFVBQU1rTCxjQUFjblEsU0FBUyxrQkFBa0Isa0JBQWtCO0FBQ2pFLFFBQUksQ0FBQ29HLEtBQUs5QixTQUFTOEwsS0FBSyxHQUFHO0FBQ3pCRixnQkFBVTVMLFdBQVc7QUFBQSxJQUN2QjtBQUNBLFFBQUksQ0FBQzhCLEtBQUs3QixTQUFTO0FBQ2pCMkwsZ0JBQVUzTCxVQUFVO0FBQUEsSUFDdEI7QUFFQSxRQUFJN0Ysb0JBQW9Ca0ksU0FBUyxHQUFHO0FBQ2xDLFVBQ0UsQ0FBQ1IsS0FBSytKLFdBQVcsS0FDakIvSixLQUFLK0osV0FBVyxLQUFLLEtBQ3JCRSxNQUFNakssS0FBSytKLFdBQVcsQ0FBQyxHQUN2QjtBQUNBRCxrQkFBVUMsV0FBVyxJQUFJO0FBQUEsTUFDM0IsV0FBVy9KLEtBQUsrSixXQUFXLElBQUl6UixvQkFBb0JrSSxRQUFRO0FBQ3pEc0osa0JBQVVDLFdBQVcsSUFDbkIsV0FBV3pSLG9CQUFvQmtJLE1BQU07QUFBQSxNQUN6QztBQUFBLElBQ0Y7QUFFQTNILGNBQVVpUixTQUFTO0FBQ25CLFdBQU9JLE9BQU9DLEtBQUtMLFNBQVMsRUFBRXRKLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU00SixvQkFBb0JBLENBQUNqTCxNQUFNO0FBQy9CLFVBQU0sRUFBRW1ELE1BQU1sRCxNQUFNLElBQUlELEVBQUVFO0FBQzFCUCxzQkFBa0IsQ0FBQ3VMLGVBQWU7QUFBQSxNQUNoQyxHQUFHQTtBQUFBQSxNQUNILENBQUMvSCxJQUFJLEdBQUdsRDtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTTRELHdCQUF3QixPQUFPc0gsYUFBYTtBQUNoRCxRQUFJO0FBQ0YsWUFBTXhLLFdBQVcsTUFBTXRMLElBQUl1TDtBQUFBQSxRQUN6QixrREFBa0R1SyxRQUFRO0FBQUEsTUFDNUQ7QUFDQXZTLDRCQUFzQitILFNBQVNFLElBQUk7QUFDbkNFLGNBQVFxSyxLQUFLekssU0FBU0UsTUFBTXhCLE9BQU9wRCxLQUFLLGVBQWU7QUFDdkQwRCx3QkFBa0I7QUFBQSxRQUNoQlosVUFBVTRCLFNBQVNFLE1BQU05QixVQUFVOUM7QUFBQUEsUUFDbkMrQyxTQUFTMkIsU0FBU0UsTUFBTTdCLFNBQVMvQztBQUFBQSxRQUNqQzJELFNBQVNlLFNBQVNFLE1BQU1qQjtBQUFBQSxRQUN4QlQsY0FBY3dCLFNBQVNFLE1BQU0xQjtBQUFBQSxRQUM3QkMsbUJBQW1CdUIsU0FBU0UsTUFBTXpCLG1CQUFtQm5EO0FBQUFBLFFBQ3JEb0QsT0FBT3NCLFNBQVNFLE1BQU14QixPQUFPcEQ7QUFBQUEsUUFDN0JxRCxlQUFlcUIsU0FBU0UsTUFBTXZCLGVBQWVyRDtBQUFBQSxRQUM3Q2lELGVBQWV5QixTQUFTRSxNQUFNM0I7QUFBQUEsUUFDOUJLLG1CQUFtQm9CLFNBQVNFLE1BQU10QixxQkFBcUI7QUFBQSxNQUN6RCxDQUFDO0FBQ0Q3Ryx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNvSSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsSUFDbkQ7QUFBQSxFQUNGO0FBRUEsUUFBTWdELHdCQUF3QixPQUFPd0QsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTTNHLFdBQVcsTUFBTXRMLElBQUl1TDtBQUFBQSxRQUN6QixrREFBa0QwRyxPQUFPO0FBQUEsTUFDM0Q7QUFDQXBPLHNCQUFnQnlILFNBQVNFLElBQUk7QUFDN0I3SCx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVM4SCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBRUEsUUFBTXVLLG9CQUFvQixZQUFZO0FBQ3BDLFFBQUlwUyxjQUFjO0FBQ2hCLFVBQUk7QUFDRixjQUFNNUQsSUFBSTZTO0FBQUFBLFVBQ1IsK0NBQStDalAsYUFBYWdELEdBQUc7QUFBQSxVQUMvRDtBQUFBLFlBQ0U0RSxNQUFNLEVBQUVzSCxZQUFZdk4sT0FBT3dOLFlBQVksb0JBQUlwTCxLQUFLLEVBQUU7QUFBQSxVQUNwRDtBQUFBLFFBQ0Y7QUFDQWhFLDJCQUFtQixLQUFLO0FBQ3hCRSx3QkFBZ0IsSUFBSTtBQUNwQm9CLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQ0QrSCwrQkFBdUI7QUFBQSxNQUN6QixTQUFTMUIsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxNQUM5QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXdLLGVBQWUsT0FBT3RMLE1BQU07QUFDaENBLE1BQUUySCxlQUFlO0FBQ2pCLFFBQUk7QUFDRixZQUFNdFMsSUFBSTZQO0FBQUFBLFFBQ1IsK0NBQStDdk0sbUJBQW1Cc0QsR0FBRztBQUFBLFFBQ3JFeUQ7QUFBQUEsTUFDRjtBQUNBaEgseUJBQW1CLEtBQUs7QUFFeEI0QixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEK0gsNkJBQXVCO0FBQUEsSUFDekIsU0FBUzFCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU16RyxZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixTQUFTLE1BQU1GLGVBQWUsQ0FBQ2lSLE9BQU8sRUFBRSxHQUFHQSxHQUFHaFIsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLFFBSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlzRTtBQUFBLE1BRXRFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBR1gsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtFQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxtREFBa0Qsc0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsMkRBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFDYlEsbUNBQWEsU0FBUztBQUN0QlcsNkNBQXVCLEVBQUU7QUFDekJFLG1DQUFhLEtBQUs7QUFBQSxvQkFDcEI7QUFBQSxvQkFDQSxXQUFXLDJEQUEyRGQsY0FBYyxZQUFZLHVDQUF1QyxtQ0FBbUM7QUFBQSxvQkFBRztBQUFBO0FBQUEsc0JBSTNLM0MsZ0JBQWdCK0k7QUFBQUEsd0JBQ2QsQ0FBQ2xCLE1BQU1BLEVBQUU5RCxXQUFXLG1CQUFtQixDQUFDOEQsRUFBRTlEO0FBQUFBLHNCQUM1QyxFQUFFbUY7QUFBQUEsc0JBQ0g7QUFBQTtBQUFBO0FBQUEsa0JBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNO0FBQ2J0RyxtQ0FBYSxXQUFXO0FBQ3hCVyw2Q0FBdUIsRUFBRTtBQUN6QkUsbUNBQWEsS0FBSztBQUFBLG9CQUNwQjtBQUFBLG9CQUNBLFdBQVcsMkRBQTJEZCxjQUFjLGNBQWMsdUNBQXVDLG1DQUFtQztBQUFBLG9CQUFHO0FBQUE7QUFBQSxzQkFJN0szQyxnQkFBZ0IrSTtBQUFBQSx3QkFDZCxDQUFDbEIsTUFBTUEsRUFBRTlELFVBQVU4RCxFQUFFOUQsV0FBVztBQUFBLHNCQUNsQyxFQUFFbUY7QUFBQUEsc0JBQ0g7QUFBQTtBQUFBO0FBQUEsa0JBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWVBO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFDYnBHLGtDQUFZLE1BQU07QUFDbEJTLDZDQUF1QixFQUFFO0FBQ3pCRSxtQ0FBYSxLQUFLO0FBQUEsb0JBQ3BCO0FBQUEsb0JBQ0EsV0FBVyxpQ0FBaUNaLGFBQWEsU0FBUyx1Q0FBdUMsbUNBQW1DO0FBQUEsb0JBRTVJLGlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBO0FBQUEsa0JBUmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUNiQyxrQ0FBWSxNQUFNO0FBQ2xCUyw2Q0FBdUIsRUFBRTtBQUN6QkUsbUNBQWEsS0FBSztBQUFBLG9CQUNwQjtBQUFBLG9CQUNBLFdBQVcsaUNBQWlDWixhQUFhLFNBQVMsdUNBQXVDLG1DQUFtQztBQUFBLG9CQUU1SSxpQ0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0I7QUFBQTtBQUFBLGtCQVJqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFDYkMsa0NBQVksT0FBTztBQUNuQlMsNkNBQXVCLEVBQUU7QUFDekJFLG1DQUFhLEtBQUs7QUFBQSxvQkFDcEI7QUFBQSxvQkFDQSxXQUFXLGlDQUFpQ1osYUFBYSxVQUFVLHVDQUF1QyxtQ0FBbUM7QUFBQSxvQkFFN0ksaUNBQUMsc0JBQW1CLFdBQVUsYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQTtBQUFBLGtCQVJ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErQkE7QUFBQSxpQkFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvRUE7QUFBQSxlQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStFQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osT0FBT087QUFBQUEsZ0JBQ1A7QUFBQSxnQkFDQSxVQUFVLENBQUN5RSxNQUFNO0FBQ2Ysd0JBQU13TCxNQUFNeEwsRUFBRUUsT0FBT0Q7QUFDckJ6RSxpQ0FBZWdRLEdBQUc7QUFDbEIsc0JBQUlBLFFBQVEsSUFBSTtBQUNkbFEsa0NBQWMsRUFBRTtBQUFBLGtCQUNsQjtBQUFBLGdCQUNGO0FBQUEsZ0JBQ0EsY0FBYyxNQUFNQSxjQUFjQyxXQUFXO0FBQUEsZ0JBQzdDLFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTZHO0FBQUEsWUFFN0c7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlO0FBQUEsZ0JBQ3JCLFNBQVMsTUFBTUQsY0FBY0MsV0FBVztBQUFBLGdCQUN4QyxXQUFVO0FBQUEsZ0JBQTJGO0FBQUE7QUFBQSxjQUp2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsYUExR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJHQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFDQUFvQyxpQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNaa0IsdUJBQWFFLG9CQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUNBQW9DLDZCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ1pGLHVCQUFhRyxnQkFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFDQUFvQyxnQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNaSCx1QkFBYUksbUJBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxQ0FBb0MsNkJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDWkosdUJBQWFLLGdCQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlDQTtBQUFBLFFBR0NoQyxjQUFjLGVBQWUsQ0FBQ3ZCLHNCQUM3Qix1QkFBQyw2QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFHekJpTixjQUFjO0FBQUEsUUFFZHhMLGFBQWEsV0FDWjRHLHNCQUFzQixFQUFFUCxTQUFTakcsZ0JBQy9CO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsWUFBWWlMLEtBQUtTO0FBQUFBLGNBQ2ZsRixzQkFBc0IsRUFBRVAsU0FBU2pHO0FBQUFBLFlBQ25DO0FBQUEsWUFDQSxjQUFjRDtBQUFBQTtBQUFBQSxVQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLK0I7QUFBQSxXQW5LckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNLQTtBQUFBLFNBbExGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtTEE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXNUM7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsdUJBQWEsS0FBSztBQUNsQmtCLG9CQUFVLENBQUMsQ0FBQztBQUFBLFFBQ2Q7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsOEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVnTyxjQUFjLFlBQVUsTUFFNUQ7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVaLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ3pSLFVBQVV3VixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSnpILFNBQVMsRUFDVEQsWUFBWSxFQUNaakMsU0FBU3lKLE1BQU14SCxZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBT3JGLFVBQVVFLFlBQVk4TTtBQUFBQSxrQkFDN0IsVUFBVSxDQUFDNUwsVUFBVWtLLGlCQUFpQixZQUFZbEssS0FBSztBQUFBLGtCQUV0RHBJLGlCQUFPeUs7QUFBQUEsb0JBQUksQ0FBQ3dKLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU03UCxLQUN6QzZQLGdCQUFNOUksY0FEVzhJLE1BQU03UCxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FvQkE7QUFBQSxjQUNDeEMsT0FBT3NGLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnRGLGlCQUFPc0YsWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxpQkE3QjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVULHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQzlJLFVBQVV3VixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSnpILFNBQVMsRUFDVEQsWUFBWSxFQUNaakMsU0FBU3lKLE1BQU14SCxZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBT3JGLFVBQVVHLFdBQVc2TTtBQUFBQSxrQkFDNUIsVUFBVSxDQUFDNUwsVUFBVWtLLGlCQUFpQixXQUFXbEssS0FBSztBQUFBLGtCQUVyRGxJLGdCQUFNdUs7QUFBQUEsb0JBQUksQ0FBQ25DLFNBQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUtsRSxLQUN2Q2tFO0FBQUFBLDJCQUFLaUQ7QUFBQUEsc0JBQVU7QUFBQSxzQkFBRztBQUFBLHNCQUNsQmpELEtBQUtrRCxlQUFlbEQsS0FBS2tELGVBQWU7QUFBQSx5QkFGdkJsRCxLQUFLbEUsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBcUJBO0FBQUEsY0FDQ3hDLE9BQU91RixXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ2RixpQkFBT3VGLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBOUI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFjO0FBQUE7QUFBQSxvQkFFRix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUp0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxxQ0FBcUMvSSxVQUFVd1YsTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVMxSCxZQUFZLEVBQUVqQyxTQUFTeUosTUFBTXhILFlBQVksQ0FBQztBQUFBLGtCQUU1RCxPQUFPckYsVUFBVU0sZ0JBQWdCME07QUFBQUEsa0JBQ2pDLFVBQVUsQ0FBQzVMLFVBQVVrSyxpQkFBaUIsZ0JBQWdCbEssS0FBSztBQUFBLGtCQUUxRCxXQUFDLFNBQVMsVUFBVSxTQUFTLEVBQUVxQztBQUFBQSxvQkFBSSxDQUFDeUosVUFDbkMsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE9BQy9CQSxtQkFEaUJBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxrREFBaUQsaUNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT3BOO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3FCLE1BQU07QUFDZnBCLG9DQUFnQm9CLEVBQUVFLE9BQU9ELEtBQUs7QUFDOUJuQixnQ0FBWSxDQUFDa0QsVUFBVTtBQUFBLHNCQUNyQixHQUFHQTtBQUFBQSxzQkFDSHpDLG1CQUFtQlMsRUFBRUUsT0FBT0Q7QUFBQUEsb0JBQzlCLEVBQUU7QUFBQSxrQkFDSjtBQUFBLGtCQUNBLEtBQUs1QixrQkFBa0JwQixhQUFhRSxZQUFZO0FBQUE7QUFBQSxnQkFYbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV29EO0FBQUEsaUJBZnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWU7QUFBQTtBQUFBLG9CQUVGLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ2xILFVBQVV3VixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBUzFILFlBQVksRUFBRWpDLFNBQVN5SixNQUFNeEgsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU9yRixVQUFVSyxpQkFBaUIyTTtBQUFBQSxrQkFDbEMsVUFBVSxDQUFDNUwsVUFBVWtLLGlCQUFpQixpQkFBaUJsSyxLQUFLO0FBQUEsa0JBRTNEO0FBQUEsb0JBQ0M7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLGtCQUFRLEVBQ1JxQztBQUFBQSxvQkFBSSxDQUFDMEosWUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsU0FDakNBLHFCQURpQkEsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkF0Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdUJBO0FBQUEsaUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsWUFFQ25OLFNBQVNLLGtCQUFrQixjQUMxQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVPO0FBQUEsb0JBQ3pCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ2pKLFVBQVV3VixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSnpILFNBQVMsRUFDVEQsWUFBWSxFQUNaakMsU0FBU3lKLE1BQU14SCxZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBT3JGLFVBQVVPLHFCQUFxQnlNO0FBQUFBLGtCQUN0QyxVQUFVLENBQUM1TCxVQUNUa0ssaUJBQWlCLHFCQUFxQmxLLEtBQUs7QUFBQSxrQkFHNUNsSSxnQkFBTXVLO0FBQUFBLG9CQUFJLENBQUNuQyxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLbEUsS0FDdkNrRTtBQUFBQSwyQkFBS2lEO0FBQUFBLHNCQUFVO0FBQUEsc0JBQUc7QUFBQSxzQkFDbEJqRCxLQUFLa0QsZUFBZWxELEtBQUtrRCxlQUFlO0FBQUEseUJBRnZCbEQsS0FBS2xFLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXVCQTtBQUFBLGlCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdDQTtBQUFBLFlBRUQ0QyxTQUFTSyxrQkFBa0IsV0FDMUIsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxvQkFFSTtBQUFBLG9CQUN0Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxxQ0FBcUNqSixVQUFVd1YsTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0p6SCxTQUFTLEVBQ1RELFlBQVksRUFDWmpDLFNBQVN5SixNQUFNeEgsWUFBWSxDQUFDO0FBQUEsa0JBRWpDLE9BQU9yRixVQUFVUyxpQkFBaUJ1TTtBQUFBQSxrQkFDbEMsVUFBVSxDQUFDNUwsVUFDVGtLLGlCQUFpQixpQkFBaUJsSyxLQUFLO0FBQUEsa0JBR3hDcEcsZ0JBQU15STtBQUFBQSxvQkFBSSxDQUFDMkosU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS2hRLEtBQ3ZDZ1E7QUFBQUEsMkJBQUszQztBQUFBQSxzQkFBVTtBQUFBLHNCQUFJMkMsS0FBS0M7QUFBQUEseUJBRFBELEtBQUtoUSxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FzQkE7QUFBQSxpQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQkE7QUFBQSxZQUVENEMsU0FBU0ssa0JBQWtCLGNBQzFCLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsb0JBRU87QUFBQSxvQkFDekIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBO0FBQUE7QUFBQSxnQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcscUNBQXFDakosVUFBVXdWLE1BQU07QUFBQSxrQkFDaEUsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUNDLE9BQU9DLFdBQVc7QUFDL0Isd0JBQUksQ0FBQ0EsVUFBVSxDQUFDQSxPQUFPQyxTQUFVLFFBQU87QUFDeEMsMkJBQU9ELE9BQU9DLFNBQ1h6SCxTQUFTLEVBQ1RELFlBQVksRUFDWmpDLFNBQVN5SixNQUFNeEgsWUFBWSxDQUFDO0FBQUEsa0JBQ2pDO0FBQUEsa0JBQ0EsT0FBT3JGLFVBQVVRLFNBQVN3TTtBQUFBQSxrQkFDMUIsVUFBVSxDQUFDNUwsVUFBVWtLLGlCQUFpQixTQUFTbEssS0FBSztBQUFBLGtCQUVuRGxHLGlCQUFPdUk7QUFBQUEsb0JBQUksQ0FBQ2pELFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1wRCxLQUN6Q29EO0FBQUFBLDRCQUFNOEQ7QUFBQUEsc0JBQUs7QUFBQSxzQkFBSTlELE1BQU1nRTtBQUFBQSx5QkFESmhFLE1BQU1wRCxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FxQkE7QUFBQSxpQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4QkE7QUFBQSxZQUVENEMsU0FBU0UsV0FDUjVGLG9CQUFvQmtJLFNBQVMsSUFDM0IsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVHLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU94QyxVQUFVSTtBQUFBQSxrQkFDakIsSUFBRztBQUFBLGtCQUNILFVBQVUsQ0FBQ2UsTUFBTTtBQUNmeUssaUNBQWF6SyxDQUFDO0FBQUEsa0JBQ2hCO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsS0FBSzdHLG9CQUFvQmtJO0FBQUFBLGtCQUN6QixXQUFXLHFDQUFxQ3BMLFVBQVV3VixNQUFNO0FBQUE7QUFBQSxnQkFYbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVzZKO0FBQUEsY0FFNUpoUyxPQUFPd0YsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWeEYsaUJBQU93RixpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFRix1QkFBQyxVQUFLLFdBQVUsZ0VBQStEO0FBQUE7QUFBQSxnQkFDdkU5RixvQkFBb0JrSTtBQUFBQSxnQkFBTztBQUFBLG1CQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBLElBRUEsdUJBQUMsT0FBRSxXQUFVLDRCQUEyQiw2QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQsSUFHdkQsdUJBQUMsT0FBRSxXQUFVLDhCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsWUFHMUMsdUJBQUMsU0FBSSxXQUFVLHFGQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsdUNBQUMsb0JBQWlCLE9BQU0sU0FBUSxXQUFVLGVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsZ0JBQ3JELHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0Msd0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3BIO0FBQUFBLG9CQUNULFdBQVU7QUFBQTtBQUFBLGtCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHdUY7QUFBQSxnQkFFdkYsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUQ7QUFBQSxtQkFObkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxVQUNFWixXQUNDYyxtQkFBbUIsYUFDakIsQ0FBQ3FGLGNBQWNyRyxvQkFBb0JrSSxXQUFXO0FBQUEsZ0JBRW5ELFNBQVM2STtBQUFBQSxnQkFDVCxXQUFXLDJFQUEyRTdRLFVBQVUsbUNBQW1DYyxtQkFBbUIsV0FBVyxrQ0FBa0NBLG1CQUFtQixhQUFhLG9DQUFvQywrQkFBK0I7QUFBQSxnQkFFclNkLG9CQUNHLGtCQUNBYyxtQkFBbUIsV0FDakIsV0FDQUEsbUJBQW1CLGFBQ2pCLGFBQ0E7QUFBQTtBQUFBLGNBaEJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBalVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa1VBO0FBQUEsYUF0VUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVVQTtBQUFBO0FBQUEsTUE5VUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBK1VBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzFCO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCZ0Isb0JBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDZDtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxpQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVTRSLGNBQ3BDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxvQkFFWix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUp4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLElBQUc7QUFBQSxrQkFDSCxPQUFPNUwsZUFBZVg7QUFBQUEsa0JBQ3RCLFVBQVVrTTtBQUFBQSxrQkFDVjtBQUFBLGtCQUNBO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLElBQUcsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZCO0FBQUEsb0JBQzVCcFQsT0FBT3lLO0FBQUFBLHNCQUFJLENBQUN3SixVQUNYLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU03UCxLQUNsQzZQLGdCQUFNOUksY0FESThJLE1BQU03UCxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBO0FBQUEsZ0JBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUE7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBUztBQUFBO0FBQUEsb0JBRVIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBO0FBQUE7QUFBQSxnQkFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxJQUFHO0FBQUEsa0JBQ0gsT0FBT3lELGVBQWVWO0FBQUFBLGtCQUN0QixVQUFVaU07QUFBQUEsa0JBQ1Y7QUFBQSxrQkFDQTtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFlBQU8sT0FBTSxJQUFHLCtCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLG9CQUMvQmxULE1BQU11SztBQUFBQSxzQkFBSSxDQUFDbkMsU0FDVix1QkFBQyxZQUFzQixPQUFPQSxLQUFLbEUsS0FDaENrRSxlQUFLaUQsYUFES2pELEtBQUtsRSxLQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBO0FBQUEsZ0JBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUE7QUFBQSxjQUNDeEMsT0FBT3VGLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnZGLGlCQUFPdUYsV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxpQkF4QjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWM7QUFBQTtBQUFBLG9CQUVGLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSnREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUMwTSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBUzFILFlBQVksRUFBRWpDLFNBQVN5SixNQUFNeEgsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU94RSxnQkFBZ0JQLGdCQUFnQjBNO0FBQUFBLGtCQUN2QyxVQUFVLENBQUM1TCxVQUNUc0ssc0JBQXNCLGdCQUFnQnRLLEtBQUs7QUFBQSxrQkFHNUMsV0FBQyxTQUFTLFVBQVUsU0FBUyxFQUFFcUM7QUFBQUEsb0JBQUksQ0FBQ3lKLFVBQ25DLHVCQUFDLE9BQU8sUUFBUCxFQUF3QyxPQUFPQSxPQUM3Q0EsbUJBRGlCQSxNQUFNN0gsWUFBWSxHQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxpQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxpQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixPQUFPeEUsZUFBZUg7QUFBQUEsa0JBQ3RCLFVBQVUsQ0FBQ1MsTUFDVEwsa0JBQWtCLENBQUNxQyxVQUFVO0FBQUEsb0JBQzNCLEdBQUdBO0FBQUFBLG9CQUNIekMsbUJBQW1CUyxFQUFFRSxPQUFPRDtBQUFBQSxrQkFDOUIsRUFBRTtBQUFBO0FBQUEsZ0JBUk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0c7QUFBQSxpQkFiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWU7QUFBQTtBQUFBLG9CQUVGLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUN5TCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBUzFILFlBQVksRUFBRWpDLFNBQVN5SixNQUFNeEgsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU94RSxnQkFBZ0JSLGlCQUFpQjJNO0FBQUFBLGtCQUN4QyxVQUFVLENBQUM1TCxVQUNUc0ssc0JBQXNCLGlCQUFpQnRLLEtBQUs7QUFBQSxrQkFHN0M7QUFBQSxvQkFDQztBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsa0JBQVEsRUFDUnFDO0FBQUFBLG9CQUFJLENBQUMwSixZQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxTQUNqQ0EscUJBRGlCQSxTQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F5QkE7QUFBQSxpQkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0E7QUFBQSxZQUVDdE0sZUFBZVIsa0JBQWtCLGNBQ2hDLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsb0JBRU87QUFBQSxvQkFDekIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBO0FBQUE7QUFBQSxnQkFMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ3dNLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKekgsU0FBUyxFQUNURCxZQUFZLEVBQ1pqQyxTQUFTeUosTUFBTXhILFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPeEUsZ0JBQWdCTixxQkFBcUJ5TTtBQUFBQSxrQkFDNUMsVUFBVSxDQUFDNUwsVUFDVHNLLHNCQUFzQixxQkFBcUJ0SyxLQUFLO0FBQUEsa0JBR2pEbEksZ0JBQU11SztBQUFBQSxvQkFBSSxDQUFDbkMsU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS2xFLEtBQ3ZDa0UsZUFBS2lELGFBRFlqRCxLQUFLbEUsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBc0JBO0FBQUEsaUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBO0FBQUEsWUFFRHlELGVBQWVSLGtCQUFrQixXQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVJO0FBQUEsb0JBQ3RCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUN3TSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSnpILFNBQVMsRUFDVEQsWUFBWSxFQUNaakMsU0FBU3lKLE1BQU14SCxZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBT3hFLGdCQUFnQkosaUJBQWlCdU07QUFBQUEsa0JBQ3hDLFVBQVUsQ0FBQzVMLFVBQ1RzSyxzQkFBc0IsaUJBQWlCdEssS0FBSztBQUFBLGtCQUc3Q3BHLGdCQUFNeUk7QUFBQUEsb0JBQUksQ0FBQzJKLFNBQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUtoUSxLQUN2Q2dRLGVBQUszQyxhQURZMkMsS0FBS2hRLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXNCQTtBQUFBLGlCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStCQTtBQUFBLFlBRUR5RCxlQUFlUixrQkFBa0IsY0FDaEMsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxvQkFFTztBQUFBLG9CQUN6Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDd00sT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0p6SCxTQUFTLEVBQ1RELFlBQVksRUFDWmpDLFNBQVN5SixNQUFNeEgsWUFBWSxDQUFDO0FBQUEsa0JBRWpDLE9BQU94RSxnQkFBZ0JMLFNBQVN3TTtBQUFBQSxrQkFDaEMsVUFBVSxDQUFDNUwsVUFBVXNLLHNCQUFzQixTQUFTdEssS0FBSztBQUFBLGtCQUV4RGxHLGlCQUFPdUk7QUFBQUEsb0JBQUksQ0FBQ2pELFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1wRCxLQUN6Q29ELGdCQUFNOEQsUUFEVzlELE1BQU1wRCxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FvQkE7QUFBQSxpQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkE7QUFBQSxZQUdGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFBNEo7QUFBQTtBQUFBLGNBRnhLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUEvT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnUEE7QUFBQSxhQXBQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcVBBO0FBQUE7QUFBQSxNQTVQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUE2UEE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXbEQ7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJFLDBCQUFnQixJQUFJO0FBQUEsUUFDdEI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMscURBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCxnQkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDK0csTUFBTTtBQUNmQSxrQkFBRTJILGVBQWU7QUFDakIwRCxrQ0FBa0I7QUFBQSxjQUNwQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFBMEo7QUFBQTtBQUFBLGdCQUZ0SztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBO0FBQUEsWUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQTtBQUFBLE1BM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRCQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxRQUFPO0FBQUEsY0FDUCxTQUFRO0FBQUEsY0FFUjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxlQUFjO0FBQUEsa0JBQ2QsZ0JBQWU7QUFBQSxrQkFDZixhQUFZO0FBQUEsa0JBQ1osR0FBRTtBQUFBO0FBQUEsZ0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTRIO0FBQUE7QUFBQSxZQVY5SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsbUNBQ1h0UCwyQkFBaUJNLFNBQ2QsZ0JBQWdCTixpQkFBaUJPLGFBQWErRSxVQUFVLENBQUMsa0JBQ3pELG1CQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVnRGLDJCQUFpQk0sU0FDZCxxQkFBcUJOLGlCQUFpQk8sYUFBYStFLFVBQVUsQ0FBQywwQkFDOUQsOERBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUVGLE1BQU14RjtBQUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkQyxtQ0FBeUIsS0FBSztBQUM5QkUsOEJBQW9CO0FBQUEsWUFDbEJDLEtBQUs7QUFBQSxZQUNMQyxRQUFRO0FBQUEsWUFDUkMsUUFBUTtBQUFBLFlBQ1JDLGdCQUFnQjtBQUFBLFlBQ2hCQyxRQUFRO0FBQUEsWUFDUkMsYUFBYTtBQUFBLFVBQ2YsQ0FBQztBQUFBLFFBQ0g7QUFBQSxRQUNBLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUNQLFdBQVU7QUFBQSxRQUVWO0FBQUEsaUNBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQUcsV0FBVSxRQUMvQixpQ0FBQyxPQUFJLE1BQU0sSUFDVCxpQ0FBQyxRQUFLLFdBQVUsK0NBQ2QsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBFQUF5RTtBQUFBO0FBQUEsZ0JBQ2pGLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsYUFBWTtBQUFBLGtCQUNaLE9BQU9QLGlCQUFpQkcsVUFBVTJQO0FBQUFBLGtCQUNsQyxVQUFVLENBQUM1TCxVQUNUakUsb0JBQW9CLENBQUNnRyxVQUFVO0FBQUEsb0JBQzdCLEdBQUdBO0FBQUFBLG9CQUNIOUYsUUFBUStEO0FBQUFBLGtCQUNWLEVBQUU7QUFBQSxrQkFFSixXQUFVO0FBQUEsa0JBQ1YsU0FBU3ZJLGVBQWU0SyxJQUFJLENBQUM2SixTQUFTO0FBQUEsb0JBQ3BDaFYsT0FBT2dWO0FBQUFBLG9CQUNQbE0sT0FBT2tNO0FBQUFBLGtCQUNULEVBQUU7QUFBQTtBQUFBLGdCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFNO0FBQUEsaUJBakJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsWUFFQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBFQUF5RSxzQkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQyxNQUFNO0FBQUEsZ0JBQU47QUFBQSxrQkFDQyxNQUFNO0FBQUEsa0JBQ04sYUFBWTtBQUFBLGtCQUNaLE9BQU9wUSxpQkFBaUJJO0FBQUFBLGtCQUN4QixVQUFVLENBQUM2RCxNQUNUaEUsb0JBQW9CLENBQUNnRyxVQUFVO0FBQUEsb0JBQzdCLEdBQUdBO0FBQUFBLG9CQUNIN0YsUUFBUTZELEVBQUVFLE9BQU9EO0FBQUFBLGtCQUNuQixFQUFFO0FBQUEsa0JBRUosV0FBVTtBQUFBO0FBQUEsZ0JBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVW1IO0FBQUEsaUJBZHJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFFQ2xFLGlCQUFpQkcsV0FBVyxlQUMzQix1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDJFQUEwRTtBQUFBO0FBQUEsZ0JBQzFFLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FDRUgsaUJBQWlCSyxpQkFDYmpHLE1BQU00RixpQkFBaUJLLGNBQWMsSUFDckM7QUFBQSxrQkFFTixVQUFVLENBQUNnUSxHQUFHcE8sZUFDWmhDLG9CQUFvQixDQUFDZ0csVUFBVTtBQUFBLG9CQUM3QixHQUFHQTtBQUFBQSxvQkFDSDVGLGdCQUFnQjRCO0FBQUFBLGtCQUNsQixFQUFFO0FBQUEsa0JBRUosV0FBVTtBQUFBLGtCQUNWLFFBQU87QUFBQSxrQkFDUCxhQUFZO0FBQUEsa0JBQ1osY0FBYyxDQUFDcU8sWUFDYkEsV0FBV0EsVUFBVWxXLE1BQU0sRUFBRW1XLFFBQVEsS0FBSztBQUFBO0FBQUEsZ0JBaEI5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkc7QUFBQSxjQUVILHVCQUFDLE9BQUUsV0FBVSxvQ0FBbUMsc0RBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxlQW5FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFFQSxLQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVFQSxLQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlFQSxLQTFFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNO0FBQ2J4USwyQ0FBeUIsS0FBSztBQUM5QkUsc0NBQW9CO0FBQUEsb0JBQ2xCQyxLQUFLO0FBQUEsb0JBQ0xDLFFBQVE7QUFBQSxvQkFDUkMsUUFBUTtBQUFBLG9CQUNSQyxnQkFBZ0I7QUFBQSxvQkFDaEJDLFFBQVE7QUFBQSxvQkFDUkMsYUFBYTtBQUFBLGtCQUNmLENBQUM7QUFBQSxnQkFDSDtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBMkY7QUFBQTtBQUFBLGNBYnZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU0M7QUFBQUEsZ0JBQ1QsU0FBU3dJO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFFVGhKLDJCQUFpQk0sU0FDZCxVQUFVTixpQkFBaUJPLGFBQWErRSxVQUFVLENBQUMsaUJBQ25EO0FBQUE7QUFBQSxjQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQTtBQUFBO0FBQUEsTUF6SkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMEpBO0FBQUEsT0FsOEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtOEJBLEtBcDhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcThCQTtBQUVKO0FBQUV6SixHQTE2RklELGlCQUFlO0FBQUE0VSxLQUFmNVU7QUE0NkZOLGVBQWVBO0FBQWdCLElBQUE0VTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ3VzdG9tQWxlcnQiLCJGYVdoYXRzYXBwU3F1YXJlIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsIlNpZGViYXIiLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIklvTWRNb3JlIiwiTWRHcmlkVmlldyIsIk1kVmlld0xpc3QiLCJNZE91dGxpbmVUYWJsZVJvd3MiLCJNZEFzc2lnbm1lbnRJbmQiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJDaXJjdWxhckxvYWRlciIsImhhbmRsZUVucm9sbG1lbnRSZXF1ZXN0UHJpbnQiLCJDdXN0b21BbGVydERpYWxvZyIsImZpZWxkU2l6ZSIsIkJyZWFkY3J1bWIiLCJkYXlqcyIsIlNlYXJjaE91dGxpbmVkIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJub3RpZmljYXRpb24iLCJJbnB1dCIsIkJ1dHRvbiIsIkRhdGVQaWNrZXIiLCJBbnRNb2RhbCIsIlRhYmxlIiwiQ2FyZCIsIlJvdyIsIkNvbCIsIkNoZWNrYm94IiwiTU9CSUxFX0VOUk9MTF9TVEFUVVNfQ09ORklHIiwia2V5IiwibGFiZWwiLCJjb2xvciIsImJnTGlnaHQiLCJ0ZXh0Q29sb3IiLCJpY29uQ29sb3IiLCJyaW5nQ29sb3IiLCJpY29uIiwiU1RBVFVTX09QVElPTlMiLCJNb2JpbGVBcHBFbnJvbGwiLCJfcyIsImdyb3VwcyIsInNldEdyb3VwcyIsInVzZXJzIiwic2V0VXNlcnMiLCJUYWJsZUVucm9sbHMiLCJzZXRUYWJsZUVucm9sbHMiLCJmaWx0ZXJlZEVucm9sbHMiLCJzZXRGaWx0ZXJlZEVucm9sbHMiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVcGRhdGVHcm91cCIsInNldEN1cnJlbnRVcGRhdGVHcm91cCIsImF2YWlsYWJsZVRpY2tldHMiLCJzZXRBdmFpbGFibGVUaWNrZXRzIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwiYXZhaWxhYmxlVGlja2V0c0FkZCIsInNldEF2YWlsYWJsZVRpY2tldHNBZGQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImlzRGF0YVRhYmxlTG9hZGluZyIsInNldElzRGF0YVRhYmxlTG9hZGluZyIsImVycm9ycyIsInNldEVycm9ycyIsImFsbEVucm9sbFVybCIsInNldEFsbEVucm9sbFVybCIsImxlYWRzIiwic2V0TGVhZHMiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJ3aGF0c2FwcEVuYWJsZSIsInNldFdoYXRzYXBwRW5hYmxlIiwiZW5yb2xsbWVudFN0ZXAiLCJzZXRFbnJvbGxtZW50U3RlcCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJpc0V4aXN0aW5nRW5yb2xsbWVudCIsInNldElzRXhpc3RpbmdFbnJvbGxtZW50IiwiYWRtaW4iLCJzZXRBZG1pbiIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInZpZXdNb2RlIiwic2V0Vmlld01vZGUiLCJjdXJyZW50UGFnZSIsInNldEN1cnJlbnRQYWdlIiwiaXRlbXNQZXJQYWdlIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5Iiwic2VsZWN0ZWRFbnJvbGxtZW50cyIsInNldFNlbGVjdGVkRW5yb2xsbWVudHMiLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJzaG93U3RhdHVzVXBkYXRlTW9kYWwiLCJzZXRTaG93U3RhdHVzVXBkYXRlTW9kYWwiLCJzdGF0dXNVcGRhdGVEYXRhIiwic2V0U3RhdHVzVXBkYXRlRGF0YSIsIl9pZCIsInN0YXR1cyIsInJlbWFyayIsImZvbGxvd191cF9kYXRlIiwiaXNCdWxrIiwic2VsZWN0ZWRJZHMiLCJpc1N0YXR1c1VwZGF0aW5nIiwic2V0SXNTdGF0dXNVcGRhdGluZyIsInN1bW1hcnlTdGF0cyIsInNldFN1bW1hcnlTdGF0cyIsInRvdGFsRW5yb2xsbWVudHMiLCJ0b3RhbFRpY2tldHMiLCJ1bmlxdWVDdXN0b21lcnMiLCJ1bmlxdWVHcm91cHMiLCJ0b2RheSIsIkRhdGUiLCJjdXJyZW50WWVhciIsImdldEZ1bGxZZWFyIiwiY3VycmVudE1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImN1cnJlbnRZZWFyTW9udGgiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInllYXIiLCJtb250aCIsInNsaWNlIiwiZGF5IiwiZ2V0RGF0ZSIsInBhcnNlRGF0ZSIsImRhdGVTdHJpbmciLCJzcGxpdCIsInBhcnNlSW50IiwibW9udGhOYW1lIiwibW9udGhOYW1lcyIsImZvcm1hdFRvWWVhck1vbnRoIiwiZ2V0TW9udGhEYXRlUmFuZ2UiLCJzdGFydERhdGUiLCJlbmREYXRlIiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsInNlbGVjdGVkRGF0ZSIsInNldFNlbGVjdGVkRGF0ZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9pZCIsInVzZXJfaWQiLCJub19vZl90aWNrZXRzIiwicmVmZXJyZWRfdHlwZSIsInBheW1lbnRfdHlwZSIsInJlZmVycmVkX2N1c3RvbWVyIiwiYWdlbnQiLCJyZWZlcnJlZF9sZWFkIiwiY2hpdF9hc2tpbmdfbW9udGgiLCJpc1ZlcmlmaWVkIiwic2V0SXNWZXJpZmllZCIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJ0aWNrZXRzIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJ1c2VyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInVzZXJPYmoiLCJKU09OIiwicGFyc2UiLCJhZG1pbklkIiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJnZXRTdGF0dXNDb3VudHMiLCJjb250YWN0ZWQiLCJmaWx0ZXIiLCJ1IiwidG90YWwiLCJsZW5ndGgiLCJDb250YWN0ZWQiLCJJbnRlcmVzdGVkIiwiQ29udmVydGVkIiwiUmVqZWN0ZWQiLCJnZXRTdGF0dXNDb2xvciIsImdldFN0YXR1c0ljb24iLCJnZXRUYWJGaWx0ZXJlZEVucm9sbHMiLCJlbnJvbGwiLCJoYW5kbGVTZWxlY3RFbnJvbGxtZW50IiwiaWQiLCJwcmV2IiwiaW5jbHVkZXMiLCJpdGVtIiwiaGFuZGxlU2VsZWN0QWxsIiwidGFiRmlsdGVyZWQiLCJjdXJyZW50SWRzIiwibWFwIiwiaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZSIsImZldGNoQWxsRW5yb2xsbWVudERhdGEiLCJyZXMiLCJyYXdEYXRhIiwicmVkdWNlIiwic3VtIiwiU2V0IiwiQm9vbGVhbiIsInNpemUiLCJncm91cF9uYW1lIiwiaW5kZXgiLCJtb2JpbGVfZW5yb2xsX2NvZGUiLCJuYW1lIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZW5yb2xsbWVudF9kYXRlIiwiY3JlYXRlZEF0IiwicmVmZXJyZWRfYnkiLCJyZWZlcnJlZF9lbXBsb3llZSIsImFjdGlvbiIsIml0ZW1zIiwib3BlblN0YXR1c1VwZGF0ZU1vZGFsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiaGFuZGxlRW5yb2xsQ2xpY2siLCJlcnIiLCJmaWx0ZXJlZCIsInRvTG93ZXJDYXNlIiwidG9TdHJpbmciLCJDb250YWN0U3VtbWFyeURhc2hib2FyZCIsImNvdW50cyIsInBlbmRpbmdDb3VudCIsImNvbnZlcnNpb25SYXRlIiwidG9GaXhlZCIsInJlamVjdGlvblJhdGUiLCJwYXJzZUZsb2F0IiwiY2ZnIiwiY291bnQiLCJwZXJjZW50YWdlIiwid2lkdGgiLCJoYW5kbGVTdGF0dXNVcGRhdGVTdWJtaXQiLCJpZHNUb1VwZGF0ZSIsInVwZGF0ZVByb21pc2VzIiwicHV0IiwiUHJvbWlzZSIsImFsbCIsIkFjdGlvbkRyb3Bkb3duIiwibG9nIiwiaGFuZGxlRW5yb2xsQ2xpY2tXcmFwcGVyIiwicmVuZGVyRW5yb2xsbWVudENhcmQiLCJpc1BlbmRpbmciLCJpc1NlbGVjdGVkIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJFbnJvbGxSb3ciLCJTaW1wbGVQYWdpbmF0aW9uIiwidG90YWxQYWdlcyIsIm9uUGFnZUNoYW5nZSIsInBhZ2VzIiwibWF4IiwicHVzaCIsImkiLCJNYXRoIiwibWluIiwicGFnZSIsInJlbmRlckVucm9sbHMiLCJ0YWJGaWx0ZXJlZEVucm9sbHMiLCJ0YWJJbmRleE9mTGFzdEl0ZW0iLCJ0YWJJbmRleE9mRmlyc3RJdGVtIiwidGFiQ3VycmVudEl0ZW1zIiwidGFiVG90YWxQYWdlcyIsImNlaWwiLCJTZWxlY3Rpb25IZWFkZXIiLCJ0YWJsZUNvbHVtbnMiLCJoZWFkZXIiLCJyZW5kZXIiLCJyZWNvcmQiLCJjb2x1bW5zIiwidXNlcklkIiwiZ3JvdXBJZCIsInJlZmVycmVkQ3VzdG9tZXJJZCIsInJlZmVycmVkTGVhZElkIiwiYWdlbnRJZCIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwidGlja2V0c0NvdW50IiwidGlja2V0RW50cmllcyIsInRpY2tldE51bWJlciIsInRpY2tldEVudHJ5IiwicG9zdCIsImhlYWRlcnMiLCJkZWxldGUiLCJkZWxldGVkX2J5IiwiZGVsZXRlZF9hdCIsImZldGNoVXNlcnMiLCJmZXRjaEFnZW50cyIsImZldGNoTGVhZHMiLCJoYW5kbGVWZXJpZnkiLCJ3YXJuaW5nIiwicGFyYW1zIiwic2VsZWN0ZWRVc2VyIiwiZmluZCIsImciLCJzZWxlY3RlZEFnZW50IiwiYSIsInNlbGVjdGVkUmVmZXJyZWRDdXN0b21lciIsInNlbGVjdGVkUmVmZXJyZWRMZWFkIiwibCIsImFnZW50TmFtZSIsInJlZmVycmVkQ3VzdG9tZXJOYW1lIiwicmVmZXJyZWRMZWFkTmFtZSIsImxlYWRfbmFtZSIsInJlZmVycmVkSW5mb1BhcnRzIiwic2VsZWN0ZWRCeSIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsIm1hcmdpbkJvdHRvbSIsIm1hcmdpbiIsImJvcmRlclRvcCIsImRlc2NyaXB0aW9uIiwicGFydCIsImR1cmF0aW9uIiwic3VjY2VzcyIsImhhbmRsZU11bHRpU3RlcCIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInByZXZEYXRhIiwicHJldkVycm9ycyIsImhhbmRsZUFudElucHV0RFNlbGVjdCIsImZldGNoVGlja2V0cyIsImhhbmRsZUNoYW5nZSIsInZhbGlkYXRlIiwibmV3RXJyb3JzIiwibm9PZlRpY2tldHMiLCJ0cmltIiwiaXNOYU4iLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJwcmV2U3RhdGUiLCJlbnJvbGxJZCIsImluZm8iLCJoYW5kbGVEZWxldGVHcm91cCIsImhhbmRsZVVwZGF0ZSIsInAiLCJ2YWwiLCJoZWlnaHQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidW5kZWZpbmVkIiwiZ3JvdXAiLCJwVHlwZSIsInJlZlR5cGUiLCJsZWFkIiwibGVhZF9waG9uZSIsIm9wdCIsIl8iLCJjdXJyZW50Iiwic3RhcnRPZiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vYmlsZUFwcEVucm9sbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuLy8gaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcclxuLy8gaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbi8vIGltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuLy8gaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbi8vIGltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuLy8gaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHBTcXVhcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuLy8gaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biwgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuLy8gaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuLy8gaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG4vLyBpbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG4vLyBpbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG4vLyBpbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG4vLyBjb25zdCBNb2JpbGVBcHBFbnJvbGwgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbVGFibGVFbnJvbGxzLCBzZXRUYWJsZUVucm9sbHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW2F2YWlsYWJsZVRpY2tldHMsIHNldEF2YWlsYWJsZVRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2N1cnJlbnRHcm91cCwgc2V0Q3VycmVudEdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFthdmFpbGFibGVUaWNrZXRzQWRkLCBzZXRBdmFpbGFibGVUaWNrZXRzQWRkXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2lzRGF0YVRhYmxlTG9hZGluZywgc2V0SXNEYXRhVGFibGVMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4vLyAgIGNvbnN0IFthbGxFbnJvbGxVcmwsIHNldEFsbEVucm9sbFVybF0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuLy8gICBjb25zdCBbbGVhZHMsIHNldExlYWRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFt3aGF0c2FwcEVuYWJsZSwgc2V0V2hhdHNhcHBFbmFibGVdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbi8vICAgY29uc3QgW2Vucm9sbG1lbnRTdGVwLCBzZXRFbnJvbGxtZW50U3RlcF0gPSB1c2VTdGF0ZShcInZlcmlmeVwiKTtcclxuLy8gICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4vLyAgICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuLy8gICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4vLyAgIH0pO1xyXG4vLyAgIGNvbnN0IFtpc0V4aXN0aW5nRW5yb2xsbWVudCwgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFthZG1pbiwgc2V0QWRtaW5dID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIC8vIFN0YXRlIGZvciBzdW1tYXJ5IG1ldHJpY3NcclxuLy8gICBjb25zdCBbc3VtbWFyeVN0YXRzLCBzZXRTdW1tYXJ5U3RhdHNdID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgdG90YWxFbnJvbGxtZW50czogMCxcclxuLy8gICAgIHRvdGFsVGlja2V0czogMCxcclxuLy8gICAgIHVuaXF1ZUN1c3RvbWVyczogMCxcclxuLy8gICAgIHVuaXF1ZUdyb3VwczogMCxcclxuLy8gICB9KTtcclxuXHJcbi8vICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgIGNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuLy8gICBjb25zdCBjdXJyZW50TW9udGggPSBTdHJpbmcodG9kYXkuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuLy8gICBjb25zdCBjdXJyZW50WWVhck1vbnRoID0gYCR7Y3VycmVudFllYXJ9LSR7Y3VycmVudE1vbnRofWA7XHJcblxyXG4vLyAgIGZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZSkge1xyXG4vLyAgICAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuLy8gICAgIGNvbnN0IG1vbnRoID0gYDAke2RhdGUuZ2V0TW9udGgoKSArIDF9YC5zbGljZSgtMik7XHJcbi8vICAgICBjb25zdCBkYXkgPSBgMCR7ZGF0ZS5nZXREYXRlKCl9YC5zbGljZSgtMik7XHJcbi8vICAgICByZXR1cm4gYCR7eWVhcn0tJHttb250aH0tJHtkYXl9YDtcclxuLy8gICB9XHJcblxyXG4vLyAgIGNvbnN0IHBhcnNlRGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbi8vICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gZGF0ZVN0cmluZy5zcGxpdChcIi1cIik7XHJcbi8vICAgICByZXR1cm4ge1xyXG4vLyAgICAgICB5ZWFyLFxyXG4vLyAgICAgICBtb250aDogU3RyaW5nKHBhcnNlSW50KG1vbnRoKSkucGFkU3RhcnQoMiwgXCIwXCIpLFxyXG4vLyAgICAgICBtb250aE5hbWU6IG1vbnRoTmFtZXNbcGFyc2VJbnQobW9udGgpIC0gMV0sXHJcbi8vICAgICB9O1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZvcm1hdFRvWWVhck1vbnRoID0gKHllYXIsIG1vbnRoKSA9PiB7XHJcbi8vICAgICByZXR1cm4gYCR7eWVhcn0tJHtTdHJpbmcobW9udGgpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGdldE1vbnRoRGF0ZVJhbmdlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuLy8gICAgIGNvbnN0IHsgeWVhciwgbW9udGggfSA9IHBhcnNlRGF0ZShkYXRlU3RyaW5nKTtcclxuLy8gICAgIGNvbnN0IHN0YXJ0RGF0ZSA9IG5ldyBEYXRlKHllYXIsIHBhcnNlSW50KG1vbnRoKSAtIDEsIDEpO1xyXG4vLyAgICAgY29uc3QgZW5kRGF0ZSA9IG5ldyBEYXRlKHllYXIsIHBhcnNlSW50KG1vbnRoKSwgMCk7XHJcblxyXG4vLyAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgZnJvbV9kYXRlOiBmb3JtYXREYXRlKHN0YXJ0RGF0ZSksXHJcbi8vICAgICAgIHRvX2RhdGU6IGZvcm1hdERhdGUoZW5kRGF0ZSksXHJcbi8vICAgICB9O1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbi8vICAgY29uc3QgbW9udGhOYW1lcyA9IFtcclxuLy8gICAgIFwiSmFudWFyeVwiLFxyXG4vLyAgICAgXCJGZWJydWFyeVwiLFxyXG4vLyAgICAgXCJNYXJjaFwiLFxyXG4vLyAgICAgXCJBcHJpbFwiLFxyXG4vLyAgICAgXCJNYXlcIixcclxuLy8gICAgIFwiSnVuZVwiLFxyXG4vLyAgICAgXCJKdWx5XCIsXHJcbi8vICAgICBcIkF1Z3VzdFwiLFxyXG4vLyAgICAgXCJTZXB0ZW1iZXJcIixcclxuLy8gICAgIFwiT2N0b2JlclwiLFxyXG4vLyAgICAgXCJOb3ZlbWJlclwiLFxyXG4vLyAgICAgXCJEZWNlbWJlclwiLFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbi8vICAgICB1c2VyX2lkOiBcIlwiLFxyXG4vLyAgICAgbm9fb2ZfdGlja2V0czogXCJcIixcclxuLy8gICAgIHJlZmVycmVkX3R5cGU6IFwiXCIsXHJcbi8vICAgICBwYXltZW50X3R5cGU6IFwiXCIsXHJcbi8vICAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuLy8gICAgIGFnZW50OiBcIlwiLFxyXG4vLyAgICAgcmVmZXJyZWRfbGVhZDogXCJcIixcclxuLy8gICAgIGNoaXRfYXNraW5nX21vbnRoOiBcIlwiLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCBbaXNWZXJpZmllZCwgc2V0SXNWZXJpZmllZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICBncm91cF9pZDogXCJcIixcclxuLy8gICAgIHVzZXJfaWQ6IFwiXCIsXHJcbi8vICAgICB0aWNrZXRzOiBcIlwiLFxyXG4vLyAgICAgcGF5bWVudF90eXBlOiBcIlwiLFxyXG4vLyAgICAgcmVmZXJyZWRfdHlwZTogXCJcIixcclxuLy8gICAgIHJlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4vLyAgICAgYWdlbnQ6IFwiXCIsXHJcbi8vICAgICByZWZlcnJlZF9sZWFkOiBcIlwiLFxyXG4vLyAgICAgY2hpdF9hc2tpbmdfbW9udGg6IFwiXCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbi8vICAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuLy8gICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4vLyAgICAgY29uc3QgYWRtaW5JZCA9IHVzZXJPYmo/Ll9pZDtcclxuLy8gICAgIGlmIChhZG1pbklkKSB7XHJcbi8vICAgICAgIHNldEFkbWluKHVzZXJPYmouX2lkKTtcclxuLy8gICAgIH0gZWxzZSB7XHJcbi8vICAgICAgIHNldEFkbWluKFwiXCIpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbi8vICAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaEdyb3VwcygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgLy8gRXh0cmFjdGVkIGZldGNoIGZ1bmN0aW9uIHRvIHJldXNlIGFmdGVyIG11dGF0aW9uc1xyXG4vLyAgIGNvbnN0IGZldGNoQWxsRW5yb2xsbWVudERhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvbW9iaWxlLWFwcC1lbnJvbGwvZ2V0LW1vYmlsZS1hcHAtZW5yb2xsXCIpO1xyXG4vLyAgICAgICBjb25zdCByYXdEYXRhID0gcmVzLmRhdGE7XHJcblxyXG4vLyAgICAgICAvLyBDb21wdXRlIHN1bW1hcnkgbWV0cmljcyBmcm9tIHJhdyBkYXRhXHJcbi8vICAgICAgIGNvbnN0IHRvdGFsRW5yb2xsbWVudHMgPSByYXdEYXRhLmxlbmd0aDtcclxuLy8gICAgICAgY29uc3QgdG90YWxUaWNrZXRzID0gcmF3RGF0YS5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgKGl0ZW0ubm9fb2ZfdGlja2V0cyB8fCAwKSwgMCk7XHJcbi8vICAgICAgIGNvbnN0IHVuaXF1ZUN1c3RvbWVycyA9IG5ldyBTZXQocmF3RGF0YS5tYXAoaXRlbSA9PiBpdGVtLnVzZXJfaWQ/Ll9pZCkuZmlsdGVyKEJvb2xlYW4pKS5zaXplO1xyXG4vLyAgICAgICBjb25zdCB1bmlxdWVHcm91cHMgPSBuZXcgU2V0KHJhd0RhdGEubWFwKGl0ZW0gPT4gaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSkuZmlsdGVyKEJvb2xlYW4pKS5zaXplO1xyXG5cclxuLy8gICAgICAgc2V0U3VtbWFyeVN0YXRzKHtcclxuLy8gICAgICAgICB0b3RhbEVucm9sbG1lbnRzLFxyXG4vLyAgICAgICAgIHRvdGFsVGlja2V0cyxcclxuLy8gICAgICAgICB1bmlxdWVDdXN0b21lcnMsXHJcbi8vICAgICAgICAgdW5pcXVlR3JvdXBzLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGRhdGEgPSByYXdEYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbi8vICAgICAgICAgX2lkOiBpdGVtLl9pZCxcclxuLy8gICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgIG1vYmlsZV9lbnJvbGxfY29kZTogaXRlbT8ubW9iaWxlX2Vucm9sbF9jb2RlLFxyXG4vLyAgICAgICAgIG5hbWU6IGl0ZW0udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIHBob25lX251bWJlcjogaXRlbS51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgICAgICAgZ3JvdXBfbmFtZTogaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIixcclxuLy8gICAgICAgICBub19vZl90aWNrZXRzOiBpdGVtLm5vX29mX3RpY2tldHMsXHJcbi8vICAgICAgICAgcGF5bWVudF90eXBlOiBpdGVtLnBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgICBjaGl0X2Fza2luZ19tb250aDogaXRlbS5jaGl0X2Fza2luZ19tb250aCxcclxuLy8gICAgICAgICByZWZlcnJlZF90eXBlOiBpdGVtLnJlZmVycmVkX3R5cGUsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfYnk6XHJcbi8vICAgICAgICAgICBpdGVtPy5yZWZlcnJlZF90eXBlPy50b0xvd2VyQ2FzZSgpPy50cmltKCkgPT09IFwiYWdlbnRcIiAmJiBpdGVtPy5hZ2VudFxyXG4vLyAgICAgICAgICAgICA/IGAke2l0ZW0/LmFnZW50Py5uYW1lIHx8IFwiLVwifSB8ICR7aXRlbT8uYWdlbnQ/LnBob25lX251bWJlciB8fCBcIi1cIn1gXHJcbi8vICAgICAgICAgICAgIDogaXRlbT8ucmVmZXJyZWRfdHlwZT8udG9Mb3dlckNhc2UoKT8udHJpbSgpID09PSBcImVtcGxveWVlXCIgJiYgaXRlbT8uYWdlbnRcclxuLy8gICAgICAgICAgICAgPyBgJHtpdGVtPy5hZ2VudD8ubmFtZSB8fCBcIi1cIn0gfCAke2l0ZW0/LmFnZW50Py5waG9uZV9udW1iZXIgfHwgXCItXCJ9YFxyXG4vLyAgICAgICAgICAgICA6IGl0ZW0/LnJlZmVycmVkX3R5cGU/LnRvTG93ZXJDYXNlKCk/LnRyaW0oKSA9PT0gXCJjdXN0b21lclwiICYmIGl0ZW0/LnJlZmVycmVkX2N1c3RvbWVyXHJcbi8vICAgICAgICAgICAgID8gYCR7aXRlbT8ucmVmZXJyZWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBcIi1cIn0gfCAke2l0ZW0/LnJlZmVycmVkX2N1c3RvbWVyPy5waG9uZV9udW1iZXIgfHwgXCItXCJ9YFxyXG4vLyAgICAgICAgICAgICA6IGl0ZW0/LnJlZmVycmVkX3R5cGU/LnRvTG93ZXJDYXNlKCk/LnRyaW0oKSA9PT0gXCJsZWFkXCIgJiYgaXRlbT8ucmVmZXJyZWRfbGVhZFxyXG4vLyAgICAgICAgICAgICA/IGAke2l0ZW0/LnJlZmVycmVkX2xlYWQ/LmxlYWRfbmFtZSB8fCBcIi1cIn0gfCAke2l0ZW0/LnJlZmVycmVkX2xlYWQ/LmFnZW50X251bWJlciB8fCBcIi1cIn1gXHJcbi8vICAgICAgICAgICAgIDogXCJOL0FcIixcclxuLy8gICAgICAgICBlbnJvbGxtZW50X2RhdGU6IGl0ZW0uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0sXHJcbi8vICAgICAgICAgYWN0aW9uOiAoXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgIDxEcm9wZG93blxyXG4vLyAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4vLyAgICAgICAgICAgICAgIG1lbnU9e3tcclxuLy8gICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbi8vICAgICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGl0ZW0uX2lkKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGl0ZW0uX2lkKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRW5yb2xsQ2xpY2soaXRlbSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIEFwcHJvdmVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgICBdLFxyXG4vLyAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkIGN1cnNvci1wb2ludGVyXCIgLz5cclxuLy8gICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICksXHJcbi8vICAgICAgIH0pKTtcclxuLy8gICAgICAgc2V0VGFibGVFbnJvbGxzKGRhdGEpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggZW5yb2xsbWVudCBkYXRhXCIsIGVycik7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuLy8gICB9LCBbZmV0Y2hBbGxFbnJvbGxtZW50RGF0YV0pO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVFbnJvbGxDbGljayA9IChpdGVtKSA9PiB7XHJcbi8vICAgICBzZXRDdXJyZW50R3JvdXAoaXRlbSk7XHJcbi8vICAgICBzZXRGb3JtRGF0YSh7XHJcbi8vICAgICAgIHVzZXJfaWQ6IGl0ZW0udXNlcl9pZD8uX2lkIHx8IFwiXCIsXHJcbi8vICAgICAgIGdyb3VwX2lkOiBpdGVtLmdyb3VwX2lkPy5faWQgfHwgXCJcIixcclxuLy8gICAgICAgcGF5bWVudF90eXBlOiBpdGVtLnBheW1lbnRfdHlwZSB8fCBcIlwiLFxyXG4vLyAgICAgICByZWZlcnJlZF90eXBlOiBpdGVtLnJlZmVycmVkX3R5cGUgfHwgXCJcIixcclxuLy8gICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGl0ZW0uY2hpdF9hc2tpbmdfbW9udGggfHwgXCJcIixcclxuLy8gICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IGl0ZW0ucmVmZXJyZWRfY3VzdG9tZXI/Ll9pZCB8fCBcIlwiLFxyXG4vLyAgICAgICByZWZlcnJlZF9sZWFkOiBpdGVtLnJlZmVycmVkX2xlYWQ/Ll9pZCB8fCBcIlwiLFxyXG4vLyAgICAgICBhZ2VudDogaXRlbS5hZ2VudD8uX2lkIHx8IFwiXCIsXHJcbi8vICAgICAgIG5vX29mX3RpY2tldHM6IGl0ZW0ubm9fb2ZfdGlja2V0cyB8fCAxLFxyXG4vLyAgICAgfSk7XHJcbi8vICAgICBzZXRFbnJvbGxtZW50U3RlcChcInZlcmlmeVwiKTtcclxuLy8gICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4vLyAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuLy8gICAgIGNvbnN0IHtcclxuLy8gICAgICAgbm9fb2ZfdGlja2V0cyxcclxuLy8gICAgICAgZ3JvdXBfaWQsXHJcbi8vICAgICAgIHVzZXJfaWQsXHJcbi8vICAgICAgIHBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgcmVmZXJyZWRfY3VzdG9tZXIsXHJcbi8vICAgICAgIHJlZmVycmVkX3R5cGUsXHJcbi8vICAgICAgIGFnZW50LFxyXG4vLyAgICAgICByZWZlcnJlZF9sZWFkLFxyXG4vLyAgICAgICBjaGl0X2Fza2luZ19tb250aCxcclxuLy8gICAgIH0gPSBmb3JtRGF0YTtcclxuXHJcbi8vICAgICBjb25zdCB0aWNrZXRzQ291bnQgPSBwYXJzZUludChub19vZl90aWNrZXRzIHx8IDEsIDEwKTtcclxuLy8gICAgIGNvbnN0IHRpY2tldEVudHJpZXMgPSBhdmFpbGFibGVUaWNrZXRzQWRkXHJcbi8vICAgICAgIC5zbGljZSgwLCB0aWNrZXRzQ291bnQpXHJcbi8vICAgICAgIC5tYXAoKHRpY2tldE51bWJlcikgPT4gKHtcclxuLy8gICAgICAgICBncm91cF9pZCxcclxuLy8gICAgICAgICB1c2VyX2lkLFxyXG4vLyAgICAgICAgIHBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgICByZWZlcnJlZF90eXBlLFxyXG4vLyAgICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBmb3JtRGF0YS5jaGl0X2Fza2luZ19tb250aCxcclxuLy8gICAgICAgICByZWZlcnJlZF9jdXN0b21lcixcclxuLy8gICAgICAgICByZWZlcnJlZF9sZWFkLFxyXG4vLyAgICAgICAgIGFnZW50LFxyXG4vLyAgICAgICAgIG5vX29mX3RpY2tldHM6IHRpY2tldHNDb3VudCxcclxuLy8gICAgICAgICB0aWNrZXRzOiB0aWNrZXROdW1iZXIsXHJcbi8vICAgICAgIH0pKTtcclxuXHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICBmb3IgKGNvbnN0IHRpY2tldEVudHJ5IG9mIHRpY2tldEVudHJpZXMpIHtcclxuLy8gICAgICAgICBhd2FpdCBhcGkucG9zdChcIi9lbnJvbGwvYWRkLWVucm9sbFwiLCB0aWNrZXRFbnRyeSwge1xyXG4vLyAgICAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBpZiAoY3VycmVudEdyb3VwPy5faWQpIHtcclxuLy8gICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKFxyXG4vLyAgICAgICAgICAgYC9tb2JpbGUtYXBwLWVucm9sbC9kZWxldGUtbW9iaWxlLWFwcC1lbnJvbGwvJHtjdXJyZW50R3JvdXAuX2lkfWAsXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGRhdGE6IHsgZGVsZXRlZF9ieTogYWRtaW4sIGRlbGV0ZWRfYXQ6IG5ldyBEYXRlKCkgfSxcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgKTtcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4vLyAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJVc2VyIEVucm9sbGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4vLyAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbi8vICAgICAgIHNldEZvcm1EYXRhKHtcclxuLy8gICAgICAgICBncm91cF9pZDogXCJcIixcclxuLy8gICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4vLyAgICAgICAgIG5vX29mX3RpY2tldHM6IFwiXCIsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfdHlwZTogXCJcIixcclxuLy8gICAgICAgICBwYXltZW50X3R5cGU6IFwiXCIsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbi8vICAgICAgICAgYWdlbnQ6IFwiXCIsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfbGVhZDogXCJcIixcclxuLy8gICAgICAgICBjaGl0X2Fza2luZ19tb250aDogXCJcIixcclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICAvLyBSZWZyZXNoIGRhdGEgYWZ0ZXIgc3VjY2Vzc2Z1bCBlbnJvbGxtZW50XHJcbi8vICAgICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBlbnJvbGxpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIkVucm9sbG1lbnQgZmFpbGVkXCIsXHJcbi8vICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4vLyAgICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRhdGE6XCIsIGVycm9yKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoVXNlcnMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4vLyAgICAgICAgIHNldEFnZW50cyhyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBMZWFkc1wiLCBlcnIpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hBZ2VudHMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaExlYWRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9sZWFkL2dldC1sZWFkXCIpO1xyXG4vLyAgICAgICAgIHNldExlYWRzKHJlc3BvbnNlLmRhdGEpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIExlYWRzXCIsIGVycik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaExlYWRzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVWZXJpZnkgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBjb25zdCB7XHJcbi8vICAgICAgIHVzZXJfaWQsXHJcbi8vICAgICAgIGdyb3VwX2lkLFxyXG4vLyAgICAgICBhZ2VudCxcclxuLy8gICAgICAgcmVmZXJyZWRfY3VzdG9tZXIsXHJcbi8vICAgICAgIHJlZmVycmVkX2xlYWQsXHJcbi8vICAgICAgIHJlZmVycmVkX3R5cGUsXHJcbi8vICAgICB9ID0gZm9ybURhdGE7XHJcblxyXG4vLyAgICAgaWYgKCF1c2VyX2lkIHx8ICFncm91cF9pZCkge1xyXG4vLyAgICAgICBub3RpZmljYXRpb24ud2FybmluZyh7XHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGJvdGggR3JvdXAgYW5kIEN1c3RvbWVyIGJlZm9yZSB2ZXJpZnlpbmcuXCIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICByZXR1cm47XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2dldC1lbnJvbGwtY2hlY2tgLCB7XHJcbi8vICAgICAgICAgcGFyYW1zOiB7IHVzZXJfaWQsIGdyb3VwX2lkIH0sXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgY29uc3Qgc2VsZWN0ZWRVc2VyID0gdXNlcnMuZmluZCgodSkgPT4gdS5faWQgPT09IHVzZXJfaWQpO1xyXG4vLyAgICAgICBjb25zdCBzZWxlY3RlZEdyb3VwID0gZ3JvdXBzLmZpbmQoKGcpID0+IGcuX2lkID09PSBncm91cF9pZCk7XHJcbi8vICAgICAgIGNvbnN0IHNlbGVjdGVkQWdlbnQgPSBhZ2VudHMuZmluZCgoYSkgPT4gYS5faWQgPT09IGFnZW50KTtcclxuLy8gICAgICAgY29uc3Qgc2VsZWN0ZWRSZWZlcnJlZEN1c3RvbWVyID0gdXNlcnMuZmluZChcclxuLy8gICAgICAgICAodSkgPT4gdS5faWQgPT09IHJlZmVycmVkX2N1c3RvbWVyLFxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgICBjb25zdCBzZWxlY3RlZFJlZmVycmVkTGVhZCA9IGxlYWRzPy5maW5kPy4oXHJcbi8vICAgICAgICAgKGwpID0+IGwuX2lkID09PSByZWZlcnJlZF9sZWFkLFxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhKSB7XHJcbi8vICAgICAgICAgY29uc3QgYWdlbnROYW1lID1cclxuLy8gICAgICAgICAgIHR5cGVvZiByZXNwb25zZS5kYXRhLmFnZW50ID09PSBcIm9iamVjdFwiXHJcbi8vICAgICAgICAgICAgID8gcmVzcG9uc2UuZGF0YS5hZ2VudD8ubmFtZVxyXG4vLyAgICAgICAgICAgICA6IG51bGw7XHJcbi8vICAgICAgICAgY29uc3QgcmVmZXJyZWRDdXN0b21lck5hbWUgPVxyXG4vLyAgICAgICAgICAgdHlwZW9mIHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfY3VzdG9tZXIgPT09IFwib2JqZWN0XCJcclxuLy8gICAgICAgICAgICAgPyByZXNwb25zZS5kYXRhLnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWVcclxuLy8gICAgICAgICAgICAgOiBudWxsO1xyXG4vLyAgICAgICAgIGNvbnN0IHJlZmVycmVkTGVhZE5hbWUgPVxyXG4vLyAgICAgICAgICAgdHlwZW9mIHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfbGVhZCA9PT0gXCJvYmplY3RcIlxyXG4vLyAgICAgICAgICAgICA/IHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lXHJcbi8vICAgICAgICAgICAgIDogbnVsbDtcclxuXHJcbi8vICAgICAgICAgY29uc3QgcmVmZXJyZWRJbmZvUGFydHMgPSBbXTtcclxuXHJcbi8vICAgICAgICAgaWYgKGFnZW50TmFtZSlcclxuLy8gICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXHJcbi8vICAgICAgICAgICAgIGAgQWxyZWFkeSByZWZlcnJlZCBieSBBZ2VudCBOYW1lOiAke2FnZW50TmFtZX1gLFxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICBpZiAocmVmZXJyZWRDdXN0b21lck5hbWUpXHJcbi8vICAgICAgICAgICByZWZlcnJlZEluZm9QYXJ0cy5wdXNoKFxyXG4vLyAgICAgICAgICAgICBgIEFscmVhZHkgcmVmZXJyZWQgYnkgQ3VzdG9tZXIgTmFtZTogJHtyZWZlcnJlZEN1c3RvbWVyTmFtZX1gLFxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICBpZiAocmVmZXJyZWRMZWFkTmFtZSlcclxuLy8gICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXHJcbi8vICAgICAgICAgICAgIGAgQWxyZWFkeSByZWZlcnJlZCBieSBMZWFkIE5hbWU6ICR7cmVmZXJyZWRMZWFkTmFtZX1gLFxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICBpZiAocmVmZXJyZWRJbmZvUGFydHMubGVuZ3RoID09PSAwKVxyXG4vLyAgICAgICAgICAgcmVmZXJyZWRJbmZvUGFydHMucHVzaChcIkVucm9sbG1lbnQgZXhpc3RzIHdpdGggbm8gcmVmZXJyYWwgaW5mby5cIik7XHJcblxyXG4vLyAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4vLyAgICAgICAgICAgLi4ucHJldixcclxuLy8gICAgICAgICAgIG5vX29mX3RpY2tldHM6IHJlc3BvbnNlPy5kYXRhPy5ub19vZl90aWNrZXRzID8/IHByZXYubm9fb2ZfdGlja2V0cyxcclxuLy8gICAgICAgICAgIHBheW1lbnRfdHlwZTogcmVzcG9uc2U/LmRhdGE/LnBheW1lbnRfdHlwZSA/PyBwcmV2LnBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgICAgIHJlZmVycmVkX2N1c3RvbWVyOlxyXG4vLyAgICAgICAgICAgICByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfY3VzdG9tZXIgPz8gcHJldi5yZWZlcnJlZF9jdXN0b21lcixcclxuLy8gICAgICAgICAgIHJlZmVycmVkX2xlYWQ6IHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJlZF9sZWFkID8/IHByZXYucmVmZXJyZWRfbGVhZCxcclxuLy8gICAgICAgICAgIHJlZmVycmVkX3R5cGU6XHJcbi8vICAgICAgICAgICAgIHByZXYucmVmZXJyZWRfdHlwZSB8fFxyXG4vLyAgICAgICAgICAgICByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfdHlwZSB8fFxyXG4vLyAgICAgICAgICAgICAocmVzcG9uc2UuZGF0YT8uYWdlbnRcclxuLy8gICAgICAgICAgICAgICA/IFwiQWdlbnRcIlxyXG4vLyAgICAgICAgICAgICAgIDogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfY3VzdG9tZXJcclxuLy8gICAgICAgICAgICAgICAgID8gXCJDdXN0b21lclwiXHJcbi8vICAgICAgICAgICAgICAgICA6IHJlc3BvbnNlLmRhdGE/LnJlZmVycmVkX2xlYWRcclxuLy8gICAgICAgICAgICAgICAgICAgPyBcIkxlYWRzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgOiBcIlwiKSxcclxuLy8gICAgICAgICB9KSk7XHJcblxyXG4vLyAgICAgICAgIGxldCBzZWxlY3RlZEJ5ID0gXCJVbmtub3duXCI7XHJcbi8vICAgICAgICAgaWYgKHJlZmVycmVkX3R5cGUgPT09IFwiQWdlbnRcIilcclxuLy8gICAgICAgICAgIHNlbGVjdGVkQnkgPSBzZWxlY3RlZEFnZW50Py5uYW1lIHx8IFwiVW5rbm93biBBZ2VudFwiO1xyXG4vLyAgICAgICAgIGVsc2UgaWYgKHJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIilcclxuLy8gICAgICAgICAgIHNlbGVjdGVkQnkgPVxyXG4vLyAgICAgICAgICAgICBzZWxlY3RlZFJlZmVycmVkQ3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBcIlVua25vd24gQ3VzdG9tZXJcIjtcclxuLy8gICAgICAgICBlbHNlIGlmIChyZWZlcnJlZF90eXBlID09PSBcIkxlYWRzXCIpXHJcbi8vICAgICAgICAgICBzZWxlY3RlZEJ5ID0gc2VsZWN0ZWRSZWZlcnJlZExlYWQ/LmxlYWRfbmFtZSB8fCBcIlVua25vd24gTGVhZFwiO1xyXG5cclxuLy8gICAgICAgICBzZXRJc0V4aXN0aW5nRW5yb2xsbWVudCh0cnVlKTtcclxuLy8gICAgICAgICBzZXRFbnJvbGxtZW50U3RlcChcImNvbnRpbnVlXCIpO1xyXG5cclxuLy8gICAgICAgICBub3RpZmljYXRpb24ud2FybmluZyh7XHJcbi8vICAgICAgICAgICBtZXNzYWdlOiAoXHJcbi8vICAgICAgICAgICAgIDxzcGFuXHJcbi8vICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuLy8gICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLFxyXG4vLyAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMS4yNXJlbVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBcIjEwcHhcIixcclxuLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgQ3VzdG9tZXIgTmFtZTogXCJ7c2VsZWN0ZWRVc2VyPy5mdWxsX25hbWV9XCJcclxuLy8gICAgICAgICAgICAgICA8YnIgLz5cclxuLy8gICAgICAgICAgICAgICA8aHIgc3R5bGU9e3sgbWFyZ2luOiBcIjEwcHggMFwiLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNjY2NcIiB9fSAvPlxyXG4vLyAgICAgICAgICAgICAgIEdyb3VwIE5hbWU6IFwie3NlbGVjdGVkR3JvdXA/Lmdyb3VwX25hbWV9XCJcclxuLy8gICAgICAgICAgICAgICA8YnIgLz5cclxuLy8gICAgICAgICAgICAgICA8aHIgc3R5bGU9e3sgbWFyZ2luOiBcIjEwcHggMFwiLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNjY2NcIiB9fSAvPlxyXG4vLyAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgZGVzY3JpcHRpb246IChcclxuLy8gICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMS4yNXJlbVwiIH19PlxyXG4vLyAgICAgICAgICAgICAgIHtyZWZlcnJlZEluZm9QYXJ0cy5tYXAoKHBhcnQsIGluZGV4KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2luZGV4fT5cclxuLy8gICAgICAgICAgICAgICAgICAge3BhcnR9XHJcbi8vICAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aHJcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW46IFwiMTBweCAwXCIsIGJvcmRlclRvcDogXCIxcHggc29saWQgI2NjY1wiIH19XHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgIGR1cmF0aW9uOiAzMCxcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgICBzZXRJc0V4aXN0aW5nRW5yb2xsbWVudCh0cnVlKTtcclxuLy8gICAgICAgICBzZXRJc1ZlcmlmaWVkKHRydWUpO1xyXG4vLyAgICAgICAgIHNldEVucm9sbG1lbnRTdGVwKFwiY29udGludWVcIik7XHJcbi8vICAgICAgIH0gZWxzZSB7XHJcbi8vICAgICAgICAgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnQoZmFsc2UpO1xyXG4vLyAgICAgICAgIHNldElzVmVyaWZpZWQodHJ1ZSk7XHJcbi8vICAgICAgICAgc2V0RW5yb2xsbWVudFN0ZXAoXCJjb250aW51ZVwiKTtcclxuXHJcbi8vICAgICAgICAgbm90aWZpY2F0aW9uLnN1Y2Nlc3Moe1xyXG4vLyAgICAgICAgICAgbWVzc2FnZTogYEVsaWdpYmxlIGZvciBFbnJvbGxtZW50YCxcclxuLy8gICAgICAgICAgIGRlc2NyaXB0aW9uOiBgVXNlciBcIiR7c2VsZWN0ZWRVc2VyPy5mdWxsX25hbWV9XCIgY2FuIGJlIGVucm9sbGVkIGluIFwiJHtzZWxlY3RlZEdyb3VwPy5ncm91cF9uYW1lfVwiLmAsXHJcbi8vICAgICAgICAgICBkdXJhdGlvbjogNixcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJWZXJpZmljYXRpb24gZXJyb3I6XCIsIGVycik7XHJcbi8vICAgICAgIG5vdGlmaWNhdGlvbi5lcnJvcih7XHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJFcnJvciBjaGVja2luZyBlbnJvbGxtZW50XCIsXHJcbi8vICAgICAgICAgZGVzY3JpcHRpb246IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZU11bHRpU3RlcCA9IGFzeW5jIChlKSA9PiB7XHJcbi8vICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4vLyAgICAgaWYgKGVucm9sbG1lbnRTdGVwID09PSBcInZlcmlmeVwiKSB7XHJcbi8vICAgICAgIGF3YWl0IGhhbmRsZVZlcmlmeSgpO1xyXG4vLyAgICAgfSBlbHNlIGlmIChlbnJvbGxtZW50U3RlcCA9PT0gXCJjb250aW51ZVwiKSB7XHJcbi8vICAgICAgIHNldEVucm9sbG1lbnRTdGVwKFwic3VibWl0XCIpO1xyXG4vLyAgICAgfSBlbHNlIGlmIChlbnJvbGxtZW50U3RlcCA9PT0gXCJzdWJtaXRcIikge1xyXG4vLyAgICAgICBoYW5kbGVTdWJtaXQoZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuLy8gICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuLy8gICAgICAgLi4ucHJldkRhdGEsXHJcbi8vICAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4vLyAgICAgfSkpO1xyXG5cclxuLy8gICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuLy8gICAgICAgLi4ucHJldkVycm9ycyxcclxuLy8gICAgICAgW2ZpZWxkXTogXCJcIixcclxuLy8gICAgIH0pKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVBbnRJbnB1dERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbi8vICAgICAgIC4uLnByZXZEYXRhLFxyXG4vLyAgICAgICBbZmllbGRdOiB2YWx1ZSxcclxuLy8gICAgIH0pKTtcclxuXHJcbi8vICAgICBzZXRFcnJvcnMoeyAuLi5lcnJvcnMsIFtmaWVsZF06IFwiXCIgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmIChmb3JtRGF0YS5ncm91cF9pZCkge1xyXG4vLyAgICAgICBjb25zdCBmZXRjaFRpY2tldHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgICAgdHJ5IHtcclxuLy8gICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbi8vICAgICAgICAgICAgIGAvZW5yb2xsL2dldC1uZXh0LXRpY2tldHMvJHtmb3JtRGF0YS5ncm91cF9pZH1gLFxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICAgIHNldEF2YWlsYWJsZVRpY2tldHNBZGQocmVzcG9uc2UuZGF0YS5hdmFpbGFibGVUaWNrZXRzIHx8IFtdKTtcclxuLy8gICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIG5leHQgdGlja2V0czpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICAgICAgc2V0QXZhaWxhYmxlVGlja2V0c0FkZChbXSk7XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICB9O1xyXG4vLyAgICAgICBmZXRjaFRpY2tldHMoKTtcclxuLy8gICAgIH0gZWxzZSB7XHJcbi8vICAgICAgIHNldEF2YWlsYWJsZVRpY2tldHNBZGQoW10pO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtmb3JtRGF0YS5ncm91cF9pZF0pO1xyXG5cclxuLy8gICBjb25zdCBjb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICBdO1xyXG4vLyAgIGlmIChhbGxFbnJvbGxVcmwpIHtcclxuLy8gICAgIGNvbHVtbnMucHVzaCh7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJFbnJvbGxlZCBHcm91cFwiIH0pO1xyXG4vLyAgIH1cclxuLy8gICBjb2x1bW5zLnB1c2goXHJcbi8vICAgICB7IGtleTogXCJtb2JpbGVfZW5yb2xsX2NvZGVcIiwgaGVhZGVyOiBcIk1vYmlsZSBFbnJvbGwgQ29kZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWZlcnJlZF90eXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVucm9sbG1lbnRfZGF0ZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBEYXRlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNoaXRfYXNraW5nX21vbnRoXCIsIGhlYWRlcjogXCJDaGl0IEFza2luZyBNb250aFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJyZWZlcnJlZF9ieVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4vLyAgICk7XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbi8vICAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuLy8gICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuLy8gICAgICAgLi4ucHJldkRhdGEsXHJcbi8vICAgICAgIFtuYW1lXTogdmFsdWUsXHJcbi8vICAgICB9KSk7XHJcbi8vICAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7IC4uLnByZXZFcnJvcnMsIFtuYW1lXTogXCJcIiB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgdmFsaWRhdGUgPSAodHlwZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbi8vICAgICBjb25zdCBkYXRhID0gdHlwZSA9PT0gXCJhZGRFbnJvbGxtZW50XCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG4vLyAgICAgY29uc3Qgbm9PZlRpY2tldHMgPSB0eXBlID09PSBcImFkZEVucm9sbG1lbnRcIiA/IFwibm9fb2ZfdGlja2V0c1wiIDogXCJ0aWNrZXRzXCI7XHJcbi8vICAgICBpZiAoIWRhdGEuZ3JvdXBfaWQudHJpbSgpKSB7XHJcbi8vICAgICAgIG5ld0Vycm9ycy5ncm91cF9pZCA9IFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwXCI7XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAoIWRhdGEudXNlcl9pZCkge1xyXG4vLyAgICAgICBuZXdFcnJvcnMudXNlcl9pZCA9IFwiUGxlYXNlIHNlbGVjdCBhIGN1c3RvbWVyXCI7XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgaWYgKGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoID4gMCkge1xyXG4vLyAgICAgICBpZiAoXHJcbi8vICAgICAgICAgIWRhdGFbbm9PZlRpY2tldHNdIHx8XHJcbi8vICAgICAgICAgZGF0YVtub09mVGlja2V0c10gPD0gMCB8fFxyXG4vLyAgICAgICAgIGlzTmFOKGRhdGFbbm9PZlRpY2tldHNdKVxyXG4vLyAgICAgICApIHtcclxuLy8gICAgICAgICBuZXdFcnJvcnNbbm9PZlRpY2tldHNdID0gXCJQbGVhc2UgZW50ZXIgbnVtYmVyIG9mIHRpY2tldHNcIjtcclxuLy8gICAgICAgfSBlbHNlIGlmIChkYXRhW25vT2ZUaWNrZXRzXSA+IGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoKSB7XHJcbi8vICAgICAgICAgbmV3RXJyb3JzW25vT2ZUaWNrZXRzXSA9XHJcbi8vICAgICAgICAgICBgTWF4aW11bSAke2F2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RofSB0aWNrZXRzIGFsbG93ZWRgO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbi8vICAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbi8vICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldlN0YXRlKSA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2U3RhdGUsXHJcbi8vICAgICAgIFtuYW1lXTogdmFsdWUsXHJcbi8vICAgICB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGVucm9sbElkKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbi8vICAgICAgICAgYC9tb2JpbGUtYXBwLWVucm9sbC9nZXQtbW9iaWxlLWFwcC1lbnJvbGwtYnktaWQvJHtlbnJvbGxJZH1gLFxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbi8vICAgICAgIGNvbnNvbGUuaW5mbyhyZXNwb25zZS5kYXRhPy5hZ2VudD8uX2lkLCBcInRlc3QgY3VzdG9tZXJcIik7XHJcbi8vICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuLy8gICAgICAgICBncm91cF9pZDogcmVzcG9uc2UuZGF0YT8uZ3JvdXBfaWQ/Ll9pZCxcclxuLy8gICAgICAgICB1c2VyX2lkOiByZXNwb25zZS5kYXRhPy51c2VyX2lkPy5faWQsXHJcbi8vICAgICAgICAgdGlja2V0czogcmVzcG9uc2UuZGF0YT8udGlja2V0cyxcclxuLy8gICAgICAgICBwYXltZW50X3R5cGU6IHJlc3BvbnNlLmRhdGE/LnBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgICByZWZlcnJlZF9jdXN0b21lcjogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfY3VzdG9tZXI/Ll9pZCxcclxuLy8gICAgICAgICBhZ2VudDogcmVzcG9uc2UuZGF0YT8uYWdlbnQ/Ll9pZCxcclxuLy8gICAgICAgICByZWZlcnJlZF9sZWFkOiByZXNwb25zZS5kYXRhPy5yZWZlcnJlZF9sZWFkPy5faWQsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfdHlwZTogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfdHlwZSxcclxuLy8gICAgICAgICBjaGl0X2Fza2luZ19tb250aDogcmVzcG9uc2UuZGF0YT8uY2hpdF9hc2tpbmdfbW9udGggfHwgXCJcIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50OlwiLCBlcnJvcik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuLy8gICAgICAgICBgL21vYmlsZS1hcHAtZW5yb2xsL2dldC1tb2JpbGUtYXBwLWVucm9sbC1ieS1pZC8ke2dyb3VwSWR9YCxcclxuLy8gICAgICAgKTtcclxuLy8gICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4vLyAgICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsOlwiLCBlcnJvcik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlRGVsZXRlR3JvdXAgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShcclxuLy8gICAgICAgICAgIGAvbW9iaWxlLWFwcC1lbnJvbGwvZGVsZXRlLW1vYmlsZS1hcHAtZW5yb2xsLyR7Y3VycmVudEdyb3VwLl9pZH1gLFxyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBkZWxldGVkX2J5OiBhZG1pbixcclxuLy8gICAgICAgICAgICAgZGVsZXRlZF9hdDogbmV3IERhdGUoKSxcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgKTtcclxuLy8gICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4vLyAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuLy8gICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4vLyAgICAgICAgICAgbWVzc2FnZTogXCJFbnJvbGwgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuLy8gICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICAgIC8vIFJlZnJlc2ggZGF0YSBhZnRlciBkZWxldGlvblxyXG4vLyAgICAgICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbi8vICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBhd2FpdCBhcGkucHV0KFxyXG4vLyAgICAgICAgIGAvbW9iaWxlLWFwcC1lbnJvbGwvdXBkYXRlLW1vYmlsZS1hcHAtZW5yb2xsLyR7Y3VycmVudFVwZGF0ZUdyb3VwLl9pZH1gLFxyXG4vLyAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLFxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG5cclxuLy8gICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4vLyAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJFbnJvbGxtZW50IFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbi8vICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBmZXRjaEFsbEVucm9sbG1lbnREYXRhKCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZW5yb2xsOlwiLCBlcnJvcik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDw+XHJcbi8vICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4vLyAgICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbi8vICAgICAgICAgICA8Q3VzdG9tQWxlcnRcclxuLy8gICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuLy8gICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4vLyAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgICAgICA8QnJlYWRjcnVtYi8+XHJcbi8vICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICBNb2JpbGUgQXBwIEVucm9sbG1lbnRzXHJcbi8vICAgICAgICAgICAgIDwvaDE+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogU3VtbWFyeSBDYXJkcyBTZWN0aW9uICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItOFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC00IGJvcmRlci1sLTQgYm9yZGVyLWJsdWUtNTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlRvdGFsIEVucm9sbG1lbnRzPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3N1bW1hcnlTdGF0cy50b3RhbEVucm9sbG1lbnRzfTwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC00IGJvcmRlci1sLTQgYm9yZGVyLWdyZWVuLTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5Ub3RhbCBUaWNrZXRzPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3N1bW1hcnlTdGF0cy50b3RhbFRpY2tldHN9PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBwLTQgYm9yZGVyLWwtNCBib3JkZXItcHVycGxlLTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5VbmlxdWUgQ3VzdG9tZXJzPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3N1bW1hcnlTdGF0cy51bmlxdWVDdXN0b21lcnN9PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBwLTQgYm9yZGVyLWwtNCBib3JkZXItb3JhbmdlLTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5VbmlxdWUgR3JvdXBzPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3N1bW1hcnlTdGF0cy51bmlxdWVHcm91cHN9PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yMFwiPlxyXG4vLyAgICAgICAgICAgICAgIHtUYWJsZUVucm9sbHM/Lmxlbmd0aCA+IDAgPyAoXHJcbi8vICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuLy8gICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlRW5yb2xscywgc2VhcmNoVGV4dCl9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbi8vICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIk1vYmlsZSBBcHAgRW5yb2xsbWVudHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgTW9iaWxlIEFwcCBFbnJvbGxtZW50cy5jc3ZgfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbi8vICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNEYXRhVGFibGVMb2FkaW5nfVxyXG4vLyAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZUVucm9sbHM/Lmxlbmd0aCA8PSAwfVxyXG4vLyAgICAgICAgICAgICAgICAgICBkYXRhPXtcIk1vYmlsZSBFbnJvbGxtZW50IERhdGFcIn1cclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8TW9kYWxcclxuLy8gICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsfVxyXG4vLyAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4vLyAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4vLyAgICAgICAgICAgfX1cclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4vLyAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgQWRkIEVucm9sbG1lbnRcclxuLy8gICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgR3JvdXAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggR3JvdXBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfaWQgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZ3JvdXBfaWRcIiwgdmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2lkICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZ3JvdXBfaWR9PC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuLy8gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuLy8gICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICBuYW1lPVwidXNlcl9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8udXNlcl9pZCB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJ1c2VyX2lkXCIsIHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9IHx7XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5waG9uZV9udW1iZXIgPyB1c2VyLnBob25lX251bWJlciA6IFwiTm8gTnVtYmVyXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheW1lbnRfdHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIFNlbGVjdCBQYXltZW50IFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQYXltZW50IFR5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXltZW50X3R5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5wYXltZW50X3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicGF5bWVudF90eXBlXCIsIHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge1tcIkRhaWx5XCIsIFwiV2Vla2x5XCIsIFwiTW9udGhseVwiXS5tYXAoKHBUeXBlKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtwVHlwZX0gdmFsdWU9e3BUeXBlfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtwVHlwZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBDaGl0IEFza2luZyBNb250aFxyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYm9yZGVyIHJvdW5kZWQgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZS50YXJnZXQudmFsdWUsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4vLyAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICBtYXg9e2Zvcm1hdFRvWWVhck1vbnRoKGN1cnJlbnRZZWFyLCBjdXJyZW50TW9udGgpfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJyZWZlcnJlZF90eXBlXCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWZlcnJlZCBUeXBlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuLy8gICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfdHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlZmVycmVkX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfdHlwZVwiLCB2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtbXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJTZWxmIEpvaW5pbmdcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFwiTGVhZHNcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBcIk90aGVyc1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBdLm1hcCgocmVmVHlwZSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmVHlwZX0gdmFsdWU9e3JlZlR5cGV9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge3JlZlR5cGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEN1c3RvbWVye1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEN1c3RvbWVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfY3VzdG9tZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucmVmZXJyZWRfY3VzdG9tZXIgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfY3VzdG9tZXJcIiwgdmFsdWUpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfSB8e1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5waG9uZV9udW1iZXIgPyB1c2VyLnBob25lX251bWJlciA6IFwiTm8gTnVtYmVyXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJMZWFkc1wiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIExlYWRze1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIExlYWRzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfbGVhZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9sZWFkIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcInJlZmVycmVkX2xlYWRcIiwgdmFsdWUpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2xlYWRzLm1hcCgobGVhZCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtsZWFkLl9pZH0gdmFsdWU9e2xlYWQuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2xlYWQubGVhZF9uYW1lfSB8IHtsZWFkLmxlYWRfcGhvbmV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJFbXBsb3llZVwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEVtcGxveWVle1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEVtcGxveWVlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWdlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGlmICghb3B0aW9uIHx8ICFvcHRpb24uY2hpbGRyZW4pIHJldHVybiBmYWxzZTtcclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJhZ2VudFwiLCB2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ncm91cF9pZCA/IChcclxuLy8gICAgICAgICAgICAgICAgIGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoID4gMCA/IChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyIG9mIFRpY2tldHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vX29mX3RpY2tldHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5ub19vZl90aWNrZXRzfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgTnVtYmVyIG9mIFRpY2tldHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG1heD17YXZhaWxhYmxlVGlja2V0c0FkZC5sZW5ndGh9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubm9fb2ZfdGlja2V0cyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubm9fb2ZfdGlja2V0c31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc20gdGV4dC1ibHVlLTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgT25seSB7YXZhaWxhYmxlVGlja2V0c0FkZC5sZW5ndGh9IHRpY2tldHMgbGVmdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtcmVkLTYwMFwiPkdyb3VwIGlzIEZ1bGw8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXJlZC02MDBcIj48L3A+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBwLTQgbWF4LXctZnVsbCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzcGFjZS15LTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwU3F1YXJlIGNvbG9yPVwiZ3JlZW5cIiBjbGFzc05hbWU9XCJ3LTEwIGgtMTBcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt3aGF0c2FwcEVuYWJsZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBjaGVja2VkOnJpbmctMiAgY2hlY2tlZDpyaW5nLWdyZWVuLTcwMCAgcm91bmRlZC1mdWxsIHctNCBoLTRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwXCI+U2VuZCBWaWEgV2hhdHNhcHA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4vLyAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbi8vICAgICAgICAgICAgICAgICAgICAgbG9hZGluZyB8fFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIChlbnJvbGxtZW50U3RlcCA9PT0gXCJzdWJtaXRcIiAmJlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKCFpc1ZlcmlmaWVkIHx8IGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoID09PSAwKSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVNdWx0aVN0ZXB9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctMS80IHRleHQtd2hpdGUgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgbG9hZGluZ1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA6IGVucm9sbG1lbnRTdGVwID09PSBcInZlcmlmeVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTcwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDogZW5yb2xsbWVudFN0ZXAgPT09IFwiY29udGludWVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge2xvYWRpbmdcclxuLy8gICAgICAgICAgICAgICAgICAgICA/IFwiUHJvY2Vzc2luZy4uLlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgOiBlbnJvbGxtZW50U3RlcCA9PT0gXCJ2ZXJpZnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPyBcIlZlcmlmeVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA6IGVucm9sbG1lbnRTdGVwID09PSBcImNvbnRpbnVlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkNvbnRpbnVlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlN1Ym1pdFwifVxyXG4vLyAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZm9ybT5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvTW9kYWw+XHJcbi8vICAgICAgICAgPE1vZGFsXHJcbi8vICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuLy8gICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuLy8gICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuLy8gICAgICAgICAgIH19XHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuLy8gICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFVwZGF0ZSBFbnJvbGxtZW50XHJcbi8vICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBHcm91cCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBfaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfaWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuLy8gICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuLy8gICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHcm91cDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVzZXJfaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ1c2VyX2lkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaWQ9XCJ1c2VyX2lkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnVzZXJfaWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuLy8gICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuLy8gICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBDdXN0b21lcjwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAge2Vycm9ycy51c2VyX2lkICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMudXNlcl9pZH08L3A+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGF5bWVudF90eXBlXCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgU2VsZWN0IFBheW1lbnQgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFBheW1lbnQgVHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgbmFtZT1cInBheW1lbnRfdHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnBheW1lbnRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwicGF5bWVudF90eXBlXCIsIHZhbHVlKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtbXCJEYWlseVwiLCBcIldlZWtseVwiLCBcIk1vbnRobHlcIl0ubWFwKChwVHlwZSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cFR5cGUudG9Mb3dlckNhc2UoKX0gdmFsdWU9e3BUeXBlfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtwVHlwZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBDaGl0IEFza2luZyBNb250aFxyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYm9yZGVyIHJvdW5kZWQgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNoaXRfYXNraW5nX21vbnRofVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXYpID0+ICh7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGUudGFyZ2V0LnZhbHVlLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInJlZmVycmVkX3R5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF90eXBlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwicmVmZXJyZWRfdHlwZVwiLCB2YWx1ZSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7W1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIFwiU2VsZiBKb2luaW5nXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFwiRW1wbG95ZWVcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBcIkxlYWRzXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJPdGhlcnNcIixcclxuLy8gICAgICAgICAgICAgICAgICAgXS5tYXAoKHJlZlR5cGUpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZlR5cGV9IHZhbHVlPXtyZWZUeXBlfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcntcIiBcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBDdXN0b21lclwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2N1c3RvbWVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnJlZmVycmVkX2N1c3RvbWVyIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwicmVmZXJyZWRfY3VzdG9tZXJcIiwgdmFsdWUpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiTGVhZHNcIiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBMZWFkc3tcIiBcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBMZWFkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfbGVhZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5yZWZlcnJlZF9sZWFkIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwicmVmZXJyZWRfbGVhZFwiLCB2YWx1ZSlcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7bGVhZHMubWFwKChsZWFkKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2xlYWQuX2lkfSB2YWx1ZT17bGVhZC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7bGVhZC5sZWFkX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJFbXBsb3llZVwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEVtcGxveWVle1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEVtcGxveWVlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWdlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcImFnZW50XCIsIHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4vLyAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICA8L2Zvcm0+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L01vZGFsPlxyXG4vLyAgICAgICAgIDxNb2RhbFxyXG4vLyAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbi8vICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbi8vICAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuLy8gICAgICAgICAgIH19XHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuLy8gICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFN1cmUgd2FudCB0byByZW1vdmUgdGhpcyBFbnJvbGxtZW50ID9cclxuLy8gICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPGZvcm1cclxuLy8gICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbi8vICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZUdyb3VwKCk7XHJcbi8vICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDBcclxuLy8gICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBSZW1vdmVcclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDwvZm9ybT5cclxuLy8gICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvTW9kYWw+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC8+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vIGV4cG9ydCBkZWZhdWx0IE1vYmlsZUFwcEVucm9sbDtcclxuXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG4vLyBpbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biwgQnV0dG9uLCBEYXRlUGlja2VyLCBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQge1xyXG4gIE1kR3JpZFZpZXcsXHJcbiAgTWRWaWV3TGlzdCxcclxuICBNZE91dGxpbmVUYWJsZVJvd3MsXHJcbiAgTWRBc3NpZ25tZW50SW5kLFxyXG59IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBoYW5kbGVFbnJvbGxtZW50UmVxdWVzdFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9lbnJvbGxtZW50UmVxdWVzdFByaW50XCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgeyBTZWFyY2hPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5cclxuaW1wb3J0IHtcclxuICBTZWxlY3QsXHJcbiAgRHJvcGRvd24sXHJcbiAgbm90aWZpY2F0aW9uLFxyXG4gIElucHV0LFxyXG4gIEJ1dHRvbixcclxuICBEYXRlUGlja2VyLFxyXG4gIE1vZGFsIGFzIEFudE1vZGFsLFxyXG4gIFRhYmxlLFxyXG4gIENhcmQsXHJcbiAgUm93LFxyXG4gIENvbCxcclxuICBDaGVja2JveCxcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuLy8gU1RBVFVTX1NVTU1BUllfQ09ORklHIGZvciBNb2JpbGUgRW5yb2xsbWVudHNcclxuLy8gY29uc3QgTU9CSUxFX0VOUk9MTF9TVEFUVVNfQ09ORklHID0gW1xyXG4vLyAgIHtcclxuLy8gICAgIGtleTogXCJDb250YWN0ZWRcIixcclxuLy8gICAgIGxhYmVsOiBcIkNvbnRhY3RlZFwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1pbmRpZ28tNTAwIHRvLWluZGlnby02MDBcIixcclxuLy8gICAgIGJnTGlnaHQ6IFwiYmctaW5kaWdvLTUwXCIsXHJcbi8vICAgICB0ZXh0Q29sb3I6IFwidGV4dC1pbmRpZ28tNzAwXCIsXHJcbi8vICAgICBpY29uQ29sb3I6IFwidGV4dC1pbmRpZ28tNTAwXCIsXHJcbi8vICAgICByaW5nQ29sb3I6IFwicmluZy1pbmRpZ28tMTAwXCIsXHJcbi8vICAgICBpY29uOiAoXHJcbi8vICAgICAgIDxzdmdcclxuLy8gICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01XCJcclxuLy8gICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgPlxyXG4vLyAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgZD1cIk0zIDVhMiAyIDAgMDEyLTJoMy4yOGExIDEgMCAwMS45NDguNjg0bDEuNDk4IDQuNDkzYTEgMSAwIDAxLS41MDIgMS4yMWwtMi4yNTcgMS4xM2ExMS4wNDIgMTEuMDQyIDAgMDA1LjUxNiA1LjUxNmwxLjEzLTIuMjU3YTEgMSAwIDAxMS4yMS0uNTAybDQuNDkzIDEuNDk4YTEgMSAwIDAxLjY4NC45NDlWMTlhMiAyIDAgMDEtMiAyaC0xQzkuNzE2IDIxIDMgMTQuMjg0IDMgNlY1elwiXHJcbi8vICAgICAgICAgLz5cclxuLy8gICAgICAgPC9zdmc+XHJcbi8vICAgICApLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcIkludGVyZXN0ZWRcIixcclxuLy8gICAgIGxhYmVsOiBcIkludGVyZXN0ZWRcIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuLy8gICAgIGJnTGlnaHQ6IFwiYmctYmx1ZS01MFwiLFxyXG4vLyAgICAgdGV4dENvbG9yOiBcInRleHQtYmx1ZS03MDBcIixcclxuLy8gICAgIGljb25Db2xvcjogXCJ0ZXh0LWJsdWUtNTAwXCIsXHJcbi8vICAgICByaW5nQ29sb3I6IFwicmluZy1ibHVlLTEwMFwiLFxyXG4vLyAgICAgaWNvbjogKFxyXG4vLyAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNVwiXHJcbi8vICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgID5cclxuLy8gICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgIGQ9XCJNMTEuMDQ5IDIuOTI3Yy4zLS45MjEgMS42MDMtLjkyMSAxLjkwMiAwbDEuNTE5IDQuNjc0YTEgMSAwIDAwLjk1LjY5aDQuOTE1Yy45NjkgMCAxLjM3MSAxLjI0LjU4OCAxLjgxbC0zLjk3NiAyLjg4OGExIDEgMCAwMC0uMzYzIDEuMTE4bDEuNTE4IDQuNjc0Yy4zLjkyMi0uNzU1IDEuNjg4LTEuNTM4IDEuMTE4bC0zLjk3Ni0yLjg4OGExIDEgMCAwMC0xLjE3NiAwbC0zLjk3NiAyLjg4OGMtLjc4My41Ny0xLjgzOC0uMTk3LTEuNTM4LTEuMTE4bDEuNTE4LTQuNjc0YTEgMSAwIDAwLS4zNjMtMS4xMThsLTMuOTc2LTIuODg4Yy0uNzg0LS41Ny0uMzgtMS44MS41ODgtMS44MWg0LjkxNGExIDEgMCAwMC45NTEtLjY5bDEuNTE5LTQuNjc0elwiXHJcbi8vICAgICAgICAgLz5cclxuLy8gICAgICAgPC9zdmc+XHJcbi8vICAgICApLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcIkZvbGxvdyBVcFwiLFxyXG4vLyAgICAgbGFiZWw6IFwiRm9sbG93IFVwXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLXB1cnBsZS01MDAgdG8tcHVycGxlLTYwMFwiLFxyXG4vLyAgICAgYmdMaWdodDogXCJiZy1wdXJwbGUtNTBcIixcclxuLy8gICAgIHRleHRDb2xvcjogXCJ0ZXh0LXB1cnBsZS03MDBcIixcclxuLy8gICAgIGljb25Db2xvcjogXCJ0ZXh0LXB1cnBsZS01MDBcIixcclxuLy8gICAgIHJpbmdDb2xvcjogXCJyaW5nLXB1cnBsZS0xMDBcIixcclxuLy8gICAgIGljb246IChcclxuLy8gICAgICAgPHN2Z1xyXG4vLyAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTVcIlxyXG4vLyAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICA+XHJcbi8vICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbi8vICAgICAgICAgICBkPVwiTTEyIDh2NGwzIDNtNi0zYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiXHJcbi8vICAgICAgICAgLz5cclxuLy8gICAgICAgPC9zdmc+XHJcbi8vICAgICApLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcIkNvbnZlcnRlZFwiLFxyXG4vLyAgICAgbGFiZWw6IFwiQ29udmVydGVkXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWVtZXJhbGQtNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4vLyAgICAgYmdMaWdodDogXCJiZy1lbWVyYWxkLTUwXCIsXHJcbi8vICAgICB0ZXh0Q29sb3I6IFwidGV4dC1lbWVyYWxkLTcwMFwiLFxyXG4vLyAgICAgaWNvbkNvbG9yOiBcInRleHQtZW1lcmFsZC01MDBcIixcclxuLy8gICAgIHJpbmdDb2xvcjogXCJyaW5nLWVtZXJhbGQtMTAwXCIsXHJcbi8vICAgICBpY29uOiAoXHJcbi8vICAgICAgIDxzdmdcclxuLy8gICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01XCJcclxuLy8gICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgPlxyXG4vLyAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgZD1cIk05IDEybDIgMiA0LTRtNiAyYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiXHJcbi8vICAgICAgICAgLz5cclxuLy8gICAgICAgPC9zdmc+XHJcbi8vICAgICApLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcIlJlamVjdGVkXCIsXHJcbi8vICAgICBsYWJlbDogXCJSZWplY3RlZFwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1yZWQtNTAwIHRvLXJlZC02MDBcIixcclxuLy8gICAgIGJnTGlnaHQ6IFwiYmctcmVkLTUwXCIsXHJcbi8vICAgICB0ZXh0Q29sb3I6IFwidGV4dC1yZWQtNzAwXCIsXHJcbi8vICAgICBpY29uQ29sb3I6IFwidGV4dC1yZWQtNTAwXCIsXHJcbi8vICAgICByaW5nQ29sb3I6IFwicmluZy1yZWQtMTAwXCIsXHJcbi8vICAgICBpY29uOiAoXHJcbi8vICAgICAgIDxzdmdcclxuLy8gICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01XCJcclxuLy8gICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgPlxyXG4vLyAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgZD1cIk0xMCAxNGwyLTJtMCAwbDItMm0tMiAybC0yLTJtMiAybDIgMm03LTJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCJcclxuLy8gICAgICAgICAvPlxyXG4vLyAgICAgICA8L3N2Zz5cclxuLy8gICAgICksXHJcbi8vICAgfSxcclxuLy8gXTtcclxuXHJcbi8vIGNvbnN0IFNUQVRVU19PUFRJT05TID0gW1xyXG4vLyAgIFwiTm90IENvbnRhY3RlZFwiLFxyXG4vLyAgIFwiQ29udGFjdGVkXCIsXHJcbi8vICAgXCJJbnRlcmVzdGVkXCIsXHJcbi8vICAgXCJGb2xsb3cgVXBcIixcclxuLy8gICBcIkNvbnZlcnRlZFwiLFxyXG4vLyAgIFwiUmVqZWN0ZWRcIixcclxuLy8gXTtcclxuXHJcbi8vIGNvbnN0IE1vYmlsZUFwcEVucm9sbCA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtUYWJsZUVucm9sbHMsIHNldFRhYmxlRW5yb2xsc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2ZpbHRlcmVkRW5yb2xscywgc2V0RmlsdGVyZWRFbnJvbGxzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtzaG93TW9kYWxVcGRhdGUsIHNldFNob3dNb2RhbFVwZGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2N1cnJlbnRVcGRhdGVHcm91cCwgc2V0Q3VycmVudFVwZGF0ZUdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFthdmFpbGFibGVUaWNrZXRzLCBzZXRBdmFpbGFibGVUaWNrZXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtjdXJyZW50R3JvdXAsIHNldEN1cnJlbnRHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbYXZhaWxhYmxlVGlja2V0c0FkZCwgc2V0QXZhaWxhYmxlVGlja2V0c0FkZF0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtpc0RhdGFUYWJsZUxvYWRpbmcsIHNldElzRGF0YVRhYmxlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuLy8gICBjb25zdCBbYWxsRW5yb2xsVXJsLCBzZXRBbGxFbnJvbGxVcmxdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbi8vICAgY29uc3QgW2xlYWRzLCBzZXRMZWFkc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbd2hhdHNhcHBFbmFibGUsIHNldFdoYXRzYXBwRW5hYmxlXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4vLyAgIGNvbnN0IFtlbnJvbGxtZW50U3RlcCwgc2V0RW5yb2xsbWVudFN0ZXBdID0gdXNlU3RhdGUoXCJ2ZXJpZnlcIik7XHJcbi8vICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuLy8gICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbi8vICAgICB0eXBlOiBcImluZm9cIixcclxuLy8gICB9KTtcclxuLy8gICBjb25zdCBbaXNFeGlzdGluZ0Vucm9sbG1lbnQsIHNldElzRXhpc3RpbmdFbnJvbGxtZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbYWRtaW4sIHNldEFkbWluXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICAvLyBOZXcgc3RhdGVzIGZvciBzdGF0dXMgdHJhY2tpbmcgVUlcclxuLy8gICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUoXCJwZW5kaW5nXCIpO1xyXG4vLyAgIGNvbnN0IFt2aWV3TW9kZSwgc2V0Vmlld01vZGVdID0gdXNlU3RhdGUoXCJncmlkXCIpO1xyXG4vLyAgIGNvbnN0IFtjdXJyZW50UGFnZSwgc2V0Q3VycmVudFBhZ2VdID0gdXNlU3RhdGUoMSk7XHJcbi8vICAgY29uc3QgW2l0ZW1zUGVyUGFnZV0gPSB1c2VTdGF0ZSg5KTtcclxuLy8gICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICAvLyBTdGF0dXMgdXBkYXRlIG1vZGFsIHN0YXRlcyAtIFVzaW5nIEFudCBEZXNpZ24gTW9kYWxcclxuLy8gICBjb25zdCBbc2hvd1N0YXR1c1VwZGF0ZU1vZGFsLCBzZXRTaG93U3RhdHVzVXBkYXRlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtzdGF0dXNVcGRhdGVEYXRhLCBzZXRTdGF0dXNVcGRhdGVEYXRhXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIF9pZDogXCJcIixcclxuLy8gICAgIHN0YXR1czogXCJcIixcclxuLy8gICAgIHJlbWFyazogXCJcIixcclxuLy8gICAgIGZvbGxvd191cF9kYXRlOiBcIlwiLFxyXG4vLyAgIH0pO1xyXG4vLyAgIGNvbnN0IFtpc1N0YXR1c1VwZGF0aW5nLCBzZXRJc1N0YXR1c1VwZGF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgLy8gU3RhdGUgZm9yIHN1bW1hcnkgbWV0cmljc1xyXG4vLyAgIGNvbnN0IFtzdW1tYXJ5U3RhdHMsIHNldFN1bW1hcnlTdGF0c10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB0b3RhbEVucm9sbG1lbnRzOiAwLFxyXG4vLyAgICAgdG90YWxUaWNrZXRzOiAwLFxyXG4vLyAgICAgdW5pcXVlQ3VzdG9tZXJzOiAwLFxyXG4vLyAgICAgdW5pcXVlR3JvdXBzOiAwLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbi8vICAgY29uc3QgY3VycmVudFllYXIgPSB0b2RheS5nZXRGdWxsWWVhcigpO1xyXG4vLyAgIGNvbnN0IGN1cnJlbnRNb250aCA9IFN0cmluZyh0b2RheS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4vLyAgIGNvbnN0IGN1cnJlbnRZZWFyTW9udGggPSBgJHtjdXJyZW50WWVhcn0tJHtjdXJyZW50TW9udGh9YDtcclxuXHJcbi8vICAgZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlKSB7XHJcbi8vICAgICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG4vLyAgICAgY29uc3QgbW9udGggPSBgMCR7ZGF0ZS5nZXRNb250aCgpICsgMX1gLnNsaWNlKC0yKTtcclxuLy8gICAgIGNvbnN0IGRheSA9IGAwJHtkYXRlLmdldERhdGUoKX1gLnNsaWNlKC0yKTtcclxuLy8gICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gO1xyXG4vLyAgIH1cclxuXHJcbi8vICAgY29uc3QgcGFyc2VEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuLy8gICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSBkYXRlU3RyaW5nLnNwbGl0KFwiLVwiKTtcclxuLy8gICAgIHJldHVybiB7XHJcbi8vICAgICAgIHllYXIsXHJcbi8vICAgICAgIG1vbnRoOiBTdHJpbmcocGFyc2VJbnQobW9udGgpKS5wYWRTdGFydCgyLCBcIjBcIiksXHJcbi8vICAgICAgIG1vbnRoTmFtZTogbW9udGhOYW1lc1twYXJzZUludChtb250aCkgLSAxXSxcclxuLy8gICAgIH07XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZm9ybWF0VG9ZZWFyTW9udGggPSAoeWVhciwgbW9udGgpID0+IHtcclxuLy8gICAgIHJldHVybiBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZ2V0TW9udGhEYXRlUmFuZ2UgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4vLyAgICAgY29uc3QgeyB5ZWFyLCBtb250aCB9ID0gcGFyc2VEYXRlKGRhdGVTdHJpbmcpO1xyXG4vLyAgICAgY29uc3Qgc3RhcnREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpIC0gMSwgMSk7XHJcbi8vICAgICBjb25zdCBlbmREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpLCAwKTtcclxuXHJcbi8vICAgICByZXR1cm4ge1xyXG4vLyAgICAgICBmcm9tX2RhdGU6IGZvcm1hdERhdGUoc3RhcnREYXRlKSxcclxuLy8gICAgICAgdG9fZGF0ZTogZm9ybWF0RGF0ZShlbmREYXRlKSxcclxuLy8gICAgIH07XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICBjb25zdCBtb250aE5hbWVzID0gW1xyXG4vLyAgICAgXCJKYW51YXJ5XCIsXHJcbi8vICAgICBcIkZlYnJ1YXJ5XCIsXHJcbi8vICAgICBcIk1hcmNoXCIsXHJcbi8vICAgICBcIkFwcmlsXCIsXHJcbi8vICAgICBcIk1heVwiLFxyXG4vLyAgICAgXCJKdW5lXCIsXHJcbi8vICAgICBcIkp1bHlcIixcclxuLy8gICAgIFwiQXVndXN0XCIsXHJcbi8vICAgICBcIlNlcHRlbWJlclwiLFxyXG4vLyAgICAgXCJPY3RvYmVyXCIsXHJcbi8vICAgICBcIk5vdmVtYmVyXCIsXHJcbi8vICAgICBcIkRlY2VtYmVyXCIsXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICBncm91cF9pZDogXCJcIixcclxuLy8gICAgIHVzZXJfaWQ6IFwiXCIsXHJcbi8vICAgICBub19vZl90aWNrZXRzOiBcIlwiLFxyXG4vLyAgICAgcmVmZXJyZWRfdHlwZTogXCJcIixcclxuLy8gICAgIHBheW1lbnRfdHlwZTogXCJcIixcclxuLy8gICAgIHJlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4vLyAgICAgYWdlbnQ6IFwiXCIsXHJcbi8vICAgICByZWZlcnJlZF9sZWFkOiBcIlwiLFxyXG4vLyAgICAgY2hpdF9hc2tpbmdfbW9udGg6IFwiXCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGNvbnN0IFtpc1ZlcmlmaWVkLCBzZXRJc1ZlcmlmaWVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4vLyAgICAgdXNlcl9pZDogXCJcIixcclxuLy8gICAgIHRpY2tldHM6IFwiXCIsXHJcbi8vICAgICBwYXltZW50X3R5cGU6IFwiXCIsXHJcbi8vICAgICByZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4vLyAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbi8vICAgICBhZ2VudDogXCJcIixcclxuLy8gICAgIHJlZmVycmVkX2xlYWQ6IFwiXCIsXHJcbi8vICAgICBjaGl0X2Fza2luZ19tb250aDogXCJcIixcclxuLy8gICB9KTtcclxuXHJcbi8vICAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbi8vICAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuLy8gICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4vLyAgICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbi8vICAgICBjb25zdCBhZG1pbklkID0gdXNlck9iaj8uX2lkO1xyXG4vLyAgICAgaWYgKGFkbWluSWQpIHtcclxuLy8gICAgICAgc2V0QWRtaW4odXNlck9iai5faWQpO1xyXG4vLyAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgc2V0QWRtaW4oXCJcIik7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuLy8gICAgICAgICBzZXRHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoR3JvdXBzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvLyBHZXQgc3RhdHVzIGNvdW50cyBmb3Igc3VtbWFyeVxyXG4vLyAgIGNvbnN0IGdldFN0YXR1c0NvdW50cyA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGNvbnRhY3RlZCA9IGZpbHRlcmVkRW5yb2xscy5maWx0ZXIoXHJcbi8vICAgICAgICh1KSA9PiB1LnN0YXR1cyAmJiB1LnN0YXR1cyAhPT0gXCJOb3QgQ29udGFjdGVkXCIsXHJcbi8vICAgICApO1xyXG4vLyAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgdG90YWw6IGNvbnRhY3RlZC5sZW5ndGgsXHJcbi8vICAgICAgIENvbnRhY3RlZDogY29udGFjdGVkLmZpbHRlcigodSkgPT4gdS5zdGF0dXMgPT09IFwiQ29udGFjdGVkXCIpLmxlbmd0aCxcclxuLy8gICAgICAgSW50ZXJlc3RlZDogY29udGFjdGVkLmZpbHRlcigodSkgPT4gdS5zdGF0dXMgPT09IFwiSW50ZXJlc3RlZFwiKS5sZW5ndGgsXHJcbi8vICAgICAgIFwiRm9sbG93IFVwXCI6IGNvbnRhY3RlZC5maWx0ZXIoKHUpID0+IHUuc3RhdHVzID09PSBcIkZvbGxvdyBVcFwiKS5sZW5ndGgsXHJcbi8vICAgICAgIENvbnZlcnRlZDogY29udGFjdGVkLmZpbHRlcigodSkgPT4gdS5zdGF0dXMgPT09IFwiQ29udmVydGVkXCIpLmxlbmd0aCxcclxuLy8gICAgICAgUmVqZWN0ZWQ6IGNvbnRhY3RlZC5maWx0ZXIoKHUpID0+IHUuc3RhdHVzID09PSBcIlJlamVjdGVkXCIpLmxlbmd0aCxcclxuLy8gICAgIH07XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gR2V0IHN0YXR1cyBjb2xvclxyXG4vLyAgIGNvbnN0IGdldFN0YXR1c0NvbG9yID0gKHN0YXR1cykgPT4ge1xyXG4vLyAgICAgc3dpdGNoIChzdGF0dXMpIHtcclxuLy8gICAgICAgY2FzZSBcIkFwcHJvdmVkXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIFwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctZW1lcmFsZC02MDAvMjBcIjtcclxuLy8gICAgICAgY2FzZSBcIlBlbmRpbmdcIjpcclxuLy8gICAgICAgICByZXR1cm4gXCJiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWFtYmVyLTYwMC8yMFwiO1xyXG4vLyAgICAgICBjYXNlIFwiSW50ZXJlc3RlZFwiOlxyXG4vLyAgICAgICAgIHJldHVybiBcImJnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWJsdWUtNjAwLzIwXCI7XHJcbi8vICAgICAgIGNhc2UgXCJOb3QgSW50ZXJlc3RlZFwiOlxyXG4vLyAgICAgICAgIHJldHVybiBcImJnLWdyYXktNTAgdGV4dC1ncmF5LTYwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyYXktNTAwLzIwXCI7XHJcbi8vICAgICAgIGNhc2UgXCJDb250YWN0ZWRcIjpcclxuLy8gICAgICAgICByZXR1cm4gXCJiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctaW5kaWdvLTYwMC8yMFwiO1xyXG4vLyAgICAgICBjYXNlIFwiRm9sbG93IFVwXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIFwiYmctcHVycGxlLTUwIHRleHQtcHVycGxlLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLXB1cnBsZS02MDAvMjBcIjtcclxuLy8gICAgICAgY2FzZSBcIkNvbnZlcnRlZFwiOlxyXG4vLyAgICAgICAgIHJldHVybiBcImJnLWdyZWVuLTUwIHRleHQtZ3JlZW4tNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctZ3JlZW4tNjAwLzIwXCI7XHJcbi8vICAgICAgIGNhc2UgXCJSZWplY3RlZFwiOlxyXG4vLyAgICAgICAgIHJldHVybiBcImJnLXJlZC01MCB0ZXh0LXJlZC03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1yZWQtNjAwLzIwXCI7XHJcbi8vICAgICAgIGRlZmF1bHQ6XHJcbi8vICAgICAgICAgcmV0dXJuIFwiYmctZ3JheS01MCB0ZXh0LWdyYXktNjAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctZ3JheS01MDAvMjBcIjtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBHZXQgc3RhdHVzIGljb25cclxuLy8gICBjb25zdCBnZXRTdGF0dXNJY29uID0gKHN0YXR1cykgPT4ge1xyXG4vLyAgICAgc3dpdGNoIChzdGF0dXMpIHtcclxuLy8gICAgICAgY2FzZSBcIkNvbnRhY3RlZFwiOlxyXG4vLyAgICAgICAgIHJldHVybiAoXHJcbi8vICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTRcIlxyXG4vLyAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICBkPVwiTTMgNWEyIDIgMCAwMTItMmgzLjI4YTEgMSAwIDAxLjk0OC42ODRsMS40OTggNC40OTNhMSAxIDAgMDEtLjUwMiAxLjIxbC0yLjI1NyAxLjEzYTExLjA0MiAxMS4wNDIgMCAwMDUuNTE2IDUuNTE2bDEuMTMtMi4yNTdhMSAxIDAgMDExLjIxLS41MDJsNC40OTMgMS40OThhMSAxIDAgMDEuNjg0Ljk0OVYxOWEyIDIgMCAwMS0yIDJoLTFDOS43MTYgMjEgMyAxNC4yODQgMyA2VjV6XCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgIGNhc2UgXCJJbnRlcmVzdGVkXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNFwiXHJcbi8vICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgICAgIGQ9XCJNMTEuMDQ5IDIuOTI3Yy4zLS45MjEgMS42MDMtLjkyMSAxLjkwMiAwbDEuNTE5IDQuNjc0YTEgMSAwIDAwLjk1LjY5aDQuOTE1Yy45NjkgMCAxLjM3MSAxLjI0LjU4OCAxLjgxbC0zLjk3NiAyLjg4OGExIDEgMCAwMC0uMzYzIDEuMTE4bDEuNTE4IDQuNjc0Yy4zLjkyMi0uNzU1IDEuNjg4LTEuNTM4IDEuMTE4bC0zLjk3Ni0yLjg4OGExIDEgMCAwMC0xLjE3NiAwbC0zLjk3NiAyLjg4OGMtLjc4My41Ny0xLjgzOC0uMTk3LTEuNTM4LTEuMTE4bDEuNTE4LTQuNjc0YTEgMSAwIDAwLS4zNjMtMS4xMThsLTMuOTc2LTIuODg4Yy0uNzg0LS41Ny0uMzgtMS44MS41ODgtMS44MWg0LjkxNGExIDEgMCAwMC45NTEtLjY5bDEuNTE5LTQuNjc0elwiXHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICBjYXNlIFwiRm9sbG93IFVwXCI6XHJcbi8vICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNFwiXHJcbi8vICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgICAgIGQ9XCJNMTIgOHY0bDMgM202LTNhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgIGNhc2UgXCJDb252ZXJ0ZWRcIjpcclxuLy8gICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuLy8gICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbi8vICAgICAgICAgICAgICAgZD1cIk05IDEybDIgMiA0LTRtNiAyYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiXHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICBjYXNlIFwiUmVqZWN0ZWRcIjpcclxuLy8gICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuLy8gICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbi8vICAgICAgICAgICAgICAgZD1cIk0xMCAxNGwyLTJtMCAwbDItMm0tMiAybC0yLTJtMiAybDIgMm03LTJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgIGRlZmF1bHQ6XHJcbi8vICAgICAgICAgcmV0dXJuIG51bGw7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gRmlsdGVyIHVzZXJzIGJhc2VkIG9uIGFjdGl2ZSB0YWIgKHN0YXR1cylcclxuLy8gICBjb25zdCBnZXRUYWJGaWx0ZXJlZEVucm9sbHMgPSAoKSA9PiB7XHJcbi8vICAgICBpZiAoYWN0aXZlVGFiID09PSBcInBlbmRpbmdcIikge1xyXG4vLyAgICAgICByZXR1cm4gZmlsdGVyZWRFbnJvbGxzLmZpbHRlcihcclxuLy8gICAgICAgICAoZW5yb2xsKSA9PiBlbnJvbGwuc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIiB8fCAhZW5yb2xsLnN0YXR1cyxcclxuLy8gICAgICAgKTtcclxuLy8gICAgIH0gZWxzZSB7XHJcbi8vICAgICAgIHJldHVybiBmaWx0ZXJlZEVucm9sbHMuZmlsdGVyKFxyXG4vLyAgICAgICAgIChlbnJvbGwpID0+IGVucm9sbC5zdGF0dXMgJiYgZW5yb2xsLnN0YXR1cyAhPT0gXCJOb3QgQ29udGFjdGVkXCIsXHJcbi8vICAgICAgICk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vIGNvbnN0IGZldGNoQWxsRW5yb2xsbWVudERhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbi8vICAgdHJ5IHtcclxuLy8gICAgIHNldElzRGF0YVRhYmxlTG9hZGluZyh0cnVlKTtcclxuLy8gICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvbW9iaWxlLWFwcC1lbnJvbGwvZ2V0LW1vYmlsZS1hcHAtZW5yb2xsXCIpO1xyXG4vLyAgICAgY29uc3QgcmF3RGF0YSA9IHJlcy5kYXRhO1xyXG5cclxuLy8gICAgIC8vIENvbXB1dGUgc3VtbWFyeSBtZXRyaWNzIGZyb20gcmF3IGRhdGFcclxuLy8gICAgIGNvbnN0IHRvdGFsRW5yb2xsbWVudHMgPSByYXdEYXRhLmxlbmd0aDtcclxuLy8gICAgIGNvbnN0IHRvdGFsVGlja2V0cyA9IHJhd0RhdGEucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIChpdGVtLm5vX29mX3RpY2tldHMgfHwgMCksIDApO1xyXG4vLyAgICAgY29uc3QgdW5pcXVlQ3VzdG9tZXJzID0gbmV3IFNldChyYXdEYXRhLm1hcChpdGVtID0+IGl0ZW0udXNlcl9pZD8uX2lkKS5maWx0ZXIoQm9vbGVhbikpLnNpemU7XHJcbi8vICAgICBjb25zdCB1bmlxdWVHcm91cHMgPSBuZXcgU2V0KHJhd0RhdGEubWFwKGl0ZW0gPT4gaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSkuZmlsdGVyKEJvb2xlYW4pKS5zaXplO1xyXG5cclxuLy8gICAgIHNldFN1bW1hcnlTdGF0cyh7XHJcbi8vICAgICAgIHRvdGFsRW5yb2xsbWVudHMsXHJcbi8vICAgICAgIHRvdGFsVGlja2V0cyxcclxuLy8gICAgICAgdW5pcXVlQ3VzdG9tZXJzLFxyXG4vLyAgICAgICB1bmlxdWVHcm91cHMsXHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICBjb25zdCBkYXRhID0gcmF3RGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICBfaWQ6IGl0ZW0uX2lkLFxyXG4vLyAgICAgICBpZDogaW5kZXggKyAxLFxyXG4vLyAgICAgICBtb2JpbGVfZW5yb2xsX2NvZGU6IGl0ZW0/Lm1vYmlsZV9lbnJvbGxfY29kZSxcclxuLy8gICAgICAgbmFtZTogaXRlbS51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgIHBob25lX251bWJlcjogaXRlbS51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgICAgIGdyb3VwX25hbWU6IGl0ZW0uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgIG5vX29mX3RpY2tldHM6IGl0ZW0ubm9fb2ZfdGlja2V0cyxcclxuLy8gICAgICAgcGF5bWVudF90eXBlOiBpdGVtLnBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGl0ZW0uY2hpdF9hc2tpbmdfbW9udGgsXHJcbi8vICAgICAgIHJlZmVycmVkX3R5cGU6IGl0ZW0ucmVmZXJyZWRfdHlwZSxcclxuLy8gICAgICAgc3RhdHVzOiBpdGVtLnN0YXR1cyB8fCBcIk5vdCBDb250YWN0ZWRcIixcclxuLy8gICAgICAgcmVtYXJrOiBpdGVtLnJlbWFyayB8fCBcIlwiLFxyXG4vLyAgICAgICBmb2xsb3dfdXBfZGF0ZTogaXRlbS5mb2xsb3dfdXBfZGF0ZSB8fCBcIlwiLFxyXG4vLyAgICAgICAvLyDinIUgUFJFU0VSVkUgVEhFIEZVTEwgTkVTVEVEIE9CSkVDVFMgRk9SIEFQUFJPVkUgRlVOQ1RJT05cclxuLy8gICAgICAgdXNlcl9pZDogaXRlbS51c2VyX2lkLCAgICAgICAgLy8gS2VlcCB0aGUgZnVsbCB1c2VyIG9iamVjdFxyXG4vLyAgICAgICBncm91cF9pZDogaXRlbS5ncm91cF9pZCwgICAgICAvLyBLZWVwIHRoZSBmdWxsIGdyb3VwIG9iamVjdFxyXG4vLyAgICAgICByZWZlcnJlZF9jdXN0b21lcjogaXRlbS5yZWZlcnJlZF9jdXN0b21lcixcclxuLy8gICAgICAgcmVmZXJyZWRfbGVhZDogaXRlbS5yZWZlcnJlZF9sZWFkLFxyXG4vLyAgICAgICBhZ2VudDogaXRlbS5hZ2VudCxcclxuLy8gICAgICAgZW5yb2xsbWVudF9kYXRlOiBpdGVtLmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdLFxyXG4vLyAgICAgICByZWZlcnJlZF9ieTpcclxuLy8gICAgICAgICBpdGVtPy5yZWZlcnJlZF90eXBlPy50b0xvd2VyQ2FzZSgpPy50cmltKCkgPT09IFwiYWdlbnRcIiAmJiBpdGVtPy5hZ2VudFxyXG4vLyAgICAgICAgICAgPyBgJHtpdGVtPy5hZ2VudD8ubmFtZSB8fCBcIi1cIn0gfCAke2l0ZW0/LmFnZW50Py5waG9uZV9udW1iZXIgfHwgXCItXCJ9YFxyXG4vLyAgICAgICAgICAgOiBpdGVtPy5yZWZlcnJlZF90eXBlPy50b0xvd2VyQ2FzZSgpPy50cmltKCkgPT09IFwiZW1wbG95ZWVcIiAmJiBpdGVtPy5hZ2VudFxyXG4vLyAgICAgICAgICAgPyBgJHtpdGVtPy5hZ2VudD8ubmFtZSB8fCBcIi1cIn0gfCAke2l0ZW0/LmFnZW50Py5waG9uZV9udW1iZXIgfHwgXCItXCJ9YFxyXG4vLyAgICAgICAgICAgOiBpdGVtPy5yZWZlcnJlZF90eXBlPy50b0xvd2VyQ2FzZSgpPy50cmltKCkgPT09IFwiY3VzdG9tZXJcIiAmJiBpdGVtPy5yZWZlcnJlZF9jdXN0b21lclxyXG4vLyAgICAgICAgICAgPyBgJHtpdGVtPy5yZWZlcnJlZF9jdXN0b21lcj8uZnVsbF9uYW1lIHx8IFwiLVwifSB8ICR7aXRlbT8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlciB8fCBcIi1cIn1gXHJcbi8vICAgICAgICAgICA6IGl0ZW0/LnJlZmVycmVkX3R5cGU/LnRvTG93ZXJDYXNlKCk/LnRyaW0oKSA9PT0gXCJsZWFkXCIgJiYgaXRlbT8ucmVmZXJyZWRfbGVhZFxyXG4vLyAgICAgICAgICAgPyBgJHtpdGVtPy5yZWZlcnJlZF9sZWFkPy5sZWFkX25hbWUgfHwgXCItXCJ9IHwgJHtpdGVtPy5yZWZlcnJlZF9sZWFkPy5hZ2VudF9udW1iZXIgfHwgXCItXCJ9YFxyXG4vLyAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgYWN0aW9uOiAoXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgIDxEcm9wZG93blxyXG4vLyAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4vLyAgICAgICAgICAgICAgIG1lbnU9e3tcclxuLy8gICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbi8vICAgICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGl0ZW0uX2lkKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGl0ZW0uX2lkKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRW5yb2xsQ2xpY2soaXRlbSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIEFwcHJvdmVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgICBdLFxyXG4vLyAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkIGN1cnNvci1wb2ludGVyXCIgLz5cclxuLy8gICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICksXHJcblxyXG4vLyAgICAgfSkpO1xyXG4vLyAgICAgc2V0VGFibGVFbnJvbGxzKGRhdGEpO1xyXG4vLyAgICAgc2V0RmlsdGVyZWRFbnJvbGxzKGRhdGEpO1xyXG4vLyAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBlbnJvbGxtZW50IGRhdGFcIiwgZXJyKTtcclxuLy8gICB9IGZpbmFsbHkge1xyXG4vLyAgICAgc2V0SXNEYXRhVGFibGVMb2FkaW5nKGZhbHNlKTtcclxuLy8gICB9XHJcbi8vIH0sIFtdKTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuLy8gICB9LCBbZmV0Y2hBbGxFbnJvbGxtZW50RGF0YV0pO1xyXG5cclxuLy8gICAvLyBGaWx0ZXIgYnkgc2VhcmNoIHRlcm1cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgaWYgKHNlYXJjaFRlcm0pIHtcclxuLy8gICAgICAgY29uc3QgZmlsdGVyZWQgPSBUYWJsZUVucm9sbHMuZmlsdGVyKFxyXG4vLyAgICAgICAgIChlbnJvbGwpID0+XHJcbi8vICAgICAgICAgICBlbnJvbGwubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcclxuLy8gICAgICAgICAgIGVucm9sbC5waG9uZV9udW1iZXIudG9TdHJpbmcoKS5pbmNsdWRlcyhzZWFyY2hUZXJtKSB8fFxyXG4vLyAgICAgICAgICAgZW5yb2xsLmdyb3VwX25hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpLFxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgICBzZXRGaWx0ZXJlZEVucm9sbHMoZmlsdGVyZWQpO1xyXG4vLyAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgc2V0RmlsdGVyZWRFbnJvbGxzKFRhYmxlRW5yb2xscyk7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW3NlYXJjaFRlcm0sIFRhYmxlRW5yb2xsc10pO1xyXG5cclxuLy8gICAvLyBDb250YWN0IFN1bW1hcnkgRGFzaGJvYXJkIENvbXBvbmVudFxyXG4vLyAgIGNvbnN0IENvbnRhY3RTdW1tYXJ5RGFzaGJvYXJkID0gKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgY291bnRzID0gZ2V0U3RhdHVzQ291bnRzKCk7XHJcbi8vICAgICBjb25zdCBwZW5kaW5nQ291bnQgPSBmaWx0ZXJlZEVucm9sbHMuZmlsdGVyKFxyXG4vLyAgICAgICAodSkgPT4gdS5zdGF0dXMgPT09IFwiTm90IENvbnRhY3RlZFwiIHx8ICF1LnN0YXR1cyxcclxuLy8gICAgICkubGVuZ3RoO1xyXG4vLyAgICAgY29uc3QgY29udmVyc2lvblJhdGUgPVxyXG4vLyAgICAgICBjb3VudHMudG90YWwgPiAwXHJcbi8vICAgICAgICAgPyAoKGNvdW50cy5Db252ZXJ0ZWQgLyBjb3VudHMudG90YWwpICogMTAwKS50b0ZpeGVkKDEpXHJcbi8vICAgICAgICAgOiBcIjAuMFwiO1xyXG4vLyAgICAgY29uc3QgcmVqZWN0aW9uUmF0ZSA9XHJcbi8vICAgICAgIGNvdW50cy50b3RhbCA+IDBcclxuLy8gICAgICAgICA/ICgoY291bnRzLlJlamVjdGVkIC8gY291bnRzLnRvdGFsKSAqIDEwMCkudG9GaXhlZCgxKVxyXG4vLyAgICAgICAgIDogXCIwLjBcIjtcclxuXHJcbi8vICAgICByZXR1cm4gKFxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNSBtYi02XCI+XHJcbi8vICAgICAgICAgey8qIFN1bW1hcnkgSGVhZGVyICovfVxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGdhcC0zIG1iLTVcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwMCB0by1pbmRpZ28tNjAwIHJvdW5kZWQteGwgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LWJsdWUtMjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNVwiXHJcbi8vICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGQ9XCJNOSAxOXYtNmEyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2NmEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0yem0wIDBWOWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAydjEwbS02IDBhMiAyIDAgMDAyIDJoMmEyIDIgMCAwMDItMm0wIDBWNWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAydjE0YTIgMiAwIDAxLTIgMmgtMmEyIDIgMCAwMS0yLTJ6XCJcclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgIENvbnRhY3QgU3VtbWFyeVxyXG4vLyAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICBPdmVydmlldyBvZiBtb2JpbGUgZW5yb2xsbWVudCBmb2xsb3ctdXAgd29ya1xyXG4vLyAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7LyogQ29udmVyc2lvbiBSYXRlIEJhZGdlICovfVxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4vLyAgICAgICAgICAgICB7cGFyc2VGbG9hdChjb252ZXJzaW9uUmF0ZSkgPiAwICYmIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctZW1lcmFsZC01MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEuNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZD1cIk0xMyA3aDhtMCAwdjhtMC04bC04IDgtNC00LTYgNlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC03MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2NvbnZlcnNpb25SYXRlfSUgY29udmVyc2lvblxyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICB7cGFyc2VGbG9hdChyZWplY3Rpb25SYXRlKSA+IDAgJiYgKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEuNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXJlZC01MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBkPVwiTTEzIDE3aDhtMCAwVjltMCA4bC04LTgtNCA0LTYtNlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7cmVqZWN0aW9uUmF0ZX0lIHJlamVjdGlvblxyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiBTdGF0dXMgQ2FyZHMgUm93ICovfVxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBsZzpncmlkLWNvbHMtNSBnYXAtMyBtYi01XCI+XHJcbi8vICAgICAgICAgICB7TU9CSUxFX0VOUk9MTF9TVEFUVVNfQ09ORklHLm1hcCgoY2ZnKSA9PiB7XHJcbi8vICAgICAgICAgICAgIGNvbnN0IGNvdW50ID0gY291bnRzW2NmZy5rZXldO1xyXG4vLyAgICAgICAgICAgICBjb25zdCBwZXJjZW50YWdlID1cclxuLy8gICAgICAgICAgICAgICBjb3VudHMudG90YWwgPiAwID8gKChjb3VudCAvIGNvdW50cy50b3RhbCkgKiAxMDApLnRvRml4ZWQoMCkgOiAwO1xyXG4vLyAgICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgIGtleT17Y2ZnLmtleX1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC00IGhvdmVyOnNoYWRvdy1tZCBob3ZlcjotdHJhbnNsYXRlLXktMC41IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBncm91cCBjdXJzb3ItZGVmYXVsdCAke2NvdW50ID09PSAwID8gXCJvcGFjaXR5LTUwXCIgOiBcIlwifWB9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctMjAgaC0yMCByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgJHtjZmcuY29sb3J9IG9wYWNpdHktWzAuMDddIC10cmFuc2xhdGUteS0xLzIgdHJhbnNsYXRlLXgtMS8yIGdyb3VwLWhvdmVyOm9wYWNpdHktWzAuMTJdIHRyYW5zaXRpb24tb3BhY2l0eWB9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctOSBoLTkgcm91bmRlZC1sZyAke2NmZy5iZ0xpZ2h0fSAke2NmZy5pY29uQ29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTMgcmluZy0xICR7Y2ZnLnJpbmdDb2xvcn1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2NmZy5pY29ufVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1ncmF5LTkwMCBsZWFkaW5nLW5vbmUgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjb3VudH1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjZmcubGFiZWx9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xLjUgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tciAke2NmZy5jb2xvcn0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNzAwIGVhc2Utb3V0YH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwZXJjZW50YWdlfSVgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCBtdC0xIHRleHQtcmlnaHRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7cGVyY2VudGFnZX0lXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgfSl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiBCb3R0b20gU3RhdHMgQmFyICovfVxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgYmctc2xhdGUtNTAgcm91bmRlZC14bCBweC00IHB5LTIuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC82MFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1sZyBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTYwMCB0by1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuLy8gICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZD1cIk0xNyAyMGg1di0yYTMgMyAwIDAwLTUuMzU2LTEuODU3TTE3IDIwSDdtMTAgMHYtMmMwLS42NTYtLjEyNi0xLjI4My0uMzU2LTEuODU3TTcgMjBIMnYtMmEzIDMgMCAwMTUuMzU2LTEuODU3TTcgMjB2LTJjMC0uNjU2LjEyNi0xLjI4My4zNTYtMS44NTdtMCAwYTUuMDAyIDUuMDAyIDAgMDE5LjI4OCAwTTE1IDExYTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHpcIlxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwIGxlYWRpbmctbm9uZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAge2NvdW50cy50b3RhbH1cclxuLy8gICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgVG90YWwgUHJvY2Vzc2VkXHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBiZy1hbWJlci01MCByb3VuZGVkLXhsIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItYW1iZXItMjAwLzYwXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNTAwIHRvLW9yYW5nZS01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctc21cIj5cclxuLy8gICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuLy8gICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZD1cIk0xMiA4djRsMyAzbTYtM2E5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIlxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWFtYmVyLTcwMCBsZWFkaW5nLW5vbmVcIj5cclxuLy8gICAgICAgICAgICAgICAgIHtwZW5kaW5nQ291bnR9XHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYW1iZXItNjAwIGZvbnQtbWVkaXVtXCI+XHJcbi8vICAgICAgICAgICAgICAgICBTdGlsbCBQZW5kaW5nXHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIHtjb3VudHNbXCJGb2xsb3cgVXBcIl0gPiAwICYmIChcclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IGJnLXB1cnBsZS01MCByb3VuZGVkLXhsIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItcHVycGxlLTIwMC82MFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwMCB0by1wdXJwbGUtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LXNtXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBkPVwiTTE1IDE3aDVsLTEuNDA1LTEuNDA1QTIuMDMyIDIuMDMyIDAgMDExOCAxNC4xNThWMTFhNi4wMDIgNi4wMDIgMCAwMC00LTUuNjU5VjVhMiAyIDAgMTAtNCAwdi4zNDFDNy42NyA2LjE2NSA2IDguMzg4IDYgMTF2My4xNTljMCAuNTM4LS4yMTQgMS4wNTUtLjU5NSAxLjQzNkw0IDE3aDVtNiAwdjFhMyAzIDAgMTEtNiAwdi0xbTYgMEg5XCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtcHVycGxlLTcwMCBsZWFkaW5nLW5vbmVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2NvdW50c1tcIkZvbGxvdyBVcFwiXX1cclxuLy8gICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcHVycGxlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBGb2xsb3cgVXBzIER1ZVxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IG1sLWF1dG9cIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwIGxlYWRpbmctbm9uZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAge2ZpbHRlcmVkRW5yb2xscy5sZW5ndGggPiAwXHJcbi8vICAgICAgICAgICAgICAgICAgID8gKChjb3VudHMudG90YWwgLyBmaWx0ZXJlZEVucm9sbHMubGVuZ3RoKSAqIDEwMCkudG9GaXhlZCgxKVxyXG4vLyAgICAgICAgICAgICAgICAgICA6IFwiMC4wXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAlXHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuLy8gICAgICAgICAgICAgICAgIFByb2Nlc3MgUmF0ZVxyXG4vLyAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy0xMiBoLTEyXCI+XHJcbi8vICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgLXJvdGF0ZS05MFwiIHZpZXdCb3g9XCIwIDAgMzYgMzZcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICAgICAgICAgIGQ9XCJNMTggMi4wODQ1IGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgMzEuODMxIGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgLTMxLjgzMVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiI2YxZjVmOVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiM1wiXHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICAgICAgZD1cIk0xOCAyLjA4NDUgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAzMS44MzEgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAtMzEuODMxXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJ1cmwoI3Byb2dyZXNzR3JhZGllbnQpXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtgJHtmaWx0ZXJlZEVucm9sbHMubGVuZ3RoID4gMCA/IChjb3VudHMudG90YWwgLyBmaWx0ZXJlZEVucm9sbHMubGVuZ3RoKSAqIDEwMCA6IDB9LCAxMDBgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDxkZWZzPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGluZWFyR3JhZGllbnRcclxuLy8gICAgICAgICAgICAgICAgICAgICBpZD1cInByb2dyZXNzR3JhZGllbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHgxPVwiMCVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHkxPVwiMCVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHgyPVwiMTAwJVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgeTI9XCIwJVwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwJVwiIHN0b3BDb2xvcj1cIiM2MzY2ZjFcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjEwMCVcIiBzdG9wQ29sb3I9XCIjM2I4MmY2XCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGVmcz5cclxuLy8gICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIE9wZW4gc3RhdHVzIHVwZGF0ZSBtb2RhbCAtIFVzaW5nIEFudCBEZXNpZ24gTW9kYWxcclxuLy8gICBjb25zdCBvcGVuU3RhdHVzVXBkYXRlTW9kYWwgPSAoZW5yb2xsKSA9PiB7XHJcbi8vICAgICBzZXRTdGF0dXNVcGRhdGVEYXRhKHtcclxuLy8gICAgICAgX2lkOiBlbnJvbGwuX2lkLFxyXG4vLyAgICAgICBzdGF0dXM6IGVucm9sbC5zdGF0dXMgfHwgXCJcIixcclxuLy8gICAgICAgcmVtYXJrOiBlbnJvbGwucmVtYXJrIHx8IFwiXCIsXHJcbi8vICAgICAgIGZvbGxvd191cF9kYXRlOiBlbnJvbGwuZm9sbG93X3VwX2RhdGUgfHwgXCJcIixcclxuLy8gICAgIH0pO1xyXG4vLyAgICAgc2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsKHRydWUpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIEhhbmRsZSBzdGF0dXMgdXBkYXRlIHN1Ym1pdFxyXG4vLyAgIGNvbnN0IGhhbmRsZVN0YXR1c1VwZGF0ZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIGNvbnN0IHsgX2lkLCBzdGF0dXMsIHJlbWFyaywgZm9sbG93X3VwX2RhdGUgfSA9IHN0YXR1c1VwZGF0ZURhdGE7XHJcbi8vICAgICBpZiAoIXN0YXR1cykge1xyXG4vLyAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYSBzdGF0dXMuXCIsXHJcbi8vICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICByZXR1cm47XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAoc3RhdHVzID09PSBcIkZvbGxvdyBVcFwiICYmICFmb2xsb3dfdXBfZGF0ZSkge1xyXG4vLyAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYSBmb2xsb3ctdXAgZGF0ZS5cIixcclxuLy8gICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBzZXRJc1N0YXR1c1VwZGF0aW5nKHRydWUpO1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgYXdhaXQgYXBpLnB1dChgL21vYmlsZS1hcHAtZW5yb2xsL3ZlcmlmeS1lbnJvbGwvJHtfaWR9YCwge1xyXG4vLyAgICAgICAgIHN0YXR1cyxcclxuLy8gICAgICAgICByZW1hcms6IHJlbWFyayB8fCBcIlwiLFxyXG4vLyAgICAgICAgIGZvbGxvd191cF9kYXRlOiBzdGF0dXMgPT09IFwiRm9sbG93IFVwXCIgPyBmb2xsb3dfdXBfZGF0ZSA6IFwiXCIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIlN0YXR1cyB1cGRhdGVkIHN1Y2Nlc3NmdWxseSFcIixcclxuLy8gICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIHNldFNob3dTdGF0dXNVcGRhdGVNb2RhbChmYWxzZSk7XHJcbi8vICAgICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuLy8gICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4vLyAgICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHVwZGF0ZSBzdGF0dXMuXCIsXHJcbi8vICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldElzU3RhdHVzVXBkYXRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyBjb25zdCBBY3Rpb25Ecm9wZG93biA9ICh7IGVucm9sbCB9KSA9PiB7XHJcbi8vICAgLy8gRGVidWcgbG9nIHRvIHNlZSB3aGF0IGRhdGEgaXMgYXZhaWxhYmxlXHJcbi8vICAgY29uc29sZS5sb2coXCI9PT0gQWN0aW9uRHJvcGRvd24gZW5yb2xsIGRhdGEgPT09XCIsIGVucm9sbCk7XHJcbi8vICAgY29uc29sZS5sb2coXCJ1c2VyX2lkOlwiLCBlbnJvbGwudXNlcl9pZCk7XHJcbi8vICAgY29uc29sZS5sb2coXCJncm91cF9pZDpcIiwgZW5yb2xsLmdyb3VwX2lkKTtcclxuLy8gICBjb25zb2xlLmxvZyhcIl9pZDpcIiwgZW5yb2xsLl9pZCk7XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUVucm9sbENsaWNrV3JhcHBlciA9ICgpID0+IHtcclxuLy8gICAgIGNvbnNvbGUubG9nKFwiPT09IEFwcHJvdmUgYnV0dG9uIGNsaWNrZWQgZm9yIGVucm9sbG1lbnQgPT09XCIsIGVucm9sbCk7XHJcbi8vICAgICAvLyBQYXNzIHRoZSBmdWxsIGVucm9sbCBvYmplY3Qgd2l0aCBhbGwgbmVzdGVkIGRhdGFcclxuLy8gICAgIGhhbmRsZUVucm9sbENsaWNrKGVucm9sbCk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxEcm9wZG93blxyXG4vLyAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuLy8gICAgICAgbWVudT17e1xyXG4vLyAgICAgICAgIGl0ZW1zOiBbXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCJzdGF0dXNcIixcclxuLy8gICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIHB4LTIgcHktMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXHJcbi8vICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuU3RhdHVzVXBkYXRlTW9kYWwoZW5yb2xsKX1cclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBkPVwiTTExIDVINmEyIDIgMCAwMC0yIDJ2MTFhMiAyIDAgMDAyIDJoMTFhMiAyIDAgMDAyLTJ2LTVtLTEuNDE0LTkuNDE0YTIgMiAwIDExMi44MjggMi44MjhMMTEuODI4IDE1SDl2LTIuODI4bDguNTg2LTguNTg2elwiXHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgIFVwZGF0ZSBTdGF0dXNcclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbi8vICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXIgcHgtMiBweS0xXCJcclxuLy8gICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihlbnJvbGwuX2lkKX1cclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICBFZGl0XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4vLyAgICAgICAgICAgICBsYWJlbDogKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCBmb250LW1lZGl1bSBjdXJzb3ItcG9pbnRlciBweC0yIHB5LTFcIlxyXG4vLyAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGVucm9sbC5faWQpfVxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAga2V5OiBcIjNcIixcclxuLy8gICAgICAgICAgICAgbGFiZWw6IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIHB4LTIgcHktMVwiXHJcbi8vICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFbnJvbGxDbGlja1dyYXBwZXJ9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgQXBwcm92ZVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApLFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICBdLFxyXG4vLyAgICAgICB9fVxyXG4vLyAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuLy8gICAgID5cclxuLy8gICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZCBjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuLy8gICAgIDwvRHJvcGRvd24+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vICAgLy8gUmVuZGVyIGVucm9sbG1lbnQgY2FyZCBmb3IgZ3JpZCB2aWV3XHJcbi8vICAgY29uc3QgcmVuZGVyRW5yb2xsbWVudENhcmQgPSAoZW5yb2xsKSA9PiB7XHJcbi8vICAgICBjb25zdCBpc1BlbmRpbmcgPSBlbnJvbGwuc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIiB8fCAhZW5yb2xsLnN0YXR1cztcclxuLy8gICAgIGlmIChhY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiICYmICFpc1BlbmRpbmcpIHJldHVybiBudWxsO1xyXG4vLyAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjb250YWN0ZWRcIiAmJiBpc1BlbmRpbmcpIHJldHVybiBudWxsO1xyXG5cclxuLy8gICAgIC8vIENPTlRBQ1RFRCBUQUIg4oCUIFJpY2ggd29yay1zdGF0dXMgY2FyZFxyXG4vLyAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjb250YWN0ZWRcIikge1xyXG4vLyAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgIGtleT17ZW5yb2xsLl9pZH1cclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjotdHJhbnNsYXRlLXktMSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIlxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctZnVsbCBoLTEuNSByb3VuZGVkLXQtMnhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB0by1pbmRpZ28tNTAwIG9wYWNpdHktOTBcIiAvPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcHQtNlwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1pbi13LTBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtaW5kaWdvLTcwMCBmb250LWJvbGQgdGV4dC1zbSBmbGV4LXNocmluay0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtlbnJvbGwubmFtZT8uY2hhckF0KDApPy50b1VwcGVyQ2FzZSgpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIHRydW5jYXRlIHRleHQtbGdcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLm5hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwubW9iaWxlX2Vucm9sbF9jb2RlfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8QWN0aW9uRHJvcGRvd24gZW5yb2xsPXtlbnJvbGx9IC8+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTIuNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBQaG9uZVxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMC41XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtlbnJvbGwucGhvbmVfbnVtYmVyfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtMi41XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbi8vICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0wLjUgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2Vucm9sbC5ncm91cF9uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBXT1JLIFNUQVRVUyBTRUNUSU9OICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2xhdGUtNTAgdG8tYmx1ZS01MC81MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzgwIHAtNCBzcGFjZS15LTNcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSA1SDdhMiAyIDAgMDAtMiAydjEwYTIgMiAwIDAwMiAyaDhhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJoLTJNOSA1YTIgMiAwIDAwMiAyaDJhMiAyIDAgMDAyLTJNOSA1YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgICAgICBXb3JrIFN0YXR1c1xyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhblxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgJHtnZXRTdGF0dXNDb2xvcihlbnJvbGwuc3RhdHVzKX1gfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzSWNvbihlbnJvbGwuc3RhdHVzKX1cclxuLy8gICAgICAgICAgICAgICAgICAge2Vucm9sbC5zdGF0dXN9XHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctZW1lcmFsZC02MDAvMjBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2Vucm9sbC5ub19vZl90aWNrZXRzfSB0aWNrZXRzXHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHtlbnJvbGwucmVtYXJrICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgUmVtYXJrXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwucmVtYXJrfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgIHtlbnJvbGwucmVmZXJyZWRfYnkgJiYgZW5yb2xsLnJlZmVycmVkX2J5ICE9PSBcIk4vQVwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHAtMi41XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0wLjVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIFJlZmVycmVkIEJ5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWluZGlnby03MDAgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwucmVmZXJyZWRfYnl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICB7ZW5yb2xsLmZvbGxvd191cF9kYXRlICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItcHVycGxlLTIwMCBwLTIuNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTAuNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgRm9sbG93IFVwIERhdGVcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wdXJwbGUtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk04IDdWM204IDRWM20tOSA4aDEwTTUgMjFoMTRhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJ6XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1wdXJwbGUtNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwuZm9sbG93X3VwX2RhdGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgdGV4dC1yaWdodFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgRW5yb2xsZWQ6IHtlbnJvbGwuZW5yb2xsbWVudF9kYXRlfVxyXG4vLyAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgKTtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICAvLyBQRU5ESU5HIFRBQlxyXG4vLyAgICAgcmV0dXJuIChcclxuLy8gICAgICAgPGRpdlxyXG4vLyAgICAgICAgIGtleT17ZW5yb2xsLl9pZH1cclxuLy8gICAgICAgICBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3cteGwgaG92ZXI6LXRyYW5zbGF0ZS15LTEgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcclxuLy8gICAgICAgPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctZnVsbCBoLTEuNSByb3VuZGVkLXQtMnhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1hbWJlci00MDAgdG8tb3JhbmdlLTUwMCBvcGFjaXR5LTgwXCIgLz5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBwdC02XCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtaW4tdy0wXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWFtYmVyLTcwMCBmb250LWJvbGQgdGV4dC1zbSBmbGV4LXNocmluay0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICB7ZW5yb2xsLm5hbWU/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cnVuY2F0ZSB0ZXh0LWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtlbnJvbGwubmFtZX1cclxuLy8gICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2Vucm9sbC5tb2JpbGVfZW5yb2xsX2NvZGV9XHJcbi8vICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8QWN0aW9uRHJvcGRvd24gZW5yb2xsPXtlbnJvbGx9IC8+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgbWItNFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTIuNVwiPlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgIFBob25lXHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTAuNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAge2Vucm9sbC5waG9uZV9udW1iZXJ9XHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yLjVcIj5cclxuLy8gICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICBHcm91cFxyXG4vLyAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0wLjUgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgIHtlbnJvbGwuZ3JvdXBfbmFtZX1cclxuLy8gICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LWdyYXktNTAwIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBwdC0zIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCBmb250LW1lZGl1bSBiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWFtYmVyLTYwMC8yMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFBlbmRpbmdcclxuLy8gICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4vLyAgICAgICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCJcclxuLy8gICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZD1cIk04IDdWM204IDRWM20tOSA4aDEwTTUgMjFoMTRhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJ6XCJcclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgICAge2Vucm9sbC5lbnJvbGxtZW50X2RhdGV9XHJcbi8vICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgICk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gTGlzdCB2aWV3IHJvd1xyXG4vLyAgIGNvbnN0IEVucm9sbFJvdyA9ICh7IGVucm9sbCB9KSA9PiB7XHJcbi8vICAgICBjb25zdCBpc1BlbmRpbmcgPSBlbnJvbGwuc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIiB8fCAhZW5yb2xsLnN0YXR1cztcclxuLy8gICAgIGlmIChhY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiICYmICFpc1BlbmRpbmcpIHJldHVybiBudWxsO1xyXG4vLyAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjb250YWN0ZWRcIiAmJiBpc1BlbmRpbmcpIHJldHVybiBudWxsO1xyXG5cclxuLy8gICAgIGlmIChhY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIpIHtcclxuLy8gICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICBrZXk9e2Vucm9sbC5faWR9XHJcbi8vICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1sZyBob3Zlcjpib3JkZXItYmx1ZS0zMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlblwiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtNCBwLTRcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB3LWZ1bGwgc206dy1hdXRvXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLWluZGlnby0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1pbmRpZ28tNzAwIGZvbnQtYm9sZCB0ZXh0LXNtIGZsZXgtc2hyaW5rLTBcIj5cclxuLy8gICAgICAgICAgICAgICAgIHtlbnJvbGwubmFtZT8uY2hhckF0KDApPy50b1VwcGVyQ2FzZSgpfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMSBmbGV4LXdyYXBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLm5hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkICR7Z2V0U3RhdHVzQ29sb3IoZW5yb2xsLnN0YXR1cyl9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtnZXRTdGF0dXNJY29uKGVucm9sbC5zdGF0dXMpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwuc3RhdHVzfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1lbWVyYWxkLTYwMC8yMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwubm9fb2ZfdGlja2V0c30gdGlja2V0c1xyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0cnVuY2F0ZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLmdyb3VwX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtbC0wIHNtOm1sLWF1dG8gdy1mdWxsIHNtOnctYXV0b1wiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgdGV4dC1jZW50ZXIgbWluLXctWzEwMHB4XVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXZpb2xldC01MDAgZm9udC1tZWRpdW1cIj5QaG9uZTwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtdmlvbGV0LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxBY3Rpb25Ecm9wZG93biBlbnJvbGw9e2Vucm9sbH0gLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1zbGF0ZS01MCB0by1ibHVlLTUwLzQwIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgcHgtNCBweS0zXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IHRleHQteHNcIj5cclxuLy8gICAgICAgICAgICAgICB7ZW5yb2xsLnJlbWFyayAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgZmxleC0xIG1pbi13LVsyMDBweF1cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4LXNocmluay0wIG10LTAuNVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFJlbWFyazpcclxuLy8gICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwucmVtYXJrfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIHtlbnJvbGwucmVmZXJyZWRfYnkgJiYgZW5yb2xsLnJlZmVycmVkX2J5ICE9PSBcIk4vQVwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy13aGl0ZSByb3VuZGVkLWZ1bGwgcHgtMyBweS0xLjUgYm9yZGVyIGJvcmRlci1pbmRpZ28tMTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmRpZ28tNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQ6IHtlbnJvbGwucmVmZXJyZWRfYnl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAge2Vucm9sbC5mb2xsb3dfdXBfZGF0ZSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctd2hpdGUgcm91bmRlZC1mdWxsIHB4LTMgcHktMS41IGJvcmRlciBib3JkZXItcHVycGxlLTEwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZD1cIk04IDdWM204IDRWM20tOSA4aDEwTTUgMjFoMTRhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJ6XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS03MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLmZvbGxvd191cF9kYXRlfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIG1sLWF1dG9cIj5cclxuLy8gICAgICAgICAgICAgICAgIEVucm9sbGVkOiB7ZW5yb2xsLmVucm9sbG1lbnRfZGF0ZX1cclxuLy8gICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICk7XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgcmV0dXJuIChcclxuLy8gICAgICAgPGRpdlxyXG4vLyAgICAgICAgIGtleT17ZW5yb2xsLl9pZH1cclxuLy8gICAgICAgICBjbGFzc05hbWU9XCJncm91cCBiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1sZyBob3Zlcjpib3JkZXItZ3JheS0zMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlblwiXHJcbi8vICAgICAgID5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGdhcC00IHAtNFwiPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB3LWZ1bGwgc206dy1hdXRvXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1hbWJlci03MDAgZm9udC1ib2xkIHRleHQtc20gZmxleC1zaHJpbmstMFwiPlxyXG4vLyAgICAgICAgICAgICAgIHtlbnJvbGwubmFtZT8uY2hhckF0KDApPy50b1VwcGVyQ2FzZSgpfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2Vucm9sbC5uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWFtYmVyLTYwMC8yMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBQZW5kaW5nXHJcbi8vICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRydW5jYXRlXCI+XHJcbi8vICAgICAgICAgICAgICAgICB7ZW5yb2xsLmdyb3VwX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWwtMCBzbTptbC1hdXRvIHctZnVsbCBzbTp3LWF1dG9cIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQtY2VudGVyIG1pbi13LVsxMDBweF1cIj5cclxuLy8gICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYW1iZXItNTAwIGZvbnQtbWVkaXVtXCI+UGhvbmU8L3A+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1hbWJlci05MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgIHtlbnJvbGwucGhvbmVfbnVtYmVyfVxyXG4vLyAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQtY2VudGVyIG1pbi13LVs5MHB4XSBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+RW5yb2xsZWQ8L3A+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAge2Vucm9sbC5lbnJvbGxtZW50X2RhdGV9XHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCI+XHJcbi8vICAgICAgICAgICAgICAgPEFjdGlvbkRyb3Bkb3duIGVucm9sbD17ZW5yb2xsfSAvPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgICk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gU2ltcGxlIFBhZ2luYXRpb25cclxuLy8gICBjb25zdCBTaW1wbGVQYWdpbmF0aW9uID0gKHsgY3VycmVudFBhZ2UsIHRvdGFsUGFnZXMsIG9uUGFnZUNoYW5nZSB9KSA9PiB7XHJcbi8vICAgICBpZiAodG90YWxQYWdlcyA8PSAxKSByZXR1cm4gbnVsbDtcclxuLy8gICAgIGNvbnN0IHBhZ2VzID0gW107XHJcbi8vICAgICBjb25zdCBtYXggPSA1O1xyXG4vLyAgICAgcGFnZXMucHVzaCgxKTtcclxuLy8gICAgIGlmICh0b3RhbFBhZ2VzID4gbWF4KSB7XHJcbi8vICAgICAgIGlmIChjdXJyZW50UGFnZSA+IDMpIHBhZ2VzLnB1c2goXCIuLi5cIik7XHJcbi8vICAgICAgIGZvciAoXHJcbi8vICAgICAgICAgbGV0IGkgPSBNYXRoLm1heCgyLCBjdXJyZW50UGFnZSAtIDEpO1xyXG4vLyAgICAgICAgIGkgPD0gTWF0aC5taW4odG90YWxQYWdlcyAtIDEsIGN1cnJlbnRQYWdlICsgMSk7XHJcbi8vICAgICAgICAgaSsrXHJcbi8vICAgICAgICkge1xyXG4vLyAgICAgICAgIGlmIChpICE9PSAxICYmIGkgIT09IHRvdGFsUGFnZXMpIHBhZ2VzLnB1c2goaSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgICAgaWYgKGN1cnJlbnRQYWdlIDwgdG90YWxQYWdlcyAtIDIpIHBhZ2VzLnB1c2goXCIuLi5cIik7XHJcbi8vICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICBmb3IgKGxldCBpID0gMjsgaSA8PSB0b3RhbFBhZ2VzOyBpKyspIHBhZ2VzLnB1c2goaSk7XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAodG90YWxQYWdlcyA+IDEpIHBhZ2VzLnB1c2godG90YWxQYWdlcyk7XHJcblxyXG4vLyAgICAgcmV0dXJuIChcclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IG10LThcIj5cclxuLy8gICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UoY3VycmVudFBhZ2UgLSAxKX1cclxuLy8gICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50UGFnZSA9PT0gMX1cclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JheS01MCBob3ZlcjpzaGFkb3ctc20gZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgdHJhbnNpdGlvbi1hbGxcIlxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIFByZXZcclxuLy8gICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICB7cGFnZXMubWFwKChwYWdlLCBpKSA9PiAoXHJcbi8vICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgIGtleT17aX1cclxuLy8gICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdHlwZW9mIHBhZ2UgPT09IFwibnVtYmVyXCIgJiYgb25QYWdlQ2hhbmdlKHBhZ2UpfVxyXG4vLyAgICAgICAgICAgICBkaXNhYmxlZD17dHlwZW9mIHBhZ2UgIT09IFwibnVtYmVyXCJ9XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctMTAgaC0xMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcclxuLy8gICAgICAgICAgICAgICBwYWdlID09PSBjdXJyZW50UGFnZVxyXG4vLyAgICAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LXZpb2xldC0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgOiB0eXBlb2YgcGFnZSA9PT0gXCJudW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgdGV4dC1ncmF5LTcwMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6c2hhZG93LXNtXCJcclxuLy8gICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS00MDAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBjdXJzb3ItZGVmYXVsdFwiXHJcbi8vICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICB7cGFnZX1cclxuLy8gICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICkpfVxyXG4vLyAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZShjdXJyZW50UGFnZSArIDEpfVxyXG4vLyAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlID09PSB0b3RhbFBhZ2VzfVxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOnNoYWRvdy1zbSBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbFwiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgTmV4dFxyXG4vLyAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgICk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gUmVuZGVyIHVzZXJzIGJhc2VkIG9uIHZpZXcgbW9kZSBhbmQgdGFiXHJcbi8vICAgY29uc3QgcmVuZGVyRW5yb2xscyA9ICgpID0+IHtcclxuLy8gICAgIGlmIChpc0RhdGFUYWJsZUxvYWRpbmcpIHtcclxuLy8gICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuLy8gICAgICAgICAgIGlzTG9hZGluZz17aXNEYXRhVGFibGVMb2FkaW5nfVxyXG4vLyAgICAgICAgICAgZmFpbHVyZT17ZmFsc2V9XHJcbi8vICAgICAgICAgICBkYXRhPVwiRW5yb2xsbWVudCBEYXRhXCJcclxuLy8gICAgICAgICAvPlxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGNvbnN0IHRhYkZpbHRlcmVkRW5yb2xscyA9IGdldFRhYkZpbHRlcmVkRW5yb2xscygpO1xyXG4vLyAgICAgY29uc3QgdGFiSW5kZXhPZkxhc3RJdGVtID0gY3VycmVudFBhZ2UgKiBpdGVtc1BlclBhZ2U7XHJcbi8vICAgICBjb25zdCB0YWJJbmRleE9mRmlyc3RJdGVtID0gdGFiSW5kZXhPZkxhc3RJdGVtIC0gaXRlbXNQZXJQYWdlO1xyXG4vLyAgICAgY29uc3QgdGFiQ3VycmVudEl0ZW1zID0gdGFiRmlsdGVyZWRFbnJvbGxzLnNsaWNlKFxyXG4vLyAgICAgICB0YWJJbmRleE9mRmlyc3RJdGVtLFxyXG4vLyAgICAgICB0YWJJbmRleE9mTGFzdEl0ZW0sXHJcbi8vICAgICApO1xyXG4vLyAgICAgY29uc3QgdGFiVG90YWxQYWdlcyA9IE1hdGguY2VpbCh0YWJGaWx0ZXJlZEVucm9sbHMubGVuZ3RoIC8gaXRlbXNQZXJQYWdlKTtcclxuXHJcbi8vICAgICBpZiAoIXRhYkZpbHRlcmVkRW5yb2xscy5sZW5ndGgpIHtcclxuLy8gICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLWZ1bGwgcHktMjAgYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXNtIHRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS0zMDAgbXgtYXV0byBtYi00XCI+XHJcbi8vICAgICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgbXgtYXV0b1wiXHJcbi8vICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxLjVcIlxyXG4vLyAgICAgICAgICAgICAgICAgZD1cIk0xNyAyMGg1di0yYTMgMyAwIDAwLTUuMzU2LTEuODU3TTE3IDIwSDdtMTAgMHYtMmMwLS42NTYtLjEyNi0xLjI4My0uMzU2LTEuODU3TTcgMjBIMnYtMmEzIDMgMCAwMTUuMzU2LTEuODU3TTcgMjB2LTJjMC0uNjU2LjEyNi0xLjI4My4zNTYtMS44NTdtMCAwYTUuMDAyIDUuMDAyIDAgMDE5LjI4OCAwTTE1IDExYTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHptNiAyYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiXHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwXCI+XHJcbi8vICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiXHJcbi8vICAgICAgICAgICAgICAgPyBcIk5vIHBlbmRpbmcgZW5yb2xsbWVudHMgZm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgIDogXCJObyBjb250YWN0ZWQgZW5yb2xsbWVudHMgZm91bmRcIn1cclxuLy8gICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiXHJcbi8vICAgICAgICAgICAgICAgPyBcIkFsbCBlbnJvbGxtZW50cyBoYXZlIGJlZW4gY29udGFjdGVkXCJcclxuLy8gICAgICAgICAgICAgICA6IFwiVHJ5IHN3aXRjaGluZyB0byB0aGUgUGVuZGluZyB0YWIgb3IgYWRqdXN0IHlvdXIgc2VhcmNoXCJ9XHJcbi8vICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICk7XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgaWYgKHZpZXdNb2RlID09PSBcImdyaWRcIikge1xyXG4vLyAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4vLyAgICAgICAgICAge3RhYkN1cnJlbnRJdGVtcy5tYXAocmVuZGVyRW5yb2xsbWVudENhcmQpfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGlmICh2aWV3TW9kZSA9PT0gXCJsaXN0XCIpIHtcclxuLy8gICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4vLyAgICAgICAgICAge3RhYkN1cnJlbnRJdGVtcy5tYXAoKGUpID0+IChcclxuLy8gICAgICAgICAgICAgPEVucm9sbFJvdyBrZXk9e2UuaWR9IGVucm9sbD17ZX0gLz5cclxuLy8gICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIC8vIFRhYmxlIHZpZXcgLSBTdGF0dXMgdXBkYXRlIG5vdCBhZGRlZCBpbiB0YWJsZVxyXG4vLyAgICAgcmV0dXJuIChcclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc2hhZG93LXNtIGJnLXdoaXRlXCI+XHJcbi8vICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbi8vICAgICAgICAgICBkYXRhPXtUYWJsZUVucm9sbHMuZmlsdGVyKChlKSA9PlxyXG4vLyAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCJcclxuLy8gICAgICAgICAgICAgICA/IGUuc3RhdHVzICYmIGUuc3RhdHVzICE9PSBcIk5vdCBDb250YWN0ZWRcIlxyXG4vLyAgICAgICAgICAgICAgIDogIWUuc3RhdHVzIHx8IGUuc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIixcclxuLy8gICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4vLyAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiTW9iaWxlQXBwRW5yb2xsbWVudHNcIlxyXG4vLyAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIk1vYmlsZUFwcEVucm9sbG1lbnRzLmNzdlwiXHJcbi8vICAgICAgICAgLz5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApO1xyXG4vLyAgIH07XHJcblxyXG4vLyBjb25zdCBoYW5kbGVFbnJvbGxDbGljayA9IChpdGVtKSA9PiB7XHJcbi8vICAgY29uc29sZS5sb2coXCI9PT0gaGFuZGxlRW5yb2xsQ2xpY2sgY2FsbGVkIHdpdGggaXRlbSA9PT1cIiwgaXRlbSk7XHJcblxyXG4vLyAgIC8vIFNldCB0aGUgY3VycmVudCBncm91cCBmb3IgdGhlIGVucm9sbG1lbnRcclxuLy8gICBzZXRDdXJyZW50R3JvdXAoaXRlbSk7XHJcblxyXG4vLyAgIC8vIOKchSBFeHRyYWN0IElEcyBmcm9tIG5lc3RlZCBvYmplY3RzIHdpdGggcHJvcGVyIGZhbGxiYWNrc1xyXG4vLyAgIGNvbnN0IHVzZXJJZCA9IGl0ZW0udXNlcl9pZD8uX2lkIHx8IGl0ZW0udXNlcl9pZD8uaWQgfHwgXCJcIjtcclxuLy8gICBjb25zdCBncm91cElkID0gaXRlbS5ncm91cF9pZD8uX2lkIHx8IGl0ZW0uZ3JvdXBfaWQ/LmlkIHx8IFwiXCI7XHJcbi8vICAgY29uc3QgcmVmZXJyZWRDdXN0b21lcklkID0gaXRlbS5yZWZlcnJlZF9jdXN0b21lcj8uX2lkIHx8IGl0ZW0ucmVmZXJyZWRfY3VzdG9tZXI/LmlkIHx8IFwiXCI7XHJcbi8vICAgY29uc3QgcmVmZXJyZWRMZWFkSWQgPSBpdGVtLnJlZmVycmVkX2xlYWQ/Ll9pZCB8fCBpdGVtLnJlZmVycmVkX2xlYWQ/LmlkIHx8IFwiXCI7XHJcbi8vICAgY29uc3QgYWdlbnRJZCA9IGl0ZW0uYWdlbnQ/Ll9pZCB8fCBpdGVtLmFnZW50Py5pZCB8fCBcIlwiO1xyXG5cclxuLy8gICBjb25zb2xlLmxvZyhcIkV4dHJhY3RlZCBJRHM6XCIsIHtcclxuLy8gICAgIHVzZXJJZCxcclxuLy8gICAgIGdyb3VwSWQsXHJcbi8vICAgICByZWZlcnJlZEN1c3RvbWVySWQsXHJcbi8vICAgICByZWZlcnJlZExlYWRJZCxcclxuLy8gICAgIGFnZW50SWRcclxuLy8gICB9KTtcclxuXHJcbi8vICAgLy8g4pyFIFNldCBmb3JtIGRhdGEgd2l0aCBhbGwgYXZhaWxhYmxlIHZhbHVlc1xyXG4vLyAgIHNldEZvcm1EYXRhKHtcclxuLy8gICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuLy8gICAgIGdyb3VwX2lkOiBncm91cElkLFxyXG4vLyAgICAgcGF5bWVudF90eXBlOiBpdGVtLnBheW1lbnRfdHlwZSB8fCBcIlwiLFxyXG4vLyAgICAgcmVmZXJyZWRfdHlwZTogaXRlbS5yZWZlcnJlZF90eXBlIHx8IFwiXCIsXHJcbi8vICAgICBjaGl0X2Fza2luZ19tb250aDogaXRlbS5jaGl0X2Fza2luZ19tb250aCB8fCBcIlwiLFxyXG4vLyAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IHJlZmVycmVkQ3VzdG9tZXJJZCxcclxuLy8gICAgIHJlZmVycmVkX2xlYWQ6IHJlZmVycmVkTGVhZElkLFxyXG4vLyAgICAgYWdlbnQ6IGFnZW50SWQsXHJcbi8vICAgICBub19vZl90aWNrZXRzOiBpdGVtLm5vX29mX3RpY2tldHMgfHwgMSxcclxuLy8gICB9KTtcclxuXHJcbi8vICAgc2V0RW5yb2xsbWVudFN0ZXAoXCJ2ZXJpZnlcIik7XHJcbi8vICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4vLyB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4vLyAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuLy8gICAgIGNvbnN0IHtcclxuLy8gICAgICAgbm9fb2ZfdGlja2V0cyxcclxuLy8gICAgICAgZ3JvdXBfaWQsXHJcbi8vICAgICAgIHVzZXJfaWQsXHJcbi8vICAgICAgIHBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgcmVmZXJyZWRfY3VzdG9tZXIsXHJcbi8vICAgICAgIHJlZmVycmVkX3R5cGUsXHJcbi8vICAgICAgIGFnZW50LFxyXG4vLyAgICAgICByZWZlcnJlZF9sZWFkLFxyXG4vLyAgICAgICBjaGl0X2Fza2luZ19tb250aCxcclxuLy8gICAgIH0gPSBmb3JtRGF0YTtcclxuXHJcbi8vICAgICBjb25zdCB0aWNrZXRzQ291bnQgPSBwYXJzZUludChub19vZl90aWNrZXRzIHx8IDEsIDEwKTtcclxuLy8gICAgIGNvbnN0IHRpY2tldEVudHJpZXMgPSBhdmFpbGFibGVUaWNrZXRzQWRkXHJcbi8vICAgICAgIC5zbGljZSgwLCB0aWNrZXRzQ291bnQpXHJcbi8vICAgICAgIC5tYXAoKHRpY2tldE51bWJlcikgPT4gKHtcclxuLy8gICAgICAgICBncm91cF9pZCxcclxuLy8gICAgICAgICB1c2VyX2lkLFxyXG4vLyAgICAgICAgIHBheW1lbnRfdHlwZSxcclxuLy8gICAgICAgICByZWZlcnJlZF90eXBlLFxyXG4vLyAgICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBmb3JtRGF0YS5jaGl0X2Fza2luZ19tb250aCxcclxuLy8gICAgICAgICByZWZlcnJlZF9jdXN0b21lcixcclxuLy8gICAgICAgICByZWZlcnJlZF9sZWFkLFxyXG4vLyAgICAgICAgIGFnZW50LFxyXG4vLyAgICAgICAgIG5vX29mX3RpY2tldHM6IHRpY2tldHNDb3VudCxcclxuLy8gICAgICAgICB0aWNrZXRzOiB0aWNrZXROdW1iZXIsXHJcbi8vICAgICAgIH0pKTtcclxuXHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICBmb3IgKGNvbnN0IHRpY2tldEVudHJ5IG9mIHRpY2tldEVudHJpZXMpIHtcclxuLy8gICAgICAgICBhd2FpdCBhcGkucG9zdChcIi9lbnJvbGwvYWRkLWVucm9sbFwiLCB0aWNrZXRFbnRyeSwge1xyXG4vLyAgICAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBpZiAoY3VycmVudEdyb3VwPy5faWQpIHtcclxuLy8gICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKFxyXG4vLyAgICAgICAgICAgYC9tb2JpbGUtYXBwLWVucm9sbC9kZWxldGUtbW9iaWxlLWFwcC1lbnJvbGwvJHtjdXJyZW50R3JvdXAuX2lkfWAsXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGRhdGE6IHsgZGVsZXRlZF9ieTogYWRtaW4sIGRlbGV0ZWRfYXQ6IG5ldyBEYXRlKCkgfSxcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgKTtcclxuLy8gICAgICAgfVxyXG5cclxuLy8gICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4vLyAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJVc2VyIEVucm9sbGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4vLyAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbi8vICAgICAgIHNldEZvcm1EYXRhKHtcclxuLy8gICAgICAgICBncm91cF9pZDogXCJcIixcclxuLy8gICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4vLyAgICAgICAgIG5vX29mX3RpY2tldHM6IFwiXCIsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfdHlwZTogXCJcIixcclxuLy8gICAgICAgICBwYXltZW50X3R5cGU6IFwiXCIsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbi8vICAgICAgICAgYWdlbnQ6IFwiXCIsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfbGVhZDogXCJcIixcclxuLy8gICAgICAgICBjaGl0X2Fza2luZ19tb250aDogXCJcIixcclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBmZXRjaEFsbEVucm9sbG1lbnREYXRhKCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZW5yb2xsaW5nIHVzZXI6XCIsIGVycm9yKTtcclxuLy8gICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4vLyAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJFbnJvbGxtZW50IGZhaWxlZFwiLFxyXG4vLyAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuLy8gICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaFVzZXJzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hBZ2VudHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1hZ2VudFwiKTtcclxuLy8gICAgICAgICBzZXRBZ2VudHMocmVzcG9uc2UuZGF0YSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggTGVhZHNcIiwgZXJyKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfTtcclxuLy8gICAgIGZldGNoQWdlbnRzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hMZWFkcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvbGVhZC9nZXQtbGVhZFwiKTtcclxuLy8gICAgICAgICBzZXRMZWFkcyhyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBMZWFkc1wiLCBlcnIpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hMZWFkcygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlVmVyaWZ5ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgY29uc3Qge1xyXG4vLyAgICAgICB1c2VyX2lkLFxyXG4vLyAgICAgICBncm91cF9pZCxcclxuLy8gICAgICAgYWdlbnQsXHJcbi8vICAgICAgIHJlZmVycmVkX2N1c3RvbWVyLFxyXG4vLyAgICAgICByZWZlcnJlZF9sZWFkLFxyXG4vLyAgICAgICByZWZlcnJlZF90eXBlLFxyXG4vLyAgICAgfSA9IGZvcm1EYXRhO1xyXG5cclxuLy8gICAgIGlmICghdXNlcl9pZCB8fCAhZ3JvdXBfaWQpIHtcclxuLy8gICAgICAgbm90aWZpY2F0aW9uLndhcm5pbmcoe1xyXG4vLyAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBib3RoIEdyb3VwIGFuZCBDdXN0b21lciBiZWZvcmUgdmVyaWZ5aW5nLlwiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC9nZXQtZW5yb2xsLWNoZWNrYCwge1xyXG4vLyAgICAgICAgIHBhcmFtczogeyB1c2VyX2lkLCBncm91cF9pZCB9LFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHNlbGVjdGVkVXNlciA9IHVzZXJzLmZpbmQoKHUpID0+IHUuX2lkID09PSB1c2VyX2lkKTtcclxuLy8gICAgICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGdyb3Vwcy5maW5kKChnKSA9PiBnLl9pZCA9PT0gZ3JvdXBfaWQpO1xyXG4vLyAgICAgICBjb25zdCBzZWxlY3RlZEFnZW50ID0gYWdlbnRzLmZpbmQoKGEpID0+IGEuX2lkID09PSBhZ2VudCk7XHJcbi8vICAgICAgIGNvbnN0IHNlbGVjdGVkUmVmZXJyZWRDdXN0b21lciA9IHVzZXJzLmZpbmQoXHJcbi8vICAgICAgICAgKHUpID0+IHUuX2lkID09PSByZWZlcnJlZF9jdXN0b21lcixcclxuLy8gICAgICAgKTtcclxuLy8gICAgICAgY29uc3Qgc2VsZWN0ZWRSZWZlcnJlZExlYWQgPSBsZWFkcz8uZmluZD8uKFxyXG4vLyAgICAgICAgIChsKSA9PiBsLl9pZCA9PT0gcmVmZXJyZWRfbGVhZCxcclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIGlmIChyZXNwb25zZT8uZGF0YSkge1xyXG4vLyAgICAgICAgIGNvbnN0IGFnZW50TmFtZSA9XHJcbi8vICAgICAgICAgICB0eXBlb2YgcmVzcG9uc2UuZGF0YS5hZ2VudCA9PT0gXCJvYmplY3RcIlxyXG4vLyAgICAgICAgICAgICA/IHJlc3BvbnNlLmRhdGEuYWdlbnQ/Lm5hbWVcclxuLy8gICAgICAgICAgICAgOiBudWxsO1xyXG4vLyAgICAgICAgIGNvbnN0IHJlZmVycmVkQ3VzdG9tZXJOYW1lID1cclxuLy8gICAgICAgICAgIHR5cGVvZiByZXNwb25zZS5kYXRhLnJlZmVycmVkX2N1c3RvbWVyID09PSBcIm9iamVjdFwiXHJcbi8vICAgICAgICAgICAgID8gcmVzcG9uc2UuZGF0YS5yZWZlcnJlZF9jdXN0b21lcj8uZnVsbF9uYW1lXHJcbi8vICAgICAgICAgICAgIDogbnVsbDtcclxuLy8gICAgICAgICBjb25zdCByZWZlcnJlZExlYWROYW1lID1cclxuLy8gICAgICAgICAgIHR5cGVvZiByZXNwb25zZS5kYXRhLnJlZmVycmVkX2xlYWQgPT09IFwib2JqZWN0XCJcclxuLy8gICAgICAgICAgICAgPyByZXNwb25zZS5kYXRhLnJlZmVycmVkX2xlYWQ/LmxlYWRfbmFtZVxyXG4vLyAgICAgICAgICAgICA6IG51bGw7XHJcblxyXG4vLyAgICAgICAgIGNvbnN0IHJlZmVycmVkSW5mb1BhcnRzID0gW107XHJcblxyXG4vLyAgICAgICAgIGlmIChhZ2VudE5hbWUpXHJcbi8vICAgICAgICAgICByZWZlcnJlZEluZm9QYXJ0cy5wdXNoKFxyXG4vLyAgICAgICAgICAgICBgIEFscmVhZHkgcmVmZXJyZWQgYnkgQWdlbnQgTmFtZTogJHthZ2VudE5hbWV9YCxcclxuLy8gICAgICAgICAgICk7XHJcbi8vICAgICAgICAgaWYgKHJlZmVycmVkQ3VzdG9tZXJOYW1lKVxyXG4vLyAgICAgICAgICAgcmVmZXJyZWRJbmZvUGFydHMucHVzaChcclxuLy8gICAgICAgICAgICAgYCBBbHJlYWR5IHJlZmVycmVkIGJ5IEN1c3RvbWVyIE5hbWU6ICR7cmVmZXJyZWRDdXN0b21lck5hbWV9YCxcclxuLy8gICAgICAgICAgICk7XHJcbi8vICAgICAgICAgaWYgKHJlZmVycmVkTGVhZE5hbWUpXHJcbi8vICAgICAgICAgICByZWZlcnJlZEluZm9QYXJ0cy5wdXNoKFxyXG4vLyAgICAgICAgICAgICBgIEFscmVhZHkgcmVmZXJyZWQgYnkgTGVhZCBOYW1lOiAke3JlZmVycmVkTGVhZE5hbWV9YCxcclxuLy8gICAgICAgICAgICk7XHJcbi8vICAgICAgICAgaWYgKHJlZmVycmVkSW5mb1BhcnRzLmxlbmd0aCA9PT0gMClcclxuLy8gICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXCJFbnJvbGxtZW50IGV4aXN0cyB3aXRoIG5vIHJlZmVycmFsIGluZm8uXCIpO1xyXG5cclxuLy8gICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICBub19vZl90aWNrZXRzOiByZXNwb25zZT8uZGF0YT8ubm9fb2ZfdGlja2V0cyA/PyBwcmV2Lm5vX29mX3RpY2tldHMsXHJcbi8vICAgICAgICAgICBwYXltZW50X3R5cGU6IHJlc3BvbnNlPy5kYXRhPy5wYXltZW50X3R5cGUgPz8gcHJldi5wYXltZW50X3R5cGUsXHJcbi8vICAgICAgICAgICByZWZlcnJlZF9jdXN0b21lcjpcclxuLy8gICAgICAgICAgICAgcmVzcG9uc2U/LmRhdGE/LnJlZmVycmVkX2N1c3RvbWVyID8/IHByZXYucmVmZXJyZWRfY3VzdG9tZXIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZF9sZWFkOiByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfbGVhZCA/PyBwcmV2LnJlZmVycmVkX2xlYWQsXHJcbi8vICAgICAgICAgICByZWZlcnJlZF90eXBlOlxyXG4vLyAgICAgICAgICAgICBwcmV2LnJlZmVycmVkX3R5cGUgfHxcclxuLy8gICAgICAgICAgICAgcmVzcG9uc2U/LmRhdGE/LnJlZmVycmVkX3R5cGUgfHxcclxuLy8gICAgICAgICAgICAgKHJlc3BvbnNlLmRhdGE/LmFnZW50XHJcbi8vICAgICAgICAgICAgICAgPyBcIkFnZW50XCJcclxuLy8gICAgICAgICAgICAgICA6IHJlc3BvbnNlLmRhdGE/LnJlZmVycmVkX2N1c3RvbWVyXHJcbi8vICAgICAgICAgICAgICAgICA/IFwiQ3VzdG9tZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgOiByZXNwb25zZS5kYXRhPy5yZWZlcnJlZF9sZWFkXHJcbi8vICAgICAgICAgICAgICAgICAgID8gXCJMZWFkc1wiXHJcbi8vICAgICAgICAgICAgICAgICAgIDogXCJcIiksXHJcbi8vICAgICAgICAgfSkpO1xyXG5cclxuLy8gICAgICAgICBsZXQgc2VsZWN0ZWRCeSA9IFwiVW5rbm93blwiO1xyXG4vLyAgICAgICAgIGlmIChyZWZlcnJlZF90eXBlID09PSBcIkFnZW50XCIpXHJcbi8vICAgICAgICAgICBzZWxlY3RlZEJ5ID0gc2VsZWN0ZWRBZ2VudD8ubmFtZSB8fCBcIlVua25vd24gQWdlbnRcIjtcclxuLy8gICAgICAgICBlbHNlIGlmIChyZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIpXHJcbi8vICAgICAgICAgICBzZWxlY3RlZEJ5ID1cclxuLy8gICAgICAgICAgICAgc2VsZWN0ZWRSZWZlcnJlZEN1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCJVbmtub3duIEN1c3RvbWVyXCI7XHJcbi8vICAgICAgICAgZWxzZSBpZiAocmVmZXJyZWRfdHlwZSA9PT0gXCJMZWFkc1wiKVxyXG4vLyAgICAgICAgICAgc2VsZWN0ZWRCeSA9IHNlbGVjdGVkUmVmZXJyZWRMZWFkPy5sZWFkX25hbWUgfHwgXCJVbmtub3duIExlYWRcIjtcclxuXHJcbi8vICAgICAgICAgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnQodHJ1ZSk7XHJcbi8vICAgICAgICAgc2V0RW5yb2xsbWVudFN0ZXAoXCJjb250aW51ZVwiKTtcclxuXHJcbi8vICAgICAgICAgbm90aWZpY2F0aW9uLndhcm5pbmcoe1xyXG4vLyAgICAgICAgICAgbWVzc2FnZTogKFxyXG4vLyAgICAgICAgICAgICA8c3BhblxyXG4vLyAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbi8vICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuLy8gICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEuMjVyZW1cIixcclxuLy8gICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogXCIxMHB4XCIsXHJcbi8vICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIEN1c3RvbWVyIE5hbWU6IFwie3NlbGVjdGVkVXNlcj8uZnVsbF9uYW1lfVwiXHJcbi8vICAgICAgICAgICAgICAgPGJyIC8+XHJcbi8vICAgICAgICAgICAgICAgPGhyIHN0eWxlPXt7IG1hcmdpbjogXCIxMHB4IDBcIiwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCAjY2NjXCIgfX0gLz5cclxuLy8gICAgICAgICAgICAgICBHcm91cCBOYW1lOiBcIntzZWxlY3RlZEdyb3VwPy5ncm91cF9uYW1lfVwiXHJcbi8vICAgICAgICAgICAgICAgPGJyIC8+XHJcbi8vICAgICAgICAgICAgICAgPGhyIHN0eWxlPXt7IG1hcmdpbjogXCIxMHB4IDBcIiwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCAjY2NjXCIgfX0gLz5cclxuLy8gICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgIGRlc2NyaXB0aW9uOiAoXHJcbi8vICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcIjEuMjVyZW1cIiB9fT5cclxuLy8gICAgICAgICAgICAgICB7cmVmZXJyZWRJbmZvUGFydHMubWFwKChwYXJ0LCBpbmRleCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpbmRleH0+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtwYXJ0fVxyXG4vLyAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPGhyXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luOiBcIjEwcHggMFwiLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNjY2NcIiB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICksXHJcbi8vICAgICAgICAgICBkdXJhdGlvbjogMzAsXHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgICAgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnQodHJ1ZSk7XHJcbi8vICAgICAgICAgc2V0SXNWZXJpZmllZCh0cnVlKTtcclxuLy8gICAgICAgICBzZXRFbnJvbGxtZW50U3RlcChcImNvbnRpbnVlXCIpO1xyXG4vLyAgICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICAgIHNldElzRXhpc3RpbmdFbnJvbGxtZW50KGZhbHNlKTtcclxuLy8gICAgICAgICBzZXRJc1ZlcmlmaWVkKHRydWUpO1xyXG4vLyAgICAgICAgIHNldEVucm9sbG1lbnRTdGVwKFwiY29udGludWVcIik7XHJcblxyXG4vLyAgICAgICAgIG5vdGlmaWNhdGlvbi5zdWNjZXNzKHtcclxuLy8gICAgICAgICAgIG1lc3NhZ2U6IGBFbGlnaWJsZSBmb3IgRW5yb2xsbWVudGAsXHJcbi8vICAgICAgICAgICBkZXNjcmlwdGlvbjogYFVzZXIgXCIke3NlbGVjdGVkVXNlcj8uZnVsbF9uYW1lfVwiIGNhbiBiZSBlbnJvbGxlZCBpbiBcIiR7c2VsZWN0ZWRHcm91cD8uZ3JvdXBfbmFtZX1cIi5gLFxyXG4vLyAgICAgICAgICAgZHVyYXRpb246IDYsXHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiVmVyaWZpY2F0aW9uIGVycm9yOlwiLCBlcnIpO1xyXG4vLyAgICAgICBub3RpZmljYXRpb24uZXJyb3Ioe1xyXG4vLyAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3IgY2hlY2tpbmcgZW5yb2xsbWVudFwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVNdWx0aVN0ZXAgPSBhc3luYyAoZSkgPT4ge1xyXG4vLyAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuLy8gICAgIGlmIChlbnJvbGxtZW50U3RlcCA9PT0gXCJ2ZXJpZnlcIikge1xyXG4vLyAgICAgICBhd2FpdCBoYW5kbGVWZXJpZnkoKTtcclxuLy8gICAgIH0gZWxzZSBpZiAoZW5yb2xsbWVudFN0ZXAgPT09IFwiY29udGludWVcIikge1xyXG4vLyAgICAgICBzZXRFbnJvbGxtZW50U3RlcChcInN1Ym1pdFwiKTtcclxuLy8gICAgIH0gZWxzZSBpZiAoZW5yb2xsbWVudFN0ZXAgPT09IFwic3VibWl0XCIpIHtcclxuLy8gICAgICAgaGFuZGxlU3VibWl0KGUpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbi8vICAgICAgIC4uLnByZXZEYXRhLFxyXG4vLyAgICAgICBbZmllbGRdOiB2YWx1ZSxcclxuLy8gICAgIH0pKTtcclxuXHJcbi8vICAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7XHJcbi8vICAgICAgIC4uLnByZXZFcnJvcnMsXHJcbi8vICAgICAgIFtmaWVsZF06IFwiXCIsXHJcbi8vICAgICB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2RGF0YSxcclxuLy8gICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbi8vICAgICB9KSk7XHJcblxyXG4vLyAgICAgc2V0RXJyb3JzKHsgLi4uZXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBpZiAoZm9ybURhdGEuZ3JvdXBfaWQpIHtcclxuLy8gICAgICAgY29uc3QgZmV0Y2hUaWNrZXRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4vLyAgICAgICAgICAgICBgL2Vucm9sbC9nZXQtbmV4dC10aWNrZXRzLyR7Zm9ybURhdGEuZ3JvdXBfaWR9YCxcclxuLy8gICAgICAgICAgICk7XHJcbi8vICAgICAgICAgICBzZXRBdmFpbGFibGVUaWNrZXRzQWRkKHJlc3BvbnNlLmRhdGEuYXZhaWxhYmxlVGlja2V0cyB8fCBbXSk7XHJcbi8vICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBuZXh0IHRpY2tldHM6XCIsIGVycm9yKTtcclxuLy8gICAgICAgICAgIHNldEF2YWlsYWJsZVRpY2tldHNBZGQoW10pO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfTtcclxuLy8gICAgICAgZmV0Y2hUaWNrZXRzKCk7XHJcbi8vICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICBzZXRBdmFpbGFibGVUaWNrZXRzQWRkKFtdKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbZm9ybURhdGEuZ3JvdXBfaWRdKTtcclxuXHJcbi8vICAgY29uc3QgY29sdW1ucyA9IFtcclxuLy8gICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbi8vICAgXTtcclxuLy8gICBpZiAoYWxsRW5yb2xsVXJsKSB7XHJcbi8vICAgICBjb2x1bW5zLnB1c2goeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiRW5yb2xsZWQgR3JvdXBcIiB9KTtcclxuLy8gICB9XHJcbi8vICAgY29sdW1ucy5wdXNoKFxyXG4vLyAgICAgeyBrZXk6IFwibW9iaWxlX2Vucm9sbF9jb2RlXCIsIGhlYWRlcjogXCJNb2JpbGUgRW5yb2xsIENvZGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJlbnJvbGxtZW50X2RhdGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGF0ZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJjaGl0X2Fza2luZ19tb250aFwiLCBoZWFkZXI6IFwiQ2hpdCBBc2tpbmcgTW9udGhcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVmZXJyZWRfYnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuLy8gICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuLy8gICApO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbi8vICAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbi8vICAgICAgIC4uLnByZXZEYXRhLFxyXG4vLyAgICAgICBbbmFtZV06IHZhbHVlLFxyXG4vLyAgICAgfSkpO1xyXG4vLyAgICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoeyAuLi5wcmV2RXJyb3JzLCBbbmFtZV06IFwiXCIgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHZhbGlkYXRlID0gKHR5cGUpID0+IHtcclxuLy8gICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4vLyAgICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkRW5yb2xsbWVudFwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuLy8gICAgIGNvbnN0IG5vT2ZUaWNrZXRzID0gdHlwZSA9PT0gXCJhZGRFbnJvbGxtZW50XCIgPyBcIm5vX29mX3RpY2tldHNcIiA6IFwidGlja2V0c1wiO1xyXG4vLyAgICAgaWYgKCFkYXRhLmdyb3VwX2lkLnRyaW0oKSkge1xyXG4vLyAgICAgICBuZXdFcnJvcnMuZ3JvdXBfaWQgPSBcIlBsZWFzZSBzZWxlY3QgYSBncm91cFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgaWYgKCFkYXRhLnVzZXJfaWQpIHtcclxuLy8gICAgICAgbmV3RXJyb3JzLnVzZXJfaWQgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGlmIChhdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aCA+IDApIHtcclxuLy8gICAgICAgaWYgKFxyXG4vLyAgICAgICAgICFkYXRhW25vT2ZUaWNrZXRzXSB8fFxyXG4vLyAgICAgICAgIGRhdGFbbm9PZlRpY2tldHNdIDw9IDAgfHxcclxuLy8gICAgICAgICBpc05hTihkYXRhW25vT2ZUaWNrZXRzXSlcclxuLy8gICAgICAgKSB7XHJcbi8vICAgICAgICAgbmV3RXJyb3JzW25vT2ZUaWNrZXRzXSA9IFwiUGxlYXNlIGVudGVyIG51bWJlciBvZiB0aWNrZXRzXCI7XHJcbi8vICAgICAgIH0gZWxzZSBpZiAoZGF0YVtub09mVGlja2V0c10gPiBhdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aCkge1xyXG4vLyAgICAgICAgIG5ld0Vycm9yc1tub09mVGlja2V0c10gPVxyXG4vLyAgICAgICAgICAgYE1heGltdW0gJHthdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aH0gdGlja2V0cyBhbGxvd2VkYDtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4vLyAgICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuLy8gICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4vLyAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZTdGF0ZSkgPT4gKHtcclxuLy8gICAgICAgLi4ucHJldlN0YXRlLFxyXG4vLyAgICAgICBbbmFtZV06IHZhbHVlLFxyXG4vLyAgICAgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChlbnJvbGxJZCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4vLyAgICAgICAgIGAvbW9iaWxlLWFwcC1lbnJvbGwvZ2V0LW1vYmlsZS1hcHAtZW5yb2xsLWJ5LWlkLyR7ZW5yb2xsSWR9YCxcclxuLy8gICAgICAgKTtcclxuLy8gICAgICAgc2V0Q3VycmVudFVwZGF0ZUdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4vLyAgICAgICBjb25zb2xlLmluZm8ocmVzcG9uc2UuZGF0YT8uYWdlbnQ/Ll9pZCwgXCJ0ZXN0IGN1c3RvbWVyXCIpO1xyXG4vLyAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbi8vICAgICAgICAgZ3JvdXBfaWQ6IHJlc3BvbnNlLmRhdGE/Lmdyb3VwX2lkPy5faWQsXHJcbi8vICAgICAgICAgdXNlcl9pZDogcmVzcG9uc2UuZGF0YT8udXNlcl9pZD8uX2lkLFxyXG4vLyAgICAgICAgIHRpY2tldHM6IHJlc3BvbnNlLmRhdGE/LnRpY2tldHMsXHJcbi8vICAgICAgICAgcGF5bWVudF90eXBlOiByZXNwb25zZS5kYXRhPy5wYXltZW50X3R5cGUsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IHJlc3BvbnNlLmRhdGE/LnJlZmVycmVkX2N1c3RvbWVyPy5faWQsXHJcbi8vICAgICAgICAgYWdlbnQ6IHJlc3BvbnNlLmRhdGE/LmFnZW50Py5faWQsXHJcbi8vICAgICAgICAgcmVmZXJyZWRfbGVhZDogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfbGVhZD8uX2lkLFxyXG4vLyAgICAgICAgIHJlZmVycmVkX3R5cGU6IHJlc3BvbnNlLmRhdGE/LnJlZmVycmVkX3R5cGUsXHJcbi8vICAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IHJlc3BvbnNlLmRhdGE/LmNoaXRfYXNraW5nX21vbnRoIHx8IFwiXCIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudDpcIiwgZXJyb3IpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbi8vICAgICAgICAgYC9tb2JpbGUtYXBwLWVucm9sbC9nZXQtbW9iaWxlLWFwcC1lbnJvbGwtYnktaWQvJHtncm91cElkfWAsXHJcbi8vICAgICAgICk7XHJcbi8vICAgICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuLy8gICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbDpcIiwgZXJyb3IpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZURlbGV0ZUdyb3VwID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgaWYgKGN1cnJlbnRHcm91cCkge1xyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGF3YWl0IGFwaS5kZWxldGUoXHJcbi8vICAgICAgICAgICBgL21vYmlsZS1hcHAtZW5yb2xsL2RlbGV0ZS1tb2JpbGUtYXBwLWVucm9sbC8ke2N1cnJlbnRHcm91cC5faWR9YCxcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgZGF0YTogeyBkZWxldGVkX2J5OiBhZG1pbiwgZGVsZXRlZF9hdDogbmV3IERhdGUoKSB9LFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbi8vICAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4vLyAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuLy8gICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbi8vICAgICAgICAgICBtZXNzYWdlOiBcIkVucm9sbCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4vLyAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgICAgZmV0Y2hBbGxFbnJvbGxtZW50RGF0YSgpO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBncm91cDpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuLy8gICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbi8vICAgICAgICAgYC9tb2JpbGUtYXBwLWVucm9sbC91cGRhdGUtbW9iaWxlLWFwcC1lbnJvbGwvJHtjdXJyZW50VXBkYXRlR3JvdXAuX2lkfWAsXHJcbi8vICAgICAgICAgdXBkYXRlRm9ybURhdGEsXHJcbi8vICAgICAgICk7XHJcbi8vICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcblxyXG4vLyAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbi8vICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIkVucm9sbG1lbnQgVXBkYXRlZCBTdWNjZXNzZnVsbHlcIixcclxuLy8gICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBlbnJvbGw6XCIsIGVycm9yKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPD5cclxuLy8gICAgICAgPGRpdj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICAgIDxOYXZiYXJcclxuLy8gICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbi8vICAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgPFNpZGViYXIgLz5cclxuLy8gICAgICAgICAgIDxDdXN0b21BbGVydFxyXG4vLyAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4vLyAgICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbi8vICAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbi8vICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0Q29uZmlnKChwKSA9PiAoeyAuLi5wLCB2aXNpYmlsaXR5OiBmYWxzZSB9KSl9XHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IGJnLXNsYXRlLTUwIG1pbi1oLXNjcmVlblwiPlxyXG4vLyAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIEhlYWRlciBCYXIgKi99XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC01IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IGxnOml0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIHRyYWNraW5nLXRpZ2h0XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgTW9iaWxlIEFwcCBFbnJvbGxtZW50c1xyXG4vLyAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIE1hbmFnZSBhbmQgdHJhY2sgbW9iaWxlIGVucm9sbG1lbnQgcmVxdWVzdHNcclxuLy8gICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIGxnOnctYXV0b1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctc2xhdGUtMTAwIHJvdW5kZWQteGwgcC0xIGdhcC0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwicGVuZGluZ1wiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHthY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiID8gXCJiZy13aGl0ZSB0ZXh0LXZpb2xldC03MDAgc2hhZG93LXNtXCIgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTgwMFwifWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgUGVuZGluZyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkRW5yb2xscy5maWx0ZXIoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgKGUpID0+IGUuc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIiB8fCAhZS5zdGF0dXMsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwiY29udGFjdGVkXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCAke2FjdGl2ZVRhYiA9PT0gXCJjb250YWN0ZWRcIiA/IFwiYmctd2hpdGUgdGV4dC12aW9sZXQtNzAwIHNoYWRvdy1zbVwiIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS04MDBcIn1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIENvbnRhY3RlZCAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkRW5yb2xscy5maWx0ZXIoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgKGUpID0+IGUuc3RhdHVzICYmIGUuc3RhdHVzICE9PSBcIk5vdCBDb250YWN0ZWRcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGhcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIClcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTEwMCByb3VuZGVkLXhsIHAtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKFwiZ3JpZFwiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7dmlld01vZGUgPT09IFwiZ3JpZFwiID8gXCJiZy13aGl0ZSB0ZXh0LXZpb2xldC03MDAgc2hhZG93LXNtXCIgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTgwMFwifWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPE1kR3JpZFZpZXcgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld01vZGUoXCJsaXN0XCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHt2aWV3TW9kZSA9PT0gXCJsaXN0XCIgPyBcImJnLXdoaXRlIHRleHQtdmlvbGV0LTcwMCBzaGFkb3ctc21cIiA6IFwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktODAwXCJ9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8TWRWaWV3TGlzdCBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZShcInRhYmxlXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHt2aWV3TW9kZSA9PT0gXCJ0YWJsZVwiID8gXCJiZy13aGl0ZSB0ZXh0LXZpb2xldC03MDAgc2hhZG93LXNtXCIgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTgwMFwifWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPE1kT3V0bGluZVRhYmxlUm93cyBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIFNlYXJjaCBCYXIgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC01XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8SW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgbmFtZSwgcGhvbmUgb3IgZ3JvdXBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XHJcbi8vICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gZS50YXJnZXQudmFsdWU7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2V0U2VhcmNoUXVlcnkodmFsKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICBpZiAodmFsID09PSBcIlwiKSB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWFyY2hUZXJtKFwiXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgb25QcmVzc0VudGVyPXsoKSA9PiBzZXRTZWFyY2hUZXJtKHNlYXJjaFF1ZXJ5KX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMCB3LTgwIHJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBpY29uPXs8U2VhcmNoT3V0bGluZWQgLz59XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlYXJjaFRlcm0oc2VhcmNoUXVlcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEwIGJnLXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTcwMCBib3JkZXItdmlvbGV0LTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIFNlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlci1sLTQgYm9yZGVyLWJsdWUtNTAwIHAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgVG90YWwgRW5yb2xsbWVudHNcclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLnRvdGFsRW5yb2xsbWVudHN9XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlci1sLTQgYm9yZGVyLWdyZWVuLTUwMCBwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIFRvdGFsIFRpY2tldHNcclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLnRvdGFsVGlja2V0c31cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyLWwtNCBib3JkZXItcHVycGxlLTUwMCBwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIFVuaXF1ZSBDdXN0b21lcnNcclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLnVuaXF1ZUN1c3RvbWVyc31cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyLWwtNCBib3JkZXItb3JhbmdlLTUwMCBwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIFVuaXF1ZSBHcm91cHNcclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7c3VtbWFyeVN0YXRzLnVuaXF1ZUdyb3Vwc31cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiDimIUgQ09OVEFDVCBTVU1NQVJZIOKAlCBvbmx5IGluIENvbnRhY3RlZCB0YWIgKi99XHJcbi8vICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIgJiYgIWlzRGF0YVRhYmxlTG9hZGluZyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPENvbnRhY3RTdW1tYXJ5RGFzaGJvYXJkIC8+XHJcbi8vICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICB7cmVuZGVyRW5yb2xscygpfVxyXG5cclxuLy8gICAgICAgICAgICAge3ZpZXdNb2RlICE9PSBcInRhYmxlXCIgJiZcclxuLy8gICAgICAgICAgICAgICBnZXRUYWJGaWx0ZXJlZEVucm9sbHMoKS5sZW5ndGggPiBpdGVtc1BlclBhZ2UgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPFNpbXBsZVBhZ2luYXRpb25cclxuLy8gICAgICAgICAgICAgICAgICAgY3VycmVudFBhZ2U9e2N1cnJlbnRQYWdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICB0b3RhbFBhZ2VzPXtNYXRoLmNlaWwoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZ2V0VGFiRmlsdGVyZWRFbnJvbGxzKCkubGVuZ3RoIC8gaXRlbXNQZXJQYWdlLFxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e3NldEN1cnJlbnRQYWdlfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiBBZGQgRW5yb2xsbWVudCBNb2RhbCAtIFVzaW5nIGN1c3RvbSBNb2RhbCBjb21wb25lbnQgKi99XHJcbi8vICAgICAgICAgPE1vZGFsXHJcbi8vICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbH1cclxuLy8gICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuLy8gICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuLy8gICAgICAgICAgIH19XHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuLy8gICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIEFkZCBFbnJvbGxtZW50XHJcbi8vICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbi8vICAgICAgICAgICAgICAgey8qIEFsbCBleGlzdGluZyBmb3JtIGZpZWxkcyAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgR3JvdXAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggR3JvdXBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfaWQgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZ3JvdXBfaWRcIiwgdmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2lkICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZ3JvdXBfaWR9PC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuLy8gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuLy8gICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICBuYW1lPVwidXNlcl9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8udXNlcl9pZCB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJ1c2VyX2lkXCIsIHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9IHx7XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5waG9uZV9udW1iZXIgPyB1c2VyLnBob25lX251bWJlciA6IFwiTm8gTnVtYmVyXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheW1lbnRfdHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIFNlbGVjdCBQYXltZW50IFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQYXltZW50IFR5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXltZW50X3R5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5wYXltZW50X3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicGF5bWVudF90eXBlXCIsIHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge1tcIkRhaWx5XCIsIFwiV2Vla2x5XCIsIFwiTW9udGhseVwiXS5tYXAoKHBUeXBlKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtwVHlwZX0gdmFsdWU9e3BUeXBlfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtwVHlwZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBDaGl0IEFza2luZyBNb250aFxyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYm9yZGVyIHJvdW5kZWQgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZS50YXJnZXQudmFsdWUsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4vLyAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICBtaW49e2Zvcm1hdFRvWWVhck1vbnRoKGN1cnJlbnRZZWFyLCBjdXJyZW50TW9udGgpfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJyZWZlcnJlZF90eXBlXCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWZlcnJlZCBUeXBlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuLy8gICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfdHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlZmVycmVkX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfdHlwZVwiLCB2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtbXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJTZWxmIEpvaW5pbmdcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFwiTGVhZHNcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBcIk90aGVyc1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBdLm1hcCgocmVmVHlwZSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmVHlwZX0gdmFsdWU9e3JlZlR5cGV9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge3JlZlR5cGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEN1c3RvbWVye1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEN1c3RvbWVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfY3VzdG9tZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucmVmZXJyZWRfY3VzdG9tZXIgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfY3VzdG9tZXJcIiwgdmFsdWUpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfSB8e1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5waG9uZV9udW1iZXIgPyB1c2VyLnBob25lX251bWJlciA6IFwiTm8gTnVtYmVyXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJMZWFkc1wiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIExlYWRze1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIExlYWRzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfbGVhZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9sZWFkIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcInJlZmVycmVkX2xlYWRcIiwgdmFsdWUpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2xlYWRzLm1hcCgobGVhZCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtsZWFkLl9pZH0gdmFsdWU9e2xlYWQuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2xlYWQubGVhZF9uYW1lfSB8IHtsZWFkLmxlYWRfcGhvbmV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJFbXBsb3llZVwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEVtcGxveWVle1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEVtcGxveWVlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWdlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGlmICghb3B0aW9uIHx8ICFvcHRpb24uY2hpbGRyZW4pIHJldHVybiBmYWxzZTtcclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJhZ2VudFwiLCB2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ncm91cF9pZCA/IChcclxuLy8gICAgICAgICAgICAgICAgIGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoID4gMCA/IChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyIG9mIFRpY2tldHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vX29mX3RpY2tldHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5ub19vZl90aWNrZXRzfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGFuZ2UoZSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgTnVtYmVyIG9mIFRpY2tldHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG1heD17YXZhaWxhYmxlVGlja2V0c0FkZC5sZW5ndGh9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubm9fb2ZfdGlja2V0cyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubm9fb2ZfdGlja2V0c31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc20gdGV4dC1ibHVlLTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgT25seSB7YXZhaWxhYmxlVGlja2V0c0FkZC5sZW5ndGh9IHRpY2tldHMgbGVmdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtcmVkLTYwMFwiPkdyb3VwIGlzIEZ1bGw8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXJlZC02MDBcIj48L3A+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBwLTQgbWF4LXctZnVsbCBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBzcGFjZS15LTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwU3F1YXJlIGNvbG9yPVwiZ3JlZW5cIiBjbGFzc05hbWU9XCJ3LTEwIGgtMTBcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt3aGF0c2FwcEVuYWJsZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBjaGVja2VkOnJpbmctMiBjaGVja2VkOnJpbmctZ3JlZW4tNzAwIHJvdW5kZWQtZnVsbCB3LTQgaC00XCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMFwiPlNlbmQgVmlhIFdoYXRzYXBwPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmcgfHxcclxuLy8gICAgICAgICAgICAgICAgICAgICAoZW5yb2xsbWVudFN0ZXAgPT09IFwic3VibWl0XCIgJiZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICghaXNWZXJpZmllZCB8fCBhdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aCA9PT0gMCkpXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTXVsdGlTdGVwfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTEvNCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlciAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTQwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBlbnJvbGxtZW50U3RlcCA9PT0gXCJ2ZXJpZnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JheS02MDAgaG92ZXI6YmctZ3JheS03MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA6IGVucm9sbG1lbnRTdGVwID09PSBcImNvbnRpbnVlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JlZW4tNjAwIGhvdmVyOmJnLWdyZWVuLTcwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPyBcIlByb2Nlc3NpbmcuLi5cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDogZW5yb2xsbWVudFN0ZXAgPT09IFwidmVyaWZ5XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID8gXCJWZXJpZnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBlbnJvbGxtZW50U3RlcCA9PT0gXCJjb250aW51ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJDb250aW51ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJTdWJtaXRcIn1cclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Zvcm0+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L01vZGFsPlxyXG5cclxuLy8gICAgICAgICB7LyogVXBkYXRlIE1vZGFsIC0gVXNpbmcgY3VzdG9tIE1vZGFsIGNvbXBvbmVudCAqL31cclxuLy8gICAgICAgICA8TW9kYWxcclxuLy8gICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4vLyAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4vLyAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4vLyAgICAgICAgICAgfX1cclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4vLyAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgVXBkYXRlIEVucm9sbG1lbnRcclxuLy8gICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZX0+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIEdyb3VwIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cF9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ncm91cF9pZH1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4vLyAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEdyb3VwPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidXNlcl9pZFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgbmFtZT1cInVzZXJfaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBpZD1cInVzZXJfaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudXNlcl9pZH1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4vLyAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEN1c3RvbWVyPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICB7ZXJyb3JzLnVzZXJfaWQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy51c2VyX2lkfTwvcD5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwYXltZW50X3R5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICBTZWxlY3QgUGF5bWVudCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUGF5bWVudCBUeXBlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuLy8gICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5bWVudF90eXBlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucGF5bWVudF90eXBlIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJwYXltZW50X3R5cGVcIiwgdmFsdWUpXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge1tcIkRhaWx5XCIsIFwiV2Vla2x5XCIsIFwiTW9udGhseVwiXS5tYXAoKHBUeXBlKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtwVHlwZS50b0xvd2VyQ2FzZSgpfSB2YWx1ZT17cFR5cGV9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge3BUeXBlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIENoaXQgQXNraW5nIE1vbnRoXHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgIHR5cGU9XCJtb250aFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBib3JkZXIgcm91bmRlZCB3LWZ1bGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY2hpdF9hc2tpbmdfbW9udGh9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZS50YXJnZXQudmFsdWUsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWxcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicmVmZXJyZWRfdHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyZWQgVHlwZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX3R5cGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5yZWZlcnJlZF90eXBlIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJyZWZlcnJlZF90eXBlXCIsIHZhbHVlKVxyXG4vLyAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtbXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJTZWxmIEpvaW5pbmdcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFwiTGVhZHNcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICBcIk90aGVyc1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICBdLm1hcCgocmVmVHlwZSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmVHlwZX0gdmFsdWU9e3JlZlR5cGV9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge3JlZlR5cGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEN1c3RvbWVye1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEN1c3RvbWVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfY3VzdG9tZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfY3VzdG9tZXIgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJyZWZlcnJlZF9jdXN0b21lclwiLCB2YWx1ZSlcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJMZWFkc1wiICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIExlYWRze1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIExlYWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9sZWFkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnJlZmVycmVkX2xlYWQgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJyZWZlcnJlZF9sZWFkXCIsIHZhbHVlKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtsZWFkcy5tYXAoKGxlYWQpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bGVhZC5faWR9IHZhbHVlPXtsZWFkLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtsZWFkLmxlYWRfbmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkVtcGxveWVlXCIgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgRW1wbG95ZWV7XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgRW1wbG95ZWVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZ2VudFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5hZ2VudCB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiYWdlbnRcIiwgdmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Ll9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgVXBkYXRlXHJcbi8vICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgIDwvZm9ybT5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvTW9kYWw+XHJcblxyXG4vLyAgICAgICAgIHsvKiBEZWxldGUgTW9kYWwgLSBVc2luZyBjdXN0b20gTW9kYWwgY29tcG9uZW50ICovfVxyXG4vLyAgICAgICAgIDxNb2RhbFxyXG4vLyAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbi8vICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbi8vICAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuLy8gICAgICAgICAgIH19XHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuLy8gICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFN1cmUgd2FudCB0byByZW1vdmUgdGhpcyBFbnJvbGxtZW50ID9cclxuLy8gICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPGZvcm1cclxuLy8gICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbi8vICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZUdyb3VwKCk7XHJcbi8vICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4vLyAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9Nb2RhbD5cclxuXHJcbi8vICAgICAgICAgey8qIFN0YXR1cyBVcGRhdGUgTW9kYWwgLSBVc2luZyBBbnQgRGVzaWduIE1vZGFsIHdpdGggQ2FyZHMsIFJvdywgQ29sLCBhbmQgVGFibGUgKi99XHJcbi8vICAgICAgICAgPEFudE1vZGFsXHJcbi8vICAgICAgICAgICB0aXRsZT17XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ibHVlLTEwMCByb3VuZGVkLXhsIHRleHQtYmx1ZS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTEgNUg2YTIgMiAwIDAwLTIgMnYxMWEyIDIgMCAwMDIgMmgxMWEyIDIgMCAwMDItMnYtNW0tMS40MTQtOS40MTRhMiAyIDAgMTEyLjgyOCAyLjgyOEwxMS44MjggMTVIOXYtMi44MjhsOC41ODYtOC41ODZ6XCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBVcGRhdGUgU3RhdHVzXHJcbi8vICAgICAgICAgICAgICAgICA8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIENoYW5nZSB0aGUgY29udGFjdCBzdGF0dXMgYW5kIHJlbWFyayBmb3IgdGhpcyBlbnJvbGxtZW50LlxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIH1cclxuLy8gICAgICAgICAgIG9wZW49e3Nob3dTdGF0dXNVcGRhdGVNb2RhbH1cclxuLy8gICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTaG93U3RhdHVzVXBkYXRlTW9kYWwoZmFsc2UpfVxyXG4vLyAgICAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4vLyAgICAgICAgICAgd2lkdGg9ezcwMH1cclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsXCJcclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuLy8gICAgICAgICAgICAgPENvbCBzcGFuPXsyNH0+XHJcbi8vICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcm91bmRlZC14bFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgU3RhdHVzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBTdGF0dXNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N0YXR1c1VwZGF0ZURhdGEuc3RhdHVzIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0YXR1c1VwZGF0ZURhdGEoKHByZXYpID0+ICh7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IHZhbHVlLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1NUQVRVU19PUFRJT05TLm1hcCgob3B0KSA9PiAoe1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogb3B0LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogb3B0LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgfSkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgUmVtYXJrXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWFcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFkZCBhIHJlbWFyay4uLlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RhdHVzVXBkYXRlRGF0YS5yZW1hcmt9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0YXR1c1VwZGF0ZURhdGEoKHByZXYpID0+ICh7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICByZW1hcms6IGUudGFyZ2V0LnZhbHVlLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByZXNpemUtbm9uZSByb3VuZGVkLWxnIGJvcmRlci1zbGF0ZS0zMDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIHtzdGF0dXNVcGRhdGVEYXRhLnN0YXR1cyA9PT0gXCJGb2xsb3cgVXBcIiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1wdXJwbGUtNjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBGb2xsb3cgVXAgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNVcGRhdGVEYXRhLmZvbGxvd191cF9kYXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGRheWpzKHN0YXR1c1VwZGF0ZURhdGEuZm9sbG93X3VwX2RhdGUpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG51bGxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KF8sIGRhdGVTdHJpbmcpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U3RhdHVzVXBkYXRlRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2xsb3dfdXBfZGF0ZTogZGF0ZVN0cmluZyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMSByb3VuZGVkLWxnIGJvcmRlci1wdXJwbGUtMzAwIGhvdmVyOmJvcmRlci1wdXJwbGUtNDAwIGZvY3VzOmJvcmRlci1wdXJwbGUtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiWVlZWS1NTS1ERFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGZvbGxvdy11cCBkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWREYXRlPXsoY3VycmVudCkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50ICYmIGN1cnJlbnQgPCBkYXlqcygpLnN0YXJ0T2YoXCJkYXlcIilcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcHVycGxlLTUwMCBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBhIGZ1dHVyZSBkYXRlIGZvciB0aGUgZm9sbG93LXVwXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L0NhcmQ+XHJcbi8vICAgICAgICAgICAgIDwvQ29sPlxyXG4vLyAgICAgICAgICAgPC9Sb3c+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTYgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbi8vICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICB0eXBlPVwiZGVmYXVsdFwiXHJcbi8vICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsKGZhbHNlKX1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHB4LTYgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtNTAgcm91bmRlZC14bCBmb250LW1lZGl1bVwiXHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICBDYW5jZWxcclxuLy8gICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbi8vICAgICAgICAgICAgICAgbG9hZGluZz17aXNTdGF0dXNVcGRhdGluZ31cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdGF0dXNVcGRhdGVTdWJtaXR9XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMSBweC02IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tYmx1ZS03MDAgaG92ZXI6dG8taW5kaWdvLTcwMCB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbWQgc2hhZG93LWJsdWUtMjAwIHRyYW5zaXRpb24tYWxsXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIFVwZGF0ZSBTdGF0dXNcclxuLy8gICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L0FudE1vZGFsPlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvPlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG4vLyBleHBvcnQgZGVmYXVsdCBNb2JpbGVBcHBFbnJvbGw7XHJcblxyXG5jb25zdCBNT0JJTEVfRU5ST0xMX1NUQVRVU19DT05GSUcgPSBbXHJcbiAge1xyXG4gICAga2V5OiBcIkNvbnRhY3RlZFwiLFxyXG4gICAgbGFiZWw6IFwiQ29udGFjdGVkXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLWluZGlnby01MDAgdG8taW5kaWdvLTYwMFwiLFxyXG4gICAgYmdMaWdodDogXCJiZy1pbmRpZ28tNTBcIixcclxuICAgIHRleHRDb2xvcjogXCJ0ZXh0LWluZGlnby03MDBcIixcclxuICAgIGljb25Db2xvcjogXCJ0ZXh0LWluZGlnby01MDBcIixcclxuICAgIHJpbmdDb2xvcjogXCJyaW5nLWluZGlnby0xMDBcIixcclxuICAgIGljb246IChcclxuICAgICAgPHN2Z1xyXG4gICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTVcIlxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPHBhdGhcclxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICBkPVwiTTMgNWEyIDIgMCAwMTItMmgzLjI4YTEgMSAwIDAxLjk0OC42ODRsMS40OTggNC40OTNhMSAxIDAgMDEtLjUwMiAxLjIxbC0yLjI1NyAxLjEzYTExLjA0MiAxMS4wNDIgMCAwMDUuNTE2IDUuNTE2bDEuMTMtMi4yNTdhMSAxIDAgMDExLjIxLS41MDJsNC40OTMgMS40OThhMSAxIDAgMDEuNjg0Ljk0OVYxOWEyIDIgMCAwMS0yIDJoLTFDOS43MTYgMjEgMyAxNC4yODQgMyA2VjV6XCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiSW50ZXJlc3RlZFwiLFxyXG4gICAgbGFiZWw6IFwiSW50ZXJlc3RlZFwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4gICAgYmdMaWdodDogXCJiZy1ibHVlLTUwXCIsXHJcbiAgICB0ZXh0Q29sb3I6IFwidGV4dC1ibHVlLTcwMFwiLFxyXG4gICAgaWNvbkNvbG9yOiBcInRleHQtYmx1ZS01MDBcIixcclxuICAgIHJpbmdDb2xvcjogXCJyaW5nLWJsdWUtMTAwXCIsXHJcbiAgICBpY29uOiAoXHJcbiAgICAgIDxzdmdcclxuICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01XCJcclxuICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgPlxyXG4gICAgICAgIDxwYXRoXHJcbiAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgZD1cIk0xMS4wNDkgMi45MjdjLjMtLjkyMSAxLjYwMy0uOTIxIDEuOTAyIDBsMS41MTkgNC42NzRhMSAxIDAgMDAuOTUuNjloNC45MTVjLjk2OSAwIDEuMzcxIDEuMjQuNTg4IDEuODFsLTMuOTc2IDIuODg4YTEgMSAwIDAwLS4zNjMgMS4xMThsMS41MTggNC42NzRjLjMuOTIyLS43NTUgMS42ODgtMS41MzggMS4xMThsLTMuOTc2LTIuODg4YTEgMSAwIDAwLTEuMTc2IDBsLTMuOTc2IDIuODg4Yy0uNzgzLjU3LTEuODM4LS4xOTctMS41MzgtMS4xMThsMS41MTgtNC42NzRhMSAxIDAgMDAtLjM2My0xLjExOGwtMy45NzYtMi44ODhjLS43ODQtLjU3LS4zOC0xLjgxLjU4OC0xLjgxaDQuOTE0YTEgMSAwIDAwLjk1MS0uNjlsMS41MTktNC42NzR6XCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiRm9sbG93IFVwXCIsXHJcbiAgICBsYWJlbDogXCJGb2xsb3cgVXBcIixcclxuICAgIGNvbG9yOiBcImZyb20tcHVycGxlLTUwMCB0by1wdXJwbGUtNjAwXCIsXHJcbiAgICBiZ0xpZ2h0OiBcImJnLXB1cnBsZS01MFwiLFxyXG4gICAgdGV4dENvbG9yOiBcInRleHQtcHVycGxlLTcwMFwiLFxyXG4gICAgaWNvbkNvbG9yOiBcInRleHQtcHVycGxlLTUwMFwiLFxyXG4gICAgcmluZ0NvbG9yOiBcInJpbmctcHVycGxlLTEwMFwiLFxyXG4gICAgaWNvbjogKFxyXG4gICAgICA8c3ZnXHJcbiAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNVwiXHJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgID5cclxuICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgIGQ9XCJNMTIgOHY0bDMgM202LTNhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiQ29udmVydGVkXCIsXHJcbiAgICBsYWJlbDogXCJDb252ZXJ0ZWRcIixcclxuICAgIGNvbG9yOiBcImZyb20tZW1lcmFsZC01MDAgdG8tZ3JlZW4tNjAwXCIsXHJcbiAgICBiZ0xpZ2h0OiBcImJnLWVtZXJhbGQtNTBcIixcclxuICAgIHRleHRDb2xvcjogXCJ0ZXh0LWVtZXJhbGQtNzAwXCIsXHJcbiAgICBpY29uQ29sb3I6IFwidGV4dC1lbWVyYWxkLTUwMFwiLFxyXG4gICAgcmluZ0NvbG9yOiBcInJpbmctZW1lcmFsZC0xMDBcIixcclxuICAgIGljb246IChcclxuICAgICAgPHN2Z1xyXG4gICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTVcIlxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPHBhdGhcclxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICBkPVwiTTkgMTJsMiAyIDQtNG02IDJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiUmVqZWN0ZWRcIixcclxuICAgIGxhYmVsOiBcIlJlamVjdGVkXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLXJlZC01MDAgdG8tcmVkLTYwMFwiLFxyXG4gICAgYmdMaWdodDogXCJiZy1yZWQtNTBcIixcclxuICAgIHRleHRDb2xvcjogXCJ0ZXh0LXJlZC03MDBcIixcclxuICAgIGljb25Db2xvcjogXCJ0ZXh0LXJlZC01MDBcIixcclxuICAgIHJpbmdDb2xvcjogXCJyaW5nLXJlZC0xMDBcIixcclxuICAgIGljb246IChcclxuICAgICAgPHN2Z1xyXG4gICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTVcIlxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPHBhdGhcclxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICBkPVwiTTEwIDE0bDItMm0wIDBsMi0ybS0yIDJsLTItMm0yIDJsMiAybTctMmE5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvc3ZnPlxyXG4gICAgKSxcclxuICB9LFxyXG5dO1xyXG5cclxuY29uc3QgU1RBVFVTX09QVElPTlMgPSBbXHJcbiAgXCJOb3QgQ29udGFjdGVkXCIsXHJcbiAgXCJDb250YWN0ZWRcIixcclxuICBcIkludGVyZXN0ZWRcIixcclxuICBcIkZvbGxvdyBVcFwiLFxyXG4gIFwiQ29udmVydGVkXCIsXHJcbiAgXCJSZWplY3RlZFwiLFxyXG5dO1xyXG5cclxuY29uc3QgTW9iaWxlQXBwRW5yb2xsID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlRW5yb2xscywgc2V0VGFibGVFbnJvbGxzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRFbnJvbGxzLCBzZXRGaWx0ZXJlZEVucm9sbHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2F2YWlsYWJsZVRpY2tldHMsIHNldEF2YWlsYWJsZVRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRHcm91cCwgc2V0Q3VycmVudEdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFthdmFpbGFibGVUaWNrZXRzQWRkLCBzZXRBdmFpbGFibGVUaWNrZXRzQWRkXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzRGF0YVRhYmxlTG9hZGluZywgc2V0SXNEYXRhVGFibGVMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFthbGxFbnJvbGxVcmwsIHNldEFsbEVucm9sbFVybF0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbbGVhZHMsIHNldExlYWRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt3aGF0c2FwcEVuYWJsZSwgc2V0V2hhdHNhcHBFbmFibGVdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnRTdGVwLCBzZXRFbnJvbGxtZW50U3RlcF0gPSB1c2VTdGF0ZShcInZlcmlmeVwiKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtpc0V4aXN0aW5nRW5yb2xsbWVudCwgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbiwgc2V0QWRtaW5dID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIC8vIE5ldyBzdGF0ZXMgZm9yIHN0YXR1cyB0cmFja2luZyBVSVxyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcInBlbmRpbmdcIik7XHJcbiAgY29uc3QgW3ZpZXdNb2RlLCBzZXRWaWV3TW9kZV0gPSB1c2VTdGF0ZShcImdyaWRcIik7XHJcbiAgY29uc3QgW2N1cnJlbnRQYWdlLCBzZXRDdXJyZW50UGFnZV0gPSB1c2VTdGF0ZSgxKTtcclxuICBjb25zdCBbaXRlbXNQZXJQYWdlXSA9IHVzZVN0YXRlKDkpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIC8vIFNFTEVDVElPTiBTVEFURVNcclxuICBjb25zdCBbc2VsZWN0ZWRFbnJvbGxtZW50cywgc2V0U2VsZWN0ZWRFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8gU3RhdHVzIHVwZGF0ZSBtb2RhbCBzdGF0ZXMgLSBVcGRhdGVkIHdpdGggYnVsayBzdXBwb3J0XHJcbiAgY29uc3QgW3Nob3dTdGF0dXNVcGRhdGVNb2RhbCwgc2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc3RhdHVzVXBkYXRlRGF0YSwgc2V0U3RhdHVzVXBkYXRlRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBfaWQ6IFwiXCIsXHJcbiAgICBzdGF0dXM6IFwiXCIsXHJcbiAgICByZW1hcms6IFwiXCIsXHJcbiAgICBmb2xsb3dfdXBfZGF0ZTogXCJcIixcclxuICAgIGlzQnVsazogZmFsc2UsXHJcbiAgICBzZWxlY3RlZElkczogW10sXHJcbiAgfSk7XHJcbiAgY29uc3QgW2lzU3RhdHVzVXBkYXRpbmcsIHNldElzU3RhdHVzVXBkYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBTdGF0ZSBmb3Igc3VtbWFyeSBtZXRyaWNzXHJcbiAgY29uc3QgW3N1bW1hcnlTdGF0cywgc2V0U3VtbWFyeVN0YXRzXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsRW5yb2xsbWVudHM6IDAsXHJcbiAgICB0b3RhbFRpY2tldHM6IDAsXHJcbiAgICB1bmlxdWVDdXN0b21lcnM6IDAsXHJcbiAgICB1bmlxdWVHcm91cHM6IDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICBjb25zdCBjdXJyZW50WWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbiAgY29uc3QgY3VycmVudE1vbnRoID0gU3RyaW5nKHRvZGF5LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgY29uc3QgY3VycmVudFllYXJNb250aCA9IGAke2N1cnJlbnRZZWFyfS0ke2N1cnJlbnRNb250aH1gO1xyXG5cclxuICBmdW5jdGlvbiBmb3JtYXREYXRlKGRhdGUpIHtcclxuICAgIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IGAwJHtkYXRlLmdldE1vbnRoKCkgKyAxfWAuc2xpY2UoLTIpO1xyXG4gICAgY29uc3QgZGF5ID0gYDAke2RhdGUuZ2V0RGF0ZSgpfWAuc2xpY2UoLTIpO1xyXG4gICAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbiAgfVxyXG5cclxuICBjb25zdCBwYXJzZURhdGUgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgW3llYXIsIG1vbnRoXSA9IGRhdGVTdHJpbmcuc3BsaXQoXCItXCIpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgeWVhcixcclxuICAgICAgbW9udGg6IFN0cmluZyhwYXJzZUludChtb250aCkpLnBhZFN0YXJ0KDIsIFwiMFwiKSxcclxuICAgICAgbW9udGhOYW1lOiBtb250aE5hbWVzW3BhcnNlSW50KG1vbnRoKSAtIDFdLFxyXG4gICAgfTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmb3JtYXRUb1llYXJNb250aCA9ICh5ZWFyLCBtb250aCkgPT4ge1xyXG4gICAgcmV0dXJuIGAke3llYXJ9LSR7U3RyaW5nKG1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRNb250aERhdGVSYW5nZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCB7IHllYXIsIG1vbnRoIH0gPSBwYXJzZURhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICBjb25zdCBzdGFydERhdGUgPSBuZXcgRGF0ZSh5ZWFyLCBwYXJzZUludChtb250aCkgLSAxLCAxKTtcclxuICAgIGNvbnN0IGVuZERhdGUgPSBuZXcgRGF0ZSh5ZWFyLCBwYXJzZUludChtb250aCksIDApO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGZyb21fZGF0ZTogZm9ybWF0RGF0ZShzdGFydERhdGUpLFxyXG4gICAgICB0b19kYXRlOiBmb3JtYXREYXRlKGVuZERhdGUpLFxyXG4gICAgfTtcclxuICB9O1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IG1vbnRoTmFtZXMgPSBbXHJcbiAgICBcIkphbnVhcnlcIixcclxuICAgIFwiRmVicnVhcnlcIixcclxuICAgIFwiTWFyY2hcIixcclxuICAgIFwiQXByaWxcIixcclxuICAgIFwiTWF5XCIsXHJcbiAgICBcIkp1bmVcIixcclxuICAgIFwiSnVseVwiLFxyXG4gICAgXCJBdWd1c3RcIixcclxuICAgIFwiU2VwdGVtYmVyXCIsXHJcbiAgICBcIk9jdG9iZXJcIixcclxuICAgIFwiTm92ZW1iZXJcIixcclxuICAgIFwiRGVjZW1iZXJcIixcclxuICBdO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIG5vX29mX3RpY2tldHM6IFwiXCIsXHJcbiAgICByZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4gICAgcGF5bWVudF90eXBlOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICBhZ2VudDogXCJcIixcclxuICAgIHJlZmVycmVkX2xlYWQ6IFwiXCIsXHJcbiAgICBjaGl0X2Fza2luZ19tb250aDogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2lzVmVyaWZpZWQsIHNldElzVmVyaWZpZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgdGlja2V0czogXCJcIixcclxuICAgIHBheW1lbnRfdHlwZTogXCJcIixcclxuICAgIHJlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgIGFnZW50OiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfbGVhZDogXCJcIixcclxuICAgIGNoaXRfYXNraW5nX21vbnRoOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuICAgIGNvbnN0IGFkbWluSWQgPSB1c2VyT2JqPy5faWQ7XHJcbiAgICBpZiAoYWRtaW5JZCkge1xyXG4gICAgICBzZXRBZG1pbih1c2VyT2JqLl9pZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRBZG1pbihcIlwiKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEdldCBzdGF0dXMgY291bnRzIGZvciBzdW1tYXJ5XHJcbiAgY29uc3QgZ2V0U3RhdHVzQ291bnRzID0gKCkgPT4ge1xyXG4gICAgY29uc3QgY29udGFjdGVkID0gZmlsdGVyZWRFbnJvbGxzLmZpbHRlcihcclxuICAgICAgKHUpID0+IHUuc3RhdHVzICYmIHUuc3RhdHVzICE9PSBcIk5vdCBDb250YWN0ZWRcIixcclxuICAgICk7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICB0b3RhbDogY29udGFjdGVkLmxlbmd0aCxcclxuICAgICAgQ29udGFjdGVkOiBjb250YWN0ZWQuZmlsdGVyKCh1KSA9PiB1LnN0YXR1cyA9PT0gXCJDb250YWN0ZWRcIikubGVuZ3RoLFxyXG4gICAgICBJbnRlcmVzdGVkOiBjb250YWN0ZWQuZmlsdGVyKCh1KSA9PiB1LnN0YXR1cyA9PT0gXCJJbnRlcmVzdGVkXCIpLmxlbmd0aCxcclxuICAgICAgXCJGb2xsb3cgVXBcIjogY29udGFjdGVkLmZpbHRlcigodSkgPT4gdS5zdGF0dXMgPT09IFwiRm9sbG93IFVwXCIpLmxlbmd0aCxcclxuICAgICAgQ29udmVydGVkOiBjb250YWN0ZWQuZmlsdGVyKCh1KSA9PiB1LnN0YXR1cyA9PT0gXCJDb252ZXJ0ZWRcIikubGVuZ3RoLFxyXG4gICAgICBSZWplY3RlZDogY29udGFjdGVkLmZpbHRlcigodSkgPT4gdS5zdGF0dXMgPT09IFwiUmVqZWN0ZWRcIikubGVuZ3RoLFxyXG4gICAgfTtcclxuICB9O1xyXG5cclxuICAvLyBHZXQgc3RhdHVzIGNvbG9yXHJcbiAgY29uc3QgZ2V0U3RhdHVzQ29sb3IgPSAoc3RhdHVzKSA9PiB7XHJcbiAgICBzd2l0Y2ggKHN0YXR1cykge1xyXG4gICAgICBjYXNlIFwiQXBwcm92ZWRcIjpcclxuICAgICAgICByZXR1cm4gXCJiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1lbWVyYWxkLTYwMC8yMFwiO1xyXG4gICAgICBjYXNlIFwiUGVuZGluZ1wiOlxyXG4gICAgICAgIHJldHVybiBcImJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctYW1iZXItNjAwLzIwXCI7XHJcbiAgICAgIGNhc2UgXCJJbnRlcmVzdGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIFwiYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctYmx1ZS02MDAvMjBcIjtcclxuICAgICAgY2FzZSBcIk5vdCBJbnRlcmVzdGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIFwiYmctZ3JheS01MCB0ZXh0LWdyYXktNjAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctZ3JheS01MDAvMjBcIjtcclxuICAgICAgY2FzZSBcIkNvbnRhY3RlZFwiOlxyXG4gICAgICAgIHJldHVybiBcImJnLWluZGlnby01MCB0ZXh0LWluZGlnby03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1pbmRpZ28tNjAwLzIwXCI7XHJcbiAgICAgIGNhc2UgXCJGb2xsb3cgVXBcIjpcclxuICAgICAgICByZXR1cm4gXCJiZy1wdXJwbGUtNTAgdGV4dC1wdXJwbGUtNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctcHVycGxlLTYwMC8yMFwiO1xyXG4gICAgICBjYXNlIFwiQ29udmVydGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIFwiYmctZ3JlZW4tNTAgdGV4dC1ncmVlbi03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1ncmVlbi02MDAvMjBcIjtcclxuICAgICAgY2FzZSBcIlJlamVjdGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIFwiYmctcmVkLTUwIHRleHQtcmVkLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLXJlZC02MDAvMjBcIjtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm4gXCJiZy1ncmF5LTUwIHRleHQtZ3JheS02MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1ncmF5LTUwMC8yMFwiO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEdldCBzdGF0dXMgaWNvblxyXG4gIGNvbnN0IGdldFN0YXR1c0ljb24gPSAoc3RhdHVzKSA9PiB7XHJcbiAgICBzd2l0Y2ggKHN0YXR1cykge1xyXG4gICAgICBjYXNlIFwiQ29udGFjdGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNFwiXHJcbiAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgICAgIGQ9XCJNMyA1YTIgMiAwIDAxMi0yaDMuMjhhMSAxIDAgMDEuOTQ4LjY4NGwxLjQ5OCA0LjQ5M2ExIDEgMCAwMS0uNTAyIDEuMjFsLTIuMjU3IDEuMTNhMTEuMDQyIDExLjA0MiAwIDAwNS41MTYgNS41MTZsMS4xMy0yLjI1N2ExIDEgMCAwMTEuMjEtLjUwMmw0LjQ5MyAxLjQ5OGExIDEgMCAwMS42ODQuOTQ5VjE5YTIgMiAwIDAxLTIgMmgtMUM5LjcxNiAyMSAzIDE0LjI4NCAzIDZWNXpcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgKTtcclxuICAgICAgY2FzZSBcIkludGVyZXN0ZWRcIjpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgZD1cIk0xMS4wNDkgMi45MjdjLjMtLjkyMSAxLjYwMy0uOTIxIDEuOTAyIDBsMS41MTkgNC42NzRhMSAxIDAgMDAuOTUuNjloNC45MTVjLjk2OSAwIDEuMzcxIDEuMjQuNTg4IDEuODFsLTMuOTc2IDIuODg4YTEgMSAwIDAwLS4zNjMgMS4xMThsMS41MTggNC42NzRjLjMuOTIyLS43NTUgMS42ODgtMS41MzggMS4xMThsLTMuOTc2LTIuODg4YTEgMSAwIDAwLTEuMTc2IDBsLTMuOTc2IDIuODg4Yy0uNzgzLjU3LTEuODM4LS4xOTctMS41MzgtMS4xMThsMS41MTgtNC42NzRhMSAxIDAgMDAtLjM2My0xLjExOGwtMy45NzYtMi44ODhjLS43ODQtLjU3LS4zOC0xLjgxLjU4OC0xLjgxaDQuOTE0YTEgMSAwIDAwLjk1MS0uNjlsMS41MTktNC42NzR6XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICk7XHJcbiAgICAgIGNhc2UgXCJGb2xsb3cgVXBcIjpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgZD1cIk0xMiA4djRsMyAzbTYtM2E5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgKTtcclxuICAgICAgY2FzZSBcIkNvbnZlcnRlZFwiOlxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTRcIlxyXG4gICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICBkPVwiTTkgMTJsMiAyIDQtNG02IDJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICk7XHJcbiAgICAgIGNhc2UgXCJSZWplY3RlZFwiOlxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTRcIlxyXG4gICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICBkPVwiTTEwIDE0bDItMm0wIDBsMi0ybS0yIDJsLTItMm0yIDJsMiAybTctMmE5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgKTtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBGaWx0ZXIgdXNlcnMgYmFzZWQgb24gYWN0aXZlIHRhYiAoc3RhdHVzKVxyXG4gIGNvbnN0IGdldFRhYkZpbHRlcmVkRW5yb2xscyA9ICgpID0+IHtcclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiKSB7XHJcbiAgICAgIHJldHVybiBmaWx0ZXJlZEVucm9sbHMuZmlsdGVyKFxyXG4gICAgICAgIChlbnJvbGwpID0+IGVucm9sbC5zdGF0dXMgPT09IFwiTm90IENvbnRhY3RlZFwiIHx8ICFlbnJvbGwuc3RhdHVzLFxyXG4gICAgICApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIGZpbHRlcmVkRW5yb2xscy5maWx0ZXIoXHJcbiAgICAgICAgKGVucm9sbCkgPT4gZW5yb2xsLnN0YXR1cyAmJiBlbnJvbGwuc3RhdHVzICE9PSBcIk5vdCBDb250YWN0ZWRcIixcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBTRUxFQ1RJT04gSEFORExFUlNcclxuICBjb25zdCBoYW5kbGVTZWxlY3RFbnJvbGxtZW50ID0gKGlkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnRzKChwcmV2KSA9PiB7XHJcbiAgICAgIGlmIChwcmV2LmluY2x1ZGVzKGlkKSkge1xyXG4gICAgICAgIHJldHVybiBwcmV2LmZpbHRlcigoaXRlbSkgPT4gaXRlbSAhPT0gaWQpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBbLi4ucHJldiwgaWRdO1xyXG4gICAgfSk7XHJcbiAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEFsbCA9ICgpID0+IHtcclxuICAgIGNvbnN0IHRhYkZpbHRlcmVkID0gZ2V0VGFiRmlsdGVyZWRFbnJvbGxzKCk7XHJcbiAgICBjb25zdCBjdXJyZW50SWRzID0gdGFiRmlsdGVyZWQubWFwKChpdGVtKSA9PiBpdGVtLl9pZCk7XHJcbiAgICBpZiAoc2VsZWN0QWxsKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50cyhjdXJyZW50SWRzKTtcclxuICAgIH1cclxuICAgIHNldFNlbGVjdEFsbCghc2VsZWN0QWxsKTtcclxuICB9O1xyXG5cclxuICAvLyBCdWxrIGFjdGlvbiBoYW5kbGVyXHJcbiAgY29uc3QgaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZSA9ICgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYXQgbGVhc3Qgb25lIGVucm9sbG1lbnQuXCIsXHJcbiAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBzZXRTdGF0dXNVcGRhdGVEYXRhKHtcclxuICAgICAgX2lkOiBcIlwiLFxyXG4gICAgICBzdGF0dXM6IFwiXCIsXHJcbiAgICAgIHJlbWFyazogXCJcIixcclxuICAgICAgZm9sbG93X3VwX2RhdGU6IFwiXCIsXHJcbiAgICAgIGlzQnVsazogdHJ1ZSxcclxuICAgICAgc2VsZWN0ZWRJZHM6IFsuLi5zZWxlY3RlZEVucm9sbG1lbnRzXSxcclxuICAgIH0pO1xyXG4gICAgc2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQWxsRW5yb2xsbWVudERhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvbW9iaWxlLWFwcC1lbnJvbGwvZ2V0LW1vYmlsZS1hcHAtZW5yb2xsXCIpO1xyXG4gICAgICBjb25zdCByYXdEYXRhID0gcmVzLmRhdGE7XHJcblxyXG4gICAgICBjb25zdCB0b3RhbEVucm9sbG1lbnRzID0gcmF3RGF0YS5sZW5ndGg7XHJcbiAgICAgIGNvbnN0IHRvdGFsVGlja2V0cyA9IHJhd0RhdGEucmVkdWNlKFxyXG4gICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChpdGVtLm5vX29mX3RpY2tldHMgfHwgMCksXHJcbiAgICAgICAgMCxcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgdW5pcXVlQ3VzdG9tZXJzID0gbmV3IFNldChcclxuICAgICAgICByYXdEYXRhLm1hcCgoaXRlbSkgPT4gaXRlbS51c2VyX2lkPy5faWQpLmZpbHRlcihCb29sZWFuKSxcclxuICAgICAgKS5zaXplO1xyXG4gICAgICBjb25zdCB1bmlxdWVHcm91cHMgPSBuZXcgU2V0KFxyXG4gICAgICAgIHJhd0RhdGEubWFwKChpdGVtKSA9PiBpdGVtLmdyb3VwX2lkPy5ncm91cF9uYW1lKS5maWx0ZXIoQm9vbGVhbiksXHJcbiAgICAgICkuc2l6ZTtcclxuXHJcbiAgICAgIHNldFN1bW1hcnlTdGF0cyh7XHJcbiAgICAgICAgdG90YWxFbnJvbGxtZW50cyxcclxuICAgICAgICB0b3RhbFRpY2tldHMsXHJcbiAgICAgICAgdW5pcXVlQ3VzdG9tZXJzLFxyXG4gICAgICAgIHVuaXF1ZUdyb3VwcyxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBkYXRhID0gcmF3RGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIF9pZDogaXRlbS5faWQsXHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICBtb2JpbGVfZW5yb2xsX2NvZGU6IGl0ZW0ubW9iaWxlX2Vucm9sbF9jb2RlLFxyXG4gICAgICAgIG5hbWU6IGl0ZW0udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgIHBob25lX251bWJlcjogaXRlbS51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgZ3JvdXBfbmFtZTogaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICBub19vZl90aWNrZXRzOiBpdGVtLm5vX29mX3RpY2tldHMsXHJcbiAgICAgICAgcGF5bWVudF90eXBlOiBpdGVtLnBheW1lbnRfdHlwZSxcclxuICAgICAgICBjaGl0X2Fza2luZ19tb250aDogaXRlbS5jaGl0X2Fza2luZ19tb250aCxcclxuICAgICAgICByZWZlcnJlZF90eXBlOiBpdGVtLnJlZmVycmVkX3R5cGUsXHJcbiAgICAgICAgc3RhdHVzOiBpdGVtLnN0YXR1cyB8fCBcIk5vdCBDb250YWN0ZWRcIixcclxuICAgICAgICByZW1hcms6IGl0ZW0ucmVtYXJrIHx8IFwiXCIsXHJcbiAgICAgICAgZm9sbG93X3VwX2RhdGU6IGl0ZW0uZm9sbG93X3VwX2RhdGUgfHwgXCJcIixcclxuICAgICAgICB1c2VyX2lkOiBpdGVtLnVzZXJfaWQsXHJcbiAgICAgICAgZ3JvdXBfaWQ6IGl0ZW0uZ3JvdXBfaWQsXHJcbiAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IGl0ZW0ucmVmZXJyZWRfY3VzdG9tZXIsXHJcbiAgICAgICAgcmVmZXJyZWRfbGVhZDogaXRlbS5yZWZlcnJlZF9sZWFkLFxyXG4gICAgICAgIGFnZW50OiBpdGVtLmFnZW50LFxyXG4gICAgICAgIGVucm9sbG1lbnRfZGF0ZTogaXRlbS5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICByZWZlcnJlZF9ieTogaXRlbT8udXNlcl9pZD8ucmVmZXJyZWRfZW1wbG95ZWVcclxuICA/IGAke2l0ZW0/LnVzZXJfaWQ/LnJlZmVycmVkX2VtcGxveWVlPy5uYW1lIHx8IFwiLVwifSB8ICR7XHJcbiAgICAgIGl0ZW0/LnVzZXJfaWQ/LnJlZmVycmVkX2VtcGxveWVlPy5waG9uZV9udW1iZXIgfHwgXCItXCJcclxuICAgIH1gXHJcbiAgOiBcIlNlbGZcIixcclxuXHJcbiAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwic3RhdHVzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bSBjdXJzb3ItcG9pbnRlciBweC0yIHB5LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuU3RhdHVzVXBkYXRlTW9kYWwoaXRlbSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk0xMSA1SDZhMiAyIDAgMDAtMiAydjExYTIgMiAwIDAwMiAyaDExYTIgMiAwIDAwMi0ydi01bS0xLjQxNC05LjQxNGEyIDIgMCAxMTIuODI4IDIuODI4TDExLjgyOCAxNUg5di0yLjgyOGw4LjU4Ni04LjU4NnpcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBVcGRhdGUgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihpdGVtLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3BlbihpdGVtLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVucm9sbENsaWNrKGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBcHByb3ZlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZCBjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldFRhYmxlRW5yb2xscyhkYXRhKTtcclxuICAgICAgc2V0RmlsdGVyZWRFbnJvbGxzKGRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggZW5yb2xsbWVudCBkYXRhXCIsIGVycik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuICB9LCBbZmV0Y2hBbGxFbnJvbGxtZW50RGF0YV0pO1xyXG5cclxuICAvLyBGaWx0ZXIgYnkgc2VhcmNoIHRlcm1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNlYXJjaFRlcm0pIHtcclxuICAgICAgY29uc3QgZmlsdGVyZWQgPSBUYWJsZUVucm9sbHMuZmlsdGVyKFxyXG4gICAgICAgIChlbnJvbGwpID0+XHJcbiAgICAgICAgICBlbnJvbGwubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcclxuICAgICAgICAgIGVucm9sbC5waG9uZV9udW1iZXIudG9TdHJpbmcoKS5pbmNsdWRlcyhzZWFyY2hUZXJtKSB8fFxyXG4gICAgICAgICAgZW5yb2xsLmdyb3VwX25hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRGaWx0ZXJlZEVucm9sbHMoZmlsdGVyZWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRFbnJvbGxzKFRhYmxlRW5yb2xscyk7XHJcbiAgICB9XHJcbiAgfSwgW3NlYXJjaFRlcm0sIFRhYmxlRW5yb2xsc10pO1xyXG5cclxuICAvLyBDb250YWN0IFN1bW1hcnkgRGFzaGJvYXJkIENvbXBvbmVudFxyXG4gIGNvbnN0IENvbnRhY3RTdW1tYXJ5RGFzaGJvYXJkID0gKCkgPT4ge1xyXG4gICAgY29uc3QgY291bnRzID0gZ2V0U3RhdHVzQ291bnRzKCk7XHJcbiAgICBjb25zdCBwZW5kaW5nQ291bnQgPSBmaWx0ZXJlZEVucm9sbHMuZmlsdGVyKFxyXG4gICAgICAodSkgPT4gdS5zdGF0dXMgPT09IFwiTm90IENvbnRhY3RlZFwiIHx8ICF1LnN0YXR1cyxcclxuICAgICkubGVuZ3RoO1xyXG4gICAgY29uc3QgY29udmVyc2lvblJhdGUgPVxyXG4gICAgICBjb3VudHMudG90YWwgPiAwXHJcbiAgICAgICAgPyAoKGNvdW50cy5Db252ZXJ0ZWQgLyBjb3VudHMudG90YWwpICogMTAwKS50b0ZpeGVkKDEpXHJcbiAgICAgICAgOiBcIjAuMFwiO1xyXG4gICAgY29uc3QgcmVqZWN0aW9uUmF0ZSA9XHJcbiAgICAgIGNvdW50cy50b3RhbCA+IDBcclxuICAgICAgICA/ICgoY291bnRzLlJlamVjdGVkIC8gY291bnRzLnRvdGFsKSAqIDEwMCkudG9GaXhlZCgxKVxyXG4gICAgICAgIDogXCIwLjBcIjtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNSBtYi02XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgZ2FwLTMgbWItNVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLWluZGlnby02MDAgcm91bmRlZC14bCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS0yMDBcIj5cclxuICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01XCJcclxuICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgZD1cIk05IDE5di02YTIgMiAwIDAwLTItMkg1YTIgMiAwIDAwLTIgMnY2YTIgMiAwIDAwMiAyaDJhMiAyIDAgMDAyLTJ6bTAgMFY5YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJ2MTBtLTYgMGEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0ybTAgMFY1YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJ2MTRhMiAyIDAgMDEtMiAyaC0yYTIgMiAwIDAxLTItMnpcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgQ29udGFjdCBTdW1tYXJ5XHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgIE92ZXJ2aWV3IG9mIG1vYmlsZSBlbnJvbGxtZW50IGZvbGxvdy11cCB3b3JrXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAge3BhcnNlRmxvYXQoY29udmVyc2lvblJhdGUpID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWVtZXJhbGQtNTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCByb3VuZGVkLWZ1bGwgcHgtMyBweS0xLjVcIj5cclxuICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMTMgN2g4bTAgMHY4bTAtOGwtOCA4LTQtNC02IDZcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtjb252ZXJzaW9uUmF0ZX0lIGNvbnZlcnNpb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge3BhcnNlRmxvYXQocmVqZWN0aW9uUmF0ZSkgPiAwICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTIwMCByb3VuZGVkLWZ1bGwgcHgtMyBweS0xLjVcIj5cclxuICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1yZWQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgZD1cIk0xMyAxN2g4bTAgMFY5bTAgOGwtOC04LTQgNC02LTZcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAge3JlamVjdGlvblJhdGV9JSByZWplY3Rpb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTUgZ2FwLTMgbWItNVwiPlxyXG4gICAgICAgICAge01PQklMRV9FTlJPTExfU1RBVFVTX0NPTkZJRy5tYXAoKGNmZykgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBjb3VudCA9IGNvdW50c1tjZmcua2V5XTtcclxuICAgICAgICAgICAgY29uc3QgcGVyY2VudGFnZSA9XHJcbiAgICAgICAgICAgICAgY291bnRzLnRvdGFsID4gMCA/ICgoY291bnQgLyBjb3VudHMudG90YWwpICogMTAwKS50b0ZpeGVkKDApIDogMDtcclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBrZXk9e2NmZy5rZXl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNCBob3ZlcjpzaGFkb3ctbWQgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZ3JvdXAgY3Vyc29yLWRlZmF1bHQgJHtjb3VudCA9PT0gMCA/IFwib3BhY2l0eS01MFwiIDogXCJcIn1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTIwIGgtMjAgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLWJyICR7Y2ZnLmNvbG9yfSBvcGFjaXR5LVswLjA3XSAtdHJhbnNsYXRlLXktMS8yIHRyYW5zbGF0ZS14LTEvMiBncm91cC1ob3ZlcjpvcGFjaXR5LVswLjEyXSB0cmFuc2l0aW9uLW9wYWNpdHlgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctOSBoLTkgcm91bmRlZC1sZyAke2NmZy5iZ0xpZ2h0fSAke2NmZy5pY29uQ29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTMgcmluZy0xICR7Y2ZnLnJpbmdDb2xvcn1gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2NmZy5pY29ufVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1ncmF5LTkwMCBsZWFkaW5nLW5vbmUgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjb3VudH1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjZmcubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xLjUgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tciAke2NmZy5jb2xvcn0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNzAwIGVhc2Utb3V0YH1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwZXJjZW50YWdlfSVgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCBtdC0xIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cGVyY2VudGFnZX0lXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfSl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgYmctc2xhdGUtNTAgcm91bmRlZC14bCBweC00IHB5LTIuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC82MFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1sZyBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTYwMCB0by1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgZD1cIk0xNyAyMGg1di0yYTMgMyAwIDAwLTUuMzU2LTEuODU3TTE3IDIwSDdtMTAgMHYtMmMwLS42NTYtLjEyNi0xLjI4My0uMzU2LTEuODU3TTcgMjBIMnYtMmEzIDMgMCAwMTUuMzU2LTEuODU3TTcgMjB2LTJjMC0uNjU2LjEyNi0xLjI4My4zNTYtMS44NTdtMCAwYTUuMDAyIDUuMDAyIDAgMDE5LjI4OCAwTTE1IDExYTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHpcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwIGxlYWRpbmctbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAge2NvdW50cy50b3RhbH1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgVG90YWwgUHJvY2Vzc2VkXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBiZy1hbWJlci01MCByb3VuZGVkLXhsIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItYW1iZXItMjAwLzYwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNTAwIHRvLW9yYW5nZS01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgZD1cIk0xMiA4djRsMyAzbTYtM2E5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWFtYmVyLTcwMCBsZWFkaW5nLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgIHtwZW5kaW5nQ291bnR9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYW1iZXItNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICBTdGlsbCBQZW5kaW5nXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtjb3VudHNbXCJGb2xsb3cgVXBcIl0gPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IGJnLXB1cnBsZS01MCByb3VuZGVkLXhsIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItcHVycGxlLTIwMC82MFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwMCB0by1wdXJwbGUtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTRcIlxyXG4gICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICBkPVwiTTE1IDE3aDVsLTEuNDA1LTEuNDA1QTIuMDMyIDIuMDMyIDAgMDExOCAxNC4xNThWMTFhNi4wMDIgNi4wMDIgMCAwMC00LTUuNjU5VjVhMiAyIDAgMTAtNCAwdi4zNDFDNy42NyA2LjE2NSA2IDguMzg4IDYgMTF2My4xNTljMCAuNTM4LS4yMTQgMS4wNTUtLjU5NSAxLjQzNkw0IDE3aDVtNiAwdjFhMyAzIDAgMTEtNiAwdi0xbTYgMEg5XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtcHVycGxlLTcwMCBsZWFkaW5nLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAge2NvdW50c1tcIkZvbGxvdyBVcFwiXX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcHVycGxlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICBGb2xsb3cgVXBzIER1ZVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IG1sLWF1dG9cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwIGxlYWRpbmctbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkRW5yb2xscy5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICAgICAgID8gKChjb3VudHMudG90YWwgLyBmaWx0ZXJlZEVucm9sbHMubGVuZ3RoKSAqIDEwMCkudG9GaXhlZCgxKVxyXG4gICAgICAgICAgICAgICAgICA6IFwiMC4wXCJ9XHJcbiAgICAgICAgICAgICAgICAlXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgIFByb2Nlc3MgUmF0ZVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy0xMiBoLTEyXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgLXJvdGF0ZS05MFwiIHZpZXdCb3g9XCIwIDAgMzYgMzZcIj5cclxuICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgIGQ9XCJNMTggMi4wODQ1IGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgMzEuODMxIGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgLTMxLjgzMVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiI2YxZjVmOVwiXHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiM1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgZD1cIk0xOCAyLjA4NDUgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAzMS44MzEgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAtMzEuODMxXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJ1cmwoI3Byb2dyZXNzR3JhZGllbnQpXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIzXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtgJHtmaWx0ZXJlZEVucm9sbHMubGVuZ3RoID4gMCA/IChjb3VudHMudG90YWwgLyBmaWx0ZXJlZEVucm9sbHMubGVuZ3RoKSAqIDEwMCA6IDB9LCAxMDBgfVxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkZWZzPlxyXG4gICAgICAgICAgICAgICAgICA8bGluZWFyR3JhZGllbnRcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInByb2dyZXNzR3JhZGllbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHgxPVwiMCVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHkxPVwiMCVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHgyPVwiMTAwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgeTI9XCIwJVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwJVwiIHN0b3BDb2xvcj1cIiM2MzY2ZjFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjEwMCVcIiBzdG9wQ29sb3I9XCIjM2I4MmY2XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cclxuICAgICAgICAgICAgICAgIDwvZGVmcz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIE9wZW4gc3RhdHVzIHVwZGF0ZSBtb2RhbCAoc2luZ2xlKVxyXG4gIGNvbnN0IG9wZW5TdGF0dXNVcGRhdGVNb2RhbCA9IChlbnJvbGwpID0+IHtcclxuICAgIHNldFN0YXR1c1VwZGF0ZURhdGEoe1xyXG4gICAgICBfaWQ6IGVucm9sbC5faWQsXHJcbiAgICAgIHN0YXR1czogZW5yb2xsLnN0YXR1cyB8fCBcIlwiLFxyXG4gICAgICByZW1hcms6IGVucm9sbC5yZW1hcmsgfHwgXCJcIixcclxuICAgICAgZm9sbG93X3VwX2RhdGU6IGVucm9sbC5mb2xsb3dfdXBfZGF0ZSB8fCBcIlwiLFxyXG4gICAgICBpc0J1bGs6IGZhbHNlLFxyXG4gICAgICBzZWxlY3RlZElkczogW2Vucm9sbC5faWRdLFxyXG4gICAgfSk7XHJcbiAgICBzZXRTaG93U3RhdHVzVXBkYXRlTW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIHN0YXR1cyB1cGRhdGUgc3VibWl0IC0gU3VwcG9ydHMgYm90aCBzaW5nbGUgYW5kIGJ1bGsgdXBkYXRlc1xyXG4gIGNvbnN0IGhhbmRsZVN0YXR1c1VwZGF0ZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHsgX2lkLCBzdGF0dXMsIHJlbWFyaywgZm9sbG93X3VwX2RhdGUsIGlzQnVsaywgc2VsZWN0ZWRJZHMgfSA9XHJcbiAgICAgIHN0YXR1c1VwZGF0ZURhdGE7XHJcblxyXG4gICAgaWYgKCFzdGF0dXMpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGEgc3RhdHVzLlwiLFxyXG4gICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKHN0YXR1cyA9PT0gXCJGb2xsb3cgVXBcIiAmJiAhZm9sbG93X3VwX2RhdGUpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGEgZm9sbG93LXVwIGRhdGUuXCIsXHJcbiAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNTdGF0dXNVcGRhdGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIERldGVybWluZSB3aGljaCBJRHMgdG8gdXBkYXRlXHJcbiAgICAgIGNvbnN0IGlkc1RvVXBkYXRlID0gaXNCdWxrID8gc2VsZWN0ZWRJZHMgOiBbX2lkXTtcclxuXHJcbiAgICAgIC8vIENyZWF0ZSBhbiBhcnJheSBvZiBwcm9taXNlcyBmb3IgYWxsIHVwZGF0ZXNcclxuICAgICAgY29uc3QgdXBkYXRlUHJvbWlzZXMgPSBpZHNUb1VwZGF0ZS5tYXAoKGlkKSA9PlxyXG4gICAgICAgIGFwaS5wdXQoYC9tb2JpbGUtYXBwLWVucm9sbC92ZXJpZnktZW5yb2xsLyR7aWR9YCwge1xyXG4gICAgICAgICAgc3RhdHVzLFxyXG4gICAgICAgICAgcmVtYXJrOiByZW1hcmsgfHwgXCJcIixcclxuICAgICAgICAgIGZvbGxvd191cF9kYXRlOiBzdGF0dXMgPT09IFwiRm9sbG93IFVwXCIgPyBmb2xsb3dfdXBfZGF0ZSA6IFwiXCIsXHJcbiAgICAgICAgfSksXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBFeGVjdXRlIGFsbCB1cGRhdGVzIGluIHBhcmFsbGVsXHJcbiAgICAgIGF3YWl0IFByb21pc2UuYWxsKHVwZGF0ZVByb21pc2VzKTtcclxuXHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGlzQnVsa1xyXG4gICAgICAgICAgPyBgJHtpZHNUb1VwZGF0ZS5sZW5ndGh9IGVucm9sbG1lbnRzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IWBcclxuICAgICAgICAgIDogXCJTdGF0dXMgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsKGZhbHNlKTtcclxuICAgICAgLy8gQ2xlYXIgc2VsZWN0aW9uIGFmdGVyIHN1Y2Nlc3NmdWwgdXBkYXRlXHJcbiAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgICBmZXRjaEFsbEVucm9sbG1lbnREYXRhKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiVXBkYXRlIGVycm9yOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHVwZGF0ZSBzdGF0dXMuXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3RhdHVzVXBkYXRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IEFjdGlvbkRyb3Bkb3duID0gKHsgZW5yb2xsIH0pID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiPT09IEFjdGlvbkRyb3Bkb3duIGVucm9sbCBkYXRhID09PVwiLCBlbnJvbGwpO1xyXG4gICAgY29uc29sZS5sb2coXCJ1c2VyX2lkOlwiLCBlbnJvbGwudXNlcl9pZCk7XHJcbiAgICBjb25zb2xlLmxvZyhcImdyb3VwX2lkOlwiLCBlbnJvbGwuZ3JvdXBfaWQpO1xyXG4gICAgY29uc29sZS5sb2coXCJfaWQ6XCIsIGVucm9sbC5faWQpO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUVucm9sbENsaWNrV3JhcHBlciA9ICgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCI9PT0gQXBwcm92ZSBidXR0b24gY2xpY2tlZCBmb3IgZW5yb2xsbWVudCA9PT1cIiwgZW5yb2xsKTtcclxuICAgICAgaGFuZGxlRW5yb2xsQ2xpY2soZW5yb2xsKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGtleTogXCJzdGF0dXNcIixcclxuICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIHB4LTIgcHktMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5TdGF0dXNVcGRhdGVNb2RhbChlbnJvbGwpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTEgNUg2YTIgMiAwIDAwLTIgMnYxMWEyIDIgMCAwMDIgMmgxMWEyIDIgMCAwMDItMnYtNW0tMS40MTQtOS40MTRhMiAyIDAgMTEyLjgyOCAyLjgyOEwxMS44MjggMTVIOXYtMi44MjhsOC41ODYtOC41ODZ6XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIFN0YXR1c1xyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXIgcHgtMiBweS0xXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGVucm9sbC5faWQpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXIgcHgtMiBweS0xXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGVucm9sbC5faWQpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXIgcHgtMiBweS0xXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRW5yb2xsQ2xpY2tXcmFwcGVyfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBcHByb3ZlXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgXSxcclxuICAgICAgICB9fVxyXG4gICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZCBjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuICAgICAgPC9Ecm9wZG93bj5cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgLy8gUmVuZGVyIGVucm9sbG1lbnQgY2FyZCBmb3IgZ3JpZCB2aWV3IC0gV0lUSCBDSEVDS0JPWFxyXG4gIGNvbnN0IHJlbmRlckVucm9sbG1lbnRDYXJkID0gKGVucm9sbCkgPT4ge1xyXG4gICAgY29uc3QgaXNQZW5kaW5nID0gZW5yb2xsLnN0YXR1cyA9PT0gXCJOb3QgQ29udGFjdGVkXCIgfHwgIWVucm9sbC5zdGF0dXM7XHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcInBlbmRpbmdcIiAmJiAhaXNQZW5kaW5nKSByZXR1cm4gbnVsbDtcclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIgJiYgaXNQZW5kaW5nKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBzZWxlY3RlZEVucm9sbG1lbnRzLmluY2x1ZGVzKGVucm9sbC5faWQpO1xyXG5cclxuICAgIC8vIENPTlRBQ1RFRCBUQUIg4oCUIFJpY2ggd29yay1zdGF0dXMgY2FyZFxyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjb250YWN0ZWRcIikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGtleT17ZW5yb2xsLl9pZH1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIHJlbGF0aXZlIGJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBzaGFkb3ctc20gaG92ZXI6c2hhZG93LWxnIGhvdmVyOi10cmFuc2xhdGUteS0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xyXG4gICAgICAgICAgICBpc1NlbGVjdGVkXHJcbiAgICAgICAgICAgICAgPyBcImJvcmRlci12aW9sZXQtNDAwIHJpbmctMiByaW5nLXZpb2xldC0xMDAgc2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICA6IFwiYm9yZGVyLWJsdWUtMjAwXCJcclxuICAgICAgICAgIH1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctZnVsbCBoLTEuNSByb3VuZGVkLXQtMnhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB0by1pbmRpZ28tNTAwIG9wYWNpdHktOTBcIiAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcHQtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlU2VsZWN0RW5yb2xsbWVudChlbnJvbGwuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLWluZGlnby0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1pbmRpZ28tNzAwIGZvbnQtYm9sZCB0ZXh0LXNtIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAge2Vucm9sbC5uYW1lPy5jaGFyQXQoMCk/LnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgdHJ1bmNhdGUgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlbnJvbGwubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vucm9sbC5tb2JpbGVfZW5yb2xsX2NvZGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgIDxBY3Rpb25Ecm9wZG93biBlbnJvbGw9e2Vucm9sbH0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtMi41XCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBob25lXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAge2Vucm9sbC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yLjVcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTAuNSB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZW5yb2xsLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTUwIHRvLWJsdWUtNTAvNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBwLTQgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICBkPVwiTTkgNUg3YTIgMiAwIDAwLTIgMnYxMGEyIDIgMCAwMDIgMmg4YTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0yaC0yTTkgNWEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0yTTkgNWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgV29yayBTdGF0dXNcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkICR7Z2V0U3RhdHVzQ29sb3IoZW5yb2xsLnN0YXR1cyl9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2dldFN0YXR1c0ljb24oZW5yb2xsLnN0YXR1cyl9XHJcbiAgICAgICAgICAgICAgICAgIHtlbnJvbGwuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWVtZXJhbGQtNjAwLzIwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlbnJvbGwubm9fb2ZfdGlja2V0c30gdGlja2V0c1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7ZW5yb2xsLnJlbWFyayAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlbWFya1xyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLnJlbWFya31cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICB7ZW5yb2xsLnJlZmVycmVkX2J5ICYmIGVucm9sbC5yZWZlcnJlZF9ieSAhPT0gXCJOL0FcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTIuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBCeVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmRpZ28tNzAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLnJlZmVycmVkX2J5fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2Vucm9sbC5mb2xsb3dfdXBfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgcC0yLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1wdXJwbGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZvbGxvdyBVcCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOCA3VjNtOCA0VjNtLTkgOGgxME01IDIxaDE0YTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyelwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLmZvbGxvd191cF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgIEVucm9sbGVkOiB7ZW5yb2xsLmVucm9sbG1lbnRfZGF0ZX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUEVORElORyBUQUIgLSBXSVRIIENIRUNLQk9YXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAga2V5PXtlbnJvbGwuX2lkfVxyXG4gICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIHJlbGF0aXZlIGJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBzaGFkb3ctc20gaG92ZXI6c2hhZG93LXhsIGhvdmVyOi10cmFuc2xhdGUteS0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xyXG4gICAgICAgICAgaXNTZWxlY3RlZFxyXG4gICAgICAgICAgICA/IFwiYm9yZGVyLXZpb2xldC00MDAgcmluZy0yIHJpbmctdmlvbGV0LTEwMCBzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMjAwXCJcclxuICAgICAgICB9YH1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctZnVsbCBoLTEuNSByb3VuZGVkLXQtMnhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1hbWJlci00MDAgdG8tb3JhbmdlLTUwMCBvcGFjaXR5LTgwXCIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBwdC02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZVNlbGVjdEVucm9sbG1lbnQoZW5yb2xsLl9pZCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1hbWJlci03MDAgZm9udC1ib2xkIHRleHQtc20gZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAge2Vucm9sbC5uYW1lPy5jaGFyQXQoMCk/LnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgdHJ1bmNhdGUgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICB7ZW5yb2xsLm5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlbnJvbGwubW9iaWxlX2Vucm9sbF9jb2RlfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPEFjdGlvbkRyb3Bkb3duIGVucm9sbD17ZW5yb2xsfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIG1iLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yLjVcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICBQaG9uZVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgIHtlbnJvbGwucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtMi41XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMC41IHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICB7ZW5yb2xsLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1ncmF5LTUwMCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgcHQtMyBtdC0xXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgZm9udC1tZWRpdW0gYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1hbWJlci02MDAvMjBcIj5cclxuICAgICAgICAgICAgICBOb3QgQ29udGFjdGVkXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiXHJcbiAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgIGQ9XCJNOCA3VjNtOCA0VjNtLTkgOGgxME01IDIxaDE0YTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyelwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIHtlbnJvbGwuZW5yb2xsbWVudF9kYXRlfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIExpc3QgdmlldyByb3cgLSBXSVRIIENIRUNLQk9YXHJcbiAgY29uc3QgRW5yb2xsUm93ID0gKHsgZW5yb2xsIH0pID0+IHtcclxuICAgIGNvbnN0IGlzUGVuZGluZyA9IGVucm9sbC5zdGF0dXMgPT09IFwiTm90IENvbnRhY3RlZFwiIHx8ICFlbnJvbGwuc3RhdHVzO1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJwZW5kaW5nXCIgJiYgIWlzUGVuZGluZykgcmV0dXJuIG51bGw7XHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcImNvbnRhY3RlZFwiICYmIGlzUGVuZGluZykgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRFbnJvbGxtZW50cy5pbmNsdWRlcyhlbnJvbGwuX2lkKTtcclxuXHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcImNvbnRhY3RlZFwiKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAga2V5PXtlbnJvbGwuX2lkfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1sZyBob3Zlcjpib3JkZXItYmx1ZS0zMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlbiAke1xyXG4gICAgICAgICAgICBpc1NlbGVjdGVkXHJcbiAgICAgICAgICAgICAgPyBcImJvcmRlci12aW9sZXQtNDAwIHJpbmctMiByaW5nLXZpb2xldC0xMDBcIlxyXG4gICAgICAgICAgICAgIDogXCJib3JkZXItYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgfWB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtNCBwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB3LWZ1bGwgc206dy1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZVNlbGVjdEVucm9sbG1lbnQoZW5yb2xsLl9pZCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtaW5kaWdvLTcwMCBmb250LWJvbGQgdGV4dC1zbSBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICB7ZW5yb2xsLm5hbWU/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTEgZmxleC13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vucm9sbC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCAke2dldFN0YXR1c0NvbG9yKGVucm9sbC5zdGF0dXMpfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzSWNvbihlbnJvbGwuc3RhdHVzKX1cclxuICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctZW1lcmFsZC02MDAvMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLm5vX29mX3RpY2tldHN9IHRpY2tldHNcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAge2Vucm9sbC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWwtMCBzbTptbC1hdXRvIHctZnVsbCBzbTp3LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQtY2VudGVyIG1pbi13LVsxMDBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC12aW9sZXQtNTAwIGZvbnQtbWVkaXVtXCI+UGhvbmU8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC05MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Vucm9sbC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICA8QWN0aW9uRHJvcGRvd24gZW5yb2xsPXtlbnJvbGx9IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtNTAgdG8tYmx1ZS01MC80MCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIHB4LTQgcHktM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAge2Vucm9sbC5yZW1hcmsgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIGZsZXgtMSBtaW4tdy1bMjAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleC1zaHJpbmstMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZW1hcms6XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLnJlbWFya31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7ZW5yb2xsLnJlZmVycmVkX2J5ICYmIGVucm9sbC5yZWZlcnJlZF9ieSAhPT0gXCJOL0FcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctd2hpdGUgcm91bmRlZC1mdWxsIHB4LTMgcHktMS41IGJvcmRlciBib3JkZXItaW5kaWdvLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5kaWdvLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZmVycmVkOiB7ZW5yb2xsLnJlZmVycmVkX2J5fVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtlbnJvbGwuZm9sbG93X3VwX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXdoaXRlIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEuNSBib3JkZXIgYm9yZGVyLXB1cnBsZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOCA3VjNtOCA0VjNtLTkgOGgxME01IDIxaDE0YTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyelwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1wdXJwbGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vucm9sbC5mb2xsb3dfdXBfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBtbC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICBFbnJvbGxlZDoge2Vucm9sbC5lbnJvbGxtZW50X2RhdGV9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXZcclxuICAgICAgICBrZXk9e2Vucm9sbC5faWR9XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1sZyBob3Zlcjpib3JkZXItZ3JheS0zMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlbiAke1xyXG4gICAgICAgICAgaXNTZWxlY3RlZFxyXG4gICAgICAgICAgICA/IFwiYm9yZGVyLXZpb2xldC00MDAgcmluZy0yIHJpbmctdmlvbGV0LTEwMFwiXHJcbiAgICAgICAgICAgIDogXCJib3JkZXItZ3JheS0xMDBcIlxyXG4gICAgICAgIH1gfVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtNCBwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgdy1mdWxsIHNtOnctYXV0b1wiPlxyXG4gICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBoYW5kbGVTZWxlY3RFbnJvbGxtZW50KGVucm9sbC5faWQpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctYW1iZXItMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYW1iZXItNzAwIGZvbnQtYm9sZCB0ZXh0LXNtIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICB7ZW5yb2xsLm5hbWU/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlbnJvbGwubmFtZX1cclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1hbWJlci02MDAvMjBcIj5cclxuICAgICAgICAgICAgICAgICAgUGVuZGluZ1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAge2Vucm9sbC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1sLTAgc206bWwtYXV0byB3LWZ1bGwgc206dy1hdXRvXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LWNlbnRlciBtaW4tdy1bMTAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWFtYmVyLTUwMCBmb250LW1lZGl1bVwiPlBob25lPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtYW1iZXItOTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7ZW5yb2xsLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LWNlbnRlciBtaW4tdy1bOTBweF0gYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPkVucm9sbGVkPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIHtlbnJvbGwuZW5yb2xsbWVudF9kYXRlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgIDxBY3Rpb25Ecm9wZG93biBlbnJvbGw9e2Vucm9sbH0gLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIFNpbXBsZSBQYWdpbmF0aW9uXHJcbiAgY29uc3QgU2ltcGxlUGFnaW5hdGlvbiA9ICh7IGN1cnJlbnRQYWdlLCB0b3RhbFBhZ2VzLCBvblBhZ2VDaGFuZ2UgfSkgPT4ge1xyXG4gICAgaWYgKHRvdGFsUGFnZXMgPD0gMSkgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBwYWdlcyA9IFtdO1xyXG4gICAgY29uc3QgbWF4ID0gNTtcclxuICAgIHBhZ2VzLnB1c2goMSk7XHJcbiAgICBpZiAodG90YWxQYWdlcyA+IG1heCkge1xyXG4gICAgICBpZiAoY3VycmVudFBhZ2UgPiAzKSBwYWdlcy5wdXNoKFwiLi4uXCIpO1xyXG4gICAgICBmb3IgKFxyXG4gICAgICAgIGxldCBpID0gTWF0aC5tYXgoMiwgY3VycmVudFBhZ2UgLSAxKTtcclxuICAgICAgICBpIDw9IE1hdGgubWluKHRvdGFsUGFnZXMgLSAxLCBjdXJyZW50UGFnZSArIDEpO1xyXG4gICAgICAgIGkrK1xyXG4gICAgICApIHtcclxuICAgICAgICBpZiAoaSAhPT0gMSAmJiBpICE9PSB0b3RhbFBhZ2VzKSBwYWdlcy5wdXNoKGkpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChjdXJyZW50UGFnZSA8IHRvdGFsUGFnZXMgLSAyKSBwYWdlcy5wdXNoKFwiLi4uXCIpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChsZXQgaSA9IDI7IGkgPD0gdG90YWxQYWdlczsgaSsrKSBwYWdlcy5wdXNoKGkpO1xyXG4gICAgfVxyXG4gICAgaWYgKHRvdGFsUGFnZXMgPiAxKSBwYWdlcy5wdXNoKHRvdGFsUGFnZXMpO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBtdC04XCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25QYWdlQ2hhbmdlKGN1cnJlbnRQYWdlIC0gMSl9XHJcbiAgICAgICAgICBkaXNhYmxlZD17Y3VycmVudFBhZ2UgPT09IDF9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6c2hhZG93LXNtIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICBQcmV2XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAge3BhZ2VzLm1hcCgocGFnZSwgaSkgPT4gKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9e2l9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHR5cGVvZiBwYWdlID09PSBcIm51bWJlclwiICYmIG9uUGFnZUNoYW5nZShwYWdlKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e3R5cGVvZiBwYWdlICE9PSBcIm51bWJlclwifVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LTEwIGgtMTAgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7cGFnZSA9PT0gY3VycmVudFBhZ2UgPyBcImJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LXZpb2xldC0yMDBcIiA6IHR5cGVvZiBwYWdlID09PSBcIm51bWJlclwiID8gXCJiZy13aGl0ZSB0ZXh0LWdyYXktNzAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgaG92ZXI6YmctZ3JheS01MCBob3ZlcjpzaGFkb3ctc21cIiA6IFwiYmctd2hpdGUgdGV4dC1ncmF5LTQwMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGN1cnNvci1kZWZhdWx0XCJ9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3BhZ2V9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApKX1cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UoY3VycmVudFBhZ2UgKyAxKX1cclxuICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50UGFnZSA9PT0gdG90YWxQYWdlc31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JheS01MCBob3ZlcjpzaGFkb3ctc20gZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIE5leHRcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIFJlbmRlciB1c2VycyBiYXNlZCBvbiB2aWV3IG1vZGUgYW5kIHRhYiAtIFdJVEggU0VMRUNUIEFMTCBIRUFERVJcclxuICBjb25zdCByZW5kZXJFbnJvbGxzID0gKCkgPT4ge1xyXG4gICAgaWYgKGlzRGF0YVRhYmxlTG9hZGluZykge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgaXNMb2FkaW5nPXtpc0RhdGFUYWJsZUxvYWRpbmd9XHJcbiAgICAgICAgICBmYWlsdXJlPXtmYWxzZX1cclxuICAgICAgICAgIGRhdGE9XCJFbnJvbGxtZW50IERhdGFcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdGFiRmlsdGVyZWRFbnJvbGxzID0gZ2V0VGFiRmlsdGVyZWRFbnJvbGxzKCk7XHJcbiAgICBjb25zdCB0YWJJbmRleE9mTGFzdEl0ZW0gPSBjdXJyZW50UGFnZSAqIGl0ZW1zUGVyUGFnZTtcclxuICAgIGNvbnN0IHRhYkluZGV4T2ZGaXJzdEl0ZW0gPSB0YWJJbmRleE9mTGFzdEl0ZW0gLSBpdGVtc1BlclBhZ2U7XHJcbiAgICBjb25zdCB0YWJDdXJyZW50SXRlbXMgPSB0YWJGaWx0ZXJlZEVucm9sbHMuc2xpY2UoXHJcbiAgICAgIHRhYkluZGV4T2ZGaXJzdEl0ZW0sXHJcbiAgICAgIHRhYkluZGV4T2ZMYXN0SXRlbSxcclxuICAgICk7XHJcbiAgICBjb25zdCB0YWJUb3RhbFBhZ2VzID0gTWF0aC5jZWlsKHRhYkZpbHRlcmVkRW5yb2xscy5sZW5ndGggLyBpdGVtc1BlclBhZ2UpO1xyXG5cclxuICAgIGlmICghdGFiRmlsdGVyZWRFbnJvbGxzLmxlbmd0aCkge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tZnVsbCBweS0yMCBiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctc20gdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTMwMCBteC1hdXRvIG1iLTRcIj5cclxuICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgaC0xNiBteC1hdXRvXCJcclxuICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgICAgICAgICBkPVwiTTE3IDIwaDV2LTJhMyAzIDAgMDAtNS4zNTYtMS44NTdNMTcgMjBIN20xMCAwdi0yYzAtLjY1Ni0uMTI2LTEuMjgzLS4zNTYtMS44NTdNNyAyMEgydi0yYTMgMyAwIDAxNS4zNTYtMS44NTdNNyAyMHYtMmMwLS42NTYuMTI2LTEuMjgzLjM1Ni0xLjg1N20wIDBhNS4wMDIgNS4wMDIgMCAwMTkuMjg4IDBNMTUgMTFhMyAzIDAgMTEtNiAwIDMgMyAwIDAxNiAwem02IDJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJwZW5kaW5nXCJcclxuICAgICAgICAgICAgICA/IFwiTm8gcGVuZGluZyBlbnJvbGxtZW50cyBmb3VuZFwiXHJcbiAgICAgICAgICAgICAgOiBcIk5vIGNvbnRhY3RlZCBlbnJvbGxtZW50cyBmb3VuZFwifVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNDAwIG10LTFcIj5cclxuICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJwZW5kaW5nXCJcclxuICAgICAgICAgICAgICA/IFwiQWxsIGVucm9sbG1lbnRzIGhhdmUgYmVlbiBjb250YWN0ZWRcIlxyXG4gICAgICAgICAgICAgIDogXCJUcnkgc3dpdGNoaW5nIHRvIHRoZSBQZW5kaW5nIHRhYiBvciBhZGp1c3QgeW91ciBzZWFyY2hcIn1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTRUxFQ1QgQUxMIEhFQURFUlxyXG4gICAgY29uc3QgU2VsZWN0aW9uSGVhZGVyID0gKCkgPT4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00IHB4LTJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0QWxsfVxyXG4gICAgICAgICAgICBpbmRldGVybWluYXRlPXtcclxuICAgICAgICAgICAgICBzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aCA+IDAgJiZcclxuICAgICAgICAgICAgICBzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aCA8IHRhYkZpbHRlcmVkRW5yb2xscy5sZW5ndGhcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50cy5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICAgPyBgJHtzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aH0gc2VsZWN0ZWRgXHJcbiAgICAgICAgICAgICAgOiBcIlNlbGVjdCBBbGxcIn1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICBpY29uPXtcclxuICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00XCJcclxuICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgZD1cIk0xMSA1SDZhMiAyIDAgMDAtMiAydjExYTIgMiAwIDAwMiAyaDExYTIgMiAwIDAwMi0ydi01bS0xLjQxNC05LjQxNGEyIDIgMCAxMTIuODI4IDIuODI4TDExLjgyOCAxNUg5di0yLjgyOGw4LjU4Ni04LjU4NnpcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVCdWxrU3RhdHVzVXBkYXRlfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIGhvdmVyOmJnLXZpb2xldC03MDAgYm9yZGVyLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBCdWxrIFVwZGF0ZSAoe3NlbGVjdGVkRW5yb2xsbWVudHMubGVuZ3RofSlcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAodmlld01vZGUgPT09IFwiZ3JpZFwiKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxTZWxlY3Rpb25IZWFkZXIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4gICAgICAgICAgICB7dGFiQ3VycmVudEl0ZW1zLm1hcChyZW5kZXJFbnJvbGxtZW50Q2FyZCl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8Lz5cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodmlld01vZGUgPT09IFwibGlzdFwiKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxTZWxlY3Rpb25IZWFkZXIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgIHt0YWJDdXJyZW50SXRlbXMubWFwKChlKSA9PiAoXHJcbiAgICAgICAgICAgICAgPEVucm9sbFJvdyBrZXk9e2UuaWR9IGVucm9sbD17ZX0gLz5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8Lz5cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBUYWJsZSB2aWV3IC0gV0lUSCBTRUxFQ1RJT04gQ09MVU1OXHJcbiAgICBjb25zdCB0YWJsZUNvbHVtbnMgPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6IFwic2VsZWN0aW9uXCIsXHJcbiAgICAgICAgaGVhZGVyOiAoXHJcbiAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0QWxsfVxyXG4gICAgICAgICAgICBpbmRldGVybWluYXRlPXtcclxuICAgICAgICAgICAgICBzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aCA+IDAgJiZcclxuICAgICAgICAgICAgICBzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aCA8IGdldFRhYkZpbHRlcmVkRW5yb2xscygpLmxlbmd0aFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICksXHJcbiAgICAgICAgcmVuZGVyOiAocmVjb3JkKSA9PiAoXHJcbiAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRFbnJvbGxtZW50cy5pbmNsdWRlcyhyZWNvcmQuX2lkKX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZVNlbGVjdEVucm9sbG1lbnQocmVjb3JkLl9pZCl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICksXHJcbiAgICAgIH0sXHJcbiAgICAgIC4uLmNvbHVtbnMsXHJcbiAgICBdO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1zbSBiZy13aGl0ZVwiPlxyXG4gICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgZGF0YT17VGFibGVFbnJvbGxzLmZpbHRlcigoZSkgPT5cclxuICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImNvbnRhY3RlZFwiXHJcbiAgICAgICAgICAgICAgPyBlLnN0YXR1cyAmJiBlLnN0YXR1cyAhPT0gXCJOb3QgQ29udGFjdGVkXCJcclxuICAgICAgICAgICAgICA6ICFlLnN0YXR1cyB8fCBlLnN0YXR1cyA9PT0gXCJOb3QgQ29udGFjdGVkXCIsXHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIk1vYmlsZUFwcEVucm9sbG1lbnRzXCJcclxuICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJNb2JpbGVBcHBFbnJvbGxtZW50cy5jc3ZcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFbnJvbGxDbGljayA9IChpdGVtKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcIj09PSBoYW5kbGVFbnJvbGxDbGljayBjYWxsZWQgd2l0aCBpdGVtID09PVwiLCBpdGVtKTtcclxuXHJcbiAgICBzZXRDdXJyZW50R3JvdXAoaXRlbSk7XHJcblxyXG4gICAgY29uc3QgdXNlcklkID0gaXRlbS51c2VyX2lkPy5faWQgfHwgXCJcIjtcclxuICAgIGNvbnN0IGdyb3VwSWQgPSBpdGVtLmdyb3VwX2lkPy5faWQgfHwgaXRlbS5ncm91cF9pZD8uaWQgfHwgXCJcIjtcclxuICAgIGNvbnN0IHJlZmVycmVkQ3VzdG9tZXJJZCA9IGl0ZW0ucmVmZXJyZWRfY3VzdG9tZXI/Ll9pZCB8fCBcIlwiO1xyXG4gICAgY29uc3QgcmVmZXJyZWRMZWFkSWQgPSBpdGVtLnJlZmVycmVkX2xlYWQ/Ll9pZCB8fCBcIlwiO1xyXG4gICAgY29uc3QgYWdlbnRJZCA9IGl0ZW0uYWdlbnQ/Ll9pZCB8fCBcIlwiO1xyXG5cclxuICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgdXNlcl9pZDogdXNlcklkLFxyXG4gICAgICBncm91cF9pZDogZ3JvdXBJZCxcclxuICAgICAgcGF5bWVudF90eXBlOiBpdGVtLnBheW1lbnRfdHlwZSB8fCBcIlwiLFxyXG4gICAgICByZWZlcnJlZF90eXBlOiBpdGVtLnJlZmVycmVkX3R5cGUgfHwgXCJcIixcclxuICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGl0ZW0uY2hpdF9hc2tpbmdfbW9udGggfHwgXCJcIixcclxuICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IHJlZmVycmVkQ3VzdG9tZXJJZCxcclxuICAgICAgcmVmZXJyZWRfbGVhZDogcmVmZXJyZWRMZWFkSWQsXHJcbiAgICAgIGFnZW50OiBhZ2VudElkLFxyXG4gICAgICBub19vZl90aWNrZXRzOiBpdGVtLm5vX29mX3RpY2tldHMgfHwgMSxcclxuICAgIH0pO1xyXG5cclxuICAgIHNldEVucm9sbG1lbnRTdGVwKFwidmVyaWZ5XCIpO1xyXG4gICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgY29uc3Qge1xyXG4gICAgICBub19vZl90aWNrZXRzLFxyXG4gICAgICBncm91cF9pZCxcclxuICAgICAgdXNlcl9pZCxcclxuICAgICAgcGF5bWVudF90eXBlLFxyXG4gICAgICByZWZlcnJlZF9jdXN0b21lcixcclxuICAgICAgcmVmZXJyZWRfdHlwZSxcclxuICAgICAgYWdlbnQsXHJcbiAgICAgIHJlZmVycmVkX2xlYWQsXHJcbiAgICAgIGNoaXRfYXNraW5nX21vbnRoLFxyXG4gICAgfSA9IGZvcm1EYXRhO1xyXG5cclxuICAgIGNvbnN0IHRpY2tldHNDb3VudCA9IHBhcnNlSW50KG5vX29mX3RpY2tldHMgfHwgMSwgMTApO1xyXG4gICAgY29uc3QgdGlja2V0RW50cmllcyA9IGF2YWlsYWJsZVRpY2tldHNBZGRcclxuICAgICAgLnNsaWNlKDAsIHRpY2tldHNDb3VudClcclxuICAgICAgLm1hcCgodGlja2V0TnVtYmVyKSA9PiAoe1xyXG4gICAgICAgIGdyb3VwX2lkLFxyXG4gICAgICAgIHVzZXJfaWQsXHJcbiAgICAgICAgcGF5bWVudF90eXBlLFxyXG4gICAgICAgIHJlZmVycmVkX3R5cGUsXHJcbiAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGZvcm1EYXRhLmNoaXRfYXNraW5nX21vbnRoLFxyXG4gICAgICAgIHJlZmVycmVkX2N1c3RvbWVyLFxyXG4gICAgICAgIHJlZmVycmVkX2xlYWQsXHJcbiAgICAgICAgYWdlbnQsXHJcbiAgICAgICAgbm9fb2ZfdGlja2V0czogdGlja2V0c0NvdW50LFxyXG4gICAgICAgIHRpY2tldHM6IHRpY2tldE51bWJlcixcclxuICAgICAgfSkpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGZvciAoY29uc3QgdGlja2V0RW50cnkgb2YgdGlja2V0RW50cmllcykge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL2Vucm9sbC9hZGQtZW5yb2xsXCIsIHRpY2tldEVudHJ5LCB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChjdXJyZW50R3JvdXA/Ll9pZCkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoXHJcbiAgICAgICAgICBgL21vYmlsZS1hcHAtZW5yb2xsL2RlbGV0ZS1tb2JpbGUtYXBwLWVucm9sbC8ke2N1cnJlbnRHcm91cC5faWR9YCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgZGF0YTogeyBkZWxldGVkX2J5OiBhZG1pbiwgZGVsZXRlZF9hdDogbmV3IERhdGUoKSB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlVzZXIgRW5yb2xsZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgbm9fb2ZfdGlja2V0czogXCJcIixcclxuICAgICAgICByZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4gICAgICAgIHBheW1lbnRfdHlwZTogXCJcIixcclxuICAgICAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgICAgICBhZ2VudDogXCJcIixcclxuICAgICAgICByZWZlcnJlZF9sZWFkOiBcIlwiLFxyXG4gICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBcIlwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGZldGNoQWxsRW5yb2xsbWVudERhdGEoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBlbnJvbGxpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVucm9sbG1lbnQgZmFpbGVkXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoVXNlcnMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4gICAgICAgIHNldEFnZW50cyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBMZWFkc1wiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaExlYWRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9sZWFkL2dldC1sZWFkXCIpO1xyXG4gICAgICAgIHNldExlYWRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIExlYWRzXCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaExlYWRzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVWZXJpZnkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCB7XHJcbiAgICAgIHVzZXJfaWQsXHJcbiAgICAgIGdyb3VwX2lkLFxyXG4gICAgICBhZ2VudCxcclxuICAgICAgcmVmZXJyZWRfY3VzdG9tZXIsXHJcbiAgICAgIHJlZmVycmVkX2xlYWQsXHJcbiAgICAgIHJlZmVycmVkX3R5cGUsXHJcbiAgICB9ID0gZm9ybURhdGE7XHJcblxyXG4gICAgaWYgKCF1c2VyX2lkIHx8ICFncm91cF9pZCkge1xyXG4gICAgICBub3RpZmljYXRpb24ud2FybmluZyh7XHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGJvdGggR3JvdXAgYW5kIEN1c3RvbWVyIGJlZm9yZSB2ZXJpZnlpbmcuXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2dldC1lbnJvbGwtY2hlY2tgLCB7XHJcbiAgICAgICAgcGFyYW1zOiB7IHVzZXJfaWQsIGdyb3VwX2lkIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3Qgc2VsZWN0ZWRVc2VyID0gdXNlcnMuZmluZCgodSkgPT4gdS5faWQgPT09IHVzZXJfaWQpO1xyXG4gICAgICBjb25zdCBzZWxlY3RlZEdyb3VwID0gZ3JvdXBzLmZpbmQoKGcpID0+IGcuX2lkID09PSBncm91cF9pZCk7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkQWdlbnQgPSBhZ2VudHMuZmluZCgoYSkgPT4gYS5faWQgPT09IGFnZW50KTtcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRSZWZlcnJlZEN1c3RvbWVyID0gdXNlcnMuZmluZChcclxuICAgICAgICAodSkgPT4gdS5faWQgPT09IHJlZmVycmVkX2N1c3RvbWVyLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBzZWxlY3RlZFJlZmVycmVkTGVhZCA9IGxlYWRzPy5maW5kPy4oXHJcbiAgICAgICAgKGwpID0+IGwuX2lkID09PSByZWZlcnJlZF9sZWFkLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhKSB7XHJcbiAgICAgICAgY29uc3QgYWdlbnROYW1lID1cclxuICAgICAgICAgIHR5cGVvZiByZXNwb25zZS5kYXRhLmFnZW50ID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgICAgID8gcmVzcG9uc2UuZGF0YS5hZ2VudD8ubmFtZVxyXG4gICAgICAgICAgICA6IG51bGw7XHJcbiAgICAgICAgY29uc3QgcmVmZXJyZWRDdXN0b21lck5hbWUgPVxyXG4gICAgICAgICAgdHlwZW9mIHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfY3VzdG9tZXIgPT09IFwib2JqZWN0XCJcclxuICAgICAgICAgICAgPyByZXNwb25zZS5kYXRhLnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWVcclxuICAgICAgICAgICAgOiBudWxsO1xyXG4gICAgICAgIGNvbnN0IHJlZmVycmVkTGVhZE5hbWUgPVxyXG4gICAgICAgICAgdHlwZW9mIHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfbGVhZCA9PT0gXCJvYmplY3RcIlxyXG4gICAgICAgICAgICA/IHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lXHJcbiAgICAgICAgICAgIDogbnVsbDtcclxuXHJcbiAgICAgICAgY29uc3QgcmVmZXJyZWRJbmZvUGFydHMgPSBbXTtcclxuXHJcbiAgICAgICAgaWYgKGFnZW50TmFtZSlcclxuICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXHJcbiAgICAgICAgICAgIGAgQWxyZWFkeSByZWZlcnJlZCBieSBBZ2VudCBOYW1lOiAke2FnZW50TmFtZX1gLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVmZXJyZWRDdXN0b21lck5hbWUpXHJcbiAgICAgICAgICByZWZlcnJlZEluZm9QYXJ0cy5wdXNoKFxyXG4gICAgICAgICAgICBgIEFscmVhZHkgcmVmZXJyZWQgYnkgQ3VzdG9tZXIgTmFtZTogJHtyZWZlcnJlZEN1c3RvbWVyTmFtZX1gLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVmZXJyZWRMZWFkTmFtZSlcclxuICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXHJcbiAgICAgICAgICAgIGAgQWxyZWFkeSByZWZlcnJlZCBieSBMZWFkIE5hbWU6ICR7cmVmZXJyZWRMZWFkTmFtZX1gLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVmZXJyZWRJbmZvUGFydHMubGVuZ3RoID09PSAwKVxyXG4gICAgICAgICAgcmVmZXJyZWRJbmZvUGFydHMucHVzaChcIkVucm9sbG1lbnQgZXhpc3RzIHdpdGggbm8gcmVmZXJyYWwgaW5mby5cIik7XHJcblxyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIG5vX29mX3RpY2tldHM6IHJlc3BvbnNlPy5kYXRhPy5ub19vZl90aWNrZXRzID8/IHByZXYubm9fb2ZfdGlja2V0cyxcclxuICAgICAgICAgIHBheW1lbnRfdHlwZTogcmVzcG9uc2U/LmRhdGE/LnBheW1lbnRfdHlwZSA/PyBwcmV2LnBheW1lbnRfdHlwZSxcclxuICAgICAgICAgIHJlZmVycmVkX2N1c3RvbWVyOlxyXG4gICAgICAgICAgICByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfY3VzdG9tZXIgPz8gcHJldi5yZWZlcnJlZF9jdXN0b21lcixcclxuICAgICAgICAgIHJlZmVycmVkX2xlYWQ6IHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJlZF9sZWFkID8/IHByZXYucmVmZXJyZWRfbGVhZCxcclxuICAgICAgICAgIHJlZmVycmVkX3R5cGU6XHJcbiAgICAgICAgICAgIHByZXYucmVmZXJyZWRfdHlwZSB8fFxyXG4gICAgICAgICAgICByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfdHlwZSB8fFxyXG4gICAgICAgICAgICAocmVzcG9uc2UuZGF0YT8uYWdlbnRcclxuICAgICAgICAgICAgICA/IFwiQWdlbnRcIlxyXG4gICAgICAgICAgICAgIDogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgID8gXCJDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICA6IHJlc3BvbnNlLmRhdGE/LnJlZmVycmVkX2xlYWRcclxuICAgICAgICAgICAgICAgICAgPyBcIkxlYWRzXCJcclxuICAgICAgICAgICAgICAgICAgOiBcIlwiKSxcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGxldCBzZWxlY3RlZEJ5ID0gXCJVbmtub3duXCI7XHJcbiAgICAgICAgaWYgKHJlZmVycmVkX3R5cGUgPT09IFwiQWdlbnRcIilcclxuICAgICAgICAgIHNlbGVjdGVkQnkgPSBzZWxlY3RlZEFnZW50Py5uYW1lIHx8IFwiVW5rbm93biBBZ2VudFwiO1xyXG4gICAgICAgIGVsc2UgaWYgKHJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIilcclxuICAgICAgICAgIHNlbGVjdGVkQnkgPVxyXG4gICAgICAgICAgICBzZWxlY3RlZFJlZmVycmVkQ3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBcIlVua25vd24gQ3VzdG9tZXJcIjtcclxuICAgICAgICBlbHNlIGlmIChyZWZlcnJlZF90eXBlID09PSBcIkxlYWRzXCIpXHJcbiAgICAgICAgICBzZWxlY3RlZEJ5ID0gc2VsZWN0ZWRSZWZlcnJlZExlYWQ/LmxlYWRfbmFtZSB8fCBcIlVua25vd24gTGVhZFwiO1xyXG5cclxuICAgICAgICBzZXRJc0V4aXN0aW5nRW5yb2xsbWVudCh0cnVlKTtcclxuICAgICAgICBzZXRFbnJvbGxtZW50U3RlcChcImNvbnRpbnVlXCIpO1xyXG5cclxuICAgICAgICBub3RpZmljYXRpb24ud2FybmluZyh7XHJcbiAgICAgICAgICBtZXNzYWdlOiAoXHJcbiAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMS4yNXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBcIjEwcHhcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ3VzdG9tZXIgTmFtZTogXCJ7c2VsZWN0ZWRVc2VyPy5mdWxsX25hbWV9XCJcclxuICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICA8aHIgc3R5bGU9e3sgbWFyZ2luOiBcIjEwcHggMFwiLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNjY2NcIiB9fSAvPlxyXG4gICAgICAgICAgICAgIEdyb3VwIE5hbWU6IFwie3NlbGVjdGVkR3JvdXA/Lmdyb3VwX25hbWV9XCJcclxuICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICA8aHIgc3R5bGU9e3sgbWFyZ2luOiBcIjEwcHggMFwiLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNjY2NcIiB9fSAvPlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IChcclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMS4yNXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIHtyZWZlcnJlZEluZm9QYXJ0cy5tYXAoKHBhcnQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgICAge3BhcnR9XHJcbiAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICA8aHJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW46IFwiMTBweCAwXCIsIGJvcmRlclRvcDogXCIxcHggc29saWQgI2NjY1wiIH19XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICAgIGR1cmF0aW9uOiAzMCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRJc0V4aXN0aW5nRW5yb2xsbWVudCh0cnVlKTtcclxuICAgICAgICBzZXRJc1ZlcmlmaWVkKHRydWUpO1xyXG4gICAgICAgIHNldEVucm9sbG1lbnRTdGVwKFwiY29udGludWVcIik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnQoZmFsc2UpO1xyXG4gICAgICAgIHNldElzVmVyaWZpZWQodHJ1ZSk7XHJcbiAgICAgICAgc2V0RW5yb2xsbWVudFN0ZXAoXCJjb250aW51ZVwiKTtcclxuXHJcbiAgICAgICAgbm90aWZpY2F0aW9uLnN1Y2Nlc3Moe1xyXG4gICAgICAgICAgbWVzc2FnZTogYEVsaWdpYmxlIGZvciBFbnJvbGxtZW50YCxcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBgVXNlciBcIiR7c2VsZWN0ZWRVc2VyPy5mdWxsX25hbWV9XCIgY2FuIGJlIGVucm9sbGVkIGluIFwiJHtzZWxlY3RlZEdyb3VwPy5ncm91cF9uYW1lfVwiLmAsXHJcbiAgICAgICAgICBkdXJhdGlvbjogNixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJWZXJpZmljYXRpb24gZXJyb3I6XCIsIGVycik7XHJcbiAgICAgIG5vdGlmaWNhdGlvbi5lcnJvcih7XHJcbiAgICAgICAgbWVzc2FnZTogXCJFcnJvciBjaGVja2luZyBlbnJvbGxtZW50XCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU11bHRpU3RlcCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgaWYgKGVucm9sbG1lbnRTdGVwID09PSBcInZlcmlmeVwiKSB7XHJcbiAgICAgIGF3YWl0IGhhbmRsZVZlcmlmeSgpO1xyXG4gICAgfSBlbHNlIGlmIChlbnJvbGxtZW50U3RlcCA9PT0gXCJjb250aW51ZVwiKSB7XHJcbiAgICAgIHNldEVucm9sbG1lbnRTdGVwKFwic3VibWl0XCIpO1xyXG4gICAgfSBlbHNlIGlmIChlbnJvbGxtZW50U3RlcCA9PT0gXCJzdWJtaXRcIikge1xyXG4gICAgICBoYW5kbGVTdWJtaXQoZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgLi4ucHJldkVycm9ycyxcclxuICAgICAgW2ZpZWxkXTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBbnRJbnB1dERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuXHJcbiAgICBzZXRFcnJvcnMoeyAuLi5lcnJvcnMsIFtmaWVsZF06IFwiXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmb3JtRGF0YS5ncm91cF9pZCkge1xyXG4gICAgICBjb25zdCBmZXRjaFRpY2tldHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICAgIGAvZW5yb2xsL2dldC1uZXh0LXRpY2tldHMvJHtmb3JtRGF0YS5ncm91cF9pZH1gLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHNldEF2YWlsYWJsZVRpY2tldHNBZGQocmVzcG9uc2UuZGF0YS5hdmFpbGFibGVUaWNrZXRzIHx8IFtdKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIG5leHQgdGlja2V0czpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgc2V0QXZhaWxhYmxlVGlja2V0c0FkZChbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG4gICAgICBmZXRjaFRpY2tldHMoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEF2YWlsYWJsZVRpY2tldHNBZGQoW10pO1xyXG4gICAgfVxyXG4gIH0sIFtmb3JtRGF0YS5ncm91cF9pZF0pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJtb2JpbGVfZW5yb2xsX2NvZGVcIiwgaGVhZGVyOiBcIk1vYmlsZSBFbnJvbGwgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICBdO1xyXG4gIGlmIChhbGxFbnJvbGxVcmwpIHtcclxuICAgIGNvbHVtbnMucHVzaCh7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJFbnJvbGxlZCBHcm91cFwiIH0pO1xyXG4gIH1cclxuICBjb2x1bW5zLnB1c2goXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF90eXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbG1lbnRfZGF0ZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImNoaXRfYXNraW5nX21vbnRoXCIsIGhlYWRlcjogXCJDaGl0IEFza2luZyBNb250aFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF9ieVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAge2tleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIkNvbnRhY3QgU3RhdHVzXCJ9LFxyXG4gICAge2tleTogXCJmb2xsb3dfdXBfZGF0ZVwiLCBoZWFkZXI6IFwiRm9sbG93IFVwIERhdGVcIn0sXHJcbiAgICB7a2V5OiBcInJlbWFya1wiLCBoZWFkZXI6IFwiUmVtYXJrXCJ9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7IC4uLnByZXZFcnJvcnMsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGUgPSAodHlwZSkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBjb25zdCBkYXRhID0gdHlwZSA9PT0gXCJhZGRFbnJvbGxtZW50XCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG4gICAgY29uc3Qgbm9PZlRpY2tldHMgPSB0eXBlID09PSBcImFkZEVucm9sbG1lbnRcIiA/IFwibm9fb2ZfdGlja2V0c1wiIDogXCJ0aWNrZXRzXCI7XHJcbiAgICBpZiAoIWRhdGEuZ3JvdXBfaWQudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF9pZCA9IFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEudXNlcl9pZCkge1xyXG4gICAgICBuZXdFcnJvcnMudXNlcl9pZCA9IFwiUGxlYXNlIHNlbGVjdCBhIGN1c3RvbWVyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoID4gMCkge1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgIWRhdGFbbm9PZlRpY2tldHNdIHx8XHJcbiAgICAgICAgZGF0YVtub09mVGlja2V0c10gPD0gMCB8fFxyXG4gICAgICAgIGlzTmFOKGRhdGFbbm9PZlRpY2tldHNdKVxyXG4gICAgICApIHtcclxuICAgICAgICBuZXdFcnJvcnNbbm9PZlRpY2tldHNdID0gXCJQbGVhc2UgZW50ZXIgbnVtYmVyIG9mIHRpY2tldHNcIjtcclxuICAgICAgfSBlbHNlIGlmIChkYXRhW25vT2ZUaWNrZXRzXSA+IGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzW25vT2ZUaWNrZXRzXSA9XHJcbiAgICAgICAgICBgTWF4aW11bSAke2F2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RofSB0aWNrZXRzIGFsbG93ZWRgO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldlN0YXRlKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2U3RhdGUsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGVucm9sbElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9tb2JpbGUtYXBwLWVucm9sbC9nZXQtbW9iaWxlLWFwcC1lbnJvbGwtYnktaWQvJHtlbnJvbGxJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIGNvbnNvbGUuaW5mbyhyZXNwb25zZS5kYXRhPy5hZ2VudD8uX2lkLCBcInRlc3QgY3VzdG9tZXJcIik7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBncm91cF9pZDogcmVzcG9uc2UuZGF0YT8uZ3JvdXBfaWQ/Ll9pZCxcclxuICAgICAgICB1c2VyX2lkOiByZXNwb25zZS5kYXRhPy51c2VyX2lkPy5faWQsXHJcbiAgICAgICAgdGlja2V0czogcmVzcG9uc2UuZGF0YT8udGlja2V0cyxcclxuICAgICAgICBwYXltZW50X3R5cGU6IHJlc3BvbnNlLmRhdGE/LnBheW1lbnRfdHlwZSxcclxuICAgICAgICByZWZlcnJlZF9jdXN0b21lcjogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfY3VzdG9tZXI/Ll9pZCxcclxuICAgICAgICBhZ2VudDogcmVzcG9uc2UuZGF0YT8uYWdlbnQ/Ll9pZCxcclxuICAgICAgICByZWZlcnJlZF9sZWFkOiByZXNwb25zZS5kYXRhPy5yZWZlcnJlZF9sZWFkPy5faWQsXHJcbiAgICAgICAgcmVmZXJyZWRfdHlwZTogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfdHlwZSxcclxuICAgICAgICBjaGl0X2Fza2luZ19tb250aDogcmVzcG9uc2UuZGF0YT8uY2hpdF9hc2tpbmdfbW9udGggfHwgXCJcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50OlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL21vYmlsZS1hcHAtZW5yb2xsL2dldC1tb2JpbGUtYXBwLWVucm9sbC1ieS1pZC8ke2dyb3VwSWR9YCxcclxuICAgICAgKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlR3JvdXAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShcclxuICAgICAgICAgIGAvbW9iaWxlLWFwcC1lbnJvbGwvZGVsZXRlLW1vYmlsZS1hcHAtZW5yb2xsLyR7Y3VycmVudEdyb3VwLl9pZH1gLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBkYXRhOiB7IGRlbGV0ZWRfYnk6IGFkbWluLCBkZWxldGVkX2F0OiBuZXcgRGF0ZSgpIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRW5yb2xsIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBmZXRjaEFsbEVucm9sbG1lbnREYXRhKCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnB1dChcclxuICAgICAgICBgL21vYmlsZS1hcHAtZW5yb2xsL3VwZGF0ZS1tb2JpbGUtYXBwLWVucm9sbC8ke2N1cnJlbnRVcGRhdGVHcm91cC5faWR9YCxcclxuICAgICAgICB1cGRhdGVGb3JtRGF0YSxcclxuICAgICAgKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuXHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRW5yb2xsbWVudCBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgZmV0Y2hBbGxFbnJvbGxtZW50RGF0YSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGVucm9sbDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0XHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWxlcnRDb25maWcoKHApID0+ICh7IC4uLnAsIHZpc2liaWxpdHk6IGZhbHNlIH0pKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgYmctc2xhdGUtNTAgbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcblxyXG4gICAgICAgICAgICB7LyogSGVhZGVyIEJhciAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTUgbWItNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbGc6aXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICBNb2JpbGUgQXBwIEVucm9sbG1lbnRzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTWFuYWdlIGFuZCB0cmFjayBtb2JpbGUgZW5yb2xsbWVudCByZXF1ZXN0c1xyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyB3LWZ1bGwgbGc6dy1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBiZy1zbGF0ZS0xMDAgcm91bmRlZC14bCBwLTEgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYihcInBlbmRpbmdcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHthY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiID8gXCJiZy13aGl0ZSB0ZXh0LXZpb2xldC03MDAgc2hhZG93LXNtXCIgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTgwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGVuZGluZyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkRW5yb2xscy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKGUpID0+IGUuc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIiB8fCAhZS5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUYWIoXCJjb250YWN0ZWRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHthY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIgPyBcImJnLXdoaXRlIHRleHQtdmlvbGV0LTcwMCBzaGFkb3ctc21cIiA6IFwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktODAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDb250YWN0ZWQgKFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJlZEVucm9sbHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChlKSA9PiBlLnN0YXR1cyAmJiBlLnN0YXR1cyAhPT0gXCJOb3QgQ29udGFjdGVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1zbGF0ZS0xMDAgcm91bmRlZC14bCBwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZpZXdNb2RlKFwiZ3JpZFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHt2aWV3TW9kZSA9PT0gXCJncmlkXCIgPyBcImJnLXdoaXRlIHRleHQtdmlvbGV0LTcwMCBzaGFkb3ctc21cIiA6IFwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktODAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8TWRHcmlkVmlldyBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZpZXdNb2RlKFwibGlzdFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHt2aWV3TW9kZSA9PT0gXCJsaXN0XCIgPyBcImJnLXdoaXRlIHRleHQtdmlvbGV0LTcwMCBzaGFkb3ctc21cIiA6IFwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktODAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8TWRWaWV3TGlzdCBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZpZXdNb2RlKFwidGFibGVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7dmlld01vZGUgPT09IFwidGFibGVcIiA/IFwiYmctd2hpdGUgdGV4dC12aW9sZXQtNzAwIHNoYWRvdy1zbVwiIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS04MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxNZE91dGxpbmVUYWJsZVJvd3MgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTZWFyY2ggQmFyICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtNVwiPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IG5hbWUsIHBob25lIG9yIGdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFF1ZXJ5KHZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbCA9PT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VhcmNoVGVybShcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIG9uUHJlc3NFbnRlcj17KCkgPT4gc2V0U2VhcmNoVGVybShzZWFyY2hRdWVyeSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTAgdy04MCByb3VuZGVkLWxnIGJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtMjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PFNlYXJjaE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWFyY2hUZXJtKHNlYXJjaFF1ZXJ5KX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMCBiZy12aW9sZXQtNjAwIGhvdmVyOmJnLXZpb2xldC03MDAgYm9yZGVyLXZpb2xldC02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTZWFyY2hcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXItbC00IGJvcmRlci1ibHVlLTUwMCBwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvdGFsIEVucm9sbG1lbnRzXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy50b3RhbEVucm9sbG1lbnRzfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXItbC00IGJvcmRlci1ncmVlbi01MDAgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbCBUaWNrZXRzXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy50b3RhbFRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlci1sLTQgYm9yZGVyLXB1cnBsZS01MDAgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICBVbmlxdWUgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy51bmlxdWVDdXN0b21lcnN9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlci1sLTQgYm9yZGVyLW9yYW5nZS01MDAgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICBVbmlxdWUgR3JvdXBzXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAge3N1bW1hcnlTdGF0cy51bmlxdWVHcm91cHN9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQ09OVEFDVCBTVU1NQVJZIOKAlCBvbmx5IGluIENvbnRhY3RlZCB0YWIgKi99XHJcbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIgJiYgIWlzRGF0YVRhYmxlTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgPENvbnRhY3RTdW1tYXJ5RGFzaGJvYXJkIC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7cmVuZGVyRW5yb2xscygpfVxyXG5cclxuICAgICAgICAgICAge3ZpZXdNb2RlICE9PSBcInRhYmxlXCIgJiZcclxuICAgICAgICAgICAgICBnZXRUYWJGaWx0ZXJlZEVucm9sbHMoKS5sZW5ndGggPiBpdGVtc1BlclBhZ2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFNpbXBsZVBhZ2luYXRpb25cclxuICAgICAgICAgICAgICAgICAgY3VycmVudFBhZ2U9e2N1cnJlbnRQYWdlfVxyXG4gICAgICAgICAgICAgICAgICB0b3RhbFBhZ2VzPXtNYXRoLmNlaWwoXHJcbiAgICAgICAgICAgICAgICAgICAgZ2V0VGFiRmlsdGVyZWRFbnJvbGxzKCkubGVuZ3RoIC8gaXRlbXNQZXJQYWdlLFxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e3NldEN1cnJlbnRQYWdlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBZGQgRW5yb2xsbWVudCBNb2RhbCAtIFVzaW5nIGN1c3RvbSBNb2RhbCBjb21wb25lbnQgKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIEFkZCBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgey8qIEFsbCBleGlzdGluZyBmb3JtIGZpZWxkcyAtIGtlZXAgYXMgaXMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEdyb3VwIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZ3JvdXBfaWRcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZ3JvdXBfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInVzZXJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnVzZXJfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwidXNlcl9pZFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfSB8e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIucGhvbmVfbnVtYmVyID8gdXNlci5waG9uZV9udW1iZXIgOiBcIk5vIE51bWJlclwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheW1lbnRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBQYXltZW50IFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFBheW1lbnQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBheW1lbnRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnBheW1lbnRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJwYXltZW50X3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1wiRGFpbHlcIiwgXCJXZWVrbHlcIiwgXCJNb250aGx5XCJdLm1hcCgocFR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3BUeXBlfSB2YWx1ZT17cFR5cGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENoaXQgQXNraW5nIE1vbnRoXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBib3JkZXIgcm91bmRlZCB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIG1pbj17Zm9ybWF0VG9ZZWFyTW9udGgoY3VycmVudFllYXIsIGN1cnJlbnRNb250aCl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyZWQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF90eXBlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcInJlZmVycmVkX3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgIFwiU2VsZiBKb2luaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiRW1wbG95ZWVcIixcclxuICAgICAgICAgICAgICAgICAgICBcIkxlYWRzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJPdGhlcnNcIixcclxuICAgICAgICAgICAgICAgICAgXS5tYXAoKHJlZlR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZlR5cGV9IHZhbHVlPXtyZWZUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJlZF9jdXN0b21lclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9IHx7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnBob25lX251bWJlciA/IHVzZXIucGhvbmVfbnVtYmVyIDogXCJObyBOdW1iZXJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkxlYWRzXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgTGVhZHN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIExlYWRzXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfbGVhZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9sZWFkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcInJlZmVycmVkX2xlYWRcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2xlYWRzLm1hcCgobGVhZCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtsZWFkLl9pZH0gdmFsdWU9e2xlYWQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xlYWQubGVhZF9uYW1lfSB8IHtsZWFkLmxlYWRfcGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJFbXBsb3llZVwiICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEVtcGxveWVle1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIW9wdGlvbiB8fCAhb3B0aW9uLmNoaWxkcmVuKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJhZ2VudFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtmb3JtRGF0YS5ncm91cF9pZCA/IChcclxuICAgICAgICAgICAgICAgIGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTnVtYmVyIG9mIFRpY2tldHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibm9fb2ZfdGlja2V0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/Lm5vX29mX3RpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBOdW1iZXIgb2YgVGlja2V0c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4PXthdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5vX29mX3RpY2tldHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5vX29mX3RpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNtIHRleHQtYmx1ZS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE9ubHkge2F2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RofSB0aWNrZXRzIGxlZnRcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1yZWQtNjAwXCI+R3JvdXAgaXMgRnVsbDwvcD5cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1yZWQtNjAwXCI+PC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcC00IG1heC13LWZ1bGwgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcFNxdWFyZSBjb2xvcj1cImdyZWVuXCIgY2xhc3NOYW1lPVwidy0xMCBoLTEwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgV2hhdHNBcHBcclxuICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt3aGF0c2FwcEVuYWJsZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBjaGVja2VkOnJpbmctMiBjaGVja2VkOnJpbmctZ3JlZW4tNzAwIHJvdW5kZWQtZnVsbCB3LTQgaC00XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMFwiPlNlbmQgVmlhIFdoYXRzYXBwPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmcgfHxcclxuICAgICAgICAgICAgICAgICAgICAoZW5yb2xsbWVudFN0ZXAgPT09IFwic3VibWl0XCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICghaXNWZXJpZmllZCB8fCBhdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aCA9PT0gMCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTXVsdGlTdGVwfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTEvNCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlciAke2xvYWRpbmcgPyBcImJnLWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZFwiIDogZW5yb2xsbWVudFN0ZXAgPT09IFwidmVyaWZ5XCIgPyBcImJnLWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNzAwXCIgOiBlbnJvbGxtZW50U3RlcCA9PT0gXCJjb250aW51ZVwiID8gXCJiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwXCIgOiBcImJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwXCJ9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2xvYWRpbmdcclxuICAgICAgICAgICAgICAgICAgICA/IFwiUHJvY2Vzc2luZy4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBlbnJvbGxtZW50U3RlcCA9PT0gXCJ2ZXJpZnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlZlcmlmeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IGVucm9sbG1lbnRTdGVwID09PSBcImNvbnRpbnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkNvbnRpbnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlN1Ym1pdFwifVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIHsvKiBVcGRhdGUgTW9kYWwgLSBVc2luZyBjdXN0b20gTW9kYWwgY29tcG9uZW50ICovfVxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBVcGRhdGUgRW5yb2xsbWVudFxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgR3JvdXAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBfaWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfaWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHcm91cDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVzZXJfaWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInVzZXJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICBpZD1cInVzZXJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudXNlcl9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEN1c3RvbWVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLnVzZXJfaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy51c2VyX2lkfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwYXltZW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgUGF5bWVudCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQYXltZW50IFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXltZW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5wYXltZW50X3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInBheW1lbnRfdHlwZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1wiRGFpbHlcIiwgXCJXZWVrbHlcIiwgXCJNb250aGx5XCJdLm1hcCgocFR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3BUeXBlLnRvTG93ZXJDYXNlKCl9IHZhbHVlPXtwVHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cFR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ2hpdCBBc2tpbmcgTW9udGhcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJvcmRlciByb3VuZGVkIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jaGl0X2Fza2luZ19tb250aH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJyZWZlcnJlZF90eXBlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwicmVmZXJyZWRfdHlwZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgIFwiU2VsZiBKb2luaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiRW1wbG95ZWVcIixcclxuICAgICAgICAgICAgICAgICAgICBcIkxlYWRzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJPdGhlcnNcIixcclxuICAgICAgICAgICAgICAgICAgXS5tYXAoKHJlZlR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZlR5cGV9IHZhbHVlPXtyZWZUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInJlZmVycmVkX2N1c3RvbWVyXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkxlYWRzXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgTGVhZHN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIExlYWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9sZWFkXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnJlZmVycmVkX2xlYWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJyZWZlcnJlZF9sZWFkXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtsZWFkcy5tYXAoKGxlYWQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bGVhZC5faWR9IHZhbHVlPXtsZWFkLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsZWFkLmxlYWRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkVtcGxveWVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgRW1wbG95ZWV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcImFnZW50XCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogRGVsZXRlIE1vZGFsIC0gVXNpbmcgY3VzdG9tIE1vZGFsIGNvbXBvbmVudCAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsRGVsZXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBTdXJlIHdhbnQgdG8gcmVtb3ZlIHRoaXMgRW5yb2xsbWVudCA/XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50R3JvdXAgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVHcm91cCgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBSZW1vdmVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIHsvKiBTdGF0dXMgVXBkYXRlIE1vZGFsIC0gVXNpbmcgQW50IERlc2lnbiBNb2RhbCAtIFVwZGF0ZWQgd2l0aCBCdWxrIFN1cHBvcnQgKi99XHJcbiAgICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ibHVlLTEwMCByb3VuZGVkLXhsIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMTEgNUg2YTIgMiAwIDAwLTIgMnYxMWEyIDIgMCAwMDIgMmgxMWEyIDIgMCAwMDItMnYtNW0tMS40MTQtOS40MTRhMiAyIDAgMTEyLjgyOCAyLjgyOEwxMS44MjggMTVIOXYtMi44MjhsOC41ODYtOC41ODZ6XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c3RhdHVzVXBkYXRlRGF0YS5pc0J1bGtcclxuICAgICAgICAgICAgICAgICAgICA/IGBCdWxrIFVwZGF0ZSAoJHtzdGF0dXNVcGRhdGVEYXRhLnNlbGVjdGVkSWRzPy5sZW5ndGggfHwgMH0gZW5yb2xsbWVudHMpYFxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJVcGRhdGUgU3RhdHVzXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzdGF0dXNVcGRhdGVEYXRhLmlzQnVsa1xyXG4gICAgICAgICAgICAgICAgICAgID8gYFVwZGF0ZSBzdGF0dXMgZm9yICR7c3RhdHVzVXBkYXRlRGF0YS5zZWxlY3RlZElkcz8ubGVuZ3RoIHx8IDB9IHNlbGVjdGVkIGVucm9sbG1lbnRzYFxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJDaGFuZ2UgdGhlIGNvbnRhY3Qgc3RhdHVzIGFuZCByZW1hcmsgZm9yIHRoaXMgZW5yb2xsbWVudFwifVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG9wZW49e3Nob3dTdGF0dXNVcGRhdGVNb2RhbH1cclxuICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dTdGF0dXNVcGRhdGVNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFN0YXR1c1VwZGF0ZURhdGEoe1xyXG4gICAgICAgICAgICAgIF9pZDogXCJcIixcclxuICAgICAgICAgICAgICBzdGF0dXM6IFwiXCIsXHJcbiAgICAgICAgICAgICAgcmVtYXJrOiBcIlwiLFxyXG4gICAgICAgICAgICAgIGZvbGxvd191cF9kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICAgIGlzQnVsazogZmFsc2UsXHJcbiAgICAgICAgICAgICAgc2VsZWN0ZWRJZHM6IFtdLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgICB3aWR0aD17NzAwfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC0yeGxcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4gICAgICAgICAgICA8Q29sIHNwYW49ezI0fT5cclxuICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTdGF0dXMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RhdHVzVXBkYXRlRGF0YS5zdGF0dXMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U3RhdHVzVXBkYXRlRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17U1RBVFVTX09QVElPTlMubWFwKChvcHQpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBvcHQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBvcHQsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZW1hcmtcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dC5UZXh0QXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGEgcmVtYXJrLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdGF0dXNVcGRhdGVEYXRhLnJlbWFya31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U3RhdHVzVXBkYXRlRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlbWFyazogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJlc2l6ZS1ub25lIHJvdW5kZWQtbGcgYm9yZGVyLXNsYXRlLTMwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge3N0YXR1c1VwZGF0ZURhdGEuc3RhdHVzID09PSBcIkZvbGxvdyBVcFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEZvbGxvdyBVcCBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c1VwZGF0ZURhdGEuZm9sbG93X3VwX2RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZGF5anMoc3RhdHVzVXBkYXRlRGF0YS5mb2xsb3dfdXBfZGF0ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoXywgZGF0ZVN0cmluZykgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTdGF0dXNVcGRhdGVEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbGxvd191cF9kYXRlOiBkYXRlU3RyaW5nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExIHJvdW5kZWQtbGcgYm9yZGVyLXB1cnBsZS0zMDAgaG92ZXI6Ym9yZGVyLXB1cnBsZS00MDAgZm9jdXM6Ym9yZGVyLXB1cnBsZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtYXQ9XCJZWVlZLU1NLUREXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgZm9sbG93LXVwIGRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZERhdGU9eyhjdXJyZW50KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnQgJiYgY3VycmVudCA8IGRheWpzKCkuc3RhcnRPZihcImRheVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1wdXJwbGUtNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IGEgZnV0dXJlIGRhdGUgZm9yIHRoZSBmb2xsb3ctdXBcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICA8L1Jvdz5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgbXQtNiBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJkZWZhdWx0XCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93U3RhdHVzVXBkYXRlTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgc2V0U3RhdHVzVXBkYXRlRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgIF9pZDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgc3RhdHVzOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICByZW1hcms6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgIGZvbGxvd191cF9kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICBpc0J1bGs6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZElkczogW10sXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgcHgtNiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS01MCByb3VuZGVkLXhsIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXtpc1N0YXR1c1VwZGF0aW5nfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN0YXR1c1VwZGF0ZVN1Ym1pdH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHB4LTYgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS0yMDAgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3N0YXR1c1VwZGF0ZURhdGEuaXNCdWxrXHJcbiAgICAgICAgICAgICAgICA/IGBVcGRhdGUgJHtzdGF0dXNVcGRhdGVEYXRhLnNlbGVjdGVkSWRzPy5sZW5ndGggfHwgMH0gRW5yb2xsbWVudHNgXHJcbiAgICAgICAgICAgICAgICA6IFwiVXBkYXRlIFN0YXR1c1wifVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQW50TW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1vYmlsZUFwcEVucm9sbDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL01vYmlsZUFwcEVucm9sbC5qc3gifQ==