import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PigmeReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Input, Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaCalculator } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const PigmeReport = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [tableBorrowers, setTableBorrowers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentCustomer, setCurrentCustomer] = useState(null);
  const [currentUpdateCustomer, setCurrentUpdateCustomer] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    customer: "",
    maturity_period: "",
    maturity_interest: "",
    payable_amount: "",
    start_date: "",
    end_date: "",
    note: ""
  });
  const [errors, setErrors] = useState({});
  const [updateFormData, setUpdateFormData] = useState({
    customer: "",
    maturity_period: "",
    maturity_interest: "",
    payable_amount: "",
    start_date: "",
    end_date: "",
    note: ""
  });
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await api.get("/user/get-user");
        if (response.status >= 400)
          throw new Error("Failed to fetch Customers");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching  Customer Data:", error);
      }
    };
    fetchCustomers();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchBorrowers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/pigme/get-all-pigme-customers");
        setPigmeCustomers(response.data);
        const formattedData = response?.data?.map((pigmeCustomer, index) => ({
          _id: pigmeCustomer?._id,
          id: index + 1,
          pigme_id: pigmeCustomer?.pigme_id,
          customer_name: pigmeCustomer?.customer?.full_name,
          date: pigmeCustomer?.createdAt,
          maturity_period: pigmeCustomer?.maturity_period,
          maturity_interest: pigmeCustomer?.maturity_interest,
          payable_amount: pigmeCustomer?.payable_amount,
          start_date: pigmeCustomer?.start_date?.split("T")[0],
          end_date: pigmeCustomer?.end_date?.split("T")[0],
          note: pigmeCustomer?.note,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(pigmeCustomer._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                        lineNumber: 102,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(pigmeCustomer._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                        lineNumber: 115,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 129,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 95,
              columnNumber: 15
            },
            this
          ) }, pigmeCustomer._id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
            lineNumber: 94,
            columnNumber: 11
          }, this)
        }));
        setTableBorrowers(formattedData);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchBorrowers();
  }, [reloadTrigger]);
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addCustomer" ? formData : updateFormData;
    if (!data.customer) {
      newErrors.customer = "Customer Name is required";
    }
    if (!data.maturity_period) {
      newErrors.maturity_period = "Maturity Period is Required";
    }
    if (!data.payable_amount) {
      newErrors.payable_amount = "Payable Amount is required";
    } else if (!data.payable_amount || isNaN(data.payable_amount) || data.payable_amount <= 0) {
      newErrors.payable_amount = "Payable Amount must be a positive number";
    }
    if (!data.start_date) {
      newErrors.start_date = "Start Date is required";
    }
    if (!data.end_date) {
      newErrors.end_date = "End Date is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleDeleteModalOpen = async (pigmeId) => {
    try {
      const response = await api.get(`pigme/get-pigme/${pigmeId}`);
      setCurrentCustomer(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Pigme:", error);
    }
  };
  const handleUpdateModalOpen = async (pigmeId) => {
    try {
      const response = await api.get(`pigme/get-pigme/${pigmeId}`);
      const PigmeData = response.data;
      const formattedStartDate = PigmeData?.start_date?.split("T")[0];
      const formattedEndDate = PigmeData?.end_date?.split("T")[0];
      setCurrentUpdateCustomer(response.data);
      setUpdateFormData({
        customer: response?.data?.customer._id,
        maturity_period: response?.data?.maturity_period,
        maturity_interest: response?.data?.maturity_interest,
        payable_amount: response?.data?.payable_amount,
        start_date: formattedStartDate,
        end_date: formattedEndDate,
        note: response?.data?.note
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching pigme Customer by ID:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({ ...prevData, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handleDeletePigme = async () => {
    if (currentCustomer) {
      try {
        await api.delete(`/pigme/delete-pigme-customer/${currentCustomer._id}`);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Pigme User deleted successfully",
          type: "success",
          visibility: true
        });
        setShowModalDelete(false);
        setCurrentCustomer(null);
      } catch (error) {
        console.error("Error deleting pigme User:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        await api.patch(
          `/pigme/update-pigme-customer/${currentUpdateCustomer._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Borrower updated successfully",
          type: "success",
          visibility: true
        });
      }
    } catch (error) {
      console.error("Error updating Borrower:", error);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "customer_name", header: "Customer Name" },
    { key: "maturity_period", header: "Maturity Period" },
    { key: "maturity_interest", header: "Maturity Interest" },
    { key: "start_date", header: "Start Date" },
    { key: "end_date", header: "Due Date" },
    { key: "note", header: "Note" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-hidden", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
        lineNumber: 300,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
        lineNumber: 304,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-5", children: " Reports - Pigme" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
        lineNumber: 316,
        columnNumber: 13
      }, this),
      tableBorrowers?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          catcher: "_id",
          updateHandler: handleUpdateModalOpen,
          data: filterOption(tableBorrowers, searchText),
          columns,
          exportedFileName: `Groups-${tableBorrowers.length > 0 ? tableBorrowers[0].date + " to " + tableBorrowers[tableBorrowers.length - 1].date : "empty"}.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
          lineNumber: 320,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          data: "Pigme Data",
          failure: tableBorrowers?.length <= 0
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
          lineNumber: 334,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
      lineNumber: 315,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
      lineNumber: 312,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Pigme" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
            lineNumber: 348,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "customer",
                  children: [
                    "Customer Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                      lineNumber: 357,
                      columnNumber: 33
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 353,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search  Customer Name ",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "borrower",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.customer || void 0,
                  onChange: (value) => handleAntInputDSelect("customer", value),
                  children: users.map(
                    (customer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: customer._id, children: customer.full_name }, customer._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                      lineNumber: 390,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 374,
                  columnNumber: 17
                },
                this
              ),
              errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 396,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 352,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "maturity_period",
                  children: [
                    "Maturity period",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                      lineNumber: 406,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 401,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  placeholder: "Select or Search Maturity period",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "maturity_period",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.maturity_period || void 0,
                  onChange: (value) => handleAntInputDSelect("maturity_period", value),
                  children: ["Daily", "Weekly", "Monthly"].map(
                    (period) => /* @__PURE__ */ jsxDEV(Select.Option, { value: period, children: period }, period, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                      lineNumber: 438,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 423,
                  columnNumber: 18
                },
                this
              ),
              errors.maturity_period && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.maturity_period }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 444,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 400,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "maturity_interest",
                    children: "Maturity Interest"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 452,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "maturity_interest",
                    value: updateFormData.maturity_interest,
                    onChange: handleInputChange,
                    id: "maturity_interest",
                    placeholder: "Enter Maturity Interest",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 458,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 451,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "payable_amount",
                    children: [
                      "Payable Amount ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                        lineNumber: 474,
                        columnNumber: 36
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 470,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "payable_amount",
                    value: updateFormData.payable_amount,
                    onChange: handleInputChange,
                    id: "tenure",
                    placeholder: "Enter Payable Amount",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 476,
                    columnNumber: 19
                  },
                  this
                ),
                errors.payable_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.payable_amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 487,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 469,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 450,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "start_date",
                    children: [
                      "Start Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                        lineNumber: 500,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 496,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "start_date",
                    value: updateFormData.start_date,
                    onChange: handleInputChange,
                    id: "start_date",
                    placeholder: "Enter the Date",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 502,
                    columnNumber: 19
                  },
                  this
                ),
                errors.start_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 513,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 495,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "end_date",
                    children: [
                      "End Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                        lineNumber: 523,
                        columnNumber: 30
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 519,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "end_date",
                    value: updateFormData.end_date,
                    onChange: handleInputChange,
                    id: "end_date",
                    placeholder: "Enter End Date",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 525,
                    columnNumber: 19
                  },
                  this
                ),
                errors.end_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.end_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 536,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 518,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 494,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "note",
                  children: "Note"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 543,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex w-full gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "note",
                    value: updateFormData.note,
                    onChange: handleInputChange,
                    id: "note",
                    placeholder: "Specify Note if any!",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 550,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "bg-violet-700 hover:bg-violet-800 w-10 h-10 flex justify-center items-center rounded-md",
                    onClick: () => {
                      window.open("Calculator:///");
                    },
                    children: /* @__PURE__ */ jsxDEV(FaCalculator, { color: "white" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                      lineNumber: 566,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 560,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 549,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 542,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
                children: "Update Pigme"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                lineNumber: 571,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 570,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
            lineNumber: 351,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
          lineNumber: 347,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
        lineNumber: 343,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentCustomer(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Pigme Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
            lineNumber: 591,
            columnNumber: 13
          }, this),
          currentCustomer && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeletePigme();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentCustomer.customer?.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                          lineNumber: 608,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                          lineNumber: 612,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                      lineNumber: 603,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "borrowerName",
                      placeholder: "Enter the Pigme Customer Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                      lineNumber: 614,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                  lineNumber: 602,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
                    lineNumber: 622,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
              lineNumber: 595,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
          lineNumber: 590,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
        lineNumber: 583,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
    lineNumber: 299,
    columnNumber: 3
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx",
    lineNumber: 298,
    columnNumber: 5
  }, this);
};
_s(PigmeReport, "egpgVVweK10MMNT0+N40gQyT7xE=");
_c = PigmeReport;
export default PigmeReport;
var _c;
$RefreshReg$(_c, "PigmeReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmeReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUd3QixTQW9NcEIsVUFwTW9COzs7Ozs7Ozs7Ozs7Ozs7OztBQWxHeEIsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLE9BQU1DLFFBQVFDLGdCQUFnQjtBQUN2QyxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msb0JBQW9CO0FBQzdCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsTUFBTUMsY0FBY0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJbEIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ21CLGdCQUFnQkMsaUJBQWlCLElBQUlwQixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDcUIsZ0JBQWdCQyxpQkFBaUIsSUFBSXRCLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUN1QixXQUFXQyxZQUFZLElBQUl4QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDeUIsaUJBQWlCQyxrQkFBa0IsSUFBSTFCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMyQixpQkFBaUJDLGtCQUFrQixJQUFJNUIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzZCLGlCQUFpQkMsa0JBQWtCLElBQUk5QixTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDK0IsdUJBQXVCQyx3QkFBd0IsSUFBSWhDLFNBQVMsSUFBSTtBQUN2RSxRQUFNLENBQUNpQyxZQUFZQyxhQUFhLElBQUlsQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUMsZUFBZUMsZ0JBQWdCLElBQUlwQyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDcUMsV0FBV0MsWUFBWSxJQUFJdEMsU0FBUyxLQUFLO0FBQ2hELFFBQU11Qyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCUixrQkFBY08sS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxhQUFhQyxjQUFjLElBQUk1QyxTQUFTO0FBQUEsSUFDN0M2QyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSWpELFNBQVM7QUFBQSxJQUN2Q2tELFVBQVU7QUFBQSxJQUNWQyxpQkFBaUI7QUFBQSxJQUNqQkMsbUJBQW1CO0FBQUEsSUFDbkJDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTFELFNBQVMsQ0FBQyxDQUFDO0FBRXZDLFFBQU0sQ0FBQzJELGdCQUFnQkMsaUJBQWlCLElBQUk1RCxTQUFTO0FBQUEsSUFDbkRrRCxVQUFVO0FBQUEsSUFDVkMsaUJBQWlCO0FBQUEsSUFDakJDLG1CQUFtQjtBQUFBLElBQ25CQyxnQkFBZ0I7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUR6RCxZQUFVLE1BQU07QUFDZCxVQUFNOEQsaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTTNELElBQUk0RCxJQUFJLGdCQUFnQjtBQUMvQyxZQUFJRCxTQUFTRSxVQUFVO0FBQ3JCLGdCQUFNLElBQUlDLE1BQU0sMkJBQTJCO0FBQzdDL0MsaUJBQVM0QyxTQUFTSSxJQUFJO0FBQUEsTUFDeEIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxrQ0FBa0NBLEtBQUs7QUFBQSxNQUN2RDtBQUFBLElBQ0Y7QUFDQU4sbUJBQWU7QUFBQSxFQUNqQixHQUFHLENBQUMxQixhQUFhLENBQUM7QUFFbEJwQyxZQUFVLE1BQU07QUFDZCxVQUFNc0UsaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGL0IscUJBQWEsSUFBSTtBQUNqQixjQUFNd0IsV0FBVyxNQUFNM0QsSUFBSTRELElBQUksZ0NBQWdDO0FBQy9EM0MsMEJBQWtCMEMsU0FBU0ksSUFBSTtBQUMvQixjQUFNSSxnQkFBZ0JSLFVBQVVJLE1BQU1LLElBQUksQ0FBQ0MsZUFBZUMsV0FBVztBQUFBLFVBQ25FQyxLQUFLRixlQUFlRTtBQUFBQSxVQUNwQkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1pHLFVBQVVKLGVBQWVJO0FBQUFBLFVBQ3pCQyxlQUFlTCxlQUFldEIsVUFBVTRCO0FBQUFBLFVBQ3hDQyxNQUFNUCxlQUFlUTtBQUFBQSxVQUNyQjdCLGlCQUFpQnFCLGVBQWVyQjtBQUFBQSxVQUNoQ0MsbUJBQW1Cb0IsZUFBZXBCO0FBQUFBLFVBQ2xDQyxnQkFBZ0JtQixlQUFlbkI7QUFBQUEsVUFDL0JDLFlBQVlrQixlQUFlbEIsWUFBWTJCLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxVQUNuRDFCLFVBQVVpQixlQUFlakIsVUFBVTBCLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxVQUMvQ3pCLE1BQU1nQixlQUFlaEI7QUFBQUEsVUFDckIwQixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0QsU0FBUyxDQUFDLE9BQU87QUFBQSxjQUNmLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMO0FBQUEsb0JBQ0VDLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUNQQyxzQkFBc0JkLGNBQWNFLEdBQUc7QUFBQSx3QkFDeEM7QUFBQTtBQUFBLHNCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRVUsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQ1BFLHNCQUFzQmYsY0FBY0UsR0FBRztBQUFBLHdCQUN4QztBQUFBO0FBQUEsc0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRUw7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUFsQ2pDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1DQSxLQXBDOENGLGNBQWNFLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUNBO0FBQUEsUUFFSixFQUFFO0FBQ0ZwRCwwQkFBa0JnRCxhQUFhO0FBQUEsTUFDakMsU0FBU0gsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRCxVQUFDO0FBQ0M3QixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0ErQixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ2xDLGFBQWEsQ0FBQztBQUVsQixRQUFNcUQsbUJBQW1CQSxDQUFDQyxPQUFPaEQsVUFBVTtBQUN6Q1EsZ0JBQVksQ0FBQ3lDLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNELEtBQUssR0FBR2hEO0FBQUFBLElBQ1gsRUFBRTtBQUVGaUIsY0FBVSxDQUFDaUMsZ0JBQWdCO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixLQUFLLEdBQUc7QUFBQSxJQUNYLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTUcsd0JBQXdCQSxDQUFDSCxPQUFPaEQsVUFBVTtBQUM5Q21CLHNCQUFrQixDQUFDOEIsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsS0FBSyxHQUFHaEQ7QUFBQUEsSUFDWCxFQUFFO0FBRUZpQixjQUFVLENBQUNpQyxnQkFBZ0IsRUFBRSxHQUFHQSxZQUFZLENBQUNGLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUM1RDtBQUNBLFFBQU1JLGVBQWVBLENBQUNyRCxNQUFNO0FBQzFCLFVBQU0sRUFBRXNELE1BQU1yRCxNQUFNLElBQUlELEVBQUVFO0FBRTFCTyxnQkFBWSxDQUFDOEMsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsSUFBSSxHQUFHckQsTUFBTSxFQUFFO0FBRWxEaUIsY0FBVSxDQUFDcUMsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQy9DO0FBRUEsUUFBTUUsZUFBZUEsQ0FBQ2pELFNBQVM7QUFDN0IsVUFBTWtELFlBQVksQ0FBQztBQUVuQixVQUFNL0IsT0FBT25CLFNBQVMsZ0JBQWdCQyxXQUFXVztBQUVqRCxRQUFJLENBQUNPLEtBQUtoQixVQUFVO0FBQ2xCK0MsZ0JBQVUvQyxXQUFXO0FBQUEsSUFDdkI7QUFFQSxRQUFJLENBQUNnQixLQUFLZixpQkFBaUI7QUFDekI4QyxnQkFBVTlDLGtCQUFrQjtBQUFBLElBQzlCO0FBRUEsUUFBSSxDQUFDZSxLQUFLYixnQkFBZ0I7QUFDeEI0QyxnQkFBVTVDLGlCQUFpQjtBQUFBLElBQzdCLFdBQ0UsQ0FBQ2EsS0FBS2Isa0JBQ042QyxNQUFNaEMsS0FBS2IsY0FBYyxLQUN6QmEsS0FBS2Isa0JBQWtCLEdBQ3ZCO0FBQ0E0QyxnQkFBVTVDLGlCQUFpQjtBQUFBLElBQzdCO0FBRUEsUUFBSSxDQUFDYSxLQUFLWixZQUFZO0FBQ3BCMkMsZ0JBQVUzQyxhQUFhO0FBQUEsSUFDekI7QUFDQSxRQUFJLENBQUNZLEtBQUtYLFVBQVU7QUFDbEIwQyxnQkFBVTFDLFdBQVc7QUFBQSxJQUN2QjtBQUVBRyxjQUFVdUMsU0FBUztBQUNuQixXQUFPRSxPQUFPQyxLQUFLSCxTQUFTLEVBQUVJLFdBQVc7QUFBQSxFQUMzQztBQUlBLFFBQU1kLHdCQUF3QixPQUFPZSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNeEMsV0FBVyxNQUFNM0QsSUFBSTRELElBQUksbUJBQW1CdUMsT0FBTyxFQUFFO0FBQzNEeEUseUJBQW1CZ0MsU0FBU0ksSUFBSTtBQUNoQ3hDLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU3lDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNbUIsd0JBQXdCLE9BQU9nQixZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNeEMsV0FBVyxNQUFNM0QsSUFBSTRELElBQUksbUJBQW1CdUMsT0FBTyxFQUFFO0FBQzNELFlBQU1DLFlBQVl6QyxTQUFTSTtBQUMzQixZQUFNc0MscUJBQXFCRCxXQUFXakQsWUFBWTJCLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDOUQsWUFBTXdCLG1CQUFtQkYsV0FBV2hELFVBQVUwQixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzFEakQsK0JBQXlCOEIsU0FBU0ksSUFBSTtBQUN0Q04sd0JBQWtCO0FBQUEsUUFDaEJWLFVBQVVZLFVBQVVJLE1BQU1oQixTQUFTd0I7QUFBQUEsUUFDbkN2QixpQkFBaUJXLFVBQVVJLE1BQU1mO0FBQUFBLFFBQ2pDQyxtQkFBbUJVLFVBQVVJLE1BQU1kO0FBQUFBLFFBQ25DQyxnQkFBZ0JTLFVBQVVJLE1BQU1iO0FBQUFBLFFBQ2hDQyxZQUFZa0Q7QUFBQUEsUUFDWmpELFVBQVVrRDtBQUFBQSxRQUNWakQsTUFBTU0sVUFBVUksTUFBTVY7QUFBQUEsTUFDeEIsQ0FBQztBQUNENUIseUJBQW1CLElBQUk7QUFDdkI4QixnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVNTLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3Q0FBd0NBLEtBQUs7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUMsb0JBQW9CQSxDQUFDbEUsTUFBTTtBQUMvQixVQUFNLEVBQUVzRCxNQUFNckQsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQmtCLHNCQUFrQixDQUFDOEIsY0FBYyxFQUFFLEdBQUdBLFVBQVUsQ0FBQ0ksSUFBSSxHQUFHckQsTUFBTSxFQUFFO0FBQ2hFaUIsY0FBVSxDQUFDcUMsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQy9DO0FBRUEsUUFBTWEsb0JBQW9CLFlBQVk7QUFDcEMsUUFBSTlFLGlCQUFpQjtBQUNuQixVQUFJO0FBQ0YsY0FBTTFCLElBQUl5RyxPQUFPLGdDQUFnQy9FLGdCQUFnQjZDLEdBQUcsRUFBRTtBQUN0RXRDLHlCQUFpQixDQUFDMkQsU0FBU0EsT0FBTyxDQUFDO0FBQ25DbkQsdUJBQWU7QUFBQSxVQUNiRSxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFVBQ05GLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFDRG5CLDJCQUFtQixLQUFLO0FBQ3hCSSwyQkFBbUIsSUFBSTtBQUFBLE1BQ3pCLFNBQVNxQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNMEMsZUFBZSxPQUFPckUsTUFBTTtBQUNoQ0EsTUFBRXNFLGVBQWU7QUFDakIsVUFBTUMsVUFBVWYsYUFBYTtBQUM3QixRQUFJO0FBQ0YsVUFBSWUsU0FBUztBQUNYLGNBQU01RyxJQUFJNkc7QUFBQUEsVUFDUixnQ0FBZ0NqRixzQkFBc0IyQyxHQUFHO0FBQUEsVUFDekRmO0FBQUFBLFFBQ0Y7QUFDQS9CLDJCQUFtQixLQUFLO0FBQ3hCUSx5QkFBaUIsQ0FBQzJELFNBQVNBLE9BQU8sQ0FBQztBQUNuQ25ELHVCQUFlO0FBQUEsVUFDYkUsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxVQUNORixZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3NCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw0QkFBNEJBLEtBQUs7QUFBQSxJQUNqRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEMsVUFBVTtBQUFBLElBQ2QsRUFBRTdCLEtBQUssTUFBTThCLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUU5QixLQUFLLGlCQUFpQjhCLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRTlCLEtBQUssbUJBQW1COEIsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFOUIsS0FBSyxxQkFBcUI4QixRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUU5QixLQUFLLGNBQWM4QixRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFOUIsS0FBSyxZQUFZOEIsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRTlCLEtBQUssUUFBUThCLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUU5QixLQUFLLFVBQVU4QixRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFNBQ0UsbUNBQ0YsaUNBQUMsU0FBSSxXQUFVLDRCQUNUO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFlBQVk7QUFBQSxRQUNaO0FBQUE7QUFBQSxNQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUUyRDtBQUFBLElBRTNEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNdkUsWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsUUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNtRCxVQUFVLEVBQUUsR0FBR0EsTUFBTWxELFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBRUgsdUJBQUMsU0FBSSxXQUFVLGdCQUdiLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrQkFBOEIsZ0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUczRHhCLGdCQUFnQmdGLFNBQVMsS0FBSyxDQUFDaEUsWUFDOUI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVE7QUFBQSxVQUNSLGVBQWVpRDtBQUFBQSxVQUNmLE1BQU0zRSxhQUFhVSxnQkFBZ0JZLFVBQVU7QUFBQSxVQUM3QztBQUFBLFVBQ0Esa0JBQWtCLFVBQ2hCWixlQUFlZ0YsU0FBUyxJQUNwQmhGLGVBQWUsQ0FBQyxFQUFFMEQsT0FDbEIsU0FDQTFELGVBQWVBLGVBQWVnRixTQUFTLENBQUMsRUFBRXRCLE9BQzFDLE9BQU87QUFBQTtBQUFBLFFBVmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BV1MsSUFHVDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLE1BQUs7QUFBQSxVQUNMLFNBQVMxRCxnQkFBZ0JnRixVQUFVO0FBQUE7QUFBQSxRQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHdUM7QUFBQSxTQXRCM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzFFO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVpRixjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsb0JBRUosdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FnQkE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxxQ0FBcUMvRixVQUFVcUcsTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBTzdELGdCQUFnQlQsWUFBWXdFO0FBQUFBLGtCQUNuQyxVQUFVLENBQUNqRixVQUFVbUQsc0JBQXNCLFlBQVluRCxLQUFLO0FBQUEsa0JBRTNEeEIsZ0JBQU1zRDtBQUFBQSxvQkFBSSxDQUFDckIsYUFDVix1QkFBQyxPQUFPLFFBQVAsRUFBaUMsT0FBT0EsU0FBU3dCLEtBQy9DeEIsbUJBQVM0QixhQURRNUIsU0FBU3dCLEtBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9CQTtBQUFBLGNBQ0NqQixPQUFPUCxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJPLGlCQUFPUCxZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGlCQTVDOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4Q0E7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFpQjtBQUFBO0FBQUEsb0JBRVQ7QUFBQSxvQkFDaEIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FnQkM7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDa0UsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNFLFlBQVksRUFBRUMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU83RCxnQkFBZ0JSLG1CQUFtQnVFO0FBQUFBLGtCQUMxQyxVQUFVLENBQUNqRixVQUNUbUQsc0JBQXNCLG1CQUFtQm5ELEtBQUs7QUFBQSxrQkFHL0MsV0FBQyxTQUFTLFVBQVUsU0FBUyxFQUFFOEI7QUFBQUEsb0JBQUksQ0FBQ29ELFdBQ25DLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkQ7QUFBQSxjQUNDbEUsT0FBT04sbUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWTSxpQkFBT04sbUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQTlDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdEQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFtQjtBQUFBO0FBQUEsa0JBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1EsZUFBZVA7QUFBQUEsb0JBQ3RCLFVBQVVzRDtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUM1RixVQUFVcUcsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRaUs7QUFBQSxtQkFmbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZ0I7QUFBQTtBQUFBLHNCQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU94RCxlQUFlTjtBQUFBQSxvQkFDdEIsVUFBVXFEO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQzVGLFVBQVVxRyxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFpSztBQUFBLGdCQUVoSzFELE9BQU9KLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkksaUJBQU9KLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQ0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBWTtBQUFBO0FBQUEsc0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT00sZUFBZUw7QUFBQUEsb0JBQ3RCLFVBQVVvRDtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUM1RixVQUFVcUcsTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRaUs7QUFBQSxnQkFFaEsxRCxPQUFPSCxjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkcsaUJBQU9ILGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFVO0FBQUE7QUFBQSxzQkFFVCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPSyxlQUFlSjtBQUFBQSxvQkFDdEIsVUFBVW1EO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQzVGLFVBQVVxRyxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFpSztBQUFBLGdCQUVoSzFELE9BQU9GLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWRSxpQkFBT0YsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsaUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTTtBQUFBO0FBQUEsZ0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9JLGVBQWVIO0FBQUFBLG9CQUN0QixVQUFVa0Q7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDNUYsVUFBVXFHLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUWlLO0FBQUEsZ0JBRWpLO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFTLE1BQU07QUFDYlMsNkJBQU9DLEtBQUssZ0JBQWdCO0FBQUEsb0JBQzlCO0FBQUEsb0JBRUEsaUNBQUMsZ0JBQWEsT0FBTSxXQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBO0FBQUEsa0JBTjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDcUg7QUFBQTtBQUFBLGNBSGpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBbk9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb09BO0FBQUEsYUF4T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlPQTtBQUFBO0FBQUEsTUE3T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOE9BO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3BHO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSSw2QkFBbUIsSUFBSTtBQUFBLFFBQ3pCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLHFDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsbUJBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ1csTUFBTTtBQUNmQSxrQkFBRXNFLGVBQWU7QUFDakJILGtDQUFrQjtBQUFBLGNBQ3BCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYjlFLDBCQUFnQnFCLFVBQVU0QixhQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDaEUsVUFBVXFHLE1BQU07QUFBQTtBQUFBLG9CQUxsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS2lLO0FBQUEscUJBakJuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQzJGO0FBQUE7QUFBQSxrQkFIdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtDQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQTtBQUFBLE1BaERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlEQTtBQUFBLE9BN1VOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4VUksS0EvVUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdWQTtBQUVKO0FBQUVuRyxHQTNtQklELGFBQVc7QUFBQStHLEtBQVgvRztBQTZtQk4sZUFBZUE7QUFBWSxJQUFBK0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJJbnB1dCIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiSW9NZE1vcmUiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJGYUNhbGN1bGF0b3IiLCJDaXJjdWxhckxvYWRlciIsImZpZWxkU2l6ZSIsIlBpZ21lUmVwb3J0IiwiX3MiLCJ1c2VycyIsInNldFVzZXJzIiwicGlnbWVDdXN0b21lcnMiLCJzZXRQaWdtZUN1c3RvbWVycyIsInRhYmxlQm9ycm93ZXJzIiwic2V0VGFibGVCb3Jyb3dlcnMiLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50Q3VzdG9tZXIiLCJzZXRDdXJyZW50Q3VzdG9tZXIiLCJjdXJyZW50VXBkYXRlQ3VzdG9tZXIiLCJzZXRDdXJyZW50VXBkYXRlQ3VzdG9tZXIiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJjdXN0b21lciIsIm1hdHVyaXR5X3BlcmlvZCIsIm1hdHVyaXR5X2ludGVyZXN0IiwicGF5YWJsZV9hbW91bnQiLCJzdGFydF9kYXRlIiwiZW5kX2RhdGUiLCJub3RlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsImZldGNoQ3VzdG9tZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJzdGF0dXMiLCJFcnJvciIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaEJvcnJvd2VycyIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJwaWdtZUN1c3RvbWVyIiwiaW5kZXgiLCJfaWQiLCJpZCIsInBpZ21lX2lkIiwiY3VzdG9tZXJfbmFtZSIsImZ1bGxfbmFtZSIsImRhdGUiLCJjcmVhdGVkQXQiLCJzcGxpdCIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJwcmV2RGF0YSIsInByZXZFcnJvcnMiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJoYW5kbGVDaGFuZ2UiLCJuYW1lIiwicHJldiIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImlzTmFOIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsInBpZ21lSWQiLCJQaWdtZURhdGEiLCJmb3JtYXR0ZWRTdGFydERhdGUiLCJmb3JtYXR0ZWRFbmREYXRlIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVEZWxldGVQaWdtZSIsImRlbGV0ZSIsImhhbmRsZVVwZGF0ZSIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBhdGNoIiwiY29sdW1ucyIsImhlYWRlciIsImhlaWdodCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJwZXJpb2QiLCJ3aW5kb3ciLCJvcGVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGlnbWVSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBJbnB1dCxTZWxlY3QsIERyb3Bkb3duIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYUNhbGN1bGF0b3IgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmNvbnN0IFBpZ21lUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUN1c3RvbWVycywgc2V0UGlnbWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUJvcnJvd2Vycywgc2V0VGFibGVCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Q3VzdG9tZXIsIHNldEN1cnJlbnRDdXN0b21lcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUN1c3RvbWVyLCBzZXRDdXJyZW50VXBkYXRlQ3VzdG9tZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgbWF0dXJpdHlfcGVyaW9kOiBcIlwiLFxyXG4gICAgbWF0dXJpdHlfaW50ZXJlc3Q6IFwiXCIsXHJcbiAgICBwYXlhYmxlX2Ftb3VudDogXCJcIixcclxuICAgIHN0YXJ0X2RhdGU6IFwiXCIsXHJcbiAgICBlbmRfZGF0ZTogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBjdXN0b21lcjogXCJcIixcclxuICAgIG1hdHVyaXR5X3BlcmlvZDogXCJcIixcclxuICAgIG1hdHVyaXR5X2ludGVyZXN0OiBcIlwiLFxyXG4gICAgcGF5YWJsZV9hbW91bnQ6IFwiXCIsXHJcbiAgICBzdGFydF9kYXRlOiBcIlwiLFxyXG4gICAgZW5kX2RhdGU6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApXHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggQ3VzdG9tZXJzXCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyAgQ3VzdG9tZXIgRGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hDdXN0b21lcnMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hCb3Jyb3dlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9waWdtZS9nZXQtYWxsLXBpZ21lLWN1c3RvbWVyc1wiKTtcclxuICAgICAgICBzZXRQaWdtZUN1c3RvbWVycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2U/LmRhdGE/Lm1hcCgocGlnbWVDdXN0b21lciwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IHBpZ21lQ3VzdG9tZXI/Ll9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBwaWdtZV9pZDogcGlnbWVDdXN0b21lcj8ucGlnbWVfaWQsXHJcbiAgICAgICAgICBjdXN0b21lcl9uYW1lOiBwaWdtZUN1c3RvbWVyPy5jdXN0b21lcj8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgZGF0ZTogcGlnbWVDdXN0b21lcj8uY3JlYXRlZEF0LFxyXG4gICAgICAgICAgbWF0dXJpdHlfcGVyaW9kOiBwaWdtZUN1c3RvbWVyPy5tYXR1cml0eV9wZXJpb2QsXHJcbiAgICAgICAgICBtYXR1cml0eV9pbnRlcmVzdDogcGlnbWVDdXN0b21lcj8ubWF0dXJpdHlfaW50ZXJlc3QsXHJcbiAgICAgICAgICBwYXlhYmxlX2Ftb3VudDogcGlnbWVDdXN0b21lcj8ucGF5YWJsZV9hbW91bnQsXHJcbiAgICAgICAgICBzdGFydF9kYXRlOiBwaWdtZUN1c3RvbWVyPy5zdGFydF9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICBlbmRfZGF0ZTogcGlnbWVDdXN0b21lcj8uZW5kX2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgIG5vdGU6IHBpZ21lQ3VzdG9tZXI/Lm5vdGUsXHJcbiAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCIga2V5PXtwaWdtZUN1c3RvbWVyLl9pZH0+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgdHJpZ2dlcj17WydjbGljayddfVxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVNb2RhbE9wZW4ocGlnbWVDdXN0b21lci5faWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZU1vZGFsT3BlbihwaWdtZUN1c3RvbWVyLl9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRUYWJsZUJvcnJvd2Vycyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEJvcnJvd2VycygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuXHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7XHJcbiAgICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgICAgIFtmaWVsZF06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoeyAuLi5wcmV2RXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuXHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuXHJcbiAgICBjb25zdCBkYXRhID0gdHlwZSA9PT0gXCJhZGRDdXN0b21lclwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuXHJcbiAgICBpZiAoIWRhdGEuY3VzdG9tZXIpIHtcclxuICAgICAgbmV3RXJyb3JzLmN1c3RvbWVyID0gXCJDdXN0b21lciBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLm1hdHVyaXR5X3BlcmlvZCkge1xyXG4gICAgICBuZXdFcnJvcnMubWF0dXJpdHlfcGVyaW9kID0gXCJNYXR1cml0eSBQZXJpb2QgaXMgUmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGF5YWJsZV9hbW91bnQpIHtcclxuICAgICAgbmV3RXJyb3JzLnBheWFibGVfYW1vdW50ID0gXCJQYXlhYmxlIEFtb3VudCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgIWRhdGEucGF5YWJsZV9hbW91bnQgfHxcclxuICAgICAgaXNOYU4oZGF0YS5wYXlhYmxlX2Ftb3VudCkgfHxcclxuICAgICAgZGF0YS5wYXlhYmxlX2Ftb3VudCA8PSAwXHJcbiAgICApIHtcclxuICAgICAgbmV3RXJyb3JzLnBheWFibGVfYW1vdW50ID0gXCJQYXlhYmxlIEFtb3VudCBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLnN0YXJ0X2RhdGUpIHtcclxuICAgICAgbmV3RXJyb3JzLnN0YXJ0X2RhdGUgPSBcIlN0YXJ0IERhdGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5lbmRfZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMuZW5kX2RhdGUgPSBcIkVuZCBEYXRlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAocGlnbWVJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGBwaWdtZS9nZXQtcGlnbWUvJHtwaWdtZUlkfWApO1xyXG4gICAgICBzZXRDdXJyZW50Q3VzdG9tZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBQaWdtZTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChwaWdtZUlkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYHBpZ21lL2dldC1waWdtZS8ke3BpZ21lSWR9YCk7XHJcbiAgICAgIGNvbnN0IFBpZ21lRGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZFN0YXJ0RGF0ZSA9IFBpZ21lRGF0YT8uc3RhcnRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWRFbmREYXRlID0gUGlnbWVEYXRhPy5lbmRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlQ3VzdG9tZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBjdXN0b21lcjogcmVzcG9uc2U/LmRhdGE/LmN1c3RvbWVyLl9pZCxcclxuICAgICAgICBtYXR1cml0eV9wZXJpb2Q6IHJlc3BvbnNlPy5kYXRhPy5tYXR1cml0eV9wZXJpb2QsXHJcbiAgICAgICAgbWF0dXJpdHlfaW50ZXJlc3Q6IHJlc3BvbnNlPy5kYXRhPy5tYXR1cml0eV9pbnRlcmVzdCxcclxuICAgICAgICBwYXlhYmxlX2Ftb3VudDogcmVzcG9uc2U/LmRhdGE/LnBheWFibGVfYW1vdW50LFxyXG4gICAgICAgIHN0YXJ0X2RhdGU6IGZvcm1hdHRlZFN0YXJ0RGF0ZSxcclxuICAgICAgICBlbmRfZGF0ZTogZm9ybWF0dGVkRW5kRGF0ZSxcclxuICAgICAgICBub3RlOiByZXNwb25zZT8uZGF0YT8ubm90ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwaWdtZSBDdXN0b21lciBieSBJRDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoeyAuLi5wcmV2RGF0YSwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlUGlnbWUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEN1c3RvbWVyKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL3BpZ21lL2RlbGV0ZS1waWdtZS1jdXN0b21lci8ke2N1cnJlbnRDdXN0b21lci5faWR9YCk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGlnbWUgVXNlciBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudEN1c3RvbWVyKG51bGwpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBwaWdtZSBVc2VyOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wYXRjaChcclxuICAgICAgICAgIGAvcGlnbWUvdXBkYXRlLXBpZ21lLWN1c3RvbWVyLyR7Y3VycmVudFVwZGF0ZUN1c3RvbWVyLl9pZH1gLFxyXG4gICAgICAgICAgdXBkYXRlRm9ybURhdGFcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQm9ycm93ZXIgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIEJvcnJvd2VyOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJtYXR1cml0eV9wZXJpb2RcIiwgaGVhZGVyOiBcIk1hdHVyaXR5IFBlcmlvZFwiIH0sXHJcbiAgICB7IGtleTogXCJtYXR1cml0eV9pbnRlcmVzdFwiLCBoZWFkZXI6IFwiTWF0dXJpdHkgSW50ZXJlc3RcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhcnRfZGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbmRfZGF0ZVwiLCBoZWFkZXI6IFwiRHVlIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgb3ZlcmZsb3cteC1oaWRkZW5cIj5cclxuICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbXQtMjBcIj5cclxuICAgICAgIFxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi01XCI+IFJlcG9ydHMgLSBQaWdtZTwvaDE+XHJcbiAgICAgICAgICAgIFxyXG5cclxuICAgICAgICAgICAge3RhYmxlQm9ycm93ZXJzPy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24odGFibGVCb3Jyb3dlcnMsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BHcm91cHMtJHtcclxuICAgICAgICAgICAgICAgICAgdGFibGVCb3Jyb3dlcnMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICAgID8gdGFibGVCb3Jyb3dlcnNbMF0uZGF0ZSArXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIiB0byBcIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICB0YWJsZUJvcnJvd2Vyc1t0YWJsZUJvcnJvd2Vycy5sZW5ndGggLSAxXS5kYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcImVtcHR5XCJcclxuICAgICAgICAgICAgICAgIH0uY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBkYXRhPVwiUGlnbWUgRGF0YVwiXHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXt0YWJsZUJvcnJvd2Vycz8ubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSBQaWdtZVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIHsvKiA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJjdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCIgc2VsZWN0ZWQgaGlkZGVuPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lciBOYW1lXHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17dXNlci5faWR9Pnt1c2VyLmZ1bGxfbmFtZX08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggIEN1c3RvbWVyIE5hbWUgXCJcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYm9ycm93ZXJcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmN1c3RvbWVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiY3VzdG9tZXJcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKChjdXN0b21lcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Y3VzdG9tZXIuX2lkfSB2YWx1ZT17Y3VzdG9tZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzLmN1c3RvbWVyfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwibWF0dXJpdHlfcGVyaW9kXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgTWF0dXJpdHkgcGVyaW9ke1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwibWF0dXJpdHlfcGVyaW9kXCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJtYXR1cml0eV9wZXJpb2RcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubWF0dXJpdHlfcGVyaW9kfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIHNlbGVjdGVkIGhpZGRlbj5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgTWF0dXJpdHkgUGVyaW9kXHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZGFpbHlcIj5EYWlseTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwid2Vla2x5XCI+V2Vla2x5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtb250aGx5XCI+TW9udGhseTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+ICovfVxyXG4gICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIE1hdHVyaXR5IHBlcmlvZFwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cIm1hdHVyaXR5X3BlcmlvZFwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/Lm1hdHVyaXR5X3BlcmlvZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwibWF0dXJpdHlfcGVyaW9kXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtbXCJEYWlseVwiLCBcIldlZWtseVwiLCBcIk1vbnRobHlcIl0ubWFwKChwZXJpb2QpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3BlcmlvZH0gdmFsdWU9e3BlcmlvZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGVyaW9kfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMubWF0dXJpdHlfcGVyaW9kICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubWF0dXJpdHlfcGVyaW9kfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm1hdHVyaXR5X2ludGVyZXN0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1hdHVyaXR5IEludGVyZXN0XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJtYXR1cml0eV9pbnRlcmVzdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm1hdHVyaXR5X2ludGVyZXN0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm1hdHVyaXR5X2ludGVyZXN0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIE1hdHVyaXR5IEludGVyZXN0XCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGF5YWJsZV9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5YWJsZSBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlhYmxlX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnBheWFibGVfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRlbnVyZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYXlhYmxlIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlhYmxlX2Ftb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlhYmxlX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJzdGFydF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0IERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnN0YXJ0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGFydF9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXJ0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW5kX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRW5kIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW5kX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJlbmRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbmQgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBOb3RlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU3BlY2lmeSBOb3RlIGlmIGFueSFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgdy0xMCBoLTEwIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHJvdW5kZWQtbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKFwiQ2FsY3VsYXRvcjovLy9cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYUNhbGN1bGF0b3IgY29sb3I9XCJ3aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDBcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIFBpZ21lXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEN1c3RvbWVyKG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgRGVsZXRlIFBpZ21lIEN1c3RvbWVyXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50Q3VzdG9tZXIgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVQaWdtZSgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50Q3VzdG9tZXIuY3VzdG9tZXI/LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHRvIGNvbmZpcm0gZGVsZXRpb24ue1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJib3Jyb3dlck5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIFBpZ21lIEN1c3RvbWVyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMFxyXG4gICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQaWdtZVJlcG9ydDtcclxuXHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QaWdtZVJlcG9ydC5qc3gifQ==