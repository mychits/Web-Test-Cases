import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-YZVM2MHU.js?v=819e0a34";
import "/node_modules/.vite/deps/chunk-73THXJN7.js?v=819e0a34";
import "/node_modules/.vite/deps/chunk-2TUXWMP5.js?v=819e0a34";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
