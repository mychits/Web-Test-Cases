import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ConvertedLead.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Select, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
const groupOptions = [
  { value: "Today", label: "Today" },
  { value: "Yesterday", label: "Yesterday" },
  { value: "ThisMonth", label: "This Month" },
  { value: "LastMonth", label: "Last Month" },
  { value: "ThisYear", label: "This Year" },
  { value: "Custom", label: "Custom" }
];
const ConvertedLead = () => {
  _s();
  const [loadingPage, setLoadingPage] = useState(true);
  const [selectedLabel, setSelectedLabel] = useState("ThisMonth");
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [customerReferredBy, setCustomerReferredBy] = useState("");
  const [employeeReferredBy, setEmployeeReferredBy] = useState("");
  const [leadTableData, setLeadTableData] = useState([]);
  const [fetchingLeads, setFetchingLeads] = useState(false);
  const formatDateEnCA = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };
  const getIdFromValue = (val) => {
    if (!val) return "";
    return val.split("_")[1] || "";
  };
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    const today = /* @__PURE__ */ new Date();
    if (value === "Today") {
      const f = formatDateEnCA(today);
      setSelectedFromDate(f);
      setSelectedDate(f);
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(y.getDate() - 1);
      const f = formatDateEnCA(y);
      setSelectedFromDate(f);
      setSelectedDate(f);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDateEnCA(start));
      setSelectedDate(formatDateEnCA(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDateEnCA(start));
      setSelectedDate(formatDateEnCA(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDateEnCA(start));
      setSelectedDate(formatDateEnCA(end));
    } else if (value === "Custom") {
      setSelectedFromDate("");
      setSelectedDate("");
    }
  };
  useEffect(() => {
    const p1 = api.get("/user/get-user").catch(() => ({ data: [] }));
    const p2 = api.get("/agent/get").catch(() => ({ data: { agent: [] } }));
    const p3 = api.get("/employee").catch(() => ({ data: { employee: [] } }));
    const p4 = api.get("/user/get-user").catch(() => ({ data: { customer: [] } }));
    Promise.all([p1, p2, p3, p4]).then(([u, a, e, c]) => {
      setUsers(u?.data || []);
      setAgents(a?.data?.agent || []);
      setEmployees(e?.data?.employee || []);
      setCustomers(c?.data?.customer || []);
    }).finally(() => setLoadingPage(false));
  }, []);
  useEffect(() => {
    if (selectedFromDate && selectedDate) {
      fetchFilteredLeads();
    } else {
      setLeadTableData([]);
    }
  }, [selectedFromDate, selectedDate, customerReferredBy, employeeReferredBy]);
  useEffect(() => {
    if (!loadingPage) {
      handleSelectFilter("ThisMonth");
    }
  }, [loadingPage]);
  const fetchFilteredLeads = async () => {
    setFetchingLeads(true);
    try {
      const params = new URLSearchParams();
      params.append("from_date", selectedFromDate);
      params.append("to_date", selectedDate);
      if (customerReferredBy) {
        params.append("customer_id", getIdFromValue(customerReferredBy));
      }
      if (employeeReferredBy) {
        params.append("agent_id", getIdFromValue(employeeReferredBy));
      }
      const url = `/lead/converted-customer?${params.toString()}`;
      const res = await api.get(url);
      const data = res?.data?.response || [];
      const formatted = data.map((lead, index) => ({
        id: lead?._id,
        SlNo: index + 1,
        LeadName: lead?.lead_name || "",
        leadPhone: lead?.lead_phone || "",
        leadProfession: lead?.lead_profession || "",
        groupName: lead?.group_id?.group_name || "",
        leadType: lead?.lead_type || "",
        schemeType: lead?.scheme_type || "",
        referredBy: lead?.lead_agent?.name && lead?.lead_agent?.phone_number ? `${lead?.lead_agent?.name} | ${lead?.lead_agent?.phone_number}` : lead?.lead_customer?.full_name && lead?.lead_customer?.phone_number ? `${lead?.lead_customer?.full_name} | ${lead?.lead_customer?.phone_number}` : "N/A"
      }));
      setLeadTableData(formatted);
    } catch (e) {
      console.error("Fetch Error:", e);
      setLeadTableData([]);
    } finally {
      setFetchingLeads(false);
    }
  };
  const leadColumns = [
    { header: "Sl No", key: "SlNo" },
    { header: "Name", key: "LeadName" },
    { header: "Phone", key: "leadPhone" },
    { header: "Profession", key: "leadProfession" },
    { header: "Group", key: "groupName" },
    { header: "Lead Type", key: "leadType" },
    { header: "Scheme Type", key: "schemeType" },
    { header: "Referred By", key: "referredBy" }
  ];
  const isCustomMode = selectedLabel === "Custom";
  const totalConverted = leadTableData.length;
  const referredByCustomer = leadTableData.filter(
    (l) => l.referredBy !== "N/A" && customers.some((c) => `${c.full_name} | ${c.phone_number}` === l.referredBy)
  ).length;
  const referredByEmployee = leadTableData.filter(
    (l) => l.referredBy !== "N/A" && employees.some(
      (e) => `${e.full_name || e.name} | ${e.phone_number}` === l.referredBy
    )
  ).length;
  const otherReferrers = totalConverted - (referredByCustomer + referredByEmployee);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-5 w-full", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-800", children: "Report – Converted Leads" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 198,
        columnNumber: 9
      }, this),
      loadingPage && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-sm text-gray-600", children: [
        /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 203,
          columnNumber: 13
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { children: "Loading lookups..." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 203,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 202,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 197,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "Date Filter" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 211,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            showSearch: true,
            value: selectedLabel,
            onChange: handleSelectFilter,
            className: "w-full h-11",
            popupMatchSelectWidth: false,
            children: groupOptions.map(
              (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g.value, children: g.label }, g.value, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                lineNumber: 220,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
            lineNumber: 212,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 210,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "From Date" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 228,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: selectedFromDate,
            onChange: (e) => {
              setSelectedFromDate(e.target.value);
              setSelectedLabel("Custom");
            },
            disabled: !isCustomMode,
            className: `w-full h-11 border rounded-lg px-3 ${!isCustomMode ? "bg-gray-100 cursor-not-allowed" : "border-gray-300"}`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
            lineNumber: 229,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 227,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "To Date" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 244,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: selectedDate,
            onChange: (e) => {
              setSelectedDate(e.target.value);
              setSelectedLabel("Custom");
            },
            disabled: !isCustomMode,
            className: `w-full h-11 border rounded-lg px-3 ${!isCustomMode ? "bg-gray-100 cursor-not-allowed" : "border-gray-300"}`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
            lineNumber: 245,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 243,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "Customer Referred By" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 260,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            showSearch: true,
            allowClear: true,
            value: customerReferredBy,
            onChange: (v) => setCustomerReferredBy(v || ""),
            placeholder: "Select Customer Referrer",
            className: "w-full h-11",
            popupMatchSelectWidth: false,
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                lineNumber: 270,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Select.OptGroup, { label: "Users", children: users.map(
                (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `USER_${u._id}`, children: [
                  u.full_name,
                  " | ",
                  u.phone_number
                ] }, u._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                  lineNumber: 273,
                  columnNumber: 15
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                lineNumber: 271,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Select.OptGroup, { label: "Agents", children: agents.map(
                (a) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `AGENT_${a._id}`, children: [
                  a.name,
                  " | ",
                  a.phone_number
                ] }, a._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                  lineNumber: 280,
                  columnNumber: 15
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                lineNumber: 278,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Select.OptGroup, { label: "Customers", children: customers.map(
                (c) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `CUS_${c._id}`, children: [
                  c.full_name,
                  " | ",
                  c.phone_number
                ] }, c._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                  lineNumber: 287,
                  columnNumber: 15
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                lineNumber: 285,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
            lineNumber: 261,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 259,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 209,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "Employee Referred By" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 299,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Select,
        {
          showSearch: true,
          allowClear: true,
          value: employeeReferredBy,
          onChange: (v) => setEmployeeReferredBy(v || ""),
          placeholder: "Select Employee Referrer",
          className: "w-full h-11",
          children: [
            /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
              lineNumber: 308,
              columnNumber: 13
            }, this),
            employees.map(
              (e) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `EMP_${e._id}`, children: [
                e.full_name || e.name,
                " | ",
                e.phone_number
              ] }, e._id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
                lineNumber: 310,
                columnNumber: 13
              }, this)
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 300,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 298,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 297,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 border border-violet-200 rounded-lg p-4 mb-4 grid grid-cols-1 md:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "Total Converted Leads" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 321,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-violet-700", children: totalConverted }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 322,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 320,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "Referred by Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 326,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-green-700", children: referredByCustomer }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 327,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 325,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "Referred by Employee" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 331,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-purple-700", children: referredByEmployee }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 332,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 330,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "Other Referrers" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 336,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-orange-700", children: otherReferrers }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 337,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 335,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 319,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg border mb-5", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "font-semibold text-gray-700 mb-2", children: "Referrer Breakdown" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 343,
        columnNumber: 9
      }, this),
      leadTableData.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "No leads available." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 346,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1", children: [...new Set(leadTableData.map((l) => l.referredBy))].map((ref) => {
        if (!ref || ref === "N/A") return null;
        const count = leadTableData.filter((l) => l.referredBy === ref).length;
        return /* @__PURE__ */ jsxDEV("li", { className: "flex justify-between border-b py-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-800", children: ref }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
            lineNumber: 356,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-violet-700", children: count }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
            lineNumber: 357,
            columnNumber: 19
          }, this)
        ] }, ref, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
          lineNumber: 355,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
        lineNumber: 348,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 342,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow rounded-lg p-3 min-h-[200px]", children: fetchingLeads ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-16", children: /* @__PURE__ */ jsxDEV(Spin, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 369,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 368,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(DataTable, { columns: leadColumns, data: leadTableData, exportedFileName: "Converted Lead.csv", exportedPdfName: "Converted Lead" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 372,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
      lineNumber: 366,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx",
    lineNumber: 194,
    columnNumber: 5
  }, this);
};
_s(ConvertedLead, "7OKE7vjuBXQq5XqmFaF/NB7hKuo=");
_c = ConvertedLead;
export default ConvertedLead;
var _c;
$RefreshReg$(_c, "ConvertedLead");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ConvertedLead.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcU1ROzJCQXJNUjtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELFNBQVNDLFFBQVFDLFlBQVk7QUFDN0IsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBRXRCLE1BQU1DLGVBQWU7QUFBQSxFQUNuQixFQUFFQyxPQUFPLFNBQVNDLE9BQU8sUUFBUTtBQUFBLEVBQ2pDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxZQUFZO0FBQUEsRUFDekMsRUFBRUQsT0FBTyxhQUFhQyxPQUFPLGFBQWE7QUFBQSxFQUMxQyxFQUFFRCxPQUFPLGFBQWFDLE9BQU8sYUFBYTtBQUFBLEVBQzFDLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxZQUFZO0FBQUEsRUFDeEMsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLFNBQVM7QUFBQztBQUd0QyxNQUFNQyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSVosU0FBUyxJQUFJO0FBRW5ELFFBQU0sQ0FBQ2EsZUFBZUMsZ0JBQWdCLElBQUlkLFNBQVMsV0FBVztBQUM5RCxRQUFNLENBQUNlLGtCQUFrQkMsbUJBQW1CLElBQUloQixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDaUIsY0FBY0MsZUFBZSxJQUFJbEIsU0FBUyxFQUFFO0FBRW5ELFFBQU0sQ0FBQ21CLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQixRQUFRQyxTQUFTLElBQUl0QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDdUIsV0FBV0MsWUFBWSxJQUFJeEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsRUFBRTtBQUU3QyxRQUFNLENBQUMyQixvQkFBb0JDLHFCQUFxQixJQUFJNUIsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQzZCLG9CQUFvQkMscUJBQXFCLElBQUk5QixTQUFTLEVBQUU7QUFFL0QsUUFBTSxDQUFDK0IsZUFBZUMsZ0JBQWdCLElBQUloQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDaUMsZUFBZUMsZ0JBQWdCLElBQUlsQyxTQUFTLEtBQUs7QUFHeEQsUUFBTW1DLGlCQUFpQkEsQ0FBQ0MsU0FBUztBQUMvQixRQUFJLENBQUNBLEtBQU0sUUFBTztBQUNsQixVQUFNQyxJQUFJLElBQUlDLEtBQUtGLElBQUk7QUFDdkIsVUFBTUcsT0FBT0YsRUFBRUcsWUFBWTtBQUMzQixVQUFNQyxLQUFLQyxPQUFPTCxFQUFFTSxTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUNuRCxVQUFNQyxLQUFLSCxPQUFPTCxFQUFFUyxRQUFRLENBQUMsRUFBRUYsU0FBUyxHQUFHLEdBQUc7QUFDOUMsV0FBTyxHQUFHTCxJQUFJLElBQUlFLEVBQUUsSUFBSUksRUFBRTtBQUFBLEVBQzVCO0FBRUEsUUFBTUUsaUJBQWlCQSxDQUFDQyxRQUFRO0FBQzlCLFFBQUksQ0FBQ0EsSUFBSyxRQUFPO0FBQ2pCLFdBQU9BLElBQUlDLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLEVBQzlCO0FBR0EsUUFBTUMscUJBQXFCQSxDQUFDM0MsVUFBVTtBQUNwQ08scUJBQWlCUCxLQUFLO0FBRXRCLFVBQU00QyxRQUFRLG9CQUFJYixLQUFLO0FBRXZCLFFBQUkvQixVQUFVLFNBQVM7QUFDckIsWUFBTTZDLElBQUlqQixlQUFlZ0IsS0FBSztBQUM5Qm5DLDBCQUFvQm9DLENBQUM7QUFDckJsQyxzQkFBZ0JrQyxDQUFDO0FBQUEsSUFDbkIsV0FBVzdDLFVBQVUsYUFBYTtBQUNoQyxZQUFNOEMsSUFBSSxJQUFJZixLQUFLYSxLQUFLO0FBQ3hCRSxRQUFFQyxRQUFRRCxFQUFFUCxRQUFRLElBQUksQ0FBQztBQUN6QixZQUFNTSxJQUFJakIsZUFBZWtCLENBQUM7QUFDMUJyQywwQkFBb0JvQyxDQUFDO0FBQ3JCbEMsc0JBQWdCa0MsQ0FBQztBQUFBLElBQ25CLFdBQVc3QyxVQUFVLGFBQWE7QUFDaEMsWUFBTWdELFFBQVEsSUFBSWpCLEtBQUthLE1BQU1YLFlBQVksR0FBR1csTUFBTVIsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTWEsTUFBTSxJQUFJbEIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHVyxNQUFNUixTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFM0IsMEJBQW9CbUIsZUFBZW9CLEtBQUssQ0FBQztBQUN6Q3JDLHNCQUFnQmlCLGVBQWVxQixHQUFHLENBQUM7QUFBQSxJQUNyQyxXQUFXakQsVUFBVSxhQUFhO0FBQ2hDLFlBQU1nRCxRQUFRLElBQUlqQixLQUFLYSxNQUFNWCxZQUFZLEdBQUdXLE1BQU1SLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTWEsTUFBTSxJQUFJbEIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHVyxNQUFNUixTQUFTLEdBQUcsQ0FBQztBQUM3RDNCLDBCQUFvQm1CLGVBQWVvQixLQUFLLENBQUM7QUFDekNyQyxzQkFBZ0JpQixlQUFlcUIsR0FBRyxDQUFDO0FBQUEsSUFDckMsV0FBV2pELFVBQVUsWUFBWTtBQUMvQixZQUFNZ0QsUUFBUSxJQUFJakIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHLEdBQUcsQ0FBQztBQUNoRCxZQUFNZ0IsTUFBTSxJQUFJbEIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRHhCLDBCQUFvQm1CLGVBQWVvQixLQUFLLENBQUM7QUFDekNyQyxzQkFBZ0JpQixlQUFlcUIsR0FBRyxDQUFDO0FBQUEsSUFDckMsV0FBV2pELFVBQVUsVUFBVTtBQUM3QlMsMEJBQW9CLEVBQUU7QUFDdEJFLHNCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0FqQixZQUFVLE1BQU07QUFDZCxVQUFNd0QsS0FBS3JELElBQUlzRCxJQUFJLGdCQUFnQixFQUFFQyxNQUFNLE9BQU8sRUFBRUMsTUFBTSxHQUFHLEVBQUU7QUFDL0QsVUFBTUMsS0FBS3pELElBQUlzRCxJQUFJLFlBQVksRUFBRUMsTUFBTSxPQUFPLEVBQUVDLE1BQU0sRUFBRUUsT0FBTyxHQUFHLEVBQUUsRUFBRTtBQUN0RSxVQUFNQyxLQUFLM0QsSUFBSXNELElBQUksV0FBVyxFQUFFQyxNQUFNLE9BQU8sRUFBRUMsTUFBTSxFQUFFSSxVQUFVLEdBQUcsRUFBRSxFQUFFO0FBQ3hFLFVBQU1DLEtBQUs3RCxJQUFJc0QsSUFBSSxnQkFBZ0IsRUFBRUMsTUFBTSxPQUFPLEVBQUVDLE1BQU0sRUFBRU0sVUFBVSxHQUFHLEVBQUUsRUFBRTtBQUU3RUMsWUFBUUMsSUFBSSxDQUFDWCxJQUFJSSxJQUFJRSxJQUFJRSxFQUFFLENBQUMsRUFDekJJLEtBQUssQ0FBQyxDQUFDQyxHQUFHQyxHQUFHQyxHQUFHQyxDQUFDLE1BQU07QUFDdEJyRCxlQUFTa0QsR0FBR1YsUUFBUSxFQUFFO0FBQ3RCdEMsZ0JBQVVpRCxHQUFHWCxNQUFNRSxTQUFTLEVBQUU7QUFDOUJ0QyxtQkFBYWdELEdBQUdaLE1BQU1JLFlBQVksRUFBRTtBQUNwQ3RDLG1CQUFhK0MsR0FBR2IsTUFBTU0sWUFBWSxFQUFFO0FBQUEsSUFDdEMsQ0FBQyxFQUNBUSxRQUFRLE1BQU05RCxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3hDLEdBQUcsRUFBRTtBQUdMWCxZQUFVLE1BQU07QUFDZCxRQUFJYyxvQkFBb0JFLGNBQWM7QUFDcEMwRCx5QkFBbUI7QUFBQSxJQUNyQixPQUFPO0FBQ0wzQyx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUNqQixrQkFBa0JFLGNBQWNVLG9CQUFvQkUsa0JBQWtCLENBQUM7QUFHM0U1QixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNVLGFBQWE7QUFDaEJ1Qyx5QkFBbUIsV0FBVztBQUFBLElBQ2hDO0FBQUEsRUFDRixHQUFHLENBQUN2QyxXQUFXLENBQUM7QUFHaEIsUUFBTWdFLHFCQUFxQixZQUFZO0FBQ3JDekMscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNGLFlBQU0wQyxTQUFTLElBQUlDLGdCQUFnQjtBQUNuQ0QsYUFBT0UsT0FBTyxhQUFhL0QsZ0JBQWdCO0FBQzNDNkQsYUFBT0UsT0FBTyxXQUFXN0QsWUFBWTtBQUVyQyxVQUFJVSxvQkFBb0I7QUFDdEJpRCxlQUFPRSxPQUFPLGVBQWUvQixlQUFlcEIsa0JBQWtCLENBQUM7QUFBQSxNQUNqRTtBQUNBLFVBQUlFLG9CQUFvQjtBQUN0QitDLGVBQU9FLE9BQU8sWUFBWS9CLGVBQWVsQixrQkFBa0IsQ0FBQztBQUFBLE1BQzlEO0FBRUEsWUFBTWtELE1BQU0sNEJBQTRCSCxPQUFPSSxTQUFTLENBQUM7QUFDekQsWUFBTUMsTUFBTSxNQUFNN0UsSUFBSXNELElBQUlxQixHQUFHO0FBQzdCLFlBQU1uQixPQUFPcUIsS0FBS3JCLE1BQU1zQixZQUFZO0FBRXBDLFlBQU1DLFlBQVl2QixLQUFLd0IsSUFBSSxDQUFDQyxNQUFNQyxXQUFXO0FBQUEsUUFDM0NDLElBQUlGLE1BQU1HO0FBQUFBLFFBQ1ZDLE1BQU1ILFFBQVE7QUFBQSxRQUNkSSxVQUFVTCxNQUFNTSxhQUFhO0FBQUEsUUFDN0JDLFdBQVdQLE1BQU1RLGNBQWM7QUFBQSxRQUMvQkMsZ0JBQWdCVCxNQUFNVSxtQkFBbUI7QUFBQSxRQUN6Q0MsV0FBV1gsTUFBTVksVUFBVUMsY0FBYztBQUFBLFFBQ3pDQyxVQUFVZCxNQUFNZSxhQUFhO0FBQUEsUUFDN0JDLFlBQVloQixNQUFNaUIsZUFBZTtBQUFBLFFBQ2pDQyxZQUNHbEIsTUFBTW1CLFlBQVlDLFFBQVFwQixNQUFNbUIsWUFBWUUsZUFDekMsR0FBR3JCLE1BQU1tQixZQUFZQyxJQUFJLE1BQU1wQixNQUFNbUIsWUFBWUUsWUFBWSxLQUM1RHJCLE1BQU1zQixlQUFlQyxhQUFhdkIsTUFBTXNCLGVBQWVELGVBQ3hELEdBQUdyQixNQUFNc0IsZUFBZUMsU0FBUyxNQUFNdkIsTUFBTXNCLGVBQWVELFlBQVksS0FDeEU7QUFBQSxNQUNSLEVBQUU7QUFFRjFFLHVCQUFpQm1ELFNBQVM7QUFBQSxJQUM1QixTQUFTWCxHQUFHO0FBQ1ZxQyxjQUFRQyxNQUFNLGdCQUFnQnRDLENBQUM7QUFDL0J4Qyx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCLFVBQUM7QUFDQ0UsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNkUsY0FBYztBQUFBLElBQ2xCLEVBQUVDLFFBQVEsU0FBU0MsS0FBSyxPQUFPO0FBQUEsSUFDL0IsRUFBRUQsUUFBUSxRQUFRQyxLQUFLLFdBQVc7QUFBQSxJQUNsQyxFQUFFRCxRQUFRLFNBQVNDLEtBQUssWUFBWTtBQUFBLElBQ3BDLEVBQUVELFFBQVEsY0FBY0MsS0FBSyxpQkFBaUI7QUFBQSxJQUM5QyxFQUFFRCxRQUFRLFNBQVNDLEtBQUssWUFBWTtBQUFBLElBQ3BDLEVBQUVELFFBQVEsYUFBYUMsS0FBSyxXQUFXO0FBQUEsSUFDdkMsRUFBRUQsUUFBUSxlQUFlQyxLQUFLLGFBQWE7QUFBQSxJQUMzQyxFQUFFRCxRQUFRLGVBQWVDLEtBQUssYUFBYTtBQUFBLEVBQUM7QUFHOUMsUUFBTUMsZUFBZXJHLGtCQUFrQjtBQUd2QyxRQUFNc0csaUJBQWlCcEYsY0FBY3FGO0FBQ3JDLFFBQU1DLHFCQUFxQnRGLGNBQWN1RjtBQUFBQSxJQUFPLENBQUFDLE1BQzlDQSxFQUFFaEIsZUFBZSxTQUNqQjlFLFVBQVUrRixLQUFLLENBQUEvQyxNQUFLLEdBQUdBLEVBQUVtQyxTQUFTLE1BQU1uQyxFQUFFaUMsWUFBWSxPQUFPYSxFQUFFaEIsVUFBVTtBQUFBLEVBQzNFLEVBQUVhO0FBRUYsUUFBTUsscUJBQXFCMUYsY0FBY3VGO0FBQUFBLElBQU8sQ0FBQUMsTUFDOUNBLEVBQUVoQixlQUFlLFNBQ2pCaEYsVUFBVWlHO0FBQUFBLE1BQUssQ0FBQWhELE1BQ2IsR0FBR0EsRUFBRW9DLGFBQWFwQyxFQUFFaUMsSUFBSSxNQUFNakMsRUFBRWtDLFlBQVksT0FBT2EsRUFBRWhCO0FBQUFBLElBQ3ZEO0FBQUEsRUFDRixFQUFFYTtBQUVGLFFBQU1NLGlCQUFpQlAsa0JBQWtCRSxxQkFBcUJJO0FBRTlELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBR2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDOUcsZUFDQyx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSwrQkFBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtCO0FBQUEsUUFBRztBQUFBLFFBQUMsdUJBQUMsVUFBSyxrQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsV0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHVCQUFzQiwyQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQ2xEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsT0FBT0U7QUFBQUEsWUFDUCxVQUFVcUM7QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFDVix1QkFBdUI7QUFBQSxZQUV0QjVDLHVCQUFhOEU7QUFBQUEsY0FBSSxDQUFDdUMsTUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLEVBQUVwSCxPQUNuQ29ILFlBQUVuSCxTQURlbUgsRUFBRXBILE9BQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxZQUNEO0FBQUE7QUFBQSxVQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHVCQUFzQix5QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQ2hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPUTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3lELE1BQU07QUFDZnhELGtDQUFvQndELEVBQUVvRCxPQUFPckgsS0FBSztBQUNsQ08sK0JBQWlCLFFBQVE7QUFBQSxZQUMzQjtBQUFBLFlBQ0EsVUFBVSxDQUFDb0c7QUFBQUEsWUFDWCxXQUFXLHNDQUNULENBQUNBLGVBQWUsbUNBQW1DLGlCQUFpQjtBQUFBO0FBQUEsVUFUeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUs7QUFBQSxXQVpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLHVCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9qRztBQUFBQSxZQUNQLFVBQVUsQ0FBQ3VELE1BQU07QUFDZnRELDhCQUFnQnNELEVBQUVvRCxPQUFPckgsS0FBSztBQUM5Qk8sK0JBQWlCLFFBQVE7QUFBQSxZQUMzQjtBQUFBLFlBQ0EsVUFBVSxDQUFDb0c7QUFBQUEsWUFDWCxXQUFXLHNDQUNULENBQUNBLGVBQWUsbUNBQW1DLGlCQUFpQjtBQUFBO0FBQUEsVUFUeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUs7QUFBQSxXQVpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLG9DQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQTtBQUFBLFlBQ0EsT0FBT3ZGO0FBQUFBLFlBQ1AsVUFBVSxDQUFDa0csTUFBTWpHLHNCQUFzQmlHLEtBQUssRUFBRTtBQUFBLFlBQzlDLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQSxZQUNWLHVCQUF1QjtBQUFBLFlBRXZCO0FBQUEscUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQzNCLHVCQUFDLE9BQU8sVUFBUCxFQUFnQixPQUFNLFNBQ3BCMUcsZ0JBQU1pRTtBQUFBQSxnQkFBSSxDQUFDZCxNQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPLFFBQVFBLEVBQUVrQixHQUFHLElBQzVDbEI7QUFBQUEsb0JBQUVzQztBQUFBQSxrQkFBVTtBQUFBLGtCQUFJdEMsRUFBRW9DO0FBQUFBLHFCQUREcEMsRUFBRWtCLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGNBQ0EsdUJBQUMsT0FBTyxVQUFQLEVBQWdCLE9BQU0sVUFDcEJuRSxpQkFBTytEO0FBQUFBLGdCQUFJLENBQUNiLE1BQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU8sU0FBU0EsRUFBRWlCLEdBQUcsSUFDN0NqQjtBQUFBQSxvQkFBRWtDO0FBQUFBLGtCQUFLO0FBQUEsa0JBQUlsQyxFQUFFbUM7QUFBQUEscUJBREluQyxFQUFFaUIsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FDQSx1QkFBQyxPQUFPLFVBQVAsRUFBZ0IsT0FBTSxhQUNwQi9ELG9CQUFVMkQ7QUFBQUEsZ0JBQUksQ0FBQ1gsTUFDZCx1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBTyxPQUFPQSxFQUFFZSxHQUFHLElBQzNDZjtBQUFBQSxvQkFBRW1DO0FBQUFBLGtCQUFVO0FBQUEsa0JBQUluQyxFQUFFaUM7QUFBQUEscUJBRERqQyxFQUFFZSxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQTtBQUFBO0FBQUEsVUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBK0JBO0FBQUEsV0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQTtBQUFBLFNBcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxRkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYixpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFdBQU0sV0FBVSx1QkFBc0Isb0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxNQUMzRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQSxPQUFPM0Q7QUFBQUEsVUFDUCxVQUFVLENBQUNnRyxNQUFNL0Ysc0JBQXNCK0YsS0FBSyxFQUFFO0FBQUEsVUFDOUMsYUFBWTtBQUFBLFVBQ1osV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFDMUJ0RyxVQUFVNkQ7QUFBQUEsY0FBSSxDQUFDWixNQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPLE9BQU9BLEVBQUVnQixHQUFHLElBQzNDaEI7QUFBQUEsa0JBQUVvQyxhQUFhcEMsRUFBRWlDO0FBQUFBLGdCQUFLO0FBQUEsZ0JBQUlqQyxFQUFFa0M7QUFBQUEsbUJBRFhsQyxFQUFFZ0IsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBO0FBQUEsUUFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFjQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG1HQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUseUJBQXdCLHFDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsT0FBRSxXQUFVLHFDQUFxQzJCLDRCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsV0FGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSx5QkFBd0Isb0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxRQUN6RCx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DRSxnQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUseUJBQXdCLG9DQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsUUFDekQsdUJBQUMsT0FBRSxXQUFVLHFDQUFxQ0ksZ0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxXQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLE9BQUUsV0FBVSxxQ0FBcUNDLDRCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsV0FGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLG9DQUFtQyxrQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BRWxFM0YsY0FBY3FGLFdBQVcsSUFDeEIsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QixtQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RCxJQUV4RCx1QkFBQyxRQUFHLFdBQVUsYUFDWCxXQUFDLEdBQUcsSUFBSVUsSUFBSS9GLGNBQWNxRCxJQUFJLENBQUNtQyxNQUFNQSxFQUFFaEIsVUFBVSxDQUFDLENBQUMsRUFBRW5CLElBQUksQ0FBQzJDLFFBQVE7QUFDakUsWUFBSSxDQUFDQSxPQUFPQSxRQUFRLE1BQU8sUUFBTztBQUVsQyxjQUFNQyxRQUFRakcsY0FBY3VGLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWhCLGVBQWV3QixHQUFHLEVBQUVYO0FBRWhFLGVBQ0UsdUJBQUMsUUFBYSxXQUFVLHNDQUN0QjtBQUFBLGlDQUFDLFVBQUssV0FBVSw2QkFBNkJXLGlCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2pELHVCQUFDLFVBQUssV0FBVSw2QkFBNkJDLG1CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLGFBRjVDRCxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLE1BRUosQ0FBQyxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDWjlGLDBCQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSyxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLHVCQUFDLGFBQVUsU0FBUzhFLGFBQWEsTUFBTWhGLGVBQWUsa0JBQWlCLHNCQUFxQixpQkFBZ0Isb0JBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEgsS0FOaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0FwTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFMQTtBQUVKO0FBc1ZBckIsR0Foc0JNRCxlQUFhO0FBQUF3SCxLQUFieEg7QUF1c0JOLGVBQWVBO0FBQWMsSUFBQXdIO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIlNlbGVjdCIsIlNwaW4iLCJhcGkiLCJEYXRhVGFibGUiLCJncm91cE9wdGlvbnMiLCJ2YWx1ZSIsImxhYmVsIiwiQ29udmVydGVkTGVhZCIsIl9zIiwibG9hZGluZ1BhZ2UiLCJzZXRMb2FkaW5nUGFnZSIsInNlbGVjdGVkTGFiZWwiLCJzZXRTZWxlY3RlZExhYmVsIiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJ1c2VycyIsInNldFVzZXJzIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiY3VzdG9tZXJzIiwic2V0Q3VzdG9tZXJzIiwiY3VzdG9tZXJSZWZlcnJlZEJ5Iiwic2V0Q3VzdG9tZXJSZWZlcnJlZEJ5IiwiZW1wbG95ZWVSZWZlcnJlZEJ5Iiwic2V0RW1wbG95ZWVSZWZlcnJlZEJ5IiwibGVhZFRhYmxlRGF0YSIsInNldExlYWRUYWJsZURhdGEiLCJmZXRjaGluZ0xlYWRzIiwic2V0RmV0Y2hpbmdMZWFkcyIsImZvcm1hdERhdGVFbkNBIiwiZGF0ZSIsImQiLCJEYXRlIiwieXl5eSIsImdldEZ1bGxZZWFyIiwibW0iLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwiZGQiLCJnZXREYXRlIiwiZ2V0SWRGcm9tVmFsdWUiLCJ2YWwiLCJzcGxpdCIsImhhbmRsZVNlbGVjdEZpbHRlciIsInRvZGF5IiwiZiIsInkiLCJzZXREYXRlIiwic3RhcnQiLCJlbmQiLCJwMSIsImdldCIsImNhdGNoIiwiZGF0YSIsInAyIiwiYWdlbnQiLCJwMyIsImVtcGxveWVlIiwicDQiLCJjdXN0b21lciIsIlByb21pc2UiLCJhbGwiLCJ0aGVuIiwidSIsImEiLCJlIiwiYyIsImZpbmFsbHkiLCJmZXRjaEZpbHRlcmVkTGVhZHMiLCJwYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJhcHBlbmQiLCJ1cmwiLCJ0b1N0cmluZyIsInJlcyIsInJlc3BvbnNlIiwiZm9ybWF0dGVkIiwibWFwIiwibGVhZCIsImluZGV4IiwiaWQiLCJfaWQiLCJTbE5vIiwiTGVhZE5hbWUiLCJsZWFkX25hbWUiLCJsZWFkUGhvbmUiLCJsZWFkX3Bob25lIiwibGVhZFByb2Zlc3Npb24iLCJsZWFkX3Byb2Zlc3Npb24iLCJncm91cE5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJsZWFkVHlwZSIsImxlYWRfdHlwZSIsInNjaGVtZVR5cGUiLCJzY2hlbWVfdHlwZSIsInJlZmVycmVkQnkiLCJsZWFkX2FnZW50IiwibmFtZSIsInBob25lX251bWJlciIsImxlYWRfY3VzdG9tZXIiLCJmdWxsX25hbWUiLCJjb25zb2xlIiwiZXJyb3IiLCJsZWFkQ29sdW1ucyIsImhlYWRlciIsImtleSIsImlzQ3VzdG9tTW9kZSIsInRvdGFsQ29udmVydGVkIiwibGVuZ3RoIiwicmVmZXJyZWRCeUN1c3RvbWVyIiwiZmlsdGVyIiwibCIsInNvbWUiLCJyZWZlcnJlZEJ5RW1wbG95ZWUiLCJvdGhlclJlZmVycmVycyIsImciLCJ0YXJnZXQiLCJ2IiwiU2V0IiwicmVmIiwiY291bnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb252ZXJ0ZWRMZWFkLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIFNwaW4gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuXHJcbmNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICB7IHZhbHVlOiBcIlRvZGF5XCIsIGxhYmVsOiBcIlRvZGF5XCIgfSxcclxuICB7IHZhbHVlOiBcIlllc3RlcmRheVwiLCBsYWJlbDogXCJZZXN0ZXJkYXlcIiB9LFxyXG4gIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gIHsgdmFsdWU6IFwiTGFzdE1vbnRoXCIsIGxhYmVsOiBcIkxhc3QgTW9udGhcIiB9LFxyXG4gIHsgdmFsdWU6IFwiVGhpc1llYXJcIiwgbGFiZWw6IFwiVGhpcyBZZWFyXCIgfSxcclxuICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG5dO1xyXG5cclxuY29uc3QgQ29udmVydGVkTGVhZCA9ICgpID0+IHtcclxuICBjb25zdCBbbG9hZGluZ1BhZ2UsIHNldExvYWRpbmdQYWdlXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIlRoaXNNb250aFwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VzdG9tZXJzLCBzZXRDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbY3VzdG9tZXJSZWZlcnJlZEJ5LCBzZXRDdXN0b21lclJlZmVycmVkQnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2VtcGxveWVlUmVmZXJyZWRCeSwgc2V0RW1wbG95ZWVSZWZlcnJlZEJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBbbGVhZFRhYmxlRGF0YSwgc2V0TGVhZFRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZldGNoaW5nTGVhZHMsIHNldEZldGNoaW5nTGVhZHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEZPUk1BVCBEQVRFIC0tLS0tLS0tLS1cclxuICBjb25zdCBmb3JtYXREYXRlRW5DQSA9IChkYXRlKSA9PiB7XHJcbiAgICBpZiAoIWRhdGUpIHJldHVybiBcIlwiO1xyXG4gICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgY29uc3QgeXl5eSA9IGQuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1tID0gU3RyaW5nKGQuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIGNvbnN0IGRkID0gU3RyaW5nKGQuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICByZXR1cm4gYCR7eXl5eX0tJHttbX0tJHtkZH1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldElkRnJvbVZhbHVlID0gKHZhbCkgPT4ge1xyXG4gICAgaWYgKCF2YWwpIHJldHVybiBcIlwiO1xyXG4gICAgcmV0dXJuIHZhbC5zcGxpdChcIl9cIilbMV0gfHwgXCJcIjtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLSBEQVRFIEZJTFRFUiBTRUxFQ1QgLS0tLS0tLS1cclxuICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBjb25zdCBmID0gZm9ybWF0RGF0ZUVuQ0EodG9kYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGYpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgIGNvbnN0IHkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHkuc2V0RGF0ZSh5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICBjb25zdCBmID0gZm9ybWF0RGF0ZUVuQ0EoeSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZik7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGVFbkNBKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlRW5DQShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGVFbkNBKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlRW5DQShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGVFbkNBKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlRW5DQShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShcIlwiKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gTE9BRCBMT09LVVBTIC0tLS0tLS0tLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgcDEgPSBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIikuY2F0Y2goKCkgPT4gKHsgZGF0YTogW10gfSkpO1xyXG4gICAgY29uc3QgcDIgPSBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKS5jYXRjaCgoKSA9PiAoeyBkYXRhOiB7IGFnZW50OiBbXSB9IH0pKTtcclxuICAgIGNvbnN0IHAzID0gYXBpLmdldChcIi9lbXBsb3llZVwiKS5jYXRjaCgoKSA9PiAoeyBkYXRhOiB7IGVtcGxveWVlOiBbXSB9IH0pKTtcclxuICAgIGNvbnN0IHA0ID0gYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpLmNhdGNoKCgpID0+ICh7IGRhdGE6IHsgY3VzdG9tZXI6IFtdIH0gfSkpO1xyXG5cclxuICAgIFByb21pc2UuYWxsKFtwMSwgcDIsIHAzLCBwNF0pXHJcbiAgICAgIC50aGVuKChbdSwgYSwgZSwgY10pID0+IHtcclxuICAgICAgICBzZXRVc2Vycyh1Py5kYXRhIHx8IFtdKTtcclxuICAgICAgICBzZXRBZ2VudHMoYT8uZGF0YT8uYWdlbnQgfHwgW10pO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhlPy5kYXRhPy5lbXBsb3llZSB8fCBbXSk7XHJcbiAgICAgICAgc2V0Q3VzdG9tZXJzKGM/LmRhdGE/LmN1c3RvbWVyIHx8IFtdKTtcclxuICAgICAgfSlcclxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZ1BhZ2UoZmFsc2UpKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gRkVUQ0ggV0hFTiBGSUxURVIgQ0hBTkdFUyAtLS0tLS0tLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEZyb21EYXRlICYmIHNlbGVjdGVkRGF0ZSkge1xyXG4gICAgICBmZXRjaEZpbHRlcmVkTGVhZHMoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldExlYWRUYWJsZURhdGEoW10pO1xyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZERhdGUsIGN1c3RvbWVyUmVmZXJyZWRCeSwgZW1wbG95ZWVSZWZlcnJlZEJ5XSk7XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gSU5JVElBTCBERUZBVUxUIEZJTFRFUiAtLS0tLS0tLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghbG9hZGluZ1BhZ2UpIHtcclxuICAgICAgaGFuZGxlU2VsZWN0RmlsdGVyKFwiVGhpc01vbnRoXCIpO1xyXG4gICAgfVxyXG4gIH0sIFtsb2FkaW5nUGFnZV0pO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEFQSSBDQUxMIC0tLS0tLS0tLS1cclxuICBjb25zdCBmZXRjaEZpbHRlcmVkTGVhZHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRGZXRjaGluZ0xlYWRzKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKFwiZnJvbV9kYXRlXCIsIHNlbGVjdGVkRnJvbURhdGUpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKFwidG9fZGF0ZVwiLCBzZWxlY3RlZERhdGUpO1xyXG5cclxuICAgICAgaWYgKGN1c3RvbWVyUmVmZXJyZWRCeSkge1xyXG4gICAgICAgIHBhcmFtcy5hcHBlbmQoXCJjdXN0b21lcl9pZFwiLCBnZXRJZEZyb21WYWx1ZShjdXN0b21lclJlZmVycmVkQnkpKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoZW1wbG95ZWVSZWZlcnJlZEJ5KSB7XHJcbiAgICAgICAgcGFyYW1zLmFwcGVuZChcImFnZW50X2lkXCIsIGdldElkRnJvbVZhbHVlKGVtcGxveWVlUmVmZXJyZWRCeSkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB1cmwgPSBgL2xlYWQvY29udmVydGVkLWN1c3RvbWVyPyR7cGFyYW1zLnRvU3RyaW5nKCl9YDtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG4gICAgICBjb25zdCBkYXRhID0gcmVzPy5kYXRhPy5yZXNwb25zZSB8fCBbXTtcclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGRhdGEubWFwKChsZWFkLCBpbmRleCkgPT4gKHtcclxuICAgICAgICBpZDogbGVhZD8uX2lkLFxyXG4gICAgICAgIFNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICBMZWFkTmFtZTogbGVhZD8ubGVhZF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgbGVhZFBob25lOiBsZWFkPy5sZWFkX3Bob25lIHx8IFwiXCIsXHJcbiAgICAgICAgbGVhZFByb2Zlc3Npb246IGxlYWQ/LmxlYWRfcHJvZmVzc2lvbiB8fCBcIlwiLFxyXG4gICAgICAgIGdyb3VwTmFtZTogbGVhZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJcIixcclxuICAgICAgICBsZWFkVHlwZTogbGVhZD8ubGVhZF90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgc2NoZW1lVHlwZTogbGVhZD8uc2NoZW1lX3R5cGUgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZEJ5OlxyXG4gICAgICAgICAgKGxlYWQ/LmxlYWRfYWdlbnQ/Lm5hbWUgJiYgbGVhZD8ubGVhZF9hZ2VudD8ucGhvbmVfbnVtYmVyKVxyXG4gICAgICAgICAgICA/IGAke2xlYWQ/LmxlYWRfYWdlbnQ/Lm5hbWV9IHwgJHtsZWFkPy5sZWFkX2FnZW50Py5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICA6IChsZWFkPy5sZWFkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiYgbGVhZD8ubGVhZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyKVxyXG4gICAgICAgICAgICA/IGAke2xlYWQ/LmxlYWRfY3VzdG9tZXI/LmZ1bGxfbmFtZX0gfCAke2xlYWQ/LmxlYWRfY3VzdG9tZXI/LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgIDogXCJOL0FcIixcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0TGVhZFRhYmxlRGF0YShmb3JtYXR0ZWQpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmV0Y2ggRXJyb3I6XCIsIGUpO1xyXG4gICAgICBzZXRMZWFkVGFibGVEYXRhKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldEZldGNoaW5nTGVhZHMoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gVEFCTEUgQ09MVU1OUyAtLS0tLS0tLS0tXHJcbiAgY29uc3QgbGVhZENvbHVtbnMgPSBbXHJcbiAgICB7IGhlYWRlcjogXCJTbCBOb1wiLCBrZXk6IFwiU2xOb1wiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJOYW1lXCIsIGtleTogXCJMZWFkTmFtZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJQaG9uZVwiLCBrZXk6IFwibGVhZFBob25lXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIlByb2Zlc3Npb25cIiwga2V5OiBcImxlYWRQcm9mZXNzaW9uXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIkdyb3VwXCIsIGtleTogXCJncm91cE5hbWVcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiTGVhZCBUeXBlXCIsIGtleTogXCJsZWFkVHlwZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJTY2hlbWUgVHlwZVwiLCBrZXk6IFwic2NoZW1lVHlwZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiLCBrZXk6IFwicmVmZXJyZWRCeVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaXNDdXN0b21Nb2RlID0gc2VsZWN0ZWRMYWJlbCA9PT0gXCJDdXN0b21cIjtcclxuXHJcbiAgLy8gLS0tLS0tLS0tLSBTVU1NQVJZIExJS0UgTk9OLUNPTlZFUlRFRCAtLS0tLS0tLS0tXHJcbiAgY29uc3QgdG90YWxDb252ZXJ0ZWQgPSBsZWFkVGFibGVEYXRhLmxlbmd0aDtcclxuICBjb25zdCByZWZlcnJlZEJ5Q3VzdG9tZXIgPSBsZWFkVGFibGVEYXRhLmZpbHRlcihsID0+XHJcbiAgICBsLnJlZmVycmVkQnkgIT09IFwiTi9BXCIgJiZcclxuICAgIGN1c3RvbWVycy5zb21lKGMgPT4gYCR7Yy5mdWxsX25hbWV9IHwgJHtjLnBob25lX251bWJlcn1gID09PSBsLnJlZmVycmVkQnkpXHJcbiAgKS5sZW5ndGg7XHJcblxyXG4gIGNvbnN0IHJlZmVycmVkQnlFbXBsb3llZSA9IGxlYWRUYWJsZURhdGEuZmlsdGVyKGwgPT5cclxuICAgIGwucmVmZXJyZWRCeSAhPT0gXCJOL0FcIiAmJlxyXG4gICAgZW1wbG95ZWVzLnNvbWUoZSA9PlxyXG4gICAgICBgJHtlLmZ1bGxfbmFtZSB8fCBlLm5hbWV9IHwgJHtlLnBob25lX251bWJlcn1gID09PSBsLnJlZmVycmVkQnlcclxuICAgIClcclxuICApLmxlbmd0aDtcclxuXHJcbiAgY29uc3Qgb3RoZXJSZWZlcnJlcnMgPSB0b3RhbENvbnZlcnRlZCAtIChyZWZlcnJlZEJ5Q3VzdG9tZXIgKyByZWZlcnJlZEJ5RW1wbG95ZWUpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgdy1mdWxsXCI+XHJcblxyXG4gICAgICB7LyogSEVBREVSICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICBSZXBvcnQg4oCTIENvbnZlcnRlZCBMZWFkc1xyXG4gICAgICAgIDwvaDE+XHJcbiAgICAgICAge2xvYWRpbmdQYWdlICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgIDxTcGluIHNpemU9XCJzbWFsbFwiIC8+IDxzcGFuPkxvYWRpbmcgbG9va3Vwcy4uLjwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEZJTFRFUiBST1cgMSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5EYXRlIEZpbHRlcjwvbGFiZWw+XHJcbiAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWx9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTZWxlY3RGaWx0ZXJ9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2cudmFsdWV9IHZhbHVlPXtnLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgIHtnLmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+RnJvbSBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZExhYmVsKFwiQ3VzdG9tXCIpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IWlzQ3VzdG9tTW9kZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGgtMTEgYm9yZGVyIHJvdW5kZWQtbGcgcHgtMyAke1xyXG4gICAgICAgICAgICAgICFpc0N1c3RvbU1vZGUgPyBcImJnLWdyYXktMTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiIDogXCJib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlRvIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZExhYmVsKFwiQ3VzdG9tXCIpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IWlzQ3VzdG9tTW9kZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGgtMTEgYm9yZGVyIHJvdW5kZWQtbGcgcHgtMyAke1xyXG4gICAgICAgICAgICAgICFpc0N1c3RvbU1vZGUgPyBcImJnLWdyYXktMTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiIDogXCJib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPkN1c3RvbWVyIFJlZmVycmVkIEJ5PC9sYWJlbD5cclxuICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgIHZhbHVlPXtjdXN0b21lclJlZmVycmVkQnl9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0Q3VzdG9tZXJSZWZlcnJlZEJ5KHYgfHwgXCJcIil9XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyIFJlZmVycmVyXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgPFNlbGVjdC5PcHRHcm91cCBsYWJlbD1cIlVzZXJzXCI+XHJcbiAgICAgICAgICAgICAge3VzZXJzLm1hcCgodSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1Ll9pZH0gdmFsdWU9e2BVU0VSXyR7dS5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgIHt1LmZ1bGxfbmFtZX0gfCB7dS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0Lk9wdEdyb3VwPlxyXG4gICAgICAgICAgICA8U2VsZWN0Lk9wdEdyb3VwIGxhYmVsPVwiQWdlbnRzXCI+XHJcbiAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGEpID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YS5faWR9IHZhbHVlPXtgQUdFTlRfJHthLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAge2EubmFtZX0gfCB7YS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0Lk9wdEdyb3VwPlxyXG4gICAgICAgICAgICA8U2VsZWN0Lk9wdEdyb3VwIGxhYmVsPVwiQ3VzdG9tZXJzXCI+XHJcbiAgICAgICAgICAgICAge2N1c3RvbWVycy5tYXAoKGMpID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Yy5faWR9IHZhbHVlPXtgQ1VTXyR7Yy5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgIHtjLmZ1bGxfbmFtZX0gfCB7Yy5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0Lk9wdEdyb3VwPlxyXG4gICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEZJTFRFUiBST1cgMiAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5FbXBsb3llZSBSZWZlcnJlZCBCeTwvbGFiZWw+XHJcbiAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWVSZWZlcnJlZEJ5fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KHYpID0+IHNldEVtcGxveWVlUmVmZXJyZWRCeSh2IHx8IFwiXCIpfVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZSBSZWZlcnJlclwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlKSA9PiAoXHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlLl9pZH0gdmFsdWU9e2BFTVBfJHtlLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgIHtlLmZ1bGxfbmFtZSB8fCBlLm5hbWV9IHwge2UucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogU1VNTUFSWSDigJQgU0FNRSBBUyBOT04tQ09OVkVSVEVEICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDAgcm91bmRlZC1sZyBwLTQgbWItNCBncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCB0ZXh0LXNtXCI+VG90YWwgQ29udmVydGVkIExlYWRzPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC12aW9sZXQtNzAwXCI+e3RvdGFsQ29udmVydGVkfTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCB0ZXh0LXNtXCI+UmVmZXJyZWQgYnkgQ3VzdG9tZXI8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPntyZWZlcnJlZEJ5Q3VzdG9tZXJ9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIHRleHQtc21cIj5SZWZlcnJlZCBieSBFbXBsb3llZTwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMFwiPntyZWZlcnJlZEJ5RW1wbG95ZWV9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIHRleHQtc21cIj5PdGhlciBSZWZlcnJlcnM8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS03MDBcIj57b3RoZXJSZWZlcnJlcnN9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiDinIUgUkVGRVJSRVIgQlJFQUtET1dOIChBRERFRCBIRVJFKSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBib3JkZXIgbWItNVwiPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlJlZmVycmVyIEJyZWFrZG93bjwvaDI+XHJcblxyXG4gICAgICAgIHtsZWFkVGFibGVEYXRhLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPk5vIGxlYWRzIGF2YWlsYWJsZS48L3A+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAge1suLi5uZXcgU2V0KGxlYWRUYWJsZURhdGEubWFwKChsKSA9PiBsLnJlZmVycmVkQnkpKV0ubWFwKChyZWYpID0+IHtcclxuICAgICAgICAgICAgICBpZiAoIXJlZiB8fCByZWYgPT09IFwiTi9BXCIpIHJldHVybiBudWxsO1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCBjb3VudCA9IGxlYWRUYWJsZURhdGEuZmlsdGVyKChsKSA9PiBsLnJlZmVycmVkQnkgPT09IHJlZikubGVuZ3RoO1xyXG5cclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGxpIGtleT17cmVmfSBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBweS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj57cmVmfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPntjb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC91bD5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBUQUJMRSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBzaGFkb3cgcm91bmRlZC1sZyBwLTMgbWluLWgtWzIwMHB4XVwiPlxyXG4gICAgICAgIHtmZXRjaGluZ0xlYWRzID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTE2XCI+XHJcbiAgICAgICAgICAgIDxTcGluIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPERhdGFUYWJsZSBjb2x1bW5zPXtsZWFkQ29sdW1uc30gZGF0YT17bGVhZFRhYmxlRGF0YX0gZXhwb3J0ZWRGaWxlTmFtZT1cIkNvbnZlcnRlZCBMZWFkLmNzdlwiIGV4cG9ydGVkUGRmTmFtZT1cIkNvbnZlcnRlZCBMZWFkXCIgLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG4vLyBjb25zdCBDb252ZXJ0ZWRMZWFkID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IFtsb2FkaW5nUGFnZSwgc2V0TG9hZGluZ1BhZ2VdID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiVGhpc01vbnRoXCIpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEZyb21EYXRlLCBzZXRTZWxlY3RlZEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbi8vICAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtjdXN0b21lcnMsIHNldEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4vLyAgIGNvbnN0IFtjdXN0b21lclJlZmVycmVkQnksIHNldEN1c3RvbWVyUmVmZXJyZWRCeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbZW1wbG95ZWVSZWZlcnJlZEJ5LCBzZXRFbXBsb3llZVJlZmVycmVkQnldID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIGNvbnN0IFtjb252ZXJ0ZWRMZWFkcywgc2V0Q29udmVydGVkTGVhZHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtub25Db252ZXJ0ZWRMZWFkcywgc2V0Tm9uQ29udmVydGVkTGVhZHNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuLy8gICBjb25zdCBbbG9hZGluZ0RhdGEsIHNldExvYWRpbmdEYXRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgLy8gLS0tLS0tLS0tLSBGT1JNQVQgREFURSAtLS0tLS0tLS0tXHJcbi8vICAgY29uc3QgZm9ybWF0RGF0ZUVuQ0EgPSAoZGF0ZSkgPT4ge1xyXG4vLyAgICAgaWYgKCFkYXRlKSByZXR1cm4gXCJcIjtcclxuLy8gICAgIGNvbnN0IGQgPSBuZXcgRGF0ZShkYXRlKTtcclxuLy8gICAgIGNvbnN0IHl5eXkgPSBkLmdldEZ1bGxZZWFyKCk7XHJcbi8vICAgICBjb25zdCBtbSA9IFN0cmluZyhkLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbi8vICAgICBjb25zdCBkZCA9IFN0cmluZyhkLmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4vLyAgICAgcmV0dXJuIGAke3l5eXl9LSR7bW19LSR7ZGR9YDtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBnZXRJZEZyb21WYWx1ZSA9ICh2YWwpID0+ICh2YWwgPyB2YWwuc3BsaXQoXCJfXCIpWzFdIDogXCJcIik7XHJcblxyXG4vLyAgIC8vIC0tLS0tLS0tIERBVEUgRklMVEVSIFNFTEVDVCAtLS0tLS0tLVxyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcblxyXG4vLyAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG5cclxuLy8gICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbi8vICAgICAgIGNvbnN0IGYgPSBmb3JtYXREYXRlRW5DQSh0b2RheSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZik7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgeS5zZXREYXRlKHkuZ2V0RGF0ZSgpIC0gMSk7XHJcbi8vICAgICAgIGNvbnN0IGYgPSBmb3JtYXREYXRlRW5DQSh5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGYpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZUVuQ0Eoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGVFbkNBKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZUVuQ0Eoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGVFbkNBKGVuZCkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZUVuQ0EobmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSkpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGVFbkNBKG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSkpKTtcclxuLy8gICAgIH0gZWxzZSB7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoXCJcIik7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tIExPQUQgTE9PS1VQUyAtLS0tLS0tLS0tXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGNvbnN0IHAxID0gYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpLmNhdGNoKCgpID0+ICh7IGRhdGE6IFtdIH0pKTtcclxuLy8gICAgIGNvbnN0IHAyID0gYXBpLmdldChcIi9hZ2VudC9nZXRcIikuY2F0Y2goKCkgPT4gKHsgZGF0YTogeyBhZ2VudDogW10gfSB9KSk7XHJcbi8vICAgICBjb25zdCBwMyA9IGFwaS5nZXQoXCIvZW1wbG95ZWVcIikuY2F0Y2goKCkgPT4gKHsgZGF0YTogeyBlbXBsb3llZTogW10gfSB9KSk7XHJcbi8vICAgICBjb25zdCBwNCA9IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKS5jYXRjaCgoKSA9PiAoeyBkYXRhOiB7IGN1c3RvbWVyOiBbXSB9IH0pKTtcclxuXHJcbi8vICAgICBQcm9taXNlLmFsbChbcDEsIHAyLCBwMywgcDRdKVxyXG4vLyAgICAgICAudGhlbigoW3UsIGEsIGUsIGNdKSA9PiB7XHJcbi8vICAgICAgICAgc2V0VXNlcnModT8uZGF0YSB8fCBbXSk7XHJcbi8vICAgICAgICAgc2V0QWdlbnRzKGE/LmRhdGE/LmFnZW50IHx8IFtdKTtcclxuLy8gICAgICAgICBzZXRFbXBsb3llZXMoZT8uZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgICAgIHNldEN1c3RvbWVycyhjPy5kYXRhPy5jdXN0b21lciB8fCBbXSk7XHJcbi8vICAgICAgIH0pXHJcbi8vICAgICAgIC5maW5hbGx5KCgpID0+IHNldExvYWRpbmdQYWdlKGZhbHNlKSk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICAvLyAtLS0tLS0tLS0tIEZFVENIIEJPVEggUkVQT1JUUyAtLS0tLS0tLS0tXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGlmIChzZWxlY3RlZEZyb21EYXRlICYmIHNlbGVjdGVkRGF0ZSkge1xyXG4vLyAgICAgICBmZXRjaFJlcG9ydHMoKTtcclxuLy8gICAgIH0gZWxzZSB7XHJcbi8vICAgICAgIHNldENvbnZlcnRlZExlYWRzKFtdKTtcclxuLy8gICAgICAgc2V0Tm9uQ29udmVydGVkTGVhZHMoW10pO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZERhdGUsIGN1c3RvbWVyUmVmZXJyZWRCeSwgZW1wbG95ZWVSZWZlcnJlZEJ5XSk7XHJcblxyXG4vLyAgIC8vIC0tLS0tLS0tLS0gREVGQVVMVCBGSUxURVIgLS0tLS0tLS0tLVxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBpZiAoIWxvYWRpbmdQYWdlKSBoYW5kbGVTZWxlY3RGaWx0ZXIoXCJUaGlzTW9udGhcIik7XHJcbi8vICAgfSwgW2xvYWRpbmdQYWdlXSk7XHJcblxyXG4vLyAgIC8vIC0tLS0tLS0tLS0gQVBJIENBTEwgLS0tLS0tLS0tLVxyXG4vLyAgIGNvbnN0IGZldGNoUmVwb3J0cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHNldExvYWRpbmdEYXRhKHRydWUpO1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xyXG4vLyAgICAgICBwYXJhbXMuYXBwZW5kKFwiZnJvbV9kYXRlXCIsIHNlbGVjdGVkRnJvbURhdGUpO1xyXG4vLyAgICAgICBwYXJhbXMuYXBwZW5kKFwidG9fZGF0ZVwiLCBzZWxlY3RlZERhdGUpO1xyXG5cclxuLy8gICAgICAgaWYgKGN1c3RvbWVyUmVmZXJyZWRCeSkgcGFyYW1zLmFwcGVuZChcImN1c3RvbWVyX2lkXCIsIGdldElkRnJvbVZhbHVlKGN1c3RvbWVyUmVmZXJyZWRCeSkpO1xyXG4vLyAgICAgICBpZiAoZW1wbG95ZWVSZWZlcnJlZEJ5KSBwYXJhbXMuYXBwZW5kKFwiYWdlbnRfaWRcIiwgZ2V0SWRGcm9tVmFsdWUoZW1wbG95ZWVSZWZlcnJlZEJ5KSk7XHJcblxyXG4vLyAgICAgICAvLyBDb252ZXJ0ZWRcclxuLy8gICAgICAgY29uc3QgY29udmVydGVkID0gYXdhaXQgYXBpLmdldChgL2xlYWQvY29udmVydGVkLWN1c3RvbWVyPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCk7XHJcbi8vICAgICAgIGNvbnN0IGNvbnZlcnRlZERhdGEgPSBjb252ZXJ0ZWQ/LmRhdGE/LnJlc3BvbnNlIHx8IFtdO1xyXG5cclxuLy8gICAgICAgc2V0Q29udmVydGVkTGVhZHMoXHJcbi8vICAgICAgICAgY29udmVydGVkRGF0YS5tYXAoKGxlYWQsIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAgICAgaWQ6IGxlYWQ/Ll9pZCxcclxuLy8gICAgICAgICAgIFNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIExlYWROYW1lOiBsZWFkPy5sZWFkX25hbWUgfHwgXCJcIixcclxuLy8gICAgICAgICAgIGxlYWRQaG9uZTogbGVhZD8ubGVhZF9waG9uZSB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgZ3JvdXBOYW1lOiBsZWFkPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgbGVhZFR5cGU6IGxlYWQ/LmxlYWRfdHlwZSB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgcmVmZXJyZWRCeTpcclxuLy8gICAgICAgICAgICAgbGVhZD8ubGVhZF9hZ2VudFxyXG4vLyAgICAgICAgICAgICAgID8gYCR7bGVhZD8ubGVhZF9hZ2VudD8ubmFtZX0gfCAke2xlYWQ/LmxlYWRfYWdlbnQ/LnBob25lX251bWJlcn1gXHJcbi8vICAgICAgICAgICAgICAgOiBsZWFkPy5sZWFkX2N1c3RvbWVyXHJcbi8vICAgICAgICAgICAgICAgPyBgJHtsZWFkPy5sZWFkX2N1c3RvbWVyPy5mdWxsX25hbWV9IHwgJHtsZWFkPy5sZWFkX2N1c3RvbWVyPy5waG9uZV9udW1iZXJ9YFxyXG4vLyAgICAgICAgICAgICAgIDogXCJOL0FcIixcclxuLy8gICAgICAgICB9KSlcclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIC8vIE5vbiBDb252ZXJ0ZWRcclxuLy8gICAgICAgY29uc3Qgbm9uQ29udmVydGVkID0gYXdhaXQgYXBpLmdldChgL2xlYWQvbm90LWNvbnZlcnRlZC1jdXN0b21lcj8ke3BhcmFtcy50b1N0cmluZygpfWApO1xyXG4vLyAgICAgICBjb25zdCBub25Db252ZXJ0ZWREYXRhID0gbm9uQ29udmVydGVkPy5kYXRhPy5yZXNwb25zZSB8fCBbXTtcclxuXHJcbi8vICAgICAgIHNldE5vbkNvbnZlcnRlZExlYWRzKFxyXG4vLyAgICAgICAgIG5vbkNvbnZlcnRlZERhdGEubWFwKChsZWFkLCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgICAgIGlkOiBsZWFkPy5faWQsXHJcbi8vICAgICAgICAgICBTbE5vOiBpbmRleCArIDEsXHJcbi8vICAgICAgICAgICBMZWFkTmFtZTogbGVhZD8ubGVhZF9uYW1lIHx8IFwiXCIsXHJcbi8vICAgICAgICAgICBQaG9uZTogbGVhZD8ubGVhZF9waG9uZSB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgZ3JvdXBOYW1lOiBsZWFkPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIixcclxuLy8gICAgICAgICAgIHJlYXNvbjogbGVhZD8ucmVhc29uIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZEJ5OlxyXG4vLyAgICAgICAgICAgICBsZWFkPy5sZWFkX2FnZW50XHJcbi8vICAgICAgICAgICAgICAgPyBgJHtsZWFkPy5sZWFkX2FnZW50Py5uYW1lfSB8ICR7bGVhZD8ubGVhZF9hZ2VudD8ucGhvbmVfbnVtYmVyfWBcclxuLy8gICAgICAgICAgICAgICA6IGxlYWQ/LmxlYWRfY3VzdG9tZXJcclxuLy8gICAgICAgICAgICAgICA/IGAke2xlYWQ/LmxlYWRfY3VzdG9tZXI/LmZ1bGxfbmFtZX0gfCAke2xlYWQ/LmxlYWRfY3VzdG9tZXI/LnBob25lX251bWJlcn1gXHJcbi8vICAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4vLyAgICAgICAgIH0pKVxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfSBjYXRjaCB7XHJcbi8vICAgICAgIHNldENvbnZlcnRlZExlYWRzKFtdKTtcclxuLy8gICAgICAgc2V0Tm9uQ29udmVydGVkTGVhZHMoW10pO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgc2V0TG9hZGluZ0RhdGEoZmFsc2UpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGlzQ3VzdG9tTW9kZSA9IHNlbGVjdGVkTGFiZWwgPT09IFwiQ3VzdG9tXCI7XHJcblxyXG4vLyAgIC8vIC0tLS0tLS0tLS0gVEFCTEUgQ09MVU1OUyAtLS0tLS0tLS0tXHJcbi8vICAgY29uc3QgY29udmVydGVkQ29sdW1ucyA9IFtcclxuLy8gICAgIHsgaGVhZGVyOiBcIlNsIE5vXCIsIGtleTogXCJTbE5vXCIgfSxcclxuLy8gICAgIHsgaGVhZGVyOiBcIk5hbWVcIiwga2V5OiBcIkxlYWROYW1lXCIgfSxcclxuLy8gICAgIHsgaGVhZGVyOiBcIlBob25lXCIsIGtleTogXCJsZWFkUGhvbmVcIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiR3JvdXBcIiwga2V5OiBcImdyb3VwTmFtZVwiIH0sXHJcbi8vICAgICB7IGhlYWRlcjogXCJMZWFkIFR5cGVcIiwga2V5OiBcImxlYWRUeXBlXCIgfSxcclxuLy8gICAgIHsgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIsIGtleTogXCJyZWZlcnJlZEJ5XCIgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICBjb25zdCBub25Db252ZXJ0ZWRDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBoZWFkZXI6IFwiU2wgTm9cIiwga2V5OiBcIlNsTm9cIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiTmFtZVwiLCBrZXk6IFwiTGVhZE5hbWVcIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiUGhvbmVcIiwga2V5OiBcIlBob25lXCIgfSxcclxuLy8gICAgIHsgaGVhZGVyOiBcIkdyb3VwXCIsIGtleTogXCJncm91cE5hbWVcIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiUmVhc29uXCIsIGtleTogXCJyZWFzb25cIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiwga2V5OiBcInJlZmVycmVkQnlcIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSB3LWZ1bGxcIj5cclxuLy8gICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5cclxuLy8gICAgICAgICBMZWFkcyBSZXBvcnQg4oCTIENvbnZlcnRlZCAmIE5vbi1Db252ZXJ0ZWRcclxuLy8gICAgICAgPC9oMT5cclxuXHJcbi8vICAgICAgIHsvKiBGSUxURVJTICovfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNFwiPlxyXG4vLyAgICAgICAgIHsvKiBEYXRlIEZpbHRlciAqL31cclxuLy8gICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5EYXRlIEZpbHRlcjwvbGFiZWw+XHJcbi8vICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsdGVyfVxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChnKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtnLnZhbHVlfSB2YWx1ZT17Zy52YWx1ZX0+XHJcbi8vICAgICAgICAgICAgICAgICB7Zy5sYWJlbH1cclxuLy8gICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiBGcm9tIERhdGUgKi99XHJcbi8vICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+RnJvbSBEYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4vLyAgICAgICAgICAgICBkaXNhYmxlZD17IWlzQ3VzdG9tTW9kZX1cclxuLy8gICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSk7XHJcbi8vICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRMYWJlbChcIkN1c3RvbVwiKTtcclxuLy8gICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgYm9yZGVyIHJvdW5kZWQtbWQgcHgtMlwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICB7LyogVG8gRGF0ZSAqL31cclxuLy8gICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5UbyBEYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbi8vICAgICAgICAgICAgIGRpc2FibGVkPXshaXNDdXN0b21Nb2RlfVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgICAgICAgICAgICAgIHNldFNlbGVjdGVkTGFiZWwoXCJDdXN0b21cIik7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExIGJvcmRlciByb3VuZGVkLW1kIHB4LTJcIlxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qIEN1c3RvbWVyIFJlZmVycmVyICovfVxyXG4vLyAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPkN1c3RvbWVyIFJlZmVycmVkIEJ5PC9sYWJlbD5cclxuLy8gICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4vLyAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tZXJSZWZlcnJlZEJ5fVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KHYpID0+IHNldEN1c3RvbWVyUmVmZXJyZWRCeSh2IHx8IFwiXCIpfVxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9TZWxlY3QuT3B0aW9uPlxyXG5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdC5PcHRHcm91cCBsYWJlbD1cIlVzZXJzXCI+XHJcbi8vICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1Ll9pZH0gdmFsdWU9e2BVU0VSXyR7dS5faWR9YH0+XHJcbi8vICAgICAgICAgICAgICAgICAgIHt1LmZ1bGxfbmFtZX0gfCB7dS5waG9uZV9udW1iZXJ9XHJcbi8vICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdEdyb3VwPlxyXG5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdC5PcHRHcm91cCBsYWJlbD1cIkFnZW50c1wiPlxyXG4vLyAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2EuX2lkfSB2YWx1ZT17YEFHRU5UXyR7YS5faWR9YH0+XHJcbi8vICAgICAgICAgICAgICAgICAgIHthLm5hbWV9IHwge2EucGhvbmVfbnVtYmVyfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICA8L1NlbGVjdC5PcHRHcm91cD5cclxuXHJcbi8vICAgICAgICAgICAgIDxTZWxlY3QuT3B0R3JvdXAgbGFiZWw9XCJDdXN0b21lcnNcIj5cclxuLy8gICAgICAgICAgICAgICB7Y3VzdG9tZXJzLm1hcCgoYykgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjLl9pZH0gdmFsdWU9e2BDVVNfJHtjLl9pZH1gfT5cclxuLy8gICAgICAgICAgICAgICAgICAge2MuZnVsbF9uYW1lfSB8IHtjLnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3QuT3B0R3JvdXA+XHJcbi8vICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogRW1wbG95ZWUgUmVmZXJyZXIgKi99XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi00XCI+XHJcbi8vICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+RW1wbG95ZWUgUmVmZXJyZWQgQnk8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgIHZhbHVlPXtlbXBsb3llZVJlZmVycmVkQnl9XHJcbi8vICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0RW1wbG95ZWVSZWZlcnJlZEJ5KHYgfHwgXCJcIil9XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlLl9pZH0gdmFsdWU9e2BFTVBfJHtlLl9pZH1gfT5cclxuLy8gICAgICAgICAgICAgICAgIHtlLmZ1bGxfbmFtZSB8fCBlLm5hbWV9IHwge2UucGhvbmVfbnVtYmVyfVxyXG4vLyAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogLS0tLS0tLS0tLSBTVU1NQVJZIEJPWEVTIC0tLS0tLS0tLS0gKi99XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtNTAgYm9yZGVyIHAtMyByb3VuZGVkIHRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIHRleHQtc21cIj5Db252ZXJ0ZWQgTGVhZHM8L3A+XHJcbi8vICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDBcIj57Y29udmVydGVkTGVhZHMubGVuZ3RofTwvcD5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctNTAgYm9yZGVyIHAtMyByb3VuZGVkIHRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIHRleHQtc21cIj5Ob24gQ29udmVydGVkIExlYWRzPC9wPlxyXG4vLyAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC15ZWxsb3ctNzAwXCI+e25vbkNvbnZlcnRlZExlYWRzLmxlbmd0aH08L3A+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgcC0zIHJvdW5kZWQgdGV4dC1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPlRvdGFsIExlYWRzPC9wPlxyXG4vLyAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4vLyAgICAgICAgICAgICB7Y29udmVydGVkTGVhZHMubGVuZ3RoICsgbm9uQ29udmVydGVkTGVhZHMubGVuZ3RofVxyXG4vLyAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIFxyXG5cclxuLy8gICAgICAgey8qIC0tLS0tLS0tLS0gQ09OVkVSVEVEIExFQURTIFRBQkxFIC0tLS0tLS0tLS0gKi99XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgc2hhZG93IG1iLTZcIj5cclxuLy8gICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItM1wiPkNvbnZlcnRlZCBMZWFkczwvaDI+XHJcbi8vICAgICAgICAge2xvYWRpbmdEYXRhID8gKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTEwXCI+XHJcbi8vICAgICAgICAgICAgIDxTcGluIC8+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPERhdGFUYWJsZSBjb2x1bW5zPXtjb252ZXJ0ZWRDb2x1bW5zfSBkYXRhPXtjb252ZXJ0ZWRMZWFkc30gLz5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgIHsvKiAtLS0tLS0tLS0tIE5PTi1DT05WRVJURUQgTEVBRFMgVEFCTEUgLS0tLS0tLS0tLSAqL31cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBzaGFkb3dcIj5cclxuLy8gICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItM1wiPlxyXG4vLyAgICAgICAgICAgTm9uIENvbnZlcnRlZCBMZWFkc1xyXG4vLyAgICAgICAgIDwvaDI+XHJcbi8vICAgICAgICAge2xvYWRpbmdEYXRhID8gKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTEwXCI+XHJcbi8vICAgICAgICAgICAgIDxTcGluIC8+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPERhdGFUYWJsZSBjb2x1bW5zPXtub25Db252ZXJ0ZWRDb2x1bW5zfSBkYXRhPXtub25Db252ZXJ0ZWRMZWFkc30gLz5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnZlcnRlZExlYWQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Db252ZXJ0ZWRMZWFkLmpzeCJ9