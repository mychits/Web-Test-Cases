import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/OutstandingReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import {
  Users,
  UserCheck,
  Layers3,
  Wallet,
  TrendingUp,
  IndianRupee,
  BadgeIndianRupee,
  Trophy,
  Shield
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const OutstandingReport = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [screenLoading, setScreenLoading] = useState(true);
  const [error, setError] = useState(null);
  const [usersData, setUsersData] = useState([]);
  const [filters, setFilters] = useState({
    groupFilter: "All",
    referredByFilter: "All",
    fromDate: "",
    toDate: "",
    relationshipManagerFilter: "All",
    customerStatusFilter: "All"
  });
  const StatsCard = ({
    title,
    value,
    icon: Icon,
    gradient,
    iconBg = "bg-white/20"
  }) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `relative rounded-2xl ${gradient} text-white shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 p-4 lg:p-5`,
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `absolute top-4 right-4 ${iconBg} p-2 rounded-lg flex items-center justify-center`,
            children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4 lg:w-5 lg:h-5", strokeWidth: 2 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 48,
              columnNumber: 9
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 45,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs sm:text-sm font-medium text-white/80", children: title }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 52,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "mt-4 text-[clamp(14px,1.2vw,22px)] font-bold whitespace-nowrap", children: value }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 54,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 51,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
      lineNumber: 42,
      columnNumber: 3
    },
    this
  );
  const transformUserData = (userInfo, index) => {
    return {
      sl_no: index + 1,
      _id: userInfo._id,
      userId: userInfo?.user_id?._id || null,
      customerId: userInfo?.user_id?.customer_id || "N/A",
      userName: userInfo?.user_id?.full_name || "N/A",
      userPhone: userInfo?.user_id?.phone_number || "N/A",
      collectionArea: userInfo?.user_id?.collection_area?.route_name || "N/A",
      collectionExecutive: userInfo?.user_id?.collection_area?.agent_id?.length ? userInfo.user_id.collection_area.agent_id.map((agent) => agent.name).join(" | ") : "N/A",
      groupName: userInfo?.group_id?.group_name || "N/A",
      groupValue: Number(userInfo?.group_id?.group_value) || 0,
      firstInstallment: Number(userInfo?.group_id?.monthly_installment) || 0,
      paymentsTicket: userInfo?.tickets || 0,
      relationshipManager: userInfo?.group_id?.relationship_manager?.name || "N/A",
      referred_type: userInfo?.referred_type || "N/A",
      reffered_by: userInfo?.referred_agent?.name || userInfo?.referred_customer?.full_name || userInfo?.referred_lead?.full_name || "N/A",
      payment_type: userInfo?.payment_type || "N/A",
      customer_status: userInfo?.customer_status || "N/A",
      chit_asking_month: userInfo?.chit_asking_month || "N/A",
      enrollmentDate: userInfo?.createdAt ? userInfo.createdAt.split("T")[0] : "",
      amountPaid: Number(userInfo?.total_investment) || 0,
      profit: Number(userInfo?.total_profit) || 0,
      totalLateFee: Number(userInfo?.total_late_fee) || 0,
      totalPenalty: Number(userInfo?.total_penalty) || 0,
      toBePaidAmount: Number(userInfo?.total_payable) || 0,
      balance: Number(userInfo?.total_balance) || 0,
      firstInstallmentStatus: Number(userInfo?.total_investment) >= Number(userInfo?.group_id?.monthly_installment) ? "Paid" : "Not Paid",
      status: userInfo?.is_prized ? "Prized" : "Un Prized",
      isPrized: userInfo?.is_prized || false,
      statusDiv: userInfo?.is_prized ? /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-lg shadow-sm border border-emerald-200", children: [
        /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            fillRule: "evenodd",
            d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
            clipRule: "evenodd"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 130,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm", children: "Prized" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 128,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-2 bg-amber-50 text-amber-700 px-3 py-1.5 rounded-lg shadow-sm border border-amber-200", children: [
        /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            fillRule: "evenodd",
            d: "M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z",
            clipRule: "evenodd"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 142,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 141,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm", children: "Un Prized" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 149,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 140,
        columnNumber: 7
      }, this)
    };
  };
  const groupOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.groupName))],
    [usersData]
  );
  const relationshipManagerOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.relationshipManager))].filter(Boolean),
    [usersData]
  );
  const customerStatusOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.customer_status))].filter(Boolean),
    [usersData]
  );
  const referredByOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.reffered_by))].filter(Boolean),
    [usersData]
  );
  const filteredUsers = useMemo(() => {
    return filterOption(
      usersData.filter((u) => {
        const matchGroup = filters.groupFilter === "All" || !filters.groupFilter ? true : u.groupName === filters.groupFilter;
        const matchReferredBy = filters.referredByFilter === "All" || !filters.referredByFilter ? true : u.reffered_by === filters.referredByFilter;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = filters.fromDate ? enrollmentDate >= new Date(filters.fromDate) : true;
        const matchToDate = filters.toDate ? enrollmentDate <= new Date(filters.toDate) : true;
        const matchRelationshipManager = filters.relationshipManagerFilter === "All" || !filters.relationshipManagerFilter ? true : u.relationshipManager === filters.relationshipManagerFilter;
        const matchCustomerStatus = filters.customerStatusFilter === "All" || !filters.customerStatusFilter ? true : u.customer_status === filters.customerStatusFilter;
        return matchGroup && matchReferredBy && matchRelationshipManager && matchCustomerStatus && matchFromDate && matchToDate;
      }),
      searchText
    );
  }, [usersData, filters, searchText]);
  const totals = useMemo(() => {
    const totalEnrollments = filteredUsers.length;
    const groupSet = new Set(filteredUsers.map((user) => user.groupName));
    const totalGroups = filters.groupFilter === "All" ? groupSet.size : filters.groupFilter ? 1 : groupSet.size;
    const customerSet = new Set(
      filteredUsers.map((u) => u.userId).filter(Boolean)
    );
    const totalCustomers = customerSet.size;
    const prizedCount = filteredUsers.filter((u) => u.isPrized === true).length;
    const unprizedCount = filteredUsers.filter(
      (u) => u.isPrized === false
    ).length;
    const totalToBePaid = filteredUsers.reduce(
      (sum, u) => sum + (Number(u.toBePaidAmount) || 0),
      0
    );
    const totalProfit = filteredUsers.reduce(
      (sum, u) => sum + (u.profit || 0),
      0
    );
    const totalPaid = filteredUsers.reduce(
      (sum, u) => sum + (u.amountPaid || 0),
      0
    );
    const totalBalance = filteredUsers.reduce(
      (sum, u) => sum + (u.balance || 0),
      0
    );
    return {
      totalEnrollments,
      totalGroups,
      totalCustomers,
      prizedCount,
      unprizedCount,
      totalToBePaid,
      totalProfit,
      totalPaid,
      totalBalance
    };
  }, [filteredUsers, filters.groupFilter]);
  const handleFilterChange = useCallback((key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  }, []);
  useEffect(() => {
    const fetchData = async () => {
      try {
        setScreenLoading(true);
        setError(null);
        const reportResponse = await api.get("/v1/admin/users/outstanding");
        const reportData = reportResponse.data.data.map(transformUserData);
        setUsersData(reportData);
      } catch (error2) {
        console.error("Error fetching data:", error2);
        setError("Failed to load data. Please try again later.");
        message.error("Failed to load data. Please try again later.");
      } finally {
        setScreenLoading(false);
      }
    };
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "customerId", header: "Customer Id" },
    { key: "customer_status", header: "Customer Status" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "groupName", header: "Group Name" },
    { key: "groupValue", header: "Group Value" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "enrollmentDate", header: "Enrollment Date" },
    { key: "referred_type", header: "Referred Type" },
    { key: "reffered_by", header: "Referred By" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "relationshipManager", header: "Group Relationship Manager" },
    { key: "payment_type", header: "Payment Type" },
    { key: "firstInstallment", header: "First Installment" },
    { key: "firstInstallmentStatus", header: "First Installment Status" },
    { key: "amountPaid", header: "Amount Paid" },
    { key: "totalLateFee", header: "Late Fee" },
    { key: "totalPenalty", header: "Penalty" },
    { key: "toBePaidAmount", header: "Payable Amount" },
    { key: "balance", header: "Balance" },
    { key: "collectionArea", header: "Collection Area" },
    { key: "collectionExecutive", header: "Collection Executive" },
    { key: "statusDiv", header: "Status" }
  ];
  const ExcelColumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "customerId", header: "Customer Id" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "groupName", header: "Group Name" },
    { key: "groupValue", header: "Group Value" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "enrollmentDate", header: "Enrollment Date" },
    { key: "referred_type", header: "Referred Type" },
    { key: "reffered_by", header: "Referred By" },
    { key: "relationshipManager", header: "Relationship Manager" },
    { key: "payment_type", header: "Payment Type" },
    { key: "firstInstallment", header: "First Installment" },
    { key: "toBePaidAmount", header: "Payable Amount" },
    { key: "amountPaid", header: "Amount Paid" },
    { key: "totalLateFee", header: "Late Fee" },
    { key: "totalPenalty", header: "Penalty" },
    { key: "balance", header: "Balance" },
    { key: "collectionArea", header: "Collection Area" },
    { key: "collectionExecutive", header: "Collection Executive" },
    { key: "status", header: "Status" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-1", children: /* @__PURE__ */ jsxDEV("div", { className: " ", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 355,
        columnNumber: 9
      },
      this
    ),
    screenLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full flex flex-col justify-center items-center min-h-screen", children: [
      /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-indigo-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 361,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-6 text-lg text-gray-600 font-medium", children: "Loading user data..." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 362,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
      lineNumber: 360,
      columnNumber: 9
    }, this) : error ? /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-center items-center p-8 min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border-l-4 border-red-500 text-red-700 px-6 py-5 rounded-lg shadow-lg max-w-md", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start", children: [
      /* @__PURE__ */ jsxDEV(
        "svg",
        {
          className: "w-6 h-6 mr-3 flex-shrink-0",
          fill: "currentColor",
          viewBox: "0 0 20 20",
          children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              fillRule: "evenodd",
              d: "M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z",
              clipRule: "evenodd"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 375,
              columnNumber: 19
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 370,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-lg mb-1", children: "Error Loading Data" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 382,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: error }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 385,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "mt-4 bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg",
            onClick: () => window.location.reload(),
            children: "Retry Loading"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 386,
            columnNumber: 19
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 381,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
      lineNumber: 369,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
      lineNumber: 368,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
      lineNumber: 367,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex-grow max-w-screen p-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-8 mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-3 mb-2", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-8 h-8 text-indigo-600",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                  lineNumber: 406,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 400,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent", children: "OutStanding Reports" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 413,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 399,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-500 text-sm", children: "Comprehensive overview of customer data and analytics" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 417,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 398,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-5", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-5 h-5 text-indigo-600",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                  lineNumber: 430,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 424,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: "Filters" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 437,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 423,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Group Filter" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 442,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Group",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.groupFilter,
                onChange: (value) => handleFilterChange("groupFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                    lineNumber: 462,
                    columnNumber: 21
                  }, this),
                  groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                      lineNumber: 465,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                lineNumber: 445,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 441,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Customer Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 472,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Customer Status",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.customerStatusFilter,
                onChange: (value) => handleFilterChange("customerStatusFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                    lineNumber: 492,
                    columnNumber: 21
                  }, this),
                  customerStatusOptions.map(
                    (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status, children: status }, status, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                      lineNumber: 495,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                lineNumber: 475,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 471,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Referred By" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 503,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Referred By",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.referredByFilter,
                onChange: (value) => handleFilterChange("referredByFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                    lineNumber: 523,
                    columnNumber: 21
                  }, this),
                  referredByOptions.map(
                    (referrer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: referrer, children: referrer }, referrer, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                      lineNumber: 526,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                lineNumber: 506,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 502,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Relationship Manager(GRM)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 533,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Relationship Manager",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.relationshipManagerFilter,
                onChange: (value) => handleFilterChange("relationshipManagerFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                    lineNumber: 553,
                    columnNumber: 21
                  }, this),
                  relationshipManagerOptions.map(
                    (rm) => /* @__PURE__ */ jsxDEV(Select.Option, { value: rm, children: rm }, rm, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                      lineNumber: 556,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                lineNumber: 536,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 532,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[180px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 563,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: filters.fromDate,
                onChange: (e) => handleFilterChange("fromDate", e.target.value),
                className: "w-full border-2 border-gray-200 rounded-lg px-4 py-2.5 focus:outline-none focus:border-indigo-500 transition-colors duration-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                lineNumber: 566,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 562,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[180px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
              lineNumber: 577,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: filters.toDate,
                onChange: (e) => handleFilterChange("toDate", e.target.value),
                className: "w-full border-2 border-gray-200 rounded-lg px-4 py-2.5 focus:outline-none focus:border-indigo-500 transition-colors duration-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
                lineNumber: 580,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 576,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 440,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 422,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5 mb-8", children: [
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Customers",
            value: totals.totalCustomers,
            icon: Users,
            gradient: "bg-gradient-to-br from-pink-500 to-rose-500"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 594,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Enrollments",
            value: totals.totalEnrollments,
            icon: UserCheck,
            gradient: "bg-gradient-to-br from-blue-500 to-indigo-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 601,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Groups",
            value: totals.totalGroups,
            icon: Layers3,
            gradient: "bg-gradient-to-br from-emerald-500 to-green-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 608,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Prized",
            value: totals.prizedCount,
            icon: Trophy,
            gradient: "bg-gradient-to-br from-yellow-500 to-amber-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 615,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Unprized",
            value: totals.unprizedCount,
            icon: Shield,
            gradient: "bg-gradient-to-br from-gray-500 to-gray-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 622,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Payable",
            value: `₹${totals.totalToBePaid.toLocaleString("en-IN")}`,
            icon: Wallet,
            gradient: "bg-gradient-to-br from-purple-500 to-fuchsia-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 629,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Profit",
            value: `₹${totals.totalProfit.toLocaleString("en-IN")}`,
            icon: TrendingUp,
            gradient: "bg-gradient-to-br from-teal-500 to-cyan-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 636,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Paid",
            value: `₹${totals.totalPaid.toLocaleString("en-IN")}`,
            icon: IndianRupee,
            gradient: "bg-gradient-to-br from-indigo-500 to-violet-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 643,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Balance",
            value: `₹${totals.totalBalance.toLocaleString("en-IN")}`,
            icon: BadgeIndianRupee,
            gradient: "bg-gradient-to-br from-rose-500 to-red-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
            lineNumber: 650,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 593,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: filteredUsers,
          columns: Auctioncolumns,
          exportCols: ExcelColumns,
          exportedPdfName: `All Customer Report`,
          printHeaderKeys: [
            "From Date",
            "Group Name",
            "Referred By",
            "Customer Status",
            "To Date",
            "Total Customers",
            "Total Groups",
            "Relationship Manager",
            "Prized",
            "Unprized",
            "Total Amount Payable",
            "Total Profit",
            "Total Amount Paid",
            "Total Balance"
          ],
          printHeaderValues: [
            filters.fromDate ? new Date(filters.fromDate).toLocaleDateString("en-GB") : "—",
            filters.groupFilter || "All Groups",
            filters.referredByFilter || "All",
            filters.customerStatusFilter || "All",
            filters.relationshipManagerFilter || "All",
            filters.toDate ? new Date(filters.toDate).toLocaleDateString("en-GB") : "—",
            totals.totalCustomers,
            totals.totalGroups,
            totals.prizedCount,
            totals.unprizedCount,
            `₹${totals.totalToBePaid.toLocaleString("en-IN")}`,
            `₹${totals.totalProfit.toLocaleString("en-IN")}`,
            `₹${totals.totalPaid.toLocaleString("en-IN")}`,
            `₹${totals.totalBalance.toLocaleString("en-IN")}`
          ],
          exportedFileName: `CustomerReport.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
          lineNumber: 660,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
        lineNumber: 659,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
      lineNumber: 397,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
    lineNumber: 354,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx",
    lineNumber: 353,
    columnNumber: 5
  }, this);
};
_s(OutstandingReport, "3Hc+pUZtGDLSex/fovZuuLqzBGA=");
_c = OutstandingReport;
export default OutstandingReport;
var _c;
$RefreshReg$(_c, "OutstandingReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/OutstandingReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NROzJCQS9DUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLFVBQVVDLFNBQVNDLG1CQUFtQjtBQUMxRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLFFBQVFDLGVBQWU7QUFDaEMsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsTUFBTUMsb0JBQW9CQSxNQUFNO0FBQUFDLEtBQUE7QUFDOUIsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUl0QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDdUIsZUFBZUMsZ0JBQWdCLElBQUl4QixTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDeUIsT0FBT0MsUUFBUSxJQUFJMUIsU0FBUyxJQUFJO0FBQ3ZDLFFBQU0sQ0FBQzJCLFdBQVdDLFlBQVksSUFBSTVCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2QixTQUFTQyxVQUFVLElBQUk5QixTQUFTO0FBQUEsSUFDckMrQixhQUFhO0FBQUEsSUFDYkMsa0JBQWtCO0FBQUEsSUFDbEJDLFVBQVU7QUFBQSxJQUNWQyxRQUFRO0FBQUEsSUFDUkMsMkJBQTJCO0FBQUEsSUFDM0JDLHNCQUFzQjtBQUFBLEVBQ3hCLENBQUM7QUFFRCxRQUFNQyxZQUFZQSxDQUFDO0FBQUEsSUFDakJDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLE1BQU1DO0FBQUFBLElBQ05DO0FBQUFBLElBQ0FDLFNBQVM7QUFBQSxFQUNYLE1BQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVcsd0JBQXdCRCxRQUFRO0FBQUEsTUFFM0M7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVywwQkFBMEJDLE1BQU07QUFBQSxZQUUzQyxpQ0FBQyxRQUFLLFdBQVUseUJBQXdCLGFBQWEsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQTtBQUFBLFVBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLGdEQUFnREwsbUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFFbkUsdUJBQUMsUUFBRyxXQUFVLGtFQUNYQyxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQTtBQUFBO0FBQUEsSUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkE7QUFHRixRQUFNSyxvQkFBb0JBLENBQUNDLFVBQVVDLFVBQVU7QUFDN0MsV0FBTztBQUFBLE1BQ0xDLE9BQU9ELFFBQVE7QUFBQSxNQUNmRSxLQUFLSCxTQUFTRztBQUFBQSxNQUVkQyxRQUFRSixVQUFVSyxTQUFTRixPQUFPO0FBQUEsTUFDbENHLFlBQVlOLFVBQVVLLFNBQVNFLGVBQWU7QUFBQSxNQUM5Q0MsVUFBVVIsVUFBVUssU0FBU0ksYUFBYTtBQUFBLE1BQzFDQyxXQUFXVixVQUFVSyxTQUFTTSxnQkFBZ0I7QUFBQSxNQUU5Q0MsZ0JBQWdCWixVQUFVSyxTQUFTUSxpQkFBaUJDLGNBQWM7QUFBQSxNQUVsRUMscUJBQXFCZixVQUFVSyxTQUFTUSxpQkFBaUJHLFVBQVVDLFNBQy9EakIsU0FBU0ssUUFBUVEsZ0JBQWdCRyxTQUM5QkUsSUFBSSxDQUFDQyxVQUFVQSxNQUFNQyxJQUFJLEVBQ3pCQyxLQUFLLEtBQUssSUFDYjtBQUFBLE1BRUpDLFdBQVd0QixVQUFVdUIsVUFBVUMsY0FBYztBQUFBLE1BQzdDQyxZQUFZQyxPQUFPMUIsVUFBVXVCLFVBQVVJLFdBQVcsS0FBSztBQUFBLE1BQ3ZEQyxrQkFBa0JGLE9BQU8xQixVQUFVdUIsVUFBVU0sbUJBQW1CLEtBQUs7QUFBQSxNQUVyRUMsZ0JBQWdCOUIsVUFBVStCLFdBQVc7QUFBQSxNQUVyQ0MscUJBQ0VoQyxVQUFVdUIsVUFBVVUsc0JBQXNCYixRQUFRO0FBQUEsTUFFcERjLGVBQWVsQyxVQUFVa0MsaUJBQWlCO0FBQUEsTUFFMUNDLGFBQ0VuQyxVQUFVb0MsZ0JBQWdCaEIsUUFDMUJwQixVQUFVcUMsbUJBQW1CNUIsYUFDN0JULFVBQVVzQyxlQUFlN0IsYUFDekI7QUFBQSxNQUVGOEIsY0FBY3ZDLFVBQVV1QyxnQkFBZ0I7QUFBQSxNQUV4Q0MsaUJBQWlCeEMsVUFBVXdDLG1CQUFtQjtBQUFBLE1BRTlDQyxtQkFBbUJ6QyxVQUFVeUMscUJBQXFCO0FBQUEsTUFFbERDLGdCQUFnQjFDLFVBQVUyQyxZQUN0QjNDLFNBQVMyQyxVQUFVQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQy9CO0FBQUEsTUFFSkMsWUFBWW5CLE9BQU8xQixVQUFVOEMsZ0JBQWdCLEtBQUs7QUFBQSxNQUVsREMsUUFBUXJCLE9BQU8xQixVQUFVZ0QsWUFBWSxLQUFLO0FBQUEsTUFFMUNDLGNBQWN2QixPQUFPMUIsVUFBVWtELGNBQWMsS0FBSztBQUFBLE1BRWxEQyxjQUFjekIsT0FBTzFCLFVBQVVvRCxhQUFhLEtBQUs7QUFBQSxNQUVqREMsZ0JBQWdCM0IsT0FBTzFCLFVBQVVzRCxhQUFhLEtBQUs7QUFBQSxNQUVuREMsU0FBUzdCLE9BQU8xQixVQUFVd0QsYUFBYSxLQUFLO0FBQUEsTUFFNUNDLHdCQUNFL0IsT0FBTzFCLFVBQVU4QyxnQkFBZ0IsS0FDakNwQixPQUFPMUIsVUFBVXVCLFVBQVVNLG1CQUFtQixJQUMxQyxTQUNBO0FBQUEsTUFFTjZCLFFBQVExRCxVQUFVMkQsWUFBWSxXQUFXO0FBQUEsTUFDekNDLFVBQVU1RCxVQUFVMkQsYUFBYTtBQUFBLE1BRWpDRSxXQUFXN0QsVUFBVTJELFlBQ25CLHVCQUFDLFNBQUksV0FBVSw0SEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssZ0JBQWUsU0FBUSxhQUNuRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsVUFBUztBQUFBLFlBQ1QsR0FBRTtBQUFBLFlBQ0YsVUFBUztBQUFBO0FBQUEsVUFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHb0IsS0FKdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFFQSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHNCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsV0FUaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHNIQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxnQkFBZSxTQUFRLGFBQ25EO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxVQUFTO0FBQUEsWUFDVCxHQUFFO0FBQUEsWUFDRixVQUFTO0FBQUE7QUFBQSxVQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdvQixLQUp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUVBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IseUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxXQVRuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxJQUVKO0FBQUEsRUFDRjtBQUdBLFFBQU1HLGVBQWUxRztBQUFBQSxJQUNuQixNQUFNLENBQUMsR0FBRyxJQUFJMkcsSUFBSWpGLFVBQVVvQyxJQUFJLENBQUM4QyxNQUFNQSxFQUFFMUMsU0FBUyxDQUFDLENBQUM7QUFBQSxJQUNwRCxDQUFDeEMsU0FBUztBQUFBLEVBQ1o7QUFDQSxRQUFNbUYsNkJBQTZCN0c7QUFBQUEsSUFDakMsTUFDRSxDQUFDLEdBQUcsSUFBSTJHLElBQUlqRixVQUFVb0MsSUFBSSxDQUFDOEMsTUFBTUEsRUFBRWhDLG1CQUFtQixDQUFDLENBQUMsRUFBRWtDLE9BQU9DLE9BQU87QUFBQSxJQUMxRSxDQUFDckYsU0FBUztBQUFBLEVBQ1o7QUFDRixRQUFNc0Ysd0JBQXdCaEg7QUFBQUEsSUFDNUIsTUFBTSxDQUFDLEdBQUcsSUFBSTJHLElBQUlqRixVQUFVb0MsSUFBSSxDQUFDOEMsTUFBTUEsRUFBRXhCLGVBQWUsQ0FBQyxDQUFDLEVBQUUwQixPQUFPQyxPQUFPO0FBQUEsSUFDMUUsQ0FBQ3JGLFNBQVM7QUFBQSxFQUNaO0FBRUUsUUFBTXVGLG9CQUFvQmpIO0FBQUFBLElBQ3hCLE1BQU0sQ0FBQyxHQUFHLElBQUkyRyxJQUFJakYsVUFBVW9DLElBQUksQ0FBQzhDLE1BQU1BLEVBQUU3QixXQUFXLENBQUMsQ0FBQyxFQUFFK0IsT0FBT0MsT0FBTztBQUFBLElBQ3RFLENBQUNyRixTQUFTO0FBQUEsRUFDWjtBQUVBLFFBQU13RixnQkFBZ0JsSCxRQUFRLE1BQU07QUFDbEMsV0FBT1E7QUFBQUEsTUFDTGtCLFVBQVVvRixPQUFPLENBQUNGLE1BQU07QUFFdEIsY0FBTU8sYUFDSnZGLFFBQVFFLGdCQUFnQixTQUFTLENBQUNGLFFBQVFFLGNBQ3RDLE9BQ0E4RSxFQUFFMUMsY0FBY3RDLFFBQVFFO0FBRzlCLGNBQU1zRixrQkFDSnhGLFFBQVFHLHFCQUFxQixTQUFTLENBQUNILFFBQVFHLG1CQUMzQyxPQUNBNkUsRUFBRTdCLGdCQUFnQm5ELFFBQVFHO0FBR2hDLGNBQU11RCxpQkFBaUIsSUFBSStCLEtBQUtULEVBQUV0QixjQUFjO0FBQ2hELGNBQU1nQyxnQkFBZ0IxRixRQUFRSSxXQUMxQnNELGtCQUFrQixJQUFJK0IsS0FBS3pGLFFBQVFJLFFBQVEsSUFDM0M7QUFDSixjQUFNdUYsY0FBYzNGLFFBQVFLLFNBQ3hCcUQsa0JBQWtCLElBQUkrQixLQUFLekYsUUFBUUssTUFBTSxJQUN6QztBQUVKLGNBQU11RiwyQkFDSjVGLFFBQVFNLDhCQUE4QixTQUN0QyxDQUFDTixRQUFRTSw0QkFDTCxPQUNBMEUsRUFBRWhDLHdCQUF3QmhELFFBQVFNO0FBRXhDLGNBQU11RixzQkFDSjdGLFFBQVFPLHlCQUF5QixTQUNqQyxDQUFDUCxRQUFRTyx1QkFDTCxPQUNBeUUsRUFBRXhCLG9CQUFvQnhELFFBQVFPO0FBRXBDLGVBQ0VnRixjQUNBQyxtQkFDQUksNEJBQ0FDLHVCQUNBSCxpQkFDQUM7QUFBQUEsTUFFSixDQUFDO0FBQUEsTUFDRG5HO0FBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sV0FBV0UsU0FBU1IsVUFBVSxDQUFDO0FBRW5DLFFBQU1zRyxTQUFTMUgsUUFBUSxNQUFNO0FBQzNCLFVBQU0ySCxtQkFBbUJULGNBQWNyRDtBQUV2QyxVQUFNK0QsV0FBVyxJQUFJakIsSUFBSU8sY0FBY3BELElBQUksQ0FBQytELFNBQVNBLEtBQUszRCxTQUFTLENBQUM7QUFDcEUsVUFBTTRELGNBQ0psRyxRQUFRRSxnQkFBZ0IsUUFDcEI4RixTQUFTRyxPQUNUbkcsUUFBUUUsY0FDTixJQUNBOEYsU0FBU0c7QUFFakIsVUFBTUMsY0FBYyxJQUFJckI7QUFBQUEsTUFDdEJPLGNBQWNwRCxJQUFJLENBQUM4QyxNQUFNQSxFQUFFNUQsTUFBTSxFQUFFOEQsT0FBT0MsT0FBTztBQUFBLElBQ25EO0FBQ0EsVUFBTWtCLGlCQUFpQkQsWUFBWUQ7QUFHbkMsVUFBTUcsY0FBY2hCLGNBQWNKLE9BQU8sQ0FBQ0YsTUFBTUEsRUFBRUosYUFBYSxJQUFJLEVBQUUzQztBQUNyRSxVQUFNc0UsZ0JBQWdCakIsY0FBY0o7QUFBQUEsTUFDbEMsQ0FBQ0YsTUFBTUEsRUFBRUosYUFBYTtBQUFBLElBQ3hCLEVBQUUzQztBQUVGLFVBQU11RSxnQkFBZ0JsQixjQUFjbUI7QUFBQUEsTUFDbEMsQ0FBQ0MsS0FBSzFCLE1BQU0wQixPQUFPaEUsT0FBT3NDLEVBQUVYLGNBQWMsS0FBSztBQUFBLE1BQy9DO0FBQUEsSUFDRjtBQUNBLFVBQU1zQyxjQUFjckIsY0FBY21CO0FBQUFBLE1BQ2hDLENBQUNDLEtBQUsxQixNQUFNMEIsT0FBTzFCLEVBQUVqQixVQUFVO0FBQUEsTUFDL0I7QUFBQSxJQUNGO0FBQ0EsVUFBTTZDLFlBQVl0QixjQUFjbUI7QUFBQUEsTUFDOUIsQ0FBQ0MsS0FBSzFCLE1BQU0wQixPQUFPMUIsRUFBRW5CLGNBQWM7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxVQUFNZ0QsZUFBZXZCLGNBQWNtQjtBQUFBQSxNQUNqQyxDQUFDQyxLQUFLMUIsTUFBTTBCLE9BQU8xQixFQUFFVCxXQUFXO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLE1BQ0x3QjtBQUFBQSxNQUNBRztBQUFBQSxNQUNBRztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBRztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUN2QixlQUFldEYsUUFBUUUsV0FBVyxDQUFDO0FBRXZDLFFBQU00RyxxQkFBcUJ6SSxZQUFZLENBQUMwSSxLQUFLckcsVUFBVTtBQUNyRFQsZUFBVyxDQUFDK0csVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsR0FBRyxHQUFHckcsTUFBTSxFQUFFO0FBQUEsRUFDbEQsR0FBRyxFQUFFO0FBRUx4QyxZQUFVLE1BQU07QUFDZCxVQUFNK0ksWUFBWSxZQUFZO0FBQzVCLFVBQUk7QUFDRnRILHlCQUFpQixJQUFJO0FBQ3JCRSxpQkFBUyxJQUFJO0FBRWIsY0FBTXFILGlCQUFpQixNQUFNNUksSUFBSTZJLElBQUksNkJBQTZCO0FBQ2xFLGNBQU1DLGFBQWFGLGVBQWVHLEtBQUtBLEtBQUtuRixJQUFJbkIsaUJBQWlCO0FBQ2pFaEIscUJBQWFxSCxVQUFVO0FBQUEsTUFDekIsU0FBU3hILFFBQU87QUFDZDBILGdCQUFRMUgsTUFBTSx3QkFBd0JBLE1BQUs7QUFDM0NDLGlCQUFTLDhDQUE4QztBQUN2RG5CLGdCQUFRa0IsTUFBTSw4Q0FBOEM7QUFBQSxNQUM5RCxVQUFDO0FBQ0NELHlCQUFpQixLQUFLO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBRUFzSCxjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxRQUFNTSxpQkFBaUI7QUFBQSxJQUNyQixFQUFFUixLQUFLLFNBQVNTLFFBQVEsU0FBUztBQUFBLElBQ2pDLEVBQUVULEtBQUssY0FBY1MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxtQkFBbUJTLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRVQsS0FBSyxZQUFZUyxRQUFRLGdCQUFnQjtBQUFBLElBQzNDLEVBQUVULEtBQUssYUFBYVMsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxhQUFhUyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFVCxLQUFLLGNBQWNTLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLFNBQVM7QUFBQSxJQUMxQyxFQUFFVCxLQUFLLGtCQUFrQlMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFVCxLQUFLLGlCQUFpQlMsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFVCxLQUFLLGVBQWVTLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVULEtBQUsscUJBQXFCUyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUVULEtBQUssdUJBQXVCUyxRQUFRLDZCQUE2QjtBQUFBLElBQ25FLEVBQUVULEtBQUssZ0JBQWdCUyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFVCxLQUFLLG9CQUFvQlMsUUFBUSxvQkFBb0I7QUFBQSxJQUN2RCxFQUFFVCxLQUFLLDBCQUEwQlMsUUFBUSwyQkFBMkI7QUFBQSxJQUNwRSxFQUFFVCxLQUFLLGNBQWNTLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVULEtBQUssZ0JBQWdCUyxRQUFRLFdBQVc7QUFBQSxJQUMxQyxFQUFFVCxLQUFLLGdCQUFnQlMsUUFBUSxVQUFVO0FBQUEsSUFDekMsRUFBRVQsS0FBSyxrQkFBa0JTLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRVQsS0FBSyxXQUFXUyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFVCxLQUFLLGtCQUFrQlMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFVCxLQUFLLHVCQUF1QlMsUUFBUSx1QkFBdUI7QUFBQSxJQUM3RCxFQUFFVCxLQUFLLGFBQWFTLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHeEMsUUFBTUMsZUFBZTtBQUFBLElBQ25CLEVBQUVWLEtBQUssU0FBU1MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRVQsS0FBSyxjQUFjUyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFVCxLQUFLLFlBQVlTLFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxhQUFhUyxRQUFRLGVBQWU7QUFBQSxJQUMzQyxFQUFFVCxLQUFLLGFBQWFTLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUVULEtBQUssY0FBY1MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxrQkFBa0JTLFFBQVEsU0FBUztBQUFBLElBQzFDLEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLGtCQUFrQjtBQUFBLElBQ25ELEVBQUVULEtBQUssaUJBQWlCUyxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVULEtBQUssZUFBZVMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRVQsS0FBSyx1QkFBdUJTLFFBQVEsdUJBQXVCO0FBQUEsSUFDN0QsRUFBRVQsS0FBSyxnQkFBZ0JTLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVULEtBQUssb0JBQW9CUyxRQUFRLG9CQUFvQjtBQUFBLElBQ3ZELEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVULEtBQUssY0FBY1MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxnQkFBZ0JTLFFBQVEsV0FBVztBQUFBLElBQzFDLEVBQUVULEtBQUssZ0JBQWdCUyxRQUFRLFVBQVU7QUFBQSxJQUN6QyxFQUFFVCxLQUFLLFdBQVdTLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLGtCQUFrQjtBQUFBLElBQ25ELEVBQUVULEtBQUssdUJBQXVCUyxRQUFRLHVCQUF1QjtBQUFBLElBQzdELEVBQUVULEtBQUssVUFBVVMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSxLQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLDZCQUE2QixDQUFDRSxNQUFNakksY0FBY2lJLEVBQUVDLE9BQU9qSCxLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVsQmhCLGdCQUNDLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLDZCQUFDLGtCQUFlLE9BQU0scUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUN2Qyx1QkFBQyxPQUFFLFdBQVUsMENBQXlDLG9DQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxJQUNFRSxRQUNGLHVCQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUFJLFdBQVUsMkZBQ2IsaUNBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE1BQUs7QUFBQSxVQUNMLFNBQVE7QUFBQSxVQUVSO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFTO0FBQUEsY0FDVCxHQUFFO0FBQUEsY0FDRixVQUFTO0FBQUE7QUFBQSxZQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdvQjtBQUFBO0FBQUEsUUFSdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsOEJBQTZCLGtDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxXQUFXQSxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFFBQzlCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1nSSxPQUFPQyxTQUFTQyxPQUFPO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFNBQVE7QUFBQSxjQUVSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQWM7QUFBQSxrQkFDZCxnQkFBZTtBQUFBLGtCQUNmLGFBQWE7QUFBQSxrQkFDYixHQUFFO0FBQUE7QUFBQSxnQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJbUk7QUFBQTtBQUFBLFlBVnJJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsaUdBQWdHLG1DQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQyxxRUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFNBQVE7QUFBQSxjQUVSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQWM7QUFBQSxrQkFDZCxnQkFBZTtBQUFBLGtCQUNmLGFBQWE7QUFBQSxrQkFDYixHQUFFO0FBQUE7QUFBQSxnQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJNko7QUFBQTtBQUFBLFlBVi9KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHVCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLGFBZDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw0QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUVDLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxZQUFZO0FBQUEsZ0JBQ1osYUFBWTtBQUFBLGdCQUNaLGtCQUFpQjtBQUFBLGdCQUNqQixjQUFjLENBQUNDLE9BQU9DLFlBQ25CQSxRQUFRQyxZQUFZLElBQ2xCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPbkksUUFBUUU7QUFBQUEsZ0JBQ2YsVUFBVSxDQUFDUSxVQUNUb0csbUJBQW1CLGVBQWVwRyxLQUFLO0FBQUEsZ0JBR3pDO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxPQUFNLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QjtBQUFBLGtCQUU3Qm9FLGFBQWE1QztBQUFBQSxvQkFBSSxDQUFDbUcsVUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE9BQy9CQSxtQkFEaUJBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCwrQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUVOLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxZQUFZO0FBQUEsZ0JBQ1osYUFBWTtBQUFBLGdCQUNaLGtCQUFpQjtBQUFBLGdCQUNqQixjQUFjLENBQUNDLE9BQU9DLFlBQ25CQSxRQUFRQyxZQUFZLElBQ2xCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPbkksUUFBUU87QUFBQUEsZ0JBQ2YsVUFBVSxDQUFDRyxVQUNUb0csbUJBQW1CLHdCQUF3QnBHLEtBQUs7QUFBQSxnQkFHbEQ7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0sbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBRTdCMEUsc0JBQXNCbEQ7QUFBQUEsb0JBQUksQ0FBQ3dDLFdBQzFCLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBd0JBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTyxFQUFFcUQsT0FBTyxPQUFPO0FBQUEsZ0JBQ3ZCLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLFlBQVk7QUFBQSxnQkFDWixhQUFZO0FBQUEsZ0JBQ1osa0JBQWlCO0FBQUEsZ0JBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsWUFDbkJBLFFBQVFDLFlBQVksSUFDbEJDLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU9uSSxRQUFRRztBQUFBQSxnQkFDZixVQUFVLENBQUNPLFVBQ1RvRyxtQkFBbUIsb0JBQW9CcEcsS0FBSztBQUFBLGdCQUc5QztBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sT0FBTSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFFN0IyRSxrQkFBa0JuRDtBQUFBQSxvQkFBSSxDQUFDb0csYUFDdEIsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLFVBQ2xDQSxzQkFEaUJBLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCx5Q0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUVQLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxZQUFZO0FBQUEsZ0JBQ1osYUFBWTtBQUFBLGdCQUNaLGtCQUFpQjtBQUFBLGdCQUNqQixjQUFjLENBQUNDLE9BQU9DLFlBQ25CQSxRQUFRQyxZQUFZLElBQ2xCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPbkksUUFBUU07QUFBQUEsZ0JBQ2YsVUFBVSxDQUFDSSxVQUNUb0csbUJBQW1CLDZCQUE2QnBHLEtBQUs7QUFBQSxnQkFHdkQ7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0sbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBRTdCdUUsMkJBQTJCL0M7QUFBQUEsb0JBQUksQ0FBQ3FHLE9BQy9CLHVCQUFDLE9BQU8sUUFBUCxFQUF1QixPQUFPQSxJQUM1QkEsZ0JBRGlCQSxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBd0JBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU92SSxRQUFRSTtBQUFBQSxnQkFDZixVQUFVLENBQUNzSCxNQUNUWixtQkFBbUIsWUFBWVksRUFBRUMsT0FBT2pILEtBQUs7QUFBQSxnQkFFL0MsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNOEk7QUFBQSxlQVZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHVCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPVixRQUFRSztBQUFBQSxnQkFDZixVQUFVLENBQUNxSCxNQUNUWixtQkFBbUIsVUFBVVksRUFBRUMsT0FBT2pILEtBQUs7QUFBQSxnQkFFN0MsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNOEk7QUFBQSxlQVZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUFwSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFKQTtBQUFBLFdBdktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3S0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPb0YsT0FBT087QUFBQUEsWUFDZCxNQUFNeEg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RDtBQUFBLFFBR3hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPaUgsT0FBT0M7QUFBQUEsWUFDZCxNQUFNakg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkwRDtBQUFBLFFBRzFEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPZ0gsT0FBT0k7QUFBQUEsWUFDZCxNQUFNbkg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk0RDtBQUFBLFFBRzVEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPK0csT0FBT1E7QUFBQUEsWUFDZCxNQUFNbEg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkyRDtBQUFBLFFBRzNEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPMEcsT0FBT1M7QUFBQUEsWUFDZCxNQUFNbEg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RDtBQUFBLFFBR3hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUl5RyxPQUFPVSxjQUFjZ0MsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUN2RCxNQUFNeEo7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk2RDtBQUFBLFFBRzdEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUk4RyxPQUFPYSxZQUFZNkIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUNyRCxNQUFNdko7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RDtBQUFBLFFBR3hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUk2RyxPQUFPYyxVQUFVNEIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUNuRCxNQUFNdEo7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk0RDtBQUFBLFFBRzVEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUk0RyxPQUFPZSxhQUFhMkIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUN0RCxNQUFNcko7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl1RDtBQUFBLFdBN0R6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0RBO0FBQUEsTUFHQSx1QkFBQyxTQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNbUc7QUFBQUEsVUFDTixTQUFTaUM7QUFBQUEsVUFDVCxZQUFZRTtBQUFBQSxVQUNaLGlCQUFpQjtBQUFBLFVBQ2pCLGlCQUFpQjtBQUFBLFlBQ2Y7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFBZTtBQUFBLFVBRWpCLG1CQUFtQjtBQUFBLFlBQ2pCekgsUUFBUUksV0FDSixJQUFJcUYsS0FBS3pGLFFBQVFJLFFBQVEsRUFBRXFJLG1CQUFtQixPQUFPLElBQ3JEO0FBQUEsWUFDSnpJLFFBQVFFLGVBQWU7QUFBQSxZQUN2QkYsUUFBUUcsb0JBQW9CO0FBQUEsWUFDNUJILFFBQVFPLHdCQUF3QjtBQUFBLFlBQ2hDUCxRQUFRTSw2QkFBNkI7QUFBQSxZQUNyQ04sUUFBUUssU0FDSixJQUFJb0YsS0FBS3pGLFFBQVFLLE1BQU0sRUFBRW9JLG1CQUFtQixPQUFPLElBQ25EO0FBQUEsWUFDSjNDLE9BQU9PO0FBQUFBLFlBQ1BQLE9BQU9JO0FBQUFBLFlBQ1BKLE9BQU9RO0FBQUFBLFlBQ1BSLE9BQU9TO0FBQUFBLFlBQ1AsSUFBSVQsT0FBT1UsY0FBY2dDLGVBQWUsT0FBTyxDQUFDO0FBQUEsWUFDaEQsSUFBSTFDLE9BQU9hLFlBQVk2QixlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQzlDLElBQUkxQyxPQUFPYyxVQUFVNEIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUM1QyxJQUFJMUMsT0FBT2UsYUFBYTJCLGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFBRTtBQUFBLFVBRW5ELGtCQUFrQjtBQUFBO0FBQUEsUUF6Q3BCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXlDeUMsS0ExQzNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0Q0E7QUFBQSxTQWxURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbVRBO0FBQUEsT0E5Vko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdXQSxLQWpXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa1dBO0FBRUo7QUFBRWpKLEdBaHJCSUQsbUJBQWlCO0FBQUFvSixLQUFqQnBKO0FBa3JCTixlQUFlQTtBQUFrQixJQUFBb0o7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsInVzZUNhbGxiYWNrIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJtZXNzYWdlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiVXNlcnMiLCJVc2VyQ2hlY2siLCJMYXllcnMzIiwiV2FsbGV0IiwiVHJlbmRpbmdVcCIsIkluZGlhblJ1cGVlIiwiQmFkZ2VJbmRpYW5SdXBlZSIsIlRyb3BoeSIsIlNoaWVsZCIsIk91dHN0YW5kaW5nUmVwb3J0IiwiX3MiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInNjcmVlbkxvYWRpbmciLCJzZXRTY3JlZW5Mb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsInVzZXJzRGF0YSIsInNldFVzZXJzRGF0YSIsImZpbHRlcnMiLCJzZXRGaWx0ZXJzIiwiZ3JvdXBGaWx0ZXIiLCJyZWZlcnJlZEJ5RmlsdGVyIiwiZnJvbURhdGUiLCJ0b0RhdGUiLCJyZWxhdGlvbnNoaXBNYW5hZ2VyRmlsdGVyIiwiY3VzdG9tZXJTdGF0dXNGaWx0ZXIiLCJTdGF0c0NhcmQiLCJ0aXRsZSIsInZhbHVlIiwiaWNvbiIsIkljb24iLCJncmFkaWVudCIsImljb25CZyIsInRyYW5zZm9ybVVzZXJEYXRhIiwidXNlckluZm8iLCJpbmRleCIsInNsX25vIiwiX2lkIiwidXNlcklkIiwidXNlcl9pZCIsImN1c3RvbWVySWQiLCJjdXN0b21lcl9pZCIsInVzZXJOYW1lIiwiZnVsbF9uYW1lIiwidXNlclBob25lIiwicGhvbmVfbnVtYmVyIiwiY29sbGVjdGlvbkFyZWEiLCJjb2xsZWN0aW9uX2FyZWEiLCJyb3V0ZV9uYW1lIiwiY29sbGVjdGlvbkV4ZWN1dGl2ZSIsImFnZW50X2lkIiwibGVuZ3RoIiwibWFwIiwiYWdlbnQiLCJuYW1lIiwiam9pbiIsImdyb3VwTmFtZSIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsImdyb3VwVmFsdWUiLCJOdW1iZXIiLCJncm91cF92YWx1ZSIsImZpcnN0SW5zdGFsbG1lbnQiLCJtb250aGx5X2luc3RhbGxtZW50IiwicGF5bWVudHNUaWNrZXQiLCJ0aWNrZXRzIiwicmVsYXRpb25zaGlwTWFuYWdlciIsInJlbGF0aW9uc2hpcF9tYW5hZ2VyIiwicmVmZXJyZWRfdHlwZSIsInJlZmZlcmVkX2J5IiwicmVmZXJyZWRfYWdlbnQiLCJyZWZlcnJlZF9jdXN0b21lciIsInJlZmVycmVkX2xlYWQiLCJwYXltZW50X3R5cGUiLCJjdXN0b21lcl9zdGF0dXMiLCJjaGl0X2Fza2luZ19tb250aCIsImVucm9sbG1lbnREYXRlIiwiY3JlYXRlZEF0Iiwic3BsaXQiLCJhbW91bnRQYWlkIiwidG90YWxfaW52ZXN0bWVudCIsInByb2ZpdCIsInRvdGFsX3Byb2ZpdCIsInRvdGFsTGF0ZUZlZSIsInRvdGFsX2xhdGVfZmVlIiwidG90YWxQZW5hbHR5IiwidG90YWxfcGVuYWx0eSIsInRvQmVQYWlkQW1vdW50IiwidG90YWxfcGF5YWJsZSIsImJhbGFuY2UiLCJ0b3RhbF9iYWxhbmNlIiwiZmlyc3RJbnN0YWxsbWVudFN0YXR1cyIsInN0YXR1cyIsImlzX3ByaXplZCIsImlzUHJpemVkIiwic3RhdHVzRGl2IiwiZ3JvdXBPcHRpb25zIiwiU2V0IiwidSIsInJlbGF0aW9uc2hpcE1hbmFnZXJPcHRpb25zIiwiZmlsdGVyIiwiQm9vbGVhbiIsImN1c3RvbWVyU3RhdHVzT3B0aW9ucyIsInJlZmVycmVkQnlPcHRpb25zIiwiZmlsdGVyZWRVc2VycyIsIm1hdGNoR3JvdXAiLCJtYXRjaFJlZmVycmVkQnkiLCJEYXRlIiwibWF0Y2hGcm9tRGF0ZSIsIm1hdGNoVG9EYXRlIiwibWF0Y2hSZWxhdGlvbnNoaXBNYW5hZ2VyIiwibWF0Y2hDdXN0b21lclN0YXR1cyIsInRvdGFscyIsInRvdGFsRW5yb2xsbWVudHMiLCJncm91cFNldCIsInVzZXIiLCJ0b3RhbEdyb3VwcyIsInNpemUiLCJjdXN0b21lclNldCIsInRvdGFsQ3VzdG9tZXJzIiwicHJpemVkQ291bnQiLCJ1bnByaXplZENvdW50IiwidG90YWxUb0JlUGFpZCIsInJlZHVjZSIsInN1bSIsInRvdGFsUHJvZml0IiwidG90YWxQYWlkIiwidG90YWxCYWxhbmNlIiwiaGFuZGxlRmlsdGVyQ2hhbmdlIiwia2V5IiwicHJldiIsImZldGNoRGF0YSIsInJlcG9ydFJlc3BvbnNlIiwiZ2V0IiwicmVwb3J0RGF0YSIsImRhdGEiLCJjb25zb2xlIiwiQXVjdGlvbmNvbHVtbnMiLCJoZWFkZXIiLCJFeGNlbENvbHVtbnMiLCJlIiwidGFyZ2V0Iiwid2luZG93IiwibG9jYXRpb24iLCJyZWxvYWQiLCJ3aWR0aCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZ3JvdXAiLCJyZWZlcnJlciIsInJtIiwidG9Mb2NhbGVTdHJpbmciLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJPdXRzdGFuZGluZ1JlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHtcclxuICBVc2VycyxcclxuICBVc2VyQ2hlY2ssXHJcbiAgTGF5ZXJzMyxcclxuICBXYWxsZXQsXHJcbiAgVHJlbmRpbmdVcCxcclxuICBJbmRpYW5SdXBlZSxcclxuICBCYWRnZUluZGlhblJ1cGVlLFxyXG4gIFRyb3BoeSxcclxuICBTaGllbGQsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuY29uc3QgT3V0c3RhbmRpbmdSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NjcmVlbkxvYWRpbmcsIHNldFNjcmVlbkxvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJzLCBzZXRGaWx0ZXJzXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwRmlsdGVyOiBcIkFsbFwiLFxyXG4gICAgcmVmZXJyZWRCeUZpbHRlcjogXCJBbGxcIixcclxuICAgIGZyb21EYXRlOiBcIlwiLFxyXG4gICAgdG9EYXRlOiBcIlwiLFxyXG4gICAgcmVsYXRpb25zaGlwTWFuYWdlckZpbHRlcjogXCJBbGxcIixcclxuICAgIGN1c3RvbWVyU3RhdHVzRmlsdGVyOiBcIkFsbFwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBTdGF0c0NhcmQgPSAoe1xyXG4gICAgdGl0bGUsXHJcbiAgICB2YWx1ZSxcclxuICAgIGljb246IEljb24sXHJcbiAgICBncmFkaWVudCxcclxuICAgIGljb25CZyA9IFwiYmctd2hpdGUvMjBcIixcclxuICB9KSA9PiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHJvdW5kZWQtMnhsICR7Z3JhZGllbnR9IHRleHQtd2hpdGUgc2hhZG93LWxnIGhvdmVyOnNoYWRvdy14bCBob3ZlcjotdHJhbnNsYXRlLXktMSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgcC00IGxnOnAtNWB9XHJcbiAgICA+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtNCByaWdodC00ICR7aWNvbkJnfSBwLTIgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlcmB9XHJcbiAgICAgID5cclxuICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IGxnOnctNSBsZzpoLTVcIiBzdHJva2VXaWR0aD17Mn0gLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlLzgwXCI+e3RpdGxlfTwvcD5cclxuXHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1bY2xhbXAoMTRweCwxLjJ2dywyMnB4KV0gZm9udC1ib2xkIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICB7dmFsdWV9XHJcbiAgICAgICAgPC9oMj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG5cclxuICBjb25zdCB0cmFuc2Zvcm1Vc2VyRGF0YSA9ICh1c2VySW5mbywgaW5kZXgpID0+IHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICAgIF9pZDogdXNlckluZm8uX2lkLFxyXG5cclxuICAgICAgdXNlcklkOiB1c2VySW5mbz8udXNlcl9pZD8uX2lkIHx8IG51bGwsXHJcbiAgICAgIGN1c3RvbWVySWQ6IHVzZXJJbmZvPy51c2VyX2lkPy5jdXN0b21lcl9pZCB8fCBcIk4vQVwiLFxyXG4gICAgICB1c2VyTmFtZTogdXNlckluZm8/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICB1c2VyUGhvbmU6IHVzZXJJbmZvPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuXHJcbiAgICAgIGNvbGxlY3Rpb25BcmVhOiB1c2VySW5mbz8udXNlcl9pZD8uY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lIHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICBjb2xsZWN0aW9uRXhlY3V0aXZlOiB1c2VySW5mbz8udXNlcl9pZD8uY29sbGVjdGlvbl9hcmVhPy5hZ2VudF9pZD8ubGVuZ3RoXHJcbiAgICAgICAgPyB1c2VySW5mby51c2VyX2lkLmNvbGxlY3Rpb25fYXJlYS5hZ2VudF9pZFxyXG4gICAgICAgICAgICAubWFwKChhZ2VudCkgPT4gYWdlbnQubmFtZSlcclxuICAgICAgICAgICAgLmpvaW4oXCIgfCBcIilcclxuICAgICAgICA6IFwiTi9BXCIsXHJcblxyXG4gICAgICBncm91cE5hbWU6IHVzZXJJbmZvPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICBncm91cFZhbHVlOiBOdW1iZXIodXNlckluZm8/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSkgfHwgMCxcclxuICAgICAgZmlyc3RJbnN0YWxsbWVudDogTnVtYmVyKHVzZXJJbmZvPy5ncm91cF9pZD8ubW9udGhseV9pbnN0YWxsbWVudCkgfHwgMCxcclxuXHJcbiAgICAgIHBheW1lbnRzVGlja2V0OiB1c2VySW5mbz8udGlja2V0cyB8fCAwLFxyXG5cclxuICAgICAgcmVsYXRpb25zaGlwTWFuYWdlcjpcclxuICAgICAgICB1c2VySW5mbz8uZ3JvdXBfaWQ/LnJlbGF0aW9uc2hpcF9tYW5hZ2VyPy5uYW1lIHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICByZWZlcnJlZF90eXBlOiB1c2VySW5mbz8ucmVmZXJyZWRfdHlwZSB8fCBcIk4vQVwiLFxyXG5cclxuICAgICAgcmVmZmVyZWRfYnk6XHJcbiAgICAgICAgdXNlckluZm8/LnJlZmVycmVkX2FnZW50Py5uYW1lIHx8XHJcbiAgICAgICAgdXNlckluZm8/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgfHxcclxuICAgICAgICB1c2VySW5mbz8ucmVmZXJyZWRfbGVhZD8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgXCJOL0FcIixcclxuXHJcbiAgICAgIHBheW1lbnRfdHlwZTogdXNlckluZm8/LnBheW1lbnRfdHlwZSB8fCBcIk4vQVwiLFxyXG5cclxuICAgICAgY3VzdG9tZXJfc3RhdHVzOiB1c2VySW5mbz8uY3VzdG9tZXJfc3RhdHVzIHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICBjaGl0X2Fza2luZ19tb250aDogdXNlckluZm8/LmNoaXRfYXNraW5nX21vbnRoIHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICBlbnJvbGxtZW50RGF0ZTogdXNlckluZm8/LmNyZWF0ZWRBdFxyXG4gICAgICAgID8gdXNlckluZm8uY3JlYXRlZEF0LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgIDogXCJcIixcclxuXHJcbiAgICAgIGFtb3VudFBhaWQ6IE51bWJlcih1c2VySW5mbz8udG90YWxfaW52ZXN0bWVudCkgfHwgMCxcclxuXHJcbiAgICAgIHByb2ZpdDogTnVtYmVyKHVzZXJJbmZvPy50b3RhbF9wcm9maXQpIHx8IDAsXHJcblxyXG4gICAgICB0b3RhbExhdGVGZWU6IE51bWJlcih1c2VySW5mbz8udG90YWxfbGF0ZV9mZWUpIHx8IDAsXHJcblxyXG4gICAgICB0b3RhbFBlbmFsdHk6IE51bWJlcih1c2VySW5mbz8udG90YWxfcGVuYWx0eSkgfHwgMCxcclxuXHJcbiAgICAgIHRvQmVQYWlkQW1vdW50OiBOdW1iZXIodXNlckluZm8/LnRvdGFsX3BheWFibGUpIHx8IDAsXHJcblxyXG4gICAgICBiYWxhbmNlOiBOdW1iZXIodXNlckluZm8/LnRvdGFsX2JhbGFuY2UpIHx8IDAsXHJcblxyXG4gICAgICBmaXJzdEluc3RhbGxtZW50U3RhdHVzOlxyXG4gICAgICAgIE51bWJlcih1c2VySW5mbz8udG90YWxfaW52ZXN0bWVudCkgPj1cclxuICAgICAgICBOdW1iZXIodXNlckluZm8/Lmdyb3VwX2lkPy5tb250aGx5X2luc3RhbGxtZW50KVxyXG4gICAgICAgICAgPyBcIlBhaWRcIlxyXG4gICAgICAgICAgOiBcIk5vdCBQYWlkXCIsXHJcblxyXG4gICAgICBzdGF0dXM6IHVzZXJJbmZvPy5pc19wcml6ZWQgPyBcIlByaXplZFwiIDogXCJVbiBQcml6ZWRcIixcclxuICAgICAgaXNQcml6ZWQ6IHVzZXJJbmZvPy5pc19wcml6ZWQgfHwgZmFsc2UsXHJcblxyXG4gICAgICBzdGF0dXNEaXY6IHVzZXJJbmZvPy5pc19wcml6ZWQgPyAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDBcIj5cclxuICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNFwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+XHJcbiAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICBkPVwiTTEwIDE4YTggOCAwIDEwMC0xNiA4IDggMCAwMDAgMTZ6bTMuNzA3LTkuMjkzYTEgMSAwIDAwLTEuNDE0LTEuNDE0TDkgMTAuNTg2IDcuNzA3IDkuMjkzYTEgMSAwIDAwLTEuNDE0IDEuNDE0bDIgMmExIDEgMCAwMDEuNDE0IDBsNC00elwiXHJcbiAgICAgICAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbVwiPlByaXplZDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMFwiPlxyXG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjAgMjBcIj5cclxuICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgIGQ9XCJNMTAgMThhOCA4IDAgMTAwLTE2IDggOCAwIDAwMCAxNnpNOC43MDcgNy4yOTNhMSAxIDAgMDAtMS40MTQgMS40MTRMOC41ODYgMTBsLTEuMjkzIDEuMjkzYTEgMSAwIDEwMS40MTQgMS40MTRMMTAgMTEuNDE0bDEuMjkzIDEuMjkzYTEgMSAwIDAwMS40MTQtMS40MTRMMTEuNDE0IDEwbDEuMjkzLTEuMjkzYTEgMSAwIDAwLTEuNDE0LTEuNDE0TDEwIDguNTg2IDguNzA3IDcuMjkzelwiXHJcbiAgICAgICAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbVwiPlVuIFByaXplZDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgIH07XHJcbiAgfTtcclxuXHJcbiAgLy8gR2V0IHVuaXF1ZSBncm91cCBvcHRpb25zXHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gdXNlTWVtbyhcclxuICAgICgpID0+IFsuLi5uZXcgU2V0KHVzZXJzRGF0YS5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKSldLFxyXG4gICAgW3VzZXJzRGF0YV0sXHJcbiAgKTtcclxuICBjb25zdCByZWxhdGlvbnNoaXBNYW5hZ2VyT3B0aW9ucyA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PlxyXG4gICAgICBbLi4ubmV3IFNldCh1c2Vyc0RhdGEubWFwKCh1KSA9PiB1LnJlbGF0aW9uc2hpcE1hbmFnZXIpKV0uZmlsdGVyKEJvb2xlYW4pLFxyXG4gICAgW3VzZXJzRGF0YV0sXHJcbiAgKTtcclxuY29uc3QgY3VzdG9tZXJTdGF0dXNPcHRpb25zID0gdXNlTWVtbyhcclxuICAoKSA9PiBbLi4ubmV3IFNldCh1c2Vyc0RhdGEubWFwKCh1KSA9PiB1LmN1c3RvbWVyX3N0YXR1cykpXS5maWx0ZXIoQm9vbGVhbiksXHJcbiAgW3VzZXJzRGF0YV0sXHJcbik7XHJcbiAgLy8gR2V0IHVuaXF1ZSByZWZlcnJlZCBieSBvcHRpb25zXHJcbiAgY29uc3QgcmVmZXJyZWRCeU9wdGlvbnMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5yZWZmZXJlZF9ieSkpXS5maWx0ZXIoQm9vbGVhbiksXHJcbiAgICBbdXNlcnNEYXRhXSxcclxuICApO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyT3B0aW9uKFxyXG4gICAgICB1c2Vyc0RhdGEuZmlsdGVyKCh1KSA9PiB7XHJcbiAgICAgICAgLy8gR3JvdXAgZmlsdGVyXHJcbiAgICAgICAgY29uc3QgbWF0Y2hHcm91cCA9XHJcbiAgICAgICAgICBmaWx0ZXJzLmdyb3VwRmlsdGVyID09PSBcIkFsbFwiIHx8ICFmaWx0ZXJzLmdyb3VwRmlsdGVyXHJcbiAgICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgICA6IHUuZ3JvdXBOYW1lID09PSBmaWx0ZXJzLmdyb3VwRmlsdGVyO1xyXG5cclxuICAgICAgICAvLyBSZWZlcnJlZCBCeSBmaWx0ZXJcclxuICAgICAgICBjb25zdCBtYXRjaFJlZmVycmVkQnkgPVxyXG4gICAgICAgICAgZmlsdGVycy5yZWZlcnJlZEJ5RmlsdGVyID09PSBcIkFsbFwiIHx8ICFmaWx0ZXJzLnJlZmVycmVkQnlGaWx0ZXJcclxuICAgICAgICAgICAgPyB0cnVlXHJcbiAgICAgICAgICAgIDogdS5yZWZmZXJlZF9ieSA9PT0gZmlsdGVycy5yZWZlcnJlZEJ5RmlsdGVyO1xyXG5cclxuICAgICAgICAvLyBEYXRlIGZpbHRlcnNcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50RGF0ZSA9IG5ldyBEYXRlKHUuZW5yb2xsbWVudERhdGUpO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmaWx0ZXJzLmZyb21EYXRlXHJcbiAgICAgICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZpbHRlcnMuZnJvbURhdGUpXHJcbiAgICAgICAgICA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hUb0RhdGUgPSBmaWx0ZXJzLnRvRGF0ZVxyXG4gICAgICAgICAgPyBlbnJvbGxtZW50RGF0ZSA8PSBuZXcgRGF0ZShmaWx0ZXJzLnRvRGF0ZSlcclxuICAgICAgICAgIDogdHJ1ZTtcclxuXHJcbiAgICAgICAgY29uc3QgbWF0Y2hSZWxhdGlvbnNoaXBNYW5hZ2VyID1cclxuICAgICAgICAgIGZpbHRlcnMucmVsYXRpb25zaGlwTWFuYWdlckZpbHRlciA9PT0gXCJBbGxcIiB8fFxyXG4gICAgICAgICAgIWZpbHRlcnMucmVsYXRpb25zaGlwTWFuYWdlckZpbHRlclxyXG4gICAgICAgICAgICA/IHRydWVcclxuICAgICAgICAgICAgOiB1LnJlbGF0aW9uc2hpcE1hbmFnZXIgPT09IGZpbHRlcnMucmVsYXRpb25zaGlwTWFuYWdlckZpbHRlcjtcclxuXHJcbiAgICAgICAgY29uc3QgbWF0Y2hDdXN0b21lclN0YXR1cyA9XHJcbiAgICAgICAgICBmaWx0ZXJzLmN1c3RvbWVyU3RhdHVzRmlsdGVyID09PSBcIkFsbFwiIHx8XHJcbiAgICAgICAgICAhZmlsdGVycy5jdXN0b21lclN0YXR1c0ZpbHRlclxyXG4gICAgICAgICAgICA/IHRydWVcclxuICAgICAgICAgICAgOiB1LmN1c3RvbWVyX3N0YXR1cyA9PT0gZmlsdGVycy5jdXN0b21lclN0YXR1c0ZpbHRlcjtcclxuXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIG1hdGNoR3JvdXAgJiZcclxuICAgICAgICAgIG1hdGNoUmVmZXJyZWRCeSAmJlxyXG4gICAgICAgICAgbWF0Y2hSZWxhdGlvbnNoaXBNYW5hZ2VyICYmXHJcbiAgICAgICAgICBtYXRjaEN1c3RvbWVyU3RhdHVzICYmXHJcbiAgICAgICAgICBtYXRjaEZyb21EYXRlICYmXHJcbiAgICAgICAgICBtYXRjaFRvRGF0ZVxyXG4gICAgICAgICk7XHJcbiAgICAgIH0pLFxyXG4gICAgICBzZWFyY2hUZXh0LFxyXG4gICAgKTtcclxuICB9LCBbdXNlcnNEYXRhLCBmaWx0ZXJzLCBzZWFyY2hUZXh0XSk7XHJcblxyXG4gIGNvbnN0IHRvdGFscyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgdG90YWxFbnJvbGxtZW50cyA9IGZpbHRlcmVkVXNlcnMubGVuZ3RoO1xyXG5cclxuICAgIGNvbnN0IGdyb3VwU2V0ID0gbmV3IFNldChmaWx0ZXJlZFVzZXJzLm1hcCgodXNlcikgPT4gdXNlci5ncm91cE5hbWUpKTtcclxuICAgIGNvbnN0IHRvdGFsR3JvdXBzID1cclxuICAgICAgZmlsdGVycy5ncm91cEZpbHRlciA9PT0gXCJBbGxcIlxyXG4gICAgICAgID8gZ3JvdXBTZXQuc2l6ZVxyXG4gICAgICAgIDogZmlsdGVycy5ncm91cEZpbHRlclxyXG4gICAgICAgICAgPyAxXHJcbiAgICAgICAgICA6IGdyb3VwU2V0LnNpemU7XHJcblxyXG4gICAgY29uc3QgY3VzdG9tZXJTZXQgPSBuZXcgU2V0KFxyXG4gICAgICBmaWx0ZXJlZFVzZXJzLm1hcCgodSkgPT4gdS51c2VySWQpLmZpbHRlcihCb29sZWFuKSxcclxuICAgICk7XHJcbiAgICBjb25zdCB0b3RhbEN1c3RvbWVycyA9IGN1c3RvbWVyU2V0LnNpemU7XHJcblxyXG4gICAgLy8gQ2FsY3VsYXRlIHByaXplZCBhbmQgdW5wcml6ZWQgY291bnRzXHJcbiAgICBjb25zdCBwcml6ZWRDb3VudCA9IGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1KSA9PiB1LmlzUHJpemVkID09PSB0cnVlKS5sZW5ndGg7XHJcbiAgICBjb25zdCB1bnByaXplZENvdW50ID0gZmlsdGVyZWRVc2Vycy5maWx0ZXIoXHJcbiAgICAgICh1KSA9PiB1LmlzUHJpemVkID09PSBmYWxzZSxcclxuICAgICkubGVuZ3RoO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsVG9CZVBhaWQgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZShcclxuICAgICAgKHN1bSwgdSkgPT4gc3VtICsgKE51bWJlcih1LnRvQmVQYWlkQW1vdW50KSB8fCAwKSxcclxuICAgICAgMCxcclxuICAgICk7XHJcbiAgICBjb25zdCB0b3RhbFByb2ZpdCA9IGZpbHRlcmVkVXNlcnMucmVkdWNlKFxyXG4gICAgICAoc3VtLCB1KSA9PiBzdW0gKyAodS5wcm9maXQgfHwgMCksXHJcbiAgICAgIDAsXHJcbiAgICApO1xyXG4gICAgY29uc3QgdG90YWxQYWlkID0gZmlsdGVyZWRVc2Vycy5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHUpID0+IHN1bSArICh1LmFtb3VudFBhaWQgfHwgMCksXHJcbiAgICAgIDAsXHJcbiAgICApO1xyXG4gICAgY29uc3QgdG90YWxCYWxhbmNlID0gZmlsdGVyZWRVc2Vycy5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHUpID0+IHN1bSArICh1LmJhbGFuY2UgfHwgMCksXHJcbiAgICAgIDAsXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsRW5yb2xsbWVudHMsXHJcbiAgICAgIHRvdGFsR3JvdXBzLFxyXG4gICAgICB0b3RhbEN1c3RvbWVycyxcclxuICAgICAgcHJpemVkQ291bnQsXHJcbiAgICAgIHVucHJpemVkQ291bnQsXHJcbiAgICAgIHRvdGFsVG9CZVBhaWQsXHJcbiAgICAgIHRvdGFsUHJvZml0LFxyXG4gICAgICB0b3RhbFBhaWQsXHJcbiAgICAgIHRvdGFsQmFsYW5jZSxcclxuICAgIH07XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnMsIGZpbHRlcnMuZ3JvdXBGaWx0ZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRmlsdGVyQ2hhbmdlID0gdXNlQ2FsbGJhY2soKGtleSwgdmFsdWUpID0+IHtcclxuICAgIHNldEZpbHRlcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtrZXldOiB2YWx1ZSB9KSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldFNjcmVlbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi91c2Vycy9vdXRzdGFuZGluZ1wiKTtcclxuICAgICAgICBjb25zdCByZXBvcnREYXRhID0gcmVwb3J0UmVzcG9uc2UuZGF0YS5kYXRhLm1hcCh0cmFuc2Zvcm1Vc2VyRGF0YSk7XHJcbiAgICAgICAgc2V0VXNlcnNEYXRhKHJlcG9ydERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBkYXRhLiBQbGVhc2UgdHJ5IGFnYWluIGxhdGVyLlwiKTtcclxuICAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgZGF0YS4gUGxlYXNlIHRyeSBhZ2FpbiBsYXRlci5cIik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0U2NyZWVuTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBBdWN0aW9uY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfc3RhdHVzXCIsIGhlYWRlcjogXCJDdXN0b21lciBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwVmFsdWVcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsbWVudERhdGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF90eXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmZlcmVkX2J5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJjaGl0X2Fza2luZ19tb250aFwiLCBoZWFkZXI6IFwiQ2hpdCBBc2tpbmcgTW9udGhcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVsYXRpb25zaGlwTWFuYWdlclwiLCBoZWFkZXI6IFwiR3JvdXAgUmVsYXRpb25zaGlwIE1hbmFnZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudF90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZmlyc3RJbnN0YWxsbWVudFwiLCBoZWFkZXI6IFwiRmlyc3QgSW5zdGFsbG1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZmlyc3RJbnN0YWxsbWVudFN0YXR1c1wiLCBoZWFkZXI6IFwiRmlyc3QgSW5zdGFsbG1lbnQgU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFBhaWRcIiwgaGVhZGVyOiBcIkFtb3VudCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsTGF0ZUZlZVwiLCBoZWFkZXI6IFwiTGF0ZSBGZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQZW5hbHR5XCIsIGhlYWRlcjogXCJQZW5hbHR5XCIgfSxcclxuICAgIHsga2V5OiBcInRvQmVQYWlkQW1vdW50XCIsIGhlYWRlcjogXCJQYXlhYmxlIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25BcmVhXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIEFyZWFcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGlvbkV4ZWN1dGl2ZVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBFeGVjdXRpdmVcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzRGl2XCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IEV4Y2VsQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwVmFsdWVcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsbWVudERhdGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF90eXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmZlcmVkX2J5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWxhdGlvbnNoaXBNYW5hZ2VyXCIsIGhlYWRlcjogXCJSZWxhdGlvbnNoaXAgTWFuYWdlclwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJmaXJzdEluc3RhbGxtZW50XCIsIGhlYWRlcjogXCJGaXJzdCBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b0JlUGFpZEFtb3VudFwiLCBoZWFkZXI6IFwiUGF5YWJsZSBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50UGFpZFwiLCBoZWFkZXI6IFwiQW1vdW50IFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxMYXRlRmVlXCIsIGhlYWRlcjogXCJMYXRlIEZlZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbFBlbmFsdHlcIiwgaGVhZGVyOiBcIlBlbmFsdHlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0aW9uQXJlYVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBBcmVhXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25FeGVjdXRpdmVcIiwgaGVhZGVyOiBcIkNvbGxlY3Rpb24gRXhlY3V0aXZlXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIHtzY3JlZW5Mb2FkaW5nID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtaW5kaWdvLTYwMFwiIC8+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTYgdGV4dC1sZyB0ZXh0LWdyYXktNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgTG9hZGluZyB1c2VyIGRhdGEuLi5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IGVycm9yID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcC04IG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlci1sLTQgYm9yZGVyLXJlZC01MDAgdGV4dC1yZWQtNzAwIHB4LTYgcHktNSByb3VuZGVkLWxnIHNoYWRvdy1sZyBtYXgtdy1tZFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTYgaC02IG1yLTMgZmxleC1zaHJpbmstMFwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDIwIDIwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMTAgMThhOCA4IDAgMTAwLTE2IDggOCAwIDAwMCAxNnpNOC43MDcgNy4yOTNhMSAxIDAgMDAtMS40MTQgMS40MTRMOC41ODYgMTBsLTEuMjkzIDEuMjkzYTEgMSAwIDEwMS40MTQgMS40MTRMMTAgMTEuNDE0bDEuMjkzIDEuMjkzYTEgMSAwIDAwMS40MTQtMS40MTRMMTEuNDE0IDEwbDEuMjkzLTEuMjkzYTEgMSAwIDAwLTEuNDE0LTEuNDE0TDEwIDguNTg2IDguNzA3IDcuMjkzelwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1sZyBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRXJyb3IgTG9hZGluZyBEYXRhXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj57ZXJyb3J9PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCBiZy1yZWQtNTAwIGhvdmVyOmJnLXJlZC02MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHB5LTIgcHgtNCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZXRyeSBMb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IG1heC13LXNjcmVlbiBwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC04IG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtaW5kaWdvLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICBkPVwiTTkgMTd2LTJtMyAydi00bTMgNHYtNm0yIDEwSDdhMiAyIDAgMDEtMi0yVjVhMiAyIDAgMDEyLTJoNS41ODZhMSAxIDAgMDEuNzA3LjI5M2w1LjQxNCA1LjQxNGExIDEgMCAwMS4yOTMuNzA3VjE5YTIgMiAwIDAxLTIgMnpcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tNjAwIHRvLWJsdWUtNjAwIGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgIE91dFN0YW5kaW5nIFJlcG9ydHNcclxuICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICBDb21wcmVoZW5zaXZlIG92ZXJ2aWV3IG9mIGN1c3RvbWVyIGRhdGEgYW5kIGFuYWx5dGljc1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTYgbWItOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMyA0YTEgMSAwIDAxMS0xaDE2YTEgMSAwIDAxMSAxdjIuNTg2YTEgMSAwIDAxLS4yOTMuNzA3bC02LjQxNCA2LjQxNGExIDEgMCAwMC0uMjkzLjcwN1YxN2wtNCA0di02LjU4NmExIDEgMCAwMC0uMjkzLS43MDdMMy4yOTMgNy4yOTNBMSAxIDAgMDEzIDYuNTg2VjR6XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+RmlsdGVyczwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMjAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgRmlsdGVyXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLmdyb3VwRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVGaWx0ZXJDaGFuZ2UoXCJncm91cEZpbHRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LVsyMDBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXI9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyIFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLmN1c3RvbWVyU3RhdHVzRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVGaWx0ZXJDaGFuZ2UoXCJjdXN0b21lclN0YXR1c0ZpbHRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyU3RhdHVzT3B0aW9ucy5tYXAoKHN0YXR1cykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtzdGF0dXN9IHZhbHVlPXtzdGF0dXN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctWzIwMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZmVycmVkIEJ5XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWZlcnJlZCBCeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLnJlZmVycmVkQnlGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUZpbHRlckNoYW5nZShcInJlZmVycmVkQnlGaWx0ZXJcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJBbGxcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtyZWZlcnJlZEJ5T3B0aW9ucy5tYXAoKHJlZmVycmVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZmVycmVyfSB2YWx1ZT17cmVmZXJyZXJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVmZXJyZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LVsyMDBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWxhdGlvbnNoaXAgTWFuYWdlcihHUk0pXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWxhdGlvbnNoaXAgTWFuYWdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLnJlbGF0aW9uc2hpcE1hbmFnZXJGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUZpbHRlckNoYW5nZShcInJlbGF0aW9uc2hpcE1hbmFnZXJGaWx0ZXJcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJBbGxcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtyZWxhdGlvbnNoaXBNYW5hZ2VyT3B0aW9ucy5tYXAoKHJtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JtfSB2YWx1ZT17cm19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cm19XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LVsxODBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBGcm9tIERhdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLmZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUZpbHRlckNoYW5nZShcImZyb21EYXRlXCIsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LVsxODBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy50b0RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlKFwidG9EYXRlXCIsIGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogU3RhdGlzdGljcyBDYXJkcyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy01IGdhcC01IG1iLThcIj5cclxuICAgICAgICAgICAgICA8U3RhdHNDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlRvdGFsIEN1c3RvbWVyc1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWxzLnRvdGFsQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17VXNlcnN9XHJcbiAgICAgICAgICAgICAgICBncmFkaWVudD1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcGluay01MDAgdG8tcm9zZS01MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgRW5yb2xsbWVudHNcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RvdGFscy50b3RhbEVucm9sbG1lbnRzfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17VXNlckNoZWNrfVxyXG4gICAgICAgICAgICAgICAgZ3JhZGllbnQ9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLWluZGlnby02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgR3JvdXBzXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt0b3RhbHMudG90YWxHcm91cHN9XHJcbiAgICAgICAgICAgICAgICBpY29uPXtMYXllcnMzfVxyXG4gICAgICAgICAgICAgICAgZ3JhZGllbnQ9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWVtZXJhbGQtNTAwIHRvLWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgPFN0YXRzQ2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJQcml6ZWRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RvdGFscy5wcml6ZWRDb3VudH1cclxuICAgICAgICAgICAgICAgIGljb249e1Ryb3BoeX1cclxuICAgICAgICAgICAgICAgIGdyYWRpZW50PVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS15ZWxsb3ctNTAwIHRvLWFtYmVyLTYwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgPFN0YXRzQ2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJVbnByaXplZFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWxzLnVucHJpemVkQ291bnR9XHJcbiAgICAgICAgICAgICAgICBpY29uPXtTaGllbGR9XHJcbiAgICAgICAgICAgICAgICBncmFkaWVudD1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JheS01MDAgdG8tZ3JheS02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgUGF5YWJsZVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7dG90YWxzLnRvdGFsVG9CZVBhaWQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17V2FsbGV0fVxyXG4gICAgICAgICAgICAgICAgZ3JhZGllbnQ9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXB1cnBsZS01MDAgdG8tZnVjaHNpYS02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgUHJvZml0XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0b3RhbHMudG90YWxQcm9maXQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17VHJlbmRpbmdVcH1cclxuICAgICAgICAgICAgICAgIGdyYWRpZW50PVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS10ZWFsLTUwMCB0by1jeWFuLTYwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgPFN0YXRzQ2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJUb3RhbCBQYWlkXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0b3RhbHMudG90YWxQYWlkLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YH1cclxuICAgICAgICAgICAgICAgIGljb249e0luZGlhblJ1cGVlfVxyXG4gICAgICAgICAgICAgICAgZ3JhZGllbnQ9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWluZGlnby01MDAgdG8tdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgPFN0YXRzQ2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJUb3RhbCBCYWxhbmNlXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0b3RhbHMudG90YWxCYWxhbmNlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YH1cclxuICAgICAgICAgICAgICAgIGljb249e0JhZGdlSW5kaWFuUnVwZWV9XHJcbiAgICAgICAgICAgICAgICBncmFkaWVudD1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcm9zZS01MDAgdG8tcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRGF0YSBUYWJsZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydENvbHM9e0V4Y2VsQ29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT17YEFsbCBDdXN0b21lciBSZXBvcnRgfVxyXG4gICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICAgIFwiRnJvbSBEYXRlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiR3JvdXAgTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlJlZmVycmVkIEJ5XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiQ3VzdG9tZXIgU3RhdHVzXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG8gRGF0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIEN1c3RvbWVyc1wiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIEdyb3Vwc1wiLFxyXG4gICAgICAgICAgICAgICAgICBcIlJlbGF0aW9uc2hpcCBNYW5hZ2VyXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiUHJpemVkXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVW5wcml6ZWRcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBBbW91bnQgUGF5YWJsZVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIFByb2ZpdFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIEFtb3VudCBQYWlkXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgQmFsYW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlcnMuZnJvbURhdGVcclxuICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGZpbHRlcnMuZnJvbURhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIuKAlFwiLFxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJzLmdyb3VwRmlsdGVyIHx8IFwiQWxsIEdyb3Vwc1wiLFxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJzLnJlZmVycmVkQnlGaWx0ZXIgfHwgXCJBbGxcIixcclxuICAgICAgICAgICAgICAgICAgZmlsdGVycy5jdXN0b21lclN0YXR1c0ZpbHRlciB8fCBcIkFsbFwiLFxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJzLnJlbGF0aW9uc2hpcE1hbmFnZXJGaWx0ZXIgfHwgXCJBbGxcIixcclxuICAgICAgICAgICAgICAgICAgZmlsdGVycy50b0RhdGVcclxuICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGZpbHRlcnMudG9EYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIDogXCLigJRcIixcclxuICAgICAgICAgICAgICAgICAgdG90YWxzLnRvdGFsQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICAgICAgICB0b3RhbHMudG90YWxHcm91cHMsXHJcbiAgICAgICAgICAgICAgICAgIHRvdGFscy5wcml6ZWRDb3VudCxcclxuICAgICAgICAgICAgICAgICAgdG90YWxzLnVucHJpemVkQ291bnQsXHJcbiAgICAgICAgICAgICAgICAgIGDigrkke3RvdGFscy50b3RhbFRvQmVQYWlkLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSR7dG90YWxzLnRvdGFsUHJvZml0LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSR7dG90YWxzLnRvdGFsUGFpZC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgICAgICAgIGDigrkke3RvdGFscy50b3RhbEJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lclJlcG9ydC5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgT3V0c3RhbmRpbmdSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9PdXRzdGFuZGluZ1JlcG9ydC5qc3gifQ==