import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayOutOthers.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FaPhoneAlt, FaUser, FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Modal as AntModal, Drawer, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaReceipt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const PayOutOthers = () => {
  _s();
  const { paymentType } = useParams();
  const [groups, setGroups] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [userName, setUserName] = useState("");
  const [viewLoader, setViewLoader] = useState(false);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentUpdateAmount, setCurrentUpdateAmount] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [receiptNo, setReceiptNo] = useState("");
  const whatsappEnable = true;
  const [paymentMode, setPaymentMode] = useState("cash");
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [enableGroupColumn, setEnableGroupColumn] = useState(true);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [render, setRerender] = useState(0);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [openAntDDrawer, setOpenAntDDrawer] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [lastThreePayments, setLastThreePayments] = useState([]);
  const [adminName, setAdminName] = useState("");
  const [showOthersField, setShowOthersField] = useState(false);
  const [selectedTicketValue, setSelectedTicketValue] = useState(null);
  const [whatsappEnabled, setWhatsappEnabled] = useState(true);
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [disbursementType, setDisbursementType] = useState("");
  const disbursementTypes = [
    {
      key: "#1",
      title: "Chit Cancellation",
      value: "Chit Cancellation"
    },
    {
      key: "#2",
      title: "Refund to Member",
      value: "Refund to Member"
    },
    {
      key: "#3",
      title: "Foreman Commission Disbursement",
      value: "Refund to Member"
    },
    {
      key: "#4",
      title: "Reinvestment Transfer",
      value: "Reinvestment Transfer"
    },
    {
      key: "#5",
      title: "Advance Payout Before Auction",
      value: "Advance Payout Before Auction"
    },
    {
      key: "#6",
      title: "Divident Share Disbursement",
      value: "Divident Share Disbursement"
    },
    {
      key: "#7",
      title: "Group Closure Settlement",
      value: "Group Closure Settlement"
    },
    {
      key: "#8",
      title: "Emergency Withdrawal",
      value: "Emergency Withdrawal"
    },
    {
      key: "#9",
      title: "Mistaken Payment Reversal",
      value: "Mistaken Payment Reversal"
    },
    {
      key: "#10",
      title: "Others",
      value: "Others"
    }
  ];
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    user_id: "",
    pay_date: today,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: "",
    payment_group_tickets: [],
    disbursement_type: "",
    note: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    amount: "",
    pay_date: ""
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const [recipientType, setRecipientType] = useState("customer");
  const [guestName, setGuestName] = useState("");
  const [guestMobile, setGuestMobile] = useState("");
  const [guestData, setGuestData] = useState({
    guest_name: "",
    mobile_number: ""
  });
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    setAdminName(userObj?.name || "");
    if (userObj && userObj?.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj?.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setModifyPayment(isModify);
    }
  }, []);
  useEffect(() => {
    const usr = localStorage.getItem("user");
    let admin_type = null;
    try {
      if (usr) {
        admin_type = JSON.parse(usr);
      }
    } catch (e) {
      console.error("Failed to parse user from localStorage:", e);
    }
    const fetchTodaysPayments = async () => {
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get(
          "/payment-out/get-payment-out-report-daybook",
          {
            params: {
              pay_date: today,
              pay_for: paymentType
            }
          }
        );
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              receipt: group.receipt_no,
              old_receipt: group.old_receipt_no,
              amount: group.amount,
              date: formatPayDate(group.pay_date),
              transaction_date: formatPayDate(group.createdAt),
              disbursed_by: group?.admin_type?.admin_name || "Super Admin",
              disbursement_type: group.disbursement_type,
              note: group.note
            };
          });
          setTablePayments(formattedData);
          setEnableGroupColumn(true);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setFilteredAuction([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchTodaysPayments();
  }, [render]);
  const fetchLastThreeTransactions = async (event) => {
    event.preventDefault();
    setOpenAntDDrawer(true);
    if (formData.user_id && formData.payment_group_tickets) {
      try {
        setShowLoader(true);
        const response = await api.get("payment-out/get-last-n-transaction", {
          params: {
            user_id: formData.user_id,
            payment_group_tickets: paymentGroupTickets,
            limit: 3,
            pay_for: paymentType
          }
        });
        if (response?.data) {
          setLastThreePayments(response.data);
        } else {
          setLastThreePayments([]);
        }
      } catch (error) {
        setLastThreePayments([]);
      } finally {
        setShowLoader(false);
      }
    }
  };
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [alertConfig]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [alertConfig]);
  const validateForm = () => {
    console.log("Validating...", { recipientType, guestName, guestMobile, formData });
    const newErrors = {};
    if (recipientType === "customer") {
      if (!selectedGroupId) {
        newErrors.customer = "Please select a customer";
      }
      if (!selectedTicketValue) {
        newErrors.payment_group_tickets = "Please select a group and ticket";
      }
    } else {
      if (!guestName.trim()) {
        newErrors.guestName = "Guest Name is required";
      }
      if (!guestMobile.trim()) {
        newErrors.guestMobile = "Mobile number is required";
      } else if (!/^\d{10}$/.test(guestMobile.trim())) {
        newErrors.guestMobile = "Enter a valid 10-digit mobile number";
      }
    }
    if (!formData.pay_date) {
      newErrors.pay_date = "Payment date is required";
    }
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    if (paymentMode === "online" && !formData.transaction_id?.trim()) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    if (paymentMode === "cheque" && !formData.cheque_date?.trim()) {
      newErrors.cheque_date = "Cheque Date is required for cheque payments";
    }
    if (paymentMode === "cheque" && !formData.cheque_number?.trim()) {
      newErrors.cheque_number = "Cheque Number is required for cheque payments";
    }
    if (recipientType === "customer" && !formData.disbursement_type) {
      newErrors.disbursement_type = "Disbursement Type is Required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "disbursement_type") {
      if (value === "Others") {
        setShowOthersField(true);
        setDisbursementType("");
      } else {
        setShowOthersField(false);
      }
    }
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({ ...prevData, [name]: "" }));
  };
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
    setSelectedTicketValue(values);
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/enroll/get-group-enroll/${groupId}`);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" }
  ];
  if (enableGroupColumn) {
    columns.push({ key: "group_name", header: "Group Name" });
  }
  columns.push(
    { key: "ticket", header: "Ticket Number" },
    { key: "old_receipt", header: "Old Receipt" },
    { key: "receipt", header: "Receipt" },
    { key: "amount", header: "Amount" },
    { key: "disbursed_by", header: "Disbursed By" },
    { key: "disbursement_type", header: "Disbursement Type" },
    { key: "note", header: "Note" },
    { key: "action", header: "Action" }
  );
  const handleCustomer = async (groupId) => {
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: groupId
    }));
    setSelectedTicketValue(null);
    setPaymentGroupTickets([]);
    setErrors((prev) => ({ ...prev, customer: "", payment_group_tickets: "" }));
    handleGroupChange(groupId);
    handleGroupAuctionChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    if (groupId === "today") {
      fetchPaymentList({ from_date: today, to_date: today });
    } else {
      fetchPaymentList({ group_id: groupId });
    }
  };
  const formatPayDate = (dateString) => {
    return dateString?.split("T")[0];
  };
  const handleGroupPaymentChange = async (groupId) => {
    setSelectedAuctionGroup(groupId);
    if (groupId) {
      let url;
      if (groupId === "today") {
        url = `/payment-out/get-payment-out-report-daybook/?pay_date=${today}&pay_for=${paymentType}`;
        setEnableGroupColumn(true);
      } else {
        url = `/payment-out/get-group-payment-out/?group_id=${groupId}&pay_for=${paymentType}`;
        setEnableGroupColumn(false);
      }
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((payment, index) => ({
            _id: payment._id,
            id: index + 1,
            name: payment.customer_name || payment.user_id?.full_name,
            phone_number: payment.customer_phone || payment.user_id?.phone_number,
            group_name: payment.group_id?.group_name,
            ticket: payment.ticket,
            receipt: payment.receipt_no,
            old_receipt: payment.old_receipt_no,
            amount: payment.amount,
            date: payment.pay_date?.split("T")[0],
            transaction_date: payment.createdAt?.split("T")[0],
            disbursed_by: payment.admin_type?.admin_name || "Super Admin",
            disbursement_type: payment.disbursement_type,
            note: payment.note
          }));
          setTablePayments(formattedData);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setFilteredAuction([]);
      } finally {
        setIsLoading(false);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prevData.transaction_id : ""
    }));
  };
  const fetchPaymentList = async (filters = {}) => {
    try {
      setTablePayments([]);
      setIsLoading(true);
      const response = await api.get("/v1/admin/payments-out/others", { params: filters });
      if (response.data?.data) {
        const formattedData = response.data.data.map((payment, index) => ({
          _id: payment._id,
          id: index + 1,
          name: payment.customer_name || payment.user_id?.full_name || "",
          phone_number: payment.customer_phone || payment.user_id?.phone_number || "",
          group_name: payment.group_id?.group_name || "",
          ticket: payment.ticket || "",
          receipt: payment.receipt_no || "",
          old_receipt: payment.old_receipt_no || "",
          amount: payment.amount || "",
          date: payment.pay_date?.split("T")[0] || "",
          transaction_date: payment.createdAt?.split("T")[0] || "",
          disbursed_by: payment.admin_type?.admin_name || "Super Admin",
          disbursement_type: payment.disbursement_type || "",
          note: payment.note || ""
        }));
        setTablePayments(formattedData);
        setEnableGroupColumn(true);
      } else {
        setTablePayments([]);
      }
    } catch (error) {
      console.error("Error fetching payment data:", error);
      setTablePayments([]);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchPaymentList({ from_date: today, to_date: today });
  }, [render]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (!isValid) return;
    try {
      setDisabled(true);
      setAlertConfig((prev) => ({ ...prev, visibility: false }));
      setShowModal(false);
      const usr = localStorage.getItem("user");
      let admin_type = null;
      try {
        if (usr) admin_type = JSON.parse(usr);
      } catch (e2) {
        console.error("Failed to parse user:", e2);
      }
      let payload = {
        pay_date: formData.pay_date,
        amount: formData.amount,
        pay_type: formData.pay_type,
        transaction_id: formData.transaction_id || void 0,
        cheque_number: formData.cheque_number || "",
        cheque_date: formData.cheque_date || "",
        cheque_bank_name: formData.cheque_bank_name || "",
        cheque_bank_branch: formData.cheque_bank_branch || "",
        note: formData.note || "",
        admin_type: admin_type?._id,
        disbursement_type: formData.disbursement_type === "Others" ? disbursementType || "Others" : formData.disbursement_type,
        customer_type: recipientType
        // "registered" or "guest"
      };
      if (recipientType === "customer") {
        payload.user_id = selectedGroupId;
        if (selectedTicketValue) {
          const parts = selectedTicketValue.split("|");
          if (parts.length === 2) {
            payload.group_id = parts[0].replace("chit-", "");
            payload.ticket = parts[1];
          }
        }
      } else {
        payload.guest_name = guestName.trim();
        payload.guest_phone = guestMobile.trim();
      }
      setOpenBackdropLoader(true);
      const response = await api.post("/v1/admin/payments-out/others", payload);
      if (response.status === 200 || response.status === 201) {
        setSelectedGroupId("");
        setSelectedTicketValue(null);
        setGuestName("");
        setGuestMobile("");
        setFormData({
          user_id: "",
          pay_date: today,
          amount: "",
          pay_type: "cash",
          transaction_id: "",
          disbursement_type: "",
          note: ""
        });
        setAlertConfig({
          visibility: true,
          noReload: true,
          message: "Payment Out Added Successfully",
          type: "success"
        });
      } else {
        setAlertConfig({
          visibility: true,
          noReload: true,
          message: "Payment Added Failed",
          type: "error"
        });
      }
    } catch (error) {
      console.error("Error submitting payment data:", error);
      setAlertConfig({
        visibility: true,
        noReload: true,
        message: error.response?.data?.message || "Error submitting payment data",
        type: "error"
      });
    } finally {
      setOpenBackdropLoader(false);
      setDisabled(false);
      setRerender((prev) => prev + 1);
    }
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/payment/delete-payment/${currentGroup._id}`);
        setShowModalDelete(false);
        setCurrentGroup(null);
        setAlertConfig({
          visibility: true,
          message: "Payment deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const handleViewModalOpen = async (groupId) => {
    try {
      setLoading(true);
      setShowModalView(true);
      setCurrentGroupId(groupId);
      setViewLoader(true);
      const response = await api.get(`/payment-out/others/${groupId}`);
      setCurrentViewGroup(response.data.data);
    } catch (error) {
      console.error("Error viewing Payment:", error);
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentUpdateAmount(response.data);
      setUpdateFormData({
        amount: response?.data?.amount,
        pay_date: response?.data?.pay_date.split("T")[0]
      });
      setShowUpdateModal(true);
    } catch (error) {
      console.error("Error fetching Payment Amount data:", error);
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        `/payment-out/others/${currentUpdateAmount._id}`,
        updateFormData
      );
      setShowUpdateModal(false);
      setAlertConfig({
        visibility: true,
        message: "Payment Amount Updated Successfully",
        type: "success"
      });
      setRerender((prev) => prev + 1);
    } catch (error) {
      console.error("Error updating Payment Amount:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Update failed",
        type: "error"
      });
    }
  };
  const handleDisbursementTypeChange = (event) => {
    const { name, value } = event.target;
    setDisbursementType(value);
  };
  const handleGroupAuctionChange = async (groupId) => {
    if (groupId) {
      try {
        const response = await api.post(
          `/enroll/get-user-tickets-report/${groupId}`
        );
        if (response.data && response.data.length > 0) {
          const validAuctions = response.data.filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setFilteredAuction(validAuctions);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "payment Data processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
    lineNumber: 789,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20 min-h-screen", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
      lineNumber: 793,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
        lineNumber: 794,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
        lineNumber: 798,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0 p-7 flex flex-col", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
        lineNumber: 807,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-red-500 font-bold", children: paymentType?.toUpperCase() }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
          lineNumber: 809,
          columnNumber: 17
        }, this),
        "  ",
        "Payments Out"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
        lineNumber: 808,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6  mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-bold", children: "Search or Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
            lineNumber: 817,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Today's Payment",
                popupMatchSelectWidth: false,
                showSearch: true,
                className: "w-full    h-14 max-w-md",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: selectedAuctionGroupId || void 0,
                onChange: handleGroupPayment,
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "today", children: "Today's Payments" }, "#1", false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 833,
                    columnNumber: 23
                  }, this),
                  actualGroups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 837,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 819,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowModal(true),
                className: "ml-4 bg-violet-600 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+Add Payment Out"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 843,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 842,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
            lineNumber: 818,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
          lineNumber: 816,
          columnNumber: 17
        }, this),
        TablePayments && TablePayments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: TablePayments.filter(
              (item) => Object.values(item).some(
                (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
              )
            ),
            columns,
            exportedFileName: `Payments ${TablePayments.length > 0 ? TablePayments[0].date + " to " + TablePayments[TablePayments.length - 1].date : "empty"}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
            lineNumber: 854,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Payments Data",
            failure: TablePayments.length <= 0 && selectedAuctionGroupId
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
            lineNumber: 872,
            columnNumber: 21
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
          lineNumber: 871,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
        lineNumber: 815,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
      lineNumber: 806,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setSelectedGroupId("");
          setSelectedTicketValue(null);
          setShowModal(false);
          setErrors({});
          setRecipientType("customer");
          setGuestName("");
          setGuestMobile("");
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left ", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Payment Out" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
            lineNumber: 897,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV(
              Drawer,
              {
                closable: true,
                destroyOnHidden: true,
                title: /* @__PURE__ */ jsxDEV("p", { children: "Last Three Transactions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 902,
                  columnNumber: 26
                }, this),
                placement: "right",
                open: openAntDDrawer,
                loading: showLoader,
                onClose: () => setOpenAntDDrawer(false),
                children: lastThreePayments?.length <= 0 ? /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-center text-xl", children: "No Transaction Found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 909,
                  columnNumber: 19
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 ", children: lastThreePayments.map((payment, index) => {
                  return /* @__PURE__ */ jsxDEV(
                    "section",
                    {
                      className: "bg-white shadow-md rounded-lg p-4 space-y-2 border border-gray-200 ",
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Payment Date:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: payment?.pay_date }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                            lineNumber: 922,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 920,
                          columnNumber: 31
                        }, this),
                        payment.group_id && /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Group:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: payment.group_id?.group_name }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                            lineNumber: 928,
                            columnNumber: 35
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 926,
                          columnNumber: 27
                        }, this),
                        payment.ticket && /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Ticket:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment?.ticket }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                            lineNumber: 936,
                            columnNumber: 35
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 934,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "PayOut Amount:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: [
                            "₹",
                            payment?.amount
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                            lineNumber: 941,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 939,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Payment Type:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment?.pay_type }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                            lineNumber: 945,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 943,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                          "Name:",
                          " ",
                          /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment.user_id?.full_name }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                            lineNumber: 949,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 947,
                          columnNumber: 31
                        }, this)
                      ]
                    },
                    index,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 916,
                      columnNumber: 25
                    },
                    this
                  );
                }) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 913,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 899,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex p-1 bg-gray-100 rounded-lg mb-2", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setRecipientType("customer");
                    setGuestName("");
                    setGuestMobile("");
                    setErrors((prev) => ({ ...prev, guestName: "", guestMobile: "" }));
                  },
                  className: `flex-1 py-2 text-sm font-medium rounded-md transition-all ${recipientType === "customer" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-700"}`,
                  children: "Customer"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 962,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setRecipientType("guest");
                    setShowOthersField(false);
                    setSelectedGroupId("");
                    setPaymentGroupTickets([]);
                    setErrors((prev) => ({
                      ...prev,
                      customer: "",
                      payment_group_tickets: ""
                    }));
                  },
                  className: `flex-1 py-2 text-sm font-medium rounded-md transition-all ${recipientType === "guest" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-700"}`,
                  children: "Guest"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 978,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 961,
              columnNumber: 19
            }, this),
            recipientType === "customer" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Customer ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1009,
                        columnNumber: 36
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1005,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full ${fieldSize.height}`,
                    placeholder: "Select Or Search Customer",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: selectedGroupId || void 0,
                    onChange: handleCustomer,
                    children: groups.map(
                      (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: `${group.full_name} | ${group.phone_number}` }, group._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1027,
                        columnNumber: 23
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1012,
                    columnNumber: 25
                  },
                  this
                ),
                errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1034,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1004,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Group & Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1039,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    placeholder: "Select Group | Ticket",
                    onChange: handlePaymentAntSelect,
                    value: selectedTicketValue,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full h-14",
                    allowClear: true,
                    children: filteredAuction.map((entry, index) => {
                      const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                      const groupId = entry?.enrollment?.group?._id || `missing-${index}`;
                      const ticket = entry?.enrollment?.tickets || "Unknown";
                      const key = `chit-${groupId}|${ticket}`;
                      return /* @__PURE__ */ jsxDEV(Select.Option, { value: key, children: [
                        groupName,
                        " | ",
                        ticket
                      ] }, key, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1055,
                        columnNumber: 27
                      }, this);
                    })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1042,
                    columnNumber: 25
                  },
                  this
                ),
                errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.payment_group_tickets }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1062,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1038,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1003,
              columnNumber: 17
            }, this),
            recipientType === "guest" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "guest_name",
                    children: [
                      "Guest Name ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1076,
                        columnNumber: 38
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1072,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none", children: /* @__PURE__ */ jsxDEV(FaUser, { className: "text-gray-400" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1080,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1079,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      id: "guest_name",
                      value: guestName,
                      onChange: (e) => {
                        setGuestName(e.target.value);
                        if (errors.guestName) setErrors({ ...errors, guestName: "" });
                      },
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full pl-10 p-2.5",
                      placeholder: "Enter Guest Name"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1082,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1078,
                  columnNumber: 25
                }, this),
                errors.guestName && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.guestName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1095,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1071,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "guest_mobile",
                    children: [
                      "Mobile Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1104,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1100,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none", children: /* @__PURE__ */ jsxDEV(FaPhoneAlt, { className: "text-gray-400" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1108,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1107,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "tel",
                      id: "guest_mobile",
                      value: guestMobile,
                      onChange: (e) => {
                        const value = e.target.value.replace(/[^0-9]/g, "");
                        setGuestMobile(value);
                        if (errors.guestMobile)
                          setErrors({ ...errors, guestMobile: "" });
                      },
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 block w-full pl-10 p-2.5",
                      placeholder: "Enter Mobile Number"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1110,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1106,
                  columnNumber: 25
                }, this),
                errors.guestMobile && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.guestMobile }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1126,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1099,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1070,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "group_install",
                  children: "Payment Date"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1134,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  disabled: !modifyPayment,
                  type: "date",
                  name: "pay_date",
                  value: formData.pay_date,
                  id: "pay_date",
                  onChange: handleChange,
                  placeholder: "",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full h-14"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1140,
                  columnNumber: 23
                },
                this
              ),
              errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1152,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1133,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1132,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: [
                      "Amount ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1163,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1159,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      name: "amount",
                      value: formData.amount,
                      id: "amount",
                      onChange: handleChange,
                      placeholder: "Enter Amount",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1166,
                      columnNumber: 25
                    },
                    this
                  ),
                  recipientType === "customer" && /* @__PURE__ */ jsxDEV(Tooltip, { title: "Last 3 Transactions", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      className: "bg-green-300 rounded-md p-2 border-2 font-semibold",
                      onClick: (e) => fetchLastThreeTransactions(e),
                      children: /* @__PURE__ */ jsxDEV(FaReceipt, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1183,
                        columnNumber: 31
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1179,
                      columnNumber: 29
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1178,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1165,
                  columnNumber: 23
                }, this),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1190,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1158,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "pay_mode",
                    children: "Payment Mode"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1194,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "pay_mode",
                    id: "pay_mode",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                    onChange: handlePaymentModeChange,
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1206,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1207,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1208,
                        columnNumber: 25
                      }, this),
                      modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "suspense", children: "Suspense" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 1211,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "credit", children: "Credit" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 1212,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "adjustment", children: "Adjustment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 1213,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "others", children: "Others" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                          lineNumber: 1214,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1210,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1200,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1193,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1157,
              columnNumber: 19
            }, this),
            recipientType === "customer" && formData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pay_mode",
                  children: "Individual Ticket Amount"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1225,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg hover:cursor-not-allowed w-full p-2.5",
                  placeholder: "totalAmount",
                  value: Number(formData.amount) / paymentGroupTickets.length,
                  disabled: true
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1232,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1224,
              columnNumber: 17
            }, this),
            paymentMode === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "transaction_id",
                  children: [
                    "Transaction ID ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1247,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1243,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "transaction_id",
                  id: "transaction_id",
                  value: formData.transaction_id,
                  onChange: handleChange,
                  placeholder: "Enter Transaction ID",
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1249,
                  columnNumber: 23
                },
                this
              ),
              errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1259,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1242,
              columnNumber: 17
            }, this),
            paymentMode === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h5", { className: "text-base font-semibold text-gray-900 mb-3", children: "Cheque Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1267,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                    "Cheque Number ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1271,
                      columnNumber: 43
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1270,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_number",
                      id: "cheque_number",
                      value: formData.cheque_number,
                      onChange: handleChange,
                      placeholder: "Enter Cheque Number",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1273,
                      columnNumber: 27
                    },
                    this
                  ),
                  errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1283,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1269,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                    "Cheque Date ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1289,
                      columnNumber: 41
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1288,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      name: "cheque_date",
                      id: "cheque_date",
                      value: formData?.cheque_date?.split("T")[0],
                      onChange: handleChange,
                      placeholder: "Enter Cheque Date",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1291,
                      columnNumber: 27
                    },
                    this
                  ),
                  errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1301,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1287,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1306,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_bank_name",
                      id: "cheque_bank_name",
                      value: formData.cheque_bank_name,
                      onChange: handleChange,
                      placeholder: "Enter Bank Name",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1309,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1305,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Bank Branch" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1321,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      name: "cheque_bank_branch",
                      id: "cheque_bank_branch",
                      value: formData.cheque_bank_branch,
                      onChange: handleChange,
                      placeholder: "Enter Bank Branch",
                      className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent bg-gray-50 focus:bg-white transition-all"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1324,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1320,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1268,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1266,
              columnNumber: 17
            }, this),
            recipientType === "customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pay_mode",
                  children: "Disbursement Type"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1339,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "disbursement_type",
                  id: "pay_mode",
                  value: formData.disbursement_type,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                  onChange: handleChange,
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select any" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                      lineNumber: 1352,
                      columnNumber: 25
                    }, this),
                    disbursementTypes.map(
                      (dType) => /* @__PURE__ */ jsxDEV("option", { value: dType.value, children: dType.title }, dType.key, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                        lineNumber: 1354,
                        columnNumber: 21
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1345,
                  columnNumber: 23
                },
                this
              ),
              errors.disbursement_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.disbursement_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1360,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1338,
              columnNumber: 17
            }, this),
            showOthersField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "othersField",
                    children: "Others"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1369,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: " border border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                    id: "othersField",
                    name: "disbursement_type",
                    value: disbursementType,
                    placeholder: "Specify if your option is not listed above",
                    onChange: handleDisbursementTypeChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1375,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1368,
                columnNumber: 23
              }, this),
              errors.disbursement_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.disbursement_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1386,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1367,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "note",
                  children: "Note"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1394,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  rows: 2,
                  type: "text",
                  className: "w-full p-3 border border-gray-300 rounded-lg",
                  id: "note",
                  name: "note",
                  value: formData.note,
                  placeholder: "Note if any?",
                  onChange: handleChange
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1400,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1393,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-violet-50 p-3 rounded-lg", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Disbursed By" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1413,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: adminName }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1416,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1412,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1411,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between w-full", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: whatsappEnabled,
                    onChange: (e) => setWhatsappEnabled(e.target.checked),
                    className: "w-4 h-4 accent-green-500"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                    lineNumber: 1425,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm", children: "Send via WhatsApp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1432,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1424,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 text-green-600", children: [
                /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { className: "w-6 h-6" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1439,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium", children: "WhatsApp" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1440,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1438,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1421,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-4", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setShowModal(false),
                  className: "px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1445,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Tooltip, { title: "Saving Payment Out", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                  children: "Save Payment Out"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                  lineNumber: 1453,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
                lineNumber: 1452,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
              lineNumber: 1444,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
            lineNumber: 898,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
          lineNumber: 896,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
        lineNumber: 884,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
    lineNumber: 792,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
    lineNumber: 791,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx",
    lineNumber: 787,
    columnNumber: 5
  }, this);
};
_s(PayOutOthers, "44kZtHdbVb38kcaHLzRWzxYh0oo=", false, function() {
  return [useParams];
});
_c = PayOutOthers;
export default PayOutOthers;
var _c;
$RefreshReg$(_c, "PayOutOthers");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutOthers.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb3hCUSxTQXNOWSxVQXROWjsyQkFweEJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxZQUFZQyxRQUFRQyx3QkFBd0I7QUFDckQsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRUixTQUFTUyxVQUFVQyxRQUFRQyxlQUFlO0FBQzNELFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyx3QkFBd0I7QUFDL0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUN6QixRQUFNLEVBQUVDLFlBQVksSUFBSVIsVUFBVTtBQUNsQyxRQUFNLENBQUNTLFFBQVFDLFNBQVMsSUFBSXpCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMwQixjQUFjQyxlQUFlLElBQUkzQixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDNEIsZUFBZUMsZ0JBQWdCLElBQUk3QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDOEIsZUFBZUMsZ0JBQWdCLElBQUkvQixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDZ0Msc0JBQXNCQyx1QkFBdUIsSUFBSWpDLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNrQyxpQkFBaUJDLGtCQUFrQixJQUFJbkMsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ29DLHdCQUF3QkMseUJBQXlCLElBQUlyQyxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDc0MsZUFBZUMsZ0JBQWdCLElBQUl2QyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDd0MsVUFBVUMsV0FBVyxJQUFJekMsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQzBDLFlBQVlDLGFBQWEsSUFBSTNDLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUM0QyxpQkFBaUJDLGtCQUFrQixJQUFJN0MsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQzhDLFdBQVdDLFlBQVksSUFBSS9DLFNBQVMsQ0FBQyxDQUFDO0FBQzdDLFFBQU0sQ0FBQ2dELFdBQVdDLFlBQVksSUFBSWpELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNrRCxpQkFBaUJDLGtCQUFrQixJQUFJbkQsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ29ELHFCQUFxQkMsc0JBQXNCLElBQUlyRCxTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDc0QsY0FBY0MsZUFBZSxJQUFJdkQsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ3dELGVBQWVDLGdCQUFnQixJQUFJekQsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzBELGtCQUFrQkMsbUJBQW1CLElBQUkzRCxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDNEQsaUJBQWlCQyxrQkFBa0IsSUFBSTdELFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM4RCxXQUFXQyxZQUFZLElBQUkvRCxTQUFTLEVBQUU7QUFDN0MsUUFBTWdFLGlCQUFpQjtBQUN2QixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSWxFLFNBQVMsTUFBTTtBQUNyRCxRQUFNbUUsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUl4RSxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDeUUsU0FBU0MsVUFBVSxJQUFJMUUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQzJFLFVBQVVDLFdBQVcsSUFBSTVFLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUM2RSxZQUFZQyxhQUFhLElBQUk5RSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK0UsaUJBQWlCQyxrQkFBa0IsSUFBSWhGLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNpRixtQkFBbUJDLG9CQUFvQixJQUFJbEYsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ21GLHFCQUFxQkMsc0JBQXNCLElBQUlwRixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDcUYsUUFBUUMsV0FBVyxJQUFJdEYsU0FBUyxDQUFDO0FBQ3hDLFFBQU0sQ0FBQ3VGLG9CQUFvQkMscUJBQXFCLElBQUl4RixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDeUYsZ0JBQWdCQyxpQkFBaUIsSUFBSTFGLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUMyRixnQkFBZ0JDLGlCQUFpQixJQUFJNUYsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQzZGLFlBQVlDLGFBQWEsSUFBSTlGLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUMrRixtQkFBbUJDLG9CQUFvQixJQUFJaEcsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ2lHLFdBQVdDLFlBQVksSUFBSWxHLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNtRyxpQkFBaUJDLGtCQUFrQixJQUFJcEcsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3FHLHFCQUFxQkMsc0JBQXNCLElBQUl0RyxTQUFTLElBQUk7QUFDbkUsUUFBTSxDQUFDdUcsaUJBQWlCQyxrQkFBa0IsSUFBSXhHLFNBQVMsSUFBSTtBQUMzRCxRQUFNeUcsNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQjlCLGtCQUFjNkIsS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxrQkFBa0JDLG1CQUFtQixJQUFJOUcsU0FBUyxFQUFFO0FBQzNELFFBQU0rRyxvQkFBb0I7QUFBQSxJQUV4QjtBQUFBLE1BQ0VDLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUE4sT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRUssS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQTixPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFSyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BOLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFFQTtBQUFBLE1BQ0VLLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUE4sT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRUssS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQTixPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFSyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BOLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VLLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUE4sT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRUssS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQTixPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFSyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BOLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VLLEtBQUs7QUFBQSxNQUNMQyxPQUFPO0FBQUEsTUFDUE4sT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUFDO0FBR0gsUUFBTU8sOEJBQThCQSxDQUFDUixNQUFNO0FBQ3pDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQjlCLGtCQUFjNkIsS0FBSztBQUFBLEVBQ3JCO0FBQ0EsUUFBTSxDQUFDUSxhQUFhQyxjQUFjLElBQUlwSCxTQUFTO0FBQUEsSUFDN0NxSCxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUkxSCxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUMySCxVQUFVQyxXQUFXLElBQUk1SCxTQUFTO0FBQUEsSUFDdkM2SCxTQUFTO0FBQUEsSUFFVEMsVUFBVTNEO0FBQUFBLElBQ1Y0RCxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxlQUFlO0FBQUEsSUFDZkMsYUFBYTtBQUFBLElBQ2JDLGtCQUFrQjtBQUFBLElBQ2xCQyxvQkFBb0I7QUFBQSxJQUNwQkMsdUJBQXVCO0FBQUEsSUFDdkJDLG1CQUFtQjtBQUFBLElBQ25CQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJMUksU0FBUztBQUFBLElBQ25EK0gsUUFBUTtBQUFBLElBQ1JELFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCxRQUFNLENBQUNhLGVBQWVDLGdCQUFnQixJQUFJNUksU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzZJLGVBQWVDLGdCQUFnQixJQUFJOUksU0FBUyxVQUFVO0FBQzdELFFBQU0sQ0FBQytJLFdBQVdDLFlBQVksSUFBSWhKLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNpSixhQUFhQyxjQUFjLElBQUlsSixTQUFTLEVBQUU7QUFFakQsUUFBTSxDQUFDbUosV0FBV0MsWUFBWSxJQUFJcEosU0FBUztBQUFBLElBQ3pDcUosWUFBWTtBQUFBLElBQ1pDLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBRUR2SixZQUFVLE1BQU07QUFDZCxVQUFNd0osT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFDL0JyRCxpQkFBYXdELFNBQVNHLFFBQVEsRUFBRTtBQUVoQyxRQUNFSCxXQUNBQSxTQUFTSSx1QkFBdUJDLG9CQUFvQkMsY0FDcEQ7QUFDQSxZQUFNQyxXQUNKUCxTQUFTSSx1QkFBdUJDLG9CQUFvQkMsaUJBQ2xELFNBQ0UsT0FDQTtBQUNOcEIsdUJBQWlCcUIsUUFBUTtBQUFBLElBQzNCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTGxLLFlBQVUsTUFBTTtBQUNkLFVBQU1tSyxNQUFNVixhQUFhQyxRQUFRLE1BQU07QUFDdkMsUUFBSVUsYUFBYTtBQUVqQixRQUFJO0FBQ0YsVUFBSUQsS0FBSztBQUNQQyxxQkFBYVIsS0FBS0MsTUFBTU0sR0FBRztBQUFBLE1BQzdCO0FBQUEsSUFDRixTQUFTeEQsR0FBRztBQUNWMEQsY0FBUUMsTUFBTSwyQ0FBMkMzRCxDQUFDO0FBQUEsSUFDNUQ7QUFFQSxVQUFNNEQsc0JBQXNCLFlBQVk7QUFDdEMsVUFBSTtBQUNGdkkseUJBQWlCLEVBQUU7QUFDbkJ5QyxxQkFBYSxJQUFJO0FBQ2pCLGNBQU0rRixXQUFXLE1BQU1ySyxJQUFJc0s7QUFBQUEsVUFDekI7QUFBQSxVQUNBO0FBQUEsWUFDRUMsUUFBUTtBQUFBLGNBQ04zQyxVQUFVM0Q7QUFBQUEsY0FDVnVHLFNBQVNuSjtBQUFBQSxZQUNYO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxZQUFJZ0osU0FBU0ksUUFBUUosU0FBU0ksS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNQyxnQkFBZ0JOLFNBQVNJLEtBQUtHLElBQUksQ0FBQ0MsT0FBT0MsVUFBVTtBQUN4RCxnQkFBSSxDQUFDRCxPQUFPRSxVQUFVQyxXQUFZLFFBQU8sQ0FBQztBQUMxQyxtQkFBTztBQUFBLGNBQ0xDLEtBQUtKLE1BQU1JO0FBQUFBLGNBQ1hDLElBQUlKLFFBQVE7QUFBQSxjQUNabkIsTUFBTWtCLE9BQU9sRCxTQUFTd0Q7QUFBQUEsY0FDdEJDLGNBQWNQLE9BQU9sRCxTQUFTeUQ7QUFBQUEsY0FDOUJKLFlBQVlILE9BQU9FLFVBQVVDO0FBQUFBLGNBQzdCSyxRQUFRUixNQUFNUTtBQUFBQSxjQUNkQyxTQUFTVCxNQUFNVTtBQUFBQSxjQUNmQyxhQUFhWCxNQUFNWTtBQUFBQSxjQUNuQjVELFFBQVFnRCxNQUFNaEQ7QUFBQUEsY0FDZDZELE1BQU1DLGNBQWNkLE1BQU1qRCxRQUFRO0FBQUEsY0FDbENnRSxrQkFBa0JELGNBQWNkLE1BQU1nQixTQUFTO0FBQUEsY0FDL0NDLGNBQWNqQixPQUFPWixZQUFZOEIsY0FBYztBQUFBLGNBQy9DMUQsbUJBQW1Cd0MsTUFBTXhDO0FBQUFBLGNBQ3pCQyxNQUFNdUMsTUFBTXZDO0FBQUFBLFlBQ2Q7QUFBQSxVQUNGLENBQUM7QUFDRHpHLDJCQUFpQjhJLGFBQWE7QUFDOUIzRiwrQkFBcUIsSUFBSTtBQUFBLFFBQzNCLE9BQU87QUFDTHJDLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVN3SCxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRHhILDJCQUFtQixFQUFFO0FBQUEsTUFDdkIsVUFBQztBQUNDMkIscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUVBOEYsd0JBQW9CO0FBQUEsRUFDdEIsR0FBRyxDQUFDakYsTUFBTSxDQUFDO0FBRVgsUUFBTTZHLDZCQUE2QixPQUFPQyxVQUFVO0FBQ2xEQSxVQUFNQyxlQUFlO0FBQ3JCeEcsc0JBQWtCLElBQUk7QUFDdEIsUUFBSStCLFNBQVNFLFdBQVdGLFNBQVNXLHVCQUF1QjtBQUN0RCxVQUFJO0FBQ0Z4QyxzQkFBYyxJQUFJO0FBQ2xCLGNBQU15RSxXQUFXLE1BQU1ySyxJQUFJc0ssSUFBSSxzQ0FBc0M7QUFBQSxVQUNuRUMsUUFBUTtBQUFBLFlBQ041QyxTQUFTRixTQUFTRTtBQUFBQSxZQUNsQlMsdUJBQXVCbkQ7QUFBQUEsWUFDdkJrSCxPQUFPO0FBQUEsWUFDUDNCLFNBQVNuSjtBQUFBQSxVQUNYO0FBQUEsUUFDRixDQUFDO0FBQ0QsWUFBSWdKLFVBQVVJLE1BQU07QUFDbEIzRSwrQkFBcUJ1RSxTQUFTSSxJQUFJO0FBQUEsUUFDcEMsT0FBTztBQUNMM0UsK0JBQXFCLEVBQUU7QUFBQSxRQUN6QjtBQUFBLE1BQ0YsU0FBU3FFLE9BQU87QUFDZHJFLDZCQUFxQixFQUFFO0FBQUEsTUFDekIsVUFBQztBQUNDRixzQkFBYyxLQUFLO0FBQUEsTUFDckI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUdBL0YsWUFBVSxNQUFNO0FBQ2QsVUFBTXVNLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTS9CLFdBQVcsTUFBTXJLLElBQUlzSyxJQUFJLGdCQUFnQjtBQUMvQy9JLGtCQUFVOEksU0FBU0ksSUFBSTtBQUFBLE1BQ3pCLFNBQVNOLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FpQyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDbkYsV0FBVyxDQUFDO0FBRWhCcEgsWUFBVSxNQUFNO0FBQ2QsVUFBTXVNLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTS9CLFdBQVcsTUFBTXJLLElBQUlzSyxJQUFJLHdCQUF3QjtBQUN2RDdJLHdCQUFnQjRJLFNBQVNJLElBQUk7QUFBQSxNQUMvQixTQUFTTixPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBaUMsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ25GLFdBQVcsQ0FBQztBQUVoQixRQUFNb0YsZUFBZUEsTUFBTTtBQUN6Qm5DLFlBQVFvQyxJQUFJLGlCQUFpQixFQUFFM0QsZUFBZUUsV0FBV0UsYUFBYXRCLFNBQVMsQ0FBQztBQUVoRixVQUFNOEUsWUFBWSxDQUFDO0FBRW5CLFFBQUk1RCxrQkFBa0IsWUFBWTtBQUNoQyxVQUFJLENBQUMzRyxpQkFBaUI7QUFDcEJ1SyxrQkFBVUMsV0FBVztBQUFBLE1BQ3ZCO0FBQ0EsVUFBSSxDQUFDckcscUJBQXFCO0FBQ3hCb0csa0JBQVVuRSx3QkFBd0I7QUFBQSxNQUNwQztBQUFBLElBQ0YsT0FBTztBQUVMLFVBQUksQ0FBQ1MsVUFBVTRELEtBQUssR0FBRztBQUNyQkYsa0JBQVUxRCxZQUFZO0FBQUEsTUFDeEI7QUFDQSxVQUFJLENBQUNFLFlBQVkwRCxLQUFLLEdBQUc7QUFDdkJGLGtCQUFVeEQsY0FBYztBQUFBLE1BQzFCLFdBQVcsQ0FBQyxXQUFXMkQsS0FBSzNELFlBQVkwRCxLQUFLLENBQUMsR0FBRztBQUMvQ0Ysa0JBQVV4RCxjQUFjO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDdEIsU0FBU0csVUFBVTtBQUN0QjJFLGdCQUFVM0UsV0FBVztBQUFBLElBQ3ZCO0FBRUEsVUFBTUMsU0FBUzhFLFdBQVdsRixTQUFTSSxNQUFNO0FBQ3pDLFFBQUkrRSxNQUFNL0UsTUFBTSxLQUFLQSxVQUFVLEdBQUc7QUFDaEMwRSxnQkFBVTFFLFNBQVM7QUFBQSxJQUNyQjtBQUVBLFFBQUk5RCxnQkFBZ0IsWUFBWSxDQUFDMEQsU0FBU00sZ0JBQWdCMEUsS0FBSyxHQUFHO0FBQ2hFRixnQkFBVXhFLGlCQUFpQjtBQUFBLElBQzdCO0FBQ0EsUUFBSWhFLGdCQUFnQixZQUFZLENBQUMwRCxTQUFTUSxhQUFhd0UsS0FBSyxHQUFHO0FBQzdERixnQkFBVXRFLGNBQWM7QUFBQSxJQUMxQjtBQUNBLFFBQUlsRSxnQkFBZ0IsWUFBWSxDQUFDMEQsU0FBU08sZUFBZXlFLEtBQUssR0FBRztBQUMvREYsZ0JBQVV2RSxnQkFBZ0I7QUFBQSxJQUM1QjtBQUVBLFFBQUlXLGtCQUFrQixjQUFjLENBQUNsQixTQUFTWSxtQkFBbUI7QUFDL0RrRSxnQkFBVWxFLG9CQUFvQjtBQUFBLElBQ2hDO0FBRUFiLGNBQVUrRSxTQUFTO0FBQ25CLFdBQU9NLE9BQU9DLEtBQUtQLFNBQVMsRUFBRTdCLFdBQVc7QUFBQSxFQUMzQztBQUNBLFFBQU1xQyxlQUFlQSxDQUFDdkcsTUFBTTtBQUMxQixVQUFNLEVBQUVtRCxNQUFNbEQsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQixRQUFJaUQsU0FBUyxxQkFBcUI7QUFDaEMsVUFBSWxELFVBQVUsVUFBVTtBQUN0QlAsMkJBQW1CLElBQUk7QUFDdkJVLDRCQUFvQixFQUFFO0FBQUEsTUFDeEIsT0FBTztBQUNMViwyQkFBbUIsS0FBSztBQUFBLE1BQzFCO0FBQUEsSUFDRjtBQUNBd0IsZ0JBQVksQ0FBQ3NGLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNyRCxJQUFJLEdBQUdsRDtBQUFBQSxJQUNWLEVBQUU7QUFDRmUsY0FBVSxDQUFDd0YsY0FBYyxFQUFFLEdBQUdBLFVBQVUsQ0FBQ3JELElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUN2RDtBQUVBLFFBQU1zRCx5QkFBeUJBLENBQUNDLFdBQVc7QUFDekNoSSwyQkFBdUJnSSxNQUFNO0FBQzdCOUcsMkJBQXVCOEcsTUFBTTtBQUFBLEVBQy9CO0FBRUEsUUFBTUMsb0JBQW9CLE9BQU9DLFlBQVk7QUFDM0N6TCxxQkFBaUJ5TCxPQUFPO0FBRXhCLFFBQUlBLFNBQVM7QUFDWCxVQUFJO0FBQ0YsY0FBTS9DLFdBQVcsTUFBTXJLLElBQUlzSyxJQUFJLDRCQUE0QjhDLE9BQU8sRUFBRTtBQUNwRSxZQUFJL0MsU0FBU0ksUUFBUUosU0FBU0ksS0FBS0MsU0FBUyxHQUFHO0FBQzdDckksMkJBQWlCZ0ksU0FBU0ksSUFBSTtBQUFBLFFBQ2hDLE9BQU87QUFDTHBJLDJCQUFpQixFQUFFO0FBQUEsUUFDckI7QUFBQSxNQUNGLFNBQVM4SCxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RDlILHlCQUFpQixFQUFFO0FBQUEsTUFDckI7QUFBQSxJQUNGLE9BQU87QUFDTEEsdUJBQWlCLEVBQUU7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0wsVUFBVTtBQUFBLElBQ2QsRUFBRXZHLEtBQUssTUFBTXdHLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUV4RyxLQUFLLFFBQVF3RyxRQUFRLFlBQVk7QUFBQSxJQUNuQyxFQUFFeEcsS0FBSyxvQkFBb0J3RyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUV4RyxLQUFLLFFBQVF3RyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUV4RyxLQUFLLGdCQUFnQndHLFFBQVEsZUFBZTtBQUFBLEVBQUM7QUFFakQsTUFBSXZJLG1CQUFtQjtBQUNyQnNJLFlBQVFFLEtBQUssRUFBRXpHLEtBQUssY0FBY3dHLFFBQVEsYUFBYSxDQUFDO0FBQUEsRUFDMUQ7QUFDQUQsVUFBUUU7QUFBQUEsSUFDTixFQUFFekcsS0FBSyxVQUFVd0csUUFBUSxnQkFBZ0I7QUFBQSxJQUN6QyxFQUFFeEcsS0FBSyxlQUFld0csUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRXhHLEtBQUssV0FBV3dHLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUV4RyxLQUFLLFVBQVV3RyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFeEcsS0FBSyxnQkFBZ0J3RyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFeEcsS0FBSyxxQkFBcUJ3RyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUV4RyxLQUFLLFFBQVF3RyxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFeEcsS0FBSyxVQUFVd0csUUFBUSxTQUFTO0FBQUEsRUFDcEM7QUFpQ0EsUUFBTUUsaUJBQWlCLE9BQU9KLFlBQVk7QUFDeENuTCx1QkFBbUJtTCxPQUFPO0FBQzFCMUYsZ0JBQVksQ0FBQytGLGtCQUFrQjtBQUFBLE1BQzdCLEdBQUdBO0FBQUFBLE1BQ0g5RixTQUFTeUY7QUFBQUEsSUFDWCxFQUFFO0FBRUZoSCwyQkFBdUIsSUFBSTtBQUMzQmxCLDJCQUF1QixFQUFFO0FBRXpCc0MsY0FBVSxDQUFDa0csVUFBVSxFQUFFLEdBQUdBLE1BQU1sQixVQUFVLElBQUlwRSx1QkFBdUIsR0FBRyxFQUFFO0FBRTFFK0Usc0JBQWtCQyxPQUFPO0FBQ3pCTyw2QkFBeUJQLE9BQU87QUFFaEMsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNL0MsV0FBVyxNQUFNckssSUFBSXNLLElBQUksMEJBQTBCOEMsT0FBTyxFQUFFO0FBQ2xFdksscUJBQWF3SCxTQUFTSSxRQUFRLENBQUMsQ0FBQztBQUFBLE1BQ2xDLFNBQVNOLE9BQU87QUFDZHRILHFCQUFhLENBQUMsQ0FBQztBQUFBLE1BQ2pCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLG1CQUFhLENBQUMsQ0FBQztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUNBLFFBQU0rSyxxQkFBcUIsT0FBT1IsWUFBWTtBQUM1Q2pMLDhCQUEwQmlMLE9BQU87QUFDakMsUUFBSUEsWUFBWSxTQUFTO0FBQ3ZCUyx1QkFBaUIsRUFBRUMsV0FBVzdKLE9BQU84SixTQUFTOUosTUFBTSxDQUFDO0FBQUEsSUFDdkQsT0FBTztBQUNMNEosdUJBQWlCLEVBQUU5QyxVQUFVcUMsUUFBUSxDQUFDO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBRUEsUUFBTXpCLGdCQUFnQkEsQ0FBQ3FDLGVBQWU7QUFDcEMsV0FBT0EsWUFBWTVKLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUNqQztBQUVBLFFBQU02SiwyQkFBMkIsT0FBT2IsWUFBWTtBQUNsRHJMLDRCQUF3QnFMLE9BQU87QUFDL0IsUUFBSUEsU0FBUztBQUNYLFVBQUljO0FBQ0osVUFBSWQsWUFBWSxTQUFTO0FBQ3ZCYyxjQUFNLHlEQUF5RGpLLEtBQUssWUFBWTVDLFdBQVc7QUFDM0YyRCw2QkFBcUIsSUFBSTtBQUFBLE1BQzNCLE9BQU87QUFDTGtKLGNBQU0sZ0RBQWdEZCxPQUFPLFlBQVkvTCxXQUFXO0FBQ3BGMkQsNkJBQXFCLEtBQUs7QUFBQSxNQUM1QjtBQUNBLFVBQUk7QUFDRm5ELHlCQUFpQixFQUFFO0FBQ25CeUMscUJBQWEsSUFBSTtBQUNqQixjQUFNK0YsV0FBVyxNQUFNckssSUFBSXNLLElBQUk0RCxHQUFHO0FBRWxDLFlBQUk3RCxTQUFTSSxRQUFRSixTQUFTSSxLQUFLQyxTQUFTLEdBQUc7QUFDN0MsZ0JBQU1DLGdCQUFnQk4sU0FBU0ksS0FBS0csSUFBSSxDQUFDdUQsU0FBU3JELFdBQVc7QUFBQSxZQUMzREcsS0FBS2tELFFBQVFsRDtBQUFBQSxZQUNiQyxJQUFJSixRQUFRO0FBQUEsWUFDWm5CLE1BQU13RSxRQUFRQyxpQkFBaUJELFFBQVF4RyxTQUFTd0Q7QUFBQUEsWUFDaERDLGNBQWMrQyxRQUFRRSxrQkFBa0JGLFFBQVF4RyxTQUFTeUQ7QUFBQUEsWUFDekRKLFlBQVltRCxRQUFRcEQsVUFBVUM7QUFBQUEsWUFDOUJLLFFBQVE4QyxRQUFROUM7QUFBQUEsWUFDaEJDLFNBQVM2QyxRQUFRNUM7QUFBQUEsWUFDakJDLGFBQWEyQyxRQUFRMUM7QUFBQUEsWUFDckI1RCxRQUFRc0csUUFBUXRHO0FBQUFBLFlBQ2hCNkQsTUFBTXlDLFFBQVF2RyxVQUFVeEQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFlBQ3BDd0gsa0JBQWtCdUMsUUFBUXRDLFdBQVd6SCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsWUFDakQwSCxjQUFjcUMsUUFBUWxFLFlBQVk4QixjQUFjO0FBQUEsWUFDaEQxRCxtQkFBbUI4RixRQUFROUY7QUFBQUEsWUFDM0JDLE1BQU02RixRQUFRN0Y7QUFBQUEsVUFDaEIsRUFBRTtBQUNGekcsMkJBQWlCOEksYUFBYTtBQUFBLFFBQ2hDLE9BQU87QUFDTGhJLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVN3SCxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRHhILDJCQUFtQixFQUFFO0FBQUEsTUFDdkIsVUFBQztBQUNDMkIscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRixPQUFPO0FBQ0wzQix5QkFBbUIsRUFBRTtBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU0yTCwwQkFBMEJBLENBQUM5SCxNQUFNO0FBQ3JDLFVBQU0rSCxlQUFlL0gsRUFBRUUsT0FBT0Q7QUFDOUJ6QyxtQkFBZXVLLFlBQVk7QUFDM0I3RyxnQkFBWSxDQUFDc0YsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0hsRixVQUFVeUc7QUFBQUEsTUFFVnhHLGdCQUFnQndHLGlCQUFpQixXQUFXdkIsU0FBU2pGLGlCQUFpQjtBQUFBLElBQ3hFLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTThGLG1CQUFtQixPQUFPVyxVQUFVLENBQUMsTUFBTTtBQUMvQyxRQUFJO0FBQ0YzTSx1QkFBaUIsRUFBRTtBQUNuQnlDLG1CQUFhLElBQUk7QUFDakIsWUFBTStGLFdBQVcsTUFBTXJLLElBQUlzSyxJQUFJLGlDQUFpQyxFQUFFQyxRQUFRaUUsUUFBUSxDQUFDO0FBQ25GLFVBQUluRSxTQUFTSSxNQUFNQSxNQUFNO0FBQ3ZCLGNBQU1FLGdCQUFnQk4sU0FBU0ksS0FBS0EsS0FBS0csSUFBSSxDQUFDdUQsU0FBU3JELFdBQVc7QUFBQSxVQUNoRUcsS0FBS2tELFFBQVFsRDtBQUFBQSxVQUNiQyxJQUFJSixRQUFRO0FBQUEsVUFDWm5CLE1BQU13RSxRQUFRQyxpQkFBaUJELFFBQVF4RyxTQUFTd0QsYUFBYTtBQUFBLFVBQzdEQyxjQUFjK0MsUUFBUUUsa0JBQWtCRixRQUFReEcsU0FBU3lELGdCQUFnQjtBQUFBLFVBQ3pFSixZQUFZbUQsUUFBUXBELFVBQVVDLGNBQWM7QUFBQSxVQUM1Q0ssUUFBUThDLFFBQVE5QyxVQUFVO0FBQUEsVUFDMUJDLFNBQVM2QyxRQUFRNUMsY0FBYztBQUFBLFVBQy9CQyxhQUFhMkMsUUFBUTFDLGtCQUFrQjtBQUFBLFVBQ3ZDNUQsUUFBUXNHLFFBQVF0RyxVQUFVO0FBQUEsVUFDMUI2RCxNQUFNeUMsUUFBUXZHLFVBQVV4RCxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxVQUN6Q3dILGtCQUFrQnVDLFFBQVF0QyxXQUFXekgsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsVUFDdEQwSCxjQUFjcUMsUUFBUWxFLFlBQVk4QixjQUFjO0FBQUEsVUFDaEQxRCxtQkFBbUI4RixRQUFROUYscUJBQXFCO0FBQUEsVUFDaERDLE1BQU02RixRQUFRN0YsUUFBUTtBQUFBLFFBQ3hCLEVBQUU7QUFDRnpHLHlCQUFpQjhJLGFBQWE7QUFDOUIzRiw2QkFBcUIsSUFBSTtBQUFBLE1BQzNCLE9BQU87QUFDTG5ELHlCQUFpQixFQUFFO0FBQUEsTUFDckI7QUFBQSxJQUNGLFNBQVNzSSxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EdEksdUJBQWlCLEVBQUU7QUFBQSxJQUNyQixVQUFDO0FBQ0N5QyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUF6RSxZQUFVLE1BQU07QUFDZGdPLHFCQUFpQixFQUFFQyxXQUFXN0osT0FBTzhKLFNBQVM5SixNQUFNLENBQUM7QUFBQSxFQUN2RCxHQUFHLENBQUNrQixNQUFNLENBQUM7QUFFWCxRQUFNc0osZUFBZSxPQUFPakksTUFBTTtBQUNoQ0EsTUFBRTBGLGVBQWU7QUFDakIsVUFBTXdDLFVBQVVyQyxhQUFhO0FBQzdCLFFBQUksQ0FBQ3FDLFFBQVM7QUFFZCxRQUFJO0FBQ0ZoSyxrQkFBWSxJQUFJO0FBQ2hCd0MscUJBQWUsQ0FBQ3dHLFVBQVUsRUFBRSxHQUFHQSxNQUFNdkcsWUFBWSxNQUFNLEVBQUU7QUFDekRwRSxtQkFBYSxLQUFLO0FBR2xCLFlBQU1pSCxNQUFNVixhQUFhQyxRQUFRLE1BQU07QUFDdkMsVUFBSVUsYUFBYTtBQUNqQixVQUFJO0FBQ0YsWUFBSUQsSUFBS0MsY0FBYVIsS0FBS0MsTUFBTU0sR0FBRztBQUFBLE1BQ3RDLFNBQVN4RCxJQUFHO0FBQ1YwRCxnQkFBUUMsTUFBTSx5QkFBeUIzRCxFQUFDO0FBQUEsTUFDMUM7QUFHQSxVQUFJbUksVUFBVTtBQUFBLFFBQ1ovRyxVQUFVSCxTQUFTRztBQUFBQSxRQUNuQkMsUUFBUUosU0FBU0k7QUFBQUEsUUFDakJDLFVBQVVMLFNBQVNLO0FBQUFBLFFBQ25CQyxnQkFBZ0JOLFNBQVNNLGtCQUFrQjZHO0FBQUFBLFFBQzNDNUcsZUFBZVAsU0FBU08saUJBQWlCO0FBQUEsUUFDekNDLGFBQWFSLFNBQVNRLGVBQWU7QUFBQSxRQUNyQ0Msa0JBQWtCVCxTQUFTUyxvQkFBb0I7QUFBQSxRQUMvQ0Msb0JBQW9CVixTQUFTVSxzQkFBc0I7QUFBQSxRQUNuREcsTUFBTWIsU0FBU2EsUUFBUTtBQUFBLFFBQ3ZCMkIsWUFBWUEsWUFBWWdCO0FBQUFBLFFBQ3hCNUMsbUJBQ0VaLFNBQVNZLHNCQUFzQixXQUMzQjFCLG9CQUFvQixXQUNwQmMsU0FBU1k7QUFBQUEsUUFDZndHLGVBQWVsRztBQUFBQTtBQUFBQSxNQUNqQjtBQUdBLFVBQUlBLGtCQUFrQixZQUFZO0FBQ2hDZ0csZ0JBQVFoSCxVQUFVM0Y7QUFFbEIsWUFBSW1FLHFCQUFxQjtBQUN2QixnQkFBTTJJLFFBQVEzSSxvQkFBb0IvQixNQUFNLEdBQUc7QUFFM0MsY0FBSTBLLE1BQU1wRSxXQUFXLEdBQUc7QUFDdEJpRSxvQkFBUTVELFdBQVcrRCxNQUFNLENBQUMsRUFBRUMsUUFBUSxTQUFTLEVBQUU7QUFDL0NKLG9CQUFRdEQsU0FBU3lELE1BQU0sQ0FBQztBQUFBLFVBQzFCO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMSCxnQkFBUXhGLGFBQWFOLFVBQVU0RCxLQUFLO0FBQ3BDa0MsZ0JBQVFLLGNBQWNqRyxZQUFZMEQsS0FBSztBQUFBLE1BQ3pDO0FBRUFuSCw0QkFBc0IsSUFBSTtBQUcxQixZQUFNK0UsV0FBVyxNQUFNckssSUFBSWlQLEtBQUssaUNBQWlDTixPQUFPO0FBRXhFLFVBQUl0RSxTQUFTNkUsV0FBVyxPQUFPN0UsU0FBUzZFLFdBQVcsS0FBSztBQUV0RGpOLDJCQUFtQixFQUFFO0FBQ3JCbUUsK0JBQXVCLElBQUk7QUFDM0IwQyxxQkFBYSxFQUFFO0FBQ2ZFLHVCQUFlLEVBQUU7QUFDakJ0QixvQkFBWTtBQUFBLFVBQ1ZDLFNBQVM7QUFBQSxVQUNUQyxVQUFVM0Q7QUFBQUEsVUFDVjRELFFBQVE7QUFBQSxVQUNSQyxVQUFVO0FBQUEsVUFDVkMsZ0JBQWdCO0FBQUEsVUFDaEJNLG1CQUFtQjtBQUFBLFVBQ25CQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQ0RwQix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaRSxVQUFVO0FBQUEsVUFDVkQsU0FBUztBQUFBLFVBQ1RFLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTEosdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkUsVUFBVTtBQUFBLFVBQ1ZELFNBQVM7QUFBQSxVQUNURSxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBUzZDLE9BQU87QUFDZEQsY0FBUUMsTUFBTSxrQ0FBa0NBLEtBQUs7QUFDckRqRCxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaRSxVQUFVO0FBQUEsUUFDVkQsU0FBUytDLE1BQU1FLFVBQVVJLE1BQU1yRCxXQUFXO0FBQUEsUUFDMUNFLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ2hDLDRCQUFzQixLQUFLO0FBQzNCWixrQkFBWSxLQUFLO0FBQ2pCVSxrQkFBWSxDQUFDc0ksU0FBU0EsT0FBTyxDQUFDO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsUUFBTXlCLHdCQUF3QixPQUFPL0IsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTS9DLFdBQVcsTUFBTXJLLElBQUlzSyxJQUFJLDhCQUE4QjhDLE9BQU8sRUFBRTtBQUN0RS9KLHNCQUFnQmdILFNBQVNJLElBQUk7QUFDN0J4SCx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNrSCxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sMEJBQTBCQSxLQUFLO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBRUEsUUFBTWlGLHNCQUFzQixZQUFZO0FBQ3RDLFFBQUloTSxjQUFjO0FBQ2hCLFVBQUk7QUFDRixjQUFNcEQsSUFBSXFQLE9BQU8sMkJBQTJCak0sYUFBYTZILEdBQUcsRUFBRTtBQUU5RGhJLDJCQUFtQixLQUFLO0FBQ3hCSSx3QkFBZ0IsSUFBSTtBQUNwQjZELHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNURSxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxTQUFTNkMsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSwyQkFBMkJBLEtBQUs7QUFBQSxNQUNoRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTW1GLHNCQUFzQixPQUFPbEMsWUFBWTtBQUM3QyxRQUFJO0FBQ0Y1SSxpQkFBVyxJQUFJO0FBQ2ZqQix1QkFBaUIsSUFBSTtBQUNyQmlDLHdCQUFrQjRILE9BQU87QUFDekIzSyxvQkFBYyxJQUFJO0FBQ2xCLFlBQU00SCxXQUFXLE1BQU1ySyxJQUFJc0ssSUFBSSx1QkFBdUI4QyxPQUFPLEVBQUU7QUFDL0QzSiwwQkFBb0I0RyxTQUFTSSxLQUFLQSxJQUFJO0FBQUEsSUFDeEMsU0FBU04sT0FBTztBQUNkRCxjQUFRQyxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DLFVBQUM7QUFDQzNGLGlCQUFXLEtBQUs7QUFDaEIvQixvQkFBYyxLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTThNLHdCQUF3QixPQUFPbkMsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTS9DLFdBQVcsTUFBTXJLLElBQUlzSyxJQUFJLDhCQUE4QjhDLE9BQU8sRUFBRTtBQUN0RWpLLDZCQUF1QmtILFNBQVNJLElBQUk7QUFDcENqQyx3QkFBa0I7QUFBQSxRQUNoQlgsUUFBUXdDLFVBQVVJLE1BQU01QztBQUFBQSxRQUN4QkQsVUFBVXlDLFVBQVVJLE1BQU03QyxTQUFTeEQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2pELENBQUM7QUFDRFUseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTcUYsT0FBTztBQUNkRCxjQUFRQyxNQUFNLHVDQUF1Q0EsS0FBSztBQUFBLElBQzVEO0FBQUEsRUFDRjtBQUNBLFFBQU1xRixlQUFlLE9BQU9oSixNQUFNO0FBQ2hDQSxNQUFFMEYsZUFBZTtBQUNqQixRQUFJO0FBQ0YsWUFBTWxNLElBQUl5UDtBQUFBQSxRQUNSLHVCQUF1QnZNLG9CQUFvQitILEdBQUc7QUFBQSxRQUM5QzFDO0FBQUFBLE1BQ0Y7QUFDQXpELHlCQUFtQixLQUFLO0FBQ3hCb0MscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RFLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRGxDLGtCQUFZLENBQUFzSSxTQUFRQSxPQUFPLENBQUM7QUFBQSxJQUM5QixTQUFTdkQsT0FBTztBQUNkRCxjQUFRQyxNQUFNLGtDQUFrQ0EsS0FBSztBQUNyRGpELHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVMrQyxNQUFNRSxVQUFVSSxNQUFNckQsV0FBVztBQUFBLFFBQzFDRSxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDQSxRQUFNb0ksK0JBQStCQSxDQUFDekQsVUFBVTtBQUM5QyxVQUFNLEVBQUV0QyxNQUFNbEQsTUFBTSxJQUFJd0YsTUFBTXZGO0FBQzlCRSx3QkFBb0JILEtBQUs7QUFBQSxFQUMzQjtBQUNBLFFBQU1rSCwyQkFBMkIsT0FBT1AsWUFBWTtBQUNsRCxRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU0vQyxXQUFXLE1BQU1ySyxJQUFJaVA7QUFBQUEsVUFDekIsbUNBQW1DN0IsT0FBTztBQUFBLFFBQzVDO0FBQ0EsWUFBSS9DLFNBQVNJLFFBQVFKLFNBQVNJLEtBQUtDLFNBQVMsR0FBRztBQUM3QyxnQkFBTWlGLGdCQUFnQnRGLFNBQVNJLEtBQUttRjtBQUFBQSxZQUNsQyxDQUFDQyxZQUFZQSxRQUFRQyxjQUFjRCxRQUFRQyxXQUFXakY7QUFBQUEsVUFDeEQ7QUFDQWxJLDZCQUFtQmdOLGFBQWE7QUFBQSxRQUNsQyxPQUFPO0FBQ0xoTiw2QkFBbUIsRUFBRTtBQUFBLFFBQ3ZCO0FBQUEsTUFDRixTQUFTd0gsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdER4SCwyQkFBbUIsRUFBRTtBQUFBLE1BQ3ZCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLHlCQUFtQixFQUFFO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRzBDLCtCQUNDLHVCQUFDLHNCQUFtQixPQUFPLGlDQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlELElBRXpELHVCQUFDLFNBQ0MsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkJrQjtBQUFBQSxRQUM3QixZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNVSxZQUFZSztBQUFBQSxRQUNsQixXQUFXTCxZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQ3dHLFVBQVUsRUFBRSxHQUFHQSxNQUFNdkcsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLE1BTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFFSCx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNYLHVCQUFDLFFBQUcsV0FBVSwwQkFDWjtBQUFBLCtCQUFDLFVBQUssV0FBVSxtQ0FDYjlGLHVCQUFhME8sWUFBWSxLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDO0FBQUEsUUFBSztBQUFBLFdBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGFBQVksc0NBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osdUJBQXVCO0FBQUEsZ0JBQ3ZCO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBT2xPLDBCQUEwQjBNO0FBQUFBLGdCQUNqQyxVQUFVaEI7QUFBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBeUIsT0FBTyxTQUM5QixnQ0FEaUIsTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDcE0sYUFBYW9KO0FBQUFBLG9CQUFJLENBQUNDLFVBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNSSxLQUN6Q0osZ0JBQU1HLGNBRFdILE1BQU1JLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFzQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1sSSxhQUFhLElBQUk7QUFBQSxnQkFDaEMsV0FBVTtBQUFBLGdCQUF1RztBQUFBO0FBQUEsY0FGbkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ0E7QUFBQSxhQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFFQ25CLGlCQUFpQkEsY0FBYzhJLFNBQVMsSUFDdkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU05SSxjQUFjZ087QUFBQUEsY0FBTyxDQUFDVSxTQUMxQnpELE9BQU9LLE9BQU9vRCxJQUFJLEVBQUVDO0FBQUFBLGdCQUFLLENBQUM5SixVQUN4QitKLE9BQU8vSixLQUFLLEVBQ1QySixZQUFZLEVBQ1pDLFNBQVMxTCxXQUFXeUwsWUFBWSxDQUFDO0FBQUEsY0FDdEM7QUFBQSxZQUNGO0FBQUEsWUFDQTtBQUFBLFlBQ0Esa0JBQWtCLFlBQVl4TyxjQUFjOEksU0FBUyxJQUNqRDlJLGNBQWMsQ0FBQyxFQUFFOEosT0FDbkIsU0FDQTlKLGNBQWNBLGNBQWM4SSxTQUFTLENBQUMsRUFBRWdCLE9BQ3RDLE9BQU87QUFBQTtBQUFBLFVBYmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBY1csSUFHWCx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxTQUNFOUosY0FBYzhJLFVBQVUsS0FBS3hJO0FBQUFBO0FBQUFBLFVBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtHLEtBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FoRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtFQTtBQUFBLFNBM0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0RUE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXWTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiYiw2QkFBbUIsRUFBRTtBQUNyQm1FLGlDQUF1QixJQUFJO0FBQzNCckQsdUJBQWEsS0FBSztBQUNsQnlFLG9CQUFVLENBQUMsQ0FBQztBQUNab0IsMkJBQWlCLFVBQVU7QUFDM0JFLHVCQUFhLEVBQUU7QUFDZkUseUJBQWUsRUFBRTtBQUFBLFFBQ25CO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLFVBQ3BFLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVV5RixjQUFjLFlBQVUsTUFDNUQ7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxPQUFPLHVCQUFDLE9BQUUsdUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEI7QUFBQSxnQkFDakMsV0FBVTtBQUFBLGdCQUNWLE1BQU1oSjtBQUFBQSxnQkFDTixTQUFTRTtBQUFBQSxnQkFDVCxTQUFTLE1BQU1ELGtCQUFrQixLQUFLO0FBQUEsZ0JBRXJDRyw2QkFBbUI2RSxVQUFVLElBQzVCLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0Msb0NBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1o3RSw0QkFBa0IrRSxJQUFJLENBQUN1RCxTQUFTckQsVUFBVTtBQUN6Qyx5QkFDRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBR1Y7QUFBQSwrQ0FBQyxTQUFJLFdBQVUsK0JBQThCO0FBQUE7QUFBQSwwQkFDN0I7QUFBQSwwQkFDZCx1QkFBQyxVQUFLLFdBQVUsYUFBYXFELG1CQUFTdkcsWUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBK0M7QUFBQSw2QkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFHQTtBQUFBLHdCQUVDdUcsUUFBUXBELFlBQ1AsdUJBQUMsU0FBSSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsMEJBQ3BDO0FBQUEsMEJBQ1AsdUJBQUMsVUFBSyxXQUFVLGFBQ2JvRCxrQkFBUXBELFVBQVVDLGNBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBRURtRCxRQUFROUMsVUFDUCx1QkFBQyxTQUFJLFdBQVUsK0JBQThCO0FBQUE7QUFBQSwwQkFDbkM7QUFBQSwwQkFDUix1QkFBQyxVQUFLLFdBQVUsZUFBZThDLG1CQUFTOUMsVUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBK0M7QUFBQSw2QkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFHQTtBQUFBLHdCQUVGLHVCQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLDBCQUM1QjtBQUFBLDBCQUNmLHVCQUFDLFVBQUssV0FBVSxhQUFZO0FBQUE7QUFBQSw0QkFBRThDLFNBQVN0RztBQUFBQSwrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBOEM7QUFBQSw2QkFGaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFHQTtBQUFBLHdCQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLDBCQUM3QjtBQUFBLDBCQUNkLHVCQUFDLFVBQUssV0FBVSxlQUFlc0csbUJBQVNyRyxZQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpRDtBQUFBLDZCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUdBO0FBQUEsd0JBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsMEJBQ3JDO0FBQUEsMEJBQ04sdUJBQUMsVUFBSyxXQUFVLGVBQ2JxRyxrQkFBUXhHLFNBQVN3RCxhQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsNkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBO0FBQUE7QUFBQSxvQkFsQ0tMO0FBQUFBLG9CQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBcUNBO0FBQUEsZ0JBRUosQ0FBQyxLQTFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJDQTtBQUFBO0FBQUEsY0F6REo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMkRBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsd0NBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNO0FBQ2JsQyxxQ0FBaUIsVUFBVTtBQUMzQkUsaUNBQWEsRUFBRTtBQUNmRSxtQ0FBZSxFQUFFO0FBRWpCeEIsOEJBQVUsQ0FBQ2tHLFVBQVUsRUFBRSxHQUFHQSxNQUFNN0UsV0FBVyxJQUFJRSxhQUFhLEdBQUcsRUFBRTtBQUFBLGtCQUNuRTtBQUFBLGtCQUNBLFdBQVcsNkRBQTZESixrQkFBa0IsYUFDdEYsdUNBQ0EsbUNBQW1DO0FBQUEsa0JBQ2xDO0FBQUE7QUFBQSxnQkFaUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FlQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUNiQyxxQ0FBaUIsT0FBTztBQUN4QjFDLHVDQUFtQixLQUFLO0FBQ3hCakUsdUNBQW1CLEVBQUU7QUFDckJpRCwyQ0FBdUIsRUFBRTtBQUV6QnNDLDhCQUFVLENBQUNrRyxVQUFVO0FBQUEsc0JBQ25CLEdBQUdBO0FBQUFBLHNCQUNIbEIsVUFBVTtBQUFBLHNCQUNWcEUsdUJBQXVCO0FBQUEsb0JBQ3pCLEVBQUU7QUFBQSxrQkFDSjtBQUFBLGtCQUNBLFdBQVcsNkRBQTZETyxrQkFBa0IsVUFDdEYsdUNBQ0EsbUNBQW1DO0FBQUEsa0JBQ2xDO0FBQUE7QUFBQSxnQkFqQlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBb0JBO0FBQUEsaUJBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0NBO0FBQUEsWUFHQ0Esa0JBQWtCLGNBQ2pCLG1DQUNFO0FBQUEscUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFVO0FBQUE7QUFBQSxzQkFFVCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyw2RUFBNkUzSCxVQUFVeVAsTUFBTTtBQUFBLG9CQUN4RyxhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsY0FBYyxDQUFDVCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPcE8sbUJBQW1CNE07QUFBQUEsb0JBQzFCLFVBQVVwQjtBQUFBQSxvQkFFVGxNLGlCQUFPc0o7QUFBQUEsc0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUksS0FDekMsYUFBR0osTUFBTU0sU0FBUyxNQUFNTixNQUFNTyxZQUFZLE1BRHpCUCxNQUFNSSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBbUJBO0FBQUEsZ0JBRUMxRCxPQUFPaUYsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCakYsaUJBQU9pRixZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRDtBQUFBLG1CQTlCOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQ0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGFBQVk7QUFBQSxvQkFDWixVQUFVUztBQUFBQSxvQkFDVixPQUFPOUc7QUFBQUEsb0JBQ1AsV0FBVTtBQUFBLG9CQUNWLFlBQVU7QUFBQSxvQkFFVHpELDBCQUFnQmtJLElBQUksQ0FBQzhGLE9BQU81RixVQUFVO0FBQ3JDLDRCQUFNNkYsWUFBWUQsT0FBT1osWUFBWWpGLE9BQU9HLGNBQWM7QUFDMUQsNEJBQU1vQyxVQUFVc0QsT0FBT1osWUFBWWpGLE9BQU9JLE9BQU8sV0FBV0gsS0FBSztBQUNqRSw0QkFBTU8sU0FBU3FGLE9BQU9aLFlBQVljLFdBQVc7QUFDN0MsNEJBQU05SixNQUFNLFFBQVFzRyxPQUFPLElBQUkvQixNQUFNO0FBQ3JDLDZCQUNFLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPdkUsS0FDN0I2SjtBQUFBQTtBQUFBQSx3QkFBVTtBQUFBLHdCQUFJdEY7QUFBQUEsMkJBREd2RSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBRUosQ0FBQztBQUFBO0FBQUEsa0JBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFrQkE7QUFBQSxnQkFDQ1MsT0FBT2EseUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QmIsaUJBQU9hLHlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RTtBQUFBLG1CQXhCM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQkE7QUFBQSxpQkE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4REE7QUFBQSxZQUlETyxrQkFBa0IsV0FDakIsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFZO0FBQUE7QUFBQSxzQkFFVCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0VBQ2IsaUNBQUMsVUFBTyxXQUFVLG1CQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxPQUFPRTtBQUFBQSxzQkFDUCxVQUFVLENBQUNyQyxNQUFNO0FBQ2ZzQyxxQ0FBYXRDLEVBQUVFLE9BQU9ELEtBQUs7QUFDM0IsNEJBQUljLE9BQU9zQixVQUFXckIsV0FBVSxFQUFFLEdBQUdELFFBQVFzQixXQUFXLEdBQUcsQ0FBQztBQUFBLHNCQUM5RDtBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUE7QUFBQSxvQkFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU2dDO0FBQUEscUJBYmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxnQkFDQ3RCLE9BQU9zQixhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ0QixpQkFBT3NCLGFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJEO0FBQUEsbUJBeEIvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFjO0FBQUE7QUFBQSxzQkFFUix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0VBQ2IsaUNBQUMsY0FBVyxXQUFVLG1CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxPQUFPRTtBQUFBQSxzQkFDUCxVQUFVLENBQUN2QyxNQUFNO0FBRWYsOEJBQU1DLFFBQVFELEVBQUVFLE9BQU9ELE1BQU1zSSxRQUFRLFdBQVcsRUFBRTtBQUNsRC9GLHVDQUFldkMsS0FBSztBQUNwQiw0QkFBSWMsT0FBT3dCO0FBQ1R2QixvQ0FBVSxFQUFFLEdBQUdELFFBQVF3QixhQUFhLEdBQUcsQ0FBQztBQUFBLHNCQUM1QztBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUE7QUFBQSxvQkFaZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBWW1DO0FBQUEscUJBaEJyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLGdCQUNDeEIsT0FBT3dCLGVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnhCLGlCQUFPd0IsZUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkQ7QUFBQSxtQkEzQmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkJBO0FBQUEsaUJBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkRBO0FBQUEsWUFHRix1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFlO0FBQUE7QUFBQSxnQkFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFVBQVUsQ0FBQ047QUFBQUEsa0JBQ1gsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPaEIsU0FBU0c7QUFBQUEsa0JBQ2hCLElBQUc7QUFBQSxrQkFDSCxVQUFVbUY7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVEwSTtBQUFBLGNBR3pJeEYsT0FBT0ssWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCTCxpQkFBT0ssWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxpQkFuQjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBLEtBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWE7QUFBQTtBQUFBLHNCQUVkLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT0gsU0FBU0k7QUFBQUEsc0JBQ2hCLElBQUc7QUFBQSxzQkFDSCxVQUFVa0Y7QUFBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVEySTtBQUFBLGtCQUcxSXBFLGtCQUFrQixjQUNqQix1QkFBQyxXQUFRLE9BQU0sdUJBQ2I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVMsQ0FBQ25DLE1BQU13RiwyQkFBMkJ4RixDQUFDO0FBQUEsc0JBRTVDLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBVTtBQUFBO0FBQUEsb0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLHFCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNCQTtBQUFBLGdCQUVDZSxPQUFPTSxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJOLGlCQUFPTSxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLG1CQWhDNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQ0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBVTtBQUFBO0FBQUEsa0JBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxJQUFHO0FBQUEsb0JBQ0gsV0FBVTtBQUFBLG9CQUNWLFVBQVV5RztBQUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QjtBQUFBLHNCQUN6Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSxzQkFDN0IsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUEsc0JBQzVCN0YsaUJBQ0MsbUNBQ0U7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQSx3QkFDakMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUEsd0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxQztBQUFBLHdCQUNyQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkI7QUFBQSwyQkFKL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBO0FBQUE7QUFBQSxrQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaUJBO0FBQUEsbUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsaUJBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOERBO0FBQUEsWUFFQ0Usa0JBQWtCLGNBQ2pCbEIsU0FBU0ksVUFDVDVDLG9CQUFvQnlGLFNBQVMsS0FDM0IsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLGdCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FBT21HLE9BQU9wSixTQUFTSSxNQUFNLElBQUk1QyxvQkFBb0J5RjtBQUFBQSxrQkFDckQsVUFBUTtBQUFBO0FBQUEsZ0JBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS1U7QUFBQSxpQkFiWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFFSDNHLGdCQUFnQixZQUNmLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBZ0I7QUFBQTtBQUFBLG9CQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxJQUFHO0FBQUEsa0JBQ0gsT0FBTzBELFNBQVNNO0FBQUFBLGtCQUNoQixVQUFVZ0Y7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU8ySTtBQUFBLGNBRTFJeEYsT0FBT1Esa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWUixpQkFBT1Esa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBRURoRSxnQkFBZ0IsWUFDZix1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsOENBQTZDLDhCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RTtBQUFBLGNBQ3pFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxvQkFDbEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsT0FBTzBELFNBQVNPO0FBQUFBLHNCQUNoQixVQUFVK0U7QUFBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLFdBQVU7QUFBQTtBQUFBLG9CQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPdUw7QUFBQSxrQkFFdEx4RixPQUFPUyxpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCVCxpQkFBT1MsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStEO0FBQUEscUJBZG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLG9CQUNwRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxPQUFPUCxVQUFVUSxhQUFhN0QsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLHNCQUMxQyxVQUFVMkk7QUFBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLFdBQVU7QUFBQTtBQUFBLG9CQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPdUw7QUFBQSxrQkFFdEx4RixPQUFPVSxlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJWLGlCQUFPVSxlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBLHFCQWRqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdCQTtBQUFBLGdCQUVBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsa0RBQWlELHlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsT0FBT1IsU0FBU1M7QUFBQUEsc0JBQ2hCLFVBQVU2RTtBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU91TDtBQUFBLHFCQVh6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxPQUFPdEYsU0FBU1U7QUFBQUEsc0JBQ2hCLFVBQVU0RTtBQUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU91TDtBQUFBLHFCQVh6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsbUJBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0VBO0FBQUEsaUJBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUVBO0FBQUEsWUFFRHBFLGtCQUFrQixjQUNqQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLGdCQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLElBQUc7QUFBQSxrQkFDSCxPQUFPbEIsU0FBU1k7QUFBQUEsa0JBQ2hCLFdBQVU7QUFBQSxrQkFDVixVQUFVMEU7QUFBQUEsa0JBRVY7QUFBQSwyQ0FBQyxZQUFPLE9BQU0sSUFBRywwQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkI7QUFBQSxvQkFDMUJsRyxrQkFBa0IrRDtBQUFBQSxzQkFBSSxDQUFDa0csVUFDdEIsdUJBQUMsWUFBdUIsT0FBT0EsTUFBTXJLLE9BQ2xDcUssZ0JBQU0vSixTQURJK0osTUFBTWhLLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUE7QUFBQSxnQkFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGNBQ0NTLE9BQU9jLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmQsaUJBQU9jLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVEcEMsbUJBQ0MsbUNBQ0U7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWE7QUFBQTtBQUFBLGtCQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1U7QUFBQUEsb0JBQ1AsYUFBWTtBQUFBLG9CQUNaLFVBQVUrSTtBQUFBQTtBQUFBQSxrQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT3lDO0FBQUEsbUJBZDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FDQ25JLE9BQU9jLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmQsaUJBQU9jLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxZQUdGLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTTtBQUFBO0FBQUEsZ0JBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFNO0FBQUEsa0JBQ04sTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsTUFBSztBQUFBLGtCQUNMLE9BQU9aLFNBQVNhO0FBQUFBLGtCQUNoQixhQUFZO0FBQUEsa0JBQ1osVUFBVXlFO0FBQUFBO0FBQUFBLGdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVF5QjtBQUFBLGlCQWYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUFpQmhILHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQztBQUFBLGlCQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDRDQUdiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNNO0FBQUFBLG9CQUNULFVBQVUsQ0FBQ0csTUFBTUYsbUJBQW1CRSxFQUFFRSxPQUFPcUssT0FBTztBQUFBLG9CQUNwRCxXQUFVO0FBQUE7QUFBQSxrQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSXNDO0FBQUEsZ0JBR3RDLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsaUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx1Q0FBQyxvQkFBaUIsV0FBVSxhQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQztBQUFBLGdCQUNyQyx1QkFBQyxVQUFLLFdBQVUsdUJBQXNCLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QztBQUFBLG1CQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNaE8sYUFBYSxLQUFLO0FBQUEsa0JBQ2pDLFdBQVU7QUFBQSxrQkFBNkU7QUFBQTtBQUFBLGdCQUh6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBQ0EsdUJBQUMsV0FBUSxPQUFNLHNCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQzZGO0FBQUE7QUFBQSxnQkFIekc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsZUFuakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb2pCQTtBQUFBLGFBdGpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdWpCQTtBQUFBO0FBQUEsTUFua0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9rQkE7QUFBQSxPQWhxQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlxQkEsS0FscUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtcUJBLEtBdnFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeXFCQTtBQUVKO0FBQUUzQixHQTM2Q0lELGNBQVk7QUFBQSxVQUNRTixTQUFTO0FBQUE7QUFBQW1RLEtBRDdCN1A7QUE2NkNOLGVBQWVBO0FBQWEsSUFBQTZQO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJNb2RhbCIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0IiwiQ2lyY3VsYXJMb2FkZXIiLCJGYVBob25lQWx0IiwiRmFVc2VyIiwiRmFXaGF0c2FwcFNxdWFyZSIsIk5hdmJhciIsIlNlbGVjdCIsIkFudE1vZGFsIiwiRHJhd2VyIiwiVG9vbHRpcCIsInVzZVBhcmFtcyIsIkJhY2tkcm9wQmx1ckxvYWRlciIsIkZhUmVjZWlwdCIsImZpZWxkU2l6ZSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiQnJlYWRjcnVtYiIsIlBheU91dE90aGVycyIsIl9zIiwicGF5bWVudFR5cGUiLCJncm91cHMiLCJzZXRHcm91cHMiLCJhY3R1YWxHcm91cHMiLCJzZXRBY3R1YWxHcm91cHMiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsIlRhYmxlUGF5bWVudHMiLCJzZXRUYWJsZVBheW1lbnRzIiwic2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cCIsInNlbGVjdGVkR3JvdXBJZCIsInNldFNlbGVjdGVkR3JvdXBJZCIsInNlbGVjdGVkQXVjdGlvbkdyb3VwSWQiLCJzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwiZmlsdGVyZWRVc2VycyIsInNldEZpbHRlcmVkVXNlcnMiLCJ1c2VyTmFtZSIsInNldFVzZXJOYW1lIiwidmlld0xvYWRlciIsInNldFZpZXdMb2FkZXIiLCJmaWx0ZXJlZEF1Y3Rpb24iLCJzZXRGaWx0ZXJlZEF1Y3Rpb24iLCJncm91cEluZm8iLCJzZXRHcm91cEluZm8iLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJjdXJyZW50VXBkYXRlQW1vdW50Iiwic2V0Q3VycmVudFVwZGF0ZUFtb3VudCIsImN1cnJlbnRHcm91cCIsInNldEN1cnJlbnRHcm91cCIsInNob3dNb2RhbFZpZXciLCJzZXRTaG93TW9kYWxWaWV3IiwiY3VycmVudFZpZXdHcm91cCIsInNldEN1cnJlbnRWaWV3R3JvdXAiLCJzaG93VXBsb2FkTW9kYWwiLCJzZXRTaG93VXBsb2FkTW9kYWwiLCJyZWNlaXB0Tm8iLCJzZXRSZWNlaXB0Tm8iLCJ3aGF0c2FwcEVuYWJsZSIsInBheW1lbnRNb2RlIiwic2V0UGF5bWVudE1vZGUiLCJ0b2RheSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwibG9hZGluZyIsInNldExvYWRpbmciLCJkaXNhYmxlZCIsInNldERpc2FibGVkIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzaG93VXBkYXRlTW9kYWwiLCJzZXRTaG93VXBkYXRlTW9kYWwiLCJlbmFibGVHcm91cENvbHVtbiIsInNldEVuYWJsZUdyb3VwQ29sdW1uIiwicGF5bWVudEdyb3VwVGlja2V0cyIsInNldFBheW1lbnRHcm91cFRpY2tldHMiLCJyZW5kZXIiLCJzZXRSZXJlbmRlciIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsImN1cnJlbnRHcm91cElkIiwic2V0Q3VycmVudEdyb3VwSWQiLCJvcGVuQW50RERyYXdlciIsInNldE9wZW5BbnRERHJhd2VyIiwic2hvd0xvYWRlciIsInNldFNob3dMb2FkZXIiLCJsYXN0VGhyZWVQYXltZW50cyIsInNldExhc3RUaHJlZVBheW1lbnRzIiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwic2hvd090aGVyc0ZpZWxkIiwic2V0U2hvd090aGVyc0ZpZWxkIiwic2VsZWN0ZWRUaWNrZXRWYWx1ZSIsInNldFNlbGVjdGVkVGlja2V0VmFsdWUiLCJ3aGF0c2FwcEVuYWJsZWQiLCJzZXRXaGF0c2FwcEVuYWJsZWQiLCJHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwiZGlzYnVyc2VtZW50VHlwZSIsInNldERpc2J1cnNlbWVudFR5cGUiLCJkaXNidXJzZW1lbnRUeXBlcyIsImtleSIsInRpdGxlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwibm9SZWxvYWQiLCJ0eXBlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXJfaWQiLCJwYXlfZGF0ZSIsImFtb3VudCIsInBheV90eXBlIiwidHJhbnNhY3Rpb25faWQiLCJjaGVxdWVfbnVtYmVyIiwiY2hlcXVlX2RhdGUiLCJjaGVxdWVfYmFua19uYW1lIiwiY2hlcXVlX2JhbmtfYnJhbmNoIiwicGF5bWVudF9ncm91cF90aWNrZXRzIiwiZGlzYnVyc2VtZW50X3R5cGUiLCJub3RlIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsIm1vZGlmeVBheW1lbnQiLCJzZXRNb2RpZnlQYXltZW50IiwicmVjaXBpZW50VHlwZSIsInNldFJlY2lwaWVudFR5cGUiLCJndWVzdE5hbWUiLCJzZXRHdWVzdE5hbWUiLCJndWVzdE1vYmlsZSIsInNldEd1ZXN0TW9iaWxlIiwiZ3Vlc3REYXRhIiwic2V0R3Vlc3REYXRhIiwiZ3Vlc3RfbmFtZSIsIm1vYmlsZV9udW1iZXIiLCJ1c2VyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInVzZXJPYmoiLCJKU09OIiwicGFyc2UiLCJuYW1lIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiaXNNb2RpZnkiLCJ1c3IiLCJhZG1pbl90eXBlIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hUb2RheXNQYXltZW50cyIsInJlc3BvbnNlIiwiZ2V0IiwicGFyYW1zIiwicGF5X2ZvciIsImRhdGEiLCJsZW5ndGgiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiZ3JvdXAiLCJpbmRleCIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsIl9pZCIsImlkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwidGlja2V0IiwicmVjZWlwdCIsInJlY2VpcHRfbm8iLCJvbGRfcmVjZWlwdCIsIm9sZF9yZWNlaXB0X25vIiwiZGF0ZSIsImZvcm1hdFBheURhdGUiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiY3JlYXRlZEF0IiwiZGlzYnVyc2VkX2J5IiwiYWRtaW5fbmFtZSIsImZldGNoTGFzdFRocmVlVHJhbnNhY3Rpb25zIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxpbWl0IiwiZmV0Y2hHcm91cHMiLCJ2YWxpZGF0ZUZvcm0iLCJsb2ciLCJuZXdFcnJvcnMiLCJjdXN0b21lciIsInRyaW0iLCJ0ZXN0IiwicGFyc2VGbG9hdCIsImlzTmFOIiwiT2JqZWN0Iiwia2V5cyIsImhhbmRsZUNoYW5nZSIsInByZXZEYXRhIiwiaGFuZGxlUGF5bWVudEFudFNlbGVjdCIsInZhbHVlcyIsImhhbmRsZUdyb3VwQ2hhbmdlIiwiZ3JvdXBJZCIsImNvbHVtbnMiLCJoZWFkZXIiLCJwdXNoIiwiaGFuZGxlQ3VzdG9tZXIiLCJwcmV2Rm9ybURhdGEiLCJwcmV2IiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiaGFuZGxlR3JvdXBQYXltZW50IiwiZmV0Y2hQYXltZW50TGlzdCIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJkYXRlU3RyaW5nIiwiaGFuZGxlR3JvdXBQYXltZW50Q2hhbmdlIiwidXJsIiwicGF5bWVudCIsImN1c3RvbWVyX25hbWUiLCJjdXN0b21lcl9waG9uZSIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwic2VsZWN0ZWRNb2RlIiwiZmlsdGVycyIsImhhbmRsZVN1Ym1pdCIsImlzVmFsaWQiLCJwYXlsb2FkIiwidW5kZWZpbmVkIiwiY3VzdG9tZXJfdHlwZSIsInBhcnRzIiwicmVwbGFjZSIsImd1ZXN0X3Bob25lIiwicG9zdCIsInN0YXR1cyIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZUF1Y3Rpb24iLCJkZWxldGUiLCJoYW5kbGVWaWV3TW9kYWxPcGVuIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlVXBkYXRlIiwicHV0IiwiaGFuZGxlRGlzYnVyc2VtZW50VHlwZUNoYW5nZSIsInZhbGlkQXVjdGlvbnMiLCJmaWx0ZXIiLCJhdWN0aW9uIiwiZW5yb2xsbWVudCIsInRvVXBwZXJDYXNlIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsIml0ZW0iLCJzb21lIiwiU3RyaW5nIiwiaGVpZ2h0IiwiZW50cnkiLCJncm91cE5hbWUiLCJ0aWNrZXRzIiwiTnVtYmVyIiwiZFR5cGUiLCJjaGVja2VkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5T3V0T3RoZXJzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhUGhvbmVBbHQsIEZhVXNlciwgRmFXaGF0c2FwcFNxdWFyZSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgTW9kYWwgYXMgQW50TW9kYWwsIERyYXdlciwgVG9vbHRpcCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBCYWNrZHJvcEJsdXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9CYWNrZHJvcEJsdXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgRmFSZWNlaXB0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmNvbnN0IFBheU91dE90aGVycyA9ICgpID0+IHtcclxuICBjb25zdCB7IHBheW1lbnRUeXBlIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY3R1YWxHcm91cHMsIHNldEFjdHVhbEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW1RhYmxlUGF5bWVudHMsIHNldFRhYmxlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlck5hbWUsIHNldFVzZXJOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt2aWV3TG9hZGVyLCBzZXRWaWV3TG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZmlsdGVyZWRBdWN0aW9uLCBzZXRGaWx0ZXJlZEF1Y3Rpb25dID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEluZm8sIHNldEdyb3VwSW5mb10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlQW1vdW50LCBzZXRDdXJyZW50VXBkYXRlQW1vdW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFZpZXcsIHNldFNob3dNb2RhbFZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Vmlld0dyb3VwLCBzZXRDdXJyZW50Vmlld0dyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93VXBsb2FkTW9kYWwsIHNldFNob3dVcGxvYWRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlY2VpcHRObywgc2V0UmVjZWlwdE5vXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IHdoYXRzYXBwRW5hYmxlID0gdHJ1ZTtcclxuICBjb25zdCBbcGF5bWVudE1vZGUsIHNldFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlKFwiY2FzaFwiKTtcclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Rpc2FibGVkLCBzZXREaXNhYmxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dVcGRhdGVNb2RhbCwgc2V0U2hvd1VwZGF0ZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZW5hYmxlR3JvdXBDb2x1bW4sIHNldEVuYWJsZUdyb3VwQ29sdW1uXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtwYXltZW50R3JvdXBUaWNrZXRzLCBzZXRQYXltZW50R3JvdXBUaWNrZXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcmVuZGVyLCBzZXRSZXJlbmRlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbb3BlbkJhY2tkcm9wTG9hZGVyLCBzZXRPcGVuQmFja2Ryb3BMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3JvdXBJZCwgc2V0Q3VycmVudEdyb3VwSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW29wZW5BbnRERHJhd2VyLCBzZXRPcGVuQW50RERyYXdlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dMb2FkZXIsIHNldFNob3dMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsYXN0VGhyZWVQYXltZW50cywgc2V0TGFzdFRocmVlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd090aGVyc0ZpZWxkLCBzZXRTaG93T3RoZXJzRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFRpY2tldFZhbHVlLCBzZXRTZWxlY3RlZFRpY2tldFZhbHVlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt3aGF0c2FwcEVuYWJsZWQsIHNldFdoYXRzYXBwRW5hYmxlZF0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2Rpc2J1cnNlbWVudFR5cGUsIHNldERpc2J1cnNlbWVudFR5cGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgZGlzYnVyc2VtZW50VHlwZXMgPSBbXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzFcIixcclxuICAgICAgdGl0bGU6IFwiQ2hpdCBDYW5jZWxsYXRpb25cIixcclxuICAgICAgdmFsdWU6IFwiQ2hpdCBDYW5jZWxsYXRpb25cIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjMlwiLFxyXG4gICAgICB0aXRsZTogXCJSZWZ1bmQgdG8gTWVtYmVyXCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlZnVuZCB0byBNZW1iZXJcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjM1wiLFxyXG4gICAgICB0aXRsZTogXCJGb3JlbWFuIENvbW1pc3Npb24gRGlzYnVyc2VtZW50XCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlZnVuZCB0byBNZW1iZXJcIixcclxuICAgIH0sXHJcblxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzRcIixcclxuICAgICAgdGl0bGU6IFwiUmVpbnZlc3RtZW50IFRyYW5zZmVyXCIsXHJcbiAgICAgIHZhbHVlOiBcIlJlaW52ZXN0bWVudCBUcmFuc2ZlclwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM1XCIsXHJcbiAgICAgIHRpdGxlOiBcIkFkdmFuY2UgUGF5b3V0IEJlZm9yZSBBdWN0aW9uXCIsXHJcbiAgICAgIHZhbHVlOiBcIkFkdmFuY2UgUGF5b3V0IEJlZm9yZSBBdWN0aW9uXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiIzZcIixcclxuICAgICAgdGl0bGU6IFwiRGl2aWRlbnQgU2hhcmUgRGlzYnVyc2VtZW50XCIsXHJcbiAgICAgIHZhbHVlOiBcIkRpdmlkZW50IFNoYXJlIERpc2J1cnNlbWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM3XCIsXHJcbiAgICAgIHRpdGxlOiBcIkdyb3VwIENsb3N1cmUgU2V0dGxlbWVudFwiLFxyXG4gICAgICB2YWx1ZTogXCJHcm91cCBDbG9zdXJlIFNldHRsZW1lbnRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCIjOFwiLFxyXG4gICAgICB0aXRsZTogXCJFbWVyZ2VuY3kgV2l0aGRyYXdhbFwiLFxyXG4gICAgICB2YWx1ZTogXCJFbWVyZ2VuY3kgV2l0aGRyYXdhbFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiM5XCIsXHJcbiAgICAgIHRpdGxlOiBcIk1pc3Rha2VuIFBheW1lbnQgUmV2ZXJzYWxcIixcclxuICAgICAgdmFsdWU6IFwiTWlzdGFrZW4gUGF5bWVudCBSZXZlcnNhbFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcIiMxMFwiLFxyXG4gICAgICB0aXRsZTogXCJPdGhlcnNcIixcclxuICAgICAgdmFsdWU6IFwiT3RoZXJzXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICBub1JlbG9hZDogZmFsc2UsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcblxyXG4gICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBjaGVxdWVfbnVtYmVyOiBcIlwiLFxyXG4gICAgY2hlcXVlX2RhdGU6IFwiXCIsXHJcbiAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgY2hlcXVlX2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgIGRpc2J1cnNlbWVudF90eXBlOiBcIlwiLFxyXG4gICAgbm90ZTogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV9kYXRlOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVjaXBpZW50VHlwZSwgc2V0UmVjaXBpZW50VHlwZV0gPSB1c2VTdGF0ZSgnY3VzdG9tZXInKTtcclxuICBjb25zdCBbZ3Vlc3ROYW1lLCBzZXRHdWVzdE5hbWVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtndWVzdE1vYmlsZSwgc2V0R3Vlc3RNb2JpbGVdID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICBjb25zdCBbZ3Vlc3REYXRhLCBzZXRHdWVzdERhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3Vlc3RfbmFtZTogXCJcIixcclxuICAgIG1vYmlsZV9udW1iZXI6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBzZXRBZG1pbk5hbWUodXNlck9iaj8ubmFtZSB8fCBcIlwiKTtcclxuXHJcbiAgICBpZiAoXHJcbiAgICAgIHVzZXJPYmogJiZcclxuICAgICAgdXNlck9iaj8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudFxyXG4gICAgKSB7XHJcbiAgICAgIGNvbnN0IGlzTW9kaWZ5ID1cclxuICAgICAgICB1c2VyT2JqPy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PVxyXG4gICAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0TW9kaWZ5UGF5bWVudChpc01vZGlmeSk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IGFkbWluX3R5cGUgPSBudWxsO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmICh1c3IpIHtcclxuICAgICAgICBhZG1pbl90eXBlID0gSlNPTi5wYXJzZSh1c3IpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gcGFyc2UgdXNlciBmcm9tIGxvY2FsU3RvcmFnZTpcIiwgZSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZmV0Y2hUb2RheXNQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgXCIvcGF5bWVudC1vdXQvZ2V0LXBheW1lbnQtb3V0LXJlcG9ydC1kYXlib29rXCIsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIHBheV9kYXRlOiB0b2RheSxcclxuICAgICAgICAgICAgICBwYXlfZm9yOiBwYXltZW50VHlwZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUpIHJldHVybiB7fTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IGdyb3VwLl9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgIGdyb3VwX25hbWU6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgICB0aWNrZXQ6IGdyb3VwLnRpY2tldCxcclxuICAgICAgICAgICAgICByZWNlaXB0OiBncm91cC5yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIG9sZF9yZWNlaXB0OiBncm91cC5vbGRfcmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgICBhbW91bnQ6IGdyb3VwLmFtb3VudCxcclxuICAgICAgICAgICAgICBkYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLnBheV9kYXRlKSxcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLmNyZWF0ZWRBdCksXHJcbiAgICAgICAgICAgICAgZGlzYnVyc2VkX2J5OiBncm91cD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fCBcIlN1cGVyIEFkbWluXCIsXHJcbiAgICAgICAgICAgICAgZGlzYnVyc2VtZW50X3R5cGU6IGdyb3VwLmRpc2J1cnNlbWVudF90eXBlLFxyXG4gICAgICAgICAgICAgIG5vdGU6IGdyb3VwLm5vdGUsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldFRhYmxlUGF5bWVudHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgICBzZXRFbmFibGVHcm91cENvbHVtbih0cnVlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFRvZGF5c1BheW1lbnRzKCk7XHJcbiAgfSwgW3JlbmRlcl0pO1xyXG5cclxuICBjb25zdCBmZXRjaExhc3RUaHJlZVRyYW5zYWN0aW9ucyA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldE9wZW5BbnRERHJhd2VyKHRydWUpO1xyXG4gICAgaWYgKGZvcm1EYXRhLnVzZXJfaWQgJiYgZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0U2hvd0xvYWRlcih0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCJwYXltZW50LW91dC9nZXQtbGFzdC1uLXRyYW5zYWN0aW9uXCIsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICB1c2VyX2lkOiBmb3JtRGF0YS51c2VyX2lkLFxyXG4gICAgICAgICAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IHBheW1lbnRHcm91cFRpY2tldHMsXHJcbiAgICAgICAgICAgIGxpbWl0OiAzLFxyXG4gICAgICAgICAgICBwYXlfZm9yOiBwYXltZW50VHlwZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhKSB7XHJcbiAgICAgICAgICBzZXRMYXN0VGhyZWVQYXltZW50cyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0TGFzdFRocmVlUGF5bWVudHMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRMYXN0VGhyZWVQYXltZW50cyhbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0U2hvd0xvYWRlcihmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbYWxlcnRDb25maWddKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0QWN0dWFsR3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFthbGVydENvbmZpZ10pO1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcIlZhbGlkYXRpbmcuLi5cIiwgeyByZWNpcGllbnRUeXBlLCBndWVzdE5hbWUsIGd1ZXN0TW9iaWxlLCBmb3JtRGF0YSB9KTtcclxuXHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuXHJcbiAgICBpZiAocmVjaXBpZW50VHlwZSA9PT0gXCJjdXN0b21lclwiKSB7XHJcbiAgICAgIGlmICghc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmN1c3RvbWVyID0gXCJQbGVhc2Ugc2VsZWN0IGEgY3VzdG9tZXJcIjtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIXNlbGVjdGVkVGlja2V0VmFsdWUpIHtcclxuICAgICAgICBuZXdFcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzID0gXCJQbGVhc2Ugc2VsZWN0IGEgZ3JvdXAgYW5kIHRpY2tldFwiO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBHdWVzdCBtb2RlXHJcbiAgICAgIGlmICghZ3Vlc3ROYW1lLnRyaW0oKSkge1xyXG4gICAgICAgIG5ld0Vycm9ycy5ndWVzdE5hbWUgPSBcIkd1ZXN0IE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIWd1ZXN0TW9iaWxlLnRyaW0oKSkge1xyXG4gICAgICAgIG5ld0Vycm9ycy5ndWVzdE1vYmlsZSA9IFwiTW9iaWxlIG51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgICB9IGVsc2UgaWYgKCEvXlxcZHsxMH0kLy50ZXN0KGd1ZXN0TW9iaWxlLnRyaW0oKSkpIHtcclxuICAgICAgICBuZXdFcnJvcnMuZ3Vlc3RNb2JpbGUgPSBcIkVudGVyIGEgdmFsaWQgMTAtZGlnaXQgbW9iaWxlIG51bWJlclwiO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXlfZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGF5X2RhdGUgPSBcIlBheW1lbnQgZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQoZm9ybURhdGEuYW1vdW50KTtcclxuICAgIGlmIChpc05hTihhbW91bnQpIHx8IGFtb3VudCA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIHBvc2l0aXZlIGFtb3VudFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiAmJiAhZm9ybURhdGEudHJhbnNhY3Rpb25faWQ/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkIGZvciBvbmxpbmUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAhZm9ybURhdGEuY2hlcXVlX2RhdGU/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuY2hlcXVlX2RhdGUgPSBcIkNoZXF1ZSBEYXRlIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAhZm9ybURhdGEuY2hlcXVlX251bWJlcj8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5jaGVxdWVfbnVtYmVyID0gXCJDaGVxdWUgTnVtYmVyIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAocmVjaXBpZW50VHlwZSA9PT0gXCJjdXN0b21lclwiICYmICFmb3JtRGF0YS5kaXNidXJzZW1lbnRfdHlwZSkge1xyXG4gICAgICBuZXdFcnJvcnMuZGlzYnVyc2VtZW50X3R5cGUgPSBcIkRpc2J1cnNlbWVudCBUeXBlIGlzIFJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBpZiAobmFtZSA9PT0gXCJkaXNidXJzZW1lbnRfdHlwZVwiKSB7XHJcbiAgICAgIGlmICh2YWx1ZSA9PT0gXCJPdGhlcnNcIikge1xyXG4gICAgICAgIHNldFNob3dPdGhlcnNGaWVsZCh0cnVlKTtcclxuICAgICAgICBzZXREaXNidXJzZW1lbnRUeXBlKFwiXCIpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0U2hvd090aGVyc0ZpZWxkKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRBbnRTZWxlY3QgPSAodmFsdWVzKSA9PiB7XHJcbiAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKHZhbHVlcyk7XHJcbiAgICBzZXRTZWxlY3RlZFRpY2tldFZhbHVlKHZhbHVlcyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBDaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cChncm91cElkKTtcclxuXHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC9nZXQtZ3JvdXAtZW5yb2xsLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gIF07XHJcbiAgaWYgKGVuYWJsZUdyb3VwQ29sdW1uKSB7XHJcbiAgICBjb2x1bW5zLnB1c2goeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0pO1xyXG4gIH1cclxuICBjb2x1bW5zLnB1c2goXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwib2xkX3JlY2VpcHRcIiwgaGVhZGVyOiBcIk9sZCBSZWNlaXB0XCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRcIiwgaGVhZGVyOiBcIlJlY2VpcHRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGlzYnVyc2VkX2J5XCIsIGhlYWRlcjogXCJEaXNidXJzZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGlzYnVyc2VtZW50X3R5cGVcIiwgaGVhZGVyOiBcIkRpc2J1cnNlbWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcIm5vdGVcIiwgaGVhZGVyOiBcIk5vdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9XHJcbiAgKTtcclxuICAvLyBjb25zdCBoYW5kbGVHcm91cCA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gIC8vICAgY29uc3QgZ3JvdXBJZCA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuICAvLyAgIHNldFNlbGVjdGVkR3JvdXBJZChncm91cElkKTtcclxuICAvLyAgIHNldEZvcm1EYXRhKChwcmV2Rm9ybURhdGEpID0+ICh7XHJcbiAgLy8gICAgIC4uLnByZXZGb3JtRGF0YSxcclxuICAvLyAgICAgdXNlcl9pZDogZ3JvdXBJZCxcclxuICAvLyAgIH0pKTtcclxuICAvLyAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBjdXN0b21lcjogXCJcIiB9KSk7XHJcblxyXG4gIC8vICAgaGFuZGxlR3JvdXBDaGFuZ2UoZ3JvdXBJZCk7XHJcbiAgLy8gICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UoZ3JvdXBJZCk7XHJcblxyXG4gIC8vICAgaWYgKGdyb3VwSWQpIHtcclxuICAvLyAgICAgdHJ5IHtcclxuICAvLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtncm91cElkfWApO1xyXG4gIC8vICAgICAgIHNldEdyb3VwSW5mbyhyZXNwb25zZS5kYXRhIHx8IHt9KTtcclxuICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9IGVsc2Uge1xyXG4gIC8vICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gIC8vICAgfVxyXG4gIC8vIH07XHJcblxyXG4gIC8vIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAvLyAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gIC8vICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gIC8vICAgICAuLi5wcmV2RGF0YSxcclxuICAvLyAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAvLyAgIH0pKTtcclxuICAvLyB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lciA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgICAgIHVzZXJfaWQ6IGdyb3VwSWQsXHJcbiAgICB9KSk7XHJcbiAgICAvLyBDbGVhciB0aWNrZXQgc2VsZWN0aW9uXHJcbiAgICBzZXRTZWxlY3RlZFRpY2tldFZhbHVlKG51bGwpO1xyXG4gICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICAvLyBDbGVhciBlcnJvcnNcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgY3VzdG9tZXI6IFwiXCIsIHBheW1lbnRfZ3JvdXBfdGlja2V0czogXCJcIiB9KSk7XHJcblxyXG4gICAgaGFuZGxlR3JvdXBDaGFuZ2UoZ3JvdXBJZCk7XHJcbiAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UoZ3JvdXBJZCk7XHJcblxyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtncm91cElkfWApO1xyXG4gICAgICAgIHNldEdyb3VwSW5mbyhyZXNwb25zZS5kYXRhIHx8IHt9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50ID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBpZiAoZ3JvdXBJZCA9PT0gXCJ0b2RheVwiKSB7XHJcbiAgICAgIGZldGNoUGF5bWVudExpc3QoeyBmcm9tX2RhdGU6IHRvZGF5LCB0b19kYXRlOiB0b2RheSB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGZldGNoUGF5bWVudExpc3QoeyBncm91cF9pZDogZ3JvdXBJZCB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmb3JtYXRQYXlEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIHJldHVybiBkYXRlU3RyaW5nPy5zcGxpdChcIlRcIilbMF07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50Q2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwKGdyb3VwSWQpO1xyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgbGV0IHVybDtcclxuICAgICAgaWYgKGdyb3VwSWQgPT09IFwidG9kYXlcIikge1xyXG4gICAgICAgIHVybCA9IGAvcGF5bWVudC1vdXQvZ2V0LXBheW1lbnQtb3V0LXJlcG9ydC1kYXlib29rLz9wYXlfZGF0ZT0ke3RvZGF5fSZwYXlfZm9yPSR7cGF5bWVudFR5cGV9YDtcclxuICAgICAgICBzZXRFbmFibGVHcm91cENvbHVtbih0cnVlKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB1cmwgPSBgL3BheW1lbnQtb3V0L2dldC1ncm91cC1wYXltZW50LW91dC8/Z3JvdXBfaWQ9JHtncm91cElkfSZwYXlfZm9yPSR7cGF5bWVudFR5cGV9YDtcclxuICAgICAgICBzZXRFbmFibGVHcm91cENvbHVtbihmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChwYXltZW50LCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgbmFtZTogcGF5bWVudC5jdXN0b21lcl9uYW1lIHx8IHBheW1lbnQudXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IHBheW1lbnQuY3VzdG9tZXJfcGhvbmUgfHwgcGF5bWVudC51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgIGdyb3VwX25hbWU6IHBheW1lbnQuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgIHRpY2tldDogcGF5bWVudC50aWNrZXQsXHJcbiAgICAgICAgICAgIHJlY2VpcHQ6IHBheW1lbnQucmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IHBheW1lbnQub2xkX3JlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgIGFtb3VudDogcGF5bWVudC5hbW91bnQsXHJcbiAgICAgICAgICAgIGRhdGU6IHBheW1lbnQucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogcGF5bWVudC5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgZGlzYnVyc2VkX2J5OiBwYXltZW50LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHwgXCJTdXBlciBBZG1pblwiLFxyXG4gICAgICAgICAgICBkaXNidXJzZW1lbnRfdHlwZTogcGF5bWVudC5kaXNidXJzZW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgbm90ZTogcGF5bWVudC5ub3RlLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50TW9kZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vZGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldFBheW1lbnRNb2RlKHNlbGVjdGVkTW9kZSk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBwYXlfdHlwZTogc2VsZWN0ZWRNb2RlLFxyXG5cclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IHNlbGVjdGVkTW9kZSA9PT0gXCJvbmxpbmVcIiA/IHByZXZEYXRhLnRyYW5zYWN0aW9uX2lkIDogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFBheW1lbnRMaXN0ID0gYXN5bmMgKGZpbHRlcnMgPSB7fSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0VGFibGVQYXltZW50cyhbXSk7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL3BheW1lbnRzLW91dC9vdGhlcnNcIiwgeyBwYXJhbXM6IGZpbHRlcnMgfSk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5kYXRhKSB7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBuYW1lOiBwYXltZW50LmN1c3RvbWVyX25hbWUgfHwgcGF5bWVudC51c2VyX2lkPy5mdWxsX25hbWUgfHwgJycsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IHBheW1lbnQuY3VzdG9tZXJfcGhvbmUgfHwgcGF5bWVudC51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgJycsXHJcbiAgICAgICAgICBncm91cF9uYW1lOiBwYXltZW50Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8ICcnLFxyXG4gICAgICAgICAgdGlja2V0OiBwYXltZW50LnRpY2tldCB8fCAnJyxcclxuICAgICAgICAgIHJlY2VpcHQ6IHBheW1lbnQucmVjZWlwdF9ubyB8fCAnJyxcclxuICAgICAgICAgIG9sZF9yZWNlaXB0OiBwYXltZW50Lm9sZF9yZWNlaXB0X25vIHx8ICcnLFxyXG4gICAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCB8fCAnJyxcclxuICAgICAgICAgIGRhdGU6IHBheW1lbnQucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCAnJyxcclxuICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IHBheW1lbnQuY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0gfHwgJycsXHJcbiAgICAgICAgICBkaXNidXJzZWRfYnk6IHBheW1lbnQuYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fCBcIlN1cGVyIEFkbWluXCIsXHJcbiAgICAgICAgICBkaXNidXJzZW1lbnRfdHlwZTogcGF5bWVudC5kaXNidXJzZW1lbnRfdHlwZSB8fCAnJyxcclxuICAgICAgICAgIG5vdGU6IHBheW1lbnQubm90ZSB8fCAnJyxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICBzZXRFbmFibGVHcm91cENvbHVtbih0cnVlKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoUGF5bWVudExpc3QoeyBmcm9tX2RhdGU6IHRvZGF5LCB0b19kYXRlOiB0b2RheSB9KTtcclxuICB9LCBbcmVuZGVyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICBpZiAoIWlzVmFsaWQpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXREaXNhYmxlZCh0cnVlKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKTtcclxuICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuXHJcbiAgICAgIC8vIEdldCBhZG1pbiB1c2VyXHJcbiAgICAgIGNvbnN0IHVzciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgICAgbGV0IGFkbWluX3R5cGUgPSBudWxsO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGlmICh1c3IpIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHBhcnNlIHVzZXI6XCIsIGUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBCdWlsZCBiYXNlIHBheWxvYWRcclxuICAgICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgcGF5X2RhdGU6IGZvcm1EYXRhLnBheV9kYXRlLFxyXG4gICAgICAgIGFtb3VudDogZm9ybURhdGEuYW1vdW50LFxyXG4gICAgICAgIHBheV90eXBlOiBmb3JtRGF0YS5wYXlfdHlwZSxcclxuICAgICAgICB0cmFuc2FjdGlvbl9pZDogZm9ybURhdGEudHJhbnNhY3Rpb25faWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGNoZXF1ZV9udW1iZXI6IGZvcm1EYXRhLmNoZXF1ZV9udW1iZXIgfHwgXCJcIixcclxuICAgICAgICBjaGVxdWVfZGF0ZTogZm9ybURhdGEuY2hlcXVlX2RhdGUgfHwgXCJcIixcclxuICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBmb3JtRGF0YS5jaGVxdWVfYmFua19uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgY2hlcXVlX2JhbmtfYnJhbmNoOiBmb3JtRGF0YS5jaGVxdWVfYmFua19icmFuY2ggfHwgXCJcIixcclxuICAgICAgICBub3RlOiBmb3JtRGF0YS5ub3RlIHx8IFwiXCIsXHJcbiAgICAgICAgYWRtaW5fdHlwZTogYWRtaW5fdHlwZT8uX2lkLFxyXG4gICAgICAgIGRpc2J1cnNlbWVudF90eXBlOlxyXG4gICAgICAgICAgZm9ybURhdGEuZGlzYnVyc2VtZW50X3R5cGUgPT09IFwiT3RoZXJzXCJcclxuICAgICAgICAgICAgPyBkaXNidXJzZW1lbnRUeXBlIHx8IFwiT3RoZXJzXCJcclxuICAgICAgICAgICAgOiBmb3JtRGF0YS5kaXNidXJzZW1lbnRfdHlwZSxcclxuICAgICAgICBjdXN0b21lcl90eXBlOiByZWNpcGllbnRUeXBlLCAvLyBcInJlZ2lzdGVyZWRcIiBvciBcImd1ZXN0XCJcclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIEFkZCByZWNpcGllbnQtc3BlY2lmaWMgZmllbGRzXHJcbiAgICAgIGlmIChyZWNpcGllbnRUeXBlID09PSBcImN1c3RvbWVyXCIpIHtcclxuICAgICAgICBwYXlsb2FkLnVzZXJfaWQgPSBzZWxlY3RlZEdyb3VwSWQ7XHJcblxyXG4gICAgICAgIGlmIChzZWxlY3RlZFRpY2tldFZhbHVlKSB7XHJcbiAgICAgICAgICBjb25zdCBwYXJ0cyA9IHNlbGVjdGVkVGlja2V0VmFsdWUuc3BsaXQoXCJ8XCIpO1xyXG5cclxuICAgICAgICAgIGlmIChwYXJ0cy5sZW5ndGggPT09IDIpIHtcclxuICAgICAgICAgICAgcGF5bG9hZC5ncm91cF9pZCA9IHBhcnRzWzBdLnJlcGxhY2UoXCJjaGl0LVwiLCBcIlwiKTtcclxuICAgICAgICAgICAgcGF5bG9hZC50aWNrZXQgPSBwYXJ0c1sxXTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcGF5bG9hZC5ndWVzdF9uYW1lID0gZ3Vlc3ROYW1lLnRyaW0oKTtcclxuICAgICAgICBwYXlsb2FkLmd1ZXN0X3Bob25lID0gZ3Vlc3RNb2JpbGUudHJpbSgpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcblxyXG4gICAgICAvLyBORVcgRU5EUE9JTlRcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi92MS9hZG1pbi9wYXltZW50cy1vdXQvb3RoZXJzXCIsIHBheWxvYWQpO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAxKSB7XHJcbiAgICAgICAgLy8gUmVzZXQgZm9ybVxyXG4gICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICBzZXRTZWxlY3RlZFRpY2tldFZhbHVlKG51bGwpO1xyXG4gICAgICAgIHNldEd1ZXN0TmFtZShcIlwiKTtcclxuICAgICAgICBzZXRHdWVzdE1vYmlsZShcIlwiKTtcclxuICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgICBkaXNidXJzZW1lbnRfdHlwZTogXCJcIixcclxuICAgICAgICAgIG5vdGU6IFwiXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJQYXltZW50IE91dCBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGF5bWVudCBBZGRlZCBGYWlsZWRcIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRXJyb3Igc3VibWl0dGluZyBwYXltZW50IGRhdGFcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKGZhbHNlKTtcclxuICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICBzZXRSZXJlbmRlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50L2dldC1wYXltZW50LWJ5LWlkLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQXVjdGlvbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50R3JvdXApIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvcGF5bWVudC9kZWxldGUtcGF5bWVudC8ke2N1cnJlbnRHcm91cC5faWR9YCk7XHJcblxyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlBheW1lbnQgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBhdWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3TW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFZpZXcodHJ1ZSk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgICBzZXRWaWV3TG9hZGVyKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50LW91dC9vdGhlcnMvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50Vmlld0dyb3VwKHJlc3BvbnNlLmRhdGEuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igdmlld2luZyBQYXltZW50OlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0Vmlld0xvYWRlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvZ2V0LXBheW1lbnQtYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlQW1vdW50KHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgYW1vdW50OiByZXNwb25zZT8uZGF0YT8uYW1vdW50LFxyXG4gICAgICAgIHBheV9kYXRlOiByZXNwb25zZT8uZGF0YT8ucGF5X2RhdGUuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd1VwZGF0ZU1vZGFsKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIFBheW1lbnQgQW1vdW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucHV0KFxyXG4gICAgICAgIGAvcGF5bWVudC1vdXQvb3RoZXJzLyR7Y3VycmVudFVwZGF0ZUFtb3VudC5faWR9YCxcclxuICAgICAgICB1cGRhdGVGb3JtRGF0YVxyXG4gICAgICApO1xyXG4gICAgICBzZXRTaG93VXBkYXRlTW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlBheW1lbnQgQW1vdW50IFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRSZXJlbmRlcihwcmV2ID0+IHByZXYgKyAxKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBQYXltZW50IEFtb3VudDpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlVwZGF0ZSBmYWlsZWRcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlRGlzYnVyc2VtZW50VHlwZUNoYW5nZSA9IChldmVudCkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZXZlbnQudGFyZ2V0O1xyXG4gICAgc2V0RGlzYnVyc2VtZW50VHlwZSh2YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgICAgYC9lbnJvbGwvZ2V0LXVzZXItdGlja2V0cy1yZXBvcnQvJHtncm91cElkfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3QgdmFsaWRBdWN0aW9ucyA9IHJlc3BvbnNlLmRhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgICAoYXVjdGlvbikgPT4gYXVjdGlvbi5lbnJvbGxtZW50ICYmIGF1Y3Rpb24uZW5yb2xsbWVudC5ncm91cFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbih2YWxpZEF1Y3Rpb25zKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtvcGVuQmFja2Ryb3BMb2FkZXIgPyAoXHJcbiAgICAgICAgPEJhY2tkcm9wQmx1ckxvYWRlciB0aXRsZT17XCJwYXltZW50IERhdGEgcHJvY2Vzc2luZy4uLi5cIn0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgcC03IGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LXJlZC01MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYXltZW50VHlwZT8udG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHtcIiAgXCJ9XHJcbiAgICAgICAgICAgICAgICBQYXltZW50cyBPdXRcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiAgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+U2VhcmNoIG9yIFNlbGVjdCBHcm91cDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVG9kYXkncyBQYXltZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgICAgaC0xNCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlR3JvdXBQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17XCIjMVwifSB2YWx1ZT17XCJ0b2RheVwifT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1wiVG9kYXkncyBQYXltZW50c1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FjdHVhbEdyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctdmlvbGV0LTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICtBZGQgUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtUYWJsZVBheW1lbnRzICYmIFRhYmxlUGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e1RhYmxlUGF5bWVudHMuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LnZhbHVlcyhpdGVtKS5zb21lKCh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFBheW1lbnRzICR7VGFibGVQYXltZW50cy5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFRhYmxlUGF5bWVudHNbMF0uZGF0ZSArXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIiB0byBcIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICBUYWJsZVBheW1lbnRzW1RhYmxlUGF5bWVudHMubGVuZ3RoIC0gMV0uZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImVtcHR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIH0uY3N2YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhPVwiUGF5bWVudHMgRGF0YVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVQYXltZW50cy5sZW5ndGggPD0gMCAmJiBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsfVxyXG4gICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkVGlja2V0VmFsdWUobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgIHNldFJlY2lwaWVudFR5cGUoXCJjdXN0b21lclwiKTtcclxuICAgICAgICAgICAgICAgIHNldEd1ZXN0TmFtZShcIlwiKTtcclxuICAgICAgICAgICAgICAgIHNldEd1ZXN0TW9iaWxlKFwiXCIpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdCBcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5BZGQgUGF5bWVudCBPdXQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgICAgICAgICAgIGNsb3NhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzdHJveU9uSGlkZGVuXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9ezxwPkxhc3QgVGhyZWUgVHJhbnNhY3Rpb25zPC9wPn1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJyaWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3Blbj17b3BlbkFudEREcmF3ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17c2hvd0xvYWRlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuQW50RERyYXdlcihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7bGFzdFRocmVlUGF5bWVudHM/Lmxlbmd0aCA8PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtY2VudGVyIHRleHQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gVHJhbnNhY3Rpb24gRm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsYXN0VGhyZWVQYXltZW50cy5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHNoYWRvdy1tZCByb3VuZGVkLWxnIHAtNCBzcGFjZS15LTIgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZTp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e3BheW1lbnQ/LnBheV9kYXRlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC5ncm91cF9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC5ncm91cF9pZD8uZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQudGlja2V0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0OntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsXCI+e3BheW1lbnQ/LnRpY2tldH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5T3V0IEFtb3VudDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+4oK5e3BheW1lbnQ/LmFtb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgVHlwZTp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ub3JtYWxcIj57cGF5bWVudD8ucGF5X3R5cGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOYW1lOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQudXNlcl9pZD8uZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L0RyYXdlcj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBORVc6IFNFQ1RJT04gVE9HR0xFICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcC0xIGJnLWdyYXktMTAwIHJvdW5kZWQtbGcgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRSZWNpcGllbnRUeXBlKFwiY3VzdG9tZXJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEd1ZXN0TmFtZShcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0R3Vlc3RNb2JpbGUoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJlc2V0IGVycm9ycyBmb3IgZ3Vlc3QgZmllbGRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgZ3Vlc3ROYW1lOiBcIlwiLCBndWVzdE1vYmlsZTogXCJcIiB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLW1kIHRyYW5zaXRpb24tYWxsICR7cmVjaXBpZW50VHlwZSA9PT0gXCJjdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSB0ZXh0LXZpb2xldC03MDAgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlY2lwaWVudFR5cGUoXCJndWVzdFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd090aGVyc0ZpZWxkKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7IC8vIENsZWFyIGN1c3RvbWVyIHNwZWNpZmljIGRhdGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJlc2V0IGVycm9ycyBmb3IgY3VzdG9tZXIgZmllbGRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC1tZCB0cmFuc2l0aW9uLWFsbCAke3JlY2lwaWVudFR5cGUgPT09IFwiZ3Vlc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgdGV4dC12aW9sZXQtNzAwIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHdWVzdFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBDVVNUT01FUiBTRUNUSU9OICovfVxyXG4gICAgICAgICAgICAgICAgICB7cmVjaXBpZW50VHlwZSA9PT0gXCJjdXN0b21lclwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsICR7ZmllbGRTaXplLmhlaWdodH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtncm91cC5mdWxsX25hbWV9IHwgJHtncm91cC5waG9uZV9udW1iZXJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5jdXN0b21lcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cCAmIFRpY2tldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXAgfCBUaWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50QW50U2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRpY2tldFZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgaC0xNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkQXVjdGlvbi5tYXAoKGVudHJ5LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBOYW1lID0gZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9uYW1lIHx8IFwiVW5uYW1lZCBHcm91cFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGVudHJ5Py5lbnJvbGxtZW50Py5ncm91cD8uX2lkIHx8IGBtaXNzaW5nLSR7aW5kZXh9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpY2tldCA9IGVudHJ5Py5lbnJvbGxtZW50Py50aWNrZXRzIHx8IFwiVW5rbm93blwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qga2V5ID0gYGNoaXQtJHtncm91cElkfXwke3RpY2tldH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtrZXl9IHZhbHVlPXtrZXl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cE5hbWV9IHwge3RpY2tldH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHN9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogR1VFU1QgU0VDVElPTiAqL31cclxuICAgICAgICAgICAgICAgICAge3JlY2lwaWVudFR5cGUgPT09IFwiZ3Vlc3RcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImd1ZXN0X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgR3Vlc3QgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBmbGV4IGl0ZW1zLWNlbnRlciBwbC0zIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVVzZXIgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImd1ZXN0X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2d1ZXN0TmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRHdWVzdE5hbWUoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3JzLmd1ZXN0TmFtZSkgc2V0RXJyb3JzKHsgLi4uZXJyb3JzLCBndWVzdE5hbWU6IFwiXCIgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBibG9jayB3LWZ1bGwgcGwtMTAgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHdWVzdCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWVzdE5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmd1ZXN0TmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImd1ZXN0X21vYmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBNb2JpbGUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIGZsZXggaXRlbXMtY2VudGVyIHBsLTMgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUGhvbmVBbHQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZ3Vlc3RfbW9iaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtndWVzdE1vYmlsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBbGxvdyBvbmx5IG51bWJlcnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBlLnRhcmdldC52YWx1ZS5yZXBsYWNlKC9bXjAtOV0vZywgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEd1ZXN0TW9iaWxlKHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9ycy5ndWVzdE1vYmlsZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoeyAuLi5lcnJvcnMsIGd1ZXN0TW9iaWxlOiBcIlwiIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgYmxvY2sgdy1mdWxsIHBsLTEwIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTW9iaWxlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3Vlc3RNb2JpbGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmd1ZXN0TW9iaWxlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFtb2RpZnlQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXlfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgaC0xNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5wYXlfZGF0ZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9ubHkgc2hvdyBoaXN0b3J5IGJ1dHRvbiBmb3IgY3VzdG9tZXJzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVjaXBpZW50VHlwZSA9PT0gXCJjdXN0b21lclwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIkxhc3QgMyBUcmFuc2FjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbWQgcC0yIGJvcmRlci0yIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZmV0Y2hMYXN0VGhyZWVUcmFuc2FjdGlvbnMoZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJlY2VpcHQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuYW1vdW50fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudE1vZGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5DaGVxdWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge21vZGlmeVBheW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic3VzcGVuc2VcIj5TdXNwZW5zZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNyZWRpdFwiPkNyZWRpdDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFkanVzdG1lbnRcIj5BZGp1c3RtZW50PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3RoZXJzXCI+T3RoZXJzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBUaWNrZXQgc3BsaXQgY2FsY3VsYXRpb24gb25seSBmb3IgY3VzdG9tZXJzIHdpdGggdGlja2V0cyAqL31cclxuICAgICAgICAgICAgICAgICAge3JlY2lwaWVudFR5cGUgPT09IFwiY3VzdG9tZXJcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmFtb3VudCAmJlxyXG4gICAgICAgICAgICAgICAgICAgIHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoID4gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEluZGl2aWR1YWwgVGlja2V0IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBob3ZlcjpjdXJzb3Itbm90LWFsbG93ZWQgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInRvdGFsQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17TnVtYmVyKGZvcm1EYXRhLmFtb3VudCkgLyBwYXltZW50R3JvdXBUaWNrZXRzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge3BheW1lbnRNb2RlID09PSBcIm9ubGluZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRyYW5zYWN0aW9uIElEXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudHJhbnNhY3Rpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge3BheW1lbnRNb2RlID09PSBcImNoZXF1ZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTNcIj5DaGVxdWUgRGV0YWlsczwvaDU+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2hlcXVlIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDaGVxdWUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzFlM2E4YV0gZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IGJnLWdyYXktNTAgZm9jdXM6Ymctd2hpdGUgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmNoZXF1ZV9udW1iZXJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2hlcXVlIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY2hlcXVlX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5jaGVxdWVfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQ2hlcXVlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNoZXF1ZV9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmNoZXF1ZV9kYXRlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNoZXF1ZV9iYW5rX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCYW5rIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMWUzYThhXSBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS01MCBmb2N1czpiZy13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCYW5rIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMxZTNhOGFdIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCBiZy1ncmF5LTUwIGZvY3VzOmJnLXdoaXRlIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7cmVjaXBpZW50VHlwZSA9PT0gXCJjdXN0b21lclwiICYmXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIERpc2J1cnNlbWVudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGlzYnVyc2VtZW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRpc2J1cnNlbWVudF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgYW55PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkaXNidXJzZW1lbnRUeXBlcy5tYXAoKGRUeXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2RUeXBlLmtleX0gdmFsdWU9e2RUeXBlLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkVHlwZS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGlzYnVyc2VtZW50X3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5kaXNidXJzZW1lbnRfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB7c2hvd090aGVyc0ZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJvdGhlcnNGaWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBPdGhlcnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJvdGhlcnNGaWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRpc2J1cnNlbWVudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGlzYnVyc2VtZW50VHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNwZWNpZnkgaWYgeW91ciBvcHRpb24gaXMgbm90IGxpc3RlZCBhYm92ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZURpc2J1cnNlbWVudFR5cGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGlzYnVyc2VtZW50X3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5kaXNidXJzZW1lbnRfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwibm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTm90ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb3RlIGlmIGFueT9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy12aW9sZXQtNTAgcC0zIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBEaXNidXJzZWQgQnlcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57YWRtaW5OYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB3LWZ1bGxcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIExlZnQgc2lkZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17d2hhdHNhcHBFbmFibGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFdoYXRzYXBwRW5hYmxlZChlLnRhcmdldC5jaGVja2VkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBhY2NlbnQtZ3JlZW4tNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNlbmQgdmlhIFdoYXRzQXBwXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBSaWdodCBzaWRlICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1ncmVlbi02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwU3F1YXJlIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPldoYXRzQXBwPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgcHQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJTYXZpbmcgUGF5bWVudCBPdXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTYXZlIFBheW1lbnQgT3V0XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGF5T3V0T3RoZXJzO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGF5T3V0T3RoZXJzLmpzeCJ9