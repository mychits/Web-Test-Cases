import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Reports.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { NavLink, Outlet, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import {
  MdOutlineBlock,
  MdOutlinePendingActions,
  MdGavel,
  MdOutlineEmojiPeople,
  MdCalendarMonth,
  MdGroups,
  MdOutlineReceiptLong,
  MdMan
} from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { TbUserPause, TbCoins } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { BiHistory } from "/node_modules/.vite/deps/react-icons_bi.js?v=819e0a34";
import { HiOutlineBanknotes } from "/node_modules/.vite/deps/react-icons_hi2.js?v=819e0a34";
import {
  BsArrowLeftShort,
  BsChevronDown,
  BsChevronRight
} from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import { TbDeviceMobileSearch } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { TiCancel } from "/node_modules/.vite/deps/react-icons_ti.js?v=819e0a34";
import { FaCalendarDays, FaPeopleGroup, FaPeopleArrows } from "/node_modules/.vite/deps/react-icons_fa6.js?v=819e0a34";
import { TbUserCancel } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { Modal, Button, message, Switch, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { FaPersonWalkingArrowLoopLeft } from "/node_modules/.vite/deps/react-icons_fa6.js?v=819e0a34";
import { RiGroupLine, RiAuctionFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import { FiChevronLeft, FiSettings } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { MdOutlinePayments } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { LiaCalculatorSolid } from "/node_modules/.vite/deps/react-icons_lia.js?v=819e0a34";
import { GiPayMoney, GiReceiveMoney, GiMoneyStack } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import { TbReportSearch } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { MdOutlinePayment } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { SlCalender } from "/node_modules/.vite/deps/react-icons_sl.js?v=819e0a34";
import { RiReceiptLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import __vite__cjsImport26_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useRef = __vite__cjsImport26_react["useRef"]; const useState = __vite__cjsImport26_react["useState"]; const useEffect = __vite__cjsImport26_react["useEffect"];
import { BiGrid } from "/node_modules/.vite/deps/react-icons_bi.js?v=819e0a34";
import { TbList } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { BsCalendarDate } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import { TbGraph } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { TbGraphFilled } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { IoSearchOutline } from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import { IoCloseCircle } from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import { MdCancel } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { BsCalculator } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import { LiaPeopleCarrySolid } from "/node_modules/.vite/deps/react-icons_lia.js?v=819e0a34";
import { MdPersonOff } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import {
  FaUsers,
  FaUserFriends,
  FaUserTie,
  FaUserCheck,
  FaAward,
  FaPiggyBank,
  FaMoneyBillWave,
  FaMoneyCheckAlt,
  FaChartLine,
  FaWallet,
  FaBookOpen,
  FaMapMarkedAlt,
  FaClipboardList,
  FaHandHoldingUsd,
  FaCheckCircle,
  FaMobileAlt,
  FaCalendarCheck,
  FaRoute,
  FaTrophy,
  FaChartBar
} from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { PiMoneyDuotone } from "/node_modules/.vite/deps/react-icons_pi.js?v=819e0a34";
import { TfiGift } from "/node_modules/.vite/deps/react-icons_tfi.js?v=819e0a34";
import { FiAward } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { GiThorHammer } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import { CiBank } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import { IoCashOutline } from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
const subMenus = [
  {
    id: "5",
    title: "All Customer Report",
    link: "/reports/all-user-report",
    Icon: FaUsers,
    category: "Customer",
    color: "from-sky-500 to-cyan-600"
  },
  {
    id: "3",
    title: "Group Report",
    link: "/reports/group-report",
    Icon: RiGroupLine,
    category: "Group",
    color: "from-violet-500 to-purple-600"
  },
  {
    id: "4",
    title: "Enrollment Report",
    link: "/reports/enrollment-report",
    Icon: FaClipboardList,
    category: "Customer",
    color: "from-cyan-500 to-sky-600"
  },
  {
    id: "6",
    title: "Customer Report",
    link: "/reports/customer-report",
    Icon: FaUserFriends,
    category: "Customer",
    color: "from-indigo-500 to-blue-600"
  },
  {
    id: "7",
    title: "In Active Customer Report",
    link: "/reports/inactive-user-report",
    Icon: TbUserPause,
    category: "Customer",
    color: "from-slate-500 to-gray-600"
  },
  {
    id: "47",
    title: "Suspended Customer Report",
    link: "/reports/suspend-report",
    category: "Customer",
    Icon: MdOutlineBlock,
    color: "from-amber-500 to-orange-500",
    isNew: true
  },
  {
    id: "1",
    title: "Daybook",
    link: "/reports/daybook",
    Icon: FaBookOpen,
    category: "Payments",
    color: "from-blue-500 to-indigo-600"
  },
  {
    id: "2",
    title: "Receipt Report",
    link: "/reports/receipt-report",
    Icon: MdOutlineReceiptLong,
    category: "Payments",
    color: "from-emerald-500 to-green-600",
    isNew: false
  },
  {
    id: "8",
    title: "Loan Summary Report",
    link: "/reports/customer-loan-report",
    Icon: FaHandHoldingUsd,
    category: "Loan",
    color: "from-green-500 to-teal-600"
  },
  {
    id: "9",
    title: "OutStanding Loan Report",
    link: "/reports/loan-due-report",
    category: "Loan",
    Icon: MdOutlinePendingActions,
    color: "from-orange-500 to-amber-600",
    isNew: false
  },
  {
    id: "10",
    title: "Loan Payout Report",
    link: "/reports/loan-payout-report",
    category: "Loan",
    Icon: GiPayMoney,
    color: "from-lime-500 to-green-600",
    isNew: false
  },
  {
    id: "11",
    title: "Transaction History",
    link: "/reports/transaction-history",
    category: "Customer",
    Icon: BiHistory,
    color: "from-indigo-500 to-violet-600",
    isNew: false
  },
  {
    id: "19861",
    title: "Customer Area Report",
    link: "/reports/customer-area-report",
    category: "Customer",
    Icon: FaMapMarkedAlt,
    color: "from-teal-500 to-emerald-600",
    isNew: true
  },
  {
    id: "12",
    title: "Loan Completion Report",
    link: "/reports/loan-completion-report",
    category: "Loan",
    Icon: FaCheckCircle,
    color: "from-teal-500 to-cyan-600",
    isNew: false
  },
  {
    id: "13",
    title: "Pigmy Summary Report",
    link: "/reports/pigmy-summary-report",
    Icon: FaPiggyBank,
    category: "Pigmy",
    color: "from-pink-500 to-fuchsia-600"
  },
  {
    id: "14",
    title: "Holded Customers",
    link: "/reports/holded-customer-report",
    Icon: MdOutlineBlock,
    category: "Customer",
    color: "from-slate-600 to-gray-700"
  },
  {
    id: "15",
    title: "Collection Executive Report",
    link: "/reports/collection-executive",
    Icon: FaUserTie,
    category: "Collection",
    color: "from-cyan-500 to-blue-600"
  },
  {
    id: "16",
    title: "Collection Executive Summary Report",
    link: "/reports/collection-executive-summary",
    Icon: FaChartLine,
    category: "Collection",
    color: "from-violet-500 to-indigo-600"
  },
  {
    id: "17",
    title: "Collection Area Report",
    link: "/reports/collection-area-report",
    Icon: FaMapMarkedAlt,
    category: "Collection",
    color: "from-teal-500 to-cyan-600"
  },
  {
    id: "18",
    title: "Employee Report",
    link: "/reports/employee-report",
    Icon: FaUserTie,
    category: "Employee",
    color: "from-indigo-500 to-indigo-600"
  },
  {
    id: "19",
    title: "Registration Receipt",
    link: "/reports/registration-fee-receipt",
    Icon: MdOutlineReceiptLong,
    category: "Payments",
    color: "from-emerald-500 to-teal-600"
  },
  {
    id: "20",
    title: "Outstanding Report",
    link: "/reports/outstanding-report",
    Icon: MdOutlinePendingActions,
    category: "Customer",
    color: "from-orange-500 to-yellow-600"
  },
  {
    id: "21",
    title: "Auction Filter Report",
    link: "/reports/auction-filter-report",
    Icon: RiAuctionFill,
    category: "Auction",
    color: "from-fuchsia-500 to-pink-600"
  },
  {
    id: "22",
    title: "Bid Request Report",
    link: "/reports/bid-request-report",
    Icon: MdGavel,
    category: "Auction",
    color: "from-orange-500 to-yellow-500",
    isNew: false
  },
  {
    id: "23",
    title: "Prized Customer Report",
    link: "/reports/prized-customer-report",
    Icon: FaAward,
    category: "Auction",
    color: "from-yellow-500 to-orange-600"
  },
  {
    id: "24",
    title: "All Lead Report",
    link: "/reports/lead-report",
    Icon: MdMan,
    category: "Lead",
    color: "from-purple-500 to-purple-600"
  },
  {
    id: "25",
    title: "Non Converted Lead Report",
    link: "/reports/non-converted-lead-report",
    category: "Lead",
    Icon: MdPersonOff,
    color: "from-blue-500 to-blue-600"
  },
  {
    id: "26",
    title: "Converted Lead Report",
    link: "/reports/converted-lead-report",
    category: "Lead",
    Icon: LiaPeopleCarrySolid,
    color: "from-blue-500 to-blue-600"
  },
  {
    id: "27",
    title: "Sales Report",
    link: "/reports/sales-report",
    Icon: FaChartLine,
    category: "Sales",
    color: "from-sky-500 to-indigo-600"
  },
  {
    id: "28",
    title: "Payment Summary",
    link: "/reports/payment-summary",
    Icon: FaWallet,
    category: "Payments",
    color: "from-green-500 to-emerald-600",
    isNew: false
  },
  {
    id: "29",
    title: "Monthly Installment Turnover",
    link: "/reports/monthly-install-turnover",
    Icon: SlCalender,
    category: "Employee",
    color: "from-blue-500 to-blue-600"
  },
  {
    id: "30",
    title: "Monthly Attendance Report",
    link: "/reports/employee-monthly-report",
    category: "Employee",
    Icon: FaCalendarCheck,
    color: "from-violet-500 to-fuchsia-500"
  },
  {
    id: "31",
    title: "Commission Report",
    link: "/reports/target-commission",
    category: "Agent",
    Icon: TbCoins,
    color: "from-yellow-500 to-amber-600"
  },
  {
    id: "32",
    title: "Chit Business Incentive New Report",
    link: "/reports/target-incentive-new",
    category: "Incentive",
    Icon: FaTrophy,
    color: "from-amber-500 to-yellow-600",
    isNew: true
  },
  {
    id: "33",
    title: "Unverified Customer Report",
    link: "/reports/unverified-customer-report",
    category: "Customer",
    Icon: MdCancel,
    color: "from-blue-500 to-blue-600"
  },
  // {
  //   id: "34",
  //   title: "Mobile Customer App Activity Report",
  //   link: "/reports/customer-event-logger-report",
  //   category: "Mobile",
  //   Icon: TbDeviceMobileSearch,
  //   color: "from-blue-500 to-blue-600",
  // },
  {
    id: "35",
    title: "Chit Asking Month Report",
    link: "/reports/chit-asking-month-report",
    category: "Auction",
    Icon: MdCalendarMonth,
    color: "from-blue-500 to-blue-600"
  },
  {
    id: "36",
    title: "Chit Cancellation Report",
    link: "/reports/chit-cancellation-report",
    category: "Auction",
    Icon: MdCalendarMonth,
    color: "from-blue-500 to-blue-600"
  },
  {
    id: "52",
    title: "GST and Service Charge Report",
    link: "/reports/gst-service-charge",
    category: "Payments",
    Icon: FaWallet,
    color: "from-emerald-500 to-teal-600",
    isNew: true
  },
  {
    id: "37",
    title: "User Installed Source Report",
    link: "/reports/user-registration-source-summary-report",
    category: "Mobile",
    Icon: FaMobileAlt,
    color: "from-blue-500 to-blue-600"
  },
  {
    id: "40",
    title: "Redemption Points Report",
    link: "/reports/redemtion-points",
    category: "Employee",
    Icon: TfiGift,
    color: "from-blue-500 to-blue-600",
    isNew: false
  },
  {
    id: "41",
    title: "Reward Points Report",
    link: "/reports/date-wise-reward-points",
    category: "Employee",
    Icon: TfiGift,
    color: "from-blue-500 to-blue-600",
    isNew: false
  },
  {
    id: "42",
    title: "Chit Collection Incentive Report",
    link: "/reports/chitcollection-incentive",
    category: "Incentive",
    Icon: MdGroups,
    color: "from-green-500 to-green-600",
    isNew: false
  },
  {
    id: "43",
    title: "Loan Collection Incentive Report",
    link: "/reports/loancollection-incentive",
    category: "Incentive",
    Icon: FaMoneyBillWave,
    color: "from-blue-500 to-blue-600",
    isNew: false
  },
  {
    id: "44",
    title: "Pigmy Collection Incentive Report",
    link: "/reports/pigmycollection-incentive",
    category: "Incentive",
    Icon: FaPiggyBank,
    color: "from-green-500 to-green-600",
    isNew: false
  },
  {
    id: "45",
    title: "Customer App Installation Report",
    link: "/reports/mobile-app-installs",
    category: "Mobile",
    Icon: FaMobileAlt,
    color: "from-green-500 to-green-600",
    isNew: false
  },
  {
    id: "46",
    title: "Pigmy Payout Report",
    link: "/reports/pigmy-payout-report",
    category: "Pigmy",
    Icon: GiReceiveMoney,
    color: "from-purple-500 to-indigo-600",
    isNew: false
  },
  {
    id: "48",
    title: "Payout Report",
    link: "/reports/payout-report",
    category: "Auction",
    Icon: GiPayMoney,
    color: "from-teal-500 to-cyan-600",
    isNew: false
  },
  {
    id: "49",
    title: "Employee Referred Customers Report",
    link: "/reports/employee-customer-referral-report",
    category: "Employee",
    Icon: FaUsers,
    color: "from-sky-500 to-blue-600",
    isNew: true
  },
  {
    id: "50",
    title: "Employee Collection Customer Report",
    link: "/reports/employee-collection-customer-report",
    category: "Collection",
    Icon: FaUserFriends,
    color: "from-cyan-500 to-indigo-600",
    isNew: true
  },
  {
    id: "51",
    title: "Employee Relationship Manager Report",
    link: "/reports/employee-relationship-manager-report",
    category: "Employee",
    Icon: FaUserTie,
    color: "from-violet-500 to-purple-600",
    isNew: true
  },
  {
    id: "53",
    title: "Customer visit tracker Report ",
    link: "/reports/customer-visit-tracker",
    category: "Employee",
    Icon: FaRoute,
    color: "from-cyan-500 to-blue-600",
    isNew: true
  },
  {
    id: "54",
    title: "Customer Payment tracking Report ",
    link: "/reports/customer-payment-tracking-report",
    category: "Customer",
    Icon: FaRoute,
    color: "from-cyan-500 to-blue-600",
    isNew: true
  }
];
const categories = [
  "All",
  "Group",
  "Customer",
  "Agent",
  "Employee",
  "Payments",
  "Lead",
  "Loan",
  "Pigmy",
  "Auction",
  "Sales",
  "Collection",
  "Incentive",
  "Mobile"
];
const categoryColors = {
  Customer: "bg-blue-500",
  Payments: "bg-emerald-500",
  Loan: "bg-purple-500",
  Pigmy: "bg-pink-500",
  Auction: "bg-amber-500",
  Employee: "bg-indigo-500",
  Collection: "bg-green-500",
  Lead: "bg-cyan-500",
  Group: "bg-violet-500",
  Sales: "bg-orange-500",
  Agent: "bg-yellow-500",
  Incentive: "bg-orange-500",
  Mobile: "bg-teal-500",
  Finance: "bg-lime-500",
  Chit: "bg-rose-500"
};
const Reports = () => {
  _s();
  const location = useLocation();
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState("All");
  const [viewType, setViewType] = useState("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [sidebarSearchQuery, setSidebarSearchQuery] = useState("");
  const [modalSearchQuery, setModalSearchQuery] = useState("");
  const [open, setOpen] = useState(true);
  const [hideSidebar, setHideSidebar] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState({});
  const [menus, setMenus] = useState([]);
  const [saving, setSaving] = useState(false);
  const [manageModal, setManageModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [draggedItem, setDraggedItem] = useState(null);
  const [dragOverItem, setDragOverItem] = useState(null);
  const categoryOrder = ["Customer", "Auction", "Payments"];
  const getAllCategories = () => {
    const categories2 = /* @__PURE__ */ new Set();
    menus.forEach((menu) => {
      if (menu.category) {
        categories2.add(menu.category);
      }
    });
    return Array.from(categories2);
  };
  const toggleCategory = (category) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [category]: !prev[category]
    }));
  };
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  useEffect(() => {
    fetchReports();
  }, []);
  const fetchReports = async () => {
    try {
      setIsLoading(true);
      const response = await api.get("/v1/admin/report-visibility");
      const visibility = response.data.data || [];
      const finalMenus = subMenus.map((menu) => {
        const dbMenu = visibility.find((item) => item.reportId === menu.id);
        return {
          ...menu,
          visible: dbMenu ? dbMenu.visible : true,
          category: dbMenu?.category || menu.category || "Uncategorized",
          order: dbMenu?.order || menu.order || 0
        };
      });
      finalMenus.sort((a, b) => (a.order || 0) - (b.order || 0));
      setMenus(finalMenus);
    } catch (err) {
      console.error(err);
      setMenus(
        subMenus.map((menu) => ({
          ...menu,
          visible: true,
          category: menu.category || "Uncategorized",
          order: menu.order || 0
        }))
      );
    } finally {
      setIsLoading(false);
    }
  };
  const handleNavigation = (link) => {
    navigate(link);
    setTimeout(scrollToTop, 100);
  };
  const ref = useRef(null);
  const filteredMenus = menus.filter((menu) => menu.visible).filter(
    (menu) => activeCategory === "All" || menu.category === activeCategory
  ).filter(
    (menu) => menu.title.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const allFilteredGroupedMenus = filteredMenus.reduce((acc, menu) => {
    const category = menu.category || "Uncategorized";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(menu);
    return acc;
  }, {});
  Object.keys(allFilteredGroupedMenus).forEach((category) => {
    allFilteredGroupedMenus[category].sort(
      (a, b) => (a.order || 0) - (b.order || 0)
    );
  });
  const sortedAllFilteredCategories = Object.keys(
    allFilteredGroupedMenus
  ).sort((a, b) => {
    const indexA = categoryOrder.indexOf(a);
    const indexB = categoryOrder.indexOf(b);
    if (indexA !== -1 && indexB !== -1) {
      return indexA - indexB;
    }
    if (indexA !== -1) return -1;
    if (indexB !== -1) return 1;
    return a.localeCompare(b);
  });
  const groupedMenus = menus.filter((menu) => menu.visible).reduce((acc, menu) => {
    const category = menu.category || "Uncategorized";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(menu);
    return acc;
  }, {});
  Object.keys(groupedMenus).forEach((category) => {
    groupedMenus[category].sort((a, b) => (a.order || 0) - (b.order || 0));
  });
  const sortedCategories = Object.keys(groupedMenus).sort((a, b) => {
    const indexA = categoryOrder.indexOf(a);
    const indexB = categoryOrder.indexOf(b);
    if (indexA !== -1 && indexB !== -1) {
      return indexA - indexB;
    }
    if (indexA !== -1) return -1;
    if (indexB !== -1) return 1;
    return a.localeCompare(b);
  });
  const handleClearSearch = () => {
    setSearchQuery("");
  };
  const handleClearModalSearch = () => {
    setModalSearchQuery("");
  };
  const saveReports = async () => {
    try {
      setSaving(true);
      await api.put("/v1/admin/report-visibility", {
        reports: menus.map((menu) => ({
          reportId: menu.id,
          visible: menu.visible,
          category: menu.category,
          order: menu.order || 0
        }))
      });
      message.success("Report settings updated successfully");
      await fetchReports();
      setManageModal(false);
      setModalSearchQuery("");
    } catch (err) {
      console.error(err);
      message.error("Failed to update report settings");
    } finally {
      setSaving(false);
    }
  };
  const handleCategoryChange = (menuId, newCategory) => {
    setMenus((prev) => {
      const menuToMove = prev.find((m) => m.id === menuId);
      const oldCategory = menuToMove?.category;
      const updatedMenus = prev.map((item) => {
        if (item.id === menuId) {
          return { ...item, category: newCategory };
        }
        return item;
      });
      const itemsInNewCategory = updatedMenus.filter((m) => m.category === newCategory).sort((a, b) => (a.order || 0) - (b.order || 0));
      itemsInNewCategory.forEach((item, index) => {
        const foundItem = updatedMenus.find((m) => m.id === item.id);
        if (foundItem) {
          foundItem.order = index;
        }
      });
      if (oldCategory && oldCategory !== newCategory) {
        const itemsInOldCategory = updatedMenus.filter((m) => m.category === oldCategory).sort((a, b) => (a.order || 0) - (b.order || 0));
        itemsInOldCategory.forEach((item, index) => {
          const foundItem = updatedMenus.find((m) => m.id === item.id);
          if (foundItem) {
            foundItem.order = index;
          }
        });
      }
      return updatedMenus;
    });
  };
  useEffect(() => {
    if (location.pathname === "/reports") {
      setHideSidebar(false);
      setOpen(true);
    } else if (location.pathname.startsWith("/reports/")) {
      setHideSidebar(true);
      setOpen(false);
    }
  }, [location.pathname]);
  const handleDragStart = (e, item, category) => {
    setDraggedItem({ item, category });
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData(
      "text/plain",
      JSON.stringify({ id: item.id, category })
    );
  };
  const handleDragOver = (e, item, category) => {
    e.preventDefault();
    setDragOverItem({ item, category });
  };
  const handleDragEnd = () => {
    setDraggedItem(null);
    setDragOverItem(null);
  };
  const handleDrop = (e, targetItem, targetCategory) => {
    e.preventDefault();
    if (!draggedItem || draggedItem.category !== targetCategory) {
      setDraggedItem(null);
      setDragOverItem(null);
      return;
    }
    const sourceItem = draggedItem.item;
    const sourceIndex = menus.findIndex((m) => m.id === sourceItem.id);
    const targetIndex = menus.findIndex((m) => m.id === targetItem.id);
    if (sourceIndex === -1 || targetIndex === -1 || sourceIndex === targetIndex) {
      setDraggedItem(null);
      setDragOverItem(null);
      return;
    }
    const newMenus = [...menus];
    const [removed] = newMenus.splice(sourceIndex, 1);
    newMenus.splice(targetIndex, 0, removed);
    const categoryItems = newMenus.filter((m) => m.category === targetCategory);
    categoryItems.forEach((item, index) => {
      item.order = index;
    });
    setMenus(newMenus);
    setDraggedItem(null);
    setDragOverItem(null);
  };
  const renderSidebar = () => {
    const filteredCategories = sortedCategories.filter((category) => groupedMenus[category]?.length).filter((category) => {
      if (!sidebarSearchQuery) return true;
      if (category.toLowerCase().includes(sidebarSearchQuery.toLowerCase()))
        return true;
      return groupedMenus[category]?.some(
        (item) => item.title.toLowerCase().includes(sidebarSearchQuery.toLowerCase())
      );
    });
    const getFilteredItems = (category) => {
      if (!sidebarSearchQuery) return groupedMenus[category] || [];
      return (groupedMenus[category] || []).filter(
        (item) => item.title.toLowerCase().includes(sidebarSearchQuery.toLowerCase())
      );
    };
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        ref,
        className: `min-h-screen max-h-auto p-4 pt-8 ${open ? "w-64" : "w-20"} duration-300 relative bg-white shadow-lg`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6 px-2", children: [
            open && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-400 uppercase tracking-wider", children: "Categories" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4692,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setOpen(!open),
                className: `p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 transition-all duration-300 ${!open ? "mx-auto" : ""}`,
                children: /* @__PURE__ */ jsxDEV(
                  FiChevronLeft,
                  {
                    className: `text-gray-600 text-xl transition-transform duration-300 ${!open ? "rotate-180" : ""}`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 4702,
                    columnNumber: 13
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 4696,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 4690,
            columnNumber: 9
          }, this),
          open && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 px-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: "Search reports...",
                  value: sidebarSearchQuery,
                  onChange: (e) => setSidebarSearchQuery(e.target.value),
                  className: "w-full pl-9 pr-8 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-300 placeholder:text-gray-400"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 4714,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(IoSearchOutline, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 text-base" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 4721,
                columnNumber: 15
              }, this),
              sidebarSearchQuery && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setSidebarSearchQuery(""),
                  className: "absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors",
                  children: /* @__PURE__ */ jsxDEV(IoCloseCircle, { className: "text-base" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 4727,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 4723,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4713,
              columnNumber: 13
            }, this),
            sidebarSearchQuery && /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 text-xs text-gray-400", children: [
              "Found",
              " ",
              filteredCategories.reduce(
                (acc, category) => acc + getFilteredItems(category).length,
                0
              ),
              " ",
              "results"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4733,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 4712,
            columnNumber: 9
          }, this),
          filteredCategories.map((category) => {
            const items = getFilteredItems(category);
            if (items.length === 0 && sidebarSearchQuery) return null;
            const isExpanded = expandedCategories[category] || false;
            const itemCount = items.length;
            const isActive = activeCategory === category;
            const shouldExpand = sidebarSearchQuery ? true : isExpanded;
            return /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  onClick: () => {
                    if (open) {
                      toggleCategory(category);
                      setActiveCategory(category);
                    }
                  },
                  className: `flex items-center justify-between p-2.5 rounded-xl cursor-pointer transition-all duration-200 ${isActive && open ? "bg-blue-50 text-blue-700 border-l-4 border-blue-500" : open ? "hover:bg-gray-50" : "justify-center hover:bg-gray-50"}`,
                  children: open ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(
                        "span",
                        {
                          className: `font-semibold text-sm uppercase tracking-wider ${isActive ? "text-blue-700" : "text-gray-700"}`,
                          children: category
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 4779,
                          columnNumber: 23
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "span",
                        {
                          className: `text-xs px-1.5 py-0.5 rounded-full ${isActive ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-400"}`,
                          children: itemCount
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 4786,
                          columnNumber: 23
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 4778,
                      columnNumber: 21
                    }, this),
                    shouldExpand ? /* @__PURE__ */ jsxDEV(
                      BsChevronDown,
                      {
                        className: `text-sm ${isActive ? "text-blue-500" : "text-gray-400"}`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 4797,
                        columnNumber: 19
                      },
                      this
                    ) : /* @__PURE__ */ jsxDEV(
                      BsChevronRight,
                      {
                        className: `text-sm ${isActive ? "text-blue-500" : "text-gray-400"}`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 4801,
                        columnNumber: 19
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 4777,
                    columnNumber: 17
                  }, this) : /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `w-2 h-2 rounded-full ${isActive ? "bg-blue-500" : "bg-gray-300"}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 4807,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 4759,
                  columnNumber: 15
                },
                this
              ),
              open && shouldExpand && /* @__PURE__ */ jsxDEV("div", { className: "ml-3 border-l-2 border-gray-100 pl-3 space-y-1", children: items.map(
                ({ title, link, Icon, color, isNew }) => /* @__PURE__ */ jsxDEV(
                  NavLink,
                  {
                    to: link,
                    onClick: () => {
                      scrollToTop();
                      setHideSidebar(!hideSidebar);
                      setSidebarSearchQuery("");
                    },
                    className: ({ isActive: isLinkActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${isLinkActive ? "bg-blue-50 text-blue-700 shadow-sm" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"}`,
                    children: ({ isActive: isLinkActive }) => /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      /* @__PURE__ */ jsxDEV(
                        Icon,
                        {
                          size: 18,
                          className: `${isLinkActive ? "text-blue-600" : "text-gray-400"}`
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 4835,
                          columnNumber: 27
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("span", { className: "flex-1 text-sm font-medium leading-tight", children: title }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 4841,
                        columnNumber: 27
                      }, this),
                      isNew && /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 text-xs font-bold text-white bg-gradient-to-r from-green-400 to-green-500 rounded-full animate-pulse", children: "NEW" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 4845,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 4834,
                      columnNumber: 19
                    }, this)
                  },
                  link,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 4816,
                    columnNumber: 17
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 4814,
                columnNumber: 15
              }, this)
            ] }, category, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4758,
              columnNumber: 13
            }, this);
          }),
          open && sidebarSearchQuery && filteredCategories.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-gray-100 rounded-full mb-2", children: /* @__PURE__ */ jsxDEV(IoSearchOutline, { className: "text-2xl text-gray-400" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4863,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4862,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No reports found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4865,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-1", children: "Try adjusting your search" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 4866,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 4861,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 4686,
        columnNumber: 7
      },
      this
    );
  };
  const renderCategoryChips = () => {
    const chipCategories = ["All", ...sortedCategories];
    return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mb-6 pb-2 overflow-x-auto", children: chipCategories.map((category) => {
      const count = category === "All" ? menus.filter((m) => m.visible).length : groupedMenus[category]?.length || 0;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setActiveCategory(category),
          className: `px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 whitespace-nowrap ${activeCategory === category ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md shadow-blue-200" : "bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 hover:border-gray-300"}`,
          children: [
            category,
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: `ml-1.5 text-xs ${activeCategory === category ? "text-blue-100" : "text-gray-400"}`,
                children: [
                  "(",
                  count,
                  ")"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 4898,
                columnNumber: 15
              },
              this
            )
          ]
        },
        category,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 4888,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 4880,
      columnNumber: 7
    }, this);
  };
  const renderGridCards = () => {
    if (activeCategory === "All") {
      return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: sortedAllFilteredCategories.map((category, categoryIndex) => {
        const categoryMenus = allFilteredGroupedMenus[category];
        return /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-8 h-8 rounded-lg bg-blue-50 text-blue-600 font-bold text-sm", children: categoryIndex + 1 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5e3,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-800", children: category }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5005,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: [
                categoryMenus.length,
                " report",
                categoryMenus.length !== 1 ? "s" : ""
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5009,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5004,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 4999,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-8 gap-3", children: categoryMenus.map(
            ({ title, Icon, link, color, isNew }) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => handleNavigation(link),
                className: "group cursor-pointer",
                children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-100 hover:border-blue-200 hover:-translate-y-1", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `bg-gradient-to-br ${color} h-16 flex items-center justify-center relative overflow-hidden`,
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/5" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 5029,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(Icon, { className: "text-2xl text-white drop-shadow-lg relative z-10" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 5031,
                          columnNumber: 27
                        }, this),
                        isNew && /* @__PURE__ */ jsxDEV("span", { className: "absolute top-1 right-1 px-1.5 py-0.5 text-[8px] font-bold text-white bg-green-500 rounded-full animate-pulse shadow-lg z-10", children: "NEW" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 5034,
                          columnNumber: 27
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5026,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-medium text-gray-800 group-hover:text-blue-600 transition-colors line-clamp-2 text-center leading-tight", children: title }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5041,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5040,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5025,
                  columnNumber: 23
                }, this)
              },
              link,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5020,
                columnNumber: 21
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5017,
            columnNumber: 15
          }, this)
        ] }, category, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 4997,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 4992,
        columnNumber: 9
      }, this);
    }
    return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-8 gap-3", children: filteredMenus.map(
      ({ title, Icon, link, color, isNew }) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => handleNavigation(link),
          className: "group cursor-pointer",
          children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-100 hover:border-blue-200 hover:-translate-y-1", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `bg-gradient-to-br ${color} h-16 flex items-center justify-center relative overflow-hidden`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5070,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV(Icon, { className: "text-2xl text-white drop-shadow-lg relative z-10" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5072,
                    columnNumber: 15
                  }, this),
                  isNew && /* @__PURE__ */ jsxDEV("span", { className: "absolute top-1 right-1 px-1.5 py-0.5 text-[8px] font-bold text-white bg-green-500 rounded-full animate-pulse shadow-lg z-10", children: "NEW" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5075,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5067,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-medium text-gray-800 group-hover:text-blue-600 transition-colors line-clamp-2 text-center leading-tight", children: title }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5082,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5081,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5066,
            columnNumber: 11
          }, this)
        },
        link,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5061,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 5059,
      columnNumber: 7
    }, this);
  };
  const renderListItems = () => {
    if (activeCategory === "All") {
      return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8", children: sortedAllFilteredCategories.map((category, categoryIndex) => {
        const categoryMenus = allFilteredGroupedMenus[category];
        return /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-8 h-8 rounded-lg bg-blue-50 text-blue-600 font-bold text-sm", children: categoryIndex + 1 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5155,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-800", children: category }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5160,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: [
                categoryMenus.length,
                " report",
                categoryMenus.length !== 1 ? "s" : ""
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5164,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5159,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5154,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: categoryMenus.map(
            ({ title, Icon, link, color, isNew, id }) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => handleNavigation(link),
                className: "group cursor-pointer",
                children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 hover:border-blue-200 hover:-translate-x-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center p-4 hover:bg-gray-50/50 transition-colors", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `bg-gradient-to-br ${color} rounded-xl p-3 mr-4 flex-shrink-0`,
                      children: /* @__PURE__ */ jsxDEV(Icon, { className: "text-xl text-white" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 5184,
                        columnNumber: 29
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5181,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-grow min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-wrap", children: [
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 group-hover:text-blue-600 transition-colors truncate", children: title }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 5189,
                        columnNumber: 31
                      }, this),
                      isNew && /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 text-xs font-bold text-white bg-gradient-to-r from-green-400 to-green-500 rounded-full animate-pulse flex-shrink-0", children: "NEW" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 5194,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5188,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-0.5", children: "Click to view detailed report" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5200,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5187,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "svg",
                    {
                      className: "w-5 h-5 text-gray-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all flex-shrink-0 ml-2",
                      fill: "none",
                      stroke: "currentColor",
                      viewBox: "0 0 24 24",
                      children: /* @__PURE__ */ jsxDEV(
                        "path",
                        {
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          strokeWidth: 2,
                          d: "M9 5l7 7-7 7"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 5211,
                          columnNumber: 29
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5205,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5180,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5179,
                  columnNumber: 23
                }, this)
              },
              id,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5174,
                columnNumber: 21
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5171,
            columnNumber: 15
          }, this)
        ] }, category, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5152,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5147,
        columnNumber: 9
      }, this);
    }
    return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: filteredMenus.map(
      ({ title, Icon, link, color, id, isNew }) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => handleNavigation(link),
          className: "group cursor-pointer",
          children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 hover:border-blue-200 hover:-translate-x-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center p-4 hover:bg-gray-50/50 transition-colors", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `bg-gradient-to-br ${color} rounded-xl p-3 mr-4 flex-shrink-0`,
                children: /* @__PURE__ */ jsxDEV(Icon, { className: "text-xl text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5245,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5242,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-grow min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-wrap", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 group-hover:text-blue-600 transition-colors truncate", children: title }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5250,
                  columnNumber: 19
                }, this),
                isNew && /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 text-xs font-bold text-white bg-gradient-to-r from-green-400 to-green-500 rounded-full animate-pulse flex-shrink-0", children: "NEW" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5255,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5249,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-0.5", children: "Click to view detailed report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5261,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5248,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "w-5 h-5 text-gray-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all flex-shrink-0 ml-2",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M9 5l7 7-7 7"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5272,
                    columnNumber: 17
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5266,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5241,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5240,
            columnNumber: 11
          }, this)
        },
        id,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5235,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 5233,
      columnNumber: 7
    }, this);
  };
  const renderDraggableItems = () => {
    const filteredMenusForModal = modalSearchQuery ? menus.filter(
      (menu) => menu.title.toLowerCase().includes(modalSearchQuery.toLowerCase()) || menu.category && menu.category.toLowerCase().includes(modalSearchQuery.toLowerCase())
    ) : menus;
    const groupedByCategory = {};
    filteredMenusForModal.forEach((menu) => {
      const category = menu.category || "Uncategorized";
      if (!groupedByCategory[category]) {
        groupedByCategory[category] = [];
      }
      groupedByCategory[category].push(menu);
    });
    Object.keys(groupedByCategory).forEach((category) => {
      groupedByCategory[category].sort(
        (a, b) => (a.order || 0) - (b.order || 0)
      );
    });
    const sortedCatKeys = Object.keys(groupedByCategory).sort((a, b) => {
      const indexA = categoryOrder.indexOf(a);
      const indexB = categoryOrder.indexOf(b);
      if (indexA !== -1 && indexB !== -1) return indexA - indexB;
      if (indexA !== -1) return -1;
      if (indexB !== -1) return 1;
      return a.localeCompare(b);
    });
    const allCategories = getAllCategories();
    if (modalSearchQuery && sortedCatKeys.length === 0) {
      return /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-3", children: /* @__PURE__ */ jsxDEV(IoSearchOutline, { className: "text-3xl text-gray-400" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5332,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5331,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-base font-medium text-gray-700", children: "No reports found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5334,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-1", children: "Try adjusting your search" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5337,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5330,
        columnNumber: 9
      }, this);
    }
    return sortedCatKeys.map((category) => {
      const items = groupedByCategory[category];
      if (items.length === 0) return null;
      return /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-600 uppercase tracking-wider", children: category }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5352,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: [
            items.length,
            " items"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5355,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5351,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: items.map((menu, index) => {
          const isDragging = draggedItem?.item?.id === menu.id;
          const isDragOver = dragOverItem?.item?.id === menu.id;
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              draggable: true,
              onDragStart: (e) => handleDragStart(e, menu, category),
              onDragOver: (e) => handleDragOver(e, menu, category),
              onDragEnd: handleDragEnd,
              onDrop: (e) => handleDrop(e, menu, category),
              className: `flex items-center gap-3 p-4 rounded-xl transition-all duration-200 ${isDragging ? "bg-blue-50 border-2 border-blue-400 shadow-lg opacity-50" : isDragOver ? "bg-blue-50 border-2 border-dashed border-blue-400" : "bg-gray-50 hover:bg-gray-100 border-2 border-transparent"} cursor-move`,
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-gray-400 cursor-grab flex-shrink-0", children: /* @__PURE__ */ jsxDEV(
                    "svg",
                    {
                      className: "w-5 h-5",
                      fill: "currentColor",
                      viewBox: "0 0 20 20",
                      children: /* @__PURE__ */ jsxDEV("path", { d: "M7 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm6-12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 5385,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5380,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5379,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-gray-800 truncate", children: menu.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5389,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: [
                        "Order: ",
                        menu.order || index
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 5393,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-300", children: "|" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                        lineNumber: 5396,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "select",
                        {
                          value: menu.category,
                          onChange: (e) => handleCategoryChange(menu.id, e.target.value),
                          className: "text-xs border rounded px-2 py-1 bg-white hover:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent",
                          onClick: (e) => e.stopPropagation(),
                          children: allCategories.map(
                            (cat) => /* @__PURE__ */ jsxDEV("option", { value: cat, children: cat }, cat, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                              lineNumber: 5406,
                              columnNumber: 27
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                          lineNumber: 5397,
                          columnNumber: 25
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5392,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5388,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5378,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 ml-4 flex-shrink-0", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500", children: menu.visible ? "Visible" : "Hidden" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5415,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Switch,
                    {
                      checked: menu.visible,
                      onChange: (checked) => {
                        setMenus(
                          (prev) => prev.map(
                            (item) => item.id === menu.id ? { ...item, visible: checked } : item
                          )
                        );
                      }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                      lineNumber: 5418,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5414,
                  columnNumber: 19
                }, this)
              ]
            },
            menu.id,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5363,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5357,
          columnNumber: 11
        }, this)
      ] }, category, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5350,
        columnNumber: 9
      }, this);
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex mt-16 bg-gray-50/80", children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 5442,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(Sidebar, { hideSidebar }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 5443,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `${open ? "w-64" : "w-20"} bg-white min-h-screen border-r border-gray-200/80 overflow-y-auto flex-shrink-0 transition-all duration-300`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "sticky top-0 bg-white/95 backdrop-blur-sm z-10 px-4 py-3 mt-10 border-b border-gray-100/80", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setActiveCategory("All");
                navigate("/reports");
                scrollToTop();
              },
              className: `group flex items-center justify-center gap-2 font-semibold transition-all duration-300 w-full ${open ? "px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-sm hover:shadow-md hover:scale-[1.02]" : "p-2.5 rounded-full bg-blue-600 text-white shadow-sm hover:shadow-md hover:scale-110"}`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  FaChartBar,
                  {
                    className: open ? "text-blue-100 text-lg" : "text-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5462,
                    columnNumber: 11
                  },
                  this
                ),
                open && /* @__PURE__ */ jsxDEV("span", { className: "tracking-wide text-sm", children: "Reports" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5465,
                  columnNumber: 20
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5450,
              columnNumber: 9
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5449,
            columnNumber: 7
          }, this),
          renderSidebar()
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5446,
        columnNumber: 5
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 overflow-hidden max-h-screen overflow-y-auto bg-gray-50/80", children: location.pathname === "/reports" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-5 mt-10 flex justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "relative max-w-xl w-full", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(IoSearchOutline, { className: "text-gray-400 text-lg" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5479,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5478,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search reports...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "w-full pl-11 pr-12 py-3 text-sm bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 shadow-sm hover:shadow transition-all duration-200 placeholder:text-gray-400"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5481,
            columnNumber: 15
          },
          this
        ),
        searchQuery && /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleClearSearch,
            className: "absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 transition-all duration-200",
            children: /* @__PURE__ */ jsxDEV(IoCloseCircle, { className: "text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5493,
              columnNumber: 19
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5489,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5477,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5476,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-3 mb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: renderCategoryChips() }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5501,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 flex-shrink-0", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setViewType("grid"),
              className: `p-2 rounded-lg transition-all ${viewType === "grid" ? "bg-blue-600 text-white shadow-sm" : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-200"}`,
              title: "Grid View",
              children: /* @__PURE__ */ jsxDEV(BiGrid, { size: 18 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5514,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5505,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setViewType("list"),
              className: `p-2 rounded-lg transition-all ${viewType === "list" ? "bg-blue-600 text-white shadow-sm" : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-200"}`,
              title: "List View",
              children: /* @__PURE__ */ jsxDEV(TbList, { size: 18 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5525,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5516,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium transition-all shadow-sm hover:shadow-md ml-1",
              onClick: () => setManageModal(true),
              children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV(FiSettings, { size: 15 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5532,
                  columnNumber: 19
                }, this),
                "Manage"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5531,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5527,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5504,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5500,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-xs text-gray-400", children: [
        "Showing ",
        filteredMenus.length,
        " report",
        filteredMenus.length !== 1 ? "s" : "",
        searchQuery && ` for "${searchQuery}"`,
        activeCategory !== "All" && ` in ${activeCategory}`
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5540,
        columnNumber: 11
      }, this),
      isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-16", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-10 w-10 border-3 border-blue-600 border-t-transparent" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5550,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5549,
        columnNumber: 11
      }, this) : filteredMenus.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-16", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-3", children: /* @__PURE__ */ jsxDEV(IoSearchOutline, { className: "text-3xl text-gray-400" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5555,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5554,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-1", children: "No reports found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5557,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: activeCategory !== "All" ? `No reports found in "${activeCategory}" category` : "Try adjusting your search or filter criteria" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5560,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5553,
        columnNumber: 11
      }, this) : viewType === "grid" ? renderGridCards() : renderListItems()
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 5474,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 5573,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
      lineNumber: 5472,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-base", children: [
          /* @__PURE__ */ jsxDEV(FiSettings, { className: "text-blue-600", size: 18 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5581,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Manage Reports" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5582,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-normal text-gray-400 ml-1", children: "- Order, Category & Visibility" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5583,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
          lineNumber: 5580,
          columnNumber: 9
        }, this),
        open: manageModal,
        onCancel: () => {
          setManageModal(false);
          setModalSearchQuery("");
        },
        footer: null,
        width: 880,
        className: "rounded-xl",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxDEV(IoSearchOutline, { className: "text-gray-400 text-base" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5601,
                columnNumber: 13
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5600,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: "Search reports by title or category...",
                  value: modalSearchQuery,
                  onChange: (e) => setModalSearchQuery(e.target.value),
                  className: "w-full pl-10 pr-10 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 placeholder:text-gray-400"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5603,
                  columnNumber: 11
                },
                this
              ),
              modalSearchQuery && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleClearModalSearch,
                  className: "absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 transition-all duration-200",
                  children: /* @__PURE__ */ jsxDEV(IoCloseCircle, { className: "text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5615,
                    columnNumber: 15
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5611,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5599,
              columnNumber: 9
            }, this),
            modalSearchQuery && /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 text-xs text-gray-400", children: [
              "Found",
              " ",
              menus.filter(
                (menu) => menu.title.toLowerCase().includes(modalSearchQuery.toLowerCase()) || menu.category && menu.category.toLowerCase().includes(modalSearchQuery.toLowerCase())
              ).length,
              " ",
              "result",
              menus.filter(
                (menu) => menu.title.toLowerCase().includes(modalSearchQuery.toLowerCase()) || menu.category && menu.category.toLowerCase().includes(modalSearchQuery.toLowerCase())
              ).length !== 1 ? "s" : "",
              " ",
              'matching "',
              modalSearchQuery,
              '"'
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5620,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5598,
            columnNumber: 7
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-blue-50/80 rounded-lg border border-blue-100/60", children: /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-blue-700 space-y-0.5", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4 flex-shrink-0", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  fillRule: "evenodd",
                  d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
                  clipRule: "evenodd"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5657,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5656,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Drag" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5664,
                  columnNumber: 15
                }, this),
                " to reorder reports within a category"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5663,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5655,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "flex items-center gap-2 ml-6", children: /* @__PURE__ */ jsxDEV("span", { children: [
              "Use the ",
              /* @__PURE__ */ jsxDEV("strong", { children: "dropdown" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5669,
                columnNumber: 23
              }, this),
              " to move a report to a different category"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5668,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
              lineNumber: 5667,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5654,
            columnNumber: 9
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5653,
            columnNumber: 7
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 max-h-[50vh] overflow-y-auto pr-1", children: renderDraggableItems() }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5675,
            columnNumber: 7
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2.5 mt-5 pt-4 border-t border-gray-100", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: "px-5 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg transition-colors font-medium",
                onClick: () => {
                  setManageModal(false);
                  setModalSearchQuery("");
                },
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5680,
                columnNumber: 9
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: "px-5 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-medium shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed",
                onClick: saveReports,
                disabled: saving,
                children: saving ? /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "animate-spin rounded-full h-3.5 w-3.5 border-2 border-white border-t-transparent" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                    lineNumber: 5696,
                    columnNumber: 15
                  }, this),
                  "Saving..."
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                  lineNumber: 5695,
                  columnNumber: 13
                }, this) : "Save Changes"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
                lineNumber: 5689,
                columnNumber: 9
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
            lineNumber: 5679,
            columnNumber: 7
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
        lineNumber: 5578,
        columnNumber: 5
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx",
    lineNumber: 5441,
    columnNumber: 5
  }, this);
};
_s(Reports, "/P/gp79pyXZ4yROoBbJ4Pvwd3U4=", false, function() {
  return [useLocation, useNavigate];
});
_c = Reports;
export default Reports;
var _c;
$RefreshReg$(_c, "Reports");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Reports.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbWxKWSxTQXFGTSxVQXJGTjsyQkFubEpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBKzNCQSxPQUFPQSxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0MsU0FBU0MsUUFBUUMsYUFBYUMsbUJBQW1CO0FBQzFEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGFBQWFDLGVBQWU7QUFDckMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLDBCQUEwQjtBQUNuQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGdCQUFnQkMsZUFBZUMsc0JBQXNCO0FBQzlELFNBQVNDLG9CQUFvQjtBQUU3QixTQUFTQyxPQUFPQyxRQUFRQyxTQUFTQyxRQUFRQyxjQUFjO0FBRXZELFNBQVNDLG9DQUFvQztBQUM3QyxTQUFTQyxhQUFhQyxxQkFBcUI7QUFDM0MsU0FBU0MsZUFBZUMsa0JBQWtCO0FBQzFDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsWUFBWUMsZ0JBQWdCQyxvQkFBb0I7QUFDekQsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLFFBQVFDLFVBQVVDLGlCQUFpQjtBQUM1QyxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsbUJBQW1CO0FBRTVCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MscUJBQXFCO0FBQzlCLE9BQU9DLFNBQVM7QUFFaEIsTUFBTUMsV0FBVztBQUFBLEVBQ2Y7QUFBQSxJQUNFQyxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxNQUFNL0I7QUFBQUEsSUFDTmdDLFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUE7QUFBQSxJQUNFTCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxNQUFNMUQ7QUFBQUEsSUFDTjJELFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxNQUFNbkI7QUFBQUEsSUFDTm9CLFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUE7QUFBQSxJQUNFTCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxNQUFNOUI7QUFBQUEsSUFDTitCLFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxNQUFNN0U7QUFBQUEsSUFDTjhFLFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTXJGO0FBQUFBLElBQ051RixPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTXJCO0FBQUFBLElBQ05zQixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTS9FO0FBQUFBLElBQ05nRixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VOLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLE1BQU1sQjtBQUFBQSxJQUNObUIsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFFQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNcEY7QUFBQUEsSUFDTnNGLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTXBEO0FBQUFBLElBQ05zRCxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkUsVUFBVTtBQUFBLElBQ1ZELE1BQU0zRTtBQUFBQSxJQUNONkUsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VOLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNcEI7QUFBQUEsSUFDTnNCLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTWpCO0FBQUFBLElBQ05tQixPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTFCO0FBQUFBLElBQ04yQixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTXJGO0FBQUFBLElBQ05zRixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTdCO0FBQUFBLElBQ044QixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTXZCO0FBQUFBLElBQ053QixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTXBCO0FBQUFBLElBQ05xQixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTdCO0FBQUFBLElBQ044QixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTS9FO0FBQUFBLElBQ05nRixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTXBGO0FBQUFBLElBQ05xRixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTXpEO0FBQUFBLElBQ04wRCxVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUwsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsTUFBTW5GO0FBQUFBLElBQ05vRixVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VOLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLE1BQU0zQjtBQUFBQSxJQUNONEIsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLE1BQU05RTtBQUFBQSxJQUNOK0UsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNaEM7QUFBQUEsSUFDTmtDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNakM7QUFBQUEsSUFDTm1DLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLE1BQU12QjtBQUFBQSxJQUNOd0IsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLE1BQU10QjtBQUFBQSxJQUNOdUIsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxNQUFNL0M7QUFBQUEsSUFDTmdELFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTWY7QUFBQUEsSUFDTmlCLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNNUU7QUFBQUEsSUFDTjhFLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNYjtBQUFBQSxJQUNOZSxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkUsVUFBVTtBQUFBLElBQ1ZELE1BQU1uQztBQUFBQSxJQUNOcUMsT0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNakY7QUFBQUEsSUFDTm1GLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNakY7QUFBQUEsSUFDTm1GLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VMLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNdEI7QUFBQUEsSUFDTndCLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTWhCO0FBQUFBLElBQ05rQixPQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUE7QUFBQSxJQUNFTCxJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTVY7QUFBQUEsSUFDTlksT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VOLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNVjtBQUFBQSxJQUNOWSxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkUsVUFBVTtBQUFBLElBQ1ZELE1BQU1oRjtBQUFBQSxJQUNOa0YsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VOLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNekI7QUFBQUEsSUFDTjJCLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTTFCO0FBQUFBLElBQ040QixPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkUsVUFBVTtBQUFBLElBQ1ZELE1BQU1oQjtBQUFBQSxJQUNOa0IsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VOLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNbkQ7QUFBQUEsSUFDTnFELE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTXBEO0FBQUFBLElBQ05zRCxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkUsVUFBVTtBQUFBLElBQ1ZELE1BQU0vQjtBQUFBQSxJQUNOaUMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VOLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05FLFVBQVU7QUFBQSxJQUNWRCxNQUFNOUI7QUFBQUEsSUFDTmdDLE9BQU87QUFBQSxJQUNQQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNORSxVQUFVO0FBQUEsSUFDVkQsTUFBTTdCO0FBQUFBLElBQ04rQixPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkUsVUFBVTtBQUFBLElBQ1ZELE1BQU1kO0FBQUFBLElBQ05nQixPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkUsVUFBVTtBQUFBLElBQ1ZELE1BQU1kO0FBQUFBLElBQ05nQixPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLEVBQ1Q7QUFBQztBQUdILE1BQU1DLGFBQWE7QUFBQSxFQUNqQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBUTtBQUdWLE1BQU1DLGlCQUFpQjtBQUFBLEVBQ3JCQyxVQUFVO0FBQUEsRUFDVkMsVUFBVTtBQUFBLEVBQ1ZDLE1BQU07QUFBQSxFQUNOQyxPQUFPO0FBQUEsRUFDUEMsU0FBUztBQUFBLEVBQ1RDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQUEsRUFDWkMsTUFBTTtBQUFBLEVBQ05DLE9BQU87QUFBQSxFQUNQQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUFBLEVBQ1BDLFdBQVc7QUFBQSxFQUNYQyxRQUFRO0FBQUEsRUFDUkMsU0FBUztBQUFBLEVBQ1RDLE1BQU07QUFDUjtBQWkxRkEsTUFBTUMsVUFBVUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BCLFFBQU1DLFdBQVc5RyxZQUFZO0FBQzdCLFFBQU0rRyxXQUFXOUcsWUFBWTtBQUM3QixRQUFNLENBQUMrRyxnQkFBZ0JDLGlCQUFpQixJQUFJdEUsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ3VFLFVBQVVDLFdBQVcsSUFBSXhFLFNBQVMsTUFBTTtBQUMvQyxRQUFNLENBQUN5RSxhQUFhQyxjQUFjLElBQUkxRSxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDMkUsb0JBQW9CQyxxQkFBcUIsSUFBSTVFLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUM2RSxrQkFBa0JDLG1CQUFtQixJQUFJOUUsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQytFLE1BQU1DLE9BQU8sSUFBSWhGLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNpRixhQUFhQyxjQUFjLElBQUlsRixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDbUYsb0JBQW9CQyxxQkFBcUIsSUFBSXBGLFNBQVMsQ0FBQyxDQUFDO0FBQy9ELFFBQU0sQ0FBQ3FGLE9BQU9DLFFBQVEsSUFBSXRGLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUN1RixRQUFRQyxTQUFTLElBQUl4RixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDeUYsYUFBYUMsY0FBYyxJQUFJMUYsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQzJGLFdBQVdDLFlBQVksSUFBSTVGLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUM2RixhQUFhQyxjQUFjLElBQUk5RixTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDK0YsY0FBY0MsZUFBZSxJQUFJaEcsU0FBUyxJQUFJO0FBR3JELFFBQU1pRyxnQkFBZ0IsQ0FBQyxZQUFZLFdBQVcsVUFBVTtBQUd4RCxRQUFNQyxtQkFBbUJBLE1BQU07QUFDN0IsVUFBTWxELGNBQWEsb0JBQUltRCxJQUFJO0FBQzNCZCxVQUFNZSxRQUFRLENBQUNDLFNBQVM7QUFDdEIsVUFBSUEsS0FBS3hELFVBQVU7QUFDakJHLG9CQUFXc0QsSUFBSUQsS0FBS3hELFFBQVE7QUFBQSxNQUM5QjtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU8wRCxNQUFNQyxLQUFLeEQsV0FBVTtBQUFBLEVBQzlCO0FBRUEsUUFBTXlELGlCQUFpQkEsQ0FBQzVELGFBQWE7QUFDbkN1QywwQkFBc0IsQ0FBQ3NCLFVBQVU7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUM3RCxRQUFRLEdBQUcsQ0FBQzZELEtBQUs3RCxRQUFRO0FBQUEsSUFDNUIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNOEQsY0FBY0EsTUFBTTtBQUN4QkMsV0FBT0MsU0FBUyxFQUFFQyxLQUFLLEdBQUdDLFVBQVUsU0FBUyxDQUFDO0FBQUEsRUFDaEQ7QUFFQTlHLFlBQVUsTUFBTTtBQUNkK0csaUJBQWE7QUFBQSxFQUNmLEdBQUcsRUFBRTtBQUVMLFFBQU1BLGVBQWUsWUFBWTtBQUMvQixRQUFJO0FBQ0ZwQixtQkFBYSxJQUFJO0FBQ2pCLFlBQU1xQixXQUFXLE1BQU0xRSxJQUFJMkUsSUFBSSw2QkFBNkI7QUFDNUQsWUFBTUMsYUFBYUYsU0FBU0csS0FBS0EsUUFBUTtBQUV6QyxZQUFNQyxhQUFhN0UsU0FBUzhFLElBQUksQ0FBQ2pCLFNBQVM7QUFDeEMsY0FBTWtCLFNBQVNKLFdBQVdLLEtBQUssQ0FBQ0MsU0FBU0EsS0FBS0MsYUFBYXJCLEtBQUs1RCxFQUFFO0FBQ2xFLGVBQU87QUFBQSxVQUNMLEdBQUc0RDtBQUFBQSxVQUNIc0IsU0FBU0osU0FBU0EsT0FBT0ksVUFBVTtBQUFBLFVBQ25DOUUsVUFBVTBFLFFBQVExRSxZQUFZd0QsS0FBS3hELFlBQVk7QUFBQSxVQUMvQytFLE9BQU9MLFFBQVFLLFNBQVN2QixLQUFLdUIsU0FBUztBQUFBLFFBQ3hDO0FBQUEsTUFDRixDQUFDO0FBR0RQLGlCQUFXUSxLQUFLLENBQUNDLEdBQUdDLE9BQU9ELEVBQUVGLFNBQVMsTUFBTUcsRUFBRUgsU0FBUyxFQUFFO0FBQ3pEdEMsZUFBUytCLFVBQVU7QUFBQSxJQUNyQixTQUFTVyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU1GLEdBQUc7QUFDakIxQztBQUFBQSxRQUNFOUMsU0FBUzhFLElBQUksQ0FBQ2pCLFVBQVU7QUFBQSxVQUN0QixHQUFHQTtBQUFBQSxVQUNIc0IsU0FBUztBQUFBLFVBQ1Q5RSxVQUFVd0QsS0FBS3hELFlBQVk7QUFBQSxVQUMzQitFLE9BQU92QixLQUFLdUIsU0FBUztBQUFBLFFBQ3ZCLEVBQUU7QUFBQSxNQUNKO0FBQUEsSUFDRixVQUFDO0FBQ0NoQyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTXVDLG1CQUFtQkEsQ0FBQ3hGLFNBQVM7QUFDakN5QixhQUFTekIsSUFBSTtBQUNieUYsZUFBV3pCLGFBQWEsR0FBRztBQUFBLEVBQzdCO0FBRUEsUUFBTTBCLE1BQU10SSxPQUFPLElBQUk7QUFFdkIsUUFBTXVJLGdCQUFnQmpELE1BQ25Ca0QsT0FBTyxDQUFDbEMsU0FBU0EsS0FBS3NCLE9BQU8sRUFDN0JZO0FBQUFBLElBQ0MsQ0FBQ2xDLFNBQVNoQyxtQkFBbUIsU0FBU2dDLEtBQUt4RCxhQUFhd0I7QUFBQUEsRUFDMUQsRUFDQ2tFO0FBQUFBLElBQU8sQ0FBQ2xDLFNBQ1BBLEtBQUszRCxNQUFNOEYsWUFBWSxFQUFFQyxTQUFTaEUsWUFBWStELFlBQVksQ0FBQztBQUFBLEVBQzdEO0FBRUEsUUFBTUUsMEJBQTBCSixjQUFjSyxPQUFPLENBQUNDLEtBQUt2QyxTQUFTO0FBQ3RFLFVBQU14RCxXQUFXd0QsS0FBS3hELFlBQVk7QUFFbEMsUUFBSSxDQUFDK0YsSUFBSS9GLFFBQVEsR0FBRztBQUNsQitGLFVBQUkvRixRQUFRLElBQUk7QUFBQSxJQUNsQjtBQUVBK0YsUUFBSS9GLFFBQVEsRUFBRWdHLEtBQUt4QyxJQUFJO0FBRXZCLFdBQU91QztBQUFBQSxFQUNULEdBQUcsQ0FBQyxDQUFDO0FBRUxFLFNBQU9DLEtBQUtMLHVCQUF1QixFQUFFdEMsUUFBUSxDQUFDdkQsYUFBYTtBQUN6RDZGLDRCQUF3QjdGLFFBQVEsRUFBRWdGO0FBQUFBLE1BQ2hDLENBQUNDLEdBQUdDLE9BQU9ELEVBQUVGLFNBQVMsTUFBTUcsRUFBRUgsU0FBUztBQUFBLElBQ3pDO0FBQUEsRUFDRixDQUFDO0FBRUQsUUFBTW9CLDhCQUE4QkYsT0FBT0M7QUFBQUEsSUFDekNMO0FBQUFBLEVBQ0YsRUFBRWIsS0FBSyxDQUFDQyxHQUFHQyxNQUFNO0FBQ2YsVUFBTWtCLFNBQVNoRCxjQUFjaUQsUUFBUXBCLENBQUM7QUFDdEMsVUFBTXFCLFNBQVNsRCxjQUFjaUQsUUFBUW5CLENBQUM7QUFFdEMsUUFBSWtCLFdBQVcsTUFBTUUsV0FBVyxJQUFJO0FBQ2xDLGFBQU9GLFNBQVNFO0FBQUFBLElBQ2xCO0FBRUEsUUFBSUYsV0FBVyxHQUFJLFFBQU87QUFDMUIsUUFBSUUsV0FBVyxHQUFJLFFBQU87QUFFMUIsV0FBT3JCLEVBQUVzQixjQUFjckIsQ0FBQztBQUFBLEVBQzFCLENBQUM7QUFFQyxRQUFNc0IsZUFBZWhFLE1BQ2xCa0QsT0FBTyxDQUFDbEMsU0FBU0EsS0FBS3NCLE9BQU8sRUFDN0JnQixPQUFPLENBQUNDLEtBQUt2QyxTQUFTO0FBQ3JCLFVBQU14RCxXQUFXd0QsS0FBS3hELFlBQVk7QUFDbEMsUUFBSSxDQUFDK0YsSUFBSS9GLFFBQVEsR0FBRztBQUNsQitGLFVBQUkvRixRQUFRLElBQUk7QUFBQSxJQUNsQjtBQUNBK0YsUUFBSS9GLFFBQVEsRUFBRWdHLEtBQUt4QyxJQUFJO0FBQ3ZCLFdBQU91QztBQUFBQSxFQUNULEdBQUcsQ0FBQyxDQUFDO0FBR1BFLFNBQU9DLEtBQUtNLFlBQVksRUFBRWpELFFBQVEsQ0FBQ3ZELGFBQWE7QUFDOUN3RyxpQkFBYXhHLFFBQVEsRUFBRWdGLEtBQUssQ0FBQ0MsR0FBR0MsT0FBT0QsRUFBRUYsU0FBUyxNQUFNRyxFQUFFSCxTQUFTLEVBQUU7QUFBQSxFQUN2RSxDQUFDO0FBR0QsUUFBTTBCLG1CQUFtQlIsT0FBT0MsS0FBS00sWUFBWSxFQUFFeEIsS0FBSyxDQUFDQyxHQUFHQyxNQUFNO0FBQ2hFLFVBQU1rQixTQUFTaEQsY0FBY2lELFFBQVFwQixDQUFDO0FBQ3RDLFVBQU1xQixTQUFTbEQsY0FBY2lELFFBQVFuQixDQUFDO0FBRXRDLFFBQUlrQixXQUFXLE1BQU1FLFdBQVcsSUFBSTtBQUNsQyxhQUFPRixTQUFTRTtBQUFBQSxJQUNsQjtBQUNBLFFBQUlGLFdBQVcsR0FBSSxRQUFPO0FBQzFCLFFBQUlFLFdBQVcsR0FBSSxRQUFPO0FBQzFCLFdBQU9yQixFQUFFc0IsY0FBY3JCLENBQUM7QUFBQSxFQUMxQixDQUFDO0FBRUQsUUFBTXdCLG9CQUFvQkEsTUFBTTtBQUM5QjdFLG1CQUFlLEVBQUU7QUFBQSxFQUNuQjtBQUVBLFFBQU04RSx5QkFBeUJBLE1BQU07QUFDbkMxRSx3QkFBb0IsRUFBRTtBQUFBLEVBQ3hCO0FBRUEsUUFBTTJFLGNBQWMsWUFBWTtBQUM5QixRQUFJO0FBQ0ZqRSxnQkFBVSxJQUFJO0FBQ2QsWUFBTWpELElBQUltSCxJQUFJLCtCQUErQjtBQUFBLFFBQzNDQyxTQUFTdEUsTUFBTWlDLElBQUksQ0FBQ2pCLFVBQVU7QUFBQSxVQUM1QnFCLFVBQVVyQixLQUFLNUQ7QUFBQUEsVUFDZmtGLFNBQVN0QixLQUFLc0I7QUFBQUEsVUFDZDlFLFVBQVV3RCxLQUFLeEQ7QUFBQUEsVUFDZitFLE9BQU92QixLQUFLdUIsU0FBUztBQUFBLFFBQ3ZCLEVBQUU7QUFBQSxNQUNKLENBQUM7QUFDRDlJLGNBQVE4SyxRQUFRLHNDQUFzQztBQUN0RCxZQUFNNUMsYUFBYTtBQUNuQnRCLHFCQUFlLEtBQUs7QUFDcEJaLDBCQUFvQixFQUFFO0FBQUEsSUFDeEIsU0FBU2tELEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUNqQmxKLGNBQVFvSixNQUFNLGtDQUFrQztBQUFBLElBQ2xELFVBQUM7QUFDQzFDLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNcUUsdUJBQXVCQSxDQUFDQyxRQUFRQyxnQkFBZ0I7QUFDcER6RSxhQUFTLENBQUNvQixTQUFTO0FBQ2pCLFlBQU1zRCxhQUFhdEQsS0FBS2MsS0FBSyxDQUFDeUMsTUFBTUEsRUFBRXhILE9BQU9xSCxNQUFNO0FBQ25ELFlBQU1JLGNBQWNGLFlBQVluSDtBQUVoQyxZQUFNc0gsZUFBZXpELEtBQUtZLElBQUksQ0FBQ0csU0FBUztBQUN0QyxZQUFJQSxLQUFLaEYsT0FBT3FILFFBQVE7QUFDdEIsaUJBQU8sRUFBRSxHQUFHckMsTUFBTTVFLFVBQVVrSCxZQUFZO0FBQUEsUUFDMUM7QUFDQSxlQUFPdEM7QUFBQUEsTUFDVCxDQUFDO0FBRUQsWUFBTTJDLHFCQUFxQkQsYUFDeEI1QixPQUFPLENBQUMwQixNQUFNQSxFQUFFcEgsYUFBYWtILFdBQVcsRUFDeENsQyxLQUFLLENBQUNDLEdBQUdDLE9BQU9ELEVBQUVGLFNBQVMsTUFBTUcsRUFBRUgsU0FBUyxFQUFFO0FBRWpEd0MseUJBQW1CaEUsUUFBUSxDQUFDcUIsTUFBTTRDLFVBQVU7QUFDMUMsY0FBTUMsWUFBWUgsYUFBYTNDLEtBQUssQ0FBQ3lDLE1BQU1BLEVBQUV4SCxPQUFPZ0YsS0FBS2hGLEVBQUU7QUFDM0QsWUFBSTZILFdBQVc7QUFDYkEsb0JBQVUxQyxRQUFReUM7QUFBQUEsUUFDcEI7QUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJSCxlQUFlQSxnQkFBZ0JILGFBQWE7QUFDOUMsY0FBTVEscUJBQXFCSixhQUN4QjVCLE9BQU8sQ0FBQzBCLE1BQU1BLEVBQUVwSCxhQUFhcUgsV0FBVyxFQUN4Q3JDLEtBQUssQ0FBQ0MsR0FBR0MsT0FBT0QsRUFBRUYsU0FBUyxNQUFNRyxFQUFFSCxTQUFTLEVBQUU7QUFFakQyQywyQkFBbUJuRSxRQUFRLENBQUNxQixNQUFNNEMsVUFBVTtBQUMxQyxnQkFBTUMsWUFBWUgsYUFBYTNDLEtBQUssQ0FBQ3lDLE1BQU1BLEVBQUV4SCxPQUFPZ0YsS0FBS2hGLEVBQUU7QUFDM0QsY0FBSTZILFdBQVc7QUFDYkEsc0JBQVUxQyxRQUFReUM7QUFBQUEsVUFDcEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBRUEsYUFBT0Y7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBbEssWUFBVSxNQUFNO0FBQ2hCLFFBQUlrRSxTQUFTcUcsYUFBYSxZQUFZO0FBQ3BDdEYscUJBQWUsS0FBSztBQUNwQkYsY0FBUSxJQUFJO0FBQUEsSUFDZCxXQUFXYixTQUFTcUcsU0FBU0MsV0FBVyxXQUFXLEdBQUc7QUFDcER2RixxQkFBZSxJQUFJO0FBQ2pCRixjQUFRLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0YsR0FBRyxDQUFDYixTQUFTcUcsUUFBUSxDQUFDO0FBR3BCLFFBQU1FLGtCQUFrQkEsQ0FBQ0MsR0FBR2xELE1BQU01RSxhQUFhO0FBQzdDaUQsbUJBQWUsRUFBRTJCLE1BQU01RSxTQUFTLENBQUM7QUFDakM4SCxNQUFFQyxhQUFhQyxnQkFBZ0I7QUFDL0JGLE1BQUVDLGFBQWFFO0FBQUFBLE1BQ2I7QUFBQSxNQUNBQyxLQUFLQyxVQUFVLEVBQUV2SSxJQUFJZ0YsS0FBS2hGLElBQUlJLFNBQVMsQ0FBQztBQUFBLElBQzFDO0FBQUEsRUFDRjtBQUVBLFFBQU1vSSxpQkFBaUJBLENBQUNOLEdBQUdsRCxNQUFNNUUsYUFBYTtBQUM1QzhILE1BQUVPLGVBQWU7QUFDakJsRixvQkFBZ0IsRUFBRXlCLE1BQU01RSxTQUFTLENBQUM7QUFBQSxFQUNwQztBQUVBLFFBQU1zSSxnQkFBZ0JBLE1BQU07QUFDMUJyRixtQkFBZSxJQUFJO0FBQ25CRSxvQkFBZ0IsSUFBSTtBQUFBLEVBQ3RCO0FBRUEsUUFBTW9GLGFBQWFBLENBQUNULEdBQUdVLFlBQVlDLG1CQUFtQjtBQUNwRFgsTUFBRU8sZUFBZTtBQUVqQixRQUFJLENBQUNyRixlQUFlQSxZQUFZaEQsYUFBYXlJLGdCQUFnQjtBQUMzRHhGLHFCQUFlLElBQUk7QUFDbkJFLHNCQUFnQixJQUFJO0FBQ3BCO0FBQUEsSUFDRjtBQUVBLFVBQU11RixhQUFhMUYsWUFBWTRCO0FBQy9CLFVBQU0rRCxjQUFjbkcsTUFBTW9HLFVBQVUsQ0FBQ3hCLE1BQU1BLEVBQUV4SCxPQUFPOEksV0FBVzlJLEVBQUU7QUFDakUsVUFBTWlKLGNBQWNyRyxNQUFNb0csVUFBVSxDQUFDeEIsTUFBTUEsRUFBRXhILE9BQU80SSxXQUFXNUksRUFBRTtBQUVqRSxRQUNFK0ksZ0JBQWdCLE1BQ2hCRSxnQkFBZ0IsTUFDaEJGLGdCQUFnQkUsYUFDaEI7QUFDQTVGLHFCQUFlLElBQUk7QUFDbkJFLHNCQUFnQixJQUFJO0FBQ3BCO0FBQUEsSUFDRjtBQUVBLFVBQU0yRixXQUFXLENBQUMsR0FBR3RHLEtBQUs7QUFDMUIsVUFBTSxDQUFDdUcsT0FBTyxJQUFJRCxTQUFTRSxPQUFPTCxhQUFhLENBQUM7QUFDaERHLGFBQVNFLE9BQU9ILGFBQWEsR0FBR0UsT0FBTztBQUV2QyxVQUFNRSxnQkFBZ0JILFNBQVNwRCxPQUFPLENBQUMwQixNQUFNQSxFQUFFcEgsYUFBYXlJLGNBQWM7QUFDMUVRLGtCQUFjMUYsUUFBUSxDQUFDcUIsTUFBTTRDLFVBQVU7QUFDckM1QyxXQUFLRyxRQUFReUM7QUFBQUEsSUFDZixDQUFDO0FBRUQvRSxhQUFTcUcsUUFBUTtBQUNqQjdGLG1CQUFlLElBQUk7QUFDbkJFLG9CQUFnQixJQUFJO0FBQUEsRUFDdEI7QUFHQSxRQUFNK0YsZ0JBQWdCQSxNQUFNO0FBRTFCLFVBQU1DLHFCQUFxQjFDLGlCQUN4QmYsT0FBTyxDQUFDMUYsYUFBYXdHLGFBQWF4RyxRQUFRLEdBQUdvSixNQUFNLEVBQ25EMUQsT0FBTyxDQUFDMUYsYUFBYTtBQUNwQixVQUFJLENBQUM4QixtQkFBb0IsUUFBTztBQUVoQyxVQUFJOUIsU0FBUzJGLFlBQVksRUFBRUMsU0FBUzlELG1CQUFtQjZELFlBQVksQ0FBQztBQUNsRSxlQUFPO0FBRVQsYUFBT2EsYUFBYXhHLFFBQVEsR0FBR3FKO0FBQUFBLFFBQUssQ0FBQ3pFLFNBQ25DQSxLQUFLL0UsTUFBTThGLFlBQVksRUFBRUMsU0FBUzlELG1CQUFtQjZELFlBQVksQ0FBQztBQUFBLE1BQ3BFO0FBQUEsSUFDRixDQUFDO0FBR0gsVUFBTTJELG1CQUFtQkEsQ0FBQ3RKLGFBQWE7QUFDckMsVUFBSSxDQUFDOEIsbUJBQW9CLFFBQU8wRSxhQUFheEcsUUFBUSxLQUFLO0FBQzFELGNBQVF3RyxhQUFheEcsUUFBUSxLQUFLLElBQUkwRjtBQUFBQSxRQUFPLENBQUNkLFNBQzVDQSxLQUFLL0UsTUFBTThGLFlBQVksRUFBRUMsU0FBUzlELG1CQUFtQjZELFlBQVksQ0FBQztBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUVBLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxXQUFXLG9DQUFvQ3pELE9BQU8sU0FBUyxNQUFNO0FBQUEsUUFFckU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0NBQ1pBO0FBQUFBLG9CQUNDLHVCQUFDLFVBQUssV0FBVSxnRUFBK0QsMEJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNQyxRQUFRLENBQUNELElBQUk7QUFBQSxnQkFDNUIsV0FBVyxnRkFDVCxDQUFDQSxPQUFPLFlBQVksRUFBRTtBQUFBLGdCQUd4QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLDJEQUNULENBQUNBLE9BQU8sZUFBZSxFQUFFO0FBQUE7QUFBQSxrQkFGN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdLO0FBQUE7QUFBQSxjQVRQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUdDQSxRQUNDLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU9KO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ2dHLE1BQU0vRixzQkFBc0IrRixFQUFFeUIsT0FBT0MsS0FBSztBQUFBLGtCQUNyRCxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLMk47QUFBQSxjQUUzTix1QkFBQyxtQkFBZ0IsV0FBVSx3RUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Y7QUFBQSxjQUM5RjFILHNCQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTUMsc0JBQXNCLEVBQUU7QUFBQSxrQkFDdkMsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLGlCQUFjLFdBQVUsZUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQTtBQUFBLGdCQUp0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQ0Qsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBO0FBQUEsY0FDdEM7QUFBQSxjQUNMcUgsbUJBQW1CckQ7QUFBQUEsZ0JBQ2xCLENBQUNDLEtBQUsvRixhQUFhK0YsTUFBTXVELGlCQUFpQnRKLFFBQVEsRUFBRW9KO0FBQUFBLGdCQUNwRDtBQUFBLGNBQ0Y7QUFBQSxjQUFHO0FBQUEsY0FBSTtBQUFBLGlCQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLFVBR0RELG1CQUFtQjFFLElBQUksQ0FBQ3pFLGFBQWE7QUFDcEMsa0JBQU15SixRQUFRSCxpQkFBaUJ0SixRQUFRO0FBRXZDLGdCQUFJeUosTUFBTUwsV0FBVyxLQUFLdEgsbUJBQW9CLFFBQU87QUFFckQsa0JBQU00SCxhQUFhcEgsbUJBQW1CdEMsUUFBUSxLQUFLO0FBQ25ELGtCQUFNMkosWUFBWUYsTUFBTUw7QUFDeEIsa0JBQU1RLFdBQVdwSSxtQkFBbUJ4QjtBQUdwQyxrQkFBTTZKLGVBQWUvSCxxQkFBcUIsT0FBTzRIO0FBRWpELG1CQUNFLHVCQUFDLFNBQW1CLFdBQVUsUUFDNUI7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU07QUFDYix3QkFBSXhILE1BQU07QUFFUjBCLHFDQUFlNUQsUUFBUTtBQUV2QnlCLHdDQUFrQnpCLFFBQVE7QUFBQSxvQkFDNUI7QUFBQSxrQkFDRjtBQUFBLGtCQUNBLFdBQVcsaUdBQ1Q0SixZQUFZMUgsT0FDUix3REFDQUEsT0FDRSxxQkFDQSxpQ0FBaUM7QUFBQSxrQkFHeENBLGlCQUNDLG1DQUNFO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVyxrREFDVDBILFdBQVcsa0JBQWtCLGVBQWU7QUFBQSwwQkFHN0M1SjtBQUFBQTtBQUFBQSx3QkFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXLHNDQUNUNEosV0FDSSw4QkFDQSwyQkFBMkI7QUFBQSwwQkFHaENEO0FBQUFBO0FBQUFBLHdCQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRQTtBQUFBLHlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLG9CQUNDRSxlQUNDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVcsV0FBV0QsV0FBVyxrQkFBa0IsZUFBZTtBQUFBO0FBQUEsc0JBRHBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFDdUUsSUFHdkU7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxXQUFXQSxXQUFXLGtCQUFrQixlQUFlO0FBQUE7QUFBQSxzQkFEcEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUN1RTtBQUFBLHVCQXpCM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE0QkEsSUFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLHdCQUF3QkEsV0FBVyxnQkFBZ0IsYUFBYTtBQUFBO0FBQUEsb0JBRDdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFQztBQUFBO0FBQUEsZ0JBbERMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9EQTtBQUFBLGNBRUMxSCxRQUFRMkgsZ0JBQ1AsdUJBQUMsU0FBSSxXQUFVLGtEQUNaSixnQkFBTWhGO0FBQUFBLGdCQUFJLENBQUMsRUFBRTVFLE9BQU9DLE1BQU1DLE1BQU1FLE9BQU9DLE1BQU0sTUFDNUM7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUMsSUFBSUo7QUFBQUEsb0JBQ0osU0FBUyxNQUFNO0FBQ2JnRSxrQ0FBWTtBQUNaekIscUNBQWUsQ0FBQ0QsV0FBVztBQUUzQkwsNENBQXNCLEVBQUU7QUFBQSxvQkFDMUI7QUFBQSxvQkFDQSxXQUFXLENBQUMsRUFBRTZILFVBQVVFLGFBQWEsTUFDbkMsOEVBQ0VBLGVBQ0ksdUNBQ0Esb0RBQW9EO0FBQUEsb0JBSTNELFdBQUMsRUFBRUYsVUFBVUUsYUFBYSxNQUN6QixtQ0FDRTtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQU07QUFBQSwwQkFDTixXQUFXLEdBQ1RBLGVBQWUsa0JBQWtCLGVBQWU7QUFBQTtBQUFBLHdCQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSUs7QUFBQSxzQkFFTCx1QkFBQyxVQUFLLFdBQVUsNENBQ2JqSyxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0NLLFNBQ0MsdUJBQUMsVUFBSyxXQUFVLG9IQUFtSCxtQkFBbkk7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZUE7QUFBQTtBQUFBLGtCQWhDR0o7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFtQ0E7QUFBQSxjQUNELEtBdENIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUNBO0FBQUEsaUJBL0ZNRSxVQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUdBO0FBQUEsVUFFSixDQUFDO0FBQUEsVUFHQWtDLFFBQVFKLHNCQUFzQnFILG1CQUFtQkMsV0FBVyxLQUMzRCx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsbUZBQ2IsaUNBQUMsbUJBQWdCLFdBQVUsNEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1ELEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsZ0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix5Q0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBO0FBQUE7QUFBQSxNQXZMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF5TEE7QUFBQSxFQUVKO0FBR0EsUUFBTVcsc0JBQXNCQSxNQUFNO0FBQ2hDLFVBQU1DLGlCQUFpQixDQUFDLE9BQU8sR0FBR3ZELGdCQUFnQjtBQUVsRCxXQUNFLHVCQUFDLFNBQUksV0FBVSxrREFDWnVELHlCQUFldkYsSUFBSSxDQUFDekUsYUFBYTtBQUNoQyxZQUFNaUssUUFDSmpLLGFBQWEsUUFDVHdDLE1BQU1rRCxPQUFPLENBQUMwQixNQUFNQSxFQUFFdEMsT0FBTyxFQUFFc0UsU0FDL0I1QyxhQUFheEcsUUFBUSxHQUFHb0osVUFBVTtBQUV4QyxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxTQUFTLE1BQU0zSCxrQkFBa0J6QixRQUFRO0FBQUEsVUFDekMsV0FBVyw0RkFDVHdCLG1CQUFtQnhCLFdBQ2Ysb0ZBQ0Esc0ZBQXNGO0FBQUEsVUFHM0ZBO0FBQUFBO0FBQUFBLFlBQ0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLGtCQUNUd0IsbUJBQW1CeEIsV0FDZixrQkFDQSxlQUFlO0FBQUEsZ0JBQ2xCO0FBQUE7QUFBQSxrQkFFRGlLO0FBQUFBLGtCQUFNO0FBQUE7QUFBQTtBQUFBLGNBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQTtBQUFBO0FBQUEsUUFqQktqSztBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFtQkE7QUFBQSxJQUVKLENBQUMsS0E3Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLEVBRUo7QUE0RUEsUUFBTWtLLGtCQUFrQkEsTUFBTTtBQUU5QixRQUFJMUksbUJBQW1CLE9BQU87QUFDNUIsYUFDRSx1QkFBQyxTQUFJLFdBQVUsYUFDWjJFLHNDQUE0QjFCLElBQUksQ0FBQ3pFLFVBQVVtSyxrQkFBa0I7QUFDNUQsY0FBTUMsZ0JBQWdCdkUsd0JBQXdCN0YsUUFBUTtBQUV0RCxlQUNFLHVCQUFDLFNBRUM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0dBQ1ptSywwQkFBZ0IsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxxQ0FDWG5LLHNCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVm9LO0FBQUFBLDhCQUFjaEI7QUFBQUEsZ0JBQU87QUFBQSxnQkFDckJnQixjQUFjaEIsV0FBVyxJQUFJLE1BQU07QUFBQSxtQkFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxzRkFDWmdCLHdCQUFjM0Y7QUFBQUEsWUFDYixDQUFDLEVBQUU1RSxPQUFPRSxNQUFNRCxNQUFNRyxPQUFPQyxNQUFNLE1BQ2pDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsU0FBUyxNQUFNb0YsaUJBQWlCeEYsSUFBSTtBQUFBLGdCQUNwQyxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsU0FBSSxXQUFVLCtKQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxxQkFBcUJHLEtBQUs7QUFBQSxzQkFFckM7QUFBQSwrQ0FBQyxTQUFJLFdBQVUsaUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkM7QUFBQSx3QkFFN0MsdUJBQUMsUUFBSyxXQUFVLHNEQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrRTtBQUFBLHdCQUVqRUMsU0FDQyx1QkFBQyxVQUFLLFdBQVUsK0hBQThILG1CQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUE7QUFBQTtBQUFBLG9CQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFZQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFFBQUcsV0FBVSx3SEFDWEwsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQkE7QUFBQTtBQUFBLGNBeEJLQztBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUEwQkE7QUFBQSxVQUVKLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsYUFwRFFFLFVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFEQTtBQUFBLE1BRUosQ0FBQyxLQTVESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkRBO0FBQUEsSUFFSjtBQUdBLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHNGQUNaeUYsd0JBQWNoQjtBQUFBQSxNQUFJLENBQUMsRUFBRTVFLE9BQU9FLE1BQU1ELE1BQU1HLE9BQU9DLE1BQU0sTUFDcEQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFNBQVMsTUFBTW9GLGlCQUFpQnhGLElBQUk7QUFBQSxVQUNwQyxXQUFVO0FBQUEsVUFFVixpQ0FBQyxTQUFJLFdBQVUsK0pBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcscUJBQXFCRyxLQUFLO0FBQUEsZ0JBRXJDO0FBQUEseUNBQUMsU0FBSSxXQUFVLGlDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZDO0FBQUEsa0JBRTdDLHVCQUFDLFFBQUssV0FBVSxzREFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0U7QUFBQSxrQkFFakVDLFNBQ0MsdUJBQUMsVUFBSyxXQUFVLCtIQUE4SCxtQkFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxRQUFHLFdBQVUsd0hBQ1hMLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQTtBQUFBLFFBeEJLQztBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEwQkE7QUFBQSxJQUNELEtBN0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxFQUVKO0FBcURFLFFBQU11SyxrQkFBa0JBLE1BQU07QUFDOUIsUUFBSTdJLG1CQUFtQixPQUFPO0FBQzVCLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ1oyRSxzQ0FBNEIxQixJQUFJLENBQUN6RSxVQUFVbUssa0JBQWtCO0FBQzVELGNBQU1DLGdCQUFnQnZFLHdCQUF3QjdGLFFBQVE7QUFFdEQsZUFDRSx1QkFBQyxTQUVDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtHQUNabUssMEJBQWdCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUscUNBQ1huSyxzQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1ZvSztBQUFBQSw4QkFBY2hCO0FBQUFBLGdCQUFPO0FBQUEsZ0JBQ3JCZ0IsY0FBY2hCLFdBQVcsSUFBSSxNQUFNO0FBQUEsbUJBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDWmdCLHdCQUFjM0Y7QUFBQUEsWUFDYixDQUFDLEVBQUU1RSxPQUFPRSxNQUFNRCxNQUFNRyxPQUFPQyxPQUFPTixHQUFHLE1BQ3JDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsU0FBUyxNQUFNMEYsaUJBQWlCeEYsSUFBSTtBQUFBLGdCQUNwQyxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsU0FBSSxXQUFVLCtJQUNiLGlDQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcscUJBQXFCRyxLQUFLO0FBQUEsc0JBRXJDLGlDQUFDLFFBQUssV0FBVSx3QkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0M7QUFBQTtBQUFBLG9CQUh0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2Q0FBQyxRQUFHLFdBQVUsOEZBQ1hKLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFFQ0ssU0FDQyx1QkFBQyxVQUFLLFdBQVUsa0lBQWlJLG1CQUFqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLG9CQUVBLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsNkNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWdCQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixNQUFLO0FBQUEsc0JBQ0wsUUFBTztBQUFBLHNCQUNQLFNBQVE7QUFBQSxzQkFFUjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxlQUFjO0FBQUEsMEJBQ2QsZ0JBQWU7QUFBQSwwQkFDZixhQUFhO0FBQUEsMEJBQ2IsR0FBRTtBQUFBO0FBQUEsd0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUlrQjtBQUFBO0FBQUEsb0JBVnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFZQTtBQUFBLHFCQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNDQSxLQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXdDQTtBQUFBO0FBQUEsY0E1Q0tOO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQThDQTtBQUFBLFVBRUosS0FuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvREE7QUFBQSxhQXZFUUksVUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0VBO0FBQUEsTUFFSixDQUFDLEtBL0VIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRkE7QUFBQSxJQUVKO0FBR0EsV0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDWnlGLHdCQUFjaEI7QUFBQUEsTUFBSSxDQUFDLEVBQUU1RSxPQUFPRSxNQUFNRCxNQUFNRyxPQUFPTCxJQUFJTSxNQUFNLE1BQ3hEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxTQUFTLE1BQU1vRixpQkFBaUJ4RixJQUFJO0FBQUEsVUFDcEMsV0FBVTtBQUFBLFVBRVYsaUNBQUMsU0FBSSxXQUFVLCtJQUNiLGlDQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyxxQkFBcUJHLEtBQUs7QUFBQSxnQkFFckMsaUNBQUMsUUFBSyxXQUFVLHdCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBO0FBQUEsY0FIdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw4RkFDWEosbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVDSyxTQUNDLHVCQUFDLFVBQUssV0FBVSxrSUFBaUksbUJBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FFQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQStCLDZDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsU0FBUTtBQUFBLGdCQUVSO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGVBQWM7QUFBQSxvQkFDZCxnQkFBZTtBQUFBLG9CQUNmLGFBQWE7QUFBQSxvQkFDYixHQUFFO0FBQUE7QUFBQSxrQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSWtCO0FBQUE7QUFBQSxjQVZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLGVBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0NBLEtBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0NBO0FBQUE7QUFBQSxRQTVDS047QUFBQUEsUUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BOENBO0FBQUEsSUFDRCxLQWpESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0RBO0FBQUEsRUFFSjtBQUdFLFFBQU0wSyx1QkFBdUJBLE1BQU07QUFFakMsVUFBTUMsd0JBQXdCdkksbUJBQzFCUSxNQUFNa0Q7QUFBQUEsTUFDSixDQUFDbEMsU0FDQ0EsS0FBSzNELE1BQU04RixZQUFZLEVBQUVDLFNBQVM1RCxpQkFBaUIyRCxZQUFZLENBQUMsS0FDL0RuQyxLQUFLeEQsWUFDSndELEtBQUt4RCxTQUNGMkYsWUFBWSxFQUNaQyxTQUFTNUQsaUJBQWlCMkQsWUFBWSxDQUFDO0FBQUEsSUFDaEQsSUFDQW5EO0FBRUosVUFBTWdJLG9CQUFvQixDQUFDO0FBQzNCRCwwQkFBc0JoSCxRQUFRLENBQUNDLFNBQVM7QUFDdEMsWUFBTXhELFdBQVd3RCxLQUFLeEQsWUFBWTtBQUNsQyxVQUFJLENBQUN3SyxrQkFBa0J4SyxRQUFRLEdBQUc7QUFDaEN3SywwQkFBa0J4SyxRQUFRLElBQUk7QUFBQSxNQUNoQztBQUNBd0ssd0JBQWtCeEssUUFBUSxFQUFFZ0csS0FBS3hDLElBQUk7QUFBQSxJQUN2QyxDQUFDO0FBRUR5QyxXQUFPQyxLQUFLc0UsaUJBQWlCLEVBQUVqSCxRQUFRLENBQUN2RCxhQUFhO0FBQ25Ed0ssd0JBQWtCeEssUUFBUSxFQUFFZ0Y7QUFBQUEsUUFDMUIsQ0FBQ0MsR0FBR0MsT0FBT0QsRUFBRUYsU0FBUyxNQUFNRyxFQUFFSCxTQUFTO0FBQUEsTUFDekM7QUFBQSxJQUNGLENBQUM7QUFFRCxVQUFNMEYsZ0JBQWdCeEUsT0FBT0MsS0FBS3NFLGlCQUFpQixFQUFFeEYsS0FBSyxDQUFDQyxHQUFHQyxNQUFNO0FBQ2xFLFlBQU1rQixTQUFTaEQsY0FBY2lELFFBQVFwQixDQUFDO0FBQ3RDLFlBQU1xQixTQUFTbEQsY0FBY2lELFFBQVFuQixDQUFDO0FBQ3RDLFVBQUlrQixXQUFXLE1BQU1FLFdBQVcsR0FBSSxRQUFPRixTQUFTRTtBQUNwRCxVQUFJRixXQUFXLEdBQUksUUFBTztBQUMxQixVQUFJRSxXQUFXLEdBQUksUUFBTztBQUMxQixhQUFPckIsRUFBRXNCLGNBQWNyQixDQUFDO0FBQUEsSUFDMUIsQ0FBQztBQUVELFVBQU13RixnQkFBZ0JySCxpQkFBaUI7QUFHdkMsUUFBSXJCLG9CQUFvQnlJLGNBQWNyQixXQUFXLEdBQUc7QUFDbEQsYUFDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUZBQ2IsaUNBQUMsbUJBQWdCLFdBQVUsNEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsdUNBQXNDLGdDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIseUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsSUFFSjtBQUVBLFdBQU9xQixjQUFjaEcsSUFBSSxDQUFDekUsYUFBYTtBQUNyQyxZQUFNeUosUUFBUWUsa0JBQWtCeEssUUFBUTtBQUV4QyxVQUFJeUosTUFBTUwsV0FBVyxFQUFHLFFBQU87QUFFL0IsYUFDRSx1QkFBQyxTQUFtQixXQUFVLFFBQzVCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGdFQUNYcEosc0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QnlKO0FBQUFBLGtCQUFNTDtBQUFBQSxZQUFPO0FBQUEsZUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxhQUo5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNaSyxnQkFBTWhGLElBQUksQ0FBQ2pCLE1BQU1nRSxVQUFVO0FBQzFCLGdCQUFNbUQsYUFBYTNILGFBQWE0QixNQUFNaEYsT0FBTzRELEtBQUs1RDtBQUNsRCxnQkFBTWdMLGFBQWExSCxjQUFjMEIsTUFBTWhGLE9BQU80RCxLQUFLNUQ7QUFFbkQsaUJBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDO0FBQUEsY0FDQSxhQUFhLENBQUNrSSxNQUFNRCxnQkFBZ0JDLEdBQUd0RSxNQUFNeEQsUUFBUTtBQUFBLGNBQ3JELFlBQVksQ0FBQzhILE1BQU1NLGVBQWVOLEdBQUd0RSxNQUFNeEQsUUFBUTtBQUFBLGNBQ25ELFdBQVdzSTtBQUFBQSxjQUNYLFFBQVEsQ0FBQ1IsTUFBTVMsV0FBV1QsR0FBR3RFLE1BQU14RCxRQUFRO0FBQUEsY0FDM0MsV0FBVyxzRUFDVDJLLGFBQ0ksNkRBQ0FDLGFBQ0Usc0RBQ0EsMERBQTBEO0FBQUEsY0FHbEU7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLE1BQUs7QUFBQSxzQkFDTCxTQUFRO0FBQUEsc0JBRVIsaUNBQUMsVUFBSyxHQUFFLDZNQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlOO0FBQUE7QUFBQSxvQkFMbk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSx3Q0FDWnBILGVBQUszRCxTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUseUJBQXdCO0FBQUE7QUFBQSx3QkFDOUIyRCxLQUFLdUIsU0FBU3lDO0FBQUFBLDJCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixpQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUM7QUFBQSxzQkFDekM7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsT0FBT2hFLEtBQUt4RDtBQUFBQSwwQkFDWixVQUFVLENBQUM4SCxNQUNUZCxxQkFBcUJ4RCxLQUFLNUQsSUFBSWtJLEVBQUV5QixPQUFPQyxLQUFLO0FBQUEsMEJBRTlDLFdBQVU7QUFBQSwwQkFDVixTQUFTLENBQUMxQixNQUFNQSxFQUFFK0MsZ0JBQWdCO0FBQUEsMEJBRWpDSCx3QkFBY2pHO0FBQUFBLDRCQUFJLENBQUNxRyxRQUNsQix1QkFBQyxZQUFpQixPQUFPQSxLQUN0QkEsaUJBRFVBLEtBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDBCQUNEO0FBQUE7QUFBQSx3QkFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBYUE7QUFBQSx5QkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSx1QkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF3QkE7QUFBQSxxQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQ0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUseUJBQ2J0SCxlQUFLc0IsVUFBVSxZQUFZLFlBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTdEIsS0FBS3NCO0FBQUFBLHNCQUNkLFVBQVUsQ0FBQ2lHLFlBQVk7QUFDckJ0STtBQUFBQSwwQkFBUyxDQUFDb0IsU0FDUkEsS0FBS1k7QUFBQUEsNEJBQUksQ0FBQ0csU0FDUkEsS0FBS2hGLE9BQU80RCxLQUFLNUQsS0FDYixFQUFFLEdBQUdnRixNQUFNRSxTQUFTaUcsUUFBUSxJQUM1Qm5HO0FBQUFBLDBCQUNOO0FBQUEsd0JBQ0Y7QUFBQSxzQkFDRjtBQUFBO0FBQUEsb0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVJO0FBQUEscUJBZE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQkE7QUFBQTtBQUFBO0FBQUEsWUFsRUtwQixLQUFLNUQ7QUFBQUEsWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0VBO0FBQUEsUUFFSixDQUFDLEtBNUVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2RUE7QUFBQSxXQXBGUUksVUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUZBO0FBQUEsSUFFSixDQUFDO0FBQUEsRUFDSDtBQUVBLFNBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsMkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFdBQVEsZUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDO0FBQUEsSUFHbEM7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVcsR0FBR2tDLE9BQU8sU0FBUyxNQUFNO0FBQUEsUUFFcEM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNiVCxrQ0FBa0IsS0FBSztBQUN2QkYseUJBQVMsVUFBVTtBQUNuQnVDLDRCQUFZO0FBQUEsY0FDZDtBQUFBLGNBQ0EsV0FBVyxpR0FDVDVCLE9BQ0ksOEhBQ0EscUZBQXFGO0FBQUEsY0FHM0Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXQSxPQUFPLDBCQUEwQjtBQUFBO0FBQUEsa0JBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDd0Q7QUFBQSxnQkFFdkRBLFFBQVEsdUJBQUMsVUFBSyxXQUFVLHlCQUF3Qix1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQTtBQUFBO0FBQUEsWUFmMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsVUFDQ2dILGNBQWM7QUFBQTtBQUFBO0FBQUEsTUF0QmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXVCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlFQUNaNUgsbUJBQVNxRyxhQUFhLGFBQ3JCLG1DQUVFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtDQUNiLGlDQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3RUFDYixpQ0FBQyxtQkFBZ0IsV0FBVSwyQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRCxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxhQUFZO0FBQUEsWUFDWixPQUFPL0Y7QUFBQUEsWUFDUCxVQUFVLENBQUNrRyxNQUFNakcsZUFBZWlHLEVBQUV5QixPQUFPQyxLQUFLO0FBQUEsWUFDOUMsV0FBVTtBQUFBO0FBQUEsVUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLa1A7QUFBQSxRQUVqUDVILGVBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVM4RTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWLGlDQUFDLGlCQUFjLFdBQVUsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQTtBQUFBLFVBSnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0JBQ1pxRCw4QkFBb0IsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNcEksWUFBWSxNQUFNO0FBQUEsY0FDakMsV0FBVyxpQ0FDVEQsYUFBYSxTQUNULHFDQUNBLGdFQUFnRTtBQUFBLGNBRXRFLE9BQU07QUFBQSxjQUVOLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUE7QUFBQSxZQVRuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTUMsWUFBWSxNQUFNO0FBQUEsY0FDakMsV0FBVyxpQ0FDVEQsYUFBYSxTQUNULHFDQUNBLGdFQUFnRTtBQUFBLGNBRXRFLE9BQU07QUFBQSxjQUVOLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUE7QUFBQSxZQVRuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTW1CLGVBQWUsSUFBSTtBQUFBLGNBRWxDLGlDQUFDLFVBQUssV0FBVSw2QkFDZDtBQUFBLHVDQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQjtBQUFBLGdCQUFHO0FBQUEsbUJBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQTtBQUFBLFlBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsV0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsUUFDakM0QyxjQUFjMkQ7QUFBQUEsUUFBTztBQUFBLFFBQzdCM0QsY0FBYzJELFdBQVcsSUFBSSxNQUFNO0FBQUEsUUFDbkN4SCxlQUFlLFNBQVNBLFdBQVc7QUFBQSxRQUNuQ0osbUJBQW1CLFNBQVMsT0FBT0EsY0FBYztBQUFBLFdBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BR0NzQixZQUNDLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxTQUFJLFdBQVUsdUZBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRyxLQURyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFDRTJDLGNBQWMyRCxXQUFXLElBQzNCLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtRkFDYixpQ0FBQyxtQkFBZ0IsV0FBVSw0QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsZ0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLHlCQUNWNUgsNkJBQW1CLFFBQ2hCLHdCQUF3QkEsY0FBYyxlQUN0QyxrREFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQSxJQUNFRSxhQUFhLFNBQ2Z3SSxnQkFBZ0IsSUFFaEJHLGdCQUFnQjtBQUFBLFNBL0ZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUdBLElBRUEsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FyR1g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVHQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsY0FBVyxXQUFVLGlCQUFnQixNQUFNLE1BQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFDL0MsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQiw4QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxVQUFLLFdBQVUsMENBQXlDLDhDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUVGLE1BQU16SDtBQUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkQyx5QkFBZSxLQUFLO0FBQ3BCWiw4QkFBb0IsRUFBRTtBQUFBLFFBQ3hCO0FBQUEsUUFDQSxRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxXQUFVO0FBQUEsUUFHVjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMEVBQ2IsaUNBQUMsbUJBQWdCLFdBQVUsNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9ELEtBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osT0FBT0Q7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDOEYsTUFBTTdGLG9CQUFvQjZGLEVBQUV5QixPQUFPQyxLQUFLO0FBQUEsa0JBQ25ELFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUsrTjtBQUFBLGNBRTlOeEgsb0JBQ0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUzJFO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUE7QUFBQSxnQkFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxZQUNDM0Usb0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBO0FBQUEsY0FDdEM7QUFBQSxjQUVKUSxNQUFNa0Q7QUFBQUEsZ0JBQ0osQ0FBQ2xDLFNBQ0NBLEtBQUszRCxNQUNGOEYsWUFBWSxFQUNaQyxTQUFTNUQsaUJBQWlCMkQsWUFBWSxDQUFDLEtBQ3pDbkMsS0FBS3hELFlBQ0p3RCxLQUFLeEQsU0FDRjJGLFlBQVksRUFDWkMsU0FBUzVELGlCQUFpQjJELFlBQVksQ0FBQztBQUFBLGNBQ2hELEVBQUV5RDtBQUFBQSxjQUNGO0FBQUEsY0FBSTtBQUFBLGNBRUw1RyxNQUFNa0Q7QUFBQUEsZ0JBQ0wsQ0FBQ2xDLFNBQ0NBLEtBQUszRCxNQUNGOEYsWUFBWSxFQUNaQyxTQUFTNUQsaUJBQWlCMkQsWUFBWSxDQUFDLEtBQ3pDbkMsS0FBS3hELFlBQ0p3RCxLQUFLeEQsU0FDRjJGLFlBQVksRUFDWkMsU0FBUzVELGlCQUFpQjJELFlBQVksQ0FBQztBQUFBLGNBQ2hELEVBQUV5RCxXQUFXLElBQ1QsTUFDQTtBQUFBLGNBQUk7QUFBQSxjQUFJO0FBQUEsY0FDRHBIO0FBQUFBLGNBQWlCO0FBQUEsaUJBM0I5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLGVBbERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0RBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDJCQUNYO0FBQUEscUNBQUMsU0FBSSxXQUFVLHlCQUF3QixNQUFLLGdCQUFlLFNBQVEsYUFDakU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsVUFBUztBQUFBLGtCQUNULEdBQUU7QUFBQSxrQkFDRixVQUFTO0FBQUE7QUFBQSxnQkFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHb0IsS0FKdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGNBQ0EsdUJBQUMsVUFDQztBQUFBLHVDQUFDLFlBQU8sb0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBLGdCQUFTO0FBQUEsbUJBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQ1gsaUNBQUMsVUFBSztBQUFBO0FBQUEsY0FDSSx1QkFBQyxZQUFPLHdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdCO0FBQUEsY0FBUztBQUFBLGlCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsK0NBQ1pzSSwrQkFBcUIsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUyxNQUFNO0FBQ2J6SCxpQ0FBZSxLQUFLO0FBQ3BCWixzQ0FBb0IsRUFBRTtBQUFBLGdCQUN4QjtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFTMkU7QUFBQUEsZ0JBQ1QsVUFBVWxFO0FBQUFBLGdCQUVUQSxtQkFDQyx1QkFBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsc0ZBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1HO0FBQUEsa0JBQU87QUFBQSxxQkFENUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQSxJQUVBO0FBQUE7QUFBQSxjQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQTtBQUFBO0FBQUEsTUE3SEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOEhBO0FBQUEsT0F2UUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdRQTtBQUVGO0FBQUVyQixHQWowQ0lELFNBQU87QUFBQSxVQUNNNUcsYUFDQUMsV0FBVztBQUFBO0FBQUF1USxLQUZ4QjVKO0FBbTBDTixlQUFlQTtBQUFRLElBQUE0SjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiU2lkZWJhciIsIk5hdmJhciIsIk5hdkxpbmsiLCJPdXRsZXQiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwiTWRPdXRsaW5lQmxvY2siLCJNZE91dGxpbmVQZW5kaW5nQWN0aW9ucyIsIk1kR2F2ZWwiLCJNZE91dGxpbmVFbW9qaVBlb3BsZSIsIk1kQ2FsZW5kYXJNb250aCIsIk1kR3JvdXBzIiwiTWRPdXRsaW5lUmVjZWlwdExvbmciLCJNZE1hbiIsIlRiVXNlclBhdXNlIiwiVGJDb2lucyIsIkJpSGlzdG9yeSIsIkhpT3V0bGluZUJhbmtub3RlcyIsIkJzQXJyb3dMZWZ0U2hvcnQiLCJCc0NoZXZyb25Eb3duIiwiQnNDaGV2cm9uUmlnaHQiLCJUYkRldmljZU1vYmlsZVNlYXJjaCIsIlRpQ2FuY2VsIiwiRmFDYWxlbmRhckRheXMiLCJGYVBlb3BsZUdyb3VwIiwiRmFQZW9wbGVBcnJvd3MiLCJUYlVzZXJDYW5jZWwiLCJNb2RhbCIsIkJ1dHRvbiIsIm1lc3NhZ2UiLCJTd2l0Y2giLCJTZWxlY3QiLCJGYVBlcnNvbldhbGtpbmdBcnJvd0xvb3BMZWZ0IiwiUmlHcm91cExpbmUiLCJSaUF1Y3Rpb25GaWxsIiwiRmlDaGV2cm9uTGVmdCIsIkZpU2V0dGluZ3MiLCJNZE91dGxpbmVQYXltZW50cyIsIkxpYUNhbGN1bGF0b3JTb2xpZCIsIkdpUGF5TW9uZXkiLCJHaVJlY2VpdmVNb25leSIsIkdpTW9uZXlTdGFjayIsIlRiUmVwb3J0U2VhcmNoIiwiTWRPdXRsaW5lUGF5bWVudCIsIlNsQ2FsZW5kZXIiLCJSaVJlY2VpcHRMaW5lIiwidXNlUmVmIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJCaUdyaWQiLCJUYkxpc3QiLCJCc0NhbGVuZGFyRGF0ZSIsIlRiR3JhcGgiLCJUYkdyYXBoRmlsbGVkIiwiSW9TZWFyY2hPdXRsaW5lIiwiSW9DbG9zZUNpcmNsZSIsIk1kQ2FuY2VsIiwiQnNDYWxjdWxhdG9yIiwiTGlhUGVvcGxlQ2FycnlTb2xpZCIsIk1kUGVyc29uT2ZmIiwiRmFVc2VycyIsIkZhVXNlckZyaWVuZHMiLCJGYVVzZXJUaWUiLCJGYVVzZXJDaGVjayIsIkZhQXdhcmQiLCJGYVBpZ2d5QmFuayIsIkZhTW9uZXlCaWxsV2F2ZSIsIkZhTW9uZXlDaGVja0FsdCIsIkZhQ2hhcnRMaW5lIiwiRmFXYWxsZXQiLCJGYUJvb2tPcGVuIiwiRmFNYXBNYXJrZWRBbHQiLCJGYUNsaXBib2FyZExpc3QiLCJGYUhhbmRIb2xkaW5nVXNkIiwiRmFDaGVja0NpcmNsZSIsIkZhTW9iaWxlQWx0IiwiRmFDYWxlbmRhckNoZWNrIiwiRmFSb3V0ZSIsIkZhVHJvcGh5IiwiRmFDaGFydEJhciIsIlBpTW9uZXlEdW90b25lIiwiVGZpR2lmdCIsIkZpQXdhcmQiLCJHaVRob3JIYW1tZXIiLCJDaUJhbmsiLCJJb0Nhc2hPdXRsaW5lIiwiYXBpIiwic3ViTWVudXMiLCJpZCIsInRpdGxlIiwibGluayIsIkljb24iLCJjYXRlZ29yeSIsImNvbG9yIiwiaXNOZXciLCJjYXRlZ29yaWVzIiwiY2F0ZWdvcnlDb2xvcnMiLCJDdXN0b21lciIsIlBheW1lbnRzIiwiTG9hbiIsIlBpZ215IiwiQXVjdGlvbiIsIkVtcGxveWVlIiwiQ29sbGVjdGlvbiIsIkxlYWQiLCJHcm91cCIsIlNhbGVzIiwiQWdlbnQiLCJJbmNlbnRpdmUiLCJNb2JpbGUiLCJGaW5hbmNlIiwiQ2hpdCIsIlJlcG9ydHMiLCJfcyIsImxvY2F0aW9uIiwibmF2aWdhdGUiLCJhY3RpdmVDYXRlZ29yeSIsInNldEFjdGl2ZUNhdGVnb3J5Iiwidmlld1R5cGUiLCJzZXRWaWV3VHlwZSIsInNlYXJjaFF1ZXJ5Iiwic2V0U2VhcmNoUXVlcnkiLCJzaWRlYmFyU2VhcmNoUXVlcnkiLCJzZXRTaWRlYmFyU2VhcmNoUXVlcnkiLCJtb2RhbFNlYXJjaFF1ZXJ5Iiwic2V0TW9kYWxTZWFyY2hRdWVyeSIsIm9wZW4iLCJzZXRPcGVuIiwiaGlkZVNpZGViYXIiLCJzZXRIaWRlU2lkZWJhciIsImV4cGFuZGVkQ2F0ZWdvcmllcyIsInNldEV4cGFuZGVkQ2F0ZWdvcmllcyIsIm1lbnVzIiwic2V0TWVudXMiLCJzYXZpbmciLCJzZXRTYXZpbmciLCJtYW5hZ2VNb2RhbCIsInNldE1hbmFnZU1vZGFsIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZHJhZ2dlZEl0ZW0iLCJzZXREcmFnZ2VkSXRlbSIsImRyYWdPdmVySXRlbSIsInNldERyYWdPdmVySXRlbSIsImNhdGVnb3J5T3JkZXIiLCJnZXRBbGxDYXRlZ29yaWVzIiwiU2V0IiwiZm9yRWFjaCIsIm1lbnUiLCJhZGQiLCJBcnJheSIsImZyb20iLCJ0b2dnbGVDYXRlZ29yeSIsInByZXYiLCJzY3JvbGxUb1RvcCIsIndpbmRvdyIsInNjcm9sbFRvIiwidG9wIiwiYmVoYXZpb3IiLCJmZXRjaFJlcG9ydHMiLCJyZXNwb25zZSIsImdldCIsInZpc2liaWxpdHkiLCJkYXRhIiwiZmluYWxNZW51cyIsIm1hcCIsImRiTWVudSIsImZpbmQiLCJpdGVtIiwicmVwb3J0SWQiLCJ2aXNpYmxlIiwib3JkZXIiLCJzb3J0IiwiYSIsImIiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJoYW5kbGVOYXZpZ2F0aW9uIiwic2V0VGltZW91dCIsInJlZiIsImZpbHRlcmVkTWVudXMiLCJmaWx0ZXIiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiYWxsRmlsdGVyZWRHcm91cGVkTWVudXMiLCJyZWR1Y2UiLCJhY2MiLCJwdXNoIiwiT2JqZWN0Iiwia2V5cyIsInNvcnRlZEFsbEZpbHRlcmVkQ2F0ZWdvcmllcyIsImluZGV4QSIsImluZGV4T2YiLCJpbmRleEIiLCJsb2NhbGVDb21wYXJlIiwiZ3JvdXBlZE1lbnVzIiwic29ydGVkQ2F0ZWdvcmllcyIsImhhbmRsZUNsZWFyU2VhcmNoIiwiaGFuZGxlQ2xlYXJNb2RhbFNlYXJjaCIsInNhdmVSZXBvcnRzIiwicHV0IiwicmVwb3J0cyIsInN1Y2Nlc3MiLCJoYW5kbGVDYXRlZ29yeUNoYW5nZSIsIm1lbnVJZCIsIm5ld0NhdGVnb3J5IiwibWVudVRvTW92ZSIsIm0iLCJvbGRDYXRlZ29yeSIsInVwZGF0ZWRNZW51cyIsIml0ZW1zSW5OZXdDYXRlZ29yeSIsImluZGV4IiwiZm91bmRJdGVtIiwiaXRlbXNJbk9sZENhdGVnb3J5IiwicGF0aG5hbWUiLCJzdGFydHNXaXRoIiwiaGFuZGxlRHJhZ1N0YXJ0IiwiZSIsImRhdGFUcmFuc2ZlciIsImVmZmVjdEFsbG93ZWQiLCJzZXREYXRhIiwiSlNPTiIsInN0cmluZ2lmeSIsImhhbmRsZURyYWdPdmVyIiwicHJldmVudERlZmF1bHQiLCJoYW5kbGVEcmFnRW5kIiwiaGFuZGxlRHJvcCIsInRhcmdldEl0ZW0iLCJ0YXJnZXRDYXRlZ29yeSIsInNvdXJjZUl0ZW0iLCJzb3VyY2VJbmRleCIsImZpbmRJbmRleCIsInRhcmdldEluZGV4IiwibmV3TWVudXMiLCJyZW1vdmVkIiwic3BsaWNlIiwiY2F0ZWdvcnlJdGVtcyIsInJlbmRlclNpZGViYXIiLCJmaWx0ZXJlZENhdGVnb3JpZXMiLCJsZW5ndGgiLCJzb21lIiwiZ2V0RmlsdGVyZWRJdGVtcyIsInRhcmdldCIsInZhbHVlIiwiaXRlbXMiLCJpc0V4cGFuZGVkIiwiaXRlbUNvdW50IiwiaXNBY3RpdmUiLCJzaG91bGRFeHBhbmQiLCJpc0xpbmtBY3RpdmUiLCJyZW5kZXJDYXRlZ29yeUNoaXBzIiwiY2hpcENhdGVnb3JpZXMiLCJjb3VudCIsInJlbmRlckdyaWRDYXJkcyIsImNhdGVnb3J5SW5kZXgiLCJjYXRlZ29yeU1lbnVzIiwicmVuZGVyTGlzdEl0ZW1zIiwicmVuZGVyRHJhZ2dhYmxlSXRlbXMiLCJmaWx0ZXJlZE1lbnVzRm9yTW9kYWwiLCJncm91cGVkQnlDYXRlZ29yeSIsInNvcnRlZENhdEtleXMiLCJhbGxDYXRlZ29yaWVzIiwiaXNEcmFnZ2luZyIsImlzRHJhZ092ZXIiLCJzdG9wUHJvcGFnYXRpb24iLCJjYXQiLCJjaGVja2VkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVwb3J0cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbi8vIGltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuLy8gaW1wb3J0IHsgTmF2TGluaywgT3V0bGV0LCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG4vLyBpbXBvcnQgeyBNZEhpc3RvcnksIE1kT3V0bGluZVBlbmRpbmcgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuLy8gaW1wb3J0IHsgVGJNb25leWJhZyB9IGZyb20gXCJyZWFjdC1pY29ucy90YlwiO1xyXG4vLyBpbXBvcnQgeyBIaU91dGxpbmVCYW5rbm90ZXMgfSBmcm9tIFwicmVhY3QtaWNvbnMvaGkyXCI7XHJcbi8vIGltcG9ydCB7IEJzQXJyb3dMZWZ0U2hvcnQsIEJzQ2hldnJvbkRvd24gfSBmcm9tIFwicmVhY3QtaWNvbnMvYnNcIjtcclxuLy8gaW1wb3J0IHsgVGJEZXZpY2VNb2JpbGVTZWFyY2ggfSBmcm9tIFwicmVhY3QtaWNvbnMvdGJcIjtcclxuLy8gaW1wb3J0IHsgVGlDYW5jZWwgfSBmcm9tIFwicmVhY3QtaWNvbnMvdGlcIjtcclxuLy8gaW1wb3J0IHtcclxuLy8gICBGYUNhbGVuZGFyRGF5cyxcclxuLy8gICBGYVBlb3BsZUdyb3VwLFxyXG4vLyAgIEZhUGVvcGxlQXJyb3dzLFxyXG4vLyAgIEZhVXNlckNoZWNrLFxyXG4vLyAgIEZhVXNlclRpZSxcclxuLy8gfSBmcm9tIFwicmVhY3QtaWNvbnMvZmE2XCI7XHJcbi8vIGltcG9ydCB7IFRiVXNlckNhbmNlbCB9IGZyb20gXCJyZWFjdC1pY29ucy90YlwiO1xyXG4vLyBpbXBvcnQge1xyXG4vLyAgIE1kT3V0bGluZUVtb2ppUGVvcGxlLFxyXG4vLyAgIE1kT3V0bGluZVJlY2VpcHRMb25nLFxyXG4vLyAgIE1kTWFuLFxyXG4vLyB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG4vLyBpbXBvcnQgeyBNZENhbGVuZGFyTW9udGgsTWRHcm91cHMgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuLy8gaW1wb3J0IHsgRmFQZXJzb25XYWxraW5nQXJyb3dMb29wTGVmdCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYTZcIjtcclxuLy8gaW1wb3J0IHsgUmlNb25leVJ1cGVlQ2lyY2xlRmlsbCwgUmlBdWN0aW9uRmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9yaVwiO1xyXG4vLyBpbXBvcnQgeyBGaUNoZXZyb25MZWZ0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbi8vIGltcG9ydCB7IE1kT3V0bGluZVBheW1lbnRzIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbi8vIGltcG9ydCB7IExpYUNhbGN1bGF0b3JTb2xpZCB9IGZyb20gXCJyZWFjdC1pY29ucy9saWFcIjtcclxuLy8gaW1wb3J0IHsgR2lNb25leVN0YWNrIH0gZnJvbSBcInJlYWN0LWljb25zL2dpXCI7XHJcbi8vIGltcG9ydCB7IFRiUmVwb3J0U2VhcmNoIH0gZnJvbSBcInJlYWN0LWljb25zL3RiXCI7XHJcbi8vIGltcG9ydCB7IE1kT3V0bGluZVBheW1lbnQgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuLy8gaW1wb3J0IHsgU2xDYWxlbmRlciB9IGZyb20gXCJyZWFjdC1pY29ucy9zbFwiO1xyXG4vLyBpbXBvcnQgeyBSaVJlY2VpcHRMaW5lIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbi8vIGltcG9ydCB7IHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuLy8gaW1wb3J0IHsgQmlHcmlkIH0gZnJvbSBcInJlYWN0LWljb25zL2JpXCI7XHJcbi8vIGltcG9ydCB7IFRiTGlzdCB9IGZyb20gXCJyZWFjdC1pY29ucy90YlwiO1xyXG4vLyBpbXBvcnQgeyBCc0NhbGVuZGFyRGF0ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9ic1wiO1xyXG4vLyBpbXBvcnQgeyBUYkdyYXBoIH0gZnJvbSBcInJlYWN0LWljb25zL3RiXCI7XHJcbi8vIGltcG9ydCB7IFRiR3JhcGhGaWxsZWQgfSBmcm9tIFwicmVhY3QtaWNvbnMvdGJcIjtcclxuLy8gaW1wb3J0IHsgSW9TZWFyY2hPdXRsaW5lIH0gZnJvbSBcInJlYWN0LWljb25zL2lvNVwiO1xyXG4vLyBpbXBvcnQgeyBJb0Nsb3NlQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvNVwiO1xyXG4vLyBpbXBvcnQgeyBNZENhbmNlbCB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG4vLyBpbXBvcnQgeyBCc0NhbGN1bGF0b3IgfSBmcm9tIFwicmVhY3QtaWNvbnMvYnNcIjtcclxuLy8gaW1wb3J0IHsgTGlhUGVvcGxlQ2FycnlTb2xpZCB9IGZyb20gXCJyZWFjdC1pY29ucy9saWFcIjtcclxuLy8gaW1wb3J0IHsgTWRQZXJzb25PZmYgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuLy8gaW1wb3J0IHsgRmFNb2JpbGVBbHQgLEZhSGFuZEhvbGRpbmdVc2QsIEZhUGlnZ3lCYW5rICxGYU1vbmV5QmlsbFdhdmUsIEZhQ2hhcnRCYXIsIEZhTW9uZXlDaGVja0FsdCwgRmFUcm9waHkgLEZhRXhjbGFtYXRpb25UcmlhbmdsZX0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbi8vIGltcG9ydCB7IFBpTW9uZXlEdW90b25lIH0gZnJvbSBcInJlYWN0LWljb25zL3BpXCI7XHJcbi8vIGltcG9ydCB7IFRmaUdpZnQgfSBmcm9tIFwicmVhY3QtaWNvbnMvdGZpXCI7XHJcbi8vIGltcG9ydCB7IEZpQXdhcmQgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuLy8gaW1wb3J0IHsgR2lUaG9ySGFtbWVyIH0gZnJvbSBcInJlYWN0LWljb25zL2dpXCI7XHJcbi8vIGltcG9ydCB7IENpQmFuayB9IGZyb20gXCJyZWFjdC1pY29ucy9jaVwiO1xyXG4vLyBpbXBvcnQgeyBJb0Nhc2hPdXRsaW5lIH0gZnJvbSBcInJlYWN0LWljb25zL2lvNVwiO1xyXG4vLyBjb25zdCBzdWJNZW51cyA9IFtcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIxXCIsXHJcbi8vICAgICB0aXRsZTogXCJEYXlib29rXCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL2RheWJvb2tcIixcclxuLy8gICAgIEljb246IEZhQ2FsZW5kYXJEYXlzLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiUGF5bWVudHNcIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIC8vIHtcclxuLy8gICAvLyAgICBpZDpcIjJcIixcclxuLy8gICAvLyAgIHRpdGxlOiBcIlJlY2VpcHQgUmVwb3J0XCIsXHJcbi8vICAgLy8gICBsaW5rOiBcIi9yZXBvcnRzL3JlY2VpcHRcIixcclxuLy8gICAvLyAgIEljb246IE1kT3V0bGluZVJlY2VpcHRMb25nLFxyXG4vLyAgIC8vICAgY2F0ZWdvcnk6IFwiUGF5bWVudHNcIixcclxuLy8gICAvLyAgIGNvbG9yOiBcImZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4vLyAgIC8vIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiMlwiLFxyXG4vLyAgICAgdGl0bGU6IFwiUmVjZWlwdCBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvcmVjZWlwdC1yZXBvcnRcIixcclxuLy8gICAgIEljb246IE1kT3V0bGluZVBheW1lbnRzLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiUGF5bWVudHNcIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20teWVsbG93LTUwMCB0by1waW5rLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiM1wiLFxyXG4vLyAgICAgdGl0bGU6IFwiR3JvdXAgUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL2dyb3VwLXJlcG9ydFwiLFxyXG4vLyAgICAgSWNvbjogRmFQZW9wbGVHcm91cCxcclxuLy8gICAgIGNhdGVnb3J5OiBcIkdyb3VwXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLXB1cnBsZS01MDAgdG8tcHVycGxlLTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiNFwiLFxyXG4vLyAgICAgdGl0bGU6IFwiRW5yb2xsbWVudCBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvZW5yb2xsbWVudC1yZXBvcnRcIixcclxuLy8gICAgIEljb246IEZhUGVvcGxlQXJyb3dzLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiQ3VzdG9tZXJcIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20tY3lhbi01MDAgdG8tY3lhbi02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjVcIixcclxuLy8gICAgIHRpdGxlOiBcIkFsbCBDdXN0b21lciBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvYWxsLXVzZXItcmVwb3J0XCIsXHJcbi8vICAgICBJY29uOiBGYVBlcnNvbldhbGtpbmdBcnJvd0xvb3BMZWZ0LFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiQ3VzdG9tZXJcIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20tdGVhbC01MDAgdG8tdGVhbC02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjZcIixcclxuLy8gICAgIHRpdGxlOiBcIkN1c3RvbWVyIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy91c2VyLXJlcG9ydFwiLFxyXG4vLyAgICAgSWNvbjogTWRPdXRsaW5lRW1vamlQZW9wbGUsXHJcbi8vICAgICBjYXRlZ29yeTogXCJDdXN0b21lclwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1jeWFuLTUwMCB0by1jeWFuLTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiN1wiLFxyXG4vLyAgICAgdGl0bGU6IFwiSW4gQWN0aXZlIEN1c3RvbWVyIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9pbmFjdGl2ZS11c2VyLXJlcG9ydFwiLFxyXG4vLyAgICAgSWNvbjogVGlDYW5jZWwsXHJcbi8vICAgICBjYXRlZ29yeTogXCJDdXN0b21lclwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1jeWFuLTUwMCB0by1jeWFuLTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiNDdcIixcclxuLy8gICAgIHRpdGxlOlwiU3VzcGVuZGVkIEN1c3RvbWVyIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9zdXNwZW5kLXJlcG9ydFwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiY3VzdG9tZXJcIixcclxuLy8gICAgICBJY29uOiBGYUV4Y2xhbWF0aW9uVHJpYW5nbGUsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgICBpc05ldzogdHJ1ZSxcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjhcIixcclxuLy8gICAgIHRpdGxlOiBcIkxvYW4gU3VtbWFyeSBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvY3VzdG9tZXItbG9hbi1yZXBvcnRcIixcclxuLy8gICAgIEljb246IENpQmFuayxcclxuLy8gICAgIGNhdGVnb3J5OiBcIkxvYW5cIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20tY3lhbi01MDAgdG8tY3lhbi02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjlcIixcclxuLy8gICAgIHRpdGxlOiBcIk91dFN0YW5kaW5nIExvYW4gUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL2xvYW4tZHVlLXJlcG9ydFwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiTG9hblwiLFxyXG4vLyAgICAgSWNvbjogR2lNb25leVN0YWNrLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiMTBcIixcclxuLy8gICAgIHRpdGxlOiBcIiBMb2FuIFBheW91dCBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvbG9hbi1wYXlvdXQtcmVwb3J0XCIsXHJcbi8vICAgICBjYXRlZ29yeTogXCJMb2FuXCIsXHJcbi8vICAgICBJY29uOiBGYU1vbmV5Q2hlY2tBbHQsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgICBpc05ldzogZmFsc2UsXHJcbi8vICAgfSxcclxuLy8gICAge1xyXG4vLyAgICAgaWQ6IFwiMTFcIixcclxuLy8gICAgIHRpdGxlOiBcIiBUcmFuc2FjdGlvbiBIaXN0b3J5XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL3RyYW5zYWN0aW9uLWhpc3RvcnlcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkxvYW5cIixcclxuLy8gICAgIEljb246IE1kSGlzdG9yeSxcclxuLy8gICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuLy8gICAgIGlzTmV3OiBmYWxzZSxcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjEyXCIsXHJcbi8vICAgICB0aXRsZTogXCJMb2FuIENvbXBsZXRpb24gUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL2xvYW4tY29tcGxldGlvbi1yZXBvcnRcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkxvYW5cIixcclxuLy8gICAgIEljb246IElvQ2FzaE91dGxpbmUsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgICBpc05ldzogZmFsc2UsXHJcbi8vICAgfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIxM1wiLFxyXG4vLyAgICAgdGl0bGU6IFwiUGlnbXkgU3VtbWFyeSBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvcGlnbXktc3VtbWFyeS1yZXBvcnRcIixcclxuLy8gICAgIEljb246IEJzQ2FsY3VsYXRvcixcclxuLy8gICAgIGNhdGVnb3J5OiBcIlBpZ215XCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIxNFwiLFxyXG4vLyAgICAgdGl0bGU6IFwiSG9sZGVkIEN1c3RvbWVyc1wiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9ob2xkZWQtY3VzdG9tZXItcmVwb3J0XCIsXHJcbi8vICAgICBJY29uOiBUYlVzZXJDYW5jZWwsXHJcbi8vICAgICBjYXRlZ29yeTogXCJDdXN0b21lclwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1yZWQtNTAwIHRvLXJlZC02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjE1XCIsXHJcbi8vICAgICB0aXRsZTogXCJDb2xsZWN0aW9uIEV4ZWN1dGl2ZSBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvY29sbGVjdGlvbi1leGVjdXRpdmVcIixcclxuLy8gICAgIEljb246IFRiTW9uZXliYWcsXHJcbi8vICAgICBjYXRlZ29yeTogXCJGaW5hbmNlXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWdyZWVuLTUwMCB0by1ncmVlbi02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgICB7XHJcbi8vICAgICBpZDogXCIxNlwiLFxyXG4vLyAgICAgdGl0bGU6IFwiQ29sbGVjdGlvbiBFeGVjdXRpdmUgU3VtbWFyeSBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvY29sbGVjdGlvbi1leGVjdXRpdmUtc3VtbWFyeVwiLFxyXG4vLyAgICAgSWNvbjogVGJNb25leWJhZyxcclxuLy8gICAgIGNhdGVnb3J5OiBcIkZpbmFuY2VcIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiMTdcIixcclxuLy8gICAgIHRpdGxlOiBcIkNvbGxlY3Rpb24gQXJlYSBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvY29sbGVjdGlvbi1hcmVhLXJlcG9ydFwiLFxyXG4vLyAgICAgSWNvbjogVGJNb25leWJhZyxcclxuLy8gICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWdyZWVuLTUwMCB0by1ncmVlbi02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjE4XCIsXHJcbi8vICAgICB0aXRsZTogXCJFbXBsb3llZSBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvZW1wbG95ZWUtcmVwb3J0XCIsXHJcbi8vICAgICBJY29uOiBGYVVzZXJUaWUsXHJcbi8vICAgICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1pbmRpZ28tNTAwIHRvLWluZGlnby02MDBcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIxOVwiLFxyXG4vLyAgICAgdGl0bGU6IFwiUmVnaXN0cmF0aW9uIFJlY2VpcHRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvcmVnaXN0cmF0aW9uLWZlZS1yZWNlaXB0XCIsXHJcbi8vICAgICBJY29uOiBSaVJlY2VpcHRMaW5lLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiRmluYW5jZVwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1lbWVyYWxkLTUwMCB0by1lbWVyYWxkLTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAgLy8ge1xyXG4vLyAgIC8vICAgaWQ6XCIxNFwiLFxyXG4vLyAgIC8vICAgdGl0bGU6IFwiUGF5T3V0IFJlcG9ydFwiLFxyXG4vLyAgIC8vICAgbGluazogXCIvcmVwb3J0cy9wYXlvdXRcIixcclxuLy8gICAvLyAgIEljb246IE1kT3V0bGluZVBheW1lbnQsXHJcbi8vICAgLy8gICBjYXRlZ29yeTogXCJGaW5hbmNlXCIsXHJcbi8vICAgLy8gICBjb2xvcjogXCJmcm9tLWdyZWVuLTUwMCB0by1ncmVlbi02MDBcIixcclxuLy8gICAvLyB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjIwXCIsXHJcbi8vICAgICB0aXRsZTogXCJPdXRzdGFuZGluZyBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvb3V0c3RhbmRpbmctcmVwb3J0XCIsXHJcbi8vICAgICBJY29uOiBNZE91dGxpbmVQZW5kaW5nLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiRmluYW5jZVwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1vcmFuZ2UtNTAwIHRvLW9yYW5nZS02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIC8vIHtcclxuLy8gICAvLyAgICBpZDpcIjE2XCIsXHJcbi8vICAgLy8gICB0aXRsZTogXCJBdWN0aW9uIFJlcG9ydFwiLFxyXG4vLyAgIC8vICAgbGluazogXCIvcmVwb3J0cy9hdWN0aW9uLXJlcG9ydFwiLFxyXG4vLyAgIC8vICAgSWNvbjogR2lUaG9ySGFtbWVyLFxyXG4vLyAgIC8vICAgY2F0ZWdvcnk6IFwiQXVjdGlvblwiLFxyXG4vLyAgIC8vICAgY29sb3I6IFwiZnJvbS1waW5rLTUwMCB0by1waW5rLTYwMFwiLFxyXG4vLyAgIC8vIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiMjFcIixcclxuLy8gICAgIHRpdGxlOiBcIkF1Y3Rpb24gRmlsdGVyIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9hdWN0aW9uLWZpbHRlci1yZXBvcnRcIixcclxuLy8gICAgIEljb246IFJpQXVjdGlvbkZpbGwsXHJcbi8vICAgICBjYXRlZ29yeTogXCJBdWN0aW9uXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLXBpbmstNTAwIHRvLXBpbmstNjAwXCIsXHJcbi8vICAgfSxcclxuXHJcbi8vICAgLy9zYW5qYXlcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIyMlwiLFxyXG4vLyAgICAgdGl0bGU6IFwiQmlkIFJlcXVlc3QgUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL2JpZC1yZXF1ZXN0LXJlcG9ydFwiLFxyXG4vLyAgICAgSWNvbjogUmlBdWN0aW9uRmlsbCxcclxuLy8gICAgIGNhdGVnb3J5OiBcIkF1Y3Rpb25cIixcclxuLy8gICAgIGNvbG9yOiBcImZyb20tcm9zZS01MDAgdG8tcGluay02MDBcIixcclxuLy8gICAgIGlzTmV3OiBmYWxzZSxcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIyM1wiLFxyXG4vLyAgICAgdGl0bGU6IFwiUHJpemVkIEN1c3RvbWVyIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9wcml6ZWQtY3VzdG9tZXItcmVwb3J0XCIsXHJcbi8vICAgICBJY29uOiBGaUF3YXJkLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiQXVjdGlvblwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1waW5rLTUwMCB0by1waW5rLTYwMFwiLFxyXG4vLyAgIH0sXHJcblxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjI0XCIsXHJcbi8vICAgICB0aXRsZTogXCJBbGwgTGVhZCBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvbGVhZC1yZXBvcnRcIixcclxuLy8gICAgIEljb246IE1kTWFuLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiTGVhZFwiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1wdXJwbGUtNTAwIHRvLXB1cnBsZS02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjI1XCIsXHJcbi8vICAgICB0aXRsZTogXCJOb24gQ29udmVydGVkIExlYWQgUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL25vbi1jb252ZXJ0ZWQtbGVhZC1yZXBvcnRcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkxlYWRcIixcclxuLy8gICAgIEljb246IE1kUGVyc29uT2ZmLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiMjZcIixcclxuLy8gICAgIHRpdGxlOiBcIkNvbnZlcnRlZCBMZWFkIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9jb252ZXJ0ZWQtbGVhZC1yZXBvcnRcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkxlYWRcIixcclxuLy8gICAgIEljb246IExpYVBlb3BsZUNhcnJ5U29saWQsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgfSxcclxuLy8gICAvLyB7XHJcbi8vICAgLy8gICAgaWQ6XCIxOFwiLFxyXG4vLyAgIC8vICAgdGl0bGU6IFwiUGlnbXkgUmVwb3J0XCIsXHJcbi8vICAgLy8gICBsaW5rOiBcIi9yZXBvcnRzL3BpZ21lLXJlcG9ydFwiLFxyXG4vLyAgIC8vICAgSWNvbjogTGlhQ2FsY3VsYXRvclNvbGlkLFxyXG4vLyAgIC8vICAgY2F0ZWdvcnk6IFwiUGlnbXlcIixcclxuLy8gICAvLyAgIGNvbG9yOiBcImZyb20teWVsbG93LTUwMCB0by15ZWxsb3ctNjAwXCIsXHJcbi8vICAgLy8gfSxcclxuLy8gICAvLyB7XHJcbi8vICAgLy8gICAgaWQ6XCIxOVwiLFxyXG4vLyAgIC8vICAgdGl0bGU6IFwiTG9hbiBSZXBvcnRcIixcclxuLy8gICAvLyAgIGxpbms6IFwiL3JlcG9ydHMvbG9hbi1yZXBvcnRcIixcclxuLy8gICAvLyAgIEljb246IEdpTW9uZXlTdGFjayxcclxuLy8gICAvLyAgIGNhdGVnb3J5OiBcIkxvYW5cIixcclxuLy8gICAvLyAgIGNvbG9yOiBcImZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4vLyAgIC8vIH0sXHJcblxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjI3XCIsXHJcbi8vICAgICB0aXRsZTogXCJTYWxlcyBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvc2FsZXMtcmVwb3J0XCIsXHJcbi8vICAgICBJY29uOiBGYVVzZXJDaGVjayxcclxuLy8gICAgIGNhdGVnb3J5OiBcIlNhbGVzXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIyOFwiLFxyXG4vLyAgICAgdGl0bGU6IFwiUGF5bWVudCBTdW1tYXJ5XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL3BheW1lbnQtc3VtbWFyeVwiLFxyXG4vLyAgICAgSWNvbjogVGJSZXBvcnRTZWFyY2gsXHJcbi8vICAgICBjYXRlZ29yeTogXCJQYXltZW50c1wiLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1pbmRpZ28tNTAwIHRvLWluZGlnby02MDBcIixcclxuLy8gICAgIGlzTmV3OiBmYWxzZSxcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjI5XCIsXHJcbi8vICAgICB0aXRsZTogXCJNb250aGx5IEluc3RhbGxtZW50IFR1cm5vdmVyXCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL21vbnRobHktaW5zdGFsbC10dXJub3ZlclwiLFxyXG4vLyAgICAgSWNvbjogU2xDYWxlbmRlcixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIzMFwiLFxyXG4vLyAgICAgdGl0bGU6IFwiTW9udGhseSBBdHRlbmRhbmNlIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9lbXBsb3llZS1tb250aGx5LXJlcG9ydFwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuLy8gICAgIEljb246IEJzQ2FsZW5kYXJEYXRlLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1pbmRpZ28tNTAwIHRvLWluZGlnby02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIC8vIHtcclxuLy8gICAvLyAgIGlkOlwiMjRcIixcclxuLy8gICAvLyAgIHRpdGxlOiBcIlBheW91dCBTYWxhcnkgUmVwb3J0XCIsXHJcbi8vICAgLy8gICBsaW5rOiBcIi9yZXBvcnRzL3BheW91dC1zYWxhcnktcmVwb3J0XCIsXHJcbi8vICAgLy8gICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4vLyAgIC8vICAgSWNvbjogSGlPdXRsaW5lQmFua25vdGVzLFxyXG4vLyAgIC8vICAgY29sb3I6IFwiZnJvbS1pbmRpZ28tNTAwIHRvLWluZGlnby02MDBcIixcclxuLy8gICAvLyB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjMxXCIsXHJcbi8vICAgICB0aXRsZTogXCJDb21taXNzaW9uIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy90YXJnZXQtY29tbWlzc2lvblwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiQWdlbnRcIixcclxuLy8gICAgIEljb246IFRiR3JhcGgsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLXllbGxvdy01MDAgdG8teWVsbG93LTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAgLy8ge1xyXG4vLyAgIC8vICAgaWQ6IFwiMjZcIixcclxuLy8gICAvLyAgIHRpdGxlOiBcIkNoaXQgQnVzaW5lc3MgSW5jZW50aXZlIFJlcG9ydFwiLFxyXG4vLyAgIC8vICAgbGluazogXCIvcmVwb3J0cy90YXJnZXQtaW5jZW50aXZlXCIsXHJcbi8vICAgLy8gICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4vLyAgIC8vICAgSWNvbjogVGJHcmFwaEZpbGxlZCxcclxuLy8gICAvLyAgIGNvbG9yOiBcImZyb20taW5kaWdvLTUwMCB0by1pbmRpZ28tNjAwXCIsXHJcbi8vICAgLy8gfSxcclxuLy8gICAge1xyXG4vLyAgIGlkOiBcIjMyXCIsXHJcbi8vICAgdGl0bGU6IFwiQ2hpdCBCdXNpbmVzcyBJbmNlbnRpdmUgTmV3IFJlcG9ydFwiLFxyXG4vLyAgIGxpbms6IFwiL3JlcG9ydHMvdGFyZ2V0LWluY2VudGl2ZS1uZXdcIixcclxuLy8gICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4vLyAgIEljb246IEZhVHJvcGh5LFxyXG4vLyAgIGNvbG9yOiBcImZyb20tYW1iZXItNTAwIHRvLXllbGxvdy02MDBcIixcclxuLy8gICBpc05ldzogdHJ1ZSxcclxuLy8gfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIzM1wiLFxyXG4vLyAgICAgdGl0bGU6IFwiVW52ZXJpZmllZCBDdXN0b21lciBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvdW52ZXJpZmllZC1jdXN0b21lci1yZXBvcnRcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICBJY29uOiBNZENhbmNlbCxcclxuLy8gICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjM0XCIsXHJcbi8vICAgICB0aXRsZTogXCJNb2JpbGUgQ3VzdG9tZXIgQXBwIEFjdGl2aXR5IFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9jdXN0b21lci1ldmVudC1sb2dnZXItcmVwb3J0XCIsXHJcbi8vICAgICBjYXRlZ29yeTogXCJDdXN0b21lclwiLFxyXG4vLyAgICAgSWNvbjogVGJEZXZpY2VNb2JpbGVTZWFyY2gsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgfSxcclxuLy8gICAvLyAgICAge1xyXG4vLyAgIC8vICAgaWQ6XCIyOFwiLFxyXG4vLyAgIC8vICAgdGl0bGU6IFwiUmVtYWluaW5nIFNhbGFyeSBSZXBvcnRcIixcclxuLy8gICAvLyAgIGxpbms6IFwiL3JlcG9ydHMvc2FsYXJ5LXJlbWFpbmluZ1wiLFxyXG4vLyAgIC8vICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuLy8gICAvLyAgSWNvbjogTWRDYW5jZWwsXHJcbi8vICAgLy8gIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuLy8gICAvLyB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjM1XCIsXHJcbi8vICAgICB0aXRsZTogXCJDaGl0IEFza2luZyBNb250aCBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvY2hpdC1hc2tpbmctbW9udGgtcmVwb3J0XCIsXHJcbi8vICAgICBjYXRlZ29yeTogXCJDdXN0b21lclwiLFxyXG4vLyAgICAgSWNvbjogTWRDYWxlbmRhck1vbnRoLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiMzZcIixcclxuLy8gICAgIHRpdGxlOiBcIkNoaXQgQ2FuY2VsbGF0aW9uIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9jaGl0LWNhbmNlbGxhdGlvbi1yZXBvcnRcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICBJY29uOiBNZENhbGVuZGFyTW9udGgsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCI1MlwiLFxyXG4vLyAgICAgdGl0bGU6XCJHU1QgYW5kIFNlcnZpY2UgQ2hhcmdlIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9nc3Qtc2VydmljZS1jaGFyZ2VcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbi8vICAgICAgSWNvbjogRmFNb25leUNoZWNrQWx0LFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1lbWVyYWxkLTUwMCB0by10ZWFsLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IHRydWUsXHJcbi8vICAgfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIzN1wiLFxyXG4vLyAgICAgdGl0bGU6IFwiVXNlciBJbnN0YWxsZWQgU291cmNlIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy91c2VyLXJlZ2lzdHJhdGlvbi1zb3VyY2Utc3VtbWFyeS1yZXBvcnRcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbi8vICAgICBJY29uOiBGYU1vYmlsZUFsdCxcclxuLy8gICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuLy8gICB9LFxyXG5cclxuLy8gICB7XHJcbi8vICAgICBpZDogXCIzOFwiLFxyXG4vLyAgICAgdGl0bGU6IFwiU2FsYXJ5IHJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9lbXBsb3llZS1zYWxhcnktcmVwb3J0XCIsXHJcbi8vICAgICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4vLyAgICAgSWNvbjogSGlPdXRsaW5lQmFua25vdGVzLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiMzlcIixcclxuLy8gICAgIHRpdGxlOiBcIkVtcGxveWVlIERlZHVjdGlvbiByZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvZW1wbG95ZWUtZGVkdWN0aW9uLXJlcG9ydFwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuLy8gICAgIEljb246IFBpTW9uZXlEdW90b25lLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiNDBcIixcclxuLy8gICAgIHRpdGxlOiBcIlJlZGVtcHRpb24gUG9pbnRzIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9yZWRlbXRpb24tcG9pbnRzXCIsXHJcbi8vICAgICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4vLyAgICAgSWNvbjogVGZpR2lmdCxcclxuLy8gICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuLy8gICAgIGlzTmV3OiBmYWxzZSxcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjQxXCIsXHJcbi8vICAgICB0aXRsZTogXCIgUmV3YXJkIFBvaW50cyBSZXBvcnRcIixcclxuLy8gICAgIGxpbms6IFwiL3JlcG9ydHMvZGF0ZS13aXNlLXJld2FyZC1wb2ludHNcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbi8vICAgICBJY29uOiBUZmlHaWZ0LFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiNDJcIixcclxuLy8gICAgIHRpdGxlOiBcIkNoaXQgQ29sbGVjdGlvbiBJbmNlbnRpdmUgUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL2NoaXRjb2xsZWN0aW9uLWluY2VudGl2ZVwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuLy8gICAgIEljb246IE1kR3JvdXBzLFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1ncmVlbi01MDAgdG8tZ3JlZW4tNjAwXCIsXHJcbi8vICAgICBpc05ldzogZmFsc2UsXHJcbi8vICAgfSxcclxuXHJcbi8vICAgIHtcclxuLy8gICAgIGlkOiBcIjQzXCIsXHJcbi8vICAgICB0aXRsZTogXCJMb2FuIENvbGxlY3Rpb24gSW5jZW50aXZlIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9sb2FuY29sbGVjdGlvbi1pbmNlbnRpdmVcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbi8vICAgICBJY29uOiBGYU1vbmV5QmlsbFdhdmUsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbi8vICAgICBpc05ldzogZmFsc2UsXHJcbi8vICAgfSxcclxuLy8gICB7XHJcbi8vICAgICBpZDogXCI0NFwiLFxyXG4vLyAgICAgdGl0bGU6IFwiUGlnbXkgQ29sbGVjdGlvbiBJbmNlbnRpdmUgUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL3BpZ215Y29sbGVjdGlvbi1pbmNlbnRpdmVcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbi8vICAgICBJY29uOiBGYVBpZ2d5QmFuayxcclxuLy8gICAgIGNvbG9yOiBcImZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcblxyXG4vLyAgICAge1xyXG4vLyAgICAgaWQ6IFwiNDVcIixcclxuLy8gICAgIHRpdGxlOiBcIkN1c3RvbWVyIEFwcCBJbnN0YWxsYXRpb24gUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL21vYmlsZS1hcHAtaW5zdGFsbHNcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbi8vICAgICBJY29uOiBGYU1vYmlsZUFsdCxcclxuLy8gICAgIGNvbG9yOiBcImZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAgaWQ6IFwiNDZcIixcclxuLy8gICAgIHRpdGxlOlwiUGlnbXkgUGF5b3V0IFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9waWdteS1wYXlvdXQtcmVwb3J0XCIsXHJcbi8vICAgICBjYXRlZ29yeTogXCJQaWdteVwiLFxyXG4vLyAgICAgIEljb246IEZhTW9uZXlDaGVja0FsdCxcclxuLy8gICAgIGNvbG9yOiBcImZyb20tZW1lcmFsZC01MDAgdG8tdGVhbC02MDBcIixcclxuLy8gICAgIGlzTmV3OiBmYWxzZSxcclxuLy8gICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgaWQ6IFwiNDhcIixcclxuLy8gICAgIHRpdGxlOlwiUGF5b3V0IFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9wYXlvdXQtcmVwb3J0XCIsXHJcbi8vICAgICBjYXRlZ29yeTogXCJDaGl0XCIsXHJcbi8vICAgICAgSWNvbjogRmFNb25leUNoZWNrQWx0LFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1lbWVyYWxkLTUwMCB0by10ZWFsLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IGZhbHNlLFxyXG4vLyAgIH0sXHJcblxyXG4vLyAgICB7XHJcbi8vICAgICBpZDogXCI0OVwiLFxyXG4vLyAgICAgdGl0bGU6XCJFbXBsb3llZSBSZWZlcnJlZCBDdXN0b21lcnMgUmVwb3J0XCIsXHJcbi8vICAgICBsaW5rOiBcIi9yZXBvcnRzL2VtcGxveWVlLWN1c3RvbWVyLXJlZmVycmFsLXJlcG9ydFwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuLy8gICAgICBJY29uOiBGYU1vbmV5Q2hlY2tBbHQsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWVtZXJhbGQtNTAwIHRvLXRlYWwtNjAwXCIsXHJcbi8vICAgICBpc05ldzogdHJ1ZSxcclxuLy8gICB9LFxyXG4vLyAgICB7XHJcbi8vICAgICBpZDogXCI1MFwiLFxyXG4vLyAgICAgdGl0bGU6XCJFbXBsb3llZSBDb2xsZWN0aW9uIEN1c3RvbWVyIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9lbXBsb3llZS1jb2xsZWN0aW9uLWN1c3RvbWVyLXJlcG9ydFwiLFxyXG4vLyAgICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuLy8gICAgICBJY29uOiBGYU1vbmV5Q2hlY2tBbHQsXHJcbi8vICAgICBjb2xvcjogXCJmcm9tLWVtZXJhbGQtNTAwIHRvLXRlYWwtNjAwXCIsXHJcbi8vICAgICBpc05ldzogdHJ1ZSxcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGlkOiBcIjUxXCIsXHJcbi8vICAgICB0aXRsZTpcIkVtcGxveWVlIFJlbGF0aW9uc2hpcCBNYW5hZ2VyIFJlcG9ydFwiLFxyXG4vLyAgICAgbGluazogXCIvcmVwb3J0cy9lbXBsb3llZS1yZWxhdGlvbnNoaXAtbWFuYWdlci1yZXBvcnRcIixcclxuLy8gICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbi8vICAgICAgSWNvbjogRmFNb25leUNoZWNrQWx0LFxyXG4vLyAgICAgY29sb3I6IFwiZnJvbS1lbWVyYWxkLTUwMCB0by10ZWFsLTYwMFwiLFxyXG4vLyAgICAgaXNOZXc6IHRydWUsXHJcbi8vICAgfSxcclxuLy8gXTtcclxuXHJcbi8vIGNvbnN0IGNhdGVnb3JpZXMgPSBbXCJBbGxcIiwgXCJHcm91cFwiLCBcIkN1c3RvbWVyXCIsIFwiQWdlbnRcIiwgXCJFbXBsb3llZVwiLCBcIkZpbmFuY2VcIiwgXCJQYXltZW50c1wiLCBcIkxlYWRcIiwgXCJMb2FuXCIsIFwiUGlnbXlcIiwgXCJBdWN0aW9uXCIsIFwiU2FsZXNcIl07XHJcblxyXG4vLyBjb25zdCBSZXBvcnRzID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuLy8gICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbi8vICAgY29uc3QgW2FjdGl2ZUNhdGVnb3J5LCBzZXRBY3RpdmVDYXRlZ29yeV0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuLy8gICBjb25zdCBbdmlld1R5cGUsIHNldFZpZXdUeXBlXSA9IHVzZVN0YXRlKFwiZ3JpZFwiKTtcclxuLy8gICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4vLyAgIGNvbnN0W2hpZGVTaWRlYmFyLHNldEhpZGVTaWRlYmFyXT11c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgLy8gRnVuY3Rpb24gdG8gc2Nyb2xsIHRvIHRvcFxyXG4vLyAgIGNvbnN0IHNjcm9sbFRvVG9wID0gKCkgPT4ge1xyXG4vLyAgICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBGdW5jdGlvbiB0byBoYW5kbGUgbmF2aWdhdGlvbiB3aXRoIHNjcm9sbCB0byB0b3BcclxuLy8gICBjb25zdCBoYW5kbGVOYXZpZ2F0aW9uID0gKGxpbmspID0+IHtcclxuLy8gICAgIG5hdmlnYXRlKGxpbmspO1xyXG4vLyAgICAgLy8gVXNlIHNldFRpbWVvdXQgdG8gZW5zdXJlIHNjcm9sbCBoYXBwZW5zIGFmdGVyIG5hdmlnYXRpb25cclxuLy8gICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4vLyAgICAgICBzY3JvbGxUb1RvcCgpO1xyXG4vLyAgICAgfSwgMTAwKTtcclxuLy8gICB9O1xyXG4vLyAgIGNvbnN0IHJlZiA9IHVzZVJlZihudWxsKTtcclxuXHJcbi8vICAgY29uc3QgZmlsdGVyZWRNZW51cyA9IHN1Yk1lbnVzXHJcbi8vICAgICAuZmlsdGVyKChtZW51KSA9PiBhY3RpdmVDYXRlZ29yeSA9PT0gXCJBbGxcIiB8fCBtZW51LmNhdGVnb3J5ID09PSBhY3RpdmVDYXRlZ29yeSlcclxuLy8gICAgIC5maWx0ZXIoKG1lbnUpID0+XHJcbi8vICAgICAgIG1lbnUudGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgKTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlQ2xlYXJTZWFyY2ggPSAoKSA9PiB7XHJcbi8vICAgICBzZXRTZWFyY2hRdWVyeShcIlwiKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1zY3JlZW4gbWluLWgtc2NyZWVuIGZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICB7PE5hdmJhciAvPn1cclxuLy8gICAgICAgICA8U2lkZWJhciBoaWRlU2lkZWJhcj17aGlkZVNpZGViYXJ9IC8+XHJcblxyXG4vLyAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT17YCR7b3BlbiA/IFwidy1bMzAwcHhdXCIgOiBcInctWzEwMHB4XVwiXHJcbi8vICAgICAgICAgICAgIH0gYmctZ3JheS01MCBtaW4taC1zY3JlZW4gcC00IGJvcmRlci1yIGJvcmRlci1ncmF5LTIwMGB9XHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHN0aWNreSB0b3AtNCB6LTEwXCI+XHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShcIi9yZXBvcnRzXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgc2Nyb2xsVG9Ub3AoKTtcclxuLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXHJcbi8vICAgICAgICR7b3BlblxyXG4vLyAgICAgICAgICAgICAgICAgICA/IFwicHgtNSBweS0xIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLVtyZ2IoOF8yNl84MSldIHRvLWJsdWUtOTAwIHRleHQtd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzY2FsZS1bMS4wMl1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICA6IFwicC0xIHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTEwXCJcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgIGB9XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICB7LyogSWNvbiAqL31cclxuLy8gICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnXCI+PEZhQ2hhcnRCYXIgY2xhc3NOYW1lPVwidGV4dC1sZyB0ZXh0LWJsdWUtMTAwXCIgLz48L3NwYW4+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBUZXh0ICovfVxyXG4vLyAgICAgICAgICAgICAgIHtvcGVuICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRyYWNraW5nLXdpZGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgUmVwb3J0c1xyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgIHJlZj17cmVmfVxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9e2AgbWluLWgtc2NyZWVuIG1heC1oLWF1dG8gcC01IHB0LTggICR7b3BlbiA/IFwidy02NFwiIDogXCJ3LTIwXCJcclxuLy8gICAgICAgICAgICAgICB9IGR1cmF0aW9uLTMwMCByZWxhdGl2ZWB9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxGaUNoZXZyb25MZWZ0XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgdGV4dC1zZWNvbmRhcnkgdGV4dC0zeGwgcm91bmRlZC1mdWxsIGFic29sdXRlIC1yaWdodC0zIHRvcC01IGJvcmRlciBib3JkZXItc2Vjb25kYXJ5IGN1cnNvci1wb2ludGVyICR7IW9wZW4gJiYgXCJyb3RhdGUtMTgwXCJcclxuLy8gICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oIW9wZW4pfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAge3N1Yk1lbnVzPy5tYXAoKHsgdGl0bGUsIGxpbmssIEljb24sIGdyZWVuLCBpc05ldyB9KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuLy8gICAgICAgICAgICAgICAgIGtleT17bGlua31cclxuLy8gICAgICAgICAgICAgICAgIHRvPXtsaW5rfVxyXG4vLyAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICBzY3JvbGxUb1RvcCgpXHJcbi8vICAgICAgICAgICAgICAgICAgIHNldE9wZW4oIW9wZW4pXHJcbi8vICAgICAgICAgICAgICAgICAgIHNldEhpZGVTaWRlYmFyKCFoaWRlU2lkZWJhcilcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgYG15LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZm9udC1tZWRpdW0gcm91bmRlZC1yLTN4bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgcC0zICR7Z3JlZW4gPyBcInRleHQtZ3JlZW4tODAwXCIgOiBcInRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB9ICR7aXNBY3RpdmVcclxuLy8gICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JheS0yMDAgYm9yZGVyLWwtNCBib3JkZXItYmx1ZS01MDAgdy1mdWxsIHRyYW5zbGF0ZS14LTEgc2hhZG93LXNtXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA6IFwiaG92ZXI6YmctZ3JheS0zMDAgdy1bOTUlXVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIH1gXHJcbi8vICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgeyh7IGlzQWN0aXZlIH0pID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8SWNvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MjB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Ake2lzQWN0aXZlID8gXCJhbmltYXRlLWJvdW5jZVwiIDogXCJ0ZXh0LWJsYWNrXCJ9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LWJsYWNrIGJsb2NrIG1heC13LVsxNTBweF0gbGVhZGluZy10aWdodFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICR7IW9wZW4gJiYgXCJoaWRkZW5cIn1gfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHt0aXRsZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHsvKiBBZGQgTkVXIGJhZGdlIGhlcmUgKi99XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgb3BlbiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2UgaW5saW5lLWJsb2NrXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgTkVXXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4vLyAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtMyBvdmVyZmxvdy1oaWRkZW4gXCI+XHJcbi8vICAgICAgICAgICB7bG9jYXRpb24ucGF0aG5hbWUgPT09IFwiL3JlcG9ydHNcIiA/IChcclxuLy8gICAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgICB7LyogU2VhcmNoIEJhciAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWF4LXctM3hsIG14LWF1dG9cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTYgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxJb1NlYXJjaE91dGxpbmUgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LTJ4bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHJlcG9ydHMuLi5cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTYgcHItMTYgcHktNCB0ZXh0LWxnIGJnLXdoaXRlIGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLTJ4bCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctYmx1ZS01MDAvMjAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgZm9jdXM6c2hhZG93LXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAge3NlYXJjaFF1ZXJ5ICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhclNlYXJjaH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCByaWdodC0wIHByLTUgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNjAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3ZlcjpzY2FsZS0xMTAgYWN0aXZlOnNjYWxlLTk1XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8SW9DbG9zZUNpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LTN4bFwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIENhdGVnb3J5IENoaXBzICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAge2NhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAga2V5PXtjYXRlZ29yeX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVDYXRlZ29yeShjYXRlZ29yeSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCAke2FjdGl2ZUNhdGVnb3J5ID09PSBjYXRlZ29yeVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZ1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgdGV4dC1ncmF5LTgwMCBob3ZlcjpiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBWaWV3IFRvZ2dsZSAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgbWItNiBqdXN0aWZ5LWVuZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3VHlwZShcImdyaWRcIil9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7dmlld1R5cGUgPT09IFwiZ3JpZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS04MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgdGl0bGU9XCJHcmlkIFZpZXdcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8QmlHcmlkIHNpemU9ezIwfSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdUeXBlKFwibGlzdFwiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHt2aWV3VHlwZSA9PT0gXCJsaXN0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgdGV4dC1ncmF5LTgwMCBob3ZlcjpiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkxpc3QgVmlld1wiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxUYkxpc3Qgc2l6ZT17MjB9IC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIE5vIFJlc3VsdHMgTWVzc2FnZSAqL31cclxuLy8gICAgICAgICAgICAgICB7ZmlsdGVyZWRNZW51cy5sZW5ndGggPT09IDAgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTE2IGgtMTYgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8SW9TZWFyY2hPdXRsaW5lIGNsYXNzTmFtZT1cInRleHQtM3hsIHRleHQtZ3JheS00MDBcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTJcIj5ObyByZXBvcnRzIGZvdW5kPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPlRyeSBhZGp1c3RpbmcgeW91ciBzZWFyY2ggb3IgZmlsdGVyIGNyaXRlcmlhPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIEdyaWQgVmlldyAqL31cclxuLy8gICAgICAgICAgICAgICB7dmlld1R5cGUgPT09IFwiZ3JpZFwiICYmIGZpbHRlcmVkTWVudXMubGVuZ3RoID4gMCA/IChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNCBnYXAtNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRNZW51cy5tYXAoKHsgdGl0bGUsIEljb24sIGxpbmssIGNvbG9yLCBpc05ldyB9KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTmF2aWdhdGlvbihsaW5rKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyIGgtZnVsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlbiBoLWZ1bGwgaG92ZXI6LXRyYW5zbGF0ZS15LTEgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JhZGllbnQtdG8tYnIgJHtjb2xvcn0gaC0yNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIG9wYWNpdHktMTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy13aGl0ZSBtaXgtYmxlbmQtb3ZlcmxheVwiPjwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInRleHQtNXhsIHRleHQtd2hpdGUgZHJvcC1zaGFkb3ctbGdcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBORVcgQmFkZ2Ugb24gR3JpZCBDYXJkICovfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc05ldyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0yIHJpZ2h0LTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlIHNoYWRvdy1sZ1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5FV1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGxpbmUtY2xhbXAtMiBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0aXRsZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBmbGV4LXNocmluay0wIGJsaW5rLW5ld1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5FV1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJsdWUtNjAwIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHlcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBSZXBvcnRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBtbC0yIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk05IDVsNyA3LTcgN1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgLyogTGlzdCBWaWV3ICovXHJcbi8vICAgICAgICAgICAgICAgICBmaWx0ZXJlZE1lbnVzLmxlbmd0aCA+IDAgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlkLCBpc05ldyB9KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6LXRyYW5zbGF0ZS14LTEgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBwLTUgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmFkaWVudC10by1iciAke2NvbG9yfSByb3VuZGVkLWxnIHAtNCBtci01IGZsZXgtc2hyaW5rLTBgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LXdoaXRlXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTkVXIEJhZGdlIG9uIExpc3QgVmlldyAqL31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlIGJsaW5rLW5ld1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBORVdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB2aWV3IGRldGFpbGVkIHJlcG9ydFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk05IDVsNyA3LTcgN1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICA8T3V0bGV0IC8+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcblxyXG4vLyB9O1xyXG5cclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgTmF2TGluaywgT3V0bGV0LCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIE1kT3V0bGluZUJsb2NrLFxyXG4gIE1kT3V0bGluZVBlbmRpbmdBY3Rpb25zLFxyXG4gIE1kR2F2ZWwsXHJcbiAgTWRPdXRsaW5lRW1vamlQZW9wbGUsXHJcbiAgTWRDYWxlbmRhck1vbnRoLFxyXG4gIE1kR3JvdXBzLFxyXG4gIE1kT3V0bGluZVJlY2VpcHRMb25nLFxyXG4gIE1kTWFuLFxyXG59IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBUYlVzZXJQYXVzZSwgVGJDb2lucyB9IGZyb20gXCJyZWFjdC1pY29ucy90YlwiO1xyXG5pbXBvcnQgeyBCaUhpc3RvcnkgfSBmcm9tIFwicmVhY3QtaWNvbnMvYmlcIjtcclxuaW1wb3J0IHsgSGlPdXRsaW5lQmFua25vdGVzIH0gZnJvbSBcInJlYWN0LWljb25zL2hpMlwiO1xyXG5pbXBvcnQge1xyXG4gIEJzQXJyb3dMZWZ0U2hvcnQsXHJcbiAgQnNDaGV2cm9uRG93bixcclxuICBCc0NoZXZyb25SaWdodCxcclxufSBmcm9tIFwicmVhY3QtaWNvbnMvYnNcIjtcclxuaW1wb3J0IHsgVGJEZXZpY2VNb2JpbGVTZWFyY2ggfSBmcm9tIFwicmVhY3QtaWNvbnMvdGJcIjtcclxuaW1wb3J0IHsgVGlDYW5jZWwgfSBmcm9tIFwicmVhY3QtaWNvbnMvdGlcIjtcclxuaW1wb3J0IHsgRmFDYWxlbmRhckRheXMsIEZhUGVvcGxlR3JvdXAsIEZhUGVvcGxlQXJyb3dzIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhNlwiO1xyXG5pbXBvcnQgeyBUYlVzZXJDYW5jZWwgfSBmcm9tIFwicmVhY3QtaWNvbnMvdGJcIjtcclxuXHJcbmltcG9ydCB7IE1vZGFsLCBCdXR0b24sIG1lc3NhZ2UsIFN3aXRjaCwgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmltcG9ydCB7IEZhUGVyc29uV2Fsa2luZ0Fycm93TG9vcExlZnQgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmE2XCI7XHJcbmltcG9ydCB7IFJpR3JvdXBMaW5lLCBSaUF1Y3Rpb25GaWxsIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCB7IEZpQ2hldnJvbkxlZnQsIEZpU2V0dGluZ3MgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgTWRPdXRsaW5lUGF5bWVudHMgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgTGlhQ2FsY3VsYXRvclNvbGlkIH0gZnJvbSBcInJlYWN0LWljb25zL2xpYVwiO1xyXG5pbXBvcnQgeyBHaVBheU1vbmV5LCBHaVJlY2VpdmVNb25leSwgR2lNb25leVN0YWNrIH0gZnJvbSBcInJlYWN0LWljb25zL2dpXCI7XHJcbmltcG9ydCB7IFRiUmVwb3J0U2VhcmNoIH0gZnJvbSBcInJlYWN0LWljb25zL3RiXCI7XHJcbmltcG9ydCB7IE1kT3V0bGluZVBheW1lbnQgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgU2xDYWxlbmRlciB9IGZyb20gXCJyZWFjdC1pY29ucy9zbFwiO1xyXG5pbXBvcnQgeyBSaVJlY2VpcHRMaW5lIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCB7IHVzZVJlZiwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBCaUdyaWQgfSBmcm9tIFwicmVhY3QtaWNvbnMvYmlcIjtcclxuaW1wb3J0IHsgVGJMaXN0IH0gZnJvbSBcInJlYWN0LWljb25zL3RiXCI7XHJcbmltcG9ydCB7IEJzQ2FsZW5kYXJEYXRlIH0gZnJvbSBcInJlYWN0LWljb25zL2JzXCI7XHJcbmltcG9ydCB7IFRiR3JhcGggfSBmcm9tIFwicmVhY3QtaWNvbnMvdGJcIjtcclxuaW1wb3J0IHsgVGJHcmFwaEZpbGxlZCB9IGZyb20gXCJyZWFjdC1pY29ucy90YlwiO1xyXG5pbXBvcnQgeyBJb1NlYXJjaE91dGxpbmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW81XCI7XHJcbmltcG9ydCB7IElvQ2xvc2VDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW81XCI7XHJcbmltcG9ydCB7IE1kQ2FuY2VsIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IEJzQ2FsY3VsYXRvciB9IGZyb20gXCJyZWFjdC1pY29ucy9ic1wiO1xyXG5pbXBvcnQgeyBMaWFQZW9wbGVDYXJyeVNvbGlkIH0gZnJvbSBcInJlYWN0LWljb25zL2xpYVwiO1xyXG5pbXBvcnQgeyBNZFBlcnNvbk9mZiB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5cclxuaW1wb3J0IHtcclxuICBGYVVzZXJzLFxyXG4gIEZhVXNlckZyaWVuZHMsXHJcbiAgRmFVc2VyVGllLFxyXG4gIEZhVXNlckNoZWNrLFxyXG4gIEZhQXdhcmQsXHJcbiAgRmFQaWdneUJhbmssXHJcbiAgRmFNb25leUJpbGxXYXZlLFxyXG4gIEZhTW9uZXlDaGVja0FsdCxcclxuICBGYUNoYXJ0TGluZSxcclxuICBGYVdhbGxldCxcclxuICBGYUJvb2tPcGVuLFxyXG4gIEZhTWFwTWFya2VkQWx0LFxyXG4gIEZhQ2xpcGJvYXJkTGlzdCxcclxuICBGYUhhbmRIb2xkaW5nVXNkLFxyXG4gIEZhQ2hlY2tDaXJjbGUsXHJcbiAgRmFNb2JpbGVBbHQsXHJcbiAgRmFDYWxlbmRhckNoZWNrLFxyXG4gIEZhUm91dGUsXHJcbiAgRmFUcm9waHksXHJcbiAgRmFDaGFydEJhcixcclxufSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgUGlNb25leUR1b3RvbmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvcGlcIjtcclxuaW1wb3J0IHsgVGZpR2lmdCB9IGZyb20gXCJyZWFjdC1pY29ucy90ZmlcIjtcclxuaW1wb3J0IHsgRmlBd2FyZCB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5pbXBvcnQgeyBHaVRob3JIYW1tZXIgfSBmcm9tIFwicmVhY3QtaWNvbnMvZ2lcIjtcclxuaW1wb3J0IHsgQ2lCYW5rIH0gZnJvbSBcInJlYWN0LWljb25zL2NpXCI7XHJcbmltcG9ydCB7IElvQ2FzaE91dGxpbmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW81XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuXHJcbmNvbnN0IHN1Yk1lbnVzID0gW1xyXG4gIHtcclxuICAgIGlkOiBcIjVcIixcclxuICAgIHRpdGxlOiBcIkFsbCBDdXN0b21lciBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvYWxsLXVzZXItcmVwb3J0XCIsXHJcbiAgICBJY29uOiBGYVVzZXJzLFxyXG4gICAgY2F0ZWdvcnk6IFwiQ3VzdG9tZXJcIixcclxuICAgIGNvbG9yOiBcImZyb20tc2t5LTUwMCB0by1jeWFuLTYwMFwiLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIGlkOiBcIjNcIixcclxuICAgIHRpdGxlOiBcIkdyb3VwIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9ncm91cC1yZXBvcnRcIixcclxuICAgIEljb246IFJpR3JvdXBMaW5lLFxyXG4gICAgY2F0ZWdvcnk6IFwiR3JvdXBcIixcclxuICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTUwMCB0by1wdXJwbGUtNjAwXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI0XCIsXHJcbiAgICB0aXRsZTogXCJFbnJvbGxtZW50IFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9lbnJvbGxtZW50LXJlcG9ydFwiLFxyXG4gICAgSWNvbjogRmFDbGlwYm9hcmRMaXN0LFxyXG4gICAgY2F0ZWdvcnk6IFwiQ3VzdG9tZXJcIixcclxuICAgIGNvbG9yOiBcImZyb20tY3lhbi01MDAgdG8tc2t5LTYwMFwiLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIGlkOiBcIjZcIixcclxuICAgIHRpdGxlOiBcIkN1c3RvbWVyIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9jdXN0b21lci1yZXBvcnRcIixcclxuICAgIEljb246IEZhVXNlckZyaWVuZHMsXHJcbiAgICBjYXRlZ29yeTogXCJDdXN0b21lclwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1pbmRpZ28tNTAwIHRvLWJsdWUtNjAwXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI3XCIsXHJcbiAgICB0aXRsZTogXCJJbiBBY3RpdmUgQ3VzdG9tZXIgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2luYWN0aXZlLXVzZXItcmVwb3J0XCIsXHJcbiAgICBJY29uOiBUYlVzZXJQYXVzZSxcclxuICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLXNsYXRlLTUwMCB0by1ncmF5LTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNDdcIixcclxuICAgIHRpdGxlOiBcIlN1c3BlbmRlZCBDdXN0b21lciBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvc3VzcGVuZC1yZXBvcnRcIixcclxuICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbiAgICBJY29uOiBNZE91dGxpbmVCbG9jayxcclxuICAgIGNvbG9yOiBcImZyb20tYW1iZXItNTAwIHRvLW9yYW5nZS01MDBcIixcclxuICAgIGlzTmV3OiB0cnVlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMVwiLFxyXG4gICAgdGl0bGU6IFwiRGF5Ym9va1wiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9kYXlib29rXCIsXHJcbiAgICBJY29uOiBGYUJvb2tPcGVuLFxyXG4gICAgY2F0ZWdvcnk6IFwiUGF5bWVudHNcIixcclxuICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8taW5kaWdvLTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMlwiLFxyXG4gICAgdGl0bGU6IFwiUmVjZWlwdCBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvcmVjZWlwdC1yZXBvcnRcIixcclxuICAgIEljb246IE1kT3V0bGluZVJlY2VpcHRMb25nLFxyXG4gICAgY2F0ZWdvcnk6IFwiUGF5bWVudHNcIixcclxuICAgIGNvbG9yOiBcImZyb20tZW1lcmFsZC01MDAgdG8tZ3JlZW4tNjAwXCIsXHJcbiAgICBpc05ldzogZmFsc2UsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI4XCIsXHJcbiAgICB0aXRsZTogXCJMb2FuIFN1bW1hcnkgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2N1c3RvbWVyLWxvYW4tcmVwb3J0XCIsXHJcbiAgICBJY29uOiBGYUhhbmRIb2xkaW5nVXNkLFxyXG4gICAgY2F0ZWdvcnk6IFwiTG9hblwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1ncmVlbi01MDAgdG8tdGVhbC02MDBcIixcclxuICB9LFxyXG5cclxuICB7XHJcbiAgICBpZDogXCI5XCIsXHJcbiAgICB0aXRsZTogXCJPdXRTdGFuZGluZyBMb2FuIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9sb2FuLWR1ZS1yZXBvcnRcIixcclxuICAgIGNhdGVnb3J5OiBcIkxvYW5cIixcclxuICAgIEljb246IE1kT3V0bGluZVBlbmRpbmdBY3Rpb25zLFxyXG4gICAgY29sb3I6IFwiZnJvbS1vcmFuZ2UtNTAwIHRvLWFtYmVyLTYwMFwiLFxyXG4gICAgaXNOZXc6IGZhbHNlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMTBcIixcclxuICAgIHRpdGxlOiBcIkxvYW4gUGF5b3V0IFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9sb2FuLXBheW91dC1yZXBvcnRcIixcclxuICAgIGNhdGVnb3J5OiBcIkxvYW5cIixcclxuICAgIEljb246IEdpUGF5TW9uZXksXHJcbiAgICBjb2xvcjogXCJmcm9tLWxpbWUtNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4gICAgaXNOZXc6IGZhbHNlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMTFcIixcclxuICAgIHRpdGxlOiBcIlRyYW5zYWN0aW9uIEhpc3RvcnlcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvdHJhbnNhY3Rpb24taGlzdG9yeVwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiQ3VzdG9tZXJcIixcclxuICAgIEljb246IEJpSGlzdG9yeSxcclxuICAgIGNvbG9yOiBcImZyb20taW5kaWdvLTUwMCB0by12aW9sZXQtNjAwXCIsXHJcbiAgICBpc05ldzogZmFsc2UsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIxOTg2MVwiLFxyXG4gICAgdGl0bGU6IFwiQ3VzdG9tZXIgQXJlYSBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvY3VzdG9tZXItYXJlYS1yZXBvcnRcIixcclxuICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbiAgICBJY29uOiBGYU1hcE1hcmtlZEFsdCxcclxuICAgIGNvbG9yOiBcImZyb20tdGVhbC01MDAgdG8tZW1lcmFsZC02MDBcIixcclxuICAgIGlzTmV3OiB0cnVlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMTJcIixcclxuICAgIHRpdGxlOiBcIkxvYW4gQ29tcGxldGlvbiBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvbG9hbi1jb21wbGV0aW9uLXJlcG9ydFwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiTG9hblwiLFxyXG4gICAgSWNvbjogRmFDaGVja0NpcmNsZSxcclxuICAgIGNvbG9yOiBcImZyb20tdGVhbC01MDAgdG8tY3lhbi02MDBcIixcclxuICAgIGlzTmV3OiBmYWxzZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjEzXCIsXHJcbiAgICB0aXRsZTogXCJQaWdteSBTdW1tYXJ5IFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9waWdteS1zdW1tYXJ5LXJlcG9ydFwiLFxyXG4gICAgSWNvbjogRmFQaWdneUJhbmssXHJcbiAgICBjYXRlZ29yeTogXCJQaWdteVwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1waW5rLTUwMCB0by1mdWNoc2lhLTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMTRcIixcclxuICAgIHRpdGxlOiBcIkhvbGRlZCBDdXN0b21lcnNcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvaG9sZGVkLWN1c3RvbWVyLXJlcG9ydFwiLFxyXG4gICAgSWNvbjogTWRPdXRsaW5lQmxvY2ssXHJcbiAgICBjYXRlZ29yeTogXCJDdXN0b21lclwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1zbGF0ZS02MDAgdG8tZ3JheS03MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjE1XCIsXHJcbiAgICB0aXRsZTogXCJDb2xsZWN0aW9uIEV4ZWN1dGl2ZSBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvY29sbGVjdGlvbi1leGVjdXRpdmVcIixcclxuICAgIEljb246IEZhVXNlclRpZSxcclxuICAgIGNhdGVnb3J5OiBcIkNvbGxlY3Rpb25cIixcclxuICAgIGNvbG9yOiBcImZyb20tY3lhbi01MDAgdG8tYmx1ZS02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjE2XCIsXHJcbiAgICB0aXRsZTogXCJDb2xsZWN0aW9uIEV4ZWN1dGl2ZSBTdW1tYXJ5IFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9jb2xsZWN0aW9uLWV4ZWN1dGl2ZS1zdW1tYXJ5XCIsXHJcbiAgICBJY29uOiBGYUNoYXJ0TGluZSxcclxuICAgIGNhdGVnb3J5OiBcIkNvbGxlY3Rpb25cIixcclxuICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTUwMCB0by1pbmRpZ28tNjAwXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIxN1wiLFxyXG4gICAgdGl0bGU6IFwiQ29sbGVjdGlvbiBBcmVhIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9jb2xsZWN0aW9uLWFyZWEtcmVwb3J0XCIsXHJcbiAgICBJY29uOiBGYU1hcE1hcmtlZEFsdCxcclxuICAgIGNhdGVnb3J5OiBcIkNvbGxlY3Rpb25cIixcclxuICAgIGNvbG9yOiBcImZyb20tdGVhbC01MDAgdG8tY3lhbi02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjE4XCIsXHJcbiAgICB0aXRsZTogXCJFbXBsb3llZSBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvZW1wbG95ZWUtcmVwb3J0XCIsXHJcbiAgICBJY29uOiBGYVVzZXJUaWUsXHJcbiAgICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1pbmRpZ28tNTAwIHRvLWluZGlnby02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjE5XCIsXHJcbiAgICB0aXRsZTogXCJSZWdpc3RyYXRpb24gUmVjZWlwdFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9yZWdpc3RyYXRpb24tZmVlLXJlY2VpcHRcIixcclxuICAgIEljb246IE1kT3V0bGluZVJlY2VpcHRMb25nLFxyXG4gICAgY2F0ZWdvcnk6IFwiUGF5bWVudHNcIixcclxuICAgIGNvbG9yOiBcImZyb20tZW1lcmFsZC01MDAgdG8tdGVhbC02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjIwXCIsXHJcbiAgICB0aXRsZTogXCJPdXRzdGFuZGluZyBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvb3V0c3RhbmRpbmctcmVwb3J0XCIsXHJcbiAgICBJY29uOiBNZE91dGxpbmVQZW5kaW5nQWN0aW9ucyxcclxuICAgIGNhdGVnb3J5OiBcIkN1c3RvbWVyXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLW9yYW5nZS01MDAgdG8teWVsbG93LTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMjFcIixcclxuICAgIHRpdGxlOiBcIkF1Y3Rpb24gRmlsdGVyIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9hdWN0aW9uLWZpbHRlci1yZXBvcnRcIixcclxuICAgIEljb246IFJpQXVjdGlvbkZpbGwsXHJcbiAgICBjYXRlZ29yeTogXCJBdWN0aW9uXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLWZ1Y2hzaWEtNTAwIHRvLXBpbmstNjAwXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIyMlwiLFxyXG4gICAgdGl0bGU6IFwiQmlkIFJlcXVlc3QgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2JpZC1yZXF1ZXN0LXJlcG9ydFwiLFxyXG4gICAgSWNvbjogTWRHYXZlbCxcclxuICAgIGNhdGVnb3J5OiBcIkF1Y3Rpb25cIixcclxuICAgIGNvbG9yOiBcImZyb20tb3JhbmdlLTUwMCB0by15ZWxsb3ctNTAwXCIsXHJcbiAgICBpc05ldzogZmFsc2UsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIyM1wiLFxyXG4gICAgdGl0bGU6IFwiUHJpemVkIEN1c3RvbWVyIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9wcml6ZWQtY3VzdG9tZXItcmVwb3J0XCIsXHJcbiAgICBJY29uOiBGYUF3YXJkLFxyXG4gICAgY2F0ZWdvcnk6IFwiQXVjdGlvblwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS15ZWxsb3ctNTAwIHRvLW9yYW5nZS02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjI0XCIsXHJcbiAgICB0aXRsZTogXCJBbGwgTGVhZCBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvbGVhZC1yZXBvcnRcIixcclxuICAgIEljb246IE1kTWFuLFxyXG4gICAgY2F0ZWdvcnk6IFwiTGVhZFwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1wdXJwbGUtNTAwIHRvLXB1cnBsZS02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjI1XCIsXHJcbiAgICB0aXRsZTogXCJOb24gQ29udmVydGVkIExlYWQgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL25vbi1jb252ZXJ0ZWQtbGVhZC1yZXBvcnRcIixcclxuICAgIGNhdGVnb3J5OiBcIkxlYWRcIixcclxuICAgIEljb246IE1kUGVyc29uT2ZmLFxyXG4gICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMjZcIixcclxuICAgIHRpdGxlOiBcIkNvbnZlcnRlZCBMZWFkIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9jb252ZXJ0ZWQtbGVhZC1yZXBvcnRcIixcclxuICAgIGNhdGVnb3J5OiBcIkxlYWRcIixcclxuICAgIEljb246IExpYVBlb3BsZUNhcnJ5U29saWQsXHJcbiAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIyN1wiLFxyXG4gICAgdGl0bGU6IFwiU2FsZXMgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL3NhbGVzLXJlcG9ydFwiLFxyXG4gICAgSWNvbjogRmFDaGFydExpbmUsXHJcbiAgICBjYXRlZ29yeTogXCJTYWxlc1wiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1za3ktNTAwIHRvLWluZGlnby02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjI4XCIsXHJcbiAgICB0aXRsZTogXCJQYXltZW50IFN1bW1hcnlcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvcGF5bWVudC1zdW1tYXJ5XCIsXHJcbiAgICBJY29uOiBGYVdhbGxldCxcclxuICAgIGNhdGVnb3J5OiBcIlBheW1lbnRzXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLWdyZWVuLTUwMCB0by1lbWVyYWxkLTYwMFwiLFxyXG4gICAgaXNOZXc6IGZhbHNlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMjlcIixcclxuICAgIHRpdGxlOiBcIk1vbnRobHkgSW5zdGFsbG1lbnQgVHVybm92ZXJcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvbW9udGhseS1pbnN0YWxsLXR1cm5vdmVyXCIsXHJcbiAgICBJY29uOiBTbENhbGVuZGVyLFxyXG4gICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjMwXCIsXHJcbiAgICB0aXRsZTogXCJNb250aGx5IEF0dGVuZGFuY2UgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2VtcGxveWVlLW1vbnRobHktcmVwb3J0XCIsXHJcbiAgICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4gICAgSWNvbjogRmFDYWxlbmRhckNoZWNrLFxyXG4gICAgY29sb3I6IFwiZnJvbS12aW9sZXQtNTAwIHRvLWZ1Y2hzaWEtNTAwXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCIzMVwiLFxyXG4gICAgdGl0bGU6IFwiQ29tbWlzc2lvbiBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvdGFyZ2V0LWNvbW1pc3Npb25cIixcclxuICAgIGNhdGVnb3J5OiBcIkFnZW50XCIsXHJcbiAgICBJY29uOiBUYkNvaW5zLFxyXG4gICAgY29sb3I6IFwiZnJvbS15ZWxsb3ctNTAwIHRvLWFtYmVyLTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMzJcIixcclxuICAgIHRpdGxlOiBcIkNoaXQgQnVzaW5lc3MgSW5jZW50aXZlIE5ldyBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvdGFyZ2V0LWluY2VudGl2ZS1uZXdcIixcclxuICAgIGNhdGVnb3J5OiBcIkluY2VudGl2ZVwiLFxyXG4gICAgSWNvbjogRmFUcm9waHksXHJcbiAgICBjb2xvcjogXCJmcm9tLWFtYmVyLTUwMCB0by15ZWxsb3ctNjAwXCIsXHJcbiAgICBpc05ldzogdHJ1ZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjMzXCIsXHJcbiAgICB0aXRsZTogXCJVbnZlcmlmaWVkIEN1c3RvbWVyIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy91bnZlcmlmaWVkLWN1c3RvbWVyLXJlcG9ydFwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiQ3VzdG9tZXJcIixcclxuICAgIEljb246IE1kQ2FuY2VsLFxyXG4gICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4gIH0sXHJcbiAgLy8ge1xyXG4gIC8vICAgaWQ6IFwiMzRcIixcclxuICAvLyAgIHRpdGxlOiBcIk1vYmlsZSBDdXN0b21lciBBcHAgQWN0aXZpdHkgUmVwb3J0XCIsXHJcbiAgLy8gICBsaW5rOiBcIi9yZXBvcnRzL2N1c3RvbWVyLWV2ZW50LWxvZ2dlci1yZXBvcnRcIixcclxuICAvLyAgIGNhdGVnb3J5OiBcIk1vYmlsZVwiLFxyXG4gIC8vICAgSWNvbjogVGJEZXZpY2VNb2JpbGVTZWFyY2gsXHJcbiAgLy8gICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbiAgLy8gfSxcclxuICB7XHJcbiAgICBpZDogXCIzNVwiLFxyXG4gICAgdGl0bGU6IFwiQ2hpdCBBc2tpbmcgTW9udGggUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2NoaXQtYXNraW5nLW1vbnRoLXJlcG9ydFwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiQXVjdGlvblwiLFxyXG4gICAgSWNvbjogTWRDYWxlbmRhck1vbnRoLFxyXG4gICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMzZcIixcclxuICAgIHRpdGxlOiBcIkNoaXQgQ2FuY2VsbGF0aW9uIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9jaGl0LWNhbmNlbGxhdGlvbi1yZXBvcnRcIixcclxuICAgIGNhdGVnb3J5OiBcIkF1Y3Rpb25cIixcclxuICAgIEljb246IE1kQ2FsZW5kYXJNb250aCxcclxuICAgIGNvbG9yOiBcImZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDBcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjUyXCIsXHJcbiAgICB0aXRsZTogXCJHU1QgYW5kIFNlcnZpY2UgQ2hhcmdlIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9nc3Qtc2VydmljZS1jaGFyZ2VcIixcclxuICAgIGNhdGVnb3J5OiBcIlBheW1lbnRzXCIsXHJcbiAgICBJY29uOiBGYVdhbGxldCxcclxuICAgIGNvbG9yOiBcImZyb20tZW1lcmFsZC01MDAgdG8tdGVhbC02MDBcIixcclxuICAgIGlzTmV3OiB0cnVlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiMzdcIixcclxuICAgIHRpdGxlOiBcIlVzZXIgSW5zdGFsbGVkIFNvdXJjZSBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvdXNlci1yZWdpc3RyYXRpb24tc291cmNlLXN1bW1hcnktcmVwb3J0XCIsXHJcbiAgICBjYXRlZ29yeTogXCJNb2JpbGVcIixcclxuICAgIEljb246IEZhTW9iaWxlQWx0LFxyXG4gICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4gIH0sXHJcblxyXG4gIHtcclxuICAgIGlkOiBcIjQwXCIsXHJcbiAgICB0aXRsZTogXCJSZWRlbXB0aW9uIFBvaW50cyBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvcmVkZW10aW9uLXBvaW50c1wiLFxyXG4gICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuICAgIEljb246IFRmaUdpZnQsXHJcbiAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbiAgICBpc05ldzogZmFsc2UsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI0MVwiLFxyXG4gICAgdGl0bGU6IFwiUmV3YXJkIFBvaW50cyBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvZGF0ZS13aXNlLXJld2FyZC1wb2ludHNcIixcclxuICAgIGNhdGVnb3J5OiBcIkVtcGxveWVlXCIsXHJcbiAgICBJY29uOiBUZmlHaWZ0LFxyXG4gICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4gICAgaXNOZXc6IGZhbHNlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNDJcIixcclxuICAgIHRpdGxlOiBcIkNoaXQgQ29sbGVjdGlvbiBJbmNlbnRpdmUgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2NoaXRjb2xsZWN0aW9uLWluY2VudGl2ZVwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiSW5jZW50aXZlXCIsXHJcbiAgICBJY29uOiBNZEdyb3VwcyxcclxuICAgIGNvbG9yOiBcImZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTYwMFwiLFxyXG4gICAgaXNOZXc6IGZhbHNlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNDNcIixcclxuICAgIHRpdGxlOiBcIkxvYW4gQ29sbGVjdGlvbiBJbmNlbnRpdmUgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2xvYW5jb2xsZWN0aW9uLWluY2VudGl2ZVwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiSW5jZW50aXZlXCIsXHJcbiAgICBJY29uOiBGYU1vbmV5QmlsbFdhdmUsXHJcbiAgICBjb2xvcjogXCJmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwXCIsXHJcbiAgICBpc05ldzogZmFsc2UsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI0NFwiLFxyXG4gICAgdGl0bGU6IFwiUGlnbXkgQ29sbGVjdGlvbiBJbmNlbnRpdmUgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL3BpZ215Y29sbGVjdGlvbi1pbmNlbnRpdmVcIixcclxuICAgIGNhdGVnb3J5OiBcIkluY2VudGl2ZVwiLFxyXG4gICAgSWNvbjogRmFQaWdneUJhbmssXHJcbiAgICBjb2xvcjogXCJmcm9tLWdyZWVuLTUwMCB0by1ncmVlbi02MDBcIixcclxuICAgIGlzTmV3OiBmYWxzZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjQ1XCIsXHJcbiAgICB0aXRsZTogXCJDdXN0b21lciBBcHAgSW5zdGFsbGF0aW9uIFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9tb2JpbGUtYXBwLWluc3RhbGxzXCIsXHJcbiAgICBjYXRlZ29yeTogXCJNb2JpbGVcIixcclxuICAgIEljb246IEZhTW9iaWxlQWx0LFxyXG4gICAgY29sb3I6IFwiZnJvbS1ncmVlbi01MDAgdG8tZ3JlZW4tNjAwXCIsXHJcbiAgICBpc05ldzogZmFsc2UsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCI0NlwiLFxyXG4gICAgdGl0bGU6IFwiUGlnbXkgUGF5b3V0IFJlcG9ydFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9waWdteS1wYXlvdXQtcmVwb3J0XCIsXHJcbiAgICBjYXRlZ29yeTogXCJQaWdteVwiLFxyXG4gICAgSWNvbjogR2lSZWNlaXZlTW9uZXksXHJcbiAgICBjb2xvcjogXCJmcm9tLXB1cnBsZS01MDAgdG8taW5kaWdvLTYwMFwiLFxyXG4gICAgaXNOZXc6IGZhbHNlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNDhcIixcclxuICAgIHRpdGxlOiBcIlBheW91dCBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvcGF5b3V0LXJlcG9ydFwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiQXVjdGlvblwiLFxyXG4gICAgSWNvbjogR2lQYXlNb25leSxcclxuICAgIGNvbG9yOiBcImZyb20tdGVhbC01MDAgdG8tY3lhbi02MDBcIixcclxuICAgIGlzTmV3OiBmYWxzZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjQ5XCIsXHJcbiAgICB0aXRsZTogXCJFbXBsb3llZSBSZWZlcnJlZCBDdXN0b21lcnMgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2VtcGxveWVlLWN1c3RvbWVyLXJlZmVycmFsLXJlcG9ydFwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiRW1wbG95ZWVcIixcclxuICAgIEljb246IEZhVXNlcnMsXHJcbiAgICBjb2xvcjogXCJmcm9tLXNreS01MDAgdG8tYmx1ZS02MDBcIixcclxuICAgIGlzTmV3OiB0cnVlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNTBcIixcclxuICAgIHRpdGxlOiBcIkVtcGxveWVlIENvbGxlY3Rpb24gQ3VzdG9tZXIgUmVwb3J0XCIsXHJcbiAgICBsaW5rOiBcIi9yZXBvcnRzL2VtcGxveWVlLWNvbGxlY3Rpb24tY3VzdG9tZXItcmVwb3J0XCIsXHJcbiAgICBjYXRlZ29yeTogXCJDb2xsZWN0aW9uXCIsXHJcbiAgICBJY29uOiBGYVVzZXJGcmllbmRzLFxyXG4gICAgY29sb3I6IFwiZnJvbS1jeWFuLTUwMCB0by1pbmRpZ28tNjAwXCIsXHJcbiAgICBpc05ldzogdHJ1ZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcIjUxXCIsXHJcbiAgICB0aXRsZTogXCJFbXBsb3llZSBSZWxhdGlvbnNoaXAgTWFuYWdlciBSZXBvcnRcIixcclxuICAgIGxpbms6IFwiL3JlcG9ydHMvZW1wbG95ZWUtcmVsYXRpb25zaGlwLW1hbmFnZXItcmVwb3J0XCIsXHJcbiAgICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4gICAgSWNvbjogRmFVc2VyVGllLFxyXG4gICAgY29sb3I6IFwiZnJvbS12aW9sZXQtNTAwIHRvLXB1cnBsZS02MDBcIixcclxuICAgIGlzTmV3OiB0cnVlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNTNcIixcclxuICAgIHRpdGxlOiBcIkN1c3RvbWVyIHZpc2l0IHRyYWNrZXIgUmVwb3J0IFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9jdXN0b21lci12aXNpdC10cmFja2VyXCIsXHJcbiAgICBjYXRlZ29yeTogXCJFbXBsb3llZVwiLFxyXG4gICAgSWNvbjogRmFSb3V0ZSxcclxuICAgIGNvbG9yOiBcImZyb20tY3lhbi01MDAgdG8tYmx1ZS02MDBcIixcclxuICAgIGlzTmV3OiB0cnVlLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiNTRcIixcclxuICAgIHRpdGxlOiBcIkN1c3RvbWVyIFBheW1lbnQgdHJhY2tpbmcgUmVwb3J0IFwiLFxyXG4gICAgbGluazogXCIvcmVwb3J0cy9jdXN0b21lci1wYXltZW50LXRyYWNraW5nLXJlcG9ydFwiLFxyXG4gICAgY2F0ZWdvcnk6IFwiQ3VzdG9tZXJcIixcclxuICAgIEljb246IEZhUm91dGUsXHJcbiAgICBjb2xvcjogXCJmcm9tLWN5YW4tNTAwIHRvLWJsdWUtNjAwXCIsXHJcbiAgICBpc05ldzogdHJ1ZSxcclxuICB9LFxyXG5dO1xyXG5cclxuY29uc3QgY2F0ZWdvcmllcyA9IFtcclxuICBcIkFsbFwiLFxyXG4gIFwiR3JvdXBcIixcclxuICBcIkN1c3RvbWVyXCIsXHJcbiAgXCJBZ2VudFwiLFxyXG4gIFwiRW1wbG95ZWVcIixcclxuICBcIlBheW1lbnRzXCIsXHJcbiAgXCJMZWFkXCIsXHJcbiAgXCJMb2FuXCIsXHJcbiAgXCJQaWdteVwiLFxyXG4gIFwiQXVjdGlvblwiLFxyXG4gIFwiU2FsZXNcIixcclxuICBcIkNvbGxlY3Rpb25cIixcclxuICBcIkluY2VudGl2ZVwiLFxyXG4gIFwiTW9iaWxlXCIsXHJcbl07XHJcblxyXG5jb25zdCBjYXRlZ29yeUNvbG9ycyA9IHtcclxuICBDdXN0b21lcjogXCJiZy1ibHVlLTUwMFwiLFxyXG4gIFBheW1lbnRzOiBcImJnLWVtZXJhbGQtNTAwXCIsXHJcbiAgTG9hbjogXCJiZy1wdXJwbGUtNTAwXCIsXHJcbiAgUGlnbXk6IFwiYmctcGluay01MDBcIixcclxuICBBdWN0aW9uOiBcImJnLWFtYmVyLTUwMFwiLFxyXG4gIEVtcGxveWVlOiBcImJnLWluZGlnby01MDBcIixcclxuICBDb2xsZWN0aW9uOiBcImJnLWdyZWVuLTUwMFwiLFxyXG4gIExlYWQ6IFwiYmctY3lhbi01MDBcIixcclxuICBHcm91cDogXCJiZy12aW9sZXQtNTAwXCIsXHJcbiAgU2FsZXM6IFwiYmctb3JhbmdlLTUwMFwiLFxyXG4gIEFnZW50OiBcImJnLXllbGxvdy01MDBcIixcclxuICBJbmNlbnRpdmU6IFwiYmctb3JhbmdlLTUwMFwiLFxyXG4gIE1vYmlsZTogXCJiZy10ZWFsLTUwMFwiLFxyXG4gIEZpbmFuY2U6IFwiYmctbGltZS01MDBcIixcclxuICBDaGl0OiBcImJnLXJvc2UtNTAwXCIsXHJcbn07XHJcblxyXG4vLyBjb25zdCBSZXBvcnRzID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuLy8gICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbi8vICAgY29uc3QgW2FjdGl2ZUNhdGVnb3J5LCBzZXRBY3RpdmVDYXRlZ29yeV0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuLy8gICBjb25zdCBbdmlld1R5cGUsIHNldFZpZXdUeXBlXSA9IHVzZVN0YXRlKFwiZ3JpZFwiKTtcclxuLy8gICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4vLyAgIGNvbnN0IFtoaWRlU2lkZWJhciwgc2V0SGlkZVNpZGViYXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtleHBhbmRlZENhdGVnb3JpZXMsIHNldEV4cGFuZGVkQ2F0ZWdvcmllc10gPSB1c2VTdGF0ZSh7fSk7XHJcbi8vICAgY29uc3QgW21lbnVzLCBzZXRNZW51c10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4vLyBjb25zdCBbbWFuYWdlTW9kYWwsIHNldE1hbmFnZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgY29uc3QgdG9nZ2xlQ2F0ZWdvcnkgPSAoY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgIHNldEV4cGFuZGVkQ2F0ZWdvcmllcyhwcmV2ID0+ICh7XHJcbi8vICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgIFtjYXRlZ29yeV06ICFwcmV2W2NhdGVnb3J5XVxyXG4vLyAgICAgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHNjcm9sbFRvVG9wID0gKCkgPT4ge1xyXG4vLyAgICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgZmV0Y2hSZXBvcnRzKCk7XHJcbi8vIH0sIFtdKTtcclxuXHJcbi8vIGNvbnN0IGZldGNoUmVwb3J0cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICB0cnkge1xyXG4vLyAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL3JlcG9ydC12aXNpYmlsaXR5XCIpO1xyXG5cclxuLy8gICAgIGNvbnN0IHZpc2liaWxpdHkgPSByZXNwb25zZS5kYXRhLmRhdGEgfHwgW107XHJcblxyXG4vLyAgICAgY29uc3QgZmluYWxNZW51cyA9IHN1Yk1lbnVzLm1hcCgobWVudSkgPT4ge1xyXG4vLyAgICAgICBjb25zdCBkYk1lbnUgPSB2aXNpYmlsaXR5LmZpbmQoXHJcbi8vICAgICAgICAgKGl0ZW0pID0+IGl0ZW0ucmVwb3J0SWQgPT09IG1lbnUuaWRcclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIHJldHVybiB7XHJcbi8vICAgICAgICAgLi4ubWVudSxcclxuLy8gICAgICAgICB2aXNpYmxlOiBkYk1lbnUgPyBkYk1lbnUudmlzaWJsZSA6IHRydWUsXHJcbi8vICAgICAgIH07XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICBzZXRNZW51cyhmaW5hbE1lbnVzKTtcclxuLy8gICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuXHJcbi8vICAgICBzZXRNZW51cyhcclxuLy8gICAgICAgc3ViTWVudXMubWFwKChtZW51KSA9PiAoe1xyXG4vLyAgICAgICAgIC4uLm1lbnUsXHJcbi8vICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuLy8gICAgICAgfSkpXHJcbi8vICAgICApO1xyXG4vLyAgIH1cclxuLy8gfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlTmF2aWdhdGlvbiA9IChsaW5rKSA9PiB7XHJcbi8vICAgICBuYXZpZ2F0ZShsaW5rKTtcclxuLy8gICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4vLyAgICAgICBzY3JvbGxUb1RvcCgpO1xyXG4vLyAgICAgfSwgMTAwKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCByZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4vLyAgY29uc3QgZmlsdGVyZWRNZW51cyA9IG1lbnVzXHJcbi8vIC5maWx0ZXIobWVudT0+bWVudS52aXNpYmxlKVxyXG4vLyAuZmlsdGVyKFxyXG4vLyBtZW51PT5cclxuLy8gYWN0aXZlQ2F0ZWdvcnk9PT1cIkFsbFwiXHJcbi8vIHx8XHJcbi8vIG1lbnUuY2F0ZWdvcnk9PT1hY3RpdmVDYXRlZ29yeVxyXG4vLyApXHJcbi8vIC5maWx0ZXIoXHJcbi8vIG1lbnU9PlxyXG4vLyBtZW51LnRpdGxlXHJcbi8vIC50b0xvd2VyQ2FzZSgpXHJcbi8vIC5pbmNsdWRlcyhcclxuLy8gc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKVxyXG4vLyApXHJcbi8vICk7XHJcblxyXG4vLyBjb25zdCBncm91cGVkTWVudXMgPSBtZW51c1xyXG4vLyAgIC5maWx0ZXIoKG1lbnUpID0+IG1lbnUudmlzaWJsZSlcclxuLy8gICAucmVkdWNlKChhY2MsIG1lbnUpID0+IHtcclxuLy8gICAgIGlmICghYWNjW21lbnUuY2F0ZWdvcnldKSB7XHJcbi8vICAgICAgIGFjY1ttZW51LmNhdGVnb3J5XSA9IFtdO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGFjY1ttZW51LmNhdGVnb3J5XS5wdXNoKG1lbnUpO1xyXG5cclxuLy8gICAgIHJldHVybiBhY2M7XHJcbi8vICAgfSwge30pO1xyXG5cclxuLy8gY29uc3Qgc29ydGVkQ2F0ZWdvcmllcyA9IE9iamVjdC5rZXlzKGdyb3VwZWRNZW51cyk7XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUNsZWFyU2VhcmNoID0gKCkgPT4ge1xyXG4vLyAgICAgc2V0U2VhcmNoUXVlcnkoXCJcIik7XHJcbi8vICAgfTtcclxuXHJcbi8vIGNvbnN0IHNhdmVSZXBvcnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgIHRyeSB7XHJcbi8vICAgICBzZXRTYXZpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgYXdhaXQgYXBpLnB1dChcIi92MS9hZG1pbi9yZXBvcnQtdmlzaWJpbGl0eVwiLCB7XHJcbi8vICAgICAgIHJlcG9ydHM6IG1lbnVzLm1hcCgobWVudSkgPT4gKHtcclxuLy8gICAgICAgICByZXBvcnRJZDogbWVudS5pZCxcclxuLy8gICAgICAgICB2aXNpYmxlOiBtZW51LnZpc2libGUsXHJcbi8vICAgICAgIH0pKSxcclxuLy8gICAgIH0pO1xyXG5cclxuLy8gICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlJlcG9ydCBzZXR0aW5ncyB1cGRhdGVkXCIpO1xyXG5cclxuLy8gICAgIGF3YWl0IGZldGNoUmVwb3J0cygpO1xyXG5cclxuLy8gICAgIHNldE1hbmFnZU1vZGFsKGZhbHNlKTtcclxuLy8gICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuLy8gICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHJlcG9ydCBzZXR0aW5nc1wiKTtcclxuLy8gICB9IGZpbmFsbHkge1xyXG4vLyAgICAgc2V0U2F2aW5nKGZhbHNlKTtcclxuLy8gICB9XHJcbi8vIH07XHJcblxyXG4vLyAgIC8vIEZ1bmN0aW9uIHRvIHJlbmRlciBzaWRlYmFyIHdpdGggY29sbGFwc2libGUgY2F0ZWdvcmllc1xyXG4vLyAgIGNvbnN0IHJlbmRlclNpZGViYXIgPSAoKSA9PiB7XHJcbi8vICAgICByZXR1cm4gKFxyXG4vLyAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgcmVmPXtyZWZ9XHJcbi8vICAgICAgICAgY2xhc3NOYW1lPXtgbWluLWgtc2NyZWVuIG1heC1oLWF1dG8gcC01IHB0LTggJHtvcGVuID8gXCJ3LTY0XCIgOiBcInctMjBcIn0gZHVyYXRpb24tMzAwIHJlbGF0aXZlYH1cclxuLy8gICAgICAgPlxyXG4vLyAgICAgICAgIDxGaUNoZXZyb25MZWZ0XHJcbi8vICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSB0ZXh0LXNlY29uZGFyeSB0ZXh0LTN4bCByb3VuZGVkLWZ1bGwgYWJzb2x1dGUgLXJpZ2h0LTMgdG9wLTUgYm9yZGVyIGJvcmRlci1zZWNvbmRhcnkgY3Vyc29yLXBvaW50ZXIgJHshb3BlbiAmJiBcInJvdGF0ZS0xODBcIn1gfVxyXG4vLyAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0T3Blbighb3Blbil9XHJcbi8vICAgICAgICAgLz5cclxuXHJcbi8vICAgICAgICAge3NvcnRlZENhdGVnb3JpZXMuZmlsdGVyKChjYXRlZ29yeSkgPT4gZ3JvdXBlZE1lbnVzW2NhdGVnb3J5XT8ubGVuZ3RoKS5tYXAoKGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICAgICAgICBjb25zdCBpdGVtcyA9IGdyb3VwZWRNZW51c1tjYXRlZ29yeV0gfHwgW107XHJcbi8vICAgICAgICAgICBjb25zdCBpc0V4cGFuZGVkID0gZXhwYW5kZWRDYXRlZ29yaWVzW2NhdGVnb3J5XSB8fCBmYWxzZTtcclxuXHJcbi8vICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnl9IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICB7LyogQ2F0ZWdvcnkgSGVhZGVyICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW4gJiYgdG9nZ2xlQ2F0ZWdvcnkoY2F0ZWdvcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMiByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb24tYWxsICR7IW9wZW4gPyBcImp1c3RpZnktY2VudGVyXCIgOiBcIlwifWB9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAge29wZW4gPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtpc0V4cGFuZGVkID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEJzQ2hldnJvbkRvd24gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxCc0NoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWdyYXktNDAwXCI+PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIFN1Yi1tZW51IEl0ZW1zICovfVxyXG4vLyAgICAgICAgICAgICAgIHtvcGVuICYmIGlzRXhwYW5kZWQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC00IGJvcmRlci1sLTIgYm9yZGVyLWdyYXktMjAwIHBsLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoeyB0aXRsZSwgbGluaywgSWNvbiwgY29sb3IsIGlzTmV3IH0pID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdG89e2xpbmt9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNjcm9sbFRvVG9wKCk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldEhpZGVTaWRlYmFyKCFoaWRlU2lkZWJhcik7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBgbXktMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmb250LW1lZGl1bSByb3VuZGVkLXItM3hsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBwLTIgdGV4dC1ncmF5LTkwMCAke2lzQWN0aXZlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYXktMjAwIGJvcmRlci1sLTQgYm9yZGVyLWJsdWUtNTAwIHctZnVsbCB0cmFuc2xhdGUteC0xIHNoYWRvdy1zbVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImhvdmVyOmJnLWdyYXktMzAwIHctWzk1JV1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9YFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHsoeyBpc0FjdGl2ZSB9KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezE4fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtpc0FjdGl2ZSA/IFwiYW5pbWF0ZS1ib3VuY2VcIiA6IFwidGV4dC1ibGFja1wifWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsYWNrIGJsb2NrIG1heC13LVsxNTBweF0gbGVhZGluZy10aWdodCB0ZXh0LXNtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgb3BlbiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2UgaW5saW5lLWJsb2NrXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTkVXXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICB9KX1cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2PlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LXNjcmVlbiBtaW4taC1zY3JlZW4gZmxleCBtdC0yMFwiPlxyXG4vLyAgICAgICAgIDxOYXZiYXIgLz5cclxuLy8gICAgICAgICA8U2lkZWJhciBoaWRlU2lkZWJhcj17aGlkZVNpZGViYXJ9IC8+XHJcblxyXG4vLyAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT17YCR7b3BlbiA/IFwidy1bMzAwcHhdXCIgOiBcInctWzEwMHB4XVwifSBiZy1ncmF5LTUwIG1pbi1oLXNjcmVlbiBwLTQgYm9yZGVyLXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LXktYXV0b2B9XHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHN0aWNreSB0b3AtNCB6LTEwXCI+XHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShcIi9yZXBvcnRzXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgc2Nyb2xsVG9Ub3AoKTtcclxuLy8gICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwICR7b3BlblxyXG4vLyAgICAgICAgICAgICAgICAgICA/IFwicHgtNSBweS0xIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLVtyZ2IoOF8yNl84MSldIHRvLWJsdWUtOTAwIHRleHQtd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzY2FsZS1bMS4wMl1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICA6IFwicC0xIHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTEwXCJcclxuLy8gICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZ1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgPEZhQ2hhcnRCYXIgY2xhc3NOYW1lPVwidGV4dC1sZyB0ZXh0LWJsdWUtMTAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAge29wZW4gJiYgPHNwYW4gY2xhc3NOYW1lPVwidHJhY2tpbmctd2lkZVwiPlJlcG9ydHM8L3NwYW4+fVxyXG4vLyAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAge3JlbmRlclNpZGViYXIoKX1cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC0zIG92ZXJmbG93LWhpZGRlblwiPlxyXG4vLyAgICAgICAgICAge2xvY2F0aW9uLnBhdGhuYW1lID09PSBcIi9yZXBvcnRzXCIgPyAoXHJcbi8vICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgey8qIFNlYXJjaCBCYXIgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1heC13LTN4bCBteC1hdXRvXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC02IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8SW9TZWFyY2hPdXRsaW5lIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC0yeGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCByZXBvcnRzLi4uXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTE2IHByLTE2IHB5LTQgdGV4dC1sZyBiZy13aGl0ZSBib3JkZXItMiBib3JkZXItZ3JheS0yMDAgcm91bmRlZC0yeGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLWJsdWUtNTAwLzIwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGZvY3VzOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtzZWFyY2hRdWVyeSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJTZWFyY2h9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBwci01IGZsZXggaXRlbXMtY2VudGVyIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6c2NhbGUtMTEwIGFjdGl2ZTpzY2FsZS05NVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPElvQ2xvc2VDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC0zeGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBDYXRlZ29yeSBDaGlwcyAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICAgIHtjYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGtleT17Y2F0ZWdvcnl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQ2F0ZWdvcnkoY2F0ZWdvcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLWZ1bGwgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHthY3RpdmVDYXRlZ29yeSA9PT0gY2F0ZWdvcnlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbGdcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS04MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5fVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogVmlldyBUb2dnbGUgKi99XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIG1iLTYganVzdGlmeS1lbmRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld1R5cGUoXCJncmlkXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke3ZpZXdUeXBlID09PSBcImdyaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MDAgdG8tYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDogXCJiZy13aGl0ZSB0ZXh0LWdyYXktODAwIGhvdmVyOmJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiR3JpZCBWaWV3XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPEJpR3JpZCBzaXplPXsyMH0gLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3VHlwZShcImxpc3RcIil9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7dmlld1R5cGUgPT09IFwibGlzdFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS04MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMaXN0IFZpZXdcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8VGJMaXN0IHNpemU9ezIwfSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gY2xhc3NOYW1lPVwicHgtNCBweS0yIHJvdW5kZWQtbGcgYmctaW5kaWdvLTYwMCB0ZXh0LXdoaXRlXCJcclxuLy8gb25DbGljaz17KCk9PlxyXG4vLyBzZXRNYW5hZ2VNb2RhbCh0cnVlKVxyXG4vLyB9XHJcbi8vID5cclxuLy8gTWFuYWdlIFJlcG9ydHNcclxuLy8gPC9idXR0b24+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBObyBSZXN1bHRzIE1lc3NhZ2UgKi99XHJcbi8vICAgICAgICAgICAgICAge2ZpbHRlcmVkTWVudXMubGVuZ3RoID09PSAwICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xNiBoLTE2IGJnLWdyYXktMTAwIHJvdW5kZWQtZnVsbCBtYi00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPElvU2VhcmNoT3V0bGluZSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCB0ZXh0LWdyYXktNDAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+Tm8gcmVwb3J0cyBmb3VuZDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5UcnkgYWRqdXN0aW5nIHlvdXIgc2VhcmNoIG9yIGZpbHRlciBjcml0ZXJpYTwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBHcmlkIFZpZXcgKi99XHJcbi8vICAgICAgICAgICAgICAge3ZpZXdUeXBlID09PSBcImdyaWRcIiAmJiBmaWx0ZXJlZE1lbnVzLmxlbmd0aCA+IDAgPyAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgZ2FwLTZcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkTWVudXMubWFwKCh7IHRpdGxlLCBJY29uLCBsaW5rLCBjb2xvciwgaXNOZXcgfSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGtleT17bGlua31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlciBoLWZ1bGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBvdmVyZmxvdy1oaWRkZW4gaC1mdWxsIGhvdmVyOi10cmFuc2xhdGUteS0xIGJvcmRlciBib3JkZXItZ3JheS0xMDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IGgtMjQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuYH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBvcGFjaXR5LTEwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctd2hpdGUgbWl4LWJsZW5kLW92ZXJsYXlcIj48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ0ZXh0LTV4bCB0ZXh0LXdoaXRlIGRyb3Atc2hhZG93LWxnXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiByaWdodC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBzaGFkb3ctbGdcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBORVdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBsaW5lLWNsYW1wLTIgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTmV3ICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBweC0yIHB5LTEgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2UgZmxleC1zaHJpbmstMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5FV1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJsdWUtNjAwIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHlcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5WaWV3IFJlcG9ydDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBtbC0yIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk05IDVsNyA3LTcgN1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgLyogTGlzdCBWaWV3ICovXHJcbi8vICAgICAgICAgICAgICAgICBmaWx0ZXJlZE1lbnVzLmxlbmd0aCA+IDAgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlkLCBpc05ldyB9KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6LXRyYW5zbGF0ZS14LTEgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBwLTUgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmFkaWVudC10by1iciAke2NvbG9yfSByb3VuZGVkLWxnIHAtNCBtci01IGZsZXgtc2hyaW5rLTBgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LXdoaXRlXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5FV1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWNrIHRvIHZpZXcgZGV0YWlsZWQgcmVwb3J0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTkgNWw3IDctNyA3XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIClcclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgIDxPdXRsZXQgLz5cclxuLy8gICAgICAgICAgICl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPE1vZGFsXHJcbi8vIHRpdGxlPVwiTWFuYWdlIFJlcG9ydHNcIlxyXG4vLyBvcGVuPXttYW5hZ2VNb2RhbH1cclxuLy8gb25DYW5jZWw9eygpPT5zZXRNYW5hZ2VNb2RhbChmYWxzZSl9XHJcbi8vIGZvb3Rlcj17bnVsbH1cclxuLy8gd2lkdGg9ezcwMH1cclxuLy8gPlxyXG5cclxuLy8gPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuXHJcbi8vIHtcclxuLy8gbWVudXMubWFwKChtZW51KT0+KFxyXG5cclxuLy8gPGRpdlxyXG4vLyBrZXk9e21lbnUuaWR9XHJcbi8vIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGJvcmRlciByb3VuZGVkLWxnIHAtM1wiXHJcbi8vID5cclxuXHJcbi8vIDxkaXY+XHJcblxyXG4vLyA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cclxuXHJcbi8vIHttZW51LnRpdGxlfVxyXG5cclxuLy8gPC9kaXY+XHJcblxyXG4vLyA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPlxyXG5cclxuLy8ge21lbnUuY2F0ZWdvcnl9XHJcblxyXG4vLyA8L2Rpdj5cclxuXHJcbi8vIDwvZGl2PlxyXG5cclxuLy8gPFN3aXRjaFxyXG5cclxuLy8gY2hlY2tlZD17bWVudS52aXNpYmxlfVxyXG5cclxuLy8gb25DaGFuZ2U9eyhjaGVja2VkKSA9PiB7XHJcbi8vICAgc2V0TWVudXMoKHByZXYpID0+XHJcbi8vICAgICBwcmV2Lm1hcCgoaXRlbSkgPT5cclxuLy8gICAgICAgaXRlbS5pZCA9PT0gbWVudS5pZFxyXG4vLyAgICAgICAgID8ge1xyXG4vLyAgICAgICAgICAgICAuLi5pdGVtLFxyXG4vLyAgICAgICAgICAgICB2aXNpYmxlOiBjaGVja2VkLFxyXG4vLyAgICAgICAgICAgfVxyXG4vLyAgICAgICAgIDogaXRlbVxyXG4vLyAgICAgKVxyXG4vLyAgICk7XHJcbi8vIH19XHJcblxyXG4vLyAvPlxyXG5cclxuLy8gPC9kaXY+XHJcblxyXG4vLyApKVxyXG4vLyB9XHJcblxyXG4vLyA8QnV0dG9uXHJcbi8vICAgdHlwZT1cInByaW1hcnlcIlxyXG4vLyAgIGNsYXNzTmFtZT1cIm10LTVcIlxyXG4vLyAgIGxvYWRpbmc9e3NhdmluZ31cclxuLy8gICBvbkNsaWNrPXtzYXZlUmVwb3J0c31cclxuLy8gPlxyXG4vLyAgIFNhdmVcclxuLy8gPC9CdXR0b24+XHJcblxyXG4vLyA8L2Rpdj5cclxuXHJcbi8vIDwvTW9kYWw+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vIGNvbnN0IFJlcG9ydHMgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG4vLyAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuLy8gICBjb25zdCBbYWN0aXZlQ2F0ZWdvcnksIHNldEFjdGl2ZUNhdGVnb3J5XSA9IHVzZVN0YXRlKFwiQWxsXCIpO1xyXG4vLyAgIGNvbnN0IFt2aWV3VHlwZSwgc2V0Vmlld1R5cGVdID0gdXNlU3RhdGUoXCJncmlkXCIpO1xyXG4vLyAgIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUodHJ1ZSk7XHJcbi8vICAgY29uc3QgW2hpZGVTaWRlYmFyLCBzZXRIaWRlU2lkZWJhcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2V4cGFuZGVkQ2F0ZWdvcmllcywgc2V0RXhwYW5kZWRDYXRlZ29yaWVzXSA9IHVzZVN0YXRlKHt9KTtcclxuLy8gICBjb25zdCBbbWVudXMsIHNldE1lbnVzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFttYW5hZ2VNb2RhbCwgc2V0TWFuYWdlTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuLy8gICBjb25zdCBbZHJhZ2dlZEl0ZW0sIHNldERyYWdnZWRJdGVtXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtkcmFnT3Zlckl0ZW0sIHNldERyYWdPdmVySXRlbV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbi8vICAgLy8gRGVmaW5lIGN1c3RvbSBjYXRlZ29yeSBvcmRlclxyXG4vLyAgIGNvbnN0IGNhdGVnb3J5T3JkZXIgPSBbXCJDdXN0b21lclwiLCBcIkF1Y3Rpb25cIiwgXCJQYXltZW50c1wiXTtcclxuXHJcbi8vICAgLy8gR2V0IGFsbCB1bmlxdWUgY2F0ZWdvcmllcyBmcm9tIG1lbnVzXHJcbi8vICAgY29uc3QgZ2V0QWxsQ2F0ZWdvcmllcyA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGNhdGVnb3JpZXMgPSBuZXcgU2V0KCk7XHJcbi8vICAgICBtZW51cy5mb3JFYWNoKG1lbnUgPT4ge1xyXG4vLyAgICAgICBpZiAobWVudS5jYXRlZ29yeSkge1xyXG4vLyAgICAgICAgIGNhdGVnb3JpZXMuYWRkKG1lbnUuY2F0ZWdvcnkpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9KTtcclxuLy8gICAgIHJldHVybiBBcnJheS5mcm9tKGNhdGVnb3JpZXMpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHRvZ2dsZUNhdGVnb3J5ID0gKGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICBzZXRFeHBhbmRlZENhdGVnb3JpZXMocHJldiA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICBbY2F0ZWdvcnldOiAhcHJldltjYXRlZ29yeV1cclxuLy8gICAgIH0pKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBzY3JvbGxUb1RvcCA9ICgpID0+IHtcclxuLy8gICAgIHdpbmRvdy5zY3JvbGxUbyh7IHRvcDogMCwgYmVoYXZpb3I6IFwic21vb3RoXCIgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoUmVwb3J0cygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hSZXBvcnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vcmVwb3J0LXZpc2liaWxpdHlcIik7XHJcbi8vICAgICAgIGNvbnN0IHZpc2liaWxpdHkgPSByZXNwb25zZS5kYXRhLmRhdGEgfHwgW107XHJcblxyXG4vLyAgICAgICBjb25zdCBmaW5hbE1lbnVzID0gc3ViTWVudXMubWFwKChtZW51KSA9PiB7XHJcbi8vICAgICAgICAgY29uc3QgZGJNZW51ID0gdmlzaWJpbGl0eS5maW5kKFxyXG4vLyAgICAgICAgICAgKGl0ZW0pID0+IGl0ZW0ucmVwb3J0SWQgPT09IG1lbnUuaWRcclxuLy8gICAgICAgICApO1xyXG4vLyAgICAgICAgIHJldHVybiB7XHJcbi8vICAgICAgICAgICAuLi5tZW51LFxyXG4vLyAgICAgICAgICAgdmlzaWJsZTogZGJNZW51ID8gZGJNZW51LnZpc2libGUgOiB0cnVlLFxyXG4vLyAgICAgICAgICAgY2F0ZWdvcnk6IGRiTWVudT8uY2F0ZWdvcnkgfHwgbWVudS5jYXRlZ29yeSB8fCBcIlVuY2F0ZWdvcml6ZWRcIixcclxuLy8gICAgICAgICAgIG9yZGVyOiBkYk1lbnU/Lm9yZGVyIHx8IG1lbnUub3JkZXIgfHwgMCxcclxuLy8gICAgICAgICB9O1xyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIC8vIFNvcnQgYnkgb3JkZXJcclxuLy8gICAgICAgZmluYWxNZW51cy5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciB8fCAwKSAtIChiLm9yZGVyIHx8IDApKTtcclxuLy8gICAgICAgc2V0TWVudXMoZmluYWxNZW51cyk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4vLyAgICAgICBzZXRNZW51cyhcclxuLy8gICAgICAgICBzdWJNZW51cy5tYXAoKG1lbnUpID0+ICh7XHJcbi8vICAgICAgICAgICAuLi5tZW51LFxyXG4vLyAgICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuLy8gICAgICAgICAgIGNhdGVnb3J5OiBtZW51LmNhdGVnb3J5IHx8IFwiVW5jYXRlZ29yaXplZFwiLFxyXG4vLyAgICAgICAgICAgb3JkZXI6IG1lbnUub3JkZXIgfHwgMCxcclxuLy8gICAgICAgICB9KSlcclxuLy8gICAgICAgKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlTmF2aWdhdGlvbiA9IChsaW5rKSA9PiB7XHJcbi8vICAgICBuYXZpZ2F0ZShsaW5rKTtcclxuLy8gICAgIHNldFRpbWVvdXQoc2Nyb2xsVG9Ub3AsIDEwMCk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgcmVmID0gdXNlUmVmKG51bGwpO1xyXG5cclxuLy8gICBjb25zdCBmaWx0ZXJlZE1lbnVzID0gbWVudXNcclxuLy8gICAgIC5maWx0ZXIobWVudSA9PiBtZW51LnZpc2libGUpXHJcbi8vICAgICAuZmlsdGVyKG1lbnUgPT4gYWN0aXZlQ2F0ZWdvcnkgPT09IFwiQWxsXCIgfHwgbWVudS5jYXRlZ29yeSA9PT0gYWN0aXZlQ2F0ZWdvcnkpXHJcbi8vICAgICAuZmlsdGVyKG1lbnUgPT4gbWVudS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpKTtcclxuXHJcbi8vICAgY29uc3QgZ3JvdXBlZE1lbnVzID0gbWVudXNcclxuLy8gICAgIC5maWx0ZXIoKG1lbnUpID0+IG1lbnUudmlzaWJsZSlcclxuLy8gICAgIC5yZWR1Y2UoKGFjYywgbWVudSkgPT4ge1xyXG4vLyAgICAgICBjb25zdCBjYXRlZ29yeSA9IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCI7XHJcbi8vICAgICAgIGlmICghYWNjW2NhdGVnb3J5XSkge1xyXG4vLyAgICAgICAgIGFjY1tjYXRlZ29yeV0gPSBbXTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICBhY2NbY2F0ZWdvcnldLnB1c2gobWVudSk7XHJcbi8vICAgICAgIHJldHVybiBhY2M7XHJcbi8vICAgICB9LCB7fSk7XHJcblxyXG4vLyAgIC8vIFNvcnQgaXRlbXMgd2l0aGluIGVhY2ggY2F0ZWdvcnkgYnkgb3JkZXJcclxuLy8gICBPYmplY3Qua2V5cyhncm91cGVkTWVudXMpLmZvckVhY2goY2F0ZWdvcnkgPT4ge1xyXG4vLyAgICAgZ3JvdXBlZE1lbnVzW2NhdGVnb3J5XS5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciB8fCAwKSAtIChiLm9yZGVyIHx8IDApKTtcclxuLy8gICB9KTtcclxuXHJcbi8vICAgLy8gU29ydCBjYXRlZ29yaWVzIGJhc2VkIG9uIGN1c3RvbSBvcmRlclxyXG4vLyAgIGNvbnN0IHNvcnRlZENhdGVnb3JpZXMgPSBPYmplY3Qua2V5cyhncm91cGVkTWVudXMpLnNvcnQoKGEsIGIpID0+IHtcclxuLy8gICAgIGNvbnN0IGluZGV4QSA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihhKTtcclxuLy8gICAgIGNvbnN0IGluZGV4QiA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihiKTtcclxuXHJcbi8vICAgICBpZiAoaW5kZXhBICE9PSAtMSAmJiBpbmRleEIgIT09IC0xKSB7XHJcbi8vICAgICAgIHJldHVybiBpbmRleEEgLSBpbmRleEI7XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAoaW5kZXhBICE9PSAtMSkgcmV0dXJuIC0xO1xyXG4vLyAgICAgaWYgKGluZGV4QiAhPT0gLTEpIHJldHVybiAxO1xyXG4vLyAgICAgcmV0dXJuIGEubG9jYWxlQ29tcGFyZShiKTtcclxuLy8gICB9KTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlQ2xlYXJTZWFyY2ggPSAoKSA9PiB7XHJcbi8vICAgICBzZXRTZWFyY2hRdWVyeShcIlwiKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBzYXZlUmVwb3J0cyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldFNhdmluZyh0cnVlKTtcclxuLy8gICAgICAgYXdhaXQgYXBpLnB1dChcIi92MS9hZG1pbi9yZXBvcnQtdmlzaWJpbGl0eVwiLCB7XHJcbi8vICAgICAgICAgcmVwb3J0czogbWVudXMubWFwKChtZW51KSA9PiAoe1xyXG4vLyAgICAgICAgICAgcmVwb3J0SWQ6IG1lbnUuaWQsXHJcbi8vICAgICAgICAgICB2aXNpYmxlOiBtZW51LnZpc2libGUsXHJcbi8vICAgICAgICAgICBjYXRlZ29yeTogbWVudS5jYXRlZ29yeSxcclxuLy8gICAgICAgICAgIG9yZGVyOiBtZW51Lm9yZGVyIHx8IDAsXHJcbi8vICAgICAgICAgfSkpLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiUmVwb3J0IHNldHRpbmdzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4vLyAgICAgICBhd2FpdCBmZXRjaFJlcG9ydHMoKTtcclxuLy8gICAgICAgc2V0TWFuYWdlTW9kYWwoZmFsc2UpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuLy8gICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcmVwb3J0IHNldHRpbmdzXCIpO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0U2F2aW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBIYW5kbGUgY2F0ZWdvcnkgY2hhbmdlIGZvciBhIHNwZWNpZmljIHJlcG9ydFxyXG4vLyAgIGNvbnN0IGhhbmRsZUNhdGVnb3J5Q2hhbmdlID0gKG1lbnVJZCwgbmV3Q2F0ZWdvcnkpID0+IHtcclxuLy8gICAgIHNldE1lbnVzKHByZXYgPT4ge1xyXG4vLyAgICAgICAvLyBHZXQgdGhlIGN1cnJlbnQgY2F0ZWdvcnkgb2YgdGhlIG1lbnUgYmVpbmcgbW92ZWRcclxuLy8gICAgICAgY29uc3QgbWVudVRvTW92ZSA9IHByZXYuZmluZChtID0+IG0uaWQgPT09IG1lbnVJZCk7XHJcbi8vICAgICAgIGNvbnN0IG9sZENhdGVnb3J5ID0gbWVudVRvTW92ZT8uY2F0ZWdvcnk7XHJcblxyXG4vLyAgICAgICAvLyBVcGRhdGUgdGhlIG1lbnUgd2l0aCBuZXcgY2F0ZWdvcnlcclxuLy8gICAgICAgY29uc3QgdXBkYXRlZE1lbnVzID0gcHJldi5tYXAoaXRlbSA9PiB7XHJcbi8vICAgICAgICAgaWYgKGl0ZW0uaWQgPT09IG1lbnVJZCkge1xyXG4vLyAgICAgICAgICAgcmV0dXJuIHsgLi4uaXRlbSwgY2F0ZWdvcnk6IG5ld0NhdGVnb3J5IH07XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIHJldHVybiBpdGVtO1xyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIC8vIEdldCBhbGwgaXRlbXMgaW4gdGhlIG5ldyBjYXRlZ29yeSBhbmQgcmVvcmRlciB0aGVtXHJcbi8vICAgICAgIGNvbnN0IGl0ZW1zSW5OZXdDYXRlZ29yeSA9IHVwZGF0ZWRNZW51c1xyXG4vLyAgICAgICAgIC5maWx0ZXIobSA9PiBtLmNhdGVnb3J5ID09PSBuZXdDYXRlZ29yeSlcclxuLy8gICAgICAgICAuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcblxyXG4vLyAgICAgICAvLyBVcGRhdGUgb3JkZXIgZm9yIGl0ZW1zIGluIHRoZSBuZXcgY2F0ZWdvcnlcclxuLy8gICAgICAgaXRlbXNJbk5ld0NhdGVnb3J5LmZvckVhY2goKGl0ZW0sIGluZGV4KSA9PiB7XHJcbi8vICAgICAgICAgY29uc3QgZm91bmRJdGVtID0gdXBkYXRlZE1lbnVzLmZpbmQobSA9PiBtLmlkID09PSBpdGVtLmlkKTtcclxuLy8gICAgICAgICBpZiAoZm91bmRJdGVtKSB7XHJcbi8vICAgICAgICAgICBmb3VuZEl0ZW0ub3JkZXIgPSBpbmRleDtcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgLy8gSWYgbW92aW5nIGZyb20gb2xkIGNhdGVnb3J5LCByZW9yZGVyIGl0ZW1zIGluIG9sZCBjYXRlZ29yeVxyXG4vLyAgICAgICBpZiAob2xkQ2F0ZWdvcnkgJiYgb2xkQ2F0ZWdvcnkgIT09IG5ld0NhdGVnb3J5KSB7XHJcbi8vICAgICAgICAgY29uc3QgaXRlbXNJbk9sZENhdGVnb3J5ID0gdXBkYXRlZE1lbnVzXHJcbi8vICAgICAgICAgICAuZmlsdGVyKG0gPT4gbS5jYXRlZ29yeSA9PT0gb2xkQ2F0ZWdvcnkpXHJcbi8vICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcblxyXG4vLyAgICAgICAgIGl0ZW1zSW5PbGRDYXRlZ29yeS5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICAgICAgY29uc3QgZm91bmRJdGVtID0gdXBkYXRlZE1lbnVzLmZpbmQobSA9PiBtLmlkID09PSBpdGVtLmlkKTtcclxuLy8gICAgICAgICAgIGlmIChmb3VuZEl0ZW0pIHtcclxuLy8gICAgICAgICAgICAgZm91bmRJdGVtLm9yZGVyID0gaW5kZXg7XHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIHJldHVybiB1cGRhdGVkTWVudXM7XHJcbi8vICAgICB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBEcmFnIGFuZCBkcm9wIGhhbmRsZXJzIGZvciByZW9yZGVyaW5nIHdpdGhpbiBjYXRlZ29yaWVzXHJcbi8vICAgY29uc3QgaGFuZGxlRHJhZ1N0YXJ0ID0gKGUsIGl0ZW0sIGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbSh7IGl0ZW0sIGNhdGVnb3J5IH0pO1xyXG4vLyAgICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9ICdtb3ZlJztcclxuLy8gICAgIGUuZGF0YVRyYW5zZmVyLnNldERhdGEoJ3RleHQvcGxhaW4nLCBKU09OLnN0cmluZ2lmeSh7IGlkOiBpdGVtLmlkLCBjYXRlZ29yeSB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlRHJhZ092ZXIgPSAoZSwgaXRlbSwgY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbSh7IGl0ZW0sIGNhdGVnb3J5IH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZURyYWdFbmQgPSAoKSA9PiB7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVEcm9wID0gKGUsIHRhcmdldEl0ZW0sIHRhcmdldENhdGVnb3J5KSA9PiB7XHJcbi8vICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4vLyAgICAgaWYgKCFkcmFnZ2VkSXRlbSB8fCBkcmFnZ2VkSXRlbS5jYXRlZ29yeSAhPT0gdGFyZ2V0Q2F0ZWdvcnkpIHtcclxuLy8gICAgICAgc2V0RHJhZ2dlZEl0ZW0obnVsbCk7XHJcbi8vICAgICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGNvbnN0IHNvdXJjZUl0ZW0gPSBkcmFnZ2VkSXRlbS5pdGVtO1xyXG4vLyAgICAgY29uc3Qgc291cmNlSW5kZXggPSBtZW51cy5maW5kSW5kZXgobSA9PiBtLmlkID09PSBzb3VyY2VJdGVtLmlkKTtcclxuLy8gICAgIGNvbnN0IHRhcmdldEluZGV4ID0gbWVudXMuZmluZEluZGV4KG0gPT4gbS5pZCA9PT0gdGFyZ2V0SXRlbS5pZCk7XHJcblxyXG4vLyAgICAgaWYgKHNvdXJjZUluZGV4ID09PSAtMSB8fCB0YXJnZXRJbmRleCA9PT0gLTEgfHwgc291cmNlSW5kZXggPT09IHRhcmdldEluZGV4KSB7XHJcbi8vICAgICAgIHNldERyYWdnZWRJdGVtKG51bGwpO1xyXG4vLyAgICAgICBzZXREcmFnT3Zlckl0ZW0obnVsbCk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBjb25zdCBuZXdNZW51cyA9IFsuLi5tZW51c107XHJcbi8vICAgICBjb25zdCBbcmVtb3ZlZF0gPSBuZXdNZW51cy5zcGxpY2Uoc291cmNlSW5kZXgsIDEpO1xyXG4vLyAgICAgbmV3TWVudXMuc3BsaWNlKHRhcmdldEluZGV4LCAwLCByZW1vdmVkKTtcclxuXHJcbi8vICAgICAvLyBVcGRhdGUgb3JkZXIgdmFsdWVzXHJcbi8vICAgICBjb25zdCBjYXRlZ29yeUl0ZW1zID0gbmV3TWVudXMuZmlsdGVyKG0gPT4gbS5jYXRlZ29yeSA9PT0gdGFyZ2V0Q2F0ZWdvcnkpO1xyXG4vLyAgICAgY2F0ZWdvcnlJdGVtcy5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICBpdGVtLm9yZGVyID0gaW5kZXg7XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICBzZXRNZW51cyhuZXdNZW51cyk7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBJbXByb3ZlZCBzaWRlYmFyIHJlbmRlciB3aXRoIGN1c3RvbSBjYXRlZ29yeSBvcmRlclxyXG4vLyAgIGNvbnN0IHJlbmRlclNpZGViYXIgPSAoKSA9PiB7XHJcbi8vICAgICByZXR1cm4gKFxyXG4vLyAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgcmVmPXtyZWZ9XHJcbi8vICAgICAgICAgY2xhc3NOYW1lPXtgbWluLWgtc2NyZWVuIG1heC1oLWF1dG8gcC00IHB0LTggJHtvcGVuID8gXCJ3LTcyXCIgOiBcInctMjBcIn0gZHVyYXRpb24tMzAwIHJlbGF0aXZlIGJnLXdoaXRlIHNoYWRvdy1sZ2B9XHJcbi8vICAgICAgID5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02IHB4LTJcIj5cclxuLy8gICAgICAgICAgIHtvcGVuICYmIChcclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgQ2F0ZWdvcmllc1xyXG4vLyAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKCFvcGVuKX1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xyXG4vLyAgICAgICAgICAgICAgICFvcGVuID8gXCJteC1hdXRvXCIgOiBcIlwiXHJcbi8vICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICA8RmlDaGV2cm9uTGVmdFxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtZ3JheS02MDAgdGV4dC14bCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgJHtcclxuLy8gICAgICAgICAgICAgICAgICFvcGVuID8gXCJyb3RhdGUtMTgwXCIgOiBcIlwiXHJcbi8vICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAge3NvcnRlZENhdGVnb3JpZXNcclxuLy8gICAgICAgICAgIC5maWx0ZXIoKGNhdGVnb3J5KSA9PiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5sZW5ndGgpXHJcbi8vICAgICAgICAgICAubWFwKChjYXRlZ29yeSkgPT4ge1xyXG4vLyAgICAgICAgICAgICBjb25zdCBpdGVtcyA9IGdyb3VwZWRNZW51c1tjYXRlZ29yeV0gfHwgW107XHJcbi8vICAgICAgICAgICAgIGNvbnN0IGlzRXhwYW5kZWQgPSBleHBhbmRlZENhdGVnb3JpZXNbY2F0ZWdvcnldIHx8IGZhbHNlO1xyXG4vLyAgICAgICAgICAgICBjb25zdCBpdGVtQ291bnQgPSBpdGVtcy5sZW5ndGg7XHJcblxyXG4vLyAgICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYga2V5PXtjYXRlZ29yeX0gY2xhc3NOYW1lPVwibWItM1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuICYmIHRvZ2dsZUNhdGVnb3J5KGNhdGVnb3J5KX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMi41IHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb3BlbiA/IFwiaG92ZXI6YmctZ3JheS01MFwiIDogXCJqdXN0aWZ5LWNlbnRlciBob3ZlcjpiZy1ncmF5LTUwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtvcGVuID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCB0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDAgYmctZ3JheS0xMDAgcHgtMS41IHB5LTAuNSByb3VuZGVkLWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbUNvdW50fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtpc0V4cGFuZGVkID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8QnNDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtc21cIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPEJzQ2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1zbVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZ3JheS0zMDBcIj48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHtvcGVuICYmIGlzRXhwYW5kZWQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTMgYm9yZGVyLWwtMiBib3JkZXItZ3JheS0xMDAgcGwtMyBzcGFjZS15LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7aXRlbXMubWFwKCh7IHRpdGxlLCBsaW5rLCBJY29uLCBjb2xvciwgaXNOZXcgfSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB0bz17bGlua31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjcm9sbFRvVG9wKCk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SGlkZVNpZGViYXIoIWhpZGVTaWRlYmFyKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIuNSByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCBzaGFkb3ctc21cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOnRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgeyh7IGlzQWN0aXZlIH0pID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MTh9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgPyBcInRleHQtYmx1ZS02MDBcIiA6IFwidGV4dC1ncmF5LTQwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIGxlYWRpbmctdGlnaHRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTmV3ICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5FV1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICk7XHJcbi8vICAgICAgICAgICB9KX1cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIFJlbmRlciBjYXRlZ29yaWVzIGNoaXBzIHdpdGggY3VzdG9tIG9yZGVyXHJcbi8vICAgY29uc3QgcmVuZGVyQ2F0ZWdvcnlDaGlwcyA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGNoaXBDYXRlZ29yaWVzID0gW1wiQWxsXCIsIC4uLnNvcnRlZENhdGVnb3JpZXNdO1xyXG5cclxuLy8gICAgIHJldHVybiAoXHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgbWItNiBwYi0yIG92ZXJmbG93LXgtYXV0b1wiPlxyXG4vLyAgICAgICAgIHtjaGlwQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICAgICAgICBjb25zdCBjb3VudCA9IGNhdGVnb3J5ID09PSBcIkFsbFwiXHJcbi8vICAgICAgICAgICAgID8gbWVudXMuZmlsdGVyKG0gPT4gbS52aXNpYmxlKS5sZW5ndGhcclxuLy8gICAgICAgICAgICAgOiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5sZW5ndGggfHwgMDtcclxuXHJcbi8vICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAga2V5PXtjYXRlZ29yeX1cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVDYXRlZ29yeShjYXRlZ29yeSl9XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4vLyAgICAgICAgICAgICAgICAgYWN0aXZlQ2F0ZWdvcnkgPT09IGNhdGVnb3J5XHJcbi8vICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tYmx1ZS03MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LWJsdWUtMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGhvdmVyOmJvcmRlci1ncmF5LTMwMFwiXHJcbi8vICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XHJcbi8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbWwtMS41IHRleHQteHMgJHtcclxuLy8gICAgICAgICAgICAgICAgIGFjdGl2ZUNhdGVnb3J5ID09PSBjYXRlZ29yeSA/IFwidGV4dC1ibHVlLTEwMFwiIDogXCJ0ZXh0LWdyYXktNDAwXCJcclxuLy8gICAgICAgICAgICAgICB9YH0+XHJcbi8vICAgICAgICAgICAgICAgICAoe2NvdW50fSlcclxuLy8gICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICB9KX1cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIFJlbmRlciBncmlkIGNhcmRzXHJcbi8vICAgY29uc3QgcmVuZGVyR3JpZENhcmRzID0gKCkgPT4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00IGdhcC01XCI+XHJcbi8vICAgICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlzTmV3IH0pID0+IChcclxuLy8gICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICBrZXk9e2xpbmt9XHJcbi8vICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGxpbmspfVxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIlxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMjAwIGhvdmVyOi10cmFuc2xhdGUteS0xLjVcIj5cclxuLy8gICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IGgtMjggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuYH1cclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay81XCI+PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC01eGwgdGV4dC13aGl0ZSBkcm9wLXNoYWRvdy1sZyByZWxhdGl2ZSB6LTEwXCIgLz5cclxuLy8gICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBzaGFkb3ctbGcgei0xMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBORVdcclxuLy8gICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTVcIj5cclxuLy8gICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzIGxpbmUtY2xhbXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4vLyAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIHRleHQtYmx1ZS02MDAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlZpZXcgUmVwb3J0PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IG1sLTIgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDVsNyA3LTcgN1wiIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgKSl9XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG5cclxuLy8gICAvLyBSZW5kZXIgbGlzdCBpdGVtc1xyXG4vLyAgIGNvbnN0IHJlbmRlckxpc3RJdGVtcyA9ICgpID0+IChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbi8vICAgICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlkLCBpc05ldyB9KSA9PiAoXHJcbi8vICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAga2V5PXtpZH1cclxuLy8gICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbi8vICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMjAwIGhvdmVyOi10cmFuc2xhdGUteC0xXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgcC00IGhvdmVyOmJnLWdyYXktNTAvNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IHJvdW5kZWQteGwgcC0zIG1yLTQgZmxleC1zaHJpbmstMGB9PlxyXG4vLyAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC14bCB0ZXh0LXdoaXRlXCIgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBtaW4tdy0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzIHRydW5jYXRlXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTQwMCB0by1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2UgZmxleC1zaHJpbmstMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgTkVXXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMC41XCI+Q2xpY2sgdG8gdmlldyBkZXRhaWxlZCByZXBvcnQ8L3A+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktMzAwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS01MDAgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLWFsbCBmbGV4LXNocmluay0wIG1sLTJcIlxyXG4vLyAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDVsNyA3LTcgN1wiIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICkpfVxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuXHJcbi8vICAgLy8gUmVuZGVyIGRyYWdnYWJsZSBpdGVtcyB3aXRoIGNhdGVnb3J5IGRyb3Bkb3duIGZvciBtYW5hZ2UgbW9kYWxcclxuLy8gICBjb25zdCByZW5kZXJEcmFnZ2FibGVJdGVtcyA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGdyb3VwZWRCeUNhdGVnb3J5ID0ge307XHJcbi8vICAgICBtZW51cy5mb3JFYWNoKG1lbnUgPT4ge1xyXG4vLyAgICAgICBjb25zdCBjYXRlZ29yeSA9IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCI7XHJcbi8vICAgICAgIGlmICghZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldKSB7XHJcbi8vICAgICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldID0gW107XHJcbi8vICAgICAgIH1cclxuLy8gICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldLnB1c2gobWVudSk7XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICAvLyBTb3J0IGl0ZW1zIHdpdGhpbiBlYWNoIGNhdGVnb3J5IGJ5IG9yZGVyXHJcbi8vICAgICBPYmplY3Qua2V5cyhncm91cGVkQnlDYXRlZ29yeSkuZm9yRWFjaChjYXRlZ29yeSA9PiB7XHJcbi8vICAgICAgIGdyb3VwZWRCeUNhdGVnb3J5W2NhdGVnb3J5XS5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciB8fCAwKSAtIChiLm9yZGVyIHx8IDApKTtcclxuLy8gICAgIH0pO1xyXG5cclxuLy8gICAgIC8vIFNvcnQgY2F0ZWdvcmllc1xyXG4vLyAgICAgY29uc3Qgc29ydGVkQ2F0S2V5cyA9IE9iamVjdC5rZXlzKGdyb3VwZWRCeUNhdGVnb3J5KS5zb3J0KChhLCBiKSA9PiB7XHJcbi8vICAgICAgIGNvbnN0IGluZGV4QSA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihhKTtcclxuLy8gICAgICAgY29uc3QgaW5kZXhCID0gY2F0ZWdvcnlPcmRlci5pbmRleE9mKGIpO1xyXG4vLyAgICAgICBpZiAoaW5kZXhBICE9PSAtMSAmJiBpbmRleEIgIT09IC0xKSByZXR1cm4gaW5kZXhBIC0gaW5kZXhCO1xyXG4vLyAgICAgICBpZiAoaW5kZXhBICE9PSAtMSkgcmV0dXJuIC0xO1xyXG4vLyAgICAgICBpZiAoaW5kZXhCICE9PSAtMSkgcmV0dXJuIDE7XHJcbi8vICAgICAgIHJldHVybiBhLmxvY2FsZUNvbXBhcmUoYik7XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICAvLyBHZXQgYWxsIGF2YWlsYWJsZSBjYXRlZ29yaWVzIGZvciBkcm9wZG93blxyXG4vLyAgICAgY29uc3QgYWxsQ2F0ZWdvcmllcyA9IGdldEFsbENhdGVnb3JpZXMoKTtcclxuXHJcbi8vICAgICByZXR1cm4gc29ydGVkQ2F0S2V5cy5tYXAoY2F0ZWdvcnkgPT4gKFxyXG4vLyAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnl9IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuLy8gICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTNcIj5cclxuLy8gICAgICAgICAgIHtjYXRlZ29yeX1cclxuLy8gICAgICAgICA8L2g0PlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbi8vICAgICAgICAgICB7Z3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldLm1hcCgobWVudSwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICAgICAgY29uc3QgaXNEcmFnZ2luZyA9IGRyYWdnZWRJdGVtPy5pdGVtPy5pZCA9PT0gbWVudS5pZDtcclxuLy8gICAgICAgICAgICAgY29uc3QgaXNEcmFnT3ZlciA9IGRyYWdPdmVySXRlbT8uaXRlbT8uaWQgPT09IG1lbnUuaWQ7XHJcblxyXG4vLyAgICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgIGtleT17bWVudS5pZH1cclxuLy8gICAgICAgICAgICAgICAgIGRyYWdnYWJsZVxyXG4vLyAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9eyhlKSA9PiBoYW5kbGVEcmFnU3RhcnQoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgb25EcmFnT3Zlcj17KGUpID0+IGhhbmRsZURyYWdPdmVyKGUsIG1lbnUsIGNhdGVnb3J5KX1cclxuLy8gICAgICAgICAgICAgICAgIG9uRHJhZ0VuZD17aGFuZGxlRHJhZ0VuZH1cclxuLy8gICAgICAgICAgICAgICAgIG9uRHJvcD17KGUpID0+IGhhbmRsZURyb3AoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC00IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7XHJcbi8vICAgICAgICAgICAgICAgICAgIGlzRHJhZ2dpbmdcclxuLy8gICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS01MCBib3JkZXItMiBib3JkZXItYmx1ZS00MDAgc2hhZG93LWxnIG9wYWNpdHktNTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDogaXNEcmFnT3ZlclxyXG4vLyAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLWJsdWUtNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMCBib3JkZXItMiBib3JkZXItdHJhbnNwYXJlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgfSBjdXJzb3ItbW92ZWB9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmbGV4LTEgbWluLXctMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgY3Vyc29yLWdyYWIgZmxleC1zaHJpbmstMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTcgMmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTYtMTJhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00em0wIDZhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00em0wIDZhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00elwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHttZW51LnRpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+T3JkZXI6IHttZW51Lm9yZGVyIHx8IGluZGV4fTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTMwMFwiPnw8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttZW51LmNhdGVnb3J5fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNhdGVnb3J5Q2hhbmdlKG1lbnUuaWQsIGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBib3JkZXIgcm91bmRlZCBweC0yIHB5LTEgYmctd2hpdGUgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTQwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2FsbENhdGVnb3JpZXMubWFwKGNhdCA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NhdH0gdmFsdWU9e2NhdH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWwtNCBmbGV4LXNocmluay0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHttZW51LnZpc2libGUgPyBcIlZpc2libGVcIiA6IFwiSGlkZGVuXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPFN3aXRjaFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e21lbnUudmlzaWJsZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGNoZWNrZWQpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHNldE1lbnVzKChwcmV2KSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2Lm1hcCgoaXRlbSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmlkID09PSBtZW51LmlkXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHsgLi4uaXRlbSwgdmlzaWJsZTogY2hlY2tlZCB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICk7XHJcbi8vICAgICAgICAgICB9KX1cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gZmxleCBtdC0xNiBiZy1ncmF5LTUwXCI+XHJcbi8vICAgICAgIDxOYXZiYXIgLz5cclxuLy8gICAgICAgPFNpZGViYXIgaGlkZVNpZGViYXI9e2hpZGVTaWRlYmFyfSAvPlxyXG5cclxuLy8gICAgICAgey8qIFNpZGViYXIgKi99XHJcbi8vICAgICAgIDxkaXZcclxuLy8gICAgICAgICBjbGFzc05hbWU9e2Ake29wZW4gPyBcInctNzJcIiA6IFwidy0yMFwifSBiZy13aGl0ZSBtaW4taC1zY3JlZW4gYm9yZGVyLXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LXktYXV0byBmbGV4LXNocmluay0wIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBgfVxyXG4vLyAgICAgICA+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctd2hpdGUgei0xMCBwLTQgbXQtMTBcIj5cclxuLy8gICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgIG5hdmlnYXRlKFwiL3JlcG9ydHNcIik7XHJcbi8vICAgICAgICAgICAgICAgc2Nyb2xsVG9Ub3AoKTtcclxuLy8gICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdy1mdWxsICR7XHJcbi8vICAgICAgICAgICAgICAgb3BlblxyXG4vLyAgICAgICAgICAgICAgICAgPyBcInB4LTQgcHktMi41IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWJsdWUtNzAwIHRleHQtd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzY2FsZS1bMS4wMl1cIlxyXG4vLyAgICAgICAgICAgICAgICAgOiBcInAtMi41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTEwXCJcclxuLy8gICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxGYUNoYXJ0QmFyIGNsYXNzTmFtZT17b3BlbiA/IFwidGV4dC1ibHVlLTEwMCB0ZXh0LWxnXCIgOiBcInRleHQtbGdcIn0gLz5cclxuLy8gICAgICAgICAgICAge29wZW4gJiYgPHNwYW4gY2xhc3NOYW1lPVwidHJhY2tpbmctd2lkZVwiPlJlcG9ydHM8L3NwYW4+fVxyXG4vLyAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAge3JlbmRlclNpZGViYXIoKX1cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogTWFpbiBDb250ZW50ICovfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTYgIG92ZXJmbG93LWhpZGRlbiBtYXgtaC1zY3JlZW4gb3ZlcmZsb3cteS1hdXRvIFwiPlxyXG4vLyAgICAgICAgIHtsb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvcmVwb3J0c1wiID8gKFxyXG4vLyAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgey8qIFNlYXJjaCBCYXIgKi99XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBtdC0xMCBtci02MCBcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1heC13LTJ4bCBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC00IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPElvU2VhcmNoT3V0bGluZSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQteGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCByZXBvcnRzLi4uXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEyIHByLTEyIHB5LTMuNSB0ZXh0LWJhc2UgYmctd2hpdGUgYm9yZGVyLTIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLWJsdWUtNTAwLzIwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBzaGFkb3ctc20gaG92ZXI6c2hhZG93IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICB7c2VhcmNoUXVlcnkgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJTZWFyY2h9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgcHItNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxJb0Nsb3NlQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBDb250cm9scyBCYXIgKi99XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAge3JlbmRlckNhdGVnb3J5Q2hpcHMoKX1cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdUeXBlKFwiZ3JpZFwiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZpZXdUeXBlID09PSBcImdyaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy13aGl0ZSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkdyaWQgVmlld1wiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxCaUdyaWQgc2l6ZT17MjB9IC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld1R5cGUoXCJsaXN0XCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIuNSByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmlld1R5cGUgPT09IFwibGlzdFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTGlzdCBWaWV3XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPFRiTGlzdCBzaXplPXsyMH0gLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSByb3VuZGVkLWxnIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgbWwtMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1hbmFnZU1vZGFsKHRydWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxGaVNldHRpbmdzIHNpemU9ezE2fSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIE1hbmFnZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogUmVzdWx0cyBTdGF0cyAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFNob3dpbmcge2ZpbHRlcmVkTWVudXMubGVuZ3RofSByZXBvcnR7ZmlsdGVyZWRNZW51cy5sZW5ndGggIT09IDEgPyBcInNcIiA6IFwiXCJ9XHJcbi8vICAgICAgICAgICAgICAge3NlYXJjaFF1ZXJ5ICYmIGAgZm9yIFwiJHtzZWFyY2hRdWVyeX1cImB9XHJcbi8vICAgICAgICAgICAgICAge2FjdGl2ZUNhdGVnb3J5ICE9PSBcIkFsbFwiICYmIGAgaW4gJHthY3RpdmVDYXRlZ29yeX1gfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBMb2FkaW5nIFN0YXRlICovfVxyXG4vLyAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEyIHctMTIgYm9yZGVyLTQgYm9yZGVyLWJsdWUtNjAwIGJvcmRlci10LXRyYW5zcGFyZW50XCI+PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICkgOiBmaWx0ZXJlZE1lbnVzLmxlbmd0aCA9PT0gMCA/IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTIwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTIwIGgtMjAgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPElvU2VhcmNoT3V0bGluZSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCB0ZXh0LWdyYXktNDAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTJcIj5ObyByZXBvcnRzIGZvdW5kPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5UcnkgYWRqdXN0aW5nIHlvdXIgc2VhcmNoIG9yIGZpbHRlciBjcml0ZXJpYTwvcD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICB2aWV3VHlwZSA9PT0gXCJncmlkXCIgPyByZW5kZXJHcmlkQ2FyZHMoKSA6IHJlbmRlckxpc3RJdGVtcygpXHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPE91dGxldCAvPlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgey8qIE1hbmFnZSBNb2RhbCB3aXRoIENhdGVnb3J5IERyb3Bkb3duIGFuZCBEcmFnICYgRHJvcCAqL31cclxuLy8gICAgICAgPE1vZGFsXHJcbi8vICAgICAgICAgdGl0bGU9e1xyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICA8RmlTZXR0aW5ncyBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuLy8gICAgICAgICAgICAgPHNwYW4+TWFuYWdlIFJlcG9ydHMgLSBPcmRlciwgQ2F0ZWdvcnkgJiBWaXNpYmlsaXR5PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIG9wZW49e21hbmFnZU1vZGFsfVxyXG4vLyAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRNYW5hZ2VNb2RhbChmYWxzZSl9XHJcbi8vICAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4vLyAgICAgICAgIHdpZHRoPXs5MDB9XHJcbi8vICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC0yeGxcIlxyXG4vLyAgICAgICA+XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IG1heC1oLVs2MHZoXSBvdmVyZmxvdy15LWF1dG8gcHItMiBtdC0xMFwiPlxyXG4vLyAgICAgICAgICAge3JlbmRlckRyYWdnYWJsZUl0ZW1zKCl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBtdC02IHB0LTQgYm9yZGVyLXRcIj5cclxuLy8gICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZm9udC1tZWRpdW1cIlxyXG4vLyAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNYW5hZ2VNb2RhbChmYWxzZSl9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIENhbmNlbFxyXG4vLyAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBmb250LW1lZGl1bSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuLy8gICAgICAgICAgICAgb25DbGljaz17c2F2ZVJlcG9ydHN9XHJcbi8vICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIHtzYXZpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC00IHctNCBib3JkZXItMiBib3JkZXItd2hpdGUgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIj48L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICBTYXZpbmcuLi5cclxuLy8gICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgXCJTYXZlIENoYW5nZXNcIlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvTW9kYWw+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG4vL3dvcmtpbmdcclxuLy8gY29uc3QgUmVwb3J0cyA9ICgpID0+IHtcclxuLy8gICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbi8vICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4vLyAgIGNvbnN0IFthY3RpdmVDYXRlZ29yeSwgc2V0QWN0aXZlQ2F0ZWdvcnldID0gdXNlU3RhdGUoXCJBbGxcIik7XHJcbi8vICAgY29uc3QgW3ZpZXdUeXBlLCBzZXRWaWV3VHlwZV0gPSB1c2VTdGF0ZShcImdyaWRcIik7XHJcbi8vICAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuLy8gICBjb25zdCBbaGlkZVNpZGViYXIsIHNldEhpZGVTaWRlYmFyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbZXhwYW5kZWRDYXRlZ29yaWVzLCBzZXRFeHBhbmRlZENhdGVnb3JpZXNdID0gdXNlU3RhdGUoe30pO1xyXG4vLyAgIGNvbnN0IFttZW51cywgc2V0TWVudXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW21hbmFnZU1vZGFsLCBzZXRNYW5hZ2VNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4vLyAgIGNvbnN0IFtkcmFnZ2VkSXRlbSwgc2V0RHJhZ2dlZEl0ZW1dID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW2RyYWdPdmVySXRlbSwgc2V0RHJhZ092ZXJJdGVtXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuLy8gICAvLyBEZWZpbmUgY3VzdG9tIGNhdGVnb3J5IG9yZGVyXHJcbi8vICAgY29uc3QgY2F0ZWdvcnlPcmRlciA9IFtcIkN1c3RvbWVyXCIsIFwiQXVjdGlvblwiLCBcIlBheW1lbnRzXCJdO1xyXG5cclxuLy8gICAvLyBHZXQgYWxsIHVuaXF1ZSBjYXRlZ29yaWVzIGZyb20gbWVudXNcclxuLy8gICBjb25zdCBnZXRBbGxDYXRlZ29yaWVzID0gKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgY2F0ZWdvcmllcyA9IG5ldyBTZXQoKTtcclxuLy8gICAgIG1lbnVzLmZvckVhY2gobWVudSA9PiB7XHJcbi8vICAgICAgIGlmIChtZW51LmNhdGVnb3J5KSB7XHJcbi8vICAgICAgICAgY2F0ZWdvcmllcy5hZGQobWVudS5jYXRlZ29yeSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0pO1xyXG4vLyAgICAgcmV0dXJuIEFycmF5LmZyb20oY2F0ZWdvcmllcyk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgdG9nZ2xlQ2F0ZWdvcnkgPSAoY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgIHNldEV4cGFuZGVkQ2F0ZWdvcmllcyhwcmV2ID0+ICh7XHJcbi8vICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgIFtjYXRlZ29yeV06ICFwcmV2W2NhdGVnb3J5XVxyXG4vLyAgICAgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHNjcm9sbFRvVG9wID0gKCkgPT4ge1xyXG4vLyAgICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgZmV0Y2hSZXBvcnRzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICBjb25zdCBmZXRjaFJlcG9ydHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9yZXBvcnQtdmlzaWJpbGl0eVwiKTtcclxuLy8gICAgICAgY29uc3QgdmlzaWJpbGl0eSA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGZpbmFsTWVudXMgPSBzdWJNZW51cy5tYXAoKG1lbnUpID0+IHtcclxuLy8gICAgICAgICBjb25zdCBkYk1lbnUgPSB2aXNpYmlsaXR5LmZpbmQoXHJcbi8vICAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5yZXBvcnRJZCA9PT0gbWVudS5pZFxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgICAgIC4uLm1lbnUsXHJcbi8vICAgICAgICAgICB2aXNpYmxlOiBkYk1lbnUgPyBkYk1lbnUudmlzaWJsZSA6IHRydWUsXHJcbi8vICAgICAgICAgICBjYXRlZ29yeTogZGJNZW51Py5jYXRlZ29yeSB8fCBtZW51LmNhdGVnb3J5IHx8IFwiVW5jYXRlZ29yaXplZFwiLFxyXG4vLyAgICAgICAgICAgb3JkZXI6IGRiTWVudT8ub3JkZXIgfHwgbWVudS5vcmRlciB8fCAwLFxyXG4vLyAgICAgICAgIH07XHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgLy8gU29ydCBieSBvcmRlclxyXG4vLyAgICAgICBmaW5hbE1lbnVzLnNvcnQoKGEsIGIpID0+IChhLm9yZGVyIHx8IDApIC0gKGIub3JkZXIgfHwgMCkpO1xyXG4vLyAgICAgICBzZXRNZW51cyhmaW5hbE1lbnVzKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbi8vICAgICAgIHNldE1lbnVzKFxyXG4vLyAgICAgICAgIHN1Yk1lbnVzLm1hcCgobWVudSkgPT4gKHtcclxuLy8gICAgICAgICAgIC4uLm1lbnUsXHJcbi8vICAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4vLyAgICAgICAgICAgY2F0ZWdvcnk6IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCIsXHJcbi8vICAgICAgICAgICBvcmRlcjogbWVudS5vcmRlciB8fCAwLFxyXG4vLyAgICAgICAgIH0pKVxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVOYXZpZ2F0aW9uID0gKGxpbmspID0+IHtcclxuLy8gICAgIG5hdmlnYXRlKGxpbmspO1xyXG4vLyAgICAgc2V0VGltZW91dChzY3JvbGxUb1RvcCwgMTAwKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCByZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4vLyAgIGNvbnN0IGZpbHRlcmVkTWVudXMgPSBtZW51c1xyXG4vLyAgICAgLmZpbHRlcihtZW51ID0+IG1lbnUudmlzaWJsZSlcclxuLy8gICAgIC5maWx0ZXIobWVudSA9PiBhY3RpdmVDYXRlZ29yeSA9PT0gXCJBbGxcIiB8fCBtZW51LmNhdGVnb3J5ID09PSBhY3RpdmVDYXRlZ29yeSlcclxuLy8gICAgIC5maWx0ZXIobWVudSA9PiBtZW51LnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkpO1xyXG5cclxuLy8gICBjb25zdCBncm91cGVkTWVudXMgPSBtZW51c1xyXG4vLyAgICAgLmZpbHRlcigobWVudSkgPT4gbWVudS52aXNpYmxlKVxyXG4vLyAgICAgLnJlZHVjZSgoYWNjLCBtZW51KSA9PiB7XHJcbi8vICAgICAgIGNvbnN0IGNhdGVnb3J5ID0gbWVudS5jYXRlZ29yeSB8fCBcIlVuY2F0ZWdvcml6ZWRcIjtcclxuLy8gICAgICAgaWYgKCFhY2NbY2F0ZWdvcnldKSB7XHJcbi8vICAgICAgICAgYWNjW2NhdGVnb3J5XSA9IFtdO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICAgIGFjY1tjYXRlZ29yeV0ucHVzaChtZW51KTtcclxuLy8gICAgICAgcmV0dXJuIGFjYztcclxuLy8gICAgIH0sIHt9KTtcclxuXHJcbi8vICAgLy8gU29ydCBpdGVtcyB3aXRoaW4gZWFjaCBjYXRlZ29yeSBieSBvcmRlclxyXG4vLyAgIE9iamVjdC5rZXlzKGdyb3VwZWRNZW51cykuZm9yRWFjaChjYXRlZ29yeSA9PiB7XHJcbi8vICAgICBncm91cGVkTWVudXNbY2F0ZWdvcnldLnNvcnQoKGEsIGIpID0+IChhLm9yZGVyIHx8IDApIC0gKGIub3JkZXIgfHwgMCkpO1xyXG4vLyAgIH0pO1xyXG5cclxuLy8gICAvLyBTb3J0IGNhdGVnb3JpZXMgYmFzZWQgb24gY3VzdG9tIG9yZGVyXHJcbi8vICAgY29uc3Qgc29ydGVkQ2F0ZWdvcmllcyA9IE9iamVjdC5rZXlzKGdyb3VwZWRNZW51cykuc29ydCgoYSwgYikgPT4ge1xyXG4vLyAgICAgY29uc3QgaW5kZXhBID0gY2F0ZWdvcnlPcmRlci5pbmRleE9mKGEpO1xyXG4vLyAgICAgY29uc3QgaW5kZXhCID0gY2F0ZWdvcnlPcmRlci5pbmRleE9mKGIpO1xyXG5cclxuLy8gICAgIGlmIChpbmRleEEgIT09IC0xICYmIGluZGV4QiAhPT0gLTEpIHtcclxuLy8gICAgICAgcmV0dXJuIGluZGV4QSAtIGluZGV4QjtcclxuLy8gICAgIH1cclxuLy8gICAgIGlmIChpbmRleEEgIT09IC0xKSByZXR1cm4gLTE7XHJcbi8vICAgICBpZiAoaW5kZXhCICE9PSAtMSkgcmV0dXJuIDE7XHJcbi8vICAgICByZXR1cm4gYS5sb2NhbGVDb21wYXJlKGIpO1xyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVDbGVhclNlYXJjaCA9ICgpID0+IHtcclxuLy8gICAgIHNldFNlYXJjaFF1ZXJ5KFwiXCIpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHNhdmVSZXBvcnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0U2F2aW5nKHRydWUpO1xyXG4vLyAgICAgICBhd2FpdCBhcGkucHV0KFwiL3YxL2FkbWluL3JlcG9ydC12aXNpYmlsaXR5XCIsIHtcclxuLy8gICAgICAgICByZXBvcnRzOiBtZW51cy5tYXAoKG1lbnUpID0+ICh7XHJcbi8vICAgICAgICAgICByZXBvcnRJZDogbWVudS5pZCxcclxuLy8gICAgICAgICAgIHZpc2libGU6IG1lbnUudmlzaWJsZSxcclxuLy8gICAgICAgICAgIGNhdGVnb3J5OiBtZW51LmNhdGVnb3J5LFxyXG4vLyAgICAgICAgICAgb3JkZXI6IG1lbnUub3JkZXIgfHwgMCxcclxuLy8gICAgICAgICB9KSksXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJSZXBvcnQgc2V0dGluZ3MgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbi8vICAgICAgIGF3YWl0IGZldGNoUmVwb3J0cygpO1xyXG4vLyAgICAgICBzZXRNYW5hZ2VNb2RhbChmYWxzZSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4vLyAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSByZXBvcnQgc2V0dGluZ3NcIik7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIEhhbmRsZSBjYXRlZ29yeSBjaGFuZ2UgZm9yIGEgc3BlY2lmaWMgcmVwb3J0XHJcbi8vICAgY29uc3QgaGFuZGxlQ2F0ZWdvcnlDaGFuZ2UgPSAobWVudUlkLCBuZXdDYXRlZ29yeSkgPT4ge1xyXG4vLyAgICAgc2V0TWVudXMocHJldiA9PiB7XHJcbi8vICAgICAgIGNvbnN0IG1lbnVUb01vdmUgPSBwcmV2LmZpbmQobSA9PiBtLmlkID09PSBtZW51SWQpO1xyXG4vLyAgICAgICBjb25zdCBvbGRDYXRlZ29yeSA9IG1lbnVUb01vdmU/LmNhdGVnb3J5O1xyXG5cclxuLy8gICAgICAgY29uc3QgdXBkYXRlZE1lbnVzID0gcHJldi5tYXAoaXRlbSA9PiB7XHJcbi8vICAgICAgICAgaWYgKGl0ZW0uaWQgPT09IG1lbnVJZCkge1xyXG4vLyAgICAgICAgICAgcmV0dXJuIHsgLi4uaXRlbSwgY2F0ZWdvcnk6IG5ld0NhdGVnb3J5IH07XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIHJldHVybiBpdGVtO1xyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGl0ZW1zSW5OZXdDYXRlZ29yeSA9IHVwZGF0ZWRNZW51c1xyXG4vLyAgICAgICAgIC5maWx0ZXIobSA9PiBtLmNhdGVnb3J5ID09PSBuZXdDYXRlZ29yeSlcclxuLy8gICAgICAgICAuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcblxyXG4vLyAgICAgICBpdGVtc0luTmV3Q2F0ZWdvcnkuZm9yRWFjaCgoaXRlbSwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICBjb25zdCBmb3VuZEl0ZW0gPSB1cGRhdGVkTWVudXMuZmluZChtID0+IG0uaWQgPT09IGl0ZW0uaWQpO1xyXG4vLyAgICAgICAgIGlmIChmb3VuZEl0ZW0pIHtcclxuLy8gICAgICAgICAgIGZvdW5kSXRlbS5vcmRlciA9IGluZGV4O1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBpZiAob2xkQ2F0ZWdvcnkgJiYgb2xkQ2F0ZWdvcnkgIT09IG5ld0NhdGVnb3J5KSB7XHJcbi8vICAgICAgICAgY29uc3QgaXRlbXNJbk9sZENhdGVnb3J5ID0gdXBkYXRlZE1lbnVzXHJcbi8vICAgICAgICAgICAuZmlsdGVyKG0gPT4gbS5jYXRlZ29yeSA9PT0gb2xkQ2F0ZWdvcnkpXHJcbi8vICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcblxyXG4vLyAgICAgICAgIGl0ZW1zSW5PbGRDYXRlZ29yeS5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICAgICAgY29uc3QgZm91bmRJdGVtID0gdXBkYXRlZE1lbnVzLmZpbmQobSA9PiBtLmlkID09PSBpdGVtLmlkKTtcclxuLy8gICAgICAgICAgIGlmIChmb3VuZEl0ZW0pIHtcclxuLy8gICAgICAgICAgICAgZm91bmRJdGVtLm9yZGVyID0gaW5kZXg7XHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIHJldHVybiB1cGRhdGVkTWVudXM7XHJcbi8vICAgICB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBEcmFnIGFuZCBkcm9wIGhhbmRsZXJzIGZvciByZW9yZGVyaW5nIHdpdGhpbiBjYXRlZ29yaWVzXHJcbi8vICAgY29uc3QgaGFuZGxlRHJhZ1N0YXJ0ID0gKGUsIGl0ZW0sIGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbSh7IGl0ZW0sIGNhdGVnb3J5IH0pO1xyXG4vLyAgICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9ICdtb3ZlJztcclxuLy8gICAgIGUuZGF0YVRyYW5zZmVyLnNldERhdGEoJ3RleHQvcGxhaW4nLCBKU09OLnN0cmluZ2lmeSh7IGlkOiBpdGVtLmlkLCBjYXRlZ29yeSB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlRHJhZ092ZXIgPSAoZSwgaXRlbSwgY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbSh7IGl0ZW0sIGNhdGVnb3J5IH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZURyYWdFbmQgPSAoKSA9PiB7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVEcm9wID0gKGUsIHRhcmdldEl0ZW0sIHRhcmdldENhdGVnb3J5KSA9PiB7XHJcbi8vICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4vLyAgICAgaWYgKCFkcmFnZ2VkSXRlbSB8fCBkcmFnZ2VkSXRlbS5jYXRlZ29yeSAhPT0gdGFyZ2V0Q2F0ZWdvcnkpIHtcclxuLy8gICAgICAgc2V0RHJhZ2dlZEl0ZW0obnVsbCk7XHJcbi8vICAgICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGNvbnN0IHNvdXJjZUl0ZW0gPSBkcmFnZ2VkSXRlbS5pdGVtO1xyXG4vLyAgICAgY29uc3Qgc291cmNlSW5kZXggPSBtZW51cy5maW5kSW5kZXgobSA9PiBtLmlkID09PSBzb3VyY2VJdGVtLmlkKTtcclxuLy8gICAgIGNvbnN0IHRhcmdldEluZGV4ID0gbWVudXMuZmluZEluZGV4KG0gPT4gbS5pZCA9PT0gdGFyZ2V0SXRlbS5pZCk7XHJcblxyXG4vLyAgICAgaWYgKHNvdXJjZUluZGV4ID09PSAtMSB8fCB0YXJnZXRJbmRleCA9PT0gLTEgfHwgc291cmNlSW5kZXggPT09IHRhcmdldEluZGV4KSB7XHJcbi8vICAgICAgIHNldERyYWdnZWRJdGVtKG51bGwpO1xyXG4vLyAgICAgICBzZXREcmFnT3Zlckl0ZW0obnVsbCk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBjb25zdCBuZXdNZW51cyA9IFsuLi5tZW51c107XHJcbi8vICAgICBjb25zdCBbcmVtb3ZlZF0gPSBuZXdNZW51cy5zcGxpY2Uoc291cmNlSW5kZXgsIDEpO1xyXG4vLyAgICAgbmV3TWVudXMuc3BsaWNlKHRhcmdldEluZGV4LCAwLCByZW1vdmVkKTtcclxuXHJcbi8vICAgICBjb25zdCBjYXRlZ29yeUl0ZW1zID0gbmV3TWVudXMuZmlsdGVyKG0gPT4gbS5jYXRlZ29yeSA9PT0gdGFyZ2V0Q2F0ZWdvcnkpO1xyXG4vLyAgICAgY2F0ZWdvcnlJdGVtcy5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICBpdGVtLm9yZGVyID0gaW5kZXg7XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICBzZXRNZW51cyhuZXdNZW51cyk7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBVcGRhdGVkIHNpZGViYXIgcmVuZGVyIHdpdGggY2xpY2thYmxlIGNhdGVnb3JpZXMgdGhhdCBmaWx0ZXIgcmVwb3J0c1xyXG4vLyAgIGNvbnN0IHJlbmRlclNpZGViYXIgPSAoKSA9PiB7XHJcbi8vICAgICByZXR1cm4gKFxyXG4vLyAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgcmVmPXtyZWZ9XHJcbi8vICAgICAgICAgY2xhc3NOYW1lPXtgbWluLWgtc2NyZWVuIG1heC1oLWF1dG8gcC00IHB0LTggJHtvcGVuID8gXCJ3LTcyXCIgOiBcInctMjBcIn0gZHVyYXRpb24tMzAwIHJlbGF0aXZlIGJnLXdoaXRlIHNoYWRvdy1sZ2B9XHJcbi8vICAgICAgID5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02IHB4LTJcIj5cclxuLy8gICAgICAgICAgIHtvcGVuICYmIChcclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgQ2F0ZWdvcmllc1xyXG4vLyAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKCFvcGVuKX1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xyXG4vLyAgICAgICAgICAgICAgICFvcGVuID8gXCJteC1hdXRvXCIgOiBcIlwiXHJcbi8vICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICA8RmlDaGV2cm9uTGVmdFxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtZ3JheS02MDAgdGV4dC14bCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgJHtcclxuLy8gICAgICAgICAgICAgICAgICFvcGVuID8gXCJyb3RhdGUtMTgwXCIgOiBcIlwiXHJcbi8vICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAge3NvcnRlZENhdGVnb3JpZXNcclxuLy8gICAgICAgICAgIC5maWx0ZXIoKGNhdGVnb3J5KSA9PiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5sZW5ndGgpXHJcbi8vICAgICAgICAgICAubWFwKChjYXRlZ29yeSkgPT4ge1xyXG4vLyAgICAgICAgICAgICBjb25zdCBpdGVtcyA9IGdyb3VwZWRNZW51c1tjYXRlZ29yeV0gfHwgW107XHJcbi8vICAgICAgICAgICAgIGNvbnN0IGlzRXhwYW5kZWQgPSBleHBhbmRlZENhdGVnb3JpZXNbY2F0ZWdvcnldIHx8IGZhbHNlO1xyXG4vLyAgICAgICAgICAgICBjb25zdCBpdGVtQ291bnQgPSBpdGVtcy5sZW5ndGg7XHJcbi8vICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlQ2F0ZWdvcnkgPT09IGNhdGVnb3J5O1xyXG5cclxuLy8gICAgICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnl9IGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIGlmIChvcGVuKSB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAvLyBUb2dnbGUgZXhwYW5zaW9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB0b2dnbGVDYXRlZ29yeShjYXRlZ29yeSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXQgYWN0aXZlIGNhdGVnb3J5IHRvIGZpbHRlciByZXBvcnRzIG9uIHRoZSByaWdodCBzaWRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVDYXRlZ29yeShjYXRlZ29yeSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0yLjUgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSAmJiBvcGVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIGJvcmRlci1sLTQgYm9yZGVyLWJsdWUtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDogb3BlblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPyBcImhvdmVyOmJnLWdyYXktNTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBcImp1c3RpZnktY2VudGVyIGhvdmVyOmJnLWdyYXktNTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge29wZW4gPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZm9udC1zZW1pYm9sZCB0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlID8gXCJ0ZXh0LWJsdWUtNzAwXCIgOiBcInRleHQtZ3JheS03MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQteHMgcHgtMS41IHB5LTAuNSByb3VuZGVkLWZ1bGwgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSA/IFwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMFwiIDogXCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtQ291bnR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2lzRXhwYW5kZWQgPyAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxCc0NoZXZyb25Eb3duIGNsYXNzTmFtZT17YHRleHQtc20gJHtpc0FjdGl2ZSA/IFwidGV4dC1ibHVlLTUwMFwiIDogXCJ0ZXh0LWdyYXktNDAwXCJ9YH0gLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxCc0NoZXZyb25SaWdodCBjbGFzc05hbWU9e2B0ZXh0LXNtICR7aXNBY3RpdmUgPyBcInRleHQtYmx1ZS01MDBcIiA6IFwidGV4dC1ncmF5LTQwMFwifWB9IC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0yIGgtMiByb3VuZGVkLWZ1bGwgJHtpc0FjdGl2ZSA/IFwiYmctYmx1ZS01MDBcIiA6IFwiYmctZ3JheS0zMDBcIn1gfT48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHtvcGVuICYmIGlzRXhwYW5kZWQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTMgYm9yZGVyLWwtMiBib3JkZXItZ3JheS0xMDAgcGwtMyBzcGFjZS15LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7aXRlbXMubWFwKCh7IHRpdGxlLCBsaW5rLCBJY29uLCBjb2xvciwgaXNOZXcgfSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB0bz17bGlua31cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjcm9sbFRvVG9wKCk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SGlkZVNpZGViYXIoIWhpZGVTaWRlYmFyKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZTogaXNMaW5rQWN0aXZlIH0pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTMgcHktMi41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0xpbmtBY3RpdmVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCBzaGFkb3ctc21cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOnRleHQtZ3JheS05MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgeyh7IGlzQWN0aXZlOiBpc0xpbmtBY3RpdmUgfSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsxOH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0xpbmtBY3RpdmUgPyBcInRleHQtYmx1ZS02MDBcIiA6IFwidGV4dC1ncmF5LTQwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIGxlYWRpbmctdGlnaHRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTmV3ICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5FV1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICk7XHJcbi8vICAgICAgICAgICB9KX1cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIFJlbmRlciBjYXRlZ29yaWVzIGNoaXBzIHdpdGggY3VzdG9tIG9yZGVyXHJcbi8vICAgY29uc3QgcmVuZGVyQ2F0ZWdvcnlDaGlwcyA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGNoaXBDYXRlZ29yaWVzID0gW1wiQWxsXCIsIC4uLnNvcnRlZENhdGVnb3JpZXNdO1xyXG5cclxuLy8gICAgIHJldHVybiAoXHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgbWItNiBwYi0yIG92ZXJmbG93LXgtYXV0b1wiPlxyXG4vLyAgICAgICAgIHtjaGlwQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICAgICAgICBjb25zdCBjb3VudCA9IGNhdGVnb3J5ID09PSBcIkFsbFwiXHJcbi8vICAgICAgICAgICAgID8gbWVudXMuZmlsdGVyKG0gPT4gbS52aXNpYmxlKS5sZW5ndGhcclxuLy8gICAgICAgICAgICAgOiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5sZW5ndGggfHwgMDtcclxuXHJcbi8vICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAga2V5PXtjYXRlZ29yeX1cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVDYXRlZ29yeShjYXRlZ29yeSl9XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4vLyAgICAgICAgICAgICAgICAgYWN0aXZlQ2F0ZWdvcnkgPT09IGNhdGVnb3J5XHJcbi8vICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tYmx1ZS03MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LWJsdWUtMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGhvdmVyOmJvcmRlci1ncmF5LTMwMFwiXHJcbi8vICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XHJcbi8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbWwtMS41IHRleHQteHMgJHtcclxuLy8gICAgICAgICAgICAgICAgIGFjdGl2ZUNhdGVnb3J5ID09PSBjYXRlZ29yeSA/IFwidGV4dC1ibHVlLTEwMFwiIDogXCJ0ZXh0LWdyYXktNDAwXCJcclxuLy8gICAgICAgICAgICAgICB9YH0+XHJcbi8vICAgICAgICAgICAgICAgICAoe2NvdW50fSlcclxuLy8gICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICB9KX1cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICApO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIFJlbmRlciBncmlkIGNhcmRzXHJcbi8vICAgY29uc3QgcmVuZGVyR3JpZENhcmRzID0gKCkgPT4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00IGdhcC01XCI+XHJcbi8vICAgICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlzTmV3IH0pID0+IChcclxuLy8gICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICBrZXk9e2xpbmt9XHJcbi8vICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGxpbmspfVxyXG4vLyAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIlxyXG4vLyAgICAgICAgID5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMjAwIGhvdmVyOi10cmFuc2xhdGUteS0xLjVcIj5cclxuLy8gICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IGgtMjggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuYH1cclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay81XCI+PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC01eGwgdGV4dC13aGl0ZSBkcm9wLXNoYWRvdy1sZyByZWxhdGl2ZSB6LTEwXCIgLz5cclxuLy8gICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBzaGFkb3ctbGcgei0xMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBORVdcclxuLy8gICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTVcIj5cclxuLy8gICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzIGxpbmUtY2xhbXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4vLyAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIHRleHQtYmx1ZS02MDAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlZpZXcgUmVwb3J0PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IG1sLTIgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDVsNyA3LTcgN1wiIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgKSl9XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG5cclxuLy8gICAvLyBSZW5kZXIgbGlzdCBpdGVtc1xyXG4vLyAgIGNvbnN0IHJlbmRlckxpc3RJdGVtcyA9ICgpID0+IChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbi8vICAgICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlkLCBpc05ldyB9KSA9PiAoXHJcbi8vICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAga2V5PXtpZH1cclxuLy8gICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbi8vICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMjAwIGhvdmVyOi10cmFuc2xhdGUteC0xXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgcC00IGhvdmVyOmJnLWdyYXktNTAvNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IHJvdW5kZWQteGwgcC0zIG1yLTQgZmxleC1zaHJpbmstMGB9PlxyXG4vLyAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC14bCB0ZXh0LXdoaXRlXCIgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBtaW4tdy0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzIHRydW5jYXRlXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTQwMCB0by1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2UgZmxleC1zaHJpbmstMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgTkVXXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMC41XCI+Q2xpY2sgdG8gdmlldyBkZXRhaWxlZCByZXBvcnQ8L3A+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPHN2Z1xyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktMzAwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS01MDAgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLWFsbCBmbGV4LXNocmluay0wIG1sLTJcIlxyXG4vLyAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuLy8gICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDVsNyA3LTcgN1wiIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICkpfVxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuXHJcbi8vICAgLy8gUmVuZGVyIGRyYWdnYWJsZSBpdGVtcyB3aXRoIGNhdGVnb3J5IGRyb3Bkb3duIGZvciBtYW5hZ2UgbW9kYWxcclxuLy8gICBjb25zdCByZW5kZXJEcmFnZ2FibGVJdGVtcyA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGdyb3VwZWRCeUNhdGVnb3J5ID0ge307XHJcbi8vICAgICBtZW51cy5mb3JFYWNoKG1lbnUgPT4ge1xyXG4vLyAgICAgICBjb25zdCBjYXRlZ29yeSA9IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCI7XHJcbi8vICAgICAgIGlmICghZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldKSB7XHJcbi8vICAgICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldID0gW107XHJcbi8vICAgICAgIH1cclxuLy8gICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldLnB1c2gobWVudSk7XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICBPYmplY3Qua2V5cyhncm91cGVkQnlDYXRlZ29yeSkuZm9yRWFjaChjYXRlZ29yeSA9PiB7XHJcbi8vICAgICAgIGdyb3VwZWRCeUNhdGVnb3J5W2NhdGVnb3J5XS5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciB8fCAwKSAtIChiLm9yZGVyIHx8IDApKTtcclxuLy8gICAgIH0pO1xyXG5cclxuLy8gICAgIGNvbnN0IHNvcnRlZENhdEtleXMgPSBPYmplY3Qua2V5cyhncm91cGVkQnlDYXRlZ29yeSkuc29ydCgoYSwgYikgPT4ge1xyXG4vLyAgICAgICBjb25zdCBpbmRleEEgPSBjYXRlZ29yeU9yZGVyLmluZGV4T2YoYSk7XHJcbi8vICAgICAgIGNvbnN0IGluZGV4QiA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihiKTtcclxuLy8gICAgICAgaWYgKGluZGV4QSAhPT0gLTEgJiYgaW5kZXhCICE9PSAtMSkgcmV0dXJuIGluZGV4QSAtIGluZGV4QjtcclxuLy8gICAgICAgaWYgKGluZGV4QSAhPT0gLTEpIHJldHVybiAtMTtcclxuLy8gICAgICAgaWYgKGluZGV4QiAhPT0gLTEpIHJldHVybiAxO1xyXG4vLyAgICAgICByZXR1cm4gYS5sb2NhbGVDb21wYXJlKGIpO1xyXG4vLyAgICAgfSk7XHJcblxyXG4vLyAgICAgY29uc3QgYWxsQ2F0ZWdvcmllcyA9IGdldEFsbENhdGVnb3JpZXMoKTtcclxuXHJcbi8vICAgICByZXR1cm4gc29ydGVkQ2F0S2V5cy5tYXAoY2F0ZWdvcnkgPT4gKFxyXG4vLyAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnl9IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuLy8gICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTNcIj5cclxuLy8gICAgICAgICAgIHtjYXRlZ29yeX1cclxuLy8gICAgICAgICA8L2g0PlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbi8vICAgICAgICAgICB7Z3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldLm1hcCgobWVudSwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICAgICAgY29uc3QgaXNEcmFnZ2luZyA9IGRyYWdnZWRJdGVtPy5pdGVtPy5pZCA9PT0gbWVudS5pZDtcclxuLy8gICAgICAgICAgICAgY29uc3QgaXNEcmFnT3ZlciA9IGRyYWdPdmVySXRlbT8uaXRlbT8uaWQgPT09IG1lbnUuaWQ7XHJcblxyXG4vLyAgICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgIGtleT17bWVudS5pZH1cclxuLy8gICAgICAgICAgICAgICAgIGRyYWdnYWJsZVxyXG4vLyAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9eyhlKSA9PiBoYW5kbGVEcmFnU3RhcnQoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgb25EcmFnT3Zlcj17KGUpID0+IGhhbmRsZURyYWdPdmVyKGUsIG1lbnUsIGNhdGVnb3J5KX1cclxuLy8gICAgICAgICAgICAgICAgIG9uRHJhZ0VuZD17aGFuZGxlRHJhZ0VuZH1cclxuLy8gICAgICAgICAgICAgICAgIG9uRHJvcD17KGUpID0+IGhhbmRsZURyb3AoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC00IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7XHJcbi8vICAgICAgICAgICAgICAgICAgIGlzRHJhZ2dpbmdcclxuLy8gICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS01MCBib3JkZXItMiBib3JkZXItYmx1ZS00MDAgc2hhZG93LWxnIG9wYWNpdHktNTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDogaXNEcmFnT3ZlclxyXG4vLyAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLWJsdWUtNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMCBib3JkZXItMiBib3JkZXItdHJhbnNwYXJlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgfSBjdXJzb3ItbW92ZWB9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmbGV4LTEgbWluLXctMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgY3Vyc29yLWdyYWIgZmxleC1zaHJpbmstMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTcgMmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTYtMTJhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00em0wIDZhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00em0wIDZhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00elwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHttZW51LnRpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+T3JkZXI6IHttZW51Lm9yZGVyIHx8IGluZGV4fTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTMwMFwiPnw8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttZW51LmNhdGVnb3J5fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNhdGVnb3J5Q2hhbmdlKG1lbnUuaWQsIGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBib3JkZXIgcm91bmRlZCBweC0yIHB5LTEgYmctd2hpdGUgaG92ZXI6Ym9yZGVyLWJsdWUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTQwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2FsbENhdGVnb3JpZXMubWFwKGNhdCA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NhdH0gdmFsdWU9e2NhdH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtbC00IGZsZXgtc2hyaW5rLTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge21lbnUudmlzaWJsZSA/IFwiVmlzaWJsZVwiIDogXCJIaWRkZW5cIn1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17bWVudS52aXNpYmxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoY2hlY2tlZCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc2V0TWVudXMoKHByZXYpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHByZXYubWFwKChpdGVtKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uaWQgPT09IG1lbnUuaWRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5pdGVtLCB2aXNpYmxlOiBjaGVja2VkIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKTtcclxuLy8gICAgICAgICAgIH0pfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgICkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBmbGV4IG10LTE2IGJnLWdyYXktNTBcIj5cclxuLy8gICAgICAgPE5hdmJhciAvPlxyXG4vLyAgICAgICA8U2lkZWJhciBoaWRlU2lkZWJhcj17aGlkZVNpZGViYXJ9IC8+XHJcblxyXG4vLyAgICAgICB7LyogU2lkZWJhciAqL31cclxuLy8gICAgICAgPGRpdlxyXG4vLyAgICAgICAgIGNsYXNzTmFtZT17YCR7b3BlbiA/IFwidy03MlwiIDogXCJ3LTIwXCJ9IGJnLXdoaXRlIG1pbi1oLXNjcmVlbiBib3JkZXItciBib3JkZXItZ3JheS0yMDAgb3ZlcmZsb3cteS1hdXRvIGZsZXgtc2hyaW5rLTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwYH1cclxuLy8gICAgICAgPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIGJnLXdoaXRlIHotMTAgcC00IG10LTEwXCI+XHJcbi8vICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRBY3RpdmVDYXRlZ29yeShcIkFsbFwiKTtcclxuLy8gICAgICAgICAgICAgICBuYXZpZ2F0ZShcIi9yZXBvcnRzXCIpO1xyXG4vLyAgICAgICAgICAgICAgIHNjcm9sbFRvVG9wKCk7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHctZnVsbCAke1xyXG4vLyAgICAgICAgICAgICAgIG9wZW5cclxuLy8gICAgICAgICAgICAgICAgID8gXCJweC00IHB5LTIuNSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1ibHVlLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtWzEuMDJdXCJcclxuLy8gICAgICAgICAgICAgICAgIDogXCJwLTIuNSByb3VuZGVkLWZ1bGwgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNjYWxlLTExMFwiXHJcbi8vICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICA8RmFDaGFydEJhciBjbGFzc05hbWU9e29wZW4gPyBcInRleHQtYmx1ZS0xMDAgdGV4dC1sZ1wiIDogXCJ0ZXh0LWxnXCJ9IC8+XHJcbi8vICAgICAgICAgICAgIHtvcGVuICYmIDxzcGFuIGNsYXNzTmFtZT1cInRyYWNraW5nLXdpZGVcIj5SZXBvcnRzPC9zcGFuPn1cclxuLy8gICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIHtyZW5kZXJTaWRlYmFyKCl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgey8qIE1haW4gQ29udGVudCAqL31cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC02IG92ZXJmbG93LWhpZGRlbiBtYXgtaC1zY3JlZW4gb3ZlcmZsb3cteS1hdXRvXCI+XHJcbi8vICAgICAgICAge2xvY2F0aW9uLnBhdGhuYW1lID09PSBcIi9yZXBvcnRzXCIgPyAoXHJcbi8vICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICB7LyogU2VhcmNoIEJhciAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IG10LTEwXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtYXgtdy0yeGxcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC00IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPElvU2VhcmNoT3V0bGluZSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQteGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCByZXBvcnRzLi4uXCJcclxuLy8gICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEyIHByLTEyIHB5LTMuNSB0ZXh0LWJhc2UgYmctd2hpdGUgYm9yZGVyLTIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLWJsdWUtNTAwLzIwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBzaGFkb3ctc20gaG92ZXI6c2hhZG93IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICB7c2VhcmNoUXVlcnkgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJTZWFyY2h9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgcHItNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxJb0Nsb3NlQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBDb250cm9scyBCYXIgKi99XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAge3JlbmRlckNhdGVnb3J5Q2hpcHMoKX1cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdUeXBlKFwiZ3JpZFwiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZpZXdUeXBlID09PSBcImdyaWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy13aGl0ZSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkdyaWQgVmlld1wiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxCaUdyaWQgc2l6ZT17MjB9IC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld1R5cGUoXCJsaXN0XCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIuNSByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmlld1R5cGUgPT09IFwibGlzdFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTGlzdCBWaWV3XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPFRiTGlzdCBzaXplPXsyMH0gLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSByb3VuZGVkLWxnIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgbWwtMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1hbmFnZU1vZGFsKHRydWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxGaVNldHRpbmdzIHNpemU9ezE2fSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIE1hbmFnZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogUmVzdWx0cyBTdGF0cyAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIFNob3dpbmcge2ZpbHRlcmVkTWVudXMubGVuZ3RofSByZXBvcnR7ZmlsdGVyZWRNZW51cy5sZW5ndGggIT09IDEgPyBcInNcIiA6IFwiXCJ9XHJcbi8vICAgICAgICAgICAgICAge3NlYXJjaFF1ZXJ5ICYmIGAgZm9yIFwiJHtzZWFyY2hRdWVyeX1cImB9XHJcbi8vICAgICAgICAgICAgICAge2FjdGl2ZUNhdGVnb3J5ICE9PSBcIkFsbFwiICYmIGAgaW4gJHthY3RpdmVDYXRlZ29yeX1gfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBMb2FkaW5nIFN0YXRlICovfVxyXG4vLyAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEyIHctMTIgYm9yZGVyLTQgYm9yZGVyLWJsdWUtNjAwIGJvcmRlci10LXRyYW5zcGFyZW50XCI+PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICkgOiBmaWx0ZXJlZE1lbnVzLmxlbmd0aCA9PT0gMCA/IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTIwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTIwIGgtMjAgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIG1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPElvU2VhcmNoT3V0bGluZSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCB0ZXh0LWdyYXktNDAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTJcIj5ObyByZXBvcnRzIGZvdW5kPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2FjdGl2ZUNhdGVnb3J5ICE9PSBcIkFsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPyBgTm8gcmVwb3J0cyBmb3VuZCBpbiBcIiR7YWN0aXZlQ2F0ZWdvcnl9XCIgY2F0ZWdvcnlgXHJcbi8vICAgICAgICAgICAgICAgICAgICAgOiBcIlRyeSBhZGp1c3RpbmcgeW91ciBzZWFyY2ggb3IgZmlsdGVyIGNyaXRlcmlhXCJ9XHJcbi8vICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgdmlld1R5cGUgPT09IFwiZ3JpZFwiID8gcmVuZGVyR3JpZENhcmRzKCkgOiByZW5kZXJMaXN0SXRlbXMoKVxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgIDxPdXRsZXQgLz5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgIHsvKiBNYW5hZ2UgTW9kYWwgKi99XHJcbi8vICAgICAgIDxNb2RhbFxyXG4vLyAgICAgICAgIHRpdGxlPXtcclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgICAgICAgPEZpU2V0dGluZ3MgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPk1hbmFnZSBSZXBvcnRzIC0gT3JkZXIsIENhdGVnb3J5ICYgVmlzaWJpbGl0eTwvc3Bhbj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgICBvcGVuPXttYW5hZ2VNb2RhbH1cclxuLy8gICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0TWFuYWdlTW9kYWwoZmFsc2UpfVxyXG4vLyAgICAgICAgIGZvb3Rlcj17bnVsbH1cclxuLy8gICAgICAgICB3aWR0aD17OTAwfVxyXG4vLyAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsXCJcclxuLy8gICAgICAgPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTQgYmctYmx1ZS01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYmx1ZS0xMDAgbXQtMTBcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsdWUtNzAwIHNwYWNlLXktMVwiPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8cGF0aCBmaWxsUnVsZT1cImV2ZW5vZGRcIiBkPVwiTTE4IDEwYTggOCAwIDExLTE2IDAgOCA4IDAgMDExNiAwem0tNy00YTEgMSAwIDExLTIgMCAxIDEgMCAwMTIgMHpNOSA5YTEgMSAwIDAwMCAydjNhMSAxIDAgMDAxIDFoMWExIDEgMCAxMDAtMnYtM2ExIDEgMCAwMC0xLTFIOXpcIiBjbGlwUnVsZT1cImV2ZW5vZGRcIiAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmc+RHJhZzwvc3Ryb25nPiB0byByZW9yZGVyIHJlcG9ydHMgd2l0aGluIGEgY2F0ZWdvcnk8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWwtN1wiPlxyXG4vLyAgICAgICAgICAgICAgIDxzcGFuPlVzZSB0aGUgPHN0cm9uZz5kcm9wZG93bjwvc3Ryb25nPiB0byBtb3ZlIGEgcmVwb3J0IHRvIGEgZGlmZmVyZW50IGNhdGVnb3J5PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgbWF4LWgtWzYwdmhdIG92ZXJmbG93LXktYXV0byBwci0yXCI+XHJcbi8vICAgICAgICAgICB7cmVuZGVyRHJhZ2dhYmxlSXRlbXMoKX1cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTYgcHQtNCBib3JkZXItdFwiPlxyXG4vLyAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIuNSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBmb250LW1lZGl1bVwiXHJcbi8vICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1hbmFnZU1vZGFsKGZhbHNlKX1cclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgQ2FuY2VsXHJcbi8vICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbWVkaXVtIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4vLyAgICAgICAgICAgICBvbkNsaWNrPXtzYXZlUmVwb3J0c31cclxuLy8gICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ31cclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAge3NhdmluZyA/IChcclxuLy8gICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTQgdy00IGJvcmRlci0yIGJvcmRlci13aGl0ZSBib3JkZXItdC10cmFuc3BhcmVudFwiPjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIFNhdmluZy4uLlxyXG4vLyAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICBcIlNhdmUgQ2hhbmdlc1wiXHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9Nb2RhbD5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG4vLyBjb25zdCBSZXBvcnRzID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuLy8gICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbi8vICAgY29uc3QgW2FjdGl2ZUNhdGVnb3J5LCBzZXRBY3RpdmVDYXRlZ29yeV0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuLy8gICBjb25zdCBbdmlld1R5cGUsIHNldFZpZXdUeXBlXSA9IHVzZVN0YXRlKFwiZ3JpZFwiKTtcclxuLy8gICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtzaWRlYmFyU2VhcmNoUXVlcnksIHNldFNpZGViYXJTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuLy8gICBjb25zdCBbaGlkZVNpZGViYXIsIHNldEhpZGVTaWRlYmFyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbZXhwYW5kZWRDYXRlZ29yaWVzLCBzZXRFeHBhbmRlZENhdGVnb3JpZXNdID0gdXNlU3RhdGUoe30pO1xyXG4vLyAgIGNvbnN0IFttZW51cywgc2V0TWVudXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW21hbmFnZU1vZGFsLCBzZXRNYW5hZ2VNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4vLyAgIGNvbnN0IFtkcmFnZ2VkSXRlbSwgc2V0RHJhZ2dlZEl0ZW1dID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW2RyYWdPdmVySXRlbSwgc2V0RHJhZ092ZXJJdGVtXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuLy8gICAvLyBEZWZpbmUgY3VzdG9tIGNhdGVnb3J5IG9yZGVyXHJcbi8vICAgY29uc3QgY2F0ZWdvcnlPcmRlciA9IFtcIkN1c3RvbWVyXCIsIFwiQXVjdGlvblwiLCBcIlBheW1lbnRzXCJdO1xyXG5cclxuLy8gICAvLyBHZXQgYWxsIHVuaXF1ZSBjYXRlZ29yaWVzIGZyb20gbWVudXNcclxuLy8gICBjb25zdCBnZXRBbGxDYXRlZ29yaWVzID0gKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgY2F0ZWdvcmllcyA9IG5ldyBTZXQoKTtcclxuLy8gICAgIG1lbnVzLmZvckVhY2gobWVudSA9PiB7XHJcbi8vICAgICAgIGlmIChtZW51LmNhdGVnb3J5KSB7XHJcbi8vICAgICAgICAgY2F0ZWdvcmllcy5hZGQobWVudS5jYXRlZ29yeSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0pO1xyXG4vLyAgICAgcmV0dXJuIEFycmF5LmZyb20oY2F0ZWdvcmllcyk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgdG9nZ2xlQ2F0ZWdvcnkgPSAoY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgIHNldEV4cGFuZGVkQ2F0ZWdvcmllcyhwcmV2ID0+ICh7XHJcbi8vICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgIFtjYXRlZ29yeV06ICFwcmV2W2NhdGVnb3J5XVxyXG4vLyAgICAgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHNjcm9sbFRvVG9wID0gKCkgPT4ge1xyXG4vLyAgICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgZmV0Y2hSZXBvcnRzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICBjb25zdCBmZXRjaFJlcG9ydHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9yZXBvcnQtdmlzaWJpbGl0eVwiKTtcclxuLy8gICAgICAgY29uc3QgdmlzaWJpbGl0eSA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGZpbmFsTWVudXMgPSBzdWJNZW51cy5tYXAoKG1lbnUpID0+IHtcclxuLy8gICAgICAgICBjb25zdCBkYk1lbnUgPSB2aXNpYmlsaXR5LmZpbmQoXHJcbi8vICAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5yZXBvcnRJZCA9PT0gbWVudS5pZFxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgICAgIC4uLm1lbnUsXHJcbi8vICAgICAgICAgICB2aXNpYmxlOiBkYk1lbnUgPyBkYk1lbnUudmlzaWJsZSA6IHRydWUsXHJcbi8vICAgICAgICAgICBjYXRlZ29yeTogZGJNZW51Py5jYXRlZ29yeSB8fCBtZW51LmNhdGVnb3J5IHx8IFwiVW5jYXRlZ29yaXplZFwiLFxyXG4vLyAgICAgICAgICAgb3JkZXI6IGRiTWVudT8ub3JkZXIgfHwgbWVudS5vcmRlciB8fCAwLFxyXG4vLyAgICAgICAgIH07XHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgLy8gU29ydCBieSBvcmRlclxyXG4vLyAgICAgICBmaW5hbE1lbnVzLnNvcnQoKGEsIGIpID0+IChhLm9yZGVyIHx8IDApIC0gKGIub3JkZXIgfHwgMCkpO1xyXG4vLyAgICAgICBzZXRNZW51cyhmaW5hbE1lbnVzKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbi8vICAgICAgIHNldE1lbnVzKFxyXG4vLyAgICAgICAgIHN1Yk1lbnVzLm1hcCgobWVudSkgPT4gKHtcclxuLy8gICAgICAgICAgIC4uLm1lbnUsXHJcbi8vICAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4vLyAgICAgICAgICAgY2F0ZWdvcnk6IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCIsXHJcbi8vICAgICAgICAgICBvcmRlcjogbWVudS5vcmRlciB8fCAwLFxyXG4vLyAgICAgICAgIH0pKVxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVOYXZpZ2F0aW9uID0gKGxpbmspID0+IHtcclxuLy8gICAgIG5hdmlnYXRlKGxpbmspO1xyXG4vLyAgICAgc2V0VGltZW91dChzY3JvbGxUb1RvcCwgMTAwKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCByZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4vLyAgIGNvbnN0IGZpbHRlcmVkTWVudXMgPSBtZW51c1xyXG4vLyAgICAgLmZpbHRlcihtZW51ID0+IG1lbnUudmlzaWJsZSlcclxuLy8gICAgIC5maWx0ZXIobWVudSA9PiBhY3RpdmVDYXRlZ29yeSA9PT0gXCJBbGxcIiB8fCBtZW51LmNhdGVnb3J5ID09PSBhY3RpdmVDYXRlZ29yeSlcclxuLy8gICAgIC5maWx0ZXIobWVudSA9PiBtZW51LnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkpO1xyXG5cclxuLy8gICBjb25zdCBncm91cGVkTWVudXMgPSBtZW51c1xyXG4vLyAgICAgLmZpbHRlcigobWVudSkgPT4gbWVudS52aXNpYmxlKVxyXG4vLyAgICAgLnJlZHVjZSgoYWNjLCBtZW51KSA9PiB7XHJcbi8vICAgICAgIGNvbnN0IGNhdGVnb3J5ID0gbWVudS5jYXRlZ29yeSB8fCBcIlVuY2F0ZWdvcml6ZWRcIjtcclxuLy8gICAgICAgaWYgKCFhY2NbY2F0ZWdvcnldKSB7XHJcbi8vICAgICAgICAgYWNjW2NhdGVnb3J5XSA9IFtdO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICAgIGFjY1tjYXRlZ29yeV0ucHVzaChtZW51KTtcclxuLy8gICAgICAgcmV0dXJuIGFjYztcclxuLy8gICAgIH0sIHt9KTtcclxuXHJcbi8vICAgLy8gU29ydCBpdGVtcyB3aXRoaW4gZWFjaCBjYXRlZ29yeSBieSBvcmRlclxyXG4vLyAgIE9iamVjdC5rZXlzKGdyb3VwZWRNZW51cykuZm9yRWFjaChjYXRlZ29yeSA9PiB7XHJcbi8vICAgICBncm91cGVkTWVudXNbY2F0ZWdvcnldLnNvcnQoKGEsIGIpID0+IChhLm9yZGVyIHx8IDApIC0gKGIub3JkZXIgfHwgMCkpO1xyXG4vLyAgIH0pO1xyXG5cclxuLy8gICAvLyBTb3J0IGNhdGVnb3JpZXMgYmFzZWQgb24gY3VzdG9tIG9yZGVyXHJcbi8vICAgY29uc3Qgc29ydGVkQ2F0ZWdvcmllcyA9IE9iamVjdC5rZXlzKGdyb3VwZWRNZW51cykuc29ydCgoYSwgYikgPT4ge1xyXG4vLyAgICAgY29uc3QgaW5kZXhBID0gY2F0ZWdvcnlPcmRlci5pbmRleE9mKGEpO1xyXG4vLyAgICAgY29uc3QgaW5kZXhCID0gY2F0ZWdvcnlPcmRlci5pbmRleE9mKGIpO1xyXG5cclxuLy8gICAgIGlmIChpbmRleEEgIT09IC0xICYmIGluZGV4QiAhPT0gLTEpIHtcclxuLy8gICAgICAgcmV0dXJuIGluZGV4QSAtIGluZGV4QjtcclxuLy8gICAgIH1cclxuLy8gICAgIGlmIChpbmRleEEgIT09IC0xKSByZXR1cm4gLTE7XHJcbi8vICAgICBpZiAoaW5kZXhCICE9PSAtMSkgcmV0dXJuIDE7XHJcbi8vICAgICByZXR1cm4gYS5sb2NhbGVDb21wYXJlKGIpO1xyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVDbGVhclNlYXJjaCA9ICgpID0+IHtcclxuLy8gICAgIHNldFNlYXJjaFF1ZXJ5KFwiXCIpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHNhdmVSZXBvcnRzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0U2F2aW5nKHRydWUpO1xyXG4vLyAgICAgICBhd2FpdCBhcGkucHV0KFwiL3YxL2FkbWluL3JlcG9ydC12aXNpYmlsaXR5XCIsIHtcclxuLy8gICAgICAgICByZXBvcnRzOiBtZW51cy5tYXAoKG1lbnUpID0+ICh7XHJcbi8vICAgICAgICAgICByZXBvcnRJZDogbWVudS5pZCxcclxuLy8gICAgICAgICAgIHZpc2libGU6IG1lbnUudmlzaWJsZSxcclxuLy8gICAgICAgICAgIGNhdGVnb3J5OiBtZW51LmNhdGVnb3J5LFxyXG4vLyAgICAgICAgICAgb3JkZXI6IG1lbnUub3JkZXIgfHwgMCxcclxuLy8gICAgICAgICB9KSksXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJSZXBvcnQgc2V0dGluZ3MgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbi8vICAgICAgIGF3YWl0IGZldGNoUmVwb3J0cygpO1xyXG4vLyAgICAgICBzZXRNYW5hZ2VNb2RhbChmYWxzZSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4vLyAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSByZXBvcnQgc2V0dGluZ3NcIik7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIEhhbmRsZSBjYXRlZ29yeSBjaGFuZ2UgZm9yIGEgc3BlY2lmaWMgcmVwb3J0XHJcbi8vICAgY29uc3QgaGFuZGxlQ2F0ZWdvcnlDaGFuZ2UgPSAobWVudUlkLCBuZXdDYXRlZ29yeSkgPT4ge1xyXG4vLyAgICAgc2V0TWVudXMocHJldiA9PiB7XHJcbi8vICAgICAgIGNvbnN0IG1lbnVUb01vdmUgPSBwcmV2LmZpbmQobSA9PiBtLmlkID09PSBtZW51SWQpO1xyXG4vLyAgICAgICBjb25zdCBvbGRDYXRlZ29yeSA9IG1lbnVUb01vdmU/LmNhdGVnb3J5O1xyXG5cclxuLy8gICAgICAgY29uc3QgdXBkYXRlZE1lbnVzID0gcHJldi5tYXAoaXRlbSA9PiB7XHJcbi8vICAgICAgICAgaWYgKGl0ZW0uaWQgPT09IG1lbnVJZCkge1xyXG4vLyAgICAgICAgICAgcmV0dXJuIHsgLi4uaXRlbSwgY2F0ZWdvcnk6IG5ld0NhdGVnb3J5IH07XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIHJldHVybiBpdGVtO1xyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGl0ZW1zSW5OZXdDYXRlZ29yeSA9IHVwZGF0ZWRNZW51c1xyXG4vLyAgICAgICAgIC5maWx0ZXIobSA9PiBtLmNhdGVnb3J5ID09PSBuZXdDYXRlZ29yeSlcclxuLy8gICAgICAgICAuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcblxyXG4vLyAgICAgICBpdGVtc0luTmV3Q2F0ZWdvcnkuZm9yRWFjaCgoaXRlbSwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgICBjb25zdCBmb3VuZEl0ZW0gPSB1cGRhdGVkTWVudXMuZmluZChtID0+IG0uaWQgPT09IGl0ZW0uaWQpO1xyXG4vLyAgICAgICAgIGlmIChmb3VuZEl0ZW0pIHtcclxuLy8gICAgICAgICAgIGZvdW5kSXRlbS5vcmRlciA9IGluZGV4O1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBpZiAob2xkQ2F0ZWdvcnkgJiYgb2xkQ2F0ZWdvcnkgIT09IG5ld0NhdGVnb3J5KSB7XHJcbi8vICAgICAgICAgY29uc3QgaXRlbXNJbk9sZENhdGVnb3J5ID0gdXBkYXRlZE1lbnVzXHJcbi8vICAgICAgICAgICAuZmlsdGVyKG0gPT4gbS5jYXRlZ29yeSA9PT0gb2xkQ2F0ZWdvcnkpXHJcbi8vICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcblxyXG4vLyAgICAgICAgIGl0ZW1zSW5PbGRDYXRlZ29yeS5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICAgICAgY29uc3QgZm91bmRJdGVtID0gdXBkYXRlZE1lbnVzLmZpbmQobSA9PiBtLmlkID09PSBpdGVtLmlkKTtcclxuLy8gICAgICAgICAgIGlmIChmb3VuZEl0ZW0pIHtcclxuLy8gICAgICAgICAgICAgZm91bmRJdGVtLm9yZGVyID0gaW5kZXg7XHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIHJldHVybiB1cGRhdGVkTWVudXM7XHJcbi8vICAgICB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBEcmFnIGFuZCBkcm9wIGhhbmRsZXJzIGZvciByZW9yZGVyaW5nIHdpdGhpbiBjYXRlZ29yaWVzXHJcbi8vICAgY29uc3QgaGFuZGxlRHJhZ1N0YXJ0ID0gKGUsIGl0ZW0sIGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbSh7IGl0ZW0sIGNhdGVnb3J5IH0pO1xyXG4vLyAgICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9ICdtb3ZlJztcclxuLy8gICAgIGUuZGF0YVRyYW5zZmVyLnNldERhdGEoJ3RleHQvcGxhaW4nLCBKU09OLnN0cmluZ2lmeSh7IGlkOiBpdGVtLmlkLCBjYXRlZ29yeSB9KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlRHJhZ092ZXIgPSAoZSwgaXRlbSwgY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbSh7IGl0ZW0sIGNhdGVnb3J5IH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZURyYWdFbmQgPSAoKSA9PiB7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVEcm9wID0gKGUsIHRhcmdldEl0ZW0sIHRhcmdldENhdGVnb3J5KSA9PiB7XHJcbi8vICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4vLyAgICAgaWYgKCFkcmFnZ2VkSXRlbSB8fCBkcmFnZ2VkSXRlbS5jYXRlZ29yeSAhPT0gdGFyZ2V0Q2F0ZWdvcnkpIHtcclxuLy8gICAgICAgc2V0RHJhZ2dlZEl0ZW0obnVsbCk7XHJcbi8vICAgICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGNvbnN0IHNvdXJjZUl0ZW0gPSBkcmFnZ2VkSXRlbS5pdGVtO1xyXG4vLyAgICAgY29uc3Qgc291cmNlSW5kZXggPSBtZW51cy5maW5kSW5kZXgobSA9PiBtLmlkID09PSBzb3VyY2VJdGVtLmlkKTtcclxuLy8gICAgIGNvbnN0IHRhcmdldEluZGV4ID0gbWVudXMuZmluZEluZGV4KG0gPT4gbS5pZCA9PT0gdGFyZ2V0SXRlbS5pZCk7XHJcblxyXG4vLyAgICAgaWYgKHNvdXJjZUluZGV4ID09PSAtMSB8fCB0YXJnZXRJbmRleCA9PT0gLTEgfHwgc291cmNlSW5kZXggPT09IHRhcmdldEluZGV4KSB7XHJcbi8vICAgICAgIHNldERyYWdnZWRJdGVtKG51bGwpO1xyXG4vLyAgICAgICBzZXREcmFnT3Zlckl0ZW0obnVsbCk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBjb25zdCBuZXdNZW51cyA9IFsuLi5tZW51c107XHJcbi8vICAgICBjb25zdCBbcmVtb3ZlZF0gPSBuZXdNZW51cy5zcGxpY2Uoc291cmNlSW5kZXgsIDEpO1xyXG4vLyAgICAgbmV3TWVudXMuc3BsaWNlKHRhcmdldEluZGV4LCAwLCByZW1vdmVkKTtcclxuXHJcbi8vICAgICBjb25zdCBjYXRlZ29yeUl0ZW1zID0gbmV3TWVudXMuZmlsdGVyKG0gPT4gbS5jYXRlZ29yeSA9PT0gdGFyZ2V0Q2F0ZWdvcnkpO1xyXG4vLyAgICAgY2F0ZWdvcnlJdGVtcy5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICBpdGVtLm9yZGVyID0gaW5kZXg7XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICBzZXRNZW51cyhuZXdNZW51cyk7XHJcbi8vICAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuLy8gICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBVcGRhdGVkIHNpZGViYXIgcmVuZGVyIHdpdGggc2VhcmNoIGFuZCBjbGlja2FibGUgY2F0ZWdvcmllcyB0aGF0IGZpbHRlciByZXBvcnRzXHJcbi8vICAgY29uc3QgcmVuZGVyU2lkZWJhciA9ICgpID0+IHtcclxuLy8gICAgIC8vIEZpbHRlciBjYXRlZ29yaWVzIGJhc2VkIG9uIHNpZGViYXIgc2VhcmNoXHJcbi8vICAgICBjb25zdCBmaWx0ZXJlZENhdGVnb3JpZXMgPSBzb3J0ZWRDYXRlZ29yaWVzXHJcbi8vICAgICAgIC5maWx0ZXIoKGNhdGVnb3J5KSA9PiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5sZW5ndGgpXHJcbi8vICAgICAgIC5maWx0ZXIoKGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICAgICAgaWYgKCFzaWRlYmFyU2VhcmNoUXVlcnkpIHJldHVybiB0cnVlO1xyXG4vLyAgICAgICAgIC8vIENoZWNrIGlmIGNhdGVnb3J5IG5hbWUgbWF0Y2hlcyBzZWFyY2hcclxuLy8gICAgICAgICBpZiAoY2F0ZWdvcnkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzaWRlYmFyU2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xyXG4vLyAgICAgICAgIC8vIENoZWNrIGlmIGFueSBpdGVtIGluIGNhdGVnb3J5IG1hdGNoZXMgc2VhcmNoXHJcbi8vICAgICAgICAgcmV0dXJuIGdyb3VwZWRNZW51c1tjYXRlZ29yeV0/LnNvbWUoaXRlbSA9PlxyXG4vLyAgICAgICAgICAgaXRlbS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNpZGViYXJTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICk7XHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgIC8vIEZpbHRlciBpdGVtcyB3aXRoaW4gY2F0ZWdvcmllcyBiYXNlZCBvbiBzZWFyY2hcclxuLy8gICAgIGNvbnN0IGdldEZpbHRlcmVkSXRlbXMgPSAoY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgICAgaWYgKCFzaWRlYmFyU2VhcmNoUXVlcnkpIHJldHVybiBncm91cGVkTWVudXNbY2F0ZWdvcnldIHx8IFtdO1xyXG4vLyAgICAgICByZXR1cm4gKGdyb3VwZWRNZW51c1tjYXRlZ29yeV0gfHwgW10pLmZpbHRlcihpdGVtID0+XHJcbi8vICAgICAgICAgaXRlbS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNpZGViYXJTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfTtcclxuXHJcbi8vICAgICByZXR1cm4gKFxyXG4vLyAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgcmVmPXtyZWZ9XHJcbi8vICAgICAgICAgY2xhc3NOYW1lPXtgbWluLWgtc2NyZWVuIG1heC1oLWF1dG8gcC00IHB0LTggJHtvcGVuID8gXCJ3LTcyXCIgOiBcInctMjBcIn0gZHVyYXRpb24tMzAwIHJlbGF0aXZlIGJnLXdoaXRlIHNoYWRvdy1sZ2B9XHJcbi8vICAgICAgID5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi02IHB4LTJcIj5cclxuLy8gICAgICAgICAgIHtvcGVuICYmIChcclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgQ2F0ZWdvcmllc1xyXG4vLyAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKCFvcGVuKX1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xyXG4vLyAgICAgICAgICAgICAgICFvcGVuID8gXCJteC1hdXRvXCIgOiBcIlwiXHJcbi8vICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICA8RmlDaGV2cm9uTGVmdFxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtZ3JheS02MDAgdGV4dC14bCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgJHtcclxuLy8gICAgICAgICAgICAgICAgICFvcGVuID8gXCJyb3RhdGUtMTgwXCIgOiBcIlwiXHJcbi8vICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qIFNpZGViYXIgU2VhcmNoIElucHV0ICovfVxyXG4vLyAgICAgICAgIHtvcGVuICYmIChcclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBweC0yXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuLy8gICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuLy8gICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHJlcG9ydHMuLi5cIlxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e3NpZGViYXJTZWFyY2hRdWVyeX1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2lkZWJhclNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTggcHktMiB0ZXh0LXNtIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMC8yMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDBcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgPElvU2VhcmNoT3V0bGluZSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTIuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1ncmF5LTQwMCB0ZXh0LWJhc2VcIiAvPlxyXG4vLyAgICAgICAgICAgICAgIHtzaWRlYmFyU2VhcmNoUXVlcnkgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaWRlYmFyU2VhcmNoUXVlcnkoXCJcIil9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTIgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxJb0Nsb3NlQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgey8qIFNob3cgc2VhcmNoIHJlc3VsdHMgY291bnQgKi99XHJcbi8vICAgICAgICAgICAgIHtzaWRlYmFyU2VhcmNoUXVlcnkgJiYgKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMS41IHRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgRm91bmQge2ZpbHRlcmVkQ2F0ZWdvcmllcy5yZWR1Y2UoKGFjYywgY2F0ZWdvcnkpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgIGFjYyArIGdldEZpbHRlcmVkSXRlbXMoY2F0ZWdvcnkpLmxlbmd0aCwgMFxyXG4vLyAgICAgICAgICAgICAgICAgKX0gcmVzdWx0c1xyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAge2ZpbHRlcmVkQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiB7XHJcbi8vICAgICAgICAgICBjb25zdCBpdGVtcyA9IGdldEZpbHRlcmVkSXRlbXMoY2F0ZWdvcnkpO1xyXG4vLyAgICAgICAgICAgLy8gU2tpcCBjYXRlZ29yeSBpZiBubyBpdGVtcyBtYXRjaCBzZWFyY2hcclxuLy8gICAgICAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDAgJiYgc2lkZWJhclNlYXJjaFF1ZXJ5KSByZXR1cm4gbnVsbDtcclxuXHJcbi8vICAgICAgICAgICBjb25zdCBpc0V4cGFuZGVkID0gZXhwYW5kZWRDYXRlZ29yaWVzW2NhdGVnb3J5XSB8fCBmYWxzZTtcclxuLy8gICAgICAgICAgIGNvbnN0IGl0ZW1Db3VudCA9IGl0ZW1zLmxlbmd0aDtcclxuLy8gICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlQ2F0ZWdvcnkgPT09IGNhdGVnb3J5O1xyXG5cclxuLy8gICAgICAgICAgIC8vIElmIHNlYXJjaGluZywgYXV0by1leHBhbmQgY2F0ZWdvcmllcyB0aGF0IGhhdmUgbWF0Y2hlc1xyXG4vLyAgICAgICAgICAgY29uc3Qgc2hvdWxkRXhwYW5kID0gc2lkZWJhclNlYXJjaFF1ZXJ5ID8gdHJ1ZSA6IGlzRXhwYW5kZWQ7XHJcblxyXG4vLyAgICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgICAgPGRpdiBrZXk9e2NhdGVnb3J5fSBjbGFzc05hbWU9XCJtYi0zXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICBpZiAob3Blbikge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8vIFRvZ2dsZSBleHBhbnNpb25cclxuLy8gICAgICAgICAgICAgICAgICAgICB0b2dnbGVDYXRlZ29yeShjYXRlZ29yeSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLy8gU2V0IGFjdGl2ZSBjYXRlZ29yeSB0byBmaWx0ZXIgcmVwb3J0cyBvbiB0aGUgcmlnaHQgc2lkZVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUNhdGVnb3J5KGNhdGVnb3J5KTtcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIuNSByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke1xyXG4vLyAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSAmJiBvcGVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCBib3JkZXItbC00IGJvcmRlci1ibHVlLTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgOiBvcGVuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPyBcImhvdmVyOmJnLWdyYXktNTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDogXCJqdXN0aWZ5LWNlbnRlciBob3ZlcjpiZy1ncmF5LTUwXCJcclxuLy8gICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIHtvcGVuID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGZvbnQtc2VtaWJvbGQgdGV4dC1zbSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgPyBcInRleHQtYmx1ZS03MDBcIiA6IFwidGV4dC1ncmF5LTcwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQteHMgcHgtMS41IHB5LTAuNSByb3VuZGVkLWZ1bGwgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgPyBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS03MDBcIiA6IFwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTQwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtQ291bnR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge3Nob3VsZEV4cGFuZCA/IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxCc0NoZXZyb25Eb3duIGNsYXNzTmFtZT17YHRleHQtc20gJHtpc0FjdGl2ZSA/IFwidGV4dC1ibHVlLTUwMFwiIDogXCJ0ZXh0LWdyYXktNDAwXCJ9YH0gLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEJzQ2hldnJvblJpZ2h0IGNsYXNzTmFtZT17YHRleHQtc20gJHtpc0FjdGl2ZSA/IFwidGV4dC1ibHVlLTUwMFwiIDogXCJ0ZXh0LWdyYXktNDAwXCJ9YH0gLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0yIGgtMiByb3VuZGVkLWZ1bGwgJHtpc0FjdGl2ZSA/IFwiYmctYmx1ZS01MDBcIiA6IFwiYmctZ3JheS0zMDBcIn1gfT48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHtvcGVuICYmIHNob3VsZEV4cGFuZCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTMgYm9yZGVyLWwtMiBib3JkZXItZ3JheS0xMDAgcGwtMyBzcGFjZS15LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoeyB0aXRsZSwgbGluaywgSWNvbiwgY29sb3IsIGlzTmV3IH0pID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdG89e2xpbmt9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNjcm9sbFRvVG9wKCk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldEhpZGVTaWRlYmFyKCFoaWRlU2lkZWJhcik7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENsZWFyIHNlYXJjaCB3aGVuIG5hdmlnYXRpbmdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2lkZWJhclNlYXJjaFF1ZXJ5KFwiXCIpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmU6IGlzTGlua0FjdGl2ZSB9KSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtMyBweS0yLjUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBpc0xpbmtBY3RpdmVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgc2hhZG93LXNtXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6dGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH1gXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgeyh7IGlzQWN0aXZlOiBpc0xpbmtBY3RpdmUgfSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsxOH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTGlua0FjdGl2ZSA/IFwidGV4dC1ibHVlLTYwMFwiIDogXCJ0ZXh0LWdyYXktNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleC0xIHRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy10aWdodFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBORVdcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICB9KX1cclxuXHJcbi8vICAgICAgICAgey8qIFNob3cgXCJObyByZXN1bHRzXCIgbWVzc2FnZSB3aGVuIHNlYXJjaCByZXR1cm5zIG5vIHJlc3VsdHMgKi99XHJcbi8vICAgICAgICAge29wZW4gJiYgc2lkZWJhclNlYXJjaFF1ZXJ5ICYmIGZpbHRlcmVkQ2F0ZWdvcmllcy5sZW5ndGggPT09IDAgJiYgKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1ncmF5LTEwMCByb3VuZGVkLWZ1bGwgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxJb1NlYXJjaE91dGxpbmUgY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC1ncmF5LTQwMFwiIC8+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyByZXBvcnRzIGZvdW5kPC9wPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDAgbXQtMVwiPlRyeSBhZGp1c3RpbmcgeW91ciBzZWFyY2g8L3A+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgICk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gUmVuZGVyIGNhdGVnb3JpZXMgY2hpcHMgd2l0aCBjdXN0b20gb3JkZXJcclxuLy8gICBjb25zdCByZW5kZXJDYXRlZ29yeUNoaXBzID0gKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgY2hpcENhdGVnb3JpZXMgPSBbXCJBbGxcIiwgLi4uc29ydGVkQ2F0ZWdvcmllc107XHJcblxyXG4vLyAgICAgcmV0dXJuIChcclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtYi02IHBiLTIgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbi8vICAgICAgICAge2NoaXBDYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IHtcclxuLy8gICAgICAgICAgIGNvbnN0IGNvdW50ID0gY2F0ZWdvcnkgPT09IFwiQWxsXCJcclxuLy8gICAgICAgICAgICAgPyBtZW51cy5maWx0ZXIobSA9PiBtLnZpc2libGUpLmxlbmd0aFxyXG4vLyAgICAgICAgICAgICA6IGdyb3VwZWRNZW51c1tjYXRlZ29yeV0/Lmxlbmd0aCB8fCAwO1xyXG5cclxuLy8gICAgICAgICAgIHJldHVybiAoXHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBrZXk9e2NhdGVnb3J5fVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUNhdGVnb3J5KGNhdGVnb3J5KX1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHdoaXRlc3BhY2Utbm93cmFwICR7XHJcbi8vICAgICAgICAgICAgICAgICBhY3RpdmVDYXRlZ29yeSA9PT0gY2F0ZWdvcnlcclxuLy8gICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1ibHVlLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwXCJcclxuLy8gICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIHtjYXRlZ29yeX1cclxuLy8gICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BtbC0xLjUgdGV4dC14cyAke1xyXG4vLyAgICAgICAgICAgICAgICAgYWN0aXZlQ2F0ZWdvcnkgPT09IGNhdGVnb3J5ID8gXCJ0ZXh0LWJsdWUtMTAwXCIgOiBcInRleHQtZ3JheS00MDBcIlxyXG4vLyAgICAgICAgICAgICAgIH1gfT5cclxuLy8gICAgICAgICAgICAgICAgICh7Y291bnR9KVxyXG4vLyAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICApO1xyXG4vLyAgICAgICAgIH0pfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgICk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gUmVuZGVyIGdyaWQgY2FyZHNcclxuLy8gICBjb25zdCByZW5kZXJHcmlkQ2FyZHMgPSAoKSA9PiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgZ2FwLTVcIj5cclxuLy8gICAgICAge2ZpbHRlcmVkTWVudXMubWFwKCh7IHRpdGxlLCBJY29uLCBsaW5rLCBjb2xvciwgaXNOZXcgfSkgPT4gKFxyXG4vLyAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgIGtleT17bGlua31cclxuLy8gICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbi8vICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBob3Zlcjpib3JkZXItYmx1ZS0yMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTEuNVwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JhZGllbnQtdG8tYnIgJHtjb2xvcn0gaC0yOCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5gfVxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzVcIj48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ0ZXh0LTV4bCB0ZXh0LXdoaXRlIGRyb3Atc2hhZG93LWxnIHJlbGF0aXZlIHotMTBcIiAvPlxyXG4vLyAgICAgICAgICAgICAgIHtpc05ldyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyByaWdodC0zIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlIHNoYWRvdy1sZyB6LTEwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIE5FV1xyXG4vLyAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNVwiPlxyXG4vLyAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS02MDAgdHJhbnNpdGlvbi1jb2xvcnMgbGluZS1jbGFtcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1ibHVlLTYwMCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+VmlldyBSZXBvcnQ8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgbWwtMiBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tdHJhbnNmb3JtXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTkgNWw3IDctNyA3XCIgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICApKX1cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcblxyXG4vLyAgIC8vIFJlbmRlciBsaXN0IGl0ZW1zXHJcbi8vICAgY29uc3QgcmVuZGVyTGlzdEl0ZW1zID0gKCkgPT4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuLy8gICAgICAge2ZpbHRlcmVkTWVudXMubWFwKCh7IHRpdGxlLCBJY29uLCBsaW5rLCBjb2xvciwgaWQsIGlzTmV3IH0pID0+IChcclxuLy8gICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICBrZXk9e2lkfVxyXG4vLyAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTmF2aWdhdGlvbihsaW5rKX1cclxuLy8gICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyXCJcclxuLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBob3Zlcjpib3JkZXItYmx1ZS0yMDAgaG92ZXI6LXRyYW5zbGF0ZS14LTFcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBwLTQgaG92ZXI6YmctZ3JheS01MC81MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgYmctZ3JhZGllbnQtdG8tYnIgJHtjb2xvcn0gcm91bmRlZC14bCBwLTMgbXItNCBmbGV4LXNocmluay0wYH0+XHJcbi8vICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIHRleHQtd2hpdGVcIiAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IG1pbi13LTBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS02MDAgdHJhbnNpdGlvbi1jb2xvcnMgdHJ1bmNhdGVcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtpc05ldyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBmbGV4LXNocmluay0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBORVdcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0wLjVcIj5DbGljayB0byB2aWV3IGRldGFpbGVkIHJlcG9ydDwvcD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8c3ZnXHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS0zMDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTUwMCBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tYWxsIGZsZXgtc2hyaW5rLTAgbWwtMlwiXHJcbi8vICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4vLyAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTkgNWw3IDctNyA3XCIgLz5cclxuLy8gICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgKSl9XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG5cclxuLy8gICAvLyBSZW5kZXIgZHJhZ2dhYmxlIGl0ZW1zIHdpdGggY2F0ZWdvcnkgZHJvcGRvd24gZm9yIG1hbmFnZSBtb2RhbFxyXG4vLyAgIGNvbnN0IHJlbmRlckRyYWdnYWJsZUl0ZW1zID0gKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZ3JvdXBlZEJ5Q2F0ZWdvcnkgPSB7fTtcclxuLy8gICAgIG1lbnVzLmZvckVhY2gobWVudSA9PiB7XHJcbi8vICAgICAgIGNvbnN0IGNhdGVnb3J5ID0gbWVudS5jYXRlZ29yeSB8fCBcIlVuY2F0ZWdvcml6ZWRcIjtcclxuLy8gICAgICAgaWYgKCFncm91cGVkQnlDYXRlZ29yeVtjYXRlZ29yeV0pIHtcclxuLy8gICAgICAgICBncm91cGVkQnlDYXRlZ29yeVtjYXRlZ29yeV0gPSBbXTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICBncm91cGVkQnlDYXRlZ29yeVtjYXRlZ29yeV0ucHVzaChtZW51KTtcclxuLy8gICAgIH0pO1xyXG5cclxuLy8gICAgIE9iamVjdC5rZXlzKGdyb3VwZWRCeUNhdGVnb3J5KS5mb3JFYWNoKGNhdGVnb3J5ID0+IHtcclxuLy8gICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldLnNvcnQoKGEsIGIpID0+IChhLm9yZGVyIHx8IDApIC0gKGIub3JkZXIgfHwgMCkpO1xyXG4vLyAgICAgfSk7XHJcblxyXG4vLyAgICAgY29uc3Qgc29ydGVkQ2F0S2V5cyA9IE9iamVjdC5rZXlzKGdyb3VwZWRCeUNhdGVnb3J5KS5zb3J0KChhLCBiKSA9PiB7XHJcbi8vICAgICAgIGNvbnN0IGluZGV4QSA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihhKTtcclxuLy8gICAgICAgY29uc3QgaW5kZXhCID0gY2F0ZWdvcnlPcmRlci5pbmRleE9mKGIpO1xyXG4vLyAgICAgICBpZiAoaW5kZXhBICE9PSAtMSAmJiBpbmRleEIgIT09IC0xKSByZXR1cm4gaW5kZXhBIC0gaW5kZXhCO1xyXG4vLyAgICAgICBpZiAoaW5kZXhBICE9PSAtMSkgcmV0dXJuIC0xO1xyXG4vLyAgICAgICBpZiAoaW5kZXhCICE9PSAtMSkgcmV0dXJuIDE7XHJcbi8vICAgICAgIHJldHVybiBhLmxvY2FsZUNvbXBhcmUoYik7XHJcbi8vICAgICB9KTtcclxuXHJcbi8vICAgICBjb25zdCBhbGxDYXRlZ29yaWVzID0gZ2V0QWxsQ2F0ZWdvcmllcygpO1xyXG5cclxuLy8gICAgIHJldHVybiBzb3J0ZWRDYXRLZXlzLm1hcChjYXRlZ29yeSA9PiAoXHJcbi8vICAgICAgIDxkaXYga2V5PXtjYXRlZ29yeX0gY2xhc3NOYW1lPVwibWItNlwiPlxyXG4vLyAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItM1wiPlxyXG4vLyAgICAgICAgICAge2NhdGVnb3J5fVxyXG4vLyAgICAgICAgIDwvaDQ+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuLy8gICAgICAgICAgIHtncm91cGVkQnlDYXRlZ29yeVtjYXRlZ29yeV0ubWFwKChtZW51LCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICAgICAgICBjb25zdCBpc0RyYWdnaW5nID0gZHJhZ2dlZEl0ZW0/Lml0ZW0/LmlkID09PSBtZW51LmlkO1xyXG4vLyAgICAgICAgICAgICBjb25zdCBpc0RyYWdPdmVyID0gZHJhZ092ZXJJdGVtPy5pdGVtPy5pZCA9PT0gbWVudS5pZDtcclxuXHJcbi8vICAgICAgICAgICAgIHJldHVybiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAga2V5PXttZW51LmlkfVxyXG4vLyAgICAgICAgICAgICAgICAgZHJhZ2dhYmxlXHJcbi8vICAgICAgICAgICAgICAgICBvbkRyYWdTdGFydD17KGUpID0+IGhhbmRsZURyYWdTdGFydChlLCBtZW51LCBjYXRlZ29yeSl9XHJcbi8vICAgICAgICAgICAgICAgICBvbkRyYWdPdmVyPXsoZSkgPT4gaGFuZGxlRHJhZ092ZXIoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4vLyAgICAgICAgICAgICAgICAgb25EcmFnRW5kPXtoYW5kbGVEcmFnRW5kfVxyXG4vLyAgICAgICAgICAgICAgICAgb25Ecm9wPXsoZSkgPT4gaGFuZGxlRHJvcChlLCBtZW51LCBjYXRlZ29yeSl9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgaXNEcmFnZ2luZ1xyXG4vLyAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIGJvcmRlci0yIGJvcmRlci1ibHVlLTQwMCBzaGFkb3ctbGcgb3BhY2l0eS01MFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgOiBpc0RyYWdPdmVyXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNTAgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItYmx1ZS00MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTUwIGhvdmVyOmJnLWdyYXktMTAwIGJvcmRlci0yIGJvcmRlci10cmFuc3BhcmVudFwiXHJcbi8vICAgICAgICAgICAgICAgICB9IGN1cnNvci1tb3ZlYH1cclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGZsZXgtMSBtaW4tdy0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBjdXJzb3ItZ3JhYiBmbGV4LXNocmluay0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjAgMjBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNNyAyYTIgMiAwIDEgMCAwIDQgMiAyIDAgMCAwIDAtNHptMCA2YTIgMiAwIDEgMCAwIDQgMiAyIDAgMCAwIDAtNHptMCA2YTIgMiAwIDEgMCAwIDQgMiAyIDAgMCAwIDAtNHptNi0xMmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6XCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0cnVuY2F0ZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge21lbnUudGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5PcmRlcjoge21lbnUub3JkZXIgfHwgaW5kZXh9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktMzAwXCI+fDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21lbnUuY2F0ZWdvcnl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2F0ZWdvcnlDaGFuZ2UobWVudS5pZCwgZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJvcmRlciByb3VuZGVkIHB4LTIgcHktMSBiZy13aGl0ZSBob3Zlcjpib3JkZXItYmx1ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNDAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7YWxsQ2F0ZWdvcmllcy5tYXAoY2F0ID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Y2F0fSB2YWx1ZT17Y2F0fT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1sLTQgZmxleC1zaHJpbmstMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7bWVudS52aXNpYmxlID8gXCJWaXNpYmxlXCIgOiBcIkhpZGRlblwifVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxTd2l0Y2hcclxuLy8gICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXttZW51LnZpc2libGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhjaGVja2VkKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzZXRNZW51cygocHJldikgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcHJldi5tYXAoKGl0ZW0pID0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5pZCA9PT0gbWVudS5pZFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB7IC4uLml0ZW0sIHZpc2libGU6IGNoZWNrZWQgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBpdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgfSl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgKSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggbXQtMTYgYmctZ3JheS01MFwiPlxyXG4vLyAgICAgICA8TmF2YmFyIC8+XHJcbi8vICAgICAgIDxTaWRlYmFyIGhpZGVTaWRlYmFyPXtoaWRlU2lkZWJhcn0gLz5cclxuXHJcbi8vICAgICAgIHsvKiBTaWRlYmFyICovfVxyXG4vLyAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgY2xhc3NOYW1lPXtgJHtvcGVuID8gXCJ3LTcyXCIgOiBcInctMjBcIn0gYmctd2hpdGUgbWluLWgtc2NyZWVuIGJvcmRlci1yIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy15LWF1dG8gZmxleC1zaHJpbmstMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfVxyXG4vLyAgICAgICA+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctd2hpdGUgei0xMCBwLTQgbXQtMTBcIj5cclxuLy8gICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgIHNldEFjdGl2ZUNhdGVnb3J5KFwiQWxsXCIpO1xyXG4vLyAgICAgICAgICAgICAgIG5hdmlnYXRlKFwiL3JlcG9ydHNcIik7XHJcbi8vICAgICAgICAgICAgICAgc2Nyb2xsVG9Ub3AoKTtcclxuLy8gICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdy1mdWxsICR7XHJcbi8vICAgICAgICAgICAgICAgb3BlblxyXG4vLyAgICAgICAgICAgICAgICAgPyBcInB4LTQgcHktMi41IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWJsdWUtNzAwIHRleHQtd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzY2FsZS1bMS4wMl1cIlxyXG4vLyAgICAgICAgICAgICAgICAgOiBcInAtMi41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTEwXCJcclxuLy8gICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxGYUNoYXJ0QmFyIGNsYXNzTmFtZT17b3BlbiA/IFwidGV4dC1ibHVlLTEwMCB0ZXh0LWxnXCIgOiBcInRleHQtbGdcIn0gLz5cclxuLy8gICAgICAgICAgICAge29wZW4gJiYgPHNwYW4gY2xhc3NOYW1lPVwidHJhY2tpbmctd2lkZVwiPlJlcG9ydHM8L3NwYW4+fVxyXG4vLyAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAge3JlbmRlclNpZGViYXIoKX1cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogTWFpbiBDb250ZW50ICovfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTYgb3ZlcmZsb3ctaGlkZGVuIG1heC1oLXNjcmVlbiBvdmVyZmxvdy15LWF1dG9cIj5cclxuLy8gICAgICAgICB7bG9jYXRpb24ucGF0aG5hbWUgPT09IFwiL3JlcG9ydHNcIiA/IChcclxuLy8gICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgIHsvKiBTZWFyY2ggQmFyICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgbXQtMTBcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1heC13LTJ4bFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTQgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8SW9TZWFyY2hPdXRsaW5lIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC14bFwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHJlcG9ydHMuLi5cIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoUXVlcnkoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTIgcHItMTIgcHktMy41IHRleHQtYmFzZSBiZy13aGl0ZSBib3JkZXItMiBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctYmx1ZS01MDAvMjAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3cgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIHtzZWFyY2hRdWVyeSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhclNlYXJjaH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBwci00IGZsZXggaXRlbXMtY2VudGVyIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPElvQ2xvc2VDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC0yeGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIENvbnRyb2xzIEJhciAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICB7cmVuZGVyQ2F0ZWdvcnlDaGlwcygpfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld1R5cGUoXCJncmlkXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIuNSByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmlld1R5cGUgPT09IFwiZ3JpZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiR3JpZCBWaWV3XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPEJpR3JpZCBzaXplPXsyMH0gLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3VHlwZShcImxpc3RcIil9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMi41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICB2aWV3VHlwZSA9PT0gXCJsaXN0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMaXN0IFZpZXdcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8VGJMaXN0IHNpemU9ezIwfSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHJvdW5kZWQtbGcgYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNzAwIHRleHQtd2hpdGUgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyBtbC0yXCJcclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWFuYWdlTW9kYWwodHJ1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZpU2V0dGluZ3Mgc2l6ZT17MTZ9IC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgTWFuYWdlXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHsvKiBSZXN1bHRzIFN0YXRzICovfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgU2hvd2luZyB7ZmlsdGVyZWRNZW51cy5sZW5ndGh9IHJlcG9ydHtmaWx0ZXJlZE1lbnVzLmxlbmd0aCAhPT0gMSA/IFwic1wiIDogXCJcIn1cclxuLy8gICAgICAgICAgICAgICB7c2VhcmNoUXVlcnkgJiYgYCBmb3IgXCIke3NlYXJjaFF1ZXJ5fVwiYH1cclxuLy8gICAgICAgICAgICAgICB7YWN0aXZlQ2F0ZWdvcnkgIT09IFwiQWxsXCIgJiYgYCBpbiAke2FjdGl2ZUNhdGVnb3J5fWB9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgey8qIExvYWRpbmcgU3RhdGUgKi99XHJcbi8vICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0yMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtMTIgdy0xMiBib3JkZXItNCBib3JkZXItYmx1ZS02MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIj48L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKSA6IGZpbHRlcmVkTWVudXMubGVuZ3RoID09PSAwID8gKFxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMjBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMjAgaC0yMCBiZy1ncmF5LTEwMCByb3VuZGVkLWZ1bGwgbWItNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8SW9TZWFyY2hPdXRsaW5lIGNsYXNzTmFtZT1cInRleHQtNHhsIHRleHQtZ3JheS00MDBcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItMlwiPk5vIHJlcG9ydHMgZm91bmQ8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7YWN0aXZlQ2F0ZWdvcnkgIT09IFwiQWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA/IGBObyByZXBvcnRzIGZvdW5kIGluIFwiJHthY3RpdmVDYXRlZ29yeX1cIiBjYXRlZ29yeWBcclxuLy8gICAgICAgICAgICAgICAgICAgICA6IFwiVHJ5IGFkanVzdGluZyB5b3VyIHNlYXJjaCBvciBmaWx0ZXIgY3JpdGVyaWFcIn1cclxuLy8gICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICB2aWV3VHlwZSA9PT0gXCJncmlkXCIgPyByZW5kZXJHcmlkQ2FyZHMoKSA6IHJlbmRlckxpc3RJdGVtcygpXHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPE91dGxldCAvPlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgey8qIE1hbmFnZSBNb2RhbCAqL31cclxuLy8gICAgICAgPE1vZGFsXHJcbi8vICAgICAgICAgdGl0bGU9e1xyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICA8RmlTZXR0aW5ncyBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuLy8gICAgICAgICAgICAgPHNwYW4+TWFuYWdlIFJlcG9ydHMgLSBPcmRlciwgQ2F0ZWdvcnkgJiBWaXNpYmlsaXR5PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIG9wZW49e21hbmFnZU1vZGFsfVxyXG4vLyAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRNYW5hZ2VNb2RhbChmYWxzZSl9XHJcbi8vICAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4vLyAgICAgICAgIHdpZHRoPXs5MDB9XHJcbi8vICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC0yeGxcIlxyXG4vLyAgICAgICA+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtNCBiZy1ibHVlLTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCBtdC0xMFwiPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS03MDAgc3BhY2UteS0xXCI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjAgMjBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxwYXRoIGZpbGxSdWxlPVwiZXZlbm9kZFwiIGQ9XCJNMTggMTBhOCA4IDAgMTEtMTYgMCA4IDggMCAwMTE2IDB6bS03LTRhMSAxIDAgMTEtMiAwIDEgMSAwIDAxMiAwek05IDlhMSAxIDAgMDAwIDJ2M2ExIDEgMCAwMDEgMWgxYTEgMSAwIDEwMC0ydi0zYTEgMSAwIDAwLTEtMUg5elwiIGNsaXBSdWxlPVwiZXZlbm9kZFwiIC8+XHJcbi8vICAgICAgICAgICAgICAgPC9zdmc+XHJcbi8vICAgICAgICAgICAgICAgPHNwYW4+PHN0cm9uZz5EcmFnPC9zdHJvbmc+IHRvIHJlb3JkZXIgcmVwb3J0cyB3aXRoaW4gYSBjYXRlZ29yeTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtbC03XCI+XHJcbi8vICAgICAgICAgICAgICAgPHNwYW4+VXNlIHRoZSA8c3Ryb25nPmRyb3Bkb3duPC9zdHJvbmc+IHRvIG1vdmUgYSByZXBvcnQgdG8gYSBkaWZmZXJlbnQgY2F0ZWdvcnk8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBtYXgtaC1bNjB2aF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuLy8gICAgICAgICAgIHtyZW5kZXJEcmFnZ2FibGVJdGVtcygpfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgbXQtNiBwdC00IGJvcmRlci10XCI+XHJcbi8vICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbWVkaXVtXCJcclxuLy8gICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWFuYWdlTW9kYWwoZmFsc2UpfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICBDYW5jZWxcclxuLy8gICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIuNSBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZm9udC1tZWRpdW0gc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbi8vICAgICAgICAgICAgIG9uQ2xpY2s9e3NhdmVSZXBvcnRzfVxyXG4vLyAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICB7c2F2aW5nID8gKFxyXG4vLyAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtNCB3LTQgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIGJvcmRlci10LXRyYW5zcGFyZW50XCI+PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgU2F2aW5nLi4uXHJcbi8vICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIFwiU2F2ZSBDaGFuZ2VzXCJcclxuLy8gICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L01vZGFsPlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IFJlcG9ydHMgPSAoKSA9PiB7XHJcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbYWN0aXZlQ2F0ZWdvcnksIHNldEFjdGl2ZUNhdGVnb3J5XSA9IHVzZVN0YXRlKFwiQWxsXCIpO1xyXG4gIGNvbnN0IFt2aWV3VHlwZSwgc2V0Vmlld1R5cGVdID0gdXNlU3RhdGUoXCJncmlkXCIpO1xyXG4gIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NpZGViYXJTZWFyY2hRdWVyeSwgc2V0U2lkZWJhclNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFttb2RhbFNlYXJjaFF1ZXJ5LCBzZXRNb2RhbFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpOyAvLyBOZXcgc3RhdGUgZm9yIG1vZGFsIHNlYXJjaFxyXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtoaWRlU2lkZWJhciwgc2V0SGlkZVNpZGViYXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtleHBhbmRlZENhdGVnb3JpZXMsIHNldEV4cGFuZGVkQ2F0ZWdvcmllc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW21lbnVzLCBzZXRNZW51c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbWFuYWdlTW9kYWwsIHNldE1hbmFnZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2RyYWdnZWRJdGVtLCBzZXREcmFnZ2VkSXRlbV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZHJhZ092ZXJJdGVtLCBzZXREcmFnT3Zlckl0ZW1dID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIC8vIERlZmluZSBjdXN0b20gY2F0ZWdvcnkgb3JkZXJcclxuICBjb25zdCBjYXRlZ29yeU9yZGVyID0gW1wiQ3VzdG9tZXJcIiwgXCJBdWN0aW9uXCIsIFwiUGF5bWVudHNcIl07XHJcblxyXG4gIC8vIEdldCBhbGwgdW5pcXVlIGNhdGVnb3JpZXMgZnJvbSBtZW51c1xyXG4gIGNvbnN0IGdldEFsbENhdGVnb3JpZXMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBjYXRlZ29yaWVzID0gbmV3IFNldCgpO1xyXG4gICAgbWVudXMuZm9yRWFjaCgobWVudSkgPT4ge1xyXG4gICAgICBpZiAobWVudS5jYXRlZ29yeSkge1xyXG4gICAgICAgIGNhdGVnb3JpZXMuYWRkKG1lbnUuY2F0ZWdvcnkpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKGNhdGVnb3JpZXMpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvZ2dsZUNhdGVnb3J5ID0gKGNhdGVnb3J5KSA9PiB7XHJcbiAgICBzZXRFeHBhbmRlZENhdGVnb3JpZXMoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtjYXRlZ29yeV06ICFwcmV2W2NhdGVnb3J5XSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBzY3JvbGxUb1RvcCA9ICgpID0+IHtcclxuICAgIHdpbmRvdy5zY3JvbGxUbyh7IHRvcDogMCwgYmVoYXZpb3I6IFwic21vb3RoXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoUmVwb3J0cygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hSZXBvcnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vcmVwb3J0LXZpc2liaWxpdHlcIik7XHJcbiAgICAgIGNvbnN0IHZpc2liaWxpdHkgPSByZXNwb25zZS5kYXRhLmRhdGEgfHwgW107XHJcblxyXG4gICAgICBjb25zdCBmaW5hbE1lbnVzID0gc3ViTWVudXMubWFwKChtZW51KSA9PiB7XHJcbiAgICAgICAgY29uc3QgZGJNZW51ID0gdmlzaWJpbGl0eS5maW5kKChpdGVtKSA9PiBpdGVtLnJlcG9ydElkID09PSBtZW51LmlkKTtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgLi4ubWVudSxcclxuICAgICAgICAgIHZpc2libGU6IGRiTWVudSA/IGRiTWVudS52aXNpYmxlIDogdHJ1ZSxcclxuICAgICAgICAgIGNhdGVnb3J5OiBkYk1lbnU/LmNhdGVnb3J5IHx8IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCIsXHJcbiAgICAgICAgICBvcmRlcjogZGJNZW51Py5vcmRlciB8fCBtZW51Lm9yZGVyIHx8IDAsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBTb3J0IGJ5IG9yZGVyXHJcbiAgICAgIGZpbmFsTWVudXMuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcbiAgICAgIHNldE1lbnVzKGZpbmFsTWVudXMpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgc2V0TWVudXMoXHJcbiAgICAgICAgc3ViTWVudXMubWFwKChtZW51KSA9PiAoe1xyXG4gICAgICAgICAgLi4ubWVudSxcclxuICAgICAgICAgIHZpc2libGU6IHRydWUsXHJcbiAgICAgICAgICBjYXRlZ29yeTogbWVudS5jYXRlZ29yeSB8fCBcIlVuY2F0ZWdvcml6ZWRcIixcclxuICAgICAgICAgIG9yZGVyOiBtZW51Lm9yZGVyIHx8IDAsXHJcbiAgICAgICAgfSkpLFxyXG4gICAgICApO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVOYXZpZ2F0aW9uID0gKGxpbmspID0+IHtcclxuICAgIG5hdmlnYXRlKGxpbmspO1xyXG4gICAgc2V0VGltZW91dChzY3JvbGxUb1RvcCwgMTAwKTtcclxuICB9O1xyXG5cclxuICBjb25zdCByZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkTWVudXMgPSBtZW51c1xyXG4gICAgLmZpbHRlcigobWVudSkgPT4gbWVudS52aXNpYmxlKVxyXG4gICAgLmZpbHRlcihcclxuICAgICAgKG1lbnUpID0+IGFjdGl2ZUNhdGVnb3J5ID09PSBcIkFsbFwiIHx8IG1lbnUuY2F0ZWdvcnkgPT09IGFjdGl2ZUNhdGVnb3J5LFxyXG4gICAgKVxyXG4gICAgLmZpbHRlcigobWVudSkgPT5cclxuICAgICAgbWVudS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpLFxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCBhbGxGaWx0ZXJlZEdyb3VwZWRNZW51cyA9IGZpbHRlcmVkTWVudXMucmVkdWNlKChhY2MsIG1lbnUpID0+IHtcclxuICBjb25zdCBjYXRlZ29yeSA9IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCI7XHJcblxyXG4gIGlmICghYWNjW2NhdGVnb3J5XSkge1xyXG4gICAgYWNjW2NhdGVnb3J5XSA9IFtdO1xyXG4gIH1cclxuXHJcbiAgYWNjW2NhdGVnb3J5XS5wdXNoKG1lbnUpO1xyXG5cclxuICByZXR1cm4gYWNjO1xyXG59LCB7fSk7XHJcblxyXG5PYmplY3Qua2V5cyhhbGxGaWx0ZXJlZEdyb3VwZWRNZW51cykuZm9yRWFjaCgoY2F0ZWdvcnkpID0+IHtcclxuICBhbGxGaWx0ZXJlZEdyb3VwZWRNZW51c1tjYXRlZ29yeV0uc29ydChcclxuICAgIChhLCBiKSA9PiAoYS5vcmRlciB8fCAwKSAtIChiLm9yZGVyIHx8IDApLFxyXG4gICk7XHJcbn0pO1xyXG5cclxuY29uc3Qgc29ydGVkQWxsRmlsdGVyZWRDYXRlZ29yaWVzID0gT2JqZWN0LmtleXMoXHJcbiAgYWxsRmlsdGVyZWRHcm91cGVkTWVudXMsXHJcbikuc29ydCgoYSwgYikgPT4ge1xyXG4gIGNvbnN0IGluZGV4QSA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihhKTtcclxuICBjb25zdCBpbmRleEIgPSBjYXRlZ29yeU9yZGVyLmluZGV4T2YoYik7XHJcblxyXG4gIGlmIChpbmRleEEgIT09IC0xICYmIGluZGV4QiAhPT0gLTEpIHtcclxuICAgIHJldHVybiBpbmRleEEgLSBpbmRleEI7XHJcbiAgfVxyXG5cclxuICBpZiAoaW5kZXhBICE9PSAtMSkgcmV0dXJuIC0xO1xyXG4gIGlmIChpbmRleEIgIT09IC0xKSByZXR1cm4gMTtcclxuXHJcbiAgcmV0dXJuIGEubG9jYWxlQ29tcGFyZShiKTtcclxufSk7XHJcblxyXG4gIGNvbnN0IGdyb3VwZWRNZW51cyA9IG1lbnVzXHJcbiAgICAuZmlsdGVyKChtZW51KSA9PiBtZW51LnZpc2libGUpXHJcbiAgICAucmVkdWNlKChhY2MsIG1lbnUpID0+IHtcclxuICAgICAgY29uc3QgY2F0ZWdvcnkgPSBtZW51LmNhdGVnb3J5IHx8IFwiVW5jYXRlZ29yaXplZFwiO1xyXG4gICAgICBpZiAoIWFjY1tjYXRlZ29yeV0pIHtcclxuICAgICAgICBhY2NbY2F0ZWdvcnldID0gW107XHJcbiAgICAgIH1cclxuICAgICAgYWNjW2NhdGVnb3J5XS5wdXNoKG1lbnUpO1xyXG4gICAgICByZXR1cm4gYWNjO1xyXG4gICAgfSwge30pO1xyXG5cclxuICAvLyBTb3J0IGl0ZW1zIHdpdGhpbiBlYWNoIGNhdGVnb3J5IGJ5IG9yZGVyXHJcbiAgT2JqZWN0LmtleXMoZ3JvdXBlZE1lbnVzKS5mb3JFYWNoKChjYXRlZ29yeSkgPT4ge1xyXG4gICAgZ3JvdXBlZE1lbnVzW2NhdGVnb3J5XS5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciB8fCAwKSAtIChiLm9yZGVyIHx8IDApKTtcclxuICB9KTtcclxuXHJcbiAgLy8gU29ydCBjYXRlZ29yaWVzIGJhc2VkIG9uIGN1c3RvbSBvcmRlclxyXG4gIGNvbnN0IHNvcnRlZENhdGVnb3JpZXMgPSBPYmplY3Qua2V5cyhncm91cGVkTWVudXMpLnNvcnQoKGEsIGIpID0+IHtcclxuICAgIGNvbnN0IGluZGV4QSA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihhKTtcclxuICAgIGNvbnN0IGluZGV4QiA9IGNhdGVnb3J5T3JkZXIuaW5kZXhPZihiKTtcclxuXHJcbiAgICBpZiAoaW5kZXhBICE9PSAtMSAmJiBpbmRleEIgIT09IC0xKSB7XHJcbiAgICAgIHJldHVybiBpbmRleEEgLSBpbmRleEI7XHJcbiAgICB9XHJcbiAgICBpZiAoaW5kZXhBICE9PSAtMSkgcmV0dXJuIC0xO1xyXG4gICAgaWYgKGluZGV4QiAhPT0gLTEpIHJldHVybiAxO1xyXG4gICAgcmV0dXJuIGEubG9jYWxlQ29tcGFyZShiKTtcclxuICB9KTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xlYXJTZWFyY2ggPSAoKSA9PiB7XHJcbiAgICBzZXRTZWFyY2hRdWVyeShcIlwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbGVhck1vZGFsU2VhcmNoID0gKCkgPT4ge1xyXG4gICAgc2V0TW9kYWxTZWFyY2hRdWVyeShcIlwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBzYXZlUmVwb3J0cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldFNhdmluZyh0cnVlKTtcclxuICAgICAgYXdhaXQgYXBpLnB1dChcIi92MS9hZG1pbi9yZXBvcnQtdmlzaWJpbGl0eVwiLCB7XHJcbiAgICAgICAgcmVwb3J0czogbWVudXMubWFwKChtZW51KSA9PiAoe1xyXG4gICAgICAgICAgcmVwb3J0SWQ6IG1lbnUuaWQsXHJcbiAgICAgICAgICB2aXNpYmxlOiBtZW51LnZpc2libGUsXHJcbiAgICAgICAgICBjYXRlZ29yeTogbWVudS5jYXRlZ29yeSxcclxuICAgICAgICAgIG9yZGVyOiBtZW51Lm9yZGVyIHx8IDAsXHJcbiAgICAgICAgfSkpLFxyXG4gICAgICB9KTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiUmVwb3J0IHNldHRpbmdzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICBhd2FpdCBmZXRjaFJlcG9ydHMoKTtcclxuICAgICAgc2V0TWFuYWdlTW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRNb2RhbFNlYXJjaFF1ZXJ5KFwiXCIpOyAvLyBDbGVhciBzZWFyY2ggd2hlbiBjbG9zaW5nIG1vZGFsXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSByZXBvcnQgc2V0dGluZ3NcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBjYXRlZ29yeSBjaGFuZ2UgZm9yIGEgc3BlY2lmaWMgcmVwb3J0XHJcbiAgY29uc3QgaGFuZGxlQ2F0ZWdvcnlDaGFuZ2UgPSAobWVudUlkLCBuZXdDYXRlZ29yeSkgPT4ge1xyXG4gICAgc2V0TWVudXMoKHByZXYpID0+IHtcclxuICAgICAgY29uc3QgbWVudVRvTW92ZSA9IHByZXYuZmluZCgobSkgPT4gbS5pZCA9PT0gbWVudUlkKTtcclxuICAgICAgY29uc3Qgb2xkQ2F0ZWdvcnkgPSBtZW51VG9Nb3ZlPy5jYXRlZ29yeTtcclxuXHJcbiAgICAgIGNvbnN0IHVwZGF0ZWRNZW51cyA9IHByZXYubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgaWYgKGl0ZW0uaWQgPT09IG1lbnVJZCkge1xyXG4gICAgICAgICAgcmV0dXJuIHsgLi4uaXRlbSwgY2F0ZWdvcnk6IG5ld0NhdGVnb3J5IH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBpdGVtO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IGl0ZW1zSW5OZXdDYXRlZ29yeSA9IHVwZGF0ZWRNZW51c1xyXG4gICAgICAgIC5maWx0ZXIoKG0pID0+IG0uY2F0ZWdvcnkgPT09IG5ld0NhdGVnb3J5KVxyXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciB8fCAwKSAtIChiLm9yZGVyIHx8IDApKTtcclxuXHJcbiAgICAgIGl0ZW1zSW5OZXdDYXRlZ29yeS5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZvdW5kSXRlbSA9IHVwZGF0ZWRNZW51cy5maW5kKChtKSA9PiBtLmlkID09PSBpdGVtLmlkKTtcclxuICAgICAgICBpZiAoZm91bmRJdGVtKSB7XHJcbiAgICAgICAgICBmb3VuZEl0ZW0ub3JkZXIgPSBpbmRleDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaWYgKG9sZENhdGVnb3J5ICYmIG9sZENhdGVnb3J5ICE9PSBuZXdDYXRlZ29yeSkge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1zSW5PbGRDYXRlZ29yeSA9IHVwZGF0ZWRNZW51c1xyXG4gICAgICAgICAgLmZpbHRlcigobSkgPT4gbS5jYXRlZ29yeSA9PT0gb2xkQ2F0ZWdvcnkpXHJcbiAgICAgICAgICAuc29ydCgoYSwgYikgPT4gKGEub3JkZXIgfHwgMCkgLSAoYi5vcmRlciB8fCAwKSk7XHJcblxyXG4gICAgICAgIGl0ZW1zSW5PbGRDYXRlZ29yeS5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgZm91bmRJdGVtID0gdXBkYXRlZE1lbnVzLmZpbmQoKG0pID0+IG0uaWQgPT09IGl0ZW0uaWQpO1xyXG4gICAgICAgICAgaWYgKGZvdW5kSXRlbSkge1xyXG4gICAgICAgICAgICBmb3VuZEl0ZW0ub3JkZXIgPSBpbmRleDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHVwZGF0ZWRNZW51cztcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgaWYgKGxvY2F0aW9uLnBhdGhuYW1lID09PSBcIi9yZXBvcnRzXCIpIHtcclxuICAgIHNldEhpZGVTaWRlYmFyKGZhbHNlKTtcclxuICAgIHNldE9wZW4odHJ1ZSk7XHJcbiAgfSBlbHNlIGlmIChsb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKFwiL3JlcG9ydHMvXCIpKSB7XHJcbiAgICBzZXRIaWRlU2lkZWJhcih0cnVlKTtcclxuICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgfVxyXG59LCBbbG9jYXRpb24ucGF0aG5hbWVdKTtcclxuXHJcbiAgLy8gRHJhZyBhbmQgZHJvcCBoYW5kbGVycyBmb3IgcmVvcmRlcmluZyB3aXRoaW4gY2F0ZWdvcmllc1xyXG4gIGNvbnN0IGhhbmRsZURyYWdTdGFydCA9IChlLCBpdGVtLCBjYXRlZ29yeSkgPT4ge1xyXG4gICAgc2V0RHJhZ2dlZEl0ZW0oeyBpdGVtLCBjYXRlZ29yeSB9KTtcclxuICAgIGUuZGF0YVRyYW5zZmVyLmVmZmVjdEFsbG93ZWQgPSBcIm1vdmVcIjtcclxuICAgIGUuZGF0YVRyYW5zZmVyLnNldERhdGEoXHJcbiAgICAgIFwidGV4dC9wbGFpblwiLFxyXG4gICAgICBKU09OLnN0cmluZ2lmeSh7IGlkOiBpdGVtLmlkLCBjYXRlZ29yeSB9KSxcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRHJhZ092ZXIgPSAoZSwgaXRlbSwgY2F0ZWdvcnkpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldERyYWdPdmVySXRlbSh7IGl0ZW0sIGNhdGVnb3J5IH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURyYWdFbmQgPSAoKSA9PiB7XHJcbiAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEcm9wID0gKGUsIHRhcmdldEl0ZW0sIHRhcmdldENhdGVnb3J5KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgaWYgKCFkcmFnZ2VkSXRlbSB8fCBkcmFnZ2VkSXRlbS5jYXRlZ29yeSAhPT0gdGFyZ2V0Q2F0ZWdvcnkpIHtcclxuICAgICAgc2V0RHJhZ2dlZEl0ZW0obnVsbCk7XHJcbiAgICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHNvdXJjZUl0ZW0gPSBkcmFnZ2VkSXRlbS5pdGVtO1xyXG4gICAgY29uc3Qgc291cmNlSW5kZXggPSBtZW51cy5maW5kSW5kZXgoKG0pID0+IG0uaWQgPT09IHNvdXJjZUl0ZW0uaWQpO1xyXG4gICAgY29uc3QgdGFyZ2V0SW5kZXggPSBtZW51cy5maW5kSW5kZXgoKG0pID0+IG0uaWQgPT09IHRhcmdldEl0ZW0uaWQpO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgc291cmNlSW5kZXggPT09IC0xIHx8XHJcbiAgICAgIHRhcmdldEluZGV4ID09PSAtMSB8fFxyXG4gICAgICBzb3VyY2VJbmRleCA9PT0gdGFyZ2V0SW5kZXhcclxuICAgICkge1xyXG4gICAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuICAgICAgc2V0RHJhZ092ZXJJdGVtKG51bGwpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbmV3TWVudXMgPSBbLi4ubWVudXNdO1xyXG4gICAgY29uc3QgW3JlbW92ZWRdID0gbmV3TWVudXMuc3BsaWNlKHNvdXJjZUluZGV4LCAxKTtcclxuICAgIG5ld01lbnVzLnNwbGljZSh0YXJnZXRJbmRleCwgMCwgcmVtb3ZlZCk7XHJcblxyXG4gICAgY29uc3QgY2F0ZWdvcnlJdGVtcyA9IG5ld01lbnVzLmZpbHRlcigobSkgPT4gbS5jYXRlZ29yeSA9PT0gdGFyZ2V0Q2F0ZWdvcnkpO1xyXG4gICAgY2F0ZWdvcnlJdGVtcy5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICBpdGVtLm9yZGVyID0gaW5kZXg7XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRNZW51cyhuZXdNZW51cyk7XHJcbiAgICBzZXREcmFnZ2VkSXRlbShudWxsKTtcclxuICAgIHNldERyYWdPdmVySXRlbShudWxsKTtcclxuICB9O1xyXG5cclxuICAvLyBVcGRhdGVkIHNpZGViYXIgcmVuZGVyIHdpdGggc2VhcmNoIGFuZCBjbGlja2FibGUgY2F0ZWdvcmllcyB0aGF0IGZpbHRlciByZXBvcnRzXHJcbiAgY29uc3QgcmVuZGVyU2lkZWJhciA9ICgpID0+IHtcclxuICAgIC8vIEZpbHRlciBjYXRlZ29yaWVzIGJhc2VkIG9uIHNpZGViYXIgc2VhcmNoXHJcbiAgICBjb25zdCBmaWx0ZXJlZENhdGVnb3JpZXMgPSBzb3J0ZWRDYXRlZ29yaWVzXHJcbiAgICAgIC5maWx0ZXIoKGNhdGVnb3J5KSA9PiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5sZW5ndGgpXHJcbiAgICAgIC5maWx0ZXIoKGNhdGVnb3J5KSA9PiB7XHJcbiAgICAgICAgaWYgKCFzaWRlYmFyU2VhcmNoUXVlcnkpIHJldHVybiB0cnVlO1xyXG4gICAgICAgIC8vIENoZWNrIGlmIGNhdGVnb3J5IG5hbWUgbWF0Y2hlcyBzZWFyY2hcclxuICAgICAgICBpZiAoY2F0ZWdvcnkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzaWRlYmFyU2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkpXHJcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAvLyBDaGVjayBpZiBhbnkgaXRlbSBpbiBjYXRlZ29yeSBtYXRjaGVzIHNlYXJjaFxyXG4gICAgICAgIHJldHVybiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5zb21lKChpdGVtKSA9PlxyXG4gICAgICAgICAgaXRlbS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNpZGViYXJTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSxcclxuICAgICAgICApO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAvLyBGaWx0ZXIgaXRlbXMgd2l0aGluIGNhdGVnb3JpZXMgYmFzZWQgb24gc2VhcmNoXHJcbiAgICBjb25zdCBnZXRGaWx0ZXJlZEl0ZW1zID0gKGNhdGVnb3J5KSA9PiB7XHJcbiAgICAgIGlmICghc2lkZWJhclNlYXJjaFF1ZXJ5KSByZXR1cm4gZ3JvdXBlZE1lbnVzW2NhdGVnb3J5XSB8fCBbXTtcclxuICAgICAgcmV0dXJuIChncm91cGVkTWVudXNbY2F0ZWdvcnldIHx8IFtdKS5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgaXRlbS50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNpZGViYXJTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSxcclxuICAgICAgKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdlxyXG4gICAgICAgIHJlZj17cmVmfVxyXG4gICAgICAgIGNsYXNzTmFtZT17YG1pbi1oLXNjcmVlbiBtYXgtaC1hdXRvIHAtNCBwdC04ICR7b3BlbiA/IFwidy02NFwiIDogXCJ3LTIwXCJ9IGR1cmF0aW9uLTMwMCByZWxhdGl2ZSBiZy13aGl0ZSBzaGFkb3ctbGdgfVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNiBweC0yXCI+XHJcbiAgICAgICAgICB7b3BlbiAmJiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIENhdGVnb3JpZXNcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0T3Blbighb3Blbil9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtZnVsbCBiZy1ncmF5LTEwMCBob3ZlcjpiZy1ncmF5LTIwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtcclxuICAgICAgICAgICAgICAhb3BlbiA/IFwibXgtYXV0b1wiIDogXCJcIlxyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEZpQ2hldnJvbkxlZnRcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LWdyYXktNjAwIHRleHQteGwgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwICR7XHJcbiAgICAgICAgICAgICAgICAhb3BlbiA/IFwicm90YXRlLTE4MFwiIDogXCJcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBTaWRlYmFyIFNlYXJjaCBJbnB1dCAqL31cclxuICAgICAgICB7b3BlbiAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcHgtMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCByZXBvcnRzLi4uXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzaWRlYmFyU2VhcmNoUXVlcnl9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNpZGViYXJTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOSBwci04IHB5LTIgdGV4dC1zbSBiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAvMjAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxJb1NlYXJjaE91dGxpbmUgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0yLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtZ3JheS00MDAgdGV4dC1iYXNlXCIgLz5cclxuICAgICAgICAgICAgICB7c2lkZWJhclNlYXJjaFF1ZXJ5ICYmIChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2lkZWJhclNlYXJjaFF1ZXJ5KFwiXCIpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW9DbG9zZUNpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiBTaG93IHNlYXJjaCByZXN1bHRzIGNvdW50ICovfVxyXG4gICAgICAgICAgICB7c2lkZWJhclNlYXJjaFF1ZXJ5ICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgIEZvdW5ke1wiIFwifVxyXG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkQ2F0ZWdvcmllcy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgIChhY2MsIGNhdGVnb3J5KSA9PiBhY2MgKyBnZXRGaWx0ZXJlZEl0ZW1zKGNhdGVnb3J5KS5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICAgICAgICApfXtcIiBcIn1cclxuICAgICAgICAgICAgICAgIHJlc3VsdHNcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHtmaWx0ZXJlZENhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgaXRlbXMgPSBnZXRGaWx0ZXJlZEl0ZW1zKGNhdGVnb3J5KTtcclxuICAgICAgICAgIC8vIFNraXAgY2F0ZWdvcnkgaWYgbm8gaXRlbXMgbWF0Y2ggc2VhcmNoXHJcbiAgICAgICAgICBpZiAoaXRlbXMubGVuZ3RoID09PSAwICYmIHNpZGViYXJTZWFyY2hRdWVyeSkgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgICAgICAgY29uc3QgaXNFeHBhbmRlZCA9IGV4cGFuZGVkQ2F0ZWdvcmllc1tjYXRlZ29yeV0gfHwgZmFsc2U7XHJcbiAgICAgICAgICBjb25zdCBpdGVtQ291bnQgPSBpdGVtcy5sZW5ndGg7XHJcbiAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGFjdGl2ZUNhdGVnb3J5ID09PSBjYXRlZ29yeTtcclxuXHJcbiAgICAgICAgICAvLyBJZiBzZWFyY2hpbmcsIGF1dG8tZXhwYW5kIGNhdGVnb3JpZXMgdGhhdCBoYXZlIG1hdGNoZXNcclxuICAgICAgICAgIGNvbnN0IHNob3VsZEV4cGFuZCA9IHNpZGViYXJTZWFyY2hRdWVyeSA/IHRydWUgOiBpc0V4cGFuZGVkO1xyXG5cclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxkaXYga2V5PXtjYXRlZ29yeX0gY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKG9wZW4pIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBUb2dnbGUgZXhwYW5zaW9uXHJcbiAgICAgICAgICAgICAgICAgICAgdG9nZ2xlQ2F0ZWdvcnkoY2F0ZWdvcnkpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIFNldCBhY3RpdmUgY2F0ZWdvcnkgdG8gZmlsdGVyIHJlcG9ydHMgb24gdGhlIHJpZ2h0IHNpZGVcclxuICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVDYXRlZ29yeShjYXRlZ29yeSk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0yLjUgcm91bmRlZC14bCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgJiYgb3BlblxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgYm9yZGVyLWwtNCBib3JkZXItYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogb3BlblxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImhvdmVyOmJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImp1c3RpZnktY2VudGVyIGhvdmVyOmJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge29wZW4gPyAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9udC1zZW1pYm9sZCB0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlID8gXCJ0ZXh0LWJsdWUtNzAwXCIgOiBcInRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC14cyBweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JheS0xMDAgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbUNvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG91bGRFeHBhbmQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnNDaGV2cm9uRG93blxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtICR7aXNBY3RpdmUgPyBcInRleHQtYmx1ZS01MDBcIiA6IFwidGV4dC1ncmF5LTQwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnNDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1zbSAke2lzQWN0aXZlID8gXCJ0ZXh0LWJsdWUtNTAwXCIgOiBcInRleHQtZ3JheS00MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTIgaC0yIHJvdW5kZWQtZnVsbCAke2lzQWN0aXZlID8gXCJiZy1ibHVlLTUwMFwiIDogXCJiZy1ncmF5LTMwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtvcGVuICYmIHNob3VsZEV4cGFuZCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTMgYm9yZGVyLWwtMiBib3JkZXItZ3JheS0xMDAgcGwtMyBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoeyB0aXRsZSwgbGluaywgSWNvbiwgY29sb3IsIGlzTmV3IH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdG89e2xpbmt9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjcm9sbFRvVG9wKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEhpZGVTaWRlYmFyKCFoaWRlU2lkZWJhcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIENsZWFyIHNlYXJjaCB3aGVuIG5hdmlnYXRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2lkZWJhclNlYXJjaFF1ZXJ5KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmU6IGlzTGlua0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtMyBweS0yLjUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0xpbmtBY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6dGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgeyh7IGlzQWN0aXZlOiBpc0xpbmtBY3RpdmUgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsxOH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTGlua0FjdGl2ZSA/IFwidGV4dC1ibHVlLTYwMFwiIDogXCJ0ZXh0LWdyYXktNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleC0xIHRleHQtc20gZm9udC1tZWRpdW0gbGVhZGluZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBORVdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9KX1cclxuXHJcbiAgICAgICAgey8qIFNob3cgXCJObyByZXN1bHRzXCIgbWVzc2FnZSB3aGVuIHNlYXJjaCByZXR1cm5zIG5vIHJlc3VsdHMgKi99XHJcbiAgICAgICAge29wZW4gJiYgc2lkZWJhclNlYXJjaFF1ZXJ5ICYmIGZpbHRlcmVkQ2F0ZWdvcmllcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1ncmF5LTEwMCByb3VuZGVkLWZ1bGwgbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxJb1NlYXJjaE91dGxpbmUgY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyByZXBvcnRzIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIFRyeSBhZGp1c3RpbmcgeW91ciBzZWFyY2hcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIFJlbmRlciBjYXRlZ29yaWVzIGNoaXBzIHdpdGggY3VzdG9tIG9yZGVyXHJcbiAgY29uc3QgcmVuZGVyQ2F0ZWdvcnlDaGlwcyA9ICgpID0+IHtcclxuICAgIGNvbnN0IGNoaXBDYXRlZ29yaWVzID0gW1wiQWxsXCIsIC4uLnNvcnRlZENhdGVnb3JpZXNdO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTIgbWItNiBwYi0yIG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgIHtjaGlwQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBjb3VudCA9XHJcbiAgICAgICAgICAgIGNhdGVnb3J5ID09PSBcIkFsbFwiXHJcbiAgICAgICAgICAgICAgPyBtZW51cy5maWx0ZXIoKG0pID0+IG0udmlzaWJsZSkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgOiBncm91cGVkTWVudXNbY2F0ZWdvcnldPy5sZW5ndGggfHwgMDtcclxuXHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAga2V5PXtjYXRlZ29yeX1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVDYXRlZ29yeShjYXRlZ29yeSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4gICAgICAgICAgICAgICAgYWN0aXZlQ2F0ZWdvcnkgPT09IGNhdGVnb3J5XHJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tYmx1ZS03MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LWJsdWUtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGhvdmVyOmJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1sLTEuNSB0ZXh0LXhzICR7XHJcbiAgICAgICAgICAgICAgICAgIGFjdGl2ZUNhdGVnb3J5ID09PSBjYXRlZ29yeVxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LWJsdWUtMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAoe2NvdW50fSlcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9KX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIFJlbmRlciBncmlkIGNhcmRzXHJcbiAgLy8gY29uc3QgcmVuZGVyR3JpZENhcmRzID0gKCkgPT4gKFxyXG4gIC8vICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00IGdhcC01XCI+XHJcbiAgLy8gICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlzTmV3IH0pID0+IChcclxuICAvLyAgICAgICA8ZGl2XHJcbiAgLy8gICAgICAgICBrZXk9e2xpbmt9XHJcbiAgLy8gICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGxpbmspfVxyXG4gIC8vICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gIC8vICAgICAgID5cclxuICAvLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMjAwIGhvdmVyOi10cmFuc2xhdGUteS0xLjVcIj5cclxuICAvLyAgICAgICAgICAgPGRpdlxyXG4gIC8vICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IGgtMjggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuYH1cclxuICAvLyAgICAgICAgICAgPlxyXG4gIC8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay81XCI+PC9kaXY+XHJcbiAgLy8gICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC01eGwgdGV4dC13aGl0ZSBkcm9wLXNoYWRvdy1sZyByZWxhdGl2ZSB6LTEwXCIgLz5cclxuICAvLyAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4gIC8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBzaGFkb3ctbGcgei0xMFwiPlxyXG4gIC8vICAgICAgICAgICAgICAgICBORVdcclxuICAvLyAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAvLyAgICAgICAgICAgICApfVxyXG4gIC8vICAgICAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTVcIj5cclxuICAvLyAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzIGxpbmUtY2xhbXAtMlwiPlxyXG4gIC8vICAgICAgICAgICAgICAge3RpdGxlfVxyXG4gIC8vICAgICAgICAgICAgIDwvaDM+XHJcbiAgLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIHRleHQtYmx1ZS02MDAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxyXG4gIC8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlZpZXcgUmVwb3J0PC9zcGFuPlxyXG4gIC8vICAgICAgICAgICAgICAgPHN2Z1xyXG4gIC8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IG1sLTIgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiXHJcbiAgLy8gICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAvLyAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAvLyAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgLy8gICAgICAgICAgICAgICA+XHJcbiAgLy8gICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDVsNyA3LTcgN1wiIC8+XHJcbiAgLy8gICAgICAgICAgICAgICA8L3N2Zz5cclxuICAvLyAgICAgICAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgICAgICAgPC9kaXY+XHJcbiAgLy8gICAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgKSl9XHJcbiAgLy8gICA8L2Rpdj5cclxuICAvLyApO1xyXG4gIC8vIFJlbmRlciBncmlkIGNhcmRzIC0gU21hbGxlciB2ZXJzaW9uXHJcbiAgLy8gY29uc3QgcmVuZGVyR3JpZENhcmRzID0gKCkgPT4gKFxyXG4gIC8vICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy0zIG1kOmdyaWQtY29scy00IGxnOmdyaWQtY29scy01IHhsOmdyaWQtY29scy04IGdhcC0zXCI+XHJcbiAgLy8gICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlzTmV3IH0pID0+IChcclxuICAvLyAgICAgICA8ZGl2XHJcbiAgLy8gICAgICAgICBrZXk9e2xpbmt9XHJcbiAgLy8gICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGxpbmspfVxyXG4gIC8vICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gIC8vICAgICAgID5cclxuICAvLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBob3Zlcjpib3JkZXItYmx1ZS0yMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTFcIj5cclxuICAvLyAgICAgICAgICAgPGRpdlxyXG4gIC8vICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IGgtMTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuYH1cclxuICAvLyAgICAgICAgICAgPlxyXG4gIC8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay81XCI+PC9kaXY+XHJcbiAgLy8gICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC13aGl0ZSBkcm9wLXNoYWRvdy1sZyByZWxhdGl2ZSB6LTEwXCIgLz5cclxuICAvLyAgICAgICAgICAgICB7aXNOZXcgJiYgKFxyXG4gIC8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTEgcmlnaHQtMSBweC0xLjUgcHktMC41IHRleHQtWzhweF0gZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlIHNoYWRvdy1sZyB6LTEwXCI+XHJcbiAgLy8gICAgICAgICAgICAgICAgIE5FV1xyXG4gIC8vICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gIC8vICAgICAgICAgICAgICl9XHJcbiAgLy8gICAgICAgICAgIDwvZGl2PlxyXG4gIC8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gIC8vICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBsaW5lLWNsYW1wLTIgdGV4dC1jZW50ZXIgbGVhZGluZy10aWdodFwiPlxyXG4gIC8vICAgICAgICAgICAgICAge3RpdGxlfVxyXG4gIC8vICAgICAgICAgICAgIDwvaDM+XHJcbiAgLy8gICAgICAgICAgIDwvZGl2PlxyXG4gIC8vICAgICAgICAgPC9kaXY+XHJcbiAgLy8gICAgICAgPC9kaXY+XHJcbiAgLy8gICAgICkpfVxyXG4gIC8vICAgPC9kaXY+XHJcbiAgLy8gKTtcclxuXHJcbiAgY29uc3QgcmVuZGVyR3JpZENhcmRzID0gKCkgPT4ge1xyXG4gIC8vIFdoZW4gQWxsIGlzIHNlbGVjdGVkLCBzZXBhcmF0ZSByZXBvcnRzIGJ5IGNhdGVnb3J5XHJcbiAgaWYgKGFjdGl2ZUNhdGVnb3J5ID09PSBcIkFsbFwiKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxyXG4gICAgICAgIHtzb3J0ZWRBbGxGaWx0ZXJlZENhdGVnb3JpZXMubWFwKChjYXRlZ29yeSwgY2F0ZWdvcnlJbmRleCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY2F0ZWdvcnlNZW51cyA9IGFsbEZpbHRlcmVkR3JvdXBlZE1lbnVzW2NhdGVnb3J5XTtcclxuXHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnl9PlxyXG4gICAgICAgICAgICAgIHsvKiBDYXRlZ29yeSBIZWFkaW5nICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTggaC04IHJvdW5kZWQtbGcgYmctYmx1ZS01MCB0ZXh0LWJsdWUtNjAwIGZvbnQtYm9sZCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeUluZGV4ICsgMX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnlNZW51cy5sZW5ndGh9IHJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeU1lbnVzLmxlbmd0aCAhPT0gMSA/IFwic1wiIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBSZXBvcnRzIHVuZGVyIGNhdGVnb3J5ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBtZDpncmlkLWNvbHMtNCBsZzpncmlkLWNvbHMtNSB4bDpncmlkLWNvbHMtOCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAge2NhdGVnb3J5TWVudXMubWFwKFxyXG4gICAgICAgICAgICAgICAgICAoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlzTmV3IH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2xpbmt9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOYXZpZ2F0aW9uKGxpbmspfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBob3Zlcjpib3JkZXItYmx1ZS0yMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IGgtMTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay81XCI+PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInRleHQtMnhsIHRleHQtd2hpdGUgZHJvcC1zaGFkb3ctbGcgcmVsYXRpdmUgei0xMFwiIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc05ldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMSByaWdodC0xIHB4LTEuNSBweS0wLjUgdGV4dC1bOHB4XSBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcHVsc2Ugc2hhZG93LWxnIHotMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTkVXXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBsaW5lLWNsYW1wLTIgdGV4dC1jZW50ZXIgbGVhZGluZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIC8vIFdoZW4gYSBzcGVjaWZpYyBjYXRlZ29yeSBpcyBzZWxlY3RlZFxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTMgbWQ6Z3JpZC1jb2xzLTQgbGc6Z3JpZC1jb2xzLTUgeGw6Z3JpZC1jb2xzLTggZ2FwLTNcIj5cclxuICAgICAge2ZpbHRlcmVkTWVudXMubWFwKCh7IHRpdGxlLCBJY29uLCBsaW5rLCBjb2xvciwgaXNOZXcgfSkgPT4gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGtleT17bGlua31cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGhvdmVyOmJvcmRlci1ibHVlLTIwMCBob3ZlcjotdHJhbnNsYXRlLXktMVwiPlxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JhZGllbnQtdG8tYnIgJHtjb2xvcn0gaC0xNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzVcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC13aGl0ZSBkcm9wLXNoYWRvdy1sZyByZWxhdGl2ZSB6LTEwXCIgLz5cclxuXHJcbiAgICAgICAgICAgICAge2lzTmV3ICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0xIHJpZ2h0LTEgcHgtMS41IHB5LTAuNSB0ZXh0LVs4cHhdIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBzaGFkb3ctbGcgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICBORVdcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzIGxpbmUtY2xhbXAtMiB0ZXh0LWNlbnRlciBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuICAvLyBSZW5kZXIgbGlzdCBpdGVtc1xyXG4gIC8vIGNvbnN0IHJlbmRlckxpc3RJdGVtcyA9ICgpID0+IChcclxuICAvLyAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgLy8gICAgIHtmaWx0ZXJlZE1lbnVzLm1hcCgoeyB0aXRsZSwgSWNvbiwgbGluaywgY29sb3IsIGlkLCBpc05ldyB9KSA9PiAoXHJcbiAgLy8gICAgICAgPGRpdlxyXG4gIC8vICAgICAgICAga2V5PXtpZH1cclxuICAvLyAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdmlnYXRpb24obGluayl9XHJcbiAgLy8gICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgLy8gICAgICAgPlxyXG4gIC8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWJsdWUtMjAwIGhvdmVyOi10cmFuc2xhdGUteC0xXCI+XHJcbiAgLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgcC00IGhvdmVyOmJnLWdyYXktNTAvNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAvLyAgICAgICAgICAgICA8ZGl2XHJcbiAgLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmFkaWVudC10by1iciAke2NvbG9yfSByb3VuZGVkLXhsIHAtMyBtci00IGZsZXgtc2hyaW5rLTBgfVxyXG4gIC8vICAgICAgICAgICAgID5cclxuICAvLyAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInRleHQteGwgdGV4dC13aGl0ZVwiIC8+XHJcbiAgLy8gICAgICAgICAgICAgPC9kaXY+XHJcbiAgLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgbWluLXctMFwiPlxyXG4gIC8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cclxuICAvLyAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyB0cnVuY2F0ZVwiPlxyXG4gIC8vICAgICAgICAgICAgICAgICAgIHt0aXRsZX1cclxuICAvLyAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAvLyAgICAgICAgICAgICAgICAge2lzTmV3ICYmIChcclxuICAvLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi00MDAgdG8tZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXB1bHNlIGZsZXgtc2hyaW5rLTBcIj5cclxuICAvLyAgICAgICAgICAgICAgICAgICAgIE5FV1xyXG4gIC8vICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAvLyAgICAgICAgICAgICAgICAgKX1cclxuICAvLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gIC8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTAuNVwiPlxyXG4gIC8vICAgICAgICAgICAgICAgICBDbGljayB0byB2aWV3IGRldGFpbGVkIHJlcG9ydFxyXG4gIC8vICAgICAgICAgICAgICAgPC9wPlxyXG4gIC8vICAgICAgICAgICAgIDwvZGl2PlxyXG4gIC8vICAgICAgICAgICAgIDxzdmdcclxuICAvLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTMwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNTAwIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGwgZmxleC1zaHJpbmstMCBtbC0yXCJcclxuICAvLyAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAvLyAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgLy8gICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAvLyAgICAgICAgICAgICA+XHJcbiAgLy8gICAgICAgICAgICAgICA8cGF0aFxyXG4gIC8vICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gIC8vICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAvLyAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgLy8gICAgICAgICAgICAgICAgIGQ9XCJNOSA1bDcgNy03IDdcIlxyXG4gIC8vICAgICAgICAgICAgICAgLz5cclxuICAvLyAgICAgICAgICAgICA8L3N2Zz5cclxuICAvLyAgICAgICAgICAgPC9kaXY+XHJcbiAgLy8gICAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgICA8L2Rpdj5cclxuICAvLyAgICAgKSl9XHJcbiAgLy8gICA8L2Rpdj5cclxuICAvLyApO1xyXG5cclxuICBjb25zdCByZW5kZXJMaXN0SXRlbXMgPSAoKSA9PiB7XHJcbiAgaWYgKGFjdGl2ZUNhdGVnb3J5ID09PSBcIkFsbFwiKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktOFwiPlxyXG4gICAgICAgIHtzb3J0ZWRBbGxGaWx0ZXJlZENhdGVnb3JpZXMubWFwKChjYXRlZ29yeSwgY2F0ZWdvcnlJbmRleCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY2F0ZWdvcnlNZW51cyA9IGFsbEZpbHRlcmVkR3JvdXBlZE1lbnVzW2NhdGVnb3J5XTtcclxuXHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnl9PlxyXG4gICAgICAgICAgICAgIHsvKiBDYXRlZ29yeSBIZWFkaW5nICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTggaC04IHJvdW5kZWQtbGcgYmctYmx1ZS01MCB0ZXh0LWJsdWUtNjAwIGZvbnQtYm9sZCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeUluZGV4ICsgMX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnlNZW51cy5sZW5ndGh9IHJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeU1lbnVzLmxlbmd0aCAhPT0gMSA/IFwic1wiIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICB7Y2F0ZWdvcnlNZW51cy5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICh7IHRpdGxlLCBJY29uLCBsaW5rLCBjb2xvciwgaXNOZXcsIGlkIH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTmF2aWdhdGlvbihsaW5rKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBob3Zlcjpib3JkZXItYmx1ZS0yMDAgaG92ZXI6LXRyYW5zbGF0ZS14LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBwLTQgaG92ZXI6YmctZ3JheS01MC81MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IHJvdW5kZWQteGwgcC0zIG1yLTQgZmxleC1zaHJpbmstMGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC14bCB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc05ldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBORVdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWNrIHRvIHZpZXcgZGV0YWlsZWQgcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTMwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNTAwIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGwgZmxleC1zaHJpbmstMCBtbC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSA1bDcgNy03IDdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9KX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gU3BlY2lmaWMgY2F0ZWdvcnlcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAge2ZpbHRlcmVkTWVudXMubWFwKCh7IHRpdGxlLCBJY29uLCBsaW5rLCBjb2xvciwgaWQsIGlzTmV3IH0pID0+IChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBrZXk9e2lkfVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTmF2aWdhdGlvbihsaW5rKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBob3Zlcjpib3JkZXItYmx1ZS0yMDAgaG92ZXI6LXRyYW5zbGF0ZS14LTFcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBwLTQgaG92ZXI6YmctZ3JheS01MC81MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Y29sb3J9IHJvdW5kZWQteGwgcC0zIG1yLTQgZmxleC1zaHJpbmstMGB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidGV4dC14bCB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0aXRsZX1cclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtpc05ldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBORVdcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgIENsaWNrIHRvIHZpZXcgZGV0YWlsZWQgcmVwb3J0XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTMwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNTAwIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGwgZmxleC1zaHJpbmstMCBtbC0yXCJcclxuICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgIGQ9XCJNOSA1bDcgNy03IDdcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuICAvLyBSZW5kZXIgZHJhZ2dhYmxlIGl0ZW1zIHdpdGggY2F0ZWdvcnkgZHJvcGRvd24gZm9yIG1hbmFnZSBtb2RhbFxyXG4gIGNvbnN0IHJlbmRlckRyYWdnYWJsZUl0ZW1zID0gKCkgPT4ge1xyXG4gICAgLy8gRmlsdGVyIG1lbnVzIGJhc2VkIG9uIG1vZGFsIHNlYXJjaCBxdWVyeVxyXG4gICAgY29uc3QgZmlsdGVyZWRNZW51c0Zvck1vZGFsID0gbW9kYWxTZWFyY2hRdWVyeVxyXG4gICAgICA/IG1lbnVzLmZpbHRlcihcclxuICAgICAgICAgIChtZW51KSA9PlxyXG4gICAgICAgICAgICBtZW51LnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMobW9kYWxTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICAgICAgICAobWVudS5jYXRlZ29yeSAmJlxyXG4gICAgICAgICAgICAgIG1lbnUuY2F0ZWdvcnlcclxuICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAuaW5jbHVkZXMobW9kYWxTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSksXHJcbiAgICAgICAgKVxyXG4gICAgICA6IG1lbnVzO1xyXG5cclxuICAgIGNvbnN0IGdyb3VwZWRCeUNhdGVnb3J5ID0ge307XHJcbiAgICBmaWx0ZXJlZE1lbnVzRm9yTW9kYWwuZm9yRWFjaCgobWVudSkgPT4ge1xyXG4gICAgICBjb25zdCBjYXRlZ29yeSA9IG1lbnUuY2F0ZWdvcnkgfHwgXCJVbmNhdGVnb3JpemVkXCI7XHJcbiAgICAgIGlmICghZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldKSB7XHJcbiAgICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldID0gW107XHJcbiAgICAgIH1cclxuICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldLnB1c2gobWVudSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBPYmplY3Qua2V5cyhncm91cGVkQnlDYXRlZ29yeSkuZm9yRWFjaCgoY2F0ZWdvcnkpID0+IHtcclxuICAgICAgZ3JvdXBlZEJ5Q2F0ZWdvcnlbY2F0ZWdvcnldLnNvcnQoXHJcbiAgICAgICAgKGEsIGIpID0+IChhLm9yZGVyIHx8IDApIC0gKGIub3JkZXIgfHwgMCksXHJcbiAgICAgICk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBzb3J0ZWRDYXRLZXlzID0gT2JqZWN0LmtleXMoZ3JvdXBlZEJ5Q2F0ZWdvcnkpLnNvcnQoKGEsIGIpID0+IHtcclxuICAgICAgY29uc3QgaW5kZXhBID0gY2F0ZWdvcnlPcmRlci5pbmRleE9mKGEpO1xyXG4gICAgICBjb25zdCBpbmRleEIgPSBjYXRlZ29yeU9yZGVyLmluZGV4T2YoYik7XHJcbiAgICAgIGlmIChpbmRleEEgIT09IC0xICYmIGluZGV4QiAhPT0gLTEpIHJldHVybiBpbmRleEEgLSBpbmRleEI7XHJcbiAgICAgIGlmIChpbmRleEEgIT09IC0xKSByZXR1cm4gLTE7XHJcbiAgICAgIGlmIChpbmRleEIgIT09IC0xKSByZXR1cm4gMTtcclxuICAgICAgcmV0dXJuIGEubG9jYWxlQ29tcGFyZShiKTtcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGFsbENhdGVnb3JpZXMgPSBnZXRBbGxDYXRlZ29yaWVzKCk7XHJcblxyXG4gICAgLy8gSWYgc2VhcmNoaW5nIGFuZCBubyByZXN1bHRzXHJcbiAgICBpZiAobW9kYWxTZWFyY2hRdWVyeSAmJiBzb3J0ZWRDYXRLZXlzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTYgaC0xNiBiZy1ncmF5LTEwMCByb3VuZGVkLWZ1bGwgbWItM1wiPlxyXG4gICAgICAgICAgICA8SW9TZWFyY2hPdXRsaW5lIGNsYXNzTmFtZT1cInRleHQtM3hsIHRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICBObyByZXBvcnRzIGZvdW5kXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICBUcnkgYWRqdXN0aW5nIHlvdXIgc2VhcmNoXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHNvcnRlZENhdEtleXMubWFwKChjYXRlZ29yeSkgPT4ge1xyXG4gICAgICBjb25zdCBpdGVtcyA9IGdyb3VwZWRCeUNhdGVnb3J5W2NhdGVnb3J5XTtcclxuICAgICAgLy8gU2tpcCBjYXRlZ29yeSBpZiBubyBpdGVtcyBhZnRlciBzZWFyY2ggZmlsdGVyXHJcbiAgICAgIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xyXG5cclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGtleT17Y2F0ZWdvcnl9IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cclxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIHtjYXRlZ29yeX1cclxuICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+e2l0ZW1zLmxlbmd0aH0gaXRlbXM8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgIHtpdGVtcy5tYXAoKG1lbnUsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgaXNEcmFnZ2luZyA9IGRyYWdnZWRJdGVtPy5pdGVtPy5pZCA9PT0gbWVudS5pZDtcclxuICAgICAgICAgICAgICBjb25zdCBpc0RyYWdPdmVyID0gZHJhZ092ZXJJdGVtPy5pdGVtPy5pZCA9PT0gbWVudS5pZDtcclxuXHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAga2V5PXttZW51LmlkfVxyXG4gICAgICAgICAgICAgICAgICBkcmFnZ2FibGVcclxuICAgICAgICAgICAgICAgICAgb25EcmFnU3RhcnQ9eyhlKSA9PiBoYW5kbGVEcmFnU3RhcnQoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4gICAgICAgICAgICAgICAgICBvbkRyYWdPdmVyPXsoZSkgPT4gaGFuZGxlRHJhZ092ZXIoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4gICAgICAgICAgICAgICAgICBvbkRyYWdFbmQ9e2hhbmRsZURyYWdFbmR9XHJcbiAgICAgICAgICAgICAgICAgIG9uRHJvcD17KGUpID0+IGhhbmRsZURyb3AoZSwgbWVudSwgY2F0ZWdvcnkpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICAgICAgICBpc0RyYWdnaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmx1ZS01MCBib3JkZXItMiBib3JkZXItYmx1ZS00MDAgc2hhZG93LWxnIG9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBpc0RyYWdPdmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLWJsdWUtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgYm9yZGVyLTIgYm9yZGVyLXRyYW5zcGFyZW50XCJcclxuICAgICAgICAgICAgICAgICAgfSBjdXJzb3ItbW92ZWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgY3Vyc29yLWdyYWIgZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjAgMjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTcgMmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTAgNmEyIDIgMCAxIDAgMCA0IDIgMiAwIDAgMCAwLTR6bTYtMTJhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00em0wIDZhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00em0wIDZhMiAyIDAgMSAwIDAgNCAyIDIgMCAwIDAgMC00elwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bWVudS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE9yZGVyOiB7bWVudS5vcmRlciB8fCBpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS0zMDBcIj58PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21lbnUuY2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2F0ZWdvcnlDaGFuZ2UobWVudS5pZCwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgYm9yZGVyIHJvdW5kZWQgcHgtMiBweS0xIGJnLXdoaXRlIGhvdmVyOmJvcmRlci1ibHVlLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS00MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthbGxDYXRlZ29yaWVzLm1hcCgoY2F0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Y2F0fSB2YWx1ZT17Y2F0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtbC00IGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHttZW51LnZpc2libGUgPyBcIlZpc2libGVcIiA6IFwiSGlkZGVuXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTd2l0Y2hcclxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e21lbnUudmlzaWJsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoY2hlY2tlZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRNZW51cygocHJldikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2Lm1hcCgoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uaWQgPT09IG1lbnUuaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB7IC4uLml0ZW0sIHZpc2libGU6IGNoZWNrZWQgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApO1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBmbGV4IG10LTE2IGJnLWdyYXktNTAvODBcIj5cclxuICAgIDxOYXZiYXIgLz5cclxuICAgIDxTaWRlYmFyIGhpZGVTaWRlYmFyPXtoaWRlU2lkZWJhcn0gLz5cclxuXHJcbiAgICB7LyogU2lkZWJhciAqL31cclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPXtgJHtvcGVuID8gXCJ3LTY0XCIgOiBcInctMjBcIn0gYmctd2hpdGUgbWluLWgtc2NyZWVuIGJvcmRlci1yIGJvcmRlci1ncmF5LTIwMC84MCBvdmVyZmxvdy15LWF1dG8gZmxleC1zaHJpbmstMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfVxyXG4gICAgPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0aWNreSB0b3AtMCBiZy13aGl0ZS85NSBiYWNrZHJvcC1ibHVyLXNtIHotMTAgcHgtNCBweS0zIG10LTEwIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMC84MFwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0QWN0aXZlQ2F0ZWdvcnkoXCJBbGxcIik7XHJcbiAgICAgICAgICAgIG5hdmlnYXRlKFwiL3JlcG9ydHNcIik7XHJcbiAgICAgICAgICAgIHNjcm9sbFRvVG9wKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdy1mdWxsICR7XHJcbiAgICAgICAgICAgIG9wZW5cclxuICAgICAgICAgICAgICA/IFwicHgtNCBweS0yLjUgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tYmx1ZS03MDAgdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIGhvdmVyOnNjYWxlLVsxLjAyXVwiXHJcbiAgICAgICAgICAgICAgOiBcInAtMi41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgaG92ZXI6c2NhbGUtMTEwXCJcclxuICAgICAgICAgIH1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxGYUNoYXJ0QmFyXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17b3BlbiA/IFwidGV4dC1ibHVlLTEwMCB0ZXh0LWxnXCIgOiBcInRleHQtbGdcIn1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7b3BlbiAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0cmFja2luZy13aWRlIHRleHQtc21cIj5SZXBvcnRzPC9zcGFuPn1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtyZW5kZXJTaWRlYmFyKCl9XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICB7LyogTWFpbiBDb250ZW50ICovfVxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IG92ZXJmbG93LWhpZGRlbiBtYXgtaC1zY3JlZW4gb3ZlcmZsb3cteS1hdXRvIGJnLWdyYXktNTAvODBcIj5cclxuICAgICAge2xvY2F0aW9uLnBhdGhuYW1lID09PSBcIi9yZXBvcnRzXCIgPyAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIHsvKiBTZWFyY2ggQmFyIC0gQ2VudGVyZWQgd2l0aCBwcm9wZXIgd2lkdGggKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTUgbXQtMTAgZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1heC13LXhsIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC00IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgIDxJb1NlYXJjaE91dGxpbmUgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHJlcG9ydHMuLi5cIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTEgcHItMTIgcHktMyB0ZXh0LXNtIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAvMjAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3cgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge3NlYXJjaFF1ZXJ5ICYmIChcclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJTZWFyY2h9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCByaWdodC0wIHByLTQgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNjAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJb0Nsb3NlQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ29udHJvbHMgLSBDYXRlZ29yeSBjaGlwcyBhbmQgdmlldyBidXR0b25zICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIG1iLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgIHtyZW5kZXJDYXRlZ29yeUNoaXBzKCl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdUeXBlKFwiZ3JpZFwiKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XHJcbiAgICAgICAgICAgICAgICAgIHZpZXdUeXBlID09PSBcImdyaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJHcmlkIFZpZXdcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxCaUdyaWQgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld1R5cGUoXCJsaXN0XCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcclxuICAgICAgICAgICAgICAgICAgdmlld1R5cGUgPT09IFwibGlzdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkxpc3QgVmlld1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFRiTGlzdCBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiByb3VuZGVkLWxnIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCBtbC0xXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1hbmFnZU1vZGFsKHRydWUpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgPEZpU2V0dGluZ3Mgc2l6ZT17MTV9IC8+XHJcbiAgICAgICAgICAgICAgICAgIE1hbmFnZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBSZXN1bHRzIFN0YXRzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIHRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICBTaG93aW5nIHtmaWx0ZXJlZE1lbnVzLmxlbmd0aH0gcmVwb3J0XHJcbiAgICAgICAgICAgIHtmaWx0ZXJlZE1lbnVzLmxlbmd0aCAhPT0gMSA/IFwic1wiIDogXCJcIn1cclxuICAgICAgICAgICAge3NlYXJjaFF1ZXJ5ICYmIGAgZm9yIFwiJHtzZWFyY2hRdWVyeX1cImB9XHJcbiAgICAgICAgICAgIHthY3RpdmVDYXRlZ29yeSAhPT0gXCJBbGxcIiAmJiBgIGluICR7YWN0aXZlQ2F0ZWdvcnl9YH1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBMb2FkaW5nIFN0YXRlICovfVxyXG4gICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0xNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEwIHctMTAgYm9yZGVyLTMgYm9yZGVyLWJsdWUtNjAwIGJvcmRlci10LXRyYW5zcGFyZW50XCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IGZpbHRlcmVkTWVudXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTE2XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xNiBoLTE2IGJnLWdyYXktMTAwIHJvdW5kZWQtZnVsbCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICA8SW9TZWFyY2hPdXRsaW5lIGNsYXNzTmFtZT1cInRleHQtM3hsIHRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBObyByZXBvcnRzIGZvdW5kXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgIHthY3RpdmVDYXRlZ29yeSAhPT0gXCJBbGxcIlxyXG4gICAgICAgICAgICAgICAgICA/IGBObyByZXBvcnRzIGZvdW5kIGluIFwiJHthY3RpdmVDYXRlZ29yeX1cIiBjYXRlZ29yeWBcclxuICAgICAgICAgICAgICAgICAgOiBcIlRyeSBhZGp1c3RpbmcgeW91ciBzZWFyY2ggb3IgZmlsdGVyIGNyaXRlcmlhXCJ9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiB2aWV3VHlwZSA9PT0gXCJncmlkXCIgPyAoXHJcbiAgICAgICAgICAgIHJlbmRlckdyaWRDYXJkcygpXHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICByZW5kZXJMaXN0SXRlbXMoKVxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8Lz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8T3V0bGV0IC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICB7LyogTWFuYWdlIE1vZGFsICovfVxyXG4gICAgPE1vZGFsXHJcbiAgICAgIHRpdGxlPXtcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgPEZpU2V0dGluZ3MgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPk1hbmFnZSBSZXBvcnRzPC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LWdyYXktNDAwIG1sLTFcIj5cclxuICAgICAgICAgICAgLSBPcmRlciwgQ2F0ZWdvcnkgJiBWaXNpYmlsaXR5XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIH1cclxuICAgICAgb3Blbj17bWFuYWdlTW9kYWx9XHJcbiAgICAgIG9uQ2FuY2VsPXsoKSA9PiB7XHJcbiAgICAgICAgc2V0TWFuYWdlTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldE1vZGFsU2VhcmNoUXVlcnkoXCJcIik7XHJcbiAgICAgIH19XHJcbiAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgd2lkdGg9ezg4MH1cclxuICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bFwiXHJcbiAgICA+XHJcbiAgICAgIHsvKiBNb2RhbCBTZWFyY2ggSW5wdXQgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCBwbC0zLjUgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxyXG4gICAgICAgICAgICA8SW9TZWFyY2hPdXRsaW5lIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1iYXNlXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggcmVwb3J0cyBieSB0aXRsZSBvciBjYXRlZ29yeS4uLlwiXHJcbiAgICAgICAgICAgIHZhbHVlPXttb2RhbFNlYXJjaFF1ZXJ5fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1vZGFsU2VhcmNoUXVlcnkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTAgcHItMTAgcHktMi41IHRleHQtc20gYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwLzIwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAge21vZGFsU2VhcmNoUXVlcnkgJiYgKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJNb2RhbFNlYXJjaH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBwci0zLjUgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNjAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW9DbG9zZUNpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHttb2RhbFNlYXJjaFF1ZXJ5ICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMS41IHRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICBGb3VuZHtcIiBcIn1cclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIG1lbnVzLmZpbHRlcihcclxuICAgICAgICAgICAgICAgIChtZW51KSA9PlxyXG4gICAgICAgICAgICAgICAgICBtZW51LnRpdGxlXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMobW9kYWxTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICAgICAgICAgICAgICAobWVudS5jYXRlZ29yeSAmJlxyXG4gICAgICAgICAgICAgICAgICAgIG1lbnUuY2F0ZWdvcnlcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMobW9kYWxTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSksXHJcbiAgICAgICAgICAgICAgKS5sZW5ndGhcclxuICAgICAgICAgICAgfXtcIiBcIn1cclxuICAgICAgICAgICAgcmVzdWx0XHJcbiAgICAgICAgICAgIHttZW51cy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgKG1lbnUpID0+XHJcbiAgICAgICAgICAgICAgICBtZW51LnRpdGxlXHJcbiAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhtb2RhbFNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgICAgICAgICAobWVudS5jYXRlZ29yeSAmJlxyXG4gICAgICAgICAgICAgICAgICBtZW51LmNhdGVnb3J5XHJcbiAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMobW9kYWxTZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSksXHJcbiAgICAgICAgICAgICkubGVuZ3RoICE9PSAxXHJcbiAgICAgICAgICAgICAgPyBcInNcIlxyXG4gICAgICAgICAgICAgIDogXCJcIn17XCIgXCJ9XHJcbiAgICAgICAgICAgIG1hdGNoaW5nIFwie21vZGFsU2VhcmNoUXVlcnl9XCJcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEluZm8gQm94ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC0zIGJnLWJsdWUtNTAvODAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMTAwLzYwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYmx1ZS03MDAgc3BhY2UteS0wLjVcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCBmbGV4LXNocmluay0wXCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjAgMjBcIj5cclxuICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICAgIGQ9XCJNMTggMTBhOCA4IDAgMTEtMTYgMCA4IDggMCAwMTE2IDB6bS03LTRhMSAxIDAgMTEtMiAwIDEgMSAwIDAxMiAwek05IDlhMSAxIDAgMDAwIDJ2M2ExIDEgMCAwMDEgMWgxYTEgMSAwIDEwMC0ydi0zYTEgMSAwIDAwLTEtMUg5elwiXHJcbiAgICAgICAgICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICA8c3Ryb25nPkRyYWc8L3N0cm9uZz4gdG8gcmVvcmRlciByZXBvcnRzIHdpdGhpbiBhIGNhdGVnb3J5XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1sLTZcIj5cclxuICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgVXNlIHRoZSA8c3Ryb25nPmRyb3Bkb3duPC9zdHJvbmc+IHRvIG1vdmUgYSByZXBvcnQgdG8gYSBkaWZmZXJlbnQgY2F0ZWdvcnlcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IG1heC1oLVs1MHZoXSBvdmVyZmxvdy15LWF1dG8gcHItMVwiPlxyXG4gICAgICAgIHtyZW5kZXJEcmFnZ2FibGVJdGVtcygpfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMi41IG10LTUgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldE1hbmFnZU1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0TW9kYWxTZWFyY2hRdWVyeShcIlwiKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIHRleHQtc20gYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbWVkaXVtIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgb25DbGljaz17c2F2ZVJlcG9ydHN9XHJcbiAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzYXZpbmcgPyAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTMuNSB3LTMuNSBib3JkZXItMiBib3JkZXItd2hpdGUgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgU2F2aW5nLi4uXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIFwiU2F2ZSBDaGFuZ2VzXCJcclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9Nb2RhbD5cclxuICA8L2Rpdj5cclxuKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlcG9ydHM7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9SZXBvcnRzLmpzeCJ9