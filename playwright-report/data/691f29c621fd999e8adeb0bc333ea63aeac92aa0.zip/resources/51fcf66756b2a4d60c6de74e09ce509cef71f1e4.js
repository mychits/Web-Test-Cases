import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PenaltyMonitor.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import {
  Select,
  Modal,
  Table,
  message,
  Card,
  Statistic,
  Row,
  Col,
  Button,
  DatePicker,
  Input,
  Tag,
  Checkbox,
  Dropdown,
  Menu,
  Space,
  Drawer,
  Divider,
  Typography,
  Alert,
  Progress,
  Tooltip
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import {
  SearchOutlined,
  EyeOutlined,
  FilterOutlined,
  UsergroupAddOutlined,
  PhoneOutlined,
  CloseCircleOutlined,
  CheckCircleOutlined,
  MessageOutlined,
  WarningOutlined,
  ClockCircleOutlined,
  DollarCircleOutlined,
  SendOutlined,
  DownOutlined,
  ArrowLeftOutlined,
  UndoOutlined,
  InfoCircleOutlined,
  CalculatorOutlined,
  WalletOutlined,
  ExclamationCircleOutlined,
  DownloadOutlined,
  PlusOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { AiFillBackward } from "/node_modules/.vite/deps/react-icons_ai.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
const { RangePicker } = DatePicker;
const { Option } = Select;
const { Title, Text } = Typography;
const PenaltyMonitor = () => {
  _s();
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState("");
  const [screenLoading, setScreenLoading] = useState(false);
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [monthlyCollectedSummary, setMonthlyCollectedSummary] = useState(null);
  const [monthlyCollectedDetails, setMonthlyCollectedDetails] = useState([]);
  const [monthlyCollectedLoading, setMonthlyCollectedLoading] = useState(false);
  const [monthlyDetailsModalVisible, setMonthlyDetailsModalVisible] = useState(false);
  const [breakdownModal, setBreakdownModal] = useState(false);
  const [breakdownData, setBreakdownData] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [loadingBreakdown, setLoadingBreakdown] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [sendModal, setSendModal] = useState({ open: false, type: null });
  const [reversalGroupFilter, setReversalGroupFilter] = useState("");
  const [reversalCustomerFilter, setReversalCustomerFilter] = useState("");
  const [reversalTicketFilter, setReversalTicketFilter] = useState("");
  const [reversalDrawerOpen, setReversalDrawerOpen] = useState(false);
  const [penaltySummaryDrawer, setPenaltySummaryDrawer] = useState(false);
  const [penaltySummary, setPenaltySummary] = useState(null);
  const [selectedReversalType, setSelectedReversalType] = useState(null);
  const [reverseAmountDrawer, setReverseAmountDrawer] = useState(false);
  const [reverseAmount, setReverseAmount] = useState("");
  const [maxAllowedAmount, setMaxAllowedAmount] = useState(0);
  const [addPenaltyDrawerOpen, setAddPenaltyDrawerOpen] = useState(false);
  const [addPenaltyGroupFilter, setAddPenaltyGroupFilter] = useState("");
  const [addPenaltyCustomerFilter, setAddPenaltyCustomerFilter] = useState("");
  const [addPenaltyTicketFilter, setAddPenaltyTicketFilter] = useState("");
  const [addPenaltyDetails, setAddPenaltyDetails] = useState(null);
  const [addPenaltyAmount, setAddPenaltyAmount] = useState("");
  const [addLateFeeAmount, setAddLateFeeAmount] = useState("");
  const [addPenaltyLoading, setAddPenaltyLoading] = useState(false);
  const groupOptions = [...new Set(usersData.map((u) => u.groupName))];
  const customerOptions = useMemo(() => {
    if (!reversalGroupFilter) return [];
    const customers = /* @__PURE__ */ new Map();
    usersData.filter((u) => u.groupName === reversalGroupFilter).forEach((u) => customers.set(u.userName, u));
    return Array.from(customers.values());
  }, [usersData, reversalGroupFilter]);
  const ticketOptions = useMemo(() => {
    if (!reversalCustomerFilter) return [];
    const user = usersData.find(
      (u) => u.groupName === reversalGroupFilter && u.userName === reversalCustomerFilter
    );
    return user ? [user.paymentsTicket] : [];
  }, [usersData, reversalGroupFilter, reversalCustomerFilter]);
  const addPenaltyCustomerOptions = useMemo(() => {
    if (!addPenaltyGroupFilter) return [];
    const customers = /* @__PURE__ */ new Map();
    usersData.filter((u) => u.groupName === addPenaltyGroupFilter).forEach((u) => customers.set(u.userName, u));
    return Array.from(customers.values());
  }, [usersData, addPenaltyGroupFilter]);
  const addPenaltyTicketOptions = useMemo(() => {
    if (!addPenaltyCustomerFilter) return [];
    const user = usersData.find(
      (u) => u.groupName === addPenaltyGroupFilter && u.userName === addPenaltyCustomerFilter
    );
    return user ? [user.paymentsTicket] : [];
  }, [usersData, addPenaltyGroupFilter, addPenaltyCustomerFilter]);
  const filteredUsers = useMemo(() => {
    return filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
  }, [usersData, groupFilter, fromDate, toDate, searchText]);
  const fetchData = async () => {
    try {
      setScreenLoading(true);
      const penaltyResponse = await api.get("/penalty/get-penalty-report");
      if (!penaltyResponse.data?.success || !penaltyResponse.data?.data) {
        message.error("Failed to load penalty monitor data");
        return;
      }
      const allPenaltyData = penaltyResponse.data.data;
      const reportResponse = await api.get("/user/all-customers-report");
      const userDetailsMap = /* @__PURE__ */ new Map();
      if (reportResponse.data) {
        for (const usrData of reportResponse.data) {
          if (usrData?.data) {
            for (const data of usrData.data) {
              if (data?.enrollment?.group) {
                const groupId = String(data.enrollment.group._id);
                const userId = String(usrData._id);
                const ticket = String(data.payments.ticket || "").trim();
                userDetailsMap.set(`${userId}_${groupId}_${ticket}`, {
                  userName: usrData.userName,
                  userPhone: usrData.phone_number,
                  customerId: usrData.customer_id,
                  enrollmentDate: data.enrollment.createdAt?.split("T")[0] || "",
                  isPrized: data.isPrized === "true"
                });
              }
            }
          }
        }
      }
      const usersList = [];
      let count = 1;
      for (const penaltyData of allPenaltyData) {
        const userId = String(penaltyData.user_id);
        const groupId = String(penaltyData.group_id);
        const ticket = String(penaltyData.ticket_number || "").trim();
        const userDetails = userDetailsMap.get(`${userId}_${groupId}_${ticket}`);
        if (!userDetails) continue;
        const summary = penaltyData.summary || {};
        const amountToBePaid = summary.total_expected || 0;
        const amountPaid = summary.total_paid || 0;
        const balance = summary.grand_total_due_with_penalty || 0;
        const totalPenalty = summary.total_penalty || 0;
        const totalLateFee = summary.total_late_payment_charges || 0;
        const vcPenalty = summary.total_vacant_chit_penalty || 0;
        const regularPenalty = totalPenalty - vcPenalty - (summary.manual_penalty || 0);
        const manualPenalty = summary.manual_penalty || 0;
        const manualLateFee = summary.manual_late_fee || 0;
        const totalOverdueCharges = totalPenalty + totalLateFee;
        const balanceWithoutPenalty = amountToBePaid - amountPaid;
        const enrollmentDate = moment(userDetails.enrollmentDate);
        const today = moment().startOf("day");
        const vacantGraceDays = Number(penaltyData.vacant_grace_days || 90);
        const vcGraceEnd = enrollmentDate.clone().add(vacantGraceDays, "days").startOf("day");
        let isVcWithinGrace = false;
        let isVcPenaltyApplied = false;
        const vacantCycles = penaltyData?.cycles?.filter((c) => c.vacant_cycle === true) || [];
        if (vacantCycles.length > 0) {
          if (today.isSameOrBefore(vcGraceEnd, "day")) {
            isVcWithinGrace = true;
          } else {
            isVcPenaltyApplied = true;
          }
        }
        const whatsappActions = /* @__PURE__ */ jsxDEV(Space, { size: "small", children: /* @__PURE__ */ jsxDEV(
          Button,
          {
            type: "primary",
            icon: /* @__PURE__ */ jsxDEV(EyeOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 253,
              columnNumber: 19
            }, this),
            size: "small",
            onClick: () => handleShowBreakdown(
              userId,
              groupId,
              userDetails.userName,
              penaltyData.group_name,
              penaltyData
            ),
            children: "View"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 251,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 250,
          columnNumber: 9
        }, this);
        const userRecord = {
          _id: penaltyData.enrollment_id,
          userId,
          groupId,
          sl_no: count,
          userName: userDetails.userName,
          userPhone: userDetails.userPhone,
          customerId: userDetails.customerId,
          amountPaid,
          paymentsTicket: ticket,
          amountToBePaid,
          groupName: penaltyData.group_name,
          enrollmentDate: userDetails.enrollmentDate,
          totalToBePaid: amountToBePaid,
          balance,
          regularPenalty,
          vcPenalty,
          totalPenalty,
          totalLateFee,
          balanceWithoutPenalty,
          combinedPenalty: totalPenalty,
          totalOverdueCharges,
          manualPenalty,
          manualLateFee,
          actions: whatsappActions,
          statusDiv: isVcWithinGrace ? /* @__PURE__ */ jsxDEV(Tag, { color: "violet", children: "VC – Within Grace" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 296,
            columnNumber: 11
          }, this) : isVcPenaltyApplied ? /* @__PURE__ */ jsxDEV(Tag, { color: "gold", children: "VC Penalty Applied" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 298,
            columnNumber: 11
          }, this) : userDetails.isPrized ? /* @__PURE__ */ jsxDEV(Tag, { color: "success", icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 300,
            columnNumber: 38
          }, this), children: "Prized" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 300,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV(Tag, { color: "error", icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 304,
            columnNumber: 36
          }, this), children: "Un Prized" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 304,
            columnNumber: 11
          }, this),
          isVcWithinGrace,
          isVcPenaltyApplied,
          hasPenaltyOrLateFee: totalPenalty > 0 || totalLateFee > 0,
          vacantGraceDays
        };
        usersList.push(userRecord);
        count++;
      }
      setUsersData(usersList);
    } catch (error) {
      console.error("Error fetching data:", error);
      message.error("Failed to load penalty monitor data");
    } finally {
      setScreenLoading(false);
    }
  };
  const fetchMonthlyCollected = async () => {
    try {
      setMonthlyCollectedLoading(true);
      const res = await api.get("/penalty/collected-this-month");
      if (res.data.success) {
        setMonthlyCollectedSummary(res?.data?.summary);
        setMonthlyCollectedDetails(res?.data?.details || []);
      }
    } catch (err) {
      message.error("Failed to load monthly penalty collected data");
      console.error(err);
    } finally {
      setMonthlyCollectedLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
    fetchMonthlyCollected();
  }, []);
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (["INPUT", "TEXTAREA", "SELECT"].includes(e.target.tagName)) return;
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "s") {
        e.preventDefault();
        navigate("/penalty-settings");
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [navigate]);
  const [totals, setTotals] = useState({
    totalCustomers: 0,
    totalGroups: 0,
    totalToBePaid: 0,
    totalPaid: 0,
    totalBalance: 0,
    totalPenalty: 0,
    totalLateFee: 0,
    totalRegularPenalty: 0,
    totalVcPenalty: 0,
    totalTickets: 0,
    totalBalanceWithoutPenalty: 0,
    totalOutstandingWithPenalty: 0,
    totalPenaltyAndLateFee: 0,
    totalManualPenalty: 0,
    totalManualLateFee: 0
  });
  useEffect(() => {
    const uniqueCustomerIds = new Set(filteredUsers.map((u) => u.userId));
    const totalCustomers = uniqueCustomerIds.size;
    const groupSet = new Set(filteredUsers.map((user) => user.groupName));
    const totalGroups = groupFilter ? 1 : groupSet.size;
    const totalToBePaid = filteredUsers.reduce((sum, u) => sum + (u.totalToBePaid || 0), 0);
    const totalPaid = filteredUsers.reduce((sum, u) => sum + (u.amountPaid || 0), 0);
    const totalBalance = filteredUsers.reduce((sum, u) => sum + (u.balance || 0), 0);
    const totalBalanceWithoutPenalty = filteredUsers.reduce((sum, u) => sum + (u.balanceWithoutPenalty || 0), 0);
    const totalOutstandingWithPenalty = filteredUsers.reduce((sum, u) => sum + (u.balance || 0), 0);
    const totalPenalty = filteredUsers.reduce((sum, u) => sum + (u.totalPenalty || 0), 0);
    const totalLateFee = filteredUsers.reduce((sum, u) => sum + (u.totalLateFee || 0), 0);
    const totalPenaltyAndLateFee = totalPenalty + totalLateFee;
    const totalRegularPenalty = filteredUsers.reduce((sum, u) => sum + (u.regularPenalty || 0), 0);
    const totalVcPenalty = filteredUsers.reduce((sum, u) => sum + (u.vcPenalty || 0), 0);
    const totalManualPenalty = filteredUsers.reduce((sum, u) => sum + (u.manualPenalty || 0), 0);
    const totalManualLateFee = filteredUsers.reduce((sum, u) => sum + (u.manualLateFee || 0), 0);
    const totalTickets = filteredUsers.length;
    setTotals({
      totalCustomers,
      totalGroups,
      totalToBePaid,
      totalPaid,
      totalBalance,
      totalPenalty,
      totalLateFee,
      totalRegularPenalty,
      totalVcPenalty,
      totalTickets,
      totalBalanceWithoutPenalty,
      totalOutstandingWithPenalty,
      totalPenaltyAndLateFee,
      totalManualPenalty,
      totalManualLateFee
    });
  }, [filteredUsers, groupFilter]);
  const handleShowBreakdown = async (userId, groupId, userName, groupName, cachedPenaltyData = null) => {
    try {
      setLoadingBreakdown(true);
      setSelectedCustomer({ userName, groupName });
      setBreakdownModal(true);
      let penaltyData = cachedPenaltyData;
      if (!penaltyData) {
        const res = await api.get("/penalty/get-penalty-report", {
          params: { user_id: userId, group_id: groupId }
        });
        if (res.data?.success && res.data?.data?.length > 0) {
          penaltyData = res.data.data[0];
        }
      }
      if (!penaltyData || !penaltyData.cycles) {
        message.error("No penalty breakdown data available");
        return;
      }
      setBreakdownData(penaltyData.cycles);
    } catch (err) {
      console.error(err);
      message.error("Failed to load penalty breakdown");
    } finally {
      setLoadingBreakdown(false);
    }
  };
  const calculateGraceDaysLeft = (enrollmentDateStr, vacantGraceDays = 90) => {
    const enrollmentDate = moment(enrollmentDateStr);
    const today = moment().startOf("day");
    const graceEnd = enrollmentDate.clone().add(vacantGraceDays, "days");
    return Math.max(0, graceEnd.diff(today, "days"));
  };
  const calculateDaysLate = (enrollmentDateStr) => {
    const lastDue = moment().startOf("month");
    const today = moment();
    return Math.max(0, today.diff(lastDue, "days"));
  };
  const sendSingleWhatsapp = async (user, type) => {
    try {
      setScreenLoading(true);
      const payload = {
        [`user_0`]: {
          info: {
            status: true,
            userName: user.userName,
            groupName: user.groupName,
            paymentsTicket: user.paymentsTicket,
            expected: user.totalToBePaid,
            userPhone: user.userPhone,
            ...type === "vcWithinGrace" && {
              graceDaysLeft: calculateGraceDaysLeft(user.enrollmentDate, user.vacantGraceDays)
            },
            ...type === "vcPenaltyApplied" && {
              appliedVcAmount: user.vcPenalty || 0,
              balance: user.balance
            },
            ...type === "latePenaltyWithin" && {
              daysLate: calculateDaysLate(user.enrollmentDate)
            },
            ...type === "latePenaltyApplied" && {
              lateFee: user.totalLateFee,
              penalty: user.regularPenalty,
              balance: user.balance
            }
          }
        }
      };
      let endpoint = "";
      switch (type) {
        case "vcWithinGrace":
          endpoint = "/whatsapp/vc-within-grace";
          break;
        case "vcPenaltyApplied":
          endpoint = "/whatsapp/vc-penalty-applied";
          break;
        case "latePenaltyWithin":
          endpoint = "/whatsapp/late-penalty-within-threshold";
          break;
        case "latePenaltyApplied":
          endpoint = "/whatsapp/late-penalty-applied";
          break;
        default:
          throw new Error("Invalid WhatsApp type");
      }
      const res = await api.post(endpoint, payload);
      const { success, error } = res.data;
      if (success > 0) {
        message.success(`✅ WhatsApp sent to ${user.userName}`);
      } else {
        message.error(`❌ Failed to send to ${user.userName}`);
      }
    } catch (err) {
      console.error("Single WhatsApp send error:", err);
      message.error(`❌ Failed to send to ${user.userName}`);
    } finally {
      setScreenLoading(false);
    }
  };
  const handleSendWhatsapp = async () => {
    if (selectedRows.length === 0) return;
    setScreenLoading(true);
    try {
      const payload = {};
      selectedRows.forEach((user, idx) => {
        payload[`user_${idx}`] = {
          info: {
            status: true,
            userName: user.userName,
            groupName: user.groupName,
            paymentsTicket: user.paymentsTicket,
            expected: user.totalToBePaid,
            userPhone: user.userPhone,
            ...sendModal.type === "vcWithinGrace" && {
              graceDaysLeft: calculateGraceDaysLeft(user.enrollmentDate, user.vacantGraceDays)
            },
            ...sendModal.type === "vcPenaltyApplied" && {
              appliedVcAmount: user.vcPenalty || 0,
              balance: user.balance
            },
            ...sendModal.type === "latePenaltyWithin" && {
              daysLate: calculateDaysLate(user.enrollmentDate)
            },
            ...sendModal.type === "latePenaltyApplied" && {
              lateFee: user.totalLateFee,
              penalty: user.regularPenalty,
              balance: user.balance
            }
          }
        };
      });
      let endpoint = "";
      switch (sendModal.type) {
        case "vcWithinGrace":
          endpoint = "/whatsapp/vc-within-grace";
          break;
        case "vcPenaltyApplied":
          endpoint = "/whatsapp/vc-penalty-applied";
          break;
        case "latePenaltyWithin":
          endpoint = "/whatsapp/late-penalty-within-threshold";
          break;
        case "latePenaltyApplied":
          endpoint = "/whatsapp/late-penalty-applied";
          break;
        default:
          throw new Error("Invalid WhatsApp type");
      }
      const res = await api.post(endpoint, payload);
      const { success, error } = res.data;
      message.success(`✅ ${success} message(s) sent. ❌ ${error} failed.`);
      setSendModal({ open: false, type: null });
      setSelectedRows([]);
    } catch (err) {
      console.error("WhatsApp send error:", err);
      message.error("❌ Failed to send WhatsApp messages. Check console.");
    } finally {
      setScreenLoading(false);
    }
  };
  const openSendModal = (type) => {
    setSendModal({ open: true, type });
  };
  const handleGroupSelect = (value) => {
    setReversalGroupFilter(value || "");
    setReversalCustomerFilter("");
    setReversalTicketFilter("");
  };
  const handleCustomerSelect = (value) => {
    setReversalCustomerFilter(value || "");
    setReversalTicketFilter("");
  };
  const handleTicketSelect = (value) => {
    setReversalTicketFilter(value);
  };
  const openReverseAmountDrawer = (type) => {
    let maxAmount = 0;
    switch (type) {
      case "late_fee":
        maxAmount = penaltySummary.totalLateFee;
        break;
      case "penalty":
        maxAmount = penaltySummary.regularPenalty;
        break;
      case "vc_penalty":
        maxAmount = penaltySummary.vcPenalty;
        break;
      case "all":
        maxAmount = penaltySummary.totalLateFee + penaltySummary.regularPenalty + penaltySummary.vcPenalty;
        break;
      default:
        maxAmount = 0;
    }
    setMaxAllowedAmount(maxAmount);
    setReverseAmount("");
    setSelectedReversalType(type);
    setReverseAmountDrawer(true);
    setPenaltySummaryDrawer(false);
  };
  const handleApplyReversal = async () => {
    const amount = parseFloat(reverseAmount);
    if (!amount || amount <= 0 || amount > maxAllowedAmount) {
      message.error(`Please enter a valid amount (≤ ₹${maxAllowedAmount.toFixed(2)})`);
      return;
    }
    try {
      setScreenLoading(true);
      const payload = {
        user_id: penaltySummary.userId,
        group_id: penaltySummary.groupId,
        ticket: penaltySummary.paymentsTicket,
        amount,
        type: selectedReversalType
      };
      await api.post("/penalty/reverse-amount", payload);
      message.success("✅ Penalty reversal applied successfully!");
      setReverseAmountDrawer(false);
      fetchData();
    } catch (err) {
      console.error("Reversal error:", err);
      message.error("❌ Failed to apply reversal");
    } finally {
      setScreenLoading(false);
    }
  };
  const handleAddPenaltyGroupSelect = (value) => {
    setAddPenaltyGroupFilter(value || "");
    setAddPenaltyCustomerFilter("");
    setAddPenaltyTicketFilter("");
  };
  const handleAddPenaltyCustomerSelect = (value) => {
    setAddPenaltyCustomerFilter(value || "");
    setAddPenaltyTicketFilter("");
  };
  const handleAddPenaltyTicketSelect = (value) => {
    setAddPenaltyTicketFilter(value);
  };
  const handleSavePenalty = async () => {
    if (!addPenaltyDetails || !addPenaltyAmount && !addLateFeeAmount) {
      message.error("Please enter at least one of penalty or late fee amount");
      return;
    }
    try {
      setAddPenaltyLoading(true);
      const payload = {
        user_id: addPenaltyDetails.userId,
        group_id: addPenaltyDetails.groupId,
        ticket: addPenaltyDetails.paymentsTicket,
        penalty_amount: parseFloat(addPenaltyAmount) || 0,
        late_fee_amount: parseFloat(addLateFeeAmount) || 0
      };
      await api.post("/penalty/add-manual-penalty", payload);
      message.success("✅ Penalty added successfully!");
      setAddPenaltyDrawerOpen(false);
      setAddPenaltyDetails(null);
      setAddPenaltyAmount("");
      setAddLateFeeAmount("");
      fetchData();
    } catch (err) {
      console.error("Add penalty error:", err);
      message.error("❌ Failed to add penalty");
    } finally {
      setAddPenaltyLoading(false);
    }
  };
  const formatAmount = (value) => Number(value || 0).toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const columns = [
    {
      key: "sl_no",
      header: "SL. NO",
      render: (text, record, index) => /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: index + 1 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 688,
        columnNumber: 38
      }, this)
    },
    {
      key: "userName",
      header: "Customer Name",
      render: (text) => /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-900", children: text }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 693,
        columnNumber: 23
      }, this)
    },
    {
      key: "userPhone",
      header: "Phone Number",
      render: (text) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
        /* @__PURE__ */ jsxDEV(PhoneOutlined, { className: "mr-2 text-violet-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 700,
          columnNumber: 11
        }, this),
        text
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 699,
        columnNumber: 5
      }, this)
    },
    {
      key: "customerId",
      header: "Customer ID",
      render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-sm bg-gray-100 px-2 py-1 rounded", children: text }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 708,
        columnNumber: 23
      }, this)
    },
    {
      key: "groupName",
      header: "Group Name",
      render: (text) => /* @__PURE__ */ jsxDEV(Tag, { color: "violet", className: "font-medium", children: text }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 713,
        columnNumber: 23
      }, this)
    },
    {
      key: "enrollmentDate",
      header: "Enrollment Date",
      render: (text) => moment(text).format("DD/MM/YYYY")
    },
    {
      key: "paymentsTicket",
      header: "Ticket"
    },
    {
      key: "totalToBePaid",
      header: "Amount Payable",
      render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-green-600", children: [
        "₹",
        Number(text || 0).toFixed(2).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 728,
        columnNumber: 5
      }, this)
    },
    {
      key: "amountPaid",
      header: "Amount Paid",
      render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-indigo-600", children: [
        "₹",
        Number(text || 0).toFixed(2).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 737,
        columnNumber: 5
      }, this)
    },
    {
      key: "balanceWithoutPenalty",
      header: "Balance",
      render: (text, record) => {
        const balance = Number(record.balanceWithoutPenalty || 0);
        return /* @__PURE__ */ jsxDEV("span", { className: `font-semibold ${balance > 0 ? "text-red-600" : "text-green-600"}`, children: [
          "₹",
          balance.toFixed(2).toLocaleString("en-IN")
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 748,
          columnNumber: 9
        }, this);
      }
    },
    {
      key: "totalPenalty",
      header: "Total Penalty",
      render: (text, record) => /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-purple-600", children: [
        "₹",
        Number(record.totalPenalty || 0).toFixed(2).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 758,
        columnNumber: 5
      }, this)
    },
    {
      key: "totalLateFee",
      header: "Late Fee",
      render: (text) => /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-orange-600", children: [
        "₹",
        Number(text || 0).toFixed(2).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 767,
        columnNumber: 5
      }, this)
    },
    {
      key: "totalOverdueCharges",
      header: "Total Overdue Charges",
      render: (text, record) => /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-red-700", children: [
        "₹",
        Number(record.totalOverdueCharges || 0).toFixed(2).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 776,
        columnNumber: 5
      }, this)
    },
    {
      key: "balance",
      header: "Outstanding with Penalty",
      render: (text) => {
        const balance = Number(text || 0);
        return /* @__PURE__ */ jsxDEV("span", { className: `font-semibold ${balance > 0 ? "text-red-600" : "text-green-600"}`, children: [
          "₹",
          balance.toFixed(2).toLocaleString("en-IN")
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 787,
          columnNumber: 9
        }, this);
      }
    },
    {
      key: "actions",
      header: "Actions",
      render: (text, record) => record.actions
    }
  ];
  const breakdownColumns = [
    {
      title: "Auction",
      dataIndex: "cycle_no",
      align: "center",
      width: 80,
      render: (text, row) => row.vacant_cycle ? /* @__PURE__ */ jsxDEV(Tag, { color: "gold", style: { fontWeight: "bold" }, children: "VC" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 808,
        columnNumber: 5
      }, this) : /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: text }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 812,
        columnNumber: 5
      }, this)
    },
    {
      title: "Due Date",
      dataIndex: "to_date",
      render: (v, row) => row.vacant_cycle ? /* @__PURE__ */ jsxDEV("span", { style: { color: "#b58900", fontWeight: "600" }, children: moment(v).format("DD/MM/YYYY") }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 820,
        columnNumber: 5
      }, this) : moment(v).format("DD/MM/YYYY")
    },
    {
      title: "Expected",
      dataIndex: "expected",
      align: "right",
      render: (v, row) => {
        const value = Number(v || 0);
        return row.vacant_cycle ? /* @__PURE__ */ jsxDEV("span", { style: { color: "#b58900", fontWeight: "600" }, children: [
          "₹",
          value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 832,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: [
          "₹",
          value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 836,
          columnNumber: 7
        }, this);
      }
    },
    {
      title: "Paid",
      dataIndex: "paid",
      align: "right",
      render: (v) => {
        const value = Number(v || 0);
        return /* @__PURE__ */ jsxDEV("span", { className: "text-green-600 font-medium", children: [
          "₹",
          value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 848,
          columnNumber: 14
        }, this);
      }
    },
    {
      title: "Balance",
      dataIndex: "balance",
      align: "right",
      render: (v) => {
        const value = Number(v || 0);
        return /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-medium", children: [
          "₹",
          value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 859,
          columnNumber: 14
        }, this);
      }
    },
    {
      title: "Penalty",
      dataIndex: "penalty",
      align: "right",
      render: (v, row) => {
        const value = Number(v || 0);
        return row.vacant_cycle ? /* @__PURE__ */ jsxDEV("span", { style: { color: "#d97706", fontWeight: 700 }, children: [
          "₹",
          value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 871,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: value > 0 ? "red" : "gray", fontWeight: 500 }, children: [
          "₹",
          value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 875,
          columnNumber: 7
        }, this);
      }
    },
    {
      title: "Late Fee",
      dataIndex: "late_payment_charges",
      align: "right",
      render: (v) => {
        const value = Number(v || 0);
        return /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-medium", children: [
          "₹",
          value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 888,
          columnNumber: 9
        }, this);
      }
    },
    {
      title: "Penalty Rate",
      dataIndex: "penalty_rate_percent",
      align: "center",
      render: (v, row) => row.vacant_cycle ? /* @__PURE__ */ jsxDEV(Tag, { color: "gold", children: "VC Rate" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 899,
        columnNumber: 24
      }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-violet-600", children: [
        Number(v || 0),
        "%"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 899,
        columnNumber: 58
      }, this)
    }
  ];
  const exportBreakdownToCSV = () => {
    if (!breakdownData.length) {
      message.warning("No data to export");
      return;
    }
    const headers = [
      "Auction",
      "Due Date",
      "Expected",
      "Paid",
      "Balance",
      "Penalty",
      "Late Fee",
      "Penalty Rate (%)"
    ];
    const csvContent = [
      headers.join(","),
      ...breakdownData.map((row) => {
        const auction = row.vacant_cycle ? "VC" : row.cycle_no;
        const dueDate = moment(row.to_date).format("DD/MM/YYYY");
        const expected = Number(row.expected || 0).toFixed(2);
        const paid = Number(row.paid || 0).toFixed(2);
        const balance = Number(row.balance || 0).toFixed(2);
        const penalty = Number(row.penalty || 0).toFixed(2);
        const lateFee = Number(row.late_payment_charges || 0).toFixed(2);
        const penaltyRate = row.vacant_cycle ? "VC Rate" : Number(row.penalty_rate_percent || 0);
        const escape = (val) => typeof val === "string" && (val.includes(",") || val.includes('"')) ? `"${val.replace(/"/g, '""')}"` : val;
        return [
          escape(auction),
          escape(dueDate),
          expected,
          paid,
          balance,
          penalty,
          lateFee,
          escape(penaltyRate)
        ].join(",");
      })
    ].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute(
      "download",
      `PenaltyBreakdown_${selectedCustomer?.userName || "customer"}_${moment().format("YYYYMMDD")}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen mt-20 bg-gradient-to-br from-gray-50 to-gray-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 962,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 963,
          columnNumber: 9
        },
        this
      ),
      screenLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex-grow flex items-center justify-center h-screen", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 969,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 968,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex-grow w-1/2 p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800 mb-2", children: "Penalty & Outstanding Report" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 976,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: "Monitor and manage customer penalties, late fees, and outstanding amounts" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 977,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 975,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "dashed",
                onClick: () => navigate("/penalty-settings"),
                children: "Go to Penalty Settings"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 980,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(CalculatorOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 988,
                  columnNumber: 23
                }, this),
                onClick: () => setAddPenaltyDrawerOpen(true),
                children: "Add Penalty"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 986,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(AiFillBackward, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 995,
                  columnNumber: 23
                }, this),
                onClick: () => setReversalDrawerOpen(true),
                children: "Penalty Reversal"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 993,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 979,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 974,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV(
          Card,
          {
            className: "shadow-sm rounded-lg border border-gray-200",
            title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV(FilterOutlined, { className: "mr-2 text-violet-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1009,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-lg", children: "Filters" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1010,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1008,
              columnNumber: 15
            }, this),
            children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Group Filter" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1016,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full",
                    allowClear: true,
                    placeholder: "Select a group",
                    onChange: (value) => setGroupFilter(value),
                    value: groupFilter || void 0,
                    suffixIcon: /* @__PURE__ */ jsxDEV(UsergroupAddOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1023,
                      columnNumber: 33
                    }, this),
                    children: groupOptions.map(
                      (group) => /* @__PURE__ */ jsxDEV(Option, { value: group, children: group }, group, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                        lineNumber: 1026,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1017,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1015,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Search Customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1033,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    placeholder: "Search by name, phone, or ID",
                    prefix: /* @__PURE__ */ jsxDEV(SearchOutlined, { className: "text-gray-400" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1036,
                      columnNumber: 29
                    }, this),
                    value: searchText,
                    onChange: (e) => setSearchText(e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1034,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1032,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1014,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1005,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1004,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 p-3 rounded-lg mr-4", children: /* @__PURE__ */ jsxDEV(UsergroupAddOutlined, { className: "text-violet-500 text-xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1054,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1053,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1057,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: totals.totalCustomers }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1058,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1056,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1052,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1051,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1050,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-100 p-3 rounded-lg mr-4", children: /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-purple-500 text-xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1067,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1066,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Tickets" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1070,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: totals.totalTickets }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1071,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1069,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1065,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1064,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1063,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 8, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm border border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-3 rounded-lg mr-4", children: /* @__PURE__ */ jsxDEV(UsergroupAddOutlined, { className: "text-green-500 text-xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1080,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1079,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Total Groups" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1083,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: totals.totalGroups }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1084,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1082,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1078,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1077,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1076,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1049,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1048,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { gutter: [12, 16], children: [
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 4, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md border-l-4 border-l-red-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Penalty" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1096,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-red-600", children: [
                "₹",
                Number(totals.totalPenalty || 0).toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1097,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1095,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1094,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1093,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1092,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 4, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md border-l-4 border-l-orange-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Late Fees" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1111,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-orange-600", children: [
                "₹",
                Number(totals.totalLateFee || 0).toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1112,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1110,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1109,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1108,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1107,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 4, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md border-l-4 border-l-amber-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Penalty Collected" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1126,
                  columnNumber: 25
                }, this),
                monthlyCollectedLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-1", children: /* @__PURE__ */ jsxDEV(CircularLoader, { size: "small" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1129,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1128,
                  columnNumber: 23
                }, this) : monthlyCollectedSummary ? /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-amber-700", children: [
                  "₹",
                  Number(monthlyCollectedSummary.totalCollected).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1132,
                  columnNumber: 23
                }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: "No data" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1139,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1125,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "link",
                  size: "small",
                  onClick: () => setMonthlyDetailsModalVisible(true),
                  className: "ml-1 p-0 h-auto",
                  children: /* @__PURE__ */ jsxDEV(EyeOutlined, { className: "text-amber-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1148,
                    columnNumber: 25
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1142,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1124,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1123,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1122,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 4, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md border-l-4 border-l-violet-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Balance" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1157,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-violet-600", children: [
                "₹",
                Number(totals.totalBalanceWithoutPenalty || 0).toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1158,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1156,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1155,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1154,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1153,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 4, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md border-l-4 border-l-purple-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Outstanding (w/ Penalty)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1172,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-purple-600", children: [
                "₹",
                Number(totals.totalOutstandingWithPenalty || 0).toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1173,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1171,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1170,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1169,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1168,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 4, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md border-l-4 border-l-pink-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Penalty + Late Fee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1187,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-pink-600", children: [
                "₹",
                Number(totals.totalPenaltyAndLateFee || 0).toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1188,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1186,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1185,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1184,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1183,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1091,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1046,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Card,
          {
            className: "shadow-sm rounded-lg border border-gray-200 overflow-hidden",
            title: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-lg", children: "Customer Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1206,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-sm", children: selectedRows.length > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-violet-600", children: [
                selectedRows.length,
                " selected"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1209,
                columnNumber: 17
              }, this) : `Showing ${filteredUsers.length} of ${usersData.length} Records` }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1207,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1205,
              columnNumber: 13
            }, this),
            extra: selectedRows.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 items-center", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: /* @__PURE__ */ jsxDEV(MessageOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1220,
                    columnNumber: 23
                  }, this),
                  type: "dashed",
                  onClick: () => openSendModal("vcWithinGrace"),
                  disabled: !selectedRows.some((u) => u.isVcWithinGrace),
                  children: "VC Grace Reminder"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1219,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: /* @__PURE__ */ jsxDEV(WarningOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1228,
                    columnNumber: 23
                  }, this),
                  danger: true,
                  onClick: () => openSendModal("vcPenaltyApplied"),
                  disabled: !selectedRows.some((u) => u.isVcPenaltyApplied),
                  children: "VC Penalty Applied"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1227,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1236,
                    columnNumber: 23
                  }, this),
                  onClick: () => openSendModal("latePenaltyWithin"),
                  disabled: !selectedRows.some(
                    (u) => !u.isVcWithinGrace && !u.isVcPenaltyApplied && u.statusDiv?.props?.children?.props?.children?.includes("Un Prized")
                  ),
                  children: "Late (No Penalty)"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1235,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: /* @__PURE__ */ jsxDEV(DollarCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1245,
                    columnNumber: 23
                  }, this),
                  type: "primary",
                  onClick: () => openSendModal("latePenaltyApplied"),
                  disabled: !selectedRows.some((u) => u.hasPenaltyOrLateFee),
                  children: "Penalty Applied"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1244,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Button, { onClick: () => setSelectedRows([]), disabled: selectedRows.length === 0, children: [
                "Clear (",
                selectedRows.length,
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1252,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1218,
              columnNumber: 13
            }, this),
            children: /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-auto overflow-y-auto max-h-[600px]", children: /* @__PURE__ */ jsxDEV("div", { style: { width: "max-content" }, children: /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: filteredUsers,
                columns,
                exportedPdfName: "Penalty Report",
                exportedFileName: "PenaltyReport.csv"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1261,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1260,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1259,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1202,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 972,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
      lineNumber: 961,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsxDEV(EyeOutlined, { className: "mr-2 text-violet-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1279,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Penalty Breakdown" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1280,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1278,
            columnNumber: 13
          }, this),
          selectedCustomer && /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600 mt-1", children: [
            selectedCustomer.userName,
            " - ",
            selectedCustomer.groupName
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1283,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1277,
          columnNumber: 9
        }, this),
        open: breakdownModal,
        onCancel: () => setBreakdownModal(false),
        footer: null,
        width: 1200,
        bodyStyle: { padding: "20px" },
        children: loadingBreakdown ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1297,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1296,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              onClick: exportBreakdownToCSV,
              disabled: loadingBreakdown || !breakdownData.length,
              icon: /* @__PURE__ */ jsxDEV(DownloadOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1306,
                columnNumber: 21
              }, this),
              children: "Export to CSV"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1302,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1301,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Table,
            {
              dataSource: breakdownData.map((d, i) => ({ ...d, key: i })),
              columns: breakdownColumns,
              pagination: false,
              bordered: true,
              scroll: { x: 1300, y: 400 },
              rowClassName: (record) => record.vacant_cycle ? "bg-yellow-50 border-l-4 border-yellow-500" : ""
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1311,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-6 gap-4 mt-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-sm", children: "Expected" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1321,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold", children: [
                "₹",
                breakdownData.reduce((s, d) => s + (d.expected || 0), 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1322,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1320,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-sm", children: "Paid" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1327,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold text-green-600", children: [
                "₹",
                breakdownData.reduce((s, d) => s + (d.paid || 0), 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1328,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1326,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-sm", children: "Penalty" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1333,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold text-red-600", children: [
                "₹",
                breakdownData.reduce((s, d) => s + (d.penalty || 0), 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1334,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1332,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-sm", children: "Late Fees" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1339,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold text-orange-600", children: [
                "₹",
                breakdownData.reduce((s, d) => s + (d.late_payment_charges || 0), 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1340,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1338,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-sm", children: "VC Penalty" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1345,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-yellow-700", children: [
                "₹",
                breakdownData.filter((d) => d.vacant_cycle).reduce((s, d) => s + (d.penalty || 0), 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1346,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1344,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1319,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1300,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 1275,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV(MessageOutlined, { className: "mr-2 text-violet-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1359,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: [
            sendModal.type === "vcWithinGrace" && "Send VC Grace Reminder?",
            sendModal.type === "vcPenaltyApplied" && "Send VC Penalty Applied Alert?",
            sendModal.type === "latePenaltyWithin" && "Send Late (No Penalty) Reminder?",
            sendModal.type === "latePenaltyApplied" && "Send Penalty Applied Notice?"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1360,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1358,
          columnNumber: 9
        }, this),
        open: sendModal.open,
        onCancel: () => setSendModal({ open: false, type: null }),
        onOk: handleSendWhatsapp,
        okText: "Send Now",
        okButtonProps: {
          loading: screenLoading,
          danger: sendModal.type?.includes("Penalty")
        },
        cancelText: "Cancel",
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mb-4", children: [
            "You are about to send WhatsApp messages to ",
            /* @__PURE__ */ jsxDEV("strong", { children: selectedRows.length }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1378,
              columnNumber: 72
            }, this),
            " customer(s)."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1378,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-5 text-sm text-gray-700 max-h-32 overflow-y-auto", children: [
            selectedRows.slice(0, 5).map(
              (u) => /* @__PURE__ */ jsxDEV("li", { children: [
                u.userName,
                " (",
                u.userPhone,
                ") - ",
                u.groupName
              ] }, u._id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1381,
                columnNumber: 11
              }, this)
            ),
            selectedRows.length > 5 && /* @__PURE__ */ jsxDEV("li", { children: [
              "+ ",
              selectedRows.length - 5,
              " more..."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1385,
              columnNumber: 39
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1379,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 1356,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV(WalletOutlined, { className: "mr-2 text-amber-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1393,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Monthly Penalty Collection Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1394,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1392,
          columnNumber: 9
        }, this),
        open: monthlyDetailsModalVisible,
        onCancel: () => setMonthlyDetailsModalVisible(false),
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setMonthlyDetailsModalVisible(false), children: "Back" }, "back", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1400,
            columnNumber: 9
          }, this)
        ],
        width: 1e3,
        bodyStyle: { padding: "20px" },
        children: monthlyCollectedLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1409,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1408,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-4 bg-amber-50 rounded-lg border border-amber-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Total Collected This Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1416,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-amber-700", children: [
                "₹",
                Number(monthlyCollectedSummary?.totalCollected).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1417,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1415,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Number of Transactions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1422,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-semibold text-gray-800", children: monthlyCollectedDetails.length }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1423,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1421,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1414,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1413,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Table,
            {
              dataSource: monthlyCollectedDetails,
              rowKey: "_id",
              pagination: { pageSize: 10 },
              scroll: { x: 900 },
              columns: [
                {
                  title: "Customer",
                  dataIndex: "userName",
                  key: "userName",
                  render: (name, r) => /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-medium", children: [
                      r.userName || "—",
                      " "
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1441,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500", children: r.userName }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1442,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1440,
                    columnNumber: 15
                  }, this)
                },
                { title: "Group", dataIndex: "groupName", key: "groupName" },
                { title: "Ticket", dataIndex: "ticket", key: "ticket" },
                {
                  title: "Regular",
                  dataIndex: "regular_penalty",
                  key: "regular_penalty",
                  align: "right",
                  render: (v) => `₹${Number(v || 0).toFixed(2)}`
                },
                {
                  title: "VC Penalty",
                  dataIndex: "vc_penalty",
                  key: "vc_penalty",
                  align: "right",
                  render: (v) => `₹${Number(v || 0).toFixed(2)}`
                },
                {
                  title: "Late Fee",
                  dataIndex: "late_fee",
                  key: "late_fee",
                  align: "right",
                  render: (v) => `₹${Number(v || 0).toFixed(2)}`
                },
                {
                  title: "Total",
                  dataIndex: "total_penalty_deducted",
                  key: "total",
                  align: "right",
                  render: (v) => /* @__PURE__ */ jsxDEV("strong", { className: "text-green-700", children: [
                    "₹",
                    Number(v || 0).toFixed(2)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1475,
                    columnNumber: 15
                  }, this)
                },
                {
                  title: "Date",
                  dataIndex: "createdAt",
                  key: "date",
                  render: (d) => moment(d).format("DD MMM YYYY")
                }
              ]
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1429,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1412,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 1390,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV(UndoOutlined, { className: "mr-2 text-violet-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1494,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Penalty Reversal" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1495,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1493,
          columnNumber: 9
        }, this),
        placement: "right",
        onClose: () => setReversalDrawerOpen(false),
        open: reversalDrawerOpen,
        width: 600,
        bodyStyle: { padding: "20px" },
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV(
            Alert,
            {
              message: "Select a customer to reverse penalties",
              description: "Choose a group, customer, and ticket to view and reverse penalties for that account.",
              type: "info",
              showIcon: true,
              className: "mb-4"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1505,
              columnNumber: 11
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1504,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1515,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Group",
                  value: reversalGroupFilter || void 0,
                  onChange: handleGroupSelect,
                  allowClear: true,
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1524,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1516,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Step 1: Select a group to proceed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1529,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1514,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1532,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Customer",
                  value: reversalCustomerFilter || void 0,
                  onChange: (value) => handleCustomerSelect(value),
                  disabled: !reversalGroupFilter,
                  allowClear: true,
                  children: customerOptions.map(
                    (user) => /* @__PURE__ */ jsxDEV(Option, { value: user.userName, children: user.userName }, user.userName, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1542,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1533,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: reversalGroupFilter ? "Step 2: Choose a customer from this group" : "Select a group first" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1547,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1531,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Ticket" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1554,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Ticket",
                  value: reversalTicketFilter || void 0,
                  onChange: handleTicketSelect,
                  disabled: !reversalCustomerFilter,
                  allowClear: true,
                  children: ticketOptions.map(
                    (ticket) => /* @__PURE__ */ jsxDEV(Option, { value: ticket, children: ticket }, ticket, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1564,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1555,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: reversalCustomerFilter ? "Step 3: Select a ticket to review penalties" : "Select a customer first" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1569,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1553,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-4", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "large",
                block: true,
                disabled: !reversalTicketFilter,
                onClick: () => {
                  const user = usersData.find(
                    (u) => u.groupName === reversalGroupFilter && u.userName === reversalCustomerFilter && u.paymentsTicket === reversalTicketFilter
                  );
                  if (user) {
                    setPenaltySummary({
                      userName: user.userName,
                      groupName: user.groupName,
                      userPhone: user.userPhone,
                      paymentsTicket: user.paymentsTicket,
                      userId: user.userId,
                      groupId: user.groupId,
                      totalLateFee: user.totalLateFee || 0,
                      regularPenalty: user.regularPenalty || 0,
                      vcPenalty: user.vcPenalty || 0
                    });
                    setReversalDrawerOpen(false);
                    setPenaltySummaryDrawer(true);
                  }
                },
                children: "Review & Reverse Penalties"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1576,
                columnNumber: 13
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1575,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1513,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 1491,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: null,
        placement: "right",
        onClose: () => setPenaltySummaryDrawer(false),
        open: penaltySummaryDrawer,
        width: 900,
        bodyStyle: { padding: "0" },
        closable: false,
        children: penaltySummary && /* @__PURE__ */ jsxDEV("div", { className: "h-full flex flex-col bg-white", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 text-white p-6 border-b", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 3, className: "text-white mb-1", children: "Penalty Reversal" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1626,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Text, { className: "text-sm", children: "Review and reverse penalties for customer account" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1627,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1625,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                danger: true,
                icon: /* @__PURE__ */ jsxDEV(ArrowLeftOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1632,
                  columnNumber: 23
                }, this),
                onClick: () => setPenaltySummaryDrawer(false),
                children: "Close"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1629,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1624,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1623,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-3", children: /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-0", children: "Customer Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1642,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1641,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Customer Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1646,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.userName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1647,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1645,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Phone Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1650,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.userPhone }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1651,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1649,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Group" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1654,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.groupName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1655,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1653,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Ticket Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1658,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.paymentsTicket }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1659,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1657,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1644,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1640,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 flex-grow overflow-auto", children: [
            /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-4", children: "Penalty Breakdown" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1665,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-4", children: [
              /* @__PURE__ */ jsxDEV(Card, { className: `h-full ${penaltySummary.totalLateFee > 0 ? "" : "opacity-60"}`, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "mb-1", children: "Late Fee" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1669,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Charges for delayed payments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1670,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1668,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Available for Reversal" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1673,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-semibold", children: [
                    "₹",
                    Number(penaltySummary.totalLateFee).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1674,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1672,
                  columnNumber: 19
                }, this),
                penaltySummary.totalLateFee > 0 && /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    className: "w-full",
                    onClick: () => openReverseAmountDrawer("late_fee"),
                    children: "Review Late Fee"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1679,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1667,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Card, { className: `h-full ${penaltySummary.regularPenalty > 0 ? "" : "opacity-60"}`, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "mb-1", children: "Regular Penalty" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1690,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Standard penalty charges" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1691,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1689,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Available for Reversal" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1694,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-semibold", children: [
                    "₹",
                    Number(penaltySummary.regularPenalty).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1695,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1693,
                  columnNumber: 19
                }, this),
                penaltySummary.regularPenalty > 0 && /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "primary",
                    className: "w-full",
                    onClick: () => openReverseAmountDrawer("penalty"),
                    children: "Review Regular Penalty"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1700,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1688,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1666,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Card, { className: `mb-4 ${penaltySummary.vcPenalty > 0 ? "" : "opacity-60"}`, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "mb-1", children: "Vacant Chit Penalty" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1712,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Vacant chit penalty charges" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1713,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1711,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Available for Reversal" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1716,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-semibold", children: [
                  "₹",
                  Number(penaltySummary.vcPenalty).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1717,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1715,
                columnNumber: 17
              }, this),
              penaltySummary.vcPenalty > 0 && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  className: "w-full",
                  onClick: () => openReverseAmountDrawer("vc_penalty"),
                  children: "Review Vacant Chit Penalty"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1722,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1710,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Card, { className: `mb-4 ${penaltySummary.totalLateFee + penaltySummary.regularPenalty + penaltySummary.vcPenalty > 0 ? "border-2 border-slate-300" : "opacity-60"}`, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "mb-1", children: "Total Reversible Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1733,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Sum of all penalties and fees" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1734,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1732,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-sm", children: "Total Available for Reversal" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1737,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-semibold", children: [
                  "₹",
                  (Number(penaltySummary.totalLateFee) + Number(penaltySummary.regularPenalty) + Number(penaltySummary.vcPenalty)).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1738,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1736,
                columnNumber: 17
              }, this),
              penaltySummary.totalLateFee + penaltySummary.regularPenalty + penaltySummary.vcPenalty > 0 && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  className: "w-full",
                  onClick: () => openReverseAmountDrawer("all"),
                  children: "Review All Penalties & Fees"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1747,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1731,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Alert,
              {
                message: "Important Information",
                description: "Select a penalty type above to reverse. You may reverse part or all of any penalty type. Enter the exact amount in the next step. All reversals will be logged for audit purposes.",
                type: "info",
                showIcon: true,
                className: "mt-4"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1756,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1664,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1621,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 1611,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: null,
        placement: "right",
        onClose: () => {
          setReverseAmountDrawer(false);
          setPenaltySummaryDrawer(true);
        },
        open: reverseAmountDrawer,
        width: 800,
        bodyStyle: { padding: "0" },
        closable: false,
        children: penaltySummary && /* @__PURE__ */ jsxDEV("div", { className: "h-full flex flex-col bg-white", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 text-white p-6 border-b", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 3, className: "text-white mb-1", children: selectedReversalType === "late_fee" ? "Reverse Late Fee" : selectedReversalType === "penalty" ? "Reverse Regular Penalty" : selectedReversalType === "vc_penalty" ? "Reverse VC Penalty" : "Reverse All Penalties & Fees" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1786,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Text, { className: "text-sm", children: "Enter the amount you want to reverse from the customer's penalties" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1795,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1785,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                danger: true,
                icon: /* @__PURE__ */ jsxDEV(ArrowLeftOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1802,
                  columnNumber: 23
                }, this),
                onClick: () => {
                  setReverseAmountDrawer(false);
                  setPenaltySummaryDrawer(true);
                },
                children: "Close"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1799,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1784,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1783,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 flex-grow overflow-auto", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4 border-b pb-4", children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-3", children: "Customer Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1815,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1818,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.userName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1819,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1817,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1822,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.userPhone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1823,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1821,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1826,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.groupName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1827,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1825,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Ticket" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1830,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: penaltySummary.paymentsTicket }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1831,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1829,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1816,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1814,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-4 bg-slate-50 rounded-lg border", children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-2", children: selectedReversalType === "late_fee" ? "Late Fee Available for Reversal" : selectedReversalType === "penalty" ? "Regular Penalty Available for Reversal" : selectedReversalType === "vc_penalty" ? "VC Penalty Available for Reversal" : "Total Reversible Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1837,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-semibold mb-2", children: [
                "₹",
                maxAllowedAmount.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1846,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Text, { type: "secondary", children: "Maximum amount that can be reversed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1849,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1836,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-3", children: "Enter Reversal Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1853,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  value: reverseAmount,
                  onChange: (e) => setReverseAmount(e.target.value),
                  placeholder: `Enter amount (e.g., ${Math.min(100, maxAllowedAmount).toLocaleString("en-IN")})`,
                  min: 0,
                  step: 0.01,
                  className: "w-full h-12 text-lg",
                  addonBefore: "₹"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1854,
                  columnNumber: 17
                },
                this
              ),
              parseFloat(reverseAmount) > maxAllowedAmount && /* @__PURE__ */ jsxDEV("div", { className: "text-red-600 text-sm mt-2 flex items-center bg-red-50 p-2 rounded", children: [
                /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "mr-2" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1866,
                  columnNumber: 21
                }, this),
                "Amount cannot exceed ₹",
                maxAllowedAmount.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1865,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1852,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "mb-3", children: "Quick Select Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1873,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-3", children: [
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    onClick: () => setReverseAmount((maxAllowedAmount * 0.25).toFixed(2)),
                    disabled: maxAllowedAmount <= 0,
                    children: "25%"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1875,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    onClick: () => setReverseAmount((maxAllowedAmount * 0.5).toFixed(2)),
                    disabled: maxAllowedAmount <= 0,
                    children: "50%"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1881,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    onClick: () => setReverseAmount((maxAllowedAmount * 0.75).toFixed(2)),
                    disabled: maxAllowedAmount <= 0,
                    children: "75%"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1887,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    onClick: () => setReverseAmount(maxAllowedAmount.toFixed(2)),
                    disabled: maxAllowedAmount <= 0,
                    children: "100%"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 1893,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1874,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1872,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Alert,
              {
                message: "Important Notice",
                description: "Reversed amounts will be deducted from the customer's balance and logged for audit. This action cannot be undone. Please verify the amount before proceeding.",
                type: "warning",
                showIcon: true,
                className: "mb-4"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1902,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "large",
                  className: "flex-1",
                  onClick: () => {
                    setReverseAmountDrawer(false);
                    setPenaltySummaryDrawer(true);
                  },
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1911,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  danger: true,
                  size: "large",
                  className: "flex-1",
                  disabled: !reverseAmount || parseFloat(reverseAmount) <= 0 || parseFloat(reverseAmount) > maxAllowedAmount,
                  onClick: handleApplyReversal,
                  children: "Apply Reversal"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1921,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1910,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1812,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1781,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 1768,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "mr-2 text-violet-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1941,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Add Manual Penalty" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1942,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 1940,
          columnNumber: 9
        }, this),
        placement: "right",
        onClose: () => setAddPenaltyDrawerOpen(false),
        open: addPenaltyDrawerOpen,
        width: 600,
        bodyStyle: { padding: "20px" },
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV(
            Alert,
            {
              message: "Select a customer to add manual penalties",
              description: "Choose a group, customer, and ticket to add manual penalties and late fees to that account.",
              type: "info",
              showIcon: true,
              className: "mb-4"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1952,
              columnNumber: 11
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1951,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1962,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Group",
                  value: addPenaltyGroupFilter || void 0,
                  onChange: handleAddPenaltyGroupSelect,
                  allowClear: true,
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1971,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1963,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Step 1: Select a group to proceed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1976,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1961,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1979,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Customer",
                  value: addPenaltyCustomerFilter || void 0,
                  onChange: (value) => handleAddPenaltyCustomerSelect(value),
                  disabled: !addPenaltyGroupFilter,
                  allowClear: true,
                  children: addPenaltyCustomerOptions.map(
                    (user) => /* @__PURE__ */ jsxDEV(Option, { value: user.userName, children: user.userName }, user.userName, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 1989,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 1980,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: addPenaltyGroupFilter ? "Step 2: Choose a customer from this group" : "Select a group first" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 1994,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 1978,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Ticket" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2001,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Ticket",
                  value: addPenaltyTicketFilter || void 0,
                  onChange: handleAddPenaltyTicketSelect,
                  disabled: !addPenaltyCustomerFilter,
                  allowClear: true,
                  children: addPenaltyTicketOptions.map(
                    (ticket) => /* @__PURE__ */ jsxDEV(Option, { value: ticket, children: ticket }, ticket, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                      lineNumber: 2011,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2002,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: addPenaltyCustomerFilter ? "Step 3: Select a ticket to add penalties" : "Select a customer first" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2016,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 2e3,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-4", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "large",
                block: true,
                disabled: !addPenaltyTicketFilter,
                onClick: () => {
                  const user = usersData.find(
                    (u) => u.groupName === addPenaltyGroupFilter && u.userName === addPenaltyCustomerFilter && u.paymentsTicket === addPenaltyTicketFilter
                  );
                  if (user) {
                    setAddPenaltyDetails({
                      userName: user.userName,
                      groupName: user.groupName,
                      userPhone: user.userPhone,
                      paymentsTicket: user.paymentsTicket,
                      userId: user.userId,
                      groupId: user.groupId,
                      balance: user.balance,
                      totalPenalty: user.totalPenalty,
                      totalLateFee: user.totalLateFee
                    });
                  }
                },
                children: "Add Penalties"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2023,
                columnNumber: 13
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 2022,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 1960,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 1938,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: null,
        placement: "right",
        onClose: () => {
          setAddPenaltyDrawerOpen(false);
          setAddPenaltyDetails(null);
          setAddPenaltyAmount("");
          setAddLateFeeAmount("");
        },
        open: !!addPenaltyDetails,
        width: 800,
        bodyStyle: { padding: "0" },
        closable: false,
        children: addPenaltyDetails && /* @__PURE__ */ jsxDEV("div", { className: "h-full flex flex-col bg-white", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 text-white p-6 border-b", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 3, className: "text-white mb-1", children: "Add Manual Penalty" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2076,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Text, { className: "text-sm", children: "Enter penalty and late fee amounts for customer account" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2077,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 2075,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                danger: true,
                icon: /* @__PURE__ */ jsxDEV(ArrowLeftOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2082,
                  columnNumber: 23
                }, this),
                onClick: () => {
                  setAddPenaltyDetails(null);
                  setAddPenaltyAmount("");
                  setAddLateFeeAmount("");
                },
                children: "Close"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2079,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 2074,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 2073,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 flex-grow overflow-auto", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4 border-b pb-4", children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-3", children: "Customer Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2096,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2099,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.userName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2100,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2098,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2103,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.userPhone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2104,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2102,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2107,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.groupName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2108,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2106,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Ticket" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2111,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.paymentsTicket }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2112,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2110,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Current Balance" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2115,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: [
                    "₹",
                    Number(addPenaltyDetails.balance || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2116,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2114,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Current Penalty" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2119,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: [
                    "₹",
                    Number(addPenaltyDetails.totalPenalty || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2120,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2118,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs uppercase tracking-wide block mb-1", children: "Current Late Fee" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2123,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: [
                    "₹",
                    Number(addPenaltyDetails.totalLateFee || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2124,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2122,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2097,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 2095,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-3", children: "Enter Penalty Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2130,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Penalty Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2132,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    value: addPenaltyAmount,
                    onChange: (e) => setAddPenaltyAmount(e.target.value),
                    placeholder: "Enter penalty amount (e.g., 500)",
                    min: 0,
                    step: 0.01,
                    className: "w-full h-12 text-lg",
                    addonBefore: "₹"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2133,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2131,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Late Fee Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2145,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    value: addLateFeeAmount,
                    onChange: (e) => setAddLateFeeAmount(e.target.value),
                    placeholder: "Enter late fee amount (e.g., 200)",
                    min: 0,
                    step: 0.01,
                    className: "w-full h-12 text-lg",
                    addonBefore: "₹"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                    lineNumber: 2146,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2144,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 2129,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Alert,
              {
                message: "Important Notice",
                description: "The penalty and late fee amounts will be added to the customer's account. This action cannot be undone. Please verify the amounts before proceeding.",
                type: "warning",
                showIcon: true,
                className: "mb-4"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                lineNumber: 2159,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "large",
                  className: "flex-1",
                  onClick: () => {
                    setAddPenaltyDetails(null);
                    setAddPenaltyAmount("");
                    setAddLateFeeAmount("");
                  },
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2168,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  size: "large",
                  className: "flex-1",
                  disabled: addPenaltyLoading || !addPenaltyAmount && !addLateFeeAmount,
                  onClick: handleSavePenalty,
                  loading: addPenaltyLoading,
                  children: "Add Penalty"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
                  lineNumber: 2179,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
              lineNumber: 2167,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
            lineNumber: 2093,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
          lineNumber: 2071,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
        lineNumber: 2056,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx",
    lineNumber: 960,
    columnNumber: 5
  }, this);
};
_s(PenaltyMonitor, "RIRDtXgMQ0ZDv623p0fDh6e87Sc=", false, function() {
  return [useNavigate];
});
_c = PenaltyMonitor;
export default PenaltyMonitor;
var _c;
$RefreshReg$(_c, "PenaltyMonitor");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyMonitor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNFBvQixTQXVoQ1YsVUF2aENVOzJCQTVQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxVQUFVQyxlQUFlO0FBQzdDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0I7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxzQkFBc0I7QUFDL0IsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxtQkFBbUI7QUFFNUIsTUFBTSxFQUFFQyxZQUFZLElBQUl4QztBQUN4QixNQUFNLEVBQUV5QyxPQUFPLElBQUlsRDtBQUNuQixNQUFNLEVBQUVtRCxPQUFPQyxLQUFLLElBQUlsQztBQUV4QixNQUFNbUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTUMsV0FBV1AsWUFBWTtBQUM3QixRQUFNLENBQUNRLFlBQVlDLGFBQWEsSUFBSTlELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMrRCxlQUFlQyxnQkFBZ0IsSUFBSWhFLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNpRSxXQUFXQyxZQUFZLElBQUlsRSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDbUUsYUFBYUMsY0FBYyxJQUFJcEUsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3FFLFVBQVVDLFdBQVcsSUFBSXRFLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN1RSxRQUFRQyxTQUFTLElBQUl4RSxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDeUUseUJBQXlCQywwQkFBMEIsSUFBSTFFLFNBQVMsSUFBSTtBQUMzRSxRQUFNLENBQUMyRSx5QkFBeUJDLDBCQUEwQixJQUFJNUUsU0FBUyxFQUFFO0FBQ3pFLFFBQU0sQ0FBQzZFLHlCQUF5QkMsMEJBQTBCLElBQUk5RSxTQUFTLEtBQUs7QUFDNUUsUUFBTSxDQUFDK0UsNEJBQTRCQyw2QkFBNkIsSUFBSWhGLFNBQVMsS0FBSztBQUdsRixRQUFNLENBQUNpRixnQkFBZ0JDLGlCQUFpQixJQUFJbEYsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ21GLGVBQWVDLGdCQUFnQixJQUFJcEYsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3FGLGtCQUFrQkMsbUJBQW1CLElBQUl0RixTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDdUYsa0JBQWtCQyxtQkFBbUIsSUFBSXhGLFNBQVMsS0FBSztBQUc5RCxRQUFNLENBQUN5RixjQUFjQyxlQUFlLElBQUkxRixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDMkYsV0FBV0MsWUFBWSxJQUFJNUYsU0FBUyxFQUFFNkYsTUFBTSxPQUFPQyxNQUFNLEtBQUssQ0FBQztBQUd0RSxRQUFNLENBQUNDLHFCQUFxQkMsc0JBQXNCLElBQUloRyxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDaUcsd0JBQXdCQyx5QkFBeUIsSUFBSWxHLFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUNtRyxzQkFBc0JDLHVCQUF1QixJQUFJcEcsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ3FHLG9CQUFvQkMscUJBQXFCLElBQUl0RyxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDdUcsc0JBQXNCQyx1QkFBdUIsSUFBSXhHLFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUN5RyxnQkFBZ0JDLGlCQUFpQixJQUFJMUcsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQzJHLHNCQUFzQkMsdUJBQXVCLElBQUk1RyxTQUFTLElBQUk7QUFDckUsUUFBTSxDQUFDNkcscUJBQXFCQyxzQkFBc0IsSUFBSTlHLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUMrRyxlQUFlQyxnQkFBZ0IsSUFBSWhILFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNpSCxrQkFBa0JDLG1CQUFtQixJQUFJbEgsU0FBUyxDQUFDO0FBRzFELFFBQU0sQ0FBQ21ILHNCQUFzQkMsdUJBQXVCLElBQUlwSCxTQUFTLEtBQUs7QUFDdEUsUUFBTSxDQUFDcUgsdUJBQXVCQyx3QkFBd0IsSUFBSXRILFNBQVMsRUFBRTtBQUNyRSxRQUFNLENBQUN1SCwwQkFBMEJDLDJCQUEyQixJQUFJeEgsU0FBUyxFQUFFO0FBQzNFLFFBQU0sQ0FBQ3lILHdCQUF3QkMseUJBQXlCLElBQUkxSCxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDMkgsbUJBQW1CQyxvQkFBb0IsSUFBSTVILFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUM2SCxrQkFBa0JDLG1CQUFtQixJQUFJOUgsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQytILGtCQUFrQkMsbUJBQW1CLElBQUloSSxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDaUksbUJBQW1CQyxvQkFBb0IsSUFBSWxJLFNBQVMsS0FBSztBQUVoRSxRQUFNbUksZUFBZSxDQUFDLEdBQUcsSUFBSUMsSUFBSW5FLFVBQVVvRSxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLFNBQVMsQ0FBQyxDQUFDO0FBR25FLFFBQU1DLGtCQUFrQnZJLFFBQVEsTUFBTTtBQUNwQyxRQUFJLENBQUM4RixvQkFBcUIsUUFBTztBQUNqQyxVQUFNMEMsWUFBWSxvQkFBSUMsSUFBSTtBQUMxQnpFLGNBQ0cwRSxPQUFPLENBQUFMLE1BQUtBLEVBQUVDLGNBQWN4QyxtQkFBbUIsRUFDL0M2QyxRQUFRLENBQUFOLE1BQUtHLFVBQVVJLElBQUlQLEVBQUVRLFVBQVVSLENBQUMsQ0FBQztBQUM1QyxXQUFPUyxNQUFNQyxLQUFLUCxVQUFVUSxPQUFPLENBQUM7QUFBQSxFQUN0QyxHQUFHLENBQUNoRixXQUFXOEIsbUJBQW1CLENBQUM7QUFFbkMsUUFBTW1ELGdCQUFnQmpKLFFBQVEsTUFBTTtBQUNsQyxRQUFJLENBQUNnRyx1QkFBd0IsUUFBTztBQUNwQyxVQUFNa0QsT0FBT2xGLFVBQVVtRjtBQUFBQSxNQUNyQixDQUFBZCxNQUFLQSxFQUFFQyxjQUFjeEMsdUJBQXVCdUMsRUFBRVEsYUFBYTdDO0FBQUFBLElBQzdEO0FBQ0EsV0FBT2tELE9BQU8sQ0FBQ0EsS0FBS0UsY0FBYyxJQUFJO0FBQUEsRUFDeEMsR0FBRyxDQUFDcEYsV0FBVzhCLHFCQUFxQkUsc0JBQXNCLENBQUM7QUFHM0QsUUFBTXFELDRCQUE0QnJKLFFBQVEsTUFBTTtBQUM5QyxRQUFJLENBQUNvSCxzQkFBdUIsUUFBTztBQUNuQyxVQUFNb0IsWUFBWSxvQkFBSUMsSUFBSTtBQUMxQnpFLGNBQ0cwRSxPQUFPLENBQUFMLE1BQUtBLEVBQUVDLGNBQWNsQixxQkFBcUIsRUFDakR1QixRQUFRLENBQUFOLE1BQUtHLFVBQVVJLElBQUlQLEVBQUVRLFVBQVVSLENBQUMsQ0FBQztBQUM1QyxXQUFPUyxNQUFNQyxLQUFLUCxVQUFVUSxPQUFPLENBQUM7QUFBQSxFQUN0QyxHQUFHLENBQUNoRixXQUFXb0QscUJBQXFCLENBQUM7QUFFckMsUUFBTWtDLDBCQUEwQnRKLFFBQVEsTUFBTTtBQUM1QyxRQUFJLENBQUNzSCx5QkFBMEIsUUFBTztBQUN0QyxVQUFNNEIsT0FBT2xGLFVBQVVtRjtBQUFBQSxNQUNyQixDQUFBZCxNQUFLQSxFQUFFQyxjQUFjbEIseUJBQXlCaUIsRUFBRVEsYUFBYXZCO0FBQUFBLElBQy9EO0FBQ0EsV0FBTzRCLE9BQU8sQ0FBQ0EsS0FBS0UsY0FBYyxJQUFJO0FBQUEsRUFDeEMsR0FBRyxDQUFDcEYsV0FBV29ELHVCQUF1QkUsd0JBQXdCLENBQUM7QUFFL0QsUUFBTWlDLGdCQUFnQnZKLFFBQVEsTUFBTTtBQUNsQyxXQUFPMkI7QUFBQUEsTUFDTHFDLFVBQVUwRSxPQUFPLENBQUNMLE1BQU07QUFDdEIsY0FBTW1CLGFBQWF0RixjQUFjbUUsRUFBRUMsY0FBY3BFLGNBQWM7QUFDL0QsY0FBTXVGLGlCQUFpQixJQUFJQyxLQUFLckIsRUFBRW9CLGNBQWM7QUFDaEQsY0FBTUUsZ0JBQWdCdkYsV0FBV3FGLGtCQUFrQixJQUFJQyxLQUFLdEYsUUFBUSxJQUFJO0FBQ3hFLGNBQU13RixjQUFjdEYsU0FBU21GLGtCQUFrQixJQUFJQyxLQUFLcEYsTUFBTSxJQUFJO0FBQ2xFLGVBQU9rRixjQUFjRyxpQkFBaUJDO0FBQUFBLE1BQ3hDLENBQUM7QUFBQSxNQUNEaEc7QUFBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDSSxXQUFXRSxhQUFhRSxVQUFVRSxRQUFRVixVQUFVLENBQUM7QUFHekQsUUFBTWlHLFlBQVksWUFBWTtBQUM1QixRQUFJO0FBQ0Y5Rix1QkFBaUIsSUFBSTtBQUVyQixZQUFNK0Ysa0JBQWtCLE1BQU03SixJQUFJOEosSUFBSSw2QkFBNkI7QUFFbkUsVUFBSSxDQUFDRCxnQkFBZ0JFLE1BQU1DLFdBQVcsQ0FBQ0gsZ0JBQWdCRSxNQUFNQSxNQUFNO0FBQ2pFekosZ0JBQVEySixNQUFNLHFDQUFxQztBQUNuRDtBQUFBLE1BQ0Y7QUFFQSxZQUFNQyxpQkFBaUJMLGdCQUFnQkUsS0FBS0E7QUFHNUMsWUFBTUksaUJBQWlCLE1BQU1uSyxJQUFJOEosSUFBSSw0QkFBNEI7QUFHakUsWUFBTU0saUJBQWlCLG9CQUFJNUIsSUFBSTtBQUMvQixVQUFJMkIsZUFBZUosTUFBTTtBQUN2QixtQkFBV00sV0FBV0YsZUFBZUosTUFBTTtBQUN6QyxjQUFJTSxTQUFTTixNQUFNO0FBQ2pCLHVCQUFXQSxRQUFRTSxRQUFRTixNQUFNO0FBQy9CLGtCQUFJQSxNQUFNTyxZQUFZQyxPQUFPO0FBQzNCLHNCQUFNQyxVQUFVQyxPQUFPVixLQUFLTyxXQUFXQyxNQUFNRyxHQUFHO0FBQ2hELHNCQUFNQyxTQUFTRixPQUFPSixRQUFRSyxHQUFHO0FBQ2pDLHNCQUFNRSxTQUFTSCxPQUFPVixLQUFLYyxTQUFTRCxVQUFVLEVBQUUsRUFBRUUsS0FBSztBQUV2RFYsK0JBQWV6QixJQUFJLEdBQUdnQyxNQUFNLElBQUlILE9BQU8sSUFBSUksTUFBTSxJQUFJO0FBQUEsa0JBQ25EaEMsVUFBVXlCLFFBQVF6QjtBQUFBQSxrQkFDbEJtQyxXQUFXVixRQUFRVztBQUFBQSxrQkFDbkJDLFlBQVlaLFFBQVFhO0FBQUFBLGtCQUNwQjFCLGdCQUFnQk8sS0FBS08sV0FBV2EsV0FBV0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsa0JBQzVEQyxVQUFVdEIsS0FBS3NCLGFBQWE7QUFBQSxnQkFDOUIsQ0FBQztBQUFBLGNBQ0g7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBR0EsWUFBTUMsWUFBWTtBQUNsQixVQUFJQyxRQUFRO0FBRVosaUJBQVdDLGVBQWV0QixnQkFBZ0I7QUFDeEMsY0FBTVMsU0FBU0YsT0FBT2UsWUFBWUMsT0FBTztBQUN6QyxjQUFNakIsVUFBVUMsT0FBT2UsWUFBWUUsUUFBUTtBQUMzQyxjQUFNZCxTQUFTSCxPQUFPZSxZQUFZRyxpQkFBaUIsRUFBRSxFQUFFYixLQUFLO0FBRzVELGNBQU1jLGNBQWN4QixlQUFlTixJQUFJLEdBQUdhLE1BQU0sSUFBSUgsT0FBTyxJQUFJSSxNQUFNLEVBQUU7QUFFdkUsWUFBSSxDQUFDZ0IsWUFBYTtBQUVsQixjQUFNQyxVQUFVTCxZQUFZSyxXQUFXLENBQUM7QUFHeEMsY0FBTUMsaUJBQWlCRCxRQUFRRSxrQkFBa0I7QUFDakQsY0FBTUMsYUFBYUgsUUFBUUksY0FBYztBQUN6QyxjQUFNQyxVQUFVTCxRQUFRTSxnQ0FBZ0M7QUFDeEQsY0FBTUMsZUFBZVAsUUFBUVEsaUJBQWlCO0FBQzlDLGNBQU1DLGVBQWVULFFBQVFVLDhCQUE4QjtBQUMzRCxjQUFNQyxZQUFZWCxRQUFRWSw2QkFBNkI7QUFDdkQsY0FBTUMsaUJBQWlCTixlQUFlSSxhQUFhWCxRQUFRYyxrQkFBa0I7QUFDN0UsY0FBTUMsZ0JBQWdCZixRQUFRYyxrQkFBa0I7QUFDaEQsY0FBTUUsZ0JBQWdCaEIsUUFBUWlCLG1CQUFtQjtBQUVqRCxjQUFNQyxzQkFBc0JYLGVBQWVFO0FBQzNDLGNBQU1VLHdCQUF3QmxCLGlCQUFpQkU7QUFHL0MsY0FBTXhDLGlCQUFpQjdILE9BQU9pSyxZQUFZcEMsY0FBYztBQUN4RCxjQUFNeUQsUUFBUXRMLE9BQU8sRUFBRXVMLFFBQVEsS0FBSztBQUNwQyxjQUFNQyxrQkFBa0JDLE9BQU81QixZQUFZNkIscUJBQXFCLEVBQUU7QUFDbEUsY0FBTUMsYUFBYTlELGVBQWUrRCxNQUFNLEVBQUVDLElBQUlMLGlCQUFpQixNQUFNLEVBQUVELFFBQVEsS0FBSztBQUVwRixZQUFJTyxrQkFBa0I7QUFDdEIsWUFBSUMscUJBQXFCO0FBQ3pCLGNBQU1DLGVBQWVuQyxhQUFhb0MsUUFBUW5GLE9BQU8sQ0FBQ29GLE1BQU1BLEVBQUVDLGlCQUFpQixJQUFJLEtBQUs7QUFFcEYsWUFBSUgsYUFBYUksU0FBUyxHQUFHO0FBQzNCLGNBQUlkLE1BQU1lLGVBQWVWLFlBQVksS0FBSyxHQUFHO0FBQzNDRyw4QkFBa0I7QUFBQSxVQUNwQixPQUFPO0FBQ0xDLGlDQUFxQjtBQUFBLFVBQ3ZCO0FBQUEsUUFDRjtBQUVBLGNBQU1PLGtCQUNKLHVCQUFDLFNBQU0sTUFBSyxTQUNWO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxNQUFNLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQUNsQixNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQ1BDO0FBQUFBLGNBQ0V2RDtBQUFBQSxjQUNBSDtBQUFBQSxjQUNBb0IsWUFBWWhEO0FBQUFBLGNBQ1o0QyxZQUFZMkM7QUFBQUEsY0FDWjNDO0FBQUFBLFlBQ0Y7QUFBQSxZQUNEO0FBQUE7QUFBQSxVQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFHRixjQUFNNEMsYUFBYTtBQUFBLFVBQ2pCMUQsS0FBS2MsWUFBWTZDO0FBQUFBLFVBQ2pCMUQ7QUFBQUEsVUFDQUg7QUFBQUEsVUFDQThELE9BQU8vQztBQUFBQSxVQUNQM0MsVUFBVWdELFlBQVloRDtBQUFBQSxVQUN0Qm1DLFdBQVdhLFlBQVliO0FBQUFBLFVBQ3ZCRSxZQUFZVyxZQUFZWDtBQUFBQSxVQUN4QmU7QUFBQUEsVUFDQTdDLGdCQUFnQnlCO0FBQUFBLFVBQ2hCa0I7QUFBQUEsVUFDQXpELFdBQVdtRCxZQUFZMkM7QUFBQUEsVUFDdkIzRSxnQkFBZ0JvQyxZQUFZcEM7QUFBQUEsVUFDNUIrRSxlQUFlekM7QUFBQUEsVUFDZkk7QUFBQUEsVUFDQVE7QUFBQUEsVUFDQUY7QUFBQUEsVUFDQUo7QUFBQUEsVUFDQUU7QUFBQUEsVUFDQVU7QUFBQUEsVUFDQXdCLGlCQUFpQnBDO0FBQUFBLFVBQ2pCVztBQUFBQSxVQUNBSDtBQUFBQSxVQUNBQztBQUFBQSxVQUNBNEIsU0FBU1I7QUFBQUEsVUFDVFMsV0FBV2pCLGtCQUNULHVCQUFDLE9BQUksT0FBTSxVQUFTLGlDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQyxJQUNuQ0MscUJBQ0YsdUJBQUMsT0FBSSxPQUFNLFFBQU8sa0NBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DLElBQ2xDOUIsWUFBWVAsV0FDZCx1QkFBQyxPQUFJLE9BQU0sV0FBVSxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CLEdBQUssc0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFFQSx1QkFBQyxPQUFJLE9BQU0sU0FBUSxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CLEdBQUsseUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVGb0M7QUFBQUEsVUFDQUM7QUFBQUEsVUFDQWlCLHFCQUFxQnZDLGVBQWUsS0FBS0UsZUFBZTtBQUFBLFVBQ3hEYTtBQUFBQSxRQUNGO0FBRUE3QixrQkFBVXNELEtBQUtSLFVBQVU7QUFDekI3QztBQUFBQSxNQUNGO0FBRUF2SCxtQkFBYXNILFNBQVM7QUFBQSxJQUN4QixTQUFTckIsT0FBTztBQUNkNEUsY0FBUTVFLE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDM0osY0FBUTJKLE1BQU0scUNBQXFDO0FBQUEsSUFDckQsVUFBQztBQUNDbkcsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0wsd0JBQXdCLFlBQVk7QUFDeEMsUUFBSTtBQUNGbEssaUNBQTJCLElBQUk7QUFDL0IsWUFBTW1LLE1BQU0sTUFBTS9PLElBQUk4SixJQUFJLCtCQUErQjtBQUN6RCxVQUFJaUYsSUFBSWhGLEtBQUtDLFNBQVM7QUFDcEJ4RixtQ0FBMkJ1SyxLQUFLaEYsTUFBTThCLE9BQU87QUFDN0NuSCxtQ0FBMkJxSyxLQUFLaEYsTUFBTWlGLFdBQVcsRUFBRTtBQUFBLE1BQ3JEO0FBQUEsSUFDRixTQUFTQyxLQUFLO0FBQ1ozTyxjQUFRMkosTUFBTSwrQ0FBK0M7QUFDN0Q0RSxjQUFRNUUsTUFBTWdGLEdBQUc7QUFBQSxJQUNuQixVQUFDO0FBQ0NySyxpQ0FBMkIsS0FBSztBQUFBLElBQ2xDO0FBQUEsRUFDRjtBQUVBL0UsWUFBVSxNQUFNO0FBQ2QrSixjQUFVO0FBQ1ZrRiwwQkFBc0I7QUFBQSxFQUN4QixHQUFHLEVBQUU7QUFFTGpQLFlBQVUsTUFBTTtBQUNkLFVBQU1xUCxnQkFBZ0JBLENBQUNDLE1BQU07QUFDM0IsVUFBSSxDQUFDLFNBQVMsWUFBWSxRQUFRLEVBQUVDLFNBQVNELEVBQUVFLE9BQU9DLE9BQU8sRUFBRztBQUNoRSxVQUFJSCxFQUFFSSxXQUFXSixFQUFFSyxZQUFZTCxFQUFFTSxJQUFJQyxZQUFZLE1BQU0sS0FBSztBQUMxRFAsVUFBRVEsZUFBZTtBQUNqQmpNLGlCQUFTLG1CQUFtQjtBQUFBLE1BQzlCO0FBQUEsSUFDRjtBQUNBa00sV0FBT0MsaUJBQWlCLFdBQVdYLGFBQWE7QUFDaEQsV0FBTyxNQUFNVSxPQUFPRSxvQkFBb0IsV0FBV1osYUFBYTtBQUFBLEVBQ2xFLEdBQUcsQ0FBQ3hMLFFBQVEsQ0FBQztBQUdiLFFBQU0sQ0FBQ3FNLFFBQVFDLFNBQVMsSUFBSWxRLFNBQVM7QUFBQSxJQUNuQ21RLGdCQUFnQjtBQUFBLElBQ2hCQyxhQUFhO0FBQUEsSUFDYjNCLGVBQWU7QUFBQSxJQUNmNEIsV0FBVztBQUFBLElBQ1hDLGNBQWM7QUFBQSxJQUNkaEUsY0FBYztBQUFBLElBQ2RFLGNBQWM7QUFBQSxJQUNkK0QscUJBQXFCO0FBQUEsSUFDckJDLGdCQUFnQjtBQUFBLElBQ2hCQyxjQUFjO0FBQUEsSUFDZEMsNEJBQTRCO0FBQUEsSUFDNUJDLDZCQUE2QjtBQUFBLElBQzdCQyx3QkFBd0I7QUFBQSxJQUN4QkMsb0JBQW9CO0FBQUEsSUFDcEJDLG9CQUFvQjtBQUFBLEVBQ3RCLENBQUM7QUFFRC9RLFlBQVUsTUFBTTtBQUNkLFVBQU1nUixvQkFBb0IsSUFBSTNJLElBQUlvQixjQUFjbkIsSUFBSSxDQUFBQyxNQUFLQSxFQUFFdUMsTUFBTSxDQUFDO0FBQ2xFLFVBQU1zRixpQkFBaUJZLGtCQUFrQkM7QUFDekMsVUFBTUMsV0FBVyxJQUFJN0ksSUFBSW9CLGNBQWNuQixJQUFJLENBQUNjLFNBQVNBLEtBQUtaLFNBQVMsQ0FBQztBQUNwRSxVQUFNNkgsY0FBY2pNLGNBQWMsSUFBSThNLFNBQVNEO0FBQy9DLFVBQU12QyxnQkFBZ0JqRixjQUFjMEgsT0FBTyxDQUFDQyxLQUFLN0ksTUFBTTZJLE9BQU83SSxFQUFFbUcsaUJBQWlCLElBQUksQ0FBQztBQUN0RixVQUFNNEIsWUFBWTdHLGNBQWMwSCxPQUFPLENBQUNDLEtBQUs3SSxNQUFNNkksT0FBTzdJLEVBQUU0RCxjQUFjLElBQUksQ0FBQztBQUMvRSxVQUFNb0UsZUFBZTlHLGNBQWMwSCxPQUFPLENBQUNDLEtBQUs3SSxNQUFNNkksT0FBTzdJLEVBQUU4RCxXQUFXLElBQUksQ0FBQztBQUMvRSxVQUFNc0UsNkJBQTZCbEgsY0FBYzBILE9BQU8sQ0FBQ0MsS0FBSzdJLE1BQU02SSxPQUFPN0ksRUFBRTRFLHlCQUF5QixJQUFJLENBQUM7QUFDM0csVUFBTXlELDhCQUE4Qm5ILGNBQWMwSCxPQUFPLENBQUNDLEtBQUs3SSxNQUFNNkksT0FBTzdJLEVBQUU4RCxXQUFXLElBQUksQ0FBQztBQUM5RixVQUFNRSxlQUFlOUMsY0FBYzBILE9BQU8sQ0FBQ0MsS0FBSzdJLE1BQU02SSxPQUFPN0ksRUFBRWdFLGdCQUFnQixJQUFJLENBQUM7QUFDcEYsVUFBTUUsZUFBZWhELGNBQWMwSCxPQUFPLENBQUNDLEtBQUs3SSxNQUFNNkksT0FBTzdJLEVBQUVrRSxnQkFBZ0IsSUFBSSxDQUFDO0FBQ3BGLFVBQU1vRSx5QkFBeUJ0RSxlQUFlRTtBQUM5QyxVQUFNK0Qsc0JBQXNCL0csY0FBYzBILE9BQU8sQ0FBQ0MsS0FBSzdJLE1BQU02SSxPQUFPN0ksRUFBRXNFLGtCQUFrQixJQUFJLENBQUM7QUFDN0YsVUFBTTRELGlCQUFpQmhILGNBQWMwSCxPQUFPLENBQUNDLEtBQUs3SSxNQUFNNkksT0FBTzdJLEVBQUVvRSxhQUFhLElBQUksQ0FBQztBQUNuRixVQUFNbUUscUJBQXFCckgsY0FBYzBILE9BQU8sQ0FBQ0MsS0FBSzdJLE1BQU02SSxPQUFPN0ksRUFBRXdFLGlCQUFpQixJQUFJLENBQUM7QUFDM0YsVUFBTWdFLHFCQUFxQnRILGNBQWMwSCxPQUFPLENBQUNDLEtBQUs3SSxNQUFNNkksT0FBTzdJLEVBQUV5RSxpQkFBaUIsSUFBSSxDQUFDO0FBQzNGLFVBQU0wRCxlQUFlakgsY0FBY3lFO0FBRW5DaUMsY0FBVTtBQUFBLE1BQ1JDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0EzQjtBQUFBQSxNQUNBNEI7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQWhFO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0ErRDtBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ3RILGVBQWVyRixXQUFXLENBQUM7QUFHL0IsUUFBTWlLLHNCQUFzQixPQUFPdkQsUUFBUUgsU0FBUzVCLFVBQVVQLFdBQVc2SSxvQkFBb0IsU0FBUztBQUNwRyxRQUFJO0FBQ0Y1TCwwQkFBb0IsSUFBSTtBQUN4QkYsMEJBQW9CLEVBQUV3RCxVQUFVUCxVQUFVLENBQUM7QUFDM0NyRCx3QkFBa0IsSUFBSTtBQUd0QixVQUFJd0csY0FBYzBGO0FBQ2xCLFVBQUksQ0FBQzFGLGFBQWE7QUFDaEIsY0FBTXVELE1BQU0sTUFBTS9PLElBQUk4SixJQUFJLCtCQUErQjtBQUFBLFVBQ3ZEcUgsUUFBUSxFQUFFMUYsU0FBU2QsUUFBUWUsVUFBVWxCLFFBQVE7QUFBQSxRQUMvQyxDQUFDO0FBQ0QsWUFBSXVFLElBQUloRixNQUFNQyxXQUFXK0UsSUFBSWhGLE1BQU1BLE1BQU1nRSxTQUFTLEdBQUc7QUFDbkR2Qyx3QkFBY3VELElBQUloRixLQUFLQSxLQUFLLENBQUM7QUFBQSxRQUMvQjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLENBQUN5QixlQUFlLENBQUNBLFlBQVlvQyxRQUFRO0FBQ3ZDdE4sZ0JBQVEySixNQUFNLHFDQUFxQztBQUNuRDtBQUFBLE1BQ0Y7QUFFQS9FLHVCQUFpQnNHLFlBQVlvQyxNQUFNO0FBQUEsSUFDckMsU0FBU3FCLEtBQUs7QUFDWkosY0FBUTVFLE1BQU1nRixHQUFHO0FBQ2pCM08sY0FBUTJKLE1BQU0sa0NBQWtDO0FBQUEsSUFDbEQsVUFBQztBQUNDM0UsMEJBQW9CLEtBQUs7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNOEwseUJBQXlCQSxDQUFDQyxtQkFBbUJsRSxrQkFBa0IsT0FBTztBQUMxRSxVQUFNM0QsaUJBQWlCN0gsT0FBTzBQLGlCQUFpQjtBQUMvQyxVQUFNcEUsUUFBUXRMLE9BQU8sRUFBRXVMLFFBQVEsS0FBSztBQUNwQyxVQUFNb0UsV0FBVzlILGVBQWUrRCxNQUFNLEVBQUVDLElBQUlMLGlCQUFpQixNQUFNO0FBQ25FLFdBQU9vRSxLQUFLQyxJQUFJLEdBQUdGLFNBQVNHLEtBQUt4RSxPQUFPLE1BQU0sQ0FBQztBQUFBLEVBQ2pEO0FBRUEsUUFBTXlFLG9CQUFvQkEsQ0FBQ0wsc0JBQXNCO0FBQy9DLFVBQU1NLFVBQVVoUSxPQUFPLEVBQUV1TCxRQUFRLE9BQU87QUFDeEMsVUFBTUQsUUFBUXRMLE9BQU87QUFDckIsV0FBTzRQLEtBQUtDLElBQUksR0FBR3ZFLE1BQU13RSxLQUFLRSxTQUFTLE1BQU0sQ0FBQztBQUFBLEVBQ2hEO0FBRUEsUUFBTUMscUJBQXFCLE9BQU8zSSxNQUFNckQsU0FBUztBQUMvQyxRQUFJO0FBQ0Y5Qix1QkFBaUIsSUFBSTtBQUNyQixZQUFNK04sVUFBVTtBQUFBLFFBQ2QsQ0FBQyxRQUFRLEdBQUc7QUFBQSxVQUNWQyxNQUFNO0FBQUEsWUFDSkMsUUFBUTtBQUFBLFlBQ1JuSixVQUFVSyxLQUFLTDtBQUFBQSxZQUNmUCxXQUFXWSxLQUFLWjtBQUFBQSxZQUNoQmMsZ0JBQWdCRixLQUFLRTtBQUFBQSxZQUNyQjZJLFVBQVUvSSxLQUFLc0Y7QUFBQUEsWUFDZnhELFdBQVc5QixLQUFLOEI7QUFBQUEsWUFDaEIsR0FBSW5GLFNBQVMsbUJBQW1CO0FBQUEsY0FDOUJxTSxlQUFlYix1QkFBdUJuSSxLQUFLTyxnQkFBZ0JQLEtBQUtrRSxlQUFlO0FBQUEsWUFDakY7QUFBQSxZQUNBLEdBQUl2SCxTQUFTLHNCQUFzQjtBQUFBLGNBQ2pDc00saUJBQWlCakosS0FBS3VELGFBQWE7QUFBQSxjQUNuQ04sU0FBU2pELEtBQUtpRDtBQUFBQSxZQUNoQjtBQUFBLFlBQ0EsR0FBSXRHLFNBQVMsdUJBQXVCO0FBQUEsY0FDbEN1TSxVQUFVVCxrQkFBa0J6SSxLQUFLTyxjQUFjO0FBQUEsWUFDakQ7QUFBQSxZQUNBLEdBQUk1RCxTQUFTLHdCQUF3QjtBQUFBLGNBQ25Dd00sU0FBU25KLEtBQUtxRDtBQUFBQSxjQUNkK0YsU0FBU3BKLEtBQUt5RDtBQUFBQSxjQUNkUixTQUFTakQsS0FBS2lEO0FBQUFBLFlBQ2hCO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsVUFBSW9HLFdBQVc7QUFDZixjQUFRMU0sTUFBSTtBQUFBLFFBQ1YsS0FBSztBQUFpQjBNLHFCQUFXO0FBQTZCO0FBQUEsUUFDOUQsS0FBSztBQUFvQkEscUJBQVc7QUFBZ0M7QUFBQSxRQUNwRSxLQUFLO0FBQXFCQSxxQkFBVztBQUEyQztBQUFBLFFBQ2hGLEtBQUs7QUFBc0JBLHFCQUFXO0FBQWtDO0FBQUEsUUFDeEU7QUFBUyxnQkFBTSxJQUFJQyxNQUFNLHVCQUF1QjtBQUFBLE1BQ2xEO0FBRUEsWUFBTXhELE1BQU0sTUFBTS9PLElBQUl3UyxLQUFLRixVQUFVVCxPQUFPO0FBQzVDLFlBQU0sRUFBRTdILFNBQVNDLE1BQU0sSUFBSThFLElBQUloRjtBQUMvQixVQUFJQyxVQUFVLEdBQUc7QUFDZjFKLGdCQUFRMEosUUFBUSxzQkFBc0JmLEtBQUtMLFFBQVEsRUFBRTtBQUFBLE1BQ3ZELE9BQU87QUFDTHRJLGdCQUFRMkosTUFBTSx1QkFBdUJoQixLQUFLTCxRQUFRLEVBQUU7QUFBQSxNQUN0RDtBQUFBLElBQ0YsU0FBU3FHLEtBQUs7QUFDWkosY0FBUTVFLE1BQU0sK0JBQStCZ0YsR0FBRztBQUNoRDNPLGNBQVEySixNQUFNLHVCQUF1QmhCLEtBQUtMLFFBQVEsRUFBRTtBQUFBLElBQ3RELFVBQUM7QUFDQzlFLHVCQUFpQixLQUFLO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBRUEsUUFBTTJPLHFCQUFxQixZQUFZO0FBQ3JDLFFBQUlsTixhQUFhd0ksV0FBVyxFQUFHO0FBQy9CaksscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNGLFlBQU0rTixVQUFVLENBQUM7QUFDakJ0TSxtQkFBYW1ELFFBQVEsQ0FBQ08sTUFBTXlKLFFBQVE7QUFDbENiLGdCQUFRLFFBQVFhLEdBQUcsRUFBRSxJQUFJO0FBQUEsVUFDdkJaLE1BQU07QUFBQSxZQUNKQyxRQUFRO0FBQUEsWUFDUm5KLFVBQVVLLEtBQUtMO0FBQUFBLFlBQ2ZQLFdBQVdZLEtBQUtaO0FBQUFBLFlBQ2hCYyxnQkFBZ0JGLEtBQUtFO0FBQUFBLFlBQ3JCNkksVUFBVS9JLEtBQUtzRjtBQUFBQSxZQUNmeEQsV0FBVzlCLEtBQUs4QjtBQUFBQSxZQUNoQixHQUFJdEYsVUFBVUcsU0FBUyxtQkFBbUI7QUFBQSxjQUN4Q3FNLGVBQWViLHVCQUF1Qm5JLEtBQUtPLGdCQUFnQlAsS0FBS2tFLGVBQWU7QUFBQSxZQUNqRjtBQUFBLFlBQ0EsR0FBSTFILFVBQVVHLFNBQVMsc0JBQXNCO0FBQUEsY0FDM0NzTSxpQkFBaUJqSixLQUFLdUQsYUFBYTtBQUFBLGNBQ25DTixTQUFTakQsS0FBS2lEO0FBQUFBLFlBQ2hCO0FBQUEsWUFDQSxHQUFJekcsVUFBVUcsU0FBUyx1QkFBdUI7QUFBQSxjQUM1Q3VNLFVBQVVULGtCQUFrQnpJLEtBQUtPLGNBQWM7QUFBQSxZQUNqRDtBQUFBLFlBQ0EsR0FBSS9ELFVBQVVHLFNBQVMsd0JBQXdCO0FBQUEsY0FDN0N3TSxTQUFTbkosS0FBS3FEO0FBQUFBLGNBQ2QrRixTQUFTcEosS0FBS3lEO0FBQUFBLGNBQ2RSLFNBQVNqRCxLQUFLaUQ7QUFBQUEsWUFDaEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUVELFVBQUlvRyxXQUFXO0FBQ2YsY0FBUTdNLFVBQVVHLE1BQUk7QUFBQSxRQUNwQixLQUFLO0FBQWlCME0scUJBQVc7QUFBNkI7QUFBQSxRQUM5RCxLQUFLO0FBQW9CQSxxQkFBVztBQUFnQztBQUFBLFFBQ3BFLEtBQUs7QUFBcUJBLHFCQUFXO0FBQTJDO0FBQUEsUUFDaEYsS0FBSztBQUFzQkEscUJBQVc7QUFBa0M7QUFBQSxRQUN4RTtBQUFTLGdCQUFNLElBQUlDLE1BQU0sdUJBQXVCO0FBQUEsTUFDbEQ7QUFFQSxZQUFNeEQsTUFBTSxNQUFNL08sSUFBSXdTLEtBQUtGLFVBQVVULE9BQU87QUFDNUMsWUFBTSxFQUFFN0gsU0FBU0MsTUFBTSxJQUFJOEUsSUFBSWhGO0FBQy9CekosY0FBUTBKLFFBQVEsS0FBS0EsT0FBTyx1QkFBdUJDLEtBQUssVUFBVTtBQUNsRXZFLG1CQUFhLEVBQUVDLE1BQU0sT0FBT0MsTUFBTSxLQUFLLENBQUM7QUFDeENKLHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsU0FBU3lKLEtBQUs7QUFDWkosY0FBUTVFLE1BQU0sd0JBQXdCZ0YsR0FBRztBQUN6QzNPLGNBQVEySixNQUFNLG9EQUFvRDtBQUFBLElBQ3BFLFVBQUM7QUFDQ25HLHVCQUFpQixLQUFLO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBRUEsUUFBTTZPLGdCQUFnQkEsQ0FBQy9NLFNBQVM7QUFDOUJGLGlCQUFhLEVBQUVDLE1BQU0sTUFBTUMsS0FBSyxDQUFDO0FBQUEsRUFDbkM7QUFHQSxRQUFNZ04sb0JBQW9CQSxDQUFDQyxVQUFVO0FBQ25DL00sMkJBQXVCK00sU0FBUyxFQUFFO0FBQ2xDN00sOEJBQTBCLEVBQUU7QUFDNUJFLDRCQUF3QixFQUFFO0FBQUEsRUFDNUI7QUFDQSxRQUFNNE0sdUJBQXVCQSxDQUFDRCxVQUFVO0FBQ3RDN00sOEJBQTBCNk0sU0FBUyxFQUFFO0FBQ3JDM00sNEJBQXdCLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFFBQU02TSxxQkFBcUJBLENBQUNGLFVBQVU7QUFDcEMzTSw0QkFBd0IyTSxLQUFLO0FBQUEsRUFDL0I7QUFFQSxRQUFNRywwQkFBMEJBLENBQUNwTixTQUFTO0FBQ3hDLFFBQUlxTixZQUFZO0FBQ2hCLFlBQVFyTixNQUFJO0FBQUEsTUFDVixLQUFLO0FBQVlxTixvQkFBWTFNLGVBQWUrRjtBQUFjO0FBQUEsTUFDMUQsS0FBSztBQUFXMkcsb0JBQVkxTSxlQUFlbUc7QUFBZ0I7QUFBQSxNQUMzRCxLQUFLO0FBQWN1RyxvQkFBWTFNLGVBQWVpRztBQUFXO0FBQUEsTUFDekQsS0FBSztBQUFPeUcsb0JBQVkxTSxlQUFlK0YsZUFBZS9GLGVBQWVtRyxpQkFBaUJuRyxlQUFlaUc7QUFBVztBQUFBLE1BQ2hIO0FBQVN5RyxvQkFBWTtBQUFBLElBQ3ZCO0FBQ0FqTSx3QkFBb0JpTSxTQUFTO0FBQzdCbk0scUJBQWlCLEVBQUU7QUFDbkJKLDRCQUF3QmQsSUFBSTtBQUM1QmdCLDJCQUF1QixJQUFJO0FBQzNCTiw0QkFBd0IsS0FBSztBQUFBLEVBQy9CO0FBRUEsUUFBTTRNLHNCQUFzQixZQUFZO0FBQ3RDLFVBQU1DLFNBQVNDLFdBQVd2TSxhQUFhO0FBQ3ZDLFFBQUksQ0FBQ3NNLFVBQVVBLFVBQVUsS0FBS0EsU0FBU3BNLGtCQUFrQjtBQUN2RHpHLGNBQVEySixNQUFNLG1DQUFtQ2xELGlCQUFpQnNNLFFBQVEsQ0FBQyxDQUFDLEdBQUc7QUFDL0U7QUFBQSxJQUNGO0FBQ0EsUUFBSTtBQUNGdlAsdUJBQWlCLElBQUk7QUFDckIsWUFBTStOLFVBQVU7QUFBQSxRQUNkcEcsU0FBU2xGLGVBQWVvRTtBQUFBQSxRQUN4QmUsVUFBVW5GLGVBQWVpRTtBQUFBQSxRQUN6QkksUUFBUXJFLGVBQWU0QztBQUFBQSxRQUN2QmdLO0FBQUFBLFFBQ0F2TixNQUFNYTtBQUFBQSxNQUNSO0FBQ0EsWUFBTXpHLElBQUl3UyxLQUFLLDJCQUEyQlgsT0FBTztBQUNqRHZSLGNBQVEwSixRQUFRLDBDQUEwQztBQUMxRHBELDZCQUF1QixLQUFLO0FBQzVCZ0QsZ0JBQVU7QUFBQSxJQUNaLFNBQVNxRixLQUFLO0FBQ1pKLGNBQVE1RSxNQUFNLG1CQUFtQmdGLEdBQUc7QUFDcEMzTyxjQUFRMkosTUFBTSw0QkFBNEI7QUFBQSxJQUM1QyxVQUFDO0FBQ0NuRyx1QkFBaUIsS0FBSztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUdBLFFBQU13UCw4QkFBOEJBLENBQUNULFVBQVU7QUFDN0N6TCw2QkFBeUJ5TCxTQUFTLEVBQUU7QUFDcEN2TCxnQ0FBNEIsRUFBRTtBQUM5QkUsOEJBQTBCLEVBQUU7QUFBQSxFQUM5QjtBQUNBLFFBQU0rTCxpQ0FBaUNBLENBQUNWLFVBQVU7QUFDaER2TCxnQ0FBNEJ1TCxTQUFTLEVBQUU7QUFDdkNyTCw4QkFBMEIsRUFBRTtBQUFBLEVBQzlCO0FBQ0EsUUFBTWdNLCtCQUErQkEsQ0FBQ1gsVUFBVTtBQUM5Q3JMLDhCQUEwQnFMLEtBQUs7QUFBQSxFQUNqQztBQUVBLFFBQU1ZLG9CQUFvQixZQUFZO0FBQ3BDLFFBQUksQ0FBQ2hNLHFCQUFzQixDQUFDRSxvQkFBb0IsQ0FBQ0Usa0JBQW1CO0FBQ2xFdkgsY0FBUTJKLE1BQU0seURBQXlEO0FBQ3ZFO0FBQUEsSUFDRjtBQUNBLFFBQUk7QUFDRmpDLDJCQUFxQixJQUFJO0FBQ3pCLFlBQU02SixVQUFVO0FBQUEsUUFDZHBHLFNBQVNoRSxrQkFBa0JrRDtBQUFBQSxRQUMzQmUsVUFBVWpFLGtCQUFrQitDO0FBQUFBLFFBQzVCSSxRQUFRbkQsa0JBQWtCMEI7QUFBQUEsUUFDMUJ1SyxnQkFBZ0JOLFdBQVd6TCxnQkFBZ0IsS0FBSztBQUFBLFFBQ2hEZ00saUJBQWlCUCxXQUFXdkwsZ0JBQWdCLEtBQUs7QUFBQSxNQUNuRDtBQUNBLFlBQU03SCxJQUFJd1MsS0FBSywrQkFBK0JYLE9BQU87QUFDckR2UixjQUFRMEosUUFBUSwrQkFBK0I7QUFDL0M5Qyw4QkFBd0IsS0FBSztBQUM3QlEsMkJBQXFCLElBQUk7QUFDekJFLDBCQUFvQixFQUFFO0FBQ3RCRSwwQkFBb0IsRUFBRTtBQUN0QjhCLGdCQUFVO0FBQUEsSUFDWixTQUFTcUYsS0FBSztBQUNaSixjQUFRNUUsTUFBTSxzQkFBc0JnRixHQUFHO0FBQ3ZDM08sY0FBUTJKLE1BQU0seUJBQXlCO0FBQUEsSUFDekMsVUFBQztBQUNDakMsMkJBQXFCLEtBQUs7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEwsZUFBZUEsQ0FBQ2YsVUFDcEJ6RixPQUFPeUYsU0FBUyxDQUFDLEVBQUVnQixlQUFlLFNBQVM7QUFBQSxJQUN6Q0MsdUJBQXVCO0FBQUEsSUFDdkJDLHVCQUF1QjtBQUFBLEVBQ3pCLENBQUM7QUFHSCxRQUFNQyxVQUFVO0FBQUEsSUFDZDtBQUFBLE1BQ0V2RSxLQUFLO0FBQUEsTUFDTHdFLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDQyxNQUFNQyxRQUFRQyxVQUFVLHVCQUFDLFVBQUssV0FBVSw2QkFBNkJBLGtCQUFRLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxJQUMxRjtBQUFBLElBQ0E7QUFBQSxNQUNFNUUsS0FBSztBQUFBLE1BQ0x3RSxRQUFRO0FBQUEsTUFDUkMsUUFBUUEsQ0FBQ0MsU0FBUyx1QkFBQyxTQUFJLFdBQVUsNkJBQTZCQSxrQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRDtBQUFBLElBQ3JFO0FBQUEsSUFDQTtBQUFBLE1BQ0UxRSxLQUFLO0FBQUEsTUFDTHdFLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDQyxTQUNQLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLGlCQUFjLFdBQVUsMEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUM5Q0E7QUFBQUEsV0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxJQUVKO0FBQUEsSUFDQTtBQUFBLE1BQ0UxRSxLQUFLO0FBQUEsTUFDTHdFLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDQyxTQUFTLHVCQUFDLFVBQUssV0FBVSxtREFBbURBLGtCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsSUFDNUY7QUFBQSxJQUNBO0FBQUEsTUFDRTFFLEtBQUs7QUFBQSxNQUNMd0UsUUFBUTtBQUFBLE1BQ1JDLFFBQVFBLENBQUNDLFNBQVMsdUJBQUMsT0FBSSxPQUFNLFVBQVMsV0FBVSxlQUFlQSxrQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLElBQ3RFO0FBQUEsSUFDQTtBQUFBLE1BQ0UxRSxLQUFLO0FBQUEsTUFDTHdFLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDQyxTQUFTeFMsT0FBT3dTLElBQUksRUFBRUcsT0FBTyxZQUFZO0FBQUEsSUFDcEQ7QUFBQSxJQUNBO0FBQUEsTUFDRTdFLEtBQUs7QUFBQSxNQUNMd0UsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRXhFLEtBQUs7QUFBQSxNQUNMd0UsUUFBUTtBQUFBLE1BQ1JDLFFBQVFBLENBQUNDLFNBQ1AsdUJBQUMsVUFBSyxXQUFVLGdDQUErQjtBQUFBO0FBQUEsUUFDM0MvRyxPQUFPK0csUUFBUSxDQUFDLEVBQUVkLFFBQVEsQ0FBQyxFQUFFUSxlQUFlLE9BQU87QUFBQSxXQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUVKO0FBQUEsSUFDQTtBQUFBLE1BQ0VwRSxLQUFLO0FBQUEsTUFDTHdFLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDQyxTQUNQLHVCQUFDLFVBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLFFBQzVDL0csT0FBTytHLFFBQVEsQ0FBQyxFQUFFZCxRQUFRLENBQUMsRUFBRVEsZUFBZSxPQUFPO0FBQUEsV0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFFSjtBQUFBLElBQ0E7QUFBQSxNQUNFcEUsS0FBSztBQUFBLE1BQ0x3RSxRQUFRO0FBQUEsTUFDUkMsUUFBUUEsQ0FBQ0MsTUFBTUMsV0FBVztBQUN4QixjQUFNbEksVUFBVWtCLE9BQU9nSCxPQUFPcEgseUJBQXlCLENBQUM7QUFDeEQsZUFDRSx1QkFBQyxVQUFLLFdBQVcsaUJBQWlCZCxVQUFVLElBQUksaUJBQWlCLGdCQUFnQixJQUFJO0FBQUE7QUFBQSxVQUNqRkEsUUFBUW1ILFFBQVEsQ0FBQyxFQUFFUSxlQUFlLE9BQU87QUFBQSxhQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVKO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxNQUNFcEUsS0FBSztBQUFBLE1BQ0x3RSxRQUFRO0FBQUEsTUFDUkMsUUFBUUEsQ0FBQ0MsTUFBTUMsV0FDYix1QkFBQyxVQUFLLFdBQVUsaUNBQWdDO0FBQUE7QUFBQSxRQUM1Q2hILE9BQU9nSCxPQUFPaEksZ0JBQWdCLENBQUMsRUFBRWlILFFBQVEsQ0FBQyxFQUFFUSxlQUFlLE9BQU87QUFBQSxXQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUVKO0FBQUEsSUFDQTtBQUFBLE1BQ0VwRSxLQUFLO0FBQUEsTUFDTHdFLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDQyxTQUNQLHVCQUFDLFVBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLFFBQzVDL0csT0FBTytHLFFBQVEsQ0FBQyxFQUFFZCxRQUFRLENBQUMsRUFBRVEsZUFBZSxPQUFPO0FBQUEsV0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFFSjtBQUFBLElBQ0E7QUFBQSxNQUNFcEUsS0FBSztBQUFBLE1BQ0x3RSxRQUFRO0FBQUEsTUFDUkMsUUFBUUEsQ0FBQ0MsTUFBTUMsV0FDYix1QkFBQyxVQUFLLFdBQVUsOEJBQTZCO0FBQUE7QUFBQSxRQUN6Q2hILE9BQU9nSCxPQUFPckgsdUJBQXVCLENBQUMsRUFBRXNHLFFBQVEsQ0FBQyxFQUFFUSxlQUFlLE9BQU87QUFBQSxXQUQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUVKO0FBQUEsSUFDQTtBQUFBLE1BQ0VwRSxLQUFLO0FBQUEsTUFDTHdFLFFBQVE7QUFBQSxNQUNSQyxRQUFRQSxDQUFDQyxTQUFTO0FBQ2hCLGNBQU1qSSxVQUFVa0IsT0FBTytHLFFBQVEsQ0FBQztBQUNoQyxlQUNFLHVCQUFDLFVBQUssV0FBVyxpQkFBaUJqSSxVQUFVLElBQUksaUJBQWlCLGdCQUFnQixJQUFJO0FBQUE7QUFBQSxVQUNqRkEsUUFBUW1ILFFBQVEsQ0FBQyxFQUFFUSxlQUFlLE9BQU87QUFBQSxhQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVKO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxNQUNFcEUsS0FBSztBQUFBLE1BQ0x3RSxRQUFRO0FBQUEsTUFDUkMsUUFBUUEsQ0FBQ0MsTUFBTUMsV0FBV0EsT0FBTzNGO0FBQUFBLElBQ25DO0FBQUEsRUFBQztBQUdILFFBQU04RixtQkFBbUI7QUFBQSxJQUN2QjtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQVCxRQUFRQSxDQUFDQyxNQUFNUyxRQUNiQSxJQUFJOUcsZUFDRix1QkFBQyxPQUFJLE9BQU0sUUFBTyxPQUFPLEVBQUUrRyxZQUFZLE9BQU8sR0FBRyxrQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsVUFBSyxXQUFVLGVBQWVWLGtCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQUEsSUFFMUM7QUFBQSxJQUNBO0FBQUEsTUFDRUssT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYUCxRQUFRQSxDQUFDWSxHQUFHRixRQUNWQSxJQUFJOUcsZUFDRix1QkFBQyxVQUFLLE9BQU8sRUFBRWlILE9BQU8sV0FBV0YsWUFBWSxNQUFNLEdBQUlsVCxpQkFBT21ULENBQUMsRUFBRVIsT0FBTyxZQUFZLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0YsSUFFdEYzUyxPQUFPbVQsQ0FBQyxFQUFFUixPQUFPLFlBQVk7QUFBQSxJQUVuQztBQUFBLElBQ0E7QUFBQSxNQUNFRSxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hDLE9BQU87QUFBQSxNQUNQUixRQUFRQSxDQUFDWSxHQUFHRixRQUFRO0FBQ2xCLGNBQU0vQixRQUFRekYsT0FBTzBILEtBQUssQ0FBQztBQUMzQixlQUFPRixJQUFJOUcsZUFDVCx1QkFBQyxVQUFLLE9BQU8sRUFBRWlILE9BQU8sV0FBV0YsWUFBWSxNQUFNLEdBQUc7QUFBQTtBQUFBLFVBQ2xEaEMsTUFBTWdCLGVBQWUsU0FBUyxFQUFFQyx1QkFBdUIsR0FBR0MsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLGFBRHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxlQUFjO0FBQUE7QUFBQSxVQUMxQmxCLE1BQU1nQixlQUFlLFNBQVMsRUFBRUMsdUJBQXVCLEdBQUdDLHVCQUF1QixFQUFFLENBQUM7QUFBQSxhQUR4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVKO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxNQUNFUyxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hDLE9BQU87QUFBQSxNQUNQUixRQUFRQSxDQUFDWSxNQUFNO0FBQ2IsY0FBTWpDLFFBQVF6RixPQUFPMEgsS0FBSyxDQUFDO0FBQzNCLGVBQU8sdUJBQUMsVUFBSyxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsVUFDaERqQyxNQUFNZ0IsZUFBZSxTQUFTLEVBQUVDLHVCQUF1QixHQUFHQyx1QkFBdUIsRUFBRSxDQUFDO0FBQUEsYUFEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVQO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQUEsTUFDRVMsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYQyxPQUFPO0FBQUEsTUFDUFIsUUFBUUEsQ0FBQ1ksTUFBTTtBQUNiLGNBQU1qQyxRQUFRekYsT0FBTzBILEtBQUssQ0FBQztBQUMzQixlQUFPLHVCQUFDLFVBQUssV0FBVSw0QkFBMkI7QUFBQTtBQUFBLFVBQzlDakMsTUFBTWdCLGVBQWUsU0FBUyxFQUFFQyx1QkFBdUIsR0FBR0MsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLGFBRGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFUDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLE1BQ0VTLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWEMsT0FBTztBQUFBLE1BQ1BSLFFBQVFBLENBQUNZLEdBQUdGLFFBQVE7QUFDbEIsY0FBTS9CLFFBQVF6RixPQUFPMEgsS0FBSyxDQUFDO0FBQzNCLGVBQU9GLElBQUk5RyxlQUNULHVCQUFDLFVBQUssT0FBTyxFQUFFaUgsT0FBTyxXQUFXRixZQUFZLElBQUksR0FBRztBQUFBO0FBQUEsVUFDaERoQyxNQUFNZ0IsZUFBZSxTQUFTLEVBQUVDLHVCQUF1QixHQUFHQyx1QkFBdUIsRUFBRSxDQUFDO0FBQUEsYUFEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsVUFBSyxPQUFPLEVBQUVnQixPQUFPbEMsUUFBUSxJQUFJLFFBQVEsUUFBUWdDLFlBQVksSUFBSSxHQUFHO0FBQUE7QUFBQSxVQUNqRWhDLE1BQU1nQixlQUFlLFNBQVMsRUFBRUMsdUJBQXVCLEdBQUdDLHVCQUF1QixFQUFFLENBQUM7QUFBQSxhQUR4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVKO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxNQUNFUyxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hDLE9BQU87QUFBQSxNQUNQUixRQUFRQSxDQUFDWSxNQUFNO0FBQ2IsY0FBTWpDLFFBQVF6RixPQUFPMEgsS0FBSyxDQUFDO0FBQzNCLGVBQ0UsdUJBQUMsVUFBSyxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsVUFDMUNqQyxNQUFNZ0IsZUFBZSxTQUFTLEVBQUVDLHVCQUF1QixHQUFHQyx1QkFBdUIsRUFBRSxDQUFDO0FBQUEsYUFEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFSjtBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQUEsTUFDRVMsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYQyxPQUFPO0FBQUEsTUFDUFIsUUFBUUEsQ0FBQ1ksR0FBR0YsUUFDVkEsSUFBSTlHLGVBQWUsdUJBQUMsT0FBSSxPQUFNLFFBQU8sdUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUIsSUFBUyx1QkFBQyxVQUFLLFdBQVUsbUJBQW1CVjtBQUFBQSxlQUFPMEgsS0FBSyxDQUFDO0FBQUEsUUFBRTtBQUFBLFdBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUQ7QUFBQSxJQUM1RztBQUFBLEVBQUM7QUFHSCxRQUFNRSx1QkFBdUJBLE1BQU07QUFDakMsUUFBSSxDQUFDL1AsY0FBYzhJLFFBQVE7QUFDekJ6TixjQUFRMlUsUUFBUSxtQkFBbUI7QUFDbkM7QUFBQSxJQUNGO0FBQ0EsVUFBTUMsVUFBVTtBQUFBLE1BQ2Q7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFBa0I7QUFFcEIsVUFBTUMsYUFBYTtBQUFBLE1BQ2pCRCxRQUFRRSxLQUFLLEdBQUc7QUFBQSxNQUNoQixHQUFHblEsY0FBY2tELElBQUksQ0FBQ3lNLFFBQVE7QUFDNUIsY0FBTVMsVUFBVVQsSUFBSTlHLGVBQWUsT0FBTzhHLElBQUlVO0FBQzlDLGNBQU1DLFVBQVU1VCxPQUFPaVQsSUFBSVksT0FBTyxFQUFFbEIsT0FBTyxZQUFZO0FBQ3ZELGNBQU10QyxXQUFXNUUsT0FBT3dILElBQUk1QyxZQUFZLENBQUMsRUFBRXFCLFFBQVEsQ0FBQztBQUNwRCxjQUFNb0MsT0FBT3JJLE9BQU93SCxJQUFJYSxRQUFRLENBQUMsRUFBRXBDLFFBQVEsQ0FBQztBQUM1QyxjQUFNbkgsVUFBVWtCLE9BQU93SCxJQUFJMUksV0FBVyxDQUFDLEVBQUVtSCxRQUFRLENBQUM7QUFDbEQsY0FBTWhCLFVBQVVqRixPQUFPd0gsSUFBSXZDLFdBQVcsQ0FBQyxFQUFFZ0IsUUFBUSxDQUFDO0FBQ2xELGNBQU1qQixVQUFVaEYsT0FBT3dILElBQUljLHdCQUF3QixDQUFDLEVBQUVyQyxRQUFRLENBQUM7QUFDL0QsY0FBTXNDLGNBQWNmLElBQUk5RyxlQUFlLFlBQVlWLE9BQU93SCxJQUFJZ0Isd0JBQXdCLENBQUM7QUFDdkYsY0FBTUMsU0FBU0EsQ0FBQ0MsUUFDZCxPQUFPQSxRQUFRLGFBQWFBLElBQUkxRyxTQUFTLEdBQUcsS0FBSzBHLElBQUkxRyxTQUFTLEdBQUcsS0FDN0QsSUFBSTBHLElBQUlDLFFBQVEsTUFBTSxJQUFJLENBQUMsTUFDM0JEO0FBQ04sZUFBTztBQUFBLFVBQ0xELE9BQU9SLE9BQU87QUFBQSxVQUNkUSxPQUFPTixPQUFPO0FBQUEsVUFDZHZEO0FBQUFBLFVBQ0F5RDtBQUFBQSxVQUNBdko7QUFBQUEsVUFDQW1HO0FBQUFBLFVBQ0FEO0FBQUFBLFVBQ0F5RCxPQUFPRixXQUFXO0FBQUEsUUFBQyxFQUNuQlAsS0FBSyxHQUFHO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFBQyxFQUNGQSxLQUFLLElBQUk7QUFDWCxVQUFNWSxPQUFPLElBQUlDLEtBQUssQ0FBQ2QsVUFBVSxHQUFHLEVBQUV2UCxNQUFNLDBCQUEwQixDQUFDO0FBQ3ZFLFVBQU1zUSxNQUFNQyxJQUFJQyxnQkFBZ0JKLElBQUk7QUFDcEMsVUFBTUssT0FBT0MsU0FBU0MsY0FBYyxHQUFHO0FBQ3ZDRixTQUFLRyxPQUFPTjtBQUNaRyxTQUFLSTtBQUFBQSxNQUNIO0FBQUEsTUFDQSxvQkFBb0J0UixrQkFBa0J5RCxZQUFZLFVBQVUsSUFBSWpILE9BQU8sRUFBRTJTLE9BQU8sVUFBVSxDQUFDO0FBQUEsSUFDN0Y7QUFDQWdDLGFBQVNJLEtBQUtDLFlBQVlOLElBQUk7QUFDOUJBLFNBQUtPLE1BQU07QUFDWE4sYUFBU0ksS0FBS0csWUFBWVIsSUFBSTtBQUM5QkYsUUFBSVcsZ0JBQWdCWixHQUFHO0FBQUEsRUFDekI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyw2QkFBNkIsQ0FBQy9HLE1BQU12TCxjQUFjdUwsRUFBRUUsT0FBT3dELEtBQUs7QUFBQSxVQUNoRSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRWxCaFAsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHVEQUNiLGlDQUFDLGtCQUFlLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSx5Q0FBd0MsNENBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtGO0FBQUEsWUFDbEYsdUJBQUMsT0FBRSxXQUFVLGlCQUFnQix5RkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0c7QUFBQSxlQUZ4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTUgsU0FBUyxtQkFBbUI7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQU0sdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUI7QUFBQSxnQkFDekIsU0FBUyxNQUFNd0Qsd0JBQXdCLElBQUk7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUNyQixTQUFTLE1BQU1kLHNCQUFzQixJQUFJO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBSDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxrQkFBZSxXQUFVLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLGNBQ2hELHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStDO0FBQUEsaUJBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUdGLGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RTtBQUFBLGdCQUM1RTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1Y7QUFBQSxvQkFDQSxhQUFZO0FBQUEsb0JBQ1osVUFBVSxDQUFDeU0sVUFBVTNPLGVBQWUyTyxLQUFLO0FBQUEsb0JBQ3pDLE9BQU81TyxlQUFlOFM7QUFBQUEsb0JBQ3RCLFlBQVksdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUI7QUFBQSxvQkFFaEM5Tyx1QkFBYUU7QUFBQUEsc0JBQUksQ0FBQ29DLFVBQ2pCLHVCQUFDLFVBQW1CLE9BQU9BLE9BQ3hCQSxtQkFEVUEsT0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBLG1CQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQywrQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0U7QUFBQSxnQkFDL0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsYUFBWTtBQUFBLG9CQUNaLFFBQVEsdUJBQUMsa0JBQWUsV0FBVSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUM7QUFBQSxvQkFDakQsT0FBTzVHO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ3dMLE1BQU12TCxjQUFjdUwsRUFBRUUsT0FBT3dELEtBQUs7QUFBQTtBQUFBLGtCQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSWlEO0FBQUEsbUJBTm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQkE7QUFBQTtBQUFBLFVBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXFDQSxLQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUNsQjtBQUFBLG1DQUFDLE9BQUksSUFBSSxJQUFJLElBQUksR0FDZixpQ0FBQyxRQUFLLFdBQVUsb0NBQ2QsaUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLHdCQUFxQixXQUFVLDZCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RCxLQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQSxnQkFDcEQsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQzlDLGlCQUFPRSxrQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxtQkFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxHQUNmLGlDQUFDLFFBQUssV0FBVSxvQ0FDZCxpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsc0JBQW1CLFdBQVUsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVELEtBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLGdCQUNsRCx1QkFBQyxPQUFFLFdBQVUsbUNBQW1DRixpQkFBT1EsZ0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9FO0FBQUEsbUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUNBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksR0FDZixpQ0FBQyxRQUFLLFdBQVUsb0NBQ2QsaUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9DQUNiLGlDQUFDLHdCQUFxQixXQUFVLDRCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RCxLQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw0QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUQ7QUFBQSxnQkFDakQsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQ1IsaUJBQU9HLGVBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1FO0FBQUEsbUJBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxlQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdDQSxLQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBDQTtBQUFBLFVBQ0EsdUJBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQ2xCO0FBQUEsbUNBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxHQUNmLGlDQUFDLFFBQUssV0FBVSx5Q0FDZCxpQ0FBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtEO0FBQUEsY0FDbEQsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQztBQUFBO0FBQUEsZ0JBQzFDOUMsT0FBTzJDLE9BQU8zRCxnQkFBZ0IsQ0FBQyxFQUFFeUgsZUFBZSxTQUFTO0FBQUEsa0JBQ3pEQyx1QkFBdUI7QUFBQSxrQkFDdkJDLHVCQUF1QjtBQUFBLGdCQUN6QixDQUFDO0FBQUEsbUJBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUNBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksR0FDZixpQ0FBQyxRQUFLLFdBQVUsNENBQ2QsaUNBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGNBQ3BELHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLGdCQUM3QzNHLE9BQU8yQyxPQUFPekQsZ0JBQWdCLENBQUMsRUFBRXVILGVBQWUsU0FBUztBQUFBLGtCQUN6REMsdUJBQXVCO0FBQUEsa0JBQ3ZCQyx1QkFBdUI7QUFBQSxnQkFDekIsQ0FBQztBQUFBLG1CQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLEdBQ2YsaUNBQUMsUUFBSyxXQUFVLDJDQUNkLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUF3QixpQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQSxnQkFDckRwUCwwQkFDQyx1QkFBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsa0JBQWUsTUFBSyxXQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLElBQ0VKLDBCQUNGLHVCQUFDLE9BQUUsV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLGtCQUM1QzZJLE9BQU83SSx3QkFBd0J5UyxjQUFjLEVBQUVuRCxlQUFlLFNBQVM7QUFBQSxvQkFDdkVDLHVCQUF1QjtBQUFBLG9CQUN2QkMsdUJBQXVCO0FBQUEsa0JBQ3pCLENBQUM7QUFBQSxxQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBLElBRUEsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix1QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEM7QUFBQSxtQkFkaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNalAsOEJBQThCLElBQUk7QUFBQSxrQkFDakQsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLGVBQVksV0FBVSxvQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUM7QUFBQTtBQUFBLGdCQU56QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQSxLQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBLFlBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxHQUNmLGlDQUFDLFFBQUssV0FBVSw0Q0FDZCxpQ0FBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtEO0FBQUEsY0FDbEQsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsZ0JBQzdDc0ksT0FBTzJDLE9BQU9TLDhCQUE4QixDQUFDLEVBQUVxRCxlQUFlLFNBQVM7QUFBQSxrQkFDdkVDLHVCQUF1QjtBQUFBLGtCQUN2QkMsdUJBQXVCO0FBQUEsZ0JBQ3pCLENBQUM7QUFBQSxtQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxHQUNmLGlDQUFDLFFBQUssV0FBVSw0Q0FDZCxpQ0FBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0Isd0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsY0FDN0QsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsZ0JBQzdDM0csT0FBTzJDLE9BQU9VLCtCQUErQixDQUFDLEVBQUVvRCxlQUFlLFNBQVM7QUFBQSxrQkFDeEVDLHVCQUF1QjtBQUFBLGtCQUN2QkMsdUJBQXVCO0FBQUEsZ0JBQ3pCLENBQUM7QUFBQSxtQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxHQUNmLGlDQUFDLFFBQUssV0FBVSwwQ0FDZCxpQ0FBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0Isa0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsY0FDdkQsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQztBQUFBO0FBQUEsZ0JBQzNDM0csT0FBTzJDLE9BQU9XLDBCQUEwQixDQUFDLEVBQUVtRCxlQUFlLFNBQVM7QUFBQSxrQkFDbkVDLHVCQUF1QjtBQUFBLGtCQUN2QkMsdUJBQXVCO0FBQUEsZ0JBQ3pCLENBQUM7QUFBQSxtQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLGVBMUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkdBO0FBQUEsYUF4SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlKQTtBQUFBLFFBR0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHlCQUF3QixnQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Q7QUFBQSxjQUN4RCx1QkFBQyxVQUFLLFdBQVUseUJBQ2J4Tyx1QkFBYXdJLFNBQVMsSUFDckIsdUJBQUMsVUFBSyxXQUFVLCtCQUErQnhJO0FBQUFBLDZCQUFhd0k7QUFBQUEsZ0JBQU87QUFBQSxtQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEUsSUFFNUUsV0FBV3pFLGNBQWN5RSxNQUFNLE9BQU9oSyxVQUFVZ0ssTUFBTSxjQUoxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBRUYsT0FDRXhJLGFBQWF3SSxTQUFTLEtBQ3BCLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU0sdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0I7QUFBQSxrQkFDdEIsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTRFLGNBQWMsZUFBZTtBQUFBLGtCQUM1QyxVQUFVLENBQUNwTixhQUFhMFIsS0FBSyxDQUFDN08sTUFBTUEsRUFBRXFGLGVBQWU7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFNLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdCO0FBQUEsa0JBQ3RCO0FBQUEsa0JBQ0EsU0FBUyxNQUFNa0YsY0FBYyxrQkFBa0I7QUFBQSxrQkFDL0MsVUFBVSxDQUFDcE4sYUFBYTBSLEtBQUssQ0FBQzdPLE1BQU1BLEVBQUVzRixrQkFBa0I7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9CO0FBQUEsa0JBQzFCLFNBQVMsTUFBTWlGLGNBQWMsbUJBQW1CO0FBQUEsa0JBQ2hELFVBQVUsQ0FBQ3BOLGFBQWEwUjtBQUFBQSxvQkFDdEIsQ0FBQzdPLE1BQU0sQ0FBQ0EsRUFBRXFGLG1CQUFtQixDQUFDckYsRUFBRXNGLHNCQUFzQnRGLEVBQUVzRyxXQUFXd0ksT0FBT0MsVUFBVUQsT0FBT0MsVUFBVS9ILFNBQVMsV0FBVztBQUFBLGtCQUMzSDtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTSx1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQjtBQUFBLGtCQUMzQixNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNdUQsY0FBYyxvQkFBb0I7QUFBQSxrQkFDakQsVUFBVSxDQUFDcE4sYUFBYTBSLEtBQUssQ0FBQzdPLE1BQU1BLEVBQUV1RyxtQkFBbUI7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBSjdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsY0FDQSx1QkFBQyxVQUFPLFNBQVMsTUFBTW5KLGdCQUFnQixFQUFFLEdBQUcsVUFBVUQsYUFBYXdJLFdBQVcsR0FBRztBQUFBO0FBQUEsZ0JBQ3ZFeEksYUFBYXdJO0FBQUFBLGdCQUFPO0FBQUEsbUJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQ0E7QUFBQSxZQUlKLGlDQUFDLFNBQUksV0FBVSx3REFDYixpQ0FBQyxTQUFJLE9BQU8sRUFBRTRHLE9BQU8sY0FBYyxHQUNqQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU1yTDtBQUFBQSxnQkFDTjtBQUFBLGdCQUNBLGlCQUFnQjtBQUFBLGdCQUNoQixrQkFBaUI7QUFBQTtBQUFBLGNBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlzQyxLQUx4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBO0FBQUEsVUFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUVBO0FBQUEsV0F6U0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBTQTtBQUFBLFNBclRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1VEE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUNFLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxlQUFZLFdBQVUsMEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsWUFDN0MsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixpQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxlQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQ25FLG9CQUNDLHVCQUFDLFNBQUksV0FBVSw4QkFDWkE7QUFBQUEsNkJBQWlCeUQ7QUFBQUEsWUFBUztBQUFBLFlBQUl6RCxpQkFBaUJrRDtBQUFBQSxlQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVGLE1BQU10RDtBQUFBQSxRQUNOLFVBQVUsTUFBTUMsa0JBQWtCLEtBQUs7QUFBQSxRQUN2QyxRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxXQUFXLEVBQUVvUyxTQUFTLE9BQU87QUFBQSxRQUU1Qi9SLDZCQUNDLHVCQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMyUDtBQUFBQSxjQUNULFVBQVUzUCxvQkFBb0IsQ0FBQ0osY0FBYzhJO0FBQUFBLGNBQzdDLE1BQU0sdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQSxjQUFJO0FBQUE7QUFBQSxZQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxZQUFZOUksY0FBY2tELElBQUksQ0FBQ2tQLEdBQUdDLE9BQU8sRUFBRSxHQUFHRCxHQUFHNUgsS0FBSzZILEVBQUUsRUFBRTtBQUFBLGNBQzFELFNBQVMvQztBQUFBQSxjQUNULFlBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxRQUFRLEVBQUVnRCxHQUFHLE1BQU1DLEdBQUcsSUFBSTtBQUFBLGNBQzFCLGNBQWMsQ0FBQ3BELFdBQVlBLE9BQU90RyxlQUFlLDhDQUE4QztBQUFBO0FBQUEsWUFOakc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXFHO0FBQUEsVUFFckcsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUJBQXdCLHdCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQy9DLHVCQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGdCQUNuQzdJLGNBQWMrTCxPQUFPLENBQUN5RyxHQUFHSixNQUFNSSxLQUFLSixFQUFFckYsWUFBWSxJQUFJLENBQUMsRUFBRTZCLGVBQWUsT0FBTztBQUFBLG1CQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUJBQXdCLG9CQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBLGNBQzNDLHVCQUFDLFNBQUksV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLGdCQUNsRDVPLGNBQWMrTCxPQUFPLENBQUN5RyxHQUFHSixNQUFNSSxLQUFLSixFQUFFNUIsUUFBUSxJQUFJLENBQUMsRUFBRTVCLGVBQWUsT0FBTztBQUFBLG1CQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUJBQXdCLHVCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBLGNBQzlDLHVCQUFDLFNBQUksV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGdCQUNoRDVPLGNBQWMrTCxPQUFPLENBQUN5RyxHQUFHSixNQUFNSSxLQUFLSixFQUFFaEYsV0FBVyxJQUFJLENBQUMsRUFBRXdCLGVBQWUsT0FBTztBQUFBLG1CQURsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUJBQXdCLHlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLGNBQ2hELHVCQUFDLFNBQUksV0FBVSx5Q0FBd0M7QUFBQTtBQUFBLGdCQUNuRDVPLGNBQWMrTCxPQUFPLENBQUN5RyxHQUFHSixNQUFNSSxLQUFLSixFQUFFM0Isd0JBQXdCLElBQUksQ0FBQyxFQUFFN0IsZUFBZSxPQUFPO0FBQUEsbUJBRC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx5QkFBd0IsMEJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsY0FDakQsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsZ0JBQy9DNU8sY0FBY3dELE9BQU8sQ0FBQzRPLE1BQU1BLEVBQUV2SixZQUFZLEVBQUVrRCxPQUFPLENBQUN5RyxHQUFHSixNQUFNSSxLQUFLSixFQUFFaEYsV0FBVyxJQUFJLENBQUMsRUFBRXdCLGVBQWUsT0FBTztBQUFBLG1CQURoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsYUFsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1EQTtBQUFBO0FBQUEsTUE1RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOEVBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxtQkFBZ0IsV0FBVSwwQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRCx1QkFBQyxVQUFLLFdBQVUseUJBQ2JwTztBQUFBQSxzQkFBVUcsU0FBUyxtQkFBbUI7QUFBQSxZQUN0Q0gsVUFBVUcsU0FBUyxzQkFBc0I7QUFBQSxZQUN6Q0gsVUFBVUcsU0FBUyx1QkFBdUI7QUFBQSxZQUMxQ0gsVUFBVUcsU0FBUyx3QkFBd0I7QUFBQSxlQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVGLE1BQU1ILFVBQVVFO0FBQUFBLFFBQ2hCLFVBQVUsTUFBTUQsYUFBYSxFQUFFQyxNQUFNLE9BQU9DLE1BQU0sS0FBSyxDQUFDO0FBQUEsUUFDeEQsTUFBTTZNO0FBQUFBLFFBQ04sUUFBTztBQUFBLFFBQ1AsZUFBZTtBQUFBLFVBQ2JpRixTQUFTN1Q7QUFBQUEsVUFDVDhULFFBQVFsUyxVQUFVRyxNQUFNd0osU0FBUyxTQUFTO0FBQUEsUUFDNUM7QUFBQSxRQUNBLFlBQVc7QUFBQSxRQUVYO0FBQUEsaUNBQUMsT0FBRSxXQUFVLFFBQU87QUFBQTtBQUFBLFlBQTJDLHVCQUFDLFlBQVE3Six1QkFBYXdJLFVBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFBUztBQUFBLGVBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtIO0FBQUEsVUFDbEgsdUJBQUMsUUFBRyxXQUFVLGlFQUNYeEk7QUFBQUEseUJBQWFxUyxNQUFNLEdBQUcsQ0FBQyxFQUFFelA7QUFBQUEsY0FBSSxDQUFDQyxNQUM3Qix1QkFBQyxRQUNFQTtBQUFBQSxrQkFBRVE7QUFBQUEsZ0JBQVM7QUFBQSxnQkFBR1IsRUFBRTJDO0FBQUFBLGdCQUFVO0FBQUEsZ0JBQUszQyxFQUFFQztBQUFBQSxtQkFEM0JELEVBQUVzQyxLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxZQUNEO0FBQUEsWUFDQW5GLGFBQWF3SSxTQUFTLEtBQUssdUJBQUMsUUFBRztBQUFBO0FBQUEsY0FBR3hJLGFBQWF3SSxTQUFTO0FBQUEsY0FBRTtBQUFBLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLGVBTnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQTtBQUFBO0FBQUEsTUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBK0JBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxrQkFBZSxXQUFVLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLFVBQy9DLHVCQUFDLFVBQUssV0FBVSx5QkFBd0Isa0RBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUEsYUFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFRixNQUFNbEo7QUFBQUEsUUFDTixVQUFVLE1BQU1DLDhCQUE4QixLQUFLO0FBQUEsUUFDbkQsUUFBUTtBQUFBLFVBQ04sdUJBQUMsVUFBa0IsU0FBUyxNQUFNQSw4QkFBOEIsS0FBSyxHQUFHLG9CQUE1RCxRQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUFTO0FBQUEsUUFFWCxPQUFPO0FBQUEsUUFDUCxXQUFXLEVBQUVzUyxTQUFTLE9BQU87QUFBQSxRQUU1QnpTLG9DQUNDLHVCQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkRBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFNBQUksV0FBVSx5QkFBd0IsMENBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FDakUsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsZ0JBQy9DeUksT0FBTzdJLHlCQUF5QnlTLGNBQWMsRUFBRW5ELGVBQWUsT0FBTztBQUFBLG1CQUQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUJBQXdCLHNDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RDtBQUFBLGNBQzdELHVCQUFDLFNBQUksV0FBVSx1Q0FDWnBQLGtDQUF3QnNKLFVBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFlBQVl0SjtBQUFBQSxjQUNaLFFBQU87QUFBQSxjQUNQLFlBQVksRUFBRW9ULFVBQVUsR0FBRztBQUFBLGNBQzNCLFFBQVEsRUFBRU4sR0FBRyxJQUFJO0FBQUEsY0FDakIsU0FBUztBQUFBLGdCQUNQO0FBQUEsa0JBQ0UvQyxPQUFPO0FBQUEsa0JBQ1BDLFdBQVc7QUFBQSxrQkFDWGhGLEtBQUs7QUFBQSxrQkFDTHlFLFFBQVFBLENBQUM0RCxNQUFNQyxNQUNiLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsZUFBZUE7QUFBQUEsd0JBQUVuUCxZQUFZO0FBQUEsc0JBQUk7QUFBQSx5QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQ7QUFBQSxvQkFDakQsdUJBQUMsU0FBSSxXQUFVLHlCQUF5Qm1QLFlBQUVuUCxZQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRDtBQUFBLHVCQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsZ0JBRUo7QUFBQSxnQkFDQSxFQUFFNEwsT0FBTyxTQUFTQyxXQUFXLGFBQWFoRixLQUFLLFlBQVk7QUFBQSxnQkFDM0QsRUFBRStFLE9BQU8sVUFBVUMsV0FBVyxVQUFVaEYsS0FBSyxTQUFTO0FBQUEsZ0JBQ3REO0FBQUEsa0JBQ0UrRSxPQUFPO0FBQUEsa0JBQ1BDLFdBQVc7QUFBQSxrQkFDWGhGLEtBQUs7QUFBQSxrQkFDTGlGLE9BQU87QUFBQSxrQkFDUFIsUUFBUUEsQ0FBQ1ksTUFBTSxJQUFJMUgsT0FBTzBILEtBQUssQ0FBQyxFQUFFekIsUUFBUSxDQUFDLENBQUM7QUFBQSxnQkFDOUM7QUFBQSxnQkFDQTtBQUFBLGtCQUNFbUIsT0FBTztBQUFBLGtCQUNQQyxXQUFXO0FBQUEsa0JBQ1hoRixLQUFLO0FBQUEsa0JBQ0xpRixPQUFPO0FBQUEsa0JBQ1BSLFFBQVFBLENBQUNZLE1BQU0sSUFBSTFILE9BQU8wSCxLQUFLLENBQUMsRUFBRXpCLFFBQVEsQ0FBQyxDQUFDO0FBQUEsZ0JBQzlDO0FBQUEsZ0JBQ0E7QUFBQSxrQkFDRW1CLE9BQU87QUFBQSxrQkFDUEMsV0FBVztBQUFBLGtCQUNYaEYsS0FBSztBQUFBLGtCQUNMaUYsT0FBTztBQUFBLGtCQUNQUixRQUFRQSxDQUFDWSxNQUFNLElBQUkxSCxPQUFPMEgsS0FBSyxDQUFDLEVBQUV6QixRQUFRLENBQUMsQ0FBQztBQUFBLGdCQUM5QztBQUFBLGdCQUNBO0FBQUEsa0JBQ0VtQixPQUFPO0FBQUEsa0JBQ1BDLFdBQVc7QUFBQSxrQkFDWGhGLEtBQUs7QUFBQSxrQkFDTGlGLE9BQU87QUFBQSxrQkFDUFIsUUFBUUEsQ0FBQ1ksTUFDUCx1QkFBQyxZQUFPLFdBQVUsa0JBQWlCO0FBQUE7QUFBQSxvQkFBRTFILE9BQU8wSCxLQUFLLENBQUMsRUFBRXpCLFFBQVEsQ0FBQztBQUFBLHVCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErRDtBQUFBLGdCQUVuRTtBQUFBLGdCQUNBO0FBQUEsa0JBQ0VtQixPQUFPO0FBQUEsa0JBQ1BDLFdBQVc7QUFBQSxrQkFDWGhGLEtBQUs7QUFBQSxrQkFDTHlFLFFBQVFBLENBQUNtRCxNQUFNMVYsT0FBTzBWLENBQUMsRUFBRS9DLE9BQU8sYUFBYTtBQUFBLGdCQUMvQztBQUFBLGNBQUM7QUFBQTtBQUFBLFlBdERMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXVESTtBQUFBLGFBeEVOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwRUE7QUFBQTtBQUFBLE1BaEdKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtHQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsZ0JBQWEsV0FBVSwwQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGdDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUYsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNbE8sc0JBQXNCLEtBQUs7QUFBQSxRQUMxQyxNQUFNRDtBQUFBQSxRQUNOLE9BQU87QUFBQSxRQUNQLFdBQVcsRUFBRWlSLFNBQVMsT0FBTztBQUFBLFFBRTdCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLGFBQVk7QUFBQSxjQUNaLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtrQixLQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRTtBQUFBLGNBQ3JFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FBT3ZSLHVCQUF1QmtSO0FBQUFBLGtCQUM5QixVQUFVbkU7QUFBQUEsa0JBQ1YsWUFBVTtBQUFBLGtCQUVUM0ssdUJBQWFFO0FBQUFBLG9CQUFJLENBQUNvQyxVQUNqQix1QkFBQyxVQUFtQixPQUFPQSxPQUN4QkEsbUJBRFVBLE9BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixpREFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkU7QUFBQSxpQkFmN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RTtBQUFBLGNBQ3hFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FBT3hFLDBCQUEwQmdSO0FBQUFBLGtCQUNqQyxVQUFVLENBQUNsRSxVQUFVQyxxQkFBcUJELEtBQUs7QUFBQSxrQkFDL0MsVUFBVSxDQUFDaE47QUFBQUEsa0JBQ1gsWUFBVTtBQUFBLGtCQUVUeUMsMEJBQWdCSDtBQUFBQSxvQkFBSSxDQUFDYyxTQUNwQix1QkFBQyxVQUEyQixPQUFPQSxLQUFLTCxVQUNyQ0ssZUFBS0wsWUFES0ssS0FBS0wsVUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUNWL0MsZ0NBQ0csOENBQ0EsMEJBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0Msc0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FDdEU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixPQUFPSSx3QkFBd0I4UTtBQUFBQSxrQkFDL0IsVUFBVWhFO0FBQUFBLGtCQUNWLFVBQVUsQ0FBQ2hOO0FBQUFBLGtCQUNYLFlBQVU7QUFBQSxrQkFFVGlELHdCQUFjYjtBQUFBQSxvQkFBSSxDQUFDeUMsV0FDbEIsdUJBQUMsVUFBb0IsT0FBT0EsUUFDekJBLG9CQURVQSxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDVjdFLG1DQUNHLGdEQUNBLDZCQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLFVBQVUsQ0FBQ0U7QUFBQUEsZ0JBQ1gsU0FBUyxNQUFNO0FBQ2Isd0JBQU1nRCxPQUFPbEYsVUFBVW1GO0FBQUFBLG9CQUNyQixDQUFDZCxNQUNDQSxFQUFFQyxjQUFjeEMsdUJBQ2hCdUMsRUFBRVEsYUFBYTdDLDBCQUNmcUMsRUFBRWUsbUJBQW1CbEQ7QUFBQUEsa0JBQ3pCO0FBQ0Esc0JBQUlnRCxNQUFNO0FBQ1J6QyxzQ0FBa0I7QUFBQSxzQkFDaEJvQyxVQUFVSyxLQUFLTDtBQUFBQSxzQkFDZlAsV0FBV1ksS0FBS1o7QUFBQUEsc0JBQ2hCMEMsV0FBVzlCLEtBQUs4QjtBQUFBQSxzQkFDaEI1QixnQkFBZ0JGLEtBQUtFO0FBQUFBLHNCQUNyQndCLFFBQVExQixLQUFLMEI7QUFBQUEsc0JBQ2JILFNBQVN2QixLQUFLdUI7QUFBQUEsc0JBQ2Q4QixjQUFjckQsS0FBS3FELGdCQUFnQjtBQUFBLHNCQUNuQ0ksZ0JBQWdCekQsS0FBS3lELGtCQUFrQjtBQUFBLHNCQUN2Q0YsV0FBV3ZELEtBQUt1RCxhQUFhO0FBQUEsb0JBQy9CLENBQUM7QUFDRHBHLDBDQUFzQixLQUFLO0FBQzNCRSw0Q0FBd0IsSUFBSTtBQUFBLGtCQUM5QjtBQUFBLGdCQUNGO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdDQTtBQUFBLGVBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0ZBO0FBQUE7QUFBQTtBQUFBLE1BckhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXNIQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU87QUFBQSxRQUNQLFdBQVU7QUFBQSxRQUNWLFNBQVMsTUFBTUEsd0JBQXdCLEtBQUs7QUFBQSxRQUM1QyxNQUFNRDtBQUFBQSxRQUNOLE9BQU87QUFBQSxRQUNQLFdBQVcsRUFBRStRLFNBQVMsSUFBSTtBQUFBLFFBQzFCLFVBQVU7QUFBQSxRQUVUN1EsNEJBQ0MsdUJBQUMsU0FBSSxXQUFVLGlDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHlDQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLG1CQUFrQixnQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxjQUM3RCx1QkFBQyxRQUFLLFdBQVUsV0FBVSxpRUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkU7QUFBQSxpQkFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxNQUFNLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUEsZ0JBQ3hCLFNBQVMsTUFBTUQsd0JBQXdCLEtBQUs7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMEJBQ2IsaUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSxRQUFPLGdDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRCxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSw4Q0FBNkMsNkJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGO0FBQUEsZ0JBQzNGLHVCQUFDLFFBQUssUUFBTSxNQUFDLFdBQVUsYUFBYUMseUJBQWVxQyxZQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RDtBQUFBLG1CQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSw4Q0FBNkMsNEJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGO0FBQUEsZ0JBQzFGLHVCQUFDLFFBQUssUUFBTSxNQUFDLFdBQVUsYUFBYXJDLHlCQUFld0UsYUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkQ7QUFBQSxtQkFGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsOENBQTZDLHFCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRjtBQUFBLGdCQUNuRix1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQWF4RSx5QkFBZThCLGFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUEsbUJBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxRQUFLLE1BQUssYUFBWSxXQUFVLDhDQUE2Qyw2QkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkY7QUFBQSxnQkFDM0YsdUJBQUMsUUFBSyxRQUFNLE1BQUMsV0FBVSxhQUFhOUIseUJBQWU0QyxrQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQSxtQkFGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLGVBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLFFBQU8saUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFDbkQsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEscUNBQUMsUUFBSyxXQUFXLFVBQVU1QyxlQUFlK0YsZUFBZSxJQUFJLEtBQUssWUFBWSxJQUM1RTtBQUFBLHVDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSxRQUFPLHdCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQztBQUFBLGtCQUMxQyx1QkFBQyxRQUFLLE1BQUssYUFBWSxXQUFVLFdBQVUsNENBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVFO0FBQUEscUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHlDQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsV0FBVSxzQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUU7QUFBQSxrQkFDakUsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsb0JBQ25DYyxPQUFPN0csZUFBZStGLFlBQVksRUFBRXVILGVBQWUsT0FBTztBQUFBLHVCQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNDdE4sZUFBZStGLGVBQWUsS0FDN0I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixTQUFTLE1BQU0wRyx3QkFBd0IsVUFBVTtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFIckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLFdBQVcsVUFBVXpNLGVBQWVtRyxpQkFBaUIsSUFBSSxLQUFLLFlBQVksSUFDOUU7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHlDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsUUFBTywrQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUQ7QUFBQSxrQkFDakQsdUJBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSxXQUFVLHdDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRTtBQUFBLHFCQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxRQUFLLE1BQUssYUFBWSxXQUFVLFdBQVUsc0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlFO0FBQUEsa0JBQ2pFLHVCQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQTtBQUFBLG9CQUNuQ1UsT0FBTzdHLGVBQWVtRyxjQUFjLEVBQUVtSCxlQUFlLE9BQU87QUFBQSx1QkFEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQ3ROLGVBQWVtRyxpQkFBaUIsS0FDL0I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixTQUFTLE1BQU1zRyx3QkFBd0IsU0FBUztBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFIcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsaUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkNBO0FBQUEsWUFDQSx1QkFBQyxRQUFLLFdBQVcsUUFBUXpNLGVBQWVpRyxZQUFZLElBQUksS0FBSyxZQUFZLElBQ3ZFO0FBQUEscUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLFFBQU8sbUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsZ0JBQ3JELHVCQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsV0FBVSwyQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxtQkFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxRQUFLLE1BQUssYUFBWSxXQUFVLFdBQVUsc0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlFO0FBQUEsZ0JBQ2pFLHVCQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGtCQUNuQ1ksT0FBTzdHLGVBQWVpRyxTQUFTLEVBQUVxSCxlQUFlLE9BQU87QUFBQSxxQkFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNDdE4sZUFBZWlHLFlBQVksS0FDMUI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU13Ryx3QkFBd0IsWUFBWTtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFIdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxpQkFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUNBLHVCQUFDLFFBQUssV0FBVyxRQUFTek0sZUFBZStGLGVBQWUvRixlQUFlbUcsaUJBQWlCbkcsZUFBZWlHLFlBQWEsSUFBSSw4QkFBOEIsWUFBWSxJQUNoSztBQUFBLHFDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSxRQUFPLHVDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxRQUFLLE1BQUssYUFBWSxXQUFVLFdBQVUsNkNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdFO0FBQUEsbUJBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSxXQUFVLDRDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RTtBQUFBLGdCQUN2RSx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxtQkFFcENZLE9BQU83RyxlQUFlK0YsWUFBWSxJQUNsQ2MsT0FBTzdHLGVBQWVtRyxjQUFjLElBQ3BDVSxPQUFPN0csZUFBZWlHLFNBQVMsR0FDL0JxSCxlQUFlLE9BQU87QUFBQSxxQkFMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLG1CQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNFdE4sZUFBZStGLGVBQWUvRixlQUFlbUcsaUJBQWlCbkcsZUFBZWlHLFlBQWEsS0FDMUY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU13Ryx3QkFBd0IsS0FBSztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxpQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLGFBQVk7QUFBQSxnQkFDWixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtrQjtBQUFBLGVBakdwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1HQTtBQUFBLGFBOUlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErSUE7QUFBQTtBQUFBLE1BekpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTJKQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU87QUFBQSxRQUNQLFdBQVU7QUFBQSxRQUNWLFNBQVMsTUFBTTtBQUNicE0saUNBQXVCLEtBQUs7QUFDNUJOLGtDQUF3QixJQUFJO0FBQUEsUUFDOUI7QUFBQSxRQUNBLE1BQU1LO0FBQUFBLFFBQ04sT0FBTztBQUFBLFFBQ1AsV0FBVyxFQUFFeVEsU0FBUyxJQUFJO0FBQUEsUUFDMUIsVUFBVTtBQUFBLFFBRVQ3USw0QkFDQyx1QkFBQyxTQUFJLFdBQVUsaUNBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsbUJBQ3hCRSxtQ0FBeUIsYUFDdEIscUJBQ0FBLHlCQUF5QixZQUN6Qiw0QkFDQUEseUJBQXlCLGVBQ3pCLHVCQUNBLGtDQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFFBQUssV0FBVSxXQUFVLGtGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxNQUFNLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUEsZ0JBQ3hCLFNBQVMsTUFBTTtBQUNiRyx5Q0FBdUIsS0FBSztBQUM1Qk4sMENBQXdCLElBQUk7QUFBQSxnQkFDOUI7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxxQ0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLFFBQU8sb0NBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNEO0FBQUEsY0FDdEQsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsOENBQTZDLHdCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRjtBQUFBLGtCQUN0Rix1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQWFDLHlCQUFlcUMsWUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEQ7QUFBQSxxQkFGOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFLLE1BQUssYUFBWSxXQUFVLDhDQUE2QyxxQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUY7QUFBQSxrQkFDbkYsdUJBQUMsUUFBSyxRQUFNLE1BQUMsV0FBVSxhQUFhckMseUJBQWV3RSxhQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBLHFCQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsOENBQTZDLHFCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRjtBQUFBLGtCQUNuRix1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQWF4RSx5QkFBZThCLGFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZEO0FBQUEscUJBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSw4Q0FBNkMsc0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9GO0FBQUEsa0JBQ3BGLHVCQUFDLFFBQUssUUFBTSxNQUFDLFdBQVUsYUFBYTlCLHlCQUFlNEMsa0JBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtFO0FBQUEscUJBRnBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsUUFDeEIxQyxtQ0FBeUIsYUFDdEIsb0NBQ0FBLHlCQUF5QixZQUN6QiwyQ0FDQUEseUJBQXlCLGVBQ3pCLHNDQUNBLDZCQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLGdCQUN6Q00saUJBQWlCOE0sZUFBZSxPQUFPO0FBQUEsbUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUssTUFBSyxhQUFZLG1EQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGlCQWI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsUUFBTyxxQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxjQUN2RDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2hOO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3NJLE1BQU1ySSxpQkFBaUJxSSxFQUFFRSxPQUFPd0QsS0FBSztBQUFBLGtCQUNoRCxhQUFhLHVCQUF1QnRCLEtBQUt5RyxJQUFJLEtBQUtqUixnQkFBZ0IsRUFBRThNLGVBQWUsT0FBTyxDQUFDO0FBQUEsa0JBQzNGLEtBQUs7QUFBQSxrQkFDTCxNQUFNO0FBQUEsa0JBQ04sV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQTtBQUFBLGdCQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFpQjtBQUFBLGNBRWhCVCxXQUFXdk0sYUFBYSxJQUFJRSxvQkFDM0IsdUJBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEsdUNBQUMsNkJBQTBCLFdBQVUsVUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFBRztBQUFBLGdCQUN2QkEsaUJBQWlCOE0sZUFBZSxPQUFPO0FBQUEsbUJBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEscUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSxRQUFPLG1DQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRDtBQUFBLGNBQ3JELHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTS9NLGtCQUFrQkMsbUJBQW1CLE1BQU1zTSxRQUFRLENBQUMsQ0FBQztBQUFBLG9CQUNwRSxVQUFVdE0sb0JBQW9CO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1ELGtCQUFrQkMsbUJBQW1CLEtBQUtzTSxRQUFRLENBQUMsQ0FBQztBQUFBLG9CQUNuRSxVQUFVdE0sb0JBQW9CO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1ELGtCQUFrQkMsbUJBQW1CLE1BQU1zTSxRQUFRLENBQUMsQ0FBQztBQUFBLG9CQUNwRSxVQUFVdE0sb0JBQW9CO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1ELGlCQUFpQkMsaUJBQWlCc00sUUFBUSxDQUFDLENBQUM7QUFBQSxvQkFDM0QsVUFBVXRNLG9CQUFvQjtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsbUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVE7QUFBQSxnQkFDUixhQUFZO0FBQUEsZ0JBQ1osTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLa0I7QUFBQSxZQUdsQix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNO0FBQ2JILDJDQUF1QixLQUFLO0FBQzVCTiw0Q0FBd0IsSUFBSTtBQUFBLGtCQUM5QjtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixVQUFVLENBQUNPLGlCQUFpQnVNLFdBQVd2TSxhQUFhLEtBQUssS0FBS3VNLFdBQVd2TSxhQUFhLElBQUlFO0FBQUFBLGtCQUMxRixTQUFTbU07QUFBQUEsa0JBQW9CO0FBQUE7QUFBQSxnQkFOL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxlQXZIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdIQTtBQUFBLGFBdkpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3SkE7QUFBQTtBQUFBLE1BcktKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXVLQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsc0JBQW1CLFdBQVUsMEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QixrQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxhQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVGLFdBQVU7QUFBQSxRQUNWLFNBQVMsTUFBTWhNLHdCQUF3QixLQUFLO0FBQUEsUUFDNUMsTUFBTUQ7QUFBQUEsUUFDTixPQUFPO0FBQUEsUUFDUCxXQUFXLEVBQUVtUSxTQUFTLE9BQU87QUFBQSxRQUU3QjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixhQUFZO0FBQUEsY0FDWixNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLa0IsS0FOcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxxQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUNyRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLE9BQU9qUSx5QkFBeUI0UDtBQUFBQSxrQkFDaEMsVUFBVXpEO0FBQUFBLGtCQUNWLFlBQVU7QUFBQSxrQkFFVHJMLHVCQUFhRTtBQUFBQSxvQkFBSSxDQUFDb0MsVUFDakIsdUJBQUMsVUFBbUIsT0FBT0EsT0FDeEJBLG1CQURVQSxPQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsaURBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJFO0FBQUEsaUJBZjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxjQUN4RTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLE9BQU9sRCw0QkFBNEIwUDtBQUFBQSxrQkFDbkMsVUFBVSxDQUFDbEUsVUFBVVUsK0JBQStCVixLQUFLO0FBQUEsa0JBQ3pELFVBQVUsQ0FBQzFMO0FBQUFBLGtCQUNYLFlBQVU7QUFBQSxrQkFFVGlDLG9DQUEwQmpCO0FBQUFBLG9CQUFJLENBQUNjLFNBQzlCLHVCQUFDLFVBQTJCLE9BQU9BLEtBQUtMLFVBQ3JDSyxlQUFLTCxZQURLSyxLQUFLTCxVQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQ1Z6QixrQ0FDRyw4Q0FDQSwwQkFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxzQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQSxjQUN0RTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLE9BQU9JLDBCQUEwQndQO0FBQUFBLGtCQUNqQyxVQUFVdkQ7QUFBQUEsa0JBQ1YsVUFBVSxDQUFDbk07QUFBQUEsa0JBQ1gsWUFBVTtBQUFBLGtCQUVUZ0Msa0NBQXdCbEI7QUFBQUEsb0JBQUksQ0FBQ3lDLFdBQzVCLHVCQUFDLFVBQW9CLE9BQU9BLFFBQ3pCQSxvQkFEVUEsUUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQ1Z2RCxxQ0FDRyw2Q0FDQSw2QkFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxVQUFVLENBQUNFO0FBQUFBLGdCQUNYLFNBQVMsTUFBTTtBQUNiLHdCQUFNMEIsT0FBT2xGLFVBQVVtRjtBQUFBQSxvQkFDckIsQ0FBQ2QsTUFDQ0EsRUFBRUMsY0FBY2xCLHlCQUNoQmlCLEVBQUVRLGFBQWF2Qiw0QkFDZmUsRUFBRWUsbUJBQW1CNUI7QUFBQUEsa0JBQ3pCO0FBQ0Esc0JBQUkwQixNQUFNO0FBQ1J2Qix5Q0FBcUI7QUFBQSxzQkFDbkJrQixVQUFVSyxLQUFLTDtBQUFBQSxzQkFDZlAsV0FBV1ksS0FBS1o7QUFBQUEsc0JBQ2hCMEMsV0FBVzlCLEtBQUs4QjtBQUFBQSxzQkFDaEI1QixnQkFBZ0JGLEtBQUtFO0FBQUFBLHNCQUNyQndCLFFBQVExQixLQUFLMEI7QUFBQUEsc0JBQ2JILFNBQVN2QixLQUFLdUI7QUFBQUEsc0JBQ2QwQixTQUFTakQsS0FBS2lEO0FBQUFBLHNCQUNkRSxjQUFjbkQsS0FBS21EO0FBQUFBLHNCQUNuQkUsY0FBY3JELEtBQUtxRDtBQUFBQSxvQkFDckIsQ0FBQztBQUFBLGtCQUNIO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0F6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsZUE1RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2RkE7QUFBQTtBQUFBO0FBQUEsTUFuSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBb0hBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFFBQ1AsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNO0FBQ2JwRixrQ0FBd0IsS0FBSztBQUM3QlEsK0JBQXFCLElBQUk7QUFDekJFLDhCQUFvQixFQUFFO0FBQ3RCRSw4QkFBb0IsRUFBRTtBQUFBLFFBQ3hCO0FBQUEsUUFDQSxNQUFNLENBQUMsQ0FBQ0w7QUFBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxXQUFXLEVBQUUyUCxTQUFTLElBQUk7QUFBQSxRQUMxQixVQUFVO0FBQUEsUUFFVDNQLCtCQUNDLHVCQUFDLFNBQUksV0FBVSxpQ0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSxtQkFBa0Isa0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsY0FDL0QsdUJBQUMsUUFBSyxXQUFVLFdBQVUsdUVBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlGO0FBQUEsaUJBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsTUFBTSx1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBLGdCQUN4QixTQUFTLE1BQU07QUFDYkMsdUNBQXFCLElBQUk7QUFDekJFLHNDQUFvQixFQUFFO0FBQ3RCRSxzQ0FBb0IsRUFBRTtBQUFBLGdCQUN4QjtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FFYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLHFDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsUUFBTyxvQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxjQUN0RCx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSw4Q0FBNkMsd0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNGO0FBQUEsa0JBQ3RGLHVCQUFDLFFBQUssUUFBTSxNQUFDLFdBQVUsYUFBYUwsNEJBQWtCbUIsWUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0Q7QUFBQSxxQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFLLE1BQUssYUFBWSxXQUFVLDhDQUE2QyxxQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUY7QUFBQSxrQkFDbkYsdUJBQUMsUUFBSyxRQUFNLE1BQUMsV0FBVSxhQUFhbkIsNEJBQWtCc0QsYUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0U7QUFBQSxxQkFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFLLE1BQUssYUFBWSxXQUFVLDhDQUE2QyxxQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUY7QUFBQSxrQkFDbkYsdUJBQUMsUUFBSyxRQUFNLE1BQUMsV0FBVSxhQUFhdEQsNEJBQWtCWSxhQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRTtBQUFBLHFCQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsOENBQTZDLHNCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRjtBQUFBLGtCQUNwRix1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQWFaLDRCQUFrQjBCLGtCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRTtBQUFBLHFCQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsOENBQTZDLCtCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RjtBQUFBLGtCQUM3Rix1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQVk7QUFBQTtBQUFBLG9CQUFFaUUsT0FBTzNGLGtCQUFrQnlFLFdBQVcsQ0FBQyxFQUFFMkgsZUFBZSxPQUFPO0FBQUEsdUJBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9HO0FBQUEscUJBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSw4Q0FBNkMsK0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZGO0FBQUEsa0JBQzdGLHVCQUFDLFFBQUssUUFBTSxNQUFDLFdBQVUsYUFBWTtBQUFBO0FBQUEsb0JBQUV6RyxPQUFPM0Ysa0JBQWtCMkUsZ0JBQWdCLENBQUMsRUFBRXlILGVBQWUsT0FBTztBQUFBLHVCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RztBQUFBLHFCQUYzRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUssTUFBSyxhQUFZLFdBQVUsOENBQTZDLGdDQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RjtBQUFBLGtCQUM5Rix1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQVk7QUFBQTtBQUFBLG9CQUFFekcsT0FBTzNGLGtCQUFrQjZFLGdCQUFnQixDQUFDLEVBQUV1SCxlQUFlLE9BQU87QUFBQSx1QkFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUc7QUFBQSxxQkFGM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTZCQTtBQUFBLGlCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLFFBQU8scUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsY0FDdkQsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RTtBQUFBLGdCQUM5RTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT2xNO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ3dILE1BQU12SCxvQkFBb0J1SCxFQUFFRSxPQUFPd0QsS0FBSztBQUFBLG9CQUNuRCxhQUFZO0FBQUEsb0JBQ1osS0FBSztBQUFBLG9CQUNMLE1BQU07QUFBQSxvQkFDTixXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBO0FBQUEsa0JBUmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFpQjtBQUFBLG1CQVZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsK0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStFO0FBQUEsZ0JBQy9FO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPaEw7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDc0gsTUFBTXJILG9CQUFvQnFILEVBQUVFLE9BQU93RCxLQUFLO0FBQUEsb0JBQ25ELGFBQVk7QUFBQSxvQkFDWixLQUFLO0FBQUEsb0JBQ0wsTUFBTTtBQUFBLG9CQUNOLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUE7QUFBQSxrQkFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUWlCO0FBQUEsbUJBVm5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxpQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLGFBQVk7QUFBQSxnQkFDWixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtrQjtBQUFBLFlBR2xCLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU07QUFDYm5MLHlDQUFxQixJQUFJO0FBQ3pCRSx3Q0FBb0IsRUFBRTtBQUN0QkUsd0NBQW9CLEVBQUU7QUFBQSxrQkFDeEI7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFVBQVVDLHFCQUFzQixDQUFDSixvQkFBb0IsQ0FBQ0U7QUFBQUEsa0JBQ3RELFNBQVM0TDtBQUFBQSxrQkFDVCxTQUFTMUw7QUFBQUEsa0JBQWtCO0FBQUE7QUFBQSxnQkFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxpQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQkE7QUFBQSxlQWhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlHQTtBQUFBLGFBdkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3SEE7QUFBQTtBQUFBLE1BdklKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXlJQTtBQUFBLE9BanRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa3RDQTtBQUVKO0FBQUV0RSxHQXBsRUlELGdCQUFjO0FBQUEsVUFDREwsV0FBVztBQUFBO0FBQUE4VSxLQUR4QnpVO0FBc2xFTixlQUFlQTtBQUFlLElBQUF5VTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJNb2RhbCIsIlRhYmxlIiwibWVzc2FnZSIsIkNhcmQiLCJTdGF0aXN0aWMiLCJSb3ciLCJDb2wiLCJCdXR0b24iLCJEYXRlUGlja2VyIiwiSW5wdXQiLCJUYWciLCJDaGVja2JveCIsIkRyb3Bkb3duIiwiTWVudSIsIlNwYWNlIiwiRHJhd2VyIiwiRGl2aWRlciIsIlR5cG9ncmFwaHkiLCJBbGVydCIsIlByb2dyZXNzIiwiVG9vbHRpcCIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIm1vbWVudCIsIlNlYXJjaE91dGxpbmVkIiwiRXllT3V0bGluZWQiLCJGaWx0ZXJPdXRsaW5lZCIsIlVzZXJncm91cEFkZE91dGxpbmVkIiwiUGhvbmVPdXRsaW5lZCIsIkNsb3NlQ2lyY2xlT3V0bGluZWQiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiTWVzc2FnZU91dGxpbmVkIiwiV2FybmluZ091dGxpbmVkIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkRvbGxhckNpcmNsZU91dGxpbmVkIiwiU2VuZE91dGxpbmVkIiwiRG93bk91dGxpbmVkIiwiQXJyb3dMZWZ0T3V0bGluZWQiLCJVbmRvT3V0bGluZWQiLCJJbmZvQ2lyY2xlT3V0bGluZWQiLCJDYWxjdWxhdG9yT3V0bGluZWQiLCJXYWxsZXRPdXRsaW5lZCIsIkV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQiLCJEb3dubG9hZE91dGxpbmVkIiwiUGx1c091dGxpbmVkIiwiQWlGaWxsQmFja3dhcmQiLCJTaWRlYmFyIiwidXNlTmF2aWdhdGUiLCJSYW5nZVBpY2tlciIsIk9wdGlvbiIsIlRpdGxlIiwiVGV4dCIsIlBlbmFsdHlNb25pdG9yIiwiX3MiLCJuYXZpZ2F0ZSIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwic2NyZWVuTG9hZGluZyIsInNldFNjcmVlbkxvYWRpbmciLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsIm1vbnRobHlDb2xsZWN0ZWRTdW1tYXJ5Iiwic2V0TW9udGhseUNvbGxlY3RlZFN1bW1hcnkiLCJtb250aGx5Q29sbGVjdGVkRGV0YWlscyIsInNldE1vbnRobHlDb2xsZWN0ZWREZXRhaWxzIiwibW9udGhseUNvbGxlY3RlZExvYWRpbmciLCJzZXRNb250aGx5Q29sbGVjdGVkTG9hZGluZyIsIm1vbnRobHlEZXRhaWxzTW9kYWxWaXNpYmxlIiwic2V0TW9udGhseURldGFpbHNNb2RhbFZpc2libGUiLCJicmVha2Rvd25Nb2RhbCIsInNldEJyZWFrZG93bk1vZGFsIiwiYnJlYWtkb3duRGF0YSIsInNldEJyZWFrZG93bkRhdGEiLCJzZWxlY3RlZEN1c3RvbWVyIiwic2V0U2VsZWN0ZWRDdXN0b21lciIsImxvYWRpbmdCcmVha2Rvd24iLCJzZXRMb2FkaW5nQnJlYWtkb3duIiwic2VsZWN0ZWRSb3dzIiwic2V0U2VsZWN0ZWRSb3dzIiwic2VuZE1vZGFsIiwic2V0U2VuZE1vZGFsIiwib3BlbiIsInR5cGUiLCJyZXZlcnNhbEdyb3VwRmlsdGVyIiwic2V0UmV2ZXJzYWxHcm91cEZpbHRlciIsInJldmVyc2FsQ3VzdG9tZXJGaWx0ZXIiLCJzZXRSZXZlcnNhbEN1c3RvbWVyRmlsdGVyIiwicmV2ZXJzYWxUaWNrZXRGaWx0ZXIiLCJzZXRSZXZlcnNhbFRpY2tldEZpbHRlciIsInJldmVyc2FsRHJhd2VyT3BlbiIsInNldFJldmVyc2FsRHJhd2VyT3BlbiIsInBlbmFsdHlTdW1tYXJ5RHJhd2VyIiwic2V0UGVuYWx0eVN1bW1hcnlEcmF3ZXIiLCJwZW5hbHR5U3VtbWFyeSIsInNldFBlbmFsdHlTdW1tYXJ5Iiwic2VsZWN0ZWRSZXZlcnNhbFR5cGUiLCJzZXRTZWxlY3RlZFJldmVyc2FsVHlwZSIsInJldmVyc2VBbW91bnREcmF3ZXIiLCJzZXRSZXZlcnNlQW1vdW50RHJhd2VyIiwicmV2ZXJzZUFtb3VudCIsInNldFJldmVyc2VBbW91bnQiLCJtYXhBbGxvd2VkQW1vdW50Iiwic2V0TWF4QWxsb3dlZEFtb3VudCIsImFkZFBlbmFsdHlEcmF3ZXJPcGVuIiwic2V0QWRkUGVuYWx0eURyYXdlck9wZW4iLCJhZGRQZW5hbHR5R3JvdXBGaWx0ZXIiLCJzZXRBZGRQZW5hbHR5R3JvdXBGaWx0ZXIiLCJhZGRQZW5hbHR5Q3VzdG9tZXJGaWx0ZXIiLCJzZXRBZGRQZW5hbHR5Q3VzdG9tZXJGaWx0ZXIiLCJhZGRQZW5hbHR5VGlja2V0RmlsdGVyIiwic2V0QWRkUGVuYWx0eVRpY2tldEZpbHRlciIsImFkZFBlbmFsdHlEZXRhaWxzIiwic2V0QWRkUGVuYWx0eURldGFpbHMiLCJhZGRQZW5hbHR5QW1vdW50Iiwic2V0QWRkUGVuYWx0eUFtb3VudCIsImFkZExhdGVGZWVBbW91bnQiLCJzZXRBZGRMYXRlRmVlQW1vdW50IiwiYWRkUGVuYWx0eUxvYWRpbmciLCJzZXRBZGRQZW5hbHR5TG9hZGluZyIsImdyb3VwT3B0aW9ucyIsIlNldCIsIm1hcCIsInUiLCJncm91cE5hbWUiLCJjdXN0b21lck9wdGlvbnMiLCJjdXN0b21lcnMiLCJNYXAiLCJmaWx0ZXIiLCJmb3JFYWNoIiwic2V0IiwidXNlck5hbWUiLCJBcnJheSIsImZyb20iLCJ2YWx1ZXMiLCJ0aWNrZXRPcHRpb25zIiwidXNlciIsImZpbmQiLCJwYXltZW50c1RpY2tldCIsImFkZFBlbmFsdHlDdXN0b21lck9wdGlvbnMiLCJhZGRQZW5hbHR5VGlja2V0T3B0aW9ucyIsImZpbHRlcmVkVXNlcnMiLCJtYXRjaEdyb3VwIiwiZW5yb2xsbWVudERhdGUiLCJEYXRlIiwibWF0Y2hGcm9tRGF0ZSIsIm1hdGNoVG9EYXRlIiwiZmV0Y2hEYXRhIiwicGVuYWx0eVJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsInN1Y2Nlc3MiLCJlcnJvciIsImFsbFBlbmFsdHlEYXRhIiwicmVwb3J0UmVzcG9uc2UiLCJ1c2VyRGV0YWlsc01hcCIsInVzckRhdGEiLCJlbnJvbGxtZW50IiwiZ3JvdXAiLCJncm91cElkIiwiU3RyaW5nIiwiX2lkIiwidXNlcklkIiwidGlja2V0IiwicGF5bWVudHMiLCJ0cmltIiwidXNlclBob25lIiwicGhvbmVfbnVtYmVyIiwiY3VzdG9tZXJJZCIsImN1c3RvbWVyX2lkIiwiY3JlYXRlZEF0Iiwic3BsaXQiLCJpc1ByaXplZCIsInVzZXJzTGlzdCIsImNvdW50IiwicGVuYWx0eURhdGEiLCJ1c2VyX2lkIiwiZ3JvdXBfaWQiLCJ0aWNrZXRfbnVtYmVyIiwidXNlckRldGFpbHMiLCJzdW1tYXJ5IiwiYW1vdW50VG9CZVBhaWQiLCJ0b3RhbF9leHBlY3RlZCIsImFtb3VudFBhaWQiLCJ0b3RhbF9wYWlkIiwiYmFsYW5jZSIsImdyYW5kX3RvdGFsX2R1ZV93aXRoX3BlbmFsdHkiLCJ0b3RhbFBlbmFsdHkiLCJ0b3RhbF9wZW5hbHR5IiwidG90YWxMYXRlRmVlIiwidG90YWxfbGF0ZV9wYXltZW50X2NoYXJnZXMiLCJ2Y1BlbmFsdHkiLCJ0b3RhbF92YWNhbnRfY2hpdF9wZW5hbHR5IiwicmVndWxhclBlbmFsdHkiLCJtYW51YWxfcGVuYWx0eSIsIm1hbnVhbFBlbmFsdHkiLCJtYW51YWxMYXRlRmVlIiwibWFudWFsX2xhdGVfZmVlIiwidG90YWxPdmVyZHVlQ2hhcmdlcyIsImJhbGFuY2VXaXRob3V0UGVuYWx0eSIsInRvZGF5Iiwic3RhcnRPZiIsInZhY2FudEdyYWNlRGF5cyIsIk51bWJlciIsInZhY2FudF9ncmFjZV9kYXlzIiwidmNHcmFjZUVuZCIsImNsb25lIiwiYWRkIiwiaXNWY1dpdGhpbkdyYWNlIiwiaXNWY1BlbmFsdHlBcHBsaWVkIiwidmFjYW50Q3ljbGVzIiwiY3ljbGVzIiwiYyIsInZhY2FudF9jeWNsZSIsImxlbmd0aCIsImlzU2FtZU9yQmVmb3JlIiwid2hhdHNhcHBBY3Rpb25zIiwiaGFuZGxlU2hvd0JyZWFrZG93biIsImdyb3VwX25hbWUiLCJ1c2VyUmVjb3JkIiwiZW5yb2xsbWVudF9pZCIsInNsX25vIiwidG90YWxUb0JlUGFpZCIsImNvbWJpbmVkUGVuYWx0eSIsImFjdGlvbnMiLCJzdGF0dXNEaXYiLCJoYXNQZW5hbHR5T3JMYXRlRmVlIiwicHVzaCIsImNvbnNvbGUiLCJmZXRjaE1vbnRobHlDb2xsZWN0ZWQiLCJyZXMiLCJkZXRhaWxzIiwiZXJyIiwiaGFuZGxlS2V5RG93biIsImUiLCJpbmNsdWRlcyIsInRhcmdldCIsInRhZ05hbWUiLCJjdHJsS2V5Iiwic2hpZnRLZXkiLCJrZXkiLCJ0b0xvd2VyQ2FzZSIsInByZXZlbnREZWZhdWx0Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJ0b3RhbHMiLCJzZXRUb3RhbHMiLCJ0b3RhbEN1c3RvbWVycyIsInRvdGFsR3JvdXBzIiwidG90YWxQYWlkIiwidG90YWxCYWxhbmNlIiwidG90YWxSZWd1bGFyUGVuYWx0eSIsInRvdGFsVmNQZW5hbHR5IiwidG90YWxUaWNrZXRzIiwidG90YWxCYWxhbmNlV2l0aG91dFBlbmFsdHkiLCJ0b3RhbE91dHN0YW5kaW5nV2l0aFBlbmFsdHkiLCJ0b3RhbFBlbmFsdHlBbmRMYXRlRmVlIiwidG90YWxNYW51YWxQZW5hbHR5IiwidG90YWxNYW51YWxMYXRlRmVlIiwidW5pcXVlQ3VzdG9tZXJJZHMiLCJzaXplIiwiZ3JvdXBTZXQiLCJyZWR1Y2UiLCJzdW0iLCJjYWNoZWRQZW5hbHR5RGF0YSIsInBhcmFtcyIsImNhbGN1bGF0ZUdyYWNlRGF5c0xlZnQiLCJlbnJvbGxtZW50RGF0ZVN0ciIsImdyYWNlRW5kIiwiTWF0aCIsIm1heCIsImRpZmYiLCJjYWxjdWxhdGVEYXlzTGF0ZSIsImxhc3REdWUiLCJzZW5kU2luZ2xlV2hhdHNhcHAiLCJwYXlsb2FkIiwiaW5mbyIsInN0YXR1cyIsImV4cGVjdGVkIiwiZ3JhY2VEYXlzTGVmdCIsImFwcGxpZWRWY0Ftb3VudCIsImRheXNMYXRlIiwibGF0ZUZlZSIsInBlbmFsdHkiLCJlbmRwb2ludCIsIkVycm9yIiwicG9zdCIsImhhbmRsZVNlbmRXaGF0c2FwcCIsImlkeCIsIm9wZW5TZW5kTW9kYWwiLCJoYW5kbGVHcm91cFNlbGVjdCIsInZhbHVlIiwiaGFuZGxlQ3VzdG9tZXJTZWxlY3QiLCJoYW5kbGVUaWNrZXRTZWxlY3QiLCJvcGVuUmV2ZXJzZUFtb3VudERyYXdlciIsIm1heEFtb3VudCIsImhhbmRsZUFwcGx5UmV2ZXJzYWwiLCJhbW91bnQiLCJwYXJzZUZsb2F0IiwidG9GaXhlZCIsImhhbmRsZUFkZFBlbmFsdHlHcm91cFNlbGVjdCIsImhhbmRsZUFkZFBlbmFsdHlDdXN0b21lclNlbGVjdCIsImhhbmRsZUFkZFBlbmFsdHlUaWNrZXRTZWxlY3QiLCJoYW5kbGVTYXZlUGVuYWx0eSIsInBlbmFsdHlfYW1vdW50IiwibGF0ZV9mZWVfYW1vdW50IiwiZm9ybWF0QW1vdW50IiwidG9Mb2NhbGVTdHJpbmciLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJtYXhpbXVtRnJhY3Rpb25EaWdpdHMiLCJjb2x1bW5zIiwiaGVhZGVyIiwicmVuZGVyIiwidGV4dCIsInJlY29yZCIsImluZGV4IiwiZm9ybWF0IiwiYnJlYWtkb3duQ29sdW1ucyIsInRpdGxlIiwiZGF0YUluZGV4IiwiYWxpZ24iLCJ3aWR0aCIsInJvdyIsImZvbnRXZWlnaHQiLCJ2IiwiY29sb3IiLCJleHBvcnRCcmVha2Rvd25Ub0NTViIsIndhcm5pbmciLCJoZWFkZXJzIiwiY3N2Q29udGVudCIsImpvaW4iLCJhdWN0aW9uIiwiY3ljbGVfbm8iLCJkdWVEYXRlIiwidG9fZGF0ZSIsInBhaWQiLCJsYXRlX3BheW1lbnRfY2hhcmdlcyIsInBlbmFsdHlSYXRlIiwicGVuYWx0eV9yYXRlX3BlcmNlbnQiLCJlc2NhcGUiLCJ2YWwiLCJyZXBsYWNlIiwiYmxvYiIsIkJsb2IiLCJ1cmwiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJsaW5rIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiaHJlZiIsInNldEF0dHJpYnV0ZSIsImJvZHkiLCJhcHBlbmRDaGlsZCIsImNsaWNrIiwicmVtb3ZlQ2hpbGQiLCJyZXZva2VPYmplY3RVUkwiLCJ1bmRlZmluZWQiLCJ0b3RhbENvbGxlY3RlZCIsInNvbWUiLCJwcm9wcyIsImNoaWxkcmVuIiwicGFkZGluZyIsImQiLCJpIiwieCIsInkiLCJzIiwibG9hZGluZyIsImRhbmdlciIsInNsaWNlIiwicGFnZVNpemUiLCJuYW1lIiwiciIsIm1pbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBlbmFsdHlNb25pdG9yLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBNb2RhbCxcclxuICBUYWJsZSxcclxuICBtZXNzYWdlLFxyXG4gIENhcmQsXHJcbiAgU3RhdGlzdGljLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbiAgQnV0dG9uLFxyXG4gIERhdGVQaWNrZXIsXHJcbiAgSW5wdXQsXHJcbiAgVGFnLFxyXG4gIENoZWNrYm94LFxyXG4gIERyb3Bkb3duLFxyXG4gIE1lbnUsXHJcbiAgU3BhY2UsXHJcbiAgRHJhd2VyLFxyXG4gIERpdmlkZXIsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBBbGVydCxcclxuICBQcm9ncmVzcyxcclxuICBUb29sdGlwLFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IG1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCB7XHJcbiAgU2VhcmNoT3V0bGluZWQsXHJcbiAgRXllT3V0bGluZWQsXHJcbiAgRmlsdGVyT3V0bGluZWQsXHJcbiAgVXNlcmdyb3VwQWRkT3V0bGluZWQsXHJcbiAgUGhvbmVPdXRsaW5lZCxcclxuICBDbG9zZUNpcmNsZU91dGxpbmVkLFxyXG4gIENoZWNrQ2lyY2xlT3V0bGluZWQsXHJcbiAgTWVzc2FnZU91dGxpbmVkLFxyXG4gIFdhcm5pbmdPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIERvbGxhckNpcmNsZU91dGxpbmVkLFxyXG4gIFNlbmRPdXRsaW5lZCxcclxuICBEb3duT3V0bGluZWQsXHJcbiAgQXJyb3dMZWZ0T3V0bGluZWQsXHJcbiAgVW5kb091dGxpbmVkLFxyXG4gIEluZm9DaXJjbGVPdXRsaW5lZCxcclxuICBDYWxjdWxhdG9yT3V0bGluZWQsXHJcbiAgV2FsbGV0T3V0bGluZWQsXHJcbiAgRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCxcclxuICBEb3dubG9hZE91dGxpbmVkLFxyXG4gIFBsdXNPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHsgQWlGaWxsQmFja3dhcmQgfSBmcm9tIFwicmVhY3QtaWNvbnMvYWlcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcblxyXG5jb25zdCB7IFJhbmdlUGlja2VyIH0gPSBEYXRlUGlja2VyO1xyXG5jb25zdCB7IE9wdGlvbiB9ID0gU2VsZWN0O1xyXG5jb25zdCB7IFRpdGxlLCBUZXh0IH0gPSBUeXBvZ3JhcGh5O1xyXG5cclxuY29uc3QgUGVuYWx0eU1vbml0b3IgPSAoKSA9PiB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzY3JlZW5Mb2FkaW5nLCBzZXRTY3JlZW5Mb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21vbnRobHlDb2xsZWN0ZWRTdW1tYXJ5LCBzZXRNb250aGx5Q29sbGVjdGVkU3VtbWFyeV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbW9udGhseUNvbGxlY3RlZERldGFpbHMsIHNldE1vbnRobHlDb2xsZWN0ZWREZXRhaWxzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbW9udGhseUNvbGxlY3RlZExvYWRpbmcsIHNldE1vbnRobHlDb2xsZWN0ZWRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9udGhseURldGFpbHNNb2RhbFZpc2libGUsIHNldE1vbnRobHlEZXRhaWxzTW9kYWxWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8gTW9kYWwgZm9yIGJyZWFrZG93blxyXG4gIGNvbnN0IFticmVha2Rvd25Nb2RhbCwgc2V0QnJlYWtkb3duTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFticmVha2Rvd25EYXRhLCBzZXRCcmVha2Rvd25EYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRDdXN0b21lciwgc2V0U2VsZWN0ZWRDdXN0b21lcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbG9hZGluZ0JyZWFrZG93biwgc2V0TG9hZGluZ0JyZWFrZG93bl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIFdoYXRzQXBwIFNlbGVjdGlvbiAmIE1vZGFsXHJcbiAgY29uc3QgW3NlbGVjdGVkUm93cywgc2V0U2VsZWN0ZWRSb3dzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VuZE1vZGFsLCBzZXRTZW5kTW9kYWxdID0gdXNlU3RhdGUoeyBvcGVuOiBmYWxzZSwgdHlwZTogbnVsbCB9KTtcclxuXHJcbiAgLy8gUGVuYWx0eSBSZXZlcnNhbCBTdGF0ZVxyXG4gIGNvbnN0IFtyZXZlcnNhbEdyb3VwRmlsdGVyLCBzZXRSZXZlcnNhbEdyb3VwRmlsdGVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZXZlcnNhbEN1c3RvbWVyRmlsdGVyLCBzZXRSZXZlcnNhbEN1c3RvbWVyRmlsdGVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZXZlcnNhbFRpY2tldEZpbHRlciwgc2V0UmV2ZXJzYWxUaWNrZXRGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3JldmVyc2FsRHJhd2VyT3Blbiwgc2V0UmV2ZXJzYWxEcmF3ZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGVuYWx0eVN1bW1hcnlEcmF3ZXIsIHNldFBlbmFsdHlTdW1tYXJ5RHJhd2VyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGVuYWx0eVN1bW1hcnksIHNldFBlbmFsdHlTdW1tYXJ5XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFJldmVyc2FsVHlwZSwgc2V0U2VsZWN0ZWRSZXZlcnNhbFR5cGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JldmVyc2VBbW91bnREcmF3ZXIsIHNldFJldmVyc2VBbW91bnREcmF3ZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZXZlcnNlQW1vdW50LCBzZXRSZXZlcnNlQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFttYXhBbGxvd2VkQW1vdW50LCBzZXRNYXhBbGxvd2VkQW1vdW50XSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICAvLyBBZGQgUGVuYWx0eSBTdGF0ZVxyXG4gIGNvbnN0IFthZGRQZW5hbHR5RHJhd2VyT3Blbiwgc2V0QWRkUGVuYWx0eURyYXdlck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZGRQZW5hbHR5R3JvdXBGaWx0ZXIsIHNldEFkZFBlbmFsdHlHcm91cEZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkUGVuYWx0eUN1c3RvbWVyRmlsdGVyLCBzZXRBZGRQZW5hbHR5Q3VzdG9tZXJGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FkZFBlbmFsdHlUaWNrZXRGaWx0ZXIsIHNldEFkZFBlbmFsdHlUaWNrZXRGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FkZFBlbmFsdHlEZXRhaWxzLCBzZXRBZGRQZW5hbHR5RGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYWRkUGVuYWx0eUFtb3VudCwgc2V0QWRkUGVuYWx0eUFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkTGF0ZUZlZUFtb3VudCwgc2V0QWRkTGF0ZUZlZUFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkUGVuYWx0eUxvYWRpbmcsIHNldEFkZFBlbmFsdHlMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpKV07XHJcblxyXG4gIC8vIEN1c3RvbWVyICYgVGlja2V0IE9wdGlvbnMgZm9yIFJldmVyc2FsIEZpbHRlcnNcclxuICBjb25zdCBjdXN0b21lck9wdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmICghcmV2ZXJzYWxHcm91cEZpbHRlcikgcmV0dXJuIFtdO1xyXG4gICAgY29uc3QgY3VzdG9tZXJzID0gbmV3IE1hcCgpO1xyXG4gICAgdXNlcnNEYXRhXHJcbiAgICAgIC5maWx0ZXIodSA9PiB1Lmdyb3VwTmFtZSA9PT0gcmV2ZXJzYWxHcm91cEZpbHRlcilcclxuICAgICAgLmZvckVhY2godSA9PiBjdXN0b21lcnMuc2V0KHUudXNlck5hbWUsIHUpKTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKGN1c3RvbWVycy52YWx1ZXMoKSk7XHJcbiAgfSwgW3VzZXJzRGF0YSwgcmV2ZXJzYWxHcm91cEZpbHRlcl0pO1xyXG5cclxuICBjb25zdCB0aWNrZXRPcHRpb25zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIXJldmVyc2FsQ3VzdG9tZXJGaWx0ZXIpIHJldHVybiBbXTtcclxuICAgIGNvbnN0IHVzZXIgPSB1c2Vyc0RhdGEuZmluZChcclxuICAgICAgdSA9PiB1Lmdyb3VwTmFtZSA9PT0gcmV2ZXJzYWxHcm91cEZpbHRlciAmJiB1LnVzZXJOYW1lID09PSByZXZlcnNhbEN1c3RvbWVyRmlsdGVyXHJcbiAgICApO1xyXG4gICAgcmV0dXJuIHVzZXIgPyBbdXNlci5wYXltZW50c1RpY2tldF0gOiBbXTtcclxuICB9LCBbdXNlcnNEYXRhLCByZXZlcnNhbEdyb3VwRmlsdGVyLCByZXZlcnNhbEN1c3RvbWVyRmlsdGVyXSk7XHJcblxyXG4gIC8vIEN1c3RvbWVyICYgVGlja2V0IE9wdGlvbnMgZm9yIEFkZCBQZW5hbHR5XHJcbiAgY29uc3QgYWRkUGVuYWx0eUN1c3RvbWVyT3B0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFhZGRQZW5hbHR5R3JvdXBGaWx0ZXIpIHJldHVybiBbXTtcclxuICAgIGNvbnN0IGN1c3RvbWVycyA9IG5ldyBNYXAoKTtcclxuICAgIHVzZXJzRGF0YVxyXG4gICAgICAuZmlsdGVyKHUgPT4gdS5ncm91cE5hbWUgPT09IGFkZFBlbmFsdHlHcm91cEZpbHRlcilcclxuICAgICAgLmZvckVhY2godSA9PiBjdXN0b21lcnMuc2V0KHUudXNlck5hbWUsIHUpKTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKGN1c3RvbWVycy52YWx1ZXMoKSk7XHJcbiAgfSwgW3VzZXJzRGF0YSwgYWRkUGVuYWx0eUdyb3VwRmlsdGVyXSk7XHJcblxyXG4gIGNvbnN0IGFkZFBlbmFsdHlUaWNrZXRPcHRpb25zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIWFkZFBlbmFsdHlDdXN0b21lckZpbHRlcikgcmV0dXJuIFtdO1xyXG4gICAgY29uc3QgdXNlciA9IHVzZXJzRGF0YS5maW5kKFxyXG4gICAgICB1ID0+IHUuZ3JvdXBOYW1lID09PSBhZGRQZW5hbHR5R3JvdXBGaWx0ZXIgJiYgdS51c2VyTmFtZSA9PT0gYWRkUGVuYWx0eUN1c3RvbWVyRmlsdGVyXHJcbiAgICApO1xyXG4gICAgcmV0dXJuIHVzZXIgPyBbdXNlci5wYXltZW50c1RpY2tldF0gOiBbXTtcclxuICB9LCBbdXNlcnNEYXRhLCBhZGRQZW5hbHR5R3JvdXBGaWx0ZXIsIGFkZFBlbmFsdHlDdXN0b21lckZpbHRlcl0pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyT3B0aW9uKFxyXG4gICAgICB1c2Vyc0RhdGEuZmlsdGVyKCh1KSA9PiB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50RGF0ZSA9IG5ldyBEYXRlKHUuZW5yb2xsbWVudERhdGUpO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZSA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZyb21EYXRlKSA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hUb0RhdGUgPSB0b0RhdGUgPyBlbnJvbGxtZW50RGF0ZSA8PSBuZXcgRGF0ZSh0b0RhdGUpIDogdHJ1ZTtcclxuICAgICAgICByZXR1cm4gbWF0Y2hHcm91cCAmJiBtYXRjaEZyb21EYXRlICYmIG1hdGNoVG9EYXRlO1xyXG4gICAgICB9KSxcclxuICAgICAgc2VhcmNoVGV4dFxyXG4gICAgKTtcclxuICB9LCBbdXNlcnNEYXRhLCBncm91cEZpbHRlciwgZnJvbURhdGUsIHRvRGF0ZSwgc2VhcmNoVGV4dF0pO1xyXG5cclxuICAvLyBGZXRjaCBEYXRhIEZ1bmN0aW9uIC0gVXBkYXRlZCB0byB1c2UgYmFja2VuZCBjYWxjdWxhdGlvbnNcclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRTY3JlZW5Mb2FkaW5nKHRydWUpO1xyXG4gICAgICAvLyBGZXRjaCBwZW5hbHR5IHJlcG9ydCBmcm9tIGJhY2tlbmRcclxuICAgICAgY29uc3QgcGVuYWx0eVJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9wZW5hbHR5L2dldC1wZW5hbHR5LXJlcG9ydFwiKTtcclxuICAgICAgXHJcbiAgICAgIGlmICghcGVuYWx0eVJlc3BvbnNlLmRhdGE/LnN1Y2Nlc3MgfHwgIXBlbmFsdHlSZXNwb25zZS5kYXRhPy5kYXRhKSB7XHJcbiAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBsb2FkIHBlbmFsdHkgbW9uaXRvciBkYXRhXCIpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgYWxsUGVuYWx0eURhdGEgPSBwZW5hbHR5UmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICBcclxuICAgICAgLy8gRmV0Y2ggdXNlciBkZXRhaWxzIGZvciBhZGRpdGlvbmFsIGluZm9ybWF0aW9uXHJcbiAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2FsbC1jdXN0b21lcnMtcmVwb3J0XCIpO1xyXG4gICAgICBcclxuICAgICAgLy8gQ3JlYXRlIGEgbWFwIG9mIHVzZXIgZGV0YWlscyBmb3IgcXVpY2sgbG9va3VwXHJcbiAgICAgIGNvbnN0IHVzZXJEZXRhaWxzTWFwID0gbmV3IE1hcCgpO1xyXG4gICAgICBpZiAocmVwb3J0UmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgIGZvciAoY29uc3QgdXNyRGF0YSBvZiByZXBvcnRSZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBpZiAodXNyRGF0YT8uZGF0YSkge1xyXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGRhdGEgb2YgdXNyRGF0YS5kYXRhKSB7XHJcbiAgICAgICAgICAgICAgaWYgKGRhdGE/LmVucm9sbG1lbnQ/Lmdyb3VwKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gU3RyaW5nKGRhdGEuZW5yb2xsbWVudC5ncm91cC5faWQpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdXNlcklkID0gU3RyaW5nKHVzckRhdGEuX2lkKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHRpY2tldCA9IFN0cmluZyhkYXRhLnBheW1lbnRzLnRpY2tldCB8fCBcIlwiKS50cmltKCk7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIHVzZXJEZXRhaWxzTWFwLnNldChgJHt1c2VySWR9XyR7Z3JvdXBJZH1fJHt0aWNrZXR9YCwge1xyXG4gICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNyRGF0YS51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c3JEYXRhLnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJJZDogdXNyRGF0YS5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgZW5yb2xsbWVudERhdGU6IGRhdGEuZW5yb2xsbWVudC5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICBpc1ByaXplZDogZGF0YS5pc1ByaXplZCA9PT0gXCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gUHJvY2VzcyBwZW5hbHR5IGRhdGEgZnJvbSBiYWNrZW5kXHJcbiAgICAgIGNvbnN0IHVzZXJzTGlzdCA9IFtdO1xyXG4gICAgICBsZXQgY291bnQgPSAxO1xyXG4gICAgICBcclxuICAgICAgZm9yIChjb25zdCBwZW5hbHR5RGF0YSBvZiBhbGxQZW5hbHR5RGF0YSkge1xyXG4gICAgICAgIGNvbnN0IHVzZXJJZCA9IFN0cmluZyhwZW5hbHR5RGF0YS51c2VyX2lkKTtcclxuICAgICAgICBjb25zdCBncm91cElkID0gU3RyaW5nKHBlbmFsdHlEYXRhLmdyb3VwX2lkKTtcclxuICAgICAgICBjb25zdCB0aWNrZXQgPSBTdHJpbmcocGVuYWx0eURhdGEudGlja2V0X251bWJlciB8fCBcIlwiKS50cmltKCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gR2V0IHVzZXIgZGV0YWlscyBmcm9tIG1hcFxyXG4gICAgICAgIGNvbnN0IHVzZXJEZXRhaWxzID0gdXNlckRldGFpbHNNYXAuZ2V0KGAke3VzZXJJZH1fJHtncm91cElkfV8ke3RpY2tldH1gKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAoIXVzZXJEZXRhaWxzKSBjb250aW51ZTtcclxuICAgICAgICBcclxuICAgICAgICBjb25zdCBzdW1tYXJ5ID0gcGVuYWx0eURhdGEuc3VtbWFyeSB8fCB7fTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBFeHRyYWN0IHZhbHVlcyBmcm9tIGJhY2tlbmQgY2FsY3VsYXRpb25cclxuICAgICAgICBjb25zdCBhbW91bnRUb0JlUGFpZCA9IHN1bW1hcnkudG90YWxfZXhwZWN0ZWQgfHwgMDtcclxuICAgICAgICBjb25zdCBhbW91bnRQYWlkID0gc3VtbWFyeS50b3RhbF9wYWlkIHx8IDA7XHJcbiAgICAgICAgY29uc3QgYmFsYW5jZSA9IHN1bW1hcnkuZ3JhbmRfdG90YWxfZHVlX3dpdGhfcGVuYWx0eSB8fCAwO1xyXG4gICAgICAgIGNvbnN0IHRvdGFsUGVuYWx0eSA9IHN1bW1hcnkudG90YWxfcGVuYWx0eSB8fCAwO1xyXG4gICAgICAgIGNvbnN0IHRvdGFsTGF0ZUZlZSA9IHN1bW1hcnkudG90YWxfbGF0ZV9wYXltZW50X2NoYXJnZXMgfHwgMDtcclxuICAgICAgICBjb25zdCB2Y1BlbmFsdHkgPSBzdW1tYXJ5LnRvdGFsX3ZhY2FudF9jaGl0X3BlbmFsdHkgfHwgMDtcclxuICAgICAgICBjb25zdCByZWd1bGFyUGVuYWx0eSA9IHRvdGFsUGVuYWx0eSAtIHZjUGVuYWx0eSAtIChzdW1tYXJ5Lm1hbnVhbF9wZW5hbHR5IHx8IDApO1xyXG4gICAgICAgIGNvbnN0IG1hbnVhbFBlbmFsdHkgPSBzdW1tYXJ5Lm1hbnVhbF9wZW5hbHR5IHx8IDA7XHJcbiAgICAgICAgY29uc3QgbWFudWFsTGF0ZUZlZSA9IHN1bW1hcnkubWFudWFsX2xhdGVfZmVlIHx8IDA7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc3QgdG90YWxPdmVyZHVlQ2hhcmdlcyA9IHRvdGFsUGVuYWx0eSArIHRvdGFsTGF0ZUZlZTtcclxuICAgICAgICBjb25zdCBiYWxhbmNlV2l0aG91dFBlbmFsdHkgPSBhbW91bnRUb0JlUGFpZCAtIGFtb3VudFBhaWQ7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gRGV0ZXJtaW5lIFZDIHN0YXR1c1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gbW9tZW50KHVzZXJEZXRhaWxzLmVucm9sbG1lbnREYXRlKTtcclxuICAgICAgICBjb25zdCB0b2RheSA9IG1vbWVudCgpLnN0YXJ0T2YoXCJkYXlcIik7XHJcbiAgICAgICAgY29uc3QgdmFjYW50R3JhY2VEYXlzID0gTnVtYmVyKHBlbmFsdHlEYXRhLnZhY2FudF9ncmFjZV9kYXlzIHx8IDkwKTtcclxuICAgICAgICBjb25zdCB2Y0dyYWNlRW5kID0gZW5yb2xsbWVudERhdGUuY2xvbmUoKS5hZGQodmFjYW50R3JhY2VEYXlzLCBcImRheXNcIikuc3RhcnRPZihcImRheVwiKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgaXNWY1dpdGhpbkdyYWNlID0gZmFsc2U7XHJcbiAgICAgICAgbGV0IGlzVmNQZW5hbHR5QXBwbGllZCA9IGZhbHNlO1xyXG4gICAgICAgIGNvbnN0IHZhY2FudEN5Y2xlcyA9IHBlbmFsdHlEYXRhPy5jeWNsZXM/LmZpbHRlcigoYykgPT4gYy52YWNhbnRfY3ljbGUgPT09IHRydWUpIHx8IFtdO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh2YWNhbnRDeWNsZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgaWYgKHRvZGF5LmlzU2FtZU9yQmVmb3JlKHZjR3JhY2VFbmQsIFwiZGF5XCIpKSB7XHJcbiAgICAgICAgICAgIGlzVmNXaXRoaW5HcmFjZSA9IHRydWU7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpc1ZjUGVuYWx0eUFwcGxpZWQgPSB0cnVlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBjb25zdCB3aGF0c2FwcEFjdGlvbnMgPSAoXHJcbiAgICAgICAgICA8U3BhY2Ugc2l6ZT1cInNtYWxsXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgaWNvbj17PEV5ZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgIGhhbmRsZVNob3dCcmVha2Rvd24oXHJcbiAgICAgICAgICAgICAgICAgIHVzZXJJZCxcclxuICAgICAgICAgICAgICAgICAgZ3JvdXBJZCxcclxuICAgICAgICAgICAgICAgICAgdXNlckRldGFpbHMudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHBlbmFsdHlEYXRhLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHBlbmFsdHlEYXRhXHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgVmlld1xyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvU3BhY2U+XHJcbiAgICAgICAgKTtcclxuICAgICAgICBcclxuICAgICAgICBjb25zdCB1c2VyUmVjb3JkID0ge1xyXG4gICAgICAgICAgX2lkOiBwZW5hbHR5RGF0YS5lbnJvbGxtZW50X2lkLFxyXG4gICAgICAgICAgdXNlcklkLFxyXG4gICAgICAgICAgZ3JvdXBJZCxcclxuICAgICAgICAgIHNsX25vOiBjb3VudCxcclxuICAgICAgICAgIHVzZXJOYW1lOiB1c2VyRGV0YWlscy51c2VyTmFtZSxcclxuICAgICAgICAgIHVzZXJQaG9uZTogdXNlckRldGFpbHMudXNlclBob25lLFxyXG4gICAgICAgICAgY3VzdG9tZXJJZDogdXNlckRldGFpbHMuY3VzdG9tZXJJZCxcclxuICAgICAgICAgIGFtb3VudFBhaWQsXHJcbiAgICAgICAgICBwYXltZW50c1RpY2tldDogdGlja2V0LFxyXG4gICAgICAgICAgYW1vdW50VG9CZVBhaWQsXHJcbiAgICAgICAgICBncm91cE5hbWU6IHBlbmFsdHlEYXRhLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICBlbnJvbGxtZW50RGF0ZTogdXNlckRldGFpbHMuZW5yb2xsbWVudERhdGUsXHJcbiAgICAgICAgICB0b3RhbFRvQmVQYWlkOiBhbW91bnRUb0JlUGFpZCxcclxuICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICByZWd1bGFyUGVuYWx0eSxcclxuICAgICAgICAgIHZjUGVuYWx0eSxcclxuICAgICAgICAgIHRvdGFsUGVuYWx0eSxcclxuICAgICAgICAgIHRvdGFsTGF0ZUZlZSxcclxuICAgICAgICAgIGJhbGFuY2VXaXRob3V0UGVuYWx0eSxcclxuICAgICAgICAgIGNvbWJpbmVkUGVuYWx0eTogdG90YWxQZW5hbHR5LFxyXG4gICAgICAgICAgdG90YWxPdmVyZHVlQ2hhcmdlcyxcclxuICAgICAgICAgIG1hbnVhbFBlbmFsdHksXHJcbiAgICAgICAgICBtYW51YWxMYXRlRmVlLFxyXG4gICAgICAgICAgYWN0aW9uczogd2hhdHNhcHBBY3Rpb25zLFxyXG4gICAgICAgICAgc3RhdHVzRGl2OiBpc1ZjV2l0aGluR3JhY2UgPyAoXHJcbiAgICAgICAgICAgIDxUYWcgY29sb3I9XCJ2aW9sZXRcIj5WQyDigJMgV2l0aGluIEdyYWNlPC9UYWc+XHJcbiAgICAgICAgICApIDogaXNWY1BlbmFsdHlBcHBsaWVkID8gKFxyXG4gICAgICAgICAgICA8VGFnIGNvbG9yPVwiZ29sZFwiPlZDIFBlbmFsdHkgQXBwbGllZDwvVGFnPlxyXG4gICAgICAgICAgKSA6IHVzZXJEZXRhaWxzLmlzUHJpemVkID8gKFxyXG4gICAgICAgICAgICA8VGFnIGNvbG9yPVwic3VjY2Vzc1wiIGljb249ezxDaGVja0NpcmNsZU91dGxpbmVkIC8+fT5cclxuICAgICAgICAgICAgICBQcml6ZWRcclxuICAgICAgICAgICAgPC9UYWc+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8VGFnIGNvbG9yPVwiZXJyb3JcIiBpY29uPXs8Q2xvc2VDaXJjbGVPdXRsaW5lZCAvPn0+XHJcbiAgICAgICAgICAgICAgVW4gUHJpemVkXHJcbiAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICAgIGlzVmNXaXRoaW5HcmFjZSxcclxuICAgICAgICAgIGlzVmNQZW5hbHR5QXBwbGllZCxcclxuICAgICAgICAgIGhhc1BlbmFsdHlPckxhdGVGZWU6IHRvdGFsUGVuYWx0eSA+IDAgfHwgdG90YWxMYXRlRmVlID4gMCxcclxuICAgICAgICAgIHZhY2FudEdyYWNlRGF5cyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgIHVzZXJzTGlzdC5wdXNoKHVzZXJSZWNvcmQpO1xyXG4gICAgICAgIGNvdW50Kys7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIHNldFVzZXJzRGF0YSh1c2Vyc0xpc3QpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBsb2FkIHBlbmFsdHkgbW9uaXRvciBkYXRhXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U2NyZWVuTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hNb250aGx5Q29sbGVjdGVkID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TW9udGhseUNvbGxlY3RlZExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvcGVuYWx0eS9jb2xsZWN0ZWQtdGhpcy1tb250aFwiKTtcclxuICAgICAgaWYgKHJlcy5kYXRhLnN1Y2Nlc3MpIHtcclxuICAgICAgICBzZXRNb250aGx5Q29sbGVjdGVkU3VtbWFyeShyZXM/LmRhdGE/LnN1bW1hcnkpO1xyXG4gICAgICAgIHNldE1vbnRobHlDb2xsZWN0ZWREZXRhaWxzKHJlcz8uZGF0YT8uZGV0YWlscyB8fCBbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgbW9udGhseSBwZW5hbHR5IGNvbGxlY3RlZCBkYXRhXCIpO1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRNb250aGx5Q29sbGVjdGVkTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gICAgZmV0Y2hNb250aGx5Q29sbGVjdGVkKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlKSA9PiB7XHJcbiAgICAgIGlmIChbJ0lOUFVUJywgJ1RFWFRBUkVBJywgJ1NFTEVDVCddLmluY2x1ZGVzKGUudGFyZ2V0LnRhZ05hbWUpKSByZXR1cm47XHJcbiAgICAgIGlmIChlLmN0cmxLZXkgJiYgZS5zaGlmdEtleSAmJiBlLmtleS50b0xvd2VyQ2FzZSgpID09PSAncycpIHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgbmF2aWdhdGUoJy9wZW5hbHR5LXNldHRpbmdzJyk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XHJcbiAgfSwgW25hdmlnYXRlXSk7XHJcblxyXG4gIC8vIENhbGN1bGF0ZSB0b3RhbHMgYmFzZWQgb24gYmFja2VuZCBkYXRhXHJcbiAgY29uc3QgW3RvdGFscywgc2V0VG90YWxzXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsQ3VzdG9tZXJzOiAwLFxyXG4gICAgdG90YWxHcm91cHM6IDAsXHJcbiAgICB0b3RhbFRvQmVQYWlkOiAwLFxyXG4gICAgdG90YWxQYWlkOiAwLFxyXG4gICAgdG90YWxCYWxhbmNlOiAwLFxyXG4gICAgdG90YWxQZW5hbHR5OiAwLFxyXG4gICAgdG90YWxMYXRlRmVlOiAwLFxyXG4gICAgdG90YWxSZWd1bGFyUGVuYWx0eTogMCxcclxuICAgIHRvdGFsVmNQZW5hbHR5OiAwLFxyXG4gICAgdG90YWxUaWNrZXRzOiAwLFxyXG4gICAgdG90YWxCYWxhbmNlV2l0aG91dFBlbmFsdHk6IDAsXHJcbiAgICB0b3RhbE91dHN0YW5kaW5nV2l0aFBlbmFsdHk6IDAsXHJcbiAgICB0b3RhbFBlbmFsdHlBbmRMYXRlRmVlOiAwLFxyXG4gICAgdG90YWxNYW51YWxQZW5hbHR5OiAwLFxyXG4gICAgdG90YWxNYW51YWxMYXRlRmVlOiAwLFxyXG4gIH0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdW5pcXVlQ3VzdG9tZXJJZHMgPSBuZXcgU2V0KGZpbHRlcmVkVXNlcnMubWFwKHUgPT4gdS51c2VySWQpKTtcclxuICAgIGNvbnN0IHRvdGFsQ3VzdG9tZXJzID0gdW5pcXVlQ3VzdG9tZXJJZHMuc2l6ZTtcclxuICAgIGNvbnN0IGdyb3VwU2V0ID0gbmV3IFNldChmaWx0ZXJlZFVzZXJzLm1hcCgodXNlcikgPT4gdXNlci5ncm91cE5hbWUpKTtcclxuICAgIGNvbnN0IHRvdGFsR3JvdXBzID0gZ3JvdXBGaWx0ZXIgPyAxIDogZ3JvdXBTZXQuc2l6ZTtcclxuICAgIGNvbnN0IHRvdGFsVG9CZVBhaWQgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZSgoc3VtLCB1KSA9PiBzdW0gKyAodS50b3RhbFRvQmVQYWlkIHx8IDApLCAwKTtcclxuICAgIGNvbnN0IHRvdGFsUGFpZCA9IGZpbHRlcmVkVXNlcnMucmVkdWNlKChzdW0sIHUpID0+IHN1bSArICh1LmFtb3VudFBhaWQgfHwgMCksIDApO1xyXG4gICAgY29uc3QgdG90YWxCYWxhbmNlID0gZmlsdGVyZWRVc2Vycy5yZWR1Y2UoKHN1bSwgdSkgPT4gc3VtICsgKHUuYmFsYW5jZSB8fCAwKSwgMCk7XHJcbiAgICBjb25zdCB0b3RhbEJhbGFuY2VXaXRob3V0UGVuYWx0eSA9IGZpbHRlcmVkVXNlcnMucmVkdWNlKChzdW0sIHUpID0+IHN1bSArICh1LmJhbGFuY2VXaXRob3V0UGVuYWx0eSB8fCAwKSwgMCk7XHJcbiAgICBjb25zdCB0b3RhbE91dHN0YW5kaW5nV2l0aFBlbmFsdHkgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZSgoc3VtLCB1KSA9PiBzdW0gKyAodS5iYWxhbmNlIHx8IDApLCAwKTtcclxuICAgIGNvbnN0IHRvdGFsUGVuYWx0eSA9IGZpbHRlcmVkVXNlcnMucmVkdWNlKChzdW0sIHUpID0+IHN1bSArICh1LnRvdGFsUGVuYWx0eSB8fCAwKSwgMCk7XHJcbiAgICBjb25zdCB0b3RhbExhdGVGZWUgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZSgoc3VtLCB1KSA9PiBzdW0gKyAodS50b3RhbExhdGVGZWUgfHwgMCksIDApO1xyXG4gICAgY29uc3QgdG90YWxQZW5hbHR5QW5kTGF0ZUZlZSA9IHRvdGFsUGVuYWx0eSArIHRvdGFsTGF0ZUZlZTtcclxuICAgIGNvbnN0IHRvdGFsUmVndWxhclBlbmFsdHkgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZSgoc3VtLCB1KSA9PiBzdW0gKyAodS5yZWd1bGFyUGVuYWx0eSB8fCAwKSwgMCk7XHJcbiAgICBjb25zdCB0b3RhbFZjUGVuYWx0eSA9IGZpbHRlcmVkVXNlcnMucmVkdWNlKChzdW0sIHUpID0+IHN1bSArICh1LnZjUGVuYWx0eSB8fCAwKSwgMCk7XHJcbiAgICBjb25zdCB0b3RhbE1hbnVhbFBlbmFsdHkgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZSgoc3VtLCB1KSA9PiBzdW0gKyAodS5tYW51YWxQZW5hbHR5IHx8IDApLCAwKTtcclxuICAgIGNvbnN0IHRvdGFsTWFudWFsTGF0ZUZlZSA9IGZpbHRlcmVkVXNlcnMucmVkdWNlKChzdW0sIHUpID0+IHN1bSArICh1Lm1hbnVhbExhdGVGZWUgfHwgMCksIDApO1xyXG4gICAgY29uc3QgdG90YWxUaWNrZXRzID0gZmlsdGVyZWRVc2Vycy5sZW5ndGg7XHJcblxyXG4gICAgc2V0VG90YWxzKHtcclxuICAgICAgdG90YWxDdXN0b21lcnMsXHJcbiAgICAgIHRvdGFsR3JvdXBzLFxyXG4gICAgICB0b3RhbFRvQmVQYWlkLFxyXG4gICAgICB0b3RhbFBhaWQsXHJcbiAgICAgIHRvdGFsQmFsYW5jZSxcclxuICAgICAgdG90YWxQZW5hbHR5LFxyXG4gICAgICB0b3RhbExhdGVGZWUsXHJcbiAgICAgIHRvdGFsUmVndWxhclBlbmFsdHksXHJcbiAgICAgIHRvdGFsVmNQZW5hbHR5LFxyXG4gICAgICB0b3RhbFRpY2tldHMsXHJcbiAgICAgIHRvdGFsQmFsYW5jZVdpdGhvdXRQZW5hbHR5LFxyXG4gICAgICB0b3RhbE91dHN0YW5kaW5nV2l0aFBlbmFsdHksXHJcbiAgICAgIHRvdGFsUGVuYWx0eUFuZExhdGVGZWUsXHJcbiAgICAgIHRvdGFsTWFudWFsUGVuYWx0eSxcclxuICAgICAgdG90YWxNYW51YWxMYXRlRmVlLFxyXG4gICAgfSk7XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnMsIGdyb3VwRmlsdGVyXSk7XHJcblxyXG4gIC8vIFNob3cgcGVuYWx0eSBicmVha2Rvd25cclxuICBjb25zdCBoYW5kbGVTaG93QnJlYWtkb3duID0gYXN5bmMgKHVzZXJJZCwgZ3JvdXBJZCwgdXNlck5hbWUsIGdyb3VwTmFtZSwgY2FjaGVkUGVuYWx0eURhdGEgPSBudWxsKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nQnJlYWtkb3duKHRydWUpO1xyXG4gICAgICBzZXRTZWxlY3RlZEN1c3RvbWVyKHsgdXNlck5hbWUsIGdyb3VwTmFtZSB9KTtcclxuICAgICAgc2V0QnJlYWtkb3duTW9kYWwodHJ1ZSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBVc2UgY2FjaGVkIGRhdGEgaWYgYXZhaWxhYmxlXHJcbiAgICAgIGxldCBwZW5hbHR5RGF0YSA9IGNhY2hlZFBlbmFsdHlEYXRhO1xyXG4gICAgICBpZiAoIXBlbmFsdHlEYXRhKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9wZW5hbHR5L2dldC1wZW5hbHR5LXJlcG9ydFwiLCB7XHJcbiAgICAgICAgICBwYXJhbXM6IHsgdXNlcl9pZDogdXNlcklkLCBncm91cF9pZDogZ3JvdXBJZCB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChyZXMuZGF0YT8uc3VjY2VzcyAmJiByZXMuZGF0YT8uZGF0YT8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgcGVuYWx0eURhdGEgPSByZXMuZGF0YS5kYXRhWzBdO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgaWYgKCFwZW5hbHR5RGF0YSB8fCAhcGVuYWx0eURhdGEuY3ljbGVzKSB7XHJcbiAgICAgICAgbWVzc2FnZS5lcnJvcihcIk5vIHBlbmFsdHkgYnJlYWtkb3duIGRhdGEgYXZhaWxhYmxlXCIpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgc2V0QnJlYWtkb3duRGF0YShwZW5hbHR5RGF0YS5jeWNsZXMpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBsb2FkIHBlbmFsdHkgYnJlYWtkb3duXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZ0JyZWFrZG93bihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gV2hhdHNBcHAgSGFuZGxlcnNcclxuICBjb25zdCBjYWxjdWxhdGVHcmFjZURheXNMZWZ0ID0gKGVucm9sbG1lbnREYXRlU3RyLCB2YWNhbnRHcmFjZURheXMgPSA5MCkgPT4ge1xyXG4gICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBtb21lbnQoZW5yb2xsbWVudERhdGVTdHIpO1xyXG4gICAgY29uc3QgdG9kYXkgPSBtb21lbnQoKS5zdGFydE9mKFwiZGF5XCIpO1xyXG4gICAgY29uc3QgZ3JhY2VFbmQgPSBlbnJvbGxtZW50RGF0ZS5jbG9uZSgpLmFkZCh2YWNhbnRHcmFjZURheXMsIFwiZGF5c1wiKTtcclxuICAgIHJldHVybiBNYXRoLm1heCgwLCBncmFjZUVuZC5kaWZmKHRvZGF5LCBcImRheXNcIikpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNhbGN1bGF0ZURheXNMYXRlID0gKGVucm9sbG1lbnREYXRlU3RyKSA9PiB7XHJcbiAgICBjb25zdCBsYXN0RHVlID0gbW9tZW50KCkuc3RhcnRPZihcIm1vbnRoXCIpO1xyXG4gICAgY29uc3QgdG9kYXkgPSBtb21lbnQoKTtcclxuICAgIHJldHVybiBNYXRoLm1heCgwLCB0b2RheS5kaWZmKGxhc3REdWUsIFwiZGF5c1wiKSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2VuZFNpbmdsZVdoYXRzYXBwID0gYXN5bmMgKHVzZXIsIHR5cGUpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldFNjcmVlbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgW2B1c2VyXzBgXToge1xyXG4gICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICBzdGF0dXM6IHRydWUsXHJcbiAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICBwYXltZW50c1RpY2tldDogdXNlci5wYXltZW50c1RpY2tldCxcclxuICAgICAgICAgICAgZXhwZWN0ZWQ6IHVzZXIudG90YWxUb0JlUGFpZCxcclxuICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgLi4uKHR5cGUgPT09IFwidmNXaXRoaW5HcmFjZVwiICYmIHtcclxuICAgICAgICAgICAgICBncmFjZURheXNMZWZ0OiBjYWxjdWxhdGVHcmFjZURheXNMZWZ0KHVzZXIuZW5yb2xsbWVudERhdGUsIHVzZXIudmFjYW50R3JhY2VEYXlzKSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIC4uLih0eXBlID09PSBcInZjUGVuYWx0eUFwcGxpZWRcIiAmJiB7XHJcbiAgICAgICAgICAgICAgYXBwbGllZFZjQW1vdW50OiB1c2VyLnZjUGVuYWx0eSB8fCAwLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2U6IHVzZXIuYmFsYW5jZSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIC4uLih0eXBlID09PSBcImxhdGVQZW5hbHR5V2l0aGluXCIgJiYge1xyXG4gICAgICAgICAgICAgIGRheXNMYXRlOiBjYWxjdWxhdGVEYXlzTGF0ZSh1c2VyLmVucm9sbG1lbnREYXRlKSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIC4uLih0eXBlID09PSBcImxhdGVQZW5hbHR5QXBwbGllZFwiICYmIHtcclxuICAgICAgICAgICAgICBsYXRlRmVlOiB1c2VyLnRvdGFsTGF0ZUZlZSxcclxuICAgICAgICAgICAgICBwZW5hbHR5OiB1c2VyLnJlZ3VsYXJQZW5hbHR5LFxyXG4gICAgICAgICAgICAgIGJhbGFuY2U6IHVzZXIuYmFsYW5jZSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBsZXQgZW5kcG9pbnQgPSBcIlwiO1xyXG4gICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICBjYXNlIFwidmNXaXRoaW5HcmFjZVwiOiBlbmRwb2ludCA9IFwiL3doYXRzYXBwL3ZjLXdpdGhpbi1ncmFjZVwiOyBicmVhaztcclxuICAgICAgICBjYXNlIFwidmNQZW5hbHR5QXBwbGllZFwiOiBlbmRwb2ludCA9IFwiL3doYXRzYXBwL3ZjLXBlbmFsdHktYXBwbGllZFwiOyBicmVhaztcclxuICAgICAgICBjYXNlIFwibGF0ZVBlbmFsdHlXaXRoaW5cIjogZW5kcG9pbnQgPSBcIi93aGF0c2FwcC9sYXRlLXBlbmFsdHktd2l0aGluLXRocmVzaG9sZFwiOyBicmVhaztcclxuICAgICAgICBjYXNlIFwibGF0ZVBlbmFsdHlBcHBsaWVkXCI6IGVuZHBvaW50ID0gXCIvd2hhdHNhcHAvbGF0ZS1wZW5hbHR5LWFwcGxpZWRcIjsgYnJlYWs7XHJcbiAgICAgICAgZGVmYXVsdDogdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBXaGF0c0FwcCB0eXBlXCIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkucG9zdChlbmRwb2ludCwgcGF5bG9hZCk7XHJcbiAgICAgIGNvbnN0IHsgc3VjY2VzcywgZXJyb3IgfSA9IHJlcy5kYXRhO1xyXG4gICAgICBpZiAoc3VjY2VzcyA+IDApIHtcclxuICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoYOKchSBXaGF0c0FwcCBzZW50IHRvICR7dXNlci51c2VyTmFtZX1gKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBtZXNzYWdlLmVycm9yKGDinYwgRmFpbGVkIHRvIHNlbmQgdG8gJHt1c2VyLnVzZXJOYW1lfWApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIlNpbmdsZSBXaGF0c0FwcCBzZW5kIGVycm9yOlwiLCBlcnIpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKGDinYwgRmFpbGVkIHRvIHNlbmQgdG8gJHt1c2VyLnVzZXJOYW1lfWApO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U2NyZWVuTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VuZFdoYXRzYXBwID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkUm93cy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAgIHNldFNjcmVlbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge307XHJcbiAgICAgIHNlbGVjdGVkUm93cy5mb3JFYWNoKCh1c2VyLCBpZHgpID0+IHtcclxuICAgICAgICBwYXlsb2FkW2B1c2VyXyR7aWR4fWBdID0ge1xyXG4gICAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICBzdGF0dXM6IHRydWUsXHJcbiAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICBwYXltZW50c1RpY2tldDogdXNlci5wYXltZW50c1RpY2tldCxcclxuICAgICAgICAgICAgZXhwZWN0ZWQ6IHVzZXIudG90YWxUb0JlUGFpZCxcclxuICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgLi4uKHNlbmRNb2RhbC50eXBlID09PSBcInZjV2l0aGluR3JhY2VcIiAmJiB7XHJcbiAgICAgICAgICAgICAgZ3JhY2VEYXlzTGVmdDogY2FsY3VsYXRlR3JhY2VEYXlzTGVmdCh1c2VyLmVucm9sbG1lbnREYXRlLCB1c2VyLnZhY2FudEdyYWNlRGF5cyksXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAuLi4oc2VuZE1vZGFsLnR5cGUgPT09IFwidmNQZW5hbHR5QXBwbGllZFwiICYmIHtcclxuICAgICAgICAgICAgICBhcHBsaWVkVmNBbW91bnQ6IHVzZXIudmNQZW5hbHR5IHx8IDAsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZTogdXNlci5iYWxhbmNlLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLi4uKHNlbmRNb2RhbC50eXBlID09PSBcImxhdGVQZW5hbHR5V2l0aGluXCIgJiYge1xyXG4gICAgICAgICAgICAgIGRheXNMYXRlOiBjYWxjdWxhdGVEYXlzTGF0ZSh1c2VyLmVucm9sbG1lbnREYXRlKSxcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIC4uLihzZW5kTW9kYWwudHlwZSA9PT0gXCJsYXRlUGVuYWx0eUFwcGxpZWRcIiAmJiB7XHJcbiAgICAgICAgICAgICAgbGF0ZUZlZTogdXNlci50b3RhbExhdGVGZWUsXHJcbiAgICAgICAgICAgICAgcGVuYWx0eTogdXNlci5yZWd1bGFyUGVuYWx0eSxcclxuICAgICAgICAgICAgICBiYWxhbmNlOiB1c2VyLmJhbGFuY2UsXHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGxldCBlbmRwb2ludCA9IFwiXCI7XHJcbiAgICAgIHN3aXRjaCAoc2VuZE1vZGFsLnR5cGUpIHtcclxuICAgICAgICBjYXNlIFwidmNXaXRoaW5HcmFjZVwiOiBlbmRwb2ludCA9IFwiL3doYXRzYXBwL3ZjLXdpdGhpbi1ncmFjZVwiOyBicmVhaztcclxuICAgICAgICBjYXNlIFwidmNQZW5hbHR5QXBwbGllZFwiOiBlbmRwb2ludCA9IFwiL3doYXRzYXBwL3ZjLXBlbmFsdHktYXBwbGllZFwiOyBicmVhaztcclxuICAgICAgICBjYXNlIFwibGF0ZVBlbmFsdHlXaXRoaW5cIjogZW5kcG9pbnQgPSBcIi93aGF0c2FwcC9sYXRlLXBlbmFsdHktd2l0aGluLXRocmVzaG9sZFwiOyBicmVhaztcclxuICAgICAgICBjYXNlIFwibGF0ZVBlbmFsdHlBcHBsaWVkXCI6IGVuZHBvaW50ID0gXCIvd2hhdHNhcHAvbGF0ZS1wZW5hbHR5LWFwcGxpZWRcIjsgYnJlYWs7XHJcbiAgICAgICAgZGVmYXVsdDogdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBXaGF0c0FwcCB0eXBlXCIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkucG9zdChlbmRwb2ludCwgcGF5bG9hZCk7XHJcbiAgICAgIGNvbnN0IHsgc3VjY2VzcywgZXJyb3IgfSA9IHJlcy5kYXRhO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoYOKchSAke3N1Y2Nlc3N9IG1lc3NhZ2Uocykgc2VudC4g4p2MICR7ZXJyb3J9IGZhaWxlZC5gKTtcclxuICAgICAgc2V0U2VuZE1vZGFsKHsgb3BlbjogZmFsc2UsIHR5cGU6IG51bGwgfSk7XHJcbiAgICAgIHNldFNlbGVjdGVkUm93cyhbXSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIldoYXRzQXBwIHNlbmQgZXJyb3I6XCIsIGVycik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCLinYwgRmFpbGVkIHRvIHNlbmQgV2hhdHNBcHAgbWVzc2FnZXMuIENoZWNrIGNvbnNvbGUuXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U2NyZWVuTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlblNlbmRNb2RhbCA9ICh0eXBlKSA9PiB7XHJcbiAgICBzZXRTZW5kTW9kYWwoeyBvcGVuOiB0cnVlLCB0eXBlIH0pO1xyXG4gIH07XHJcblxyXG4gIC8vIFJldmVyc2FsIEhhbmRsZXJzXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBTZWxlY3QgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFJldmVyc2FsR3JvdXBGaWx0ZXIodmFsdWUgfHwgXCJcIik7XHJcbiAgICBzZXRSZXZlcnNhbEN1c3RvbWVyRmlsdGVyKFwiXCIpO1xyXG4gICAgc2V0UmV2ZXJzYWxUaWNrZXRGaWx0ZXIoXCJcIik7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVDdXN0b21lclNlbGVjdCA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0UmV2ZXJzYWxDdXN0b21lckZpbHRlcih2YWx1ZSB8fCBcIlwiKTtcclxuICAgIHNldFJldmVyc2FsVGlja2V0RmlsdGVyKFwiXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlVGlja2V0U2VsZWN0ID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRSZXZlcnNhbFRpY2tldEZpbHRlcih2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlblJldmVyc2VBbW91bnREcmF3ZXIgPSAodHlwZSkgPT4ge1xyXG4gICAgbGV0IG1heEFtb3VudCA9IDA7XHJcbiAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgY2FzZSBcImxhdGVfZmVlXCI6IG1heEFtb3VudCA9IHBlbmFsdHlTdW1tYXJ5LnRvdGFsTGF0ZUZlZTsgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJwZW5hbHR5XCI6IG1heEFtb3VudCA9IHBlbmFsdHlTdW1tYXJ5LnJlZ3VsYXJQZW5hbHR5OyBicmVhaztcclxuICAgICAgY2FzZSBcInZjX3BlbmFsdHlcIjogbWF4QW1vdW50ID0gcGVuYWx0eVN1bW1hcnkudmNQZW5hbHR5OyBicmVhaztcclxuICAgICAgY2FzZSBcImFsbFwiOiBtYXhBbW91bnQgPSBwZW5hbHR5U3VtbWFyeS50b3RhbExhdGVGZWUgKyBwZW5hbHR5U3VtbWFyeS5yZWd1bGFyUGVuYWx0eSArIHBlbmFsdHlTdW1tYXJ5LnZjUGVuYWx0eTsgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6IG1heEFtb3VudCA9IDA7XHJcbiAgICB9XHJcbiAgICBzZXRNYXhBbGxvd2VkQW1vdW50KG1heEFtb3VudCk7XHJcbiAgICBzZXRSZXZlcnNlQW1vdW50KFwiXCIpO1xyXG4gICAgc2V0U2VsZWN0ZWRSZXZlcnNhbFR5cGUodHlwZSk7XHJcbiAgICBzZXRSZXZlcnNlQW1vdW50RHJhd2VyKHRydWUpO1xyXG4gICAgc2V0UGVuYWx0eVN1bW1hcnlEcmF3ZXIoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFwcGx5UmV2ZXJzYWwgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KHJldmVyc2VBbW91bnQpO1xyXG4gICAgaWYgKCFhbW91bnQgfHwgYW1vdW50IDw9IDAgfHwgYW1vdW50ID4gbWF4QWxsb3dlZEFtb3VudCkge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKGBQbGVhc2UgZW50ZXIgYSB2YWxpZCBhbW91bnQgKOKJpCDigrkke21heEFsbG93ZWRBbW91bnQudG9GaXhlZCgyKX0pYCk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldFNjcmVlbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgdXNlcl9pZDogcGVuYWx0eVN1bW1hcnkudXNlcklkLFxyXG4gICAgICAgIGdyb3VwX2lkOiBwZW5hbHR5U3VtbWFyeS5ncm91cElkLFxyXG4gICAgICAgIHRpY2tldDogcGVuYWx0eVN1bW1hcnkucGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgYW1vdW50LFxyXG4gICAgICAgIHR5cGU6IHNlbGVjdGVkUmV2ZXJzYWxUeXBlLFxyXG4gICAgICB9O1xyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi9wZW5hbHR5L3JldmVyc2UtYW1vdW50XCIsIHBheWxvYWQpO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCLinIUgUGVuYWx0eSByZXZlcnNhbCBhcHBsaWVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgIHNldFJldmVyc2VBbW91bnREcmF3ZXIoZmFsc2UpO1xyXG4gICAgICBmZXRjaERhdGEoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiUmV2ZXJzYWwgZXJyb3I6XCIsIGVycik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCLinYwgRmFpbGVkIHRvIGFwcGx5IHJldmVyc2FsXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U2NyZWVuTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gQWRkIFBlbmFsdHkgSGFuZGxlcnNcclxuICBjb25zdCBoYW5kbGVBZGRQZW5hbHR5R3JvdXBTZWxlY3QgPSAodmFsdWUpID0+IHtcclxuICAgIHNldEFkZFBlbmFsdHlHcm91cEZpbHRlcih2YWx1ZSB8fCBcIlwiKTtcclxuICAgIHNldEFkZFBlbmFsdHlDdXN0b21lckZpbHRlcihcIlwiKTtcclxuICAgIHNldEFkZFBlbmFsdHlUaWNrZXRGaWx0ZXIoXCJcIik7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBZGRQZW5hbHR5Q3VzdG9tZXJTZWxlY3QgPSAodmFsdWUpID0+IHtcclxuICAgIHNldEFkZFBlbmFsdHlDdXN0b21lckZpbHRlcih2YWx1ZSB8fCBcIlwiKTtcclxuICAgIHNldEFkZFBlbmFsdHlUaWNrZXRGaWx0ZXIoXCJcIik7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBZGRQZW5hbHR5VGlja2V0U2VsZWN0ID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRBZGRQZW5hbHR5VGlja2V0RmlsdGVyKHZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlUGVuYWx0eSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghYWRkUGVuYWx0eURldGFpbHMgfHwgKCFhZGRQZW5hbHR5QW1vdW50ICYmICFhZGRMYXRlRmVlQW1vdW50KSkge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiUGxlYXNlIGVudGVyIGF0IGxlYXN0IG9uZSBvZiBwZW5hbHR5IG9yIGxhdGUgZmVlIGFtb3VudFwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0QWRkUGVuYWx0eUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgdXNlcl9pZDogYWRkUGVuYWx0eURldGFpbHMudXNlcklkLFxyXG4gICAgICAgIGdyb3VwX2lkOiBhZGRQZW5hbHR5RGV0YWlscy5ncm91cElkLFxyXG4gICAgICAgIHRpY2tldDogYWRkUGVuYWx0eURldGFpbHMucGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgcGVuYWx0eV9hbW91bnQ6IHBhcnNlRmxvYXQoYWRkUGVuYWx0eUFtb3VudCkgfHwgMCxcclxuICAgICAgICBsYXRlX2ZlZV9hbW91bnQ6IHBhcnNlRmxvYXQoYWRkTGF0ZUZlZUFtb3VudCkgfHwgMCxcclxuICAgICAgfTtcclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvcGVuYWx0eS9hZGQtbWFudWFsLXBlbmFsdHlcIiwgcGF5bG9hZCk7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIuKchSBQZW5hbHR5IGFkZGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgIHNldEFkZFBlbmFsdHlEcmF3ZXJPcGVuKGZhbHNlKTtcclxuICAgICAgc2V0QWRkUGVuYWx0eURldGFpbHMobnVsbCk7XHJcbiAgICAgIHNldEFkZFBlbmFsdHlBbW91bnQoXCJcIik7XHJcbiAgICAgIHNldEFkZExhdGVGZWVBbW91bnQoXCJcIik7XHJcbiAgICAgIGZldGNoRGF0YSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJBZGQgcGVuYWx0eSBlcnJvcjpcIiwgZXJyKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIuKdjCBGYWlsZWQgdG8gYWRkIHBlbmFsdHlcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRBZGRQZW5hbHR5TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0QW1vdW50ID0gKHZhbHVlKSA9PlxyXG4gICAgTnVtYmVyKHZhbHVlIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgIH0pO1xyXG5cclxuICAvLyBDT0xVTU4gREVGSU5JVElPTlxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJzbF9ub1wiLFxyXG4gICAgICBoZWFkZXI6IFwiU0wuIE5PXCIsXHJcbiAgICAgIHJlbmRlcjogKHRleHQsIHJlY29yZCwgaW5kZXgpID0+IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj57aW5kZXggKyAxfTwvc3Bhbj4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidXNlck5hbWVcIixcclxuICAgICAgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCkgPT4gPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+e3RleHR9PC9kaXY+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcInVzZXJQaG9uZVwiLFxyXG4gICAgICBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgIHJlbmRlcjogKHRleHQpID0+IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICA8UGhvbmVPdXRsaW5lZCBjbGFzc05hbWU9XCJtci0yIHRleHQtdmlvbGV0LTUwMFwiIC8+XHJcbiAgICAgICAgICB7dGV4dH1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJjdXN0b21lcklkXCIsXHJcbiAgICAgIGhlYWRlcjogXCJDdXN0b21lciBJRFwiLFxyXG4gICAgICByZW5kZXI6ICh0ZXh0KSA9PiA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbSBiZy1ncmF5LTEwMCBweC0yIHB5LTEgcm91bmRlZFwiPnt0ZXh0fTwvc3Bhbj4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiZ3JvdXBOYW1lXCIsXHJcbiAgICAgIGhlYWRlcjogXCJHcm91cCBOYW1lXCIsXHJcbiAgICAgIHJlbmRlcjogKHRleHQpID0+IDxUYWcgY29sb3I9XCJ2aW9sZXRcIiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPnt0ZXh0fTwvVGFnPixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJlbnJvbGxtZW50RGF0ZVwiLFxyXG4gICAgICBoZWFkZXI6IFwiRW5yb2xsbWVudCBEYXRlXCIsXHJcbiAgICAgIHJlbmRlcjogKHRleHQpID0+IG1vbWVudCh0ZXh0KS5mb3JtYXQoXCJERC9NTS9ZWVlZXCIpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcInBheW1lbnRzVGlja2V0XCIsXHJcbiAgICAgIGhlYWRlcjogXCJUaWNrZXRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJ0b3RhbFRvQmVQYWlkXCIsXHJcbiAgICAgIGhlYWRlcjogXCJBbW91bnQgUGF5YWJsZVwiLFxyXG4gICAgICByZW5kZXI6ICh0ZXh0KSA9PiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPlxyXG4gICAgICAgICAg4oK5e051bWJlcih0ZXh0IHx8IDApLnRvRml4ZWQoMikudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiYW1vdW50UGFpZFwiLFxyXG4gICAgICBoZWFkZXI6IFwiQW1vdW50IFBhaWRcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCkgPT4gKFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmRpZ28tNjAwXCI+XHJcbiAgICAgICAgICDigrl7TnVtYmVyKHRleHQgfHwgMCkudG9GaXhlZCgyKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJiYWxhbmNlV2l0aG91dFBlbmFsdHlcIixcclxuICAgICAgaGVhZGVyOiBcIkJhbGFuY2VcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCwgcmVjb3JkKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYmFsYW5jZSA9IE51bWJlcihyZWNvcmQuYmFsYW5jZVdpdGhvdXRQZW5hbHR5IHx8IDApO1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bmb250LXNlbWlib2xkICR7YmFsYW5jZSA+IDAgPyBcInRleHQtcmVkLTYwMFwiIDogXCJ0ZXh0LWdyZWVuLTYwMFwifWB9PlxyXG4gICAgICAgICAgICDigrl7YmFsYW5jZS50b0ZpeGVkKDIpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKTtcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJ0b3RhbFBlbmFsdHlcIixcclxuICAgICAgaGVhZGVyOiBcIlRvdGFsIFBlbmFsdHlcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCwgcmVjb3JkKSA9PiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj5cclxuICAgICAgICAgIOKCuXtOdW1iZXIocmVjb3JkLnRvdGFsUGVuYWx0eSB8fCAwKS50b0ZpeGVkKDIpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcInRvdGFsTGF0ZUZlZVwiLFxyXG4gICAgICBoZWFkZXI6IFwiTGF0ZSBGZWVcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCkgPT4gKFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICDigrl7TnVtYmVyKHRleHQgfHwgMCkudG9GaXhlZCgyKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJ0b3RhbE92ZXJkdWVDaGFyZ2VzXCIsXHJcbiAgICAgIGhlYWRlcjogXCJUb3RhbCBPdmVyZHVlIENoYXJnZXNcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCwgcmVjb3JkKSA9PiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC03MDBcIj5cclxuICAgICAgICAgIOKCuXtOdW1iZXIocmVjb3JkLnRvdGFsT3ZlcmR1ZUNoYXJnZXMgfHwgMCkudG9GaXhlZCgyKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJiYWxhbmNlXCIsXHJcbiAgICAgIGhlYWRlcjogXCJPdXRzdGFuZGluZyB3aXRoIFBlbmFsdHlcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGJhbGFuY2UgPSBOdW1iZXIodGV4dCB8fCAwKTtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZm9udC1zZW1pYm9sZCAke2JhbGFuY2UgPiAwID8gXCJ0ZXh0LXJlZC02MDBcIiA6IFwidGV4dC1ncmVlbi02MDBcIn1gfT5cclxuICAgICAgICAgICAg4oK5e2JhbGFuY2UudG9GaXhlZCgyKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICk7XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiYWN0aW9uc1wiLFxyXG4gICAgICBoZWFkZXI6IFwiQWN0aW9uc1wiLFxyXG4gICAgICByZW5kZXI6ICh0ZXh0LCByZWNvcmQpID0+IHJlY29yZC5hY3Rpb25zLFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBicmVha2Rvd25Db2x1bW5zID0gW1xyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJBdWN0aW9uXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJjeWNsZV9ub1wiLFxyXG4gICAgICBhbGlnbjogXCJjZW50ZXJcIixcclxuICAgICAgd2lkdGg6IDgwLFxyXG4gICAgICByZW5kZXI6ICh0ZXh0LCByb3cpID0+XHJcbiAgICAgICAgcm93LnZhY2FudF9jeWNsZSA/IChcclxuICAgICAgICAgIDxUYWcgY29sb3I9XCJnb2xkXCIgc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIgfX0+XHJcbiAgICAgICAgICAgIFZDXHJcbiAgICAgICAgICA8L1RhZz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57dGV4dH08L3NwYW4+XHJcbiAgICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIkR1ZSBEYXRlXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJ0b19kYXRlXCIsXHJcbiAgICAgIHJlbmRlcjogKHYsIHJvdykgPT5cclxuICAgICAgICByb3cudmFjYW50X2N5Y2xlID8gKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwiI2I1ODkwMFwiLCBmb250V2VpZ2h0OiBcIjYwMFwiIH19Pnttb21lbnQodikuZm9ybWF0KFwiREQvTU0vWVlZWVwiKX08L3NwYW4+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIG1vbWVudCh2KS5mb3JtYXQoXCJERC9NTS9ZWVlZXCIpXHJcbiAgICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIkV4cGVjdGVkXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJleHBlY3RlZFwiLFxyXG4gICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICByZW5kZXI6ICh2LCByb3cpID0+IHtcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IE51bWJlcih2IHx8IDApO1xyXG4gICAgICAgIHJldHVybiByb3cudmFjYW50X2N5Y2xlID8gKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwiI2I1ODkwMFwiLCBmb250V2VpZ2h0OiBcIjYwMFwiIH19PlxyXG4gICAgICAgICAgICDigrl7dmFsdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICDigrl7dmFsdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICk7XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJQYWlkXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJwYWlkXCIsXHJcbiAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgIHJlbmRlcjogKHYpID0+IHtcclxuICAgICAgICBjb25zdCB2YWx1ZSA9IE51bWJlcih2IHx8IDApO1xyXG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAg4oK5e3ZhbHVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwgeyBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMiB9KX1cclxuICAgICAgICA8L3NwYW4+O1xyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiQmFsYW5jZVwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwiYmFsYW5jZVwiLFxyXG4gICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICByZW5kZXI6ICh2KSA9PiB7XHJcbiAgICAgICAgY29uc3QgdmFsdWUgPSBOdW1iZXIodiB8fCAwKTtcclxuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICDigrl7dmFsdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxyXG4gICAgICAgIDwvc3Bhbj47XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJQZW5hbHR5XCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJwZW5hbHR5XCIsXHJcbiAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgIHJlbmRlcjogKHYsIHJvdykgPT4ge1xyXG4gICAgICAgIGNvbnN0IHZhbHVlID0gTnVtYmVyKHYgfHwgMCk7XHJcbiAgICAgICAgcmV0dXJuIHJvdy52YWNhbnRfY3ljbGUgPyAoXHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogXCIjZDk3NzA2XCIsIGZvbnRXZWlnaHQ6IDcwMCB9fT5cclxuICAgICAgICAgICAg4oK5e3ZhbHVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwgeyBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMiB9KX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IHZhbHVlID4gMCA/IFwicmVkXCIgOiBcImdyYXlcIiwgZm9udFdlaWdodDogNTAwIH19PlxyXG4gICAgICAgICAgICDigrl7dmFsdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICk7XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJMYXRlIEZlZVwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwibGF0ZV9wYXltZW50X2NoYXJnZXNcIixcclxuICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgcmVuZGVyOiAodikgPT4ge1xyXG4gICAgICAgIGNvbnN0IHZhbHVlID0gTnVtYmVyKHYgfHwgMCk7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICDigrl7dmFsdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICk7XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJQZW5hbHR5IFJhdGVcIixcclxuICAgICAgZGF0YUluZGV4OiBcInBlbmFsdHlfcmF0ZV9wZXJjZW50XCIsXHJcbiAgICAgIGFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgICByZW5kZXI6ICh2LCByb3cpID0+XHJcbiAgICAgICAgcm93LnZhY2FudF9jeWNsZSA/IDxUYWcgY29sb3I9XCJnb2xkXCI+VkMgUmF0ZTwvVGFnPiA6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMFwiPntOdW1iZXIodiB8fCAwKX0lPC9zcGFuPixcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZXhwb3J0QnJlYWtkb3duVG9DU1YgPSAoKSA9PiB7XHJcbiAgICBpZiAoIWJyZWFrZG93bkRhdGEubGVuZ3RoKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIk5vIGRhdGEgdG8gZXhwb3J0XCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCBoZWFkZXJzID0gW1xyXG4gICAgICBcIkF1Y3Rpb25cIixcclxuICAgICAgXCJEdWUgRGF0ZVwiLFxyXG4gICAgICBcIkV4cGVjdGVkXCIsXHJcbiAgICAgIFwiUGFpZFwiLFxyXG4gICAgICBcIkJhbGFuY2VcIixcclxuICAgICAgXCJQZW5hbHR5XCIsXHJcbiAgICAgIFwiTGF0ZSBGZWVcIixcclxuICAgICAgXCJQZW5hbHR5IFJhdGUgKCUpXCIsXHJcbiAgICBdO1xyXG4gICAgY29uc3QgY3N2Q29udGVudCA9IFtcclxuICAgICAgaGVhZGVycy5qb2luKFwiLFwiKSxcclxuICAgICAgLi4uYnJlYWtkb3duRGF0YS5tYXAoKHJvdykgPT4ge1xyXG4gICAgICAgIGNvbnN0IGF1Y3Rpb24gPSByb3cudmFjYW50X2N5Y2xlID8gXCJWQ1wiIDogcm93LmN5Y2xlX25vO1xyXG4gICAgICAgIGNvbnN0IGR1ZURhdGUgPSBtb21lbnQocm93LnRvX2RhdGUpLmZvcm1hdChcIkREL01NL1lZWVlcIik7XHJcbiAgICAgICAgY29uc3QgZXhwZWN0ZWQgPSBOdW1iZXIocm93LmV4cGVjdGVkIHx8IDApLnRvRml4ZWQoMik7XHJcbiAgICAgICAgY29uc3QgcGFpZCA9IE51bWJlcihyb3cucGFpZCB8fCAwKS50b0ZpeGVkKDIpO1xyXG4gICAgICAgIGNvbnN0IGJhbGFuY2UgPSBOdW1iZXIocm93LmJhbGFuY2UgfHwgMCkudG9GaXhlZCgyKTtcclxuICAgICAgICBjb25zdCBwZW5hbHR5ID0gTnVtYmVyKHJvdy5wZW5hbHR5IHx8IDApLnRvRml4ZWQoMik7XHJcbiAgICAgICAgY29uc3QgbGF0ZUZlZSA9IE51bWJlcihyb3cubGF0ZV9wYXltZW50X2NoYXJnZXMgfHwgMCkudG9GaXhlZCgyKTtcclxuICAgICAgICBjb25zdCBwZW5hbHR5UmF0ZSA9IHJvdy52YWNhbnRfY3ljbGUgPyBcIlZDIFJhdGVcIiA6IE51bWJlcihyb3cucGVuYWx0eV9yYXRlX3BlcmNlbnQgfHwgMCk7XHJcbiAgICAgICAgY29uc3QgZXNjYXBlID0gKHZhbCkgPT5cclxuICAgICAgICAgIHR5cGVvZiB2YWwgPT09IFwic3RyaW5nXCIgJiYgKHZhbC5pbmNsdWRlcyhcIixcIikgfHwgdmFsLmluY2x1ZGVzKCdcIicpKVxyXG4gICAgICAgICAgICA/IGBcIiR7dmFsLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgXHJcbiAgICAgICAgICAgIDogdmFsO1xyXG4gICAgICAgIHJldHVybiBbXHJcbiAgICAgICAgICBlc2NhcGUoYXVjdGlvbiksXHJcbiAgICAgICAgICBlc2NhcGUoZHVlRGF0ZSksXHJcbiAgICAgICAgICBleHBlY3RlZCxcclxuICAgICAgICAgIHBhaWQsXHJcbiAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgcGVuYWx0eSxcclxuICAgICAgICAgIGxhdGVGZWUsXHJcbiAgICAgICAgICBlc2NhcGUocGVuYWx0eVJhdGUpLFxyXG4gICAgICAgIF0uam9pbihcIixcIik7XHJcbiAgICAgIH0pLFxyXG4gICAgXS5qb2luKFwiXFxuXCIpO1xyXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZDb250ZW50XSwgeyB0eXBlOiBcInRleHQvY3N2O2NoYXJzZXQ9dXRmLTg7XCIgfSk7XHJcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xyXG4gICAgbGluay5ocmVmID0gdXJsO1xyXG4gICAgbGluay5zZXRBdHRyaWJ1dGUoXHJcbiAgICAgIFwiZG93bmxvYWRcIixcclxuICAgICAgYFBlbmFsdHlCcmVha2Rvd25fJHtzZWxlY3RlZEN1c3RvbWVyPy51c2VyTmFtZSB8fCBcImN1c3RvbWVyXCJ9XyR7bW9tZW50KCkuZm9ybWF0KFwiWVlZWU1NRERcIil9LmNzdmBcclxuICAgICk7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxpbmspO1xyXG4gICAgbGluay5jbGljaygpO1xyXG4gICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChsaW5rKTtcclxuICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gbXQtMjAgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmF5LTUwIHRvLWdyYXktMTAwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAge3NjcmVlbkxvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLXNjcmVlblwiPlxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgdy0xLzIgcC02XCI+XHJcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgd2l0aCBidXR0b25zICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTggZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+UGVuYWx0eSAmIE91dHN0YW5kaW5nIFJlcG9ydDwvaDE+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+TW9uaXRvciBhbmQgbWFuYWdlIGN1c3RvbWVyIHBlbmFsdGllcywgbGF0ZSBmZWVzLCBhbmQgb3V0c3RhbmRpbmcgYW1vdW50czwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhc2hlZFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvcGVuYWx0eS1zZXR0aW5ncycpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHbyB0byBQZW5hbHR5IFNldHRpbmdzXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8Q2FsY3VsYXRvck91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBZGRQZW5hbHR5RHJhd2VyT3Blbih0cnVlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkIFBlbmFsdHlcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249ezxBaUZpbGxCYWNrd2FyZCAvPn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmV2ZXJzYWxEcmF3ZXJPcGVuKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBQZW5hbHR5IFJldmVyc2FsXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTWFpbiBGaWx0ZXJzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2hhZG93LXNtIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiXHJcbiAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RmlsdGVyT3V0bGluZWQgY2xhc3NOYW1lPVwibXItMiB0ZXh0LXZpb2xldC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1sZ1wiPkZpbHRlcnM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkdyb3VwIEZpbHRlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGEgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0R3JvdXBGaWx0ZXIodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwRmlsdGVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIHN1ZmZpeEljb249ezxVc2VyZ3JvdXBBZGRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+U2VhcmNoIEN1c3RvbWVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IG5hbWUsIHBob25lLCBvciBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmVmaXg9ezxTZWFyY2hPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoVGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFN0YXRzIENhcmRzIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIHsvKiBGaXJzdCBSb3cgLSBDb21wYWN0IE92ZXJ2aWV3IENhcmRzICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfT5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC0xMDAgcC0zIHJvdW5kZWQtbGcgbXItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxVc2VyZ3JvdXBBZGRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC01MDAgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3RvdGFscy50b3RhbEN1c3RvbWVyc308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXB1cnBsZS0xMDAgcC0zIHJvdW5kZWQtbGcgbXItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxjdWxhdG9yT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNTAwIHRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBUaWNrZXRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57dG90YWxzLnRvdGFsVGlja2V0c308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBwLTMgcm91bmRlZC1sZyBtci00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJncm91cEFkZE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwIHRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBHcm91cHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPnt0b3RhbHMudG90YWxHcm91cHN9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzEyLCAxNl19PlxyXG4gICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXs0fT5cclxuICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LW1kIGJvcmRlci1sLTQgYm9yZGVyLWwtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBQZW5hbHR5PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKHRvdGFscy50b3RhbFBlbmFsdHkgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17NH0+XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1tZCBib3JkZXItbC00IGJvcmRlci1sLW9yYW5nZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+VG90YWwgTGF0ZSBGZWVzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKHRvdGFscy50b3RhbExhdGVGZWUgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17NH0+XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1tZCBib3JkZXItbC00IGJvcmRlci1sLWFtYmVyLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5QZW5hbHR5IENvbGxlY3RlZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge21vbnRobHlDb2xsZWN0ZWRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgc2l6ZT1cInNtYWxsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG1vbnRobHlDb2xsZWN0ZWRTdW1tYXJ5ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtYW1iZXItNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKG1vbnRobHlDb2xsZWN0ZWRTdW1tYXJ5LnRvdGFsQ29sbGVjdGVkKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+Tm8gZGF0YTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibGlua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vbnRobHlEZXRhaWxzTW9kYWxWaXNpYmxlKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0xIHAtMCBoLWF1dG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RXllT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1hbWJlci02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXs0fT5cclxuICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LW1kIGJvcmRlci1sLTQgYm9yZGVyLWwtdmlvbGV0LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBCYWxhbmNlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKHRvdGFscy50b3RhbEJhbGFuY2VXaXRob3V0UGVuYWx0eSB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXs0fT5cclxuICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LW1kIGJvcmRlci1sLTQgYm9yZGVyLWwtcHVycGxlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5PdXRzdGFuZGluZyAody8gUGVuYWx0eSk8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtcHVycGxlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtOdW1iZXIodG90YWxzLnRvdGFsT3V0c3RhbmRpbmdXaXRoUGVuYWx0eSB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXs0fT5cclxuICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LW1kIGJvcmRlci1sLTQgYm9yZGVyLWwtcGluay01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+UGVuYWx0eSArIExhdGUgRmVlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXBpbmstNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcih0b3RhbHMudG90YWxQZW5hbHR5QW5kTGF0ZUZlZSB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4gICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNoYWRvdy1zbSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgb3ZlcmZsb3ctaGlkZGVuXCJcclxuICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtbGdcIj5DdXN0b21lciBEZXRhaWxzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSb3dzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXZpb2xldC02MDBcIj57c2VsZWN0ZWRSb3dzLmxlbmd0aH0gc2VsZWN0ZWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIGBTaG93aW5nICR7ZmlsdGVyZWRVc2Vycy5sZW5ndGh9IG9mICR7dXNlcnNEYXRhLmxlbmd0aH0gUmVjb3Jkc2BcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgZXh0cmE9e1xyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRSb3dzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIGljb249ezxNZXNzYWdlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGFzaGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5TZW5kTW9kYWwoXCJ2Y1dpdGhpbkdyYWNlXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3RlZFJvd3Muc29tZSgodSkgPT4gdS5pc1ZjV2l0aGluR3JhY2UpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFZDIEdyYWNlIFJlbWluZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFdhcm5pbmdPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlblNlbmRNb2RhbChcInZjUGVuYWx0eUFwcGxpZWRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGVkUm93cy5zb21lKCh1KSA9PiB1LmlzVmNQZW5hbHR5QXBwbGllZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVkMgUGVuYWx0eSBBcHBsaWVkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PENsb2NrQ2lyY2xlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuU2VuZE1vZGFsKFwibGF0ZVBlbmFsdHlXaXRoaW5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGVkUm93cy5zb21lKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAodSkgPT4gIXUuaXNWY1dpdGhpbkdyYWNlICYmICF1LmlzVmNQZW5hbHR5QXBwbGllZCAmJiB1LnN0YXR1c0Rpdj8ucHJvcHM/LmNoaWxkcmVuPy5wcm9wcz8uY2hpbGRyZW4/LmluY2x1ZGVzKFwiVW4gUHJpemVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIExhdGUgKE5vIFBlbmFsdHkpXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgaWNvbj17PERvbGxhckNpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlblNlbmRNb2RhbChcImxhdGVQZW5hbHR5QXBwbGllZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRSb3dzLnNvbWUoKHUpID0+IHUuaGFzUGVuYWx0eU9yTGF0ZUZlZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGVuYWx0eSBBcHBsaWVkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFJvd3MoW10pfSBkaXNhYmxlZD17c2VsZWN0ZWRSb3dzLmxlbmd0aCA9PT0gMH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDbGVhciAoe3NlbGVjdGVkUm93cy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWF1dG8gb3ZlcmZsb3cteS1hdXRvIG1heC1oLVs2MDBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IFwibWF4LWNvbnRlbnRcIiB9fT5cclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQZW5hbHR5IFJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlBlbmFsdHlSZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBCcmVha2Rvd24gTW9kYWwgKi99XHJcbiAgICAgIDxNb2RhbFxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8RXllT3V0bGluZWQgY2xhc3NOYW1lPVwibXItMiB0ZXh0LXZpb2xldC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlBlbmFsdHkgQnJlYWtkb3duPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEN1c3RvbWVyLnVzZXJOYW1lfSAtIHtzZWxlY3RlZEN1c3RvbWVyLmdyb3VwTmFtZX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXticmVha2Rvd25Nb2RhbH1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0QnJlYWtkb3duTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgICB3aWR0aD17MTIwMH1cclxuICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogXCIyMHB4XCIgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHtsb2FkaW5nQnJlYWtkb3duID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTY0XCI+XHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17ZXhwb3J0QnJlYWtkb3duVG9DU1Z9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ0JyZWFrZG93biB8fCAhYnJlYWtkb3duRGF0YS5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICBpY29uPXs8RG93bmxvYWRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBFeHBvcnQgdG8gQ1NWXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8VGFibGVcclxuICAgICAgICAgICAgICBkYXRhU291cmNlPXticmVha2Rvd25EYXRhLm1hcCgoZCwgaSkgPT4gKHsgLi4uZCwga2V5OiBpIH0pKX1cclxuICAgICAgICAgICAgICBjb2x1bW5zPXticmVha2Rvd25Db2x1bW5zfVxyXG4gICAgICAgICAgICAgIHBhZ2luYXRpb249e2ZhbHNlfVxyXG4gICAgICAgICAgICAgIGJvcmRlcmVkXHJcbiAgICAgICAgICAgICAgc2Nyb2xsPXt7IHg6IDEzMDAsIHk6IDQwMCB9fVxyXG4gICAgICAgICAgICAgIHJvd0NsYXNzTmFtZT17KHJlY29yZCkgPT4gKHJlY29yZC52YWNhbnRfY3ljbGUgPyBcImJnLXllbGxvdy01MCBib3JkZXItbC00IGJvcmRlci15ZWxsb3ctNTAwXCIgOiBcIlwiKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy02IGdhcC00IG10LTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPkV4cGVjdGVkPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICDigrl7YnJlYWtkb3duRGF0YS5yZWR1Y2UoKHMsIGQpID0+IHMgKyAoZC5leHBlY3RlZCB8fCAwKSwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtXCI+UGFpZDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi02MDBcIj5cclxuICAgICAgICAgICAgICAgICAg4oK5e2JyZWFrZG93bkRhdGEucmVkdWNlKChzLCBkKSA9PiBzICsgKGQucGFpZCB8fCAwKSwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtXCI+UGVuYWx0eTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIOKCuXticmVha2Rvd25EYXRhLnJlZHVjZSgocywgZCkgPT4gcyArIChkLnBlbmFsdHkgfHwgMCksIDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPkxhdGUgRmVlczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIOKCuXticmVha2Rvd25EYXRhLnJlZHVjZSgocywgZCkgPT4gcyArIChkLmxhdGVfcGF5bWVudF9jaGFyZ2VzIHx8IDApLCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5WQyBQZW5hbHR5PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQteWVsbG93LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICDigrl7YnJlYWtkb3duRGF0YS5maWx0ZXIoKGQpID0+IGQudmFjYW50X2N5Y2xlKS5yZWR1Y2UoKHMsIGQpID0+IHMgKyAoZC5wZW5hbHR5IHx8IDApLCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgIHsvKiBXaGF0c0FwcCBCdWxrIENvbmZpcm1hdGlvbiBNb2RhbCAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8TWVzc2FnZU91dGxpbmVkIGNsYXNzTmFtZT1cIm1yLTIgdGV4dC12aW9sZXQtNjAwXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAge3NlbmRNb2RhbC50eXBlID09PSBcInZjV2l0aGluR3JhY2VcIiAmJiBcIlNlbmQgVkMgR3JhY2UgUmVtaW5kZXI/XCJ9XHJcbiAgICAgICAgICAgICAge3NlbmRNb2RhbC50eXBlID09PSBcInZjUGVuYWx0eUFwcGxpZWRcIiAmJiBcIlNlbmQgVkMgUGVuYWx0eSBBcHBsaWVkIEFsZXJ0P1wifVxyXG4gICAgICAgICAgICAgIHtzZW5kTW9kYWwudHlwZSA9PT0gXCJsYXRlUGVuYWx0eVdpdGhpblwiICYmIFwiU2VuZCBMYXRlIChObyBQZW5hbHR5KSBSZW1pbmRlcj9cIn1cclxuICAgICAgICAgICAgICB7c2VuZE1vZGFsLnR5cGUgPT09IFwibGF0ZVBlbmFsdHlBcHBsaWVkXCIgJiYgXCJTZW5kIFBlbmFsdHkgQXBwbGllZCBOb3RpY2U/XCJ9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXtzZW5kTW9kYWwub3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2VuZE1vZGFsKHsgb3BlbjogZmFsc2UsIHR5cGU6IG51bGwgfSl9XHJcbiAgICAgICAgb25Paz17aGFuZGxlU2VuZFdoYXRzYXBwfVxyXG4gICAgICAgIG9rVGV4dD1cIlNlbmQgTm93XCJcclxuICAgICAgICBva0J1dHRvblByb3BzPXt7XHJcbiAgICAgICAgICBsb2FkaW5nOiBzY3JlZW5Mb2FkaW5nLFxyXG4gICAgICAgICAgZGFuZ2VyOiBzZW5kTW9kYWwudHlwZT8uaW5jbHVkZXMoXCJQZW5hbHR5XCIpLFxyXG4gICAgICAgIH19XHJcbiAgICAgICAgY2FuY2VsVGV4dD1cIkNhbmNlbFwiXHJcbiAgICAgID5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi00XCI+WW91IGFyZSBhYm91dCB0byBzZW5kIFdoYXRzQXBwIG1lc3NhZ2VzIHRvIDxzdHJvbmc+e3NlbGVjdGVkUm93cy5sZW5ndGh9PC9zdHJvbmc+IGN1c3RvbWVyKHMpLjwvcD5cclxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC1kaXNjIHBsLTUgdGV4dC1zbSB0ZXh0LWdyYXktNzAwIG1heC1oLTMyIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAge3NlbGVjdGVkUm93cy5zbGljZSgwLCA1KS5tYXAoKHUpID0+IChcclxuICAgICAgICAgICAgPGxpIGtleT17dS5faWR9PlxyXG4gICAgICAgICAgICAgIHt1LnVzZXJOYW1lfSAoe3UudXNlclBob25lfSkgLSB7dS5ncm91cE5hbWV9XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICAgIHtzZWxlY3RlZFJvd3MubGVuZ3RoID4gNSAmJiA8bGk+KyB7c2VsZWN0ZWRSb3dzLmxlbmd0aCAtIDV9IG1vcmUuLi48L2xpPn1cclxuICAgICAgICA8L3VsPlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgey8qIE1vbnRobHkgUGVuYWx0eSBDb2xsZWN0aW9uIERldGFpbHMgTW9kYWwgKi99XHJcbiAgICAgIDxNb2RhbFxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPFdhbGxldE91dGxpbmVkIGNsYXNzTmFtZT1cIm1yLTIgdGV4dC1hbWJlci02MDBcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5Nb250aGx5IFBlbmFsdHkgQ29sbGVjdGlvbiBEZXRhaWxzPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9wZW49e21vbnRobHlEZXRhaWxzTW9kYWxWaXNpYmxlfVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRNb250aGx5RGV0YWlsc01vZGFsVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICA8QnV0dG9uIGtleT1cImJhY2tcIiBvbkNsaWNrPXsoKSA9PiBzZXRNb250aGx5RGV0YWlsc01vZGFsVmlzaWJsZShmYWxzZSl9PlxyXG4gICAgICAgICAgICBCYWNrXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICBdfVxyXG4gICAgICAgIHdpZHRoPXsxMDAwfVxyXG4gICAgICAgIGJvZHlTdHlsZT17eyBwYWRkaW5nOiBcIjIwcHhcIiB9fVxyXG4gICAgICA+XHJcbiAgICAgICAge21vbnRobHlDb2xsZWN0ZWRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTY0XCI+XHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTQgYmctYW1iZXItNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlRvdGFsIENvbGxlY3RlZCBUaGlzIE1vbnRoPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYW1iZXItNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihtb250aGx5Q29sbGVjdGVkU3VtbWFyeT8udG90YWxDb2xsZWN0ZWQpLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+TnVtYmVyIG9mIFRyYW5zYWN0aW9uczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge21vbnRobHlDb2xsZWN0ZWREZXRhaWxzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxUYWJsZVxyXG4gICAgICAgICAgICAgIGRhdGFTb3VyY2U9e21vbnRobHlDb2xsZWN0ZWREZXRhaWxzfVxyXG4gICAgICAgICAgICAgIHJvd0tleT1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgcGFnaW5hdGlvbj17eyBwYWdlU2l6ZTogMTAgfX1cclxuICAgICAgICAgICAgICBzY3JvbGw9e3sgeDogOTAwIH19XHJcbiAgICAgICAgICAgICAgY29sdW1ucz17W1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICBkYXRhSW5kZXg6IFwidXNlck5hbWVcIixcclxuICAgICAgICAgICAgICAgICAga2V5OiBcInVzZXJOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgIHJlbmRlcjogKG5hbWUsIHIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntyLnVzZXJOYW1lIHx8IFwi4oCUXCJ9IDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj57ci51c2VyTmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7IHRpdGxlOiBcIkdyb3VwXCIsIGRhdGFJbmRleDogXCJncm91cE5hbWVcIiwga2V5OiBcImdyb3VwTmFtZVwiIH0sXHJcbiAgICAgICAgICAgICAgICB7IHRpdGxlOiBcIlRpY2tldFwiLCBkYXRhSW5kZXg6IFwidGlja2V0XCIsIGtleTogXCJ0aWNrZXRcIiB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJSZWd1bGFyXCIsXHJcbiAgICAgICAgICAgICAgICAgIGRhdGFJbmRleDogXCJyZWd1bGFyX3BlbmFsdHlcIixcclxuICAgICAgICAgICAgICAgICAga2V5OiBcInJlZ3VsYXJfcGVuYWx0eVwiLFxyXG4gICAgICAgICAgICAgICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICAgICAgICAgICAgICByZW5kZXI6ICh2KSA9PiBg4oK5JHtOdW1iZXIodiB8fCAwKS50b0ZpeGVkKDIpfWAsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJWQyBQZW5hbHR5XCIsXHJcbiAgICAgICAgICAgICAgICAgIGRhdGFJbmRleDogXCJ2Y19wZW5hbHR5XCIsXHJcbiAgICAgICAgICAgICAgICAgIGtleTogXCJ2Y19wZW5hbHR5XCIsXHJcbiAgICAgICAgICAgICAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgICAgICAgICAgICAgIHJlbmRlcjogKHYpID0+IGDigrkke051bWJlcih2IHx8IDApLnRvRml4ZWQoMil9YCxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIkxhdGUgRmVlXCIsXHJcbiAgICAgICAgICAgICAgICAgIGRhdGFJbmRleDogXCJsYXRlX2ZlZVwiLFxyXG4gICAgICAgICAgICAgICAgICBrZXk6IFwibGF0ZV9mZWVcIixcclxuICAgICAgICAgICAgICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgICAgICAgICAgICAgcmVuZGVyOiAodikgPT4gYOKCuSR7TnVtYmVyKHYgfHwgMCkudG9GaXhlZCgyKX1gLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVG90YWxcIixcclxuICAgICAgICAgICAgICAgICAgZGF0YUluZGV4OiBcInRvdGFsX3BlbmFsdHlfZGVkdWN0ZWRcIixcclxuICAgICAgICAgICAgICAgICAga2V5OiBcInRvdGFsXCIsXHJcbiAgICAgICAgICAgICAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgICAgICAgICAgICAgIHJlbmRlcjogKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNzAwXCI+4oK5e051bWJlcih2IHx8IDApLnRvRml4ZWQoMil9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJEYXRlXCIsXHJcbiAgICAgICAgICAgICAgICAgIGRhdGFJbmRleDogXCJjcmVhdGVkQXRcIixcclxuICAgICAgICAgICAgICAgICAga2V5OiBcImRhdGVcIixcclxuICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoZCkgPT4gbW9tZW50KGQpLmZvcm1hdChcIkREIE1NTSBZWVlZXCIpLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgIHsvKiBQZW5hbHR5IFJldmVyc2FsIFNlbGVjdGlvbiBEcmF3ZXIgKi99XHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxVbmRvT3V0bGluZWQgY2xhc3NOYW1lPVwibXItMiB0ZXh0LXZpb2xldC02MDBcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5QZW5hbHR5IFJldmVyc2FsPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRSZXZlcnNhbERyYXdlck9wZW4oZmFsc2UpfVxyXG4gICAgICAgIG9wZW49e3JldmVyc2FsRHJhd2VyT3Blbn1cclxuICAgICAgICB3aWR0aD17NjAwfVxyXG4gICAgICAgIGJvZHlTdHlsZT17eyBwYWRkaW5nOiBcIjIwcHhcIiB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICA8QWxlcnRcclxuICAgICAgICAgICAgbWVzc2FnZT1cIlNlbGVjdCBhIGN1c3RvbWVyIHRvIHJldmVyc2UgcGVuYWx0aWVzXCJcclxuICAgICAgICAgICAgZGVzY3JpcHRpb249XCJDaG9vc2UgYSBncm91cCwgY3VzdG9tZXIsIGFuZCB0aWNrZXQgdG8gdmlldyBhbmQgcmV2ZXJzZSBwZW5hbHRpZXMgZm9yIHRoYXQgYWNjb3VudC5cIlxyXG4gICAgICAgICAgICB0eXBlPVwiaW5mb1wiXHJcbiAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+R3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3JldmVyc2FsR3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cFNlbGVjdH1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuICAgICAgICAgICAgICAgICAge2dyb3VwfVxyXG4gICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlN0ZXAgMTogU2VsZWN0IGEgZ3JvdXAgdG8gcHJvY2VlZDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+Q3VzdG9tZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3JldmVyc2FsQ3VzdG9tZXJGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUN1c3RvbWVyU2VsZWN0KHZhbHVlKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17IXJldmVyc2FsR3JvdXBGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2N1c3RvbWVyT3B0aW9ucy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXt1c2VyLnVzZXJOYW1lfSB2YWx1ZT17dXNlci51c2VyTmFtZX0+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2VyLnVzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIHtyZXZlcnNhbEdyb3VwRmlsdGVyXHJcbiAgICAgICAgICAgICAgICA/IFwiU3RlcCAyOiBDaG9vc2UgYSBjdXN0b21lciBmcm9tIHRoaXMgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgOiBcIlNlbGVjdCBhIGdyb3VwIGZpcnN0XCJ9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+VGlja2V0PC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgVGlja2V0XCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cmV2ZXJzYWxUaWNrZXRGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUaWNrZXRTZWxlY3R9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFyZXZlcnNhbEN1c3RvbWVyRmlsdGVyfVxyXG4gICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHt0aWNrZXRPcHRpb25zLm1hcCgodGlja2V0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uIGtleT17dGlja2V0fSB2YWx1ZT17dGlja2V0fT5cclxuICAgICAgICAgICAgICAgICAge3RpY2tldH1cclxuICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICB7cmV2ZXJzYWxDdXN0b21lckZpbHRlclxyXG4gICAgICAgICAgICAgICAgPyBcIlN0ZXAgMzogU2VsZWN0IGEgdGlja2V0IHRvIHJldmlldyBwZW5hbHRpZXNcIlxyXG4gICAgICAgICAgICAgICAgOiBcIlNlbGVjdCBhIGN1c3RvbWVyIGZpcnN0XCJ9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00XCI+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXshcmV2ZXJzYWxUaWNrZXRGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdXNlciA9IHVzZXJzRGF0YS5maW5kKFxyXG4gICAgICAgICAgICAgICAgICAodSkgPT5cclxuICAgICAgICAgICAgICAgICAgICB1Lmdyb3VwTmFtZSA9PT0gcmV2ZXJzYWxHcm91cEZpbHRlciAmJlxyXG4gICAgICAgICAgICAgICAgICAgIHUudXNlck5hbWUgPT09IHJldmVyc2FsQ3VzdG9tZXJGaWx0ZXIgJiZcclxuICAgICAgICAgICAgICAgICAgICB1LnBheW1lbnRzVGlja2V0ID09PSByZXZlcnNhbFRpY2tldEZpbHRlclxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIGlmICh1c2VyKSB7XHJcbiAgICAgICAgICAgICAgICAgIHNldFBlbmFsdHlTdW1tYXJ5KHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci51c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgcGF5bWVudHNUaWNrZXQ6IHVzZXIucGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcklkOiB1c2VyLnVzZXJJZCxcclxuICAgICAgICAgICAgICAgICAgICBncm91cElkOiB1c2VyLmdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWxMYXRlRmVlOiB1c2VyLnRvdGFsTGF0ZUZlZSB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgIHJlZ3VsYXJQZW5hbHR5OiB1c2VyLnJlZ3VsYXJQZW5hbHR5IHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgdmNQZW5hbHR5OiB1c2VyLnZjUGVuYWx0eSB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgc2V0UmV2ZXJzYWxEcmF3ZXJPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0UGVuYWx0eVN1bW1hcnlEcmF3ZXIodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJldmlldyAmIFJldmVyc2UgUGVuYWx0aWVzXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvRHJhd2VyPlxyXG5cclxuICAgICAgPERyYXdlclxyXG4gICAgICAgIHRpdGxlPXtudWxsfVxyXG4gICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRQZW5hbHR5U3VtbWFyeURyYXdlcihmYWxzZSl9XHJcbiAgICAgICAgb3Blbj17cGVuYWx0eVN1bW1hcnlEcmF3ZXJ9XHJcbiAgICAgICAgd2lkdGg9ezkwMH1cclxuICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogXCIwXCIgfX1cclxuICAgICAgICBjbG9zYWJsZT17ZmFsc2V9XHJcbiAgICAgID5cclxuICAgICAgICB7cGVuYWx0eVN1bW1hcnkgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgZmxleCBmbGV4LWNvbCBiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgICB7LyogSGVhZGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCB0ZXh0LXdoaXRlIHAtNiBib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezN9IGNsYXNzTmFtZT1cInRleHQtd2hpdGUgbWItMVwiPlBlbmFsdHkgUmV2ZXJzYWw8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+UmV2aWV3IGFuZCByZXZlcnNlIHBlbmFsdGllcyBmb3IgY3VzdG9tZXIgYWNjb3VudDwvVGV4dD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8QXJyb3dMZWZ0T3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBlbmFsdHlTdW1tYXJ5RHJhd2VyKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgey8qIEN1c3RvbWVyIEluZm8gQ2FyZCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwibWItMFwiPkN1c3RvbWVyIERldGFpbHM8L1RpdGxlPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgYmxvY2sgbWItMVwiPkN1c3RvbWVyIE5hbWU8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIj57cGVuYWx0eVN1bW1hcnkudXNlck5hbWV9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBibG9jayBtYi0xXCI+UGhvbmUgTnVtYmVyPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+e3BlbmFsdHlTdW1tYXJ5LnVzZXJQaG9uZX08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJsb2NrIG1iLTFcIj5Hcm91cDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPntwZW5hbHR5U3VtbWFyeS5ncm91cE5hbWV9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBibG9jayBtYi0xXCI+VGlja2V0IE51bWJlcjwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPntwZW5hbHR5U3VtbWFyeS5wYXltZW50c1RpY2tldH08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiBQZW5hbHR5IEJyZWFrZG93biBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBmbGV4LWdyb3cgb3ZlcmZsb3ctYXV0b1wiPlxyXG4gICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwibWItNFwiPlBlbmFsdHkgQnJlYWtkb3duPC9UaXRsZT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPXtgaC1mdWxsICR7cGVuYWx0eVN1bW1hcnkudG90YWxMYXRlRmVlID4gMCA/ICcnIDogJ29wYWNpdHktNjAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezV9IGNsYXNzTmFtZT1cIm1iLTFcIj5MYXRlIEZlZTwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQtc21cIj5DaGFyZ2VzIGZvciBkZWxheWVkIHBheW1lbnRzPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQtc21cIj5BdmFpbGFibGUgZm9yIFJldmVyc2FsPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKHBlbmFsdHlTdW1tYXJ5LnRvdGFsTGF0ZUZlZSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtwZW5hbHR5U3VtbWFyeS50b3RhbExhdGVGZWUgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlblJldmVyc2VBbW91bnREcmF3ZXIoXCJsYXRlX2ZlZVwiKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZXZpZXcgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT17YGgtZnVsbCAke3BlbmFsdHlTdW1tYXJ5LnJlZ3VsYXJQZW5hbHR5ID4gMCA/ICcnIDogJ29wYWNpdHktNjAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezV9IGNsYXNzTmFtZT1cIm1iLTFcIj5SZWd1bGFyIFBlbmFsdHk8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+U3RhbmRhcmQgcGVuYWx0eSBjaGFyZ2VzPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQtc21cIj5BdmFpbGFibGUgZm9yIFJldmVyc2FsPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKHBlbmFsdHlTdW1tYXJ5LnJlZ3VsYXJQZW5hbHR5KS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge3BlbmFsdHlTdW1tYXJ5LnJlZ3VsYXJQZW5hbHR5ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5SZXZlcnNlQW1vdW50RHJhd2VyKFwicGVuYWx0eVwiKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZXZpZXcgUmVndWxhciBQZW5hbHR5XHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPXtgbWItNCAke3BlbmFsdHlTdW1tYXJ5LnZjUGVuYWx0eSA+IDAgPyAnJyA6ICdvcGFjaXR5LTYwJ31gfT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezV9IGNsYXNzTmFtZT1cIm1iLTFcIj5WYWNhbnQgQ2hpdCBQZW5hbHR5PC9UaXRsZT5cclxuICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQtc21cIj5WYWNhbnQgY2hpdCBwZW5hbHR5IGNoYXJnZXM8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwidGV4dC1zbVwiPkF2YWlsYWJsZSBmb3IgUmV2ZXJzYWw8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihwZW5hbHR5U3VtbWFyeS52Y1BlbmFsdHkpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7cGVuYWx0eVN1bW1hcnkudmNQZW5hbHR5ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuUmV2ZXJzZUFtb3VudERyYXdlcihcInZjX3BlbmFsdHlcIil9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZXZpZXcgVmFjYW50IENoaXQgUGVuYWx0eVxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT17YG1iLTQgJHsocGVuYWx0eVN1bW1hcnkudG90YWxMYXRlRmVlICsgcGVuYWx0eVN1bW1hcnkucmVndWxhclBlbmFsdHkgKyBwZW5hbHR5U3VtbWFyeS52Y1BlbmFsdHkpID4gMCA/ICdib3JkZXItMiBib3JkZXItc2xhdGUtMzAwJyA6ICdvcGFjaXR5LTYwJ31gfT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezV9IGNsYXNzTmFtZT1cIm1iLTFcIj5Ub3RhbCBSZXZlcnNpYmxlIEFtb3VudDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+U3VtIG9mIGFsbCBwZW5hbHRpZXMgYW5kIGZlZXM8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwidGV4dC1zbVwiPlRvdGFsIEF2YWlsYWJsZSBmb3IgUmV2ZXJzYWw8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuXsoXHJcbiAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIocGVuYWx0eVN1bW1hcnkudG90YWxMYXRlRmVlKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIocGVuYWx0eVN1bW1hcnkucmVndWxhclBlbmFsdHkpICtcclxuICAgICAgICAgICAgICAgICAgICAgIE51bWJlcihwZW5hbHR5U3VtbWFyeS52Y1BlbmFsdHkpXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgeyhwZW5hbHR5U3VtbWFyeS50b3RhbExhdGVGZWUgKyBwZW5hbHR5U3VtbWFyeS5yZWd1bGFyUGVuYWx0eSArIHBlbmFsdHlTdW1tYXJ5LnZjUGVuYWx0eSkgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5SZXZlcnNlQW1vdW50RHJhd2VyKFwiYWxsXCIpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUmV2aWV3IEFsbCBQZW5hbHRpZXMgJiBGZWVzXHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlPVwiSW1wb3J0YW50IEluZm9ybWF0aW9uXCJcclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiU2VsZWN0IGEgcGVuYWx0eSB0eXBlIGFib3ZlIHRvIHJldmVyc2UuIFlvdSBtYXkgcmV2ZXJzZSBwYXJ0IG9yIGFsbCBvZiBhbnkgcGVuYWx0eSB0eXBlLiBFbnRlciB0aGUgZXhhY3QgYW1vdW50IGluIHRoZSBuZXh0IHN0ZXAuIEFsbCByZXZlcnNhbHMgd2lsbCBiZSBsb2dnZWQgZm9yIGF1ZGl0IHB1cnBvc2VzLlwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiaW5mb1wiXHJcbiAgICAgICAgICAgICAgICBzaG93SWNvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L0RyYXdlcj5cclxuXHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT17bnVsbH1cclxuICAgICAgICBwbGFjZW1lbnQ9XCJyaWdodFwiXHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0UmV2ZXJzZUFtb3VudERyYXdlcihmYWxzZSk7XHJcbiAgICAgICAgICBzZXRQZW5hbHR5U3VtbWFyeURyYXdlcih0cnVlKTtcclxuICAgICAgICB9fVxyXG4gICAgICAgIG9wZW49e3JldmVyc2VBbW91bnREcmF3ZXJ9XHJcbiAgICAgICAgd2lkdGg9ezgwMH1cclxuICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogXCIwXCIgfX1cclxuICAgICAgICBjbG9zYWJsZT17ZmFsc2V9XHJcbiAgICAgID5cclxuICAgICAgICB7cGVuYWx0eVN1bW1hcnkgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgZmxleCBmbGV4LWNvbCBiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgICB7LyogSGVhZGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCB0ZXh0LXdoaXRlIHAtNiBib3JkZXItYlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezN9IGNsYXNzTmFtZT1cInRleHQtd2hpdGUgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJldmVyc2FsVHlwZSA9PT0gXCJsYXRlX2ZlZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiUmV2ZXJzZSBMYXRlIEZlZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkUmV2ZXJzYWxUeXBlID09PSBcInBlbmFsdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlJldmVyc2UgUmVndWxhciBQZW5hbHR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRSZXZlcnNhbFR5cGUgPT09IFwidmNfcGVuYWx0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiUmV2ZXJzZSBWQyBQZW5hbHR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJSZXZlcnNlIEFsbCBQZW5hbHRpZXMgJiBGZWVzXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0IGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICBFbnRlciB0aGUgYW1vdW50IHlvdSB3YW50IHRvIHJldmVyc2UgZnJvbSB0aGUgY3VzdG9tZXIncyBwZW5hbHRpZXNcclxuICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgZGFuZ2VyXHJcbiAgICAgICAgICAgICAgICAgIGljb249ezxBcnJvd0xlZnRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFJldmVyc2VBbW91bnREcmF3ZXIoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFBlbmFsdHlTdW1tYXJ5RHJhd2VyKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBmbGV4LWdyb3cgb3ZlcmZsb3ctYXV0b1wiPlxyXG4gICAgICAgICAgICAgIHsvKiBDdXN0b21lciBJbmZvICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBib3JkZXItYiBwYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IGNsYXNzTmFtZT1cIm1iLTNcIj5DdXN0b21lciBJbmZvcm1hdGlvbjwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBibG9jayBtYi0xXCI+Q3VzdG9tZXI8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPntwZW5hbHR5U3VtbWFyeS51c2VyTmFtZX08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJsb2NrIG1iLTFcIj5QaG9uZTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+e3BlbmFsdHlTdW1tYXJ5LnVzZXJQaG9uZX08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJsb2NrIG1iLTFcIj5Hcm91cDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+e3BlbmFsdHlTdW1tYXJ5Lmdyb3VwTmFtZX08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJsb2NrIG1iLTFcIj5UaWNrZXQ8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPntwZW5hbHR5U3VtbWFyeS5wYXltZW50c1RpY2tldH08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgey8qIEF2YWlsYWJsZSBBbW91bnQgQ2FyZCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC00IGJnLXNsYXRlLTUwIHJvdW5kZWQtbGcgYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmV2ZXJzYWxUeXBlID09PSBcImxhdGVfZmVlXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiTGF0ZSBGZWUgQXZhaWxhYmxlIGZvciBSZXZlcnNhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBzZWxlY3RlZFJldmVyc2FsVHlwZSA9PT0gXCJwZW5hbHR5XCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiUmVndWxhciBQZW5hbHR5IEF2YWlsYWJsZSBmb3IgUmV2ZXJzYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRSZXZlcnNhbFR5cGUgPT09IFwidmNfcGVuYWx0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcIlZDIFBlbmFsdHkgQXZhaWxhYmxlIGZvciBSZXZlcnNhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIlRvdGFsIFJldmVyc2libGUgQW1vdW50XCJ9XHJcbiAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAg4oK5e21heEFsbG93ZWRBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiPk1heGltdW0gYW1vdW50IHRoYXQgY2FuIGJlIHJldmVyc2VkPC9UZXh0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsvKiBBbW91bnQgSW5wdXQgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwibWItM1wiPkVudGVyIFJldmVyc2FsIEFtb3VudDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZXZlcnNlQW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJldmVyc2VBbW91bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17YEVudGVyIGFtb3VudCAoZS5nLiwgJHtNYXRoLm1pbigxMDAsIG1heEFsbG93ZWRBbW91bnQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9KWB9XHJcbiAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgc3RlcD17MC4wMX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgdGV4dC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgIGFkZG9uQmVmb3JlPVwi4oK5XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7cGFyc2VGbG9hdChyZXZlcnNlQW1vdW50KSA+IG1heEFsbG93ZWRBbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LXNtIG10LTIgZmxleCBpdGVtcy1jZW50ZXIgYmctcmVkLTUwIHAtMiByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwibXItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgQW1vdW50IGNhbm5vdCBleGNlZWQg4oK5e21heEFsbG93ZWRBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsvKiBRdWljayBTZWxlY3QgQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NX0gY2xhc3NOYW1lPVwibWItM1wiPlF1aWNrIFNlbGVjdCBBbW91bnQ8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXZlcnNlQW1vdW50KChtYXhBbGxvd2VkQW1vdW50ICogMC4yNSkudG9GaXhlZCgyKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e21heEFsbG93ZWRBbW91bnQgPD0gMH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDI1JVxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJldmVyc2VBbW91bnQoKG1heEFsbG93ZWRBbW91bnQgKiAwLjUpLnRvRml4ZWQoMikpfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXttYXhBbGxvd2VkQW1vdW50IDw9IDB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA1MCVcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXZlcnNlQW1vdW50KChtYXhBbGxvd2VkQW1vdW50ICogMC43NSkudG9GaXhlZCgyKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e21heEFsbG93ZWRBbW91bnQgPD0gMH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDc1JVxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJldmVyc2VBbW91bnQobWF4QWxsb3dlZEFtb3VudC50b0ZpeGVkKDIpKX1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bWF4QWxsb3dlZEFtb3VudCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgMTAwJVxyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsvKiBXYXJuaW5nIEFsZXJ0ICovfVxyXG4gICAgICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZT1cIkltcG9ydGFudCBOb3RpY2VcIlxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJSZXZlcnNlZCBhbW91bnRzIHdpbGwgYmUgZGVkdWN0ZWQgZnJvbSB0aGUgY3VzdG9tZXIncyBiYWxhbmNlIGFuZCBsb2dnZWQgZm9yIGF1ZGl0LiBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLiBQbGVhc2UgdmVyaWZ5IHRoZSBhbW91bnQgYmVmb3JlIHByb2NlZWRpbmcuXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ3YXJuaW5nXCJcclxuICAgICAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi00XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFJldmVyc2VBbW91bnREcmF3ZXIoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFBlbmFsdHlTdW1tYXJ5RHJhd2VyKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTFcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXJldmVyc2VBbW91bnQgfHwgcGFyc2VGbG9hdChyZXZlcnNlQW1vdW50KSA8PSAwIHx8IHBhcnNlRmxvYXQocmV2ZXJzZUFtb3VudCkgPiBtYXhBbGxvd2VkQW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBcHBseVJldmVyc2FsfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBcHBseSBSZXZlcnNhbFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9EcmF3ZXI+XHJcblxyXG4gICAgICB7LyogQWRkIFBlbmFsdHkgU2VsZWN0aW9uIERyYXdlciAqL31cclxuICAgICAgPERyYXdlclxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJtci0yIHRleHQtdmlvbGV0LTYwMFwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPkFkZCBNYW51YWwgUGVuYWx0eTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBwbGFjZW1lbnQ9XCJyaWdodFwiXHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWRkUGVuYWx0eURyYXdlck9wZW4oZmFsc2UpfVxyXG4gICAgICAgIG9wZW49e2FkZFBlbmFsdHlEcmF3ZXJPcGVufVxyXG4gICAgICAgIHdpZHRoPXs2MDB9XHJcbiAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IFwiMjBweFwiIH19XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICBtZXNzYWdlPVwiU2VsZWN0IGEgY3VzdG9tZXIgdG8gYWRkIG1hbnVhbCBwZW5hbHRpZXNcIlxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkNob29zZSBhIGdyb3VwLCBjdXN0b21lciwgYW5kIHRpY2tldCB0byBhZGQgbWFudWFsIHBlbmFsdGllcyBhbmQgbGF0ZSBmZWVzIHRvIHRoYXQgYWNjb3VudC5cIlxyXG4gICAgICAgICAgICB0eXBlPVwiaW5mb1wiXHJcbiAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTRcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+R3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2FkZFBlbmFsdHlHcm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUFkZFBlbmFsdHlHcm91cFNlbGVjdH1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuICAgICAgICAgICAgICAgICAge2dyb3VwfVxyXG4gICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlN0ZXAgMTogU2VsZWN0IGEgZ3JvdXAgdG8gcHJvY2VlZDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+Q3VzdG9tZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2FkZFBlbmFsdHlDdXN0b21lckZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQWRkUGVuYWx0eUN1c3RvbWVyU2VsZWN0KHZhbHVlKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17IWFkZFBlbmFsdHlHcm91cEZpbHRlcn1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7YWRkUGVuYWx0eUN1c3RvbWVyT3B0aW9ucy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXt1c2VyLnVzZXJOYW1lfSB2YWx1ZT17dXNlci51c2VyTmFtZX0+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2VyLnVzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIHthZGRQZW5hbHR5R3JvdXBGaWx0ZXJcclxuICAgICAgICAgICAgICAgID8gXCJTdGVwIDI6IENob29zZSBhIGN1c3RvbWVyIGZyb20gdGhpcyBncm91cFwiXHJcbiAgICAgICAgICAgICAgICA6IFwiU2VsZWN0IGEgZ3JvdXAgZmlyc3RcIn1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5UaWNrZXQ8L2xhYmVsPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBUaWNrZXRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXthZGRQZW5hbHR5VGlja2V0RmlsdGVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQWRkUGVuYWx0eVRpY2tldFNlbGVjdH1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17IWFkZFBlbmFsdHlDdXN0b21lckZpbHRlcn1cclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7YWRkUGVuYWx0eVRpY2tldE9wdGlvbnMubWFwKCh0aWNrZXQpID0+IChcclxuICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXt0aWNrZXR9IHZhbHVlPXt0aWNrZXR9PlxyXG4gICAgICAgICAgICAgICAgICB7dGlja2V0fVxyXG4gICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIHthZGRQZW5hbHR5Q3VzdG9tZXJGaWx0ZXJcclxuICAgICAgICAgICAgICAgID8gXCJTdGVwIDM6IFNlbGVjdCBhIHRpY2tldCB0byBhZGQgcGVuYWx0aWVzXCJcclxuICAgICAgICAgICAgICAgIDogXCJTZWxlY3QgYSBjdXN0b21lciBmaXJzdFwifVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNFwiPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17IWFkZFBlbmFsdHlUaWNrZXRGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdXNlciA9IHVzZXJzRGF0YS5maW5kKFxyXG4gICAgICAgICAgICAgICAgICAodSkgPT5cclxuICAgICAgICAgICAgICAgICAgICB1Lmdyb3VwTmFtZSA9PT0gYWRkUGVuYWx0eUdyb3VwRmlsdGVyICYmXHJcbiAgICAgICAgICAgICAgICAgICAgdS51c2VyTmFtZSA9PT0gYWRkUGVuYWx0eUN1c3RvbWVyRmlsdGVyICYmXHJcbiAgICAgICAgICAgICAgICAgICAgdS5wYXltZW50c1RpY2tldCA9PT0gYWRkUGVuYWx0eVRpY2tldEZpbHRlclxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIGlmICh1c2VyKSB7XHJcbiAgICAgICAgICAgICAgICAgIHNldEFkZFBlbmFsdHlEZXRhaWxzKHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci51c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgcGF5bWVudHNUaWNrZXQ6IHVzZXIucGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcklkOiB1c2VyLnVzZXJJZCxcclxuICAgICAgICAgICAgICAgICAgICBncm91cElkOiB1c2VyLmdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgYmFsYW5jZTogdXNlci5iYWxhbmNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHRvdGFsUGVuYWx0eTogdXNlci50b3RhbFBlbmFsdHksXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWxMYXRlRmVlOiB1c2VyLnRvdGFsTGF0ZUZlZSxcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEFkZCBQZW5hbHRpZXNcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9EcmF3ZXI+XHJcblxyXG4gICAgICA8RHJhd2VyXHJcbiAgICAgICAgdGl0bGU9e251bGx9XHJcbiAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgIHNldEFkZFBlbmFsdHlEcmF3ZXJPcGVuKGZhbHNlKTtcclxuICAgICAgICAgIHNldEFkZFBlbmFsdHlEZXRhaWxzKG51bGwpO1xyXG4gICAgICAgICAgc2V0QWRkUGVuYWx0eUFtb3VudChcIlwiKTtcclxuICAgICAgICAgIHNldEFkZExhdGVGZWVBbW91bnQoXCJcIik7XHJcbiAgICAgICAgfX1cclxuICAgICAgICBvcGVuPXshIWFkZFBlbmFsdHlEZXRhaWxzfVxyXG4gICAgICAgIHdpZHRoPXs4MDB9XHJcbiAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IFwiMFwiIH19XHJcbiAgICAgICAgY2xvc2FibGU9e2ZhbHNlfVxyXG4gICAgICA+XHJcbiAgICAgICAge2FkZFBlbmFsdHlEZXRhaWxzICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGZsZXggZmxleC1jb2wgYmctd2hpdGVcIj5cclxuICAgICAgICAgICAgey8qIEhlYWRlciBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC0xMDAgdGV4dC13aGl0ZSBwLTYgYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXszfSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIG1iLTFcIj5BZGQgTWFudWFsIFBlbmFsdHk8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+RW50ZXIgcGVuYWx0eSBhbmQgbGF0ZSBmZWUgYW1vdW50cyBmb3IgY3VzdG9tZXIgYWNjb3VudDwvVGV4dD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8QXJyb3dMZWZ0T3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRBZGRQZW5hbHR5RGV0YWlscyhudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRBZGRQZW5hbHR5QW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFkZExhdGVGZWVBbW91bnQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGZsZXgtZ3JvdyBvdmVyZmxvdy1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIEluZm8gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGJvcmRlci1iIHBiLTRcIj5cclxuICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwibWItM1wiPkN1c3RvbWVyIEluZm9ybWF0aW9uPC9UaXRsZT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHR5cGU9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGJsb2NrIG1iLTFcIj5DdXN0b21lcjwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+e2FkZFBlbmFsdHlEZXRhaWxzLnVzZXJOYW1lfTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgYmxvY2sgbWItMVwiPlBob25lPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIj57YWRkUGVuYWx0eURldGFpbHMudXNlclBob25lfTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgYmxvY2sgbWItMVwiPkdyb3VwPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIj57YWRkUGVuYWx0eURldGFpbHMuZ3JvdXBOYW1lfTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgYmxvY2sgbWItMVwiPlRpY2tldDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+e2FkZFBlbmFsdHlEZXRhaWxzLnBheW1lbnRzVGlja2V0fTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgYmxvY2sgbWItMVwiPkN1cnJlbnQgQmFsYW5jZTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+4oK5e051bWJlcihhZGRQZW5hbHR5RGV0YWlscy5iYWxhbmNlIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBibG9jayBtYi0xXCI+Q3VycmVudCBQZW5hbHR5PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIj7igrl7TnVtYmVyKGFkZFBlbmFsdHlEZXRhaWxzLnRvdGFsUGVuYWx0eSB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgYmxvY2sgbWItMVwiPkN1cnJlbnQgTGF0ZSBGZWU8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPuKCuXtOdW1iZXIoYWRkUGVuYWx0eURldGFpbHMudG90YWxMYXRlRmVlIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsvKiBQZW5hbHR5IElucHV0IFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IGNsYXNzTmFtZT1cIm1iLTNcIj5FbnRlciBQZW5hbHR5IERldGFpbHM8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlBlbmFsdHkgQW1vdW50PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2FkZFBlbmFsdHlBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRQZW5hbHR5QW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHBlbmFsdHkgYW1vdW50IChlLmcuLCA1MDApXCJcclxuICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3RlcD17MC4wMX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiB0ZXh0LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICBhZGRvbkJlZm9yZT1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5MYXRlIEZlZSBBbW91bnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWRkTGF0ZUZlZUFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFkZExhdGVGZWVBbW91bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgbGF0ZSBmZWUgYW1vdW50IChlLmcuLCAyMDApXCJcclxuICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3RlcD17MC4wMX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMiB0ZXh0LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICBhZGRvbkJlZm9yZT1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7LyogV2FybmluZyBBbGVydCAqL31cclxuICAgICAgICAgICAgICA8QWxlcnRcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U9XCJJbXBvcnRhbnQgTm90aWNlXCJcclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiVGhlIHBlbmFsdHkgYW5kIGxhdGUgZmVlIGFtb3VudHMgd2lsbCBiZSBhZGRlZCB0byB0aGUgY3VzdG9tZXIncyBhY2NvdW50LiBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLiBQbGVhc2UgdmVyaWZ5IHRoZSBhbW91bnRzIGJlZm9yZSBwcm9jZWVkaW5nLlwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwid2FybmluZ1wiXHJcbiAgICAgICAgICAgICAgICBzaG93SWNvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItNFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMVwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRBZGRQZW5hbHR5RGV0YWlscyhudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRBZGRQZW5hbHR5QW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFkZExhdGVGZWVBbW91bnQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xXCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2FkZFBlbmFsdHlMb2FkaW5nIHx8ICghYWRkUGVuYWx0eUFtb3VudCAmJiAhYWRkTGF0ZUZlZUFtb3VudCl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVQZW5hbHR5fVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXthZGRQZW5hbHR5TG9hZGluZ31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkIFBlbmFsdHlcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvRHJhd2VyPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBlbmFsdHlNb25pdG9yOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QZW5hbHR5TW9uaXRvci5qc3gifQ==