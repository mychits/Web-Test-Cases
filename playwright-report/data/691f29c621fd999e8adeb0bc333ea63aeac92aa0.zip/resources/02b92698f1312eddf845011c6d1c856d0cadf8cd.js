import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/StaffMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const StaffMenu = () => {
  const staffCategories = [
    {
      id: 1,
      title: "Agents",
      description: "Manage agent records, roles and assignments",
      icon: /* @__PURE__ */ jsxDEV(Users, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
        lineNumber: 12,
        columnNumber: 11
      }, this),
      color: "from-blue-600 to-blue-700",
      lightColor: "bg-blue-50",
      borderColor: "border-blue-200",
      href: "/staff-menu/agent-menu",
      stats: "Active Agents"
    },
    {
      id: 2,
      title: "Employees",
      description: "Manage employee records, roles and assignments",
      icon: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
        lineNumber: 23,
        columnNumber: 11
      }, this),
      color: "from-amber-600 to-amber-700",
      lightColor: "bg-amber-50",
      borderColor: "border-amber-200",
      href: "/staff-menu/employee-menu",
      stats: "Active Employees"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
      lineNumber: 36,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
        lineNumber: 38,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-gray-900", children: "HR Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
            lineNumber: 41,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Manage and organize your team members" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
            lineNumber: 44,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
          lineNumber: 40,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6", children: staffCategories.map(
          (category) => /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `relative h-full overflow-hidden rounded-xl bg-white border ${category.borderColor} shadow-md hover:shadow-lg transition-all duration-300`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                    lineNumber: 55,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `inline-flex items-center justify-center w-14 h-14 ${category.lightColor} rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300`,
                      children: /* @__PURE__ */ jsxDEV("div", { children: category.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                        lineNumber: 63,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                      lineNumber: 60,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: category.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                      lineNumber: 67,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: category.description }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                      lineNumber: 70,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                    lineNumber: 66,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                      lineNumber: 76,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `p-1.5 rounded-lg bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300`,
                        children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                          lineNumber: 82,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                        lineNumber: 79,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                    lineNumber: 75,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                  lineNumber: 59,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
                    lineNumber: 87,
                    columnNumber: 21
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
              lineNumber: 52,
              columnNumber: 19
            },
            this
          ) }, category.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
            lineNumber: 51,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
          lineNumber: 49,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border border-blue-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-blue-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
            lineNumber: 97,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
            lineNumber: 96,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
              lineNumber: 100,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Use the staff directory to manage personnel, update employee information and Provide Designation all in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
              lineNumber: 101,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
            lineNumber: 99,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
          lineNumber: 95,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
          lineNumber: 94,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
        lineNumber: 39,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
      lineNumber: 37,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
    lineNumber: 35,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
};
_c = StaffMenu;
export default StaffMenu;
var _c;
$RefreshReg$(_c, "StaffMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/StaffMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1k7QUFYWiwyQkFBcUI7QUFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLE9BQU9BLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxPQUFPQyxXQUFXQyxjQUFhQyxXQUFZO0FBRXBELE1BQU1DLFlBQVlBLE1BQU07QUFDdEIsUUFBTUMsa0JBQWtCO0FBQUEsSUFDdEI7QUFBQSxNQUNFQyxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsTUFDaENDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFUixJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFDcENDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFJSCxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLDJCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUMsNkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIscURBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNaVCwwQkFBZ0JVO0FBQUFBLFVBQUksQ0FBQ0MsYUFDcEIsdUJBQUMsUUFBdUIsSUFBSUEsU0FBU0gsTUFBTSxXQUFVLFNBQ25EO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLDhEQUE4REcsU0FBU0osV0FBVztBQUFBLGNBRTdGO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyxzREFBc0RJLFNBQVNOLEtBQUs7QUFBQTtBQUFBLGtCQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ29MO0FBQUEsZ0JBR3BMLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcscURBQXFETSxTQUFTTCxVQUFVO0FBQUEsc0JBRW5GLGlDQUFDLFNBQUtLLG1CQUFTUCxRQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9CO0FBQUE7QUFBQSxvQkFIdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsb0ZBQ1hPLG1CQUFTVCxTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUseUNBQ1ZTLG1CQUFTUixlQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLGlIQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlHQUNiUSxtQkFBU0YsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxzQ0FBc0NFLFNBQVNOLEtBQUs7QUFBQSx3QkFFL0QsaUNBQUMsZ0JBQWEsV0FBVSx3QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNEM7QUFBQTtBQUFBLHNCQUg5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSUE7QUFBQSx1QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEscUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMEJBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyx3REFBd0RNLFNBQVNOLEtBQUs7QUFBQTtBQUFBLGtCQURuRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQ3dKO0FBQUE7QUFBQTtBQUFBLFlBcEMxSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFzQ0EsS0F2Q1NNLFNBQVNWLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0NBO0FBQUEsUUFDRCxLQTNDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNENBO0FBQUEsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNEZBQ2pCLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLE9BQUksV0FBVSxnQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDZDQUE0QywwQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxPQUFFLFdBQVUsa0JBQWlCLGtJQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnSjtBQUFBLGVBRmxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVSjtBQUFBLFdBakVBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrRUE7QUFBQSxTQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsT0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdFQSxLQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEVBO0FBRUo7QUFBRVcsS0F4R0liO0FBMEdOLGVBQWVBO0FBQVUsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5hdmJhciIsIlNpZGViYXIiLCJVc2VycyIsIkJyaWVmY2FzZSIsIkNoZXZyb25SaWdodCIsIlphcCIsIlN0YWZmTWVudSIsInN0YWZmQ2F0ZWdvcmllcyIsImlkIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImljb24iLCJjb2xvciIsImxpZ2h0Q29sb3IiLCJib3JkZXJDb2xvciIsImhyZWYiLCJzdGF0cyIsIm1hcCIsImNhdGVnb3J5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3RhZmZNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgVXNlcnMsIEJyaWVmY2FzZSwgQ2hldnJvblJpZ2h0LFphcCAgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcblxyXG5jb25zdCBTdGFmZk1lbnUgPSAoKSA9PiB7XHJcbiAgY29uc3Qgc3RhZmZDYXRlZ29yaWVzID0gW1xyXG4gICAge1xyXG4gICAgICBpZDogMSxcclxuICAgICAgdGl0bGU6IFwiQWdlbnRzXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBhZ2VudCByZWNvcmRzLCByb2xlcyBhbmQgYXNzaWdubWVudHNcIixcclxuICAgICAgaWNvbjogPFVzZXJzIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPixcclxuICAgICAgY29sb3I6IFwiZnJvbS1ibHVlLTYwMCB0by1ibHVlLTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLWJsdWUtNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLWJsdWUtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL3N0YWZmLW1lbnUvYWdlbnQtbWVudVwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgQWdlbnRzXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogMixcclxuICAgICAgdGl0bGU6IFwiRW1wbG95ZWVzXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBlbXBsb3llZSByZWNvcmRzLCByb2xlcyBhbmQgYXNzaWdubWVudHNcIixcclxuICAgICAgaWNvbjogPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tYW1iZXItNjAwIHRvLWFtYmVyLTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLWFtYmVyLTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci1hbWJlci0yMDBcIixcclxuICAgICAgaHJlZjogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51XCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBFbXBsb3llZXNcIixcclxuICAgIH0sXHJcbiAgICAgXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIHctZnVsbCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBIUiBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgIE1hbmFnZSBhbmQgb3JnYW5pemUgeW91ciB0ZWFtIG1lbWJlcnNcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAge3N0YWZmQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8TGluayBrZXk9e2NhdGVnb3J5LmlkfSB0bz17Y2F0ZWdvcnkuaHJlZn0gY2xhc3NOYW1lPVwiZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGgtZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBib3JkZXIgJHtjYXRlZ29yeS5ib3JkZXJDb2xvcn0gc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTMyIGgtMzIgYmctZ3JhZGllbnQtdG8tYnIgJHtjYXRlZ29yeS5jb2xvcn0gb3BhY2l0eS01IGdyb3VwLWhvdmVyOm9wYWNpdHktMTAgcm91bmRlZC1mdWxsIC1tci0xNiAtbXQtMTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJsdXIteGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC03XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTE0IGgtMTQgJHtjYXRlZ29yeS5saWdodENvbG9yfSByb3VuZGVkLWxnIG1iLTUgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+e2NhdGVnb3J5Lmljb259PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItMiBncm91cC1ob3Zlcjp0ZXh0LWdyYXktOTUwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBncm91cC1ob3Zlcjpib3JkZXItZ3JheS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGdyb3VwLWhvdmVyOnRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuc3RhdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgYmctZ3JhZGllbnQtdG8tYnIgJHtjYXRlZ29yeS5jb2xvcn0gb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zZm9ybSB0cmFuc2xhdGUteC0xIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHJpZ2h0LTAgaC0wLjUgYmctZ3JhZGllbnQtdG8tciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTYgcC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ibHVlLTEwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWJsdWUtNjAwIG10LTFcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIG1iLTJcIj5RdWljayBUaXBzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwXCI+VXNlIHRoZSBzdGFmZiBkaXJlY3RvcnkgdG8gbWFuYWdlIHBlcnNvbm5lbCwgdXBkYXRlIGVtcGxveWVlIGluZm9ybWF0aW9uIGFuZCBQcm92aWRlIERlc2lnbmF0aW9uIGFsbCBpbiBvbmUgcGxhY2UuPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN0YWZmTWVudTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1N0YWZmTWVudS5qc3gifQ==