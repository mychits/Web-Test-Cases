import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeReferredCustomers.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import api from "/src/instance/TokenInstance.js";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const EmployeeReferredCustomers = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState({
    totalCustomers: 0,
    totalEnrollments: 0,
    totalOutstanding: 0,
    totalInvestment: 0
  });
  const [formData, setFormData] = useState({
    employee: "",
    customer: "",
    filterType: "Today"
  });
  const hasFetched = useRef(false);
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value || ""
    }));
  };
  const fetchEmployees = async () => {
    try {
      const response = await api.get("/employee/");
      const verifiedEmployees = (response.data?.employee || []).filter((emp) => emp.isVerified);
      setEmployees(verifiedEmployees);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const fetchCustomers = async (employeeId) => {
    try {
      if (!employeeId) {
        setCustomers([]);
        return;
      }
      const response = await api.get("/user/get-user");
      setCustomers(response.data || []);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    fetchCustomers(formData.employee);
  }, [formData.employee]);
  const fetchEmployeeCustomers = useCallback(
    async () => {
      try {
        setLoading(true);
        let data = [];
        if (formData.employee) {
          const response = await api.get(
            `/v1/admin/employees/${formData.employee}/referred-customers`
          );
          data = response.data?.data || [];
        } else {
          const responses = await Promise.all(
            employees.map(
              (emp) => api.get(
                `/v1/admin/employees/${emp._id}/referred-customers`
              )
            )
          );
          data = responses.flatMap(
            (res) => res.data?.data || []
          );
        }
        if (formData.customer) {
          data = data.filter(
            (item) => item.user_id?._id === formData.customer
          );
        }
        setSummary({
          totalCustomers: new Set(
            data.map((item) => item.user_id?._id)
          ).size,
          totalEnrollments: data.length,
          totalOutstanding: data.reduce(
            (sum, item) => sum + (item.total_balance || 0),
            0
          ),
          totalInvestment: data.reduce(
            (sum, item) => sum + (item.total_investment || 0),
            0
          )
        });
        const formatted = data.map((item, index) => ({
          id: item._id,
          slNo: index + 1,
          customerName: item.user_id?.full_name || "-",
          phone: item.user_id?.phone_number || "-",
          group: item.group_id?.group_name || "-",
          tickets: item.tickets || 0,
          installment: item.group_install || 0,
          investment: item.total_investment || 0,
          outstanding: item.total_balance || 0,
          isPrized: item.is_prized === true ? "Prized" : "Not Prized",
          totalProfit: item.total_profit || 0,
          totalPenalty: item.total_penalty || 0,
          totalLateFee: item.total_late_fee || 0,
          status: item.customer_status || "-",
          joinedDate: item.createdAt ? new Date(item.createdAt).toLocaleDateString("en-GB").replace(/\//g, "-") : "-"
        }));
        setReportData(formatted);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    },
    [
      employees,
      formData.employee,
      formData.customer
    ]
  );
  useEffect(() => {
    if (!employees.length) return;
    if (!hasFetched.current) {
      hasFetched.current = true;
      fetchEmployeeCustomers();
    }
  }, [employees, fetchEmployeeCustomers]);
  useEffect(
    () => {
      if (!employees.length) return;
      if (hasFetched.current) {
        fetchEmployeeCustomers();
      }
    },
    [
      formData.employee,
      formData.customer
    ]
  );
  const columns = [
    {
      key: "slNo",
      header: "Sl No"
    },
    {
      key: "status",
      header: "Customer Status"
    },
    {
      key: "isPrized",
      header: "Auction Status"
    },
    {
      key: "joinedDate",
      header: "Joined Date"
    },
    {
      key: "customerName",
      header: "Customer Name"
    },
    {
      key: "phone",
      header: "Phone"
    },
    {
      key: "group",
      header: "Group"
    },
    {
      key: "tickets",
      header: "Ticket"
    },
    {
      key: "installment",
      header: "Group Installment"
    },
    {
      key: "totalProfit",
      header: "Total Profit"
    },
    {
      key: "investment",
      header: "Total Investment"
    },
    {
      key: "totalPenalty",
      header: "Total Penalty"
    },
    {
      key: "totalLateFee",
      header: "Total Late Fee"
    },
    {
      key: "outstanding",
      header: "Balance"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10 w-full overflow-x-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow min-w-[900px] p-7", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Employee Referred Customer Report" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
      lineNumber: 705,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Employee" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 711,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-12",
            placeholder: "Select Employee",
            value: formData.employee || void 0,
            onChange: (value) => {
              setFormData((prev) => ({
                ...prev,
                employee: value,
                customer: ""
              }));
            },
            allowClear: true,
            showSearch: true,
            optionFilterProp: "children",
            filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Employees" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
                lineNumber: 733,
                columnNumber: 29
              }, this),
              employees.map(
                (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: emp.name }, emp._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
                  lineNumber: 735,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
            lineNumber: 713,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 710,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "w-1/3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm", children: "Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 743,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-12",
            placeholder: "All Customers",
            value: formData.customer || void 0,
            onChange: (value) => handleAntDSelect("customer", value),
            allowClear: true,
            showSearch: true,
            optionFilterProp: "children",
            filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
                lineNumber: 759,
                columnNumber: 29
              }, this),
              customers.map(
                (customer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: customer._id, children: customer.full_name }, customer._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
                  lineNumber: 761,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
            lineNumber: 745,
            columnNumber: 25
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 742,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
      lineNumber: 709,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Customers" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 811,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: summary.totalCustomers }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 812,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 810,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Enrollments" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 816,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: summary.totalEnrollments }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 817,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 815,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Balance" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 821,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: [
          "₹",
          summary.totalOutstanding
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 822,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 820,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "Total Investment" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 826,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: [
          "₹",
          summary.totalInvestment
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
          lineNumber: 827,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 825,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
      lineNumber: 809,
      columnNumber: 17
    }, this),
    reportData.length > 0 && !loading ? /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        columns,
        data: reportData,
        exportedFileName: "Employee Referred Customer Report",
        exportedPdfName: "Employee Referred Customer Report"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 832,
        columnNumber: 9
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      CircularLoader,
      {
        isLoading: loading,
        failure: !loading && reportData.length === 0,
        data: "Employee Referred Customers"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
        lineNumber: 839,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
    lineNumber: 704,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx",
    lineNumber: 703,
    columnNumber: 5
  }, this);
};
_s(EmployeeReferredCustomers, "Eer3RjgPFCrpKg+M1s02vm1FY7g=");
_c = EmployeeReferredCustomers;
export default EmployeeReferredCustomers;
var _c;
$RefreshReg$(_c, "EmployeeReferredCustomers");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeReferredCustomers.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ3NCZ0I7MkJBaHNCaEI7QUFBZ0JBLE1BQVdDLGNBQVVDLE9BQVFDLHNCQUFtQixlQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZFLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLGNBQWM7QUE2YXZCLE1BQU1DLDRCQUE0QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJWixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDYSxXQUFXQyxZQUFZLElBQUlkLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNlLFlBQVlDLGFBQWEsSUFBSWhCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNpQixTQUFTQyxVQUFVLElBQUlsQixTQUFTLEtBQUs7QUFFNUMsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBUztBQUFBLElBQ25DcUIsZ0JBQWdCO0FBQUEsSUFDaEJDLGtCQUFrQjtBQUFBLElBQ2xCQyxrQkFBa0I7QUFBQSxJQUNsQkMsaUJBQWlCO0FBQUEsRUFDckIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJMUIsU0FBUztBQUFBLElBQ3JDMkIsVUFBVTtBQUFBLElBQ1ZDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsRUFDaEIsQ0FBQztBQUVELFFBQU1DLGFBQWE3QixPQUFPLEtBQUs7QUFFL0IsUUFBTThCLG1CQUFtQkEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN2Q1AsZ0JBQVksQ0FBQ1EsVUFBVTtBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHQyxTQUFTO0FBQUEsSUFDdEIsRUFBRTtBQUFBLEVBQ047QUFLQSxRQUFNRSxpQkFBaUIsWUFBWTtBQUMvQixRQUFJO0FBQ0EsWUFBTUMsV0FBVyxNQUFNN0IsSUFBSThCLElBQUksWUFBWTtBQUUzQyxZQUFNQyxxQkFDRkYsU0FBU0csTUFBTVosWUFBWSxJQUM3QmEsT0FBTyxDQUFDQyxRQUFRQSxJQUFJQyxVQUFVO0FBRWhDOUIsbUJBQWEwQixpQkFBaUI7QUFBQSxJQUNsQyxTQUFTSyxPQUFPO0FBQ1pDLGNBQVFDLElBQUlGLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0o7QUFFQTVDLFlBQVUsTUFBTTtBQUNab0MsbUJBQWU7QUFBQSxFQUNuQixHQUFHLEVBQUU7QUFLTCxRQUFNVyxpQkFBaUIsT0FBT0MsZUFBZTtBQUN6QyxRQUFJO0FBQ0EsVUFBSSxDQUFDQSxZQUFZO0FBQ2JqQyxxQkFBYSxFQUFFO0FBQ2Y7QUFBQSxNQUNKO0FBRUEsWUFBTXNCLFdBQVcsTUFBTTdCLElBQUk4QixJQUFJLGdCQUFnQjtBQUUvQ3ZCLG1CQUFhc0IsU0FBU0csUUFBUSxFQUFFO0FBQUEsSUFDcEMsU0FBU0ksT0FBTztBQUNaQyxjQUFRQyxJQUFJRixLQUFLO0FBQUEsSUFDckI7QUFBQSxFQUNKO0FBRUE1QyxZQUFVLE1BQU07QUFDWitDLG1CQUFlckIsU0FBU0UsUUFBUTtBQUFBLEVBQ3BDLEdBQUcsQ0FBQ0YsU0FBU0UsUUFBUSxDQUFDO0FBS3RCLFFBQU1xQix5QkFBeUI5QztBQUFBQSxJQUFZLFlBQVk7QUFDbkQsVUFBSTtBQUNBZ0IsbUJBQVcsSUFBSTtBQUVmLFlBQUlxQixPQUFPO0FBRVgsWUFBSWQsU0FBU0UsVUFBVTtBQUNuQixnQkFBTVMsV0FBVyxNQUFNN0IsSUFBSThCO0FBQUFBLFlBQ3ZCLHVCQUF1QlosU0FBU0UsUUFBUTtBQUFBLFVBQzVDO0FBRUFZLGlCQUFPSCxTQUFTRyxNQUFNQSxRQUFRO0FBQUEsUUFDbEMsT0FBTztBQUNILGdCQUFNVSxZQUFZLE1BQU1DLFFBQVFDO0FBQUFBLFlBQzVCeEMsVUFBVXlDO0FBQUFBLGNBQUksQ0FBQ1gsUUFDWGxDLElBQUk4QjtBQUFBQSxnQkFDQSx1QkFBdUJJLElBQUlZLEdBQUc7QUFBQSxjQUNsQztBQUFBLFlBQ0o7QUFBQSxVQUNKO0FBRUFkLGlCQUFPVSxVQUFVSztBQUFBQSxZQUNiLENBQUNDLFFBQVFBLElBQUloQixNQUFNQSxRQUFRO0FBQUEsVUFDL0I7QUFBQSxRQUNKO0FBR0EsWUFBSWQsU0FBU0csVUFBVTtBQUNuQlcsaUJBQU9BLEtBQUtDO0FBQUFBLFlBQ1IsQ0FBQ2dCLFNBQ0dBLEtBQUtDLFNBQVNKLFFBQVE1QixTQUFTRztBQUFBQSxVQUN2QztBQUFBLFFBQ0o7QUFFQVIsbUJBQVc7QUFBQSxVQUNQQyxnQkFBZ0IsSUFBSXFDO0FBQUFBLFlBQ2hCbkIsS0FBS2EsSUFBSSxDQUFDSSxTQUFTQSxLQUFLQyxTQUFTSixHQUFHO0FBQUEsVUFDeEMsRUFBRU07QUFBQUEsVUFFRnJDLGtCQUFrQmlCLEtBQUtxQjtBQUFBQSxVQUV2QnJDLGtCQUFrQmdCLEtBQUtzQjtBQUFBQSxZQUNuQixDQUFDQyxLQUFLTixTQUNGTSxPQUFPTixLQUFLTyxpQkFBaUI7QUFBQSxZQUNqQztBQUFBLFVBQ0o7QUFBQSxVQUVBdkMsaUJBQWlCZSxLQUFLc0I7QUFBQUEsWUFDbEIsQ0FBQ0MsS0FBS04sU0FDRk0sT0FBT04sS0FBS1Esb0JBQW9CO0FBQUEsWUFDcEM7QUFBQSxVQUNKO0FBQUEsUUFDSixDQUFDO0FBRUQsY0FBTUMsWUFBWTFCLEtBQUthLElBQUksQ0FBQ0ksTUFBTVUsV0FBVztBQUFBLFVBQ3pDQyxJQUFJWCxLQUFLSDtBQUFBQSxVQUNUZSxNQUFNRixRQUFRO0FBQUEsVUFDZEcsY0FDSWIsS0FBS0MsU0FBU2EsYUFBYTtBQUFBLFVBQy9CQyxPQUNJZixLQUFLQyxTQUFTZSxnQkFBZ0I7QUFBQSxVQUNsQ0MsT0FDSWpCLEtBQUtrQixVQUFVQyxjQUFjO0FBQUEsVUFDakNDLFNBQVNwQixLQUFLb0IsV0FBVztBQUFBLFVBQ3pCQyxhQUNJckIsS0FBS3NCLGlCQUFpQjtBQUFBLFVBQzFCQyxZQUNJdkIsS0FBS1Esb0JBQW9CO0FBQUEsVUFDN0JnQixhQUNJeEIsS0FBS08saUJBQWlCO0FBQUEsVUFFMUJrQixVQUNJekIsS0FBSzBCLGNBQWMsT0FDYixXQUNBO0FBQUEsVUFFVkMsYUFDSTNCLEtBQUs0QixnQkFBZ0I7QUFBQSxVQUV6QkMsY0FDSTdCLEtBQUs4QixpQkFBaUI7QUFBQSxVQUUxQkMsY0FDSS9CLEtBQUtnQyxrQkFBa0I7QUFBQSxVQUUzQkMsUUFDSWpDLEtBQUtrQyxtQkFBbUI7QUFBQSxVQUU1QkMsWUFBWW5DLEtBQUtvQyxZQUNYLElBQUlDLEtBQUtyQyxLQUFLb0MsU0FBUyxFQUNwQkUsbUJBQW1CLE9BQU8sRUFDMUJDLFFBQVEsT0FBTyxHQUFHLElBQ3JCO0FBQUEsUUFDVixFQUFFO0FBRUYvRSxzQkFBY2lELFNBQVM7QUFBQSxNQUMzQixTQUFTdEIsT0FBTztBQUNaQyxnQkFBUUMsSUFBSUYsS0FBSztBQUFBLE1BQ3JCLFVBQUM7QUFDR3pCLG1CQUFXLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0o7QUFBQSxJQUFHO0FBQUEsTUFDQ1A7QUFBQUEsTUFDQWMsU0FBU0U7QUFBQUEsTUFDVEYsU0FBU0c7QUFBQUEsSUFBUTtBQUFBLEVBQ3BCO0FBS0Q3QixZQUFVLE1BQU07QUFDWixRQUFJLENBQUNZLFVBQVVpRCxPQUFRO0FBR3ZCLFFBQUksQ0FBQzlCLFdBQVdrRSxTQUFTO0FBQ3JCbEUsaUJBQVdrRSxVQUFVO0FBQ3JCaEQsNkJBQXVCO0FBQUEsSUFDM0I7QUFBQSxFQUNKLEdBQUcsQ0FBQ3JDLFdBQVdxQyxzQkFBc0IsQ0FBQztBQUd0Q2pEO0FBQUFBLElBQVUsTUFBTTtBQUNaLFVBQUksQ0FBQ1ksVUFBVWlELE9BQVE7QUFFdkIsVUFBSTlCLFdBQVdrRSxTQUFTO0FBQ3BCaEQsK0JBQXVCO0FBQUEsTUFDM0I7QUFBQSxJQUNKO0FBQUEsSUFBRztBQUFBLE1BQ0N2QixTQUFTRTtBQUFBQSxNQUNURixTQUFTRztBQUFBQSxJQUFRO0FBQUEsRUFDcEI7QUFFRCxRQUFNcUUsVUFBVTtBQUFBLElBQ1o7QUFBQSxNQUNJQyxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUVBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLE1BQ0lELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxNQUNJRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsTUFDSUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNaO0FBQUEsRUFBQztBQUdMLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLHFDQUNYLGlDQUFDLFNBQUksV0FBVSwrQkFDWDtBQUFBLDJCQUFDLFFBQUcsV0FBVSwrQkFBOEIsaURBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFNBQ1g7QUFBQSwrQkFBQyxXQUFNLFdBQVUsc0JBQXFCLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFFOUM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQSxZQUNaLE9BQU8xRSxTQUFTRSxZQUFZeUU7QUFBQUEsWUFDNUIsVUFBVSxDQUFDbkUsVUFBVTtBQUNqQlAsMEJBQVksQ0FBQ1EsVUFBVTtBQUFBLGdCQUNuQixHQUFHQTtBQUFBQSxnQkFDSFAsVUFBVU07QUFBQUEsZ0JBQ1ZMLFVBQVU7QUFBQSxjQUNkLEVBQUU7QUFBQSxZQUNOO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLGtCQUFpQjtBQUFBLFlBQ2pCLGNBQWMsQ0FBQ3lFLE9BQU9DLFlBQ2pCQSxRQUFRQyxZQUFZLElBQ2hCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLFlBR3JDO0FBQUEscUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLDZCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQztBQUFBLGNBQ3BDN0YsVUFBVXlDO0FBQUFBLGdCQUFJLENBQUNYLFFBQ1osdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUlZLEtBQ25DWixjQUFJaUUsUUFEV2pFLElBQUlZLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQTtBQUFBLFVBekJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTBCQTtBQUFBLFdBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNYO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHNCQUFxQix3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFFBRTlDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxXQUFVO0FBQUEsWUFDVixhQUFZO0FBQUEsWUFDWixPQUFPNUIsU0FBU0csWUFBWXdFO0FBQUFBLFlBQzVCLFVBQVUsQ0FBQ25FLFVBQVVGLGlCQUFpQixZQUFZRSxLQUFLO0FBQUEsWUFDdkQ7QUFBQSxZQUNBO0FBQUEsWUFDQSxrQkFBaUI7QUFBQSxZQUNqQixjQUFjLENBQUNvRSxPQUFPQyxZQUNqQkEsUUFBUUMsWUFBWSxJQUNoQkMsWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxZQUdyQztBQUFBLHFDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNwQzNGLFVBQVV1QztBQUFBQSxnQkFBSSxDQUFDeEIsYUFDWix1QkFBQyxPQUFPLFFBQVAsRUFBaUMsT0FBT0EsU0FBU3lCLEtBQzdDekIsbUJBQVMwQyxhQURNMUMsU0FBU3lCLEtBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQTtBQUFBLFVBbkJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9CQTtBQUFBLFdBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxTQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsSUEwQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsK0JBQUMsT0FBRSwrQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtCO0FBQUEsUUFDbEIsdUJBQUMsUUFBSWxDLGtCQUFRRSxrQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsV0FGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ1g7QUFBQSwrQkFBQyxPQUFFLGlDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUNwQix1QkFBQyxRQUFJRixrQkFBUUcsb0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsK0JBQUMsT0FBRSw2QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCO0FBQUEsUUFDaEIsdUJBQUMsUUFBRztBQUFBO0FBQUEsVUFBRUgsUUFBUUk7QUFBQUEsYUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsV0FGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSwrQkFBQyxPQUFFLGdDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxRQUNuQix1QkFBQyxRQUFHO0FBQUE7QUFBQSxVQUFFSixRQUFRSztBQUFBQSxhQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxXQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFFQ1QsV0FBVzZDLFNBQVMsS0FBSyxDQUFDM0MsVUFDdkI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHO0FBQUEsUUFDQSxNQUFNRjtBQUFBQSxRQUNOLGtCQUFpQjtBQUFBLFFBQ2pCLGlCQUFnQjtBQUFBO0FBQUEsTUFKcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXVELElBR3ZEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxXQUFXRTtBQUFBQSxRQUNYLFNBQVMsQ0FBQ0EsV0FBV0YsV0FBVzZDLFdBQVc7QUFBQSxRQUMzQyxNQUFLO0FBQUE7QUFBQSxNQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdzQztBQUFBLE9BMUk5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNklBLEtBOUlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErSUE7QUFHUjtBQUFFbEQsR0E3WklELDJCQUF5QjtBQUFBa0csS0FBekJsRztBQWdhTixlQUFlQTtBQUEwQixJQUFBa0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlUmVmIiwidXNlQ2FsbGJhY2siLCJOYXZiYXIiLCJTaWRlYmFyIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJhcGkiLCJTZWxlY3QiLCJFbXBsb3llZVJlZmVycmVkQ3VzdG9tZXJzIiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJjdXN0b21lcnMiLCJzZXRDdXN0b21lcnMiLCJyZXBvcnREYXRhIiwic2V0UmVwb3J0RGF0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic3VtbWFyeSIsInNldFN1bW1hcnkiLCJ0b3RhbEN1c3RvbWVycyIsInRvdGFsRW5yb2xsbWVudHMiLCJ0b3RhbE91dHN0YW5kaW5nIiwidG90YWxJbnZlc3RtZW50IiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImVtcGxveWVlIiwiY3VzdG9tZXIiLCJmaWx0ZXJUeXBlIiwiaGFzRmV0Y2hlZCIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInZhbHVlIiwicHJldiIsImZldGNoRW1wbG95ZWVzIiwicmVzcG9uc2UiLCJnZXQiLCJ2ZXJpZmllZEVtcGxveWVlcyIsImRhdGEiLCJmaWx0ZXIiLCJlbXAiLCJpc1ZlcmlmaWVkIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwiZmV0Y2hDdXN0b21lcnMiLCJlbXBsb3llZUlkIiwiZmV0Y2hFbXBsb3llZUN1c3RvbWVycyIsInJlc3BvbnNlcyIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJfaWQiLCJmbGF0TWFwIiwicmVzIiwiaXRlbSIsInVzZXJfaWQiLCJTZXQiLCJzaXplIiwibGVuZ3RoIiwicmVkdWNlIiwic3VtIiwidG90YWxfYmFsYW5jZSIsInRvdGFsX2ludmVzdG1lbnQiLCJmb3JtYXR0ZWQiLCJpbmRleCIsImlkIiwic2xObyIsImN1c3RvbWVyTmFtZSIsImZ1bGxfbmFtZSIsInBob25lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXAiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXRzIiwiaW5zdGFsbG1lbnQiLCJncm91cF9pbnN0YWxsIiwiaW52ZXN0bWVudCIsIm91dHN0YW5kaW5nIiwiaXNQcml6ZWQiLCJpc19wcml6ZWQiLCJ0b3RhbFByb2ZpdCIsInRvdGFsX3Byb2ZpdCIsInRvdGFsUGVuYWx0eSIsInRvdGFsX3BlbmFsdHkiLCJ0b3RhbExhdGVGZWUiLCJ0b3RhbF9sYXRlX2ZlZSIsInN0YXR1cyIsImN1c3RvbWVyX3N0YXR1cyIsImpvaW5lZERhdGUiLCJjcmVhdGVkQXQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwicmVwbGFjZSIsImN1cnJlbnQiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRW1wbG95ZWVSZWZlcnJlZEN1c3RvbWVycy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZVJlZiwgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG4vLyBjb25zdCBFbXBsb3llZVJlZmVycmVkQ3VzdG9tZXJzID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbcmVwb3J0RGF0YSwgc2V0UmVwb3J0RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB0b3RhbEN1c3RvbWVyczogMCxcclxuLy8gICAgIHRvdGFsRW5yb2xsbWVudHM6IDAsXHJcbi8vICAgICB0b3RhbE91dHN0YW5kaW5nOiAwLFxyXG4vLyAgICAgdG90YWxJbnZlc3RtZW50OiAwLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIGVtcGxveWVlOiBcIlwiLFxyXG4vLyAgICAgY3VzdG9tZXI6IFwiXCIsXHJcbi8vICAgICBmaWx0ZXJUeXBlOiBcIlRvZGF5XCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEZyb21EYXRlLCBzZXRTZWxlY3RlZEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZFRvRGF0ZSwgc2V0U2VsZWN0ZWRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuLy8gICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICBbZmllbGRdOiB2YWx1ZSxcclxuLy8gICAgIH0pKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKGZhbHNlKTtcclxuXHJcbi8vICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbi8vICAgICBsZXQgZnJvbSA9IFwiXCI7XHJcbi8vICAgICBsZXQgdG8gPSBcIlwiO1xyXG5cclxuLy8gICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbi8vICAgICAgIGZyb20gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgICAgdG8gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgeSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgeS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIDEpO1xyXG4vLyAgICAgICBmcm9tID0gZm9ybWF0RGF0ZSh5KTtcclxuLy8gICAgICAgdG8gPSBmb3JtYXREYXRlKHkpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbi8vICAgICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuLy8gICAgICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuLy8gICAgICAgZnJvbSA9IGZvcm1hdERhdGUoc3RhcnQpO1xyXG4vLyAgICAgICB0byA9IGZvcm1hdERhdGUoZW5kKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4vLyAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4vLyAgICAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbi8vICAgICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4vLyAgICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZyb20pO1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRUb0RhdGUodG8pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZpbHRlck9wdGlvbnMgPSBbXHJcbi8vICAgICB7XHJcbi8vICAgICAgIHZhbHVlOiBcIlRvZGF5XCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIlRvZGF5XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICB2YWx1ZTogXCJZZXN0ZXJkYXlcIixcclxuLy8gICAgICAgbGFiZWw6IFwiWWVzdGVyZGF5XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICB2YWx1ZTogXCJUaGlzTW9udGhcIixcclxuLy8gICAgICAgbGFiZWw6IFwiVGhpcyBNb250aFwiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAgdmFsdWU6IFwiTGFzdE1vbnRoXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIkxhc3QgTW9udGhcIixcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIHZhbHVlOiBcIlRoaXNZZWFyXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIlRoaXMgWWVhclwiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAgdmFsdWU6IFwiQ3VzdG9tXCIsXHJcbi8vICAgICAgIGxhYmVsOiBcIkN1c3RvbVwiLFxyXG4vLyAgICAgfSxcclxuLy8gICBdO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgaGFuZGxlU2VsZWN0RmlsdGVyKGZvcm1EYXRhLmZpbHRlclR5cGUpO1xyXG4vLyAgIH0sIFtmb3JtRGF0YS5maWx0ZXJUeXBlXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICAvLyBjaGFuZ2UgZW5kcG9pbnQgaWYgcmVxdWlyZWRcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlL1wiKTtcclxuLy8gICAgICAgY29uc3QgdmVyaWZpZWRFbXBsb3llZXMgPSAocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pLmZpbHRlcihcclxuLy8gICAgICAgICAoZW1wKSA9PiBlbXAuaXNWZXJpZmllZCA9PT0gdHJ1ZSxcclxuLy8gICAgICAgKTtcclxuXHJcbi8vICAgICAgIHNldEVtcGxveWVlcyh2ZXJpZmllZEVtcGxveWVlcyk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hDdXN0b21lcnMgPSBhc3luYyAoZW1wbG95ZWVJZCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgaWYgKCFlbXBsb3llZUlkKSB7XHJcbi8vICAgICAgICAgc2V0Q3VzdG9tZXJzKFtdKTtcclxuLy8gICAgICAgICByZXR1cm47XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3VzZXIvZ2V0LXVzZXJgKTtcclxuXHJcbi8vICAgICAgIHNldEN1c3RvbWVycyhyZXNwb25zZT8uZGF0YSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoQ3VzdG9tZXJzKGZvcm1EYXRhLmVtcGxveWVlKTtcclxuLy8gICB9LCBbZm9ybURhdGEuZW1wbG95ZWVdKTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hFbXBsb3llZUN1c3RvbWVycyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgICBsZXQgZGF0YSA9IFtdO1xyXG5cclxuLy8gICAgICAgaWYgKGZvcm1EYXRhLmVtcGxveWVlKSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4vLyAgICAgICAgICAgYC92MS9hZG1pbi9lbXBsb3llZXMvJHtmb3JtRGF0YS5lbXBsb3llZX0vcmVmZXJyZWQtY3VzdG9tZXJzYCxcclxuLy8gICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICBkYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXTtcclxuLy8gICAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgICBjb25zdCByZXNwb25zZXMgPSBhd2FpdCBQcm9taXNlLmFsbChcclxuLy8gICAgICAgICAgIGVtcGxveWVlcy5tYXAoKGVtcCkgPT5cclxuLy8gICAgICAgICAgICAgYXBpLmdldChgL3YxL2FkbWluL2VtcGxveWVlcy8ke2VtcC5faWR9L3JlZmVycmVkLWN1c3RvbWVyc2ApLFxyXG4vLyAgICAgICAgICAgKSxcclxuLy8gICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICAvLyBkYXRhID0gcmVzcG9uc2VzLmZsYXRNYXAoKHJlcykgPT4gcmVzLmRhdGE/LmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICAgIGRhdGEgPSByZXNwb25zZXNcclxuLy8gICAgICAgICAgIC5maWx0ZXIoKHJlcykgPT4gKHJlcy5kYXRhPy5kYXRhIHx8IFtdKS5sZW5ndGggPiAwKVxyXG4vLyAgICAgICAgICAgLmZsYXRNYXAoKHJlcykgPT4gcmVzLmRhdGEuZGF0YSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIC8vIEN1c3RvbWVyIGZpbHRlclxyXG4vLyAgICAgICBpZiAoZm9ybURhdGEuY3VzdG9tZXIpIHtcclxuLy8gICAgICAgICBkYXRhID0gZGF0YS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0udXNlcl9pZD8uX2lkID09PSBmb3JtRGF0YS5jdXN0b21lcik7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIC8vIFN1bW1hcnlcclxuLy8gICAgICAgc2V0U3VtbWFyeSh7XHJcbi8vICAgICAgICAgdG90YWxDdXN0b21lcnM6IG5ldyBTZXQoZGF0YS5tYXAoKGl0ZW0pID0+IGl0ZW0udXNlcl9pZD8uX2lkKSkuc2l6ZSxcclxuLy8gICAgICAgICB0b3RhbEVucm9sbG1lbnRzOiBkYXRhLmxlbmd0aCxcclxuLy8gICAgICAgICB0b3RhbE91dHN0YW5kaW5nOiBkYXRhLnJlZHVjZShcclxuLy8gICAgICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChpdGVtLnRvdGFsX2JhbGFuY2UgfHwgMCksXHJcbi8vICAgICAgICAgICAwLFxyXG4vLyAgICAgICAgICksXHJcbi8vICAgICAgICAgdG90YWxJbnZlc3RtZW50OiBkYXRhLnJlZHVjZShcclxuLy8gICAgICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChpdGVtLnRvdGFsX2ludmVzdG1lbnQgfHwgMCksXHJcbi8vICAgICAgICAgICAwLFxyXG4vLyAgICAgICAgICksXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgLy8gVGFibGUgZGF0YVxyXG4vLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBkYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbi8vICAgICAgICAgaWQ6IGl0ZW0uX2lkLFxyXG4vLyAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBjdXN0b21lck5hbWU6IGl0ZW0udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIHBob25lOiBpdGVtLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuLy8gICAgICAgICBncm91cDogaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIixcclxuLy8gICAgICAgICB0aWNrZXRzOiBpdGVtLnRpY2tldHMgfHwgMCxcclxuLy8gICAgICAgICBpbnN0YWxsbWVudDogaXRlbS5ncm91cF9pbnN0YWxsIHx8IDAsXHJcbi8vICAgICAgICAgaW52ZXN0bWVudDogaXRlbS50b3RhbF9pbnZlc3RtZW50IHx8IDAsXHJcbi8vICAgICAgICAgb3V0c3RhbmRpbmc6IGl0ZW0udG90YWxfYmFsYW5jZSB8fCAwLFxyXG4vLyAgICAgICAgIGlzUHJpemVkOiBpdGVtPy5pc19wcml6ZWQsXHJcbi8vICAgICAgICAgdG90YWxQcm9maXQ6IGl0ZW0/LnRvdGFsX3Byb2ZpdCB8fCAwLFxyXG4vLyAgICAgICAgIHRvdGFsUGVuYWx0eTogaXRlbT8udG90YWxfcGVuYWx0eSB8fCAwLFxyXG4vLyAgICAgICAgIHRvdGFsTGF0ZUZlZTogaXRlbT8udG90YWxfbGF0ZV9mZWUgfHwgMCxcclxuLy8gICAgICAgICBzdGF0dXM6IGl0ZW0uY3VzdG9tZXJfc3RhdHVzIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIGpvaW5lZERhdGU6IGl0ZW0uY3JlYXRlZEF0XHJcbi8vICAgICAgICAgICA/IG5ldyBEYXRlKGl0ZW0uY3JlYXRlZEF0KVxyXG4vLyAgICAgICAgICAgICAgIC50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKVxyXG4vLyAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXC8vZywgXCItXCIpXHJcbi8vICAgICAgICAgICA6IFwiLVwiLFxyXG4vLyAgICAgICB9KSk7XHJcblxyXG4vLyAgICAgICBzZXRSZXBvcnREYXRhKGZvcm1hdHRlZCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBpZiAoZW1wbG95ZWVzLmxlbmd0aCA+IDApIHtcclxuLy8gICAgICAgZmV0Y2hFbXBsb3llZUN1c3RvbWVycygpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtlbXBsb3llZXMsIGZvcm1EYXRhLmVtcGxveWVlLCBmb3JtRGF0YS5jdXN0b21lcl0pO1xyXG5cclxuLy8gICBjb25zdCBjb2x1bW5zID0gW1xyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwic2xOb1wiLFxyXG4vLyAgICAgICBoZWFkZXI6IFwiU2wgTm9cIixcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGtleTogXCJzdGF0dXNcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIkN1c3RvbWVyIFN0YXR1c1wiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiBcImlzUHJpemVkXCIsXHJcbi8vICAgICAgIGhlYWRlcjogXCJBdWN0aW9uIFN0YXR1c1wiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiBcImpvaW5lZERhdGVcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIkpvaW5lZCBEYXRlXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwiY3VzdG9tZXJOYW1lXCIsXHJcbi8vICAgICAgIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwicGhvbmVcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIlBob25lXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwiZ3JvdXBcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIkdyb3VwXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwidGlja2V0c1wiLFxyXG4vLyAgICAgICBoZWFkZXI6IFwiVGlja2V0XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwiaW5zdGFsbG1lbnRcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIkdyb3VwIEluc3RhbGxtZW50XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwidG90YWxQcm9maXRcIixcclxuLy8gICAgICAgaGVhZGVyOiBcIlRvdGFsIFByb2ZpdFwiLFxyXG4vLyAgICAgfSxcclxuXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGtleTogXCJpbnZlc3RtZW50XCIsXHJcbi8vICAgICAgIGhlYWRlcjogXCJUb3RhbCBJbnZlc3RtZW50XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwidG90YWxQZW5hbHR5XCIsXHJcbi8vICAgICAgIGhlYWRlcjogXCJUb3RhbCBQZW5hbHR5XCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBrZXk6IFwidG90YWxMYXRlRmVlXCIsXHJcbi8vICAgICAgIGhlYWRlcjogXCJUb3RhbCBMYXRlIEZlZVwiLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiBcIm91dHN0YW5kaW5nXCIsXHJcbi8vICAgICAgIGhlYWRlcjogXCJCYWxhbmNlXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMTBcIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgRW1wbG95ZWUgUmVmZXJyZWQgQ3VzdG9tZXIgUmVwb3J0XHJcbi8vICAgICAgICAgPC9oMj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG1iLTZcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzNcIj5cclxuLy8gICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgdGV4dC1zbVwiPkVtcGxveWVlPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbi8vICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRW1wbG95ZWVcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbXBsb3llZSB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbi8vICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICAgIGVtcGxveWVlOiB2YWx1ZSxcclxuLy8gICAgICAgICAgICAgICAgICAgY3VzdG9tZXI6IFwiXCIsXHJcbi8vICAgICAgICAgICAgICAgICB9KSk7XHJcbi8vICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbi8vICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuLy8gICAgICAgICAgICAgICAgIChvcHRpb24/LmNoaWxkcmVuID8/IFwiXCIpXHJcbi8vICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbi8vICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4vLyAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIEVtcGxveWVlczwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAge2VtcC5uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzNcIj5cclxuLy8gICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgdGV4dC1zbVwiPkN1c3RvbWVyPC9sYWJlbD5cclxuXHJcbi8vICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbi8vICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgQ3VzdG9tZXJzXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY3VzdG9tZXIgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJjdXN0b21lclwiLCB2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4vLyAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4vLyAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbi8vICAgICAgICAgICAgICAgICAob3B0aW9uPy5jaGlsZHJlbiA/PyBcIlwiKVxyXG4vLyAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBDdXN0b21lcnM8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAge2N1c3RvbWVycy5tYXAoKGN1c3RvbWVyKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2N1c3RvbWVyLl9pZH0gdmFsdWU9e2N1c3RvbWVyLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5mdWxsX25hbWV9XHJcbi8vICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgPGxhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbi8vICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHAtMlwiXHJcbi8vICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbi8vICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRnJvbURhdGVcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShcclxuLy8gICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZVxyXG4vLyAgICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxsYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgIFRvIERhdGVcclxuLy8gICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcC0yXCJcclxuLy8gICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuLy8gICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUb0RhdGVcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWVcclxuLy8gICAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgKX0gKi99XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHAtNCByb3VuZGVkXCI+XHJcbi8vICAgICAgICAgICAgIDxwPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuLy8gICAgICAgICAgICAgPGgyPntzdW1tYXJ5LnRvdGFsQ3VzdG9tZXJzfTwvaDI+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBwLTQgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgICA8cD5Ub3RhbCBFbnJvbGxtZW50czwvcD5cclxuLy8gICAgICAgICAgICAgPGgyPntzdW1tYXJ5LnRvdGFsRW5yb2xsbWVudHN9PC9oMj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTEwMCBwLTQgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgICA8cD5Ub3RhbCBPdXRzdGFuZGluZzwvcD5cclxuLy8gICAgICAgICAgICAgPGgyPuKCuXtzdW1tYXJ5LnRvdGFsT3V0c3RhbmRpbmd9PC9oMj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmcteWVsbG93LTEwMCBwLTQgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgICA8cD5Ub3RhbCBJbnZlc3RtZW50PC9wPlxyXG4vLyAgICAgICAgICAgICA8aDI+4oK5e3N1bW1hcnkudG90YWxJbnZlc3RtZW50fTwvaDI+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAge3JlcG9ydERhdGEubGVuZ3RoID4gMCAmJiAhbG9hZGluZyA/IChcclxuLy8gICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuLy8gICAgICAgICAgICAgZGF0YT17cmVwb3J0RGF0YX1cclxuLy8gICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkVtcGxveWVlIFJlZmVycmVkIEN1c3RvbWVyIFJlcG9ydFwiXHJcbi8vICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkVtcGxveWVlIFJlZmVycmVkIEN1c3RvbWVyIFJlcG9ydFwiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuLy8gICAgICAgICAgICAgaXNMb2FkaW5nPXtsb2FkaW5nfVxyXG4vLyAgICAgICAgICAgICBmYWlsdXJlPXshbG9hZGluZyAmJiByZXBvcnREYXRhLmxlbmd0aCA9PT0gMH1cclxuLy8gICAgICAgICAgICAgZGF0YT1cIkVtcGxveWVlIFJlZmVycmVkIEN1c3RvbWVyc1wiXHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IEVtcGxveWVlUmVmZXJyZWRDdXN0b21lcnMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtyZXBvcnREYXRhLCBzZXRSZXBvcnREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgdG90YWxDdXN0b21lcnM6IDAsXHJcbiAgICAgICAgdG90YWxFbnJvbGxtZW50czogMCxcclxuICAgICAgICB0b3RhbE91dHN0YW5kaW5nOiAwLFxyXG4gICAgICAgIHRvdGFsSW52ZXN0bWVudDogMCxcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIGVtcGxveWVlOiBcIlwiLFxyXG4gICAgICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgIGZpbHRlclR5cGU6IFwiVG9kYXlcIixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGhhc0ZldGNoZWQgPSB1c2VSZWYoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIFtmaWVsZF06IHZhbHVlIHx8IFwiXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgLy8gRkVUQ0ggRU1QTE9ZRUVTXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlL1wiKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHZlcmlmaWVkRW1wbG95ZWVzID0gKFxyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW11cclxuICAgICAgICAgICAgKS5maWx0ZXIoKGVtcCkgPT4gZW1wLmlzVmVyaWZpZWQpO1xyXG5cclxuICAgICAgICAgICAgc2V0RW1wbG95ZWVzKHZlcmlmaWVkRW1wbG95ZWVzKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIEZFVENIIENVU1RPTUVSU1xyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJzID0gYXN5bmMgKGVtcGxveWVlSWQpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoIWVtcGxveWVlSWQpIHtcclxuICAgICAgICAgICAgICAgIHNldEN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG5cclxuICAgICAgICAgICAgc2V0Q3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEgfHwgW10pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgZmV0Y2hDdXN0b21lcnMoZm9ybURhdGEuZW1wbG95ZWUpO1xyXG4gICAgfSwgW2Zvcm1EYXRhLmVtcGxveWVlXSk7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIEZFVENIIFJFUE9SVFxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIGNvbnN0IGZldGNoRW1wbG95ZWVDdXN0b21lcnMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgICAgIGxldCBkYXRhID0gW107XHJcblxyXG4gICAgICAgICAgICBpZiAoZm9ybURhdGEuZW1wbG95ZWUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgICAgICAgICAgICBgL3YxL2FkbWluL2VtcGxveWVlcy8ke2Zvcm1EYXRhLmVtcGxveWVlfS9yZWZlcnJlZC1jdXN0b21lcnNgXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgIGRhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2VzID0gYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICAgICAgICAgICAgZW1wbG95ZWVzLm1hcCgoZW1wKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcGkuZ2V0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYC92MS9hZG1pbi9lbXBsb3llZXMvJHtlbXAuX2lkfS9yZWZlcnJlZC1jdXN0b21lcnNgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgIGRhdGEgPSByZXNwb25zZXMuZmxhdE1hcChcclxuICAgICAgICAgICAgICAgICAgICAocmVzKSA9PiByZXMuZGF0YT8uZGF0YSB8fCBbXVxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gY3VzdG9tZXIgZmlsdGVyXHJcbiAgICAgICAgICAgIGlmIChmb3JtRGF0YS5jdXN0b21lcikge1xyXG4gICAgICAgICAgICAgICAgZGF0YSA9IGRhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgIChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnVzZXJfaWQ/Ll9pZCA9PT0gZm9ybURhdGEuY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHNldFN1bW1hcnkoe1xyXG4gICAgICAgICAgICAgICAgdG90YWxDdXN0b21lcnM6IG5ldyBTZXQoXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS5tYXAoKGl0ZW0pID0+IGl0ZW0udXNlcl9pZD8uX2lkKVxyXG4gICAgICAgICAgICAgICAgKS5zaXplLFxyXG5cclxuICAgICAgICAgICAgICAgIHRvdGFsRW5yb2xsbWVudHM6IGRhdGEubGVuZ3RoLFxyXG5cclxuICAgICAgICAgICAgICAgIHRvdGFsT3V0c3RhbmRpbmc6IGRhdGEucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgICAgIChzdW0sIGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSArIChpdGVtLnRvdGFsX2JhbGFuY2UgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgKSxcclxuXHJcbiAgICAgICAgICAgICAgICB0b3RhbEludmVzdG1lbnQ6IGRhdGEucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgICAgIChzdW0sIGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSArIChpdGVtLnRvdGFsX2ludmVzdG1lbnQgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBkYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgICBpZDogaXRlbS5faWQsXHJcbiAgICAgICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21lck5hbWU6XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICBwaG9uZTpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgIGdyb3VwOlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICB0aWNrZXRzOiBpdGVtLnRpY2tldHMgfHwgMCxcclxuICAgICAgICAgICAgICAgIGluc3RhbGxtZW50OlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uZ3JvdXBfaW5zdGFsbCB8fCAwLFxyXG4gICAgICAgICAgICAgICAgaW52ZXN0bWVudDpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRvdGFsX2ludmVzdG1lbnQgfHwgMCxcclxuICAgICAgICAgICAgICAgIG91dHN0YW5kaW5nOlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0udG90YWxfYmFsYW5jZSB8fCAwLFxyXG5cclxuICAgICAgICAgICAgICAgIGlzUHJpemVkOlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uaXNfcHJpemVkID09PSB0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJQcml6ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiTm90IFByaXplZFwiLFxyXG5cclxuICAgICAgICAgICAgICAgIHRvdGFsUHJvZml0OlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0udG90YWxfcHJvZml0IHx8IDAsXHJcblxyXG4gICAgICAgICAgICAgICAgdG90YWxQZW5hbHR5OlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0udG90YWxfcGVuYWx0eSB8fCAwLFxyXG5cclxuICAgICAgICAgICAgICAgIHRvdGFsTGF0ZUZlZTpcclxuICAgICAgICAgICAgICAgICAgICBpdGVtLnRvdGFsX2xhdGVfZmVlIHx8IDAsXHJcblxyXG4gICAgICAgICAgICAgICAgc3RhdHVzOlxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uY3VzdG9tZXJfc3RhdHVzIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgIGpvaW5lZERhdGU6IGl0ZW0uY3JlYXRlZEF0XHJcbiAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShpdGVtLmNyZWF0ZWRBdClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXC8vZywgXCItXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgc2V0UmVwb3J0RGF0YShmb3JtYXR0ZWQpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbXHJcbiAgICAgICAgZW1wbG95ZWVzLFxyXG4gICAgICAgIGZvcm1EYXRhLmVtcGxveWVlLFxyXG4gICAgICAgIGZvcm1EYXRhLmN1c3RvbWVyLFxyXG4gICAgXSk7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIENBTEwgUkVQT1JUIEFQSVxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFlbXBsb3llZXMubGVuZ3RoKSByZXR1cm47XHJcblxyXG4gICAgICAgIC8vIFByZXZlbnQgZHVwbGljYXRlIGNhbGwgaW4gUmVhY3QgU3RyaWN0TW9kZVxyXG4gICAgICAgIGlmICghaGFzRmV0Y2hlZC5jdXJyZW50KSB7XHJcbiAgICAgICAgICAgIGhhc0ZldGNoZWQuY3VycmVudCA9IHRydWU7XHJcbiAgICAgICAgICAgIGZldGNoRW1wbG95ZWVDdXN0b21lcnMoKTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbZW1wbG95ZWVzLCBmZXRjaEVtcGxveWVlQ3VzdG9tZXJzXSk7XHJcblxyXG4gICAgLy8gRW1wbG95ZWUgY2hhbmdlZFxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIWVtcGxveWVlcy5sZW5ndGgpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKGhhc0ZldGNoZWQuY3VycmVudCkge1xyXG4gICAgICAgICAgICBmZXRjaEVtcGxveWVlQ3VzdG9tZXJzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW1xyXG4gICAgICAgIGZvcm1EYXRhLmVtcGxveWVlLFxyXG4gICAgICAgIGZvcm1EYXRhLmN1c3RvbWVyLFxyXG4gICAgXSk7XHJcblxyXG4gICAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJzbE5vXCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJTbCBOb1wiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwic3RhdHVzXCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJDdXN0b21lciBTdGF0dXNcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcImlzUHJpemVkXCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJBdWN0aW9uIFN0YXR1c1wiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwiam9pbmVkRGF0ZVwiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiSm9pbmVkIERhdGVcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcImN1c3RvbWVyTmFtZVwiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwicGhvbmVcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIlBob25lXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJncm91cFwiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiR3JvdXBcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcInRpY2tldHNcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIlRpY2tldFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwiaW5zdGFsbG1lbnRcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIkdyb3VwIEluc3RhbGxtZW50XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJ0b3RhbFByb2ZpdFwiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiVG90YWwgUHJvZml0XCIsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwiaW52ZXN0bWVudFwiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiVG90YWwgSW52ZXN0bWVudFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwidG90YWxQZW5hbHR5XCIsXHJcbiAgICAgICAgICAgIGhlYWRlcjogXCJUb3RhbCBQZW5hbHR5XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJ0b3RhbExhdGVGZWVcIixcclxuICAgICAgICAgICAgaGVhZGVyOiBcIlRvdGFsIExhdGUgRmVlXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGtleTogXCJvdXRzdGFuZGluZ1wiLFxyXG4gICAgICAgICAgICBoZWFkZXI6IFwiQmFsYW5jZVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICBdO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTEwIHctZnVsbCBvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgbWluLXctWzkwMHB4XSBwLTdcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbXBsb3llZSBSZWZlcnJlZCBDdXN0b21lciBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5FbXBsb3llZTwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1wbG95ZWUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbXBsb3llZTogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5jaGlsZHJlbiA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgRW1wbG95ZWVzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc21cIj5DdXN0b21lcjwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmN1c3RvbWVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJjdXN0b21lclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5jaGlsZHJlbiA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgQ3VzdG9tZXJzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVycy5tYXAoKGN1c3RvbWVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjdXN0b21lci5faWR9IHZhbHVlPXtjdXN0b21lci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VzdG9tZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHAtMlwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRnJvbURhdGVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC52YWx1ZVxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5cclxuICAgICAgICAgICAgICAgIFRvIERhdGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHJvdW5kZWQgcC0yXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRUb0RhdGVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoXHJcbiAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX0gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyPntzdW1tYXJ5LnRvdGFsQ3VzdG9tZXJzfTwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIEVucm9sbG1lbnRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDI+e3N1bW1hcnkudG90YWxFbnJvbGxtZW50c308L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC0xMDAgcC00IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+VG90YWwgQmFsYW5jZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyPuKCuXtzdW1tYXJ5LnRvdGFsT3V0c3RhbmRpbmd9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctMTAwIHAtNCByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRvdGFsIEludmVzdG1lbnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMj7igrl7c3VtbWFyeS50b3RhbEludmVzdG1lbnR9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtyZXBvcnREYXRhLmxlbmd0aCA+IDAgJiYgIWxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtyZXBvcnREYXRhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiRW1wbG95ZWUgUmVmZXJyZWQgQ3VzdG9tZXIgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiRW1wbG95ZWUgUmVmZXJyZWQgQ3VzdG9tZXIgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXshbG9hZGluZyAmJiByZXBvcnREYXRhLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT1cIkVtcGxveWVlIFJlZmVycmVkIEN1c3RvbWVyc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW1wbG95ZWVSZWZlcnJlZEN1c3RvbWVyczsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW1wbG95ZWVSZWZlcnJlZEN1c3RvbWVycy5qc3gifQ==