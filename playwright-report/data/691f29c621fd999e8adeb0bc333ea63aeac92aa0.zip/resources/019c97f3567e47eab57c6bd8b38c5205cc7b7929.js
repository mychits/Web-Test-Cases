import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayOutCommission.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tooltip, notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
const CommissionPayout = () => {
  _s();
  const paymentFor = "commission";
  const [api, contextHolder] = notification.useNotification();
  const [showCommissionModal, setShowCommissionModal] = useState(false);
  const [modifyPayment, setModifyPayment] = useState(false);
  const [adminId, setAdminId] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [agentType, setAgentType] = useState("");
  const [calculatedAmount, setCalculatedAmount] = useState("0.00");
  const [alreadyPaid, setAlreadyPaid] = useState("0.00");
  const [remainingPayable, setRemainingPayable] = useState("0.00");
  const [selectedUserList, setSelectedUserList] = useState([]);
  const [commissionPayments, setCommissionPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingCommissionCalculation, setIsLoadingCommissionCalculation] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [errors, setErrors] = useState({});
  const [reRender, setReRender] = useState(0);
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    difference: 0,
    upToTarget: 0,
    beyondTarget: 0,
    targetCommission: 0,
    isTargetSet: false,
    targetDisplay: "Not Set",
    calculationType: "commission"
    // "commission" for agents, "incentive" for employees
  });
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  const [commissionForm, setCommissionForm] = useState({
    agent_id: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    selectedMonth: currentMonth,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: paymentFor,
    admin_type: ""
  });
  const [commissionBreakdown, setCommissionBreakdown] = useState([]);
  const [isTargetLoading, setIsTargetLoading] = useState(false);
  const fetchAgents = async () => {
    try {
      const res = await API.get("/agent/get-agent");
      const all = res.data || [];
      setAgents(
        all.filter((a) => a.agent_type === "agent" || a.agent_type === "both")
      );
      setEmployees(
        all.filter(
          (a) => a.agent_type === "employee" || a.agent_type === "both"
        )
      );
    } catch (err) {
      console.error("Agent fetch error", err);
    }
  };
  const formatDate = (date) => {
    if (!date) return "";
    if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return date;
    }
    const d = new Date(date);
    if (isNaN(d)) return "";
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const fetchTargetDetails = async (agentId, month, type) => {
    if (!agentId || !month) {
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        upToTarget: 0,
        beyondTarget: 0,
        targetCommission: 0,
        isTargetSet: false,
        targetDisplay: "Not Set",
        calculationType: type === "employee" ? "incentive" : "commission"
      });
      return;
    }
    setIsTargetLoading(true);
    try {
      const [year, monthStr] = month.split("-");
      const firstDay = `${year}-${monthStr}-01`;
      const lastDay = new Date(year, parseInt(monthStr), 0).toISOString().split("T")[0];
      const targetRes = await API.get(`/target/agent/${agentId}`, {
        params: { year }
      });
      const monthNames = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
      ];
      const monthNumber = parseInt(monthStr, 10);
      const monthName = monthNames[monthNumber - 1];
      let targetForMonth = 0;
      if (targetRes.data && targetRes.data.length > 0) {
        const monthData = targetRes.data[0].monthData || {};
        targetForMonth = Number(monthData[monthName] || 0);
      }
      const comm = await API.get("/enroll/get-detailed-commission-per-month", {
        params: {
          agent_id: agentId,
          from_date: formatDate(firstDay),
          to_date: formatDate(lastDay)
        }
      });
      let achieved = comm?.data?.summary?.actual_business || 0;
      if (typeof achieved === "string") {
        achieved = Number(achieved.replace(/[^0-9.-]+/g, ""));
      }
      const remaining = Math.max(targetForMonth - achieved, 0);
      const difference = targetForMonth - achieved;
      let upToTarget = 0;
      let beyondTarget = 0;
      let totalCommission = 0;
      if (type === "agent") {
        if (achieved <= targetForMonth) {
          upToTarget = achieved * 5e-3;
        } else {
          upToTarget = targetForMonth * 5e-3;
          beyondTarget = (achieved - targetForMonth) * 0.01;
        }
        totalCommission = upToTarget + beyondTarget;
      } else {
        if (achieved > targetForMonth) {
          beyondTarget = (achieved - targetForMonth) * 0.01;
        }
        totalCommission = beyondTarget;
      }
      const targetDisplay = targetForMonth > 0 ? `₹${targetForMonth.toLocaleString("en-IN")}` : "Not Set";
      setTargetData({
        target: targetForMonth,
        achieved,
        remaining,
        difference,
        upToTarget,
        beyondTarget,
        targetCommission: totalCommission,
        isTargetSet: targetForMonth >= 0,
        targetDisplay,
        calculationType: type === "employee" ? "incentive" : "commission"
      });
      if (type === "agent") {
        setCalculatedAmount(totalCommission.toFixed(2));
        setCommissionForm((prev) => ({
          ...prev,
          amount: totalCommission.toFixed(2)
        }));
      } else {
        setCalculatedAmount(totalCommission.toFixed(2));
        setCommissionForm((prev) => ({
          ...prev,
          amount: totalCommission.toFixed(2)
        }));
      }
      setCommissionBreakdown(comm?.data?.commission_data || []);
    } catch (error) {
      console.error("Failed to fetch target details", error);
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        upToTarget: 0,
        beyondTarget: 0,
        targetCommission: 0,
        isTargetSet: false,
        targetDisplay: "Not Set",
        calculationType: agentType === "employee" ? "incentive" : "commission"
      });
      setCommissionBreakdown([]);
    } finally {
      setIsTargetLoading(false);
    }
  };
  const fetchCommissionPayments = async () => {
    setIsLoading(true);
    try {
      const response = await API.get("/payment-out/get-commission-payments");
      const responseData = response.data.map((payment, index) => ({
        id: index + 1,
        _id: payment._id,
        agent_id: payment.agent_id,
        agent_name: payment.agent_id?.name,
        pay_date: payment.pay_date,
        amount: payment.amount,
        pay_type: payment.pay_type,
        commission_from: payment.commissionCalculationFromDate?.split("T")[0] || "-",
        commission_to: payment.commissionCalculationToDate?.split("T")[0] || "-",
        transaction_id: payment.transaction_id,
        note: payment.note,
        pay_for: payment.pay_for,
        disbursed_by: payment.admin_type?.name,
        receipt_no: payment.receipt_no
      }));
      setCommissionPayments(responseData);
    } catch (error) {
      console.error("Failed to fetch Commission payments", error);
      setCommissionPayments([]);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    setAdminId(userObj._id);
    setAdminName(userObj.full_name || userObj.name || "");
    if (userObj?.admin_access_right_id?.access_permissions?.edit_payment) {
      setModifyPayment(
        userObj.admin_access_right_id.access_permissions.edit_payment === "true"
      );
    }
    fetchAgents();
    fetchCommissionPayments();
  }, [reRender]);
  const getMonthRange = (selectedMonth) => {
    if (!selectedMonth) return { firstDay: "", lastDay: "" };
    const [year, month] = selectedMonth.split("-");
    const firstDay = `${year}-${month}-01`;
    const lastDay = new Date(year, month, 0).toISOString().split("T")[0];
    return { firstDay, lastDay };
  };
  const calculateTotalPayableCommission = async (agentId, month, type) => {
    if (!agentId || !month) {
      setCommissionForm((prev) => ({ ...prev, amount: "" }));
      return;
    }
    setIsLoadingCommissionCalculation(true);
    try {
      await fetchTargetDetails(agentId, month, type);
    } catch (error) {
      console.error("Failed to calculate agent commission:", error);
      setCommissionForm((prev) => ({ ...prev, amount: "" }));
    } finally {
      setIsLoadingCommissionCalculation(false);
    }
  };
  const handleCommissionChange = (e) => {
    const { name, value } = e.target;
    setCommissionForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
    if (name === "agent_id" || name === "selectedMonth") {
      const updatedAgentId = name === "agent_id" ? value : commissionForm.agent_id;
      const updatedMonth = name === "selectedMonth" ? value : commissionForm.selectedMonth;
      if (updatedAgentId && updatedMonth && agentType) {
        calculateTotalPayableCommission(
          updatedAgentId,
          updatedMonth,
          agentType
        );
      } else {
        setCalculatedAmount("0.00");
        setTargetData({
          target: 0,
          achieved: 0,
          remaining: 0,
          difference: 0,
          upToTarget: 0,
          beyondTarget: 0,
          targetCommission: 0,
          isTargetSet: false,
          targetDisplay: "Not Set",
          calculationType: agentType === "employee" ? "incentive" : "commission"
        });
        setCommissionBreakdown([]);
      }
    }
  };
  const validateForm = () => {
    const newErrors = {};
    if (!commissionForm.agent_id) {
      newErrors.agent_id = "Please select an agent";
    }
    if (!commissionForm.amount || isNaN(commissionForm.amount) || parseFloat(commissionForm.amount) <= 0) {
      newErrors.amount = "Please enter a valid amount";
    }
    if (!commissionForm.selectedMonth) {
      newErrors.selectedMonth = "Please select a month";
    }
    if (commissionForm.pay_type === "online" && !commissionForm.transaction_id) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleCommissionSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      try {
        setIsLoading(true);
        const { firstDay, lastDay } = getMonthRange(
          commissionForm.selectedMonth
        );
        const payload = {
          ...commissionForm,
          admin_type: adminId,
          commissionCalculationFromDate: firstDay,
          commissionCalculationToDate: lastDay
        };
        await API.post("/payment-out/add-commission-payment", payload);
        api.open({
          message: "Commission PayOut Added",
          description: "Commission Payment Has Been Successfully Added",
          className: "bg-green-400 rounded-lg font-bold",
          showProgress: true,
          pauseOnHover: false
        });
        setShowCommissionModal(false);
        setCommissionForm({
          agent_id: "",
          pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          selectedMonth: currentMonth,
          amount: "",
          pay_type: "cash",
          transaction_id: "",
          note: "",
          admin_type: adminId,
          pay_for: paymentFor
        });
        setReRender((val) => val + 1);
        fetchCommissionPayments();
      } catch (error) {
        const message = error.message || "Something went wrong";
        api.open({
          message: "Failed to Add Commission Payout",
          description: message,
          showProgress: true,
          pauseOnHover: false,
          className: "bg-red-400 rounded-lg font-bold"
        });
      } finally {
        setIsLoading(false);
      }
    }
  };
  const commissionColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Pay Date" },
    { key: "agent_name", header: "Agent" },
    { key: "amount", header: "Amount (₹)" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "commission_from", header: "From Date" },
    { key: "commission_to", header: "To Date" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "note", header: "Note" },
    { key: "disbursed_by", header: "Disbursed by" }
  ];
  const resetCommissionForm = () => {
    setAgentType("");
    setSelectedUserList([]);
    setCommissionForm({
      agent_id: "",
      pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      selectedMonth: currentMonth,
      amount: "",
      pay_type: "cash",
      transaction_id: "",
      note: "",
      admin_type: adminId,
      pay_for: paymentFor
    });
    setCommissionBreakdown([]);
    setTargetData({
      target: 0,
      achieved: 0,
      remaining: 0,
      difference: 0,
      upToTarget: 0,
      beyondTarget: 0,
      targetCommission: 0,
      isTargetSet: false,
      targetDisplay: "Not Set",
      calculationType: "commission"
    });
    setCalculatedAmount("0.00");
    setErrors({});
    setAlreadyPaid("0.00");
    setRemainingPayable("0.00");
    setIsTargetLoading(false);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
        lineNumber: 492,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
        lineNumber: 493,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          noReload: alertConfig.noReload
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
          lineNumber: 494,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4 md:mb-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-red-500 font-bold", children: "Commission / Incentive" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
              lineNumber: 503,
              columnNumber: 17
            }, this),
            " ",
            "Payments Out"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
            lineNumber: 502,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { title: "Add Commission Payment", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowCommissionModal(true);
                resetCommissionForm();
              },
              className: "bg-violet-900 text-white px-4 py-2 rounded shadow-md hover:bg-violet-600 transition duration-200 flex items-center",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "+" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 516,
                  columnNumber: 19
                }, this),
                " Commission / Incentive Payment"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
              lineNumber: 509,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
            lineNumber: 508,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
          lineNumber: 501,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 bg-white p-6 rounded-lg shadow-md", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-violet-800 border-b pb-2", children: "Commission / Incentive Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
            lineNumber: 521,
            columnNumber: 15
          }, this),
          isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Commission Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
            lineNumber: 526,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
            lineNumber: 525,
            columnNumber: 15
          }, this) : commissionPayments.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: commissionPayments,
              columns: commissionColumns,
              exportedPdfName: "PayOut Commission",
              exportedFileName: `Commission Payments.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
              lineNumber: 529,
              columnNumber: 15
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: "No commission payments found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
            lineNumber: 536,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
          lineNumber: 520,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
        lineNumber: 500,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showCommissionModal,
          onClose: () => {
            setShowCommissionModal(false);
            resetCommissionForm();
          },
          width: "max-w-md",
          children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900 border-b pb-2", children: "Add Commission / Incentive Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
              lineNumber: 552,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleCommissionSubmit, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Select Type ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 558,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 557,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    value: agentType,
                    onChange: (e) => {
                      const selected = e.target.value;
                      setAgentType(selected);
                      setSelectedUserList(
                        selected === "agent" ? agents : employees
                      );
                      setCommissionForm((prev) => ({
                        ...prev,
                        agent_id: "",
                        amount: ""
                      }));
                      setAlreadyPaid("0.00");
                      setRemainingPayable("0.00");
                      setTargetData({
                        target: 0,
                        achieved: 0,
                        remaining: 0,
                        difference: 0,
                        upToTarget: 0,
                        beyondTarget: 0,
                        targetCommission: 0,
                        isTargetSet: false,
                        targetDisplay: "Not Set",
                        calculationType: selected === "employee" ? "incentive" : "commission"
                      });
                      setCommissionBreakdown([]);
                      setCalculatedAmount("0.00");
                      setErrors({});
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", disabled: true, children: "-- Select Type --" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 594,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "agent", children: "Agent" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 597,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "employee", children: "Employee" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 598,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 560,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 556,
                columnNumber: 17
              }, this),
              agentType && /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Select ",
                  agentType === "agent" ? "Agent" : "Employee",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 606,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 604,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full h-12",
                    placeholder: `Select ${agentType}`,
                    showSearch: true,
                    optionFilterProp: "children",
                    filterOption: (input, option) => String(option?.children)?.toLowerCase().includes(input.toLowerCase()),
                    value: commissionForm.agent_id || void 0,
                    onChange: (value) => {
                      setErrors((prev) => ({ ...prev, agent_id: "" }));
                      setCommissionForm((prev) => ({
                        ...prev,
                        agent_id: value
                      }));
                      calculateTotalPayableCommission(
                        value,
                        commissionForm.selectedMonth,
                        agentType
                      );
                    },
                    children: (agentType === "agent" ? agents : employees).map(
                      (person) => /* @__PURE__ */ jsxDEV(Select.Option, { value: person._id, children: [
                        person.name,
                        " | ",
                        person.phone_number
                      ] }, person._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 634,
                        columnNumber: 23
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 608,
                    columnNumber: 21
                  },
                  this
                ),
                errors.agent_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.agent_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 641,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 603,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Month ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 651,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 650,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "month",
                    name: "selectedMonth",
                    value: commissionForm.selectedMonth,
                    max: currentMonth,
                    onChange: handleCommissionChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 653,
                    columnNumber: 19
                  },
                  this
                ),
                errors.selectedMonth && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.selectedMonth }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 662,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 649,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-2", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => calculateTotalPayableCommission(
                    commissionForm.agent_id,
                    commissionForm.selectedMonth,
                    agentType
                  ),
                  disabled: !commissionForm.agent_id || !commissionForm.selectedMonth || isLoadingCommissionCalculation,
                  className: "px-2 py-2 bg-green-700 text-white rounded-lg shadow-md hover:bg-green-800 transition duration-200",
                  children: isLoadingCommissionCalculation ? "Calculating..." : "Calculate Amount"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 669,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 668,
                columnNumber: 17
              }, this),
              isTargetLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex justify-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Target Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 694,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 693,
                columnNumber: 17
              }, this),
              agentType && targetData && !isTargetLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: targetData.isTargetSet ? /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-100 p-4 rounded-lg shadow mb-6", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-yellow-800 mb-2", children: "Target Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 703,
                  columnNumber: 25
                }, this),
                targetData.achieved >= targetData.target && /* @__PURE__ */ jsxDEV("div", { className: "text-green-800 font-semibold mb-3", children: "🎉 Target Achieved" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 708,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-3 gap-4 bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Target Set" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 715,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: targetData.targetDisplay,
                        readOnly: true,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 718,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 714,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Achieved" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 725,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: `₹${targetData.achieved?.toLocaleString(
                          "en-IN"
                        )}`,
                        readOnly: true,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 728,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 724,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Difference" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 737,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: `₹${targetData.difference?.toLocaleString(
                          "en-IN"
                        )}`,
                        readOnly: true,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 740,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 736,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: [
                      "Total Payable",
                      " ",
                      targetData.calculationType === "incentive" ? "Incentive" : "Commission"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 750,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        readOnly: true,
                        value: `₹${targetData.targetCommission.toLocaleString(
                          "en-IN",
                          {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }
                        )}`,
                        className: "border px-3 py-2 rounded w-full bg-gray-50 text-green-700 font-bold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 756,
                        columnNumber: 29
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 749,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 713,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 702,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-yellow-50 rounded-lg border border-yellow-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-yellow-800 font-medium", children: [
                "No target set for this ",
                agentType,
                ".",
                " ",
                targetData.calculationType === "incentive" ? "Incentive" : "Commission",
                " ",
                "will be calculated based on standard rules."
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 772,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 771,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 700,
                columnNumber: 17
              }, this),
              agentType && targetData.isTargetSet && !isTargetLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 bg-white p-4 rounded-lg shadow border", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-800 mb-3 text-lg", children: [
                  targetData.calculationType === "incentive" ? "Incentive" : "Commission",
                  " ",
                  "Breakdown"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 787,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm border", children: [
                  /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-violet-100 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Part" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 796,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "Amount (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 797,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 795,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 794,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { children: [
                    agentType === "agent" && /* @__PURE__ */ jsxDEV("tr", { children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: "0.5% up to Target" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 805,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: [
                        "₹",
                        targetData.upToTarget?.toLocaleString("en-IN", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        })
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 808,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 804,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("tr", { children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: agentType === "agent" ? "1% beyond Target" : "1% incentive on target difference" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 818,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: [
                        "₹",
                        targetData.beyondTarget?.toLocaleString("en-IN", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        })
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 823,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 817,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("tr", { className: "bg-green-100 font-semibold", children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: [
                        "Total Payable",
                        " ",
                        targetData.calculationType === "incentive" ? "Incentive" : "Commission"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 832,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right text-green-800", children: [
                        "₹",
                        targetData.targetCommission?.toLocaleString(
                          "en-IN",
                          {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 838,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 831,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 802,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 793,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 786,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 855,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "pay_date",
                    value: commissionForm.pay_date,
                    onChange: handleCommissionChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    disabled: !modifyPayment
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 858,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 867,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 854,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Total Payable (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 874,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: calculatedAmount,
                    readOnly: true,
                    className: "w-full p-3 border border-gray-300 rounded-lg bg-gray-100 font-semibold"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 877,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 873,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Enter Amount (₹) ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 887,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 886,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "amount",
                    min: 1,
                    value: commissionForm.amount,
                    onChange: (e) => {
                      const value = e.target.value;
                      setCommissionForm((prev) => ({
                        ...prev,
                        amount: value
                      }));
                      setErrors((prev) => ({ ...prev, amount: "" }));
                    },
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    placeholder: "Enter how much to pay"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 889,
                    columnNumber: 19
                  },
                  this
                ),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 906,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 885,
                columnNumber: 17
              }, this),
              agentType === "agent" && commissionBreakdown.length > 0 && !isLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-gray-100 p-3 rounded-lg shadow-inner border border-gray-300", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 mb-3 text-lg", children: "Commission Breakdown (Customer-wise)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 912,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "max-h-60 overflow-y-auto custom-scrollbar", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm border", children: [
                  /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-violet-100 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 919,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Phone" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 922,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 925,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "Released Group value (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 928,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 918,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 917,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { children: commissionBreakdown.map(
                    (item, index) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item.user_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 936,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item.phone_number || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 939,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item.group_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 942,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: item.commission_released === "Yes" ? item.group_value : "₹0" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 945,
                        columnNumber: 31
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 935,
                      columnNumber: 25
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 933,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 916,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 915,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 911,
                columnNumber: 17
              }, this),
              agentType === "employee" && commissionBreakdown.length > 0 && !isLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-gray-100 p-3 rounded-lg shadow-inner border border-gray-300", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 mb-3 text-lg", children: "Incentive Breakdown (Customer-wise)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 959,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "max-h-60 overflow-y-auto custom-scrollbar", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm border", children: [
                  /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-violet-100 text-gray-700", children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 966,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Phone" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 969,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-left", children: "Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 972,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "border px-3 py-2 text-right", children: "Released Group value (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 975,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 965,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 964,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { children: commissionBreakdown.map(
                    (item, index) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item.user_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 983,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item.phone_number || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 986,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2", children: item.group_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 989,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "border px-3 py-2 text-right", children: item.commission_released === "Yes" ? item.group_value : "₹0" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 992,
                        columnNumber: 31
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                      lineNumber: 982,
                      columnNumber: 25
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 980,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 963,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 962,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 958,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Mode" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1005,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "pay_type",
                    value: commissionForm.pay_type,
                    onChange: handleCommissionChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 1014,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 1015,
                        columnNumber: 21
                      }, this),
                      modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                          lineNumber: 1018,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "bank_transfer", children: "Bank Transfer" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                          lineNumber: 1019,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                        lineNumber: 1017,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 1008,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pay_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_type }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1024,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 1004,
                columnNumber: 17
              }, this),
              commissionForm.pay_type === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Transaction ID ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 1033,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1032,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "transaction_id",
                    value: commissionForm.transaction_id,
                    onChange: handleCommissionChange,
                    placeholder: "Enter transaction ID",
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 1035,
                    columnNumber: 21
                  },
                  this
                ),
                errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1044,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 1031,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1052,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    name: "note",
                    value: commissionForm.note,
                    onChange: handleCommissionChange,
                    placeholder: "Additional details",
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    rows: "2"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 1055,
                    columnNumber: 19
                  },
                  this
                ),
                errors.note && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.note }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1064,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 1051,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-violet-50 p-3 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Disbursed By" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1069,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: adminName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                  lineNumber: 1072,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 1068,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setShowCommissionModal(false);
                      resetCommissionForm();
                    },
                    className: "px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 1076,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    disabled: isLoading || isLoadingCommissionCalculation,
                    className: "px-4 py-2 bg-violet-700 text-white rounded-lg hover:bg-violet-600 disabled:opacity-50",
                    children: isLoading ? "Processing..." : "Save Payment"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                    lineNumber: 1086,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
                lineNumber: 1075,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
              lineNumber: 555,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
            lineNumber: 551,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
          lineNumber: 543,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
      lineNumber: 491,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
    lineNumber: 489,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx",
    lineNumber: 488,
    columnNumber: 5
  }, this);
};
_s(CommissionPayout, "4+xPcoDg3ozKHPEtpkOfWqNfFnE=", false, function() {
  return [notification.useNotification];
});
_c = CommissionPayout;
export default CommissionPayout;
var _c;
$RefreshReg$(_c, "CommissionPayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutCommission.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMmVVLFNBNmdCWSxVQTdnQlo7MkJBM2VWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFNBQVNDLG9CQUFvQjtBQUM5QyxPQUFPQyxvQkFBb0I7QUFFM0IsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTUMsYUFBYTtBQUNuQixRQUFNLENBQUNDLEtBQUtDLGFBQWEsSUFBSU4sYUFBYU8sZ0JBQWdCO0FBQzFELFFBQU0sQ0FBQ0MscUJBQXFCQyxzQkFBc0IsSUFBSW5CLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUNvQixlQUFlQyxnQkFBZ0IsSUFBSXJCLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNzQixTQUFTQyxVQUFVLElBQUl2QixTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDd0IsYUFBYUMsY0FBYyxJQUFJekIsU0FBUztBQUFBLElBQzdDMEIsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJL0IsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2dDLFdBQVdDLFlBQVksSUFBSWpDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDb0Msa0JBQWtCQyxtQkFBbUIsSUFBSXJDLFNBQVMsTUFBTTtBQUMvRCxRQUFNLENBQUNzQyxhQUFhQyxjQUFjLElBQUl2QyxTQUFTLE1BQU07QUFDckQsUUFBTSxDQUFDd0Msa0JBQWtCQyxtQkFBbUIsSUFBSXpDLFNBQVMsTUFBTTtBQUMvRCxRQUFNLENBQUMwQyxrQkFBa0JDLG1CQUFtQixJQUFJM0MsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzRDLG9CQUFvQkMscUJBQXFCLElBQUk3QyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDOEMsV0FBV0MsWUFBWSxJQUFJL0MsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2dELGdDQUFnQ0MsaUNBQWlDLElBQ3RFakQsU0FBUyxLQUFLO0FBQ2hCLFFBQU0sQ0FBQ2tELFdBQVdDLFlBQVksSUFBSW5ELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNvRCxRQUFRQyxTQUFTLElBQUlyRCxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNzRCxVQUFVQyxXQUFXLElBQUl2RCxTQUFTLENBQUM7QUFDMUMsUUFBTSxDQUFDd0QsWUFBWUMsYUFBYSxJQUFJekQsU0FBUztBQUFBLElBQzNDMEQsUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsSUFDWEMsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxJQUNaQyxjQUFjO0FBQUEsSUFDZEMsa0JBQWtCO0FBQUEsSUFDbEJDLGFBQWE7QUFBQSxJQUNiQyxlQUFlO0FBQUEsSUFDZkMsaUJBQWlCO0FBQUE7QUFBQSxFQUNuQixDQUFDO0FBR0QsUUFBTUMsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFNQyxlQUFlLEdBQUdGLE1BQU1HLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxJQUM3Q0osTUFBTUssU0FBUyxJQUFJO0FBQUEsRUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUVsQixRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUk1RSxTQUFTO0FBQUEsSUFDbkQ2RSxVQUFVO0FBQUEsSUFDVkMsV0FBVSxvQkFBSVQsS0FBSyxHQUFFVSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxJQUMvQ0MsZUFBZVg7QUFBQUEsSUFDZlksUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsTUFBTTtBQUFBLElBQ05DLFNBQVN4RTtBQUFBQSxJQUNUeUUsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU0sQ0FBQ0MscUJBQXFCQyxzQkFBc0IsSUFBSXpGLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUMwRixpQkFBaUJDLGtCQUFrQixJQUFJM0YsU0FBUyxLQUFLO0FBRTVELFFBQU00RixjQUFjLFlBQVk7QUFDOUIsUUFBSTtBQUNGLFlBQU1DLE1BQU0sTUFBTTNGLElBQUk0RixJQUFJLGtCQUFrQjtBQUM1QyxZQUFNQyxNQUFNRixJQUFJRyxRQUFRO0FBQ3hCakU7QUFBQUEsUUFDRWdFLElBQUlFLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsZUFBZSxXQUFXRCxFQUFFQyxlQUFlLE1BQU07QUFBQSxNQUN2RTtBQUNBbEU7QUFBQUEsUUFDRThELElBQUlFO0FBQUFBLFVBQ0YsQ0FBQ0MsTUFBTUEsRUFBRUMsZUFBZSxjQUFjRCxFQUFFQyxlQUFlO0FBQUEsUUFDekQ7QUFBQSxNQUNGO0FBQUEsSUFDRixTQUFTQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0scUJBQXFCRixHQUFHO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBRUEsUUFBTUcsYUFBYUEsQ0FBQ0MsU0FBUztBQUMzQixRQUFJLENBQUNBLEtBQU0sUUFBTztBQUNsQixRQUFJLE9BQU9BLFNBQVMsWUFBWSxzQkFBc0JDLEtBQUtELElBQUksR0FBRztBQUNoRSxhQUFPQTtBQUFBQSxJQUNUO0FBQ0EsVUFBTUUsSUFBSSxJQUFJckMsS0FBS21DLElBQUk7QUFDdkIsUUFBSUcsTUFBTUQsQ0FBQyxFQUFHLFFBQU87QUFDckIsVUFBTUUsT0FBT0YsRUFBRW5DLFlBQVk7QUFDM0IsVUFBTXNDLFFBQVFyQyxPQUFPa0MsRUFBRWpDLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ3RELFVBQU1vQyxNQUFNdEMsT0FBT2tDLEVBQUVLLFFBQVEsQ0FBQyxFQUFFckMsU0FBUyxHQUFHLEdBQUc7QUFDL0MsV0FBTyxHQUFHa0MsSUFBSSxJQUFJQyxLQUFLLElBQUlDLEdBQUc7QUFBQSxFQUNoQztBQUVBLFFBQU1FLHFCQUFxQixPQUFPQyxTQUFTSixPQUFPaEYsU0FBUztBQUN6RCxRQUFJLENBQUNvRixXQUFXLENBQUNKLE9BQU87QUFDdEJwRCxvQkFBYztBQUFBLFFBQ1pDLFFBQVE7QUFBQSxRQUNSQyxVQUFVO0FBQUEsUUFDVkMsV0FBVztBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxZQUFZO0FBQUEsUUFDWkMsY0FBYztBQUFBLFFBQ2RDLGtCQUFrQjtBQUFBLFFBQ2xCQyxhQUFhO0FBQUEsUUFDYkMsZUFBZTtBQUFBLFFBQ2ZDLGlCQUFpQnRDLFNBQVMsYUFBYSxjQUFjO0FBQUEsTUFDdkQsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBOEQsdUJBQW1CLElBQUk7QUFDdkIsUUFBSTtBQUVGLFlBQU0sQ0FBQ2lCLE1BQU1NLFFBQVEsSUFBSUwsTUFBTTdCLE1BQU0sR0FBRztBQUN4QyxZQUFNbUMsV0FBVyxHQUFHUCxJQUFJLElBQUlNLFFBQVE7QUFDcEMsWUFBTUUsVUFBVSxJQUFJL0MsS0FBS3VDLE1BQU1TLFNBQVNILFFBQVEsR0FBRyxDQUFDLEVBQ2pEbkMsWUFBWSxFQUNaQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR2YsWUFBTXNDLFlBQVksTUFBTXBILElBQUk0RixJQUFJLGlCQUFpQm1CLE9BQU8sSUFBSTtBQUFBLFFBQzFETSxRQUFRLEVBQUVYLEtBQUs7QUFBQSxNQUNqQixDQUFDO0FBR0QsWUFBTVksYUFBYTtBQUFBLFFBQ2pCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUFVO0FBRVosWUFBTUMsY0FBY0osU0FBU0gsVUFBVSxFQUFFO0FBQ3pDLFlBQU1RLFlBQVlGLFdBQVdDLGNBQWMsQ0FBQztBQUU1QyxVQUFJRSxpQkFBaUI7QUFDckIsVUFBSUwsVUFBVXRCLFFBQVFzQixVQUFVdEIsS0FBSzRCLFNBQVMsR0FBRztBQUMvQyxjQUFNQyxZQUFZUCxVQUFVdEIsS0FBSyxDQUFDLEVBQUU2QixhQUFhLENBQUM7QUFDbERGLHlCQUFpQkcsT0FBT0QsVUFBVUgsU0FBUyxLQUFLLENBQUM7QUFBQSxNQUNuRDtBQUdBLFlBQU1LLE9BQU8sTUFBTTdILElBQUk0RixJQUFJLDZDQUE2QztBQUFBLFFBQ3RFeUIsUUFBUTtBQUFBLFVBQ04xQyxVQUFVb0M7QUFBQUEsVUFDVmUsV0FBV3pCLFdBQVdZLFFBQVE7QUFBQSxVQUM5QmMsU0FBUzFCLFdBQVdhLE9BQU87QUFBQSxRQUM3QjtBQUFBLE1BQ0YsQ0FBQztBQUVELFVBQUl6RCxXQUFXb0UsTUFBTS9CLE1BQU1rQyxTQUFTQyxtQkFBbUI7QUFDdkQsVUFBSSxPQUFPeEUsYUFBYSxVQUFVO0FBQ2hDQSxtQkFBV21FLE9BQU9uRSxTQUFTeUUsUUFBUSxjQUFjLEVBQUUsQ0FBQztBQUFBLE1BQ3REO0FBRUEsWUFBTXhFLFlBQVl5RSxLQUFLQyxJQUFJWCxpQkFBaUJoRSxVQUFVLENBQUM7QUFDdkQsWUFBTUUsYUFBYThELGlCQUFpQmhFO0FBR3BDLFVBQUlHLGFBQWE7QUFDakIsVUFBSUMsZUFBZTtBQUNuQixVQUFJd0Usa0JBQWtCO0FBRXRCLFVBQUkxRyxTQUFTLFNBQVM7QUFFcEIsWUFBSThCLFlBQVlnRSxnQkFBZ0I7QUFDOUI3RCx1QkFBYUgsV0FBVztBQUFBLFFBQzFCLE9BQU87QUFDTEcsdUJBQWE2RCxpQkFBaUI7QUFDOUI1RCwwQkFBZ0JKLFdBQVdnRSxrQkFBa0I7QUFBQSxRQUMvQztBQUNBWSwwQkFBa0J6RSxhQUFhQztBQUFBQSxNQUNqQyxPQUFPO0FBRUwsWUFBSUosV0FBV2dFLGdCQUFnQjtBQUM3QjVELDBCQUFnQkosV0FBV2dFLGtCQUFrQjtBQUFBLFFBQy9DO0FBQ0FZLDBCQUFrQnhFO0FBQUFBLE1BQ3BCO0FBR0EsWUFBTUcsZ0JBQ0p5RCxpQkFBaUIsSUFDYixJQUFJQSxlQUFlYSxlQUFlLE9BQU8sQ0FBQyxLQUMxQztBQUVOL0Usb0JBQWM7QUFBQSxRQUNaQyxRQUFRaUU7QUFBQUEsUUFDUmhFO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDLGtCQUFrQnVFO0FBQUFBLFFBQ2xCdEUsYUFBYTBELGtCQUFrQjtBQUFBLFFBQy9CekQ7QUFBQUEsUUFDQUMsaUJBQWlCdEMsU0FBUyxhQUFhLGNBQWM7QUFBQSxNQUN2RCxDQUFDO0FBRUQsVUFBSUEsU0FBUyxTQUFTO0FBQ3BCUSw0QkFBb0JrRyxnQkFBZ0JFLFFBQVEsQ0FBQyxDQUFDO0FBQzlDN0QsMEJBQWtCLENBQUM4RCxVQUFVO0FBQUEsVUFDM0IsR0FBR0E7QUFBQUEsVUFDSHhELFFBQVFxRCxnQkFBZ0JFLFFBQVEsQ0FBQztBQUFBLFFBQ25DLEVBQUU7QUFBQSxNQUNKLE9BQU87QUFDTHBHLDRCQUFvQmtHLGdCQUFnQkUsUUFBUSxDQUFDLENBQUM7QUFDOUM3RCwwQkFBa0IsQ0FBQzhELFVBQVU7QUFBQSxVQUMzQixHQUFHQTtBQUFBQSxVQUNIeEQsUUFBUXFELGdCQUFnQkUsUUFBUSxDQUFDO0FBQUEsUUFDbkMsRUFBRTtBQUFBLE1BQ0o7QUFHQWhELDZCQUF1QnNDLE1BQU0vQixNQUFNMkMsbUJBQW1CLEVBQUU7QUFBQSxJQUMxRCxTQUFTckMsT0FBTztBQUNkRCxjQUFRQyxNQUFNLGtDQUFrQ0EsS0FBSztBQUNyRDdDLG9CQUFjO0FBQUEsUUFDWkMsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxXQUFXO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFlBQVk7QUFBQSxRQUNaQyxjQUFjO0FBQUEsUUFDZEMsa0JBQWtCO0FBQUEsUUFDbEJDLGFBQWE7QUFBQSxRQUNiQyxlQUFlO0FBQUEsUUFDZkMsaUJBQWlCakMsY0FBYyxhQUFhLGNBQWM7QUFBQSxNQUM1RCxDQUFDO0FBQ0R1RCw2QkFBdUIsRUFBRTtBQUFBLElBQzNCLFVBQUM7QUFDQ0UseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNaUQsMEJBQTBCLFlBQVk7QUFDMUM3RixpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNOEYsV0FBVyxNQUFNM0ksSUFBSTRGLElBQUksc0NBQXNDO0FBQ3JFLFlBQU1nRCxlQUFlRCxTQUFTN0MsS0FBSytDLElBQUksQ0FBQ0MsU0FBU0MsV0FBVztBQUFBLFFBQzFEQyxJQUFJRCxRQUFRO0FBQUEsUUFDWkUsS0FBS0gsUUFBUUc7QUFBQUEsUUFDYnRFLFVBQVVtRSxRQUFRbkU7QUFBQUEsUUFDbEJ1RSxZQUFZSixRQUFRbkUsVUFBVXdFO0FBQUFBLFFBQzlCdkUsVUFBVWtFLFFBQVFsRTtBQUFBQSxRQUNsQkksUUFBUThELFFBQVE5RDtBQUFBQSxRQUNoQkMsVUFBVTZELFFBQVE3RDtBQUFBQSxRQUNsQm1FLGlCQUNFTixRQUFRTywrQkFBK0J2RSxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxRQUMxRHdFLGVBQ0VSLFFBQVFTLDZCQUE2QnpFLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLFFBQ3hESSxnQkFBZ0I0RCxRQUFRNUQ7QUFBQUEsUUFDeEJDLE1BQU0yRCxRQUFRM0Q7QUFBQUEsUUFDZEMsU0FBUzBELFFBQVExRDtBQUFBQSxRQUNqQm9FLGNBQWNWLFFBQVF6RCxZQUFZOEQ7QUFBQUEsUUFDbENNLFlBQVlYLFFBQVFXO0FBQUFBLE1BQ3RCLEVBQUU7QUFDRjlHLDRCQUFzQmlHLFlBQVk7QUFBQSxJQUNwQyxTQUFTeEMsT0FBTztBQUNkRCxjQUFRQyxNQUFNLHVDQUF1Q0EsS0FBSztBQUMxRHpELDRCQUFzQixFQUFFO0FBQUEsSUFDMUIsVUFBQztBQUNDRSxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUFoRCxZQUFVLE1BQU07QUFDZCxVQUFNNkosT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFDL0JySSxlQUFXd0ksUUFBUVosR0FBRztBQUN0QmhHLGlCQUFhNEcsUUFBUUcsYUFBYUgsUUFBUVYsUUFBUSxFQUFFO0FBQ3BELFFBQUlVLFNBQVNJLHVCQUF1QkMsb0JBQW9CQyxjQUFjO0FBQ3BFaEo7QUFBQUEsUUFDRTBJLFFBQVFJLHNCQUFzQkMsbUJBQW1CQyxpQkFBaUI7QUFBQSxNQUNwRTtBQUFBLElBQ0Y7QUFDQXpFLGdCQUFZO0FBQ1pnRCw0QkFBd0I7QUFBQSxFQUMxQixHQUFHLENBQUN0RixRQUFRLENBQUM7QUFHYixRQUFNZ0gsZ0JBQWdCQSxDQUFDckYsa0JBQWtCO0FBQ3ZDLFFBQUksQ0FBQ0EsY0FBZSxRQUFPLEVBQUVrQyxVQUFVLElBQUlDLFNBQVMsR0FBRztBQUN2RCxVQUFNLENBQUNSLE1BQU1DLEtBQUssSUFBSTVCLGNBQWNELE1BQU0sR0FBRztBQUM3QyxVQUFNbUMsV0FBVyxHQUFHUCxJQUFJLElBQUlDLEtBQUs7QUFDakMsVUFBTU8sVUFBVSxJQUFJL0MsS0FBS3VDLE1BQU1DLE9BQU8sQ0FBQyxFQUFFOUIsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ25FLFdBQU8sRUFBRW1DLFVBQVVDLFFBQVE7QUFBQSxFQUM3QjtBQUVBLFFBQU1tRCxrQ0FBa0MsT0FBT3RELFNBQVNKLE9BQU9oRixTQUFTO0FBQ3RFLFFBQUksQ0FBQ29GLFdBQVcsQ0FBQ0osT0FBTztBQUN0QmpDLHdCQUFrQixDQUFDOEQsVUFBVSxFQUFFLEdBQUdBLE1BQU14RCxRQUFRLEdBQUcsRUFBRTtBQUNyRDtBQUFBLElBQ0Y7QUFFQWpDLHNDQUFrQyxJQUFJO0FBQ3RDLFFBQUk7QUFDRixZQUFNK0QsbUJBQW1CQyxTQUFTSixPQUFPaEYsSUFBSTtBQUFBLElBQy9DLFNBQVN5RSxPQUFPO0FBQ2RELGNBQVFDLE1BQU0seUNBQXlDQSxLQUFLO0FBQzVEMUIsd0JBQWtCLENBQUM4RCxVQUFVLEVBQUUsR0FBR0EsTUFBTXhELFFBQVEsR0FBRyxFQUFFO0FBQUEsSUFDdkQsVUFBQztBQUNDakMsd0NBQWtDLEtBQUs7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNdUgseUJBQXlCQSxDQUFDQyxNQUFNO0FBQ3BDLFVBQU0sRUFBRXBCLE1BQU1xQixNQUFNLElBQUlELEVBQUUvRztBQUMxQmtCLHNCQUFrQixDQUFDOEQsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ1csSUFBSSxHQUFHcUIsTUFBTSxFQUFFO0FBQ3hEckgsY0FBVSxDQUFDcUYsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ1csSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUU3QyxRQUFJQSxTQUFTLGNBQWNBLFNBQVMsaUJBQWlCO0FBQ25ELFlBQU1zQixpQkFDSnRCLFNBQVMsYUFBYXFCLFFBQVEvRixlQUFlRTtBQUMvQyxZQUFNK0YsZUFDSnZCLFNBQVMsa0JBQWtCcUIsUUFBUS9GLGVBQWVNO0FBQ3BELFVBQUkwRixrQkFBa0JDLGdCQUFnQjFJLFdBQVc7QUFDL0NxSTtBQUFBQSxVQUNFSTtBQUFBQSxVQUNBQztBQUFBQSxVQUNBMUk7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMRyw0QkFBb0IsTUFBTTtBQUMxQm9CLHNCQUFjO0FBQUEsVUFDWkMsUUFBUTtBQUFBLFVBQ1JDLFVBQVU7QUFBQSxVQUNWQyxXQUFXO0FBQUEsVUFDWEMsWUFBWTtBQUFBLFVBQ1pDLFlBQVk7QUFBQSxVQUNaQyxjQUFjO0FBQUEsVUFDZEMsa0JBQWtCO0FBQUEsVUFDbEJDLGFBQWE7QUFBQSxVQUNiQyxlQUFlO0FBQUEsVUFDZkMsaUJBQ0VqQyxjQUFjLGFBQWEsY0FBYztBQUFBLFFBQzdDLENBQUM7QUFDRHVELCtCQUF1QixFQUFFO0FBQUEsTUFDM0I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1vRixlQUFlQSxNQUFNO0FBQ3pCLFVBQU1DLFlBQVksQ0FBQztBQUNuQixRQUFJLENBQUNuRyxlQUFlRSxVQUFVO0FBQzVCaUcsZ0JBQVVqRyxXQUFXO0FBQUEsSUFDdkI7QUFDQSxRQUNFLENBQUNGLGVBQWVPLFVBQ2hCeUIsTUFBTWhDLGVBQWVPLE1BQU0sS0FDM0I2RixXQUFXcEcsZUFBZU8sTUFBTSxLQUFLLEdBQ3JDO0FBQ0E0RixnQkFBVTVGLFNBQVM7QUFBQSxJQUNyQjtBQUNBLFFBQUksQ0FBQ1AsZUFBZU0sZUFBZTtBQUNqQzZGLGdCQUFVN0YsZ0JBQWdCO0FBQUEsSUFDNUI7QUFDQSxRQUNFTixlQUFlUSxhQUFhLFlBQzVCLENBQUNSLGVBQWVTLGdCQUNoQjtBQUNBMEYsZ0JBQVUxRixpQkFDUjtBQUFBLElBQ0o7QUFDQS9CLGNBQVV5SCxTQUFTO0FBQ25CLFdBQU9FLE9BQU9DLEtBQUtILFNBQVMsRUFBRWxELFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1zRCx5QkFBeUIsT0FBT1QsTUFBTTtBQUMxQ0EsTUFBRVUsZUFBZTtBQUNqQixVQUFNQyxVQUFVUCxhQUFhO0FBQzdCLFFBQUlPLFNBQVM7QUFDWCxVQUFJO0FBQ0ZySSxxQkFBYSxJQUFJO0FBR2pCLGNBQU0sRUFBRW9FLFVBQVVDLFFBQVEsSUFBSWtEO0FBQUFBLFVBQzVCM0YsZUFBZU07QUFBQUEsUUFDakI7QUFFQSxjQUFNb0csVUFBVTtBQUFBLFVBQ2QsR0FBRzFHO0FBQUFBLFVBQ0hZLFlBQVlqRTtBQUFBQSxVQUNaaUksK0JBQStCcEM7QUFBQUEsVUFDL0JzQyw2QkFBNkJyQztBQUFBQSxRQUMvQjtBQUVBLGNBQU1sSCxJQUFJb0wsS0FBSyx1Q0FBdUNELE9BQU87QUFDN0R0SyxZQUFJd0ssS0FBSztBQUFBLFVBQ1A1SixTQUFTO0FBQUEsVUFDVDZKLGFBQWE7QUFBQSxVQUNiQyxXQUFXO0FBQUEsVUFDWEMsY0FBYztBQUFBLFVBQ2RDLGNBQWM7QUFBQSxRQUNoQixDQUFDO0FBQ0R4SywrQkFBdUIsS0FBSztBQUM1QnlELDBCQUFrQjtBQUFBLFVBQ2hCQyxVQUFVO0FBQUEsVUFDVkMsV0FBVSxvQkFBSVQsS0FBSyxHQUFFVSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxVQUMvQ0MsZUFBZVg7QUFBQUEsVUFDZlksUUFBUTtBQUFBLFVBQ1JDLFVBQVU7QUFBQSxVQUNWQyxnQkFBZ0I7QUFBQSxVQUNoQkMsTUFBTTtBQUFBLFVBQ05FLFlBQVlqRTtBQUFBQSxVQUNaZ0UsU0FBU3hFO0FBQUFBLFFBQ1gsQ0FBQztBQUNEeUMsb0JBQVksQ0FBQ3FJLFFBQVFBLE1BQU0sQ0FBQztBQUM1QmhELGdDQUF3QjtBQUFBLE1BQzFCLFNBQVN0QyxPQUFPO0FBQ2QsY0FBTTNFLFVBQVUyRSxNQUFNM0UsV0FBVztBQUNqQ1osWUFBSXdLLEtBQUs7QUFBQSxVQUNQNUosU0FBUztBQUFBLFVBQ1Q2SixhQUFhN0o7QUFBQUEsVUFDYitKLGNBQWM7QUFBQSxVQUNkQyxjQUFjO0FBQUEsVUFDZEYsV0FBVztBQUFBLFFBQ2IsQ0FBQztBQUFBLE1BQ0gsVUFBQztBQUNDMUkscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEksb0JBQW9CO0FBQUEsSUFDeEIsRUFBRUMsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLFlBQVlDLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxRQUFRO0FBQUEsSUFDckMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLGFBQWE7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLFlBQVk7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGlCQUFpQkMsUUFBUSxVQUFVO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxFQUFDO0FBR2pELFFBQU1DLHNCQUFzQkEsTUFBTTtBQUNoQzdKLGlCQUFhLEVBQUU7QUFDZlEsd0JBQW9CLEVBQUU7QUFDdEJpQyxzQkFBa0I7QUFBQSxNQUNoQkMsVUFBVTtBQUFBLE1BQ1ZDLFdBQVUsb0JBQUlULEtBQUssR0FBRVUsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDL0NDLGVBQWVYO0FBQUFBLE1BQ2ZZLFFBQVE7QUFBQSxNQUNSQyxVQUFVO0FBQUEsTUFDVkMsZ0JBQWdCO0FBQUEsTUFDaEJDLE1BQU07QUFBQSxNQUNORSxZQUFZakU7QUFBQUEsTUFDWmdFLFNBQVN4RTtBQUFBQSxJQUNYLENBQUM7QUFDRDJFLDJCQUF1QixFQUFFO0FBQ3pCaEMsa0JBQWM7QUFBQSxNQUNaQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFdBQVc7QUFBQSxNQUNYQyxZQUFZO0FBQUEsTUFDWkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxrQkFBa0I7QUFBQSxNQUNsQkMsYUFBYTtBQUFBLE1BQ2JDLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxJQUNuQixDQUFDO0FBQ0Q5Qix3QkFBb0IsTUFBTTtBQUMxQmdCLGNBQVUsQ0FBQyxDQUFDO0FBQ1pkLG1CQUFlLE1BQU07QUFDckJFLHdCQUFvQixNQUFNO0FBQzFCa0QsdUJBQW1CLEtBQUs7QUFBQSxFQUMxQjtBQUVBLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDRTNFO0FBQUFBO0FBQUFBLElBQ0QsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTVEsWUFBWUs7QUFBQUEsVUFDbEIsV0FBV0wsWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsVUFBVUgsWUFBWUk7QUFBQUE7QUFBQUEsUUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWlDO0FBQUEsTUFFakMsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHVDQUNaO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG1DQUFrQyxzQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQVE7QUFBQSxZQUFJO0FBQUEsZUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxXQUFRLE9BQU0sMEJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNiVCx1Q0FBdUIsSUFBSTtBQUMzQjZLLG9DQUFvQjtBQUFBLGNBQ3RCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQUssV0FBVSxRQUFPLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSw0REFBMkQsK0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDbEosWUFDQyx1QkFBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsa0JBQWUsV0FBVyxNQUFNLE1BQUsseUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJELEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFDRUYsbUJBQW1CZ0YsU0FBUyxJQUM5QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTWhGO0FBQUFBLGNBQ04sU0FBU2lKO0FBQUFBLGNBQ1QsaUJBQWdCO0FBQUEsY0FDaEIsa0JBQWtCO0FBQUE7QUFBQSxZQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJOEMsSUFHOUMsdUJBQUMsU0FBSSxXQUFVLG1DQUFrQyw0Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUNBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVzNLO0FBQUFBLFVBQ1gsU0FBUyxNQUFNO0FBQ2JDLG1DQUF1QixLQUFLO0FBQzVCNkssZ0NBQW9CO0FBQUEsVUFDdEI7QUFBQSxVQUNBLE9BQU07QUFBQSxVQUVOLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxzREFBcUQsa0RBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVkLHdCQUNwQztBQUFBLHFDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ2xELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPaEo7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDdUksTUFBTTtBQUNmLDRCQUFNd0IsV0FBV3hCLEVBQUUvRyxPQUFPZ0g7QUFDMUJ2SSxtQ0FBYThKLFFBQVE7QUFDckJ0SjtBQUFBQSx3QkFDRXNKLGFBQWEsVUFBVW5LLFNBQVNFO0FBQUFBLHNCQUNsQztBQUNBNEMsd0NBQWtCLENBQUM4RCxVQUFVO0FBQUEsd0JBQzNCLEdBQUdBO0FBQUFBLHdCQUNIN0QsVUFBVTtBQUFBLHdCQUNWSyxRQUFRO0FBQUEsc0JBQ1YsRUFBRTtBQUNGM0MscUNBQWUsTUFBTTtBQUNyQkUsMENBQW9CLE1BQU07QUFDMUJnQixvQ0FBYztBQUFBLHdCQUNaQyxRQUFRO0FBQUEsd0JBQ1JDLFVBQVU7QUFBQSx3QkFDVkMsV0FBVztBQUFBLHdCQUNYQyxZQUFZO0FBQUEsd0JBQ1pDLFlBQVk7QUFBQSx3QkFDWkMsY0FBYztBQUFBLHdCQUNkQyxrQkFBa0I7QUFBQSx3QkFDbEJDLGFBQWE7QUFBQSx3QkFDYkMsZUFBZTtBQUFBLHdCQUNmQyxpQkFDRThILGFBQWEsYUFBYSxjQUFjO0FBQUEsc0JBQzVDLENBQUM7QUFDRHhHLDZDQUF1QixFQUFFO0FBQ3pCcEQsMENBQW9CLE1BQU07QUFDMUJnQixnQ0FBVSxDQUFDLENBQUM7QUFBQSxvQkFDZDtBQUFBLG9CQUVBO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcsVUFBUSxNQUFDLGlDQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCO0FBQUEsc0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkF0Q25DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF1Q0E7QUFBQSxtQkEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0Q0E7QUFBQSxjQUVDbkIsYUFDQyx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUN0REEsY0FBYyxVQUFVLFVBQVU7QUFBQSxrQkFBWTtBQUFBLGtCQUN0RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsYUFBYSxVQUFVQSxTQUFTO0FBQUEsb0JBQ2hDO0FBQUEsb0JBQ0Esa0JBQWlCO0FBQUEsb0JBQ2pCLGNBQWMsQ0FBQ2dLLE9BQU9DLFdBQ3BCM0gsT0FBTzJILFFBQVFDLFFBQVEsR0FDbkJDLFlBQVksRUFDYkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsb0JBRWpDLE9BQU8xSCxlQUFlRSxZQUFZMEg7QUFBQUEsb0JBQ2xDLFVBQVUsQ0FBQzdCLFVBQVU7QUFDbkJySCxnQ0FBVSxDQUFDcUYsVUFBVSxFQUFFLEdBQUdBLE1BQU03RCxVQUFVLEdBQUcsRUFBRTtBQUMvQ0Qsd0NBQWtCLENBQUM4RCxVQUFVO0FBQUEsd0JBQzNCLEdBQUdBO0FBQUFBLHdCQUNIN0QsVUFBVTZGO0FBQUFBLHNCQUNaLEVBQUU7QUFDRkg7QUFBQUEsd0JBQ0VHO0FBQUFBLHdCQUNBL0YsZUFBZU07QUFBQUEsd0JBQ2YvQztBQUFBQSxzQkFDRjtBQUFBLG9CQUNGO0FBQUEsb0JBRUVBLHlCQUFjLFVBQVVKLFNBQVNFLFdBQVcrRztBQUFBQSxzQkFDNUMsQ0FBQ3lELFdBQ0MsdUJBQUMsT0FBTyxRQUFQLEVBQStCLE9BQU9BLE9BQU9yRCxLQUMzQ3FEO0FBQUFBLCtCQUFPbkQ7QUFBQUEsd0JBQUs7QUFBQSx3QkFBSW1ELE9BQU9DO0FBQUFBLDJCQURORCxPQUFPckQsS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUVKO0FBQUE7QUFBQSxrQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQStCQTtBQUFBLGdCQUNDL0YsT0FBT3lCLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWekIsaUJBQU95QixZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQ0E7QUFBQSxjQUlGLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ3hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT0YsZUFBZU07QUFBQUEsb0JBQ3RCLEtBQUtYO0FBQUFBLG9CQUNMLFVBQVVrRztBQUFBQSxvQkFDVixXQUFVO0FBQUE7QUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTTBEO0FBQUEsZ0JBRXpEcEgsT0FBTzZCLGlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsaUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFDUHNGO0FBQUFBLG9CQUNFNUYsZUFBZUU7QUFBQUEsb0JBQ2ZGLGVBQWVNO0FBQUFBLG9CQUNmL0M7QUFBQUEsa0JBQ0Y7QUFBQSxrQkFFRixVQUNFLENBQUN5QyxlQUFlRSxZQUNoQixDQUFDRixlQUFlTSxpQkFDaEJqQztBQUFBQSxrQkFFRixXQUFVO0FBQUEsa0JBRVRBLDJDQUNHLG1CQUNBO0FBQUE7QUFBQSxnQkFsQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBLEtBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsY0FHQzBDLG1CQUNDLHVCQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxrQkFBZSxXQUFXLE1BQU0sTUFBSyxvQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0QsS0FEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBSUR4RCxhQUFhc0IsY0FBYyxDQUFDa0MsbUJBQzNCLHVCQUFDLFNBQUksV0FBVSxRQUNabEMscUJBQVdTLGNBQ1YsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDBDQUF5Qyw4QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVDVCxXQUFXRyxZQUFZSCxXQUFXRSxVQUNqQyx1QkFBQyxTQUFJLFdBQVUscUNBQW9DLGtDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0YsdUJBQUMsU0FBSSxXQUFVLHdDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxxQkFBb0IsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPRixXQUFXVTtBQUFBQSx3QkFDbEI7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBR3NFO0FBQUEsdUJBUHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLHFCQUFvQix3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU8sSUFBSVYsV0FBV0csVUFBVTZFO0FBQUFBLDBCQUM5QjtBQUFBLHdCQUNGLENBQUM7QUFBQSx3QkFDRDtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLc0U7QUFBQSx1QkFUeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUscUJBQW9CLDBCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTyxJQUFJaEYsV0FBV0ssWUFBWTJFO0FBQUFBLDBCQUNoQztBQUFBLHdCQUNGLENBQUM7QUFBQSx3QkFDRDtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLc0U7QUFBQSx1QkFUeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUVBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUscUJBQW9CO0FBQUE7QUFBQSxzQkFDckI7QUFBQSxzQkFDYmhGLFdBQVdXLG9CQUFvQixjQUM1QixjQUNBO0FBQUEseUJBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDO0FBQUEsd0JBQ0EsT0FBTyxJQUFJWCxXQUFXUSxpQkFBaUJ3RTtBQUFBQSwwQkFDckM7QUFBQSwwQkFDQTtBQUFBLDRCQUNFa0UsdUJBQXVCO0FBQUEsNEJBQ3ZCQyx1QkFBdUI7QUFBQSwwQkFDekI7QUFBQSx3QkFDRixDQUFDO0FBQUEsd0JBQ0QsV0FBVTtBQUFBO0FBQUEsc0JBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVNpRjtBQUFBLHVCQWhCbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFrQkE7QUFBQSxxQkF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1REE7QUFBQSxtQkFsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2IsaUNBQUMsT0FBRSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsZ0JBQ2pCeks7QUFBQUEsZ0JBQVU7QUFBQSxnQkFBRTtBQUFBLGdCQUNuQ3NCLFdBQVdXLG9CQUFvQixjQUM1QixjQUNBO0FBQUEsZ0JBQWM7QUFBQSxnQkFBSTtBQUFBLG1CQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQSxLQS9FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlGQTtBQUFBLGNBSURqQyxhQUFhc0IsV0FBV1MsZUFBZSxDQUFDeUIsbUJBQ3ZDLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw0Q0FDWGxDO0FBQUFBLDZCQUFXVyxvQkFBb0IsY0FDNUIsY0FDQTtBQUFBLGtCQUFjO0FBQUEsa0JBQUk7QUFBQSxxQkFIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFdBQU0sV0FBVSw2QkFDZjtBQUFBLHlDQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLCtCQUNaO0FBQUEsMkNBQUMsUUFBRyxXQUFVLDhCQUE2QixvQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFDL0MsdUJBQUMsUUFBRyxXQUFVLCtCQUE4QiwwQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBQ0EsdUJBQUMsV0FDRWpDO0FBQUFBLGtDQUFjLFdBQ2IsdUJBQUMsUUFDQztBQUFBLDZDQUFDLFFBQUcsV0FBVSxvQkFBbUIsaUNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxRQUFHLFdBQVUsK0JBQThCO0FBQUE7QUFBQSx3QkFFekNzQixXQUFXTSxZQUFZMEUsZUFBZSxTQUFTO0FBQUEsMEJBQzlDa0UsdUJBQXVCO0FBQUEsMEJBQ3ZCQyx1QkFBdUI7QUFBQSx3QkFDekIsQ0FBQztBQUFBLDJCQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBTUE7QUFBQSx5QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVdBO0FBQUEsb0JBRUYsdUJBQUMsUUFDQztBQUFBLDZDQUFDLFFBQUcsV0FBVSxvQkFDWHpLLHdCQUFjLFVBQ1gscUJBQ0EsdUNBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSwrQkFBOEI7QUFBQTtBQUFBLHdCQUV6Q3NCLFdBQVdPLGNBQWN5RSxlQUFlLFNBQVM7QUFBQSwwQkFDaERrRSx1QkFBdUI7QUFBQSwwQkFDdkJDLHVCQUF1QjtBQUFBLHdCQUN6QixDQUFDO0FBQUEsMkJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFNQTtBQUFBLHlCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBYUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsOEJBQ1o7QUFBQSw2Q0FBQyxRQUFHLFdBQVUsb0JBQW1CO0FBQUE7QUFBQSx3QkFDakI7QUFBQSx3QkFDYm5KLFdBQVdXLG9CQUFvQixjQUM1QixjQUNBO0FBQUEsMkJBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSw4Q0FBNkM7QUFBQTtBQUFBLHdCQUV4RFgsV0FBV1Esa0JBQWtCd0U7QUFBQUEsMEJBQzVCO0FBQUEsMEJBQ0E7QUFBQSw0QkFDRWtFLHVCQUF1QjtBQUFBLDRCQUN2QkMsdUJBQXVCO0FBQUEsMEJBQ3pCO0FBQUEsd0JBQ0Y7QUFBQSwyQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVNBO0FBQUEseUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsdUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0NBO0FBQUEscUJBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeURBO0FBQUEsbUJBaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUVBO0FBQUEsY0FHRix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9oSSxlQUFlRztBQUFBQSxvQkFDdEIsVUFBVTBGO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFDVixVQUFVLENBQUNwSjtBQUFBQTtBQUFBQSxrQkFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTTJCO0FBQUEsZ0JBRTFCZ0MsT0FBTzBCLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWMUIsaUJBQU8wQixZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8xQztBQUFBQSxvQkFDUDtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJb0Y7QUFBQSxtQkFSdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxrQkFDN0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxLQUFLO0FBQUEsb0JBQ0wsT0FBT3VDLGVBQWVPO0FBQUFBLG9CQUN0QixVQUFVLENBQUN1RixNQUFNO0FBQ2YsNEJBQU1DLFFBQVFELEVBQUUvRyxPQUFPZ0g7QUFDdkI5Rix3Q0FBa0IsQ0FBQzhELFVBQVU7QUFBQSx3QkFDM0IsR0FBR0E7QUFBQUEsd0JBQ0h4RCxRQUFRd0Y7QUFBQUEsc0JBQ1YsRUFBRTtBQUNGckgsZ0NBQVUsQ0FBQ3FGLFVBQVUsRUFBRSxHQUFHQSxNQUFNeEQsUUFBUSxHQUFHLEVBQUU7QUFBQSxvQkFDL0M7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBO0FBQUEsa0JBZGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWNxQztBQUFBLGdCQUVwQzlCLE9BQU84QixVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI5QixpQkFBTzhCLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsbUJBckI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGNBRUNoRCxjQUFjLFdBQVdzRCxvQkFBb0JvQyxTQUFTLEtBQUksQ0FBQzlFLGFBQzFELHVCQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw0Q0FBMkMsb0RBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ2IsaUNBQUMsV0FBTSxXQUFVLDZCQUNmO0FBQUEseUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsK0JBQ1o7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsOEJBQTZCLHdCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDhCQUE2QixxQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSw4QkFBNkIscUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsK0JBQThCLHdDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxXQUNFMEMsOEJBQW9CdUQ7QUFBQUEsb0JBQUksQ0FBQzZELE1BQU0zRCxVQUM5Qix1QkFBQyxRQUFlLFdBQVUsb0JBQ3hCO0FBQUEsNkNBQUMsUUFBRyxXQUFVLG9CQUNYMkQsZUFBS0MsYUFBYSxPQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9CQUNYRCxlQUFLSCxnQkFBZ0IsT0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQkFDWEcsZUFBS0UsY0FBYyxPQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUNYRixlQUFLRyx3QkFBd0IsUUFDMUJILEtBQUtJLGNBQ0wsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUlBO0FBQUEseUJBZE8vRCxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZUE7QUFBQSxrQkFDRCxLQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLHFCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQSxLQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVDQTtBQUFBLG1CQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRDQTtBQUFBLGNBRUQvRyxjQUFjLGNBQWNzRCxvQkFBb0JvQyxTQUFTLEtBQUssQ0FBQzlFLGFBQzlELHVCQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw0Q0FBMkMsbURBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ2IsaUNBQUMsV0FBTSxXQUFVLDZCQUNmO0FBQUEseUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsK0JBQ1o7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsOEJBQTZCLHdCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDhCQUE2QixxQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSw4QkFBNkIscUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsK0JBQThCLHdDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxXQUNFMEMsOEJBQW9CdUQ7QUFBQUEsb0JBQUksQ0FBQzZELE1BQU0zRCxVQUM5Qix1QkFBQyxRQUFlLFdBQVUsb0JBQ3hCO0FBQUEsNkNBQUMsUUFBRyxXQUFVLG9CQUNYMkQsZUFBS0MsYUFBYSxPQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9CQUNYRCxlQUFLSCxnQkFBZ0IsT0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSxvQkFDWEcsZUFBS0UsY0FBYyxPQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsUUFBRyxXQUFVLCtCQUNYRixlQUFLRyx3QkFBd0IsUUFDMUJILEtBQUtJLGNBQ0wsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUlBO0FBQUEseUJBZE8vRCxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZUE7QUFBQSxrQkFDRCxLQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLHFCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQSxLQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVDQTtBQUFBLG1CQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRDQTtBQUFBLGNBRUYsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU90RSxlQUFlUTtBQUFBQSxvQkFDdEIsVUFBVXFGO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QjtBQUFBLHNCQUN6Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSxzQkFDNUJwSixpQkFDQyxtQ0FDRTtBQUFBLCtDQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2QjtBQUFBLHdCQUM3Qix1QkFBQyxZQUFPLE9BQU0saUJBQWdCLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEyQztBQUFBLDJCQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUE7QUFBQTtBQUFBLGtCQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjQTtBQUFBLGdCQUNDZ0MsT0FBTytCLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWL0IsaUJBQU8rQixZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3QkE7QUFBQSxjQUVDUixlQUFlUSxhQUFhLFlBQzNCLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQy9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1IsZUFBZVM7QUFBQUEsb0JBQ3RCLFVBQVVvRjtBQUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBO0FBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU0wRDtBQUFBLGdCQUV6RHBILE9BQU9nQyxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZoQyxpQkFBT2dDLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBR0YsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9CQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU9ULGVBQWVVO0FBQUFBLG9CQUN0QixVQUFVbUY7QUFBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUE7QUFBQSxrQkFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTVU7QUFBQSxnQkFFVHBILE9BQU9pQyxRQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJqQyxpQkFBT2lDLFFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNEO0FBQUEsbUJBYjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQWlCbkMsdUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsbUJBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU07QUFDYi9CLDZDQUF1QixLQUFLO0FBQzVCNkssMENBQW9CO0FBQUEsb0JBQ3RCO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUE2RTtBQUFBO0FBQUEsa0JBTnpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxVQUFVbEosYUFBYUU7QUFBQUEsb0JBQ3ZCLFdBQVU7QUFBQSxvQkFFVEYsc0JBQVksa0JBQWtCO0FBQUE7QUFBQSxrQkFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsaUJBMWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJoQkE7QUFBQSxlQS9oQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnaUJBO0FBQUE7QUFBQSxRQXhpQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BeWlCQTtBQUFBLFNBN2xCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOGxCQTtBQUFBLE9BaG1CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaW1CQSxLQWxtQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1tQkE7QUFFSjtBQUFFakMsR0Foa0NJRCxrQkFBZ0I7QUFBQSxVQUVTRixhQUFhTyxlQUFlO0FBQUE7QUFBQWdNLEtBRnJEck07QUFra0NOLGVBQWVBO0FBQWlCLElBQUFxTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiQVBJIiwiTW9kYWwiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiU2VsZWN0IiwiVG9vbHRpcCIsIm5vdGlmaWNhdGlvbiIsIlNldHRpbmdTaWRlYmFyIiwiQ29tbWlzc2lvblBheW91dCIsIl9zIiwicGF5bWVudEZvciIsImFwaSIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJzaG93Q29tbWlzc2lvbk1vZGFsIiwic2V0U2hvd0NvbW1pc3Npb25Nb2RhbCIsIm1vZGlmeVBheW1lbnQiLCJzZXRNb2RpZnlQYXltZW50IiwiYWRtaW5JZCIsInNldEFkbWluSWQiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJub1JlbG9hZCIsInR5cGUiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJhZ2VudFR5cGUiLCJzZXRBZ2VudFR5cGUiLCJjYWxjdWxhdGVkQW1vdW50Iiwic2V0Q2FsY3VsYXRlZEFtb3VudCIsImFscmVhZHlQYWlkIiwic2V0QWxyZWFkeVBhaWQiLCJyZW1haW5pbmdQYXlhYmxlIiwic2V0UmVtYWluaW5nUGF5YWJsZSIsInNlbGVjdGVkVXNlckxpc3QiLCJzZXRTZWxlY3RlZFVzZXJMaXN0IiwiY29tbWlzc2lvblBheW1lbnRzIiwic2V0Q29tbWlzc2lvblBheW1lbnRzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiaXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uIiwic2V0SXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uIiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwicmVSZW5kZXIiLCJzZXRSZVJlbmRlciIsInRhcmdldERhdGEiLCJzZXRUYXJnZXREYXRhIiwidGFyZ2V0IiwiYWNoaWV2ZWQiLCJyZW1haW5pbmciLCJkaWZmZXJlbmNlIiwidXBUb1RhcmdldCIsImJleW9uZFRhcmdldCIsInRhcmdldENvbW1pc3Npb24iLCJpc1RhcmdldFNldCIsInRhcmdldERpc3BsYXkiLCJjYWxjdWxhdGlvblR5cGUiLCJ0b2RheSIsIkRhdGUiLCJjdXJyZW50TW9udGgiLCJnZXRGdWxsWWVhciIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJjb21taXNzaW9uRm9ybSIsInNldENvbW1pc3Npb25Gb3JtIiwiYWdlbnRfaWQiLCJwYXlfZGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJzZWxlY3RlZE1vbnRoIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsIm5vdGUiLCJwYXlfZm9yIiwiYWRtaW5fdHlwZSIsImNvbW1pc3Npb25CcmVha2Rvd24iLCJzZXRDb21taXNzaW9uQnJlYWtkb3duIiwiaXNUYXJnZXRMb2FkaW5nIiwic2V0SXNUYXJnZXRMb2FkaW5nIiwiZmV0Y2hBZ2VudHMiLCJyZXMiLCJnZXQiLCJhbGwiLCJkYXRhIiwiZmlsdGVyIiwiYSIsImFnZW50X3R5cGUiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRlc3QiLCJkIiwiaXNOYU4iLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJnZXREYXRlIiwiZmV0Y2hUYXJnZXREZXRhaWxzIiwiYWdlbnRJZCIsIm1vbnRoU3RyIiwiZmlyc3REYXkiLCJsYXN0RGF5IiwicGFyc2VJbnQiLCJ0YXJnZXRSZXMiLCJwYXJhbXMiLCJtb250aE5hbWVzIiwibW9udGhOdW1iZXIiLCJtb250aE5hbWUiLCJ0YXJnZXRGb3JNb250aCIsImxlbmd0aCIsIm1vbnRoRGF0YSIsIk51bWJlciIsImNvbW0iLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwic3VtbWFyeSIsImFjdHVhbF9idXNpbmVzcyIsInJlcGxhY2UiLCJNYXRoIiwibWF4IiwidG90YWxDb21taXNzaW9uIiwidG9Mb2NhbGVTdHJpbmciLCJ0b0ZpeGVkIiwicHJldiIsImNvbW1pc3Npb25fZGF0YSIsImZldGNoQ29tbWlzc2lvblBheW1lbnRzIiwicmVzcG9uc2UiLCJyZXNwb25zZURhdGEiLCJtYXAiLCJwYXltZW50IiwiaW5kZXgiLCJpZCIsIl9pZCIsImFnZW50X25hbWUiLCJuYW1lIiwiY29tbWlzc2lvbl9mcm9tIiwiY29tbWlzc2lvbkNhbGN1bGF0aW9uRnJvbURhdGUiLCJjb21taXNzaW9uX3RvIiwiY29tbWlzc2lvbkNhbGN1bGF0aW9uVG9EYXRlIiwiZGlzYnVyc2VkX2J5IiwicmVjZWlwdF9ubyIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImZ1bGxfbmFtZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsImdldE1vbnRoUmFuZ2UiLCJjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uIiwiaGFuZGxlQ29tbWlzc2lvbkNoYW5nZSIsImUiLCJ2YWx1ZSIsInVwZGF0ZWRBZ2VudElkIiwidXBkYXRlZE1vbnRoIiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwicGFyc2VGbG9hdCIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVDb21taXNzaW9uU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicGF5bG9hZCIsInBvc3QiLCJvcGVuIiwiZGVzY3JpcHRpb24iLCJjbGFzc05hbWUiLCJzaG93UHJvZ3Jlc3MiLCJwYXVzZU9uSG92ZXIiLCJ2YWwiLCJjb21taXNzaW9uQ29sdW1ucyIsImtleSIsImhlYWRlciIsInJlc2V0Q29tbWlzc2lvbkZvcm0iLCJzZWxlY3RlZCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwicGVyc29uIiwicGhvbmVfbnVtYmVyIiwibWluaW11bUZyYWN0aW9uRGlnaXRzIiwibWF4aW11bUZyYWN0aW9uRGlnaXRzIiwiaXRlbSIsInVzZXJfbmFtZSIsImdyb3VwX25hbWUiLCJjb21taXNzaW9uX3JlbGVhc2VkIiwiZ3JvdXBfdmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYXlPdXRDb21taXNzaW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBUb29sdGlwLCBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgU2V0dGluZ1NpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TZXR0aW5nU2lkZWJhclwiO1xyXG5cclxuY29uc3QgQ29tbWlzc2lvblBheW91dCA9ICgpID0+IHtcclxuICBjb25zdCBwYXltZW50Rm9yID0gXCJjb21taXNzaW9uXCI7XHJcbiAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgY29uc3QgW3Nob3dDb21taXNzaW9uTW9kYWwsIHNldFNob3dDb21taXNzaW9uTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIG5vUmVsb2FkOiBmYWxzZSxcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnRUeXBlLCBzZXRBZ2VudFR5cGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2NhbGN1bGF0ZWRBbW91bnQsIHNldENhbGN1bGF0ZWRBbW91bnRdID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG4gIGNvbnN0IFthbHJlYWR5UGFpZCwgc2V0QWxyZWFkeVBhaWRdID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG4gIGNvbnN0IFtyZW1haW5pbmdQYXlhYmxlLCBzZXRSZW1haW5pbmdQYXlhYmxlXSA9IHVzZVN0YXRlKFwiMC4wMFwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRVc2VyTGlzdCwgc2V0U2VsZWN0ZWRVc2VyTGlzdF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvbW1pc3Npb25QYXltZW50cywgc2V0Q29tbWlzc2lvblBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdDb21taXNzaW9uQ2FsY3VsYXRpb24sIHNldElzTG9hZGluZ0NvbW1pc3Npb25DYWxjdWxhdGlvbl0gPVxyXG4gICAgdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtyZVJlbmRlciwgc2V0UmVSZW5kZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3RhcmdldERhdGEsIHNldFRhcmdldERhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdGFyZ2V0OiAwLFxyXG4gICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICByZW1haW5pbmc6IDAsXHJcbiAgICBkaWZmZXJlbmNlOiAwLFxyXG4gICAgdXBUb1RhcmdldDogMCxcclxuICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgIHRhcmdldENvbW1pc3Npb246IDAsXHJcbiAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgIGNhbGN1bGF0aW9uVHlwZTogXCJjb21taXNzaW9uXCIsIC8vIFwiY29tbWlzc2lvblwiIGZvciBhZ2VudHMsIFwiaW5jZW50aXZlXCIgZm9yIGVtcGxveWVlc1xyXG4gIH0pO1xyXG5cclxuICAvLyBHZXQgY3VycmVudCBtb250aCBmb3IgbWF4IGF0dHJpYnV0ZVxyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICBjb25zdCBjdXJyZW50TW9udGggPSBgJHt0b2RheS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZyhcclxuICAgIHRvZGF5LmdldE1vbnRoKCkgKyAxXHJcbiAgKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuXHJcbiAgY29uc3QgW2NvbW1pc3Npb25Gb3JtLCBzZXRDb21taXNzaW9uRm9ybV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBhZ2VudF9pZDogXCJcIixcclxuICAgIHBheV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgc2VsZWN0ZWRNb250aDogY3VycmVudE1vbnRoLFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gICAgcGF5X2ZvcjogcGF5bWVudEZvcixcclxuICAgIGFkbWluX3R5cGU6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtjb21taXNzaW9uQnJlYWtkb3duLCBzZXRDb21taXNzaW9uQnJlYWtkb3duXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNUYXJnZXRMb2FkaW5nLCBzZXRJc1RhcmdldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4gICAgICBjb25zdCBhbGwgPSByZXMuZGF0YSB8fCBbXTtcclxuICAgICAgc2V0QWdlbnRzKFxyXG4gICAgICAgIGFsbC5maWx0ZXIoKGEpID0+IGEuYWdlbnRfdHlwZSA9PT0gXCJhZ2VudFwiIHx8IGEuYWdlbnRfdHlwZSA9PT0gXCJib3RoXCIpXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEVtcGxveWVlcyhcclxuICAgICAgICBhbGwuZmlsdGVyKFxyXG4gICAgICAgICAgKGEpID0+IGEuYWdlbnRfdHlwZSA9PT0gXCJlbXBsb3llZVwiIHx8IGEuYWdlbnRfdHlwZSA9PT0gXCJib3RoXCJcclxuICAgICAgICApXHJcbiAgICAgICk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkFnZW50IGZldGNoIGVycm9yXCIsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiB7XHJcbiAgICBpZiAoIWRhdGUpIHJldHVybiBcIlwiO1xyXG4gICAgaWYgKHR5cGVvZiBkYXRlID09PSBcInN0cmluZ1wiICYmIC9eXFxkezR9LVxcZHsyfS1cXGR7Mn0kLy50ZXN0KGRhdGUpKSB7XHJcbiAgICAgIHJldHVybiBkYXRlO1xyXG4gICAgfVxyXG4gICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgaWYgKGlzTmFOKGQpKSByZXR1cm4gXCJcIjtcclxuICAgIGNvbnN0IHllYXIgPSBkLmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IFN0cmluZyhkLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICBjb25zdCBkYXkgPSBTdHJpbmcoZC5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoVGFyZ2V0RGV0YWlscyA9IGFzeW5jIChhZ2VudElkLCBtb250aCwgdHlwZSkgPT4ge1xyXG4gICAgaWYgKCFhZ2VudElkIHx8ICFtb250aCkge1xyXG4gICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICB0YXJnZXQ6IDAsXHJcbiAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICAgIGRpZmZlcmVuY2U6IDAsXHJcbiAgICAgICAgdXBUb1RhcmdldDogMCxcclxuICAgICAgICBiZXlvbmRUYXJnZXQ6IDAsXHJcbiAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuICAgICAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICAgICAgdGFyZ2V0RGlzcGxheTogXCJOb3QgU2V0XCIsXHJcbiAgICAgICAgY2FsY3VsYXRpb25UeXBlOiB0eXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNUYXJnZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gQ2FsY3VsYXRlIGZpcnN0IGFuZCBsYXN0IGRheSBvZiBzZWxlY3RlZCBtb250aFxyXG4gICAgICBjb25zdCBbeWVhciwgbW9udGhTdHJdID0gbW9udGguc3BsaXQoXCItXCIpO1xyXG4gICAgICBjb25zdCBmaXJzdERheSA9IGAke3llYXJ9LSR7bW9udGhTdHJ9LTAxYDtcclxuICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIHBhcnNlSW50KG1vbnRoU3RyKSwgMClcclxuICAgICAgICAudG9JU09TdHJpbmcoKVxyXG4gICAgICAgIC5zcGxpdChcIlRcIilbMF07XHJcblxyXG4gICAgICAvLyBGZXRjaCB0YXJnZXQgZGV0YWlscyBmb3IgdGhlIHNlbGVjdGVkIGFnZW50XHJcbiAgICAgIGNvbnN0IHRhcmdldFJlcyA9IGF3YWl0IEFQSS5nZXQoYC90YXJnZXQvYWdlbnQvJHthZ2VudElkfWAsIHtcclxuICAgICAgICBwYXJhbXM6IHsgeWVhciB9LFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIE1hcCBtb250aCBudW1iZXIgdG8gbW9udGggbmFtZVxyXG4gICAgICBjb25zdCBtb250aE5hbWVzID0gW1xyXG4gICAgICAgIFwiSmFudWFyeVwiLFxyXG4gICAgICAgIFwiRmVicnVhcnlcIixcclxuICAgICAgICBcIk1hcmNoXCIsXHJcbiAgICAgICAgXCJBcHJpbFwiLFxyXG4gICAgICAgIFwiTWF5XCIsXHJcbiAgICAgICAgXCJKdW5lXCIsXHJcbiAgICAgICAgXCJKdWx5XCIsXHJcbiAgICAgICAgXCJBdWd1c3RcIixcclxuICAgICAgICBcIlNlcHRlbWJlclwiLFxyXG4gICAgICAgIFwiT2N0b2JlclwiLFxyXG4gICAgICAgIFwiTm92ZW1iZXJcIixcclxuICAgICAgICBcIkRlY2VtYmVyXCIsXHJcbiAgICAgIF07XHJcbiAgICAgIGNvbnN0IG1vbnRoTnVtYmVyID0gcGFyc2VJbnQobW9udGhTdHIsIDEwKTtcclxuICAgICAgY29uc3QgbW9udGhOYW1lID0gbW9udGhOYW1lc1ttb250aE51bWJlciAtIDFdO1xyXG5cclxuICAgICAgbGV0IHRhcmdldEZvck1vbnRoID0gMDtcclxuICAgICAgaWYgKHRhcmdldFJlcy5kYXRhICYmIHRhcmdldFJlcy5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCBtb250aERhdGEgPSB0YXJnZXRSZXMuZGF0YVswXS5tb250aERhdGEgfHwge307XHJcbiAgICAgICAgdGFyZ2V0Rm9yTW9udGggPSBOdW1iZXIobW9udGhEYXRhW21vbnRoTmFtZV0gfHwgMCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEZldGNoIGNvbW1pc3Npb24gZGF0YSB0byBnZXQgYWNoaWV2ZWQgLSBDT1JSRUNURUQ6IFJlbW92ZWQgZXh0cmEgL2FwaSBwcmVmaXhcclxuICAgICAgY29uc3QgY29tbSA9IGF3YWl0IEFQSS5nZXQoXCIvZW5yb2xsL2dldC1kZXRhaWxlZC1jb21taXNzaW9uLXBlci1tb250aFwiLCB7XHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBhZ2VudF9pZDogYWdlbnRJZCxcclxuICAgICAgICAgIGZyb21fZGF0ZTogZm9ybWF0RGF0ZShmaXJzdERheSksXHJcbiAgICAgICAgICB0b19kYXRlOiBmb3JtYXREYXRlKGxhc3REYXkpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgbGV0IGFjaGlldmVkID0gY29tbT8uZGF0YT8uc3VtbWFyeT8uYWN0dWFsX2J1c2luZXNzIHx8IDA7XHJcbiAgICAgIGlmICh0eXBlb2YgYWNoaWV2ZWQgPT09IFwic3RyaW5nXCIpIHtcclxuICAgICAgICBhY2hpZXZlZCA9IE51bWJlcihhY2hpZXZlZC5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIikpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZW1haW5pbmcgPSBNYXRoLm1heCh0YXJnZXRGb3JNb250aCAtIGFjaGlldmVkLCAwKTtcclxuICAgICAgY29uc3QgZGlmZmVyZW5jZSA9IHRhcmdldEZvck1vbnRoIC0gYWNoaWV2ZWQ7XHJcblxyXG4gICAgICAvLyBDYWxjdWxhdGUgY29tbWlzc2lvbi9pbmNlbnRpdmUgYmFzZWQgb24gYWdlbnQgdHlwZVxyXG4gICAgICBsZXQgdXBUb1RhcmdldCA9IDA7XHJcbiAgICAgIGxldCBiZXlvbmRUYXJnZXQgPSAwO1xyXG4gICAgICBsZXQgdG90YWxDb21taXNzaW9uID0gMDtcclxuXHJcbiAgICAgIGlmICh0eXBlID09PSBcImFnZW50XCIpIHtcclxuICAgICAgICAvLyBGb3IgYWdlbnRzOiAwLjUlIHVwIHRvIHRhcmdldCwgMSUgYmV5b25kIHRhcmdldFxyXG4gICAgICAgIGlmIChhY2hpZXZlZCA8PSB0YXJnZXRGb3JNb250aCkge1xyXG4gICAgICAgICAgdXBUb1RhcmdldCA9IGFjaGlldmVkICogMC4wMDU7IC8vIDAuNSVcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdXBUb1RhcmdldCA9IHRhcmdldEZvck1vbnRoICogMC4wMDU7XHJcbiAgICAgICAgICBiZXlvbmRUYXJnZXQgPSAoYWNoaWV2ZWQgLSB0YXJnZXRGb3JNb250aCkgKiAwLjAxOyAvLyAxJVxyXG4gICAgICAgIH1cclxuICAgICAgICB0b3RhbENvbW1pc3Npb24gPSB1cFRvVGFyZ2V0ICsgYmV5b25kVGFyZ2V0O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIEZvciBlbXBsb3llZXM6IDElIG9ubHkgb24gYW1vdW50IGJleW9uZCB0YXJnZXRcclxuICAgICAgICBpZiAoYWNoaWV2ZWQgPiB0YXJnZXRGb3JNb250aCkge1xyXG4gICAgICAgICAgYmV5b25kVGFyZ2V0ID0gKGFjaGlldmVkIC0gdGFyZ2V0Rm9yTW9udGgpICogMC4wMTsgLy8gMSVcclxuICAgICAgICB9XHJcbiAgICAgICAgdG90YWxDb21taXNzaW9uID0gYmV5b25kVGFyZ2V0O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBGb3JtYXQgdGFyZ2V0IHZhbHVlIGZvciBkaXNwbGF5XHJcbiAgICAgIGNvbnN0IHRhcmdldERpc3BsYXkgPVxyXG4gICAgICAgIHRhcmdldEZvck1vbnRoID4gMFxyXG4gICAgICAgICAgPyBg4oK5JHt0YXJnZXRGb3JNb250aC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWBcclxuICAgICAgICAgIDogXCJOb3QgU2V0XCI7XHJcblxyXG4gICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICB0YXJnZXQ6IHRhcmdldEZvck1vbnRoLFxyXG4gICAgICAgIGFjaGlldmVkLFxyXG4gICAgICAgIHJlbWFpbmluZyxcclxuICAgICAgICBkaWZmZXJlbmNlLFxyXG4gICAgICAgIHVwVG9UYXJnZXQsXHJcbiAgICAgICAgYmV5b25kVGFyZ2V0LFxyXG4gICAgICAgIHRhcmdldENvbW1pc3Npb246IHRvdGFsQ29tbWlzc2lvbixcclxuICAgICAgICBpc1RhcmdldFNldDogdGFyZ2V0Rm9yTW9udGggPj0gMCxcclxuICAgICAgICB0YXJnZXREaXNwbGF5OiB0YXJnZXREaXNwbGF5LFxyXG4gICAgICAgIGNhbGN1bGF0aW9uVHlwZTogdHlwZSA9PT0gXCJlbXBsb3llZVwiID8gXCJpbmNlbnRpdmVcIiA6IFwiY29tbWlzc2lvblwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmICh0eXBlID09PSBcImFnZW50XCIpIHtcclxuICAgICAgICBzZXRDYWxjdWxhdGVkQW1vdW50KHRvdGFsQ29tbWlzc2lvbi50b0ZpeGVkKDIpKTtcclxuICAgICAgICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICBhbW91bnQ6IHRvdGFsQ29tbWlzc2lvbi50b0ZpeGVkKDIpLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRDYWxjdWxhdGVkQW1vdW50KHRvdGFsQ29tbWlzc2lvbi50b0ZpeGVkKDIpKTtcclxuICAgICAgICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICBhbW91bnQ6IHRvdGFsQ29tbWlzc2lvbi50b0ZpeGVkKDIpLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gU3RvcmUgY29tbWlzc2lvbiBicmVha2Rvd24gZm9yIGRpc3BsYXlcclxuICAgICAgc2V0Q29tbWlzc2lvbkJyZWFrZG93bihjb21tPy5kYXRhPy5jb21taXNzaW9uX2RhdGEgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YXJnZXQgZGV0YWlsc1wiLCBlcnJvcik7XHJcbiAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICBhY2hpZXZlZDogMCxcclxuICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgICB1cFRvVGFyZ2V0OiAwLFxyXG4gICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gICAgICAgIGlzVGFyZ2V0U2V0OiBmYWxzZSxcclxuICAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgICAgICBjYWxjdWxhdGlvblR5cGU6IGFnZW50VHlwZSA9PT0gXCJlbXBsb3llZVwiID8gXCJpbmNlbnRpdmVcIiA6IFwiY29tbWlzc2lvblwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0Q29tbWlzc2lvbkJyZWFrZG93bihbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1RhcmdldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgZmV0Y2hDb21taXNzaW9uUGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvcGF5bWVudC1vdXQvZ2V0LWNvbW1pc3Npb24tcGF5bWVudHNcIik7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChwYXltZW50LCBpbmRleCkgPT4gKHtcclxuICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgIF9pZDogcGF5bWVudC5faWQsXHJcbiAgICAgICAgYWdlbnRfaWQ6IHBheW1lbnQuYWdlbnRfaWQsXHJcbiAgICAgICAgYWdlbnRfbmFtZTogcGF5bWVudC5hZ2VudF9pZD8ubmFtZSxcclxuICAgICAgICBwYXlfZGF0ZTogcGF5bWVudC5wYXlfZGF0ZSxcclxuICAgICAgICBhbW91bnQ6IHBheW1lbnQuYW1vdW50LFxyXG4gICAgICAgIHBheV90eXBlOiBwYXltZW50LnBheV90eXBlLFxyXG4gICAgICAgIGNvbW1pc3Npb25fZnJvbTpcclxuICAgICAgICAgIHBheW1lbnQuY29tbWlzc2lvbkNhbGN1bGF0aW9uRnJvbURhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuICAgICAgICBjb21taXNzaW9uX3RvOlxyXG4gICAgICAgICAgcGF5bWVudC5jb21taXNzaW9uQ2FsY3VsYXRpb25Ub0RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIi1cIixcclxuICAgICAgICB0cmFuc2FjdGlvbl9pZDogcGF5bWVudC50cmFuc2FjdGlvbl9pZCxcclxuICAgICAgICBub3RlOiBwYXltZW50Lm5vdGUsXHJcbiAgICAgICAgcGF5X2ZvcjogcGF5bWVudC5wYXlfZm9yLFxyXG4gICAgICAgIGRpc2J1cnNlZF9ieTogcGF5bWVudC5hZG1pbl90eXBlPy5uYW1lLFxyXG4gICAgICAgIHJlY2VpcHRfbm86IHBheW1lbnQucmVjZWlwdF9ubyxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRDb21taXNzaW9uUGF5bWVudHMocmVzcG9uc2VEYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggQ29tbWlzc2lvbiBwYXltZW50c1wiLCBlcnJvcik7XHJcbiAgICAgIHNldENvbW1pc3Npb25QYXltZW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBzZXRBZG1pbklkKHVzZXJPYmouX2lkKTtcclxuICAgIHNldEFkbWluTmFtZSh1c2VyT2JqLmZ1bGxfbmFtZSB8fCB1c2VyT2JqLm5hbWUgfHwgXCJcIik7XHJcbiAgICBpZiAodXNlck9iaj8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCkge1xyXG4gICAgICBzZXRNb2RpZnlQYXltZW50KFxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X3BheW1lbnQgPT09IFwidHJ1ZVwiXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gICAgZmV0Y2hDb21taXNzaW9uUGF5bWVudHMoKTtcclxuICB9LCBbcmVSZW5kZXJdKTtcclxuXHJcbiAgLy8gSGVscGVyIGZ1bmN0aW9uIHRvIGdldCBmaXJzdCBhbmQgbGFzdCBkYXkgZnJvbSBzZWxlY3RlZCBtb250aFxyXG4gIGNvbnN0IGdldE1vbnRoUmFuZ2UgPSAoc2VsZWN0ZWRNb250aCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZE1vbnRoKSByZXR1cm4geyBmaXJzdERheTogXCJcIiwgbGFzdERheTogXCJcIiB9O1xyXG4gICAgY29uc3QgW3llYXIsIG1vbnRoXSA9IHNlbGVjdGVkTW9udGguc3BsaXQoXCItXCIpO1xyXG4gICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbiAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgcmV0dXJuIHsgZmlyc3REYXksIGxhc3REYXkgfTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uID0gYXN5bmMgKGFnZW50SWQsIG1vbnRoLCB0eXBlKSA9PiB7XHJcbiAgICBpZiAoIWFnZW50SWQgfHwgIW1vbnRoKSB7XHJcbiAgICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhbW91bnQ6IFwiXCIgfSkpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgZmV0Y2hUYXJnZXREZXRhaWxzKGFnZW50SWQsIG1vbnRoLCB0eXBlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gY2FsY3VsYXRlIGFnZW50IGNvbW1pc3Npb246XCIsIGVycm9yKTtcclxuICAgICAgc2V0Q29tbWlzc2lvbkZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIGFtb3VudDogXCJcIiB9KSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmdDb21taXNzaW9uQ2FsY3VsYXRpb24oZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbW1pc3Npb25DaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcblxyXG4gICAgaWYgKG5hbWUgPT09IFwiYWdlbnRfaWRcIiB8fCBuYW1lID09PSBcInNlbGVjdGVkTW9udGhcIikge1xyXG4gICAgICBjb25zdCB1cGRhdGVkQWdlbnRJZCA9XHJcbiAgICAgICAgbmFtZSA9PT0gXCJhZ2VudF9pZFwiID8gdmFsdWUgOiBjb21taXNzaW9uRm9ybS5hZ2VudF9pZDtcclxuICAgICAgY29uc3QgdXBkYXRlZE1vbnRoID1cclxuICAgICAgICBuYW1lID09PSBcInNlbGVjdGVkTW9udGhcIiA/IHZhbHVlIDogY29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aDtcclxuICAgICAgaWYgKHVwZGF0ZWRBZ2VudElkICYmIHVwZGF0ZWRNb250aCAmJiBhZ2VudFR5cGUpIHtcclxuICAgICAgICBjYWxjdWxhdGVUb3RhbFBheWFibGVDb21taXNzaW9uKFxyXG4gICAgICAgICAgdXBkYXRlZEFnZW50SWQsXHJcbiAgICAgICAgICB1cGRhdGVkTW9udGgsXHJcbiAgICAgICAgICBhZ2VudFR5cGVcclxuICAgICAgICApO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldENhbGN1bGF0ZWRBbW91bnQoXCIwLjAwXCIpO1xyXG4gICAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgICAgICBkaWZmZXJlbmNlOiAwLFxyXG4gICAgICAgICAgdXBUb1RhcmdldDogMCxcclxuICAgICAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgICAgICAgIHRhcmdldENvbW1pc3Npb246IDAsXHJcbiAgICAgICAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICAgICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgICAgICAgIGNhbGN1bGF0aW9uVHlwZTpcclxuICAgICAgICAgICAgYWdlbnRUeXBlID09PSBcImVtcGxveWVlXCIgPyBcImluY2VudGl2ZVwiIDogXCJjb21taXNzaW9uXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0Q29tbWlzc2lvbkJyZWFrZG93bihbXSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghY29tbWlzc2lvbkZvcm0uYWdlbnRfaWQpIHtcclxuICAgICAgbmV3RXJyb3JzLmFnZW50X2lkID0gXCJQbGVhc2Ugc2VsZWN0IGFuIGFnZW50XCI7XHJcbiAgICB9XHJcbiAgICBpZiAoXHJcbiAgICAgICFjb21taXNzaW9uRm9ybS5hbW91bnQgfHxcclxuICAgICAgaXNOYU4oY29tbWlzc2lvbkZvcm0uYW1vdW50KSB8fFxyXG4gICAgICBwYXJzZUZsb2F0KGNvbW1pc3Npb25Gb3JtLmFtb3VudCkgPD0gMFxyXG4gICAgKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIGFtb3VudFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFjb21taXNzaW9uRm9ybS5zZWxlY3RlZE1vbnRoKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5zZWxlY3RlZE1vbnRoID0gXCJQbGVhc2Ugc2VsZWN0IGEgbW9udGhcIjtcclxuICAgIH1cclxuICAgIGlmIChcclxuICAgICAgY29tbWlzc2lvbkZvcm0ucGF5X3R5cGUgPT09IFwib25saW5lXCIgJiZcclxuICAgICAgIWNvbW1pc3Npb25Gb3JtLnRyYW5zYWN0aW9uX2lkXHJcbiAgICApIHtcclxuICAgICAgbmV3RXJyb3JzLnRyYW5zYWN0aW9uX2lkID1cclxuICAgICAgICBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkIGZvciBvbmxpbmUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbW1pc3Npb25TdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgIC8vIENhbGN1bGF0ZSBmaXJzdCBhbmQgbGFzdCBkYXkgZm9yIHBheWxvYWRcclxuICAgICAgICBjb25zdCB7IGZpcnN0RGF5LCBsYXN0RGF5IH0gPSBnZXRNb250aFJhbmdlKFxyXG4gICAgICAgICAgY29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5jb21taXNzaW9uRm9ybSxcclxuICAgICAgICAgIGFkbWluX3R5cGU6IGFkbWluSWQsXHJcbiAgICAgICAgICBjb21taXNzaW9uQ2FsY3VsYXRpb25Gcm9tRGF0ZTogZmlyc3REYXksXHJcbiAgICAgICAgICBjb21taXNzaW9uQ2FsY3VsYXRpb25Ub0RhdGU6IGxhc3REYXksXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgYXdhaXQgQVBJLnBvc3QoXCIvcGF5bWVudC1vdXQvYWRkLWNvbW1pc3Npb24tcGF5bWVudFwiLCBwYXlsb2FkKTtcclxuICAgICAgICBhcGkub3Blbih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkNvbW1pc3Npb24gUGF5T3V0IEFkZGVkXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJDb21taXNzaW9uIFBheW1lbnQgSGFzIEJlZW4gU3VjY2Vzc2Z1bGx5IEFkZGVkXCIsXHJcbiAgICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tNDAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgICBzaG93UHJvZ3Jlc3M6IHRydWUsXHJcbiAgICAgICAgICBwYXVzZU9uSG92ZXI6IGZhbHNlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldENvbW1pc3Npb25Gb3JtKHtcclxuICAgICAgICAgIGFnZW50X2lkOiBcIlwiLFxyXG4gICAgICAgICAgcGF5X2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICBzZWxlY3RlZE1vbnRoOiBjdXJyZW50TW9udGgsXHJcbiAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgICAgIG5vdGU6IFwiXCIsXHJcbiAgICAgICAgICBhZG1pbl90eXBlOiBhZG1pbklkLFxyXG4gICAgICAgICAgcGF5X2ZvcjogcGF5bWVudEZvcixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRSZVJlbmRlcigodmFsKSA9PiB2YWwgKyAxKTtcclxuICAgICAgICBmZXRjaENvbW1pc3Npb25QYXltZW50cygpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIjtcclxuICAgICAgICBhcGkub3Blbih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBBZGQgQ29tbWlzc2lvbiBQYXlvdXRcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBtZXNzYWdlLFxyXG4gICAgICAgICAgc2hvd1Byb2dyZXNzOiB0cnVlLFxyXG4gICAgICAgICAgcGF1c2VPbkhvdmVyOiBmYWxzZSxcclxuICAgICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtNDAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbW1pc3Npb25Db2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWdlbnRfbmFtZVwiLCBoZWFkZXI6IFwiQWdlbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnQgKOKCuSlcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbiAgICB7IGtleTogXCJjb21taXNzaW9uX2Zyb21cIiwgaGVhZGVyOiBcIkZyb20gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJjb21taXNzaW9uX3RvXCIsIGhlYWRlcjogXCJUbyBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbiAgICB7IGtleTogXCJkaXNidXJzZWRfYnlcIiwgaGVhZGVyOiBcIkRpc2J1cnNlZCBieVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgcmVzZXRDb21taXNzaW9uRm9ybSA9ICgpID0+IHtcclxuICAgIHNldEFnZW50VHlwZShcIlwiKTtcclxuICAgIHNldFNlbGVjdGVkVXNlckxpc3QoW10pO1xyXG4gICAgc2V0Q29tbWlzc2lvbkZvcm0oe1xyXG4gICAgICBhZ2VudF9pZDogXCJcIixcclxuICAgICAgcGF5X2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgIHNlbGVjdGVkTW9udGg6IGN1cnJlbnRNb250aCxcclxuICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICBub3RlOiBcIlwiLFxyXG4gICAgICBhZG1pbl90eXBlOiBhZG1pbklkLFxyXG4gICAgICBwYXlfZm9yOiBwYXltZW50Rm9yLFxyXG4gICAgfSk7XHJcbiAgICBzZXRDb21taXNzaW9uQnJlYWtkb3duKFtdKTtcclxuICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICB0YXJnZXQ6IDAsXHJcbiAgICAgIGFjaGlldmVkOiAwLFxyXG4gICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgIGRpZmZlcmVuY2U6IDAsXHJcbiAgICAgIHVwVG9UYXJnZXQ6IDAsXHJcbiAgICAgIGJleW9uZFRhcmdldDogMCxcclxuICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuICAgICAgaXNUYXJnZXRTZXQ6IGZhbHNlLFxyXG4gICAgICB0YXJnZXREaXNwbGF5OiBcIk5vdCBTZXRcIixcclxuICAgICAgY2FsY3VsYXRpb25UeXBlOiBcImNvbW1pc3Npb25cIixcclxuICAgIH0pO1xyXG4gICAgc2V0Q2FsY3VsYXRlZEFtb3VudChcIjAuMDBcIik7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgc2V0QWxyZWFkeVBhaWQoXCIwLjAwXCIpO1xyXG4gICAgc2V0UmVtYWluaW5nUGF5YWJsZShcIjAuMDBcIik7XHJcbiAgICBzZXRJc1RhcmdldExvYWRpbmcoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgIG5vUmVsb2FkPXthbGVydENvbmZpZy5ub1JlbG9hZH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTQgbWQ6bWItMFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC1yZWQtNTAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICBDb21taXNzaW9uIC8gSW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgUGF5bWVudHMgT3V0XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIkFkZCBDb21taXNzaW9uIFBheW1lbnRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzZXRDb21taXNzaW9uRm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtOTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC02MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+Kzwvc3Bhbj4gQ29tbWlzc2lvbiAvIEluY2VudGl2ZSBQYXltZW50XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi00IHRleHQtdmlvbGV0LTgwMCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBDb21taXNzaW9uIC8gSW5jZW50aXZlIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSBkYXRhPVwiQ29tbWlzc2lvbiBQYXltZW50c1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogY29tbWlzc2lvblBheW1lbnRzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2NvbW1pc3Npb25QYXltZW50c31cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29tbWlzc2lvbkNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlBheU91dCBDb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YENvbW1pc3Npb24gUGF5bWVudHMuY3N2YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBObyBjb21taXNzaW9uIHBheW1lbnRzIGZvdW5kXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dDb21taXNzaW9uTW9kYWx9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTaG93Q29tbWlzc2lvbk1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICByZXNldENvbW1pc3Npb25Gb3JtKCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHdpZHRoPVwibWF4LXctbWRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgICAgQWRkIENvbW1pc3Npb24gLyBJbmNlbnRpdmUgUGF5bWVudFxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZUNvbW1pc3Npb25TdWJtaXR9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXthZ2VudFR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWdlbnRUeXBlKHNlbGVjdGVkKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkVXNlckxpc3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkID09PSBcImFnZW50XCIgPyBhZ2VudHMgOiBlbXBsb3llZXNcclxuICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRDb21taXNzaW9uRm9ybSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEFscmVhZHlQYWlkKFwiMC4wMFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFJlbWFpbmluZ1BheWFibGUoXCIwLjAwXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbWFpbmluZzogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBUb1RhcmdldDogMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmV5b25kVGFyZ2V0OiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1RhcmdldFNldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldERpc3BsYXk6IFwiTm90IFNldFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGlvblR5cGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWQgPT09IFwiZW1wbG95ZWVcIiA/IFwiaW5jZW50aXZlXCIgOiBcImNvbW1pc3Npb25cIixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Q29tbWlzc2lvbkJyZWFrZG93bihbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRDYWxjdWxhdGVkQW1vdW50KFwiMC4wMFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5cclxuICAgICAgICAgICAgICAgICAgICAgIC0tIFNlbGVjdCBUeXBlIC0tXHJcbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFnZW50XCI+QWdlbnQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW1wbG95ZWVcIj5FbXBsb3llZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHthZ2VudFR5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3Qge2FnZW50VHlwZSA9PT0gXCJhZ2VudFwiID8gXCJBZ2VudFwiIDogXCJFbXBsb3llZVwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17YFNlbGVjdCAke2FnZW50VHlwZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFN0cmluZyhvcHRpb24/LmNoaWxkcmVuKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8udG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Gb3JtLmFnZW50X2lkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhZ2VudF9pZDogXCJcIiB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRfaWQ6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGN1bGF0ZVRvdGFsUGF5YWJsZUNvbW1pc3Npb24oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZ2VudFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgeyhhZ2VudFR5cGUgPT09IFwiYWdlbnRcIiA/IGFnZW50cyA6IGVtcGxveWVlcykubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAocGVyc29uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtwZXJzb24uX2lkfSB2YWx1ZT17cGVyc29uLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVyc29uLm5hbWV9IHwge3BlcnNvbi5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWdlbnRfaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFnZW50X2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogU2luZ2xlIE1vbnRoIFBpY2tlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTW9udGggPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VsZWN0ZWRNb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Gb3JtLnNlbGVjdGVkTW9udGh9XHJcbiAgICAgICAgICAgICAgICAgICAgbWF4PXtjdXJyZW50TW9udGh9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnNlbGVjdGVkTW9udGggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc2VsZWN0ZWRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGNhbGN1bGF0ZVRvdGFsUGF5YWJsZUNvbW1pc3Npb24oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Gb3JtLmFnZW50X2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uRm9ybS5zZWxlY3RlZE1vbnRoLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2VudFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgIWNvbW1pc3Npb25Gb3JtLmFnZW50X2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAhY29tbWlzc2lvbkZvcm0uc2VsZWN0ZWRNb250aCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nQ29tbWlzc2lvbkNhbGN1bGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMiBiZy1ncmVlbi03MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBob3ZlcjpiZy1ncmVlbi04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2lzTG9hZGluZ0NvbW1pc3Npb25DYWxjdWxhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIkNhbGN1bGF0aW5nLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJDYWxjdWxhdGUgQW1vdW50XCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIExvYWRpbmcgaW5kaWNhdG9yIGZvciB0YXJnZXQgZGF0YSAqL31cclxuICAgICAgICAgICAgICAgIHtpc1RhcmdldExvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IGRhdGE9XCJUYXJnZXQgRGV0YWlsc1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogVGFyZ2V0IGRldGFpbHMgZm9yIGJvdGggYWdlbnRzIGFuZCBlbXBsb3llZXMgKi99XHJcbiAgICAgICAgICAgICAgICB7YWdlbnRUeXBlICYmIHRhcmdldERhdGEgJiYgIWlzVGFyZ2V0TG9hZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmlzVGFyZ2V0U2V0ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBwLTQgcm91bmRlZC1sZyBzaGFkb3cgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC15ZWxsb3ctODAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBUYXJnZXQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RhcmdldERhdGEuYWNoaWV2ZWQgPj0gdGFyZ2V0RGF0YS50YXJnZXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi04MDAgZm9udC1zZW1pYm9sZCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn46JIFRhcmdldCBBY2hpZXZlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1kOmdyaWQtY29scy0zIGdhcC00IGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhcmdldCBTZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldERhdGEudGFyZ2V0RGlzcGxheX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIHctZnVsbCBiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjaGlldmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0YXJnZXREYXRhLmFjaGlldmVkPy50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWQgdy1mdWxsIGJnLWdyYXktNTAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGlmZmVyZW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7dGFyZ2V0RGF0YS5kaWZmZXJlbmNlPy50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWQgdy1mdWxsIGJnLWdyYXktNTAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFBheWFibGV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmNhbGN1bGF0aW9uVHlwZSA9PT0gXCJpbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJJbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJDb21taXNzaW9uXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0YXJnZXREYXRhLnRhcmdldENvbW1pc3Npb24udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIHctZnVsbCBiZy1ncmF5LTUwIHRleHQtZ3JlZW4tNzAwIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy15ZWxsb3ctNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXllbGxvdy0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC15ZWxsb3ctODAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gdGFyZ2V0IHNldCBmb3IgdGhpcyB7YWdlbnRUeXBlfS57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RhcmdldERhdGEuY2FsY3VsYXRpb25UeXBlID09PSBcImluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJDb21taXNzaW9uXCJ9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHdpbGwgYmUgY2FsY3VsYXRlZCBiYXNlZCBvbiBzdGFuZGFyZCBydWxlcy5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBDb21taXNzaW9uL0luY2VudGl2ZSBicmVha2Rvd24gdGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICB7YWdlbnRUeXBlICYmIHRhcmdldERhdGEuaXNUYXJnZXRTZXQgJiYgIWlzVGFyZ2V0TG9hZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBzaGFkb3cgYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0zIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmNhbGN1bGF0aW9uVHlwZSA9PT0gXCJpbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkNvbW1pc3Npb25cIn17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBCcmVha2Rvd25cclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtc20gYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiB0ZXh0LWxlZnRcIj5QYXJ0PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBbW91bnQgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50VHlwZSA9PT0gXCJhZ2VudFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwLjUlIHVwIHRvIFRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLnVwVG9UYXJnZXQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudFR5cGUgPT09IFwiYWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiMSUgYmV5b25kIFRhcmdldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCIxJSBpbmNlbnRpdmUgb24gdGFyZ2V0IGRpZmZlcmVuY2VcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhcmdldERhdGEuYmV5b25kVGFyZ2V0Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUGF5YWJsZXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXJnZXREYXRhLmNhbGN1bGF0aW9uVHlwZSA9PT0gXCJpbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkNvbW1pc3Npb25cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHQgdGV4dC1ncmVlbi04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhcmdldERhdGEudGFyZ2V0Q29tbWlzc2lvbj8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0ucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshbW9kaWZ5UGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYXlhYmxlICjigrkpXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FsY3VsYXRlZEFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGJnLWdyYXktMTAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbnRlciBBbW91bnQgKOKCuSkgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbWluPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Q29tbWlzc2lvbkZvcm0oKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIGFtb3VudDogXCJcIiB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBob3cgbXVjaCB0byBwYXlcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuYW1vdW50fTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHthZ2VudFR5cGUgPT09IFwiYWdlbnRcIiAmJiBjb21taXNzaW9uQnJlYWtkb3duLmxlbmd0aCA+IDAgJiYhaXNMb2FkaW5nICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJnLWdyYXktMTAwIHAtMyByb3VuZGVkLWxnIHNoYWRvdy1pbm5lciBib3JkZXIgYm9yZGVyLWdyYXktMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0zIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIENvbW1pc3Npb24gQnJlYWtkb3duIChDdXN0b21lci13aXNlKVxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC02MCBvdmVyZmxvdy15LWF1dG8gY3VzdG9tLXNjcm9sbGJhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgdGV4dC1zbSBib3JkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaG9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVsZWFzZWQgR3JvdXAgdmFsdWUgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjb21taXNzaW9uQnJlYWtkb3duLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udXNlcl9uYW1lIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5ncm91cF9uYW1lIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY29tbWlzc2lvbl9yZWxlYXNlZCA9PT0gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBpdGVtLmdyb3VwX3ZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwi4oK5MFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHthZ2VudFR5cGUgPT09IFwiZW1wbG95ZWVcIiAmJiBjb21taXNzaW9uQnJlYWtkb3duLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyAmJihcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGJnLWdyYXktMTAwIHAtMyByb3VuZGVkLWxnIHNoYWRvdy1pbm5lciBib3JkZXIgYm9yZGVyLWdyYXktMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0zIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEluY2VudGl2ZSBCcmVha2Rvd24gKEN1c3RvbWVyLXdpc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLTYwIG92ZXJmbG93LXktYXV0byBjdXN0b20tc2Nyb2xsYmFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LXNtIGJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXZpb2xldC0xMDAgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWxlYXNlZCBHcm91cCB2YWx1ZSAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbW1pc3Npb25CcmVha2Rvd24ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS51c2VyX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucGhvbmVfbnVtYmVyIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmdyb3VwX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5jb21taXNzaW9uX3JlbGVhc2VkID09PSBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGl0ZW0uZ3JvdXBfdmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCLigrkwXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS5wYXlfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29tbWlzc2lvbkNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge21vZGlmeVBheW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPkNoZXF1ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYmFua190cmFuc2ZlclwiPkJhbmsgVHJhbnNmZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtjb21taXNzaW9uRm9ybS5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Gb3JtLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRyYW5zYWN0aW9uIElEXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudHJhbnNhY3Rpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBOb3RlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0ubm90ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29tbWlzc2lvbkNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFkZGl0aW9uYWwgZGV0YWlsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJvd3M9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ub3RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5ub3RlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXZpb2xldC01MCBwLTMgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBEaXNidXJzZWQgQnlcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2FkbWluTmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTMgcHQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd0NvbW1pc3Npb25Nb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXNldENvbW1pc3Npb25Gb3JtKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZyB8fCBpc0xvYWRpbmdDb21taXNzaW9uQ2FsY3VsYXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXZpb2xldC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLXZpb2xldC02MDAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gXCJQcm9jZXNzaW5nLi4uXCIgOiBcIlNhdmUgUGF5bWVudFwifVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb21taXNzaW9uUGF5b3V0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGF5T3V0Q29tbWlzc2lvbi5qc3gifQ==