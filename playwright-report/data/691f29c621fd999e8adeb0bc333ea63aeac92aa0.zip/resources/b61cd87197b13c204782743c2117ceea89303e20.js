import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitTransferPaymentForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select, Spin, Drawer } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaWhatsappSquare, FaHistory } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
const ChitTransferPaymentForm = ({ userId: initialUserId, onClose, onSuccess }) => {
  _s();
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const yesterday = new Date((/* @__PURE__ */ new Date()).setDate((/* @__PURE__ */ new Date()).getDate() - 1)).toISOString().split("T")[0];
  const [users, setUsers] = useState([]);
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(initialUserId || "");
  const [userAccountInfo, setUserAccountInfo] = useState(null);
  const [fetchingBalance, setFetchingBalance] = useState(false);
  const [enrollmentLoading, setEnrollmentLoading] = useState(false);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [errors, setErrors] = useState({});
  const [whatsappEnable, setWhatsappEnable] = useState(true);
  const [serviceCharge, setServiceCharge] = useState(0);
  const [gstAmount, setGstAmount] = useState(0);
  const [loadingTransaction, setLoadingTransaction] = useState(false);
  const [borrowers, setBorrowers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [selectedGroupTickets, setSelectedGroupTickets] = useState([]);
  const [removalReason, setRemovalReason] = useState();
  const [transactionHistory, setTransactionHistory] = useState([]);
  const [showTxnDrawer, setShowTxnDrawer] = useState(false);
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    const perms = user?.admin_access_right_id?.access_permissions || {};
    if (perms.edit_payment === "true") setModifyPayment(true);
    if (perms.edit_limited_payment === "true") {
      setModifyPayment(true);
      setModifyMinMaxPaymentDate(true);
    }
  }, []);
  const [formData, setFormData] = useState({
    user_id: initialUserId || "",
    pay_date: today,
    amount: "",
    pay_type: "Transfer",
    pay_for: "",
    transaction_id: "",
    admin_type: "",
    remarks: "",
    account_type: "savings",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: ""
  });
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await api.get("user/verified");
        setUsers(res?.data?.data || []);
      } catch {
        setUsers([]);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    if (initialUserId) {
      setSelectedUserId(initialUserId);
      setFormData((prev) => ({ ...prev, user_id: initialUserId }));
      fetchUserAccountInfo(initialUserId);
      fetchUserEnrollments(initialUserId);
    }
  }, [initialUserId]);
  const fetchUserAccountInfo = async (userId) => {
    if (!userId) return;
    setFetchingBalance(true);
    try {
      const response = await api.get(`/v1/admin/user-accounts/${userId}`);
      if (response.data?.status) {
        setUserAccountInfo(response.data.data);
      } else {
        setUserAccountInfo(null);
      }
    } catch {
      setUserAccountInfo(null);
    } finally {
      setFetchingBalance(false);
    }
  };
  const fetchUserEnrollments = async (userId) => {
    if (!userId) return;
    setEnrollmentLoading(true);
    try {
      const response = await api.post(`/enroll/get-user-tickets-report/${userId}`);
      const valid = response.data.filter((item) => item.enrollment && item.enrollment.group);
      setFilteredEnrollments(valid);
    } catch {
      setFilteredEnrollments([]);
    } finally {
      setEnrollmentLoading(false);
    }
  };
  const mapRemovalReasonToPayFor = (reason) => {
    if (!reason) return "";
    const lower = reason.toLowerCase();
    if (lower.includes("close")) return "Chit Close / Transfer";
    if (lower.includes("cancel")) return "Chit Cancellation / Transfer";
    return "";
  };
  useEffect(() => {
    if (!selectedUserId) {
      setServiceCharge(0);
      setGstAmount(0);
      setTransactionHistory([]);
      return;
    }
    const fetchTransactionHistory = async () => {
      setLoadingTransaction(true);
      try {
        const res = await api.get("/v1/admin/transaction-history/");
        const transactions = res.data.data || [];
        const userTransactions = transactions.filter(
          (txn) => txn.enroll_id?.user_id?._id === selectedUserId
        );
        setTransactionHistory(userTransactions);
        if (userTransactions.length > 0) {
          const sorted = userTransactions.sort(
            (a, b) => new Date(b.transaction_date) - new Date(a.transaction_date)
          );
          const latest = sorted[0];
          setRemovalReason(latest?.enroll_id?.removal_reason);
          setServiceCharge(latest.service_charge || 0);
          setGstAmount(latest.gst_amount || 0);
        } else {
          setServiceCharge(0);
          setGstAmount(0);
        }
      } catch (error) {
        console.error("Error fetching transaction history:", error);
        setServiceCharge(0);
        setGstAmount(0);
        setTransactionHistory([]);
      } finally {
        setLoadingTransaction(false);
      }
    };
    fetchTransactionHistory();
  }, [selectedUserId]);
  useEffect(() => {
    if (!selectedUserId) {
      setBorrowers([]);
      setPigmeCustomers([]);
      return;
    }
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(`/loans/get-borrower-by-user-id/${selectedUserId}`);
        setBorrowers(response.data);
      } catch {
        setBorrowers([]);
      }
    };
    const fetchPigmeDetails = async () => {
      try {
        const response = await api.get(`/pigme/get-pigme-customer-by-user-id/${selectedUserId}`);
        setPigmeCustomers(response.data);
      } catch {
        setPigmeCustomers([]);
      }
    };
    fetchCustomerLoanDetails();
    fetchPigmeDetails();
  }, [selectedUserId]);
  useEffect(() => {
    if (!selectedUserId) return;
    const allOptions = [
      ...filteredEnrollments.map((entry) => `chit-${entry.enrollment.group._id}|${entry.enrollment.tickets}`),
      ...pigmeCustomers.map((pigme) => `pigme-${pigme._id}`),
      ...borrowers.map((borrower) => `loan-${borrower._id}`)
    ];
    if (allOptions.length > 0) {
      setSelectedGroupTickets(allOptions);
      setErrors((prev) => ({ ...prev, group_ticket: void 0 }));
    }
  }, [filteredEnrollments, pigmeCustomers, borrowers, selectedUserId]);
  const handleCustomer = (userId) => {
    setSelectedUserId(userId);
    setFormData((prev) => ({ ...prev, user_id: userId }));
    setErrors((prev) => ({ ...prev, customer: "" }));
    setSelectedGroupTickets([]);
    setServiceCharge(0);
    setGstAmount(0);
    setTransactionHistory([]);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "amount") {
      let cleaned = value.replace(/[^0-9.]/g, "");
      if ((cleaned.match(/\./g) || []).length > 1) return;
      setFormData((prev) => ({
        ...prev,
        [name]: cleaned
      }));
      setErrors((prev) => ({
        ...prev,
        [name]: ""
      }));
      return;
    }
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: ""
    }));
  };
  const handlePaymentModeChange = (e) => {
    const mode = e.target.value;
    setFormData((prev) => ({
      ...prev,
      pay_type: mode,
      transaction_id: mode === "cash" ? "" : prev.transaction_id,
      ...mode !== "cheque" && { cheque_number: "", cheque_date: "", cheque_bank_name: "", cheque_bank_branch: "" }
    }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!formData.user_id) newErrors.customer = "Please select a customer";
    if (!selectedGroupTickets || selectedGroupTickets.length === 0) {
      newErrors.group_ticket = "Please select at least one group/ticket";
    }
    if (!formData.pay_date) newErrors.pay_date = "Payment date is required";
    if (!formData.pay_for) newErrors.pay_for = "Please select a payment reason";
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    } else if (!userAccountInfo) {
      newErrors.amount = "Unable to verify balance. Please refresh or select customer again.";
    } else if (amount > userAccountInfo.balance) {
      newErrors.amount = `Amount cannot exceed available balance of ₹${userAccountInfo.balance.toLocaleString()}`;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    const admin = JSON.parse(localStorage.getItem("user") || "{}");
    const payload = {
      user_id: formData.user_id,
      payment_group_tickets: selectedGroupTickets,
      pay_date: formData.pay_date,
      amount: parseFloat(formData.amount),
      pay_type: formData.pay_type,
      pay_for: formData.pay_for,
      admin_id: admin._id,
      admin_type: admin._id,
      transaction_id: formData.transaction_id || null,
      remarks: formData.remarks || null,
      account_type: formData.account_type || "savings",
      service_charge: serviceCharge.toString(),
      gst_amount: gstAmount.toString(),
      ...formData.pay_type === "cheque" && {
        cheque_number: formData.cheque_number,
        cheque_date: formData.cheque_date,
        cheque_bank_name: formData.cheque_bank_name,
        cheque_bank_branch: formData.cheque_bank_branch
      }
    };
    setOpenBackdropLoader(true);
    try {
      await api.post("v1/admin/user-accounts/payin", payload);
      if (onSuccess) onSuccess();
      onClose();
    } catch (error) {
      console.error(error);
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Processing Transfer..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
      lineNumber: 337,
      columnNumber: 36
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-6 max-h-[80vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold mb-4 border-b pb-2 flex items-center justify-between", children: /* @__PURE__ */ jsxDEV("span", { children: "Chit Transfer Payment" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
        lineNumber: 341,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
        lineNumber: 340,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "From  Customer ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 360,
                columnNumber: 48
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 359,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select or search customer",
                showSearch: true,
                size: "large",
                className: "w-full",
                filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                value: formData.user_id || void 0,
                onChange: handleCustomer,
                options: users.map((u) => ({
                  value: u._id,
                  label: `${u.full_name} | ${u.phone_number}`
                }))
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 362,
                columnNumber: 29
              },
              this
            ),
            errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 377,
              columnNumber: 49
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 358,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "To Group & Ticket ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 382,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 381,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                mode: "multiple",
                placeholder: "Select one or more groups, pigmy, or loans",
                disabled: enrollmentLoading || (userAccountInfo?.balance || 0) <= 0,
                loading: enrollmentLoading,
                size: "large",
                className: "w-full",
                value: selectedGroupTickets,
                onChange: (values) => {
                  setSelectedGroupTickets(values);
                  setErrors((prev) => ({ ...prev, group_ticket: void 0 }));
                },
                children: [
                  filteredEnrollments.map((entry) => {
                    const groupId = entry.enrollment.group._id;
                    const ticket = entry.enrollment.tickets;
                    const value = `chit-${groupId}|${ticket}`;
                    const label = `${entry.enrollment.group.group_name} | ${ticket}`;
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value, children: label }, value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 403,
                      columnNumber: 26
                    }, this);
                  }),
                  pigmeCustomers?.map((pigme) => {
                    const value = `pigme-${pigme._id}`;
                    const label = `${pigme.pigme_id} | ₹ ${pigme.payable_amount}`;
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value, children: label }, value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 409,
                      columnNumber: 26
                    }, this);
                  }),
                  borrowers?.map((borrower) => {
                    const value = `loan-${borrower._id}`;
                    const label = `loan-${borrower.loan_id} | ₹ ${borrower.loan_amount}`;
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value, children: label }, value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 415,
                      columnNumber: 26
                    }, this);
                  })
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 384,
                columnNumber: 29
              },
              this
            ),
            errors.group_ticket && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.group_ticket }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 418,
              columnNumber: 53
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 380,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-indigo-50 border border-indigo-200 rounded-lg p-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "Pay For (Reason) ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 423,
                columnNumber: 50
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 422,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                name: "pay_for",
                value: formData.pay_for,
                onChange: handleChange,
                className: "w-full px-4 py-2 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-indigo-400",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Payment Reason" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 432,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Chit Cancellation / Transfer", children: "Chit Cancellation" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 433,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Chit Close / Transfer", children: "Chit Close" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 434,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Pigmy Close / Transfer", children: "Pigmy Close" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 435,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Loan Close / Transfer", children: "Loan Close" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 436,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 426,
                columnNumber: 29
              },
              this
            ),
            errors.pay_for && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_for }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 440,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 421,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 357,
          columnNumber: 21
        }, this),
        userAccountInfo?.balance > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 border border-green-200 rounded-xl p-5 shadow-sm relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 right-4", children: selectedUserId && transactionHistory.length > 0 && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowTxnDrawer(true),
              className: "flex items-center gap-1.5 text-xs font-medium bg-white hover:bg-green-100 text-blue-700 px-3 py-1.5 rounded-lg border border-blue-200 shadow-sm transition",
              children: [
                /* @__PURE__ */ jsxDEV(FaHistory, { className: "text-blue-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 458,
                  columnNumber: 41
                }, this),
                "View History"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 453,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 451,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pr-28", children: [
            " ",
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium uppercase tracking-wide text-gray-500", children: "Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 468,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: userAccountInfo.full_name || userAccountInfo?.userDetails?.full_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 471,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 467,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Available Balance" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 477,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-extrabold text-green-700", children: [
                "₹ ",
                Number(userAccountInfo.balance).toLocaleString()
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 480,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 476,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 466,
            columnNumber: 29
          }, this),
          loadingTransaction && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 border-t border-green-200 pt-4 flex items-center justify-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 526,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Loading transaction details..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 527,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 525,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 449,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-6 border border-gray-200 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-bold text-gray-800 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-6 bg-blue-600 rounded-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 537,
              columnNumber: 29
            }, this),
            " Payment Details"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 536,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                "Payment Date ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 542,
                  columnNumber: 50
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 541,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  name: "pay_date",
                  value: formData.pay_date,
                  onChange: handleChange,
                  disabled: !modifyPayment,
                  min: modifyMinMaxPaymentDate ? yesterday : void 0,
                  max: modifyMinMaxPaymentDate ? today : void 0,
                  className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 544,
                  columnNumber: 33
                },
                this
              ),
              errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 554,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 540,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                "Transfer Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 558,
                  columnNumber: 53
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 557,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "amount",
                  value: formData.amount,
                  onChange: handleChange,
                  placeholder: "Enter amount",
                  className: "w-full px-4 py-2 border border-gray-300 rounded-lg bg-blue-50 font-medium text-blue-800"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 560,
                  columnNumber: 33
                },
                this
              ),
              errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 568,
                columnNumber: 51
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 mt-1", children: numberToIndianWords(formData.amount) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 569,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 556,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Remarks (optional)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 572,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  name: "remarks",
                  value: formData.remarks,
                  onChange: handleChange,
                  rows: 2,
                  placeholder: "Additional remarks (e.g., reason for cancellation)",
                  className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 573,
                  columnNumber: 33
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 571,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 539,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Payment Mode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 587,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: formData.pay_type,
                onChange: handlePaymentModeChange,
                className: "w-full px-4 py-2 border border-gray-300 rounded-lg",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 595,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Bank Transfer", children: "Bank Transfer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 596,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "online/upi", children: "Online / UPI" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 597,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 598,
                    columnNumber: 37
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 590,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 586,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 585,
            columnNumber: 25
          }, this),
          (formData.pay_type === "online" || formData.pay_type === "online/upi") && /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
              "Transaction ID ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 607,
                columnNumber: 52
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 606,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "transaction_id",
                value: formData.transaction_id,
                onChange: handleChange,
                placeholder: "Enter Transaction ID",
                className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 609,
                columnNumber: 33
              },
              this
            ),
            errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 617,
              columnNumber: 59
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 605,
            columnNumber: 13
          }, this),
          formData.pay_type === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200 space-y-4", children: [
            /* @__PURE__ */ jsxDEV("h5", { className: "text-base font-semibold text-gray-900", children: "Cheque Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 624,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                  "Cheque Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 628,
                    columnNumber: 59
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 627,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "cheque_number",
                    value: formData.cheque_number,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 630,
                    columnNumber: 41
                  },
                  this
                ),
                errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 637,
                  columnNumber: 66
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 626,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: [
                  "Cheque Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 641,
                    columnNumber: 57
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 640,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "cheque_date",
                    value: formData.cheque_date,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 643,
                    columnNumber: 41
                  },
                  this
                ),
                errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 650,
                  columnNumber: 64
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 639,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Bank Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 653,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "cheque_bank_name",
                    value: formData.cheque_bank_name,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 654,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 652,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Bank Branch" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 663,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "cheque_bank_branch",
                    value: formData.cheque_bank_branch,
                    onChange: handleChange,
                    className: "w-full px-4 py-2 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 664,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 662,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 625,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 623,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 535,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4 border border-gray-200 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { className: "text-green-500 text-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 680,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: "WhatsApp Notification" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 681,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 679,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                checked: whatsappEnable,
                onChange: (e) => setWhatsappEnable(e.target.checked),
                className: "w-5 h-5 text-green-500 rounded"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                lineNumber: 684,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Send via WhatsApp" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 690,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 683,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 678,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 pt-4 border-t border-gray-200", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "px-4 py-2 text-sm text-gray-500 hover:bg-gray-100 rounded",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 696,
              columnNumber: 25
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: (userAccountInfo?.balance || 0) <= 0,
              className: "px-6 py-2 text-sm bg-blue-600 text-white rounded font-bold hover:bg-blue-700 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed",
              title: (userAccountInfo?.balance || 0) <= 0 ? "Customer has no available balance" : "Save Payment",
              children: "Save Payment"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 703,
              columnNumber: 25
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 695,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
        lineNumber: 355,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
      lineNumber: 339,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-blue-100 rounded-xl", children: /* @__PURE__ */ jsxDEV(FaHistory, { className: "text-blue-600 text-sm" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 724,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 723,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 leading-tight", children: "Transaction History" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 727,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 font-medium", children: [
              transactionHistory.length,
              " record",
              transactionHistory.length !== 1 ? "s" : "",
              " found"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 730,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 726,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 722,
          columnNumber: 9
        }, this),
        placement: "right",
        open: showTxnDrawer,
        onClose: () => setShowTxnDrawer(false),
        width: 620,
        closable: false,
        className: "transaction-drawer",
        styles: {
          body: { padding: "0", background: "#f8fafc" },
          header: {
            padding: "20px 24px",
            borderBottom: "1px solid #e2e8f0",
            background: "#ffffff"
          }
        },
        extra: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowTxnDrawer(false),
            className: "p-2 rounded-xl hover:bg-gray-100 transition-colors",
            children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-gray-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 756,
              columnNumber: 29
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 755,
              columnNumber: 25
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 751,
            columnNumber: 9
          },
          this
        ),
        children: loadingTransaction ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-64 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 border-3 border-blue-200 border-t-blue-600 rounded-full animate-spin" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 763,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 font-medium", children: "Loading transactions..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 764,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 762,
          columnNumber: 9
        }, this) : transactionHistory.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-64 text-center px-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-8 h-8 text-gray-300", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "1.5", d: "M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 770,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 769,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 768,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-500", children: "No transactions found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 773,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-1", children: "Payment history for this customer will appear here" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
            lineNumber: 774,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 767,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-4 space-y-3", children: transactionHistory.map((txn, idx) => {
          const net = Number(txn.amount);
          const service = Number(txn.service_charge || 0);
          const gst = Number(txn.gst_amount || 0);
          const gross = txn.total_amount || net + service + gst;
          const isCredit = txn.transaction_type?.toLowerCase()?.includes("credit") || txn.transaction_type?.toLowerCase()?.includes("refund") || txn.transaction_type?.toLowerCase()?.includes("receipt");
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: `h-1 w-full ${isCredit ? "bg-gradient-to-r from-emerald-400 to-green-500" : "bg-gradient-to-r from-blue-400 to-indigo-500"}` }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 794,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: `w-8 h-8 rounded-lg flex items-center justify-center ${isCredit ? "bg-emerald-50" : "bg-blue-50"}`, children: isCredit ? /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4 text-emerald-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M7 11l5-5m0 0l5 5m-5-5v12" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 803,
                        columnNumber: 61
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 802,
                        columnNumber: 25
                      }, this) : /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4 text-blue-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 807,
                        columnNumber: 61
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 806,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 800,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-800", children: new Date(txn.transaction_date).toLocaleDateString("en-IN", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric"
                        }) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                          lineNumber: 812,
                          columnNumber: 53
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: new Date(txn.transaction_date).toLocaleTimeString("en-IN", {
                          hour: "2-digit",
                          minute: "2-digit"
                        }) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                          lineNumber: 817,
                          columnNumber: 53
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 811,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 799,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase tracking-wider ${isCredit ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-blue-50 text-blue-700 border border-blue-200"}`, children: txn.transaction_type || "Payment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 825,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 798,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4 p-3 bg-slate-50 rounded-xl", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-slate-600", children: (txn.enroll_id?.user_id?.full_name || userAccountInfo?.full_name || "N/A").charAt(0)?.toUpperCase() }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 836,
                      columnNumber: 49
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 835,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 truncate", children: txn.enroll_id?.user_id?.full_name || userAccountInfo?.full_name || "N/A" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 842,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-0.5", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-500 truncate", children: txn.enroll_id?.group_id?.group_name ? txn.enroll_id.group_id.group_name : "N/A" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                          lineNumber: 846,
                          columnNumber: 53
                        }, this),
                        txn.enroll_id?.tickets && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-300", children: "·" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                            lineNumber: 853,
                            columnNumber: 61
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded", children: [
                            "Tkt ",
                            txn.enroll_id.tickets
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                            lineNumber: 854,
                            columnNumber: 61
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                          lineNumber: 852,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 845,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 841,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 834,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-2 mb-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-2.5 text-center", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1", children: "Gross" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 866,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: [
                        "₹",
                        gross.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 867,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 865,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-2.5 text-center", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1", children: "Service" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 872,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: [
                        "₹",
                        service.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 873,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 871,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-2.5 text-center", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1", children: "GST" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 878,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: [
                        "₹",
                        gst.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 879,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 877,
                      columnNumber: 45
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: `rounded-xl p-2.5 text-center ${isCredit ? "bg-emerald-50" : "bg-blue-50"}`, children: [
                      /* @__PURE__ */ jsxDEV("p", { className: `text-[10px] font-semibold uppercase tracking-wider mb-1 ${isCredit ? "text-emerald-500" : "text-blue-500"}`, children: "Net" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 884,
                        columnNumber: 49
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: `text-base font-extrabold ${isCredit ? "text-emerald-700" : "text-blue-700"}`, children: [
                        "₹",
                        net.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 885,
                        columnNumber: 49
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 883,
                      columnNumber: 45
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 864,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 pt-3 border-t border-gray-100", children: [
                    txn.reason && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5", children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-3 h-3 text-amber-500 flex-shrink-0", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 896,
                        columnNumber: 57
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 895,
                        columnNumber: 53
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-amber-700", children: txn.reason }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 898,
                        columnNumber: 53
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 894,
                      columnNumber: 21
                    }, this),
                    txn.pay_type && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5", children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-3 h-3 text-slate-400 flex-shrink-0", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 904,
                        columnNumber: 57
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 903,
                        columnNumber: 53
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-slate-600", children: txn.pay_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 906,
                        columnNumber: 53
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 902,
                      columnNumber: 21
                    }, this),
                    txn.note && /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-1.5 bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 w-full", children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-3 h-3 text-gray-400 flex-shrink-0 mt-0.5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 912,
                        columnNumber: 57
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 911,
                        columnNumber: 53
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-600 italic leading-relaxed", children: txn.note }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                        lineNumber: 914,
                        columnNumber: 53
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                      lineNumber: 910,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                    lineNumber: 892,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
                  lineNumber: 796,
                  columnNumber: 37
                }, this)
              ]
            },
            txn._id || idx,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
              lineNumber: 789,
              columnNumber: 15
            },
            this
          );
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
          lineNumber: 777,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
        lineNumber: 720,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx",
    lineNumber: 336,
    columnNumber: 5
  }, this);
};
_s(ChitTransferPaymentForm, "QaKryUCFyMZvpc5Nc9LmdbBgTaA=");
_c = ChitTransferPaymentForm;
export default ChitTransferPaymentForm;
var _c;
$RefreshReg$(_c, "ChitTransferPaymentForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitTransferPaymentForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1ZtQyxTQW1nQnFCLFVBbmdCckI7MkJBaFZuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxRQUFRQyxNQUFNQyxjQUFjO0FBQ3JDLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsMkJBQTJCO0FBQ3BDLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQyxrQkFBa0JDLGlCQUFpQjtBQUU1QyxNQUFNQywwQkFBMEJBLENBQUMsRUFBRUMsUUFBUUMsZUFBZUMsU0FBU0MsVUFBVSxNQUFNO0FBQUFDLEtBQUE7QUFDL0UsUUFBTUMsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbkQsUUFBTUMsWUFBWSxJQUFJSCxNQUFLLG9CQUFJQSxLQUFLLEdBQUVJLFNBQVEsb0JBQUlKLEtBQUssR0FBRUssUUFBUSxJQUFJLENBQUMsQ0FBQyxFQUNsRUosWUFBWSxFQUNaQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBR2pCLFFBQU0sQ0FBQ0ksT0FBT0MsUUFBUSxJQUFJdkIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3dCLHFCQUFxQkMsc0JBQXNCLElBQUl6QixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDMEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTNCLFNBQVNXLGlCQUFpQixFQUFFO0FBQ3hFLFFBQU0sQ0FBQ2lCLGlCQUFpQkMsa0JBQWtCLElBQUk3QixTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDOEIsaUJBQWlCQyxrQkFBa0IsSUFBSS9CLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNnQyxtQkFBbUJDLG9CQUFvQixJQUFJakMsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ2tDLG9CQUFvQkMscUJBQXFCLElBQUluQyxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDb0MsUUFBUUMsU0FBUyxJQUFJckMsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDc0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXZDLFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUN3QyxlQUFlQyxnQkFBZ0IsSUFBSXpDLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUMwQyxXQUFXQyxZQUFZLElBQUkzQyxTQUFTLENBQUM7QUFDNUMsUUFBTSxDQUFDNEMsb0JBQW9CQyxxQkFBcUIsSUFBSTdDLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUM4QyxXQUFXQyxZQUFZLElBQUkvQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDZ0QsZ0JBQWdCQyxpQkFBaUIsSUFBSWpELFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNrRCxzQkFBc0JDLHVCQUF1QixJQUFJbkQsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ29ELGVBQWVDLGdCQUFnQixJQUFJckQsU0FBUztBQUduRCxRQUFNLENBQUNzRCxvQkFBb0JDLHFCQUFxQixJQUFJdkQsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ3dELGVBQWVDLGdCQUFnQixJQUFJekQsU0FBUyxLQUFLO0FBR3hELFFBQU0sQ0FBQzBELGVBQWVDLGdCQUFnQixJQUFJM0QsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzRELHlCQUF5QkMsMEJBQTBCLElBQUk3RCxTQUFTLEtBQUs7QUFFNUVELFlBQVUsTUFBTTtBQUNaLFVBQU0rRCxPQUFPQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLE1BQU0sS0FBSyxJQUFJO0FBQzVELFVBQU1DLFFBQVFMLE1BQU1NLHVCQUF1QkMsc0JBQXNCLENBQUM7QUFDbEUsUUFBSUYsTUFBTUcsaUJBQWlCLE9BQVFYLGtCQUFpQixJQUFJO0FBQ3hELFFBQUlRLE1BQU1JLHlCQUF5QixRQUFRO0FBQ3ZDWix1QkFBaUIsSUFBSTtBQUNyQkUsaUNBQTJCLElBQUk7QUFBQSxJQUNuQztBQUFBLEVBQ0osR0FBRyxFQUFFO0FBR0wsUUFBTSxDQUFDVyxVQUFVQyxXQUFXLElBQUl6RSxTQUFTO0FBQUEsSUFDckMwRSxTQUFTL0QsaUJBQWlCO0FBQUEsSUFDMUJnRSxVQUFVNUQ7QUFBQUEsSUFDVjZELFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLGNBQWM7QUFBQSxJQUNkQyxlQUFlO0FBQUEsSUFDZkMsYUFBYTtBQUFBLElBQ2JDLGtCQUFrQjtBQUFBLElBQ2xCQyxvQkFBb0I7QUFBQSxFQUN4QixDQUFDO0FBR0R2RixZQUFVLE1BQU07QUFDWixVQUFNd0YsYUFBYSxZQUFZO0FBQzNCLFVBQUk7QUFDQSxjQUFNQyxNQUFNLE1BQU1wRixJQUFJcUYsSUFBSSxlQUFlO0FBQ3pDbEUsaUJBQVNpRSxLQUFLRSxNQUFNQSxRQUFRLEVBQUU7QUFBQSxNQUNsQyxRQUFRO0FBQ0puRSxpQkFBUyxFQUFFO0FBQUEsTUFDZjtBQUFBLElBQ0o7QUFDQWdFLGVBQVc7QUFBQSxFQUNmLEdBQUcsRUFBRTtBQUdMeEYsWUFBVSxNQUFNO0FBQ1osUUFBSVksZUFBZTtBQUNmZ0Isd0JBQWtCaEIsYUFBYTtBQUMvQjhELGtCQUFZLENBQUNrQixVQUFVLEVBQUUsR0FBR0EsTUFBTWpCLFNBQVMvRCxjQUFjLEVBQUU7QUFDM0RpRiwyQkFBcUJqRixhQUFhO0FBQ2xDa0YsMkJBQXFCbEYsYUFBYTtBQUFBLElBQ3RDO0FBQUEsRUFDSixHQUFHLENBQUNBLGFBQWEsQ0FBQztBQUdsQixRQUFNaUYsdUJBQXVCLE9BQU9sRixXQUFXO0FBQzNDLFFBQUksQ0FBQ0EsT0FBUTtBQUNicUIsdUJBQW1CLElBQUk7QUFDdkIsUUFBSTtBQUNBLFlBQU0rRCxXQUFXLE1BQU0xRixJQUFJcUYsSUFBSSwyQkFBMkIvRSxNQUFNLEVBQUU7QUFDbEUsVUFBSW9GLFNBQVNKLE1BQU1LLFFBQVE7QUFDdkJsRSwyQkFBbUJpRSxTQUFTSixLQUFLQSxJQUFJO0FBQUEsTUFDekMsT0FBTztBQUNIN0QsMkJBQW1CLElBQUk7QUFBQSxNQUMzQjtBQUFBLElBQ0osUUFBUTtBQUNKQSx5QkFBbUIsSUFBSTtBQUFBLElBQzNCLFVBQUM7QUFDR0UseUJBQW1CLEtBQUs7QUFBQSxJQUM1QjtBQUFBLEVBQ0o7QUFHQSxRQUFNOEQsdUJBQXVCLE9BQU9uRixXQUFXO0FBQzNDLFFBQUksQ0FBQ0EsT0FBUTtBQUNidUIseUJBQXFCLElBQUk7QUFDekIsUUFBSTtBQUNBLFlBQU02RCxXQUFXLE1BQU0xRixJQUFJNEYsS0FBSyxtQ0FBbUN0RixNQUFNLEVBQUU7QUFDM0UsWUFBTXVGLFFBQVFILFNBQVNKLEtBQUtRLE9BQU8sQ0FBQUMsU0FBUUEsS0FBS0MsY0FBY0QsS0FBS0MsV0FBV0MsS0FBSztBQUNuRjVFLDZCQUF1QndFLEtBQUs7QUFBQSxJQUNoQyxRQUFRO0FBQ0p4RSw2QkFBdUIsRUFBRTtBQUFBLElBQzdCLFVBQUM7QUFDR1EsMkJBQXFCLEtBQUs7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFFQSxRQUFNcUUsMkJBQTJCQSxDQUFDQyxXQUFXO0FBQ3pDLFFBQUksQ0FBQ0EsT0FBUSxRQUFPO0FBQ3BCLFVBQU1DLFFBQVFELE9BQU9FLFlBQVk7QUFDakMsUUFBSUQsTUFBTUUsU0FBUyxPQUFPLEVBQUcsUUFBTztBQUNwQyxRQUFJRixNQUFNRSxTQUFTLFFBQVEsRUFBRyxRQUFPO0FBQ3JDLFdBQU87QUFBQSxFQUNYO0FBR0EzRyxZQUFVLE1BQU07QUFDWixRQUFJLENBQUMyQixnQkFBZ0I7QUFDakJlLHVCQUFpQixDQUFDO0FBQ2xCRSxtQkFBYSxDQUFDO0FBQ2RZLDRCQUFzQixFQUFFO0FBQ3hCO0FBQUEsSUFDSjtBQUVBLFVBQU1vRCwwQkFBMEIsWUFBWTtBQUN4QzlELDRCQUFzQixJQUFJO0FBQzFCLFVBQUk7QUFDQSxjQUFNMkMsTUFBTSxNQUFNcEYsSUFBSXFGLElBQUksZ0NBQWdDO0FBQzFELGNBQU1tQixlQUFlcEIsSUFBSUUsS0FBS0EsUUFBUTtBQUV0QyxjQUFNbUIsbUJBQW1CRCxhQUFhVjtBQUFBQSxVQUNsQyxDQUFDWSxRQUFRQSxJQUFJQyxXQUFXckMsU0FBU3NDLFFBQVF0RjtBQUFBQSxRQUM3QztBQUVBNkIsOEJBQXNCc0QsZ0JBQWdCO0FBRXRDLFlBQUlBLGlCQUFpQkksU0FBUyxHQUFHO0FBQzdCLGdCQUFNQyxTQUFTTCxpQkFBaUJNO0FBQUFBLFlBQzVCLENBQUNDLEdBQUdDLE1BQU0sSUFBSXJHLEtBQUtxRyxFQUFFQyxnQkFBZ0IsSUFBSSxJQUFJdEcsS0FBS29HLEVBQUVFLGdCQUFnQjtBQUFBLFVBQ3hFO0FBQ0EsZ0JBQU1DLFNBQVNMLE9BQU8sQ0FBQztBQUN2QjdELDJCQUFpQmtFLFFBQVFSLFdBQVdTLGNBQWM7QUFDbEQvRSwyQkFBaUI4RSxPQUFPRSxrQkFBa0IsQ0FBQztBQUMzQzlFLHVCQUFhNEUsT0FBT0csY0FBYyxDQUFDO0FBQUEsUUFDdkMsT0FBTztBQUNIakYsMkJBQWlCLENBQUM7QUFDbEJFLHVCQUFhLENBQUM7QUFBQSxRQUNsQjtBQUFBLE1BQ0osU0FBU2dGLE9BQU87QUFDWkMsZ0JBQVFELE1BQU0sdUNBQXVDQSxLQUFLO0FBQzFEbEYseUJBQWlCLENBQUM7QUFDbEJFLHFCQUFhLENBQUM7QUFDZFksOEJBQXNCLEVBQUU7QUFBQSxNQUM1QixVQUFDO0FBQ0dWLDhCQUFzQixLQUFLO0FBQUEsTUFDL0I7QUFBQSxJQUNKO0FBRUE4RCw0QkFBd0I7QUFBQSxFQUM1QixHQUFHLENBQUNqRixjQUFjLENBQUM7QUFHbkIzQixZQUFVLE1BQU07QUFDWixRQUFJLENBQUMyQixnQkFBZ0I7QUFDakJxQixtQkFBYSxFQUFFO0FBQ2ZFLHdCQUFrQixFQUFFO0FBQ3BCO0FBQUEsSUFDSjtBQUNBLFVBQU00RSwyQkFBMkIsWUFBWTtBQUN6QyxVQUFJO0FBQ0EsY0FBTS9CLFdBQVcsTUFBTTFGLElBQUlxRixJQUFJLGtDQUFrQy9ELGNBQWMsRUFBRTtBQUNqRnFCLHFCQUFhK0MsU0FBU0osSUFBSTtBQUFBLE1BQzlCLFFBQVE7QUFDSjNDLHFCQUFhLEVBQUU7QUFBQSxNQUNuQjtBQUFBLElBQ0o7QUFDQSxVQUFNK0Usb0JBQW9CLFlBQVk7QUFDbEMsVUFBSTtBQUNBLGNBQU1oQyxXQUFXLE1BQU0xRixJQUFJcUYsSUFBSSx3Q0FBd0MvRCxjQUFjLEVBQUU7QUFDdkZ1QiwwQkFBa0I2QyxTQUFTSixJQUFJO0FBQUEsTUFDbkMsUUFBUTtBQUNKekMsMEJBQWtCLEVBQUU7QUFBQSxNQUN4QjtBQUFBLElBQ0o7QUFDQTRFLDZCQUF5QjtBQUN6QkMsc0JBQWtCO0FBQUEsRUFDdEIsR0FBRyxDQUFDcEcsY0FBYyxDQUFDO0FBR25CM0IsWUFBVSxNQUFNO0FBQ1osUUFBSSxDQUFDMkIsZUFBZ0I7QUFDckIsVUFBTXFHLGFBQWE7QUFBQSxNQUNmLEdBQUd2RyxvQkFBb0J3RyxJQUFJLENBQUFDLFVBQVMsUUFBUUEsTUFBTTdCLFdBQVdDLE1BQU1XLEdBQUcsSUFBSWlCLE1BQU03QixXQUFXOEIsT0FBTyxFQUFFO0FBQUEsTUFDcEcsR0FBR2xGLGVBQWVnRixJQUFJLENBQUFHLFVBQVMsU0FBU0EsTUFBTW5CLEdBQUcsRUFBRTtBQUFBLE1BQ25ELEdBQUdsRSxVQUFVa0YsSUFBSSxDQUFBSSxhQUFZLFFBQVFBLFNBQVNwQixHQUFHLEVBQUU7QUFBQSxJQUFDO0FBRXhELFFBQUllLFdBQVdkLFNBQVMsR0FBRztBQUN2QjlELDhCQUF3QjRFLFVBQVU7QUFDbEMxRixnQkFBVSxDQUFBc0QsVUFBUyxFQUFFLEdBQUdBLE1BQU0wQyxjQUFjQyxPQUFVLEVBQUU7QUFBQSxJQUM1RDtBQUFBLEVBQ0osR0FBRyxDQUFDOUcscUJBQXFCd0IsZ0JBQWdCRixXQUFXcEIsY0FBYyxDQUFDO0FBR25FLFFBQU02RyxpQkFBaUJBLENBQUM3SCxXQUFXO0FBQy9CaUIsc0JBQWtCakIsTUFBTTtBQUN4QitELGdCQUFZLENBQUNrQixVQUFVLEVBQUUsR0FBR0EsTUFBTWpCLFNBQVNoRSxPQUFPLEVBQUU7QUFDcEQyQixjQUFVLENBQUNzRCxVQUFVLEVBQUUsR0FBR0EsTUFBTTZDLFVBQVUsR0FBRyxFQUFFO0FBQy9DckYsNEJBQXdCLEVBQUU7QUFDMUJWLHFCQUFpQixDQUFDO0FBQ2xCRSxpQkFBYSxDQUFDO0FBQ2RZLDBCQUFzQixFQUFFO0FBQUEsRUFDNUI7QUFFQSxRQUFNa0YsZUFBZUEsQ0FBQ0MsTUFBTTtBQUN4QixVQUFNLEVBQUVDLE1BQU1DLE1BQU0sSUFBSUYsRUFBRUc7QUFFMUIsUUFBSUYsU0FBUyxVQUFVO0FBQ25CLFVBQUlHLFVBQVVGLE1BQU1HLFFBQVEsWUFBWSxFQUFFO0FBQzFDLFdBQUtELFFBQVFFLE1BQU0sS0FBSyxLQUFLLElBQUkvQixTQUFTLEVBQUc7QUFFN0N4QyxrQkFBWSxDQUFBa0IsVUFBUztBQUFBLFFBQ2pCLEdBQUdBO0FBQUFBLFFBQ0gsQ0FBQ2dELElBQUksR0FBR0c7QUFBQUEsTUFDWixFQUFFO0FBRUZ6RyxnQkFBVSxDQUFBc0QsVUFBUztBQUFBLFFBQ2YsR0FBR0E7QUFBQUEsUUFDSCxDQUFDZ0QsSUFBSSxHQUFHO0FBQUEsTUFDWixFQUFFO0FBQ0Y7QUFBQSxJQUNKO0FBRUFsRSxnQkFBWSxDQUFBa0IsVUFBUztBQUFBLE1BQ2pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2dELElBQUksR0FBR0M7QUFBQUEsSUFDWixFQUFFO0FBRUZ2RyxjQUFVLENBQUFzRCxVQUFTO0FBQUEsTUFDZixHQUFHQTtBQUFBQSxNQUNILENBQUNnRCxJQUFJLEdBQUc7QUFBQSxJQUNaLEVBQUU7QUFBQSxFQUNOO0FBRUEsUUFBTU0sMEJBQTBCQSxDQUFDUCxNQUFNO0FBQ25DLFVBQU1RLE9BQU9SLEVBQUVHLE9BQU9EO0FBQ3RCbkUsZ0JBQVksQ0FBQWtCLFVBQVM7QUFBQSxNQUNqQixHQUFHQTtBQUFBQSxNQUNIZCxVQUFVcUU7QUFBQUEsTUFDVm5FLGdCQUFnQm1FLFNBQVMsU0FBUyxLQUFLdkQsS0FBS1o7QUFBQUEsTUFDNUMsR0FBSW1FLFNBQVMsWUFBWSxFQUFFL0QsZUFBZSxJQUFJQyxhQUFhLElBQUlDLGtCQUFrQixJQUFJQyxvQkFBb0IsR0FBRztBQUFBLElBQ2hILEVBQUU7QUFBQSxFQUNOO0FBR0EsUUFBTTZELGVBQWVBLE1BQU07QUFDdkIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQzVFLFNBQVNFLFFBQVMwRSxXQUFVWixXQUFXO0FBQzVDLFFBQUksQ0FBQ3RGLHdCQUF3QkEscUJBQXFCK0QsV0FBVyxHQUFHO0FBQzVEbUMsZ0JBQVVmLGVBQWU7QUFBQSxJQUM3QjtBQUNBLFFBQUksQ0FBQzdELFNBQVNHLFNBQVV5RSxXQUFVekUsV0FBVztBQUM3QyxRQUFJLENBQUNILFNBQVNNLFFBQVNzRSxXQUFVdEUsVUFBVTtBQUUzQyxVQUFNRixTQUFTeUUsV0FBVzdFLFNBQVNJLE1BQU07QUFDekMsUUFBSTBFLE1BQU0xRSxNQUFNLEtBQUtBLFVBQVUsR0FBRztBQUM5QndFLGdCQUFVeEUsU0FBUztBQUFBLElBQ3ZCLFdBQVcsQ0FBQ2hELGlCQUFpQjtBQUN6QndILGdCQUFVeEUsU0FBUztBQUFBLElBQ3ZCLFdBQVdBLFNBQVNoRCxnQkFBZ0IySCxTQUFTO0FBQ3pDSCxnQkFBVXhFLFNBQVMsOENBQThDaEQsZ0JBQWdCMkgsUUFBUUMsZUFBZSxDQUFDO0FBQUEsSUFDN0c7QUFFQW5ILGNBQVUrRyxTQUFTO0FBQ25CLFdBQU9LLE9BQU9DLEtBQUtOLFNBQVMsRUFBRW5DLFdBQVc7QUFBQSxFQUM3QztBQUdBLFFBQU0wQyxlQUFlLE9BQU9qQixNQUFNO0FBQzlCQSxNQUFFa0IsZUFBZTtBQUNqQixRQUFJLENBQUNULGFBQWEsRUFBRztBQUVyQixVQUFNVSxRQUFROUYsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxNQUFNLEtBQUssSUFBSTtBQUU3RCxVQUFNNEYsVUFBVTtBQUFBLE1BQ1pwRixTQUFTRixTQUFTRTtBQUFBQSxNQUNsQnFGLHVCQUF1QjdHO0FBQUFBLE1BQ3ZCeUIsVUFBVUgsU0FBU0c7QUFBQUEsTUFDbkJDLFFBQVF5RSxXQUFXN0UsU0FBU0ksTUFBTTtBQUFBLE1BQ2xDQyxVQUFVTCxTQUFTSztBQUFBQSxNQUNuQkMsU0FBU04sU0FBU007QUFBQUEsTUFDbEJrRixVQUFVSCxNQUFNN0M7QUFBQUEsTUFDaEJoQyxZQUFZNkUsTUFBTTdDO0FBQUFBLE1BQ2xCakMsZ0JBQWdCUCxTQUFTTyxrQkFBa0I7QUFBQSxNQUMzQ0UsU0FBU1QsU0FBU1MsV0FBVztBQUFBLE1BQzdCQyxjQUFjVixTQUFTVSxnQkFBZ0I7QUFBQSxNQUN2Q3VDLGdCQUFnQmpGLGNBQWN5SCxTQUFTO0FBQUEsTUFDdkN2QyxZQUFZaEYsVUFBVXVILFNBQVM7QUFBQSxNQUMvQixHQUFJekYsU0FBU0ssYUFBYSxZQUFZO0FBQUEsUUFDbENNLGVBQWVYLFNBQVNXO0FBQUFBLFFBQ3hCQyxhQUFhWixTQUFTWTtBQUFBQSxRQUN0QkMsa0JBQWtCYixTQUFTYTtBQUFBQSxRQUMzQkMsb0JBQW9CZCxTQUFTYztBQUFBQSxNQUNqQztBQUFBLElBQ0o7QUFFQW5ELDBCQUFzQixJQUFJO0FBQzFCLFFBQUk7QUFDQSxZQUFNL0IsSUFBSTRGLEtBQUssZ0NBQWdDOEQsT0FBTztBQUN0RCxVQUFJakosVUFBV0EsV0FBVTtBQUN6QkQsY0FBUTtBQUFBLElBQ1osU0FBUytHLE9BQU87QUFDWkMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBRXZCLFVBQUM7QUFDR3hGLDRCQUFzQixLQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUNKO0FBRUEsU0FDSSxtQ0FDS0Q7QUFBQUEsMEJBQXNCLHVCQUFDLHNCQUFtQixPQUFNLDRCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtEO0FBQUEsSUFFekUsdUJBQUMsU0FBSSxXQUFVLG9DQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDBFQUNWLGlDQUFDLFVBQUsscUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBLHVCQUFDLFVBQUssVUFBVXlILGNBQWMsV0FBVSxhQUVwQztBQUFBLCtCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLGlDQUFDLFNBQ0c7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxjQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixjQUFjLENBQUNPLE9BQU9DLFdBQ2xCQSxRQUFRQyxPQUFPM0QsWUFBWSxFQUFFQyxTQUFTd0QsTUFBTXpELFlBQVksQ0FBQztBQUFBLGdCQUU3RCxPQUFPakMsU0FBU0UsV0FBVzREO0FBQUFBLGdCQUMzQixVQUFVQztBQUFBQSxnQkFDVixTQUFTakgsTUFBTTBHLElBQUksQ0FBQ3FDLE9BQU87QUFBQSxrQkFDdkJ6QixPQUFPeUIsRUFBRXJEO0FBQUFBLGtCQUNUb0QsT0FBTyxHQUFHQyxFQUFFQyxTQUFTLE1BQU1ELEVBQUVFLFlBQVk7QUFBQSxnQkFDN0MsRUFBRTtBQUFBO0FBQUEsY0FiTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhUTtBQUFBLFlBRVBuSSxPQUFPb0csWUFBWSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCcEcsaUJBQU9vRyxZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLGVBbkJsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUEsdUJBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGNBQzVDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLFVBQVV4RyxzQkFBc0JKLGlCQUFpQjJILFdBQVcsTUFBTTtBQUFBLGdCQUNsRSxTQUFTdkg7QUFBQUEsZ0JBQ1QsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFPa0I7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDc0gsV0FBVztBQUNsQnJILDBDQUF3QnFILE1BQU07QUFDOUJuSSw0QkFBVSxDQUFBc0QsVUFBUyxFQUFFLEdBQUdBLE1BQU0wQyxjQUFjQyxPQUFVLEVBQUU7QUFBQSxnQkFDNUQ7QUFBQSxnQkFHQzlHO0FBQUFBLHNDQUFvQndHLElBQUksQ0FBQUMsVUFBUztBQUM5QiwwQkFBTXdDLFVBQVV4QyxNQUFNN0IsV0FBV0MsTUFBTVc7QUFDdkMsMEJBQU0wRCxTQUFTekMsTUFBTTdCLFdBQVc4QjtBQUNoQywwQkFBTVUsUUFBUSxRQUFRNkIsT0FBTyxJQUFJQyxNQUFNO0FBQ3ZDLDBCQUFNTixRQUFRLEdBQUduQyxNQUFNN0IsV0FBV0MsTUFBTXNFLFVBQVUsTUFBTUQsTUFBTTtBQUM5RCwyQkFBTyx1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBZU4sbUJBQXRCeEIsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0Q7QUFBQSxrQkFDM0QsQ0FBQztBQUFBLGtCQUVBNUYsZ0JBQWdCZ0YsSUFBSSxDQUFBRyxVQUFTO0FBQzFCLDBCQUFNUyxRQUFRLFNBQVNULE1BQU1uQixHQUFHO0FBQ2hDLDBCQUFNb0QsUUFBUSxHQUFHakMsTUFBTXlDLFFBQVEsUUFBUXpDLE1BQU0wQyxjQUFjO0FBQzNELDJCQUFPLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFlVCxtQkFBdEJ4QixPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLGtCQUMzRCxDQUFDO0FBQUEsa0JBRUE5RixXQUFXa0YsSUFBSSxDQUFBSSxhQUFZO0FBQ3hCLDBCQUFNUSxRQUFRLFFBQVFSLFNBQVNwQixHQUFHO0FBQ2xDLDBCQUFNb0QsUUFBUSxRQUFRaEMsU0FBUzBDLE9BQU8sUUFBUTFDLFNBQVMyQyxXQUFXO0FBQ2xFLDJCQUFPLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFlWCxtQkFBdEJ4QixPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLGtCQUMzRCxDQUFDO0FBQUE7QUFBQTtBQUFBLGNBaENMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlDQTtBQUFBLFlBQ0N4RyxPQUFPaUcsZ0JBQWdCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJqRyxpQkFBT2lHLGdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLGVBdEMxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVDQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsY0FDN0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxPQUFPN0QsU0FBU007QUFBQUEsZ0JBQ2hCLFVBQVUyRDtBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sSUFBRyxxQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDdEMsdUJBQUMsWUFBTyxPQUFNLGdDQUErQixpQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEQ7QUFBQSxrQkFDOUQsdUJBQUMsWUFBTyxPQUFNLHlCQUF3QiwwQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0Q7QUFBQSxrQkFDaEQsdUJBQUMsWUFBTyxPQUFNLDBCQUF5QiwyQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDbEQsdUJBQUMsWUFBTyxPQUFNLHlCQUF3QiwwQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0Q7QUFBQTtBQUFBO0FBQUEsY0FWcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxZQUVDckcsT0FBTzBDLFdBQ0osdUJBQUMsT0FBRSxXQUFVLDZCQUNSMUMsaUJBQU8wQyxXQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXJCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBdkZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3RkE7QUFBQSxRQUdDbEQsaUJBQWlCMkgsVUFBVSxLQUN4Qix1QkFBQyxTQUFJLFdBQVUseUVBRVg7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEJBQ1Y3SCw0QkFBa0I0QixtQkFBbUIyRCxTQUFTLEtBQzNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU14RCxpQkFBaUIsSUFBSTtBQUFBLGNBQ3BDLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsYUFBVSxXQUFVLG1CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBTDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BLEtBVFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBSUEsdUJBQUMsU0FBSSxXQUFVLDJDQUEwQztBQUFBO0FBQUEsWUFDckQsdUJBQUMsU0FDRztBQUFBLHFDQUFDLE9BQUUsV0FBVSw2REFBNEQsd0JBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtQ0FDUjdCLDBCQUFnQjBJLGFBQWExSSxpQkFBaUJvSixhQUFhVixhQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQSxxQ0FBQyxPQUFFLFdBQVUscUNBQW9DLGlDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsMENBQXlDO0FBQUE7QUFBQSxnQkFDL0NXLE9BQU9ySixnQkFBZ0IySCxPQUFPLEVBQUVDLGVBQWU7QUFBQSxtQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBd0NDNUcsc0JBQ0csdUJBQUMsU0FBSSxXQUFVLDhFQUNYO0FBQUEsbUNBQUMsUUFBSyxNQUFLLFdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0I7QUFBQSxZQUNsQix1QkFBQyxVQUFLLFdBQVUseUJBQXdCLDhDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFqRlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1GQTtBQUFBLFFBR0osdUJBQUMsU0FBSSxXQUFVLDhEQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJEQUNWO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQUc7QUFBQSxlQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSxtQ0FBQyxTQUNHO0FBQUEscUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsZ0JBQ2pELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPNEIsU0FBU0c7QUFBQUEsa0JBQ2hCLFVBQVU4RDtBQUFBQSxrQkFDVixVQUFVLENBQUMvRTtBQUFBQSxrQkFDWCxLQUFLRSwwQkFBMEJ6QyxZQUFZbUg7QUFBQUEsa0JBQzNDLEtBQUsxRSwwQkFBMEI3QyxRQUFRdUg7QUFBQUEsa0JBQ3ZDLFdBQVU7QUFBQTtBQUFBLGdCQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFtRztBQUFBLGNBRWxHbEcsT0FBT3VDLFlBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnZDLGlCQUFPdUMsWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxpQkFkbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBQ0EsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGdCQUM5Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT0gsU0FBU0k7QUFBQUEsa0JBQ2hCLFVBQVU2RDtBQUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBO0FBQUEsZ0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXVHO0FBQUEsY0FFdEdyRyxPQUFPd0MsVUFBVSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCeEMsaUJBQU93QyxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQzFFLHVCQUFDLFNBQUksV0FBVSw4QkFBOEJ2RSw4QkFBb0JtRSxTQUFTSSxNQUFNLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsaUJBYnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLHFDQUFDLFdBQU0sV0FBVSxrREFBaUQsa0NBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsY0FDcEY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLE9BQU9KLFNBQVNTO0FBQUFBLGtCQUNoQixVQUFVd0Q7QUFBQUEsa0JBQ1YsTUFBTTtBQUFBLGtCQUNOLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNa0U7QUFBQSxpQkFSdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkNBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1gsaUNBQUMsU0FDRztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsNEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csT0FBT2pFLFNBQVNLO0FBQUFBLGdCQUNoQixVQUFVb0U7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlCO0FBQUEsa0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxpQkFBZ0IsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEsa0JBQzNDLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLGtCQUN2Qyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQTtBQUFBO0FBQUEsY0FSakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0EsS0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFdBR0V6RSxTQUFTSyxhQUFhLFlBQVlMLFNBQVNLLGFBQWEsaUJBQ3RELHVCQUFDLFNBQUksV0FBVSxpQ0FDWDtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGNBQy9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9MLFNBQVNPO0FBQUFBLGdCQUNoQixVQUFVMEQ7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTWtFO0FBQUEsWUFFakVyRyxPQUFPMkMsa0JBQWtCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkIzQyxpQkFBTzJDLGtCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLGVBWjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUlIUCxTQUFTSyxhQUFhLFlBQ25CLHVCQUFDLFNBQUksV0FBVSwyQ0FDWDtBQUFBLG1DQUFDLFFBQUcsV0FBVSx5Q0FBd0MsOEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEscUNBQUMsU0FDRztBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUNoRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9MLFNBQVNXO0FBQUFBLG9CQUNoQixVQUFVc0Q7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBO0FBQUEsa0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtrRTtBQUFBLGdCQUVqRXJHLE9BQU8rQyxpQkFBaUIsdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qi9DLGlCQUFPK0MsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsbUJBWDVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0c7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxrQkFDbEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPWCxTQUFTWTtBQUFBQSxvQkFDaEIsVUFBVXFEO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLa0U7QUFBQSxnQkFFakVyRyxPQUFPZ0QsZUFBZSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCaEQsaUJBQU9nRCxlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RDtBQUFBLG1CQVh4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUNHO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGtEQUFpRCx5QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxnQkFDM0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPWixTQUFTYTtBQUFBQSxvQkFDaEIsVUFBVW9EO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLa0U7QUFBQSxtQkFQdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FDRztBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZFO0FBQUEsZ0JBQzdFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2pFLFNBQVNjO0FBQUFBLG9CQUNoQixVQUFVbUQ7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBO0FBQUEsa0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtrRTtBQUFBLG1CQVB0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBOUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsZUFqREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrREE7QUFBQSxhQTFJUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNElBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsb0ZBQ1g7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSxtQ0FBQyxvQkFBaUIsV0FBVSw2QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxVQUFLLFdBQVUsK0JBQThCLHFDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLGVBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSwwQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFNBQVNuRztBQUFBQSxnQkFDVCxVQUFVLENBQUNvRyxNQUFNbkcsa0JBQWtCbUcsRUFBRUcsT0FBT3FDLE9BQU87QUFBQSxnQkFDbkQsV0FBVTtBQUFBO0FBQUEsY0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJOEM7QUFBQSxZQUU5Qyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGlDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLGVBUDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFNBQVN0SztBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUEyRDtBQUFBO0FBQUEsWUFIekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFXZ0IsaUJBQWlCMkgsV0FBVyxNQUFNO0FBQUEsY0FDN0MsV0FBVTtBQUFBLGNBQ1YsUUFDSzNILGlCQUFpQjJILFdBQVcsTUFBTSxJQUM3QixzQ0FDQTtBQUFBLGNBQ1Q7QUFBQTtBQUFBLFlBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxhQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsV0F4V0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlXQTtBQUFBLFNBelhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwWEE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxPQUNJLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLGlDQUFDLFNBQUksV0FBVSw4QkFDWCxpQ0FBQyxhQUFVLFdBQVUsMkJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsbURBQWtELG1DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUseUNBQ1JqRztBQUFBQSxpQ0FBbUIyRDtBQUFBQSxjQUFPO0FBQUEsY0FBUTNELG1CQUFtQjJELFdBQVcsSUFBSSxNQUFNO0FBQUEsY0FBRztBQUFBLGlCQURsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVKLFdBQVU7QUFBQSxRQUNWLE1BQU16RDtBQUFBQSxRQUNOLFNBQVMsTUFBTUMsaUJBQWlCLEtBQUs7QUFBQSxRQUNyQyxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixXQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsVUFDSjBILE1BQU0sRUFBRUMsU0FBUyxLQUFLQyxZQUFZLFVBQVU7QUFBQSxVQUM1Q0MsUUFBUTtBQUFBLFlBQ0pGLFNBQVM7QUFBQSxZQUNURyxjQUFjO0FBQUEsWUFDZEYsWUFBWTtBQUFBLFVBQ2hCO0FBQUEsUUFDSjtBQUFBLFFBQ0EsT0FDSTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csU0FBUyxNQUFNNUgsaUJBQWlCLEtBQUs7QUFBQSxZQUNyQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxTQUFJLFdBQVUseUJBQXdCLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDN0UsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSwwQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkYsS0FEL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBO0FBQUEsVUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBR0hiLCtCQUNHLHVCQUFDLFNBQUksV0FBVSx3REFDWDtBQUFBLGlDQUFDLFNBQUksV0FBVSxrRkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RjtBQUFBLFVBQzdGLHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0MsdUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsYUFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBQ0FVLG1CQUFtQjJELFdBQVcsSUFDOUIsdUJBQUMsU0FBSSxXQUFVLG1FQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJFQUNYLGlDQUFDLFNBQUksV0FBVSx5QkFBd0IsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUM3RSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksT0FBTSxHQUFFLG9JQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1TSxLQUQzTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHVDQUFzQyxxQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGtFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RjtBQUFBLGFBUGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDVjNELDZCQUFtQjBFLElBQUksQ0FBQ2xCLEtBQUswRSxRQUFRO0FBQ2xDLGdCQUFNQyxNQUFNUixPQUFPbkUsSUFBSWxDLE1BQU07QUFDN0IsZ0JBQU04RyxVQUFVVCxPQUFPbkUsSUFBSVcsa0JBQWtCLENBQUM7QUFDOUMsZ0JBQU1rRSxNQUFNVixPQUFPbkUsSUFBSVksY0FBYyxDQUFDO0FBQ3RDLGdCQUFNa0UsUUFBUTlFLElBQUkrRSxnQkFBaUJKLE1BQU1DLFVBQVVDO0FBRW5ELGdCQUFNRyxXQUFXaEYsSUFBSWlGLGtCQUFrQnRGLFlBQVksR0FBR0MsU0FBUyxRQUFRLEtBQ25FSSxJQUFJaUYsa0JBQWtCdEYsWUFBWSxHQUFHQyxTQUFTLFFBQVEsS0FDdERJLElBQUlpRixrQkFBa0J0RixZQUFZLEdBQUdDLFNBQVMsU0FBUztBQUUzRCxpQkFDSTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUcsV0FBVTtBQUFBLGNBR1Y7QUFBQSx1Q0FBQyxTQUFJLFdBQVcsY0FBY29GLFdBQVcsbURBQW1ELDhDQUE4QyxNQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2STtBQUFBLGdCQUU3SSx1QkFBQyxTQUFJLFdBQVUsT0FFWDtBQUFBLHlDQUFDLFNBQUksV0FBVSwwQ0FDWDtBQUFBLDJDQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLDZDQUFDLFNBQUksV0FBVyx1REFBdURBLFdBQVcsa0JBQWtCLFlBQVksSUFDM0dBLHFCQUNHLHVCQUFDLFNBQUksV0FBVSw0QkFBMkIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNoRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLCtCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRyxLQURwRztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQzdFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsd0pBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlOLEtBRDdOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUEsS0FSUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FDRztBQUFBLCtDQUFDLE9BQUUsV0FBVSx1Q0FDUixjQUFJOUssS0FBSzhGLElBQUlRLGdCQUFnQixFQUFFMEUsbUJBQW1CLFNBQVM7QUFBQSwwQkFDeERDLEtBQUs7QUFBQSwwQkFBV0MsT0FBTztBQUFBLDBCQUFTQyxNQUFNO0FBQUEsd0JBQzFDLENBQUMsS0FITDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDZCQUNSLGNBQUluTCxLQUFLOEYsSUFBSVEsZ0JBQWdCLEVBQUU4RSxtQkFBbUIsU0FBUztBQUFBLDBCQUN4REMsTUFBTTtBQUFBLDBCQUFXQyxRQUFRO0FBQUEsd0JBQzdCLENBQUMsS0FITDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsMkJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFXQTtBQUFBLHlCQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXdCQTtBQUFBLG9CQUVBLHVCQUFDLFVBQUssV0FBVyxrR0FBa0dSLFdBQ3pHLDZEQUNBLGlEQUFpRCxJQUV0RGhGLGNBQUlpRixvQkFBb0IsYUFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLHVCQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlDQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSwyREFDWDtBQUFBLDJDQUFDLFNBQUksV0FBVSxxSEFDWCxpQ0FBQyxVQUFLLFdBQVUsb0NBQ1ZqRixlQUFJQyxXQUFXckMsU0FBUzRGLGFBQWExSSxpQkFBaUIwSSxhQUFhLE9BQ2hFaUMsT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ1g7QUFBQSw2Q0FBQyxPQUFFLFdBQVUsZ0RBQ1IxRixjQUFJQyxXQUFXckMsU0FBUzRGLGFBQWExSSxpQkFBaUIwSSxhQUFhLFNBRHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsc0NBQ1h4RCxjQUFJQyxXQUFXMEYsVUFBVTlCLGFBQ3BCN0QsSUFBSUMsVUFBVTBGLFNBQVM5QixhQUN2QixTQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSUE7QUFBQSx3QkFDQzdELElBQUlDLFdBQVdtQixXQUNaLG1DQUNJO0FBQUEsaURBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBaUM7QUFBQSwwQkFDakMsdUJBQUMsVUFBSyxXQUFVLGdGQUErRTtBQUFBO0FBQUEsNEJBQ3RGcEIsSUFBSUMsVUFBVW1CO0FBQUFBLCtCQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsNkJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLDJCQVpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBY0E7QUFBQSx5QkFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSx1QkExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyQkE7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsMkNBQ1g7QUFBQSw2Q0FBQyxPQUFFLFdBQVUseUVBQXdFLHFCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwRjtBQUFBLHNCQUMxRix1QkFBQyxPQUFFLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSx3QkFDekMwRCxNQUFNcEMsZUFBZSxPQUFPO0FBQUEsMkJBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNYO0FBQUEsNkNBQUMsT0FBRSxXQUFVLHlFQUF3RSx1QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEY7QUFBQSxzQkFDNUYsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQztBQUFBO0FBQUEsd0JBQ3pDa0MsUUFBUWxDLGVBQWUsT0FBTztBQUFBLDJCQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDWDtBQUFBLDZDQUFDLE9BQUUsV0FBVSx5RUFBd0UsbUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdGO0FBQUEsc0JBQ3hGLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLHdCQUN6Q21DLElBQUluQyxlQUFlLE9BQU87QUFBQSwyQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVcsZ0NBQWdDc0MsV0FBVyxrQkFBa0IsWUFBWSxJQUNyRjtBQUFBLDZDQUFDLE9BQUUsV0FBVywyREFBMkRBLFdBQVcscUJBQXFCLGVBQWUsSUFBSSxtQkFBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBK0g7QUFBQSxzQkFDL0gsdUJBQUMsT0FBRSxXQUFXLDRCQUE0QkEsV0FBVyxxQkFBcUIsZUFBZSxJQUFJO0FBQUE7QUFBQSx3QkFDdkZMLElBQUlqQyxlQUFlLE9BQU87QUFBQSwyQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSx1QkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5QkE7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ1YxQztBQUFBQSx3QkFBSVAsVUFDRCx1QkFBQyxTQUFJLFdBQVUsMEZBQ1g7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsd0NBQXVDLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDNUYsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSwrREFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0ksS0FEcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSw0Q0FBNENPLGNBQUlQLFVBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVFO0FBQUEseUJBSjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFFSE8sSUFBSWpDLFlBQ0QsdUJBQUMsU0FBSSxXQUFVLDJGQUNYO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHdDQUF1QyxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQzVGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsNEZBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZKLEtBRGpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUsNENBQTRDaUMsY0FBSWpDLFlBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlFO0FBQUEseUJBSjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFFSGlDLElBQUk0RixRQUNELHVCQUFDLFNBQUksV0FBVSw4RkFDWDtBQUFBLDZDQUFDLFNBQUksV0FBVSw4Q0FBNkMsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNsRyxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLDRIQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2TCxLQURqTTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBRSxXQUFVLG9EQUFvRDVGLGNBQUk0RixRQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwRTtBQUFBLHlCQUo5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsdUJBdkJSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEscUJBekhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMEhBO0FBQUE7QUFBQTtBQUFBLFlBaElLNUYsSUFBSUUsT0FBT3dFO0FBQUFBLFlBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrSUE7QUFBQSxRQUVSLENBQUMsS0FoSkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVLQTtBQUFBO0FBQUEsTUFoT1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa09BO0FBQUEsT0FsbUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtbUJBO0FBRVI7QUFBRTFLLEdBNTZCSUwseUJBQXVCO0FBQUFrTSxLQUF2QmxNO0FBODZCTixlQUFlQTtBQUF3QixJQUFBa007QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2VsZWN0IiwiU3BpbiIsIkRyYXdlciIsImFwaSIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJCYWNrZHJvcEJsdXJMb2FkZXIiLCJGYVdoYXRzYXBwU3F1YXJlIiwiRmFIaXN0b3J5IiwiQ2hpdFRyYW5zZmVyUGF5bWVudEZvcm0iLCJ1c2VySWQiLCJpbml0aWFsVXNlcklkIiwib25DbG9zZSIsIm9uU3VjY2VzcyIsIl9zIiwidG9kYXkiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInllc3RlcmRheSIsInNldERhdGUiLCJnZXREYXRlIiwidXNlcnMiLCJzZXRVc2VycyIsImZpbHRlcmVkRW5yb2xsbWVudHMiLCJzZXRGaWx0ZXJlZEVucm9sbG1lbnRzIiwic2VsZWN0ZWRVc2VySWQiLCJzZXRTZWxlY3RlZFVzZXJJZCIsInVzZXJBY2NvdW50SW5mbyIsInNldFVzZXJBY2NvdW50SW5mbyIsImZldGNoaW5nQmFsYW5jZSIsInNldEZldGNoaW5nQmFsYW5jZSIsImVucm9sbG1lbnRMb2FkaW5nIiwic2V0RW5yb2xsbWVudExvYWRpbmciLCJvcGVuQmFja2Ryb3BMb2FkZXIiLCJzZXRPcGVuQmFja2Ryb3BMb2FkZXIiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJ3aGF0c2FwcEVuYWJsZSIsInNldFdoYXRzYXBwRW5hYmxlIiwic2VydmljZUNoYXJnZSIsInNldFNlcnZpY2VDaGFyZ2UiLCJnc3RBbW91bnQiLCJzZXRHc3RBbW91bnQiLCJsb2FkaW5nVHJhbnNhY3Rpb24iLCJzZXRMb2FkaW5nVHJhbnNhY3Rpb24iLCJib3Jyb3dlcnMiLCJzZXRCb3Jyb3dlcnMiLCJwaWdtZUN1c3RvbWVycyIsInNldFBpZ21lQ3VzdG9tZXJzIiwic2VsZWN0ZWRHcm91cFRpY2tldHMiLCJzZXRTZWxlY3RlZEdyb3VwVGlja2V0cyIsInJlbW92YWxSZWFzb24iLCJzZXRSZW1vdmFsUmVhc29uIiwidHJhbnNhY3Rpb25IaXN0b3J5Iiwic2V0VHJhbnNhY3Rpb25IaXN0b3J5Iiwic2hvd1R4bkRyYXdlciIsInNldFNob3dUeG5EcmF3ZXIiLCJtb2RpZnlQYXltZW50Iiwic2V0TW9kaWZ5UGF5bWVudCIsIm1vZGlmeU1pbk1heFBheW1lbnREYXRlIiwic2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJ1c2VyIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBlcm1zIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiZWRpdF9saW1pdGVkX3BheW1lbnQiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwidXNlcl9pZCIsInBheV9kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJwYXlfZm9yIiwidHJhbnNhY3Rpb25faWQiLCJhZG1pbl90eXBlIiwicmVtYXJrcyIsImFjY291bnRfdHlwZSIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsImNoZXF1ZV9iYW5rX25hbWUiLCJjaGVxdWVfYmFua19icmFuY2giLCJmZXRjaFVzZXJzIiwicmVzIiwiZ2V0IiwiZGF0YSIsInByZXYiLCJmZXRjaFVzZXJBY2NvdW50SW5mbyIsImZldGNoVXNlckVucm9sbG1lbnRzIiwicmVzcG9uc2UiLCJzdGF0dXMiLCJwb3N0IiwidmFsaWQiLCJmaWx0ZXIiLCJpdGVtIiwiZW5yb2xsbWVudCIsImdyb3VwIiwibWFwUmVtb3ZhbFJlYXNvblRvUGF5Rm9yIiwicmVhc29uIiwibG93ZXIiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZmV0Y2hUcmFuc2FjdGlvbkhpc3RvcnkiLCJ0cmFuc2FjdGlvbnMiLCJ1c2VyVHJhbnNhY3Rpb25zIiwidHhuIiwiZW5yb2xsX2lkIiwiX2lkIiwibGVuZ3RoIiwic29ydGVkIiwic29ydCIsImEiLCJiIiwidHJhbnNhY3Rpb25fZGF0ZSIsImxhdGVzdCIsInJlbW92YWxfcmVhc29uIiwic2VydmljZV9jaGFyZ2UiLCJnc3RfYW1vdW50IiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzIiwiZmV0Y2hQaWdtZURldGFpbHMiLCJhbGxPcHRpb25zIiwibWFwIiwiZW50cnkiLCJ0aWNrZXRzIiwicGlnbWUiLCJib3Jyb3dlciIsImdyb3VwX3RpY2tldCIsInVuZGVmaW5lZCIsImhhbmRsZUN1c3RvbWVyIiwiY3VzdG9tZXIiLCJoYW5kbGVDaGFuZ2UiLCJlIiwibmFtZSIsInZhbHVlIiwidGFyZ2V0IiwiY2xlYW5lZCIsInJlcGxhY2UiLCJtYXRjaCIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwibW9kZSIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsInBhcnNlRmxvYXQiLCJpc05hTiIsImJhbGFuY2UiLCJ0b0xvY2FsZVN0cmluZyIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImFkbWluIiwicGF5bG9hZCIsInBheW1lbnRfZ3JvdXBfdGlja2V0cyIsImFkbWluX2lkIiwidG9TdHJpbmciLCJpbnB1dCIsIm9wdGlvbiIsImxhYmVsIiwidSIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsInZhbHVlcyIsImdyb3VwSWQiLCJ0aWNrZXQiLCJncm91cF9uYW1lIiwicGlnbWVfaWQiLCJwYXlhYmxlX2Ftb3VudCIsImxvYW5faWQiLCJsb2FuX2Ftb3VudCIsInVzZXJEZXRhaWxzIiwiTnVtYmVyIiwiY2hlY2tlZCIsImJvZHkiLCJwYWRkaW5nIiwiYmFja2dyb3VuZCIsImhlYWRlciIsImJvcmRlckJvdHRvbSIsImlkeCIsIm5ldCIsInNlcnZpY2UiLCJnc3QiLCJncm9zcyIsInRvdGFsX2Ftb3VudCIsImlzQ3JlZGl0IiwidHJhbnNhY3Rpb25fdHlwZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsIm1vbnRoIiwieWVhciIsInRvTG9jYWxlVGltZVN0cmluZyIsImhvdXIiLCJtaW51dGUiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsImdyb3VwX2lkIiwibm90ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoaXRUcmFuc2ZlclBheW1lbnRGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgU3BpbiwgRHJhd2VyIH0gZnJvbSBcImFudGRcIjsgLy8gYWRkIERyYXdlclxyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcbmltcG9ydCBCYWNrZHJvcEJsdXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9CYWNrZHJvcEJsdXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcFNxdWFyZSwgRmFIaXN0b3J5IH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7IC8vIGFkZCBpY29uXHJcblxyXG5jb25zdCBDaGl0VHJhbnNmZXJQYXltZW50Rm9ybSA9ICh7IHVzZXJJZDogaW5pdGlhbFVzZXJJZCwgb25DbG9zZSwgb25TdWNjZXNzIH0pID0+IHtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKG5ldyBEYXRlKCkuc2V0RGF0ZShuZXcgRGF0ZSgpLmdldERhdGUoKSAtIDEpKVxyXG4gICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgLnNwbGl0KFwiVFwiKVswXTtcclxuXHJcbiAgICAvLyAtLS0tIFN0YXRlIC0tLS1cclxuICAgIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2ZpbHRlcmVkRW5yb2xsbWVudHMsIHNldEZpbHRlcmVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkVXNlcklkLCBzZXRTZWxlY3RlZFVzZXJJZF0gPSB1c2VTdGF0ZShpbml0aWFsVXNlcklkIHx8IFwiXCIpO1xyXG4gICAgY29uc3QgW3VzZXJBY2NvdW50SW5mbywgc2V0VXNlckFjY291bnRJbmZvXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2ZldGNoaW5nQmFsYW5jZSwgc2V0RmV0Y2hpbmdCYWxhbmNlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtlbnJvbGxtZW50TG9hZGluZywgc2V0RW5yb2xsbWVudExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW29wZW5CYWNrZHJvcExvYWRlciwgc2V0T3BlbkJhY2tkcm9wTG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbd2hhdHNhcHBFbmFibGUsIHNldFdoYXRzYXBwRW5hYmxlXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gICAgY29uc3QgW3NlcnZpY2VDaGFyZ2UsIHNldFNlcnZpY2VDaGFyZ2VdID0gdXNlU3RhdGUoMCk7XHJcbiAgICBjb25zdCBbZ3N0QW1vdW50LCBzZXRHc3RBbW91bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgICBjb25zdCBbbG9hZGluZ1RyYW5zYWN0aW9uLCBzZXRMb2FkaW5nVHJhbnNhY3Rpb25dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2JvcnJvd2Vycywgc2V0Qm9ycm93ZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtwaWdtZUN1c3RvbWVycywgc2V0UGlnbWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkR3JvdXBUaWNrZXRzLCBzZXRTZWxlY3RlZEdyb3VwVGlja2V0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbcmVtb3ZhbFJlYXNvbiwgc2V0UmVtb3ZhbFJlYXNvbl0gPSB1c2VTdGF0ZSgpO1xyXG5cclxuICAgIC8vIE5FVzogc3RvcmUgZnVsbCB0cmFuc2FjdGlvbiBoaXN0b3J5IGFuZCBkcmF3ZXIgdmlzaWJpbGl0eVxyXG4gICAgY29uc3QgW3RyYW5zYWN0aW9uSGlzdG9yeSwgc2V0VHJhbnNhY3Rpb25IaXN0b3J5XSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtzaG93VHhuRHJhd2VyLCBzZXRTaG93VHhuRHJhd2VyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICAvLyAtLS0tIFBlcm1pc3Npb24gY2hlY2tzIC0tLS1cclxuICAgIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFttb2RpZnlNaW5NYXhQYXltZW50RGF0ZSwgc2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpIHx8IFwie31cIik7XHJcbiAgICAgICAgY29uc3QgcGVybXMgPSB1c2VyPy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucyB8fCB7fTtcclxuICAgICAgICBpZiAocGVybXMuZWRpdF9wYXltZW50ID09PSBcInRydWVcIikgc2V0TW9kaWZ5UGF5bWVudCh0cnVlKTtcclxuICAgICAgICBpZiAocGVybXMuZWRpdF9saW1pdGVkX3BheW1lbnQgPT09IFwidHJ1ZVwiKSB7XHJcbiAgICAgICAgICAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgICAgICAgIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlKHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH0sIFtdKTtcclxuXHJcbiAgICAvLyAtLS0tIEZvcm0gZGF0YSAtLS0tXHJcbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICB1c2VyX2lkOiBpbml0aWFsVXNlcklkIHx8IFwiXCIsXHJcbiAgICAgICAgcGF5X2RhdGU6IHRvZGF5LFxyXG4gICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICBwYXlfdHlwZTogXCJUcmFuc2ZlclwiLFxyXG4gICAgICAgIHBheV9mb3I6IFwiXCIsXHJcbiAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgYWRtaW5fdHlwZTogXCJcIixcclxuICAgICAgICByZW1hcmtzOiBcIlwiLFxyXG4gICAgICAgIGFjY291bnRfdHlwZTogXCJzYXZpbmdzXCIsXHJcbiAgICAgICAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICAgICAgICBjaGVxdWVfZGF0ZTogXCJcIixcclxuICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIC0tLS0gRmV0Y2ggdXNlcnMgLS0tLVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcInVzZXIvdmVyaWZpZWRcIik7XHJcbiAgICAgICAgICAgICAgICBzZXRVc2VycyhyZXM/LmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgICAgIHNldFVzZXJzKFtdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZmV0Y2hVc2VycygpO1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIC8vIC0tLS0gUHJl4oCRc2VsZWN0IHVzZXIgLS0tLVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoaW5pdGlhbFVzZXJJZCkge1xyXG4gICAgICAgICAgICBzZXRTZWxlY3RlZFVzZXJJZChpbml0aWFsVXNlcklkKTtcclxuICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIHVzZXJfaWQ6IGluaXRpYWxVc2VySWQgfSkpO1xyXG4gICAgICAgICAgICBmZXRjaFVzZXJBY2NvdW50SW5mbyhpbml0aWFsVXNlcklkKTtcclxuICAgICAgICAgICAgZmV0Y2hVc2VyRW5yb2xsbWVudHMoaW5pdGlhbFVzZXJJZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW2luaXRpYWxVc2VySWRdKTtcclxuXHJcbiAgICAvLyAtLS0tIEZldGNoIGFjY291bnQgaW5mbyAtLS0tXHJcbiAgICBjb25zdCBmZXRjaFVzZXJBY2NvdW50SW5mbyA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgICAgICBpZiAoIXVzZXJJZCkgcmV0dXJuO1xyXG4gICAgICAgIHNldEZldGNoaW5nQmFsYW5jZSh0cnVlKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi91c2VyLWFjY291bnRzLyR7dXNlcklkfWApO1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8uc3RhdHVzKSB7XHJcbiAgICAgICAgICAgICAgICBzZXRVc2VyQWNjb3VudEluZm8ocmVzcG9uc2UuZGF0YS5kYXRhKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHNldFVzZXJBY2NvdW50SW5mbyhudWxsKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICBzZXRVc2VyQWNjb3VudEluZm8obnVsbCk7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0RmV0Y2hpbmdCYWxhbmNlKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIC0tLS0gRmV0Y2ggZW5yb2xsbWVudHMgLS0tLVxyXG4gICAgY29uc3QgZmV0Y2hVc2VyRW5yb2xsbWVudHMgPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICAgICAgaWYgKCF1c2VySWQpIHJldHVybjtcclxuICAgICAgICBzZXRFbnJvbGxtZW50TG9hZGluZyh0cnVlKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7dXNlcklkfWApO1xyXG4gICAgICAgICAgICBjb25zdCB2YWxpZCA9IHJlc3BvbnNlLmRhdGEuZmlsdGVyKGl0ZW0gPT4gaXRlbS5lbnJvbGxtZW50ICYmIGl0ZW0uZW5yb2xsbWVudC5ncm91cCk7XHJcbiAgICAgICAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHModmFsaWQpO1xyXG4gICAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRFbnJvbGxtZW50TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBtYXBSZW1vdmFsUmVhc29uVG9QYXlGb3IgPSAocmVhc29uKSA9PiB7XHJcbiAgICAgICAgaWYgKCFyZWFzb24pIHJldHVybiBcIlwiO1xyXG4gICAgICAgIGNvbnN0IGxvd2VyID0gcmVhc29uLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgaWYgKGxvd2VyLmluY2x1ZGVzKFwiY2xvc2VcIikpIHJldHVybiBcIkNoaXQgQ2xvc2UgLyBUcmFuc2ZlclwiO1xyXG4gICAgICAgIGlmIChsb3dlci5pbmNsdWRlcyhcImNhbmNlbFwiKSkgcmV0dXJuIFwiQ2hpdCBDYW5jZWxsYXRpb24gLyBUcmFuc2ZlclwiO1xyXG4gICAgICAgIHJldHVybiBcIlwiO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyAtLS0tIEZldGNoIHRyYW5zYWN0aW9uIGhpc3RvcnkgZm9yIHNlcnZpY2UgY2hhcmdlLCBHU1QsIGFuZCBmdWxsIGxpc3QgLS0tLVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIXNlbGVjdGVkVXNlcklkKSB7XHJcbiAgICAgICAgICAgIHNldFNlcnZpY2VDaGFyZ2UoMCk7XHJcbiAgICAgICAgICAgIHNldEdzdEFtb3VudCgwKTtcclxuICAgICAgICAgICAgc2V0VHJhbnNhY3Rpb25IaXN0b3J5KFtdKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgZmV0Y2hUcmFuc2FjdGlvbkhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmdUcmFuc2FjdGlvbih0cnVlKTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vdHJhbnNhY3Rpb24taGlzdG9yeS9cIik7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0cmFuc2FjdGlvbnMgPSByZXMuZGF0YS5kYXRhIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgLy8gRmlsdGVyIHRyYW5zYWN0aW9ucyBmb3IgdGhpcyB1c2VyXHJcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VyVHJhbnNhY3Rpb25zID0gdHJhbnNhY3Rpb25zLmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgICAodHhuKSA9PiB0eG4uZW5yb2xsX2lkPy51c2VyX2lkPy5faWQgPT09IHNlbGVjdGVkVXNlcklkXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgLy8gU3RvcmUgZnVsbCBsaXN0XHJcbiAgICAgICAgICAgICAgICBzZXRUcmFuc2FjdGlvbkhpc3RvcnkodXNlclRyYW5zYWN0aW9ucyk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHVzZXJUcmFuc2FjdGlvbnMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNvcnRlZCA9IHVzZXJUcmFuc2FjdGlvbnMuc29ydChcclxuICAgICAgICAgICAgICAgICAgICAgICAgKGEsIGIpID0+IG5ldyBEYXRlKGIudHJhbnNhY3Rpb25fZGF0ZSkgLSBuZXcgRGF0ZShhLnRyYW5zYWN0aW9uX2RhdGUpXHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBsYXRlc3QgPSBzb3J0ZWRbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UmVtb3ZhbFJlYXNvbihsYXRlc3Q/LmVucm9sbF9pZD8ucmVtb3ZhbF9yZWFzb24pO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNlcnZpY2VDaGFyZ2UobGF0ZXN0LnNlcnZpY2VfY2hhcmdlIHx8IDApO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEdzdEFtb3VudChsYXRlc3QuZ3N0X2Ftb3VudCB8fCAwKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VydmljZUNoYXJnZSgwKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRHc3RBbW91bnQoMCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdHJhbnNhY3Rpb24gaGlzdG9yeTpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2VydmljZUNoYXJnZSgwKTtcclxuICAgICAgICAgICAgICAgIHNldEdzdEFtb3VudCgwKTtcclxuICAgICAgICAgICAgICAgIHNldFRyYW5zYWN0aW9uSGlzdG9yeShbXSk7XHJcbiAgICAgICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nVHJhbnNhY3Rpb24oZmFsc2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgZmV0Y2hUcmFuc2FjdGlvbkhpc3RvcnkoKTtcclxuICAgIH0sIFtzZWxlY3RlZFVzZXJJZF0pO1xyXG5cclxuICAgIC8vIC0tLS0gRmV0Y2ggbG9hbnMgJiBwaWdtZSBmb3IgdGhlIHNlbGVjdGVkIHVzZXIgLS0tLVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIXNlbGVjdGVkVXNlcklkKSB7XHJcbiAgICAgICAgICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICAgICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9sb2Fucy9nZXQtYm9ycm93ZXItYnktdXNlci1pZC8ke3NlbGVjdGVkVXNlcklkfWApO1xyXG4gICAgICAgICAgICAgICAgc2V0Qm9ycm93ZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IGZldGNoUGlnbWVEZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGlnbWUvZ2V0LXBpZ21lLWN1c3RvbWVyLWJ5LXVzZXItaWQvJHtzZWxlY3RlZFVzZXJJZH1gKTtcclxuICAgICAgICAgICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzKCk7XHJcbiAgICAgICAgZmV0Y2hQaWdtZURldGFpbHMoKTtcclxuICAgIH0sIFtzZWxlY3RlZFVzZXJJZF0pO1xyXG5cclxuICAgIC8vIC0tLS0gQXV0b+KAkXNlbGVjdCBhbGwgYXZhaWxhYmxlIG9wdGlvbnMgd2hlbiB1c2VyIGNoYW5nZXMgLS0tLVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIXNlbGVjdGVkVXNlcklkKSByZXR1cm47XHJcbiAgICAgICAgY29uc3QgYWxsT3B0aW9ucyA9IFtcclxuICAgICAgICAgICAgLi4uZmlsdGVyZWRFbnJvbGxtZW50cy5tYXAoZW50cnkgPT4gYGNoaXQtJHtlbnRyeS5lbnJvbGxtZW50Lmdyb3VwLl9pZH18JHtlbnRyeS5lbnJvbGxtZW50LnRpY2tldHN9YCksXHJcbiAgICAgICAgICAgIC4uLnBpZ21lQ3VzdG9tZXJzLm1hcChwaWdtZSA9PiBgcGlnbWUtJHtwaWdtZS5faWR9YCksXHJcbiAgICAgICAgICAgIC4uLmJvcnJvd2Vycy5tYXAoYm9ycm93ZXIgPT4gYGxvYW4tJHtib3Jyb3dlci5faWR9YClcclxuICAgICAgICBdO1xyXG4gICAgICAgIGlmIChhbGxPcHRpb25zLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cFRpY2tldHMoYWxsT3B0aW9ucyk7XHJcbiAgICAgICAgICAgIHNldEVycm9ycyhwcmV2ID0+ICh7IC4uLnByZXYsIGdyb3VwX3RpY2tldDogdW5kZWZpbmVkIH0pKTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbZmlsdGVyZWRFbnJvbGxtZW50cywgcGlnbWVDdXN0b21lcnMsIGJvcnJvd2Vycywgc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgICAvLyAtLS0tIEhhbmRsZXJzIC0tLS1cclxuICAgIGNvbnN0IGhhbmRsZUN1c3RvbWVyID0gKHVzZXJJZCkgPT4ge1xyXG4gICAgICAgIHNldFNlbGVjdGVkVXNlcklkKHVzZXJJZCk7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIHVzZXJfaWQ6IHVzZXJJZCB9KSk7XHJcbiAgICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBjdXN0b21lcjogXCJcIiB9KSk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgICAgIHNldFNlcnZpY2VDaGFyZ2UoMCk7XHJcbiAgICAgICAgc2V0R3N0QW1vdW50KDApO1xyXG4gICAgICAgIHNldFRyYW5zYWN0aW9uSGlzdG9yeShbXSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICAgICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcblxyXG4gICAgICAgIGlmIChuYW1lID09PSBcImFtb3VudFwiKSB7XHJcbiAgICAgICAgICAgIGxldCBjbGVhbmVkID0gdmFsdWUucmVwbGFjZSgvW14wLTkuXS9nLCBcIlwiKTtcclxuICAgICAgICAgICAgaWYgKChjbGVhbmVkLm1hdGNoKC9cXC4vZykgfHwgW10pLmxlbmd0aCA+IDEpIHJldHVybjtcclxuXHJcbiAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICBbbmFtZV06IGNsZWFuZWQsXHJcbiAgICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgICAgIHNldEVycm9ycyhwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHNldEVycm9ycyhwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIFtuYW1lXTogXCJcIixcclxuICAgICAgICB9KSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgICAgICBjb25zdCBtb2RlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogbW9kZSxcclxuICAgICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IG1vZGUgPT09IFwiY2FzaFwiID8gXCJcIiA6IHByZXYudHJhbnNhY3Rpb25faWQsXHJcbiAgICAgICAgICAgIC4uLihtb2RlICE9PSBcImNoZXF1ZVwiICYmIHsgY2hlcXVlX251bWJlcjogXCJcIiwgY2hlcXVlX2RhdGU6IFwiXCIsIGNoZXF1ZV9iYW5rX25hbWU6IFwiXCIsIGNoZXF1ZV9iYW5rX2JyYW5jaDogXCJcIiB9KSxcclxuICAgICAgICB9KSk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIC0tLS0gVmFsaWRhdGlvbiAtLS0tXHJcbiAgICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICAgICAgaWYgKCFmb3JtRGF0YS51c2VyX2lkKSBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgICAgIGlmICghc2VsZWN0ZWRHcm91cFRpY2tldHMgfHwgc2VsZWN0ZWRHcm91cFRpY2tldHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIG5ld0Vycm9ycy5ncm91cF90aWNrZXQgPSBcIlBsZWFzZSBzZWxlY3QgYXQgbGVhc3Qgb25lIGdyb3VwL3RpY2tldFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIWZvcm1EYXRhLnBheV9kYXRlKSBuZXdFcnJvcnMucGF5X2RhdGUgPSBcIlBheW1lbnQgZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZm9ybURhdGEucGF5X2ZvcikgbmV3RXJyb3JzLnBheV9mb3IgPSBcIlBsZWFzZSBzZWxlY3QgYSBwYXltZW50IHJlYXNvblwiO1xyXG5cclxuICAgICAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KGZvcm1EYXRhLmFtb3VudCk7XHJcbiAgICAgICAgaWYgKGlzTmFOKGFtb3VudCkgfHwgYW1vdW50IDw9IDApIHtcclxuICAgICAgICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgcG9zaXRpdmUgYW1vdW50XCI7XHJcbiAgICAgICAgfSBlbHNlIGlmICghdXNlckFjY291bnRJbmZvKSB7XHJcbiAgICAgICAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlVuYWJsZSB0byB2ZXJpZnkgYmFsYW5jZS4gUGxlYXNlIHJlZnJlc2ggb3Igc2VsZWN0IGN1c3RvbWVyIGFnYWluLlwiO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoYW1vdW50ID4gdXNlckFjY291bnRJbmZvLmJhbGFuY2UpIHtcclxuICAgICAgICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IGBBbW91bnQgY2Fubm90IGV4Y2VlZCBhdmFpbGFibGUgYmFsYW5jZSBvZiDigrkke3VzZXJBY2NvdW50SW5mby5iYWxhbmNlLnRvTG9jYWxlU3RyaW5nKCl9YDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICAgIH07XHJcblxyXG4gICAgLy8gLS0tLSBTdWJtaXQgLS0tLVxyXG4gICAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgaWYgKCF2YWxpZGF0ZUZvcm0oKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBjb25zdCBhZG1pbiA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpIHx8IFwie31cIik7XHJcblxyXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAgIHVzZXJfaWQ6IGZvcm1EYXRhLnVzZXJfaWQsXHJcbiAgICAgICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogc2VsZWN0ZWRHcm91cFRpY2tldHMsXHJcbiAgICAgICAgICAgIHBheV9kYXRlOiBmb3JtRGF0YS5wYXlfZGF0ZSxcclxuICAgICAgICAgICAgYW1vdW50OiBwYXJzZUZsb2F0KGZvcm1EYXRhLmFtb3VudCksXHJcbiAgICAgICAgICAgIHBheV90eXBlOiBmb3JtRGF0YS5wYXlfdHlwZSxcclxuICAgICAgICAgICAgcGF5X2ZvcjogZm9ybURhdGEucGF5X2ZvcixcclxuICAgICAgICAgICAgYWRtaW5faWQ6IGFkbWluLl9pZCxcclxuICAgICAgICAgICAgYWRtaW5fdHlwZTogYWRtaW4uX2lkLFxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogZm9ybURhdGEudHJhbnNhY3Rpb25faWQgfHwgbnVsbCxcclxuICAgICAgICAgICAgcmVtYXJrczogZm9ybURhdGEucmVtYXJrcyB8fCBudWxsLFxyXG4gICAgICAgICAgICBhY2NvdW50X3R5cGU6IGZvcm1EYXRhLmFjY291bnRfdHlwZSB8fCBcInNhdmluZ3NcIixcclxuICAgICAgICAgICAgc2VydmljZV9jaGFyZ2U6IHNlcnZpY2VDaGFyZ2UudG9TdHJpbmcoKSxcclxuICAgICAgICAgICAgZ3N0X2Ftb3VudDogZ3N0QW1vdW50LnRvU3RyaW5nKCksXHJcbiAgICAgICAgICAgIC4uLihmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJjaGVxdWVcIiAmJiB7XHJcbiAgICAgICAgICAgICAgICBjaGVxdWVfbnVtYmVyOiBmb3JtRGF0YS5jaGVxdWVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgY2hlcXVlX2RhdGU6IGZvcm1EYXRhLmNoZXF1ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgY2hlcXVlX2JhbmtfbmFtZTogZm9ybURhdGEuY2hlcXVlX2JhbmtfbmFtZSxcclxuICAgICAgICAgICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogZm9ybURhdGEuY2hlcXVlX2JhbmtfYnJhbmNoLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgYXdhaXQgYXBpLnBvc3QoXCJ2MS9hZG1pbi91c2VyLWFjY291bnRzL3BheWluXCIsIHBheWxvYWQpO1xyXG4gICAgICAgICAgICBpZiAob25TdWNjZXNzKSBvblN1Y2Nlc3MoKTtcclxuICAgICAgICAgICAgb25DbG9zZSgpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAvLyBPcHRpb25hbGx5IHNob3cgZXJyb3IgbWVzc2FnZVxyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIHtvcGVuQmFja2Ryb3BMb2FkZXIgJiYgPEJhY2tkcm9wQmx1ckxvYWRlciB0aXRsZT1cIlByb2Nlc3NpbmcgVHJhbnNmZXIuLi5cIiAvPn1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IG1heC1oLVs4MHZoXSBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCBtYi00IGJvcmRlci1iIHBiLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q2hpdCBUcmFuc2ZlciBQYXltZW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBZGQgVmlldyBIaXN0b3J5IGJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICB7Lyoge3NlbGVjdGVkVXNlcklkICYmIHRyYW5zYWN0aW9uSGlzdG9yeS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VHhuRHJhd2VyKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1zbSBiZy1ibHVlLTUwIGhvdmVyOmJnLWJsdWUtMTAwIHRleHQtYmx1ZS03MDAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFIaXN0b3J5IGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBIaXN0b3J5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICl9ICovfVxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgJiBHcm91cC9UaWNrZXQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZyb20gIEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9yIHNlYXJjaCBjdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS51c2VyX2lkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17dXNlcnMubWFwKCh1KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdS5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHt1LmZ1bGxfbmFtZX0gfCAke3UucGhvbmVfbnVtYmVyfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY3VzdG9tZXIgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuY3VzdG9tZXJ9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUbyBHcm91cCAmIFRpY2tldCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9uZSBvciBtb3JlIGdyb3VwcywgcGlnbXksIG9yIGxvYW5zXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZW5yb2xsbWVudExvYWRpbmcgfHwgKHVzZXJBY2NvdW50SW5mbz8uYmFsYW5jZSB8fCAwKSA8PSAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2Vucm9sbG1lbnRMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cFRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cFRpY2tldHModmFsdWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHByZXYgPT4gKHsgLi4ucHJldiwgZ3JvdXBfdGlja2V0OiB1bmRlZmluZWQgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENoaXQgb3B0aW9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRFbnJvbGxtZW50cy5tYXAoZW50cnkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gZW50cnkuZW5yb2xsbWVudC5ncm91cC5faWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpY2tldCA9IGVudHJ5LmVucm9sbG1lbnQudGlja2V0cztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxhYmVsID0gYCR7ZW50cnkuZW5yb2xsbWVudC5ncm91cC5ncm91cF9uYW1lfSB8ICR7dGlja2V0fWA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA8U2VsZWN0Lk9wdGlvbiBrZXk9e3ZhbHVlfSB2YWx1ZT17dmFsdWV9PntsYWJlbH08L1NlbGVjdC5PcHRpb24+O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQaWdteSBvcHRpb25zICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZUN1c3RvbWVycz8ubWFwKHBpZ21lID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBgcGlnbWUtJHtwaWdtZS5faWR9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGFiZWwgPSBgJHtwaWdtZS5waWdtZV9pZH0gfCDigrkgJHtwaWdtZS5wYXlhYmxlX2Ftb3VudH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPFNlbGVjdC5PcHRpb24ga2V5PXt2YWx1ZX0gdmFsdWU9e3ZhbHVlfT57bGFiZWx9PC9TZWxlY3QuT3B0aW9uPjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9hbiBvcHRpb25zICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtib3Jyb3dlcnM/Lm1hcChib3Jyb3dlciA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYGxvYW4tJHtib3Jyb3dlci5faWR9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGFiZWwgPSBgbG9hbi0ke2JvcnJvd2VyLmxvYW5faWR9IHwg4oK5ICR7Ym9ycm93ZXIubG9hbl9hbW91bnR9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxTZWxlY3QuT3B0aW9uIGtleT17dmFsdWV9IHZhbHVlPXt2YWx1ZX0+e2xhYmVsfTwvU2VsZWN0Lk9wdGlvbj47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfdGlja2V0ICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmdyb3VwX3RpY2tldH08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBheSBGb3IgUmVhc29uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWluZGlnby01MCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5IEZvciAoUmVhc29uKSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9mb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXlfZm9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgYmctd2hpdGUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBQYXltZW50IFJlYXNvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDaGl0IENhbmNlbGxhdGlvbiAvIFRyYW5zZmVyXCI+Q2hpdCBDYW5jZWxsYXRpb248L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ2hpdCBDbG9zZSAvIFRyYW5zZmVyXCI+Q2hpdCBDbG9zZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQaWdteSBDbG9zZSAvIFRyYW5zZmVyXCI+UGlnbXkgQ2xvc2U8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTG9hbiBDbG9zZSAvIFRyYW5zZmVyXCI+TG9hbiBDbG9zZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfZm9yICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2Zvcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEJhbGFuY2UgQ2FyZCB3aXRoIFNlcnZpY2UgQ2hhcmdlICYgR1NUICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHt1c2VyQWNjb3VudEluZm8/LmJhbGFuY2UgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCByb3VuZGVkLXhsIHAtNSBzaGFkb3ctc20gcmVsYXRpdmVcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHJpZ2h0LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRVc2VySWQgJiYgdHJhbnNhY3Rpb25IaXN0b3J5Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dUeG5EcmF3ZXIodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1tZWRpdW0gYmctd2hpdGUgaG92ZXI6YmctZ3JlZW4tMTAwIHRleHQtYmx1ZS03MDAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHNoYWRvdy1zbSB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhSGlzdG9yeSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgSGlzdG9yeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL31cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHItMjhcIj4gey8qIEFkZGVkIHByLTI4IHRvIGF2b2lkIHRleHQgb3ZlcmxhcHBpbmcgdGhlIGFic29sdXRlIGJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXJBY2NvdW50SW5mby5mdWxsX25hbWUgfHwgdXNlckFjY291bnRJbmZvPy51c2VyRGV0YWlscz8uZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEF2YWlsYWJsZSBCYWxhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7TnVtYmVyKHVzZXJBY2NvdW50SW5mby5iYWxhbmNlKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNlcnZpY2UgQ2hhcmdlcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiB7KHNlcnZpY2VDaGFyZ2UgPiAwIHx8IGdzdEFtb3VudCA+IDApICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgYm9yZGVyLXQgYm9yZGVyLWdyZWVuLTIwMCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBwLTMgYm9yZGVyIGJvcmRlci1ibHVlLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VydmljZSBDaGFyZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5IHtOdW1iZXIoc2VydmljZUNoYXJnZSkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC0zIGJvcmRlciBib3JkZXItcHVycGxlLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR1NUIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1wdXJwbGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7TnVtYmVyKGdzdEFtb3VudCkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC0zIGJvcmRlciBib3JkZXItcmVkLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgRGVkdWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7KE51bWJlcihzZXJ2aWNlQ2hhcmdlKSArIE51bWJlcihnc3RBbW91bnQpKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfSAqL31cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9hZGluZyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nVHJhbnNhY3Rpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBib3JkZXItdCBib3JkZXItZ3JlZW4tMjAwIHB0LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwaW4gc2l6ZT1cInNtYWxsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2FkaW5nIHRyYW5zYWN0aW9uIGRldGFpbHMuLi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7LyogUGF5bWVudCBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLXhsIHAtNiBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xIGgtNiBiZy1ibHVlLTYwMCByb3VuZGVkLWZ1bGxcIiAvPiBQYXltZW50IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW1vZGlmeVBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17bW9kaWZ5TWluTWF4UGF5bWVudERhdGUgPyB5ZXN0ZXJkYXkgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17bW9kaWZ5TWluTWF4UGF5bWVudERhdGUgPyB0b2RheSA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlfZGF0ZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5wYXlfZGF0ZX08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zZmVyIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBiZy1ibHVlLTUwIGZvbnQtbWVkaXVtIHRleHQtYmx1ZS04MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuYW1vdW50fTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPntudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhLmFtb3VudCl9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+UmVtYXJrcyAob3B0aW9uYWwpPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlbWFya3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucmVtYXJrc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGRpdGlvbmFsIHJlbWFya3MgKGUuZy4sIHJlYXNvbiBmb3IgY2FuY2VsbGF0aW9uKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBheW1lbnQgTW9kZSBhbmQgcmVsYXRlZCBmaWVsZHMgKHVuY2hhbmdlZCkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudE1vZGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQmFuayBUcmFuc2ZlclwiPkJhbmsgVHJhbnNmZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9ubGluZS91cGlcIj5PbmxpbmUgLyBVUEk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPkNoZXF1ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9ubGluZSAvIFVQSSBUcmFuc2FjdGlvbiBJRCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgeyhmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiB8fCBmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJvbmxpbmUvdXBpXCIpICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRyYW5zYWN0aW9uIElEXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy50cmFuc2FjdGlvbl9pZH08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQ2hlcXVlIERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJjaGVxdWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+Q2hlcXVlIERldGFpbHM8L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaGVxdWUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNoZXF1ZV9udW1iZXIgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMuY2hlcXVlX251bWJlcn08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2hlcXVlIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY2hlcXVlX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jaGVxdWVfZGF0ZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+e2Vycm9ycy5jaGVxdWVfZGF0ZX08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+QmFuayBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+QmFuayBCcmFuY2g8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogV2hhdHNBcHAgTm90aWZpY2F0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHBTcXVhcmUgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDAgdGV4dC0yeGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+V2hhdHNBcHAgTm90aWZpY2F0aW9uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3doYXRzYXBwRW5hYmxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0V2hhdHNhcHBFbmFibGUoZS50YXJnZXQuY2hlY2tlZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyZWVuLTUwMCByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5TZW5kIHZpYSBXaGF0c0FwcDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0xMDAgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17KHVzZXJBY2NvdW50SW5mbz8uYmFsYW5jZSB8fCAwKSA8PSAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yIHRleHQtc20gYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkIGZvbnQtYm9sZCBob3ZlcjpiZy1ibHVlLTcwMCBzaGFkb3ctbGcgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh1c2VyQWNjb3VudEluZm8/LmJhbGFuY2UgfHwgMCkgPD0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQ3VzdG9tZXIgaGFzIG5vIGF2YWlsYWJsZSBiYWxhbmNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNhdmUgUGF5bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhdmUgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogLS0tLSBUcmFuc2FjdGlvbiBIaXN0b3J5IERyYXdlciAtLS0tICovfVxyXG4gICAgICAgICAgICA8RHJhd2VyXHJcbiAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ibHVlLTEwMCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFIaXN0b3J5IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgdGV4dC1zbVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSGlzdG9yeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25IaXN0b3J5Lmxlbmd0aH0gcmVjb3Jke3RyYW5zYWN0aW9uSGlzdG9yeS5sZW5ndGggIT09IDEgPyBcInNcIiA6IFwiXCJ9IGZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4gICAgICAgICAgICAgICAgb3Blbj17c2hvd1R4bkRyYXdlcn1cclxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dUeG5EcmF3ZXIoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgd2lkdGg9ezYyMH1cclxuICAgICAgICAgICAgICAgIGNsb3NhYmxlPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRyYW5zYWN0aW9uLWRyYXdlclwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiB7IHBhZGRpbmc6IFwiMFwiLCBiYWNrZ3JvdW5kOiBcIiNmOGZhZmNcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGhlYWRlcjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjIwcHggMjRweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICNlMmU4ZjBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjZmZmZmZmXCJcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGV4dHJhPXtcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dUeG5EcmF3ZXIoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC14bCBob3ZlcjpiZy1ncmF5LTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmF5LTUwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNNiAxOEwxOCA2TTYgNmwxMiAxMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7bG9hZGluZ1RyYW5zYWN0aW9uID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC02NCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYm9yZGVyLTMgYm9yZGVyLWJsdWUtMjAwIGJvcmRlci10LWJsdWUtNjAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW5cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5Mb2FkaW5nIHRyYW5zYWN0aW9ucy4uLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiB0cmFuc2FjdGlvbkhpc3RvcnkubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC02NCB0ZXh0LWNlbnRlciBweC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtMnhsIGJnLWdyYXktMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LWdyYXktMzAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMS41XCIgZD1cIk05IDVIN2EyIDIgMCAwMC0yIDJ2MTBhMiAyIDAgMDAyIDJoOGEyIDIgMCAwMDItMlY3YTIgMiAwIDAwLTItMmgtMk05IDVhMiAyIDAgMDAyIDJoMmEyIDIgMCAwMDItMk05IDVhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwXCI+Tm8gdHJhbnNhY3Rpb25zIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDAgbXQtMVwiPlBheW1lbnQgaGlzdG9yeSBmb3IgdGhpcyBjdXN0b21lciB3aWxsIGFwcGVhciBoZXJlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RyYW5zYWN0aW9uSGlzdG9yeS5tYXAoKHR4biwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXQgPSBOdW1iZXIodHhuLmFtb3VudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzZXJ2aWNlID0gTnVtYmVyKHR4bi5zZXJ2aWNlX2NoYXJnZSB8fCAwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdzdCA9IE51bWJlcih0eG4uZ3N0X2Ftb3VudCB8fCAwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3NzID0gdHhuLnRvdGFsX2Ftb3VudCB8fCAobmV0ICsgc2VydmljZSArIGdzdCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNDcmVkaXQgPSB0eG4udHJhbnNhY3Rpb25fdHlwZT8udG9Mb3dlckNhc2UoKT8uaW5jbHVkZXMoXCJjcmVkaXRcIikgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eG4udHJhbnNhY3Rpb25fdHlwZT8udG9Mb3dlckNhc2UoKT8uaW5jbHVkZXMoXCJyZWZ1bmRcIikgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eG4udHJhbnNhY3Rpb25fdHlwZT8udG9Mb3dlckNhc2UoKT8uaW5jbHVkZXMoXCJyZWNlaXB0XCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3R4bi5faWQgfHwgaWR4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIG92ZXJmbG93LWhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVG9wIGFjY2VudCBzdHJpcGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgaC0xIHctZnVsbCAke2lzQ3JlZGl0ID8gJ2JnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTQwMCB0by1ncmVlbi01MDAnIDogJ2JnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTQwMCB0by1pbmRpZ28tNTAwJ31gfSAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBIZWFkZXI6IERhdGUgKyBUeXBlIEJhZGdlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTggaC04IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgJHtpc0NyZWRpdCA/ICdiZy1lbWVyYWxkLTUwJyA6ICdiZy1ibHVlLTUwJ31gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0NyZWRpdCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTYwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk03IDExbDUtNW0wIDBsNSA1bS01LTV2MTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTYwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xNyA5VjdhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjZhMiAyIDAgMDAyIDJoMm0yIDRoMTBhMiAyIDAgMDAyLTJ2LTZhMiAyIDAgMDAtMi0ySDlhMiAyIDAgMDAtMiAydjZhMiAyIDAgMDAyIDJ6bTctNWEyIDIgMCAxMS00IDAgMiAyIDAgMDE0IDB6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUodHhuLnRyYW5zYWN0aW9uX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tSU4nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogJzItZGlnaXQnLCBtb250aDogJ3Nob3J0JywgeWVhcjogJ251bWVyaWMnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHR4bi50cmFuc2FjdGlvbl9kYXRlKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLUlOJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTEgcm91bmRlZC1sZyB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyICR7aXNDcmVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3R4bi50cmFuc2FjdGlvbl90eXBlIHx8IFwiUGF5bWVudFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciAmIEdyb3VwIEluZm8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTQgcC0zIGJnLXNsYXRlLTUwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2xhdGUtMjAwIHRvLXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KHR4bi5lbnJvbGxfaWQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCB1c2VyQWNjb3VudEluZm8/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jaGFyQXQoMCk/LnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHhuLmVucm9sbF9pZD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IHVzZXJBY2NvdW50SW5mbz8uZnVsbF9uYW1lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS01MDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHhuLmVucm9sbF9pZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB0eG4uZW5yb2xsX2lkLmdyb3VwX2lkLmdyb3VwX25hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3R4bi5lbnJvbGxfaWQ/LnRpY2tldHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS0zMDBcIj7Ctzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWluZGlnby02MDAgYmctaW5kaWdvLTUwIHB4LTEuNSBweS0wLjUgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGt0IHt0eG4uZW5yb2xsX2lkLnRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFtb3VudHMgR3JpZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+R3Jvc3M8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtncm9zcy50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLXhsIHAtMi41IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlNlcnZpY2U8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtzZXJ2aWNlLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+R1NUPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7Z3N0LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIHAtMi41IHRleHQtY2VudGVyICR7aXNDcmVkaXQgPyAnYmctZW1lcmFsZC01MCcgOiAnYmctYmx1ZS01MCd9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEgJHtpc0NyZWRpdCA/ICd0ZXh0LWVtZXJhbGQtNTAwJyA6ICd0ZXh0LWJsdWUtNTAwJ31gfT5OZXQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YHRleHQtYmFzZSBmb250LWV4dHJhYm9sZCAke2lzQ3JlZGl0ID8gJ3RleHQtZW1lcmFsZC03MDAnIDogJ3RleHQtYmx1ZS03MDAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e25ldC50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJlYXNvbiwgTW9kZSAmIE5vdGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiBwdC0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eG4ucmVhc29uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWFtYmVyLTUwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNTAwIGZsZXgtc2hyaW5rLTBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMyAxNmgtMXYtNGgtMW0xLTRoLjAxTTIxIDEyYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1hbWJlci03MDBcIj57dHhuLnJlYXNvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3R4bi5wYXlfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS0xMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1zbGF0ZS00MDAgZmxleC1zaHJpbmstMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTMgMTBoMThNNyAxNWgxbTQgMGgxbS03IDRoMTJhMyAzIDAgMDAzLTNWOGEzIDMgMCAwMC0zLTNINmEzIDMgMCAwMC0zIDN2OGEzIDMgMCAwMDMgM3pcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwXCI+e3R4bi5wYXlfdHlwZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3R4bi5ub3RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjUgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtMi41IHB5LTEuNSB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWdyYXktNDAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTEgNUg2YTIgMiAwIDAwLTIgMnYxMWEyIDIgMCAwMDIgMmgxMWEyIDIgMCAwMDItMnYtNW0tMS40MTQtOS40MTRhMiAyIDAgMTEyLjgyOCAyLjgyOEwxMS44MjggMTVIOXYtMi44MjhsOC41ODYtOC41ODZ6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTYwMCBpdGFsaWMgbGVhZGluZy1yZWxheGVkXCI+e3R4bi5ub3RlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvb3RlciBTdW1tYXJ5ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJtdC00IHAtNCBiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWluZGlnby0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby02MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk05IDdoNm0wIDEwdi0zbS0zIDNoLjAxTTkgMTdoLjAxTTkgMTRoLjAxTTEyIDE0aC4wMU0xNSAxMWguMDFNMTIgMTFoLjAxTTkgMTFoLjAxTTcgMjFoMTBhMiAyIDAgMDAyLTJWNWEyIDIgMCAwMC0yLTJIN2EyIDIgMCAwMC0yIDJ2MTRhMiAyIDAgMDAyIDJ6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5Ub3RhbCBOZXQgQW1vdW50PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPnt0cmFuc2FjdGlvbkhpc3RvcnkubGVuZ3RofSB0cmFuc2FjdGlvbnM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1pbmRpZ28tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXt0cmFuc2FjdGlvbkhpc3RvcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yZWR1Y2UoKHN1bSwgdCkgPT4gc3VtICsgTnVtYmVyKHQuYW1vdW50IHx8IDApLCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L0RyYXdlcj5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDaGl0VHJhbnNmZXJQYXltZW50Rm9ybTsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQ2hpdFRyYW5zZmVyUGF5bWVudEZvcm0uanN4In0=