import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { RouterProvider } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=819e0a34"; const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];
import "/src/index.css?t=1792822511816";
import mainRoutes from "/src/routes/mainRoutes.jsx?t=1792822406834";
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(RouterProvider, { router: mainRoutes }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/main.jsx",
    lineNumber: 9,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUU7QUFSRixTQUFTQSxzQkFBc0I7QUFDL0IsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU87QUFDUCxPQUFPQyxnQkFBZ0I7QUFJdkJELFdBQVdFLFNBQVNDLGVBQWUsTUFBTSxDQUFDLEVBQUVDO0FBQUFBLEVBQzFDLHVCQUFDLGtCQUFlLFFBQVFILGNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUM7QUFDckMiLCJuYW1lcyI6WyJSb3V0ZXJQcm92aWRlciIsImNyZWF0ZVJvb3QiLCJtYWluUm91dGVzIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSb3V0ZXJQcm92aWRlciB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tIFwicmVhY3QtZG9tL2NsaWVudFwiO1xyXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xyXG5pbXBvcnQgbWFpblJvdXRlcyBmcm9tIFwiLi9yb3V0ZXMvbWFpblJvdXRlcy5qc3hcIjtcclxuXHJcblxyXG5cclxuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikpLnJlbmRlcihcclxuICA8Um91dGVyUHJvdmlkZXIgcm91dGVyPXttYWluUm91dGVzfSAvPlxyXG4pO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvbWFpbi5qc3gifQ==