import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PrintPaymentOut.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
import { BiPrinter } from "/node_modules/.vite/deps/react-icons_bi.js?v=819e0a34";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import mychitsLogo from "/src/assets/images/mychits.png?import";
const PrintPaymentOut = () => {
  _s();
  const { id } = useParams();
  const [payment, setPayment] = useState({});
  useEffect(() => {
    const fetchPayment = async () => {
      try {
        const response = await api.get(`/payment-out/get-payment-out-by-id/${id}`);
        if (response.data) {
          setPayment(response.data);
        } else {
          setPayment({});
        }
      } catch (error) {
        console.error("Error fetching payment out data:", error);
        setPayment({});
      }
    };
    fetchPayment();
  }, [id]);
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  };
  const handlePrint = async () => {
    const receiptElement = document.getElementById("receipt");
    const canvas = await html2canvas(receiptElement, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("portrait", "mm", "a4");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    pdf.addImage(imgData, "PNG", 0, 0, pageWidth, pageHeight);
    pdf.save("PaymentOutReceipt.pdf");
  };
  return /* @__PURE__ */ jsxDEV("div", { align: "center", style: { marginTop: "80px" }, children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: handlePrint,
        className: "border border-violet-400 text-white px-4 py-2 mb-5 rounded-md shadow hover:border-violet-700 transition duration-200 mt-4",
        children: /* @__PURE__ */ jsxDEV(BiPrinter, { color: "violet" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
          lineNumber: 60,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
        lineNumber: 56,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        id: "receipt",
        style: {
          width: "210mm",
          height: "297mm",
          padding: "10mm",
          border: "1px solid #ddd",
          backgroundColor: "#fff",
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          gap: "10mm"
        },
        children: [...Array(2)].map(
          (_, idx) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                width: "48%",
                border: "1px solid #ddd",
                borderRadius: "8px",
                padding: "15px",
                boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)"
              },
              children: [
                /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: mychitsLogo,
                    alt: "Company Logo",
                    width: "40",
                    style: { margin: "0 auto 8px", display: "block" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 90,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("h2", { style: { textAlign: "center", margin: 0 }, children: "MY CHITS" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                  lineNumber: 96,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("p", { style: { textAlign: "center", fontSize: "12px", margin: "5px 0" }, children: [
                  "No.11/36-25, 2nd Main, Kathriguppe Main Road,",
                  /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 99,
                    columnNumber: 15
                  }, this),
                  "Bangalore, 560085 9483900777"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                  lineNumber: 97,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                  lineNumber: 102,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { style: { textAlign: "center", margin: "5px 0" }, children: "Receipt" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                  lineNumber: 103,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "start" }, children: [
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Receipt No: ",
                    payment.receipt_no || payment.old_receipt_no || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 105,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Date: ",
                    payment.pay_date ? formatPayDate(payment.pay_date) : "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 106,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Name: ",
                    payment?.user_id?.full_name || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 107,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Mobile No: ",
                    payment?.user_id?.phone_number || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 108,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Group: ",
                    payment?.group_id?.group_name || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 109,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Ticket: ",
                    payment?.ticket || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 110,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                  lineNumber: 104,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      textAlign: "center",
                      fontWeight: "bold",
                      border: "1px solid #000",
                      padding: "10px",
                      margin: "10px 0"
                    },
                    children: [
                      "Pay Out Amount | Rs.",
                      payment?.amount || 0
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 112,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "start" }, children: [
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Disbursement Type: ",
                    payment?.disbursement_type || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 124,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Payment Mode: ",
                    payment?.pay_type || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 125,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Total: Rs.",
                    payment?.amount || 0
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 126,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { children: [
                    "Disbursed By: ",
                    payment?.admin_type?.admin_name || "Admin"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                    lineNumber: 127,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                  lineNumber: 123,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("p", { style: { marginTop: "4px" }, children: idx === 0 ? "Customer Copy" : "Admin Copy" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
                  lineNumber: 129,
                  columnNumber: 13
                }, this)
              ]
            },
            idx,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
              lineNumber: 80,
              columnNumber: 9
            },
            this
          )
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
        lineNumber: 65,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx",
    lineNumber: 55,
    columnNumber: 5
  }, this);
};
_s(PrintPaymentOut, "DIsOYJ1yqgk9lbx/acRLUsTcDaw=", false, function() {
  return [useParams];
});
_c = PrintPaymentOut;
export default PrintPaymentOut;
var _c;
$RefreshReg$(_c, "PrintPaymentOut");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrintPaymentOut.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRROzJCQTNEUjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxpQkFBaUI7QUFFeEIsTUFBTUMsa0JBQWtCQSxNQUFNO0FBQUFDLEtBQUE7QUFDNUIsUUFBTSxFQUFFQyxHQUFHLElBQUlMLFVBQVU7QUFDekIsUUFBTSxDQUFDTSxTQUFTQyxVQUFVLElBQUlYLFNBQVMsQ0FBQyxDQUFDO0FBRXpDRCxZQUFVLE1BQU07QUFDZCxVQUFNYSxlQUFlLFlBQVk7QUFDL0IsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTVIsSUFBSVMsSUFBSSxzQ0FBc0NMLEVBQUUsRUFBRTtBQUN6RSxZQUFJSSxTQUFTRSxNQUFNO0FBRWpCSixxQkFBV0UsU0FBU0UsSUFBSTtBQUFBLFFBQzFCLE9BQU87QUFDTEoscUJBQVcsQ0FBQyxDQUFDO0FBQUEsUUFDZjtBQUFBLE1BQ0YsU0FBU0ssT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxvQ0FBb0NBLEtBQUs7QUFDdkRMLG1CQUFXLENBQUMsQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBRUFDLGlCQUFhO0FBQUEsRUFDZixHQUFHLENBQUNILEVBQUUsQ0FBQztBQUVQLFFBQU1TLGdCQUFnQkEsQ0FBQ0MsZUFBZTtBQUNwQyxVQUFNQyxPQUFPLElBQUlDLEtBQUtGLFVBQVU7QUFDaEMsV0FBT0MsS0FBS0UsbUJBQW1CLFNBQVM7QUFBQSxNQUN0Q0MsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsSUFDUixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1DLGNBQWMsWUFBWTtBQUM5QixVQUFNQyxpQkFBaUJDLFNBQVNDLGVBQWUsU0FBUztBQUN4RCxVQUFNQyxTQUFTLE1BQU01QixZQUFZeUIsZ0JBQWdCLEVBQUVJLE9BQU8sRUFBRSxDQUFDO0FBQzdELFVBQU1DLFVBQVVGLE9BQU9HLFVBQVUsV0FBVztBQUU1QyxVQUFNQyxNQUFNLElBQUlqQyxNQUFNLFlBQVksTUFBTSxJQUFJO0FBQzVDLFVBQU1rQyxZQUFZRCxJQUFJRSxTQUFTQyxTQUFTQyxTQUFTO0FBQ2pELFVBQU1DLGFBQWFMLElBQUlFLFNBQVNDLFNBQVNHLFVBQVU7QUFFbkROLFFBQUlPLFNBQVNULFNBQVMsT0FBTyxHQUFHLEdBQUdHLFdBQVdJLFVBQVU7QUFDeERMLFFBQUlRLEtBQUssdUJBQXVCO0FBQUEsRUFDbEM7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBTSxVQUFTLE9BQU8sRUFBRUMsV0FBVyxPQUFPLEdBQzdDO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNqQjtBQUFBQSxRQUNULFdBQVU7QUFBQSxRQUVWLGlDQUFDLGFBQVUsT0FBTSxZQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUE7QUFBQSxNQUozQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQTtBQUFBLElBSUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUc7QUFBQSxRQUNILE9BQU87QUFBQSxVQUNMa0IsT0FBTztBQUFBLFVBQ1BDLFFBQVE7QUFBQSxVQUNSQyxTQUFTO0FBQUEsVUFDVEMsUUFBUTtBQUFBLFVBQ1JDLGlCQUFpQjtBQUFBLFVBQ2pCQyxTQUFTO0FBQUEsVUFDVEMsZUFBZTtBQUFBLFVBQ2ZDLGdCQUFnQjtBQUFBLFVBQ2hCQyxLQUFLO0FBQUEsUUFDUDtBQUFBLFFBRUMsV0FBQyxHQUFHQyxNQUFNLENBQUMsQ0FBQyxFQUFFQztBQUFBQSxVQUFJLENBQUNDLEdBQUdDLFFBQ3JCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxPQUFPO0FBQUEsZ0JBQ0xaLE9BQU87QUFBQSxnQkFDUEcsUUFBUTtBQUFBLGdCQUNSVSxjQUFjO0FBQUEsZ0JBQ2RYLFNBQVM7QUFBQSxnQkFDVFksV0FBVztBQUFBLGNBQ2I7QUFBQSxjQUVBO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsS0FBS3BEO0FBQUFBLG9CQUNMLEtBQUk7QUFBQSxvQkFDSixPQUFNO0FBQUEsb0JBQ04sT0FBTyxFQUFFcUQsUUFBUSxjQUFjVixTQUFTLFFBQVE7QUFBQTtBQUFBLGtCQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSW9EO0FBQUEsZ0JBRXBELHVCQUFDLFFBQUcsT0FBTyxFQUFFVyxXQUFXLFVBQVVELFFBQVEsRUFBRSxHQUFHLHdCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQyxPQUFFLE9BQU8sRUFBRUMsV0FBVyxVQUFVQyxVQUFVLFFBQVFGLFFBQVEsUUFBUSxHQUFHO0FBQUE7QUFBQSxrQkFFcEUsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFHO0FBQUEsa0JBQUc7QUFBQSxxQkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFHO0FBQUEsZ0JBQ0gsdUJBQUMsUUFBRyxPQUFPLEVBQUVDLFdBQVcsVUFBVUQsUUFBUSxRQUFRLEdBQUcsdUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTREO0FBQUEsZ0JBQzVELHVCQUFDLFNBQUksT0FBTyxFQUFFQyxXQUFXLFFBQVEsR0FDL0I7QUFBQSx5Q0FBQyxPQUFFO0FBQUE7QUFBQSxvQkFBYWxELFFBQVFvRCxjQUFjcEQsUUFBUXFELGtCQUFrQjtBQUFBLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRTtBQUFBLGtCQUNwRSx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBT3JELFFBQVFzRCxXQUFXOUMsY0FBY1IsUUFBUXNELFFBQVEsSUFBSTtBQUFBLHVCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRTtBQUFBLGtCQUNuRSx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBT3RELFNBQVN1RCxTQUFTQyxhQUFhO0FBQUEsdUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZDO0FBQUEsa0JBQzdDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFZeEQsU0FBU3VELFNBQVNFLGdCQUFnQjtBQUFBLHVCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRDtBQUFBLGtCQUNyRCx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBUXpELFNBQVMwRCxVQUFVQyxjQUFjO0FBQUEsdUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdEO0FBQUEsa0JBQ2hELHVCQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFTM0QsU0FBUzRELFVBQVU7QUFBQSx1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxxQkFOckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU87QUFBQSxzQkFDTFYsV0FBVztBQUFBLHNCQUNYVyxZQUFZO0FBQUEsc0JBQ1p4QixRQUFRO0FBQUEsc0JBQ1JELFNBQVM7QUFBQSxzQkFDVGEsUUFBUTtBQUFBLG9CQUNWO0FBQUEsb0JBQUU7QUFBQTtBQUFBLHNCQUVtQmpELFNBQVM4RCxVQUFVO0FBQUE7QUFBQTtBQUFBLGtCQVQxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVosV0FBVyxRQUFRLEdBQy9CO0FBQUEseUNBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQW9CbEQsU0FBUytELHFCQUFxQjtBQUFBLHVCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxPQUFFO0FBQUE7QUFBQSxvQkFBZS9ELFNBQVNnRSxZQUFZO0FBQUEsdUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEsa0JBQzNDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLG9CQUFXaEUsU0FBUzhELFVBQVU7QUFBQSx1QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxrQkFDbkMsdUJBQUMsT0FBRTtBQUFBO0FBQUEsb0JBQWU5RCxTQUFTaUUsWUFBWUMsY0FBYztBQUFBLHVCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBLHFCQUovRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVqQyxXQUFXLE1BQU0sR0FBSWEsa0JBQVEsSUFBSSxrQkFBa0IsZ0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRFO0FBQUE7QUFBQTtBQUFBLFlBaER2RUE7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0RBO0FBQUEsUUFDRDtBQUFBO0FBQUEsTUFsRUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbUVBO0FBQUEsT0E3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThFQTtBQUVKO0FBQUVoRCxHQTlISUQsaUJBQWU7QUFBQSxVQUNKSCxTQUFTO0FBQUE7QUFBQXlFLEtBRHBCdEU7QUFnSU4sZUFBZUE7QUFBZ0IsSUFBQXNFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImpzUERGIiwiaHRtbDJjYW52YXMiLCJCaVByaW50ZXIiLCJ1c2VQYXJhbXMiLCJhcGkiLCJteWNoaXRzTG9nbyIsIlByaW50UGF5bWVudE91dCIsIl9zIiwiaWQiLCJwYXltZW50Iiwic2V0UGF5bWVudCIsImZldGNoUGF5bWVudCIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImZvcm1hdFBheURhdGUiLCJkYXRlU3RyaW5nIiwiZGF0ZSIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJoYW5kbGVQcmludCIsInJlY2VpcHRFbGVtZW50IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsImNhbnZhcyIsInNjYWxlIiwiaW1nRGF0YSIsInRvRGF0YVVSTCIsInBkZiIsInBhZ2VXaWR0aCIsImludGVybmFsIiwicGFnZVNpemUiLCJnZXRXaWR0aCIsInBhZ2VIZWlnaHQiLCJnZXRIZWlnaHQiLCJhZGRJbWFnZSIsInNhdmUiLCJtYXJnaW5Ub3AiLCJ3aWR0aCIsImhlaWdodCIsInBhZGRpbmciLCJib3JkZXIiLCJiYWNrZ3JvdW5kQ29sb3IiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImp1c3RpZnlDb250ZW50IiwiZ2FwIiwiQXJyYXkiLCJtYXAiLCJfIiwiaWR4IiwiYm9yZGVyUmFkaXVzIiwiYm94U2hhZG93IiwibWFyZ2luIiwidGV4dEFsaWduIiwiZm9udFNpemUiLCJyZWNlaXB0X25vIiwib2xkX3JlY2VpcHRfbm8iLCJwYXlfZGF0ZSIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXQiLCJmb250V2VpZ2h0IiwiYW1vdW50IiwiZGlzYnVyc2VtZW50X3R5cGUiLCJwYXlfdHlwZSIsImFkbWluX3R5cGUiLCJhZG1pbl9uYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJpbnRQYXltZW50T3V0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQganNQREYgZnJvbSBcImpzcGRmXCI7XHJcbmltcG9ydCBodG1sMmNhbnZhcyBmcm9tIFwiaHRtbDJjYW52YXNcIjtcclxuaW1wb3J0IHsgQmlQcmludGVyIH0gZnJvbSBcInJlYWN0LWljb25zL2JpXCI7XHJcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IG15Y2hpdHNMb2dvIGZyb20gXCIuLi9hc3NldHMvaW1hZ2VzL215Y2hpdHMucG5nXCI7XHJcblxyXG5jb25zdCBQcmludFBheW1lbnRPdXQgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgY29uc3QgW3BheW1lbnQsIHNldFBheW1lbnRdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hQYXltZW50ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQtb3V0L2dldC1wYXltZW50LW91dC1ieS1pZC8ke2lkfWApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgLy8gICBjb25zb2xlLmxvZyhcIkZldGNoZWQgUGF5bWVudCBPdXQgRGF0YTpcIiwgcmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgICBzZXRQYXltZW50KHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRQYXltZW50KHt9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgb3V0IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRQYXltZW50KHt9KTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFBheW1lbnQoKTtcclxuICB9LCBbaWRdKTtcclxuXHJcbiAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICByZXR1cm4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiLCB7XHJcbiAgICAgIGRheTogXCJudW1lcmljXCIsXHJcbiAgICAgIG1vbnRoOiBcInNob3J0XCIsXHJcbiAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCByZWNlaXB0RWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmVjZWlwdFwiKTtcclxuICAgIGNvbnN0IGNhbnZhcyA9IGF3YWl0IGh0bWwyY2FudmFzKHJlY2VpcHRFbGVtZW50LCB7IHNjYWxlOiAyIH0pO1xyXG4gICAgY29uc3QgaW1nRGF0YSA9IGNhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS9wbmdcIik7XHJcblxyXG4gICAgY29uc3QgcGRmID0gbmV3IGpzUERGKFwicG9ydHJhaXRcIiwgXCJtbVwiLCBcImE0XCIpO1xyXG4gICAgY29uc3QgcGFnZVdpZHRoID0gcGRmLmludGVybmFsLnBhZ2VTaXplLmdldFdpZHRoKCk7XHJcbiAgICBjb25zdCBwYWdlSGVpZ2h0ID0gcGRmLmludGVybmFsLnBhZ2VTaXplLmdldEhlaWdodCgpO1xyXG5cclxuICAgIHBkZi5hZGRJbWFnZShpbWdEYXRhLCBcIlBOR1wiLCAwLCAwLCBwYWdlV2lkdGgsIHBhZ2VIZWlnaHQpO1xyXG4gICAgcGRmLnNhdmUoXCJQYXltZW50T3V0UmVjZWlwdC5wZGZcIik7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgYWxpZ249XCJjZW50ZXJcIiBzdHlsZT17eyBtYXJnaW5Ub3A6IFwiODBweFwiIH19PlxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnR9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci12aW9sZXQtNDAwIHRleHQtd2hpdGUgcHgtNCBweS0yIG1iLTUgcm91bmRlZC1tZCBzaGFkb3cgaG92ZXI6Ym9yZGVyLXZpb2xldC03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgbXQtNFwiXHJcbiAgICAgID5cclxuICAgICAgICA8QmlQcmludGVyIGNvbG9yPVwidmlvbGV0XCIgLz5cclxuICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgIFxyXG5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGlkPVwicmVjZWlwdFwiXHJcbiAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgIHdpZHRoOiBcIjIxMG1tXCIsXHJcbiAgICAgICAgICBoZWlnaHQ6IFwiMjk3bW1cIixcclxuICAgICAgICAgIHBhZGRpbmc6IFwiMTBtbVwiLFxyXG4gICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZGRkXCIsXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcInJvd1wiLFxyXG4gICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICAgICAgZ2FwOiBcIjEwbW1cIixcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAge1suLi5BcnJheSgyKV0ubWFwKChfLCBpZHgpID0+IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgd2lkdGg6IFwiNDglXCIsXHJcbiAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZGRkXCIsXHJcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjhweFwiLFxyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTVweFwiLFxyXG4gICAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDAgMTBweCByZ2JhKDAsIDAsIDAsIDAuMSlcIixcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz17bXljaGl0c0xvZ299XHJcbiAgICAgICAgICAgICAgYWx0PVwiQ29tcGFueSBMb2dvXCJcclxuICAgICAgICAgICAgICB3aWR0aD1cIjQwXCJcclxuICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW46IFwiMCBhdXRvIDhweFwiLCBkaXNwbGF5OiBcImJsb2NrXCIgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGgyIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgbWFyZ2luOiAwIH19Pk1ZIENISVRTPC9oMj5cclxuICAgICAgICAgICAgPHAgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBmb250U2l6ZTogXCIxMnB4XCIsIG1hcmdpbjogXCI1cHggMFwiIH19PlxyXG4gICAgICAgICAgICAgIE5vLjExLzM2LTI1LCAybmQgTWFpbiwgS2F0aHJpZ3VwcGUgTWFpbiBSb2FkLFxyXG4gICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgIEJhbmdhbG9yZSwgNTYwMDg1IDk0ODM5MDA3NzdcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8aHIgLz5cclxuICAgICAgICAgICAgPGgzIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiwgbWFyZ2luOiBcIjVweCAwXCIgfX0+UmVjZWlwdDwvaDM+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcInN0YXJ0XCIgfX0+XHJcbiAgICAgICAgICAgICAgPHA+UmVjZWlwdCBObzoge3BheW1lbnQucmVjZWlwdF9ubyB8fCBwYXltZW50Lm9sZF9yZWNlaXB0X25vIHx8IFwiLVwifTwvcD5cclxuICAgICAgICAgICAgICA8cD5EYXRlOiB7cGF5bWVudC5wYXlfZGF0ZSA/IGZvcm1hdFBheURhdGUocGF5bWVudC5wYXlfZGF0ZSkgOiBcIi1cIn08L3A+XHJcbiAgICAgICAgICAgICAgPHA+TmFtZToge3BheW1lbnQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIi1cIn08L3A+XHJcbiAgICAgICAgICAgICAgPHA+TW9iaWxlIE5vOiB7cGF5bWVudD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwifTwvcD5cclxuICAgICAgICAgICAgICA8cD5Hcm91cDoge3BheW1lbnQ/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiLVwifTwvcD5cclxuICAgICAgICAgICAgICA8cD5UaWNrZXQ6IHtwYXltZW50Py50aWNrZXQgfHwgXCItXCJ9PC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgIzAwMFwiLFxyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMHB4XCIsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IFwiMTBweCAwXCIsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFBheSBPdXQgQW1vdW50IHwgUnMue3BheW1lbnQ/LmFtb3VudCB8fCAwfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwic3RhcnRcIiB9fT5cclxuICAgICAgICAgICAgICA8cD5EaXNidXJzZW1lbnQgVHlwZToge3BheW1lbnQ/LmRpc2J1cnNlbWVudF90eXBlIHx8IFwiLVwifTwvcD5cclxuICAgICAgICAgICAgICA8cD5QYXltZW50IE1vZGU6IHtwYXltZW50Py5wYXlfdHlwZSB8fCBcIi1cIn08L3A+XHJcbiAgICAgICAgICAgICAgPHA+VG90YWw6IFJzLntwYXltZW50Py5hbW91bnQgfHwgMH08L3A+XHJcbiAgICAgICAgICAgICAgPHA+RGlzYnVyc2VkIEJ5OiB7cGF5bWVudD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fCBcIkFkbWluXCJ9PC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luVG9wOiBcIjRweFwiIH19PntpZHggPT09IDAgPyBcIkN1c3RvbWVyIENvcHlcIiA6IFwiQWRtaW4gQ29weVwifTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcmludFBheW1lbnRPdXQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QcmludFBheW1lbnRPdXQuanN4In0=