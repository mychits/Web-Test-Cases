import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Print.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
import { BiPrinter } from "/node_modules/.vite/deps/react-icons_bi.js?v=819e0a34";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import mychitsLogo from "/src/assets/images/mychits.png?import";
import "/src/css/BasicPrintReceipt.css";
const ReceiptComponent = () => {
  _s();
  const { id } = useParams();
  const [payment, setPayment] = useState({});
  const [loading, setLoading] = useState(true);
  const [printFormat, setPrintFormat] = useState("vertical");
  useEffect(() => {
    const fetchPayment = async () => {
      if (!id) return;
      try {
        setLoading(true);
        const response = await api.get(`/payment/get-payment-by-id/${id}`);
        setPayment(response.data || {});
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPayment();
  }, [id]);
  const formatPayDate = (dateString) => {
    if (!dateString) return "N/A";
    const d = new Date(dateString);
    return d.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  };
  const numberToWords = (num) => {
    if (num === 0) return "Zero";
    const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
    const tens = ["", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
    const twenties = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    const numToWords = (n) => {
      if (n < 10) return ones[n];
      if (n < 20) return tens[n - 10];
      if (n < 100) return twenties[Math.floor(n / 10)] + (n % 10 ? " " + ones[n % 10] : "");
      if (n < 1e3) return ones[Math.floor(n / 100)] + " Hundred" + (n % 100 ? " " + numToWords(n % 100) : "");
      if (n < 1e5) return numToWords(Math.floor(n / 1e3)) + " Thousand" + (n % 1e3 ? " " + numToWords(n % 1e3) : "");
      if (n < 1e7) return numToWords(Math.floor(n / 1e5)) + " Lakh" + (n % 1e5 ? " " + numToWords(n % 1e5) : "");
      return numToWords(Math.floor(n / 1e7)) + " Crore" + (n % 1e7 ? " " + numToWords(n % 1e7) : "");
    };
    return numToWords(num);
  };
  const handlePrint = async () => {
    if (printFormat === "vertical") {
      window.print();
    } else if (printFormat === "horizontal") {
      window.print();
    }
  };
  const VerticalReceiptSection = ({ copyType }) => /* @__PURE__ */ jsxDEV("div", { className: "pro-receipt", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pro-header", children: /* @__PURE__ */ jsxDEV("div", { className: "pro-left", children: [
      /* @__PURE__ */ jsxDEV("img", { src: mychitsLogo, className: "pro-logo", alt: "" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 349,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "pro-company", children: "MY CHITS" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 351,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "pro-address", children: [
          "No.11/36-25, Kathriguppe Main Road,",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 354,
            columnNumber: 15
          }, this),
          "Bangalore - 560085 | 9483900777"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 352,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 350,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 348,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 347,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-title", children: "PAYMENT RECEIPT" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 361,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-box", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "pro-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Receipt No:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 366,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment.receipt_no || payment.old_receipt_no }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 367,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 365,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Date:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 370,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatPayDate(payment.pay_date) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 371,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 369,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 364,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pro-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Name:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 377,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.user_id?.full_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 378,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 376,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Mobile:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 381,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.user_id?.phone_number }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 382,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 380,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 375,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pro-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Group:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 388,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.group_id?.group_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 389,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 387,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Ticket:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 392,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.ticket }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 393,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 391,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 386,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 363,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-amount-box", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Received Amount:" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 399,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "val", children: [
        "₹ ",
        payment?.amount
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 400,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 398,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-box", children: /* @__PURE__ */ jsxDEV("div", { className: "pro-row", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Payment Mode:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 406,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: payment?.pay_type }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 407,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 405,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Collected By:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 410,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: payment?.collected_by?.name || "Admin" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 411,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 409,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 404,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 403,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-footer-container-vertical", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "pro-type-box", children: [
        copyType,
        " Copy"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 417,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pro-footer", children: /* @__PURE__ */ jsxDEV("div", { className: "sign", children: "Authorized Signature" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 419,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 418,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 416,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
    lineNumber: 346,
    columnNumber: 3
  }, this);
  const HorizontalReceiptSection = ({ copyType }) => /* @__PURE__ */ jsxDEV("div", { className: "pro-receipt", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "pro-header", children: /* @__PURE__ */ jsxDEV("div", { className: "pro-center", children: [
      /* @__PURE__ */ jsxDEV("img", { src: mychitsLogo, className: "pro-logo" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 432,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "pro-company", children: "MY CHITS" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 434,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "pro-address", children: [
          "No.11/36-25, 2nd Main, Kathriguppe Main Road,",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 436,
            columnNumber: 60
          }, this),
          "Bangalore - 560085 | 9483900777"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 435,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 433,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 431,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 430,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-title", children: "PAYMENT RECEIPT" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 443,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-box", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "pro-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Receipt No:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 448,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment.receipt_no || payment.old_receipt_no }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 449,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 447,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Name:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 453,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.user_id?.full_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 454,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 452,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Date:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 458,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formatPayDate(payment.pay_date) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 459,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 457,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 446,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pro-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Mobile:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 465,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.user_id?.phone_number }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 466,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 464,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Group:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 470,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.group_id?.group_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 471,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 469,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Ticket:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 475,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: payment?.ticket }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 476,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 474,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 463,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 445,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-box", children: /* @__PURE__ */ jsxDEV("div", { className: "pro-row", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Payment Mode:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 486,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: payment?.pay_type }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 487,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 485,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pro-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Collected By:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 491,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: payment?.collected_by?.name || "Admin" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 492,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 490,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 484,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 483,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-amount-box", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Received Amount:" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 498,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "val", children: [
        "₹ ",
        payment?.amount
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 499,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 497,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-amount-words", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Amount in Words:" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 504,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "val", children: [
        numberToWords(payment?.amount || 0),
        " Rupees Only"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 505,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 503,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "pro-footer-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "pro-type-box", children: [
        copyType,
        " Copy"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 509,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pro-footer", children: /* @__PURE__ */ jsxDEV("div", { className: "sign", children: "Authorized Signature" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 511,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 510,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 508,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
    lineNumber: 429,
    columnNumber: 3
  }, this);
  if (loading)
    return /* @__PURE__ */ jsxDEV("div", { className: "loading-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "loading-spinner" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 521,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Loading receipt details..." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 522,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 520,
      columnNumber: 5
    }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "receipt-container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "print-options-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "print-button-container", children: /* @__PURE__ */ jsxDEV("button", { onClick: handlePrint, className: "print-button", children: [
        /* @__PURE__ */ jsxDEV(BiPrinter, { size: 20 }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 531,
          columnNumber: 13
        }, this),
        " Print Receipt"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 530,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 529,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "format-selector", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "radio-label", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "radio",
              value: "horizontal",
              checked: printFormat === "horizontal",
              onChange: () => setPrintFormat("horizontal")
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
              lineNumber: 537,
              columnNumber: 13
            },
            this
          ),
          "Format 1"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 536,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "radio-label", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "radio",
              value: "vertical",
              checked: printFormat === "vertical",
              onChange: () => setPrintFormat("vertical")
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
              lineNumber: 547,
              columnNumber: 13
            },
            this
          ),
          "Format 2"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 546,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 535,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
      lineNumber: 528,
      columnNumber: 7
    }, this),
    printFormat === "vertical" ? (
      // Vertical Format
      /* @__PURE__ */ jsxDEV("div", { className: "vertical-format", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "receipt-wrapper", children: /* @__PURE__ */ jsxDEV("div", { className: "side-by-side", children: [
          /* @__PURE__ */ jsxDEV(VerticalReceiptSection, { copyType: "Duplicate" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 565,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(VerticalReceiptSection, { copyType: "Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
            lineNumber: 566,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 564,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 563,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "a4-bottom-empty" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 571,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 561,
        columnNumber: 7
      }, this)
    ) : (
      // Horizontal Format
      /* @__PURE__ */ jsxDEV("div", { id: "receipt-to-print", className: "receipt-wrapper horizontal-format", children: [
        /* @__PURE__ */ jsxDEV(HorizontalReceiptSection, { copyType: "Duplicate" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 576,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "cut-line" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 577,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(HorizontalReceiptSection, { copyType: "Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 578,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "a4-bottom-empty" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
          lineNumber: 579,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
        lineNumber: 575,
        columnNumber: 7
      }, this)
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx",
    lineNumber: 527,
    columnNumber: 5
  }, this);
};
_s(ReceiptComponent, "D0rDpajZEdm2SrPD5iprZiSqtq8=", false, function() {
  return [useParams];
});
_c = ReceiptComponent;
export default ReceiptComponent;
var _c;
$RefreshReg$(_c, "ReceiptComponent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Print.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNFZVOzJCQTVWVjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBTztBQW1SUCxNQUFNQyxtQkFBbUJBLE1BQU07QUFBQUMsS0FBQTtBQUM3QixRQUFNLEVBQUVDLEdBQUcsSUFBSUwsVUFBVTtBQUN6QixRQUFNLENBQUNNLFNBQVNDLFVBQVUsSUFBSVgsU0FBUyxDQUFDLENBQUM7QUFDekMsUUFBTSxDQUFDWSxTQUFTQyxVQUFVLElBQUliLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNjLGFBQWFDLGNBQWMsSUFBSWYsU0FBUyxVQUFVO0FBRXpERCxZQUFVLE1BQU07QUFDZCxVQUFNaUIsZUFBZSxZQUFZO0FBQy9CLFVBQUksQ0FBQ1AsR0FBSTtBQUNULFVBQUk7QUFDRkksbUJBQVcsSUFBSTtBQUNmLGNBQU1JLFdBQVcsTUFBTVosSUFBSWEsSUFBSSw4QkFBOEJULEVBQUUsRUFBRTtBQUNqRUUsbUJBQVdNLFNBQVNFLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDaEMsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxNQUM3QyxVQUFDO0FBQ0NQLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFDQUcsaUJBQWE7QUFBQSxFQUNmLEdBQUcsQ0FBQ1AsRUFBRSxDQUFDO0FBRVAsUUFBTWEsZ0JBQWdCQSxDQUFDQyxlQUFlO0FBQ3BDLFFBQUksQ0FBQ0EsV0FBWSxRQUFPO0FBQ3hCLFVBQU1DLElBQUksSUFBSUMsS0FBS0YsVUFBVTtBQUM3QixXQUFPQyxFQUFFRSxtQkFBbUIsU0FBUztBQUFBLE1BQ25DQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxJQUNSLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTUMsZ0JBQWdCQSxDQUFDQyxRQUFRO0FBQzdCLFFBQUlBLFFBQVEsRUFBRyxRQUFPO0FBRXRCLFVBQU1DLE9BQU8sQ0FBQyxJQUFJLE9BQU8sT0FBTyxTQUFTLFFBQVEsUUFBUSxPQUFPLFNBQVMsU0FBUyxNQUFNO0FBQ3hGLFVBQU1DLE9BQU8sQ0FBQyxJQUFJLE9BQU8sVUFBVSxVQUFVLFlBQVksWUFBWSxXQUFXLFdBQVcsYUFBYSxZQUFZLFVBQVU7QUFDOUgsVUFBTUMsV0FBVyxDQUFDLElBQUksSUFBSSxVQUFVLFVBQVUsU0FBUyxTQUFTLFNBQVMsV0FBVyxVQUFVLFFBQVE7QUFFdEcsVUFBTUMsYUFBYUEsQ0FBQ0MsTUFBTTtBQUN4QixVQUFJQSxJQUFJLEdBQUksUUFBT0osS0FBS0ksQ0FBQztBQUN6QixVQUFJQSxJQUFJLEdBQUksUUFBT0gsS0FBS0csSUFBSSxFQUFFO0FBQzlCLFVBQUlBLElBQUksSUFBSyxRQUFPRixTQUFTRyxLQUFLQyxNQUFNRixJQUFJLEVBQUUsQ0FBQyxLQUFLQSxJQUFJLEtBQUssTUFBTUosS0FBS0ksSUFBSSxFQUFFLElBQUk7QUFDbEYsVUFBSUEsSUFBSSxJQUFNLFFBQU9KLEtBQUtLLEtBQUtDLE1BQU1GLElBQUksR0FBRyxDQUFDLElBQUksY0FBY0EsSUFBSSxNQUFNLE1BQU1ELFdBQVdDLElBQUksR0FBRyxJQUFJO0FBQ3JHLFVBQUlBLElBQUksSUFBUSxRQUFPRCxXQUFXRSxLQUFLQyxNQUFNRixJQUFJLEdBQUksQ0FBQyxJQUFJLGVBQWVBLElBQUksTUFBTyxNQUFNRCxXQUFXQyxJQUFJLEdBQUksSUFBSTtBQUNqSCxVQUFJQSxJQUFJLElBQVUsUUFBT0QsV0FBV0UsS0FBS0MsTUFBTUYsSUFBSSxHQUFNLENBQUMsSUFBSSxXQUFXQSxJQUFJLE1BQVMsTUFBTUQsV0FBV0MsSUFBSSxHQUFNLElBQUk7QUFDckgsYUFBT0QsV0FBV0UsS0FBS0MsTUFBTUYsSUFBSSxHQUFRLENBQUMsSUFBSSxZQUFZQSxJQUFJLE1BQVcsTUFBTUQsV0FBV0MsSUFBSSxHQUFRLElBQUk7QUFBQSxJQUM1RztBQUVBLFdBQU9ELFdBQVdKLEdBQUc7QUFBQSxFQUN2QjtBQUVBLFFBQU1RLGNBQWMsWUFBWTtBQUM5QixRQUFJekIsZ0JBQWdCLFlBQVk7QUFDOUIwQixhQUFPQyxNQUFNO0FBQUEsSUFDZixXQUFXM0IsZ0JBQWdCLGNBQWM7QUFDdkMwQixhQUFPQyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFHQSxRQUFNQyx5QkFBeUJBLENBQUMsRUFBRUMsU0FBUyxNQUN6Qyx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsNkJBQUMsU0FBSSxLQUFLckMsYUFBYSxXQUFVLFlBQVcsS0FBSSxNQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtEO0FBQUEsTUFDbEQsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxlQUFjLHdCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDcEMsdUJBQUMsT0FBRSxXQUFVLGVBQWM7QUFBQTtBQUFBLFVBRXpCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQUc7QUFBQSxhQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUFZLCtCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsSUFFMUMsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLE9BQU0sMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFDakMsdUJBQUMsVUFBTUksa0JBQVFrQyxjQUFjbEMsUUFBUW1DLGtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLGFBRnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsT0FBTSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQix1QkFBQyxVQUFNdkIsd0JBQWNaLFFBQVFvQyxRQUFRLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsYUFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsT0FBTSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQix1QkFBQyxVQUFNcEMsbUJBQVNxQyxTQUFTQyxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQztBQUFBLGFBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsT0FBTSx1QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUM3Qix1QkFBQyxVQUFNdEMsbUJBQVNxQyxTQUFTRSxnQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxhQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxPQUFNLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFVBQzVCLHVCQUFDLFVBQU12QyxtQkFBU3dDLFVBQVVDLGNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsYUFGdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxPQUFNLHVCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQzdCLHVCQUFDLFVBQU16QyxtQkFBUzBDLFVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsYUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsT0FBTSxnQ0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLE1BQ3RDLHVCQUFDLFVBQUssV0FBVSxPQUFNO0FBQUE7QUFBQSxRQUFHMUMsU0FBUzJDO0FBQUFBLFdBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxXQUNiLGlDQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsT0FBTSw2QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ25DLHVCQUFDLFVBQU0zQyxtQkFBUzRDLFlBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxXQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLE9BQU0sNkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUNuQyx1QkFBQyxVQUFNNUMsbUJBQVM2QyxjQUFjQyxRQUFRLFdBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxXQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUFnQmI7QUFBQUE7QUFBQUEsUUFBUztBQUFBLFdBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkM7QUFBQSxNQUM3Qyx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsUUFBTyxvQ0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4RUE7QUFJRixRQUFNYywyQkFBMkJBLENBQUMsRUFBRWQsU0FBUyxNQUMzQyx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsU0FBSSxLQUFLckMsYUFBYSxXQUFVLGNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkM7QUFBQSxNQUMzQyx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGVBQWMsd0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUNwQyx1QkFBQyxPQUFFLFdBQVUsZUFBYztBQUFBO0FBQUEsVUFDb0IsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFHO0FBQUEsVUFBRztBQUFBLGFBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUFZLCtCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsSUFFMUMsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLE9BQU0sMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUEsVUFDakMsdUJBQUMsVUFBTUksa0JBQVFrQyxjQUFjbEMsUUFBUW1DLGtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLGFBRnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsT0FBTSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQix1QkFBQyxVQUFNbkMsbUJBQVNxQyxTQUFTQyxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQztBQUFBLGFBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsT0FBTSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQix1QkFBQyxVQUFNMUIsd0JBQWNaLFFBQVFvQyxRQUFRLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsYUFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsT0FBTSx1QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUM3Qix1QkFBQyxVQUFNcEMsbUJBQVNxQyxTQUFTRSxnQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxhQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLE9BQU0sc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsVUFDNUIsdUJBQUMsVUFBTXZDLG1CQUFTd0MsVUFBVUMsY0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQSxhQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLE9BQU0sdUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsVUFDN0IsdUJBQUMsVUFBTXpDLG1CQUFTMEMsVUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxhQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUlBLHVCQUFDLFNBQUksV0FBVSxXQUNiLGlDQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsT0FBTSw2QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ25DLHVCQUFDLFVBQU0xQyxtQkFBUzRDLFlBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxXQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLE9BQU0sNkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUNuQyx1QkFBQyxVQUFNNUMsbUJBQVM2QyxjQUFjQyxRQUFRLFdBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxXQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsNkJBQUMsVUFBSyxXQUFVLE9BQU0sZ0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQSxNQUN0Qyx1QkFBQyxVQUFLLFdBQVUsT0FBTTtBQUFBO0FBQUEsUUFBRzlDLFNBQVMyQztBQUFBQSxXQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsU0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsT0FBTSxnQ0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLE1BQ3RDLHVCQUFDLFVBQUssV0FBVSxPQUFPdkI7QUFBQUEsc0JBQWNwQixTQUFTMkMsVUFBVSxDQUFDO0FBQUEsUUFBRTtBQUFBLFdBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxTQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFBZ0JWO0FBQUFBO0FBQUFBLFFBQVM7QUFBQSxXQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZDO0FBQUEsTUFDN0MsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsU0FBSSxXQUFVLFFBQU8sb0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxPQXJGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0ZBO0FBR0YsTUFBSS9CO0FBQ0YsV0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ2pDLHVCQUFDLE9BQUUsMENBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLFNBRi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUdKLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBCQUNiLGlDQUFDLFlBQU8sU0FBUzJCLGFBQWEsV0FBVSxnQkFDdEM7QUFBQSwrQkFBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQjtBQUFBLFFBQUc7QUFBQSxXQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxlQUNmO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU07QUFBQSxjQUNOLFNBQVN6QixnQkFBZ0I7QUFBQSxjQUV6QixVQUFVLE1BQU1DLGVBQWUsWUFBWTtBQUFBO0FBQUEsWUFMN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSytDO0FBQUE7QUFBQSxhQU5qRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFdBQU0sV0FBVSxlQUNmO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU07QUFBQSxjQUNOLFNBQVNELGdCQUFnQjtBQUFBLGNBRXpCLFVBQVUsTUFBTUMsZUFBZSxVQUFVO0FBQUE7QUFBQSxZQUwzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLNkM7QUFBQTtBQUFBLGFBTi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsSUFFQ0QsZ0JBQWdCO0FBQUE7QUFBQSxNQUVmLHVCQUFDLFNBQUksV0FBVSxtQkFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxpQ0FBQywwQkFBdUIsVUFBUyxlQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLFVBQzVDLHVCQUFDLDBCQUF1QixVQUFTLGNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsYUFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUscUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFdBVm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBO0FBQUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksSUFBRyxvQkFBbUIsV0FBVSxxQ0FDbkM7QUFBQSwrQkFBQyw0QkFBeUIsVUFBUyxlQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUMsdUJBQUMsU0FBSSxXQUFVLGNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQzFCLHVCQUFDLDRCQUF5QixVQUFTLGNBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxTQUFJLFdBQVUscUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFdBSm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBO0FBQUEsT0FyREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVEQTtBQUVKO0FBQUVOLEdBN1NJRCxrQkFBZ0I7QUFBQSxVQUNMSCxTQUFTO0FBQUE7QUFBQXNELEtBRHBCbkQ7QUF3VE4sZUFBZUE7QUFBaUIsSUFBQW1EO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImpzUERGIiwiaHRtbDJjYW52YXMiLCJCaVByaW50ZXIiLCJ1c2VQYXJhbXMiLCJhcGkiLCJteWNoaXRzTG9nbyIsIlJlY2VpcHRDb21wb25lbnQiLCJfcyIsImlkIiwicGF5bWVudCIsInNldFBheW1lbnQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInByaW50Rm9ybWF0Iiwic2V0UHJpbnRGb3JtYXQiLCJmZXRjaFBheW1lbnQiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmb3JtYXRQYXlEYXRlIiwiZGF0ZVN0cmluZyIsImQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwibnVtYmVyVG9Xb3JkcyIsIm51bSIsIm9uZXMiLCJ0ZW5zIiwidHdlbnRpZXMiLCJudW1Ub1dvcmRzIiwibiIsIk1hdGgiLCJmbG9vciIsImhhbmRsZVByaW50Iiwid2luZG93IiwicHJpbnQiLCJWZXJ0aWNhbFJlY2VpcHRTZWN0aW9uIiwiY29weVR5cGUiLCJyZWNlaXB0X25vIiwib2xkX3JlY2VpcHRfbm8iLCJwYXlfZGF0ZSIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXQiLCJhbW91bnQiLCJwYXlfdHlwZSIsImNvbGxlY3RlZF9ieSIsIm5hbWUiLCJIb3Jpem9udGFsUmVjZWlwdFNlY3Rpb24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcmludC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGpzUERGIGZyb20gXCJqc3BkZlwiO1xyXG5pbXBvcnQgaHRtbDJjYW52YXMgZnJvbSBcImh0bWwyY2FudmFzXCI7XHJcbmltcG9ydCB7IEJpUHJpbnRlciB9IGZyb20gXCJyZWFjdC1pY29ucy9iaVwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBteWNoaXRzTG9nbyBmcm9tIFwiLi4vYXNzZXRzL2ltYWdlcy9teWNoaXRzLnBuZ1wiO1xyXG5pbXBvcnQgXCIuLi9jc3MvQmFzaWNQcmludFJlY2VpcHQuY3NzXCJcclxuXHJcbi8vIGNvbnN0IFJlY2VpcHRDb21wb25lbnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKCk7XHJcbi8vICAgY29uc3QgW3BheW1lbnQsIHNldFBheW1lbnRdID0gdXNlU3RhdGUoe30pO1xyXG4vLyAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4vLyAgIGNvbnN0IFtwcmludEZvcm1hdCwgc2V0UHJpbnRGb3JtYXRdID0gdXNlU3RhdGUoJ3ZlcnRpY2FsJyk7IC8vICd2ZXJ0aWNhbCcgb3IgJ2hvcml6b250YWwnXHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmZXRjaFBheW1lbnQgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIGlmICghaWQpIHJldHVybjtcclxuLy8gICAgICAgdHJ5IHtcclxuLy8gICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvZ2V0LXBheW1lbnQtYnktaWQvJHtpZH1gKTtcclxuLy8gICAgICAgICBzZXRQYXltZW50KHJlc3BvbnNlLmRhdGEgfHwge30pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH07XHJcbi8vICAgICBmZXRjaFBheW1lbnQoKTtcclxuLy8gICB9LCBbaWRdKTtcclxuXHJcbi8vICAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbi8vICAgICBpZiAoIWRhdGVTdHJpbmcpIHJldHVybiBcIk4vQVwiO1xyXG4vLyAgICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4vLyAgICAgcmV0dXJuIGQudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4vLyAgICAgICBkYXk6IFwiMi1kaWdpdFwiLFxyXG4vLyAgICAgICBtb250aDogXCJzaG9ydFwiLFxyXG4vLyAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuLy8gICAgIH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVByaW50ID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgaWYgKHByaW50Rm9ybWF0ID09PSAndmVydGljYWwnKSB7XHJcbi8vICAgICAgIHdpbmRvdy5wcmludCgpO1xyXG4vLyAgICAgfSBlbHNlIGlmIChwcmludEZvcm1hdCA9PT0gJ2hvcml6b250YWwnKXtcclxuXHJcbi8vICAgICAgIHdpbmRvdy5wcmludCgpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIFZlcnRpY2FsIFJlY2VpcHQgQ29tcG9uZW50XHJcbi8vICAgY29uc3QgVmVydGljYWxSZWNlaXB0U2VjdGlvbiA9ICh7IGNvcHlUeXBlIH0pID0+IChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJlY2VpcHRcIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taGVhZGVyXCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tbGVmdFwiPlxyXG4vLyAgICAgICAgICAgPGltZyBzcmM9e215Y2hpdHNMb2dvfSBjbGFzc05hbWU9XCJwcm8tbG9nb1wiIGFsdD1cIlwiIC8+XHJcbi8vICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwicHJvLWNvbXBhbnlcIj5NWSBDSElUUzwvaDI+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInByby1hZGRyZXNzXCI+XHJcbi8vICAgICAgICAgICAgICAgTm8uMTEvMzYtMjUsIEthdGhyaWd1cHBlIE1haW4gUm9hZCxcclxuLy8gICAgICAgICAgICAgICA8YnIgLz5cclxuLy8gICAgICAgICAgICAgICBCYW5nYWxvcmUgLSA1NjAwODUgfCA5NDgzOTAwNzc3XHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXRpdGxlXCI+UEFZTUVOVCBSRUNFSVBUPC9kaXY+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1ib3hcIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1yb3dcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+UmVjZWlwdCBObzo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50LnJlY2VpcHRfbm8gfHwgcGF5bWVudC5vbGRfcmVjZWlwdF9ub308L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+RGF0ZTo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntmb3JtYXRQYXlEYXRlKHBheW1lbnQucGF5X2RhdGUpfTwvc3Bhbj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1yb3dcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+TmFtZTo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py51c2VyX2lkPy5mdWxsX25hbWV9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbi8vICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPk1vYmlsZTo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py51c2VyX2lkPy5waG9uZV9udW1iZXJ9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJvd1wiPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5Hcm91cDo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py5ncm91cF9pZD8uZ3JvdXBfbmFtZX08L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+VGlja2V0Ojwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQ/LnRpY2tldH08L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1hbW91bnQtYm94XCI+XHJcbi8vICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+UmVjZWl2ZWQgQW1vdW50Ojwvc3Bhbj5cclxuLy8gICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2YWxcIj7igrkge3BheW1lbnQ/LmFtb3VudH08L3NwYW4+XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tYm94XCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tcm93XCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbi8vICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPlBheW1lbnQgTW9kZTo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py5wYXlfdHlwZX08L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+Q29sbGVjdGVkIEJ5Ojwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQ/LmNvbGxlY3RlZF9ieT8ubmFtZSB8fCBcIkFkbWluXCJ9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tZm9vdGVyXCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWduXCI+QXV0aG9yaXplZCBTaWduYXR1cmU8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby10eXBlLWJveFwiPntjb3B5VHlwZX0gQ29weTwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuXHJcbi8vICAgLy8gSG9yaXpvbnRhbCBSZWNlaXB0IENvbXBvbmVudFxyXG4vLyAgIGNvbnN0IEhvcml6b250YWxSZWNlaXB0U2VjdGlvbiA9ICh7IGNvcHlUeXBlIH0pID0+IChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJlY2VpcHRcIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taGVhZGVyXCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tY2VudGVyXCI+XHJcbi8vICAgICAgICAgICA8aW1nIHNyYz17bXljaGl0c0xvZ299IGNsYXNzTmFtZT1cInByby1sb2dvXCIgLz5cclxuLy8gICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJwcm8tY29tcGFueVwiPk1ZIENISVRTPC9oMj5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHJvLWFkZHJlc3NcIj5cclxuLy8gICAgICAgICAgICAgICBOby4xMS8zNi0yNSwgMm5kIE1haW4sIEthdGhyaWd1cHBlIE1haW4gUm9hZCw8YnIgLz5cclxuLy8gICAgICAgICAgICAgICBCYW5nYWxvcmUgLSA1NjAwODUgfCA5NDgzOTAwNzc3XHJcbi8vICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby10aXRsZVwiPlBBWU1FTlQgUkVDRUlQVDwvZGl2PlxyXG5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tYm94XCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tcm93XCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbi8vICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPlJlY2VpcHQgTm86PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8c3Bhbj57cGF5bWVudC5yZWNlaXB0X25vIHx8IHBheW1lbnQub2xkX3JlY2VpcHRfbm99PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5OYW1lOjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZX08L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbi8vICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPkRhdGU6PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8c3Bhbj57Zm9ybWF0UGF5RGF0ZShwYXltZW50LnBheV9kYXRlKX08L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tcm93XCI+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbi8vICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPk1vYmlsZTo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py51c2VyX2lkPy5waG9uZV9udW1iZXJ9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5Hcm91cDo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py5ncm91cF9pZD8uZ3JvdXBfbmFtZX08L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbi8vICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPlRpY2tldDo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py50aWNrZXR9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tYW1vdW50LWJveFwiPlxyXG4vLyAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPlJlY2VpdmVkIEFtb3VudDo8L3NwYW4+XHJcbi8vICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsXCI+4oK5IHtwYXltZW50Py5hbW91bnR9PC9zcGFuPlxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWJveFwiPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJvd1wiPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5QYXltZW50IE1vZGU6PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8c3Bhbj57cGF5bWVudD8ucGF5X3R5cGV9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5Db2xsZWN0ZWQgQnk6PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8c3Bhbj57cGF5bWVudD8uY29sbGVjdGVkX2J5Py5uYW1lIHx8IFwiQWRtaW5cIn08L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4vLyAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5Ub3RhbDo8L3NwYW4+XHJcbi8vICAgICAgICAgICAgIDxzcGFuPuKCuSB7cGF5bWVudD8uYW1vdW50fTwvc3Bhbj5cclxuLy8gICAgICAgICAgIDwvZGl2PiAqL31cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tZm9vdGVyXCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWduXCI+QXV0aG9yaXplZCBTaWduYXR1cmU8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXR5cGUtYm94XCI+e2NvcHlUeXBlfSBDb3B5PC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG5cclxuLy8gICBpZiAobG9hZGluZylcclxuLy8gICAgIHJldHVybiAoXHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9hZGluZy1jb250YWluZXJcIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvYWRpbmctc3Bpbm5lclwiPjwvZGl2PlxyXG4vLyAgICAgICAgIDxwPkxvYWRpbmcgcmVjZWlwdCBkZXRhaWxzLi4uPC9wPlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgICk7XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlY2VpcHQtY29udGFpbmVyXCI+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJpbnQtb3B0aW9ucy1jb250YWluZXJcIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByaW50LWJ1dHRvbi1jb250YWluZXJcIj5cclxuLy8gICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlUHJpbnR9IGNsYXNzTmFtZT1cInByaW50LWJ1dHRvblwiPlxyXG4vLyAgICAgICAgICAgICA8QmlQcmludGVyIHNpemU9ezIwfSAvPiBQcmludCBSZWNlaXB0XHJcbi8vICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtYXQtc2VsZWN0b3JcIj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJyYWRpby1sYWJlbFwiPlxyXG4vLyAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPVwidmVydGljYWxcIlxyXG4vLyAgICAgICAgICAgICAgIGNoZWNrZWQ9e3ByaW50Rm9ybWF0ID09PSAndmVydGljYWwnfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBzZXRQcmludEZvcm1hdCgndmVydGljYWwnKX1cclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgRm9ybWF0IDFcclxuLy8gICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicmFkaW8tbGFiZWxcIj5cclxuLy8gICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT1cImhvcml6b250YWxcIlxyXG4vLyAgICAgICAgICAgICAgIGNoZWNrZWQ9e3ByaW50Rm9ybWF0ID09PSAnaG9yaXpvbnRhbCd9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNldFByaW50Rm9ybWF0KCdob3Jpem9udGFsJyl9XHJcbi8vICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgIEZvcm1hdCAyXHJcbi8vICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgIHtwcmludEZvcm1hdCA9PT0gJ3ZlcnRpY2FsJyA/IChcclxuLy8gICAgICAgICAvLyBWZXJ0aWNhbCBGb3JtYXRcclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInZlcnRpY2FsLWZvcm1hdFwiPlxyXG4vLyAgICAgICAgICAgey8qIEVYQUNUIEhBTEYtQTQgU0VDVElPTiAqL31cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVjZWlwdC13cmFwcGVyXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZS1ieS1zaWRlXCI+XHJcbi8vICAgICAgICAgICAgICAgPFZlcnRpY2FsUmVjZWlwdFNlY3Rpb24gY29weVR5cGU9XCJEdXBsaWNhdGVcIiAvPlxyXG4vLyAgICAgICAgICAgICAgIDxWZXJ0aWNhbFJlY2VpcHRTZWN0aW9uIGNvcHlUeXBlPVwiQ3VzdG9tZXJcIiAvPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgIHsvKiBFTVBUWSBSRU1BSU5JTkcgNTAlIEE0ICovfVxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhNC1ib3R0b20tZW1wdHlcIj48L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgKSA6IChcclxuLy8gICAgICAgICAvLyBIb3Jpem9udGFsIEZvcm1hdFxyXG4vLyAgICAgICAgIDxkaXYgaWQ9XCJyZWNlaXB0LXRvLXByaW50XCIgY2xhc3NOYW1lPVwicmVjZWlwdC13cmFwcGVyIGhvcml6b250YWwtZm9ybWF0XCI+XHJcbi8vICAgICAgICAgICA8SG9yaXpvbnRhbFJlY2VpcHRTZWN0aW9uIGNvcHlUeXBlPVwiRHVwbGljYXRlXCIgLz5cclxuLy8gICAgICAgICAgIDxIb3Jpem9udGFsUmVjZWlwdFNlY3Rpb24gY29weVR5cGU9XCJDdXN0b21lclwiIC8+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImE0LWJvdHRvbS1lbXB0eVwiPjwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICApfVxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IFJlY2VpcHRDb21wb25lbnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgY29uc3QgW3BheW1lbnQsIHNldFBheW1lbnRdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtwcmludEZvcm1hdCwgc2V0UHJpbnRGb3JtYXRdID0gdXNlU3RhdGUoJ3ZlcnRpY2FsJyk7IC8vICd2ZXJ0aWNhbCcgb3IgJ2hvcml6b250YWwnXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFBheW1lbnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGlmICghaWQpIHJldHVybjtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvZ2V0LXBheW1lbnQtYnktaWQvJHtpZH1gKTtcclxuICAgICAgICBzZXRQYXltZW50KHJlc3BvbnNlLmRhdGEgfHwge30pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFBheW1lbnQoKTtcclxuICB9LCBbaWRdKTtcclxuXHJcbiAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBpZiAoIWRhdGVTdHJpbmcpIHJldHVybiBcIk4vQVwiO1xyXG4gICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgcmV0dXJuIGQudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICBkYXk6IFwiMi1kaWdpdFwiLFxyXG4gICAgICBtb250aDogXCJzaG9ydFwiLFxyXG4gICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIC8vIEZ1bmN0aW9uIHRvIGNvbnZlcnQgbnVtYmVyIHRvIHdvcmRzXHJcbiAgY29uc3QgbnVtYmVyVG9Xb3JkcyA9IChudW0pID0+IHtcclxuICAgIGlmIChudW0gPT09IDApIHJldHVybiBcIlplcm9cIjtcclxuXHJcbiAgICBjb25zdCBvbmVzID0gW1wiXCIsIFwiT25lXCIsIFwiVHdvXCIsIFwiVGhyZWVcIiwgXCJGb3VyXCIsIFwiRml2ZVwiLCBcIlNpeFwiLCBcIlNldmVuXCIsIFwiRWlnaHRcIiwgXCJOaW5lXCJdO1xyXG4gICAgY29uc3QgdGVucyA9IFtcIlwiLCBcIlRlblwiLCBcIkVsZXZlblwiLCBcIlR3ZWx2ZVwiLCBcIlRoaXJ0ZWVuXCIsIFwiRm91cnRlZW5cIiwgXCJGaWZ0ZWVuXCIsIFwiU2l4dGVlblwiLCBcIlNldmVudGVlblwiLCBcIkVpZ2h0ZWVuXCIsIFwiTmluZXRlZW5cIl07XHJcbiAgICBjb25zdCB0d2VudGllcyA9IFtcIlwiLCBcIlwiLCBcIlR3ZW50eVwiLCBcIlRoaXJ0eVwiLCBcIkZvcnR5XCIsIFwiRmlmdHlcIiwgXCJTaXh0eVwiLCBcIlNldmVudHlcIiwgXCJFaWdodHlcIiwgXCJOaW5ldHlcIl07XHJcblxyXG4gICAgY29uc3QgbnVtVG9Xb3JkcyA9IChuKSA9PiB7XHJcbiAgICAgIGlmIChuIDwgMTApIHJldHVybiBvbmVzW25dO1xyXG4gICAgICBpZiAobiA8IDIwKSByZXR1cm4gdGVuc1tuIC0gMTBdO1xyXG4gICAgICBpZiAobiA8IDEwMCkgcmV0dXJuIHR3ZW50aWVzW01hdGguZmxvb3IobiAvIDEwKV0gKyAobiAlIDEwID8gXCIgXCIgKyBvbmVzW24gJSAxMF0gOiBcIlwiKTtcclxuICAgICAgaWYgKG4gPCAxMDAwKSByZXR1cm4gb25lc1tNYXRoLmZsb29yKG4gLyAxMDApXSArIFwiIEh1bmRyZWRcIiArIChuICUgMTAwID8gXCIgXCIgKyBudW1Ub1dvcmRzKG4gJSAxMDApIDogXCJcIik7XHJcbiAgICAgIGlmIChuIDwgMTAwMDAwKSByZXR1cm4gbnVtVG9Xb3JkcyhNYXRoLmZsb29yKG4gLyAxMDAwKSkgKyBcIiBUaG91c2FuZFwiICsgKG4gJSAxMDAwID8gXCIgXCIgKyBudW1Ub1dvcmRzKG4gJSAxMDAwKSA6IFwiXCIpO1xyXG4gICAgICBpZiAobiA8IDEwMDAwMDAwKSByZXR1cm4gbnVtVG9Xb3JkcyhNYXRoLmZsb29yKG4gLyAxMDAwMDApKSArIFwiIExha2hcIiArIChuICUgMTAwMDAwID8gXCIgXCIgKyBudW1Ub1dvcmRzKG4gJSAxMDAwMDApIDogXCJcIik7XHJcbiAgICAgIHJldHVybiBudW1Ub1dvcmRzKE1hdGguZmxvb3IobiAvIDEwMDAwMDAwKSkgKyBcIiBDcm9yZVwiICsgKG4gJSAxMDAwMDAwMCA/IFwiIFwiICsgbnVtVG9Xb3JkcyhuICUgMTAwMDAwMDApIDogXCJcIik7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiBudW1Ub1dvcmRzKG51bSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAocHJpbnRGb3JtYXQgPT09ICd2ZXJ0aWNhbCcpIHtcclxuICAgICAgd2luZG93LnByaW50KCk7XHJcbiAgICB9IGVsc2UgaWYgKHByaW50Rm9ybWF0ID09PSAnaG9yaXpvbnRhbCcpIHtcclxuICAgICAgd2luZG93LnByaW50KCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gVmVydGljYWwgUmVjZWlwdCBDb21wb25lbnRcclxuICBjb25zdCBWZXJ0aWNhbFJlY2VpcHRTZWN0aW9uID0gKHsgY29weVR5cGUgfSkgPT4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tcmVjZWlwdFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1oZWFkZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1sZWZ0XCI+XHJcbiAgICAgICAgICA8aW1nIHNyYz17bXljaGl0c0xvZ299IGNsYXNzTmFtZT1cInByby1sb2dvXCIgYWx0PVwiXCIgLz5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJwcm8tY29tcGFueVwiPk1ZIENISVRTPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHJvLWFkZHJlc3NcIj5cclxuICAgICAgICAgICAgICBOby4xMS8zNi0yNSwgS2F0aHJpZ3VwcGUgTWFpbiBSb2FkLFxyXG4gICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgIEJhbmdhbG9yZSAtIDU2MDA4NSB8IDk0ODM5MDA3NzdcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tdGl0bGVcIj5QQVlNRU5UIFJFQ0VJUFQ8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWJveFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJvd1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5SZWNlaXB0IE5vOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQucmVjZWlwdF9ubyB8fCBwYXltZW50Lm9sZF9yZWNlaXB0X25vfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5EYXRlOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdFBheURhdGUocGF5bWVudC5wYXlfZGF0ZSl9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJvd1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5OYW1lOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+TW9iaWxlOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQ/LnVzZXJfaWQ/LnBob25lX251bWJlcn08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tcm93XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPkdyb3VwOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQ/Lmdyb3VwX2lkPy5ncm91cF9uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5UaWNrZXQ6PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3Bhbj57cGF5bWVudD8udGlja2V0fTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWFtb3VudC1ib3hcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5SZWNlaXZlZCBBbW91bnQ6PC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbFwiPuKCuSB7cGF5bWVudD8uYW1vdW50fTwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1ib3hcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1yb3dcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+UGF5bWVudCBNb2RlOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQ/LnBheV90eXBlfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5Db2xsZWN0ZWQgQnk6PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3Bhbj57cGF5bWVudD8uY29sbGVjdGVkX2J5Py5uYW1lIHx8IFwiQWRtaW5cIn08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1mb290ZXItY29udGFpbmVyLXZlcnRpY2FsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tdHlwZS1ib3hcIj57Y29weVR5cGV9IENvcHk8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1mb290ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnblwiPkF1dGhvcml6ZWQgU2lnbmF0dXJlPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG5cclxuICAvLyBIb3Jpem9udGFsIFJlY2VpcHQgQ29tcG9uZW50XHJcbiAgY29uc3QgSG9yaXpvbnRhbFJlY2VpcHRTZWN0aW9uID0gKHsgY29weVR5cGUgfSkgPT4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tcmVjZWlwdFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1oZWFkZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1jZW50ZXJcIj5cclxuICAgICAgICAgIDxpbWcgc3JjPXtteWNoaXRzTG9nb30gY2xhc3NOYW1lPVwicHJvLWxvZ29cIiAvPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInByby1jb21wYW55XCI+TVkgQ0hJVFM8L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwcm8tYWRkcmVzc1wiPlxyXG4gICAgICAgICAgICAgIE5vLjExLzM2LTI1LCAybmQgTWFpbiwgS2F0aHJpZ3VwcGUgTWFpbiBSb2FkLDxiciAvPlxyXG4gICAgICAgICAgICAgIEJhbmdhbG9yZSAtIDU2MDA4NSB8IDk0ODM5MDA3NzdcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tdGl0bGVcIj5QQVlNRU5UIFJFQ0VJUFQ8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWJveFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJvd1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5SZWNlaXB0IE5vOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e3BheW1lbnQucmVjZWlwdF9ubyB8fCBwYXltZW50Lm9sZF9yZWNlaXB0X25vfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+TmFtZTo8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py51c2VyX2lkPy5mdWxsX25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5EYXRlOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdFBheURhdGUocGF5bWVudC5wYXlfZGF0ZSl9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXJvd1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5Nb2JpbGU6PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3Bhbj57cGF5bWVudD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWl0ZW1cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGJsXCI+R3JvdXA6PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3Bhbj57cGF5bWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8taXRlbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5UaWNrZXQ6PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3Bhbj57cGF5bWVudD8udGlja2V0fTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcblxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tYm94XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tcm93XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPlBheW1lbnQgTW9kZTo8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py5wYXlfdHlwZX08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1pdGVtXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPkNvbGxlY3RlZCBCeTo8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuPntwYXltZW50Py5jb2xsZWN0ZWRfYnk/Lm5hbWUgfHwgXCJBZG1pblwifTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLWFtb3VudC1ib3hcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5SZWNlaXZlZCBBbW91bnQ6PC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbFwiPuKCuSB7cGF5bWVudD8uYW1vdW50fTwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQW1vdW50IGluIFdvcmRzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByby1hbW91bnQtd29yZHNcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5BbW91bnQgaW4gV29yZHM6PC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbFwiPntudW1iZXJUb1dvcmRzKHBheW1lbnQ/LmFtb3VudCB8fCAwKX0gUnVwZWVzIE9ubHk8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tZm9vdGVyLWNvbnRhaW5lclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvLXR5cGUtYm94XCI+e2NvcHlUeXBlfSBDb3B5PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm8tZm9vdGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ25cIj5BdXRob3JpemVkIFNpZ25hdHVyZTwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG5cclxuICBpZiAobG9hZGluZylcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9hZGluZy1jb250YWluZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvYWRpbmctc3Bpbm5lclwiPjwvZGl2PlxyXG4gICAgICAgIDxwPkxvYWRpbmcgcmVjZWlwdCBkZXRhaWxzLi4uPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlY2VpcHQtY29udGFpbmVyXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJpbnQtb3B0aW9ucy1jb250YWluZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByaW50LWJ1dHRvbi1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlUHJpbnR9IGNsYXNzTmFtZT1cInByaW50LWJ1dHRvblwiPlxyXG4gICAgICAgICAgICA8QmlQcmludGVyIHNpemU9ezIwfSAvPiBQcmludCBSZWNlaXB0XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtYXQtc2VsZWN0b3JcIj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJyYWRpby1sYWJlbFwiPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxyXG4gICAgICAgICAgICAgIHZhbHVlPVwiaG9yaXpvbnRhbFwiXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17cHJpbnRGb3JtYXQgPT09ICdob3Jpem9udGFsJ31cclxuICAgICAgICAgICAgICAvLyBvbkNoYW5nZT17KCkgPT4gc2V0UHJpbnRGb3JtYXQoJ3ZlcnRpY2FsJyl9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNldFByaW50Rm9ybWF0KCdob3Jpem9udGFsJyl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIEZvcm1hdCAxXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInJhZGlvLWxhYmVsXCI+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9XCJ2ZXJ0aWNhbFwiXHJcbiAgICAgICAgICAgICAgY2hlY2tlZD17cHJpbnRGb3JtYXQgPT09ICd2ZXJ0aWNhbCd9XHJcbiAgICAgICAgICAgICAgLy8gb25DaGFuZ2U9eygpID0+IHNldFByaW50Rm9ybWF0KCdob3Jpem9udGFsJyl9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNldFByaW50Rm9ybWF0KCd2ZXJ0aWNhbCcpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICBGb3JtYXQgMlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7cHJpbnRGb3JtYXQgPT09ICd2ZXJ0aWNhbCcgPyAoXHJcbiAgICAgICAgLy8gVmVydGljYWwgRm9ybWF0XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ2ZXJ0aWNhbC1mb3JtYXRcIj5cclxuICAgICAgICAgIHsvKiBFWEFDVCBIQUxGLUE0IFNFQ1RJT04gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlY2VpcHQtd3JhcHBlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZGUtYnktc2lkZVwiPlxyXG4gICAgICAgICAgICAgIDxWZXJ0aWNhbFJlY2VpcHRTZWN0aW9uIGNvcHlUeXBlPVwiRHVwbGljYXRlXCIgLz5cclxuICAgICAgICAgICAgICA8VmVydGljYWxSZWNlaXB0U2VjdGlvbiBjb3B5VHlwZT1cIkN1c3RvbWVyXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRU1QVFkgUkVNQUlOSU5HIDUwJSBBNCAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYTQtYm90dG9tLWVtcHR5XCI+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgLy8gSG9yaXpvbnRhbCBGb3JtYXRcclxuICAgICAgICA8ZGl2IGlkPVwicmVjZWlwdC10by1wcmludFwiIGNsYXNzTmFtZT1cInJlY2VpcHQtd3JhcHBlciBob3Jpem9udGFsLWZvcm1hdFwiPlxyXG4gICAgICAgICAgPEhvcml6b250YWxSZWNlaXB0U2VjdGlvbiBjb3B5VHlwZT1cIkR1cGxpY2F0ZVwiIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImN1dC1saW5lXCI+PC9kaXY+XHJcbiAgICAgICAgICA8SG9yaXpvbnRhbFJlY2VpcHRTZWN0aW9uIGNvcHlUeXBlPVwiQ3VzdG9tZXJcIiAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhNC1ib3R0b20tZW1wdHlcIj48L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZWNlaXB0Q29tcG9uZW50O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUHJpbnQuanN4In0=