import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Pigme.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import { Modal as antModal, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Dropdown, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaCalculator } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import __vite__cjsImport21_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport21_dayjs.__esModule ? __vite__cjsImport21_dayjs.default : __vite__cjsImport21_dayjs;
const Pigme = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [tableBorrowers, setTableBorrowers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [currentCustomer, setCurrentCustomer] = useState(null);
  const [currentUpdateCustomer, setCurrentUpdateCustomer] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [withdrawData, setWithdrawData] = useState(null);
  const [showCalculated, setShowCalculated] = useState(false);
  const [editableInterest, setEditableInterest] = useState("");
  const [activeTab, setActiveTab] = useState("pigme");
  const [closedPigmyData, setClosedPigmyData] = useState([]);
  const [closedLoading, setClosedLoading] = useState(false);
  const navigate = useNavigate();
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [thirdPartyEnable, setThirdPartyEnable] = useState({
    whatsapp: true
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    customer: "",
    maturity_period: "",
    maturity_interest: "6",
    payable_amount: "",
    start_date: "",
    note: "",
    referred_customer: "",
    referred_employee: "",
    referred_type: "",
    referred_agent: "",
    duration: "12 months"
    // request_status: "APPROVED",
  });
  const [errors, setErrors] = useState({});
  const [updateFormData, setUpdateFormData] = useState({
    customer: "",
    maturity_period: "",
    maturity_interest: "6",
    payable_amount: "",
    start_date: "",
    note: "",
    referred_customer: "",
    referred_employee: "",
    referred_type: "",
    referred_agent: "",
    duration: "12 months"
  });
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await api.get("/user/get-user");
        if (response.status >= 400)
          throw new Error("Failed to fetch Customers");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching  Customer Data:", error);
      }
    };
    fetchCustomers();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get");
        setAgents(response.data?.agent);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await api.get("/employee");
        setEmployees(response?.data?.employee);
      } catch (error) {
        console.error("failed to fetch employees", error);
      }
    };
    fetchEmployees();
  }, []);
  useEffect(() => {
    const fetchClosedPigmy = async () => {
      try {
        setClosedLoading(true);
        const response = await api.get("/v1/admin/pigmes/pigme-closed");
        const data = response.data?.data || [];
        const formatted = data.map((item, index) => ({
          id: index + 1,
          _id: item._id,
          pigme_id: item.pigme_id,
          customer_name: item.customer?.full_name || "N/A",
          phone_number: item.customer?.phone_number || "N/A",
          maturity_period: item.maturity_period,
          payment_details: `${item.maturity_period} – ₹${item.payable_amount}`,
          payable_amount: item.payable_amount,
          maturity_interest: item.maturity_interest || item?.pre_matured_interest + "%",
          referred_type: item.referred_type || "N/A",
          referred_by: (() => {
            let ref = "N/A";
            const refType = item.referred_type || item.customer?.referred_type || item?.referred_employee;
            if (refType === "Employee" || item?.referred_employee) {
              const emp = item.referred_employee || item.customer?.referred_employee;
              if (emp) ref = `${emp.name} | ${emp.phone_number || emp.employeeCode || ""}`;
            } else if (refType === "Agent") {
              const agent = item.referred_agent || item.customer?.referred_agent;
              if (agent) ref = `${agent.name} | ${agent.phone_number || ""}`;
            } else if (refType === "Customer") {
              const cust = item.referred_customer || item.customer?.referred_customer;
              if (cust) ref = `${cust.full_name} | ${cust.phone_number || ""}`;
            }
            return ref;
          })(),
          start_date: item.start_date?.split("T")[0]?.split("-").reverse().join("-") || "",
          duration: item.duration ? `${item.duration} Months` : "N/A",
          status: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800", children: "Closed" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 169,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 168,
            columnNumber: 11
          }, this),
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-blue-600 cursor-pointer",
                        onClick: () => window.location.href = `/pigmy-preclosure-print/${item._id}`,
                        children: "Print"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                        lineNumber: 182,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 195,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 176,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 175,
            columnNumber: 11
          }, this)
        }));
        setClosedPigmyData(formatted);
      } catch (error) {
        console.error("Error fetching closed pigmy:", error);
        setAlertConfig({
          visibility: true,
          message: "Failed to fetch closed pigmy data",
          type: "error"
        });
      } finally {
        setClosedLoading(false);
      }
    };
    fetchClosedPigmy();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchBorrowers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/pigme/get-all-pigme-customers");
        const pigmeList = response.data || [];
        const formattedData = pigmeList.map((pigmeCustomer) => {
          let referred_by = "N/A";
          const refType = pigmeCustomer?.referred_type || pigmeCustomer?.customer?.referred_type;
          if (refType === "Employee") {
            const emp = pigmeCustomer?.referred_employee || pigmeCustomer?.customer?.referred_employee;
            if (emp) {
              referred_by = `${emp.name} | ${emp.phone_number || emp.employeeCode || ""}`;
            }
          } else if (refType === "Agent") {
            const agent = pigmeCustomer?.referred_agent || pigmeCustomer?.customer?.referred_agent;
            if (agent) {
              referred_by = `${agent.name} | ${agent.phone_number || ""}`;
            }
          } else if (refType === "Customer") {
            const cust = pigmeCustomer?.referred_customer || pigmeCustomer?.customer?.referred_customer;
            if (cust) {
              referred_by = `${cust.full_name} | ${cust.phone_number || ""}`;
            }
          }
          return {
            _id: pigmeCustomer?._id,
            pigme_id: pigmeCustomer?.pigme_id,
            customer_name: pigmeCustomer?.customer?.full_name,
            phone_number: pigmeCustomer?.customer?.phone_number,
            date: pigmeCustomer?.createdAt,
            maturity_period: pigmeCustomer?.maturity_period,
            maturity_interest: pigmeCustomer?.maturity_interest + "%",
            payment_details: `${pigmeCustomer?.maturity_period} – ₹${pigmeCustomer?.payable_amount}`,
            payable_amount: pigmeCustomer?.payable_amount,
            start_date: pigmeCustomer?.start_date?.split("T")[0].split("-").reverse().join("-"),
            duration: pigmeCustomer?.duration ? `${pigmeCustomer.duration} Months` : "N/A",
            note: pigmeCustomer?.note,
            referred_type: pigmeCustomer?.referred_type || pigmeCustomer?.customer?.referred_type || "N/A",
            referred_by,
            // now correctly set
            request_status: pigmeCustomer?.request_status || "REQUESTED",
            // status badge 
            status: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: pigmeCustomer?.request_status === "REQUESTED" ? /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800", children: "Requested" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 287,
              columnNumber: 15
            }, this) : pigmeCustomer?.request_status === "APPROVED" ? /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800", children: "Approved" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 291,
              columnNumber: 15
            }, this) : pigmeCustomer?.request_status === "CLOSED" ? /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800", children: "Closed" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 295,
              columnNumber: 15
            }, this) : "" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 285,
              columnNumber: 13
            }, this),
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-green-600",
                          onClick: () => handleUpdateModalOpen(pigmeCustomer._id),
                          children: "Edit"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                          lineNumber: 311,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-red-600",
                          onClick: () => handleDeleteModalOpen(pigmeCustomer._id),
                          children: "Delete"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                          lineNumber: 322,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    // Print Preclosure Form
                    ...pigmeCustomer?.request_status === "REQUESTED" ? [
                      {
                        key: "print-preclosure",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-blue-600 font-medium cursor-pointer",
                            onClick: () => window.open(
                              `/pigmy-preclosure-print/${pigmeCustomer._id}`,
                              "_blank"
                            ),
                            children: "Closure Form"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                            lineNumber: 336,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ] : [],
                    // ✅ Request to Withdraw 
                    ...pigmeCustomer?.request_status !== "REQUESTED" && pigmeCustomer?.request_status !== "CLOSED" ? [
                      {
                        key: "3",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-blue-600",
                            onClick: () => {
                              antModal.confirm({
                                title: `Request withdrawal for ${pigmeCustomer?.customer?.full_name}?`,
                                content: "This will set the pigmy status to REQUESTED and allow processing of withdrawal.",
                                okText: "Yes, request withdrawal",
                                cancelText: "Cancel",
                                onOk: () => updatePigmyStatus(
                                  { _id: pigmeCustomer._id },
                                  "REQUESTED"
                                )
                              });
                            },
                            children: "Request to Withdraw Pigmy"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                            lineNumber: 358,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ] : [],
                    // Withdraw option (only for REQUESTED, if still needed)
                    ...pigmeCustomer?.request_status === "REQUESTED" ? [
                      {
                        key: "4",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-purple-600",
                            onClick: () => openWithdrawModal(pigmeCustomer),
                            children: "Withdraw"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                            lineNumber: 387,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ] : []
                  ]
                },
                placement: "bottomLeft",
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 401,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 305,
                columnNumber: 17
              },
              this
            ) }, pigmeCustomer._id, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 304,
              columnNumber: 13
            }, this)
          };
        });
        const sortedData = formattedData.sort((a, b) => {
          if (a.request_status === "REQUESTED" && b.request_status !== "REQUESTED") return -1;
          if (b.request_status === "REQUESTED" && a.request_status !== "REQUESTED") return 1;
          return new Date(b.date) - new Date(a.date);
        });
        const dataWithId = sortedData.map((item, index) => ({
          ...item,
          id: index + 1
        }));
        setTableBorrowers(dataWithId);
      } catch (error) {
        console.error("Error fetching pigmy data:", error);
        setAlertConfig({
          visibility: true,
          message: "Failed to fetch pigmy customers",
          type: "error"
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchBorrowers();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addCustomer" ? formData : updateFormData;
    if (!data.customer) newErrors.customer = "Customer Name is required";
    if (!data.maturity_period) newErrors.maturity_period = "Maturity Period is Required";
    if (!data.payable_amount) newErrors.payable_amount = "Payable Amount is required";
    else if (isNaN(data.payable_amount) || data.payable_amount <= 0)
      newErrors.payable_amount = "Payable Amount must be a positive number";
    if (!data.start_date) newErrors.start_date = "Start Date is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addCustomer");
    if (!isValid) return;
    try {
      const payload = {
        ...formData,
        ...thirdPartyEnable,
        duration: Number(String(formData.duration).replace(/\D/g, ""))
        // request_status: "APPROVED",
      };
      const response = await api.post("/pigme/add-new-pigme-customer", payload);
      if (response.status >= 400) throw new Error("failed to add Customer");
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Customer Added Successfully",
        type: "success"
      });
      setShowModal(false);
      setFormData({
        customer: "",
        maturity_period: "",
        maturity_interest: "6",
        payable_amount: "",
        start_date: "",
        note: "",
        referred_customer: "",
        referred_employee: "",
        referred_type: "",
        referred_agent: "",
        duration: "12 months"
        // request_status: "APPROVED",
      });
    } catch (error) {
      console.error("Error adding Customer:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to add pigmy",
        type: "error"
      });
    }
  };
  const handleDeleteModalOpen = async (pigmeId) => {
    try {
      const response = await api.get(`pigme/get-pigme/${pigmeId}`);
      setCurrentCustomer(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Pigme:", error);
    }
  };
  const handleUpdateModalOpen = async (pigmeId) => {
    try {
      const response = await api.get(`pigme/get-pigme/${pigmeId}`);
      const PigmeData = response.data;
      const formattedStartDate = PigmeData?.start_date?.split("T")[0];
      setCurrentUpdateCustomer(response.data);
      setUpdateFormData({
        customer: response?.data?.customer._id,
        maturity_period: response?.data?.maturity_period,
        maturity_interest: response?.data?.maturity_interest,
        payable_amount: response?.data?.payable_amount,
        start_date: formattedStartDate,
        note: response?.data?.note,
        referred_employee: response?.data?.referred_employee?._id || "",
        referred_customer: response?.data?.referred_customer?._id || "",
        referred_agent: response?.data?.referred_agent?._id || "",
        referred_type: response?.data?.referred_type || "",
        duration: response?.data?.duration || ""
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching pigme Customer by ID:", error);
    }
  };
  const openApproveModal = (customer) => {
    setCurrentCustomer(customer);
    setShowApproveModal(true);
  };
  const updatePigmyStatus = async (pigmy, newStatus) => {
    try {
      await api.patch(`/v1/admin/pigmes/status/${pigmy._id}`, {
        request_status: newStatus
      });
      message.success(`Pigmy status updated to ${newStatus} successfully`);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error("Error updating pigmy status:", error);
      message.error("Failed to update pigmy status");
    }
  };
  const handleApprove = async () => {
    if (!currentCustomer) return;
    try {
      await api.patch(`/v1/admin/pigmes/status/${currentCustomer._id}`, {
        request_status: "APPROVED"
      });
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Pigmy request approved successfully",
        type: "success"
      });
      setShowApproveModal(false);
      setCurrentCustomer(null);
    } catch (error) {
      console.error("Error approving pigmy:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to approve",
        type: "error"
      });
    }
  };
  const openWithdrawModal = async (customer) => {
    try {
      const response = await api.get(`/v1/admin/pigmes/${customer._id}`);
      if (response.data.success) {
        setWithdrawData(response.data.data);
        setEditableInterest(response.data.data.pre_matured_interest || "0");
        setShowCalculated(false);
        setShowWithdrawModal(true);
      } else {
        throw new Error("Failed to fetch pigmy data");
      }
    } catch (error) {
      console.error("Error fetching pigmy for withdraw:", error);
      setAlertConfig({
        visibility: true,
        message: "Could not load pigmy details",
        type: "error"
      });
    }
  };
  const handleCalculate = async () => {
    if (!withdrawData) return;
    try {
      const response = await api.put(`/v1/admin/pigmes/pigme-closer/${withdrawData._id}`, {
        pre_matured_interest: editableInterest
      });
      if (response.data.status) {
        setWithdrawData((prev) => ({ ...prev, ...response.data.data }));
        setShowCalculated(true);
      } else {
        throw new Error("Calculation failed");
      }
    } catch (error) {
      console.error("Error calculating withdrawal:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to calculate",
        type: "error"
      });
    }
  };
  const handleWithdraw = () => {
    setShowWithdrawModal(false);
    setWithdrawData(null);
    setShowCalculated(false);
    setReloadTrigger((prev) => prev + 1);
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({ ...prevData, [field]: value }));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      referred_employee: "",
      referred_agent: "",
      referred_customer: "",
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({ ...prevData, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handleDeletePigme = async () => {
    if (currentCustomer) {
      try {
        await api.delete(`/pigme/delete-pigme-customer/${currentCustomer._id}`);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Pigmy User deleted successfully",
          type: "success",
          visibility: true
        });
        setShowModalDelete(false);
        setCurrentCustomer(null);
      } catch (error) {
        console.error("Error deleting pigmy User:", error);
        setAlertConfig({
          message: error.response?.data?.message || "Failed to delete",
          type: "error",
          visibility: true
        });
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (!isValid) return;
    try {
      await api.patch(
        `/pigme/update-pigme-customer/${currentUpdateCustomer._id}`,
        updateFormData
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        message: "Borrower updated successfully",
        type: "success",
        visibility: true
      });
    } catch (error) {
      console.error("Error updating Borrower:", error);
      setAlertConfig({
        message: error.response?.data?.message || "Update failed",
        type: "error",
        visibility: true
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "pigme_id", header: "Pigme ID" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "maturity_period", header: "Payment Type" },
    // { key: "payable_amount", header: "Amount" },
    { key: "payment_details", header: "Payment Details" },
    { key: "maturity_interest", header: "Maturity Interest" },
    { key: "referred_type", header: "Referred Type" },
    { key: "referred_by", header: "Referred By" },
    { key: "start_date", header: "Start Date", width: 120 },
    { key: "duration", header: "Duration", width: 120 },
    // { key: "note", header: "Note" },
    { key: "status", header: "Status" },
    // new status column
    { key: "action", header: "Action" }
  ];
  const closedColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pigme_id", header: "Pigme ID" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "maturity_period", header: "Payment Type" },
    { key: "payment_details", header: "Payment Details" },
    { key: "maturity_interest", header: "Maturity Interest / PreClosure Charges" },
    // { key: "referred_type", header: "Referred Type" },
    { key: "referred_by", header: "Referred By" },
    { key: "start_date", header: "Start Date", width: 120 },
    { key: "duration", header: "Duration", width: 120 },
    { key: "status", header: "Status" },
    { key: "action", header: "Action" }
    // this will contain print button
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 743,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 747,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 756,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0 p-7 overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 759,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Pigmy" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 761,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: "/reports/pigmy-payout-report",
                  className: "inline-flex items-center px-3 py-1.5 text-sm border border-green-500 text-green-600 rounded-lg\r\n      hover:bg-green-50 hover:text-green-700 hover:border-green-600\r\n      transition-all duration-200 font-medium",
                  children: "Payment Out Report"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 771,
                  columnNumber: 19
                },
                this
              ),
              activeTab === "pigme" && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setShowModal(true);
                    setErrors({});
                  },
                  className: "bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200 whitespace-nowrap",
                  children: "+ Add Pigmy"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 780,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 762,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 760,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200 mt-4", children: /* @__PURE__ */ jsxDEV("nav", { className: "-mb-px flex space-x-8", "aria-label": "Tabs", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setActiveTab("pigme"),
                className: `${activeTab === "pigme" ? "border-blue-500 text-blue-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"} whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm`,
                children: "Pigme"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 796,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setActiveTab("closed"),
                className: `${activeTab === "closed" ? "border-blue-500 text-blue-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"} whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm`,
                children: "Closed Pigmy"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 805,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 795,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 794,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 758,
          columnNumber: 13
        }, this),
        activeTab === "pigme" && /* @__PURE__ */ jsxDEV(Fragment, { children: tableBorrowers?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(tableBorrowers, searchText),
            columns,
            exportedPdfName: "Pigmy",
            exportedFileName: `Pigmy.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 821,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Pigmy Data",
            failure: tableBorrowers?.length <= 0
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 830,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 819,
          columnNumber: 13
        }, this),
        activeTab === "closed" && /* @__PURE__ */ jsxDEV(Fragment, { children: closedPigmyData?.length > 0 && !closedLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            data: filterOption(closedPigmyData, searchText),
            columns: closedColumns,
            exportedPdfName: "ClosedPigmy",
            exportedFileName: `ClosedPigmy.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 842,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading: closedLoading,
            data: "Closed Pigmy Data",
            failure: closedPigmyData?.length <= 0
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 850,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 840,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 757,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 755,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Pigmy" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 864,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Select customer Name ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 869,
              columnNumber: 40
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 868,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} w-full`,
              placeholder: "Select Or Search customer Name",
              showSearch: true,
              value: formData?.customer || "",
              onChange: (value) => handleAntDSelect("customer", value),
              filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
              options: users.map((user) => ({
                value: user._id,
                label: `${user.customer_id} | ${user.full_name} | ${user.phone_number}`
              }))
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 871,
              columnNumber: 17
            },
            this
          ),
          errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.customer }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 886,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 867,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Select Payment Type ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 891,
              columnNumber: 101
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 891,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} w-full`,
              placeholder: "Select Payment Type",
              showSearch: true,
              value: formData?.maturity_period || void 0,
              onChange: (value) => handleAntDSelect("maturity_period", value),
              children: ["Daily", "Weekly", "Monthly"].map(
                (maturity) => /* @__PURE__ */ jsxDEV(Select.Option, { value: maturity?.toLowerCase(), children: maturity }, maturity, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 900,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 892,
              columnNumber: 17
            },
            this
          ),
          errors.maturity_period && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.maturity_period }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 905,
            columnNumber: 44
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 890,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: "Referred Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 911,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg w-full`,
                placeholder: "Select Referred Type",
                showSearch: true,
                value: formData?.referred_type || void 0,
                onChange: (value) => handleAntDSelect("referred_type", value),
                children: ["Self Joining", "Customer", "Employee", "Agent", "Others"].map(
                  (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 920,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 912,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 910,
            columnNumber: 17
          }, this),
          formData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Referred Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 926,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg w-full`,
                placeholder: "Select Referred Customer",
                showSearch: true,
                value: formData?.referred_customer || void 0,
                onChange: (value) => handleAntDSelect("referred_customer", value),
                children: users.map(
                  (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                    user.full_name,
                    " | ",
                    user.phone_number
                  ] }, user._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 935,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 927,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 925,
            columnNumber: 17
          }, this),
          formData.referred_type === "Agent" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Referred Agent" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 942,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg w-full`,
                placeholder: "Select Referred Agent",
                showSearch: true,
                value: formData.referred_agent || void 0,
                onChange: (value) => handleAntDSelect("referred_agent", value),
                children: agents.map(
                  (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                    agent.name,
                    " | ",
                    agent.phone_number
                  ] }, agent._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 951,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 943,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 941,
            columnNumber: 17
          }, this),
          formData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Referred Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 958,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg w-full`,
                placeholder: "Select Referred Employee",
                showSearch: true,
                value: formData?.referred_employee || void 0,
                onChange: (value) => handleAntDSelect("referred_employee", value),
                children: employees.map(
                  (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee._id, children: [
                    employee.name,
                    " | ",
                    employee.phone_number
                  ] }, employee._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 967,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 959,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 957,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 909,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Interest %" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 976,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", name: "maturity_interest", value: formData.maturity_interest, onChange: handleChange, className: "bg-gray-50 border border-gray-300 w-full p-2.5 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 977,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 975,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Start Date ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 980,
                columnNumber: 94
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 980,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", name: "start_date", value: formData.start_date, onChange: handleChange, className: "bg-gray-50 border border-gray-300 w-full p-2.5 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 981,
              columnNumber: 19
            }, this),
            errors.start_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 982,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 979,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 974,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Duration ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 988,
                columnNumber: 92
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 988,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-14 border-gray-300 rounded-lg w-full",
                placeholder: "Select Duration",
                showSearch: true,
                value: formData?.duration || "6 months",
                onChange: (value) => handleAntDSelect("duration", value),
                children: ["6 months", "12 months", "18 months", "24 months", "30 months", "36 months", "42 months", "48 months", "54 months", "60 months"].map(
                  (cDuration) => /* @__PURE__ */ jsxDEV(Select.Option, { value: cDuration, children: cDuration }, cDuration, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 997,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 989,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 987,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
              "Payable Amount ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1002,
                columnNumber: 98
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1002,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "payable_amount", value: formData.payable_amount, onChange: handleChange, className: "bg-gray-50 border border-gray-300 w-full p-4 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1003,
              columnNumber: 19
            }, this),
            errors.payable_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.payable_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1004,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1001,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 986,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1009,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex w-full gap-2", children: [
            /* @__PURE__ */ jsxDEV("input", { type: "text", name: "note", value: formData.note, onChange: handleChange, className: "bg-gray-50 border border-gray-300 w-full p-2.5 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1011,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-700 hover:bg-blue-800 w-10 h-10 flex justify-center items-center rounded-md cursor-pointer", onClick: () => window.open("Calculator:///"), children: /* @__PURE__ */ jsxDEV(FaCalculator, { color: "white" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1013,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1012,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1010,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1008,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
            /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "text-green-600 w-5 h-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1020,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: "Enable WhatsApp Sending" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1021,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1019,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: thirdPartyEnable.whatsapp, onChange: () => setThirdPartyEnable((prev) => ({ ...prev, whatsapp: !prev.whatsapp })), className: "w-5 h-5 accent-green-600 cursor-pointer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1023,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1018,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black", children: "Save Pigmy" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1027,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1026,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 865,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 863,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 862,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModalUpdate, onClose: () => setShowModalUpdate(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Pigmy" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 1036,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Customer Name" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1039,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              disabled: true,
              value: updateFormData.customer,
              children: users.map(
                (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1046,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1040,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1038,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Type" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1051,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              value: updateFormData.maturity_period,
              onChange: (val) => handleAntInputDSelect("maturity_period", val),
              children: ["daily", "weekly", "monthly"].map(
                (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type, children: type.toUpperCase() }, type, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1058,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1052,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1050,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Interest %" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1064,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", name: "maturity_interest", value: updateFormData.maturity_interest, onChange: handleInputChange, className: "w-full p-2.5 border rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1065,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1063,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Start Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1068,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", name: "start_date", value: updateFormData.start_date, onChange: handleInputChange, className: "w-full p-2.5 border rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1069,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1067,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1062,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Duration" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1074,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "w-full",
                value: updateFormData.duration,
                onChange: (val) => handleAntInputDSelect("duration", val),
                children: ["6 months", "12 months", "18 months", "24 months"].map(
                  (dur) => /* @__PURE__ */ jsxDEV(Select.Option, { value: dur, children: dur }, dur, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1081,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1075,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1073,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payable Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1086,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "payable_amount", value: updateFormData.payable_amount, onChange: handleInputChange, className: "w-full p-4 border rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1087,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1085,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1072,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1091,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", name: "note", value: updateFormData.note, onChange: handleInputChange, className: "w-full p-2.5 border rounded-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1092,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1090,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center", children: "Update Pigmy" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1095,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1094,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 1037,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 1035,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 1034,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showApproveModal, onClose: () => setShowApproveModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Approve Pigmy Request" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 1104,
        columnNumber: 13
      }, this),
      currentCustomer && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "mb-2", children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Customer:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1108,
            columnNumber: 19
          }, this),
          " ",
          currentCustomer.customer_name
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1107,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mb-2", children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Amount:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1111,
            columnNumber: 19
          }, this),
          " ₹",
          currentCustomer.payable_amount
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1110,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mb-4", children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Referred By:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1114,
            columnNumber: 19
          }, this),
          " ",
          currentCustomer.referred_by
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1113,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mb-6 text-gray-600", children: "Do you want to approve this pigmy request?" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1116,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowApproveModal(false),
              className: "px-4 py-2 border rounded-lg",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1120,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleApprove,
              className: "px-4 py-2 bg-blue-600 text-white rounded-lg",
              children: "Approve"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1126,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1119,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 1106,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 1103,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 1102,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showWithdrawModal,
        onClose: () => {
          setShowWithdrawModal(false);
          setWithdrawData(null);
          setShowCalculated(false);
        },
        showCloseButton: false,
        children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowWithdrawModal(false);
                setWithdrawData(null);
                setShowCalculated(false);
              },
              className: "absolute top-0 right-1 text-red-600 hover:text-red-800 \r\n                 text-xl font-bold z-10 focus:outline-none",
              "aria-label": "Close",
              children: "✕"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1150,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-600 to-indigo-600 px-2 py-5 flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-white", children: "Withdraw Pigmy Account" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1165,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-purple-100 text-sm mt-1", children: "Review details before processing withdrawal" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1168,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1164,
              columnNumber: 15
            }, this),
            withdrawData && /* @__PURE__ */ jsxDEV("div", { children: [
              withdrawData.request_status === "APPROVED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-green-200 text-green-800 rounded-full text-sm font-semibold", children: "Approved" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1176,
                columnNumber: 17
              }, this),
              withdrawData.request_status === "REQUESTED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-yellow-200 text-yellow-800 rounded-full text-sm font-semibold", children: "Requested" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1181,
                columnNumber: 17
              }, this),
              withdrawData.request_status === "COMPLETED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-blue-200 text-blue-800 rounded-full text-sm font-semibold", children: "Completed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1186,
                columnNumber: 17
              }, this),
              withdrawData.request_status === "CLOSED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-gray-200 text-gray-800 rounded-full text-sm font-semibold", children: "Closed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1191,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1174,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1162,
            columnNumber: 13
          }, this),
          withdrawData && /* @__PURE__ */ jsxDEV("div", { className: "", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-100 rounded-xl p-5 mb-6", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Pigmy Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1204,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Pigmy ID" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1209,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.pigme_id }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1210,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1208,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1213,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.customer?.full_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1214,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1212,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Payment Type" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1219,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.maturity_period }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1220,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1218,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                    withdrawData.maturity_period?.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase()),
                    " ",
                    "paid Amount"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1225,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-blue-600 text-lg", children: [
                    "₹",
                    withdrawData.payable_amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1231,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1224,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Paid" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1234,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-blue-600", children: [
                    "₹",
                    withdrawData.total_paid
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1235,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1233,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Months Completed" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1239,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.start_date ? (() => {
                    const start = dayjs(withdrawData.start_date);
                    const today = dayjs();
                    let months = (today.year() - start.year()) * 12 + (today.month() - start.month());
                    months = Math.max(0, months);
                    return `${months} / ${withdrawData.duration || "?"} months`;
                  })() : "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1240,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1237,
                  columnNumber: 21
                }, this),
                withdrawData?.closure_type === "MATURED" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Interest Rate" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1252,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-green-600", children: [
                    withdrawData.maturity_interest,
                    "%"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1253,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1251,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Closure Type" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1257,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-flex px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800 mt-1", children: withdrawData.closure_type }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1258,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1256,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Start Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1264,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: new Date(withdrawData.start_date).toLocaleDateString("en-GB") }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1265,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1263,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Duration" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1270,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: [
                    withdrawData.duration,
                    " Months"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1271,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1269,
                  columnNumber: 21
                }, this),
                withdrawData.closure_type === "PRE-MATURED" && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: " Premature Withdrawal Deduction (%)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1279,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      step: "any",
                      value: editableInterest,
                      onChange: (e) => setEditableInterest(e.target.value),
                      className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500",
                      placeholder: "Enter interest percentage"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                      lineNumber: 1280,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1278,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1207,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1203,
              columnNumber: 17
            }, this),
            showCalculated && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-5 mb-6", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Calculated Values" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1299,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Paid" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1306,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-blue-600", children: [
                    "₹",
                    withdrawData.total_paid
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1307,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1305,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: withdrawData.closure_type === "PRE-MATURED" ? " Premature Withdrawal Deduction (%)" : "Maturity Interest (%)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1313,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: `text-xl font-bold ${withdrawData.closure_type === "PRE-MATURED" ? "text-red-600" : "text-green-600"}`, children: [
                    withdrawData.closure_type === "PRE-MATURED" ? withdrawData.pre_matured_interest : withdrawData.maturity_interest,
                    "%"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1314,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1312,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Maturity Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1317,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-purple-600", children: [
                    "₹",
                    withdrawData.maturity_amount
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1318,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1316,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1303,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1298,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 border-t pt-5", children: !showCalculated ? /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleCalculate,
                className: "px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl font-medium shadow-md hover:shadow-lg transition-all duration-200 flex items-center gap-2",
                children: [
                  /* @__PURE__ */ jsxDEV(FaCalculator, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                    lineNumber: 1335,
                    columnNumber: 23
                  }, this),
                  " Calculate"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                lineNumber: 1331,
                columnNumber: 17
              },
              this
            ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setShowWithdrawModal(false);
                    setWithdrawData(null);
                    setShowCalculated(false);
                  },
                  className: "px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-100 transition",
                  children: "Close"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1339,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleWithdraw,
                  className: "px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl font-medium shadow-md hover:shadow-lg transition-all duration-200",
                  children: "Done"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
                  lineNumber: 1349,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1338,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1329,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1201,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1148,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 1139,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModalDelete, onClose: () => {
      setShowModalDelete(false);
      setCurrentCustomer(null);
    }, children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Pigmy Customer" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 1366,
        columnNumber: 13
      }, this),
      currentCustomer && /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => {
        e.preventDefault();
        handleDeletePigme();
      }, className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Please enter ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentCustomer.customer.full_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
              lineNumber: 1371,
              columnNumber: 34
            }, this),
            " to confirm deletion."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1370,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Enter the Pigmy Customer Name", required: true, className: "bg-gray-50 border border-gray-300 w-full p-2.5 rounded-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
            lineNumber: 1373,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1369,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "w-full text-white bg-red-700 hover:bg-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center", children: "Delete" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
          lineNumber: 1375,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
        lineNumber: 1368,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 1365,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
      lineNumber: 1364,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
    lineNumber: 742,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx",
    lineNumber: 741,
    columnNumber: 5
  }, this);
};
_s(Pigme, "YTobl9Zmd+Ga8qDqgvlxPhF2lEU=", false, function() {
  return [useNavigate];
});
_c = Pigme;
export default Pigme;
var _c;
$RefreshReg$(_c, "Pigme");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Pigme.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0tjLFNBMG9CQSxVQTFvQkE7MkJBeEtkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixTQUFTQSxTQUFTQyxVQUFVQyxlQUFlO0FBQzNDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsVUFBVUMsY0FBYztBQUNqQyxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msb0JBQW9CO0FBQzdCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLFNBQVM7QUFDbEIsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxXQUFXO0FBRWxCLE1BQU1DLFFBQVFBLE1BQU07QUFBQUMsS0FBQTtBQUNsQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXpCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUMwQixRQUFRQyxTQUFTLElBQUkzQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDNEIsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzhCLGdCQUFnQkMsaUJBQWlCLElBQUkvQixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDZ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWpDLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDb0MsaUJBQWlCQyxrQkFBa0IsSUFBSXJDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNzQyxpQkFBaUJDLGtCQUFrQixJQUFJdkMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3dDLGtCQUFrQkMsbUJBQW1CLElBQUl6QyxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDMEMsbUJBQW1CQyxvQkFBb0IsSUFBSTNDLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUM0QyxpQkFBaUJDLGtCQUFrQixJQUFJN0MsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQzhDLHVCQUF1QkMsd0JBQXdCLElBQUkvQyxTQUFTLElBQUk7QUFDdkUsUUFBTSxDQUFDZ0QsWUFBWUMsYUFBYSxJQUFJakQsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2tELGVBQWVDLGdCQUFnQixJQUFJbkQsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQ29ELFdBQVdDLFlBQVksSUFBSXJELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNzRCxjQUFjQyxlQUFlLElBQUl2RCxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDd0QsZ0JBQWdCQyxpQkFBaUIsSUFBSXpELFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUMwRCxrQkFBa0JDLG1CQUFtQixJQUFJM0QsU0FBUyxFQUFFO0FBRzNELFFBQU0sQ0FBQzRELFdBQVdDLFlBQVksSUFBSTdELFNBQVMsT0FBTztBQUNsRCxRQUFNLENBQUM4RCxpQkFBaUJDLGtCQUFrQixJQUFJL0QsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2dFLGVBQWVDLGdCQUFnQixJQUFJakUsU0FBUyxLQUFLO0FBRXhELFFBQU1rRSxXQUFXL0MsWUFBWTtBQUU3QixRQUFNZ0QsOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQnJCLGtCQUFjb0IsS0FBSztBQUFBLEVBQ3JCO0FBQ0EsUUFBTSxDQUFDRSxrQkFBa0JDLG1CQUFtQixJQUFJeEUsU0FBUztBQUFBLElBQ3ZEeUUsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUVELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJM0UsU0FBUztBQUFBLElBQzdDNEUsWUFBWTtBQUFBLElBQ1p4RSxTQUFTO0FBQUEsSUFDVHlFLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSS9FLFNBQVM7QUFBQSxJQUN2Q2dGLFVBQVU7QUFBQSxJQUNWQyxpQkFBaUI7QUFBQSxJQUNqQkMsbUJBQW1CO0FBQUEsSUFDbkJDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsTUFBTTtBQUFBLElBQ05DLG1CQUFtQjtBQUFBLElBQ25CQyxtQkFBbUI7QUFBQSxJQUNuQkMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxVQUFVO0FBQUE7QUFBQSxFQUVaLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTVGLFNBQVMsQ0FBQyxDQUFDO0FBRXZDLFFBQU0sQ0FBQzZGLGdCQUFnQkMsaUJBQWlCLElBQUk5RixTQUFTO0FBQUEsSUFDbkRnRixVQUFVO0FBQUEsSUFDVkMsaUJBQWlCO0FBQUEsSUFDakJDLG1CQUFtQjtBQUFBLElBQ25CQyxnQkFBZ0I7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1pDLE1BQU07QUFBQSxJQUNOQyxtQkFBbUI7QUFBQSxJQUNuQkMsbUJBQW1CO0FBQUEsSUFDbkJDLGVBQWU7QUFBQSxJQUNmQyxnQkFBZ0I7QUFBQSxJQUNoQkMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUVEM0YsWUFBVSxNQUFNO0FBQ2QsVUFBTWdHLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU0zRixJQUFJNEYsSUFBSSxnQkFBZ0I7QUFDL0MsWUFBSUQsU0FBU0UsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLDJCQUEyQjtBQUM3QzFFLGlCQUFTdUUsU0FBU0ksSUFBSTtBQUFBLE1BQ3hCLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sa0NBQWtDQSxLQUFLO0FBQUEsTUFDdkQ7QUFBQSxJQUNGO0FBQ0FOLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxDQUFDN0MsYUFBYSxDQUFDO0FBRWxCbkQsWUFBVSxNQUFNO0FBQ2QsVUFBTXdHLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTVAsV0FBVyxNQUFNM0YsSUFBSTRGLElBQUksWUFBWTtBQUMzQ3RFLGtCQUFVcUUsU0FBU0ksTUFBTUksS0FBSztBQUFBLE1BQ2hDLFNBQVNDLEtBQUs7QUFDWkgsZ0JBQVFELE1BQU0seUJBQXlCSSxHQUFHO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQ0FGLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTHhHLFlBQVUsTUFBTTtBQUNkLFVBQU0yRyxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTVYsV0FBVyxNQUFNM0YsSUFBSTRGLElBQUksV0FBVztBQUMxQ3BFLHFCQUFhbUUsVUFBVUksTUFBTU8sUUFBUTtBQUFBLE1BQ3ZDLFNBQVNOLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQ0FLLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBR0wzRyxZQUFVLE1BQU07QUFDZCxVQUFNNkcsbUJBQW1CLFlBQVk7QUFDbkMsVUFBSTtBQUNGM0MseUJBQWlCLElBQUk7QUFDckIsY0FBTStCLFdBQVcsTUFBTTNGLElBQUk0RixJQUFJLCtCQUErQjtBQUM5RCxjQUFNRyxPQUFPSixTQUFTSSxNQUFNQSxRQUFRO0FBRXBDLGNBQU1TLFlBQVlULEtBQUtVLElBQUksQ0FBQ0MsTUFBTUMsV0FBVztBQUFBLFVBQzNDQyxJQUFJRCxRQUFRO0FBQUEsVUFDWkUsS0FBS0gsS0FBS0c7QUFBQUEsVUFDVkMsVUFBVUosS0FBS0k7QUFBQUEsVUFDZkMsZUFBZUwsS0FBSy9CLFVBQVVxQyxhQUFhO0FBQUEsVUFDM0NDLGNBQWNQLEtBQUsvQixVQUFVc0MsZ0JBQWdCO0FBQUEsVUFDN0NyQyxpQkFBaUI4QixLQUFLOUI7QUFBQUEsVUFDdEJzQyxpQkFBaUIsR0FBR1IsS0FBSzlCLGVBQWUsT0FBTzhCLEtBQUs1QixjQUFjO0FBQUEsVUFDbEVBLGdCQUFnQjRCLEtBQUs1QjtBQUFBQSxVQUNyQkQsbUJBQW1CNkIsS0FBSzdCLHFCQUFxQjZCLE1BQU1TLHVCQUF1QjtBQUFBLFVBQzFFaEMsZUFBZXVCLEtBQUt2QixpQkFBaUI7QUFBQSxVQUNyQ2lDLGNBQWMsTUFBTTtBQUNsQixnQkFBSUMsTUFBTTtBQUNWLGtCQUFNQyxVQUFVWixLQUFLdkIsaUJBQWlCdUIsS0FBSy9CLFVBQVVRLGlCQUFpQnVCLE1BQU14QjtBQUM1RSxnQkFBSW9DLFlBQVksY0FBY1osTUFBTXhCLG1CQUFtQjtBQUNyRCxvQkFBTXFDLE1BQU1iLEtBQUt4QixxQkFBcUJ3QixLQUFLL0IsVUFBVU87QUFDckQsa0JBQUlxQyxJQUFLRixPQUFNLEdBQUdFLElBQUlDLElBQUksTUFBTUQsSUFBSU4sZ0JBQWdCTSxJQUFJRSxnQkFBZ0IsRUFBRTtBQUFBLFlBQzVFLFdBQVdILFlBQVksU0FBUztBQUM5QixvQkFBTW5CLFFBQVFPLEtBQUt0QixrQkFBa0JzQixLQUFLL0IsVUFBVVM7QUFDcEQsa0JBQUllLE1BQU9rQixPQUFNLEdBQUdsQixNQUFNcUIsSUFBSSxNQUFNckIsTUFBTWMsZ0JBQWdCLEVBQUU7QUFBQSxZQUM5RCxXQUFXSyxZQUFZLFlBQVk7QUFDakMsb0JBQU1JLE9BQU9oQixLQUFLekIscUJBQXFCeUIsS0FBSy9CLFVBQVVNO0FBQ3RELGtCQUFJeUMsS0FBTUwsT0FBTSxHQUFHSyxLQUFLVixTQUFTLE1BQU1VLEtBQUtULGdCQUFnQixFQUFFO0FBQUEsWUFDaEU7QUFDQSxtQkFBT0k7QUFBQUEsVUFDVCxHQUFHO0FBQUEsVUFDSHRDLFlBQVkyQixLQUFLM0IsWUFBWTRDLE1BQU0sR0FBRyxFQUFFLENBQUMsR0FBR0EsTUFBTSxHQUFHLEVBQUVDLFFBQVEsRUFBRUMsS0FBSyxHQUFHLEtBQUs7QUFBQSxVQUM5RXhDLFVBQVVxQixLQUFLckIsV0FBVyxHQUFHcUIsS0FBS3JCLFFBQVEsWUFBWTtBQUFBLFVBQ3REUSxRQUNFLHVCQUFDLFNBQUksV0FBVSx1QkFDYixpQ0FBQyxVQUFLLFdBQVUsMEVBQXlFLHNCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBRUZpQyxRQUNFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQ1JDLE9BQU9DLFNBQVNDLE9BQU8sMkJBQTJCMUIsS0FBS0csR0FBRztBQUFBLHdCQUMxRDtBQUFBO0FBQUEsc0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRUw7QUFBQSxjQUVBLGlDQUFDLFlBQVMsV0FBVSw4QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQTtBQUFBLFlBbkJoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxRQUVKLEVBQUU7QUFDRm5ELDJCQUFtQjhDLFNBQVM7QUFBQSxNQUM5QixTQUFTUixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRDFCLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1p4RSxTQUFTO0FBQUEsVUFDVHlFLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFVBQUM7QUFDQ1oseUJBQWlCLEtBQUs7QUFBQSxNQUN4QjtBQUFBLElBQ0Y7QUFDQTJDLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsQ0FBQzFELGFBQWEsQ0FBQztBQUVsQm5ELFlBQVUsTUFBTTtBQUNkLFVBQU0ySSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0ZyRixxQkFBYSxJQUFJO0FBQ2pCLGNBQU0yQyxXQUFXLE1BQU0zRixJQUFJNEYsSUFBSSxnQ0FBZ0M7QUFDL0QsY0FBTTBDLFlBQVkzQyxTQUFTSSxRQUFRO0FBRW5DLGNBQU13QyxnQkFBZ0JELFVBQVU3QixJQUFJLENBQUMrQixrQkFBa0I7QUFDckQsY0FBSXBCLGNBQWM7QUFFbEIsZ0JBQU1FLFVBQ0prQixlQUFlckQsaUJBQ2ZxRCxlQUFlN0QsVUFBVVE7QUFFM0IsY0FBSW1DLFlBQVksWUFBWTtBQUMxQixrQkFBTUMsTUFDSmlCLGVBQWV0RCxxQkFDZnNELGVBQWU3RCxVQUFVTztBQUUzQixnQkFBSXFDLEtBQUs7QUFDUEgsNEJBQWMsR0FBR0csSUFBSUMsSUFBSSxNQUFNRCxJQUFJTixnQkFBZ0JNLElBQUlFLGdCQUFnQixFQUFFO0FBQUEsWUFDM0U7QUFBQSxVQUNGLFdBQ1NILFlBQVksU0FBUztBQUM1QixrQkFBTW5CLFFBQ0pxQyxlQUFlcEQsa0JBQ2ZvRCxlQUFlN0QsVUFBVVM7QUFFM0IsZ0JBQUllLE9BQU87QUFDVGlCLDRCQUFjLEdBQUdqQixNQUFNcUIsSUFBSSxNQUFNckIsTUFBTWMsZ0JBQWdCLEVBQUU7QUFBQSxZQUMzRDtBQUFBLFVBQ0YsV0FDU0ssWUFBWSxZQUFZO0FBQy9CLGtCQUFNSSxPQUNKYyxlQUFldkQscUJBQ2Z1RCxlQUFlN0QsVUFBVU07QUFFM0IsZ0JBQUl5QyxNQUFNO0FBQ1JOLDRCQUFjLEdBQUdNLEtBQUtWLFNBQVMsTUFBTVUsS0FBS1QsZ0JBQWdCLEVBQUU7QUFBQSxZQUM5RDtBQUFBLFVBQ0Y7QUFHQSxpQkFBTztBQUFBLFlBQ0xKLEtBQUsyQixlQUFlM0I7QUFBQUEsWUFDcEJDLFVBQVUwQixlQUFlMUI7QUFBQUEsWUFDekJDLGVBQWV5QixlQUFlN0QsVUFBVXFDO0FBQUFBLFlBQ3hDQyxjQUFjdUIsZUFBZTdELFVBQVVzQztBQUFBQSxZQUN2Q3dCLE1BQU1ELGVBQWVFO0FBQUFBLFlBQ3JCOUQsaUJBQWlCNEQsZUFBZTVEO0FBQUFBLFlBQ2hDQyxtQkFBbUIyRCxlQUFlM0Qsb0JBQW9CO0FBQUEsWUFDdERxQyxpQkFBaUIsR0FBR3NCLGVBQWU1RCxlQUFlLE9BQU80RCxlQUFlMUQsY0FBYztBQUFBLFlBQ3RGQSxnQkFBZ0IwRCxlQUFlMUQ7QUFBQUEsWUFDL0JDLFlBQVl5RCxlQUFlekQsWUFDdkI0QyxNQUFNLEdBQUcsRUFBRSxDQUFDLEVBQ2JBLE1BQU0sR0FBRyxFQUNUQyxRQUFRLEVBQ1JDLEtBQUssR0FBRztBQUFBLFlBQ1h4QyxVQUFVbUQsZUFBZW5ELFdBQ3JCLEdBQUdtRCxjQUFjbkQsUUFBUSxZQUN6QjtBQUFBLFlBQ0pMLE1BQU13RCxlQUFleEQ7QUFBQUEsWUFDckJHLGVBQ0VxRCxlQUFlckQsaUJBQ2ZxRCxlQUFlN0QsVUFBVVEsaUJBQ3pCO0FBQUEsWUFDRmlDO0FBQUFBO0FBQUFBLFlBQ0F1QixnQkFBZ0JILGVBQWVHLGtCQUFrQjtBQUFBO0FBQUEsWUFFakQ5QyxRQUNFLHVCQUFDLFNBQUksV0FBVSx1QkFDWjJDLHlCQUFlRyxtQkFBbUIsY0FDakMsdUJBQUMsVUFBSyxXQUFVLDhFQUE2RSx5QkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUNFSCxlQUFlRyxtQkFBbUIsYUFDcEMsdUJBQUMsVUFBSyxXQUFVLDRFQUEyRSx3QkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUNFSCxlQUFlRyxtQkFBbUIsV0FDcEMsdUJBQUMsVUFBSyxXQUFVLDBFQUF5RSxzQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxJQUVBLE1BZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUVGYixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU07QUFBQSxrQkFDSkMsT0FBTztBQUFBLG9CQUNMO0FBQUEsc0JBQ0VDLEtBQUs7QUFBQSxzQkFDTEMsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUFNVyxzQkFBc0JKLGNBQWMzQixHQUFHO0FBQUEsMEJBQUU7QUFBQTtBQUFBLHdCQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VtQixLQUFLO0FBQUEsc0JBQ0xDLE9BQ0U7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLFNBQVMsTUFBTVksc0JBQXNCTCxjQUFjM0IsR0FBRztBQUFBLDBCQUFFO0FBQUE7QUFBQSx3QkFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUtBO0FBQUEsb0JBRUo7QUFBQTtBQUFBLG9CQUVBLEdBQUkyQixlQUFlRyxtQkFBbUIsY0FDbEM7QUFBQSxzQkFDQTtBQUFBLHdCQUNFWCxLQUFLO0FBQUEsd0JBQ0xDLE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFDUEMsT0FBT1k7QUFBQUEsOEJBQ0wsMkJBQTJCTixjQUFjM0IsR0FBRztBQUFBLDhCQUM1QztBQUFBLDRCQUNGO0FBQUEsNEJBQ0Q7QUFBQTtBQUFBLDBCQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFVQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUMsSUFFRDtBQUFBO0FBQUEsb0JBRUosR0FBSTJCLGVBQWVHLG1CQUFtQixlQUNwQ0gsZUFBZUcsbUJBQW1CLFdBQ2hDO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRVgsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU07QUFDYm5JLHVDQUFTaUosUUFBUTtBQUFBLGdDQUNmQyxPQUFPLDBCQUEwQlIsZUFBZTdELFVBQVVxQyxTQUFTO0FBQUEsZ0NBQ25FaUMsU0FDRTtBQUFBLGdDQUNGQyxRQUFRO0FBQUEsZ0NBQ1JDLFlBQVk7QUFBQSxnQ0FDWkMsTUFBTUEsTUFDSkM7QUFBQUEsa0NBQ0UsRUFBRXhDLEtBQUsyQixjQUFjM0IsSUFBSTtBQUFBLGtDQUN6QjtBQUFBLGdDQUNGO0FBQUEsOEJBQ0osQ0FBQztBQUFBLDRCQUNIO0FBQUEsNEJBQUU7QUFBQTtBQUFBLDBCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFrQkE7QUFBQSxzQkFFSjtBQUFBLG9CQUFDLElBRUQ7QUFBQTtBQUFBLG9CQUVKLEdBQUkyQixlQUFlRyxtQkFBbUIsY0FDbEM7QUFBQSxzQkFDQTtBQUFBLHdCQUNFWCxLQUFLO0FBQUEsd0JBQ0xDLE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFBTXFCLGtCQUFrQmQsYUFBYTtBQUFBLDRCQUFFO0FBQUE7QUFBQSwwQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsc0JBRUo7QUFBQSxvQkFBQyxJQUVEO0FBQUEsa0JBQUc7QUFBQSxnQkFFWDtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0I7QUFBQTtBQUFBLGNBaEdqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpR0EsS0FsRzhDQSxjQUFjM0IsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtR0E7QUFBQSxVQUVKO0FBQUEsUUFDRixDQUFDO0FBR0QsY0FBTTBDLGFBQWFoQixjQUFjaUIsS0FBSyxDQUFDQyxHQUFHQyxNQUFNO0FBQzlDLGNBQUlELEVBQUVkLG1CQUFtQixlQUFlZSxFQUFFZixtQkFBbUIsWUFBYSxRQUFPO0FBQ2pGLGNBQUllLEVBQUVmLG1CQUFtQixlQUFlYyxFQUFFZCxtQkFBbUIsWUFBYSxRQUFPO0FBQ2pGLGlCQUFPLElBQUlnQixLQUFLRCxFQUFFakIsSUFBSSxJQUFJLElBQUlrQixLQUFLRixFQUFFaEIsSUFBSTtBQUFBLFFBQzNDLENBQUM7QUFHRCxjQUFNbUIsYUFBYUwsV0FBVzlDLElBQUksQ0FBQ0MsTUFBTUMsV0FBVztBQUFBLFVBQ2xELEdBQUdEO0FBQUFBLFVBQ0hFLElBQUlELFFBQVE7QUFBQSxRQUNkLEVBQUU7QUFFRi9FLDBCQUFrQmdJLFVBQVU7QUFBQSxNQUM5QixTQUFTNUQsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFDakQxQix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaeEUsU0FBUztBQUFBLFVBQ1R5RSxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0N4QixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBRUFxRixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ3hGLGFBQWEsQ0FBQztBQUVsQixRQUFNZ0gsZUFBZUEsQ0FBQzlGLE1BQU07QUFDMUIsVUFBTSxFQUFFeUQsTUFBTXhELE1BQU0sSUFBSUQsRUFBRUU7QUFDMUJTLGdCQUFZLENBQUNvRixVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDdEMsSUFBSSxHQUFHeEQsTUFBTSxFQUFFO0FBQ2xEdUIsY0FBVSxDQUFDdUUsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ3RDLElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUMvQztBQUVBLFFBQU11QyxlQUFlQSxDQUFDdkYsU0FBUztBQUM3QixVQUFNd0YsWUFBWSxDQUFDO0FBQ25CLFVBQU1qRSxPQUFPdkIsU0FBUyxnQkFBZ0JDLFdBQVdlO0FBRWpELFFBQUksQ0FBQ08sS0FBS3BCLFNBQVVxRixXQUFVckYsV0FBVztBQUN6QyxRQUFJLENBQUNvQixLQUFLbkIsZ0JBQWlCb0YsV0FBVXBGLGtCQUFrQjtBQUN2RCxRQUFJLENBQUNtQixLQUFLakIsZUFBZ0JrRixXQUFVbEYsaUJBQWlCO0FBQUEsYUFDNUNtRixNQUFNbEUsS0FBS2pCLGNBQWMsS0FBS2lCLEtBQUtqQixrQkFBa0I7QUFDNURrRixnQkFBVWxGLGlCQUFpQjtBQUM3QixRQUFJLENBQUNpQixLQUFLaEIsV0FBWWlGLFdBQVVqRixhQUFhO0FBRTdDUSxjQUFVeUUsU0FBUztBQUNuQixXQUFPRSxPQUFPQyxLQUFLSCxTQUFTLEVBQUVJLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1DLGVBQWUsT0FBT3RHLE1BQU07QUFDaENBLE1BQUV1RyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVVSLGFBQWEsYUFBYTtBQUMxQyxRQUFJLENBQUNRLFFBQVM7QUFDZCxRQUFJO0FBQ0YsWUFBTUMsVUFBVTtBQUFBLFFBQ2QsR0FBRy9GO0FBQUFBLFFBQ0gsR0FBR1A7QUFBQUEsUUFDSG1CLFVBQVVvRixPQUFPQyxPQUFPakcsU0FBU1ksUUFBUSxFQUFFc0YsUUFBUSxPQUFPLEVBQUUsQ0FBQztBQUFBO0FBQUEsTUFFL0Q7QUFDQSxZQUFNaEYsV0FBVyxNQUFNM0YsSUFBSTRLLEtBQUssaUNBQWlDSixPQUFPO0FBQ3hFLFVBQUk3RSxTQUFTRSxVQUFVLElBQUssT0FBTSxJQUFJQyxNQUFNLHdCQUF3QjtBQUNwRWhELHVCQUFpQixDQUFDZ0gsU0FBU0EsT0FBTyxDQUFDO0FBQ25DeEYscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWnhFLFNBQVM7QUFBQSxRQUNUeUUsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEMUMsbUJBQWEsS0FBSztBQUNsQjRDLGtCQUFZO0FBQUEsUUFDVkMsVUFBVTtBQUFBLFFBQ1ZDLGlCQUFpQjtBQUFBLFFBQ2pCQyxtQkFBbUI7QUFBQSxRQUNuQkMsZ0JBQWdCO0FBQUEsUUFDaEJDLFlBQVk7QUFBQSxRQUNaQyxNQUFNO0FBQUEsUUFDTkMsbUJBQW1CO0FBQUEsUUFDbkJDLG1CQUFtQjtBQUFBLFFBQ25CQyxlQUFlO0FBQUEsUUFDZkMsZ0JBQWdCO0FBQUEsUUFDaEJDLFVBQVU7QUFBQTtBQUFBLE1BRVosQ0FBQztBQUFBLElBQ0gsU0FBU1csT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUM3QzFCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1p4RSxTQUFTaUcsTUFBTUwsVUFBVUksTUFBTWhHLFdBQVc7QUFBQSxRQUMxQ3lFLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1xRSx3QkFBd0IsT0FBT2dDLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1sRixXQUFXLE1BQU0zRixJQUFJNEYsSUFBSSxtQkFBbUJpRixPQUFPLEVBQUU7QUFDM0RySSx5QkFBbUJtRCxTQUFTSSxJQUFJO0FBQ2hDL0QseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTZ0UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLFFBQU00Qyx3QkFBd0IsT0FBT2lDLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1sRixXQUFXLE1BQU0zRixJQUFJNEYsSUFBSSxtQkFBbUJpRixPQUFPLEVBQUU7QUFDM0QsWUFBTUMsWUFBWW5GLFNBQVNJO0FBQzNCLFlBQU1nRixxQkFBcUJELFdBQVcvRixZQUFZNEMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM5RGpGLCtCQUF5QmlELFNBQVNJLElBQUk7QUFDdENOLHdCQUFrQjtBQUFBLFFBQ2hCZCxVQUFVZ0IsVUFBVUksTUFBTXBCLFNBQVNrQztBQUFBQSxRQUNuQ2pDLGlCQUFpQmUsVUFBVUksTUFBTW5CO0FBQUFBLFFBQ2pDQyxtQkFBbUJjLFVBQVVJLE1BQU1sQjtBQUFBQSxRQUNuQ0MsZ0JBQWdCYSxVQUFVSSxNQUFNakI7QUFBQUEsUUFDaENDLFlBQVlnRztBQUFBQSxRQUNaL0YsTUFBTVcsVUFBVUksTUFBTWY7QUFBQUEsUUFDdEJFLG1CQUFtQlMsVUFBVUksTUFBTWIsbUJBQW1CMkIsT0FBTztBQUFBLFFBQzdENUIsbUJBQW1CVSxVQUFVSSxNQUFNZCxtQkFBbUI0QixPQUFPO0FBQUEsUUFDN0R6QixnQkFBZ0JPLFVBQVVJLE1BQU1YLGdCQUFnQnlCLE9BQU87QUFBQSxRQUN2RDFCLGVBQWVRLFVBQVVJLE1BQU1aLGlCQUFpQjtBQUFBLFFBQ2hERSxVQUFVTSxVQUFVSSxNQUFNVixZQUFZO0FBQUEsTUFDeEMsQ0FBQztBQUNEbkQseUJBQW1CLElBQUk7QUFDdkJxRCxnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVNTLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3Q0FBd0NBLEtBQUs7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFHQSxRQUFNZ0YsbUJBQW1CQSxDQUFDckcsYUFBYTtBQUNyQ25DLHVCQUFtQm1DLFFBQVE7QUFDM0J2Qyx3QkFBb0IsSUFBSTtBQUFBLEVBQzFCO0FBRUEsUUFBTWlILG9CQUFvQixPQUFPNEIsT0FBT0MsY0FBYztBQUNwRCxRQUFJO0FBQ0YsWUFBTWxMLElBQUltTCxNQUFNLDJCQUEyQkYsTUFBTXBFLEdBQUcsSUFBSTtBQUFBLFFBQ3REOEIsZ0JBQWdCdUM7QUFBQUEsTUFDbEIsQ0FBQztBQUNEbkwsY0FBUXFMLFFBQVEsMkJBQTJCRixTQUFTLGVBQWU7QUFDbkVwSSx1QkFBaUIsQ0FBQ2dILFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ3JDLFNBQVM5RCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EakcsY0FBUWlHLE1BQU0sK0JBQStCO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBR0EsUUFBTXFGLGdCQUFnQixZQUFZO0FBQ2hDLFFBQUksQ0FBQzlJLGdCQUFpQjtBQUN0QixRQUFJO0FBQ0YsWUFBTXZDLElBQUltTCxNQUFNLDJCQUEyQjVJLGdCQUFnQnNFLEdBQUcsSUFBSTtBQUFBLFFBQ2hFOEIsZ0JBQWdCO0FBQUEsTUFDbEIsQ0FBQztBQUNEN0YsdUJBQWlCLENBQUNnSCxTQUFTQSxPQUFPLENBQUM7QUFDbkN4RixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaeEUsU0FBUztBQUFBLFFBQ1R5RSxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0RwQywwQkFBb0IsS0FBSztBQUN6QkkseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTd0QsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUM3QzFCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1p4RSxTQUFTaUcsTUFBTUwsVUFBVUksTUFBTWhHLFdBQVc7QUFBQSxRQUMxQ3lFLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBLFFBQU04RSxvQkFBb0IsT0FBTzNFLGFBQWE7QUFDNUMsUUFBSTtBQUNGLFlBQU1nQixXQUFXLE1BQU0zRixJQUFJNEYsSUFBSSxvQkFBb0JqQixTQUFTa0MsR0FBRyxFQUFFO0FBQ2pFLFVBQUlsQixTQUFTSSxLQUFLcUYsU0FBUztBQUN6QmxJLHdCQUFnQnlDLFNBQVNJLEtBQUtBLElBQUk7QUFDbEN6Qyw0QkFBb0JxQyxTQUFTSSxLQUFLQSxLQUFLb0Isd0JBQXdCLEdBQUc7QUFDbEUvRCwwQkFBa0IsS0FBSztBQUN2QmQsNkJBQXFCLElBQUk7QUFBQSxNQUMzQixPQUFPO0FBQ0wsY0FBTSxJQUFJd0QsTUFBTSw0QkFBNEI7QUFBQSxNQUM5QztBQUFBLElBQ0YsU0FBU0UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHNDQUFzQ0EsS0FBSztBQUN6RDFCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1p4RSxTQUFTO0FBQUEsUUFDVHlFLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU04RyxrQkFBa0IsWUFBWTtBQUNsQyxRQUFJLENBQUNySSxhQUFjO0FBQ25CLFFBQUk7QUFDRixZQUFNMEMsV0FBVyxNQUFNM0YsSUFBSXVMLElBQUksaUNBQWlDdEksYUFBYTRELEdBQUcsSUFBSTtBQUFBLFFBQ2xGTSxzQkFBc0I5RDtBQUFBQSxNQUN4QixDQUFDO0FBQ0QsVUFBSXNDLFNBQVNJLEtBQUtGLFFBQVE7QUFFeEIzQyx3QkFBZ0IsQ0FBQTRHLFVBQVMsRUFBRSxHQUFHQSxNQUFNLEdBQUduRSxTQUFTSSxLQUFLQSxLQUFLLEVBQUU7QUFDNUQzQywwQkFBa0IsSUFBSTtBQUFBLE1BQ3hCLE9BQU87QUFDTCxjQUFNLElBQUkwQyxNQUFNLG9CQUFvQjtBQUFBLE1BQ3RDO0FBQUEsSUFDRixTQUFTRSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BEMUIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWnhFLFNBQVNpRyxNQUFNTCxVQUFVSSxNQUFNaEcsV0FBVztBQUFBLFFBQzFDeUUsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTWdILGlCQUFpQkEsTUFBTTtBQUMzQmxKLHlCQUFxQixLQUFLO0FBQzFCWSxvQkFBZ0IsSUFBSTtBQUNwQkUsc0JBQWtCLEtBQUs7QUFDdkJOLHFCQUFpQixDQUFBZ0gsU0FBUUEsT0FBTyxDQUFDO0FBQUEsRUFDbkM7QUFFQSxRQUFNMkIsbUJBQW1CQSxDQUFDQyxPQUFPMUgsVUFBVTtBQUN6Q1UsZ0JBQVksQ0FBQ2lILGNBQWMsRUFBRSxHQUFHQSxVQUFVLENBQUNELEtBQUssR0FBRzFILE1BQU0sRUFBRTtBQUMzRHVCLGNBQVUsQ0FBQ3FHLGdCQUFnQixFQUFFLEdBQUdBLFlBQVksQ0FBQ0YsS0FBSyxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQzVEO0FBRUEsUUFBTUcsd0JBQXdCQSxDQUFDSCxPQUFPMUgsVUFBVTtBQUM5Q3lCLHNCQUFrQixDQUFDa0csY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0h6RyxtQkFBbUI7QUFBQSxNQUNuQkUsZ0JBQWdCO0FBQUEsTUFDaEJILG1CQUFtQjtBQUFBLE1BQ25CLENBQUN5RyxLQUFLLEdBQUcxSDtBQUFBQSxJQUNYLEVBQUU7QUFDRnVCLGNBQVUsRUFBRSxHQUFHRCxRQUFRLENBQUNvRyxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFFQSxRQUFNSSxvQkFBb0JBLENBQUMvSCxNQUFNO0FBQy9CLFVBQU0sRUFBRXlELE1BQU14RCxNQUFNLElBQUlELEVBQUVFO0FBQzFCd0Isc0JBQWtCLENBQUNrRyxjQUFjLEVBQUUsR0FBR0EsVUFBVSxDQUFDbkUsSUFBSSxHQUFHeEQsTUFBTSxFQUFFO0FBQ2hFdUIsY0FBVSxDQUFDdUUsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ3RDLElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUMvQztBQUVBLFFBQU11RSxvQkFBb0IsWUFBWTtBQUNwQyxRQUFJeEosaUJBQWlCO0FBQ25CLFVBQUk7QUFDRixjQUFNdkMsSUFBSWdNLE9BQU8sZ0NBQWdDekosZ0JBQWdCc0UsR0FBRyxFQUFFO0FBQ3RFL0QseUJBQWlCLENBQUNnSCxTQUFTQSxPQUFPLENBQUM7QUFDbkN4Rix1QkFBZTtBQUFBLFVBQ2J2RSxTQUFTO0FBQUEsVUFDVHlFLE1BQU07QUFBQSxVQUNORCxZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQ0R2QywyQkFBbUIsS0FBSztBQUN4QlEsMkJBQW1CLElBQUk7QUFBQSxNQUN6QixTQUFTd0QsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFDakQxQix1QkFBZTtBQUFBLFVBQ2J2RSxTQUFTaUcsTUFBTUwsVUFBVUksTUFBTWhHLFdBQVc7QUFBQSxVQUMxQ3lFLE1BQU07QUFBQSxVQUNORCxZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTTBILGVBQWUsT0FBT2xJLE1BQU07QUFDaENBLE1BQUV1RyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVVSLGFBQWE7QUFDN0IsUUFBSSxDQUFDUSxRQUFTO0FBQ2QsUUFBSTtBQUNGLFlBQU12SyxJQUFJbUw7QUFBQUEsUUFDUixnQ0FBZ0MxSSxzQkFBc0JvRSxHQUFHO0FBQUEsUUFDekRyQjtBQUFBQSxNQUNGO0FBQ0F0RCx5QkFBbUIsS0FBSztBQUN4QlksdUJBQWlCLENBQUNnSCxTQUFTQSxPQUFPLENBQUM7QUFDbkN4RixxQkFBZTtBQUFBLFFBQ2J2RSxTQUFTO0FBQUEsUUFDVHlFLE1BQU07QUFBQSxRQUNORCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSCxTQUFTeUIsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRCQUE0QkEsS0FBSztBQUMvQzFCLHFCQUFlO0FBQUEsUUFDYnZFLFNBQVNpRyxNQUFNTCxVQUFVSSxNQUFNaEcsV0FBVztBQUFBLFFBQzFDeUUsTUFBTTtBQUFBLFFBQ05ELFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0ySCxVQUFVO0FBQUEsSUFDZCxFQUFFbEUsS0FBSyxNQUFNbUUsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRW5FLEtBQUssWUFBWW1FLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVuRSxLQUFLLGlCQUFpQm1FLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRW5FLEtBQUssZ0JBQWdCbUUsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRW5FLEtBQUssbUJBQW1CbUUsUUFBUSxlQUFlO0FBQUE7QUFBQSxJQUVqRCxFQUFFbkUsS0FBSyxtQkFBbUJtRSxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVuRSxLQUFLLHFCQUFxQm1FLFFBQVEsb0JBQW9CO0FBQUEsSUFDeEQsRUFBRW5FLEtBQUssaUJBQWlCbUUsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFbkUsS0FBSyxlQUFlbUUsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRW5FLEtBQUssY0FBY21FLFFBQVEsY0FBY0MsT0FBTyxJQUFJO0FBQUEsSUFDdEQsRUFBRXBFLEtBQUssWUFBWW1FLFFBQVEsWUFBWUMsT0FBTyxJQUFJO0FBQUE7QUFBQSxJQUVsRCxFQUFFcEUsS0FBSyxVQUFVbUUsUUFBUSxTQUFTO0FBQUE7QUFBQSxJQUNsQyxFQUFFbkUsS0FBSyxVQUFVbUUsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUlyQyxRQUFNRSxnQkFBZ0I7QUFBQSxJQUNwQixFQUFFckUsS0FBSyxNQUFNbUUsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRW5FLEtBQUssWUFBWW1FLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVuRSxLQUFLLGlCQUFpQm1FLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRW5FLEtBQUssZ0JBQWdCbUUsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRW5FLEtBQUssbUJBQW1CbUUsUUFBUSxlQUFlO0FBQUEsSUFDakQsRUFBRW5FLEtBQUssbUJBQW1CbUUsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFbkUsS0FBSyxxQkFBcUJtRSxRQUFRLHlDQUF5QztBQUFBO0FBQUEsSUFFN0UsRUFBRW5FLEtBQUssZUFBZW1FLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVuRSxLQUFLLGNBQWNtRSxRQUFRLGNBQWNDLE9BQU8sSUFBSTtBQUFBLElBQ3RELEVBQUVwRSxLQUFLLFlBQVltRSxRQUFRLFlBQVlDLE9BQU8sSUFBSTtBQUFBLElBQ2xELEVBQUVwRSxLQUFLLFVBQVVtRSxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFbkUsS0FBSyxVQUFVbUUsUUFBUSxTQUFTO0FBQUE7QUFBQSxFQUFHO0FBR3ZDLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDQztBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxZQUFZO0FBQUEsUUFDWjtBQUFBO0FBQUEsTUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFMkQ7QUFBQSxJQUUzRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTTlILFlBQVlHO0FBQUFBLFFBQ2xCLFdBQVdILFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVl0RTtBQUFBQSxRQUNyQixTQUFTLE1BQ1B1RSxlQUFlLENBQUN3RixVQUFVLEVBQUUsR0FBR0EsTUFBTXZGLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBRUgsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ1gsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBCQUF5QixxQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQSxZQUM1Qyx1QkFBQyxTQUFJLFdBQVUsMkJBU2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsV0FBVTtBQUFBLGtCQUVnQjtBQUFBO0FBQUEsZ0JBSjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsY0FDQ2hCLGNBQWMsV0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU07QUFDYnpCLGlDQUFhLElBQUk7QUFDakJ5RCw4QkFBVSxDQUFDLENBQUM7QUFBQSxrQkFDZDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFBZ0g7QUFBQTtBQUFBLGdCQUw1SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsaUNBQ2IsaUNBQUMsU0FBSSxXQUFVLHlCQUF3QixjQUFXLFFBQ2hEO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU0vQixhQUFhLE9BQU87QUFBQSxnQkFDbkMsV0FBVyxHQUFHRCxjQUFjLFVBQ3hCLGtDQUNBLDRFQUE0RTtBQUFBLGdCQUNoQjtBQUFBO0FBQUEsY0FMbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNQyxhQUFhLFFBQVE7QUFBQSxnQkFDcEMsV0FBVyxHQUFHRCxjQUFjLFdBQ3hCLGtDQUNBLDRFQUE0RTtBQUFBLGdCQUNoQjtBQUFBO0FBQUEsY0FMbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLGFBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwREE7QUFBQSxRQUVDQSxjQUFjLFdBQ2IsbUNBQ0c1QiwwQkFBZ0J5SSxTQUFTLEtBQUssQ0FBQ3JILFlBQzlCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixlQUFlNkY7QUFBQUEsWUFDZixNQUFNckksYUFBYW9CLGdCQUFnQmdCLFVBQVU7QUFBQSxZQUM3QztBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxVQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNZ0MsSUFHaEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxTQUFTaEIsZ0JBQWdCeUksVUFBVTtBQUFBO0FBQUEsVUFIckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3VDLEtBZDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUdEN0csY0FBYyxZQUNiLG1DQUNHRSwyQkFBaUIyRyxTQUFTLEtBQUssQ0FBQ3pHLGdCQUMvQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsTUFBTXBELGFBQWFrRCxpQkFBaUJkLFVBQVU7QUFBQSxZQUM5QyxTQUFTMEo7QUFBQUEsWUFDVCxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBa0I7QUFBQTtBQUFBLFVBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtzQyxJQUd0QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVzFJO0FBQUFBLFlBQ1gsTUFBSztBQUFBLFlBQ0wsU0FBU0YsaUJBQWlCMkcsVUFBVTtBQUFBO0FBQUEsVUFIdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3dDLEtBYjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQW5HSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUdBO0FBQUEsU0F2R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdHQTtBQUFBLElBR0EsdUJBQUMsU0FBTSxXQUFXdkksV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLHlCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVXVJLGNBQWMsWUFBVSxNQUU1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxZQUN6Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsZUFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcscUNBQXFDM0osVUFBVTRMLE1BQU07QUFBQSxjQUNoRSxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsT0FBTzdILFVBQVVFLFlBQVk7QUFBQSxjQUM3QixVQUFVLENBQUNYLFVBQVV5SCxpQkFBaUIsWUFBWXpILEtBQUs7QUFBQSxjQUN2RCxjQUFjLENBQUN1SSxPQUFPQyxXQUNwQkEsUUFBUXZFLE9BQU93RSxZQUFZLEVBQUVDLFNBQVNILE1BQU1FLFlBQVksQ0FBQztBQUFBLGNBRTNELFNBQVN0TCxNQUFNc0YsSUFBSSxDQUFDa0csVUFBVTtBQUFBLGdCQUM1QjNJLE9BQU8ySSxLQUFLOUY7QUFBQUEsZ0JBQ1pvQixPQUFPLEdBQUcwRSxLQUFLQyxXQUFXLE1BQU1ELEtBQUszRixTQUFTLE1BQU0yRixLQUFLMUYsWUFBWTtBQUFBLGNBQ3ZFLEVBQUU7QUFBQTtBQUFBLFlBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0E7QUFBQSxVQUNDM0IsT0FBT1gsWUFBWSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCVyxpQkFBT1gsWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxhQW5CaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLFlBQW9CLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySDtBQUFBLFVBQzNIO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLHFDQUFxQ2pFLFVBQVU0TCxNQUFNO0FBQUEsY0FDaEUsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLE9BQU83SCxVQUFVRyxtQkFBbUJpSTtBQUFBQSxjQUNwQyxVQUFVLENBQUM3SSxVQUFVeUgsaUJBQWlCLG1CQUFtQnpILEtBQUs7QUFBQSxjQUU3RCxXQUFDLFNBQVMsVUFBVSxTQUFTLEVBQUV5QztBQUFBQSxnQkFBSSxDQUFDcUcsYUFDbkMsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLFVBQVVMLFlBQVksR0FDeERLLHNCQURpQkEsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUE7QUFBQSxVQUNDeEgsT0FBT1YsbUJBQW1CLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJVLGlCQUFPVixtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxhQWY5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsNkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsWUFDL0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLHFDQUFxQ2xFLFVBQVU0TCxNQUFNO0FBQUEsZ0JBQ2hFLGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLE9BQU83SCxVQUFVVSxpQkFBaUIwSDtBQUFBQSxnQkFDbEMsVUFBVSxDQUFDN0ksVUFBVXlILGlCQUFpQixpQkFBaUJ6SCxLQUFLO0FBQUEsZ0JBRTNELFdBQUMsZ0JBQWdCLFlBQVksWUFBWSxTQUFTLFFBQVEsRUFBRXlDO0FBQUFBLGtCQUFJLENBQUNhLFlBQ2hFLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxTQUFVQSxxQkFBMUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNEO0FBQUEsZ0JBQ3ZEO0FBQUE7QUFBQSxjQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFDQzdDLFNBQVNVLGtCQUFrQixjQUMxQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0Msd0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLHFDQUFxQ3pFLFVBQVU0TCxNQUFNO0FBQUEsZ0JBQ2hFLGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLE9BQU83SCxVQUFVUSxxQkFBcUI0SDtBQUFBQSxnQkFDdEMsVUFBVSxDQUFDN0ksVUFBVXlILGlCQUFpQixxQkFBcUJ6SCxLQUFLO0FBQUEsZ0JBRS9EN0MsZ0JBQU1zRjtBQUFBQSxrQkFBSSxDQUFDa0csU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBSzlGLEtBQU04RjtBQUFBQSx5QkFBSzNGO0FBQUFBLG9CQUFVO0FBQUEsb0JBQUkyRixLQUFLMUY7QUFBQUEsdUJBQXBEMEYsS0FBSzlGLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFGO0FBQUEsZ0JBQ3RGO0FBQUE7QUFBQSxjQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFRHBDLFNBQVNVLGtCQUFrQixXQUMxQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MscUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFGO0FBQUEsWUFDckY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLHFDQUFxQ3pFLFVBQVU0TCxNQUFNO0FBQUEsZ0JBQ2hFLGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLE9BQU83SCxTQUFTVyxrQkFBa0J5SDtBQUFBQSxnQkFDbEMsVUFBVSxDQUFDN0ksVUFBVXlILGlCQUFpQixrQkFBa0J6SCxLQUFLO0FBQUEsZ0JBRTVEM0MsaUJBQU9vRjtBQUFBQSxrQkFBSSxDQUFDTixVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNVSxLQUFNVjtBQUFBQSwwQkFBTXFCO0FBQUFBLG9CQUFLO0FBQUEsb0JBQUlyQixNQUFNYztBQUFBQSx1QkFBbkRkLE1BQU1VLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9GO0FBQUEsZ0JBQ3JGO0FBQUE7QUFBQSxjQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFRHBDLFNBQVNVLGtCQUFrQixjQUMxQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0Msd0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLHFDQUFxQ3pFLFVBQVU0TCxNQUFNO0FBQUEsZ0JBQ2hFLGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLE9BQU83SCxVQUFVUyxxQkFBcUIySDtBQUFBQSxnQkFDdEMsVUFBVSxDQUFDN0ksVUFBVXlILGlCQUFpQixxQkFBcUJ6SCxLQUFLO0FBQUEsZ0JBRS9EekMsb0JBQVVrRjtBQUFBQSxrQkFBSSxDQUFDSCxhQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUFpQyxPQUFPQSxTQUFTTyxLQUFNUDtBQUFBQSw2QkFBU2tCO0FBQUFBLG9CQUFLO0FBQUEsb0JBQUlsQixTQUFTVztBQUFBQSx1QkFBL0RYLFNBQVNPLEtBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdHO0FBQUEsZ0JBQ2pHO0FBQUE7QUFBQSxjQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsYUE3REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStEQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUsscUJBQW9CLE9BQU9wQyxTQUFTSSxtQkFBbUIsVUFBVWdGLGNBQWMsV0FBVSwrREFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEs7QUFBQSxlQUY5SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGNBQVcsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSDtBQUFBLFlBQ2xILHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssY0FBYSxPQUFPcEYsU0FBU00sWUFBWSxVQUFVOEUsY0FBYyxXQUFVLCtEQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SjtBQUFBLFlBQzdKdkUsT0FBT1AsY0FBYyx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCTyxpQkFBT1AsY0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxlQUhwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsY0FBUyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdIO0FBQUEsWUFDaEg7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsT0FBT04sVUFBVVksWUFBWTtBQUFBLGdCQUM3QixVQUFVLENBQUNyQixVQUFVeUgsaUJBQWlCLFlBQVl6SCxLQUFLO0FBQUEsZ0JBRXRELFdBQUMsWUFBWSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsV0FBVyxFQUFFeUM7QUFBQUEsa0JBQUksQ0FBQ3NHLGNBQ3RJLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxXQUFZQSx1QkFBOUJBLFdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTREO0FBQUEsZ0JBQzdEO0FBQUE7QUFBQSxjQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGNBQWUsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzSDtBQUFBLFlBQ3RILHVCQUFDLFdBQU0sTUFBSyxVQUFTLE1BQUssa0JBQWlCLE9BQU90SSxTQUFTSyxnQkFBZ0IsVUFBVStFLGNBQWMsV0FBVSw2REFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0s7QUFBQSxZQUNyS3ZFLE9BQU9SLGtCQUFrQix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCUSxpQkFBT1Isa0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsZUFINUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9CQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLFVBQ3BFLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssUUFBTyxPQUFPTCxTQUFTTyxNQUFNLFVBQVU2RSxjQUFjLFdBQVUsK0RBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtKO0FBQUEsWUFDbEosdUJBQUMsU0FBSSxXQUFVLHNHQUFxRyxTQUFTLE1BQU0zQixPQUFPWSxLQUFLLGdCQUFnQixHQUM3SixpQ0FBQyxnQkFBYSxPQUFNLFdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsY0FBVyxXQUFVLDRCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsdUNBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsZUFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxNQUFLLFlBQVcsU0FBUzVFLGlCQUFpQkUsVUFBVSxVQUFVLE1BQU1ELG9CQUFvQixDQUFBMkYsVUFBUyxFQUFFLEdBQUdBLE1BQU0xRixVQUFVLENBQUMwRixLQUFLMUYsU0FBUyxFQUFFLEdBQUcsV0FBVSw2Q0FBM0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb007QUFBQSxhQUx0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYixpQ0FBQyxZQUFPLE1BQUssVUFBUyxXQUFVLCtKQUE4SiwwQkFBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3TSxLQUQxTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQW5LRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0tBO0FBQUEsU0F0S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVLQSxLQXhLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUtBO0FBQUEsSUFHQSx1QkFBQyxTQUFNLFdBQVduQyxpQkFBaUIsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSyxHQUN4RSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakUsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVStKLGNBQWMsWUFBVSxNQUM1RDtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzdFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsT0FBT3pHLGVBQWViO0FBQUFBLGNBRXJCeEQsZ0JBQU1zRjtBQUFBQSxnQkFBSSxDQUFDa0csU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBSzlGLEtBQU04RixlQUFLM0YsYUFBakMyRixLQUFLOUYsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0Q7QUFBQSxjQUNoRTtBQUFBO0FBQUEsWUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUM1RTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBT3JCLGVBQWVaO0FBQUFBLGNBQ3RCLFVBQVUsQ0FBQ29JLFFBQVFuQixzQkFBc0IsbUJBQW1CbUIsR0FBRztBQUFBLGNBRTlELFdBQUMsU0FBUyxVQUFVLFNBQVMsRUFBRXZHO0FBQUFBLGdCQUFJLENBQUNqQyxTQUNuQyx1QkFBQyxPQUFPLFFBQVAsRUFBeUIsT0FBT0EsTUFBT0EsZUFBS3lJLFlBQVksS0FBckN6SSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRDtBQUFBLGNBQzVEO0FBQUE7QUFBQSxZQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUMxRSx1QkFBQyxXQUFNLE1BQUssUUFBTyxNQUFLLHFCQUFvQixPQUFPZ0IsZUFBZVgsbUJBQW1CLFVBQVVpSCxtQkFBbUIsV0FBVSxvQ0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEo7QUFBQSxlQUY5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsWUFDMUUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sTUFBSyxjQUFhLE9BQU90RyxlQUFlVCxZQUFZLFVBQVUrRyxtQkFBbUIsV0FBVSxvQ0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEk7QUFBQSxlQUZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxZQUN4RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPdEcsZUFBZUg7QUFBQUEsZ0JBQ3RCLFVBQVUsQ0FBQzJILFFBQVFuQixzQkFBc0IsWUFBWW1CLEdBQUc7QUFBQSxnQkFFdkQsV0FBQyxZQUFZLGFBQWEsYUFBYSxXQUFXLEVBQUV2RztBQUFBQSxrQkFBSSxDQUFDeUcsUUFDeEQsdUJBQUMsT0FBTyxRQUFQLEVBQXdCLE9BQU9BLEtBQU1BLGlCQUFsQkEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEM7QUFBQSxnQkFDM0M7QUFBQTtBQUFBLGNBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxZQUM5RSx1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLGtCQUFpQixPQUFPMUgsZUFBZVYsZ0JBQWdCLFVBQVVnSCxtQkFBbUIsV0FBVSxrQ0FBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0o7QUFBQSxlQUZ4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0Msb0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sTUFBSyxRQUFPLE9BQU90RyxlQUFlUixNQUFNLFVBQVU4RyxtQkFBbUIsV0FBVSxvQ0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0k7QUFBQSxhQUZwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYixpQ0FBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHlHQUF3Ryw0QkFBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSixLQUR0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNERBO0FBQUEsU0E5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStEQSxLQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFNLFdBQVczSixrQkFBa0IsU0FBUyxNQUFNQyxvQkFBb0IsS0FBSyxHQUMxRSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLHFDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFDekVHLG1CQUNDLG1DQUNFO0FBQUEsK0JBQUMsT0FBRSxXQUFVLFFBQ1g7QUFBQSxpQ0FBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFBUztBQUFBLFVBQUVBLGdCQUFnQndFO0FBQUFBLGFBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLFFBQ1g7QUFBQSxpQ0FBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUFTO0FBQUEsVUFBR3hFLGdCQUFnQnVDO0FBQUFBLGFBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLFFBQ1g7QUFBQSxpQ0FBQyxZQUFPLDRCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsVUFBUztBQUFBLFVBQUV2QyxnQkFBZ0I2RTtBQUFBQSxhQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsMERBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTWhGLG9CQUFvQixLQUFLO0FBQUEsY0FDeEMsV0FBVTtBQUFBLGNBQTZCO0FBQUE7QUFBQSxZQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNpSjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUE2QztBQUFBO0FBQUEsWUFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFdBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxTQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBLEtBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXaEo7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsK0JBQXFCLEtBQUs7QUFDMUJZLDBCQUFnQixJQUFJO0FBQ3BCRSw0QkFBa0IsS0FBSztBQUFBLFFBQ3pCO0FBQUEsUUFDQSxpQkFBaUI7QUFBQSxRQUVqQixpQ0FBQyxTQUFJLFdBQVUsWUFFYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYmQscUNBQXFCLEtBQUs7QUFDMUJZLGdDQUFnQixJQUFJO0FBQ3BCRSxrQ0FBa0IsS0FBSztBQUFBLGNBQ3pCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVixjQUFXO0FBQUEsY0FBTztBQUFBO0FBQUEsWUFScEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw4RkFFYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsaUNBQWdDLHNDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQStCLDJEQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0NILGdCQUNDLHVCQUFDLFNBQ0VBO0FBQUFBLDJCQUFhMEYsbUJBQW1CLGNBQy9CLHVCQUFDLFVBQUssV0FBVSw0RUFBMkUsd0JBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVEMUYsYUFBYTBGLG1CQUFtQixlQUMvQix1QkFBQyxVQUFLLFdBQVUsOEVBQTZFLHlCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFRDFGLGFBQWEwRixtQkFBbUIsZUFDL0IsdUJBQUMsVUFBSyxXQUFVLDBFQUF5RSx5QkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUQxRixhQUFhMEYsbUJBQW1CLFlBQy9CLHVCQUFDLFVBQUssV0FBVSwwRUFBeUUsc0JBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQkE7QUFBQSxlQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9DQTtBQUFBLFVBRUMxRixnQkFDQyx1QkFBQyxTQUFJLFdBQVUsSUFFYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSw0Q0FBMkMsNkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx5QkFBd0Isd0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZDO0FBQUEsa0JBQzdDLHVCQUFDLE9BQUUsV0FBVSwrQkFBK0JBLHVCQUFhNkQsWUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0U7QUFBQSxxQkFGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtEO0FBQUEsa0JBQ2xELHVCQUFDLE9BQUUsV0FBVSwrQkFDVjdELHVCQUFhMEIsVUFBVXFDLGFBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw0QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUQ7QUFBQSxrQkFDakQsdUJBQUMsT0FBRSxXQUFVLCtCQUNWL0QsdUJBQWEyQixtQkFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUseUJBQ1YzQjtBQUFBQSxpQ0FBYTJCLGlCQUNWNkgsWUFBWSxFQUNiOUIsUUFBUSxTQUFTLENBQUN3QyxTQUFTQSxLQUFLRixZQUFZLENBQUM7QUFBQSxvQkFBRztBQUFBLG9CQUFJO0FBQUEsdUJBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSxvQkFBRWhLLGFBQWE2QjtBQUFBQSx1QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUY7QUFBQSxxQkFQbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStDO0FBQUEsa0JBQy9DLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLG9CQUFFN0IsYUFBYW1LO0FBQUFBLHVCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RTtBQUFBLHFCQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUViO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3QixnQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUQ7QUFBQSxrQkFDckQsdUJBQUMsT0FBRSxXQUFVLCtCQUNWbkssdUJBQWE4QixjQUFjLE1BQU07QUFDaEMsMEJBQU1zSSxRQUFRck0sTUFBTWlDLGFBQWE4QixVQUFVO0FBQzNDLDBCQUFNdUksUUFBUXRNLE1BQU07QUFDcEIsd0JBQUl1TSxVQUFVRCxNQUFNRSxLQUFLLElBQUlILE1BQU1HLEtBQUssS0FBSyxNQUFNRixNQUFNRyxNQUFNLElBQUlKLE1BQU1JLE1BQU07QUFDL0VGLDZCQUFTRyxLQUFLQyxJQUFJLEdBQUdKLE1BQU07QUFDM0IsMkJBQU8sR0FBR0EsTUFBTSxNQUFNdEssYUFBYW9DLFlBQVksR0FBRztBQUFBLGtCQUNwRCxHQUFHLElBQUksT0FQVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEscUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLGdCQUNDcEMsY0FBYzJLLGlCQUFpQixhQUM5Qix1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRDtBQUFBLGtCQUNsRCx1QkFBQyxPQUFFLFdBQVUsZ0NBQWdDM0s7QUFBQUEsaUNBQWE0QjtBQUFBQSxvQkFBa0I7QUFBQSx1QkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkU7QUFBQSxxQkFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUVGLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsNEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlEO0FBQUEsa0JBQ2pELHVCQUFDLFVBQUssV0FBVSw2RkFDYjVCLHVCQUFhMkssZ0JBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxrQkFDL0MsdUJBQUMsT0FBRSxXQUFVLCtCQUNWLGNBQUlqRSxLQUFLMUcsYUFBYThCLFVBQVUsRUFBRThJLG1CQUFtQixPQUFPLEtBRC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3Qix3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxrQkFDN0MsdUJBQUMsT0FBRSxXQUFVLCtCQUNWNUs7QUFBQUEsaUNBQWFvQztBQUFBQSxvQkFBUztBQUFBLHVCQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUdFcEMsYUFBYTJLLGlCQUFpQixpQkFDNUIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLG1EQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRztBQUFBLGtCQUNuRztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLE9BQU92SztBQUFBQSxzQkFDUCxVQUFVLENBQUNVLE1BQU1ULG9CQUFvQlMsRUFBRUUsT0FBT0QsS0FBSztBQUFBLHNCQUNuRCxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBO0FBQUEsb0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU15QztBQUFBLHFCQVIzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsbUJBakZOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUZBO0FBQUEsaUJBdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUZBO0FBQUEsWUFLQ2Isa0JBQ0MsdUJBQUMsU0FBSSxXQUFVLDZGQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDRDQUEyQyxpQ0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUViO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxrQkFDL0MsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQztBQUFBO0FBQUEsb0JBQzNDRixhQUFhbUs7QUFBQUEsdUJBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF5Qm5LLHVCQUFhMkssaUJBQWlCLGdCQUFnQix3Q0FBd0MsMkJBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9KO0FBQUEsa0JBQ3BKLHVCQUFDLE9BQUUsV0FBVyxxQkFBcUIzSyxhQUFhMkssaUJBQWlCLGdCQUFnQixpQkFBaUIsZ0JBQWdCLElBQUszSztBQUFBQSxpQ0FBYTJLLGlCQUFpQixnQkFBZ0IzSyxhQUFha0UsdUJBQXVCbEUsYUFBYTRCO0FBQUFBLG9CQUFrQjtBQUFBLHVCQUF4TztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5TztBQUFBLHFCQUYzTztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0Q7QUFBQSxrQkFDcEQsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsb0JBQzdDNUIsYUFBYTZLO0FBQUFBLHVCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLHdDQUNaLFdBQUMzSyxpQkFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNtSTtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFhO0FBQUEsa0JBQUc7QUFBQTtBQUFBO0FBQUEsY0FKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsSUFFQSxtQ0FDRTtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTTtBQUNiaEoseUNBQXFCLEtBQUs7QUFDMUJZLG9DQUFnQixJQUFJO0FBQ3BCRSxzQ0FBa0IsS0FBSztBQUFBLGtCQUN6QjtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFBd0Y7QUFBQTtBQUFBLGdCQU5wRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBU29JO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFBa0o7QUFBQTtBQUFBLGdCQUY5SjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQSxLQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLGVBNUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkpBO0FBQUEsYUFsTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9OQTtBQUFBO0FBQUEsTUE3TkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOE5BO0FBQUEsSUFHQSx1QkFBQyxTQUFNLFdBQVd6SixpQkFBaUIsU0FBUyxNQUFNO0FBQUVDLHlCQUFtQixLQUFLO0FBQUdRLHlCQUFtQixJQUFJO0FBQUEsSUFBRyxHQUN2RyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLHFDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFDekVELG1CQUNDLHVCQUFDLFVBQUssVUFBVSxDQUFDd0IsTUFBTTtBQUFFQSxVQUFFdUcsZUFBZTtBQUFHeUIsMEJBQWtCO0FBQUEsTUFBRyxHQUFHLFdBQVUsYUFDN0U7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsWUFDakQsdUJBQUMsVUFBSyxXQUFVLDBCQUEwQnhKLDBCQUFnQm9DLFNBQVNxQyxhQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLFlBQU87QUFBQSxlQURuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLE1BQUssUUFBTyxhQUFZLGlDQUFnQyxVQUFRLE1BQUMsV0FBVSwrREFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkk7QUFBQSxhQUovSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsd0dBQXVHLHNCQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZJO0FBQUEsV0FQL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxPQTduQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThuQkEsS0EvbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0Fnb0JBO0FBRUo7QUFBRTlGLEdBajFDSUQsT0FBSztBQUFBLFVBeUJRSCxXQUFXO0FBQUE7QUFBQWlOLEtBekJ4QjlNO0FBbTFDTixlQUFlQTtBQUFNLElBQUE4TTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiTW9kYWwiLCJhbnRNb2RhbCIsIm1lc3NhZ2UiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydERpYWxvZyIsIkRyb3Bkb3duIiwiU2VsZWN0IiwiSW9NZE1vcmUiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJGYUNhbGN1bGF0b3IiLCJDaXJjdWxhckxvYWRlciIsImZpZWxkU2l6ZSIsIkZhV2hhdHNhcHAiLCJYIiwiTGluayIsInVzZU5hdmlnYXRlIiwiQnJlYWRjcnVtYiIsImRheWpzIiwiUGlnbWUiLCJfcyIsInVzZXJzIiwic2V0VXNlcnMiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJwaWdtZUN1c3RvbWVycyIsInNldFBpZ21lQ3VzdG9tZXJzIiwidGFibGVCb3Jyb3dlcnMiLCJzZXRUYWJsZUJvcnJvd2VycyIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsInNob3dBcHByb3ZlTW9kYWwiLCJzZXRTaG93QXBwcm92ZU1vZGFsIiwic2hvd1dpdGhkcmF3TW9kYWwiLCJzZXRTaG93V2l0aGRyYXdNb2RhbCIsImN1cnJlbnRDdXN0b21lciIsInNldEN1cnJlbnRDdXN0b21lciIsImN1cnJlbnRVcGRhdGVDdXN0b21lciIsInNldEN1cnJlbnRVcGRhdGVDdXN0b21lciIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ3aXRoZHJhd0RhdGEiLCJzZXRXaXRoZHJhd0RhdGEiLCJzaG93Q2FsY3VsYXRlZCIsInNldFNob3dDYWxjdWxhdGVkIiwiZWRpdGFibGVJbnRlcmVzdCIsInNldEVkaXRhYmxlSW50ZXJlc3QiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJjbG9zZWRQaWdteURhdGEiLCJzZXRDbG9zZWRQaWdteURhdGEiLCJjbG9zZWRMb2FkaW5nIiwic2V0Q2xvc2VkTG9hZGluZyIsIm5hdmlnYXRlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwidGhpcmRQYXJ0eUVuYWJsZSIsInNldFRoaXJkUGFydHlFbmFibGUiLCJ3aGF0c2FwcCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJjdXN0b21lciIsIm1hdHVyaXR5X3BlcmlvZCIsIm1hdHVyaXR5X2ludGVyZXN0IiwicGF5YWJsZV9hbW91bnQiLCJzdGFydF9kYXRlIiwibm90ZSIsInJlZmVycmVkX2N1c3RvbWVyIiwicmVmZXJyZWRfZW1wbG95ZWUiLCJyZWZlcnJlZF90eXBlIiwicmVmZXJyZWRfYWdlbnQiLCJkdXJhdGlvbiIsImVycm9ycyIsInNldEVycm9ycyIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJmZXRjaEN1c3RvbWVycyIsInJlc3BvbnNlIiwiZ2V0Iiwic3RhdHVzIiwiRXJyb3IiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hBZ2VudHMiLCJhZ2VudCIsImVyciIsImZldGNoRW1wbG95ZWVzIiwiZW1wbG95ZWUiLCJmZXRjaENsb3NlZFBpZ215IiwiZm9ybWF0dGVkIiwibWFwIiwiaXRlbSIsImluZGV4IiwiaWQiLCJfaWQiLCJwaWdtZV9pZCIsImN1c3RvbWVyX25hbWUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJwYXltZW50X2RldGFpbHMiLCJwcmVfbWF0dXJlZF9pbnRlcmVzdCIsInJlZmVycmVkX2J5IiwicmVmIiwicmVmVHlwZSIsImVtcCIsIm5hbWUiLCJlbXBsb3llZUNvZGUiLCJjdXN0Iiwic3BsaXQiLCJyZXZlcnNlIiwiam9pbiIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhyZWYiLCJmZXRjaEJvcnJvd2VycyIsInBpZ21lTGlzdCIsImZvcm1hdHRlZERhdGEiLCJwaWdtZUN1c3RvbWVyIiwiZGF0ZSIsImNyZWF0ZWRBdCIsInJlcXVlc3Rfc3RhdHVzIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwib3BlbiIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbnRlbnQiLCJva1RleHQiLCJjYW5jZWxUZXh0Iiwib25PayIsInVwZGF0ZVBpZ215U3RhdHVzIiwib3BlbldpdGhkcmF3TW9kYWwiLCJzb3J0ZWREYXRhIiwic29ydCIsImEiLCJiIiwiRGF0ZSIsImRhdGFXaXRoSWQiLCJoYW5kbGVDaGFuZ2UiLCJwcmV2IiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwiaXNOYU4iLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicGF5bG9hZCIsIk51bWJlciIsIlN0cmluZyIsInJlcGxhY2UiLCJwb3N0IiwicGlnbWVJZCIsIlBpZ21lRGF0YSIsImZvcm1hdHRlZFN0YXJ0RGF0ZSIsIm9wZW5BcHByb3ZlTW9kYWwiLCJwaWdteSIsIm5ld1N0YXR1cyIsInBhdGNoIiwic3VjY2VzcyIsImhhbmRsZUFwcHJvdmUiLCJoYW5kbGVDYWxjdWxhdGUiLCJwdXQiLCJoYW5kbGVXaXRoZHJhdyIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsInByZXZEYXRhIiwicHJldkVycm9ycyIsImhhbmRsZUFudElucHV0RFNlbGVjdCIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlUGlnbWUiLCJkZWxldGUiLCJoYW5kbGVVcGRhdGUiLCJjb2x1bW5zIiwiaGVhZGVyIiwid2lkdGgiLCJjbG9zZWRDb2x1bW5zIiwiaGVpZ2h0IiwiaW5wdXQiLCJvcHRpb24iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidXNlciIsImN1c3RvbWVyX2lkIiwidW5kZWZpbmVkIiwibWF0dXJpdHkiLCJjRHVyYXRpb24iLCJ2YWwiLCJ0b1VwcGVyQ2FzZSIsImR1ciIsImNoYXIiLCJ0b3RhbF9wYWlkIiwic3RhcnQiLCJ0b2RheSIsIm1vbnRocyIsInllYXIiLCJtb250aCIsIk1hdGgiLCJtYXgiLCJjbG9zdXJlX3R5cGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJtYXR1cml0eV9hbW91bnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQaWdtZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBNb2RhbCBhcyBhbnRNb2RhbCwgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IERyb3Bkb3duLCBTZWxlY3QgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IEZhQ2FsY3VsYXRvciB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBYIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5cclxuY29uc3QgUGlnbWUgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUN1c3RvbWVycywgc2V0UGlnbWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZUJvcnJvd2Vycywgc2V0VGFibGVCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93QXBwcm92ZU1vZGFsLCBzZXRTaG93QXBwcm92ZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd1dpdGhkcmF3TW9kYWwsIHNldFNob3dXaXRoZHJhd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEN1c3RvbWVyLCBzZXRDdXJyZW50Q3VzdG9tZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVDdXN0b21lciwgc2V0Q3VycmVudFVwZGF0ZUN1c3RvbWVyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3dpdGhkcmF3RGF0YSwgc2V0V2l0aGRyYXdEYXRhXSA9IHVzZVN0YXRlKG51bGwpOyAvLyBzdG9yZXMgZmV0Y2hlZCBwaWdteSBkZXRhaWxzIGZvciB3aXRoZHJhd2FsXHJcbiAgY29uc3QgW3Nob3dDYWxjdWxhdGVkLCBzZXRTaG93Q2FsY3VsYXRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7IC8vIGZsYWcgdG8gc2hvdyBjYWxjdWxhdGVkIGZpZWxkc1xyXG4gIGNvbnN0IFtlZGl0YWJsZUludGVyZXN0LCBzZXRFZGl0YWJsZUludGVyZXN0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICAvLyAtLS0tIFRhYnMgLS0tLVxyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcInBpZ21lXCIpO1xyXG4gIGNvbnN0IFtjbG9zZWRQaWdteURhdGEsIHNldENsb3NlZFBpZ215RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2Nsb3NlZExvYWRpbmcsIHNldENsb3NlZExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW3RoaXJkUGFydHlFbmFibGUsIHNldFRoaXJkUGFydHlFbmFibGVdID0gdXNlU3RhdGUoe1xyXG4gICAgd2hhdHNhcHA6IHRydWUsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgY3VzdG9tZXI6IFwiXCIsXHJcbiAgICBtYXR1cml0eV9wZXJpb2Q6IFwiXCIsXHJcbiAgICBtYXR1cml0eV9pbnRlcmVzdDogXCI2XCIsXHJcbiAgICBwYXlhYmxlX2Ftb3VudDogXCJcIixcclxuICAgIHN0YXJ0X2RhdGU6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9lbXBsb3llZTogXCJcIixcclxuICAgIHJlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9hZ2VudDogXCJcIixcclxuICAgIGR1cmF0aW9uOiBcIjEyIG1vbnRoc1wiLFxyXG4gICAgLy8gcmVxdWVzdF9zdGF0dXM6IFwiQVBQUk9WRURcIixcclxuICB9KTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGN1c3RvbWVyOiBcIlwiLFxyXG4gICAgbWF0dXJpdHlfcGVyaW9kOiBcIlwiLFxyXG4gICAgbWF0dXJpdHlfaW50ZXJlc3Q6IFwiNlwiLFxyXG4gICAgcGF5YWJsZV9hbW91bnQ6IFwiXCIsXHJcbiAgICBzdGFydF9kYXRlOiBcIlwiLFxyXG4gICAgbm90ZTogXCJcIixcclxuICAgIHJlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgICBkdXJhdGlvbjogXCIxMiBtb250aHNcIixcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKVxyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIEN1c3RvbWVyc1wiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgIEN1c3RvbWVyIERhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQ3VzdG9tZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXRcIik7XHJcbiAgICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlLmRhdGE/LmFnZW50KTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBMZWFkc1wiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKHJlc3BvbnNlPy5kYXRhPy5lbXBsb3llZSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcImZhaWxlZCB0byBmZXRjaCBlbXBsb3llZXNcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEZldGNoIGNsb3NlZCBwaWdteSBkYXRhXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQ2xvc2VkUGlnbXkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0Q2xvc2VkTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vcGlnbWVzL3BpZ21lLWNsb3NlZFwiKTtcclxuICAgICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXTtcclxuICAgICAgICAvLyBGb3JtYXQgc2ltaWxhciB0byB0YWJsZUJvcnJvd2Vyc1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgcGlnbWVfaWQ6IGl0ZW0ucGlnbWVfaWQsXHJcbiAgICAgICAgICBjdXN0b21lcl9uYW1lOiBpdGVtLmN1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogaXRlbS5jdXN0b21lcj8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBtYXR1cml0eV9wZXJpb2Q6IGl0ZW0ubWF0dXJpdHlfcGVyaW9kLFxyXG4gICAgICAgICAgcGF5bWVudF9kZXRhaWxzOiBgJHtpdGVtLm1hdHVyaXR5X3BlcmlvZH0g4oCTIOKCuSR7aXRlbS5wYXlhYmxlX2Ftb3VudH1gLFxyXG4gICAgICAgICAgcGF5YWJsZV9hbW91bnQ6IGl0ZW0ucGF5YWJsZV9hbW91bnQsXHJcbiAgICAgICAgICBtYXR1cml0eV9pbnRlcmVzdDogaXRlbS5tYXR1cml0eV9pbnRlcmVzdCB8fCBpdGVtPy5wcmVfbWF0dXJlZF9pbnRlcmVzdCArIFwiJVwiLFxyXG4gICAgICAgICAgcmVmZXJyZWRfdHlwZTogaXRlbS5yZWZlcnJlZF90eXBlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICByZWZlcnJlZF9ieTogKCgpID0+IHtcclxuICAgICAgICAgICAgbGV0IHJlZiA9IFwiTi9BXCI7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlZlR5cGUgPSBpdGVtLnJlZmVycmVkX3R5cGUgfHwgaXRlbS5jdXN0b21lcj8ucmVmZXJyZWRfdHlwZSB8fCBpdGVtPy5yZWZlcnJlZF9lbXBsb3llZTtcclxuICAgICAgICAgICAgaWYgKHJlZlR5cGUgPT09IFwiRW1wbG95ZWVcIiB8fCBpdGVtPy5yZWZlcnJlZF9lbXBsb3llZSkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGVtcCA9IGl0ZW0ucmVmZXJyZWRfZW1wbG95ZWUgfHwgaXRlbS5jdXN0b21lcj8ucmVmZXJyZWRfZW1wbG95ZWU7XHJcbiAgICAgICAgICAgICAgaWYgKGVtcCkgcmVmID0gYCR7ZW1wLm5hbWV9IHwgJHtlbXAucGhvbmVfbnVtYmVyIHx8IGVtcC5lbXBsb3llZUNvZGUgfHwgXCJcIn1gO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlZlR5cGUgPT09IFwiQWdlbnRcIikge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGFnZW50ID0gaXRlbS5yZWZlcnJlZF9hZ2VudCB8fCBpdGVtLmN1c3RvbWVyPy5yZWZlcnJlZF9hZ2VudDtcclxuICAgICAgICAgICAgICBpZiAoYWdlbnQpIHJlZiA9IGAke2FnZW50Lm5hbWV9IHwgJHthZ2VudC5waG9uZV9udW1iZXIgfHwgXCJcIn1gO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlZlR5cGUgPT09IFwiQ3VzdG9tZXJcIikge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGN1c3QgPSBpdGVtLnJlZmVycmVkX2N1c3RvbWVyIHx8IGl0ZW0uY3VzdG9tZXI/LnJlZmVycmVkX2N1c3RvbWVyO1xyXG4gICAgICAgICAgICAgIGlmIChjdXN0KSByZWYgPSBgJHtjdXN0LmZ1bGxfbmFtZX0gfCAke2N1c3QucGhvbmVfbnVtYmVyIHx8IFwiXCJ9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVmO1xyXG4gICAgICAgICAgfSkoKSxcclxuICAgICAgICAgIHN0YXJ0X2RhdGU6IGl0ZW0uc3RhcnRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdPy5zcGxpdChcIi1cIikucmV2ZXJzZSgpLmpvaW4oXCItXCIpIHx8IFwiXCIsXHJcbiAgICAgICAgICBkdXJhdGlvbjogaXRlbS5kdXJhdGlvbiA/IGAke2l0ZW0uZHVyYXRpb259IE1vbnRoc2AgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgc3RhdHVzOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIENsb3NlZFxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYC9waWdteS1wcmVjbG9zdXJlLXByaW50LyR7aXRlbS5faWR9YClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZCBjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRDbG9zZWRQaWdteURhdGEoZm9ybWF0dGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY2xvc2VkIHBpZ215OlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIGNsb3NlZCBwaWdteSBkYXRhXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0Q2xvc2VkTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaENsb3NlZFBpZ215KCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQm9ycm93ZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvcGlnbWUvZ2V0LWFsbC1waWdtZS1jdXN0b21lcnNcIik7XHJcbiAgICAgICAgY29uc3QgcGlnbWVMaXN0ID0gcmVzcG9uc2UuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHBpZ21lTGlzdC5tYXAoKHBpZ21lQ3VzdG9tZXIpID0+IHtcclxuICAgICAgICAgIGxldCByZWZlcnJlZF9ieSA9IFwiTi9BXCI7XHJcblxyXG4gICAgICAgICAgY29uc3QgcmVmVHlwZSA9XHJcbiAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXI/LnJlZmVycmVkX3R5cGUgfHxcclxuICAgICAgICAgICAgcGlnbWVDdXN0b21lcj8uY3VzdG9tZXI/LnJlZmVycmVkX3R5cGU7XHJcblxyXG4gICAgICAgICAgaWYgKHJlZlR5cGUgPT09IFwiRW1wbG95ZWVcIikge1xyXG4gICAgICAgICAgICBjb25zdCBlbXAgPVxyXG4gICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXI/LnJlZmVycmVkX2VtcGxveWVlIHx8XHJcbiAgICAgICAgICAgICAgcGlnbWVDdXN0b21lcj8uY3VzdG9tZXI/LnJlZmVycmVkX2VtcGxveWVlO1xyXG5cclxuICAgICAgICAgICAgaWYgKGVtcCkge1xyXG4gICAgICAgICAgICAgIHJlZmVycmVkX2J5ID0gYCR7ZW1wLm5hbWV9IHwgJHtlbXAucGhvbmVfbnVtYmVyIHx8IGVtcC5lbXBsb3llZUNvZGUgfHwgXCJcIn1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBlbHNlIGlmIChyZWZUeXBlID09PSBcIkFnZW50XCIpIHtcclxuICAgICAgICAgICAgY29uc3QgYWdlbnQgPVxyXG4gICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXI/LnJlZmVycmVkX2FnZW50IHx8XHJcbiAgICAgICAgICAgICAgcGlnbWVDdXN0b21lcj8uY3VzdG9tZXI/LnJlZmVycmVkX2FnZW50O1xyXG5cclxuICAgICAgICAgICAgaWYgKGFnZW50KSB7XHJcbiAgICAgICAgICAgICAgcmVmZXJyZWRfYnkgPSBgJHthZ2VudC5uYW1lfSB8ICR7YWdlbnQucGhvbmVfbnVtYmVyIHx8IFwiXCJ9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgZWxzZSBpZiAocmVmVHlwZSA9PT0gXCJDdXN0b21lclwiKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGN1c3QgPVxyXG4gICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXI/LnJlZmVycmVkX2N1c3RvbWVyIHx8XHJcbiAgICAgICAgICAgICAgcGlnbWVDdXN0b21lcj8uY3VzdG9tZXI/LnJlZmVycmVkX2N1c3RvbWVyO1xyXG5cclxuICAgICAgICAgICAgaWYgKGN1c3QpIHtcclxuICAgICAgICAgICAgICByZWZlcnJlZF9ieSA9IGAke2N1c3QuZnVsbF9uYW1lfSB8ICR7Y3VzdC5waG9uZV9udW1iZXIgfHwgXCJcIn1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAvLyBlbHNlIHJlbWFpbnMgXCJOL0FcIlxyXG5cclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIF9pZDogcGlnbWVDdXN0b21lcj8uX2lkLFxyXG4gICAgICAgICAgICBwaWdtZV9pZDogcGlnbWVDdXN0b21lcj8ucGlnbWVfaWQsXHJcbiAgICAgICAgICAgIGN1c3RvbWVyX25hbWU6IHBpZ21lQ3VzdG9tZXI/LmN1c3RvbWVyPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogcGlnbWVDdXN0b21lcj8uY3VzdG9tZXI/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgZGF0ZTogcGlnbWVDdXN0b21lcj8uY3JlYXRlZEF0LFxyXG4gICAgICAgICAgICBtYXR1cml0eV9wZXJpb2Q6IHBpZ21lQ3VzdG9tZXI/Lm1hdHVyaXR5X3BlcmlvZCxcclxuICAgICAgICAgICAgbWF0dXJpdHlfaW50ZXJlc3Q6IHBpZ21lQ3VzdG9tZXI/Lm1hdHVyaXR5X2ludGVyZXN0ICsgXCIlXCIsXHJcbiAgICAgICAgICAgIHBheW1lbnRfZGV0YWlsczogYCR7cGlnbWVDdXN0b21lcj8ubWF0dXJpdHlfcGVyaW9kfSDigJMg4oK5JHtwaWdtZUN1c3RvbWVyPy5wYXlhYmxlX2Ftb3VudH1gLFxyXG4gICAgICAgICAgICBwYXlhYmxlX2Ftb3VudDogcGlnbWVDdXN0b21lcj8ucGF5YWJsZV9hbW91bnQsXHJcbiAgICAgICAgICAgIHN0YXJ0X2RhdGU6IHBpZ21lQ3VzdG9tZXI/LnN0YXJ0X2RhdGVcclxuICAgICAgICAgICAgICA/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgICAucmV2ZXJzZSgpXHJcbiAgICAgICAgICAgICAgLmpvaW4oXCItXCIpLFxyXG4gICAgICAgICAgICBkdXJhdGlvbjogcGlnbWVDdXN0b21lcj8uZHVyYXRpb25cclxuICAgICAgICAgICAgICA/IGAke3BpZ21lQ3VzdG9tZXIuZHVyYXRpb259IE1vbnRoc2BcclxuICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIG5vdGU6IHBpZ21lQ3VzdG9tZXI/Lm5vdGUsXHJcbiAgICAgICAgICAgIHJlZmVycmVkX3R5cGU6XHJcbiAgICAgICAgICAgICAgcGlnbWVDdXN0b21lcj8ucmVmZXJyZWRfdHlwZSB8fFxyXG4gICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXI/LmN1c3RvbWVyPy5yZWZlcnJlZF90eXBlIHx8XHJcbiAgICAgICAgICAgICAgXCJOL0FcIixcclxuICAgICAgICAgICAgcmVmZXJyZWRfYnksICAgIC8vIG5vdyBjb3JyZWN0bHkgc2V0XHJcbiAgICAgICAgICAgIHJlcXVlc3Rfc3RhdHVzOiBwaWdtZUN1c3RvbWVyPy5yZXF1ZXN0X3N0YXR1cyB8fCBcIlJFUVVFU1RFRFwiLFxyXG4gICAgICAgICAgICAvLyBzdGF0dXMgYmFkZ2UgXHJcbiAgICAgICAgICAgIHN0YXR1czogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAge3BpZ21lQ3VzdG9tZXI/LnJlcXVlc3Rfc3RhdHVzID09PSBcIlJFUVVFU1RFRFwiID8gKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlcXVlc3RlZFxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApIDogcGlnbWVDdXN0b21lcj8ucmVxdWVzdF9zdGF0dXMgPT09IFwiQVBQUk9WRURcIiA/IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLWZ1bGwgYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQXBwcm92ZWRcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKSA6IHBpZ21lQ3VzdG9tZXI/LnJlcXVlc3Rfc3RhdHVzID09PSBcIkNMT1NFRFwiID8gKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2xvc2VkXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIFwiXCJcclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiIGtleT17cGlnbWVDdXN0b21lci5faWR9PlxyXG4gICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihwaWdtZUN1c3RvbWVyLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKHBpZ21lQ3VzdG9tZXIuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBQcmludCBQcmVjbG9zdXJlIEZvcm1cclxuICAgICAgICAgICAgICAgICAgICAgIC4uLihwaWdtZUN1c3RvbWVyPy5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJSRVFVRVNURURcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwicHJpbnQtcHJlY2xvc3VyZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cub3BlbihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC9waWdteS1wcmVjbG9zdXJlLXByaW50LyR7cGlnbWVDdXN0b21lci5faWR9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsb3N1cmUgRm9ybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFtdKSxcclxuICAgICAgICAgICAgICAgICAgICAgIC8vIOKchSBSZXF1ZXN0IHRvIFdpdGhkcmF3IFxyXG4gICAgICAgICAgICAgICAgICAgICAgLi4uKHBpZ21lQ3VzdG9tZXI/LnJlcXVlc3Rfc3RhdHVzICE9PSBcIlJFUVVFU1RFRFwiICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXI/LnJlcXVlc3Rfc3RhdHVzICE9PSBcIkNMT1NFRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW50TW9kYWwuY29uZmlybSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBgUmVxdWVzdCB3aXRoZHJhd2FsIGZvciAke3BpZ21lQ3VzdG9tZXI/LmN1c3RvbWVyPy5mdWxsX25hbWV9P2AsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUaGlzIHdpbGwgc2V0IHRoZSBwaWdteSBzdGF0dXMgdG8gUkVRVUVTVEVEIGFuZCBhbGxvdyBwcm9jZXNzaW5nIG9mIHdpdGhkcmF3YWwuXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dDogXCJZZXMsIHJlcXVlc3Qgd2l0aGRyYXdhbFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxUZXh0OiBcIkNhbmNlbFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbk9rOiAoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVBpZ215U3RhdHVzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBfaWQ6IHBpZ21lQ3VzdG9tZXIuX2lkIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlJFUVVFU1RFRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXF1ZXN0IHRvIFdpdGhkcmF3IFBpZ215XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogW10pLFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gV2l0aGRyYXcgb3B0aW9uIChvbmx5IGZvciBSRVFVRVNURUQsIGlmIHN0aWxsIG5lZWRlZClcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLihwaWdtZUN1c3RvbWVyPy5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJSRVFVRVNURURcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiNFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlbldpdGhkcmF3TW9kYWwocGlnbWVDdXN0b21lcil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBXaXRoZHJhd1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFtdKSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2ID5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIC0tLS0tLS0tIFNvcnRpbmc6IFJFUVVFU1RFRCBmaXJzdCwgdGhlbiBieSBkYXRlIGRlc2NlbmRpbmcgLS0tLS0tLS1cclxuICAgICAgICBjb25zdCBzb3J0ZWREYXRhID0gZm9ybWF0dGVkRGF0YS5zb3J0KChhLCBiKSA9PiB7XHJcbiAgICAgICAgICBpZiAoYS5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJSRVFVRVNURURcIiAmJiBiLnJlcXVlc3Rfc3RhdHVzICE9PSBcIlJFUVVFU1RFRFwiKSByZXR1cm4gLTE7XHJcbiAgICAgICAgICBpZiAoYi5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJSRVFVRVNURURcIiAmJiBhLnJlcXVlc3Rfc3RhdHVzICE9PSBcIlJFUVVFU1RFRFwiKSByZXR1cm4gMTtcclxuICAgICAgICAgIHJldHVybiBuZXcgRGF0ZShiLmRhdGUpIC0gbmV3IERhdGUoYS5kYXRlKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gUmVhc3NpZ24gc2VyaWFsIG51bWJlcnMgYWZ0ZXIgc29ydGluZ1xyXG4gICAgICAgIGNvbnN0IGRhdGFXaXRoSWQgPSBzb3J0ZWREYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAuLi5pdGVtLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHNldFRhYmxlQm9ycm93ZXJzKGRhdGFXaXRoSWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwaWdteSBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHBpZ215IGN1c3RvbWVyc1wiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hCb3Jyb3dlcnMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkQ3VzdG9tZXJcIiA/IGZvcm1EYXRhIDogdXBkYXRlRm9ybURhdGE7XHJcblxyXG4gICAgaWYgKCFkYXRhLmN1c3RvbWVyKSBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIkN1c3RvbWVyIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5tYXR1cml0eV9wZXJpb2QpIG5ld0Vycm9ycy5tYXR1cml0eV9wZXJpb2QgPSBcIk1hdHVyaXR5IFBlcmlvZCBpcyBSZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFkYXRhLnBheWFibGVfYW1vdW50KSBuZXdFcnJvcnMucGF5YWJsZV9hbW91bnQgPSBcIlBheWFibGUgQW1vdW50IGlzIHJlcXVpcmVkXCI7XHJcbiAgICBlbHNlIGlmIChpc05hTihkYXRhLnBheWFibGVfYW1vdW50KSB8fCBkYXRhLnBheWFibGVfYW1vdW50IDw9IDApXHJcbiAgICAgIG5ld0Vycm9ycy5wYXlhYmxlX2Ftb3VudCA9IFwiUGF5YWJsZSBBbW91bnQgbXVzdCBiZSBhIHBvc2l0aXZlIG51bWJlclwiO1xyXG4gICAgaWYgKCFkYXRhLnN0YXJ0X2RhdGUpIG5ld0Vycm9ycy5zdGFydF9kYXRlID0gXCJTdGFydCBEYXRlIGlzIHJlcXVpcmVkXCI7XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRDdXN0b21lclwiKTtcclxuICAgIGlmICghaXNWYWxpZCkgcmV0dXJuO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAuLi50aGlyZFBhcnR5RW5hYmxlLFxyXG4gICAgICAgIGR1cmF0aW9uOiBOdW1iZXIoU3RyaW5nKGZvcm1EYXRhLmR1cmF0aW9uKS5yZXBsYWNlKC9cXEQvZywgJycpKSxcclxuICAgICAgICAvLyByZXF1ZXN0X3N0YXR1czogXCJBUFBST1ZFRFwiLFxyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL3BpZ21lL2FkZC1uZXctcGlnbWUtY3VzdG9tZXJcIiwgcGF5bG9hZCk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB0aHJvdyBuZXcgRXJyb3IoXCJmYWlsZWQgdG8gYWRkIEN1c3RvbWVyXCIpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiQ3VzdG9tZXIgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgICAgbWF0dXJpdHlfcGVyaW9kOiBcIlwiLFxyXG4gICAgICAgIG1hdHVyaXR5X2ludGVyZXN0OiBcIjZcIixcclxuICAgICAgICBwYXlhYmxlX2Ftb3VudDogXCJcIixcclxuICAgICAgICBzdGFydF9kYXRlOiBcIlwiLFxyXG4gICAgICAgIG5vdGU6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfdHlwZTogXCJcIixcclxuICAgICAgICByZWZlcnJlZF9hZ2VudDogXCJcIixcclxuICAgICAgICBkdXJhdGlvbjogXCIxMiBtb250aHNcIixcclxuICAgICAgICAvLyByZXF1ZXN0X3N0YXR1czogXCJBUFBST1ZFRFwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhZGRpbmcgQ3VzdG9tZXI6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gYWRkIHBpZ215XCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAocGlnbWVJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGBwaWdtZS9nZXQtcGlnbWUvJHtwaWdtZUlkfWApO1xyXG4gICAgICBzZXRDdXJyZW50Q3VzdG9tZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBQaWdtZTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChwaWdtZUlkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYHBpZ21lL2dldC1waWdtZS8ke3BpZ21lSWR9YCk7XHJcbiAgICAgIGNvbnN0IFBpZ21lRGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZFN0YXJ0RGF0ZSA9IFBpZ21lRGF0YT8uc3RhcnRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlQ3VzdG9tZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBjdXN0b21lcjogcmVzcG9uc2U/LmRhdGE/LmN1c3RvbWVyLl9pZCxcclxuICAgICAgICBtYXR1cml0eV9wZXJpb2Q6IHJlc3BvbnNlPy5kYXRhPy5tYXR1cml0eV9wZXJpb2QsXHJcbiAgICAgICAgbWF0dXJpdHlfaW50ZXJlc3Q6IHJlc3BvbnNlPy5kYXRhPy5tYXR1cml0eV9pbnRlcmVzdCxcclxuICAgICAgICBwYXlhYmxlX2Ftb3VudDogcmVzcG9uc2U/LmRhdGE/LnBheWFibGVfYW1vdW50LFxyXG4gICAgICAgIHN0YXJ0X2RhdGU6IGZvcm1hdHRlZFN0YXJ0RGF0ZSxcclxuICAgICAgICBub3RlOiByZXNwb25zZT8uZGF0YT8ubm90ZSxcclxuICAgICAgICByZWZlcnJlZF9lbXBsb3llZTogcmVzcG9uc2U/LmRhdGE/LnJlZmVycmVkX2VtcGxveWVlPy5faWQgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF9jdXN0b21lcjogcmVzcG9uc2U/LmRhdGE/LnJlZmVycmVkX2N1c3RvbWVyPy5faWQgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF9hZ2VudDogcmVzcG9uc2U/LmRhdGE/LnJlZmVycmVkX2FnZW50Py5faWQgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF90eXBlOiByZXNwb25zZT8uZGF0YT8ucmVmZXJyZWRfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiByZXNwb25zZT8uZGF0YT8uZHVyYXRpb24gfHwgXCJcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwaWdtZSBDdXN0b21lciBieSBJRDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEFwcHJvdmUgbG9naWNcclxuICBjb25zdCBvcGVuQXBwcm92ZU1vZGFsID0gKGN1c3RvbWVyKSA9PiB7XHJcbiAgICBzZXRDdXJyZW50Q3VzdG9tZXIoY3VzdG9tZXIpO1xyXG4gICAgc2V0U2hvd0FwcHJvdmVNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB1cGRhdGVQaWdteVN0YXR1cyA9IGFzeW5jIChwaWdteSwgbmV3U3RhdHVzKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucGF0Y2goYC92MS9hZG1pbi9waWdtZXMvc3RhdHVzLyR7cGlnbXkuX2lkfWAsIHtcclxuICAgICAgICByZXF1ZXN0X3N0YXR1czogbmV3U3RhdHVzLFxyXG4gICAgICB9KTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKGBQaWdteSBzdGF0dXMgdXBkYXRlZCB0byAke25ld1N0YXR1c30gc3VjY2Vzc2Z1bGx5YCk7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBwaWdteSBzdGF0dXM6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcGlnbXkgc3RhdHVzXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVBcHByb3ZlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFjdXJyZW50Q3VzdG9tZXIpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wYXRjaChgL3YxL2FkbWluL3BpZ21lcy9zdGF0dXMvJHtjdXJyZW50Q3VzdG9tZXIuX2lkfWAsIHtcclxuICAgICAgICByZXF1ZXN0X3N0YXR1czogXCJBUFBST1ZFRFwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlBpZ215IHJlcXVlc3QgYXBwcm92ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93QXBwcm92ZU1vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0Q3VycmVudEN1c3RvbWVyKG51bGwpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFwcHJvdmluZyBwaWdteTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBhcHByb3ZlXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBXaXRoZHJhdyBsb2dpY1xyXG4gIGNvbnN0IG9wZW5XaXRoZHJhd01vZGFsID0gYXN5bmMgKGN1c3RvbWVyKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9waWdtZXMvJHtjdXN0b21lci5faWR9YCk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhLnN1Y2Nlc3MpIHtcclxuICAgICAgICBzZXRXaXRoZHJhd0RhdGEocmVzcG9uc2UuZGF0YS5kYXRhKTtcclxuICAgICAgICBzZXRFZGl0YWJsZUludGVyZXN0KHJlc3BvbnNlLmRhdGEuZGF0YS5wcmVfbWF0dXJlZF9pbnRlcmVzdCB8fCBcIjBcIik7XHJcbiAgICAgICAgc2V0U2hvd0NhbGN1bGF0ZWQoZmFsc2UpO1xyXG4gICAgICAgIHNldFNob3dXaXRoZHJhd01vZGFsKHRydWUpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBwaWdteSBkYXRhXCIpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGlnbXkgZm9yIHdpdGhkcmF3OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiQ291bGQgbm90IGxvYWQgcGlnbXkgZGV0YWlsc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2FsY3VsYXRlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCF3aXRoZHJhd0RhdGEpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChgL3YxL2FkbWluL3BpZ21lcy9waWdtZS1jbG9zZXIvJHt3aXRoZHJhd0RhdGEuX2lkfWAsIHtcclxuICAgICAgICBwcmVfbWF0dXJlZF9pbnRlcmVzdDogZWRpdGFibGVJbnRlcmVzdCxcclxuICAgICAgfSk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhLnN0YXR1cykge1xyXG4gICAgICAgIC8vIE1lcmdlIHVwZGF0ZWQgZGF0YSBmcm9tIHJlc3BvbnNlXHJcbiAgICAgICAgc2V0V2l0aGRyYXdEYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgLi4ucmVzcG9uc2UuZGF0YS5kYXRhIH0pKTtcclxuICAgICAgICBzZXRTaG93Q2FsY3VsYXRlZCh0cnVlKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYWxjdWxhdGlvbiBmYWlsZWRcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjYWxjdWxhdGluZyB3aXRoZHJhd2FsOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGNhbGN1bGF0ZVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlV2l0aGRyYXcgPSAoKSA9PiB7XHJcbiAgICBzZXRTaG93V2l0aGRyYXdNb2RhbChmYWxzZSk7XHJcbiAgICBzZXRXaXRoZHJhd0RhdGEobnVsbCk7XHJcbiAgICBzZXRTaG93Q2FsY3VsYXRlZChmYWxzZSk7XHJcbiAgICBzZXRSZWxvYWRUcmlnZ2VyKHByZXYgPT4gcHJldiArIDEpOyAvLyByZWZyZXNoIHRhYmxlXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHsgLi4ucHJldkRhdGEsIFtmaWVsZF06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHsgLi4ucHJldkVycm9ycywgW2ZpZWxkXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgcmVmZXJyZWRfZW1wbG95ZWU6IFwiXCIsXHJcbiAgICAgIHJlZmVycmVkX2FnZW50OiBcIlwiLFxyXG4gICAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoeyAuLi5lcnJvcnMsIFtmaWVsZF06IFwiXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBbbmFtZV06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVQaWdtZSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50Q3VzdG9tZXIpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvcGlnbWUvZGVsZXRlLXBpZ21lLWN1c3RvbWVyLyR7Y3VycmVudEN1c3RvbWVyLl9pZH1gKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJQaWdteSBVc2VyIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50Q3VzdG9tZXIobnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIHBpZ215IFVzZXI6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBkZWxldGVcIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgaWYgKCFpc1ZhbGlkKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucGF0Y2goXHJcbiAgICAgICAgYC9waWdtZS91cGRhdGUtcGlnbWUtY3VzdG9tZXIvJHtjdXJyZW50VXBkYXRlQ3VzdG9tZXIuX2lkfWAsXHJcbiAgICAgICAgdXBkYXRlRm9ybURhdGFcclxuICAgICAgKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgbWVzc2FnZTogXCJCb3Jyb3dlciB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIEJvcnJvd2VyOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlVwZGF0ZSBmYWlsZWRcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwicGlnbWVfaWRcIiwgaGVhZGVyOiBcIlBpZ21lIElEXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwibWF0dXJpdHlfcGVyaW9kXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwicGF5YWJsZV9hbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X2RldGFpbHNcIiwgaGVhZGVyOiBcIlBheW1lbnQgRGV0YWlsc1wiIH0sXHJcbiAgICB7IGtleTogXCJtYXR1cml0eV9pbnRlcmVzdFwiLCBoZWFkZXI6IFwiTWF0dXJpdHkgSW50ZXJlc3RcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF9ieVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhcnRfZGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiLCB3aWR0aDogMTIwIH0sXHJcbiAgICB7IGtleTogXCJkdXJhdGlvblwiLCBoZWFkZXI6IFwiRHVyYXRpb25cIiwgd2lkdGg6IDEyMCB9LFxyXG4gICAgLy8geyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sIC8vIG5ldyBzdGF0dXMgY29sdW1uXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgLy8gQ29sdW1ucyBmb3IgY2xvc2VkIHBpZ215IChzYW1lIHdpdGhvdXQgYWN0aW9uIGNvbHVtbiDigJMgd2UnbGwgdXNlIGN1c3RvbSlcclxuICBjb25zdCBjbG9zZWRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwaWdtZV9pZFwiLCBoZWFkZXI6IFwiUGlnbWUgSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJtYXR1cml0eV9wZXJpb2RcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X2RldGFpbHNcIiwgaGVhZGVyOiBcIlBheW1lbnQgRGV0YWlsc1wiIH0sXHJcbiAgICB7IGtleTogXCJtYXR1cml0eV9pbnRlcmVzdFwiLCBoZWFkZXI6IFwiTWF0dXJpdHkgSW50ZXJlc3QgLyBQcmVDbG9zdXJlIENoYXJnZXNcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwicmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF9ieVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhcnRfZGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiLCB3aWR0aDogMTIwIH0sXHJcbiAgICB7IGtleTogXCJkdXJhdGlvblwiLCBoZWFkZXI6IFwiRHVyYXRpb25cIiwgd2lkdGg6IDEyMCB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LCAvLyB0aGlzIHdpbGwgY29udGFpbiBwcmludCBidXR0b25cclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgcC03IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+UGlnbXk8L2gxPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz1cIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvcGlnbXktcGF5b3V0XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIGJvcmRlciBib3JkZXItYmx1ZS01MDAgdGV4dC1ibHVlLTYwMCByb3VuZGVkLWxnIFxyXG4gICAgICAgICAgICAgICAgIGhvdmVyOmJnLWJsdWUtNTAgaG92ZXI6dGV4dC1ibHVlLTcwMCBob3Zlcjpib3JkZXItYmx1ZS02MDAgXHJcbiAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZvbnQtbWVkaXVtIHdoaXRlc3BhY2Utbm93cmFwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBpZ215IFBheW1lbnQgT3V0XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9waWdteS1wYXlvdXQtcmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMyBweS0xLjUgdGV4dC1zbSBib3JkZXIgYm9yZGVyLWdyZWVuLTUwMCB0ZXh0LWdyZWVuLTYwMCByb3VuZGVkLWxnXHJcbiAgICAgIGhvdmVyOmJnLWdyZWVuLTUwIGhvdmVyOnRleHQtZ3JlZW4tNzAwIGhvdmVyOmJvcmRlci1ncmVlbi02MDBcclxuICAgICAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgT3V0IFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwicGlnbWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctYmx1ZS04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgd2hpdGVzcGFjZS1ub3dyYXBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICsgQWRkIFBpZ215XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFRhYnMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0yMDAgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCItbWItcHggZmxleCBzcGFjZS14LThcIiBhcmlhLWxhYmVsPVwiVGFic1wiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwicGlnbWVcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHthY3RpdmVUYWIgPT09IFwicGlnbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1ibHVlLTUwMCB0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGhvdmVyOmJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9IHdoaXRlc3BhY2Utbm93cmFwIHB5LTIgcHgtMSBib3JkZXItYi0yIGZvbnQtbWVkaXVtIHRleHQtc21gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGlnbWVcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJjbG9zZWRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHthY3RpdmVUYWIgPT09IFwiY2xvc2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItYmx1ZS01MDAgdGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfSB3aGl0ZXNwYWNlLW5vd3JhcCBweS0yIHB4LTEgYm9yZGVyLWItMiBmb250LW1lZGl1bSB0ZXh0LXNtYH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIENsb3NlZCBQaWdteVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwicGlnbWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIHt0YWJsZUJvcnJvd2Vycz8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbih0YWJsZUJvcnJvd2Vycywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQaWdteVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFBpZ215LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBkYXRhPVwiUGlnbXkgRGF0YVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmFpbHVyZT17dGFibGVCb3Jyb3dlcnM/Lmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiY2xvc2VkXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICB7Y2xvc2VkUGlnbXlEYXRhPy5sZW5ndGggPiAwICYmICFjbG9zZWRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGNsb3NlZFBpZ215RGF0YSwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y2xvc2VkQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDbG9zZWRQaWdteVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YENsb3NlZFBpZ215LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2Nsb3NlZExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT1cIkNsb3NlZCBQaWdteSBEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXtjbG9zZWRQaWdteURhdGE/Lmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQWRkIFBpZ215IE1vZGFsICh1bmNoYW5nZWQpICovfVxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+QWRkIFBpZ215PC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgU2VsZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IGN1c3RvbWVyIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBjdXN0b21lciBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmN1c3RvbWVyIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJjdXN0b21lclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5sYWJlbD8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3VzZXJzLm1hcCgodXNlcikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdXNlci5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGAke3VzZXIuY3VzdG9tZXJfaWR9IHwgJHt1c2VyLmZ1bGxfbmFtZX0gfCAke3VzZXIucGhvbmVfbnVtYmVyfWAsXHJcbiAgICAgICAgICAgICAgICAgIH0pKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lciAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5jdXN0b21lcn08L3A+fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUGF5bWVudCBUeXBlICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5TZWxlY3QgUGF5bWVudCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUGF5bWVudCBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/Lm1hdHVyaXR5X3BlcmlvZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJtYXR1cml0eV9wZXJpb2RcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1wiRGFpbHlcIiwgXCJXZWVrbHlcIiwgXCJNb250aGx5XCJdLm1hcCgobWF0dXJpdHkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e21hdHVyaXR5fSB2YWx1ZT17bWF0dXJpdHk/LnRvTG93ZXJDYXNlKCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge21hdHVyaXR5fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMubWF0dXJpdHlfcGVyaW9kICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj57ZXJyb3JzLm1hdHVyaXR5X3BlcmlvZH08L3A+fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUmVmZXJyZWQgVHlwZSBhbmQgZHluYW1pYyBmaWVsZHMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+UmVmZXJyZWQgVHlwZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyZWQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ucmVmZXJyZWRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcInJlZmVycmVkX3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcIlNlbGYgSm9pbmluZ1wiLCBcIkN1c3RvbWVyXCIsIFwiRW1wbG95ZWVcIiwgXCJBZ2VudFwiLCBcIk90aGVyc1wiXS5tYXAoKHJlZlR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmVHlwZX0gdmFsdWU9e3JlZlR5cGV9PntyZWZUeXBlfTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyZWQgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfY3VzdG9tZXJcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT57dXNlci5mdWxsX25hbWV9IHwge3VzZXIucGhvbmVfbnVtYmVyfTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJBZ2VudFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5TZWxlY3QgUmVmZXJyZWQgQWdlbnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHJvdW5kZWQtbGcgdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIEFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5yZWZlcnJlZF9hZ2VudCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfYWdlbnRcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Ll9pZH0+e2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiRW1wbG95ZWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+U2VsZWN0IFJlZmVycmVkIEVtcGxveWVlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWZlcnJlZCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlZmVycmVkX2VtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJlZF9lbXBsb3llZVwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wbG95ZWUuX2lkfSB2YWx1ZT17ZW1wbG95ZWUuX2lkfT57ZW1wbG95ZWUubmFtZX0gfCB7ZW1wbG95ZWUucGhvbmVfbnVtYmVyfTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkludGVyZXN0ICU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwibWF0dXJpdHlfaW50ZXJlc3RcIiB2YWx1ZT17Zm9ybURhdGEubWF0dXJpdHlfaW50ZXJlc3R9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB3LWZ1bGwgcC0yLjUgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+U3RhcnQgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZGF0ZVwiIG5hbWU9XCJzdGFydF9kYXRlXCIgdmFsdWU9e2Zvcm1EYXRhLnN0YXJ0X2RhdGV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB3LWZ1bGwgcC0yLjUgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc3RhcnRfZGF0ZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5zdGFydF9kYXRlfTwvcD59XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+RHVyYXRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IER1cmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5kdXJhdGlvbiB8fCBcIjYgbW9udGhzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcImR1cmF0aW9uXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCI2IG1vbnRoc1wiLCBcIjEyIG1vbnRoc1wiLCBcIjE4IG1vbnRoc1wiLCBcIjI0IG1vbnRoc1wiLCBcIjMwIG1vbnRoc1wiLCBcIjM2IG1vbnRoc1wiLCBcIjQyIG1vbnRoc1wiLCBcIjQ4IG1vbnRoc1wiLCBcIjU0IG1vbnRoc1wiLCBcIjYwIG1vbnRoc1wiXS5tYXAoKGNEdXJhdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjRHVyYXRpb259IHZhbHVlPXtjRHVyYXRpb259PntjRHVyYXRpb259PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5QYXlhYmxlIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbmFtZT1cInBheWFibGVfYW1vdW50XCIgdmFsdWU9e2Zvcm1EYXRhLnBheWFibGVfYW1vdW50fSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdy1mdWxsIHAtNCByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXlhYmxlX2Ftb3VudCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5wYXlhYmxlX2Ftb3VudH08L3A+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5Ob3RlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cIm5vdGVcIiB2YWx1ZT17Zm9ybURhdGEubm90ZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHctZnVsbCBwLTIuNSByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCB3LTEwIGgtMTAgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcm91bmRlZC1tZCBjdXJzb3ItcG9pbnRlclwiIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5vcGVuKFwiQ2FsY3VsYXRvcjovLy9cIil9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYUNhbGN1bGF0b3IgY29sb3I9XCJ3aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMFwiPkVuYWJsZSBXaGF0c0FwcCBTZW5kaW5nPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17dGhpcmRQYXJ0eUVuYWJsZS53aGF0c2FwcH0gb25DaGFuZ2U9eygpID0+IHNldFRoaXJkUGFydHlFbmFibGUocHJldiA9PiAoeyAuLi5wcmV2LCB3aGF0c2FwcDogIXByZXYud2hhdHNhcHAgfSkpfSBjbGFzc05hbWU9XCJ3LTUgaC01IGFjY2VudC1ncmVlbi02MDAgY3Vyc29yLXBvaW50ZXJcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyIGJvcmRlci0yIGJvcmRlci1ibGFja1wiPlNhdmUgUGlnbXk8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qIFVwZGF0ZSBNb2RhbCAoc2ltcGxpZmllZCwgdW5jaGFuZ2VkKSAqL31cclxuICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9IG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlVwZGF0ZSBQaWdteTwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkN1c3RvbWVyIE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9Pnt1c2VyLmZ1bGxfbmFtZX08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlBheW1lbnQgVHlwZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5tYXR1cml0eV9wZXJpb2R9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJtYXR1cml0eV9wZXJpb2RcIiwgdmFsKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge1tcImRhaWx5XCIsIFwid2Vla2x5XCIsIFwibW9udGhseVwiXS5tYXAoKHR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3R5cGV9IHZhbHVlPXt0eXBlfT57dHlwZS50b1VwcGVyQ2FzZSgpfTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5JbnRlcmVzdCAlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cIm1hdHVyaXR5X2ludGVyZXN0XCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm1hdHVyaXR5X2ludGVyZXN0fSBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9IGNsYXNzTmFtZT1cInctZnVsbCBwLTIuNSBib3JkZXIgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+U3RhcnQgRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZGF0ZVwiIG5hbWU9XCJzdGFydF9kYXRlXCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnN0YXJ0X2RhdGV9IG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX0gY2xhc3NOYW1lPVwidy1mdWxsIHAtMi41IGJvcmRlciByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPkR1cmF0aW9uPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmR1cmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJkdXJhdGlvblwiLCB2YWwpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcIjYgbW9udGhzXCIsIFwiMTIgbW9udGhzXCIsIFwiMTggbW9udGhzXCIsIFwiMjQgbW9udGhzXCJdLm1hcCgoZHVyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2R1cn0gdmFsdWU9e2R1cn0+e2R1cn08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlBheWFibGUgQW1vdW50PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBuYW1lPVwicGF5YWJsZV9hbW91bnRcIiB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGF5YWJsZV9hbW91bnR9IG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX0gY2xhc3NOYW1lPVwidy1mdWxsIHAtNCBib3JkZXIgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+Tm90ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwibm90ZVwiIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ub3RlfSBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9IGNsYXNzTmFtZT1cInctZnVsbCBwLTIuNSBib3JkZXIgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIj5VcGRhdGUgUGlnbXk8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qIEFwcHJvdmUgQ29uZmlybWF0aW9uIE1vZGFsICovfVxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dBcHByb3ZlTW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dBcHByb3ZlTW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5BcHByb3ZlIFBpZ215IFJlcXVlc3Q8L2gzPlxyXG4gICAgICAgICAgICB7Y3VycmVudEN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkN1c3RvbWVyOjwvc3Ryb25nPiB7Y3VycmVudEN1c3RvbWVyLmN1c3RvbWVyX25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+QW1vdW50Ojwvc3Ryb25nPiDigrl7Y3VycmVudEN1c3RvbWVyLnBheWFibGVfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPlJlZmVycmVkIEJ5Ojwvc3Ryb25nPiB7Y3VycmVudEN1c3RvbWVyLnJlZmVycmVkX2J5fVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNiB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERvIHlvdSB3YW50IHRvIGFwcHJvdmUgdGhpcyBwaWdteSByZXF1ZXN0P1xyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QXBwcm92ZU1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwcm92ZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEFwcHJvdmVcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIHsvKiBXaXRoZHJhdyBNb2RhbCAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd1dpdGhkcmF3TW9kYWx9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dXaXRoZHJhd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0V2l0aGRyYXdEYXRhKG51bGwpO1xyXG4gICAgICAgICAgICBzZXRTaG93Q2FsY3VsYXRlZChmYWxzZSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgc2hvd0Nsb3NlQnV0dG9uPXtmYWxzZX0gICAvLyDwn5GIIGRpc2FibGUgdGhlIGRlZmF1bHQgZ3JleSBjbG9zZSBidXR0b25cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgIHsvKiBDdXN0b20gcmVkIGNsb3NlIGljb24gKi99XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93V2l0aGRyYXdNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICBzZXRXaXRoZHJhd0RhdGEobnVsbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93Q2FsY3VsYXRlZChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0xIHRleHQtcmVkLTYwMCBob3Zlcjp0ZXh0LXJlZC04MDAgXHJcbiAgICAgICAgICAgICAgICAgdGV4dC14bCBmb250LWJvbGQgei0xMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICDinJVcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXB1cnBsZS02MDAgdG8taW5kaWdvLTYwMCBweC0yIHB5LTUgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgV2l0aGRyYXcgUGlnbXkgQWNjb3VudFxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTEwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgUmV2aWV3IGRldGFpbHMgYmVmb3JlIHByb2Nlc3Npbmcgd2l0aGRyYXdhbFxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIHt3aXRoZHJhd0RhdGEucmVxdWVzdF9zdGF0dXMgPT09IFwiQVBQUk9WRURcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMyBweS0xIGJnLWdyZWVuLTIwMCB0ZXh0LWdyZWVuLTgwMCByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBcHByb3ZlZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge3dpdGhkcmF3RGF0YS5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJSRVFVRVNURURcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMyBweS0xIGJnLXllbGxvdy0yMDAgdGV4dC15ZWxsb3ctODAwIHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFJlcXVlc3RlZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge3dpdGhkcmF3RGF0YS5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJDT01QTEVURURcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMyBweS0xIGJnLWJsdWUtMjAwIHRleHQtYmx1ZS04MDAgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29tcGxldGVkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLnJlcXVlc3Rfc3RhdHVzID09PSBcIkNMT1NFRFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctZ3JheS0yMDAgdGV4dC1ncmF5LTgwMCByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDbG9zZWRcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7d2l0aGRyYXdEYXRhICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxyXG4gICAgICAgICAgICAgICAgey8qIFBpZ215IERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCByb3VuZGVkLXhsIHAtNSBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGlnbXkgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+UGlnbXkgSUQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj57d2l0aGRyYXdEYXRhLnBpZ21lX2lkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+Q3VzdG9tZXIgTmFtZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLmN1c3RvbWVyPy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtMyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlBheW1lbnQgVHlwZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLm1hdHVyaXR5X3BlcmlvZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt3aXRoZHJhd0RhdGEubWF0dXJpdHlfcGVyaW9kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcYlxcdy9nLCAoY2hhcikgPT4gY2hhci50b1VwcGVyQ2FzZSgpKX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhaWQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYmx1ZS02MDAgdGV4dC1sZ1wiPuKCuXt3aXRoZHJhd0RhdGEucGF5YWJsZV9hbW91bnR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlRvdGFsIFBhaWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+4oK5e3dpdGhkcmF3RGF0YS50b3RhbF9wYWlkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC00XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+TW9udGhzIENvbXBsZXRlZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLnN0YXJ0X2RhdGUgPyAoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0YXJ0ID0gZGF5anMod2l0aGRyYXdEYXRhLnN0YXJ0X2RhdGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvZGF5ID0gZGF5anMoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbW9udGhzID0gKHRvZGF5LnllYXIoKSAtIHN0YXJ0LnllYXIoKSkgKiAxMiArICh0b2RheS5tb250aCgpIC0gc3RhcnQubW9udGgoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGhzID0gTWF0aC5tYXgoMCwgbW9udGhzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYCR7bW9udGhzfSAvICR7d2l0aGRyYXdEYXRhLmR1cmF0aW9uIHx8ICc/J30gbW9udGhzYDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSkoKSA6ICctJ31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhPy5jbG9zdXJlX3R5cGUgPT09IFwiTUFUVVJFRFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkludGVyZXN0IFJhdGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi02MDBcIj57d2l0aGRyYXdEYXRhLm1hdHVyaXR5X2ludGVyZXN0fSU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkNsb3N1cmUgVHlwZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bSBiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt3aXRoZHJhd0RhdGEuY2xvc3VyZV90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+U3RhcnQgRGF0ZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUod2l0aGRyYXdEYXRhLnN0YXJ0X2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5EdXJhdGlvbjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLmR1cmF0aW9ufSBNb250aHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogRWRpdGFibGUgUHJlLW1hdHVyZWQgSW50ZXJlc3QgRmllbGQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgd2l0aGRyYXdEYXRhLmNsb3N1cmVfdHlwZSA9PT0gXCJQUkUtTUFUVVJFRFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+IFByZW1hdHVyZSBXaXRoZHJhd2FsIERlZHVjdGlvbiAoJSk8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiYW55XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0YWJsZUludGVyZXN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0YWJsZUludGVyZXN0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHVycGxlLTUwMCBmb2N1czpib3JkZXItcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGludGVyZXN0IHBlcmNlbnRhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ2FsY3VsYXRlZCBWYWx1ZXMgKi99XHJcbiAgICAgICAgICAgICAgICB7c2hvd0NhbGN1bGF0ZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MCB0by1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtMnhsIHAtNSBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIENhbGN1bGF0ZWQgVmFsdWVzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBQYWlkPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3dpdGhkcmF3RGF0YS50b3RhbF9wYWlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPnt3aXRoZHJhd0RhdGEuY2xvc3VyZV90eXBlID09PSBcIlBSRS1NQVRVUkVEXCIgPyBcIiBQcmVtYXR1cmUgV2l0aGRyYXdhbCBEZWR1Y3Rpb24gKCUpXCIgOiBcIk1hdHVyaXR5IEludGVyZXN0ICglKVwifTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtgdGV4dC14bCBmb250LWJvbGQgJHt3aXRoZHJhd0RhdGEuY2xvc3VyZV90eXBlID09PSBcIlBSRS1NQVRVUkVEXCIgPyBcInRleHQtcmVkLTYwMFwiIDogXCJ0ZXh0LWdyZWVuLTYwMFwifWB9Pnt3aXRoZHJhd0RhdGEuY2xvc3VyZV90eXBlID09PSBcIlBSRS1NQVRVUkVEXCIgPyB3aXRoZHJhd0RhdGEucHJlX21hdHVyZWRfaW50ZXJlc3QgOiB3aXRoZHJhd0RhdGEubWF0dXJpdHlfaW50ZXJlc3R9JTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5NYXR1cml0eSBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcHVycGxlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXt3aXRoZHJhd0RhdGEubWF0dXJpdHlfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEZvb3RlciBCdXR0b25zICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIGJvcmRlci10IHB0LTVcIj5cclxuICAgICAgICAgICAgICAgICAgeyFzaG93Q2FsY3VsYXRlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDYWxjdWxhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTYwMCB0by1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgZm9udC1tZWRpdW0gc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGYUNhbGN1bGF0b3IgLz4gQ2FsY3VsYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dXaXRoZHJhd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRXaXRoZHJhd0RhdGEobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd0NhbGN1bGF0ZWQoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNzAwIHJvdW5kZWQteGwgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlV2l0aGRyYXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBmb250LW1lZGl1bSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIERvbmVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogRGVsZXRlIE1vZGFsICh1bmNoYW5nZWQpICovfVxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX0gb25DbG9zZT17KCkgPT4geyBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpOyBzZXRDdXJyZW50Q3VzdG9tZXIobnVsbCk7IH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkRlbGV0ZSBQaWdteSBDdXN0b21lcjwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50Q3VzdG9tZXIgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IGhhbmRsZURlbGV0ZVBpZ21lKCk7IH19IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj57Y3VycmVudEN1c3RvbWVyLmN1c3RvbWVyLmZ1bGxfbmFtZX08L3NwYW4+IHRvIGNvbmZpcm0gZGVsZXRpb24uXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIFBpZ215IEN1c3RvbWVyIE5hbWVcIiByZXF1aXJlZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdy1mdWxsIHAtMi41IHJvdW5kZWQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCI+RGVsZXRlPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGlnbWU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BpZ21lLmpzeCJ9