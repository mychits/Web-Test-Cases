import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LegalsMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap, Shield, UserCheck, Sparkles, Gavel, Upload, HandCoins } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { FaHandshake } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
const LegalsMenu = () => {
  const legalsCategories = [
    {
      id: "guarantor",
      title: "Guarantor",
      description: "Manage guarantor information and documentation",
      icon: FaHandshake,
      gradient: "from-violet-500 via-purple-500 to-pink-500",
      bgGradient: "from-violet-50 via-purple-50 to-pink-50",
      href: "/legals-menu/guarantor",
      stats: "Active Guarantors",
      secondaryIcon: Shield,
      iconColor: "text-violet-600",
      bgColor: "bg-violet-100"
    },
    {
      id: "coapplicant",
      title: "Co Applicant",
      description: "Manage co‑applicant information",
      icon: FaHandshake,
      gradient: "from-blue-500 via-cyan-500 to-teal-500",
      bgGradient: "from-blue-50 via-cyan-50 to-teal-50",
      href: "/legals-menu/co-applicant",
      stats: "Active Co‑Applicants",
      secondaryIcon: UserCheck,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      id: "auction",
      title: "Auction Documentation Process",
      description: "Collect, verify, and complete all required auction documents.",
      icon: Gavel,
      gradient: "from-amber-500 via-orange-500 to-red-500",
      bgGradient: "from-amber-50 via-orange-50 to-red-50",
      href: "/legals-menu/recent-auction",
      stats: "Active Recent Auctions",
      secondaryIcon: Gavel,
      iconColor: "text-amber-600",
      bgColor: "bg-amber-100"
    },
    {
      id: "Document",
      title: "Customer KYC Document Management",
      description: "Upload, view, and manage customer documents",
      icon: Upload,
      gradient: "from-blue-500 via-blue-600 to-indigo-600",
      bgGradient: "from-blue-50 via-indigo-50 to-blue-100",
      href: "/legals-menu/user-document",
      stats: "Document Records",
      secondaryIcon: Upload,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      id: "LoanDocument",
      title: "Customer Loan Documentation Process",
      description: "Collect, verify, and complete all required loan documents.",
      icon: HandCoins,
      gradient: "from-blue-500 via-blue-600 to-indigo-600",
      bgGradient: "from-blue-50 via-indigo-50 to-blue-100",
      href: "/legals-menu/Recent-Loans",
      stats: "Active Recent Loans",
      secondaryIcon: Upload,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      id: "linked-guarantor",
      title: "Linked Guarantor",
      description: "Manage linked guarantor information and documentation",
      icon: FaHandshake,
      gradient: "from-violet-500 via-purple-500 to-pink-500",
      bgGradient: "from-violet-50 via-purple-50 to-pink-50",
      href: "/legals-menu/linked-guarantor",
      stats: "Active Linked Guarantors",
      secondaryIcon: Shield,
      iconColor: "text-violet-600",
      bgColor: "bg-violet-100"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex overflow-hidden mt-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full relative overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
        lineNumber: 92,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
          lineNumber: 94,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-8 relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-12", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-600 to-purple-600 rounded-2xl blur-lg opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 99,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-2xl", children: /* @__PURE__ */ jsxDEV(FaHandshake, { className: "w-8 h-8 text-white" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 101,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 100,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
              lineNumber: 98,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 bg-clip-text text-transparent", children: "Legal Management" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 105,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 mt-1 text-lg", children: "Manage and organize guarantor information and documentation" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 108,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
              lineNumber: 104,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
            lineNumber: 97,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
            lineNumber: 96,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12", children: legalsCategories.map((category) => {
            const Icon = category.icon;
            const SecondaryIcon = category.secondaryIcon;
            return /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV("div", { className: "relative h-full overflow-hidden rounded-3xl bg-white/80 backdrop-blur-xl border border-white/20 shadow-2xl hover:shadow-3xl transition-all duration-700 transform hover:-translate-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-3xl bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-700 p-[2px]", children: /* @__PURE__ */ jsxDEV("div", { className: `w-full h-full rounded-3xl bg-gradient-to-r ${category.gradient}` }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 123,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 122,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative h-full bg-white rounded-3xl p-8 flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("div", { className: `absolute top-4 right-4 w-32 h-32 rounded-full bg-gradient-to-br ${category.bgGradient} opacity-30 blur-2xl` }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 129,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-4 relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-3 bg-gradient-to-r from-violet-400 to-purple-400 rounded-2xl blur-lg opacity-0 group-hover:opacity-40 transition duration-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                      lineNumber: 134,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: `relative w-16 h-16 rounded-2xl ${category.bgColor} flex items-center justify-center shadow-xl border border-white/50 group-hover:scale-110 transition-transform duration-500`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-6 h-6 ${category.iconColor}` }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                      lineNumber: 136,
                      columnNumber: 31
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                      lineNumber: 135,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 133,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-2xl bg-gradient-to-br from-slate-50 to-white shadow-lg border border-slate-200/50 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-x-4 group-hover:translate-x-0", children: /* @__PURE__ */ jsxDEV(SecondaryIcon, { className: "w-5 h-5 text-slate-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 140,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 139,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 132,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mb-4 relative", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-slate-900 mb-3 group-hover:bg-gradient-to-r group-hover:from-violet-600 group-hover:to-purple-600 group-hover:bg-clip-text group-hover:text-transparent transition-all duration-500", children: category.title }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 146,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 leading-relaxed", children: category.description }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 149,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 145,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-6 border-t border-slate-200/50 relative mt-auto", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-green-500 rounded-full animate-pulse" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                        lineNumber: 158,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 w-2 h-2 bg-green-500 rounded-full animate-ping" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                        lineNumber: 159,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                      lineNumber: 157,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-slate-500 uppercase tracking-wide", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                      lineNumber: 161,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 156,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-violet-600 opacity-0 group-hover:opacity-100 transform translate-x-4 group-hover:translate-x-0 transition-all duration-500", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold", children: "Explore" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                      lineNumber: 166,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-5 h-5" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                      lineNumber: 167,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 165,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 155,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 127,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
              lineNumber: 120,
              columnNumber: 21
            }, this) }, category.id, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
              lineNumber: 119,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
            lineNumber: 114,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative p-8 bg-gradient-to-br from-violet-50 via-purple-50 to-pink-50 rounded-3xl border border-white/50 shadow-2xl overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-violet-200/30 to-transparent rounded-full blur-3xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
              lineNumber: 178,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-40 h-40 bg-gradient-to-tr from-purple-200/30 to-transparent rounded-full blur-3xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
              lineNumber: 179,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-2 bg-gradient-to-r from-violet-500 to-purple-500 rounded-2xl blur-lg opacity-50 group-hover:opacity-75 transition duration-300" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 183,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative w-14 h-14 rounded-2xl bg-white shadow-xl flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-7 h-7 text-violet-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 185,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 184,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 182,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-slate-900 mb-2 flex items-center gap-2", children: [
                  "Quick Tips",
                  /* @__PURE__ */ jsxDEV(Sparkles, { className: "w-5 h-5 text-violet-500 animate-pulse" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                    lineNumber: 191,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 189,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700 leading-relaxed", children: "Use the Legal directory to manage Guarantor Information, update guarantor details and documentation all in one place." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 193,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700 leading-relaxed mt-2", children: "Keep your legal records organized and easily accessible for compliance and reference purposes." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                  lineNumber: 196,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
                lineNumber: 188,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
              lineNumber: 181,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
            lineNumber: 177,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
          lineNumber: 95,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
        lineNumber: 93,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        @keyframes tilt {
          0%, 50%, 100% {
            transform: rotate(0deg);
          }
          25% {
            transform: rotate(0.5deg);
          }
          75% {
            transform: rotate(-0.5deg);
          }
        }
        .animate-tilt {
          animation: tilt 10s infinite;
        }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
      lineNumber: 206,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx",
    lineNumber: 90,
    columnNumber: 5
  }, this);
};
_c = LegalsMenu;
export default LegalsMenu;
var _c;
$RefreshReg$(_c, "LegalsMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LegalsMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkZRO0FBM0ZSLDJCQUFxQjtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkMsT0FBT0EsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLE9BQU9DLFdBQVdDLGNBQWNDLEtBQUtDLFFBQVFDLFdBQVdDLFVBQVVDLE9BQU9DLFFBQVFDLGlCQUFpQjtBQUMzRyxTQUFTQyxtQkFBbUI7QUFFNUIsTUFBTUMsYUFBYUEsTUFBTTtBQUN2QixRQUFNQyxtQkFBbUI7QUFBQSxJQUN2QjtBQUFBLE1BQ0VDLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU1OO0FBQUFBLE1BQ05PLFVBQVU7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxlQUFlakI7QUFBQUEsTUFDZmtCLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFVixJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNTjtBQUFBQSxNQUNOTyxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZWhCO0FBQUFBLE1BQ2ZpQixXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsTUFDRVYsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTVQ7QUFBQUEsTUFDTlUsVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLGVBQWVkO0FBQUFBLE1BQ2ZlLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFVixJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNUjtBQUFBQSxNQUNOUyxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZWI7QUFBQUEsTUFDZmMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLE1BQ0VWLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU1QO0FBQUFBLE1BQ05RLFVBQVU7QUFBQSxNQUNWQyxZQUFZO0FBQUEsTUFDWkMsTUFBTTtBQUFBLE1BQ05DLE9BQU87QUFBQSxNQUNQQyxlQUFlYjtBQUFBQSxNQUNmYyxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsTUFDRVYsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTU47QUFBQUEsTUFDTk8sVUFBVTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLGVBQWVqQjtBQUFBQSxNQUNma0IsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxJQUNYO0FBQUEsRUFBQztBQUdILFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLCtCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsUUFDekIsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDRMQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdNO0FBQUEsY0FDeE0sdUJBQUMsU0FBSSxXQUFVLDhIQUNiLGlDQUFDLGVBQVksV0FBVSx3QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsZ0hBQStHLGdDQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLDJFQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRztBQUFBLGlCQUp4RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDhEQUNaWCwyQkFBaUJZLElBQUksQ0FBQ0MsYUFBYTtBQUNsQyxrQkFBTUMsT0FBT0QsU0FBU1Q7QUFDdEIsa0JBQU1XLGdCQUFnQkYsU0FBU0o7QUFDL0IsbUJBQ0UsdUJBQUMsUUFBdUIsSUFBSUksU0FBU04sTUFBTSxXQUFVLFNBQ25ELGlDQUFDLFNBQUksV0FBVSwwTEFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwySEFDYixpQ0FBQyxTQUFJLFdBQVcsOENBQThDTSxTQUFTUixRQUFRLE1BQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GLEtBRHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSwwREFFYjtBQUFBLHVDQUFDLFNBQUksV0FBVyxtRUFBbUVRLFNBQVNQLFVBQVUsMEJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThIO0FBQUEsZ0JBRzlILHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxtSkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErSjtBQUFBLG9CQUMvSix1QkFBQyxTQUFJLFdBQVcsa0NBQWtDTyxTQUFTRixPQUFPLDhIQUNoRSxpQ0FBQyxRQUFLLFdBQVcsV0FBV0UsU0FBU0gsU0FBUyxNQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxpTkFDYixpQ0FBQyxpQkFBYyxXQUFVLDRCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSw4TUFDWEcsbUJBQVNYLFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVlcsbUJBQVNWLGVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSxxREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRTtBQUFBLHNCQUNqRSx1QkFBQyxTQUFJLFdBQVUscUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUY7QUFBQSx5QkFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSw4REFDYlUsbUJBQVNMLFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkpBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUJBQXdCLHVCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQztBQUFBLG9CQUMvQyx1QkFBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsdUJBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsbUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkNBO0FBQUEsaUJBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbURBLEtBcERTSyxTQUFTWixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFEQTtBQUFBLFVBRUosQ0FBQyxLQTVESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZEQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHdJQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdIQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRIO0FBQUEsWUFDNUgsdUJBQUMsU0FBSSxXQUFVLGtIQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThIO0FBQUEsWUFFOUgsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG9KQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdLO0FBQUEsZ0JBQ2hLLHVCQUFDLFNBQUksV0FBVSxzRkFDYixpQ0FBQyxPQUFJLFdBQVUsNkJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGlFQUFnRTtBQUFBO0FBQUEsa0JBRTVFLHVCQUFDLFlBQVMsV0FBVSwyQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkQ7QUFBQSxxQkFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FBaUMscUlBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsdUNBQXNDLDhHQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsYUExR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJHQTtBQUFBLFdBN0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4R0E7QUFBQSxTQWhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUhBO0FBQUEsSUFFQSx1QkFBQyxXQUFNLEtBQUcsTUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0NFO0FBQUEsT0ExSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJKQTtBQUVKO0FBQUVlLEtBaFBJakI7QUFrUE4sZUFBZUE7QUFBVyxJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5hdmJhciIsIlNpZGViYXIiLCJVc2VycyIsIkJyaWVmY2FzZSIsIkNoZXZyb25SaWdodCIsIlphcCIsIlNoaWVsZCIsIlVzZXJDaGVjayIsIlNwYXJrbGVzIiwiR2F2ZWwiLCJVcGxvYWQiLCJIYW5kQ29pbnMiLCJGYUhhbmRzaGFrZSIsIkxlZ2Fsc01lbnUiLCJsZWdhbHNDYXRlZ29yaWVzIiwiaWQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiaWNvbiIsImdyYWRpZW50IiwiYmdHcmFkaWVudCIsImhyZWYiLCJzdGF0cyIsInNlY29uZGFyeUljb24iLCJpY29uQ29sb3IiLCJiZ0NvbG9yIiwibWFwIiwiY2F0ZWdvcnkiLCJJY29uIiwiU2Vjb25kYXJ5SWNvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxlZ2Fsc01lbnUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBVc2VycywgQnJpZWZjYXNlLCBDaGV2cm9uUmlnaHQsIFphcCwgU2hpZWxkLCBVc2VyQ2hlY2ssIFNwYXJrbGVzLCBHYXZlbCwgVXBsb2FkLCBIYW5kQ29pbnMgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEZhSGFuZHNoYWtlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcblxyXG5jb25zdCBMZWdhbHNNZW51ID0gKCkgPT4ge1xyXG4gIGNvbnN0IGxlZ2Fsc0NhdGVnb3JpZXMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcImd1YXJhbnRvclwiLFxyXG4gICAgICB0aXRsZTogXCJHdWFyYW50b3JcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGd1YXJhbnRvciBpbmZvcm1hdGlvbiBhbmQgZG9jdW1lbnRhdGlvblwiLFxyXG4gICAgICBpY29uOiBGYUhhbmRzaGFrZSxcclxuICAgICAgZ3JhZGllbnQ6IFwiZnJvbS12aW9sZXQtNTAwIHZpYS1wdXJwbGUtNTAwIHRvLXBpbmstNTAwXCIsXHJcbiAgICAgIGJnR3JhZGllbnQ6IFwiZnJvbS12aW9sZXQtNTAgdmlhLXB1cnBsZS01MCB0by1waW5rLTUwXCIsXHJcbiAgICAgIGhyZWY6IFwiL2xlZ2Fscy1tZW51L2d1YXJhbnRvclwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgR3VhcmFudG9yc1wiLFxyXG4gICAgICBzZWNvbmRhcnlJY29uOiBTaGllbGQsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LXZpb2xldC02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy12aW9sZXQtMTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcImNvYXBwbGljYW50XCIsXHJcbiAgICAgIHRpdGxlOiBcIkNvIEFwcGxpY2FudFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgY2/igJFhcHBsaWNhbnQgaW5mb3JtYXRpb25cIixcclxuICAgICAgaWNvbjogRmFIYW5kc2hha2UsXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tYmx1ZS01MDAgdmlhLWN5YW4tNTAwIHRvLXRlYWwtNTAwXCIsXHJcbiAgICAgIGJnR3JhZGllbnQ6IFwiZnJvbS1ibHVlLTUwIHZpYS1jeWFuLTUwIHRvLXRlYWwtNTBcIixcclxuICAgICAgaHJlZjogXCIvbGVnYWxzLW1lbnUvY28tYXBwbGljYW50XCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBDb+KAkUFwcGxpY2FudHNcIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogVXNlckNoZWNrLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1ibHVlLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLWJsdWUtMTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcImF1Y3Rpb25cIixcclxuICAgICAgdGl0bGU6IFwiQXVjdGlvbiBEb2N1bWVudGF0aW9uIFByb2Nlc3NcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiQ29sbGVjdCwgdmVyaWZ5LCBhbmQgY29tcGxldGUgYWxsIHJlcXVpcmVkIGF1Y3Rpb24gZG9jdW1lbnRzLlwiLFxyXG4gICAgICBpY29uOiBHYXZlbCxcclxuICAgICAgZ3JhZGllbnQ6IFwiZnJvbS1hbWJlci01MDAgdmlhLW9yYW5nZS01MDAgdG8tcmVkLTUwMFwiLFxyXG4gICAgICBiZ0dyYWRpZW50OiBcImZyb20tYW1iZXItNTAgdmlhLW9yYW5nZS01MCB0by1yZWQtNTBcIixcclxuICAgICAgaHJlZjogXCIvbGVnYWxzLW1lbnUvcmVjZW50LWF1Y3Rpb25cIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIFJlY2VudCBBdWN0aW9uc1wiLFxyXG4gICAgICBzZWNvbmRhcnlJY29uOiBHYXZlbCxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtYW1iZXItNjAwXCIsXHJcbiAgICAgIGJnQ29sb3I6IFwiYmctYW1iZXItMTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIkRvY3VtZW50XCIsXHJcbiAgICAgIHRpdGxlOiBcIkN1c3RvbWVyIEtZQyBEb2N1bWVudCBNYW5hZ2VtZW50XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlVwbG9hZCwgdmlldywgYW5kIG1hbmFnZSBjdXN0b21lciBkb2N1bWVudHNcIixcclxuICAgICAgaWNvbjogVXBsb2FkLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLWJsdWUtNTAwIHZpYS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwXCIsXHJcbiAgICAgIGJnR3JhZGllbnQ6IFwiZnJvbS1ibHVlLTUwIHZpYS1pbmRpZ28tNTAgdG8tYmx1ZS0xMDBcIixcclxuICAgICAgaHJlZjogXCIvbGVnYWxzLW1lbnUvdXNlci1kb2N1bWVudFwiLFxyXG4gICAgICBzdGF0czogXCJEb2N1bWVudCBSZWNvcmRzXCIsXHJcbiAgICAgIHNlY29uZGFyeUljb246IFVwbG9hZCxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtYmx1ZS02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy1ibHVlLTEwMFwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogXCJMb2FuRG9jdW1lbnRcIixcclxuICAgICAgdGl0bGU6IFwiQ3VzdG9tZXIgTG9hbiBEb2N1bWVudGF0aW9uIFByb2Nlc3NcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiQ29sbGVjdCwgdmVyaWZ5LCBhbmQgY29tcGxldGUgYWxsIHJlcXVpcmVkIGxvYW4gZG9jdW1lbnRzLlwiLFxyXG4gICAgICBpY29uOiBIYW5kQ29pbnMsXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tYmx1ZS01MDAgdmlhLWJsdWUtNjAwIHRvLWluZGlnby02MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLWJsdWUtNTAgdmlhLWluZGlnby01MCB0by1ibHVlLTEwMFwiLFxyXG4gICAgICBocmVmOiBcIi9sZWdhbHMtbWVudS9SZWNlbnQtTG9hbnNcIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIFJlY2VudCBMb2Fuc1wiLFxyXG4gICAgICBzZWNvbmRhcnlJY29uOiBVcGxvYWQsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LWJsdWUtNjAwXCIsXHJcbiAgICAgIGJnQ29sb3I6IFwiYmctYmx1ZS0xMDBcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IFwibGlua2VkLWd1YXJhbnRvclwiLFxyXG4gICAgICB0aXRsZTogXCJMaW5rZWQgR3VhcmFudG9yXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBsaW5rZWQgZ3VhcmFudG9yIGluZm9ybWF0aW9uIGFuZCBkb2N1bWVudGF0aW9uXCIsXHJcbiAgICAgIGljb246IEZhSGFuZHNoYWtlLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLXZpb2xldC01MDAgdmlhLXB1cnBsZS01MDAgdG8tcGluay01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLXZpb2xldC01MCB2aWEtcHVycGxlLTUwIHRvLXBpbmstNTBcIixcclxuICAgICAgaHJlZjogXCIvbGVnYWxzLW1lbnUvbGlua2VkLWd1YXJhbnRvclwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgTGlua2VkIEd1YXJhbnRvcnNcIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogU2hpZWxkLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC12aW9sZXQtNjAwXCIsXHJcbiAgICAgIGJnQ29sb3I6IFwiYmctdmlvbGV0LTEwMFwiXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggb3ZlcmZsb3ctaGlkZGVuIG10LTIwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcmVsYXRpdmVcIj5cclxuICAgICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTEgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tcHVycGxlLTYwMCByb3VuZGVkLTJ4bCBibHVyLWxnIG9wYWNpdHktNzUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0xMDAwIGdyb3VwLWhvdmVyOmR1cmF0aW9uLTIwMCBhbmltYXRlLXRpbHRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTE2IGgtMTYgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAwIHRvLXB1cnBsZS02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LTJ4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYUhhbmRzaGFrZSBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtOTAwIHZpYS1wdXJwbGUtOTAwIHRvLXNsYXRlLTkwMCBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIExlZ2FsIE1hbmFnZW1lbnRcclxuICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgbXQtMSB0ZXh0LWxnXCI+TWFuYWdlIGFuZCBvcmdhbml6ZSBndWFyYW50b3IgaW5mb3JtYXRpb24gYW5kIGRvY3VtZW50YXRpb248L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogR3JpZCB3aXRoIGVxdWFsIGhlaWdodCBjYXJkcyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC04IG1iLTEyXCI+XHJcbiAgICAgICAgICAgICAge2xlZ2Fsc0NhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGNhdGVnb3J5Lmljb247XHJcbiAgICAgICAgICAgICAgICBjb25zdCBTZWNvbmRhcnlJY29uID0gY2F0ZWdvcnkuc2Vjb25kYXJ5SWNvbjtcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxMaW5rIGtleT17Y2F0ZWdvcnkuaWR9IHRvPXtjYXRlZ29yeS5ocmVmfSBjbGFzc05hbWU9XCJncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTN4bCBiZy13aGl0ZS84MCBiYWNrZHJvcC1ibHVyLXhsIGJvcmRlciBib3JkZXItd2hpdGUvMjAgc2hhZG93LTJ4bCBob3ZlcjpzaGFkb3ctM3hsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTcwMCB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBIb3ZlciBib3JkZXIgZ3JhZGllbnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcm91bmRlZC0zeGwgYmctZ3JhZGllbnQtdG8tciBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTcwMCBwLVsycHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy1mdWxsIGgtZnVsbCByb3VuZGVkLTN4bCBiZy1ncmFkaWVudC10by1yICR7Y2F0ZWdvcnkuZ3JhZGllbnR9YH0+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogTWFpbiBjYXJkIGNvbnRlbnQgLSBGSVhFRDogQWRkZWQgZmxleCBjb2x1bW4gYW5kIGgtZnVsbCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC1mdWxsIGJnLXdoaXRlIHJvdW5kZWQtM3hsIHAtOCBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCYWNrZ3JvdW5kIGJsdXIgZWxlbWVudCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtNCByaWdodC00IHctMzIgaC0zMiByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgJHtjYXRlZ29yeS5iZ0dyYWRpZW50fSBvcGFjaXR5LTMwIGJsdXItMnhsYH0+PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogSGVhZGVyIHdpdGggaWNvbiAtIEZpeGVkIHNwYWNpbmcgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gbWItNCByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC00MDAgdG8tcHVycGxlLTQwMCByb3VuZGVkLTJ4bCBibHVyLWxnIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTQwIHRyYW5zaXRpb24gZHVyYXRpb24tNTAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHJlbGF0aXZlIHctMTYgaC0xNiByb3VuZGVkLTJ4bCAke2NhdGVnb3J5LmJnQ29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzUwIGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPXtgdy02IGgtNiAke2NhdGVnb3J5Lmljb25Db2xvcn1gfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS01MCB0by13aGl0ZSBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNTAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCB0cmFuc2Zvcm0gdHJhbnNsYXRlLXgtNCBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2Vjb25kYXJ5SWNvbiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc2xhdGUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQ29udGVudCAtIEZJWEVEOiBBZGRlZCBmbGV4LTEgdG8gcHVzaCBmb290ZXIgZG93biAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWItNCByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi0zIGdyb3VwLWhvdmVyOmJnLWdyYWRpZW50LXRvLXIgZ3JvdXAtaG92ZXI6ZnJvbS12aW9sZXQtNjAwIGdyb3VwLWhvdmVyOnRvLXB1cnBsZS02MDAgZ3JvdXAtaG92ZXI6YmctY2xpcC10ZXh0IGdyb3VwLWhvdmVyOnRleHQtdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvb3RlciAtIEZpeGVkOiBBbHdheXMgYXQgYm90dG9tICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC02IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAvNTAgcmVsYXRpdmUgbXQtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIgaC0yIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgdy0yIGgtMiBiZy1ncmVlbi01MDAgcm91bmRlZC1mdWxsIGFuaW1hdGUtcGluZ1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5zdGF0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtdmlvbGV0LTYwMCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNmb3JtIHRyYW5zbGF0ZS14LTQgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZFwiPkV4cGxvcmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHZpYS1wdXJwbGUtNTAgdG8tcGluay01MCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXdoaXRlLzUwIHNoYWRvdy0yeGwgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctNDAgaC00MCBiZy1ncmFkaWVudC10by1ibCBmcm9tLXZpb2xldC0yMDAvMzAgdG8tdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGJsdXItM3hsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgdy00MCBoLTQwIGJnLWdyYWRpZW50LXRvLXRyIGZyb20tcHVycGxlLTIwMC8zMCB0by10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYmx1ci0zeGxcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAwIHRvLXB1cnBsZS01MDAgcm91bmRlZC0yeGwgYmx1ci1sZyBvcGFjaXR5LTUwIGdyb3VwLWhvdmVyOm9wYWNpdHktNzUgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctd2hpdGUgc2hhZG93LXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtdmlvbGV0LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFF1aWNrIFRpcHNcclxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXZpb2xldC01MDAgYW5pbWF0ZS1wdWxzZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZSB0aGUgTGVnYWwgZGlyZWN0b3J5IHRvIG1hbmFnZSBHdWFyYW50b3IgSW5mb3JtYXRpb24sIHVwZGF0ZSBndWFyYW50b3IgZGV0YWlscyBhbmQgZG9jdW1lbnRhdGlvbiBhbGwgaW4gb25lIHBsYWNlLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGxlYWRpbmctcmVsYXhlZCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgS2VlcCB5b3VyIGxlZ2FsIHJlY29yZHMgb3JnYW5pemVkIGFuZCBlYXNpbHkgYWNjZXNzaWJsZSBmb3IgY29tcGxpYW5jZSBhbmQgcmVmZXJlbmNlIHB1cnBvc2VzLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8c3R5bGUganN4PntgXHJcbiAgICAgICAgQGtleWZyYW1lcyBibG9iIHtcclxuICAgICAgICAgIDAlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMHB4LCAwcHgpIHNjYWxlKDEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgMzMlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMzBweCwgLTUwcHgpIHNjYWxlKDEuMSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICA2NiUge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMjBweCwgMjBweCkgc2NhbGUoMC45KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDEwMCUge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgwcHgsIDBweCkgc2NhbGUoMSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRlLWJsb2Ige1xyXG4gICAgICAgICAgYW5pbWF0aW9uOiBibG9iIDdzIGluZmluaXRlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuYW5pbWF0aW9uLWRlbGF5LTIwMDAge1xyXG4gICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAycztcclxuICAgICAgICB9XHJcbiAgICAgICAgLmFuaW1hdGlvbi1kZWxheS00MDAwIHtcclxuICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogNHM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIEBrZXlmcmFtZXMgdGlsdCB7XHJcbiAgICAgICAgICAwJSwgNTAlLCAxMDAlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAyNSUge1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwLjVkZWcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgNzUlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoLTAuNWRlZyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRlLXRpbHQge1xyXG4gICAgICAgICAgYW5pbWF0aW9uOiB0aWx0IDEwcyBpbmZpbml0ZTtcclxuICAgICAgICB9XHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMZWdhbHNNZW51OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9MZWdhbHNNZW51LmpzeCJ9